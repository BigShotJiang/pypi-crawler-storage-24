# OpenClaw Installer

A simple, zero-configuration installer for [OpenClaw](https://openclaw.ai) that works on Windows, macOS, and Linux.

[![PyPI](https://img.shields.io/pypi/v/openclaw-installer)](https://pypi.org/project/openclaw-installer/)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

**Author:** Gerald Enrique Nelson Mc Kenzie

---

## What It Does

This installer handles everything in one command:

1. Downloads and installs Node.js v22.16.0 (isolated, doesn't affect your system)
2. Installs OpenClaw from npm
3. Starts the OpenClaw gateway on port 18789
4. Opens the dashboard in your browser

No complex configuration needed.

---

## Installation

**Prerequisites:** Python 3.10+ and an internet connection.

```bash
# Install pipx if you don't have it
pip install pipx
pipx ensurepath

# Install the OpenClaw Installer
pipx install openclaw-installer

# Run the installer
openclaw-installer install
```

---

## Usage

### Install OpenClaw

```bash
openclaw-installer install
```

Sets up Node.js in an isolated directory, installs OpenClaw, and starts the gateway at `http://localhost:18789`.

### Open the Dashboard

```bash
openclaw dashboard
```

Or open `http://localhost:18789` directly in your browser.

### Uninstall

```bash
openclaw-installer uninstall
```

---

## Configure OpenClaw (Required After Install)

### Step 1: Run the onboard command

```bash
openclaw onboard
```

This starts an interactive setup where you choose your AI provider and enter your API key:

```
$ openclaw onboard
? Select authentication provider: (Use arrow keys)
❯ Kimi
  Anthropic
  OpenAI
  Skip (configure later)

? Enter your Kimi API key: sk-xxxxxxxxxxxxxxxxxxxxxxxx
✓ Configuration saved to ~/.openclaw/openclaw.json
```

### Step 2: Refresh the dashboard

Go back to your browser at `http://127.0.0.1:18789` and press `F5` (or `Ctrl+R` / `Cmd+R`). Your configured AI providers will appear and you're ready to use OpenClaw.

---

## Commands

| Command | Description |
|---------|-------------|
| `openclaw-installer install` | Install OpenClaw and start the gateway |
| `openclaw-installer uninstall` | Remove the OpenClaw installation |
| `openclaw-installer dashboard` | Open the OpenClaw dashboard |
| `openclaw-installer --help` | Show help |

---

## Installation Locations

Everything is stored in isolated directories — no system files are modified.

- **Windows:** `%LOCALAPPDATA%\openclaw-installer\`
- **macOS / Linux:** `~/.local/share/openclaw-installer/`

OpenClaw's own configuration lives in `~/.openclaw/` and is not touched by the installer.

---

## Requirements

- Windows 10/11, macOS 12+, or Linux
- ~200MB free disk space
- Internet connection for initial download

---

## Troubleshooting

### Port 18789 is already in use

Find and stop the process using that port:

```bash
# macOS / Linux
lsof -i :18789

# Windows
netstat -ano | findstr 18789
```

### Gateway not starting

Check the gateway status and start it manually if needed:

```bash
openclaw gateway status
openclaw gateway start
```

### Command not found after install

Make sure the bin directory is on your PATH:

```bash
# macOS / Linux
export PATH="$HOME/.local/share/openclaw-installer/bin:$PATH"

# Windows (PowerShell)
$env:PATH = "$env:LOCALAPPDATA\openclaw-installer\bin;$env:PATH"
```

---

## License

MIT License — see [LICENSE](LICENSE)