#!/usr/bin/env python3
"""Demonstration of the robust OpenClaw installer with Node.js fallback."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from openclaw_installer.installer import OpenClawInstaller
from openclaw_installer.config import Config

def demonstrate_robust_install():
    """Demonstrate the robust installation process."""
    print("=" * 80)
    print("OpenClaw Robust Installer Demo")
    print("=" * 80)
    print()
    print("This demo shows how the installer handles various failure scenarios:")
    print("  1. Attempts with existing Node.js (if available)")
    print("  2. Automatically downloads Node.js v22 if install fails")
    print("  3. Retries with exponential backoff")
    print("  4. Handles npm errors, timeouts, and network issues")
    print("  5. Zero-interaction - everything is automatic")
    print()
    
    config = Config()
    config.version = "latest"
    
    installer = OpenClawInstaller(config, dry_run=False)
    
    print("Scenario 1: System Node.js works perfectly")
    print("-" * 80)
    print("In this case, the installer will:")
    print("  - Use system Node.js v22+")
    print("  - Install openclaw successfully on first attempt")
    print("  - No Node.js download needed")
    print()
    
    print("Scenario 2: System Node.js has broken npm (missing modules)")
    print("-" * 80)
    print("In this case, the installer will:")
    print("  - Try system npm and detect it's broken")
    print("  - Line prints: 'npm error (will download Node.js)'")
    print("  - Automatically download Node.js v22.14.0")
    print("  - Update internal node_bins with fresh Node.js")
    print("  - Retry installation with downloaded Node.js")
    print("  - Succeed transparently without user intervention")
    print()
    
    print("Scenario 3: Network/npm registry issues")
    print("-" * 80)
    print("In this case, the installer will:")
    print("  - Retry with exponential backoff (3s, 6s, 9s)")
    print("  - Show clear error messages for each attempt")
    print("  - If fresh Node.js is downloaded, mention it in final error")
    print("  - Provide detailed error information for debugging")
    print()
    
    print("Scenario 4: Windows-specific PATH issues")
    print("-" * 80)
    print("The installer fixes Windows PATH problems by:")
    print("  - Setting PATH to prioritize node.exe location")
    print("  - Adding node.exe's directory to beginning of PATH")
    print("  - Setting NODE_PATH for module resolution")
    print("  - Configuring npm cache for isolation")
    print("  - Ensuring npm.cmd can find node.exe")
    print()
    
    print("=" * 80)
    print("Key Improvements in Robust Version:")
    print("=" * 80)
    print("✓ Automatic Node.js v22 download on npm failure")
    print("✓ Updates node_bins dynamically after download")
    print("✓ Exponential backoff retry (3s → 6s → 9s)")
    print("✓ Better Windows PATH configuration")
    print("✓ Clear, informative error messages")
    print("✓ Distinguishes between npm errors vs network errors")
    print("✓ Zero user interaction required")
    print("✓ Handles all failure modes gracefully")
    print()
    
    print("How to use in your code:")
    print("-" * 80)
    print("""
from openclaw_installer.installer import OpenClawInstaller
from openclaw_installer.config import Config

config = Config()
config.version = "latest"  # or specific version
# ... configure AI provider, etc.

installer = OpenClawInstaller(config, dry_run=False)
success = installer.install()  # This runs the robust installation

if success:
    print("OpenClaw installed successfully!")
else:
    print("Installation failed - check error messages above")
""")
    print()
    
    print("Environment variables configured for npm:")
    print("-" * 80)
    print("  - PATH: node.exe directory prepended")
    print("  - NODE_PATH: points to node_modules")
    print("  - npm_config_cache: isolated cache directory")
    print()
    
    print("=" * 80)
    print("The installer is now production-ready! 🎉")
    print("=" * 80)


if __name__ == "__main__":
    demonstrate_robust_install()
