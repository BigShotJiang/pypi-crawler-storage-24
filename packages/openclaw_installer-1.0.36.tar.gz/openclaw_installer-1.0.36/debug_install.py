#!/usr/bin/env python3
"""Debug the installation paths."""

from pathlib import Path
import sys
import os

def get_install_base() -> Path:
    """Get base installation directory."""
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path.home() / ".local"
    return base / "openclaw-installer"

# Check what actually exists
install_base = get_install_base()
print(f"Install base: {install_base}")
print(f"Install base exists: {install_base.exists()}")

if install_base.exists():
    print(f"\nContents of {install_base}:")
    for item in install_base.iterdir():
        print(f"  {item.name}")
        if item.is_dir():
            print(f"    (directory)")
            # If it's node_modules, list its contents
            if item.name == "node_modules":
                print(f"    Contents of node_modules:")
                for subitem in item.iterdir():
                    print(f"      {subitem.name}")
            # If it's openclaw, check for node_modules
            elif item.name == "openclaw":
                node_modules = item / "node_modules"
                if node_modules.exists():
                    print(f"    Contents of openclaw/node_modules:")
                    for subitem in node_modules.iterdir():
                        print(f"      {subitem.name}")
                        if subitem.name == "openclaw":
                            print(f"        Found openclaw!")
                            print(f"        Contents:")
                            for file in subitem.iterdir():
                                print(f"          {file.name}")
                else:
                    print(f"    No node_modules found in openclaw")

# Also check the node directory
node_dir = install_base / "node"
if node_dir.exists():
    print(f"\nNode directory exists: {node_dir}")
    node_modules = node_dir / "node_modules"
    if node_modules.exists():
        print(f"Node modules found:")
        for item in node_modules.iterdir():
            print(f"  {item.name}")
            if item.name == "openclaw":
                print(f"    Found openclaw!")
                print(f"    Contents:")
                for file in item.iterdir():
                    if file.name == "openclaw.mjs":
                        print(f"      ✓ openclaw.mjs exists")
                    elif file.name == "dist":
                        print(f"      dist (directory)")
