# OpenClaw Auto-Login Feature

## Overview

The **Auto-Login** feature provides **zero-interaction access** to the OpenClaw dashboard by automatically handling the authentication flow.

## How It Works

The automation follows the "How to connect" steps from the dashboard login screen:

```
┌─────────────────────────────────────────────────────────────────┐
│                    Auto-Login Flow                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Step 1: Start Gateway                                          │
│  ├── Check: openclaw gateway status                             │
│  ├── Try:   openclaw gateway start                              │
│  └── Fallback: openclaw gateway run (background)                │
│                                                                  │
│  Step 2: Get Tokenized URL                                      │
│  └── Run: openclaw dashboard --no-open                          │
│      └── Parse: http://127.0.0.1:18789/?token=xxx...            │
│                                                                  │
│  Step 3: Open Browser                                           │
│  ├── Windows: webbrowser / Start-Process                        │
│  ├── macOS:  open command                                       │
│  └── Linux:  xdg-open / gnome-open / kde-open                   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Usage

### Command Line

```bash
# Auto-login with default browser
openclaw-installer auto-login

# Auto-login with specific browser
openclaw-installer auto-login --browser "/path/to/browser"

# Dashboard command (with auto-login enabled by default)
openclaw-installer dashboard

# Skip auto-login
openclaw-installer dashboard --no-auto-login
```

### Configuration

Add to your `openclaw.yaml`:

```yaml
automation:
  auto_open_dashboard: true   # Auto-open after install
  auto_login: true            # Enable zero-interaction login
  browser_path: ""            # Empty = system default
  startup_timeout: 30         # Seconds to wait for gateway
```

### Platform-Specific Browser Paths

**Windows:**
```yaml
automation:
  browser_path: "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
```

**macOS:**
```yaml
automation:
  browser_path: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
```

**Linux:**
```yaml
automation:
  browser_path: "/usr/bin/google-chrome"
```

## Platform Support

| Feature | Windows | macOS | Linux |
|---------|---------|-------|-------|
| CLI Command | ✅ | ✅ | ✅ |
| Gateway Service Start | ✅ | ✅ | ✅ |
| Gateway Background Run | ✅ | ✅ | ✅ |
| Browser Auto-Detection | ✅ | ✅ | ✅ |
| Token Extraction | ✅ | ✅ | ✅ |
| Shell Script (PS1) | ✅ | ❌ | ❌ |
| Shell Script (Bash) | ❌ | ✅ | ✅ |

## API Usage

### Python

```python
from openclaw_installer import auto_login

# Auto-login with defaults
success = auto_login()

# With specific browser
success = auto_login(browser_path="/usr/bin/chrome")

# With timeout
success = auto_login(startup_timeout=60)
```

### Direct Import

```python
from openclaw_installer.automation.auto_login import auto_login

success = auto_login()
```

## Shell Scripts

### Windows PowerShell

```powershell
# From the automation folder
.\auto-login.ps1

# With browser path
.\auto-login.ps1 -BrowserPath "C:\Program Files\Google\Chrome\Application\chrome.exe"
```

### Linux/macOS Bash

```bash
# From the automation folder
./auto-login.sh

# With browser path
./auto-login.sh -b /usr/bin/google-chrome
```

## Troubleshooting

### "Gateway not responding"

```bash
# Check gateway status manually
openclaw gateway status

# Start gateway manually
openclaw gateway run
```

### "Browser not opening"

- Specify full browser path in config
- Check file permissions
- Run with verbose output

### "Token not found"

```bash
# Check if token is generated
openclaw dashboard --no-open

# May need first-time manual login
```

## Files

```
openclaw_installer/
├── automation/
│   ├── __init__.py
│   ├── auto_login.py       # Main Python module
│   ├── auto-login.ps1      # Windows PowerShell script
│   ├── auto-login.sh       # Linux/macOS Bash script
│   └── README.md           # Detailed documentation
```

## Integration

The auto-login runs automatically after installation if configured:

```bash
openclaw-installer install --config openclaw.yaml
# ... installation output ...
# Dashboard opens automatically with logged-in session!
```

## See Also

- [Automation README](openclaw_installer/automation/README.md)
- [Main README](README.md)
- Example configs in `examples/` directory
