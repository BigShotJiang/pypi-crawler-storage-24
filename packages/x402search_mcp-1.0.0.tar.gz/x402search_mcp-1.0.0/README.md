# x402search-mcp (Python)

Search 13,000+ x402-enabled HTTP APIs from Python AI agents.

Cost: $0.01 USDC per search. Base mainnet. No account needed.
npm: https://www.npmjs.com/package/x402search-mcp
API: https://x402search.xyz

## Install

    pip install x402search-mcp

## Requirements

- A wallet private key (EVM)
- USDC on Base mainnet (eip155:8453)
- Get USDC: https://www.coinbase.com/how-to-buy/usdc

## Quick Start

    import os
    from x402search import search_x402_apis

    os.environ["EVM_PRIVATE_KEY"] = "0xYOUR_PRIVATE_KEY_HERE"
    results = search_x402_apis("token price API ethereum")
    for r in results["results"]:
        print(r["url"], "-", r["description"])

## LangChain

    from langchain.tools import tool
    from x402search import search_x402_apis

    @tool
    def search_apis(query: str) -> str:
        results = search_x402_apis(query)
        return str(results["results"])

## CrewAI

    from crewai.tools import BaseTool
    from x402search import search_x402_apis

    class X402SearchTool(BaseTool):
        name: str = "x402_api_search"
        description: str = "Search 13,000+ x402-enabled HTTP APIs."
        def _run(self, query: str) -> str:
            return str(search_x402_apis(query)["results"])

## Virtuals GAME SDK

    from game_sdk.game.custom_types import Function, Argument, FunctionResultStatus
    from x402search import search_x402_apis

    def search_apis_fn(query: str) -> tuple:
        try:
            results = search_x402_apis(query)
            return FunctionResultStatus.DONE, str(results["results"]), {}
        except Exception as e:
            return FunctionResultStatus.FAILED, str(e), {}

    search_tool = Function(
        fn_name="search_x402_apis",
        fn_description="Search 13,000+ x402-enabled HTTP APIs.",
        args=[Argument(name="query", type="string", description="Search query")],
        executable=search_apis_fn,
    )

## Parameters

- query (str, required): e.g. "weather data", "crypto prices"
- private_key (str, optional): EVM private key. Defaults to EVM_PRIVATE_KEY env var
- network (str, optional): e.g. "eip155:8453" for Base mainnet
- max_price_usdc (float, optional): max price filter in USDC
- limit (int, optional): max results, default 10, max 50

## Links

- PyPI: https://pypi.org/project/x402search-mcp
- npm: https://www.npmjs.com/package/x402search-mcp
- API: https://x402search.xyz
- GitHub: https://github.com/x402-index/x402search-mcp
- x402 protocol: https://x402.org
