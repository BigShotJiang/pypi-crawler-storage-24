import json, os, time, requests
from typing import Optional

BASE_URL = "https://x402search.xyz"

class X402PaymentError(Exception): pass
class X402SearchError(Exception): pass

def _format_price(amount_raw):
    if amount_raw is None: return "unknown"
    try: return f"{int(amount_raw) / 1_000_000:.4f}"
    except: return str(amount_raw)

class X402SearchClient:
    def __init__(self, private_key=None, rpc_url=None):
        raw_key = private_key or os.environ.get("EVM_PRIVATE_KEY")
        if not raw_key:
            raise ValueError("EVM_PRIVATE_KEY is required. Your wallet needs USDC on Base mainnet. Each search costs $0.01 USDC.")
        self.private_key = raw_key if raw_key.startswith("0x") else f"0x{raw_key}"
        self.rpc_url = rpc_url or "https://mainnet.base.org"
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})

    def search(self, query, network=None, max_price_usdc=None, limit=10):
        limit = min(limit, 50)
        body = {
            "query": query,
            "filters": {
                **({"network": network} if network else {}),
                **({"max_price_usdc": max_price_usdc} if max_price_usdc is not None else {}),
            },
            "page": {"limit": limit, "offset": 0},
            "mode": "agent",
        }
        response = self._session.post(f"{BASE_URL}/v1/search", json=body)
        if response.status_code == 402:
            payment_header = self._build_payment_header(response)
            if not payment_header:
                raise X402PaymentError("x402 payment required. Ensure your wallet has USDC on Base mainnet.")
            response = self._session.post(f"{BASE_URL}/v1/search", json=body, headers={"X-Payment": payment_header})
        if response.status_code != 200:
            raise X402SearchError(f"Search failed with status {response.status_code}: {response.text}")
        data = response.json()
        results = [
            {
                "url": r.get("resource_url", ""),
                "description": (r.get("metadata") or {}).get("description", ""),
                "network": (r.get("accepts") or [{}])[0].get("network", ""),
                "price_usdc": _format_price((r.get("accepts") or [{}])[0].get("amount")),
                "scheme": (r.get("accepts") or [{}])[0].get("scheme", ""),
            }
            for r in (data.get("results") or [])
        ]
        return {"success": True, "query": query, "count": data.get("count", len(results)), "results": results}

    def _build_payment_header(self, response_402):
        try:
            from eth_account import Account
            import base64
            payment_data = response_402.json()
            accepts = payment_data.get("accepts", [])
            if not accepts: return None
            req = accepts[0]
            pay_to = req.get("payTo")
            asset = req.get("asset")
            amount = req.get("maxAmountRequired")
            network = req.get("network", "eip155:8453")
            if not all([pay_to, asset, amount]): return None
            valid_after = 0
            valid_before = int(time.time()) + 300
            nonce = os.urandom(32).hex()
            chain_id = int(network.split(":")[-1]) if ":" in network else 8453
            typed_data = {
                "types": {
                    "EIP712Domain": [
                        {"name": "name", "type": "string"},
                        {"name": "version", "type": "string"},
                        {"name": "chainId", "type": "uint256"},
                        {"name": "verifyingContract", "type": "address"},
                    ],
                    "TransferWithAuthorization": [
                        {"name": "from", "type": "address"},
                        {"name": "to", "type": "address"},
                        {"name": "value", "type": "uint256"},
                        {"name": "validAfter", "type": "uint256"},
                        {"name": "validBefore", "type": "uint256"},
                        {"name": "nonce", "type": "bytes32"},
                    ],
                },
                "domain": {"name": "USD Coin", "version": "2", "chainId": chain_id, "verifyingContract": asset},
                "primaryType": "TransferWithAuthorization",
                "message": {
                    "from": Account.from_key(self.private_key).address,
                    "to": pay_to,
                    "value": int(amount),
                    "validAfter": valid_after,
                    "validBefore": valid_before,
                    "nonce": bytes.fromhex(nonce),
                },
            }
            signed = Account.sign_typed_data(self.private_key, full_message=typed_data)
            payload = {
                "x402Version": 1,
                "scheme": "exact",
                "network": network,
                "payload": {
                    "signature": signed.signature.hex(),
                    "authorization": {
                        "from": Account.from_key(self.private_key).address,
                        "to": pay_to,
                        "value": hex(int(amount)),
                        "validAfter": hex(valid_after),
                        "validBefore": hex(valid_before),
                        "nonce": f"0x{nonce}",
                    },
                },
            }
            return base64.b64encode(json.dumps(payload).encode()).decode()
        except ImportError:
            raise X402PaymentError("eth-account is required. Install: pip install eth-account")
        except Exception as e:
            raise X402PaymentError(f"Failed to build x402 payment: {e}")

def search_x402_apis(query, private_key=None, network=None, max_price_usdc=None, limit=10):
    return X402SearchClient(private_key=private_key).search(query=query, network=network, max_price_usdc=max_price_usdc, limit=limit)
