from typing import Sequence

import httpx
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult


def _to_dict(span: ReadableSpan) -> dict:
    """Convert a finished OTel span to the Zalor wire format (plain JSON-serializable dict).

    Schema::

        {
            "name": str,
            "trace_id": str,        # 32-char hex
            "span_id": str,         # 16-char hex
            "parent_span_id": str | None,
            "start_time_ns": int,
            "end_time_ns": int,
            "status": str,          # "OK" | "ERROR" | "UNSET"
            "attributes": dict,
            "events": list[dict],
        }
    """
    ctx = span.context
    if not ctx:
        raise Exception("Span is missing context! Failed to read span.")

    parent_span_id = None
    if span.parent is not None:
        parent_span_id = format(span.parent.span_id, "016x")

    return {
        "name": span.name,
        "trace_id": format(ctx.trace_id, "032x"),
        "span_id": format(ctx.span_id, "016x"),
        "parent_span_id": parent_span_id,
        "start_time_ns": span.start_time,
        "end_time_ns": span.end_time,
        "status": span.status.status_code.name,
        "attributes": dict(span.attributes) if span.attributes else {},
        "events": [
            {
                "name": e.name,
                "timestamp_ns": e.timestamp,
                "attributes": dict(e.attributes) if e.attributes else {},
            }
            for e in span.events
        ],
    }


class ZalorSpanExporter(SpanExporter):
    """OTel SpanExporter that POSTs each finished span to the Zalor ingestion endpoint.

    Spans are posted individually and synchronously — ``SimpleSpanProcessor`` calls
    ``export()`` in the span-ending thread, so the synchronous ``httpx.Client``
    avoids event-loop complications.

    Wire endpoint: ``POST {endpoint}/api/v1/spans``
    Body: the dict produced by :func:`_to_dict`
    """

    def __init__(self, api_key: str, endpoint: str) -> None:
        self._url = f"{endpoint.rstrip('/')}/api/v1/spans"
        self._trace_id: str | None = None
        self._client = httpx.Client(
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=10.0,
        )

    @property
    def trace_id(self) -> str:
        """The OTel trace_id seen in exported spans (set after the first span is exported)."""
        return self._trace_id or "UNKNOWN"

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        for span in spans:
            try:
                d = _to_dict(span)
                if self._trace_id is None:
                    self._trace_id = d["trace_id"]
                d["trace_id"] = self._trace_id
                response = self._client.post(self._url, json=d)
                if response.status_code >= 400:
                    return SpanExportResult.FAILURE
            except:
                return SpanExportResult.FAILURE

        return SpanExportResult.SUCCESS

    def shutdown(self) -> None:
        self._client.close()
