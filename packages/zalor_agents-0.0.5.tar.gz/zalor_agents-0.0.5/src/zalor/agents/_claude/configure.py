from openinference.instrumentation.anthropic import AnthropicInstrumentor
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor

from zalor.agents.exporter import ZalorSpanExporter


def configure_claude(api_key: str, endpoint: str) -> ZalorSpanExporter:
    """Instrument the Anthropic client and ship every span to Zalor.

    Call this once before making any Anthropic API calls. After the run,
    access ``exporter.trace_id`` to get the OTel trace_id for the run.

    Args:
        api_key:  Zalor API key (starts with ``zal-``).
        endpoint: Zalor ingestion base URL, e.g. ``"https://api.zalor.ai"``.

    Returns:
        The :class:`ZalorSpanExporter` bound to this instrumentation session.

    Example::

        from zalor.agents.claude import configure_claude

        exporter = configure_claude(
            api_key="zal-...",
            endpoint="https://api.zalor.ai",
        )
        # ... run your agent ...
        print(exporter.trace_id)  # 32-char hex OTel trace_id
    """
    exporter = ZalorSpanExporter(api_key=api_key, endpoint=endpoint)
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    AnthropicInstrumentor().instrument(tracer_provider=provider)
    return exporter
