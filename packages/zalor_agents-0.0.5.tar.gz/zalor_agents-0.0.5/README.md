# zalor-agents

Zalor tracing SDK for AI agents. Instruments your agent with OpenTelemetry and ships traces to the Zalor backend for automated evaluation.

## Installation

```bash
pip install zalor-agents
```

## Quick Start

```python
from zalor.agents import test_agent

def my_agent(user_input: str) -> str:
    # your OpenAI-based agent logic here
    ...

test_agent(
    agent_name="my-assistant",
    api_key="zal-...",
    run_agent=my_agent,
)
# Prints a link to view results in the Zalor dashboard
```

## Requirements

Python >= 3.13
