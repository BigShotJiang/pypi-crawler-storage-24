# SSAPI
A CRUD API that can run on mod_python shared web hosting services such as Namecheap.
