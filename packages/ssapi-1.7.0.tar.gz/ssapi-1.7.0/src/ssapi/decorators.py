import logging

import requests
from functools import wraps

logger = logging.getLogger(__name__)


def logs_remote_server_errors(callable):
    @wraps(callable)
    def wrapper(*args, **kwargs):
        try:
            return callable(*args, **kwargs)
        except requests.HTTPError as err:
            if err.response.status_code >= 300:
                logger.error(
                    "Remote server error: %s %s",
                    err.response.status_code,
                    err.response.text,
                )
                raise err

    return wrapper
