import os
from pathlib import Path

from ssapi.defaults import (
    DEFAULT_CERTIFICATE_BASE_PATH,
    DEFAULT_CERTIFICATE_KEY_FILE_NAME,
    DEFAULT_CERTIFICATE_FILE_NAME
)


class Filesystem:
    """Filesystem storage"""

    def __init__(self):
        path = os.getenv(
            "CERTIFICATE_BASE_PATH",
            DEFAULT_CERTIFICATE_BASE_PATH
        )
        self.base_path = Path(path)

    def write(self, path, payload: bytes) -> None:
        """Write a file at the given local path"""
        with open(self.base_path / path, "wb") as fd:
            fd.write(payload)

    def read(self, path) -> bytes:
        """Read a file at the given local path"""
        with open(self.base_path / path, "rb") as fd:
            return fd.read()

    @property
    def key_path(self) -> Path:
        return self.base_path / DEFAULT_CERTIFICATE_KEY_FILE_NAME

    @property
    def certificate_path(self) -> Path:
        return self.base_path / DEFAULT_CERTIFICATE_FILE_NAME
