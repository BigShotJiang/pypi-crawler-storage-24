import base64
import json
import os
from importlib.metadata import version
from ast import literal_eval
from datetime import date, timedelta

from lxml import etree

from bottle import (
    get,
    post,
    put,
    route,
    request,
    response,
    default_app,
    Bottle,
    error,
)

from ssapi import kseflib
from ssapi import defaults
from ssapi.defaults import DEFAULT_CERTIFICATE_FILE_NAME, \
    DEFAULT_CERTIFICATE_KEY_FILE_NAME
from ssapi.entities import Sale, Return
from ssapi.env import get_env_database
from ssapi.exceptions import NotAuthenticatedRemotelyException
from ssapi.fs import Filesystem
from ssapi.names import RouteNames
from ssapi.datatypes import Undefined
from ssapi.tokens import TokenManager
from ssapi.utils import build_qr_verification_url
from ssapi.web_tools import get_bottle_routes, populate_cors_response
from ssapi.web_decorators import (
    accepts_json,
    returns_json,
    handles_db_errors,
    enables_cors,
    protected,
    not_cacheable, handles_remote_http_server_errors
)


@error(500)
def handle_500(err):
    populate_cors_response(response)
    response.content_type = "application/json"
    return json.dumps({"outcome": f"Internal server error: {err.body}"})


def get_application() -> Bottle:
    """Get the WSGI application"""
    return default_app()


@route(r"/<url:re:.*>", method="OPTIONS", name=RouteNames.CORS_PREFLIGHT)
@enables_cors
@protected
def options_preflight(*args, **kwargs):
    return None


@get("/")
@returns_json
@enables_cors
def get_root():
    app = get_application()
    routes = get_bottle_routes(app)
    return {"version": version("ssapi"), "resources": routes}


@get("/shops")
@returns_json
@enables_cors
@protected
@not_cacheable
def get_shops():
    return list(get_env_database().get_shops())


@get("/sales")
@returns_json
@enables_cors
@protected
@not_cacheable
def get_sales():
    query = request.query.decode()
    start = query.get("start", None)
    end = query.get("end", None)
    shop = query.get("shop", None)
    is_discounted = query.get("isDiscounted", None)
    return [
        dict(sale.as_map())
        for sale in get_env_database().get_sales(
            date_start=start,
            date_end=end,
            shop=shop,
            is_discounted=(
                Undefined()
                if is_discounted is None
                else literal_eval(is_discounted)
            ),
        )
    ]


@get("/sales/<id:int>")
@returns_json
@enables_cors
@protected
@not_cacheable
def get_sale(id: int) -> dict:
    sale = get_env_database().get_sale(id)
    if sale:
        return dict(sale.as_map())
    else:
        response.status = 404
        return {"outcome": f"not found: {request.path}"}


@put("/sales/<id:int>")
@accepts_json
@enables_cors
@protected
@not_cacheable
def put_sale(id: int) -> dict:
    # TODO: check id
    data = request.adapted_json
    data["id"] = id
    new_sale = Sale(**data)
    get_env_database().put_sale(id, new_sale)
    response.status = 204
    return {"outcome": f"update succeeded for sale {id}"}


@get("/returns")
@returns_json
@enables_cors
@protected
@not_cacheable
def get_returns():
    query = request.query.decode()
    start = query.get("start", None)
    end = query.get("end", None)
    shop = query.get("shop", None)
    return [
        dict(sale.as_map())
        for sale in get_env_database().get_returns(
            date_start=start, date_end=end, shop=shop
        )
    ]


@get("/returns/<id:int>")
@returns_json
@protected
@not_cacheable
def get_return(id: int) -> dict:
    return_ = get_env_database().get_return(id)
    if return_:
        return dict(return_.as_map())
    else:
        response.status = 404
        return {"outcome": f"not found: {request.path}"}


@put("/returns/<id:int>")
@accepts_json
@enables_cors
@handles_db_errors
@protected
def put_return(id: int) -> dict:
    # TODO: check id
    data = request.adapted_json
    data["id"] = id
    new_return = Return(**data)
    get_env_database().put_return(id, new_return)
    response.status = 204
    return {"outcome": f"update succeeded for return {id}"}


@post("/sales")
@accepts_json
@returns_json
@handles_db_errors
@enables_cors
@protected
def post_sales():
    try:
        new_sale = Sale(**request.adapted_json)
    except TypeError as exc:
        response.status = 400
        outcome = (
            f"creation failed: "
            f"invalid parameters for type 'sale': "
            f"{request.json} {exc}"
        )
    else:
        db = get_env_database()
        count = db.add_sales(new_sale)
        outcome = f"creation ({count}) succeeded in database at: {db.name}"

    return {"outcome": outcome}


@post("/returns")
@accepts_json
@returns_json
@handles_db_errors
@enables_cors
@protected
def post_returns():
    try:
        new_return = Return(**request.adapted_json)
    except TypeError as exc:
        response.status = 400
        outcome = (
            f"creation failed: "
            f"invalid parameters for type 'sale': "
            f"{request.json} {exc}"
        )
    else:
        db = get_env_database()
        count = db.add_returns(new_return)
        outcome = f"creation ({count}) succeeded in database at: {db.name}"

    return {"outcome": outcome}


@get("/products")
@returns_json
@enables_cors
@protected
@not_cacheable
def get_products():
    return tuple(get_env_database().get_products())


@put("/user-certificate")
@enables_cors
@protected
@not_cacheable
def put_user_certificate() -> dict | None:
    data = request.json
    try:
        cert_data = base64.b64decode(data["certificate"])
        key_data = base64.b64decode(data["key"])
    except KeyError as exc:
        response.status = 400
        return {"error": f"Missing key: {exc}"}
    except ValueError:
        response.status = 400
        return {"error": f"Base64 decoding error"}

    fs = Filesystem()
    fs.write(DEFAULT_CERTIFICATE_FILE_NAME, cert_data)
    fs.write(DEFAULT_CERTIFICATE_KEY_FILE_NAME, key_data)
    response.status = 204
    return None


@post("/invoices")
@enables_cors
@protected
@not_cacheable
@handles_remote_http_server_errors
def post_invoice() -> dict:
    data = request.json
    try:
        xml_data = base64.b64decode(data["invoice"]).decode()
        passphrase = data["passphrase"]
        nip = data["nip"]
    except KeyError as exc:
        response.status = 400
        return {"outcome": f"Missing key: {exc}"}
    except ValueError:
        response.status = 400
        return {"error": f"Base64 decoding error"}

    fs = Filesystem()
    key = kseflib.read_private_key(fs.key_path, passphrase.encode())
    cert = kseflib.read_pem_certificate(fs.certificate_path)
    challenge = kseflib.get_auth_challenge()
    request_doc = kseflib.create_auth_token_request_document(challenge, nip)
    signed_doc = kseflib.sign_auth_token_request(request_doc, key, cert)
    reference = kseflib.authenticate(signed_doc)
    try:
        access_token, refresh_token = TokenManager(reference.authentication_token).get_tokens()
    except kseflib.TokenNotFoundInResponseError as exc:
        response.status = 422
        return {
            "outcome": "error: KSeF authentication pending, retry later"
            "reason"
        }
    symmetric_key, iv = kseflib.create_temporary_symmetric_key()
    _, invoice_cert = kseflib.get_public_certificates()
    encrypted_key = kseflib.encrypt_key(symmetric_key, invoice_cert)
    session = kseflib.open_session(encrypted_key, access_token, iv)
    invoice_data = kseflib.encrypt_invoice(xml_data, symmetric_key, iv)
    outcome = kseflib.send_encrypted_invoice_data(invoice_data, access_token, session)

    # Extract issue date (P_1) from the invoice XML for QR code generation
    tree = etree.fromstring(xml_data.encode())
    issue_date_el = tree.find(".//{*}P_1")
    issue_date = issue_date_el.text if issue_date_el is not None else ""

    # Store invoice reference for later retrieval
    db = get_env_database()
    db.add_invoice(
        reference_number=outcome.get("referenceNumber", ""),
        session_reference_number=session.reference_number,
        nip=nip,
        invoice_hash=invoice_data["invoiceHash"],
        issue_date=issue_date,
    )

    return {"outcome": outcome}


@get("/invoices/<reference_id>")
@returns_json
@enables_cors
@protected
@not_cacheable
@handles_remote_http_server_errors
def get_invoice(reference_id: str) -> dict:
    """Retrieve invoice status from KSeF by reference ID."""

    # Look up stored session info
    db = get_env_database()
    invoice = db.get_invoice(reference_id)

    if invoice is None:
        response.status = 404
        return {"outcome": f"not found: {request.path}"}

    session_reference_number = invoice["session_reference_number"]

    # Get an active access token
    try:
        access_token, _ = TokenManager().get_tokens()
    except NotAuthenticatedRemotelyException:
        response.status = 401
        return {"outcome": "error: no active session, authenticate first"}

    # Query invoice status from KSeF (allow all processing states)
    try:
        status = kseflib.get_invoice_status(
            session_reference_number,
            reference_id,
            access_token,
            allowed_codes=(100, 150, 200)
        )
    except kseflib.InvalidInvoiceStatusError as err:
        response.status = 400
        return {
            "referenceNumber": reference_id,
            "ksefNumber": err.status.ksef_number,
            "invoiceNumber": err.status.invoice_number,
            "status": {
                "code": err.status.status_code,
                "description": err.status.status_description,
            },
        }

    # If still processing, return 202
    if status.status_code in (100, 150):
        response.status = 202
        return {
            "reason": {
                "status": {
                    "description": status.status_description,
                    "statusCode": response.status_code,
                    "status": status.status_code,
                    "text": response.status,
                }
            }
        }

    # Processing complete (status 200) - close session and get UPO
    kseflib.close_session(session_reference_number, access_token)
    upo_xml, upo_hash = kseflib.get_invoice_upo(
        session_reference_number,
        reference_id,
        access_token
    )

    qr_data = None
    if invoice.get("invoice_hash") and invoice.get("issue_date"):
        qr_data = {
            "data": build_qr_verification_url(
                invoice["nip"], invoice["issue_date"], invoice["invoice_hash"]
            ),
            "invoiceHash": invoice["invoice_hash"],
            "issueDate": invoice["issue_date"],
            "sellerNip": invoice["nip"],
        }

    return {
        "sessionReferenceNumber": session_reference_number,
        "referenceNumber": reference_id,
        "ksefNumber": status.ksef_number,
        "invoiceNumber": status.invoice_number,
        "status": {
            "code": status.status_code,
            "description": status.status_description
        },
        "upo": {
            "xml": upo_xml,
            "hash": upo_hash
        },
        "qrCode": qr_data,
    }


@post("/drop")
@returns_json
@enables_cors
@protected
def drop():
    # FIXME: add security
    db = get_env_database()
    db.drop()
    try:
        return {"outcome": f"Database dropped at: {db.name}"}
    finally:
        db.open()


@put("/settings/<owner_id>")
@accepts_json
@returns_json
@enables_cors
@protected
def put_settings(owner_id):
    data = request.adapted_json
    db = get_env_database()
    db.put_settings(owner_id, data)
    return {"outcome": f"Settings updated successfully at: {db.name}"}


@get("/settings/<owner_id>")
@returns_json
@enables_cors
@protected
@not_cacheable
def get_settings(owner_id):
    data = get_env_database().get_settings(owner_id)
    if data is None:
        response.status = 404
        return {"outcome": f"failed - owner '{owner_id}' not found"}
    else:
        return data


@get("/auth/<challenge_secret>")
@returns_json
@not_cacheable
def get_auth(challenge_secret: str):
    """Secret authentication URL"""
    secret = os.environ.get(defaults.DEFAULT_AUTH_SECRET_ENV_VAR, None)
    if secret is None:
        response.status = 503
        return {"reason": "Secret not set"}
    else:
        if challenge_secret == secret:
            db = get_env_database()
            session_secret = db.create_session().secret
            expire_date = date.today() + timedelta(days=365)
            session_domain = os.environ.get(
                defaults.DEFAULT_HOST_ENV_VAR, "localhost"
            )
            response.set_cookie(
                "ssapi",
                session_secret,
                expires=expire_date,
                domain=session_domain,
                path="/",
            )
            response.status = 200
            return {
                "outcome": "Valid secret. Session authenticated succesfully."
            }
        else:
            response.status = 404
            return {"reason": "Secret not found"}
