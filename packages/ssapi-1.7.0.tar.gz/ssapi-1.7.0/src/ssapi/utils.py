import base64
import time
import logging
from datetime import date
from functools import wraps
from typing import Callable, Any, Iterator, TypeVar

from ssapi.exceptions import MoreThenOneItemError, EmptySequenceError

logger = logging.getLogger(__name__)

KSEF_QR_BASE_URL = "https://qr-test.ksef.mf.gov.pl"


def build_qr_verification_url(nip: str, issue_date: str, invoice_hash: str) -> str:
    """Build the KSeF QR code verification URL for an invoice.

    invoice_hash: standard base64-encoded SHA-256 of the original XML.
    issue_date: YYYY-MM-DD string (P_1 from the invoice XML).
    Returns a URL suitable for encoding in a QR code.
    """
    hash_bytes = base64.b64decode(invoice_hash)
    hash_url = base64.urlsafe_b64encode(hash_bytes).rstrip(b"=").decode()
    date_str = date.fromisoformat(issue_date).strftime("%d-%m-%Y")
    return f"{KSEF_QR_BASE_URL}/invoice/{nip}/{date_str}/{hash_url}"

F = TypeVar("F", bound=Callable[..., Iterator])


def only_one(func: F) -> Callable:
    """Allow only one item from an iterable sequence

    Return the first item of the sequence, then attempt to retrieve a
    second one. If there is indeed a second item, raise an exception.

    Warning: taking the second item will trigger any related side effects.
    """

    @wraps(func)
    def _inner(*args, **kwargs) -> Any:
        seq = func(*args, **kwargs)
        try:
            return next(seq)
        except StopIteration:
            raise EmptySequenceError("No items were found in the sequence")
        finally:
            try:
                next(seq)
            except StopIteration:
                pass
            else:
                raise MoreThenOneItemError(
                    "More than one item was found in the sequence"
                )

    return _inner


def retry(
        func: Callable,
        times: int = 3,
        test: Callable | None = None
) -> Callable:
    """Retry calling the function a given number of times.

    Retries on exceptions being raised.
    """

    @wraps(func)
    def _inner(*args, **kwargs) -> Any:
        attempts = 0
        while True:
            try:
                return func(*args, **kwargs)
            except Exception as exc:
                attempts += 1
                if attempts > times:
                    raise
                else:
                    logger.debug(
                        "Retrying attempt n.%s of %s due to error: %s",
                        attempts,
                        times,
                        exc
                    )
                    time.sleep(1)

    return _inner
