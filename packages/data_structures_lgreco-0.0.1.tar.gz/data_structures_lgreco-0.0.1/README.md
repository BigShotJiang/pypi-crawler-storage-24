# Utilities for Leo Irakliotis Data Structure course

This package is meant for students in COMP 271 at
Loyola University Chicago.