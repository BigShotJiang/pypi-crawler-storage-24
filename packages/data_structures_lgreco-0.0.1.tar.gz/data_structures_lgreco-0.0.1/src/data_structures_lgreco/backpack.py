from __future__ import annotations


class Backpack:

    __DEFAULT_CAPACITY = 5

    def __init__(self, owner: str, capacity: int = __DEFAULT_CAPACITY) -> None:
        self.__owner: str = owner
        self.__capacity: int = capacity
        self.__items: list[str] = []

    def add_item(self, item: str) -> bool:
        space_available = (len(self.__items) < self.__capacity) and item is not None
        if space_available:
            self.__items.append(item)
        return space_available

    def remove_item(self, item: str) -> bool:
        found: bool = False
        i: int = 0
        if str is not None:
            while i < len(self.__items) and not found:
                found = self.__items[i] == item
                if found:
                    self.__items.pop(i)
                i += 1
        return found

    def count(self) -> int:
        return len(self.__items)

    def is_full(self) -> bool:
        return self.count() == self.__capacity

    def items(self) -> list[str]:
        items_list = []
        for item in self.__items:
            items_list.append(item)
        return items_list

    __EMPTY = "empty"
    __OWNER = "Backpack(owner={}, "
    __ITEMS = "items={})"
    __RATIO = "{}/{}"

    def __str__(self) -> str:
        string_owner: str = self.__OWNER.format(self.__owner)
        string_items: str = self.__ITEMS.format(self.__EMPTY)
        if len(self.__items) > 0:
            string_items = self.__ITEMS.format(
                self.__RATIO.format(len(self.__items), self.__capacity)
            )
        return string_owner + string_items


if __name__ == "__main__":
    test = Backpack("Mina", 4)
    print(test.add_item("treat"))
    print(test.add_item("treat"))
    print(test.add_item("treat"))
    print(test.add_item("treat"))
    print(test.add_item("treat"))
    print(test)
