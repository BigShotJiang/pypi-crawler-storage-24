import random

from celery import Celery
from dishka import Provider, Scope, make_container
from dishka.integrations.celery import (
    DishkaTask,
    FromDishka,
    setup_dishka,
)

provider = Provider(scope=Scope.REQUEST)
provider.provide(lambda: random.random(), provides=float)


app = Celery(task_cls=DishkaTask)


@app.task
def random_task(num: FromDishka[float]) -> float:
    return num


def main() -> None:
    container = make_container(provider)
    setup_dishka(container, app)

    result = random_task.apply()

    print(result.get())

    container.close()


if __name__ == "__main__":
    main()
