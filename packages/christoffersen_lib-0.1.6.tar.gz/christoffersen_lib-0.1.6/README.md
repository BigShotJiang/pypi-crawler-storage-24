# christoffersen-lib

Python library for the **Christoffersen Independence Test**, used in VaR (Value at Risk) backtesting in quantitative finance.

## Installation
```bash
pip install christoffersen-lib
```

## Usage
```python
from christoffersen import independence_test

violations = [0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0]

lr, p_value = independence_test(violations)

print(f"LR statistic : {lr:.4f}")
print(f"P-value      : {p_value:.4f}")

if p_value > 0.05:
    print("✅ Independence not rejected (violations are not clustered)")
else:
    print("❌ Independence rejected (violations are clustered — bad VaR model)")
```

## Interpretation

| P-value | Conclusion |
|---|---|
| > 0.05 | VaR model passes the independence test |
| ≤ 0.05 | Violations are clustered — model underestimates tail risk |

## Parameters

`independence_test(violations)`

- `violations` : list or numpy array of 0s and 1s — 1 means the VaR was exceeded on that day

Returns `(lr_statistic, p_value)`.

## Dependencies

- numpy
- scipy

## License

MIT