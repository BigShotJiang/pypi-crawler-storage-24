"""
Salim AI — Multi-provider AI backend.
Supports NVIDIA NIM, Groq, ZAI, and OpenAI-compatible APIs.
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger("salim.ai")


class SalimAI:
    """AI provider wrapper with fallback chain."""

    PROVIDERS = [
        ("nvidia", "SALIM_NVIDIA_API_KEY", "SALIM_NVIDIA_MODEL",
         "https://integrate.api.nvidia.com/v1", "meta/llama-3.1-70b-instruct"),
        ("groq",   "SALIM_GROQ_API_KEY",   "SALIM_GROQ_MODEL",
         "https://api.groq.com/openai/v1",  "llama3-70b-8192"),
        ("zai",    "SALIM_ZAI_API_KEY",     "SALIM_ZAI_MODEL",
         "https://api.zai.ai/v1",           "gpt-4o"),
        ("openai", "SALIM_OPENAI_API_KEY",  "SALIM_OPENAI_MODEL",
         "https://api.openai.com/v1",       "gpt-4o-mini"),
    ]

    def __init__(self, config):
        self.config = config
        self._active_provider = None
        self._active_key = None
        self._active_model = None
        self._active_base_url = None
        self._init_provider()

    def _init_provider(self):
        for name, key_env, model_env, base_url, default_model in self.PROVIDERS:
            key = self.config.get(key_env, "")
            if key:
                self._active_provider = name
                self._active_key = key
                self._active_model = self.config.get(model_env, "") or default_model
                self._active_base_url = base_url
                return

    def is_configured(self) -> bool:
        return bool(self._active_key)

    def status_line(self) -> str:
        if not self.is_configured():
            return "🤖 AI: not configured (set SALIM_NVIDIA_API_KEY or SALIM_GROQ_API_KEY)"
        model_short = (self._active_model or "").split("/")[-1]
        return f"🤖 AI: {self._active_provider} · {model_short}"

    async def chat(self, messages: list[dict], max_tokens: int = 1024,
                   temperature: float = 0.7, system: Optional[str] = None) -> str:
        """Send chat completion. Returns response text."""
        if not self.is_configured():
            return "⚠️ AI not configured. Set SALIM_NVIDIA_API_KEY in config."

        try:
            from openai import AsyncOpenAI
            client = AsyncOpenAI(
                api_key=self._active_key,
                base_url=self._active_base_url,
            )
            all_messages = []
            if system:
                all_messages.append({"role": "system", "content": system})
            all_messages.extend(messages)

            resp = await client.chat.completions.create(
                model=self._active_model,
                messages=all_messages,
                max_tokens=max_tokens,
                temperature=temperature,
            )
            return resp.choices[0].message.content or ""
        except Exception as e:
            logger.error(f"AI chat error: {e}")
            return f"❌ AI error: {e}"

    async def complete(self, prompt: str, system: Optional[str] = None,
                       max_tokens: int = 1024) -> str:
        """Simple prompt → completion."""
        return await self.chat(
            [{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            system=system,
        )
