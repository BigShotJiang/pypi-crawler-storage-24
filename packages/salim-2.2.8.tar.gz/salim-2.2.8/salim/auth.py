"""
Salim Auth — authentication and audit logging.
"""
from __future__ import annotations

import functools
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Callable

from telegram import Update
from telegram.ext import ContextTypes

logger = logging.getLogger("salim.auth")

AUDIT_FILE = Path.home() / ".salim" / "audit.jsonl"


def setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )


class AuthMiddleware:
    def __init__(self, config):
        self.config = config

    def is_allowed(self, user_id: int) -> bool:
        allowed = self.config.allowed_ids
        if not allowed:
            return True  # No restriction configured
        return user_id in allowed

    def log_command(self, user_id: int, username: str, cmd: str, args: str = ""):
        if not self.config.log_commands:
            return
        entry = {
            "ts": datetime.now().isoformat(),
            "user": username or str(user_id),
            "uid": user_id,
            "cmd": cmd,
            "args": args[:200],
        }
        try:
            AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(AUDIT_FILE, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

    def get_audit_log(self, n: int = 20) -> list[dict]:
        if not AUDIT_FILE.exists():
            return []
        try:
            lines = AUDIT_FILE.read_text().strip().splitlines()
            entries = [json.loads(ln) for ln in lines[-n:] if ln]
            return list(reversed(entries))
        except Exception:
            return []


def require_auth(func: Callable):
    """Decorator: reject update if user not in allowed list."""
    @functools.wraps(func)
    async def wrapper(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user:
            return
        if not self.auth.is_allowed(user.id):
            await update.effective_message.reply_text("🚫 Unauthorized.")
            return
        # Log command
        msg = update.effective_message
        if msg and msg.text:
            parts = msg.text.split()
            cmd = parts[0].lstrip("/") if parts else ""
            args_str = " ".join(parts[1:])
            self.auth.log_command(user.id, user.username or "", cmd, args_str)
        return await func(self, update, ctx, *args, **kwargs)
    return wrapper
