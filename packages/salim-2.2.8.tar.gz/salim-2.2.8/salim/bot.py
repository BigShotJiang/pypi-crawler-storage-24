"""
SalimBot v13 — Full Manus-parity AI agent.
New in v13: /slides /website /pdf /translate /tldr + all missing handlers completed.
"""
from __future__ import annotations
import asyncio, logging, platform
from pathlib import Path
from telegram import BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, ApplicationBuilder, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

from salim.auth import AuthMiddleware, require_auth
from salim.config import Config
from salim.handlers.system import SystemHandlers
from salim.handlers.shell import ShellHandlers
from salim.handlers.files import FileHandlers
from salim.handlers.screen import ScreenHandlers
from salim.handlers.power import PowerHandlers
from salim.handlers.ai_handler import AIHandler
from salim.handlers.document_writer import DocumentHandlers
from salim.handlers.voice import VoiceHandlers
from salim.handlers.camera import CameraHandlers
from salim.handlers.alerts import AlertHandlers, start_monitor
from salim.handlers.history import ConversationHistoryHandlers
from salim.handlers.code_runner import CodeRunnerHandlers
from salim.handlers.guard import IntrusionHandlers
from salim.handlers.smart_upload import SmartUploadHandlers
from salim.handlers.clipboard_image import ClipboardImageHandlers
from salim.handlers.stream import ScreenStreamHandlers
from salim.handlers.browser import BrowserHandlers
from salim.handlers.tts import TTSHandlers
from salim.handlers.ssh_handler import SSHHandlers
from salim.handlers.vision import VisionHandlers
from salim.handlers.speedtest_handler import SpeedTestHandlers
from salim.handlers.qr_handler import QRHandlers
from salim.handlers.watcher_handler import WatcherHandlers
from salim.handlers.notes_handler import NotesHandlers
from salim.handlers.scheduler_handler import SchedulerHandlers
from salim.handlers.memory import MemoryHandlers, update_last_seen, build_memory_context, learn_from_text
from salim.handlers.heartbeat import HeartbeatHandlers, get_heartbeat
from salim.handlers.agent import AgentHandlers
from salim.handlers.skills import SkillsHandlers, get_skill_loader
from salim.handlers.scraper import ScraperHandlers
from salim.handlers.analyst import DataAnalystHandlers
from salim.handlers.research import DeepResearchHandlers
from salim.handlers.email_handler import EmailHandlers
from salim.handlers.workflow import WorkflowHandlers
from salim.handlers.slides import SlidesHandlers
from salim.handlers.website import WebsiteHandlers
from salim.handlers.pdf_handler import PDFHandlers
from salim.handlers.translate import TranslateHandlers
import html
from salim.utils import short_time

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)
logger = logging.getLogger("salim.bot")


class SalimBot(
    SystemHandlers, ShellHandlers, FileHandlers, ScreenHandlers, PowerHandlers,
    AIHandler, DocumentHandlers, VoiceHandlers, CameraHandlers, AlertHandlers,
    ConversationHistoryHandlers, CodeRunnerHandlers, IntrusionHandlers,
    SmartUploadHandlers, ClipboardImageHandlers, ScreenStreamHandlers,
    BrowserHandlers, TTSHandlers, SSHHandlers, VisionHandlers,
    SpeedTestHandlers, QRHandlers, WatcherHandlers, NotesHandlers, SchedulerHandlers,
    MemoryHandlers, HeartbeatHandlers, AgentHandlers, SkillsHandlers,
    ScraperHandlers, DataAnalystHandlers, DeepResearchHandlers, EmailHandlers, WorkflowHandlers,
    SlidesHandlers, WebsiteHandlers, PDFHandlers, TranslateHandlers,
):
    """Salim v13 — Full Manus-parity autonomous AI agent."""

    def __init__(self, config: Config):
        self.config = config
        self.auth = AuthMiddleware(config)
        self._cwd = str(Path.home())
        self.cmd_paste = self.cmd_paste_smart

    def build(self) -> Application:
        app = ApplicationBuilder().token(self.config.bot_token).build()
        self._register_handlers(app)
        return app

    def _register_handlers(self, app: Application):
        cmds = [
            ("start", self.cmd_start), ("help", self.cmd_help),
            ("status", self.cmd_status), ("config", self.cmd_config), ("logs", self.cmd_logs),
            ("info", self.cmd_info), ("cpu", self.cmd_cpu), ("mem", self.cmd_mem),
            ("disk", self.cmd_disk), ("battery", self.cmd_battery), ("network", self.cmd_network),
            ("uptime", self.cmd_uptime), ("ps", self.cmd_ps), ("top", self.cmd_top), ("kill", self.cmd_kill),
            ("run", self.cmd_run), ("sh", self.cmd_run), ("exec", self.cmd_run),
            ("runbg", self.cmd_runbg), ("pipe", self.cmd_pipe), ("env", self.cmd_env),
            ("which", self.cmd_which), ("cron", self.cmd_cron), ("cronstop", self.cmd_cronstop),
            ("cronjobs", self.cmd_cronjobs),
            ("ls", self.cmd_ls), ("cd", self.cmd_cd), ("pwd", self.cmd_pwd),
            ("cat", self.cmd_cat), ("stat", self.cmd_stat), ("find", self.cmd_find),
            ("grep", self.cmd_grep), ("mkdir", self.cmd_mkdir), ("rm", self.cmd_rm),
            ("mv", self.cmd_mv), ("cp", self.cmd_cp), ("download", self.cmd_download),
            ("upload", self.cmd_upload_prompt), ("zip", self.cmd_zip), ("unzip", self.cmd_unzip),
            ("write", self.cmd_write),
            ("screenshot", self.cmd_screenshot), ("ss", self.cmd_screenshot),
            ("type", self.cmd_type), ("key", self.cmd_key), ("click", self.cmd_click),
            ("scroll", self.cmd_scroll), ("move", self.cmd_move), ("mousepos", self.cmd_mousepos),
            ("notify", self.cmd_notify), ("volume", self.cmd_volume), ("brightness", self.cmd_brightness),
            ("copy", self.cmd_copy), ("paste", self.cmd_paste), ("open", self.cmd_open),
            ("doc", self.cmd_doc), ("cam", self.cmd_cam), ("record", self.cmd_record),
            ("alert", self.cmd_alert), ("history", self.cmd_history), ("code", self.cmd_code),
            ("guard", self.cmd_guard), ("uploads", self.cmd_uploads_history),
            ("voicestatus", self.cmd_voice_status), ("copyphoto", self.cmd_copyphoto),
            ("stream", self.cmd_stream), ("streamstop", self.cmd_streamstop),
            ("browse", self.cmd_browse), ("browse_click", self.cmd_browse_click),
            ("browse_type", self.cmd_browse_type), ("browse_scroll", self.cmd_browse_scroll),
            ("browse_js", self.cmd_browse_js), ("browse_back", self.cmd_browse_back),
            ("browse_get", self.cmd_browse_get), ("browse_close", self.cmd_browse_close),
            ("tts", self.cmd_tts), ("say", self.cmd_say), ("tts_lang", self.cmd_tts_lang),
            ("tts_speed", self.cmd_tts_speed), ("tts_engine", self.cmd_tts_engine),
            ("tts_voice", self.cmd_tts_voice),
            ("ssh_add", self.cmd_ssh_add), ("ssh_list", self.cmd_ssh_list),
            ("ssh", self.cmd_ssh), ("ssh_remove", self.cmd_ssh_remove),
            ("ssh_password", self.cmd_ssh_password), ("ssh_upload", self.cmd_ssh_upload),
            ("ssh_download", self.cmd_ssh_download), ("ssh_connect", self.cmd_ssh_connect),
            ("ssh_disconnect", self.cmd_ssh_disconnect),
            ("vision", self.cmd_vision), ("askvision", self.cmd_askvision),
            ("speedtest", self.cmd_speedtest), ("qr", self.cmd_qr), ("qrread", self.cmd_qrread),
            ("watch", self.cmd_watch), ("watchlist", self.cmd_watchlist), ("watchstop", self.cmd_watchstop),
            ("note", self.cmd_note), ("notes", self.cmd_notes), ("notedel", self.cmd_notedel),
            ("noteclear", self.cmd_noteclear),
            ("at", self.cmd_at), ("every", self.cmd_every), ("jobs", self.cmd_jobs),
            ("jobcancel", self.cmd_jobcancel),
            ("memory", self.cmd_memory), ("heartbeat", self.cmd_heartbeat),
            ("agent", self.cmd_agent), ("agentstop", self.cmd_agentstop),
            ("agentstatus", self.cmd_agentstatus), ("agentlog", self.cmd_agentlog),
            ("skills", self.cmd_skills), ("skilladd", self.cmd_skilladd),
            ("scrape", self.cmd_scrape), ("scrapebulk", self.cmd_scrapebulk),
            ("scrapewatch", self.cmd_scrapewatch),
            ("analyze", self.cmd_analyze), ("dashboard", self.cmd_dashboard),
            ("plotcsv", self.cmd_plotcsv), ("research", self.cmd_research),
            ("researchstop", self.cmd_researchstop),
            ("email", self.cmd_email), ("workflow", self.cmd_workflow),
            ("slides", self.cmd_slides), ("website", self.cmd_website),
            ("pdf", self.cmd_pdf), ("translate", self.cmd_translate), ("tldr", self.cmd_tldr),
            ("shutdown", self.cmd_shutdown), ("restart", self.cmd_restart),
            ("sleep", self.cmd_sleep), ("lock", self.cmd_lock), ("logout", self.cmd_logout),
            ("hibernate", self.cmd_hibernate), ("screensaver", self.cmd_screensaver),
            ("displays", self.cmd_displays),
        ]
        for cmd, handler in cmds:
            app.add_handler(CommandHandler(cmd, handler))

        app.add_handler(CallbackQueryHandler(self._dispatch_callback))
        app.add_handler(MessageHandler(filters.Document.ALL, self.handle_document_smart))
        app.add_handler(MessageHandler(filters.PHOTO, self.handle_photo_message))
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & filters.REPLY,
            self._handle_text_or_photo_reply
        ))
        app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, self.handle_voice_message))
        app.add_handler(MessageHandler(filters.COMMAND, self.cmd_unknown))
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & ~filters.REPLY,
            self.handle_ai_message
        ))

        async def post_init(app2: Application):
            await app2.bot.set_my_commands(self._bot_commands())
            self._start_alert_monitor(app2)
            self._app = app2
            hb = get_heartbeat()
            hb.set_app(app2)
            hb.start()
            try:
                loader = get_skill_loader()
                loaded = loader.load_all(self)
                if loaded:
                    loader.register_with_bot(self)
                    for skill_name, info in loader.get_loaded().items():
                        for cmd in info["commands"]:
                            method = getattr(self, f"cmd_{cmd}", None)
                            if method:
                                app2.add_handler(CommandHandler(cmd, method))
                    logger.info(f"Loaded {len(loaded)} skills")
            except Exception as e:
                logger.warning(f"Skills load error: {e}")

        app.post_init = post_init

    @require_auth
    async def cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        from salim.ai import SalimAI
        ai = SalimAI(self.config)
        keyboard = [
            [InlineKeyboardButton("💻 System", callback_data="dash:info"),
             InlineKeyboardButton("📸 Screenshot", callback_data="dash:screenshot"),
             InlineKeyboardButton("📊 Top", callback_data="dash:top")],
            [InlineKeyboardButton("📂 Files", callback_data="dash:ls"),
             InlineKeyboardButton("⚙️ Processes", callback_data="dash:ps"),
             InlineKeyboardButton("🌐 Network", callback_data="dash:network")],
            [InlineKeyboardButton("📋 Commands", callback_data="dash:help"),
             InlineKeyboardButton("⚙️ Config", callback_data="dash:config")],
        ]
        user = update.effective_user
        await update.effective_message.reply_text(
            f"🖥️ <b>Salim v13</b> — {esc(platform.system())}\n\n"
            f"Hello, {esc(user.first_name)}! 📂 <code>{esc(self._cwd)}</code> · 🕐 {short_time()}\n"
            f"{esc(ai.status_line())}\n\n"
            "💬 <b>Type anything in plain English — AI understands!</b>\n"
            "🆕 <b>New:</b> /slides /website /pdf /translate /agent /research",
            parse_mode=H,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    @require_auth
    async def cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (
            "📋 <b>Salim v13 — Full Command Reference</b>\n\n"
            "🤖 <b>AI: just type in plain English!</b>\n\n"
            "── Manus-level AI ──\n"
            "<code>/agent</code> Autonomous multi-step execution\n"
            "<code>/research</code> Deep research report\n"
            "<code>/slides</code> AI presentation (PPTX)\n"
            "<code>/website</code> Generate full website\n"
            "<code>/pdf</code> PDF generation/extraction\n"
            "<code>/translate</code> 50+ language translation\n"
            "<code>/tldr</code> Summarize text\n"
            "<code>/scrape</code> Web scraping\n"
            "<code>/analyze</code> Data analysis + charts\n"
            "<code>/workflow</code> Multi-step automation\n"
            "<code>/email</code> Email integration\n"
            "<code>/code</code> AI writes &amp; runs code\n"
            "<code>/doc</code> Word/Excel documents\n\n"
            "── System ──\n"
            "<code>/info /cpu /mem /disk /battery /network /uptime /ps /top /kill</code>\n\n"
            "── Shell + Files ──\n"
            "<code>/run /ls /cd /cat /find /grep /mkdir /rm /mv /cp /write /zip</code>\n\n"
            "── Screen + Input ──\n"
            "<code>/screenshot /stream /type /key /click /scroll /open /notify</code>\n\n"
            "── Browser ──\n"
            "<code>/browse /browse_click /browse_type /browse_js /browse_scroll</code>\n\n"
            "── Media ──\n"
            "<code>/tts /say /cam /record /vision /askvision</code>\n\n"
            "── Remote ──\n"
            "<code>/ssh_add /ssh /ssh_list /ssh_upload /ssh_download</code>\n\n"
            "── Extras ──\n"
            "<code>/qr /qrread /speedtest /note /notes /at /every /jobs</code>\n"
            "<code>/watch /memory /heartbeat /skills /skilladd /guard</code>\n\n"
            "── Power ──\n"
            "<code>/shutdown /restart /sleep /lock /hibernate /screensaver</code>"
        )
        await update.effective_message.reply_text(text, parse_mode=H)

    @require_auth
    async def cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        import psutil
        from salim.ai import SalimAI
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        ai = SalimAI(self.config)
        await update.effective_message.reply_text(
            f"✅ <b>Salim v13 Online</b>\n🕐 {short_time()} · {esc(platform.node())}\n"
            f"📂 <code>{esc(self._cwd)}</code>\n⚙️ CPU {cpu}% · RAM {mem.percent}%\n"
            f"{esc(ai.status_line())}",
            parse_mode=H
        )

    @require_auth
    async def cmd_config(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if ctx.args and ctx.args[0] == "set" and len(ctx.args) >= 3:
            key_map = {
                "max_file_mb": "SALIM_MAX_FILE_MB",
                "nvidia_model": "SALIM_NVIDIA_MODEL",
                "groq_model": "SALIM_GROQ_MODEL",
                "openai_model": "SALIM_OPENAI_MODEL",
                "download_dir": "SALIM_DOWNLOAD_DIR",
                "upload_dir": "SALIM_UPLOAD_DIR",
            }
            k, v = ctx.args[1].lower(), " ".join(ctx.args[2:])
            env_key = key_map.get(k)
            if env_key:
                self.config.set(env_key, v)
                await update.effective_message.reply_text(f"✅ <code>{esc(k)}</code> = <code>{esc(v)}</code>", parse_mode=H)
            else:
                await update.effective_message.reply_text(f"❌ Unknown key: {esc(k)}\nValid: {esc(', '.join(key_map.keys()))}", parse_mode=H)
            return
        summary = self.config.summary()
        lines = [f"• <code>{esc(k)}</code>: <code>{esc(str(v))}</code>" for k, v in summary.items()]
        await update.effective_message.reply_text("⚙️ <b>Config</b>\n\n" + "\n".join(lines) +
            "\n\n<i>/config set &lt;key&gt; &lt;value&gt;</i>", parse_mode=H)

    @require_auth
    async def cmd_logs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        n = int(ctx.args[0]) if ctx.args else 20
        entries = self.auth.get_audit_log(n)
        if not entries:
            await update.effective_message.reply_text("📋 No log entries yet.")
            return
        lines = [f"<code>{esc(e['ts'][11:19])}</code> {esc(e.get('user','?'))} → <code>{esc(e['cmd'])}</code>" for e in entries]
        await update.effective_message.reply_text(f"📋 <b>Last {len(lines)} Commands</b>\n\n" + "\n".join(lines), parse_mode=H)

    async def _dispatch_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data or ""
        if data.startswith(("ai_", "sr_", "fa_")):
            await self.handle_ai_callback(update, ctx)
        elif data.startswith("stream_"):
            await self.handle_stream_callback(update, ctx)
        elif data.startswith("browse_"):
            await self.handle_browse_callback(update, ctx)
        elif data.startswith("vision_"):
            await self.handle_vision_callback(update, ctx)
        else:
            dispatch_map = {
                "dash:info": self.cmd_info, "dash:screenshot": self.cmd_screenshot,
                "dash:top": self.cmd_top, "dash:ls": self.cmd_ls,
                "dash:ps": self.cmd_ps, "dash:network": self.cmd_network,
                "dash:battery": self.cmd_battery, "dash:paste": self.cmd_paste_smart,
                "dash:disk": self.cmd_disk, "dash:help": self.cmd_help,
                "dash:config": self.cmd_config,
            }
            if data in dispatch_map:
                ctx.args = []
                await dispatch_map[data](update, ctx)
            elif data.startswith("rm_confirm:"):
                await self.cb_rm_confirm(update, ctx)
            elif data == "rm_cancel":
                await query.edit_message_text("❌ Cancelled.")
            elif data.startswith("power:"):
                await self.cb_power(update, ctx)
            elif data.startswith(("upload_dest:", "upload_cancel:", "upload_custom:")):
                await self.handle_upload_callback(update, ctx)
            elif data.startswith(("code_rerun:", "code_save:")):
                await self.handle_code_callback(update, ctx)
            elif data.startswith("email_setup:"):
                await self.handle_email_setup_callback(update, ctx)
            else:
                logger.warning(f"Unknown callback: {data!r}")

    async def _handle_text_or_photo_reply(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        if msg and msg.reply_to_message and msg.reply_to_message.photo:
            await self.handle_photo_reply(update, ctx)
        else:
            await self.handle_ai_message(update, ctx)

    async def cmd_unknown(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self.auth.is_allowed(update.effective_user.id):
            return
        cmd = update.effective_message.text.split()[0]
        await update.effective_message.reply_text(
            f"❓ Unknown: <code>{esc(cmd)}</code>\n/help for all commands, or just type in plain English!",
            parse_mode=H
        )

    def _bot_commands(self) -> list[BotCommand]:
        return [
            BotCommand("start", "Dashboard"), BotCommand("help", "All commands"),
            BotCommand("agent", "Autonomous AI agent"), BotCommand("research", "Deep research report"),
            BotCommand("slides", "AI presentation generator"), BotCommand("website", "Generate website"),
            BotCommand("pdf", "PDF generation/extraction"), BotCommand("translate", "Translation"),
            BotCommand("scrape", "Web scraping"), BotCommand("analyze", "Data analysis"),
            BotCommand("workflow", "Workflow automation"), BotCommand("email", "Email integration"),
            BotCommand("code", "AI code runner"), BotCommand("doc", "Word/Excel documents"),
            BotCommand("screenshot", "Take screenshot"), BotCommand("run", "Run shell command"),
            BotCommand("ls", "List files"), BotCommand("browse", "Browser automation"),
            BotCommand("vision", "Vision AI"), BotCommand("tts", "Text-to-speech"),
            BotCommand("ssh", "SSH remote control"), BotCommand("info", "System info"),
            BotCommand("note", "Quick notes"), BotCommand("at", "Schedule command"),
            BotCommand("memory", "Persistent memory"), BotCommand("guard", "Intrusion detection"),
            BotCommand("shutdown", "Shutdown machine"), BotCommand("config", "Settings"),
        ]

    def run(self, verbose: bool = False):
        from salim.auth import setup_logging
        setup_logging(verbose)
        app = self.build()
        logger.info(f"Salim v13 starting on {platform.node()}...")
        app.run_polling(allowed_updates=Update.ALL_TYPES)
