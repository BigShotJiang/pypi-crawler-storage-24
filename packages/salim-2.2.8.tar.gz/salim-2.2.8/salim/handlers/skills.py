"""
Salim Skills — dynamic plugin/skills loading system.
"""
from __future__ import annotations

import html
import importlib
import json
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.skills")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

SKILLS_DIR = Path.home() / ".salim" / "skills"
SKILLS_DIR.mkdir(parents=True, exist_ok=True)

_loaded_skills: dict = {}
_skill_loader_instance = None


class SkillLoader:
    def __init__(self):
        self._loaded: dict = {}
        self._bot = None

    def load_all(self, bot) -> list[str]:
        self._bot = bot
        loaded = []
        for skill_file in SKILLS_DIR.glob("*.py"):
            try:
                name = skill_file.stem
                spec = importlib.util.spec_from_file_location(f"salim_skill_{name}", skill_file)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    meta = getattr(module, "SKILL_META", {})
                    commands = getattr(module, "SKILL_COMMANDS", {})
                    self._loaded[name] = {
                        "module": module,
                        "meta": meta,
                        "commands": list(commands.keys()),
                        "file": str(skill_file),
                    }
                    loaded.append(name)
                    logger.info(f"Loaded skill: {name}")
            except Exception as e:
                logger.warning(f"Failed to load skill {skill_file.name}: {e}")
        return loaded

    def register_with_bot(self, bot):
        for name, info in self._loaded.items():
            module = info["module"]
            commands = getattr(module, "SKILL_COMMANDS", {})
            for cmd_name, handler_fn in commands.items():
                setattr(bot, f"cmd_{cmd_name}", lambda u, c, fn=handler_fn: fn(bot, u, c))

    def get_loaded(self) -> dict:
        return self._loaded


def get_skill_loader() -> SkillLoader:
    global _skill_loader_instance
    if _skill_loader_instance is None:
        _skill_loader_instance = SkillLoader()
    return _skill_loader_instance


class SkillsHandlers:

    @require_auth
    async def cmd_skills(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List loaded skills and plugins."""
        loader = get_skill_loader()
        loaded = loader.get_loaded()

        if not loaded:
            await update.effective_message.reply_text(
                f"🔌 <b>Skills</b>\n\n"
                f"No skills loaded yet.\n\n"
                f"Skills directory: <code>{esc(str(SKILLS_DIR))}</code>\n\n"
                f"Add Python skill files to that directory, or:\n"
                f"<code>/skilladd &lt;url&gt;</code> — install from URL\n\n"
                f"A skill is a .py file with:\n"
                f"<code>SKILL_META = {{\"name\": \"...\", \"description\": \"...\"}}</code>\n"
                f"<code>SKILL_COMMANDS = {{\"cmd_name\": handler_fn}}</code>",
                parse_mode=H
            )
            return

        lines = []
        for name, info in loaded.items():
            meta = info.get("meta", {})
            cmds = ", ".join(f"/{c}" for c in info.get("commands", []))
            lines.append(
                f"<b>{esc(name)}</b>\n"
                f"  {esc(meta.get('description', 'No description'))}\n"
                f"  Commands: {esc(cmds) if cmds else 'none'}"
            )

        await update.effective_message.reply_text(
            f"🔌 <b>Loaded Skills ({len(loaded)})</b>\n\n" + "\n\n".join(lines),
            parse_mode=H
        )

    @require_auth
    async def cmd_skilladd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Install a skill from a URL: /skilladd <url>"""
        msg = update.effective_message
        if not ctx.args:
            await msg.reply_text(
                "🔌 Usage: <code>/skilladd &lt;url&gt;</code>\n\n"
                "Downloads a Python skill file from the URL and installs it.",
                parse_mode=H
            )
            return

        url = ctx.args[0]
        if not url.startswith(("http://", "https://")):
            await msg.reply_text("❌ URL must start with http:// or https://", parse_mode=H)
            return

        status = await msg.reply_text(f"⬇️ <i>Downloading skill from {esc(url[:60])}…</i>", parse_mode=H)
        try:
            import urllib.request
            with urllib.request.urlopen(url, timeout=10) as resp:
                content = resp.read().decode("utf-8")

            # Basic safety: check it's Python
            if "import" not in content and "def " not in content:
                await status.edit_text("❌ Does not look like a valid Python skill file.", parse_mode=H)
                return

            # Extract skill name from meta or URL
            import re
            meta_match = re.search(r"SKILL_META\s*=\s*\{[^}]*\"name\"\s*:\s*\"([^\"]+)\"", content)
            if meta_match:
                skill_name = meta_match.group(1).replace(" ", "_").lower()
            else:
                skill_name = url.split("/")[-1].replace(".py", "")

            skill_name = re.sub(r"[^a-z0-9_]", "", skill_name) or "custom_skill"
            dest = SKILLS_DIR / f"{skill_name}.py"
            dest.write_text(content)

            await status.edit_text(
                f"✅ <b>Skill installed:</b> {esc(skill_name)}\n"
                f"File: <code>{esc(str(dest))}</code>\n\n"
                f"Use <code>/skills</code> to reload.",
                parse_mode=H
            )
        except Exception as e:
            await status.edit_text(f"❌ Error installing skill: {esc(str(e)[:200])}", parse_mode=H)
