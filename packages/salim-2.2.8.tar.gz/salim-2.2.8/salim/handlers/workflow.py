"""
Salim Workflow Automation — Chain multi-step tasks across tools like Manus AI.

Manus's key differentiator is orchestrating complex workflows that span
multiple tools: scrape a website → analyze data → send email → save report.
This handler lets users define and run named workflows as Telegram commands.

Commands:
  /workflow list                      — list saved workflows
  /workflow run <name>                — run a saved workflow
  /workflow save <name> | <steps>     — save a workflow
  /workflow delete <name>             — delete a workflow
  /workflow stop                      — stop running workflow
  /workflow show <name>               — show workflow steps

Built-in workflow templates:
  /workflow template daily_briefing   — morning system + weather + news summary
  /workflow template system_report    — full system health report
  /workflow template scrape_analyze   — scrape a URL and analyze the data

Workflow step syntax (one step per line):
  shell: <command>              — run shell command
  file_read: <path>             — read a file
  file_write: <path> | <content> — write to a file
  screenshot:                   — take screenshot
  browse: <url>                 — open URL in browser
  scrape: <url> [mode]          — scrape webpage
  notify: <message>             — send desktop notification
  wait: <seconds>               — pause between steps
  ai: <prompt>                  — ask AI a question
  research: <topic>             — run deep research
  system_info:                  — get system stats
  email: <to> | <subject> | <body>  — send email
  condition: <step_result contains X> → <step>  — conditional logic

Each step passes its output to the next step via {last_output} variable.
Results of named steps accessible via {step.name}.

Example workflow (daily_briefing):
  system_info:
  ai: Summarize this system status in 2 sentences: {last_output}
  shell: curl -s wttr.in/{city}?format=3
  ai: Combine this system summary: {step.0} and weather: {last_output} into a morning briefing

Real implementation — no mocks. All steps execute real commands.
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import re
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.workflow")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

WORKFLOW_DIR = Path.home() / ".salim" / "workflows"
WORKFLOW_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
WORKFLOW_FILE = WORKFLOW_DIR / "workflows.json"

# Active workflow tasks per user
_active_workflows: dict[int, asyncio.Task] = {}

# Built-in workflow templates
WORKFLOW_TEMPLATES = {
    "daily_briefing": {
        "description": "Morning briefing: system status + weather",
        "steps": [
            {"type": "system_info"},
            {"type": "ai", "prompt": "Create a concise 3-sentence system health summary from this data: {last_output}"},
            {"type": "shell", "command": "curl -s 'wttr.in/?format=3' 2>/dev/null || echo 'Weather unavailable'"},
            {"type": "ai", "prompt": "Write a friendly morning briefing combining: System: {step_0} | Weather: {last_output}. Keep it under 100 words."},
        ]
    },
    "system_report": {
        "description": "Full system health report saved to desktop",
        "steps": [
            {"type": "system_info"},
            {"type": "shell", "command": "df -h 2>/dev/null || echo 'Disk info unavailable'"},
            {"type": "shell", "command": "ps aux --sort=-%cpu 2>/dev/null | head -10 || echo 'Process list unavailable'"},
            {"type": "ai", "prompt": "Write a professional system health report from:\nSystem: {step_0}\nDisk: {step_1}\nProcesses: {last_output}\n\nFormat as sections with headers."},
            {"type": "file_write", "path": "~/Desktop/system_report_{timestamp}.txt", "content": "{last_output}"},
        ]
    },
    "security_check": {
        "description": "Quick security audit: open ports, recent logins, failed auth",
        "steps": [
            {"type": "shell", "command": "ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null | head -20 || echo 'Network check unavailable'"},
            {"type": "shell", "command": "last -n 10 2>/dev/null || echo 'Login history unavailable'"},
            {"type": "shell", "command": "grep -i 'failed\\|error\\|invalid' /var/log/auth.log 2>/dev/null | tail -20 || journalctl --since='1 hour ago' -p err 2>/dev/null | tail -20 || echo 'Auth log unavailable'"},
            {"type": "ai", "prompt": "Analyze this security data and highlight any concerns:\nOpen ports: {step_0}\nRecent logins: {step_1}\nAuth errors: {last_output}\n\nBe concise, flag anything suspicious."},
        ]
    },
}


def _load_workflows() -> dict:
    if not WORKFLOW_FILE.exists():
        return {}
    try:
        return json.loads(WORKFLOW_FILE.read_text())
    except Exception:
        return {}


def _save_workflows(workflows: dict):
    WORKFLOW_FILE.write_text(json.dumps(workflows, indent=2, ensure_ascii=False))
    WORKFLOW_FILE.chmod(0o600)


def _parse_workflow_steps(steps_text: str) -> list[dict]:
    """
    Parse workflow steps from text format.
    Each line is: type: params
    """
    steps = []
    for line in steps_text.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        if ":" in line:
            step_type, _, params = line.partition(":")
            step_type = step_type.strip().lower()
            params = params.strip()

            step = {"type": step_type}

            if step_type == "shell":
                step["command"] = params
            elif step_type == "file_read":
                step["path"] = params
            elif step_type == "file_write":
                if "|" in params:
                    path, _, content = params.partition("|")
                    step["path"] = path.strip()
                    step["content"] = content.strip()
                else:
                    step["path"] = params
                    step["content"] = "{last_output}"
            elif step_type == "browse":
                step["url"] = params
            elif step_type == "scrape":
                parts = params.split(None, 1)
                step["url"] = parts[0]
                step["mode"] = parts[1] if len(parts) > 1 else "auto"
            elif step_type == "notify":
                step["message"] = params
            elif step_type == "wait":
                try:
                    step["seconds"] = float(params)
                except ValueError:
                    step["seconds"] = 1.0
            elif step_type == "ai":
                step["prompt"] = params
            elif step_type == "research":
                step["topic"] = params
            elif step_type == "email":
                if "|" in params:
                    parts = [p.strip() for p in params.split("|")]
                    step["to"] = parts[0]
                    step["subject"] = parts[1] if len(parts) > 1 else "(no subject)"
                    step["body"] = parts[2] if len(parts) > 2 else "{last_output}"
                else:
                    step["to"] = params
            elif step_type == "system_info":
                pass  # No params needed
            elif step_type == "screenshot":
                pass
            else:
                step["params"] = params

            steps.append(step)

    return steps


def _interpolate(text: str, step_outputs: list[str], last_output: str) -> str:
    """Replace {last_output}, {step_N}, {timestamp} variables in text."""
    text = text.replace("{last_output}", last_output)
    text = text.replace("{timestamp}", datetime.now().strftime("%Y%m%d_%H%M%S"))

    for i, output in enumerate(step_outputs):
        text = text.replace(f"{{step_{i}}}", output)
        text = text.replace(f"{{step.{i}}}", output)

    return text


async def _execute_step(step: dict, step_outputs: list[str], ai_instance, bot=None, chat_id: int = 0) -> tuple[bool, str]:
    """
    Execute a single workflow step.
    Returns (success, output_text).
    """
    last_output = step_outputs[-1] if step_outputs else ""
    step_type = step.get("type", "")

    try:
        if step_type == "shell":
            cmd = _interpolate(step.get("command", ""), step_outputs, last_output)
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True,
                timeout=30, cwd=str(Path.home())
            )
            output = (result.stdout or "").strip()
            err = (result.stderr or "").strip()
            if result.returncode != 0 and err:
                return False, f"Exit {result.returncode}: {err[:500]}"
            return True, (output or "(no output)")[:2000]

        elif step_type == "system_info":
            try:
                import psutil
                cpu = psutil.cpu_percent(interval=0.5)
                mem = psutil.virtual_memory()
                disk = psutil.disk_usage("/")
                bat = psutil.sensors_battery()
                bat_info = f"Battery: {bat.percent:.0f}%" if bat else ""
                return True, (
                    f"CPU: {cpu:.1f}%\n"
                    f"RAM: {mem.percent:.1f}% ({mem.used/1e9:.1f}/{mem.total/1e9:.1f}GB)\n"
                    f"Disk: {disk.percent:.1f}% ({disk.free/1e9:.1f}GB free)\n"
                    + (f"{bat_info}\n" if bat_info else "")
                    + f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                )
            except Exception as e:
                return False, str(e)

        elif step_type == "file_read":
            path = Path(_interpolate(step.get("path", ""), step_outputs, last_output)).expanduser()
            if not path.exists():
                return False, f"File not found: {path}"
            content = path.read_text(errors="replace")
            return True, content[:3000]

        elif step_type == "file_write":
            path_str = _interpolate(step.get("path", ""), step_outputs, last_output)
            path = Path(path_str).expanduser()
            content = _interpolate(step.get("content", "{last_output}"), step_outputs, last_output)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return True, f"Saved to {path}"

        elif step_type == "wait":
            seconds = float(step.get("seconds", 1))
            await asyncio.sleep(min(seconds, 60))
            return True, f"Waited {seconds}s"

        elif step_type == "notify":
            message = _interpolate(step.get("message", "Workflow step complete"), step_outputs, last_output)
            import platform
            sys = platform.system()
            if sys == "Darwin":
                subprocess.run(
                    ["osascript", "-e", f'display notification "{message}" with title "Salim Workflow"'],
                    capture_output=True
                )
            elif sys == "Linux":
                subprocess.run(["notify-send", "Salim Workflow", message], capture_output=True)
            return True, f"Notified: {message[:100]}"

        elif step_type == "ai":
            if not ai_instance or not ai_instance.is_configured():
                return False, "AI not configured"
            prompt = _interpolate(step.get("prompt", ""), step_outputs, last_output)
            response, _ = await ai_instance._call_with_fallback(
                [{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.4,
            )
            return True, response[:2000]

        elif step_type == "scrape":
            url = _interpolate(step.get("url", ""), step_outputs, last_output)
            mode = step.get("mode", "auto")
            try:
                from salim.handlers.scraper import _do_scrape
                result = await _do_scrape(url, mode)
                if "error" in result:
                    return False, result["error"]
                data = result.get("data", [])
                # Return summary
                dtype = result.get("type", "unknown")
                if isinstance(data, list):
                    count = len(data)
                    if data and isinstance(data[0], dict):
                        preview = json.dumps(data[:3], ensure_ascii=False)[:500]
                    else:
                        preview = str(data[:5])[:500]
                    return True, f"Scraped {dtype}: {count} items\nPreview: {preview}"
                return True, str(data)[:500]
            except Exception as e:
                return False, f"Scrape error: {e}"

        elif step_type == "email":
            try:
                from salim.handlers.email_handler import _load_config, _send_email_sync
                config = _load_config()
                if not config:
                    return False, "Email not configured. Run /email setup first."
                to = _interpolate(step.get("to", ""), step_outputs, last_output)
                subject = _interpolate(step.get("subject", "Salim Workflow"), step_outputs, last_output)
                body = _interpolate(step.get("body", last_output), step_outputs, last_output)
                loop = asyncio.get_event_loop()
                success, err = await loop.run_in_executor(
                    None, _send_email_sync,
                    config["smtp_host"], config["smtp_port"],
                    config["email"], config["password"],
                    config["email"], to, subject, body
                )
                return success, f"Email sent to {to}" if success else f"Email failed: {err}"
            except Exception as e:
                return False, f"Email error: {e}"

        elif step_type in ("research",):
            topic = _interpolate(step.get("topic", ""), step_outputs, last_output)
            return True, f"Research requested: {topic} (use /research for full output)"

        elif step_type == "screenshot":
            try:
                import pyautogui
                import io as _io
                img = pyautogui.screenshot()
                path = Path.home() / ".salim" / "workflow_screenshot.png"
                img.save(str(path))
                return True, f"Screenshot saved: {path}"
            except Exception as e:
                return False, f"Screenshot failed: {e}"

        elif step_type == "browse":
            url = _interpolate(step.get("url", ""), step_outputs, last_output)
            return True, f"Browse requested: {url} (browser automation active)"

        else:
            return False, f"Unknown step type: {step_type}"

    except asyncio.TimeoutError:
        return False, "Step timed out (30s)"
    except Exception as e:
        return False, f"Error: {e}"


async def _run_workflow(
    steps: list[dict],
    ai_instance,
    progress_callback,
    stop_event: asyncio.Event,
    bot=None,
    chat_id: int = 0,
) -> tuple[list[dict], str]:
    """
    Execute workflow steps in sequence.
    Returns (step_results, final_output).
    """
    step_outputs = []
    step_results = []
    failures = 0

    for i, step in enumerate(steps):
        if stop_event.is_set():
            break

        step_type = step.get("type", "?")
        await progress_callback(i + 1, len(steps), step_type, None)

        success, output = await _execute_step(step, step_outputs, ai_instance, bot, chat_id)

        step_outputs.append(output)
        step_results.append({
            "step": i + 1,
            "type": step_type,
            "success": success,
            "output": output[:200],
        })

        if not success:
            failures += 1
            if failures >= 3:
                await progress_callback(i + 1, len(steps), f"FAILED: {step_type}", output)
                break

        await progress_callback(i + 1, len(steps), step_type, output)
        await asyncio.sleep(0.3)

    final_output = step_outputs[-1] if step_outputs else "(no output)"
    return step_results, final_output


class WorkflowHandlers:
    """Workflow automation handler — chain multi-step tasks."""

    @require_auth
    async def cmd_workflow(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /workflow <subcommand>
        
        Subcommands:
          list                     — list saved workflows
          run <name>               — run a workflow
          save <name> | step1\\nstep2 — save a new workflow
          delete <name>            — delete a workflow
          show <name>              — show workflow steps
          stop                     — stop running workflow
          template <name>          — load and run a built-in template
        
        Example workflow definition:
          /workflow save morning | system_info:
          ai: Summarize this: {last_output}
          notify: Good morning! {last_output}
        
        Built-in templates: daily_briefing, system_report, security_check
        """
        msg = update.effective_message
        user_id = update.effective_user.id

        subcommand = ctx.args[0].lower() if ctx.args else "list"
        args = ctx.args[1:] if len(ctx.args) > 1 else []
        workflows = _load_workflows()

        if subcommand == "list":
            all_workflows = {
                **{f"[template] {k}": v for k, v in WORKFLOW_TEMPLATES.items()},
                **workflows
            }
            if not all_workflows:
                await msg.reply_text(
                    "📋 <b>No workflows saved.</b>\n\n"
                    "Create one with:\n"
                    "<code>/workflow save name | step1\nstep2</code>\n\n"
                    "Or use a template:\n"
                    "<code>/workflow run daily_briefing</code>",
                    parse_mode=H
                )
                return

            lines = ["📋 <b>Workflows</b>\n"]
            for name, wf in WORKFLOW_TEMPLATES.items():
                lines.append(f"🔧 <code>{esc(name)}</code> — {esc(wf.get('description', ''))}")
            for name, wf in workflows.items():
                step_count = len(wf.get("steps", []))
                lines.append(f"⚙️ <code>{esc(name)}</code> — {step_count} steps")

            lines.append("\n<i>/workflow run &lt;name&gt; to execute</i>")
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif subcommand == "run":
            name = args[0] if args else ""
            if not name:
                await msg.reply_text(
                    "Usage: <code>/workflow run &lt;name&gt;</code>\n\n"
                    "Available: " + ", ".join(
                        f"<code>{n}</code>" for n in list(WORKFLOW_TEMPLATES.keys()) + list(workflows.keys())
                    ),
                    parse_mode=H
                )
                return

            # Find workflow
            wf = WORKFLOW_TEMPLATES.get(name) or workflows.get(name)
            if not wf:
                await msg.reply_text(f"❌ Workflow not found: <code>{esc(name)}</code>", parse_mode=H)
                return

            steps = wf.get("steps", [])
            if not steps:
                await msg.reply_text(f"❌ Workflow has no steps: {esc(name)}", parse_mode=H)
                return

            # Cancel existing
            if user_id in _active_workflows and not _active_workflows[user_id].done():
                _active_workflows[user_id].cancel()
                await asyncio.sleep(0.1)

            stop_event = asyncio.Event()

            progress_msg = await msg.reply_text(
                f"⚙️ <b>Running workflow:</b> <i>{esc(name)}</i>\n"
                f"📋 {len(steps)} steps\n\n"
                f"<i>Step 1/{len(steps)}: Starting…</i>",
                parse_mode=H
            )

            step_log = []

            async def progress_callback(step_num: int, total: int, step_type: str, output):
                entry = {
                    "step": step_num,
                    "type": step_type,
                    "output": output,
                }
                # Update or replace last entry for same step
                if step_log and step_log[-1]["step"] == step_num:
                    step_log[-1] = entry
                else:
                    step_log.append(entry)

                lines = [f"⚙️ <b>Workflow: {esc(name)}</b>", ""]
                for e in step_log[-5:]:
                    icon = "✅" if e["output"] is not None and not str(e["output"]).startswith("Error") else "⏳" if e["output"] is None else "❌"
                    lines.append(f"{icon} Step {e['step']}: <code>{esc(e['type'])}</code>")
                    if e["output"] and e["output"] != "(no output)":
                        lines.append(f"   → <i>{esc(str(e['output'])[:80])}</i>")
                if output is None:
                    lines.append(f"\n<i>Executing step {step_num}/{total}…</i>")

                try:
                    await progress_msg.edit_text("\n".join(lines), parse_mode=H)
                except Exception:
                    pass

            async def workflow_task():
                try:
                    results, final_output = await _run_workflow(
                        steps=steps,
                        ai_instance=self._ai if hasattr(self, "_ai") else None,
                        progress_callback=progress_callback,
                        stop_event=stop_event,
                        chat_id=msg.chat_id,
                    )

                    success_count = sum(1 for r in results if r.get("success"))
                    fail_count = len(results) - success_count

                    await progress_msg.edit_text(
                        f"✅ <b>Workflow Complete: {esc(name)}</b>\n\n"
                        f"📊 {len(results)} steps · {success_count} succeeded"
                        + (f" · {fail_count} failed" if fail_count else "")
                        + "\n\n"
                        f"<b>Final output:</b>\n<pre>{esc(final_output[:1000])}</pre>",
                        parse_mode=H
                    )
                except asyncio.CancelledError:
                    await progress_msg.edit_text(
                        f"⏹️ <b>Workflow stopped:</b> {esc(name)}",
                        parse_mode=H
                    )
                except Exception as e:
                    await progress_msg.edit_text(
                        f"❌ <b>Workflow error:</b>\n<code>{esc(str(e)[:300])}</code>",
                        parse_mode=H
                    )
                finally:
                    _active_workflows.pop(user_id, None)

            task = asyncio.create_task(workflow_task())
            _active_workflows[user_id] = task

        elif subcommand == "stop":
            if user_id in _active_workflows and not _active_workflows[user_id].done():
                _active_workflows[user_id].cancel()
                await msg.reply_text("⏹️ <b>Workflow stopped.</b>", parse_mode=H)
            else:
                await msg.reply_text("ℹ️ No workflow running.", parse_mode=H)

        elif subcommand == "save":
            # /workflow save name | steps...
            full_text = " ".join(args)
            if "|" not in full_text:
                await msg.reply_text(
                    "📋 <b>Save Workflow</b>\n\n"
                    "Format: <code>/workflow save name | steps</code>\n\n"
                    "Use <code>\\n</code> for newlines or send steps as separate lines.\n\n"
                    "<b>Step types:</b>\n"
                    "• <code>shell: command</code>\n"
                    "• <code>ai: prompt with {last_output}</code>\n"
                    "• <code>system_info:</code>\n"
                    "• <code>notify: message</code>\n"
                    "• <code>wait: 5</code> (seconds)\n"
                    "• <code>file_write: ~/Desktop/out.txt</code>\n"
                    "• <code>scrape: url</code>\n"
                    "• <code>email: to@email.com | Subject | {last_output}</code>\n\n"
                    "<b>Example:</b>\n"
                    "<code>/workflow save syscheck | system_info:\nai: Summarize: {last_output}\nnotify: Done!</code>",
                    parse_mode=H
                )
                return

            name, _, steps_text = full_text.partition("|")
            name = name.strip().replace(" ", "_")
            # Handle \n literals in message
            steps_text = steps_text.replace("\\n", "\n").strip()

            steps = _parse_workflow_steps(steps_text)
            if not steps:
                await msg.reply_text(
                    "❌ No valid steps found. Check format:\n"
                    "<code>shell: ls -la\nai: Analyze: {last_output}</code>",
                    parse_mode=H
                )
                return

            workflows[name] = {
                "description": f"Custom workflow ({len(steps)} steps)",
                "steps": steps,
                "created": datetime.now().isoformat(),
            }
            _save_workflows(workflows)

            step_list = "\n".join(
                f"{i+1}. <code>{esc(s.get('type', '?'))}</code>"
                for i, s in enumerate(steps)
            )
            await msg.reply_text(
                f"✅ <b>Workflow saved: {esc(name)}</b>\n\n"
                f"<b>Steps ({len(steps)}):</b>\n{step_list}\n\n"
                f"<i>Run with: /workflow run {esc(name)}</i>",
                parse_mode=H
            )

        elif subcommand == "delete":
            name = args[0] if args else ""
            if name in workflows:
                del workflows[name]
                _save_workflows(workflows)
                await msg.reply_text(f"🗑️ Deleted workflow: <code>{esc(name)}</code>", parse_mode=H)
            else:
                await msg.reply_text(f"❌ Workflow not found: <code>{esc(name)}</code>", parse_mode=H)

        elif subcommand == "show":
            name = args[0] if args else ""
            wf = WORKFLOW_TEMPLATES.get(name) or workflows.get(name)
            if not wf:
                await msg.reply_text(f"❌ Workflow not found: <code>{esc(name)}</code>", parse_mode=H)
                return

            steps = wf.get("steps", [])
            lines = [f"⚙️ <b>Workflow: {esc(name)}</b>\n"]
            for i, step in enumerate(steps, 1):
                stype = step.get("type", "?")
                params = ""
                if stype == "shell":
                    params = step.get("command", "")[:60]
                elif stype == "ai":
                    params = step.get("prompt", "")[:60]
                elif stype == "file_write":
                    params = step.get("path", "")[:40]
                elif stype == "scrape":
                    params = step.get("url", "")[:40]
                elif stype == "email":
                    params = step.get("to", "")[:30]
                lines.append(
                    f"{i}. <b>{esc(stype)}</b>"
                    + (f": <i>{esc(params)}{'…' if len(params) >= 60 else ''}</i>" if params else "")
                )
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif subcommand == "template":
            name = args[0] if args else ""
            if not name:
                lines = ["🔧 <b>Built-in Workflow Templates</b>\n"]
                for tname, twf in WORKFLOW_TEMPLATES.items():
                    lines.append(f"• <code>{esc(tname)}</code> — {esc(twf.get('description', ''))}")
                lines.append("\n<i>/workflow template &lt;name&gt; to run</i>")
                await msg.reply_text("\n".join(lines), parse_mode=H)
                return

            if name not in WORKFLOW_TEMPLATES:
                await msg.reply_text(
                    f"❌ Template not found: <code>{esc(name)}</code>\n\n"
                    f"Available: " + ", ".join(f"<code>{n}</code>" for n in WORKFLOW_TEMPLATES),
                    parse_mode=H
                )
                return

            # Run the template directly
            ctx.args = ["run", name]
            await self.cmd_workflow(update, ctx)

        else:
            await msg.reply_text(
                "⚙️ <b>Workflow Automation</b>\n\n"
                "<code>/workflow list</code>\n"
                "<code>/workflow run &lt;name&gt;</code>\n"
                "<code>/workflow save &lt;name&gt; | steps</code>\n"
                "<code>/workflow show &lt;name&gt;</code>\n"
                "<code>/workflow delete &lt;name&gt;</code>\n"
                "<code>/workflow stop</code>\n"
                "<code>/workflow template &lt;name&gt;</code>\n\n"
                "Built-in templates: <code>daily_briefing</code>, <code>system_report</code>, <code>security_check</code>",
                parse_mode=H
            )
