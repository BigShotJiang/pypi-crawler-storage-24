"""
Salim Notes — quick notes scratchpad.
"""
from __future__ import annotations

import html
import json
import logging
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.notes")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

NOTES_FILE = Path.home() / ".salim" / "notes.json"


def _load_notes() -> list[dict]:
    if not NOTES_FILE.exists():
        return []
    try:
        return json.loads(NOTES_FILE.read_text())
    except Exception:
        return []


def _save_notes(notes: list[dict]):
    NOTES_FILE.parent.mkdir(parents=True, exist_ok=True)
    NOTES_FILE.write_text(json.dumps(notes, indent=2))


class NotesHandlers:

    @require_auth
    async def cmd_note(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Save a quick note: /note <text>"""
        if not ctx.args:
            await update.effective_message.reply_text(
                "📝 Usage: <code>/note &lt;your note text&gt;</code>\n"
                "Use /notes to list all, /notedel &lt;id&gt; to delete.",
                parse_mode=H
            )
            return
        text = " ".join(ctx.args)
        notes = _load_notes()
        note_id = (max(n["id"] for n in notes) + 1) if notes else 1
        notes.append({
            "id": note_id,
            "text": text,
            "ts": datetime.now().isoformat(),
        })
        _save_notes(notes)
        await update.effective_message.reply_text(
            f"📝 Note #{note_id} saved: <i>{esc(text[:200])}</i>",
            parse_mode=H
        )

    @require_auth
    async def cmd_notes(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List all notes."""
        notes = _load_notes()
        if not notes:
            await update.effective_message.reply_text("📝 No notes saved yet. Use /note <text>.", parse_mode=H)
            return
        lines = []
        for n in notes[-20:]:
            ts = n.get("ts", "")[:16]
            lines.append(f"<b>#{n['id']}</b> <code>{esc(ts)}</code>\n{esc(n['text'][:200])}")
        await update.effective_message.reply_text(
            f"📝 <b>Notes ({len(notes)} total)</b>\n\n" + "\n\n".join(lines),
            parse_mode=H
        )

    @require_auth
    async def cmd_notedel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Delete a note by ID: /notedel <id>"""
        if not ctx.args or not ctx.args[0].isdigit():
            await update.effective_message.reply_text("Usage: /notedel <id>", parse_mode=H)
            return
        note_id = int(ctx.args[0])
        notes = _load_notes()
        new_notes = [n for n in notes if n["id"] != note_id]
        if len(new_notes) == len(notes):
            await update.effective_message.reply_text(f"❌ Note #{note_id} not found.", parse_mode=H)
            return
        _save_notes(new_notes)
        await update.effective_message.reply_text(f"🗑️ Note #{note_id} deleted.", parse_mode=H)

    @require_auth
    async def cmd_noteclear(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Clear all notes."""
        _save_notes([])
        await update.effective_message.reply_text("🗑️ All notes cleared.", parse_mode=H)
