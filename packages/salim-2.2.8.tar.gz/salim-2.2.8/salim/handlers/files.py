"""
Salim File Handlers — full file system operations via Telegram.
"""
from __future__ import annotations

import asyncio
import html
import io
import logging
import os
import shutil
import stat
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, bytes_to_human, safe_read, truncate

logger = logging.getLogger("salim.files")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)


class FileHandlers:

    def _resolve(self, path: str) -> Path:
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = Path(self._cwd) / p
        return p.resolve()

    @require_auth
    async def cmd_ls(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        path = ctx.args[0] if ctx.args else self._cwd
        try:
            p = self._resolve(path)
            entries = sorted(p.iterdir(), key=lambda e: (e.is_file(), e.name.lower()))
            lines = []
            for e in entries[:60]:
                try:
                    s = e.stat()
                    icon = "📁" if e.is_dir() else "📄"
                    size = bytes_to_human(s.st_size) if e.is_file() else ""
                    lines.append(f"{icon} <code>{esc(e.name)}</code>  {esc(size)}")
                except PermissionError:
                    lines.append(f"🔒 <code>{esc(e.name)}</code>")
            text = f"📂 <b>{esc(str(p))}</b>  ({len(entries)} items)\n\n" + "\n".join(lines)
            if len(entries) > 60:
                text += f"\n<i>...and {len(entries)-60} more</i>"
            await update.effective_message.reply_text(truncate(text), parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_cd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            self._cwd = str(Path.home())
            await update.effective_message.reply_text(f"📂 <code>{esc(self._cwd)}</code>", parse_mode=H)
            return
        path = " ".join(ctx.args)
        try:
            p = self._resolve(path)
            if not p.is_dir():
                await update.effective_message.reply_text(f"❌ Not a directory: <code>{esc(str(p))}</code>", parse_mode=H)
                return
            self._cwd = str(p)
            await update.effective_message.reply_text(f"📂 <code>{esc(self._cwd)}</code>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_pwd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.reply_text(f"📂 <code>{esc(self._cwd)}</code>", parse_mode=H)

    @require_auth
    async def cmd_cat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /cat <file>", parse_mode=H)
            return
        path = " ".join(ctx.args)
        try:
            p = self._resolve(path)
            content, is_binary = safe_read(p)
            if is_binary:
                await update.effective_message.reply_text(f"📄 Binary file: {esc(content)}", parse_mode=H)
            else:
                await update.effective_message.reply_text(
                    f"📄 <b>{esc(p.name)}</b>\n<pre>{esc(truncate(content, 3500))}</pre>",
                    parse_mode=H
                )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_stat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /stat <file>", parse_mode=H)
            return
        path = " ".join(ctx.args)
        try:
            p = self._resolve(path)
            s = p.stat()
            mtime = datetime.fromtimestamp(s.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            ctime = datetime.fromtimestamp(s.st_ctime).strftime("%Y-%m-%d %H:%M:%S")
            text = (
                f"📊 <b>{esc(p.name)}</b>\n"
                f"Path: <code>{esc(str(p))}</code>\n"
                f"Size: {bytes_to_human(s.st_size)}\n"
                f"Modified: {mtime}\n"
                f"Created: {ctime}\n"
                f"Type: {'Directory' if p.is_dir() else 'File'}\n"
                f"Permissions: {oct(stat.S_IMODE(s.st_mode))}"
            )
            await update.effective_message.reply_text(text, parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_find(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /find <pattern>", parse_mode=H)
            return
        pattern = ctx.args[0]
        out, _ = await run_shell_async(
            f"find {self._cwd} -name '*{pattern}*' -not -path '*/.*' 2>/dev/null | head -30"
        )
        await update.effective_message.reply_text(
            f"🔍 Find <code>{esc(pattern)}</code>:\n<pre>{esc(truncate(out, 3500))}</pre>",
            parse_mode=H
        )

    @require_auth
    async def cmd_grep(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /grep <pattern> [path]", parse_mode=H)
            return
        pattern = ctx.args[0]
        path = ctx.args[1] if len(ctx.args) > 1 else self._cwd
        out, _ = await run_shell_async(
            f"grep -rn '{pattern}' '{path}' --include='*.py' --include='*.txt' --include='*.md' 2>/dev/null | head -20"
        )
        await update.effective_message.reply_text(
            f"🔍 Grep <code>{esc(pattern)}</code>:\n<pre>{esc(truncate(out, 3500))}</pre>",
            parse_mode=H
        )

    @require_auth
    async def cmd_mkdir(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /mkdir <name>", parse_mode=H)
            return
        name = " ".join(ctx.args)
        try:
            p = self._resolve(name)
            p.mkdir(parents=True, exist_ok=True)
            await update.effective_message.reply_text(f"✅ Created: <code>{esc(str(p))}</code>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_rm(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /rm <path>", parse_mode=H)
            return
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        path = " ".join(ctx.args)
        p = self._resolve(path)
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Yes, delete", callback_data=f"rm_confirm:{p}"),
            InlineKeyboardButton("❌ Cancel", callback_data="rm_cancel"),
        ]])
        await update.effective_message.reply_text(
            f"⚠️ Delete <code>{esc(str(p))}</code>?",
            parse_mode=H, reply_markup=markup
        )

    async def cb_rm_confirm(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        path = query.data.split(":", 1)[1]
        try:
            p = Path(path)
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            await query.edit_message_text(f"🗑️ Deleted: <code>{esc(path)}</code>", parse_mode=H)
        except Exception as e:
            await query.edit_message_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_mv(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: /mv <src> <dst>", parse_mode=H)
            return
        src = self._resolve(ctx.args[0])
        dst = self._resolve(ctx.args[1])
        try:
            shutil.move(str(src), str(dst))
            await update.effective_message.reply_text(
                f"✅ Moved: <code>{esc(str(src))}</code> → <code>{esc(str(dst))}</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_cp(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: /cp <src> <dst>", parse_mode=H)
            return
        src = self._resolve(ctx.args[0])
        dst = self._resolve(ctx.args[1])
        try:
            if src.is_dir():
                shutil.copytree(str(src), str(dst))
            else:
                shutil.copy2(str(src), str(dst))
            await update.effective_message.reply_text(
                f"✅ Copied: <code>{esc(str(src))}</code> → <code>{esc(str(dst))}</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_download(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: /download <path>\nSends file to Telegram.", parse_mode=H
            )
            return
        path = " ".join(ctx.args)
        try:
            p = self._resolve(path)
            if not p.exists():
                await update.effective_message.reply_text(f"❌ Not found: <code>{esc(str(p))}</code>", parse_mode=H)
                return
            size = p.stat().st_size
            if size > self.config.max_file_mb * 1024 * 1024:
                await update.effective_message.reply_text(
                    f"❌ File too large ({bytes_to_human(size)}). Max: {self.config.max_file_mb} MB", parse_mode=H
                )
                return
            await update.effective_message.reply_document(
                document=open(p, "rb"),
                filename=p.name,
                caption=f"📄 {esc(p.name)} · {bytes_to_human(size)}"
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_upload_prompt(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.reply_text(
            "📤 Send any file to upload it to your laptop.\n"
            "I'll ask you where to save it.",
            parse_mode=H
        )

    @require_auth
    async def cmd_zip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /zip <path>", parse_mode=H)
            return
        path = " ".join(ctx.args)
        try:
            p = self._resolve(path)
            zip_path = p.with_suffix(".zip")
            out, rc = await run_shell_async(f"zip -r '{zip_path}' '{p}' 2>&1")
            if rc == 0:
                size = zip_path.stat().st_size
                await update.effective_message.reply_text(
                    f"✅ Zipped: <code>{esc(str(zip_path))}</code> ({bytes_to_human(size)})",
                    parse_mode=H
                )
            else:
                await update.effective_message.reply_text(f"❌ Zip error:\n<pre>{esc(out[:500])}</pre>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_unzip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /unzip <file.zip>", parse_mode=H)
            return
        path = " ".join(ctx.args)
        try:
            p = self._resolve(path)
            dest = p.parent / p.stem
            out, rc = await run_shell_async(f"unzip -o '{p}' -d '{dest}' 2>&1")
            if rc == 0:
                await update.effective_message.reply_text(
                    f"✅ Unzipped to: <code>{esc(str(dest))}</code>", parse_mode=H
                )
            else:
                await update.effective_message.reply_text(f"❌ Unzip error:\n<pre>{esc(out[:500])}</pre>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_write(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Usage: /write <path> | <content>"""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /write <path> | <content>", parse_mode=H)
            return
        text = " ".join(ctx.args)
        if "|" not in text:
            await update.effective_message.reply_text("Usage: /write <path> | <content>", parse_mode=H)
            return
        path_part, _, content = text.partition("|")
        try:
            p = self._resolve(path_part.strip())
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content.strip())
            await update.effective_message.reply_text(
                f"✅ Written: <code>{esc(str(p))}</code> ({len(content.strip())} chars)",
                parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)
