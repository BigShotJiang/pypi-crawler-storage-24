"""
Salim Web Scraper — real web scraping like Manus AI.

Manus uses its browser to scrape, extract structured data, monitor pages,
and bulk-scrape multiple URLs. This provides the same capabilities.

Commands:
  /scrape <url>               — scrape a URL (auto-detect content)
  /scrape <url> text          — extract clean text only
  /scrape <url> links         — extract all links
  /scrape <url> tables        — extract data tables as CSV
  /scrape <url> images        — list all images
  /scrapebulk <url1> <url2>…  — scrape multiple URLs
  /scrapewatch <url> <mins>   — monitor URL for changes
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, truncate

logger = logging.getLogger("salim.scraper")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

SCRAPE_DIR = Path.home() / ".salim" / "scrapes"
SCRAPE_DIR.mkdir(parents=True, exist_ok=True)

_watch_tasks: dict[int, asyncio.Task] = {}


def _extract_with_bs4(html_content: str, mode: str = "text") -> str:
    """Parse HTML with BeautifulSoup."""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_content, "html.parser")

        # Remove noise
        for tag in soup(["script", "style", "nav", "footer", "aside", "iframe"]):
            tag.decompose()

        if mode == "text":
            text = soup.get_text(separator="\n", strip=True)
            # Clean blank lines
            lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
            return "\n".join(lines)

        elif mode == "links":
            links = []
            for a in soup.find_all("a", href=True):
                text_content = a.get_text(strip=True) or "(no text)"
                href = a["href"]
                links.append(f"{text_content[:60]} → {href}")
            return "\n".join(links[:100])

        elif mode == "tables":
            tables = soup.find_all("table")
            if not tables:
                return "No tables found."
            results = []
            for i, table in enumerate(tables[:5]):
                rows = []
                for tr in table.find_all("tr"):
                    cells = [td.get_text(strip=True) for td in tr.find_all(["th", "td"])]
                    rows.append(",".join(f'"{c}"' for c in cells))
                results.append(f"# Table {i+1}\n" + "\n".join(rows))
            return "\n\n".join(results)

        elif mode == "images":
            imgs = []
            for img in soup.find_all("img"):
                src = img.get("src", "")
                alt = img.get("alt", "")
                if src:
                    imgs.append(f"{alt[:40] or '(no alt)'} → {src}")
            return "\n".join(imgs[:100])

        elif mode == "meta":
            meta_info = []
            title = soup.find("title")
            if title:
                meta_info.append(f"Title: {title.get_text(strip=True)}")
            for meta in soup.find_all("meta"):
                name = meta.get("name", meta.get("property", ""))
                content = meta.get("content", "")
                if name and content:
                    meta_info.append(f"{name}: {content[:100]}")
            return "\n".join(meta_info[:30])

        elif mode == "raw":
            return str(soup)

        else:
            return soup.get_text(separator="\n", strip=True)

    except ImportError:
        # Fallback: basic regex extraction
        if mode == "text":
            text = re.sub(r"<[^>]+>", " ", html_content)
            text = re.sub(r"\s+", " ", text).strip()
            return text[:5000]
        elif mode == "links":
            links = re.findall(r'href=["\']([^"\']+)["\']', html_content)
            return "\n".join(links[:100])
        else:
            return "BeautifulSoup not installed. Run: pip install beautifulsoup4"


async def _fetch_url(url: str, timeout: int = 15) -> tuple[str, int, str]:
    """Fetch URL with curl, return (content, status_code, content_type)."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    # Use curl for reliable fetching
    out, rc = await run_shell_async(
        f"curl -sL -w '\\n__STATUS__:%{{http_code}}\\n__CT__:%{{content_type}}\\n' "
        f"--max-time {timeout} --max-filesize 5000000 "
        f"-A 'Mozilla/5.0 (compatible; SalimBot/1.0)' "
        f"-H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' "
        f"'{url}' 2>/dev/null",
        timeout=timeout + 5
    )

    status = 0
    content_type = ""
    content = out

    # Extract status and content type from markers
    if "__STATUS__:" in out:
        parts = out.split("\n__STATUS__:")
        content = parts[0]
        rest = parts[1] if len(parts) > 1 else ""
        status_line = rest.split("\n")[0]
        try:
            status = int(status_line.strip())
        except ValueError:
            status = 0

    if "__CT__:" in out:
        ct_parts = out.split("__CT__:")
        ct_line = ct_parts[-1].split("\n")[0]
        content_type = ct_line.strip()

    return content, status, content_type


class ScraperHandlers:

    @require_auth
    async def cmd_scrape(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Scrape a URL and extract content."""
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "🌐 <b>Web Scraper</b>\n\n"
                "<b>Usage:</b> <code>/scrape &lt;url&gt; [mode]</code>\n\n"
                "<b>Modes:</b>\n"
                "• <code>text</code> (default) — clean text content\n"
                "• <code>links</code> — all hyperlinks\n"
                "• <code>tables</code> — data tables as CSV\n"
                "• <code>images</code> — image list\n"
                "• <code>meta</code> — page metadata\n"
                "• <code>raw</code> — raw HTML\n\n"
                "<b>Examples:</b>\n"
                "<code>/scrape https://en.wikipedia.org/wiki/Python text</code>\n"
                "<code>/scrape https://example.com/page tables</code>",
                parse_mode=H
            )
            return

        url = ctx.args[0]
        mode = ctx.args[1].lower() if len(ctx.args) > 1 else "text"

        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        status = await msg.reply_text(
            f"🌐 <i>Scraping {esc(url[:60])} [{mode}]…</i>",
            parse_mode=H
        )

        try:
            content, http_status, content_type = await _fetch_url(url)

            if not content or len(content) < 10:
                await status.edit_text(
                    f"❌ Empty response from {esc(url[:60])}\n"
                    f"HTTP status: {http_status}",
                    parse_mode=H
                )
                return

            if mode == "raw":
                # Send as file
                raw_bytes = content.encode("utf-8", errors="replace")
                buf = io.BytesIO(raw_bytes)
                buf.name = "page.html"
                await status.delete()
                await msg.reply_document(
                    document=buf,
                    filename="page.html",
                    caption=f"🌐 Raw HTML from {esc(url[:60])} (HTTP {http_status})"
                )
                return

            # Extract based on mode
            loop = asyncio.get_event_loop()
            extracted = await loop.run_in_executor(None, _extract_with_bs4, content, mode)

            if not extracted:
                await status.edit_text(f"⚠️ No {mode} content found at {esc(url[:60])}", parse_mode=H)
                return

            # Save to file
            filename = f"scrape_{datetime.now().strftime('%H%M%S')}_{mode}.txt"
            save_path = SCRAPE_DIR / filename
            save_path.write_text(extracted, encoding="utf-8")

            # Send as text or file
            if len(extracted) <= 3000:
                await status.edit_text(
                    f"🌐 <b>Scraped:</b> {esc(url[:60])}\n"
                    f"Mode: {mode} | HTTP: {http_status} | {len(extracted)} chars\n\n"
                    f"<pre>{esc(extracted[:2800])}</pre>",
                    parse_mode=H
                )
            else:
                # Send as file + preview
                await status.edit_text(
                    f"🌐 <b>Scraped:</b> {esc(url[:60])}\n"
                    f"Mode: {mode} | HTTP: {http_status} | {len(extracted):,} chars\n\n"
                    f"<i>Preview:</i>\n<pre>{esc(extracted[:1000])}</pre>",
                    parse_mode=H
                )
                buf = io.BytesIO(extracted.encode("utf-8"))
                buf.name = filename
                await msg.reply_document(
                    document=buf,
                    filename=filename,
                    caption=f"📄 Full scrape: {mode} content ({len(extracted):,} chars)"
                )

        except Exception as e:
            await status.edit_text(f"❌ Scrape error: {esc(str(e)[:200])}", parse_mode=H)

    @require_auth
    async def cmd_scrapebulk(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Scrape multiple URLs: /scrapebulk <url1> <url2> ..."""
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "🌐 <b>Bulk Scrape</b>\n\n"
                "Usage: <code>/scrapebulk &lt;url1&gt; &lt;url2&gt; &lt;url3&gt;…</code>\n\n"
                "Scrapes up to 10 URLs in parallel and returns a combined report.",
                parse_mode=H
            )
            return

        urls = ctx.args[:10]
        status = await msg.reply_text(
            f"🌐 <i>Bulk scraping {len(urls)} URLs…</i>",
            parse_mode=H
        )

        try:
            # Fetch all URLs in parallel
            tasks = [_fetch_url(url) for url in urls]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            report_lines = [f"📊 Bulk Scrape Report — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"]

            for url, result in zip(urls, results):
                if isinstance(result, Exception):
                    report_lines.append(f"❌ {url}: {str(result)[:100]}")
                else:
                    content, http_status, ct = result
                    extracted = _extract_with_bs4(content, "text") if content else ""
                    word_count = len(extracted.split()) if extracted else 0
                    report_lines.append(
                        f"✅ {url}\n"
                        f"   HTTP {http_status} | {word_count:,} words\n"
                        f"   Preview: {extracted[:200] if extracted else 'No content'}"
                    )
                report_lines.append("")

            report = "\n".join(report_lines)

            await status.delete()
            buf = io.BytesIO(report.encode("utf-8"))
            buf.name = "bulk_scrape.txt"
            await msg.reply_document(
                document=buf,
                filename="bulk_scrape.txt",
                caption=f"🌐 Bulk scrape: {len(urls)} URLs processed"
            )

        except Exception as e:
            await status.edit_text(f"❌ Bulk scrape error: {esc(str(e)[:200])}", parse_mode=H)

    @require_auth
    async def cmd_scrapewatch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Monitor a URL for changes: /scrapewatch <url> [interval_mins]"""
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "👀 <b>URL Change Monitor</b>\n\n"
                "Usage: <code>/scrapewatch &lt;url&gt; [interval_mins]</code>\n\n"
                "Monitors a URL and alerts you when content changes.\n"
                "Default interval: 5 minutes. Use /watchstop to stop.",
                parse_mode=H
            )
            return

        url = ctx.args[0]
        interval_mins = int(ctx.args[1]) if len(ctx.args) > 1 and ctx.args[1].isdigit() else 5
        interval_secs = max(60, interval_mins * 60)

        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        # Stop existing watch
        if chat_id in _watch_tasks and not _watch_tasks[chat_id].done():
            _watch_tasks[chat_id].cancel()

        task = asyncio.create_task(
            self._watch_loop(chat_id, url, interval_secs)
        )
        _watch_tasks[chat_id] = task

        await msg.reply_text(
            f"👀 <b>URL Monitor Started</b>\n"
            f"URL: {esc(url[:80])}\n"
            f"Interval: {interval_mins} minute(s)\n\n"
            f"You'll be notified when the page content changes.",
            parse_mode=H
        )

    async def _watch_loop(self, chat_id: int, url: str, interval_secs: int):
        """Background URL monitoring loop."""
        import hashlib

        prev_hash = None
        first_run = True

        while True:
            try:
                content, status_code, _ = await _fetch_url(url)
                if content:
                    text = _extract_with_bs4(content, "text")
                    curr_hash = hashlib.md5(text.encode()).hexdigest()

                    if first_run:
                        prev_hash = curr_hash
                        first_run = False
                        logger.info(f"Watch {url}: initial hash {curr_hash[:8]}")
                    elif curr_hash != prev_hash:
                        logger.info(f"Watch {url}: content changed!")
                        try:
                            await self._app.bot.send_message(
                                chat_id=chat_id,
                                text=(
                                    f"🔔 <b>Page Changed!</b>\n\n"
                                    f"URL: {esc(url[:80])}\n"
                                    f"Time: {datetime.now().strftime('%H:%M:%S')}\n\n"
                                    f"<i>Preview:</i>\n<pre>{esc(text[:500])}</pre>"
                                ),
                                parse_mode=H
                            )
                        except Exception as e:
                            logger.error(f"Watch alert error: {e}")
                        prev_hash = curr_hash

            except asyncio.CancelledError:
                logger.info(f"Watch {url} cancelled")
                return
            except Exception as e:
                logger.error(f"Watch loop error: {e}")

            await asyncio.sleep(interval_secs)
