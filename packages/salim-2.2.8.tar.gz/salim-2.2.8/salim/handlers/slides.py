"""
Salim Slides — AI-powered presentation generator like Manus AI.

Manus can generate entire professional slide decks from a single prompt.
This handler does the same using python-pptx + AI content generation.

Commands:
  /slides <topic>               — generate a presentation
  /slides <topic> --slides N    — set number of slides (default: 8)
  /slides <topic> --theme dark|light|corporate|creative  — choose theme
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.slides")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

SLIDES_DIR = Path.home() / ".salim" / "slides"
SLIDES_DIR.mkdir(parents=True, exist_ok=True)


THEME_CONFIGS = {
    "dark": {
        "bg": (30, 30, 46),
        "title_color": (203, 166, 247),
        "text_color": (205, 214, 244),
        "accent": (137, 180, 250),
        "subtitle_color": (166, 173, 200),
    },
    "corporate": {
        "bg": (255, 255, 255),
        "title_color": (31, 56, 100),
        "text_color": (44, 62, 80),
        "accent": (41, 128, 185),
        "subtitle_color": (127, 140, 141),
    },
    "creative": {
        "bg": (248, 249, 250),
        "title_color": (155, 89, 182),
        "text_color": (52, 73, 94),
        "accent": (230, 126, 34),
        "subtitle_color": (127, 140, 141),
    },
    "light": {
        "bg": (250, 250, 250),
        "title_color": (44, 62, 80),
        "text_color": (52, 73, 94),
        "accent": (26, 188, 156),
        "subtitle_color": (127, 140, 141),
    },
}


def _rgb(r, g, b):
    from pptx.util import Pt
    from pptx.dml.color import RGBColor
    return RGBColor(r, g, b)


def _build_pptx(slides_data: list[dict], title: str, theme: str = "dark") -> bytes:
    """Build a PPTX from structured slide data."""
    from pptx import Presentation
    from pptx.util import Inches, Pt, Emu
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN

    colors = THEME_CONFIGS.get(theme, THEME_CONFIGS["dark"])
    bg_color = _rgb(*colors["bg"])
    title_color = _rgb(*colors["title_color"])
    text_color = _rgb(*colors["text_color"])
    accent_color = _rgb(*colors["accent"])
    subtitle_color = _rgb(*colors["subtitle_color"])

    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    blank_layout = prs.slide_layouts[6]  # blank

    for i, slide_data in enumerate(slides_data):
        slide = prs.slides.add_slide(blank_layout)

        # Background
        bg = slide.background
        fill = bg.fill
        fill.solid()
        fill.fore_color.rgb = bg_color

        # Accent bar on left
        from pptx.util import Inches
        bar = slide.shapes.add_shape(
            1,  # MSO_SHAPE_TYPE.RECTANGLE
            Inches(0), Inches(0), Inches(0.15), Inches(7.5)
        )
        bar.fill.solid()
        bar.fill.fore_color.rgb = accent_color
        bar.line.fill.background()

        slide_type = slide_data.get("type", "content")
        slide_title = slide_data.get("title", "")
        slide_content = slide_data.get("content", [])
        slide_subtitle = slide_data.get("subtitle", "")

        if slide_type == "title":
            # Title slide
            txBox = slide.shapes.add_textbox(Inches(1), Inches(2.5), Inches(11), Inches(1.5))
            tf = txBox.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.CENTER
            run = p.add_run()
            run.text = slide_title
            run.font.size = Pt(44)
            run.font.bold = True
            run.font.color.rgb = title_color

            if slide_subtitle:
                txBox2 = slide.shapes.add_textbox(Inches(1), Inches(4.2), Inches(11), Inches(0.8))
                tf2 = txBox2.text_frame
                p2 = tf2.paragraphs[0]
                p2.alignment = PP_ALIGN.CENTER
                run2 = p2.add_run()
                run2.text = slide_subtitle
                run2.font.size = Pt(20)
                run2.font.color.rgb = subtitle_color

            # Slide number / date
            txDate = slide.shapes.add_textbox(Inches(10.5), Inches(7), Inches(2.5), Inches(0.4))
            tf3 = txDate.text_frame
            p3 = tf3.paragraphs[0]
            p3.alignment = PP_ALIGN.RIGHT
            run3 = p3.add_run()
            run3.text = datetime.now().strftime("%B %Y")
            run3.font.size = Pt(11)
            run3.font.color.rgb = subtitle_color

        else:
            # Content slide: title + bullet points
            # Title
            txTitle = slide.shapes.add_textbox(Inches(0.4), Inches(0.3), Inches(12.5), Inches(1.0))
            tf = txTitle.text_frame
            p = tf.paragraphs[0]
            run = p.add_run()
            run.text = slide_title
            run.font.size = Pt(28)
            run.font.bold = True
            run.font.color.rgb = title_color

            # Divider line
            line = slide.shapes.add_shape(1, Inches(0.4), Inches(1.35), Inches(12.5), Inches(0.03))
            line.fill.solid()
            line.fill.fore_color.rgb = accent_color
            line.line.fill.background()

            # Content bullets
            if slide_content:
                txContent = slide.shapes.add_textbox(Inches(0.5), Inches(1.5), Inches(12.0), Inches(5.5))
                tf2 = txContent.text_frame
                tf2.word_wrap = True

                for j, bullet in enumerate(slide_content):
                    if j == 0:
                        p = tf2.paragraphs[0]
                    else:
                        p = tf2.add_paragraph()

                    p.space_before = Pt(4)
                    p.space_after = Pt(2)
                    p.level = 0

                    # Add bullet marker
                    run = p.add_run()
                    if isinstance(bullet, dict):
                        run.text = f"• {bullet.get('text', bullet)}"
                        run.font.size = Pt(18)
                        run.font.bold = bullet.get("bold", False)
                    else:
                        run.text = f"• {bullet}"
                        run.font.size = Pt(18)
                    run.font.color.rgb = text_color

            # Slide number
            txNum = slide.shapes.add_textbox(Inches(12.5), Inches(7), Inches(0.7), Inches(0.4))
            tfn = txNum.text_frame
            pn = tfn.paragraphs[0]
            pn.alignment = PP_ALIGN.RIGHT
            rn = pn.add_run()
            rn.text = str(i + 1)
            rn.font.size = Pt(10)
            rn.font.color.rgb = subtitle_color

    buf = io.BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf.read()


class SlidesHandlers:

    @require_auth
    async def cmd_slides(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /slides <topic> [--slides N] [--theme dark|light|corporate|creative]
        
        Generate a professional presentation from a topic description.
        
        Examples:
          /slides Climate Change Impact on Agriculture
          /slides Python vs JavaScript 2025 --slides 10 --theme corporate
          /slides Q3 Sales Results --theme dark
        """
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "📊 <b>AI Slide Generator</b>\n\n"
                "Like Manus AI — create professional presentations from a single prompt.\n\n"
                "<b>Usage:</b> <code>/slides &lt;topic&gt; [options]</code>\n\n"
                "<b>Options:</b>\n"
                "• <code>--slides N</code> — number of slides (default: 8, max: 20)\n"
                "• <code>--theme dark|light|corporate|creative</code>\n\n"
                "<b>Examples:</b>\n"
                "<code>/slides The Future of AI in Healthcare</code>\n"
                "<code>/slides Python Tutorial for Beginners --slides 12 --theme light</code>\n"
                "<code>/slides Q4 Marketing Strategy --theme corporate</code>",
                parse_mode=H
            )
            return

        from salim.ai import SalimAI
        ai = SalimAI(self.config)

        if not ai.is_configured():
            await msg.reply_text(
                "❌ AI not configured. Set SALIM_NVIDIA_API_KEY or SALIM_OPENAI_API_KEY.",
                parse_mode=H
            )
            return

        # Parse arguments
        args_text = " ".join(ctx.args)
        num_slides = 8
        theme = "dark"

        slides_match = re.search(r"--slides\s+(\d+)", args_text)
        if slides_match:
            num_slides = max(3, min(20, int(slides_match.group(1))))
            args_text = args_text.replace(slides_match.group(0), "").strip()

        theme_match = re.search(r"--theme\s+(dark|light|corporate|creative)", args_text, re.IGNORECASE)
        if theme_match:
            theme = theme_match.group(1).lower()
            args_text = args_text.replace(theme_match.group(0), "").strip()

        topic = args_text.strip()
        if not topic:
            await msg.reply_text("❌ Please provide a topic.", parse_mode=H)
            return

        status = await msg.reply_text(
            f"📊 <b>Generating Presentation</b>\n"
            f"Topic: <i>{esc(topic[:100])}</i>\n"
            f"Slides: {num_slides} | Theme: {theme}\n\n"
            f"<i>🤖 AI planning content…</i>",
            parse_mode=H
        )

        try:
            # Ask AI to generate slide content
            ai_prompt = f"""Create content for a {num_slides}-slide professional presentation on: "{topic}"

Return ONLY valid JSON with this exact structure:
{{
  "title": "Presentation Title",
  "subtitle": "Subtitle or tagline",
  "slides": [
    {{
      "type": "title",
      "title": "Main Title",
      "subtitle": "Subtitle"
    }},
    {{
      "type": "content",
      "title": "Slide Title",
      "content": ["Bullet point 1", "Bullet point 2", "Bullet point 3"]
    }}
  ]
}}

Rules:
- First slide must be type "title"
- All other slides type "content" 
- Each content slide: 3-5 concise bullet points
- Total slides: {num_slides}
- Keep bullet points under 80 chars each
- Make it professional and informative
- Return ONLY the JSON, no other text"""

            await status.edit_text(
                f"📊 <b>Generating Presentation</b>\n"
                f"Topic: <i>{esc(topic[:100])}</i>\n\n"
                f"<i>🤖 AI writing slide content…</i>",
                parse_mode=H
            )

            ai_response = await ai.complete(ai_prompt, max_tokens=3000)

            # Parse JSON
            json_match = re.search(r"\{.*\}", ai_response, re.DOTALL)
            if not json_match:
                await status.edit_text(
                    f"❌ AI returned invalid response. Please try again.",
                    parse_mode=H
                )
                return

            try:
                deck = json.loads(json_match.group(0))
            except json.JSONDecodeError:
                # Try to fix common JSON issues
                raw = json_match.group(0)
                raw = re.sub(r",\s*}", "}", raw)
                raw = re.sub(r",\s*]", "]", raw)
                try:
                    deck = json.loads(raw)
                except Exception:
                    await status.edit_text(
                        "❌ Could not parse slide content. Please try again.",
                        parse_mode=H
                    )
                    return

            slides_data = deck.get("slides", [])
            pptx_title = deck.get("title", topic)

            if not slides_data:
                await status.edit_text("❌ No slides generated. Please try again.", parse_mode=H)
                return

            await status.edit_text(
                f"📊 <b>Building PPTX</b>\n"
                f"Topic: <i>{esc(pptx_title[:80])}</i>\n"
                f"Slides: {len(slides_data)} | Theme: {theme}\n\n"
                f"<i>🔨 Creating presentation file…</i>",
                parse_mode=H
            )

            # Build PPTX in thread executor
            loop = asyncio.get_event_loop()
            try:
                pptx_bytes = await loop.run_in_executor(
                    None, _build_pptx, slides_data, pptx_title, theme
                )
            except ImportError:
                await status.edit_text(
                    "❌ python-pptx not installed. Run: <code>pip install python-pptx</code>",
                    parse_mode=H
                )
                return

            # Save file
            filename = f"{topic[:40].replace(' ', '_').replace('/', '_')}_{theme}.pptx"
            filename = re.sub(r"[^a-zA-Z0-9_.-]", "", filename)
            save_path = SLIDES_DIR / filename

            buf = io.BytesIO(pptx_bytes)
            buf.name = filename

            await status.delete()
            await msg.reply_document(
                document=buf,
                filename=filename,
                caption=(
                    f"📊 <b>{esc(pptx_title)}</b>\n"
                    f"✅ {len(slides_data)} slides · {theme} theme\n"
                    f"📁 Open in PowerPoint, Google Slides, or LibreOffice Impress"
                ),
                parse_mode=H
            )

        except Exception as e:
            logger.error(f"Slides error: {e}")
            await status.edit_text(f"❌ Error generating slides: {esc(str(e)[:200])}", parse_mode=H)
