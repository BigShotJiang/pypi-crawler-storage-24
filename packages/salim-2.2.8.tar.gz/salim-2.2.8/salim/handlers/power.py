"""
Salim Power Handlers — shutdown, restart, sleep, lock, logout, hibernate.
"""
from __future__ import annotations

import html
import platform
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from salim.auth import require_auth
from salim.utils import run_shell_async

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

OS = platform.system()


def _power_cmd(action: str) -> str:
    if OS == "Darwin":
        cmds = {
            "shutdown": "osascript -e 'tell app \"System Events\" to shut down'",
            "restart": "osascript -e 'tell app \"System Events\" to restart'",
            "sleep": "pmset sleepnow",
            "lock": "osascript -e 'tell application \"System Events\" to keystroke \"q\" using {control down, command down}'",
            "logout": "osascript -e 'tell app \"System Events\" to log out'",
            "hibernate": "pmset hibernatemode 25 && pmset sleepnow",
            "screensaver": "open -a ScreenSaverEngine",
        }
    elif OS == "Windows":
        cmds = {
            "shutdown": "shutdown /s /t 60",
            "restart": "shutdown /r /t 60",
            "sleep": "rundll32.exe powrprof.dll,SetSuspendState 0,1,0",
            "lock": "rundll32.exe user32.dll,LockWorkStation",
            "logout": "shutdown /l",
            "hibernate": "shutdown /h",
            "screensaver": "",
        }
    else:
        cmds = {
            "shutdown": "systemctl poweroff",
            "restart": "systemctl reboot",
            "sleep": "systemctl suspend",
            "lock": "loginctl lock-session || xdg-screensaver lock || gnome-screensaver-command -l",
            "logout": "pkill -SIGTERM -u $USER",
            "hibernate": "systemctl hibernate",
            "screensaver": "xdg-screensaver activate",
        }
    return cmds.get(action, "")


class PowerHandlers:

    @require_auth
    async def cmd_shutdown(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("⚡ Confirm Shutdown", callback_data="power:shutdown"),
            InlineKeyboardButton("❌ Cancel", callback_data="power:cancel"),
        ]])
        await update.effective_message.reply_text(
            "⚠️ <b>Shutdown this machine?</b>", parse_mode=H, reply_markup=markup
        )

    @require_auth
    async def cmd_restart(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("🔄 Confirm Restart", callback_data="power:restart"),
            InlineKeyboardButton("❌ Cancel", callback_data="power:cancel"),
        ]])
        await update.effective_message.reply_text(
            "⚠️ <b>Restart this machine?</b>", parse_mode=H, reply_markup=markup
        )

    @require_auth
    async def cmd_sleep(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        cmd = _power_cmd("sleep")
        out, rc = await run_shell_async(cmd)
        await update.effective_message.reply_text("💤 Sleeping...", parse_mode=H)

    @require_auth
    async def cmd_hibernate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        cmd = _power_cmd("hibernate")
        await run_shell_async(cmd)
        await update.effective_message.reply_text("🌙 Hibernating...", parse_mode=H)

    @require_auth
    async def cmd_lock(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        cmd = _power_cmd("lock")
        await run_shell_async(cmd)
        await update.effective_message.reply_text("🔒 Screen locked.", parse_mode=H)

    @require_auth
    async def cmd_logout(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        markup = InlineKeyboardMarkup([[
            InlineKeyboardButton("👋 Confirm Logout", callback_data="power:logout"),
            InlineKeyboardButton("❌ Cancel", callback_data="power:cancel"),
        ]])
        await update.effective_message.reply_text(
            "⚠️ <b>Log out current user?</b>", parse_mode=H, reply_markup=markup
        )

    @require_auth
    async def cmd_screensaver(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        cmd = _power_cmd("screensaver")
        await run_shell_async(cmd)
        await update.effective_message.reply_text("🖥️ Screensaver activated.", parse_mode=H)

    @require_auth
    async def cmd_displays(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if OS == "Darwin":
            out, _ = await run_shell_async("system_profiler SPDisplaysDataType 2>/dev/null | head -30")
        elif OS == "Linux":
            out, _ = await run_shell_async("xrandr 2>/dev/null || cat /sys/class/drm/*/status 2>/dev/null")
        else:
            out, _ = await run_shell_async("wmic path Win32_VideoController get Name,CurrentHorizontalResolution,CurrentVerticalResolution 2>&1")
        await update.effective_message.reply_text(
            f"🖥️ <b>Display Info</b>\n<pre>{esc(out[:2000])}</pre>", parse_mode=H
        )

    async def cb_power(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        action = query.data.split(":", 1)[1]
        if action == "cancel":
            await query.edit_message_text("❌ Cancelled.")
            return
        cmd = _power_cmd(action)
        if cmd:
            await query.edit_message_text(f"⚡ Executing: {esc(action)}...")
            await run_shell_async(cmd)
        else:
            await query.edit_message_text(f"❌ Unknown power action: {esc(action)}")
