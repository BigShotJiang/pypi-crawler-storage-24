"""
Salim Smart Upload — receive files from Telegram and save to laptop with folder picker.
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
from datetime import datetime
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import bytes_to_human

logger = logging.getLogger("salim.smart_upload")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

UPLOAD_LOG = Path.home() / ".salim" / "uploads.jsonl"
# Pending upload state per chat
_pending_uploads: dict[int, dict] = {}


def _log_upload(filename: str, dest: str, size: int):
    entry = {
        "ts": datetime.now().isoformat(),
        "filename": filename,
        "dest": dest,
        "size": size,
    }
    try:
        UPLOAD_LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(UPLOAD_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


def _get_quick_dirs() -> list[Path]:
    home = Path.home()
    candidates = [
        home / "Desktop",
        home / "Downloads",
        home / "Documents",
        home / "Pictures",
        home / "Music",
        home / "Videos",
    ]
    existing = [p for p in candidates if p.exists()]
    if not existing:
        # On servers/containers without standard dirs, create Downloads and return it
        fallback = home / "Downloads"
        fallback.mkdir(parents=True, exist_ok=True)
        existing = [fallback]
    return existing


class SmartUploadHandlers:

    @require_auth
    async def handle_document_smart(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle incoming file uploads with folder picker."""
        msg = update.effective_message
        doc = msg.document
        if not doc:
            return

        chat_id = msg.chat_id
        filename = doc.file_name or "file"
        size = doc.file_size or 0

        # Check size limit
        max_bytes = self.config.max_file_mb * 1024 * 1024
        if size > max_bytes:
            await msg.reply_text(
                f"❌ File too large ({bytes_to_human(size)}). Max: {self.config.max_file_mb} MB",
                parse_mode=H
            )
            return

        # Store pending upload info
        _pending_uploads[chat_id] = {
            "file_id": doc.file_id,
            "filename": filename,
            "size": size,
        }

        # Build folder picker
        dirs = _get_quick_dirs()
        buttons = []
        for d in dirs[:6]:
            buttons.append([InlineKeyboardButton(
                f"📁 {d.name}",
                callback_data=f"upload_dest:{d}"
            )])
        buttons.append([
            InlineKeyboardButton("📂 Custom path…", callback_data=f"upload_custom:{chat_id}"),
            InlineKeyboardButton("❌ Cancel", callback_data=f"upload_cancel:{chat_id}"),
        ])

        await msg.reply_text(
            f"📤 <b>Upload: {esc(filename)}</b> ({bytes_to_human(size)})\n\nWhere to save?",
            parse_mode=H,
            reply_markup=InlineKeyboardMarkup(buttons)
        )

    async def handle_upload_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        data = query.data
        chat_id = query.message.chat_id

        if data.startswith("upload_cancel:"):
            _pending_uploads.pop(chat_id, None)
            await query.edit_message_text("❌ Upload cancelled.")
            return

        if data.startswith("upload_custom:"):
            await query.edit_message_text(
                "📂 Reply with the destination path:\n"
                "e.g. <code>/home/user/projects/myfile</code>",
                parse_mode=H
            )
            return

        if data.startswith("upload_dest:"):
            dest_dir = Path(data.split(":", 1)[1])
            info = _pending_uploads.pop(chat_id, None)
            if not info:
                await query.edit_message_text("❌ Upload timed out. Please re-send the file.")
                return

            await query.edit_message_text(f"⬇️ <i>Downloading {esc(info['filename'])}…</i>", parse_mode=H)
            try:
                file_obj = await ctx.bot.get_file(info["file_id"])
                dest_path = dest_dir / info["filename"]
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                buf = io.BytesIO()
                await file_obj.download_to_memory(buf)
                dest_path.write_bytes(buf.getvalue())
                _log_upload(info["filename"], str(dest_path), info["size"])
                await query.edit_message_text(
                    f"✅ <b>Saved:</b> <code>{esc(str(dest_path))}</code>\n"
                    f"Size: {bytes_to_human(info['size'])}",
                    parse_mode=H
                )
            except Exception as e:
                await query.edit_message_text(f"❌ Upload error: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_uploads_history(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show upload history."""
        if not UPLOAD_LOG.exists():
            await update.effective_message.reply_text("📤 No upload history yet.", parse_mode=H)
            return
        try:
            lines = UPLOAD_LOG.read_text().strip().splitlines()[-20:]
            entries = [json.loads(ln) for ln in lines if ln]
            text_lines = []
            for e in reversed(entries):
                ts = e.get("ts", "")[:16]
                fn = e.get("filename", "?")
                dest = e.get("dest", "?")
                size = bytes_to_human(e.get("size", 0))
                text_lines.append(f"<code>{esc(ts)}</code> {esc(fn)} → <code>{esc(dest)}</code> ({size})")
            await update.effective_message.reply_text(
                "📤 <b>Upload History</b>\n\n" + "\n".join(text_lines),
                parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)
