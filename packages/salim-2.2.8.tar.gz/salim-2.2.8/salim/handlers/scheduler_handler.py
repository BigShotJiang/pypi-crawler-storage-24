"""
Salim Scheduler — schedule commands to run at a specific time or on repeat.
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async

logger = logging.getLogger("salim.scheduler")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

JOBS_FILE = Path.home() / ".salim" / "scheduled_jobs.json"

_jobs: dict[str, dict] = {}
_job_tasks: dict[str, asyncio.Task] = {}
_app = None


def _save_jobs():
    JOBS_FILE.parent.mkdir(parents=True, exist_ok=True)
    serializable = {}
    for jid, job in _jobs.items():
        serializable[jid] = {
            k: v for k, v in job.items()
            if k not in ("task",)
        }
    JOBS_FILE.write_text(json.dumps(serializable, indent=2))


def _load_jobs() -> dict:
    if not JOBS_FILE.exists():
        return {}
    try:
        return json.loads(JOBS_FILE.read_text())
    except Exception:
        return {}


class SchedulerHandlers:

    @require_auth
    async def cmd_at(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /at HH:MM <command>   — run command once at specified time (today)
        /at +Nm <command>     — run in N minutes
        """
        msg = update.effective_message
        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "⏰ <b>Schedule a command</b>\n\n"
                "<code>/at HH:MM command</code> — run at time\n"
                "<code>/at +5m command</code> — run in 5 minutes\n"
                "<code>/at +1h command</code> — run in 1 hour\n\n"
                "Example: <code>/at 09:00 /screenshot</code>\n"
                "Example: <code>/at +30m /cpu</code>",
                parse_mode=H
            )
            return

        time_spec = ctx.args[0]
        command = " ".join(ctx.args[1:])
        chat_id = msg.chat_id

        now = datetime.now()
        run_at: Optional[datetime] = None

        if time_spec.startswith("+"):
            # Relative: +5m, +1h, +30s
            spec = time_spec[1:]
            if spec.endswith("m"):
                run_at = now + timedelta(minutes=int(spec[:-1]))
            elif spec.endswith("h"):
                run_at = now + timedelta(hours=int(spec[:-1]))
            elif spec.endswith("s"):
                run_at = now + timedelta(seconds=int(spec[:-1]))
            else:
                try:
                    run_at = now + timedelta(minutes=int(spec))
                except ValueError:
                    await msg.reply_text("❌ Invalid time spec. Use +5m, +1h, +30s.", parse_mode=H)
                    return
        else:
            # Absolute: HH:MM
            try:
                t = datetime.strptime(time_spec, "%H:%M")
                run_at = now.replace(hour=t.hour, minute=t.minute, second=0, microsecond=0)
                if run_at <= now:
                    run_at += timedelta(days=1)
            except ValueError:
                await msg.reply_text("❌ Invalid time. Use HH:MM (e.g. 14:30).", parse_mode=H)
                return

        delay = (run_at - now).total_seconds()
        job_id = f"at_{len(_jobs) + 1}"

        _jobs[job_id] = {
            "id": job_id,
            "type": "once",
            "command": command,
            "run_at": run_at.isoformat(),
            "chat_id": chat_id,
        }
        _save_jobs()

        task = asyncio.create_task(
            self._run_job_at(job_id, command, chat_id, delay)
        )
        _job_tasks[job_id] = task

        await msg.reply_text(
            f"⏰ <b>Scheduled</b> #{job_id}\n"
            f"Command: <code>{esc(command)}</code>\n"
            f"Runs at: {run_at.strftime('%H:%M:%S')} ({int(delay)}s from now)",
            parse_mode=H
        )

    @require_auth
    async def cmd_every(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /every <interval> <command>
        interval: 5m, 1h, 30s, 1d
        """
        msg = update.effective_message
        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "🔄 <b>Repeat command</b>\n\n"
                "<code>/every 5m /screenshot</code> — every 5 minutes\n"
                "<code>/every 1h /cpu</code> — every hour\n"
                "<code>/every 30s /status</code> — every 30 seconds\n"
                "<code>/every 1d /info</code> — daily\n\n"
                "Use /jobcancel <id> to stop.",
                parse_mode=H
            )
            return

        interval_spec = ctx.args[0]
        command = " ".join(ctx.args[1:])
        chat_id = msg.chat_id

        try:
            if interval_spec.endswith("m"):
                interval_secs = int(interval_spec[:-1]) * 60
            elif interval_spec.endswith("h"):
                interval_secs = int(interval_spec[:-1]) * 3600
            elif interval_spec.endswith("s"):
                interval_secs = int(interval_spec[:-1])
            elif interval_spec.endswith("d"):
                interval_secs = int(interval_spec[:-1]) * 86400
            else:
                interval_secs = int(interval_spec) * 60
        except ValueError:
            await msg.reply_text("❌ Invalid interval. Use 5m, 1h, 30s, 1d.", parse_mode=H)
            return

        if interval_secs < 10:
            await msg.reply_text("❌ Minimum interval: 10 seconds.", parse_mode=H)
            return

        job_id = f"every_{len(_jobs) + 1}"
        _jobs[job_id] = {
            "id": job_id,
            "type": "repeat",
            "command": command,
            "interval": interval_secs,
            "chat_id": chat_id,
        }
        _save_jobs()

        task = asyncio.create_task(
            self._run_job_repeat(job_id, command, chat_id, interval_secs)
        )
        _job_tasks[job_id] = task

        await msg.reply_text(
            f"🔄 <b>Repeating</b> #{job_id}\n"
            f"Command: <code>{esc(command)}</code>\n"
            f"Every: {interval_spec}",
            parse_mode=H
        )

    @require_auth
    async def cmd_jobs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List scheduled jobs."""
        if not _jobs:
            await update.effective_message.reply_text(
                "📋 No scheduled jobs. Use /at or /every.",
                parse_mode=H
            )
            return
        lines = []
        for job in _jobs.values():
            status = "🟢" if job["id"] in _job_tasks and not _job_tasks[job["id"]].done() else "🔴"
            if job["type"] == "once":
                run_at = job.get("run_at", "?")[:19]
                lines.append(f"{status} <b>#{job['id']}</b> [{job['type']}] at {run_at}\n  <code>{esc(job['command'])}</code>")
            else:
                secs = job.get("interval", 0)
                lines.append(f"{status} <b>#{job['id']}</b> [{job['type']}] every {secs}s\n  <code>{esc(job['command'])}</code>")
        await update.effective_message.reply_text(
            "📋 <b>Scheduled Jobs</b>\n\n" + "\n\n".join(lines),
            parse_mode=H
        )

    @require_auth
    async def cmd_jobcancel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Cancel a scheduled job: /jobcancel <id>"""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /jobcancel <job_id>", parse_mode=H)
            return
        job_id = ctx.args[0]
        if job_id not in _jobs:
            await update.effective_message.reply_text(f"❌ Job {esc(job_id)} not found.", parse_mode=H)
            return
        task = _job_tasks.pop(job_id, None)
        if task:
            task.cancel()
        del _jobs[job_id]
        _save_jobs()
        await update.effective_message.reply_text(f"✅ Job #{esc(job_id)} cancelled.", parse_mode=H)

    async def _run_job_at(self, job_id: str, command: str, chat_id: int, delay: float):
        """Run a one-time job after delay."""
        try:
            await asyncio.sleep(delay)
            if job_id in _jobs:
                await self._execute_job(command, chat_id, job_id)
                _jobs.pop(job_id, None)
                _save_jobs()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Job {job_id} error: {e}")

    async def _run_job_repeat(self, job_id: str, command: str, chat_id: int, interval: int):
        """Run a repeating job."""
        try:
            while job_id in _jobs:
                await asyncio.sleep(interval)
                if job_id not in _jobs:
                    break
                await self._execute_job(command, chat_id, job_id)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Job {job_id} error: {e}")

    async def _execute_job(self, command: str, chat_id: int, job_id: str):
        """Execute a scheduled command and send result."""
        try:
            from salim.utils import run_shell_async
            if command.startswith("/"):
                # Telegram command — just notify
                try:
                    await self._app.bot.send_message(
                        chat_id=chat_id,
                        text=f"⏰ <b>Job #{job_id}:</b> <code>{esc(command)}</code> (Telegram commands can't auto-run — use shell commands)",
                        parse_mode=H
                    )
                except Exception:
                    pass
            else:
                out, rc = await run_shell_async(command, timeout=60)
                try:
                    await self._app.bot.send_message(
                        chat_id=chat_id,
                        text=f"⏰ <b>Job #{job_id}:</b> <code>{esc(command)}</code>\n<pre>{esc(out[:2000])}</pre>",
                        parse_mode=H
                    )
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"Execute job error: {e}")
