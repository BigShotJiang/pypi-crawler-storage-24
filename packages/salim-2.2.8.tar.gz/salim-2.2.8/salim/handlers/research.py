"""
Salim Deep Research — like Manus AI's "Wide Research" feature.

Manus uses parallel sub-agents to research a topic from multiple angles,
synthesize findings, and produce a comprehensive report. This does the same
using web search + AI synthesis.

Commands:
  /research <topic>           — run deep research and generate report
  /researchstop               — stop running research
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, truncate

logger = logging.getLogger("salim.research")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

RESEARCH_DIR = Path.home() / ".salim" / "research"
RESEARCH_DIR.mkdir(parents=True, exist_ok=True)

_research_tasks: dict[int, asyncio.Task] = {}


async def _search_web(query: str, num_results: int = 5) -> list[dict]:
    """Perform web search via curl/DuckDuckGo or Google."""
    try:
        # Use DuckDuckGo lite
        import urllib.parse
        encoded = urllib.parse.quote(query)
        out, rc = await run_shell_async(
            f"curl -sL 'https://html.duckduckgo.com/html/?q={encoded}' "
            f"-A 'Mozilla/5.0' --max-time 10 2>/dev/null | head -c 50000",
            timeout=15
        )
        if not out or rc != 0:
            return []

        # Parse results
        results = []
        # Find result snippets
        snippets = re.findall(
            r'class="result__snippet"[^>]*>(.*?)</a>',
            out, re.DOTALL
        )
        urls = re.findall(r'class="result__url"[^>]*>(.*?)</a>', out, re.DOTALL)
        titles = re.findall(r'class="result__title"[^>]*>.*?<a[^>]*>(.*?)</a>', out, re.DOTALL)

        for i in range(min(num_results, len(snippets))):
            snippet = re.sub(r"<[^>]+>", " ", snippets[i]).strip()[:500]
            url = re.sub(r"<[^>]+>", "", urls[i]).strip() if i < len(urls) else ""
            title = re.sub(r"<[^>]+>", "", titles[i]).strip() if i < len(titles) else ""
            if snippet or url:
                results.append({"title": title, "url": url, "snippet": snippet})

        return results
    except Exception as e:
        logger.error(f"Search error: {e}")
        return []


async def _fetch_page_text(url: str) -> str:
    """Fetch a page and extract clean text."""
    try:
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        out, rc = await run_shell_async(
            f"curl -sL --max-time 8 --max-filesize 1000000 "
            f"-A 'Mozilla/5.0' '{url}' 2>/dev/null | head -c 30000",
            timeout=12
        )
        if not out:
            return ""
        # Basic HTML → text
        text = re.sub(r"<script[^>]*>.*?</script>", "", out, flags=re.DOTALL)
        text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:3000]
    except Exception:
        return ""


class DeepResearchHandlers:

    _active_research: dict = {}   # chat_id → asyncio.Task

    @require_auth
    async def cmd_research(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /research <topic>
        
        Runs deep research: searches multiple queries, reads sources,
        and produces a comprehensive AI-synthesized report.
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "🔬 <b>Deep Research</b>\n\n"
                "Like Manus AI's Wide Research — searches multiple sources,\n"
                "reads them, and synthesizes a comprehensive report.\n\n"
                "<b>Usage:</b> <code>/research &lt;topic&gt;</code>\n\n"
                "<b>Examples:</b>\n"
                "• <code>/research quantum computing 2025</code>\n"
                "• <code>/research best Python web frameworks comparison</code>\n"
                "• <code>/research electric vehicle market trends</code>\n\n"
                "Takes 1-3 minutes for thorough results.",
                parse_mode=H
            )
            return

        # Stop existing research
        if chat_id in _research_tasks and not _research_tasks[chat_id].done():
            _research_tasks[chat_id].cancel()

        topic = " ".join(ctx.args)
        status = await msg.reply_text(
            f"🔬 <b>Deep Research Starting</b>\n"
            f"Topic: <i>{esc(topic[:150])}</i>\n\n"
            f"<i>🔍 Generating search queries…</i>",
            parse_mode=H
        )

        task = asyncio.create_task(
            self._research_loop(chat_id, topic, status, msg.chat_id)
        )
        _research_tasks[chat_id] = task

    @require_auth
    async def cmd_researchstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop running research."""
        chat_id = update.effective_message.chat_id
        task = _research_tasks.get(chat_id)
        if task and not task.done():
            task.cancel()
            await update.effective_message.reply_text("🛑 Research stopped.", parse_mode=H)
        else:
            await update.effective_message.reply_text("ℹ️ No research running.", parse_mode=H)

    async def _research_loop(self, chat_id: int, topic: str, status_msg, reply_chat_id: int):
        """Main research loop."""
        from salim.ai import SalimAI
        ai = SalimAI(self.config)

        try:
            # Step 1: Generate search queries
            await status_msg.edit_text(
                f"🔬 <b>Deep Research</b>\n"
                f"Topic: <i>{esc(topic[:100])}</i>\n\n"
                f"<i>Step 1/4: Generating search queries…</i>",
                parse_mode=H
            )

            queries_response = await ai.complete(
                f"Generate 5 specific web search queries to thoroughly research: {topic}\n\n"
                f"Return ONLY the queries, one per line, no numbers or bullets.",
                max_tokens=200
            )
            queries = [q.strip() for q in queries_response.strip().splitlines() if q.strip()][:5]
            if not queries:
                queries = [topic, f"{topic} overview", f"{topic} examples"]

            # Step 2: Search and fetch sources
            await status_msg.edit_text(
                f"🔬 <b>Deep Research</b>\n"
                f"Topic: <i>{esc(topic[:100])}</i>\n\n"
                f"<i>Step 2/4: Searching {len(queries)} queries in parallel…</i>",
                parse_mode=H
            )

            # Parallel searches
            search_tasks = [_search_web(q, num_results=3) for q in queries]
            all_search_results = await asyncio.gather(*search_tasks, return_exceptions=True)

            # Collect unique URLs
            seen_urls = set()
            sources = []
            for results in all_search_results:
                if isinstance(results, list):
                    for r in results:
                        url = r.get("url", "")
                        if url and url not in seen_urls and len(seen_urls) < 8:
                            seen_urls.add(url)
                            sources.append(r)

            # Step 3: Fetch content from top sources
            await status_msg.edit_text(
                f"🔬 <b>Deep Research</b>\n"
                f"Topic: <i>{esc(topic[:100])}</i>\n\n"
                f"<i>Step 3/4: Reading {len(sources)} sources…</i>",
                parse_mode=H
            )

            fetch_tasks = [_fetch_page_text(s.get("url", "")) for s in sources[:6]]
            page_contents = await asyncio.gather(*fetch_tasks, return_exceptions=True)

            # Build context
            context_parts = []
            for i, (source, content) in enumerate(zip(sources[:6], page_contents)):
                if isinstance(content, str) and content:
                    ctx_text = content[:1500]
                elif source.get("snippet"):
                    ctx_text = source["snippet"]
                else:
                    continue
                url = source.get("url", "unknown")
                title = source.get("title", url)
                context_parts.append(f"Source {i+1}: {title}\nURL: {url}\n{ctx_text}")

            combined_context = "\n\n---\n\n".join(context_parts)

            # Step 4: AI synthesis
            await status_msg.edit_text(
                f"🔬 <b>Deep Research</b>\n"
                f"Topic: <i>{esc(topic[:100])}</i>\n\n"
                f"<i>Step 4/4: AI synthesizing report from {len(context_parts)} sources…</i>",
                parse_mode=H
            )

            report = await ai.complete(
                f"You are a research analyst. Write a comprehensive research report on: {topic}\n\n"
                f"Use the following sources as your primary information:\n\n{combined_context[:6000]}\n\n"
                f"Write a well-structured report with:\n"
                f"1. Executive Summary (2-3 sentences)\n"
                f"2. Key Findings (3-5 bullet points)\n"
                f"3. Detailed Analysis (3-4 paragraphs)\n"
                f"4. Current Trends\n"
                f"5. Conclusion\n"
                f"6. Sources (list the URLs used)\n\n"
                f"Be factual, comprehensive, and well-organized.",
                max_tokens=2000
            )

            if not report:
                report = "Could not generate report. AI may not be configured."

            # Save to file
            report_filename = f"research_{topic[:30].replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
            report_path = RESEARCH_DIR / report_filename
            full_report = f"# Research Report: {topic}\n\n*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n*Sources searched: {len(seen_urls)}*\n\n{report}"
            report_path.write_text(full_report, encoding="utf-8")

            # Send result
            await status_msg.delete()

            if len(report) <= 3000:
                await self._app.bot.send_message(
                    chat_id=reply_chat_id,
                    text=(
                        f"🔬 <b>Research Report: {esc(topic[:80])}</b>\n"
                        f"<i>{len(sources)} sources · {len(context_parts)} pages read</i>\n\n"
                        f"{esc(report[:3200])}"
                    ),
                    parse_mode=H
                )
            else:
                await self._app.bot.send_message(
                    chat_id=reply_chat_id,
                    text=(
                        f"🔬 <b>Research Report: {esc(topic[:80])}</b>\n"
                        f"<i>{len(sources)} sources · {len(context_parts)} pages read</i>\n\n"
                        f"<i>Preview:</i>\n{esc(report[:1500])}…"
                    ),
                    parse_mode=H
                )
                # Send full report as file
                buf = io.BytesIO(full_report.encode("utf-8"))
                buf.name = report_filename
                await self._app.bot.send_document(
                    chat_id=reply_chat_id,
                    document=buf,
                    filename=report_filename,
                    caption=f"📄 Full research report: {topic[:60]}"
                )

        except asyncio.CancelledError:
            logger.info(f"Research cancelled for chat {chat_id}")
        except Exception as e:
            logger.error(f"Research error: {e}")
            try:
                await self._app.bot.send_message(
                    chat_id=reply_chat_id,
                    text=f"❌ Research error: {esc(str(e)[:200])}",
                    parse_mode=H
                )
            except Exception:
                pass
