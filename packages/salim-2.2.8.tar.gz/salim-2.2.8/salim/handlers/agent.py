"""
Salim Agent — Autonomous multi-step task executor, like Manus AI's core loop.

Implements a CodeAct-style agent loop:
  1. Parse high-level goal
  2. Break into todo list (like Manus's todo.md approach)
  3. Execute each step (shell, browser, file ops, AI calls)
  4. Self-correct on failures
  5. Deliver structured results

Commands:
  /agent <goal>         — start autonomous task
  /agentstop            — stop running agent
  /agentstatus          — check what agent is doing
  /agentlog             — show last agent execution log
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, truncate

logger = logging.getLogger("salim.agent")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

AGENT_LOG_DIR = Path.home() / ".salim" / "agent_logs"
AGENT_LOG_DIR.mkdir(parents=True, exist_ok=True)

# Per-chat agent state
_agent_tasks: dict[int, asyncio.Task] = {}
_agent_status: dict[int, str] = {}
_agent_logs: dict[int, list[str]] = {}


AGENT_SYSTEM_PROMPT = """You are Salim Agent — an autonomous AI agent running on the user's computer.
You receive a goal and must break it into concrete steps, then execute them.

You can use these tools by responding with special tags:
<shell>command here</shell>  — run a shell command
<file_read>path</file_read>  — read a file
<file_write path="/some/path">content here</file_write>  — write a file
<browse>url</browse>  — fetch a URL
<python>python code here</python>  — run Python code (returns stdout)
<done>final answer or result summary</done>  — signal task completion

Rules:
- Think step-by-step. Write a brief plan first, then execute.
- After each tool result, analyze it and decide the next action.
- Self-correct if a step fails (try alternative approaches).
- Be concise. Final answer goes in <done> tags.
- Max 20 iterations to prevent runaway loops.

Current working directory: {cwd}
Date/time: {datetime}
"""


class AgentHandlers:

    @require_auth
    async def cmd_agent(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Start an autonomous agent task."""
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "🤖 <b>Salim Agent</b> — Autonomous task executor\n\n"
                "<b>Usage:</b> <code>/agent &lt;your goal&gt;</code>\n\n"
                "<b>Examples:</b>\n"
                "• <code>/agent find all Python files modified today and count lines</code>\n"
                "• <code>/agent check disk usage and find the 5 largest directories</code>\n"
                "• <code>/agent research quantum computing and write a summary</code>\n"
                "• <code>/agent monitor CPU for 30 seconds and report average</code>\n\n"
                "The agent will autonomously plan and execute steps to complete your goal.",
                parse_mode=H
            )
            return

        # Stop existing agent
        if chat_id in _agent_tasks and not _agent_tasks[chat_id].done():
            _agent_tasks[chat_id].cancel()

        goal = " ".join(ctx.args)
        status_msg = await msg.reply_text(
            f"🤖 <b>Agent starting…</b>\n📋 Goal: <i>{esc(goal[:200])}</i>\n\n"
            f"<i>Planning and executing steps…</i>",
            parse_mode=H
        )

        task = asyncio.create_task(
            self._agent_loop(chat_id, goal, status_msg.message_id, msg.chat_id)
        )
        _agent_tasks[chat_id] = task
        _agent_status[chat_id] = f"Running: {goal[:100]}"
        _agent_logs[chat_id] = []

    @require_auth
    async def cmd_agentstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop a running agent."""
        chat_id = update.effective_message.chat_id
        task = _agent_tasks.get(chat_id)
        if task and not task.done():
            task.cancel()
            _agent_status[chat_id] = "Stopped"
            await update.effective_message.reply_text("🛑 Agent stopped.", parse_mode=H)
        else:
            await update.effective_message.reply_text("ℹ️ No agent running.", parse_mode=H)

    @require_auth
    async def cmd_agentstatus(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Check agent status."""
        chat_id = update.effective_message.chat_id
        task = _agent_tasks.get(chat_id)
        status = _agent_status.get(chat_id, "Idle")
        running = task and not task.done()
        icon = "🟢" if running else "🔴"
        await update.effective_message.reply_text(
            f"{icon} <b>Agent Status:</b> {esc(status)}",
            parse_mode=H
        )

    @require_auth
    async def cmd_agentlog(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show last agent run log."""
        chat_id = update.effective_message.chat_id
        logs = _agent_logs.get(chat_id, [])
        if not logs:
            await update.effective_message.reply_text("📋 No agent log available.", parse_mode=H)
            return
        log_text = "\n".join(logs[-30:])
        await update.effective_message.reply_text(
            f"📋 <b>Agent Log</b>\n\n<pre>{esc(truncate(log_text, 3000))}</pre>",
            parse_mode=H
        )

    async def _agent_loop(self, chat_id: int, goal: str, status_msg_id: int, reply_chat_id: int):
        """The main autonomous agent loop."""
        from salim.ai import SalimAI

        ai = SalimAI(self.config)
        logs = _agent_logs.setdefault(chat_id, [])
        logs.clear()

        def log(msg_text: str):
            ts = datetime.now().strftime("%H:%M:%S")
            logs.append(f"[{ts}] {msg_text}")
            logger.info(f"Agent [{chat_id}]: {msg_text}")

        log(f"Goal: {goal}")

        conversation = [{"role": "user", "content": f"Goal: {goal}\n\nStart by making a plan, then execute it step by step."}]
        system = AGENT_SYSTEM_PROMPT.format(
            cwd=self._cwd,
            datetime=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )

        max_iterations = 20
        last_result = ""
        final_answer = ""

        for iteration in range(max_iterations):
            try:
                _agent_status[chat_id] = f"Iteration {iteration + 1}/{max_iterations}"

                # Get AI response
                response = await ai.chat(conversation, system=system, max_tokens=2000)
                if not response:
                    log("Empty AI response, stopping.")
                    break

                log(f"AI response ({len(response)} chars)")
                conversation.append({"role": "assistant", "content": response})

                # Check for completion
                done_match = re.search(r"<done>(.*?)</done>", response, re.DOTALL)
                if done_match:
                    final_answer = done_match.group(1).strip()
                    log(f"Task complete: {final_answer[:100]}")
                    break

                # Execute tool calls
                tool_results = []

                # Shell commands
                for shell_match in re.finditer(r"<shell>(.*?)</shell>", response, re.DOTALL):
                    cmd = shell_match.group(1).strip()
                    log(f"Shell: {cmd[:80]}")
                    out, rc = await run_shell_async(cmd, timeout=30, cwd=self._cwd)
                    result = f"$ {cmd}\n{out[:1000]}"
                    tool_results.append(f"Shell result (rc={rc}):\n{result}")
                    last_result = out

                # File reads
                for file_match in re.finditer(r"<file_read>(.*?)</file_read>", response, re.DOTALL):
                    path = file_match.group(1).strip()
                    try:
                        from salim.utils import safe_read
                        content, _ = safe_read(path)
                        tool_results.append(f"File {path}:\n{content[:2000]}")
                        log(f"Read file: {path}")
                    except Exception as e:
                        tool_results.append(f"File read error: {e}")

                # File writes
                for write_match in re.finditer(r'<file_write\s+path="([^"]+)">(.*?)</file_write>', response, re.DOTALL):
                    path = write_match.group(1)
                    content = write_match.group(2).strip()
                    try:
                        p = Path(path).expanduser()
                        p.parent.mkdir(parents=True, exist_ok=True)
                        p.write_text(content)
                        tool_results.append(f"Wrote {len(content)} chars to {path}")
                        log(f"Wrote file: {path}")
                    except Exception as e:
                        tool_results.append(f"File write error: {e}")

                # Python execution
                for py_match in re.finditer(r"<python>(.*?)</python>", response, re.DOTALL):
                    code = py_match.group(1).strip()
                    log(f"Python: {code[:60]}…")
                    out, rc = await run_shell_async(
                        f"python3 -c {repr(code)}",
                        timeout=30, cwd=self._cwd
                    )
                    tool_results.append(f"Python result:\n{out[:1000]}")

                # URL fetching
                for browse_match in re.finditer(r"<browse>(.*?)</browse>", response, re.DOTALL):
                    url = browse_match.group(1).strip()
                    log(f"Browse: {url}")
                    out, rc = await run_shell_async(
                        f"curl -sL --max-time 10 '{url}' | head -c 3000", timeout=15
                    )
                    tool_results.append(f"URL content ({url}):\n{out[:2000]}")

                if tool_results:
                    observation = "\n\n".join(tool_results)
                    conversation.append({"role": "user", "content": f"Tool results:\n{observation}\n\nContinue executing or complete the task."})
                else:
                    # No tools used — likely just planning text
                    conversation.append({"role": "user", "content": "Continue. Execute the next step."})

            except asyncio.CancelledError:
                log("Agent cancelled by user.")
                _agent_status[chat_id] = "Cancelled"
                return
            except Exception as e:
                log(f"Iteration error: {e}")
                break

        # Send final result
        if final_answer:
            result_text = (
                f"✅ <b>Agent Complete</b>\n\n"
                f"📋 Goal: <i>{esc(goal[:150])}</i>\n\n"
                f"📝 <b>Result:</b>\n{esc(final_answer[:3000])}\n\n"
                f"<i>Completed in {len([l for l in logs if l.startswith('[')])} steps</i>"
            )
        else:
            last_logs = "\n".join(logs[-5:])
            result_text = (
                f"⚠️ <b>Agent finished</b> (no explicit result)\n\n"
                f"📋 Goal: <i>{esc(goal[:100])}</i>\n\n"
                f"<b>Last steps:</b>\n<pre>{esc(truncate(last_logs, 1000))}</pre>"
            )

        _agent_status[chat_id] = "Completed"

        try:
            await self._app.bot.send_message(
                chat_id=reply_chat_id,
                text=truncate(result_text, 3800),
                parse_mode=H
            )
        except Exception as e:
            logger.error(f"Agent result send error: {e}")
