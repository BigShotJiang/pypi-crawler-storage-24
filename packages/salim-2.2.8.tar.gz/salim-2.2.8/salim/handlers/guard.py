"""
Salim Guard — Intrusion detection via webcam motion detection.
"""
from __future__ import annotations

import asyncio
import html
import io
import logging
import os
import platform
import tempfile
import time
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async

logger = logging.getLogger("salim.guard")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

_guard_task: asyncio.Task | None = None
_guard_enabled: bool = False
_guard_active: bool = False  # alias for _guard_enabled (used externally)


class IntrusionHandlers:

    @require_auth
    async def cmd_guard(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /guard on   — enable motion detection alerts
        /guard off  — disable
        /guard status — check status
        """
        global _guard_enabled, _guard_task
        msg = update.effective_message
        arg = ctx.args[0].lower() if ctx.args else "status"

        if arg == "on":
            _guard_enabled = True
            if _guard_task is None or _guard_task.done():
                _guard_task = asyncio.create_task(
                    self._guard_loop(msg.chat_id)
                )
            await msg.reply_text(
                "🛡️ <b>Guard activated</b>\n"
                "Motion detection is running. You'll be notified with a photo if movement is detected.\n\n"
                "Use /guard off to disable.",
                parse_mode=H
            )

        elif arg == "off":
            _guard_enabled = False
            if _guard_task and not _guard_task.done():
                _guard_task.cancel()
                _guard_task = None
            await msg.reply_text("🛡️ Guard deactivated.", parse_mode=H)

        else:
            status = "🟢 Active" if _guard_enabled else "🔴 Inactive"
            await msg.reply_text(
                f"🛡️ <b>Intrusion Guard</b>\n"
                f"Status: {status}\n\n"
                f"<code>/guard on</code> — start motion detection\n"
                f"<code>/guard off</code> — stop\n\n"
                f"Uses webcam to detect motion. Sends photo alert on detection.\n"
                f"Requires: <code>ffmpeg</code> or <code>fswebcam</code>",
                parse_mode=H
            )

    async def _guard_loop(self, chat_id: int):
        """Background motion detection loop."""
        import hashlib
        global _guard_enabled

        OS = platform.system()
        prev_hash = None
        logger.info("Guard loop started")

        while _guard_enabled:
            try:
                # Capture frame
                with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as f:
                    tmp = f.name
                try:
                    if OS == "Darwin":
                        await run_shell_async(
                            f"ffmpeg -y -f avfoundation -i '0' -frames:v 1 '{tmp}' 2>/dev/null",
                            timeout=5
                        )
                    else:
                        await run_shell_async(
                            f"ffmpeg -y -f v4l2 -i /dev/video0 -frames:v 1 '{tmp}' 2>/dev/null",
                            timeout=5
                        )

                    p = Path(tmp)
                    if p.exists() and p.stat().st_size > 100:
                        img_bytes = p.read_bytes()
                        # Simple motion: compare hash of downsampled section
                        curr_hash = hashlib.md5(img_bytes[::50]).hexdigest()

                        if prev_hash and curr_hash != prev_hash:
                            # Motion detected!
                            try:
                                buf = io.BytesIO(img_bytes)
                                buf.name = "alert.jpg"
                                await self._app.bot.send_photo(
                                    chat_id=chat_id,
                                    photo=buf,
                                    caption="🚨 <b>MOTION DETECTED</b>\nIntruder alert!",
                                    parse_mode=H
                                )
                            except Exception as e:
                                logger.error(f"Guard alert error: {e}")

                        prev_hash = curr_hash
                finally:
                    try:
                        os.unlink(tmp)
                    except Exception:
                        pass

            except Exception as e:
                logger.error(f"Guard loop error: {e}")

            await asyncio.sleep(5)  # Check every 5 seconds

        logger.info("Guard loop stopped")
