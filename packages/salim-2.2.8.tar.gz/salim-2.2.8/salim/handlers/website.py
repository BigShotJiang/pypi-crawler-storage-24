"""
Salim Website Generator — create full HTML websites from prompts or files.

Manus AI can "turn any document, resume, or dataset into a live, interactive website".
This handler does the same: generates complete self-contained HTML websites.

Commands:
  /website <description>           — generate a website from description
  /website resume                  — turn uploaded resume into a portfolio site
  /website data                    — turn uploaded CSV/JSON into data website
  /website landing <product>       — create a landing page
  /website dashboard <title>       — create a metrics dashboard
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.website")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

WEBSITE_DIR = Path.home() / ".salim" / "websites"
WEBSITE_DIR.mkdir(parents=True, exist_ok=True)


class WebsiteHandlers:

    @require_auth
    async def cmd_website(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /website <description>
        /website resume    — build portfolio from resume
        /website landing <product>
        /website dashboard <title>
        
        Generates a complete, self-contained HTML website.
        """
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "🌐 <b>Website Generator</b>\n\n"
                "Like Manus AI — creates complete, interactive websites from a prompt.\n\n"
                "<b>Usage:</b> <code>/website &lt;description&gt;</code>\n\n"
                "<b>Templates:</b>\n"
                "• <code>/website landing My SaaS Product</code>\n"
                "• <code>/website resume</code> (reply to your CV file)\n"
                "• <code>/website portfolio Photography Studio</code>\n"
                "• <code>/website dashboard Sales Q4 2025</code>\n"
                "• <code>/website blog Tech Startup Insights</code>\n\n"
                "<b>Any description works:</b>\n"
                "<code>/website A restaurant website for Bella Italia with menu and reservations</code>",
                parse_mode=H
            )
            return

        from salim.ai import SalimAI
        ai = SalimAI(self.config)

        if not ai.is_configured():
            await msg.reply_text(
                "❌ AI not configured. Set SALIM_NVIDIA_API_KEY or SALIM_OPENAI_API_KEY.",
                parse_mode=H
            )
            return

        description = " ".join(ctx.args)
        sub_type = ctx.args[0].lower() if ctx.args else "general"

        status = await msg.reply_text(
            f"🌐 <b>Generating Website</b>\n"
            f"<i>{esc(description[:100])}</i>\n\n"
            f"<i>🤖 AI designing and coding…</i>",
            parse_mode=H
        )

        try:
            system_prompt = """You are an expert web developer. Create complete, production-quality HTML websites.

Rules:
- Return ONLY valid HTML, nothing else (no markdown, no explanations)
- Self-contained: all CSS and JS must be inline (no external files needed except CDN)
- Use modern, beautiful design with excellent typography
- Mobile responsive
- Include real, helpful content (not placeholder text)
- Use a CDN for any libraries (Chart.js from cdnjs, etc.)
- Make it visually impressive and professional
- Include interactivity where appropriate"""

            if sub_type == "resume":
                prompt = f"""Create a stunning personal portfolio/resume website.
Description: {description}
Make it modern, dark theme, with sections: Hero, About, Skills, Experience, Projects, Contact.
Use animations and a professional color scheme."""
            elif sub_type == "landing":
                prompt = f"""Create a professional SaaS/product landing page.
Product: {description.replace('landing', '', 1).strip()}
Include: Hero with CTA, Features (6 cards), How it Works, Pricing (3 tiers), FAQ, Footer.
Use a modern gradient design with clear value proposition."""
            elif sub_type == "dashboard":
                prompt = f"""Create an interactive analytics dashboard.
Title: {description.replace('dashboard', '', 1).strip()}
Include: header with stats cards, multiple Chart.js charts (bar, line, pie), data table.
Use Chart.js from CDN. Dark theme. Include realistic sample data."""
            elif sub_type == "blog":
                prompt = f"""Create a beautiful blog/magazine website.
Topic: {description.replace('blog', '', 1).strip()}
Include: header, featured posts grid, categories sidebar, newsletter signup, footer.
Use a clean, readable design with excellent typography."""
            elif sub_type == "portfolio":
                prompt = f"""Create a creative portfolio website.
Description: {description}
Include: hero, gallery/projects grid with hover effects, about section, contact form.
Use creative design with animations."""
            else:
                prompt = f"""Create a complete, professional website.
Description: {description}
Make it stunning, functional, and include all necessary sections for this type of site.
Use modern web design best practices."""

            await status.edit_text(
                f"🌐 <b>Generating Website</b>\n"
                f"<i>{esc(description[:100])}</i>\n\n"
                f"<i>🤖 Writing HTML, CSS, JS…</i>",
                parse_mode=H
            )

            html_content = await ai.complete(
                prompt, system=system_prompt, max_tokens=4096
            )

            # Clean up response (remove markdown if AI added it)
            html_content = re.sub(r"^```html\s*", "", html_content.strip(), flags=re.IGNORECASE)
            html_content = re.sub(r"\s*```$", "", html_content.strip())

            if not html_content.strip().startswith("<!") and "<html" not in html_content.lower():
                # Wrap if needed
                html_content = f"<!DOCTYPE html>\n<html lang='en'>\n<head><meta charset='UTF-8'></head>\n<body>\n{html_content}\n</body>\n</html>"

            # Save
            site_name = re.sub(r"[^a-z0-9_]", "_", description[:30].lower())
            filename = f"{site_name}_{datetime.now().strftime('%H%M%S')}.html"
            save_path = WEBSITE_DIR / filename
            save_path.write_text(html_content, encoding="utf-8")

            await status.delete()
            buf = io.BytesIO(html_content.encode("utf-8"))
            buf.name = filename

            await msg.reply_document(
                document=buf,
                filename=filename,
                caption=(
                    f"🌐 <b>Website Generated!</b>\n"
                    f"📄 {len(html_content):,} chars | Self-contained HTML\n"
                    f"✅ Open in any browser — no server needed\n\n"
                    f"<i>💡 Can also be hosted on GitHub Pages, Netlify, etc.</i>"
                ),
                parse_mode=H
            )

        except Exception as e:
            logger.error(f"Website error: {e}")
            await status.edit_text(f"❌ Website generation error: {esc(str(e)[:200])}", parse_mode=H)
