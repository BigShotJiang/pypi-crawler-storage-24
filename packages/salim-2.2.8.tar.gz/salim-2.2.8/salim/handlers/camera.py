"""
Salim Camera Handlers — webcam snapshot and screen recording.
"""
from __future__ import annotations

import asyncio
import html
import io
import logging
import os
import platform
import tempfile
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async

logger = logging.getLogger("salim.camera")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

OS = platform.system()


async def _webcam_snapshot() -> bytes | None:
    """Capture a webcam snapshot and return JPEG bytes."""
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as f:
        tmp = f.name
    try:
        if OS == "Darwin":
            script = f"""
import AVFoundation, AppKit, Quartz
# Use imagesnap if available
"""
            out, rc = await run_shell_async(f"imagesnap -w 1 '{tmp}' 2>/dev/null")
            if rc != 0:
                # Fallback: ffmpeg
                out, rc = await run_shell_async(
                    f"ffmpeg -y -f avfoundation -video_size 1280x720 -framerate 30 "
                    f"-i '0' -frames:v 1 '{tmp}' 2>/dev/null"
                )
        else:
            out, rc = await run_shell_async(
                f"ffmpeg -y -f v4l2 -video_size 1280x720 -i /dev/video0 "
                f"-frames:v 1 '{tmp}' 2>/dev/null"
            )
            if rc != 0:
                out, rc = await run_shell_async(
                    f"fswebcam -r 1280x720 --no-banner '{tmp}' 2>/dev/null"
                )

        p = Path(tmp)
        if p.exists() and p.stat().st_size > 0:
            return p.read_bytes()
        return None
    except Exception as e:
        logger.error(f"Webcam error: {e}")
        return None
    finally:
        try:
            os.unlink(tmp)
        except Exception:
            pass


class CameraHandlers:

    @require_auth
    async def cmd_cam(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /cam         — take webcam snapshot
        /cam list    — list camera devices
        """
        msg = update.effective_message
        arg = ctx.args[0].lower() if ctx.args else ""

        if arg == "list":
            if OS == "Darwin":
                out, _ = await run_shell_async(
                    "system_profiler SPCameraDataType 2>/dev/null"
                )
            else:
                out, _ = await run_shell_async(
                    "ls /dev/video* 2>/dev/null && v4l2-ctl --list-devices 2>/dev/null || echo 'No cameras found'"
                )
            await msg.reply_text(
                f"📷 <b>Camera Devices</b>\n<pre>{esc(out[:2000])}</pre>",
                parse_mode=H
            )
            return

        status = await msg.reply_text("📷 <i>Capturing webcam snapshot…</i>", parse_mode=H)
        try:
            loop = asyncio.get_event_loop()
            img_bytes = await _webcam_snapshot()
            if img_bytes:
                await status.delete()
                buf = io.BytesIO(img_bytes)
                buf.name = "webcam.jpg"
                await msg.reply_photo(photo=buf, caption="📷 Webcam snapshot")
            else:
                await status.edit_text(
                    "❌ Could not capture webcam. Make sure a camera is connected.\n"
                    "Required: <code>ffmpeg</code> or <code>fswebcam</code> or <code>imagesnap</code>",
                    parse_mode=H
                )
        except Exception as e:
            await status.edit_text(f"❌ Camera error: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_record(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /record <seconds>  — record screen for N seconds (default: 5)
        Returns MP4 video.
        """
        msg = update.effective_message
        secs = int(ctx.args[0]) if ctx.args and ctx.args[0].isdigit() else 5
        secs = max(1, min(secs, 30))  # 1-30 seconds

        status = await msg.reply_text(
            f"🎥 <i>Recording screen for {secs} seconds…</i>",
            parse_mode=H
        )

        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as f:
            tmp = f.name

        try:
            if OS == "Darwin":
                out, rc = await run_shell_async(
                    f"ffmpeg -y -f avfoundation -i '1:none' -t {secs} "
                    f"-vcodec libx264 -crf 23 '{tmp}' 2>/dev/null",
                    timeout=secs + 15
                )
            else:
                # Linux: try ffmpeg with x11grab
                display = os.environ.get("DISPLAY", ":0")
                out, rc = await run_shell_async(
                    f"ffmpeg -y -f x11grab -r 15 -i {display} -t {secs} "
                    f"-vcodec libx264 -crf 28 -preset ultrafast '{tmp}' 2>/dev/null",
                    timeout=secs + 15
                )

            p = Path(tmp)
            if p.exists() and p.stat().st_size > 0:
                await status.delete()
                size_mb = p.stat().st_size / 1024 / 1024
                if size_mb > 50:
                    await msg.reply_text(
                        f"⚠️ Recording too large ({size_mb:.1f} MB). Try fewer seconds.",
                        parse_mode=H
                    )
                else:
                    await msg.reply_video(
                        video=open(tmp, "rb"),
                        filename="recording.mp4",
                        caption=f"🎥 Screen recording · {secs}s"
                    )
            else:
                await status.edit_text(
                    "❌ Recording failed. Ensure <code>ffmpeg</code> is installed.",
                    parse_mode=H
                )
        except Exception as e:
            await status.edit_text(f"❌ Recording error: {esc(str(e))}", parse_mode=H)
        finally:
            try:
                os.unlink(tmp)
            except Exception:
                pass
