"""
Salim Translate — multi-language translation via AI.
Manus supports 50+ languages. This adds that capability.

Commands:
  /translate <text>                  — auto-detect and translate to English
  /translate <text> --to <lang>      — translate to specific language
  /translate --from <lang> --to <lang> <text>
  /tldr <text or reply>              — summarize in 3 bullets (any language)
"""
from __future__ import annotations

import html
import logging
import re
from telegram import Update
from telegram.ext import ContextTypes
from salim.auth import require_auth

logger = logging.getLogger("salim.translate")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

LANGUAGE_NAMES = {
    "en": "English", "ar": "Arabic", "zh": "Chinese", "fr": "French",
    "de": "German", "es": "Spanish", "it": "Italian", "ja": "Japanese",
    "ko": "Korean", "pt": "Portuguese", "ru": "Russian", "nl": "Dutch",
    "tr": "Turkish", "pl": "Polish", "sv": "Swedish", "no": "Norwegian",
    "da": "Danish", "fi": "Finnish", "hi": "Hindi", "ur": "Urdu",
    "fa": "Persian", "id": "Indonesian", "ms": "Malay", "th": "Thai",
    "vi": "Vietnamese", "he": "Hebrew", "ro": "Romanian", "uk": "Ukrainian",
    "cs": "Czech", "sk": "Slovak", "hu": "Hungarian", "el": "Greek",
}


class TranslateHandlers:

    @require_auth
    async def cmd_translate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /translate <text>
        /translate <text> --to fr
        /translate --to arabic Hello world
        """
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "🌍 <b>Translate</b>\n\n"
                "<code>/translate Hello world</code> — detect language, translate to English\n"
                "<code>/translate Bonjour --to en</code> — translate to English\n"
                "<code>/translate Good morning --to ar</code> — to Arabic\n"
                "<code>/translate --to zh This is a test</code>\n\n"
                "Supports 50+ languages. Use 2-letter codes (en, ar, fr, de, es, zh, ja, ru…) "
                "or full language names.",
                parse_mode=H
            )
            return

        from salim.ai import SalimAI
        ai = SalimAI(self.config)

        args_text = " ".join(ctx.args)

        # Parse --to and --from flags
        target_lang = "English"
        source_lang = "auto-detect"

        to_match = re.search(r"--to\s+(\S+)", args_text, re.IGNORECASE)
        from_match = re.search(r"--from\s+(\S+)", args_text, re.IGNORECASE)

        if to_match:
            tl = to_match.group(1).lower()
            target_lang = LANGUAGE_NAMES.get(tl, tl.capitalize())
            args_text = args_text.replace(to_match.group(0), "").strip()

        if from_match:
            fl = from_match.group(1).lower()
            source_lang = LANGUAGE_NAMES.get(fl, fl.capitalize())
            args_text = args_text.replace(from_match.group(0), "").strip()

        text_to_translate = args_text.strip()
        if not text_to_translate:
            await msg.reply_text("❌ No text to translate.", parse_mode=H)
            return

        status = await msg.reply_text(
            f"🌍 <i>Translating to {esc(target_lang)}…</i>", parse_mode=H
        )
        try:
            prompt = (
                f"Translate the following text to {target_lang}.\n"
                f"Source language: {source_lang}\n\n"
                f"Text: {text_to_translate}\n\n"
                f"Return ONLY the translation, nothing else."
            )
            translation = await ai.complete(prompt, max_tokens=1000)
            await status.edit_text(
                f"🌍 <b>Translation → {esc(target_lang)}</b>\n\n{esc(translation)}",
                parse_mode=H
            )
        except Exception as e:
            await status.edit_text(f"❌ Translation error: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_tldr(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /tldr <text>   — summarize in 3 bullet points
        Or reply to any message with /tldr
        """
        msg = update.effective_message

        # Get text to summarize
        if ctx.args:
            text = " ".join(ctx.args)
        elif msg.reply_to_message and msg.reply_to_message.text:
            text = msg.reply_to_message.text
        else:
            await msg.reply_text(
                "📝 Usage: <code>/tldr &lt;long text&gt;</code>\nOr reply to any message with /tldr",
                parse_mode=H
            )
            return

        from salim.ai import SalimAI
        ai = SalimAI(self.config)

        status = await msg.reply_text("📝 <i>Summarizing…</i>", parse_mode=H)
        try:
            summary = await ai.complete(
                f"Summarize this in exactly 3 concise bullet points. Be direct and clear.\n\n{text}",
                max_tokens=300
            )
            await status.edit_text(
                f"📝 <b>TL;DR</b>\n\n{esc(summary)}",
                parse_mode=H
            )
        except Exception as e:
            await status.edit_text(f"❌ Error: {esc(str(e))}", parse_mode=H)
