"""
Salim Vision AI — photo understanding via AI vision models.
"""
from __future__ import annotations

import asyncio
import base64
import html
import io
import logging
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.vision")
H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

# Per-chat: last photo bytes
_last_photos: dict[int, bytes] = {}
_vision_auto: dict[int, bool] = {}  # Auto-describe photos


async def _describe_image(config, image_bytes: bytes, question: str = "") -> str:
    """Send image to AI vision API and return description."""
    try:
        from openai import AsyncOpenAI

        # Try vision-capable providers in order
        for key_env, model_env, base_url, default_model in [
            ("SALIM_OPENAI_API_KEY", "SALIM_OPENAI_MODEL",
             "https://api.openai.com/v1", "gpt-4o-mini"),
            ("SALIM_NVIDIA_API_KEY", "SALIM_NVIDIA_MODEL",
             "https://integrate.api.nvidia.com/v1", "meta/llama-3.2-90b-vision-instruct"),
            ("SALIM_GROQ_API_KEY", "SALIM_GROQ_MODEL",
             "https://api.groq.com/openai/v1", "llama-3.2-11b-vision-preview"),
        ]:
            api_key = config.get(key_env, "")
            if not api_key:
                continue

            model = config.get(model_env, "") or default_model
            # Only use vision-capable models
            if any(x in model.lower() for x in ["vision", "4o", "4-o", "llama-3.2"]):
                pass
            elif "gpt-4" not in model.lower():
                continue

            client = AsyncOpenAI(api_key=api_key, base_url=base_url)
            b64 = base64.b64encode(image_bytes).decode()

            prompt = question if question else (
                "Describe this image in detail. "
                "Include: what you see, any text, people, objects, colors, and context."
            )

            resp = await client.chat.completions.create(
                model=model,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
                        {"type": "text", "text": prompt}
                    ]
                }],
                max_tokens=1000,
            )
            return resp.choices[0].message.content or "No description."

        return "⚠️ No vision-capable AI configured. Add SALIM_OPENAI_API_KEY with a GPT-4o model."
    except Exception as e:
        return f"❌ Vision error: {e}"


class VisionHandlers:

    @require_auth
    async def cmd_vision(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /vision        — instructions & status
        /vision on     — auto-describe all incoming photos
        /vision off    — disable auto-describe
        """
        msg = update.effective_message
        chat_id = msg.chat_id
        arg = ctx.args[0].lower() if ctx.args else ""

        if arg == "on":
            _vision_auto[chat_id] = True
            await msg.reply_text("👁️ Vision auto-describe enabled. All photos will be described.", parse_mode=H)
        elif arg == "off":
            _vision_auto[chat_id] = False
            await msg.reply_text("👁️ Vision auto-describe disabled.", parse_mode=H)
        else:
            auto = "ON" if _vision_auto.get(chat_id, False) else "OFF"
            has_photo = "Yes" if chat_id in _last_photos else "No"
            await msg.reply_text(
                f"👁️ <b>Vision AI</b>\n\n"
                f"Auto-describe: {auto}\n"
                f"Has recent photo: {has_photo}\n\n"
                f"<b>Usage:</b>\n"
                f"• Send any photo — I'll ask if you want analysis\n"
                f"• Reply to a photo with a question\n"
                f"• <code>/askvision what is in this image?</code>\n"
                f"• <code>/vision on</code> — auto-describe all photos\n\n"
                f"Requires a vision-capable AI (GPT-4o, Llama-3.2-Vision)",
                parse_mode=H
            )

    @require_auth
    async def cmd_askvision(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Ask a question about the last received photo."""
        msg = update.effective_message
        chat_id = msg.chat_id

        if chat_id not in _last_photos:
            await msg.reply_text(
                "👁️ No recent photo. Send a photo first, then use /askvision <question>",
                parse_mode=H
            )
            return

        question = " ".join(ctx.args) if ctx.args else ""
        status = await msg.reply_text("👁️ <i>Analyzing image…</i>", parse_mode=H)
        try:
            result = await _describe_image(self.config, _last_photos[chat_id], question)
            await status.edit_text(
                f"👁️ <b>Vision Analysis</b>\n\n{esc(result)}",
                parse_mode=H
            )
        except Exception as e:
            await status.edit_text(f"❌ Vision error: {esc(str(e))}", parse_mode=H)

    async def handle_photo_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle incoming photos."""
        msg = update.effective_message
        if not self.auth.is_allowed(update.effective_user.id):
            return

        chat_id = msg.chat_id
        # Get largest photo
        photo = msg.photo[-1]
        file_obj = await photo.get_file()
        buf = io.BytesIO()
        await file_obj.download_to_memory(buf)
        img_bytes = buf.getvalue()
        _last_photos[chat_id] = img_bytes

        if _vision_auto.get(chat_id, False):
            status = await msg.reply_text("👁️ <i>Analyzing image…</i>", parse_mode=H)
            result = await _describe_image(self.config, img_bytes)
            await status.edit_text(f"👁️ {esc(result)}", parse_mode=H)
        else:
            markup = InlineKeyboardMarkup([[
                InlineKeyboardButton("👁️ Describe", callback_data="vision_describe"),
                InlineKeyboardButton("📝 OCR Text", callback_data="vision_ocr"),
                InlineKeyboardButton("❓ Ask", callback_data="vision_ask"),
            ]])
            await msg.reply_text(
                "📸 Photo received. What do you want to do?",
                reply_markup=markup
            )

    async def handle_photo_reply(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle text reply to a photo."""
        msg = update.effective_message
        if not self.auth.is_allowed(update.effective_user.id):
            return

        chat_id = msg.chat_id
        question = msg.text or ""

        # Get photo from replied message
        if msg.reply_to_message and msg.reply_to_message.photo:
            photo = msg.reply_to_message.photo[-1]
            file_obj = await photo.get_file()
            buf = io.BytesIO()
            await file_obj.download_to_memory(buf)
            img_bytes = buf.getvalue()
            _last_photos[chat_id] = img_bytes
        elif chat_id in _last_photos:
            img_bytes = _last_photos[chat_id]
        else:
            return

        status = await msg.reply_text("👁️ <i>Analyzing…</i>", parse_mode=H)
        result = await _describe_image(self.config, img_bytes, question)
        await status.edit_text(f"👁️ {esc(result)}", parse_mode=H)

    async def handle_vision_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        chat_id = query.message.chat_id
        data = query.data

        if chat_id not in _last_photos:
            await query.answer("No photo cached.")
            return

        if data == "vision_describe":
            await query.edit_message_text("👁️ <i>Describing image…</i>", parse_mode=H)
            result = await _describe_image(self.config, _last_photos[chat_id])
            await query.edit_message_text(f"👁️ <b>Description</b>\n\n{esc(result)}", parse_mode=H)

        elif data == "vision_ocr":
            await query.edit_message_text("👁️ <i>Extracting text (OCR)…</i>", parse_mode=H)
            result = await _describe_image(
                self.config, _last_photos[chat_id],
                "Extract ALL text visible in this image. Return only the text, preserving layout."
            )
            await query.edit_message_text(
                f"📝 <b>OCR Result</b>\n\n<code>{esc(result)}</code>",
                parse_mode=H
            )

        elif data == "vision_ask":
            await query.edit_message_text(
                "🤔 Reply to this message with your question about the image.",
                parse_mode=H
            )
