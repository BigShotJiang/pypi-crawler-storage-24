"""
Salim Data Analyst — AI-powered data analysis + visualization like Manus AI.

Manus can take raw data, analyze it, create charts/dashboards, and deploy
live URLs. This handler does the same: accepts CSV/Excel/JSON files or
raw data, runs pandas analysis, generates matplotlib/seaborn charts,
and sends everything back as Telegram files.

Commands:
  /analyze                   — analyze a file you upload (reply or recent)
  /analyze describe          — statistical summary of uploaded data
  /analyze chart <type>      — generate chart: bar/line/pie/scatter/hist/heatmap/box
  /analyze query <question>  — natural language query on data (AI-powered)
  /analyze clean             — clean data: remove duplicates, fix nulls, normalize
  /analyze correlate         — correlation matrix + heatmap
  /analyze report            — full automated analysis report (PDF/HTML)
  /plotcsv <url>             — fetch CSV from URL and auto-plot it
  /dashboard                 — create an interactive HTML dashboard from data

All processing is real — uses pandas, matplotlib, seaborn, scipy.
No mocks, no fake data.
"""
from __future__ import annotations

import asyncio
import base64
import csv
import html
import io
import json
import logging
import os
import re
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.analyst")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

ANALYST_DIR = Path.home() / ".salim" / "analyst"
ANALYST_DIR.mkdir(parents=True, exist_ok=True)

# Per-chat data storage
_loaded_data: dict[int, dict] = {}  # chat_id → {df, filename, loaded_at}


def _ensure_matplotlib():
    try:
        import matplotlib
        matplotlib.use("Agg")  # Non-interactive backend
        import matplotlib.pyplot as plt
        return True
    except ImportError:
        return False


def _ensure_pandas():
    try:
        import pandas as pd
        return True
    except ImportError:
        return False


def _load_dataframe(file_bytes: bytes, filename: str):
    """Load bytes into a pandas DataFrame. Supports CSV, Excel, JSON, TSV."""
    import pandas as pd

    fname_lower = filename.lower()

    if fname_lower.endswith(".csv") or fname_lower.endswith(".tsv"):
        sep = "\t" if fname_lower.endswith(".tsv") else ","
        # Try to detect encoding
        for enc in ("utf-8-sig", "utf-8", "latin-1", "cp1252"):
            try:
                df = pd.read_csv(io.BytesIO(file_bytes), sep=sep, encoding=enc,
                                 on_bad_lines="skip")
                return df, None
            except Exception:
                continue
        return None, "Could not parse CSV file"

    elif fname_lower.endswith((".xlsx", ".xls")):
        try:
            df = pd.read_excel(io.BytesIO(file_bytes))
            return df, None
        except Exception as e:
            return None, str(e)

    elif fname_lower.endswith(".json"):
        try:
            text = file_bytes.decode("utf-8", errors="replace")
            data = json.loads(text)
            if isinstance(data, list):
                df = pd.DataFrame(data)
            elif isinstance(data, dict):
                # Try to find the main array
                for v in data.values():
                    if isinstance(v, list) and v:
                        df = pd.DataFrame(v)
                        break
                else:
                    df = pd.DataFrame([data])
            return df, None
        except Exception as e:
            return None, str(e)

    elif fname_lower.endswith(".txt"):
        # Try tab-separated, then comma-separated
        for sep in ("\t", ",", ";", "|"):
            try:
                df = pd.read_csv(io.BytesIO(file_bytes), sep=sep, encoding="utf-8-sig",
                                 on_bad_lines="skip")
                if len(df.columns) > 1:
                    return df, None
            except Exception:
                pass
        # Fallback: line-by-line
        lines = file_bytes.decode("utf-8", errors="replace").splitlines()
        import pandas as pd
        df = pd.DataFrame({"line": [ln.strip() for ln in lines if ln.strip()]})
        return df, None

    return None, f"Unsupported file format: {filename}"


def _generate_describe(df) -> str:
    """Generate statistical description text."""
    import pandas as pd
    import numpy as np

    lines = []
    lines.append(f"📊 Shape: {df.shape[0]:,} rows × {df.shape[1]} columns")
    lines.append(f"💾 Memory: {df.memory_usage(deep=True).sum() / 1024:.1f} KB")
    lines.append("")

    # Column info
    lines.append("<b>Columns:</b>")
    for col in df.columns:
        dtype = str(df[col].dtype)
        null_count = df[col].isnull().sum()
        unique = df[col].nunique()
        null_pct = f" ({100*null_count/len(df):.0f}% null)" if null_count > 0 else ""
        lines.append(f"  • <code>{esc(str(col)[:30])}</code>: {esc(dtype)} | {unique:,} unique{null_pct}")

    lines.append("")

    # Numeric stats
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 0:
        lines.append("<b>Numeric stats:</b>")
        desc = df[numeric_cols].describe()
        for col in numeric_cols[:8]:  # Max 8 cols
            col_stats = desc[col]
            lines.append(
                f"  <b>{esc(str(col)[:25])}</b>: "
                f"min={col_stats['min']:.2g} | "
                f"mean={col_stats['mean']:.2g} | "
                f"max={col_stats['max']:.2g} | "
                f"std={col_stats['std']:.2g}"
            )

    # Check for duplicates
    dupe_count = df.duplicated().sum()
    if dupe_count > 0:
        lines.append(f"\n⚠️ {dupe_count:,} duplicate rows detected")

    return "\n".join(lines)


def _make_chart(df, chart_type: str, title: str = "") -> bytes:
    """
    Generate a chart and return PNG bytes.
    chart_type: bar, line, pie, scatter, hist, heatmap, box, area, count
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd

    fig, ax = plt.subplots(figsize=(12, 7))
    plt.style.use("seaborn-v0_8-darkgrid")

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    chart_title = title or f"{chart_type.capitalize()} Chart"

    try:
        if chart_type == "hist" or chart_type == "histogram":
            if numeric_cols:
                for col in numeric_cols[:4]:
                    df[col].dropna().hist(ax=ax, alpha=0.7, bins=30, label=col)
                ax.legend()
                ax.set_xlabel("Value")
                ax.set_ylabel("Frequency")
            else:
                raise ValueError("No numeric columns for histogram")

        elif chart_type == "bar":
            if cat_cols and numeric_cols:
                xcol = cat_cols[0]
                ycol = numeric_cols[0]
                top = df.groupby(xcol)[ycol].sum().sort_values(ascending=False).head(20)
                top.plot(kind="bar", ax=ax, color="steelblue", edgecolor="white")
                ax.set_xlabel(xcol)
                ax.set_ylabel(ycol)
                ax.tick_params(axis="x", rotation=45)
            elif numeric_cols:
                df[numeric_cols[:8]].mean().plot(kind="bar", ax=ax, color="steelblue")
                ax.set_ylabel("Mean Value")
                ax.tick_params(axis="x", rotation=45)
            else:
                raise ValueError("Need categorical + numeric columns for bar chart")

        elif chart_type == "line":
            if numeric_cols:
                for col in numeric_cols[:5]:
                    ax.plot(df.index, df[col], label=col, linewidth=1.5)
                ax.legend()
                ax.set_xlabel("Index")
                ax.set_ylabel("Value")
            else:
                raise ValueError("No numeric columns for line chart")

        elif chart_type == "pie":
            if cat_cols and numeric_cols:
                xcol = cat_cols[0]
                ycol = numeric_cols[0]
                data = df.groupby(xcol)[ycol].sum().sort_values(ascending=False).head(10)
                explode = [0.05] * len(data)
                data.plot(kind="pie", ax=ax, autopct="%1.1f%%", explode=explode,
                          shadow=True, startangle=140)
                ax.set_ylabel("")
            elif cat_cols:
                data = df[cat_cols[0]].value_counts().head(10)
                data.plot(kind="pie", ax=ax, autopct="%1.1f%%", shadow=True)
                ax.set_ylabel("")
            else:
                raise ValueError("Need categorical column for pie chart")

        elif chart_type == "scatter":
            if len(numeric_cols) >= 2:
                xcol, ycol = numeric_cols[0], numeric_cols[1]
                color_col = numeric_cols[2] if len(numeric_cols) > 2 else None
                sc = ax.scatter(
                    df[xcol].dropna(), df[ycol].dropna(),
                    c=df[color_col] if color_col else "steelblue",
                    alpha=0.6, edgecolors="none",
                    cmap="viridis" if color_col else None
                )
                if color_col:
                    plt.colorbar(sc, ax=ax, label=color_col)
                ax.set_xlabel(xcol)
                ax.set_ylabel(ycol)
                # Trend line
                try:
                    valid = df[[xcol, ycol]].dropna()
                    z = np.polyfit(valid[xcol], valid[ycol], 1)
                    p = np.poly1d(z)
                    x_line = np.linspace(valid[xcol].min(), valid[xcol].max(), 100)
                    ax.plot(x_line, p(x_line), "r--", alpha=0.8, label="Trend")
                    ax.legend()
                except Exception:
                    pass
            else:
                raise ValueError("Need at least 2 numeric columns for scatter plot")

        elif chart_type in ("heatmap", "correlation"):
            if len(numeric_cols) >= 2:
                try:
                    import seaborn as sns
                    corr = df[numeric_cols[:15]].corr()
                    plt.close()
                    fig, ax = plt.subplots(figsize=(12, 10))
                    sns.heatmap(
                        corr, ax=ax, annot=True, fmt=".2f",
                        cmap="RdYlGn", center=0,
                        square=True, linewidths=0.5
                    )
                except ImportError:
                    # Fallback: matplotlib imshow
                    corr = df[numeric_cols[:15]].corr()
                    im = ax.imshow(corr.values, cmap="RdYlGn", aspect="auto",
                                   vmin=-1, vmax=1)
                    ax.set_xticks(range(len(corr.columns)))
                    ax.set_yticks(range(len(corr.columns)))
                    ax.set_xticklabels([str(c)[:12] for c in corr.columns], rotation=45)
                    ax.set_yticklabels([str(c)[:12] for c in corr.columns])
                    plt.colorbar(im, ax=ax)
                    for i in range(len(corr)):
                        for j in range(len(corr.columns)):
                            ax.text(j, i, f"{corr.values[i, j]:.2f}",
                                    ha="center", va="center", fontsize=8)
                chart_title = "Correlation Heatmap"
            else:
                raise ValueError("Need at least 2 numeric columns for heatmap")

        elif chart_type == "box":
            if numeric_cols:
                df[numeric_cols[:8]].boxplot(ax=ax, vert=True)
                ax.tick_params(axis="x", rotation=45)
                ax.set_ylabel("Value")
            else:
                raise ValueError("No numeric columns for box plot")

        elif chart_type in ("count", "countplot"):
            if cat_cols:
                data = df[cat_cols[0]].value_counts().head(20)
                data.plot(kind="barh", ax=ax, color="coral")
                ax.set_xlabel("Count")
                ax.set_title(f"Count of {cat_cols[0]}")
            else:
                raise ValueError("No categorical columns for count plot")

        elif chart_type == "area":
            if numeric_cols:
                df[numeric_cols[:5]].plot(kind="area", ax=ax, alpha=0.4)
                ax.set_xlabel("Index")
                ax.set_ylabel("Value")
            else:
                raise ValueError("No numeric columns for area chart")

        else:
            # Default: bar of first numeric col
            if numeric_cols:
                df[numeric_cols[0]].head(30).plot(kind="bar", ax=ax)
            else:
                raise ValueError(f"Unknown chart type: {chart_type}")

    except Exception as chart_err:
        plt.close()
        raise chart_err

    ax.set_title(chart_title, fontsize=14, fontweight="bold", pad=15)
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def _make_html_dashboard(df, title: str = "Data Dashboard") -> str:
    """
    Generate a self-contained HTML dashboard with interactive charts.
    Uses Chart.js (CDN) — fully functional offline-style HTML.
    """
    import numpy as np
    import json as _json

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    rows, cols = df.shape
    desc_stats = {}
    for col in numeric_cols[:10]:
        col_data = df[col].dropna()
        if len(col_data):
            desc_stats[col] = {
                "min": float(col_data.min()),
                "max": float(col_data.max()),
                "mean": float(col_data.mean()),
                "std": float(col_data.std()),
                "count": int(len(col_data)),
            }

    # Build chart data
    charts_js = []

    # Chart 1: Numeric means bar chart
    if desc_stats:
        labels = _json.dumps(list(desc_stats.keys()))
        values = _json.dumps([v["mean"] for v in desc_stats.values()])
        charts_js.append(f"""
        new Chart(document.getElementById('chart1'), {{
            type: 'bar',
            data: {{
                labels: {labels},
                datasets: [{{
                    label: 'Mean Value',
                    data: {values},
                    backgroundColor: 'rgba(54, 162, 235, 0.7)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{ title: {{ display: true, text: 'Column Means' }} }}
            }}
        }});
        """)

    # Chart 2: Categorical distribution
    cat_chart_js = ""
    if cat_cols:
        top_cat = df[cat_cols[0]].value_counts().head(10)
        cat_labels = _json.dumps(list(top_cat.index.astype(str)))
        cat_values = _json.dumps(list(top_cat.values.tolist()))
        charts_js.append(f"""
        new Chart(document.getElementById('chart2'), {{
            type: 'doughnut',
            data: {{
                labels: {cat_labels},
                datasets: [{{
                    data: {cat_values},
                    backgroundColor: [
                        '#FF6384','#36A2EB','#FFCE56','#4BC0C0','#9966FF',
                        '#FF9F40','#FF6384','#C9CBCF','#7BC8A4','#E8C1A0'
                    ]
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{ title: {{ display: true, text: 'Distribution: {esc(cat_cols[0])}' }} }}
            }}
        }});
        """)

    # Chart 3: Line chart for first numeric col (if enough data)
    if numeric_cols and rows > 1:
        sample = df[numeric_cols[0]].dropna().head(100).tolist()
        line_values = _json.dumps([float(v) for v in sample])
        line_labels = _json.dumps([str(i) for i in range(len(sample))])
        charts_js.append(f"""
        new Chart(document.getElementById('chart3'), {{
            type: 'line',
            data: {{
                labels: {line_labels},
                datasets: [{{
                    label: '{esc(numeric_cols[0])}',
                    data: {line_values},
                    borderColor: 'rgba(255, 99, 132, 1)',
                    backgroundColor: 'rgba(255, 99, 132, 0.1)',
                    fill: true,
                    tension: 0.3
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{ title: {{ display: true, text: 'Trend: {esc(numeric_cols[0])}' }} }}
            }}
        }});
        """)

    # Stats cards
    stat_cards = ""
    for col, stats in list(desc_stats.items())[:6]:
        stat_cards += f"""
        <div class="stat-card">
            <div class="stat-label">{html.escape(str(col)[:20])}</div>
            <div class="stat-value">{stats['mean']:.2g}</div>
            <div class="stat-sub">mean | min: {stats['min']:.2g} | max: {stats['max']:.2g}</div>
        </div>"""

    # Preview table (first 20 rows)
    table_html = df.head(20).to_html(
        classes="data-table",
        border=0,
        index=False,
        escape=True,
        na_rep="—"
    )

    charts_init = "\n".join(charts_js)
    chart2_section = '<canvas id="chart2"></canvas>' if cat_cols else ""
    chart3_section = '<canvas id="chart3"></canvas>' if len(numeric_cols) >= 1 else ""

    dashboard_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{html.escape(title)}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f1117; color: #e0e0e0; }}
  header {{ background: linear-gradient(135deg, #1a1d2e 0%, #16213e 100%); padding: 24px 32px; border-bottom: 1px solid #2d3252; }}
  header h1 {{ font-size: 1.8em; color: #60a5fa; font-weight: 700; }}
  header .meta {{ color: #94a3b8; margin-top: 6px; font-size: 0.9em; }}
  .container {{ max-width: 1400px; margin: 0 auto; padding: 24px; }}
  .stats-row {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }}
  .stat-card {{ background: #1e2030; border: 1px solid #2d3252; border-radius: 12px; padding: 20px; transition: transform .2s; }}
  .stat-card:hover {{ transform: translateY(-2px); }}
  .stat-label {{ color: #94a3b8; font-size: 0.8em; text-transform: uppercase; letter-spacing: .05em; margin-bottom: 8px; }}
  .stat-value {{ font-size: 2em; font-weight: 700; color: #60a5fa; }}
  .stat-sub {{ color: #64748b; font-size: 0.78em; margin-top: 6px; }}
  .charts-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; margin-bottom: 28px; }}
  .chart-card {{ background: #1e2030; border: 1px solid #2d3252; border-radius: 12px; padding: 20px; }}
  .section-title {{ color: #94a3b8; font-size: 0.85em; text-transform: uppercase; letter-spacing: .05em; margin-bottom: 16px; font-weight: 600; }}
  .data-table {{ width: 100%; border-collapse: collapse; font-size: 0.85em; }}
  .data-table th {{ background: #2d3252; color: #94a3b8; padding: 10px 14px; text-align: left; font-weight: 600; }}
  .data-table td {{ padding: 9px 14px; border-bottom: 1px solid #1e2030; color: #e2e8f0; }}
  .data-table tr:hover td {{ background: #252840; }}
  .table-wrapper {{ background: #1e2030; border: 1px solid #2d3252; border-radius: 12px; padding: 20px; overflow-x: auto; margin-bottom: 28px; }}
  .info-badge {{ display: inline-block; background: #2d3252; color: #60a5fa; padding: 4px 10px; border-radius: 20px; font-size: 0.8em; margin-right: 8px; }}
  footer {{ text-align: center; padding: 24px; color: #475569; font-size: 0.8em; border-top: 1px solid #1e2030; }}
</style>
</head>
<body>
<header>
  <h1>📊 {html.escape(title)}</h1>
  <div class="meta">
    <span class="info-badge">🗂️ {rows:,} rows</span>
    <span class="info-badge">📋 {cols} columns</span>
    <span class="info-badge">🕐 Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}</span>
    {'<span class="info-badge">🔢 ' + str(len(numeric_cols)) + ' numeric cols</span>' if numeric_cols else ''}
    {'<span class="info-badge">🏷️ ' + str(len(cat_cols)) + ' categorical cols</span>' if cat_cols else ''}
  </div>
</header>

<div class="container">

  {'<div class="stats-row">' + stat_cards + '</div>' if stat_cards else ''}

  <div class="charts-grid">
    {'<div class="chart-card"><div class="section-title">Column Means</div><canvas id="chart1"></canvas></div>' if desc_stats else ''}
    {'<div class="chart-card"><div class="section-title">Category Distribution</div>' + chart2_section + '</div>' if cat_cols else ''}
    {'<div class="chart-card"><div class="section-title">Trend (first 100 rows)</div>' + chart3_section + '</div>' if numeric_cols else ''}
  </div>

  <div class="table-wrapper">
    <div class="section-title">Data Preview (first 20 rows)</div>
    {table_html}
  </div>

</div>

<footer>Salim Data Dashboard · Powered by pandas + Chart.js</footer>

<script>
{charts_init}
</script>
</body>
</html>"""

    return dashboard_html


def _clean_dataframe(df):
    """
    Clean dataframe: remove duplicates, fix column names, handle common issues.
    Returns (cleaned_df, report_lines).
    """
    import numpy as np
    import pandas as pd

    report = []
    original_rows = len(df)
    original_cols = len(df.columns)

    # 1. Clean column names
    old_cols = list(df.columns)
    df.columns = [
        re.sub(r'\s+', '_', str(c).strip().lower())
                   .replace('.', '_').replace('-', '_')
        for c in df.columns
    ]
    changed_cols = [(o, n) for o, n in zip(old_cols, df.columns) if str(o) != n]
    if changed_cols:
        report.append(f"🔤 Cleaned {len(changed_cols)} column name(s)")

    # 2. Remove completely empty rows
    df.dropna(how="all", inplace=True)
    if len(df) < original_rows:
        report.append(f"🗑️ Removed {original_rows - len(df)} completely empty rows")

    # 3. Remove duplicates
    dupe_count = df.duplicated().sum()
    if dupe_count > 0:
        df.drop_duplicates(inplace=True)
        report.append(f"🔁 Removed {dupe_count} duplicate rows")

    # 4. Try to infer better dtypes
    for col in df.columns:
        if df[col].dtype == object:
            # Try numeric
            converted = pd.to_numeric(df[col].str.replace(',', '').str.strip()
                                      if hasattr(df[col], 'str') else df[col],
                                      errors='coerce')
            non_null_orig = df[col].count()
            non_null_conv = converted.count()
            # Only convert if > 80% of values converted successfully
            if non_null_orig > 0 and non_null_conv / non_null_orig > 0.8:
                df[col] = converted
                report.append(f"🔢 Converted '{col}' to numeric")
                continue

            # Try datetime
            if any(kw in str(col).lower() for kw in ('date', 'time', 'year', 'month', 'day')):
                try:
                    dt_col = pd.to_datetime(df[col], errors='coerce', infer_datetime_format=True)
                    non_null_dt = dt_col.count()
                    if non_null_orig > 0 and non_null_dt / non_null_orig > 0.8:
                        df[col] = dt_col
                        report.append(f"📅 Converted '{col}' to datetime")
                except Exception:
                    pass

    # 5. Report remaining nulls
    null_cols = df.isnull().sum()
    null_cols = null_cols[null_cols > 0]
    if len(null_cols):
        report.append(f"⚠️ {len(null_cols)} column(s) have null values")

    final_rows = len(df)
    report.insert(0, f"✅ Cleaned: {original_rows:,} → {final_rows:,} rows, {original_cols} columns")

    return df, report


class DataAnalystHandlers:
    """Data analysis and visualization handler."""

    @require_auth
    async def cmd_analyze(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /analyze [subcommand]
        
        Subcommands:
          (none)         — analyze the most recently uploaded file
          describe       — statistical summary
          chart <type>   — bar/line/pie/scatter/hist/heatmap/box
          clean          — clean & normalize data
          correlate      — correlation analysis
          report         — full automated report
        
        Upload a CSV, Excel, or JSON file first, then use /analyze.
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        subcommand = (ctx.args[0].lower() if ctx.args else "describe")
        extra_args = ctx.args[1:] if len(ctx.args) > 1 else []

        if not _ensure_pandas():
            await msg.reply_text(
                "❌ pandas not installed. Run: <code>pip install pandas</code>",
                parse_mode=H
            )
            return

        # Load data if we have a file attachment
        if update.message and update.message.document:
            await self._load_data_from_doc(msg, update.message.document, chat_id)
            if subcommand == "describe" and not extra_args:
                # Auto-run describe after loading
                pass

        elif chat_id not in _loaded_data:
            await msg.reply_text(
                "📊 <b>Data Analyst</b>\n\n"
                "First upload a data file (CSV, Excel, JSON), then use:\n\n"
                "• <code>/analyze</code> — auto summary\n"
                "• <code>/analyze describe</code> — statistical summary\n"
                "• <code>/analyze chart bar</code> — bar chart\n"
                "• <code>/analyze chart pie</code> — pie chart\n"
                "• <code>/analyze chart scatter</code> — scatter plot\n"
                "• <code>/analyze chart heatmap</code> — correlation heatmap\n"
                "• <code>/analyze chart hist</code> — histogram\n"
                "• <code>/analyze chart line</code> — line chart\n"
                "• <code>/analyze clean</code> — clean & normalize data\n"
                "• <code>/analyze correlate</code> — correlation matrix\n"
                "• <code>/analyze report</code> — full analysis report\n\n"
                "Or use <code>/dashboard</code> for an interactive HTML dashboard.",
                parse_mode=H
            )
            return

        data_info = _loaded_data.get(chat_id, {})
        df = data_info.get("df")
        filename = data_info.get("filename", "data")

        if df is None or df.empty:
            await msg.reply_text("❌ No data loaded. Please upload a file first.", parse_mode=H)
            return

        # ── SUBCOMMANDS ────────────────────────────────────────────────────────

        if subcommand in ("describe", "summary", "stats"):
            status = await msg.reply_text("📊 <i>Analyzing data…</i>", parse_mode=H)
            try:
                desc = _generate_describe(df)
                await status.edit_text(
                    f"📊 <b>Analysis: {esc(filename)}</b>\n\n{desc}",
                    parse_mode=H
                )
            except Exception as e:
                await status.edit_text(f"❌ Analysis error: {esc(str(e)[:200])}", parse_mode=H)

        elif subcommand == "chart":
            chart_type = (extra_args[0].lower() if extra_args else "bar")
            chart_title = " ".join(extra_args[1:]) if len(extra_args) > 1 else f"{filename} — {chart_type.capitalize()}"

            if not _ensure_matplotlib():
                await msg.reply_text("❌ matplotlib not installed.", parse_mode=H)
                return

            status = await msg.reply_text(
                f"📈 <i>Generating {esc(chart_type)} chart…</i>",
                parse_mode=H
            )
            try:
                loop = asyncio.get_event_loop()
                png_bytes = await loop.run_in_executor(
                    None, _make_chart, df, chart_type, chart_title
                )
                await status.delete()
                buf = io.BytesIO(png_bytes)
                buf.name = f"{chart_type}_chart.png"
                await msg.reply_photo(
                    photo=buf,
                    caption=f"📈 <b>{esc(chart_title)}</b>\n"
                            f"Data: {esc(filename)} · {len(df):,} rows",
                    parse_mode=H
                )
            except Exception as e:
                await status.edit_text(
                    f"❌ Chart error: <code>{esc(str(e)[:300])}</code>",
                    parse_mode=H
                )

        elif subcommand == "clean":
            status = await msg.reply_text("🧹 <i>Cleaning data…</i>", parse_mode=H)
            try:
                cleaned_df, report_lines = await asyncio.get_event_loop().run_in_executor(
                    None, _clean_dataframe, df.copy()
                )
                _loaded_data[chat_id]["df"] = cleaned_df

                # Save cleaned CSV
                clean_csv = cleaned_df.to_csv(index=False).encode("utf-8-sig")
                buf = io.BytesIO(clean_csv)
                clean_filename = f"cleaned_{filename.rsplit('.', 1)[0]}.csv"
                buf.name = clean_filename

                report_text = "\n".join(report_lines)
                await status.delete()
                await msg.reply_document(
                    document=buf,
                    filename=clean_filename,
                    caption=f"🧹 <b>Data Cleaning Report</b>\n\n{esc(report_text)}",
                    parse_mode=H
                )
            except Exception as e:
                await status.edit_text(
                    f"❌ Clean error: <code>{esc(str(e)[:300])}</code>",
                    parse_mode=H
                )

        elif subcommand in ("correlate", "correlation"):
            if not _ensure_matplotlib():
                await msg.reply_text("❌ matplotlib not installed.", parse_mode=H)
                return

            status = await msg.reply_text("🔗 <i>Computing correlations…</i>", parse_mode=H)
            try:
                import numpy as np
                numeric_df = df.select_dtypes(include=[np.number])
                if len(numeric_df.columns) < 2:
                    await status.edit_text("❌ Need at least 2 numeric columns for correlation.", parse_mode=H)
                    return

                loop = asyncio.get_event_loop()
                png_bytes = await loop.run_in_executor(
                    None, _make_chart, df, "heatmap", "Correlation Matrix"
                )
                corr_matrix = numeric_df.corr().round(3)
                corr_csv = corr_matrix.to_csv().encode("utf-8-sig")

                await status.delete()
                buf = io.BytesIO(png_bytes)
                buf.name = "correlation.png"
                await msg.reply_photo(
                    photo=buf,
                    caption=f"🔗 <b>Correlation Matrix</b> — {len(numeric_df.columns)} columns",
                    parse_mode=H
                )
                # Also send CSV
                cbuf = io.BytesIO(corr_csv)
                cbuf.name = "correlation.csv"
                await msg.reply_document(
                    document=cbuf,
                    filename="correlation.csv",
                    caption="📋 Correlation values as CSV"
                )
            except Exception as e:
                await status.edit_text(
                    f"❌ Correlation error: <code>{esc(str(e)[:200])}</code>",
                    parse_mode=H
                )

        elif subcommand == "report":
            status = await msg.reply_text("📝 <i>Generating full analysis report…</i>", parse_mode=H)
            try:
                if not _ensure_matplotlib():
                    await msg.reply_text("❌ matplotlib not installed.", parse_mode=H)
                    return

                import numpy as np
                loop = asyncio.get_event_loop()

                # Generate multiple charts
                numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
                cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

                chart_types = []
                if numeric_cols:
                    chart_types.extend(["hist", "bar"])
                if len(numeric_cols) >= 2:
                    chart_types.append("scatter")
                if cat_cols:
                    chart_types.append("pie")
                if len(numeric_cols) >= 2:
                    chart_types.append("heatmap")

                await status.edit_text(
                    f"📝 <i>Building report ({len(chart_types)} charts)…</i>",
                    parse_mode=H
                )

                desc = _generate_describe(df)
                await msg.reply_text(
                    f"📊 <b>Full Report: {esc(filename)}</b>\n\n{desc}",
                    parse_mode=H
                )

                for ct in chart_types:
                    try:
                        png_bytes = await loop.run_in_executor(
                            None, _make_chart, df, ct, f"{ct.capitalize()} — {filename}"
                        )
                        buf = io.BytesIO(png_bytes)
                        buf.name = f"{ct}.png"
                        await msg.reply_photo(photo=buf, caption=f"📈 {ct.capitalize()} chart")
                    except Exception as ce:
                        logger.warning(f"Chart {ct} failed: {ce}")

                await status.delete()
                await msg.reply_text("✅ <b>Report complete.</b>", parse_mode=H)

            except Exception as e:
                await status.edit_text(
                    f"❌ Report error: <code>{esc(str(e)[:200])}</code>",
                    parse_mode=H
                )
        else:
            # Default: summary + one auto chart
            await self._auto_analyze(msg, df, filename, chat_id)

    async def _auto_analyze(self, msg, df, filename: str, chat_id: int):
        """Auto-run: summary + best chart."""
        import numpy as np

        desc = _generate_describe(df)
        await msg.reply_text(
            f"📊 <b>Auto Analysis: {esc(filename)}</b>\n\n{desc}",
            parse_mode=H
        )

        if not _ensure_matplotlib():
            return

        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

        # Pick best chart type
        if len(numeric_cols) >= 2:
            chart_type = "scatter"
        elif numeric_cols and cat_cols:
            chart_type = "bar"
        elif numeric_cols:
            chart_type = "hist"
        elif cat_cols:
            chart_type = "count"
        else:
            return

        try:
            loop = asyncio.get_event_loop()
            png_bytes = await loop.run_in_executor(
                None, _make_chart, df, chart_type, filename
            )
            buf = io.BytesIO(png_bytes)
            buf.name = "auto_chart.png"
            await msg.reply_photo(
                photo=buf,
                caption=f"📈 Auto chart ({chart_type}) · {len(df):,} rows",
            )
        except Exception as e:
            logger.warning(f"Auto chart failed: {e}")

    async def _load_data_from_doc(self, msg, document, chat_id: int):
        """Download and load a Telegram document into memory."""
        filename = document.file_name or "data.csv"
        status = await msg.reply_text(
            f"📥 <i>Loading {esc(filename)}…</i>",
            parse_mode=H
        )
        try:
            file_obj = await document.get_file()
            buf = io.BytesIO()
            await file_obj.download_to_memory(buf)
            file_bytes = buf.getvalue()

            df, error = _load_dataframe(file_bytes, filename)
            if error:
                await status.edit_text(f"❌ Load error: <code>{esc(error)}</code>", parse_mode=H)
                return

            _loaded_data[chat_id] = {
                "df": df,
                "filename": filename,
                "loaded_at": datetime.now().isoformat(),
            }
            await status.edit_text(
                f"✅ <b>Loaded:</b> {esc(filename)}\n"
                f"📊 {len(df):,} rows × {len(df.columns)} columns\n\n"
                f"Use <code>/analyze describe</code> for stats or\n"
                f"<code>/analyze chart bar</code> for a chart.",
                parse_mode=H
            )
        except Exception as e:
            await status.edit_text(
                f"❌ Failed to load file: <code>{esc(str(e)[:200])}</code>",
                parse_mode=H
            )

    @require_auth
    async def cmd_dashboard(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /dashboard [title]
        
        Generate an interactive HTML dashboard from loaded data.
        The dashboard uses Chart.js and is fully self-contained.
        
        Upload a CSV/Excel/JSON first, then use /dashboard.
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        if chat_id not in _loaded_data:
            await msg.reply_text(
                "📊 Upload a CSV, Excel, or JSON file first, then use <code>/dashboard</code>.",
                parse_mode=H
            )
            return

        data_info = _loaded_data[chat_id]
        df = data_info.get("df")
        filename = data_info.get("filename", "data")

        if df is None or df.empty:
            await msg.reply_text("❌ No data loaded.", parse_mode=H)
            return

        title = " ".join(ctx.args) if ctx.args else filename.rsplit(".", 1)[0].replace("_", " ").title()

        status = await msg.reply_text(
            f"📊 <i>Building interactive dashboard for '{esc(title)}'…</i>",
            parse_mode=H
        )
        try:
            loop = asyncio.get_event_loop()
            html_content = await loop.run_in_executor(
                None, _make_html_dashboard, df, title
            )
            html_bytes = html_content.encode("utf-8")
            buf = io.BytesIO(html_bytes)
            dash_filename = f"{title.replace(' ', '_').lower()}_dashboard.html"
            buf.name = dash_filename

            await status.delete()
            await msg.reply_document(
                document=buf,
                filename=dash_filename,
                caption=(
                    f"📊 <b>Interactive Dashboard: {esc(title)}</b>\n"
                    f"📁 Download and open in any browser.\n"
                    f"✨ Charts: Bar, Pie/Donut, Line trend\n"
                    f"📋 Data preview: first 20 rows included"
                ),
                parse_mode=H
            )
        except Exception as e:
            await status.edit_text(
                f"❌ Dashboard error: <code>{esc(str(e)[:200])}</code>",
                parse_mode=H
            )

    @require_auth
    async def cmd_plotcsv(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /plotcsv <url> [chart_type]
        
        Fetch a CSV from any URL and auto-plot it.
        
        Examples:
          /plotcsv https://raw.githubusercontent.com/datasets/covid-19/main/data/worldwide-aggregated.csv
          /plotcsv https://raw.githubusercontent.com/mwaskom/seaborn-data/master/tips.csv scatter
        """
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "📈 <b>Plot CSV from URL</b>\n\n"
                "<b>Usage:</b> <code>/plotcsv &lt;url&gt; [chart_type]</code>\n\n"
                "Chart types: bar, line, scatter, hist, pie, heatmap\n\n"
                "<b>Example:</b>\n"
                "<code>/plotcsv https://raw.githubusercontent.com/mwaskom/seaborn-data/master/tips.csv scatter</code>",
                parse_mode=H
            )
            return

        url = ctx.args[0]
        chart_type = ctx.args[1].lower() if len(ctx.args) > 1 else "auto"

        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        status = await msg.reply_text(
            f"📥 <i>Fetching CSV from {esc(url[:60])}…</i>",
            parse_mode=H
        )

        try:
            import requests
            resp = requests.get(url, headers={"User-Agent": "Salim/1.0"}, timeout=15)
            resp.raise_for_status()
            file_bytes = resp.content
            filename = url.split("/")[-1].split("?")[0] or "data.csv"

            df, error = _load_dataframe(file_bytes, filename)
            if error:
                await status.edit_text(f"❌ Parse error: <code>{esc(error)}</code>", parse_mode=H)
                return

            _loaded_data[msg.chat_id] = {
                "df": df,
                "filename": filename,
                "loaded_at": datetime.now().isoformat(),
            }

            if not _ensure_matplotlib():
                await status.edit_text("❌ matplotlib not installed.", parse_mode=H)
                return

            import numpy as np
            if chart_type == "auto":
                numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
                cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
                if len(numeric_cols) >= 2:
                    chart_type = "scatter"
                elif numeric_cols and cat_cols:
                    chart_type = "bar"
                else:
                    chart_type = "hist"

            await status.edit_text(
                f"📈 <i>Plotting {len(df):,} rows as {esc(chart_type)}…</i>",
                parse_mode=H
            )

            loop = asyncio.get_event_loop()
            png_bytes = await loop.run_in_executor(
                None, _make_chart, df, chart_type, filename
            )

            await status.delete()
            buf = io.BytesIO(png_bytes)
            buf.name = f"{chart_type}.png"
            await msg.reply_photo(
                photo=buf,
                caption=(
                    f"📈 <b>{esc(filename)}</b> — {esc(chart_type)} chart\n"
                    f"📊 {len(df):,} rows × {len(df.columns)} columns\n\n"
                    f"<i>Use /analyze for more chart types & analysis.</i>"
                ),
                parse_mode=H
            )

        except Exception as e:
            await status.edit_text(
                f"❌ Error: <code>{esc(str(e)[:300])}</code>",
                parse_mode=H
            )
