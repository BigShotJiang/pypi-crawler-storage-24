# AVP framework integrations
