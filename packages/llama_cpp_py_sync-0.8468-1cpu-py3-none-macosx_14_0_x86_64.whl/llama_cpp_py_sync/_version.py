"""Version information for llama-cpp-py-sync."""

__version__ = "0.8468"
__llama_cpp_commit__ = "3306dbaef"
__llama_cpp_tag__ = "b8468"
