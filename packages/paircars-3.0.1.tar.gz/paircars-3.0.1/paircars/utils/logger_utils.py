import secrets
import string
import logging
import argparse
import requests
import time
import os
import getpass
import urllib.request
import urllib.error
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer
from .basic_utils import get_cachedir


##################################
# Logger related functions
##################################
class SmartDefaultsHelpFormatter(argparse.ArgumentDefaultsHelpFormatter):
    def _get_help_string(self, action):
        # Don't show default for boolean flags
        if isinstance(action, argparse._StoreTrueAction) or isinstance(
            action, argparse._StoreFalseAction
        ):
            return action.help
        return super()._get_help_string(action)


def clean_shutdown(observer):
    if observer:
        observer.stop()
        observer.join(timeout=5)


def generate_password(length=6):
    """
    Generate secure 6-character password with letters, digits, and symbols
    """
    chars = string.ascii_letters + string.digits + "@#$&*"
    return "".join(secrets.choice(chars) for _ in range(length))


def get_remote_logger_link():
    cachedir = get_cachedir()
    username = getpass.getuser()
    link_file = os.path.join(cachedir, f"remotelink_{username}.txt")
    try:
        if os.path.isfile(link_file):
            with open(link_file, "r") as f:
                lines = [line.strip() for line in f if line.strip()]
            remote_link = lines[0]
        else:
            return ""
    except Exception:
        return ""
    try:
        req = urllib.request.Request(remote_link, method="GET")
        with urllib.request.urlopen(req, timeout=60) as response:
            if response.status == 200:
                return remote_link
    except (urllib.error.URLError, urllib.error.HTTPError):
        return ""


def get_emails():
    cachedir = get_cachedir()
    username = getpass.getuser()
    email_file = os.path.join(cachedir, f"emails_{username}.txt")
    try:
        with open(email_file, "r") as f:
            lines = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return ""
    if not lines:
        return ""
    else:
        return lines[0]


class StreamToLogger:
    def __init__(self, logger, log_level=logging.INFO):
        self.logger = logger
        self.log_level = log_level
        self._buffer = ""

    def write(self, message):
        # Remove trailing newlines and skip empty messages
        message = message.rstrip()
        if message:
            self.logger.log(self.log_level, message)

    def flush(self):
        pass  # Required for compatibility


class RemoteLogger(logging.Handler):
    """
    Remote logging handler for posting log messages to a web endpoint.
    """

    def __init__(
        self, job_id="default", log_id="run_default", remote_link="", password=""
    ):
        super().__init__()
        self.job_id = job_id
        self.log_id = log_id
        self.password = password
        self.remote_link = remote_link

    def emit(self, record):
        msg = self.format(record)
        try:
            requests.post(
                f"{self.remote_link}/api/log",
                json={
                    "job_id": self.job_id,
                    "log_id": self.log_id,
                    "message": f"{msg}\n",
                    "password": self.password,
                    "first": False,
                },
                timeout=2,
            )
        except Exception:
            pass  # Fail silently to avoid interrupting the main app


class LogTailHandler(FileSystemEventHandler):
    """
    Continuous logging
    """

    def __init__(self, logfile, logger):
        self.logfile = logfile
        self.logger = logger
        self._position = os.path.getsize(logfile) if os.path.exists(logfile) else 0

    def on_modified(self, event):
        if event.src_path == self.logfile:
            try:
                with open(self.logfile, "r") as f:
                    f.seek(self._position)
                    lines = f.readlines()
                    self._position = f.tell()
                for line in lines:
                    if line != "" and line != " " and line != "\n":
                        self.logger.info(line.strip())
            except Exception:
                pass


def create_logger(logname, logfile):
    """
    Create logger.

    Parameters
    ----------
    logname : str
        Name of the log
    logfile : str, optional
        Log file name
        
    Returns
    -------
    logger
        Python logging object
    str
        Log file name
    """
    logger = logging.getLogger(logname)
    # If logger already configured, return it
    if logger.hasHandlers():
        logger.handlers.clear()
    formatter = logging.Formatter("%(message)s")
    logger.setLevel(logging.DEBUG)
    filehandle = logging.FileHandler(logfile)
    filehandle.setFormatter(formatter)
    logger.addHandler(filehandle)
    logger.propagate = False
    logger.info("Log file : " + logfile + "\n")
    return logger, logfile


def get_logid(logfile):
    """
    Get log id for remote logger from logfile name
    """
    name = os.path.basename(logfile)
    logmap = {
        "apply_basiccal_target.log": "Applying basic calibration solutions on targets",
        "apply_basiccal_selfcal.log": "Applying basic calibration solutions for self-calibration",
        "apply_pbcor.log": "Applying primary beam corrections",
        "apply_selfcal.log": "Applying self-calibration solutions",
        "basic_cal.log": "Basic calibration",
        "cor_phasecenter_target.log": "Moving phasecenter to solar center",
        "cor_sidereal_selfcal.log": "Correction of sidereal motion before self-calibration",
        "cor_sidereal_target.log": "Correction of sidereal motion for target scans",
        "flagging_cal_calibrator.log": "Basic flagging of calibrators",
        "flagging_target_target.log": "Basic flagging of targets",
        "modeling.log": "Simulating visibilities of calibrators",
        "split_calibrator.log": "Spliting calibrator scans",
        "split_target.log": "Spliting target",
        "split_selfcal.log": "Spliting for self-calibration",
        "selfcal_target.log": "All self-calibrations",
        "imaging_target.log": "All imaging",
        "ds_target.log": "Making dynamic spectra",
        "do_overlay.log": "Making overlays",
        "main.log": "All master log",
        "do_msplot.log": "Diagnistic plot of ms",
    }

    if name in logmap:
        return logmap[name]
    elif name.endswith("_int.log"):
        name = name.split("_selfcal_int.log")[0].split("selfcal_")[1]
        obsid = name.split("_")[0]
        coarse_chan = name.split("ch")[1].split("_")[0]
        spw = name.split("_")[-1]
        return f"Intensity self-calibration, OBSID: {obsid}, coarse channel: {coarse_chan}, spectral window: {spw}"
    elif name.endswith("_pol.log"):
        name = name.split("_selfcal_pol.log")[0].split("selfcal_")[1]
        obsid = name.split("_")[0]
        coarse_chan = name.split("ch")[1].split("_")[0]
        spw = name.split("_")[-1]
        return f"Polarisation self-calibration, OBSID: {obsid}, coarse channel: {coarse_chan}, spectral window: {spw}"
    elif "imaging_target" in name:
        name = name.rstrip(".log").split("imaging_target_")[1]
        obsid = name.split("_")[0]
        coarse_chan = name.split("ch")[1].split("_")[0]
        spw = name.split("_")[-1]
        return f"Imaging, OBSID: {obsid}, coarse channel: {coarse_chan}, spectral window: {spw}"
    else:
        return name


def init_logger(logname, logfile, jobname="", password=""):
    """
    Initialize a remote logger with watchdog-based tailing.

    Parameters
    ----------
    logname : str
        Logger name.
    logfile : str
        Path to the local logfile to also monitor.
    jobname : str, optional
        Remote logger job ID.
    password : str
        Password used for remote authentication.

    Returns
    -------
    observer
        Observer object
    """
    timeout = 30
    waited = 0
    while True:
        if not os.path.exists(logfile):
            time.sleep(1)
            waited += 1
        elif waited >= timeout:
            return
        else:
            break
    logger = logging.getLogger(logname)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if logger.hasHandlers():
        logger.handlers.clear()
    formatter = logging.Formatter("%(message)s")
    remote_link = get_remote_logger_link()
    if remote_link != "":
        if jobname:
            job_id = jobname
            log_id = get_logid(logfile)
            remote_handler = RemoteLogger(
                job_id=job_id, log_id=log_id, remote_link=remote_link, password=password
            )
            remote_handler.setFormatter(formatter)
            logger.addHandler(remote_handler)

            try:
                requests.post(
                    f"{remote_link}/api/log",
                    json={
                        "job_id": job_id,
                        "log_id": log_id,
                        "message": "Job starting...",
                        "password": password,
                        "first": True,
                    },
                    timeout=2,
                )
            except Exception:
                pass
        if os.path.exists(logfile):
            if os.path.islink(logfile):
                logfile = os.readlink(logfile)
            event_handler = LogTailHandler(logfile, logger)
            observer = Observer()
            observer.schedule(
                event_handler, path=os.path.dirname(logfile), recursive=False
            )
            observer.start()
            return observer
        else:
            return
    else:
        return
