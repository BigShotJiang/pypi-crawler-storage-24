"""
Internal context-variable plumbing for per-request cache headers.

ContextVar is safe in asyncio: each Task gets its own snapshot,
so concurrent LLM calls from different Tasks never interfere.
"""

from __future__ import annotations

import base64
import json
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cachecore import DepDeclaration


@dataclass(slots=True)
class _RequestContext:
    deps: list[DepDeclaration] = field(default_factory=list)
    bypass: bool = False


_ctx: ContextVar[_RequestContext | None] = ContextVar(
    "cachecore_request_ctx", default=None
)


def _encode_deps(deps: list[DepDeclaration]) -> str:
    """
    Encode a list of DepDeclaration into the X-CacheCore-Deps header value.

    Format: base64url (no padding) of JSON array:
        [{"dep_id": "...", "expected_hash": "..."}]

    This is the canonical encoding the gateway expects (manifest.rs:37-51).
    """
    payload = [{"dep_id": d.dep_id, "expected_hash": d.expected_hash} for d in deps]
    raw = json.dumps(payload, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()
