"""CacheCore client exceptions."""

from __future__ import annotations


class CacheCoreError(Exception):
    """Base exception for all CacheCore client errors."""


class CacheCoreAuthError(CacheCoreError):
    """Raised on 401/403 from the gateway or admin endpoints."""


class CacheCoreRateLimitError(CacheCoreError):
    """
    Raised on 429 Too Many Requests from the gateway.

    Attributes:
        retry_after:  Value of Retry-After header if present (seconds), else None.
    """

    def __init__(self, message: str, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after
