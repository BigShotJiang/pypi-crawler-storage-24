"""
CacheCore Python client — thin adapter for the CacheCore caching proxy.

This library handles CacheCore-specific concerns (header injection,
dependency encoding, invalidation) without replacing or wrapping the
LLM SDK.  You keep using ``openai.AsyncOpenAI``, ``ChatOpenAI``, etc.
exactly as before.

Quick start::

    from cachecore import CacheCoreClient, Dep

    cc = CacheCoreClient(
        gateway_url="http://localhost:8080",
        tenant_jwt="ey...",
    )

    # Inject into any OpenAI-compatible SDK
    import httpx
    from openai import AsyncOpenAI

    oai = AsyncOpenAI(
        api_key="ignored",
        base_url="http://localhost:8080/v1",
        http_client=httpx.AsyncClient(transport=cc.transport),
    )

    # Read path — declare deps so entries can be invalidated later
    with cc.request_context(deps=[Dep("table:products")]):
        resp = await oai.chat.completions.create(model="gpt-4o", messages=[...])

    # Write path — bypass cache, then invalidate stale deps
    with cc.request_context(bypass=True):
        resp = await oai.chat.completions.create(model="gpt-4o", messages=[...])
    await cc.invalidate("table:products")
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator, Literal

import httpx

from cachecore._context import _RequestContext, _ctx
from cachecore._transport import (
    CacheCoreTransport,
    _HDR_AGE,
    _HDR_CACHE,
    _HDR_SIMILARITY,
)
from cachecore.errors import (
    CacheCoreAuthError,
    CacheCoreError,
    CacheCoreRateLimitError,
)

__all__ = [
    "CacheCoreClient",
    "CacheCoreTransport",
    "CacheStatus",
    "Dep",
    "DepDeclaration",
    "InvalidateResult",
    "CacheCoreError",
    "CacheCoreAuthError",
    "CacheCoreRateLimitError",
]

logger = logging.getLogger("cachecore")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Data classes
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class DepDeclaration:
    """
    A dependency declaration to attach to a cached entry.

    Parameters
    ----------
    dep_id:
        Arbitrary string key, e.g. ``"table:products"``, ``"doc:policy-42"``.
    hash:
        The expected hash of this dependency at time of caching.  When the
        dep is later invalidated with a *different* hash, all entries that
        declared this dep_id + hash are evicted.

        For simple use cases (invalidate everything with this dep_id),
        leave as ``"v1"`` — any stable value works.  What matters is that
        ``invalidate()`` changes the hash.

    Examples
    --------
    ::

        # Simple — just a dep ID
        Dep("table:products")

        # Explicit hash for multi-version tracking
        Dep("table:products", hash="abc123")
    """

    __slots__ = ("dep_id", "expected_hash")

    def __init__(self, dep_id: str, hash: str = "v1") -> None:
        self.dep_id = dep_id
        self.expected_hash = hash

    def __repr__(self) -> str:
        if self.expected_hash == "v1":
            return f"Dep({self.dep_id!r})"
        return f"Dep({self.dep_id!r}, hash={self.expected_hash!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, DepDeclaration):
            return NotImplemented
        return self.dep_id == other.dep_id and self.expected_hash == other.expected_hash

    def __hash__(self) -> int:
        return hash((self.dep_id, self.expected_hash))


# Convenience alias — the name users will actually type
Dep = DepDeclaration


@dataclass(frozen=True, slots=True)
class CacheStatus:
    """
    Parsed from ``X-Cache``, ``X-Cache-Similarity``, ``X-Cache-Age``
    response headers.
    """

    status: Literal["HIT_L1", "HIT_L1_STALE", "HIT_L2", "MISS", "BYPASS", "UNKNOWN"]
    similarity: float  # 0.0 – 1.0
    age_seconds: int  # 0 for MISS / BYPASS

    @classmethod
    def from_headers(cls, headers: httpx.Headers) -> CacheStatus:
        raw_status = headers.get(_HDR_CACHE, "UNKNOWN")
        status: Literal[
            "HIT_L1", "HIT_L1_STALE", "HIT_L2", "MISS", "BYPASS", "UNKNOWN"
        ]
        if raw_status in ("HIT_L1", "HIT_L1_STALE", "HIT_L2", "MISS", "BYPASS"):
            status = raw_status  # type: ignore[assignment]
        else:
            status = "UNKNOWN"

        try:
            similarity = float(headers.get(_HDR_SIMILARITY, "0.0"))
        except ValueError:
            similarity = 0.0

        try:
            age = int(headers.get(_HDR_AGE, "0"))
        except ValueError:
            age = 0

        return cls(status=status, similarity=similarity, age_seconds=age)


@dataclass(frozen=True, slots=True)
class InvalidateResult:
    """Result of a single invalidation call."""

    dep_id: str
    ok: bool
    error: str | None = None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Client
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class CacheCoreClient:
    """
    Connection-level object.  Constructed once per tenant.

    Provides:

    - An httpx async transport to inject into any OpenAI / Anthropic SDK.
    - A context manager for per-request dep declarations and bypass.
    - Invalidation helpers.

    The client is **not** a replacement for the LLM SDK.  It handles
    CacheCore-specific concerns only.

    Parameters
    ----------
    gateway_url:
        CacheCore proxy base URL, e.g. ``"http://localhost:8080"``.
        No trailing slash.
    tenant_jwt:
        HS256/RS256 JWT for this tenant.
    timeout:
        HTTP timeout in seconds for management calls (invalidate).
    debug:
        If True, log cache status for every proxied request.
    """

    __slots__ = ("_gateway_url", "_jwt", "_timeout", "_debug", "_transport", "_http")

    def __init__(
        self,
        gateway_url: str,
        tenant_jwt: str,
        *,
        timeout: float = 30.0,
        debug: bool = False,
    ) -> None:
        self._gateway_url = gateway_url.rstrip("/")
        self._jwt = tenant_jwt
        self._timeout = timeout
        self._debug = debug
        self._transport = CacheCoreTransport(jwt=tenant_jwt, debug=debug)

        # Separate httpx client for management calls (invalidate).
        # Not routed through the CacheCore transport — these go direct.
        self._http = httpx.AsyncClient(
            base_url=self._gateway_url,
            timeout=httpx.Timeout(timeout),
        )

    # ── Transport ───────────────────────────────────────────────────────

    @property
    def transport(self) -> CacheCoreTransport:
        """
        The httpx async transport to pass to your SDK's http_client.

        Example::

            http = httpx.AsyncClient(transport=client.transport)
            oai  = AsyncOpenAI(..., http_client=http)
        """
        return self._transport

    # ── Per-request context ─────────────────────────────────────────────

    @contextmanager
    def request_context(
        self,
        deps: list[DepDeclaration] | None = None,
        bypass: bool = False,
    ) -> Iterator[None]:
        """
        Set per-request cache headers for the duration of the ``with`` block.

        Uses a ``ContextVar`` so concurrent asyncio Tasks never interfere.

        Parameters
        ----------
        deps:
            Dependency declarations to tag this cache entry with.
            Pass ``[Dep("table:products")]`` etc.
        bypass:
            If True, omits ``X-CacheCore-Token`` so the gateway skips
            caching.  Use for write operations whose LLM response should
            not be cached.
        """
        token = _ctx.set(_RequestContext(deps=deps or [], bypass=bypass))
        try:
            yield
        finally:
            _ctx.reset(token)

    # ── Invalidation ────────────────────────────────────────────────────

    async def invalidate(
        self,
        dep_id: str,
        new_hash: str | None = None,
    ) -> InvalidateResult:
        """
        Invalidate all cache entries that declared the given dependency.

        Parameters
        ----------
        dep_id:
            The dependency key to invalidate, e.g. ``"table:products"``.
        new_hash:
            The new hash to store for this dep.  If None, a random UUID is
            generated — this guarantees all existing entries are stale.
        """
        if new_hash is None:
            new_hash = uuid.uuid4().hex

        try:
            resp = await self._http.post(
                "/v1/invalidate",
                json={"dep_id": dep_id, "new_hash": new_hash},
            )
            _raise_for_status(resp)
            return InvalidateResult(dep_id=dep_id, ok=True)
        except CacheCoreError as exc:
            return InvalidateResult(dep_id=dep_id, ok=False, error=str(exc))
        except httpx.HTTPError as exc:
            return InvalidateResult(dep_id=dep_id, ok=False, error=str(exc))

    async def invalidate_many(
        self,
        dep_ids: list[str],
        new_hash: str | None = None,
    ) -> list[InvalidateResult]:
        """
        Invalidate multiple deps concurrently.

        Each dep gets the same ``new_hash`` (or individual UUIDs if None).
        """
        tasks = [
            self.invalidate(dep_id, new_hash=new_hash)
            for dep_id in dep_ids
        ]
        return list(await asyncio.gather(*tasks))

    # ── Lifecycle ───────────────────────────────────────────────────────

    async def aclose(self) -> None:
        """Close the underlying HTTP clients."""
        await self._http.aclose()
        await self._transport.aclose()

    async def __aenter__(self) -> CacheCoreClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()


# ── Helpers ─────────────────────────────────────────────────────────────


def _raise_for_status(resp: httpx.Response) -> None:
    """Map gateway HTTP errors to typed exceptions."""
    if resp.status_code < 400:
        return

    if resp.status_code in (401, 403):
        raise CacheCoreAuthError(
            f"CacheCore auth error {resp.status_code}: {resp.text}"
        )

    if resp.status_code == 429:
        retry_after: float | None = None
        raw = resp.headers.get("Retry-After")
        if raw is not None:
            try:
                retry_after = float(raw)
            except ValueError:
                pass
        raise CacheCoreRateLimitError(
            f"CacheCore rate limit (429): {resp.text}",
            retry_after=retry_after,
        )

    if resp.status_code >= 400:
        raise CacheCoreError(
            f"CacheCore error {resp.status_code}: {resp.text}"
        )
