"""
CacheCore httpx async transport.

Sits between the LLM SDK and the network.  On every outgoing request it:
  1. Injects  X-CacheCore-Token  (unless bypass is active).
  2. Injects  X-CacheCore-Deps   (base64url-JSON, if deps declared).
  3. Captures X-Cache / X-Cache-Similarity / X-Cache-Age from the response.

Why a transport and not default_headers?
The OpenAI Python SDK constructs each httpx.Request internally and its
header-merging logic can drop or overwrite client-level default_headers.
Injecting at the transport layer — after Request construction, before the
TCP write — is the only guaranteed injection point.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import httpx

from cachecore._context import _ctx, _encode_deps

if TYPE_CHECKING:
    from cachecore import CacheStatus

logger = logging.getLogger("cachecore")

# ── Header constants ────────────────────────────────────────────────────
# These MUST match proxy.rs exactly.  Bug 1 in the design doc: both test
# agents used "X-Cache-Deps" — the gateway reads "X-CacheCore-Deps".
# Baking the correct names here makes the bug impossible by construction.
_HDR_TOKEN = "X-CacheCore-Token"
_HDR_DEPS = "X-CacheCore-Deps"
_HDR_CACHE = "X-Cache"
_HDR_SIMILARITY = "X-Cache-Similarity"
_HDR_AGE = "X-Cache-Age"


class CacheCoreTransport(httpx.AsyncBaseTransport):
    """
    Drop-in httpx async transport that handles all CacheCore header plumbing.

    Usage::

        transport = CacheCoreTransport(jwt="ey...")
        http = httpx.AsyncClient(transport=transport)
        oai  = AsyncOpenAI(base_url="http://localhost:8080/v1",
                           api_key="dummy", http_client=http)
    """

    __slots__ = ("_jwt", "_wrapped", "_debug")

    def __init__(
        self,
        jwt: str,
        *,
        wrapped: httpx.AsyncBaseTransport | None = None,
        debug: bool = False,
    ) -> None:
        self._jwt = jwt
        self._wrapped = wrapped or httpx.AsyncHTTPTransport()
        self._debug = debug

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        ctx = _ctx.get()

        # ── Inject token (unless bypass) ────────────────────────────────
        # Bypass = omit the token entirely.  The gateway treats a missing
        # token as bypass mode (proxy.rs:55-68).  This fixes Bug 3: the
        # old agents sent "X-Cache-Bypass: true" which is a no-op.
        bypass = ctx is not None and ctx.bypass
        if not bypass:
            request.headers[_HDR_TOKEN] = self._jwt

        # ── Inject deps ─────────────────────────────────────────────────
        # This fixes Bug 1 (wrong header name) and Bug 2 (wrong encoding)
        # by construction: correct header, correct base64url-JSON format.
        if ctx and ctx.deps:
            request.headers[_HDR_DEPS] = _encode_deps(ctx.deps)

        # ── Forward ─────────────────────────────────────────────────────
        response = await self._wrapped.handle_async_request(request)

        # ── Debug logging ───────────────────────────────────────────────
        if self._debug:
            cache = response.headers.get(_HDR_CACHE, "?")
            sim = response.headers.get(_HDR_SIMILARITY, "?")
            age = response.headers.get(_HDR_AGE, "?")
            logger.debug(
                "CacheCore  %s  sim=%s  age=%ss  %s %s",
                cache, sim, age, request.method, request.url,
            )

        return response

    async def aclose(self) -> None:
        await self._wrapped.aclose()
