# Changelog

All notable changes to this project will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2024-01-01

Initial public release.

### Added

- `CacheCoreClient` — connection-level object constructed once per tenant. Provides
  the transport, per-request context manager, and invalidation helpers.
- `CacheCoreTransport` — `httpx.AsyncBaseTransport` that injects `X-CacheCore-Token`
  and `X-CacheCore-Deps` headers at the transport layer, below the LLM SDK, guaranteeing
  correct injection regardless of SDK header-merging behaviour.
- `CacheStatus` — dataclass parsed from `X-Cache`, `X-Cache-Similarity`, and
  `X-Cache-Age` response headers. Reports `HIT_L1`, `HIT_L1_STALE`, `HIT_L2`,
  `MISS`, `BYPASS`, or `UNKNOWN`.
- `Dep` / `DepDeclaration` — dependency declaration objects. Pass to
  `request_context(deps=[Dep("table:products")])` to tag cache entries for later
  invalidation.
- `InvalidateResult` — result dataclass returned by `invalidate()` and
  `invalidate_many()`, carrying `dep_id`, `ok`, and an optional `error` message.
- `CacheCoreError` — base exception class for all CacheCore client errors.
- `CacheCoreAuthError` — raised on 401 / 403 from the gateway.
- `CacheCoreRateLimitError` — raised on 429; carries `.retry_after` attribute (seconds).
- `py.typed` marker (PEP 561) — package ships inline type stubs.
- Python 3.10, 3.11, 3.12, and 3.13 support.
- Single runtime dependency: `httpx >= 0.25.0`.
