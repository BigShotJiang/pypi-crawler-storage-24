"""
Scenario A — Financial Services Compliance Agent: Role Isolation
================================================================

Two roles under the same tenant ("finco"):
  - compliance_officer  — may see cached regulatory interpretations
  - analyst             — must never receive those cached entries

The test proves that same-tenant / different-role queries occupy completely
separate cache namespaces: an analyst query must NOT produce a cache hit from
a compliance_officer's prior query, even when the prompts are word-for-word
identical.

HOW IT WORKS
------------
CacheCore derives a per-request namespace key as:

    SHA256(tenant_id || perm_hash || system_fp || toolset_fp || policy_version)

where perm_hash = SHA256 of all configured permission_claims extracted from the
JWT.  With permission_claims = ["roles", "scope"] (the default in
config/gateway.toml), different roles produce a different perm_hash, which
produces a different namespace, which means different Redis key prefixes for
every L1 and L2 entry.  It is cryptographically impossible for an analyst
request to collide with a compliance_officer entry.

REQUIRED GATEWAY CONFIG (already correct in config/gateway.toml)
-----------------------------------------------------------------
[auth]
permission_claims = ["roles", "scope"]   # "roles" MUST be present

EXPECTED PROMETHEUS METRICS AFTER THIS TEST RUNS
-------------------------------------------------
# Same tenant_id label for both roles — no cross-tenant label noise.
# The key observation: analyst never contributes a hit_l1 from the officer's primed entry.

cachecore_requests_total{status="miss",   tenant_id="finco"}  +2  (officer first, analyst)
cachecore_requests_total{status="hit_l1", tenant_id="finco"}  +1  (officer second only)

If isolation breaks, the analyst's request would appear as:
cachecore_requests_total{status="hit_l1", tenant_id="finco"}  +2  (bug: namespace bleed)
cachecore_requests_total{status="miss",   tenant_id="finco"}  +1  (instead of +2)

RUNNING
-------
Requires a live CacheCore gateway.  Skipped automatically in unit-test CI.

    export CACHECORE_GATEWAY_URL=http://localhost:8080
    pytest tests/test_scenario_a_role_isolation.py -v -s
"""

from __future__ import annotations

import asyncio
import os

import httpx
import pytest

from cachecore import CacheCoreClient, CacheStatus
from tests.generate_token import generate_token

# ── Skip guard ─────────────────────────────────────────────────────────────────

GATEWAY_URL = os.environ.get("CACHECORE_GATEWAY_URL", "")

pytestmark = pytest.mark.skipif(
    not GATEWAY_URL,
    reason="Set CACHECORE_GATEWAY_URL to run live isolation scenarios",
)

# ── Shared query (semantically identical for both roles) ──────────────────────

COMPLIANCE_QUERY = {
    "model": "gpt-4o",
    "messages": [
        {
            "role": "system",
            "content": "You are a regulatory compliance assistant for financial institutions.",
        },
        {
            "role": "user",
            "content": (
                "Under MiFID II Article 25, what are the suitability assessment "
                "requirements for complex financial instruments?"
            ),
        },
    ],
}


# ── Helpers ────────────────────────────────────────────────────────────────────


def make_client(roles: list[str], scope: str) -> CacheCoreClient:
    """
    Create a CacheCoreClient for a finco agent with the given role claims.
    The JWT is signed with the standard dev secret — replace with your
    IdP's token endpoint in production.
    """
    jwt = generate_token(
        tenant_id="finco",
        roles=roles,
        scope=scope,
    )
    return CacheCoreClient(gateway_url=GATEWAY_URL, tenant_jwt=jwt, debug=True)


async def chat(client: CacheCoreClient, body: dict) -> CacheStatus:
    """
    Send one chat completion request via the given client.
    Returns the parsed CacheStatus from response headers.
    Using httpx directly (not via OpenAI SDK) gives us header access.
    """
    async with httpx.AsyncClient(
        transport=client.transport,
        base_url=GATEWAY_URL,
        timeout=60.0,
    ) as http:
        resp = await http.post("/v1/chat/completions", json=body)
        resp.raise_for_status()
        return CacheStatus.from_headers(resp.headers)


# ── Test ───────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_role_isolation_compliance_officer_vs_analyst() -> None:
    """
    Prove that the compliance_officer's cached entry is invisible to the analyst.

    Step 1: compliance_officer sends the query  → expect MISS  (cache cold)
    Step 2: compliance_officer sends it again   → expect HIT_L1 (proves cache works)
    Step 3: analyst sends the same query        → expect MISS  (isolated namespace)

    If step 3 returns HIT_L1 or HIT_L2, the namespaces are leaking.
    """
    async with make_client(
        roles=["compliance_officer"], scope="regulatory:read"
    ) as officer_client, make_client(
        roles=["analyst"], scope="regulatory:read"
    ) as analyst_client:

        # Step 1 — compliance_officer: cold cache → MISS, entry written
        status_1 = await chat(officer_client, COMPLIANCE_QUERY)
        assert status_1.status == "MISS", (
            f"Expected MISS on first officer request, got {status_1.status!r}. "
            "Flush Redis with: docker exec docker-redis-stack-1 redis-cli FLUSHDB"
        )

        # Let the async L2 vector write complete before querying again
        await asyncio.sleep(0.5)

        # Step 2 — compliance_officer: warm cache → HIT_L1
        status_2 = await chat(officer_client, COMPLIANCE_QUERY)
        assert status_2.status in ("HIT_L1", "HIT_L1_STALE"), (
            f"Expected HIT_L1 on officer repeat, got {status_2.status!r}. "
            "Cache is not writing correctly."
        )

        # Step 3 — analyst: same query, different namespace → must be MISS
        status_3 = await chat(analyst_client, COMPLIANCE_QUERY)
        assert status_3.status == "MISS", (
            f"ISOLATION FAILURE: analyst got {status_3.status!r} from a compliance_officer "
            "cache entry.  The role claim is not contributing to the namespace key.  "
            "Check that permission_claims includes 'roles' in config/gateway.toml."
        )


@pytest.mark.asyncio
async def test_role_isolation_is_symmetric() -> None:
    """
    Isolation works in both directions: analyst writes first, officer must not hit.

    This catches a scenario where the namespace derivation is correct for one
    direction but not the other (e.g., a perm_hash that sorts oddly).
    """
    async with make_client(
        roles=["analyst"], scope="regulatory:read"
    ) as analyst_client, make_client(
        roles=["compliance_officer"], scope="regulatory:read"
    ) as officer_client:

        # Analyst primes the cache
        status_a1 = await chat(analyst_client, COMPLIANCE_QUERY)
        assert status_a1.status == "MISS", (
            f"Expected MISS on first analyst request, got {status_a1.status!r}. "
            "Flush Redis between test runs."
        )

        await asyncio.sleep(0.5)

        # Analyst hits their own entry
        status_a2 = await chat(analyst_client, COMPLIANCE_QUERY)
        assert status_a2.status in ("HIT_L1", "HIT_L1_STALE"), (
            f"Analyst cache not working: got {status_a2.status!r}"
        )

        # Officer must not see analyst's entry
        status_o = await chat(officer_client, COMPLIANCE_QUERY)
        assert status_o.status == "MISS", (
            f"ISOLATION FAILURE: compliance_officer got {status_o.status!r} from an "
            "analyst cache entry."
        )
