"""
Tests for the cachecore client library.

Run:  pytest tests/ -v
"""

from __future__ import annotations

import asyncio
import base64
import json
from unittest.mock import AsyncMock

import httpx
import pytest

from cachecore import (
    CacheCoreClient,
    CacheStatus,
    Dep,
    DepDeclaration,
    InvalidateResult,
)
from cachecore._context import _encode_deps
from cachecore._transport import (
    CacheCoreTransport,
    _HDR_CACHE,
    _HDR_DEPS,
    _HDR_SIMILARITY,
    _HDR_TOKEN,
)
from cachecore.errors import CacheCoreAuthError, CacheCoreRateLimitError


# ── Helpers ─────────────────────────────────────────────────────────────


class _FakeTransport(httpx.AsyncBaseTransport):
    """Captures the request and returns a canned response."""

    def __init__(self, status: int = 200, headers: dict | None = None, body: bytes = b"{}"):
        self.last_request: httpx.Request | None = None
        self._status = status
        self._headers = headers or {}
        self._body = body

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        self.last_request = request
        return httpx.Response(
            status_code=self._status,
            headers=self._headers,
            content=self._body,
        )


# ── Dep encoding ────────────────────────────────────────────────────────


class TestDepEncoding:
    def test_single_dep_encodes_correctly(self):
        deps = [Dep("table:products", hash="v3")]
        encoded = _encode_deps(deps)
        decoded = json.loads(base64.urlsafe_b64decode(encoded + "=="))
        assert decoded == [{"dep_id": "table:products", "expected_hash": "v3"}]

    def test_multiple_deps(self):
        deps = [Dep("table:products"), Dep("table:orders", hash="abc")]
        encoded = _encode_deps(deps)
        decoded = json.loads(base64.urlsafe_b64decode(encoded + "=="))
        assert len(decoded) == 2
        assert decoded[0]["dep_id"] == "table:products"
        assert decoded[0]["expected_hash"] == "v1"  # default
        assert decoded[1]["expected_hash"] == "abc"

    def test_empty_deps(self):
        encoded = _encode_deps([])
        decoded = json.loads(base64.urlsafe_b64decode(encoded + "=="))
        assert decoded == []

    def test_no_base64_padding(self):
        """The gateway expects no-padding base64url."""
        encoded = _encode_deps([Dep("x")])
        assert "=" not in encoded


# ── Dep class ───────────────────────────────────────────────────────────


class TestDep:
    def test_default_hash(self):
        d = Dep("table:products")
        assert d.expected_hash == "v1"

    def test_explicit_hash(self):
        d = Dep("table:products", hash="abc123")
        assert d.expected_hash == "abc123"

    def test_alias(self):
        assert Dep is DepDeclaration

    def test_repr_simple(self):
        assert repr(Dep("x")) == "Dep('x')"

    def test_repr_with_hash(self):
        assert repr(Dep("x", hash="h")) == "Dep('x', hash='h')"

    def test_equality(self):
        assert Dep("a") == Dep("a")
        assert Dep("a", hash="1") != Dep("a", hash="2")

    def test_hashable(self):
        s = {Dep("a"), Dep("a"), Dep("b")}
        assert len(s) == 2


# ── Transport ───────────────────────────────────────────────────────────


class TestTransport:
    @pytest.mark.asyncio
    async def test_injects_token_header(self):
        fake = _FakeTransport()
        transport = CacheCoreTransport(jwt="test-jwt", wrapped=fake)

        request = httpx.Request("POST", "http://localhost:8080/v1/chat/completions")
        await transport.handle_async_request(request)

        assert fake.last_request is not None
        assert fake.last_request.headers[_HDR_TOKEN] == "test-jwt"

    @pytest.mark.asyncio
    async def test_injects_deps_header(self):
        fake = _FakeTransport()
        transport = CacheCoreTransport(jwt="jwt", wrapped=fake)
        client = CacheCoreClient.__new__(CacheCoreClient)

        # Manually set context (simulating request_context)
        from cachecore._context import _RequestContext, _ctx

        token = _ctx.set(_RequestContext(deps=[Dep("table:x", hash="v2")], bypass=False))
        try:
            request = httpx.Request("POST", "http://localhost:8080/v1/chat/completions")
            await transport.handle_async_request(request)

            assert _HDR_DEPS in fake.last_request.headers
            raw = fake.last_request.headers[_HDR_DEPS]
            decoded = json.loads(base64.urlsafe_b64decode(raw + "=="))
            assert decoded == [{"dep_id": "table:x", "expected_hash": "v2"}]
        finally:
            _ctx.reset(token)

    @pytest.mark.asyncio
    async def test_bypass_omits_token(self):
        fake = _FakeTransport()
        transport = CacheCoreTransport(jwt="jwt", wrapped=fake)

        from cachecore._context import _RequestContext, _ctx

        token = _ctx.set(_RequestContext(deps=[], bypass=True))
        try:
            request = httpx.Request("POST", "http://localhost:8080/v1/chat/completions")
            await transport.handle_async_request(request)

            assert _HDR_TOKEN not in fake.last_request.headers
        finally:
            _ctx.reset(token)

    @pytest.mark.asyncio
    async def test_no_context_still_injects_token(self):
        """When no request_context is set, token is still injected (default path)."""
        fake = _FakeTransport()
        transport = CacheCoreTransport(jwt="jwt", wrapped=fake)

        request = httpx.Request("POST", "http://localhost:8080/v1/chat/completions")
        await transport.handle_async_request(request)

        assert fake.last_request.headers[_HDR_TOKEN] == "jwt"
        assert _HDR_DEPS not in fake.last_request.headers


# ── CacheStatus ─────────────────────────────────────────────────────────


class TestCacheStatus:
    def test_parse_hit_l1(self):
        headers = httpx.Headers({
            _HDR_CACHE: "HIT_L1",
            _HDR_SIMILARITY: "1.00",
            "X-Cache-Age": "42",
        })
        cs = CacheStatus.from_headers(headers)
        assert cs.status == "HIT_L1"
        assert cs.similarity == 1.0
        assert cs.age_seconds == 42

    def test_parse_miss(self):
        headers = httpx.Headers({_HDR_CACHE: "MISS"})
        cs = CacheStatus.from_headers(headers)
        assert cs.status == "MISS"
        assert cs.similarity == 0.0
        assert cs.age_seconds == 0

    def test_parse_unknown(self):
        headers = httpx.Headers({})
        cs = CacheStatus.from_headers(headers)
        assert cs.status == "UNKNOWN"

    def test_parse_bad_values(self):
        headers = httpx.Headers({
            _HDR_CACHE: "HIT_L2",
            _HDR_SIMILARITY: "not-a-number",
            "X-Cache-Age": "also-bad",
        })
        cs = CacheStatus.from_headers(headers)
        assert cs.status == "HIT_L2"
        assert cs.similarity == 0.0
        assert cs.age_seconds == 0


# ── Client request_context ──────────────────────────────────────────────


class TestRequestContext:
    @pytest.mark.asyncio
    async def test_context_sets_and_resets(self):
        from cachecore._context import _ctx

        cc = CacheCoreClient(
            gateway_url="http://localhost:8080",
            tenant_jwt="jwt",
        )

        assert _ctx.get() is None
        with cc.request_context(deps=[Dep("a")]):
            ctx = _ctx.get()
            assert ctx is not None
            assert len(ctx.deps) == 1
            assert ctx.deps[0].dep_id == "a"
        assert _ctx.get() is None

        await cc.aclose()

    @pytest.mark.asyncio
    async def test_context_resets_on_exception(self):
        from cachecore._context import _ctx

        cc = CacheCoreClient(gateway_url="http://x", tenant_jwt="jwt")

        with pytest.raises(ValueError):
            with cc.request_context(deps=[Dep("a")]):
                raise ValueError("boom")

        assert _ctx.get() is None
        await cc.aclose()

    @pytest.mark.asyncio
    async def test_bypass_context(self):
        from cachecore._context import _ctx

        cc = CacheCoreClient(gateway_url="http://x", tenant_jwt="jwt")
        with cc.request_context(bypass=True):
            ctx = _ctx.get()
            assert ctx is not None
            assert ctx.bypass is True
        await cc.aclose()


# ── Client async context manager ────────────────────────────────────────


class TestClientLifecycle:
    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        async with CacheCoreClient(gateway_url="http://x", tenant_jwt="jwt") as cc:
            assert cc.transport is not None
        # Should not raise after close


# ── Header name correctness (regression for Bug 1) ─────────────────────


class TestHeaderNames:
    def test_token_header_is_x_cachecore_token(self):
        """Must match proxy.rs — NOT 'X-Cache-Token'."""
        assert _HDR_TOKEN == "X-CacheCore-Token"

    def test_deps_header_is_x_cachecore_deps(self):
        """Must match proxy.rs — NOT 'X-Cache-Deps'."""
        assert _HDR_DEPS == "X-CacheCore-Deps"
