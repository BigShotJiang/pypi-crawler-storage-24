"""
Scenario B — SaaS Platform: Multi-Tenant Isolation
====================================================

Two enterprise tenants on shared CacheCore infrastructure:
  - acme-corp   — Acme Corporation's LLM agents
  - beta-inc    — Beta Inc's LLM agents

Both tenants run identical workloads (same roles, same prompts, same model).
The test proves that a cache hit for acme-corp is completely invisible to
beta-inc: even when the semantic query is word-for-word identical, tenant B
must never receive a cache hit from tenant A's prior request.

HOW IT WORKS
------------
The tenant_id claim is always an input to the CacheCore namespace key:

    SHA256(tenant_id || perm_hash || system_fp || toolset_fp || policy_version)

Different tenant_id values guarantee different namespace keys regardless of
any other claim.  No configuration is required — tenant isolation is on by
default and cannot be turned off.

REQUIRED GATEWAY CONFIG
-----------------------
None.  Tenant isolation is unconditional.

EXPECTED PROMETHEUS METRICS AFTER THIS TEST RUNS
-------------------------------------------------
Separate per-tenant counters confirm that no cross-tenant hit occurs:

cachecore_requests_total{status="miss",   tenant_id="acme-corp"}  +1
cachecore_requests_total{status="hit_l1", tenant_id="acme-corp"}  +1
cachecore_requests_total{status="miss",   tenant_id="beta-inc"}   +1

If isolation breaks, beta-inc would show a hit instead of a miss:
cachecore_requests_total{status="hit_l1", tenant_id="beta-inc"}   +1  (bug: namespace bleed)

Grafana query to check live:
    sum by (tenant_id, status) (
        increase(cachecore_requests_total[$__range])
    )

RUNNING
-------
Requires a live CacheCore gateway.  Skipped automatically in unit-test CI.

    export CACHECORE_GATEWAY_URL=http://localhost:8080
    pytest tests/test_scenario_b_tenant_isolation.py -v -s
"""

from __future__ import annotations

import asyncio
import os

import httpx
import pytest

from cachecore import CacheCoreClient, CacheStatus
from tests.generate_token import generate_token

# ── Skip guard ─────────────────────────────────────────────────────────────────

GATEWAY_URL = os.environ.get("CACHECORE_GATEWAY_URL", "")

pytestmark = pytest.mark.skipif(
    not GATEWAY_URL,
    reason="Set CACHECORE_GATEWAY_URL to run live isolation scenarios",
)

# ── Shared query (identical for both tenants) ──────────────────────────────────

SAAS_QUERY = {
    "model": "gpt-4o",
    "messages": [
        {
            "role": "system",
            "content": (
                "You are a helpful assistant for a project management platform. "
                "Answer concisely."
            ),
        },
        {
            "role": "user",
            "content": "What are the top three risks for a software project that is running two weeks behind schedule?",
        },
    ],
}


# ── Helpers ────────────────────────────────────────────────────────────────────


def make_client(tenant_id: str) -> CacheCoreClient:
    """
    Create a CacheCoreClient for the given tenant.
    Both tenants use the same roles and scope to ensure the ONLY
    distinguishing input to the namespace key is tenant_id.
    """
    jwt = generate_token(
        tenant_id=tenant_id,
        roles=["user"],
        scope="projects:read",
    )
    return CacheCoreClient(gateway_url=GATEWAY_URL, tenant_jwt=jwt, debug=True)


async def chat(client: CacheCoreClient, body: dict) -> CacheStatus:
    """
    Send one chat completion request via the given client.
    Returns the parsed CacheStatus from response headers.
    """
    async with httpx.AsyncClient(
        transport=client.transport,
        base_url=GATEWAY_URL,
        timeout=60.0,
    ) as http:
        resp = await http.post("/v1/chat/completions", json=body)
        resp.raise_for_status()
        return CacheStatus.from_headers(resp.headers)


# ── Tests ──────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_tenant_isolation_no_cross_bleed() -> None:
    """
    Prove that acme-corp's cached entry is invisible to beta-inc.

    Step 1: acme-corp sends the query  → expect MISS  (cache cold)
    Step 2: acme-corp sends it again   → expect HIT_L1 (proves cache works)
    Step 3: beta-inc sends same query  → expect MISS  (isolated namespace)

    If step 3 returns a hit, tenant namespaces are leaking.
    """
    async with make_client("acme-corp") as acme_client, make_client(
        "beta-inc"
    ) as beta_client:

        # Step 1 — acme-corp: cold cache → MISS, entry written
        status_1 = await chat(acme_client, SAAS_QUERY)
        assert status_1.status == "MISS", (
            f"Expected MISS on first acme-corp request, got {status_1.status!r}. "
            "Flush Redis with: docker exec docker-redis-stack-1 redis-cli FLUSHDB"
        )

        # Let the async L2 vector write complete
        await asyncio.sleep(0.5)

        # Step 2 — acme-corp: warm cache → HIT_L1
        status_2 = await chat(acme_client, SAAS_QUERY)
        assert status_2.status in ("HIT_L1", "HIT_L1_STALE"), (
            f"Expected HIT_L1 on acme-corp repeat, got {status_2.status!r}. "
            "Cache is not writing correctly."
        )

        # Step 3 — beta-inc: same query, different tenant → must be MISS
        status_3 = await chat(beta_client, SAAS_QUERY)
        assert status_3.status == "MISS", (
            f"ISOLATION FAILURE: beta-inc got {status_3.status!r} from an acme-corp "
            "cache entry.  Tenant isolation is broken — the tenant_id claim is not "
            "contributing to the namespace key.  This is a critical security defect."
        )


@pytest.mark.asyncio
async def test_tenant_isolation_reverse_direction() -> None:
    """
    beta-inc writes first, acme-corp must not hit.

    Tests the symmetric direction to rule out ordering-dependent bugs.
    """
    async with make_client("beta-inc") as beta_client, make_client(
        "acme-corp"
    ) as acme_client:

        # beta-inc primes the cache
        status_b1 = await chat(beta_client, SAAS_QUERY)
        assert status_b1.status == "MISS", (
            f"Expected MISS on first beta-inc request, got {status_b1.status!r}. "
            "Flush Redis between test runs."
        )

        await asyncio.sleep(0.5)

        # beta-inc hits their own entry
        status_b2 = await chat(beta_client, SAAS_QUERY)
        assert status_b2.status in ("HIT_L1", "HIT_L1_STALE"), (
            f"beta-inc cache not working: got {status_b2.status!r}"
        )

        # acme-corp must not see beta-inc's entry
        status_a = await chat(acme_client, SAAS_QUERY)
        assert status_a.status == "MISS", (
            f"ISOLATION FAILURE: acme-corp got {status_a.status!r} from a "
            "beta-inc cache entry."
        )


@pytest.mark.asyncio
async def test_tenant_isolation_with_dep_declaration() -> None:
    """
    Tenant isolation holds even when both tenants declare the same dep_id.

    This is a subtle edge case: if dep tracking accidentally shares state across
    tenants (e.g., the cc:dep:keys: set), a dep invalidation by one tenant
    could evict another tenant's entries.  Verify the entries stay separate.
    """
    from cachecore import Dep

    async with make_client("acme-corp") as acme_client, make_client(
        "beta-inc"
    ) as beta_client:

        shared_dep = [Dep("tool:risk-engine", hash="v1")]

        # Both tenants write entries with the same dep_id
        async with httpx.AsyncClient(
            transport=acme_client.transport, base_url=GATEWAY_URL, timeout=60.0
        ) as http:
            with acme_client.request_context(deps=shared_dep):
                resp = await http.post("/v1/chat/completions", json=SAAS_QUERY)
                assert CacheStatus.from_headers(resp.headers).status == "MISS"

        await asyncio.sleep(0.5)

        async with httpx.AsyncClient(
            transport=beta_client.transport, base_url=GATEWAY_URL, timeout=60.0
        ) as http:
            with beta_client.request_context(deps=shared_dep):
                resp = await http.post("/v1/chat/completions", json=SAAS_QUERY)
                # beta-inc writes its own copy under its own namespace
                assert CacheStatus.from_headers(resp.headers).status == "MISS"

        await asyncio.sleep(0.5)

        # Now confirm both tenants have hits in their own namespace
        async with httpx.AsyncClient(
            transport=acme_client.transport, base_url=GATEWAY_URL, timeout=60.0
        ) as http:
            with acme_client.request_context(deps=shared_dep):
                resp = await http.post("/v1/chat/completions", json=SAAS_QUERY)
                acme_status = CacheStatus.from_headers(resp.headers)
                assert acme_status.status in ("HIT_L1", "HIT_L1_STALE"), (
                    f"acme-corp cache not working with deps: {acme_status.status!r}"
                )

        async with httpx.AsyncClient(
            transport=beta_client.transport, base_url=GATEWAY_URL, timeout=60.0
        ) as http:
            with beta_client.request_context(deps=shared_dep):
                resp = await http.post("/v1/chat/completions", json=SAAS_QUERY)
                beta_status = CacheStatus.from_headers(resp.headers)
                assert beta_status.status in ("HIT_L1", "HIT_L1_STALE"), (
                    f"beta-inc cache not working with deps: {beta_status.status!r}"
                )
