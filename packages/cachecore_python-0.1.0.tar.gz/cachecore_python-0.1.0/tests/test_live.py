import asyncio, httpx
from openai import AsyncOpenAI
from cachecore import CacheCoreClient, Dep

async def main():
    cc = CacheCoreClient(
        gateway_url="http://localhost:8080",
        tenant_jwt="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiJ0ZXN0Iiwicm9sZXMiOlsiYWRtaW4iXSwic2NvcGUiOiJvcmRlcnM6cmVhZCIsImV4cCI6MTc3MzUyMDgyN30.u_xQDTo2poaP6PLA1T98pVhZN0lsE3DY7T1cbG11yfg",
        debug=True,
    )
    oai = AsyncOpenAI(
        api_key="ignored",
        base_url="http://localhost:8080/v1",
        http_client=httpx.AsyncClient(transport=cc.transport),
    )

    # 1. L1 hit test
    msg_a = [{"role": "user", "content": "What is 2+2? Answer in one word."}]
    r1 = await oai.chat.completions.create(model="gpt-5.4", messages=msg_a)
    r2 = await oai.chat.completions.create(model="gpt-5.4", messages=msg_a)

    # 2. Dep + invalidation test — semantically distant prompt
    msg_b = [{"role": "user", "content": "Name the three largest oceans by surface area."}]
    with cc.request_context(deps=[Dep("test:smoke")]):
        r3 = await oai.chat.completions.create(model="gpt-5.4", messages=msg_b)

    await asyncio.sleep(0.5)  # let L2 vector write complete
    # r3 must be MISS → new entry written WITH test:smoke dep

    result = await cc.invalidate("test:smoke")
    print(f"Invalidated: {result}")
    # Gateway should now log count=1

    with cc.request_context(deps=[Dep("test:smoke")]):
        r4 = await oai.chat.completions.create(model="gpt-5.4", messages=msg_b)
    # r4 should be MISS (invalidation cleared the entry)

    await cc.aclose()

asyncio.run(main())