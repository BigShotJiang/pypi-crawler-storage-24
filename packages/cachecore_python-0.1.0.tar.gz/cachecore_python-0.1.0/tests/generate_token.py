#!/usr/bin/env python3
"""
Generate a JWT token for testing the gateway.

Usage:
    python generate_token.py
    
The token will be saved to token.txt and also printed to stdout.
Use it in your curl command like:
    curl -H "X-CacheCore-Token: $(cat harness/token.txt)" ...
"""

from jwt.api_jwt import encode
import time

JWT_SECRET = "dev-secret-change-me-32bytes-ok!"

def generate_token(tenant_id="test", roles=None, scope="orders:read"):
    if roles is None:
        roles = ["admin"]
    token = encode({
        "tenant_id": tenant_id,
        "roles": roles,
        "scope": scope,
        "exp": int(time.time()) + 3600
    }, JWT_SECRET, algorithm="HS256")
    return token

if __name__ == "__main__":
    token = generate_token()
    # Save to file (no newline)
    with open("token.txt", "w") as f:
        f.write(token)
    print(f"Token saved to token.txt")
    print(f"Token length: {len(token)}")
    print(f"Token: {token}")
    print(f"\nUse in curl:")
    print(f'curl -H "X-CacheCore-Token: $(cat harness/token.txt)" ...')
