import nltk

def setup():

    packages = [
        "vader_lexicon",
        "stopwords",
        "punkt",
        "wordnet"
    ]

    for p in packages:
        nltk.download(p)
