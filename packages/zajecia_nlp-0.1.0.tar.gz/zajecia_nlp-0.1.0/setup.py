from setuptools import setup, find_packages

setup(
    name="zajecia_nlp",
    version="0.1.0",
    description="Minimal NLP environment for course labs",
    author="Chris",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "pandas>=1.5",
        "numpy>=1.23",
        "matplotlib>=3.6",
        "scikit-learn>=1.2",
        "wordcloud>=1.9",
        "nltk>=3.8",
        "pillow>=9.0",
        "ipykernel>=6.0"
    ],
)
