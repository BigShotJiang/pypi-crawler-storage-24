"""Version information for sagellm-control-plane."""

__version__ = "0.5.4.12"
__author__ = "IntelliStream Team"
