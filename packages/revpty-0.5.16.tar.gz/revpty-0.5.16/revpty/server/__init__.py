"""Router for session management"""
