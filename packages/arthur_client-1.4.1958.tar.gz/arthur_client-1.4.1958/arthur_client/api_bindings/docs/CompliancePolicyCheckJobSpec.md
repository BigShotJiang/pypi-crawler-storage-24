# CompliancePolicyCheckJobSpec


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_type** | **str** |  | [optional] [default to 'compliance_policy_check']
**scope_model_id** | **str** | The id of the model to run compliance policy checks on. | 
**policy_assignment_id** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.compliance_policy_check_job_spec import CompliancePolicyCheckJobSpec

# TODO update the JSON string below
json = "{}"
# create an instance of CompliancePolicyCheckJobSpec from a JSON string
compliance_policy_check_job_spec_instance = CompliancePolicyCheckJobSpec.from_json(json)
# print the JSON string representation of the object
print(CompliancePolicyCheckJobSpec.to_json())

# convert the object into a dict
compliance_policy_check_job_spec_dict = compliance_policy_check_job_spec_instance.to_dict()
# create an instance of CompliancePolicyCheckJobSpec from a dict
compliance_policy_check_job_spec_from_dict = CompliancePolicyCheckJobSpec.from_dict(compliance_policy_check_job_spec_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


