# PostPolicyAlertRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of the policy alert rule. | 
**description** | **str** |  | [optional] 
**threshold** | **float** | The threshold that will trigger the alert rule. | 
**bound** | [**AlertBound**](AlertBound.md) | The bound of the alert rule. | 
**query** | **str** | The SQL query for the alert rule. | 
**metric_name** | **str** | The name of the metric returned by the query. | 

## Example

```python
from arthur_client.api_bindings.models.post_policy_alert_rule import PostPolicyAlertRule

# TODO update the JSON string below
json = "{}"
# create an instance of PostPolicyAlertRule from a JSON string
post_policy_alert_rule_instance = PostPolicyAlertRule.from_json(json)
# print the JSON string representation of the object
print(PostPolicyAlertRule.to_json())

# convert the object into a dict
post_policy_alert_rule_dict = post_policy_alert_rule_instance.to_dict()
# create an instance of PostPolicyAlertRule from a dict
post_policy_alert_rule_from_dict = PostPolicyAlertRule.from_dict(post_policy_alert_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


