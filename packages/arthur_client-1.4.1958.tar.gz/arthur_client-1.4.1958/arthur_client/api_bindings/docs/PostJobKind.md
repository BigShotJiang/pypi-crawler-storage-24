# PostJobKind

The set of jobs that are available to submit via the PostJobs API Notably, this does not include the fetch_data or test_custom_aggregation jobs, as there are dedicated endpoints for those

## Enum

* `METRICS_CALCULATION` (value: `'metrics_calculation'`)

* `CONNECTOR_CHECK` (value: `'connector_check'`)

* `LIST_DATASETS` (value: `'list_datasets'`)

* `SCHEMA_INSPECTION` (value: `'schema_inspection'`)

* `ALERT_CHECK` (value: `'alert_check'`)

* `SCHEDULE_JOBS` (value: `'schedule_jobs'`)

* `DISCOVER_AGENTS` (value: `'discover_agents'`)

* `COMPLIANCE_POLICY_CHECK` (value: `'compliance_policy_check'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


