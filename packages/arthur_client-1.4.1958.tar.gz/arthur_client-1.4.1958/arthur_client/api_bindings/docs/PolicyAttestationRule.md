# PolicyAttestationRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Time of record creation. | 
**updated_at** | **datetime** | Time of last record update. | 
**id** | **str** | The ID of the attestation rule. | 
**policy_id** | **str** | The ID of the parent policy. | 
**name** | **str** | The name of the attestation rule. | 
**description** | **str** |  | [optional] 
**validity_period_days** | **int** | The validity period in days for attestation. | 

## Example

```python
from arthur_client.api_bindings.models.policy_attestation_rule import PolicyAttestationRule

# TODO update the JSON string below
json = "{}"
# create an instance of PolicyAttestationRule from a JSON string
policy_attestation_rule_instance = PolicyAttestationRule.from_json(json)
# print the JSON string representation of the object
print(PolicyAttestationRule.to_json())

# convert the object into a dict
policy_attestation_rule_dict = policy_attestation_rule_instance.to_dict()
# create an instance of PolicyAttestationRule from a dict
policy_attestation_rule_from_dict = PolicyAttestationRule.from_dict(policy_attestation_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


