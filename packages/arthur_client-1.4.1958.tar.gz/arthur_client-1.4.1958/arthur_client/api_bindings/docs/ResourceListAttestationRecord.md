# ResourceListAttestationRecord


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[AttestationRecord]**](AttestationRecord.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_attestation_record import ResourceListAttestationRecord

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListAttestationRecord from a JSON string
resource_list_attestation_record_instance = ResourceListAttestationRecord.from_json(json)
# print the JSON string representation of the object
print(ResourceListAttestationRecord.to_json())

# convert the object into a dict
resource_list_attestation_record_dict = resource_list_attestation_record_instance.to_dict()
# create an instance of ResourceListAttestationRecord from a dict
resource_list_attestation_record_from_dict = ResourceListAttestationRecord.from_dict(resource_list_attestation_record_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


