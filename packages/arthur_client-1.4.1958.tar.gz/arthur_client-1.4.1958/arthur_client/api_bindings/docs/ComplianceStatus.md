# ComplianceStatus


## Enum

* `PENDING` (value: `'PENDING'`)

* `COMPLIANT` (value: `'COMPLIANT'`)

* `NON_COMPLIANT` (value: `'NON_COMPLIANT'`)

* `NEEDS_ATTENTION` (value: `'NEEDS_ATTENTION'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


