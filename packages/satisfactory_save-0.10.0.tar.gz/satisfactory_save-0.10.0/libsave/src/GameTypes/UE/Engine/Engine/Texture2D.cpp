#include "GameTypes/UE/Engine/Engine/Texture2D.h"

#include "GameTypes/UE/Core/UObject/NameTypes.h"
#include "GameTypes/UE/Engine/EngineUtils.h"

void SatisfactorySave::UTexture2D::serialize(Archive& ar) {
    if (!ar.isIArchive()) {
        throw std::runtime_error("Only IStreamArchive support implemented!");
    }

    UObject::serialize(ar);

    // UTexture::Serialize
    // https://github.com/EpicGames/UnrealEngine/blob/5.6.1-release/Engine/Source/Runtime/Engine/Private/Texture.cpp#L1055

    FStripDataFlags flags;
    ar << flags;
    flags.validateOnlyEditorDataIsStripped();

    // UTexture2D::Serialize
    // https://github.com/EpicGames/UnrealEngine/blob/5.3.2-release/Engine/Source/Runtime/Engine/Private/Texture2D.cpp#L451

    ar << flags;
    flags.validateOnlyEditorDataIsStripped();

    bool bCooked = false;
    ar << bCooked;

    bool bSerializeMipData = true;
    ar << bSerializeMipData;

    if (!bSerializeMipData) {
        throw std::runtime_error("bSerializeMipData == false not implemented!");
    }

    // UTexture::SerializeCookedPlatformData
    // https://github.com/EpicGames/UnrealEngine/blob/5.3.2-release/Engine/Source/Runtime/Engine/Private/TextureDerivedData.cpp#L3647

    FName PixelFormatName;
    ar << PixelFormatName;

    while (PixelFormatName != "None") {
        int64_t SkipOffset = 0;
        ar << SkipOffset;

        ar << RunningPlatformData;

        ar << PixelFormatName;

        // Check that second entry is none, for now expect only one entry.
        if (PixelFormatName != "None") {
            throw std::runtime_error("more than one entry not implemented!");
        }
    }
}
