from dataclasses import dataclass
from typing import Optional


@dataclass
class ServiceConfig:
    nats_subject_time: Optional[str] = None
    nats_subject_api_vessel_vectors_asof: Optional[str] = None
    nats_subject_api_vessel_cargos_asof: Optional[str] = None
    nats_subject_api_health: Optional[str] = None
    nats_subject_db_update_spire_vectors: Optional[str] = None
    nats_subject_db_update_fakedata_cargos: Optional[str] = None
    nats_subject_db_update_spire_vessel_info: Optional[str] = None
    nats_subject_db_update_gem_terminals: Optional[str] = None
    nats_kv_api_bucket: Optional[str] = None
    nats_subject_api_stub_request_json: Optional[str] = None
    nats_subject_api_stub_request_ipc: Optional[str] = None
    mariadb_table_spire_vectors: Optional[str] = None
    mariadb_table_fakedata_cargos: Optional[str] = None
    mariadb_table_spire_vessel_info: Optional[str] = None
    mariadb_table_mt_vessel_info: Optional[str] = None
    mariadb_table_gem_terminals: Optional[str] = None
    nats_kv_api_key_vessel_vectors_latest: Optional[str] = None
    nats_kv_api_key_vessel_cargos_latest: Optional[str] = None
    nats_kv_api_key_vessel_info_latest: Optional[str] = None
    nats_kv_api_key_earliest_vectors_dataset_date_utc: Optional[str] = None
    nats_kv_api_key_terminals_latest: Optional[str] = None
