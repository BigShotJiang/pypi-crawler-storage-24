import json
from datetime import datetime, timezone

from pyapi_service_kit.nats.nats_payload import NatsPayload


class TestNatsPayload:
    def test_json_payload(self):
        payload = NatsPayload(type="json", data={"key": "value"})
        result = json.loads(payload.as_bytes())
        assert result["type"] == "json"
        assert result["data"] == {"key": "value"}

    def test_epoch_ms_from_int(self):
        payload = NatsPayload(type="epoch_ms", data=1704067200000)
        result = json.loads(payload.as_bytes())
        assert result["type"] == "epoch_ms"
        assert result["data"] == 1704067200000

    def test_epoch_ms_from_datetime(self):
        dt = datetime(2024, 1, 1, tzinfo=timezone.utc)
        payload = NatsPayload(type="epoch_ms", data=dt)
        result = json.loads(payload.as_bytes())
        assert result["data"] == 1704067200000

    def test_error_payload(self):
        payload = NatsPayload(type="error", data="something went wrong")
        result = json.loads(payload.as_bytes())
        assert result["type"] == "error"
        assert result["data"] == "something went wrong"

    def test_extra_included(self):
        payload = NatsPayload(type="json", data={}, extra={"meta": 1})
        result = json.loads(payload.as_bytes())
        assert result["extra"] == {"meta": 1}

    def test_extra_omitted_when_none(self):
        payload = NatsPayload(type="json", data={})
        result = json.loads(payload.as_bytes())
        assert "extra" not in result

    def test_str_json(self):
        payload = NatsPayload(type="json", data=[1, 2, 3])
        assert "len=3" in str(payload)

    def test_str_epoch_ms(self):
        payload = NatsPayload(type="epoch_ms", data=123)
        assert "timestamp=123" in str(payload)

    def test_str_error(self):
        payload = NatsPayload(type="error", data="oops")
        assert "error=oops" in str(payload)
