from pyapi_service_kit.service.config import ServiceConfig


class TestServiceConfig:
    def test_defaults_to_none(self):
        cfg = ServiceConfig()
        assert cfg.nats_subject_time is None
        assert cfg.nats_kv_api_bucket is None

    def test_with_nats_subject(self):
        cfg = ServiceConfig(nats_subject_time="time.updates")
        assert cfg.nats_subject_time == "time.updates"

    def test_with_table_config(self):
        cfg = ServiceConfig(mariadb_table_spire_vectors="spire.vectors")
        assert cfg.mariadb_table_spire_vectors == "spire.vectors"

    def test_with_kv_key(self):
        cfg = ServiceConfig(
            nats_kv_api_key_vessel_vectors_latest="vessel_vectors_latest"
        )
        assert cfg.nats_kv_api_key_vessel_vectors_latest == "vessel_vectors_latest"
