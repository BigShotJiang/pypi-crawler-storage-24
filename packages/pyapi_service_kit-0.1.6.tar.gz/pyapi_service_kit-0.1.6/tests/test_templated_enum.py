import pytest

from pyapi_service_kit.utils.templated_enum import TemplatedEnum


class MySubjects(TemplatedEnum):
    TOPIC_A = "prefix.{env}.topic_a"
    TOPIC_B = "prefix.{env}.topic_b"


class TestTemplatedEnum:
    def setup_method(self):
        MySubjects.remove_resolver()

    def test_template_property(self):
        assert MySubjects.TOPIC_A.template == "prefix.{env}.topic_a"

    def test_value_access_blocked(self):
        with pytest.raises(AttributeError):
            _ = MySubjects.TOPIC_A.value

    def test_resolved_without_resolver_raises(self):
        with pytest.raises(RuntimeError, match="Resolver not set"):
            _ = MySubjects.TOPIC_A.resolved

    def test_resolved_with_resolver(self):
        MySubjects.set_resolver(lambda t: t.format(env="prod"))
        assert MySubjects.TOPIC_A.resolved == "prefix.prod.topic_a"

    def test_remove_resolver(self):
        MySubjects.set_resolver(lambda t: t)
        MySubjects.remove_resolver()
        with pytest.raises(RuntimeError, match="Resolver not set"):
            _ = MySubjects.TOPIC_A.resolved

    def test_raw_value(self):
        assert MySubjects.TOPIC_A.raw_value == "prefix.{env}.topic_a"

    def test_repr(self):
        assert repr(MySubjects.TOPIC_A) == "MySubjects.TOPIC_A"

    def test_str_with_resolver(self):
        MySubjects.set_resolver(lambda t: t.format(env="dev"))
        assert str(MySubjects.TOPIC_A) == "prefix.dev.topic_a"

    def test_str_without_resolver_shows_error(self):
        s = str(MySubjects.TOPIC_A)
        assert "ERROR" in s

    def test_set_resolver_non_callable_raises(self):
        with pytest.raises(TypeError, match="callable"):
            MySubjects.set_resolver("not_callable")  # type: ignore[arg-type]

    def test_empty_template_raises(self):
        with pytest.raises(ValueError, match="empty"):

            class Bad(TemplatedEnum):
                X = "   "
