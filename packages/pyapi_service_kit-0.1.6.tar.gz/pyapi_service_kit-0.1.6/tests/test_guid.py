import pytest

from pyapi_service_kit.service.guid import validate_guid


class TestValidateGuid:
    def test_valid_alphanumeric(self):
        assert validate_guid("abc123") == "abc123"

    def test_valid_with_hyphens(self):
        assert validate_guid("my-service-01") == "my-service-01"

    def test_valid_with_underscores(self):
        assert validate_guid("my_service_01") == "my_service_01"

    def test_strips_whitespace(self):
        assert validate_guid("  abc123  ") == "abc123"

    def test_empty_string_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            validate_guid("")

    def test_whitespace_only_raises(self):
        with pytest.raises(ValueError, match="empty or whitespace"):
            validate_guid("   ")

    def test_none_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            validate_guid(None)  # type: ignore[arg-type]

    def test_invalid_chars_raises(self):
        with pytest.raises(ValueError, match="invalid characters"):
            validate_guid("hello world")

    def test_dots_rejected(self):
        with pytest.raises(ValueError, match="invalid characters"):
            validate_guid("my.service")
