import pytest

from pyapi_service_kit.time.parser import parse_granularity, parse_zoned_iso


class TestParseGranularity:
    def test_seconds(self):
        assert parse_granularity("20s") == 20_000

    def test_minutes(self):
        assert parse_granularity("1m") == 60_000

    def test_hours(self):
        assert parse_granularity("5h") == 18_000_000

    def test_days(self):
        assert parse_granularity("1d") == 86_400_000

    def test_fractional(self):
        assert parse_granularity("0.5s") == 500

    def test_uppercase_normalised(self):
        assert parse_granularity("20S") == 20_000

    def test_whitespace_stripped(self):
        assert parse_granularity("  1m  ") == 60_000

    def test_invalid_suffix_raises(self):
        with pytest.raises(ValueError, match="Invalid granularity"):
            parse_granularity("20x")

    def test_no_suffix_raises(self):
        with pytest.raises(ValueError, match="Invalid granularity"):
            parse_granularity("20")


class TestParseZonedIso:
    def test_plain_iso(self):
        dt = parse_zoned_iso("2024-01-01T12:00:00+00:00")
        assert dt.year == 2024
        assert dt.hour == 12

    def test_with_timezone_bracket(self):
        dt = parse_zoned_iso("2024-01-01T12:00:00+00:00[UTC]")
        assert dt.tzname() == "UTC"

    def test_with_named_timezone(self):
        dt = parse_zoned_iso("2024-01-01T12:00:00+00:00[US/Eastern]")
        assert dt.tzname() in ("EST", "EDT")
        assert dt.hour == 7

    def test_invalid_timezone_falls_back(self):
        dt = parse_zoned_iso("2024-01-01T12:00:00+05:00[Invalid/Zone]")
        assert dt.utcoffset().total_seconds() == 5 * 3600  # type: ignore[union-attr]
