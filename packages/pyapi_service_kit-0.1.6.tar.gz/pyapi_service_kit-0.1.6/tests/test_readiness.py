from pathlib import Path

from pyapi_service_kit.service.readiness import mark_service_ready, unmark_service_ready


class TestReadiness:
    def test_mark_creates_file(self, tmp_path):
        path = str(tmp_path / "ready")
        mark_service_ready(path)
        assert Path(path).read_text() == "ready"

    def test_unmark_removes_file(self, tmp_path):
        path = str(tmp_path / "ready")
        mark_service_ready(path)
        unmark_service_ready(path)
        assert not Path(path).exists()

    def test_unmark_nonexistent_is_noop(self, tmp_path):
        path = str(tmp_path / "nonexistent")
        unmark_service_ready(path)  # should not raise

    def test_mark_creates_parent_dirs(self, tmp_path):
        path = str(tmp_path / "sub" / "dir" / "ready")
        mark_service_ready(path)
        assert Path(path).read_text() == "ready"
