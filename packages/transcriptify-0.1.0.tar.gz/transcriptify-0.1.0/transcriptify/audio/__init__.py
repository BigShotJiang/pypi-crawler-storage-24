from .adapters import BytesAudioDevice, FileAudioDevice
from .port import AudioDevice

__all__ = [
    "AudioDevice",
    "BytesAudioDevice",
    "FileAudioDevice",
    "MicrophoneAudioDevice",
]


def __getattr__(name: str):
    if name == "MicrophoneAudioDevice":
        from .adapters.mic import MicrophoneAudioDevice

        return MicrophoneAudioDevice
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
