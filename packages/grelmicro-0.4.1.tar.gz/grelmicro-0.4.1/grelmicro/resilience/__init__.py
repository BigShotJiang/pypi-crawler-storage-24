"""Resilience Patterns."""
