"""
Unit tests for EDS_auth — challenge and authorization request flow.

Run from inside test_project/:
    python manage.py test EDS_auth.tests   (if placed in the app)
    python manage.py test tests            (if placed in test_project/tests/)

Or from the repo root with pytest:
    pytest tests/test_eds_auth.py
"""

import json
import uuid
from unittest.mock import patch, MagicMock

import django
from django.test import TestCase, Client, override_settings
from django.urls import reverse, path
from django.contrib.auth import get_user_model
from django.core.cache import cache

# ---------------------------------------------------------------------------
# Minimal URL conf so tests can run without the full test_project wiring.
# If you already have EDS_auth.urls included in your ROOT_URLCONF you can
# remove the @override_settings(ROOT_URLCONF=...) decorators below.
# ---------------------------------------------------------------------------
from EDS_auth import views as eds_views

test_urlpatterns = [
    path("eds/challenge/", eds_views.challenge,   name="eds_challenge"),
    path("eds/login/",     eds_views.login_eds,   name="eds_login"),
]

User = get_user_model()

CHALLENGE_URL = "/eds/challenge/"
LOGIN_URL      = "/eds/login/"


# ===========================================================================
# Helpers
# ===========================================================================

def _get_challenge(client: Client) -> str:
    """Hit the challenge endpoint and return the nonce string."""
    response = client.get(CHALLENGE_URL)
    assert response.status_code == 200, response.content
    data = response.json()
    assert "challenge" in data
    return data["challenge"]


# ===========================================================================
# 1.  Challenge endpoint
# ===========================================================================

@override_settings(ROOT_URLCONF=__name__)
class ChallengeEndpointTests(TestCase):

    def setUp(self):
        self.client = Client()
        cache.clear()

    # -----------------------------------------------------------------------
    def test_challenge_returns_200(self):
        """GET /challenge/ must respond with HTTP 200."""
        response = self.client.get(CHALLENGE_URL)
        self.assertEqual(response.status_code, 200)

    def test_challenge_returns_json(self):
        """Response body must be valid JSON with required keys."""
        response = self.client.get(CHALLENGE_URL)
        data = response.json()
        self.assertIn("challenge",   data)
        self.assertIn("expires_in",  data)
        self.assertIn("algorithm",   data)

    def test_challenge_algorithm_is_dstu4145(self):
        """Algorithm field must be DSTU4145."""
        data = self.client.get(CHALLENGE_URL).json()
        self.assertEqual(data["algorithm"], "DSTU4145")

    def test_challenge_expires_in_300(self):
        """expires_in must be 300 seconds."""
        data = self.client.get(CHALLENGE_URL).json()
        self.assertEqual(data["expires_in"], 300)

    def test_challenge_is_valid_uuid(self):
        """The nonce must be a valid UUID v4."""
        nonce = self.client.get(CHALLENGE_URL).json()["challenge"]
        parsed = uuid.UUID(nonce, version=4)   # raises ValueError if invalid
        self.assertEqual(str(parsed), nonce)

    def test_challenge_stored_in_cache(self):
        """After a challenge is issued the cache key must exist and be True."""
        nonce = self.client.get(CHALLENGE_URL).json()["challenge"]
        self.assertTrue(cache.get(f"eds_challenge_{nonce}"))

    def test_each_challenge_is_unique(self):
        """Two consecutive challenge calls must produce distinct nonces."""
        nonce1 = self.client.get(CHALLENGE_URL).json()["challenge"]
        nonce2 = self.client.get(CHALLENGE_URL).json()["challenge"]
        self.assertNotEqual(nonce1, nonce2)

    def test_challenge_rejects_post(self):
        """POST to challenge endpoint must return 405 Method Not Allowed."""
        response = self.client.post(CHALLENGE_URL)
        self.assertEqual(response.status_code, 405)

    def test_challenge_rejects_put(self):
        """PUT to challenge endpoint must return 405 Method Not Allowed."""
        response = self.client.put(CHALLENGE_URL)
        self.assertEqual(response.status_code, 405)


# ===========================================================================
# 2.  Login endpoint — input validation
# ===========================================================================

@override_settings(ROOT_URLCONF=__name__)
class LoginValidationTests(TestCase):

    def setUp(self):
        self.client = Client()
        cache.clear()

    # -----------------------------------------------------------------------
    def test_login_rejects_get(self):
        """GET /login/ must return 405."""
        response = self.client.get(LOGIN_URL)
        self.assertEqual(response.status_code, 405)

    def test_login_missing_both_params_returns_400(self):
        """POST without any params must return 400."""
        response = self.client.post(LOGIN_URL, {})
        self.assertEqual(response.status_code, 400)
        self.assertIn("error", response.json())

    def test_login_missing_challenge_id_returns_400(self):
        """POST with only signed_data must return 400."""
        response = self.client.post(LOGIN_URL, {"signed_data": "abc"})
        self.assertEqual(response.status_code, 400)

    def test_login_missing_signed_data_returns_400(self):
        """POST with only challenge_id must return 400."""
        response = self.client.post(LOGIN_URL, {"challenge_id": str(uuid.uuid4())})
        self.assertEqual(response.status_code, 400)

    def test_login_unknown_challenge_returns_403(self):
        """A challenge_id that was never issued must return 403."""
        response = self.client.post(LOGIN_URL, {
            "challenge_id": str(uuid.uuid4()),
            "signed_data": "some_signature",
        })
        self.assertEqual(response.status_code, 403)
        self.assertIn("expired", response.json()["error"].lower())

    def test_login_expired_challenge_returns_403(self):
        """
        If the cache key was set but then deleted (simulating expiry),
        the login must return 403.
        """
        nonce = str(uuid.uuid4())
        cache.set(f"eds_challenge_{nonce}", True, timeout=300)
        cache.delete(f"eds_challenge_{nonce}")  # simulate expiry
        response = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "some_signature",
        })
        self.assertEqual(response.status_code, 403)


# ===========================================================================
# 3.  Full challenge → login flow (mocked crypto)
# ===========================================================================

@override_settings(ROOT_URLCONF=__name__)
class FullAuthFlowTests(TestCase):
    """
    These tests exercise the complete challenge + login cycle.
    Because EDSCryptoService.verify_signature depends on a compiled binary,
    we mock it at the backend layer so the rest of the stack runs for real.
    """

    TAX_ID = "1234567890"

    def setUp(self):
        self.client = Client()
        cache.clear()
        # Create a user with an attached EDSCredential
        self.user = User.objects.create_user(
            username="eds_test_user",
            password=None,
        )
        from EDS_auth.models import EDSCredential
        EDSCredential.objects.create(
            user=self.user,
            tax_id=self.TAX_ID,
            certificate_serial="SERIAL-001",
        )

    # -----------------------------------------------------------------------
    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_successful_login_returns_200(self, mock_verify):
        """Valid signature for a known tax_id must return 200 with status=success."""
        mock_verify.return_value = {"tax_id": self.TAX_ID}

        nonce = _get_challenge(self.client)
        response = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "valid_cms_blob",
        })

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "success")
        self.assertEqual(data["user"], self.user.username)

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_successful_login_creates_session(self, mock_verify):
        """After a successful login the session must contain the user id."""
        mock_verify.return_value = {"tax_id": self.TAX_ID}

        nonce = _get_challenge(self.client)
        self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "valid_cms_blob",
        })

        # Django stores the user pk in the session under _auth_user_id
        session = self.client.session
        self.assertIn("_auth_user_id", session)
        self.assertEqual(int(session["_auth_user_id"]), self.user.pk)

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_successful_login_deletes_challenge_from_cache(self, mock_verify):
        """After login the challenge nonce must be removed from the cache."""
        mock_verify.return_value = {"tax_id": self.TAX_ID}

        nonce = _get_challenge(self.client)
        self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "valid_cms_blob",
        })

        self.assertIsNone(cache.get(f"eds_challenge_{nonce}"),
                          "Challenge must be consumed (deleted) after successful login")

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_challenge_cannot_be_reused(self, mock_verify):
        """The same challenge nonce must not work a second time."""
        mock_verify.return_value = {"tax_id": self.TAX_ID}

        nonce = _get_challenge(self.client)

        # First login succeeds
        self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "valid_cms_blob",
        })

        # Second attempt with the same nonce must fail
        response = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "valid_cms_blob",
        })
        self.assertEqual(response.status_code, 403)

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_invalid_signature_returns_401(self, mock_verify):
        """If crypto verification returns None (bad sig), login must return 401."""
        mock_verify.return_value = None

        nonce = _get_challenge(self.client)
        response = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "bad_signature",
        })

        self.assertEqual(response.status_code, 401)
        data = response.json()
        self.assertEqual(data["status"], "error")

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_unregistered_tax_id_returns_401(self, mock_verify):
        """Valid signature for a tax_id with no EDSCredential must return 401."""
        mock_verify.return_value = {"tax_id": "9999999999"}  # no DB record

        nonce = _get_challenge(self.client)
        response = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "valid_cms_blob",
        })

        self.assertEqual(response.status_code, 401)

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_cert_data_missing_tax_id_returns_401(self, mock_verify):
        """If cert_data has no tax_id key the backend must refuse login."""
        mock_verify.return_value = {"subject": "CN=Test"}  # no tax_id

        nonce = _get_challenge(self.client)
        response = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "some_cms",
        })

        self.assertEqual(response.status_code, 401)


# ===========================================================================
# 4.  EDSAuthenticationBackend unit tests (isolated)
# ===========================================================================

@override_settings(ROOT_URLCONF=__name__)
class BackendTests(TestCase):

    TAX_ID = "0987654321"

    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user(username="backend_test_user")
        from EDS_auth.models import EDSCredential
        EDSCredential.objects.create(user=self.user, tax_id=self.TAX_ID)
        from EDS_auth.backends import EDSAuthenticationBackend
        self.backend = EDSAuthenticationBackend()

    # -----------------------------------------------------------------------
    def test_authenticate_returns_none_without_params(self):
        result = self.backend.authenticate(request=None)
        self.assertIsNone(result)

    def test_authenticate_returns_none_without_signed_data(self):
        result = self.backend.authenticate(request=None, original_data="nonce")
        self.assertIsNone(result)

    def test_authenticate_returns_none_without_original_data(self):
        result = self.backend.authenticate(request=None, signed_data="sig")
        self.assertIsNone(result)

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_authenticate_returns_user_on_valid_signature(self, mock_verify):
        mock_verify.return_value = {"tax_id": self.TAX_ID}
        result = self.backend.authenticate(
            request=None, signed_data="sig", original_data="nonce"
        )
        self.assertEqual(result, self.user)

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_authenticate_returns_none_on_invalid_signature(self, mock_verify):
        mock_verify.return_value = None
        result = self.backend.authenticate(
            request=None, signed_data="bad", original_data="nonce"
        )
        self.assertIsNone(result)

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_authenticate_returns_none_for_unknown_tax_id(self, mock_verify):
        mock_verify.return_value = {"tax_id": "0000000000"}
        result = self.backend.authenticate(
            request=None, signed_data="sig", original_data="nonce"
        )
        self.assertIsNone(result)

    def test_get_user_returns_existing_user(self):
        result = self.backend.get_user(self.user.pk)
        self.assertEqual(result, self.user)

    def test_get_user_returns_none_for_missing_id(self):
        result = self.backend.get_user(99999)
        self.assertIsNone(result)


# ===========================================================================
# 5.  Edge / security cases
# ===========================================================================

@override_settings(ROOT_URLCONF=__name__)
class SecurityEdgeCaseTests(TestCase):

    def setUp(self):
        self.client = Client()
        cache.clear()

    def test_login_with_empty_string_challenge_id_returns_400(self):
        response = self.client.post(LOGIN_URL, {
            "challenge_id": "",
            "signed_data": "abc",
        })
        self.assertEqual(response.status_code, 400)

    def test_login_with_empty_string_signed_data_returns_400(self):
        nonce = str(uuid.uuid4())
        cache.set(f"eds_challenge_{nonce}", True, timeout=300)
        response = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "",
        })
        self.assertEqual(response.status_code, 400)

    def test_challenge_content_type_is_json(self):
        response = self.client.get(CHALLENGE_URL)
        self.assertIn("application/json", response.get("Content-Type", ""))

    def test_login_content_type_is_json_on_400(self):
        response = self.client.post(LOGIN_URL, {})
        self.assertIn("application/json", response.get("Content-Type", ""))

    @patch("EDS_auth.backends.EDSCryptoService.verify_signature")
    def test_login_response_includes_next_url(self, mock_verify):
        """Success response must include a 'next' redirect hint."""
        user = User.objects.create_user(username="redirect_user")
        from EDS_auth.models import EDSCredential
        EDSCredential.objects.create(user=user, tax_id="1111111111")
        mock_verify.return_value = {"tax_id": "1111111111"}

        nonce = _get_challenge(self.client)
        data = self.client.post(LOGIN_URL, {
            "challenge_id": nonce,
            "signed_data": "sig",
        }).json()

        self.assertIn("next", data)