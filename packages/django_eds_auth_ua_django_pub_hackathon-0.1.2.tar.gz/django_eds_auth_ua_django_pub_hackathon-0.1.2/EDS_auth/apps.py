from django.apps import AppConfig


class EdsAuthConfig(AppConfig):
    name = 'EDS_auth'
