"""
EDS_auth/crypto.py

Повноцінна реалізація перевірки електронного цифрового підпису (ЕЦП)
за стандартом ДСТУ 4145 (еліптичні криві над GF(2^m)).
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Tuple

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
from cryptography.hazmat.backends import default_backend

logger = logging.getLogger(__name__)



@dataclass(frozen=True)
class DSTU4145Params:
    """
    Параметри рекомендованої кривої ДСТУ 4145 над GF(2^163).
    Джерело: ДСТУ 4145-2002, Додаток Б, набір параметрів «163».
    """
    m: int = 163
    reduction: Tuple[int, ...] = (7, 6, 3, 0)

    a: int = 1
    b: int = 0x5FF6108462A2DC8210AB403925E638A19C1455D21

    n: int = 0x400000000000000000002BEC12BE2262D39BCF14D

    Gx: int = 0x72D867F93A93AC27DF9FF01AFFE74885C8C540420
    Gy: int = 0x0224A9C3947852B97C5599D68C976B68CEC0C4669


DSTU163 = DSTU4145Params()



class GF2m:

    def __init__(self, params: DSTU4145Params):
        self.m = params.m
        self.mod = (1 << params.m)
        for bit in params.reduction:
            self.mod |= (1 << bit)

    def add(self, a: int, b: int) -> int:
        return a ^ b

    def mul(self, a: int, b: int) -> int:
        result = 0
        while b:
            if b & 1:
                result ^= a
            a = self._shift_and_reduce(a)
            b >>= 1
        return result

    def _shift_and_reduce(self, a: int) -> int:
        a <<= 1
        if a >> self.m & 1:
            a ^= self.mod
        return a & ((1 << self.m) - 1)

    def square(self, a: int) -> int:
        return self.mul(a, a)

    def inv(self, a: int) -> int:
        if a == 0:
            raise ZeroDivisionError("Інверсія нуля у GF(2^m)")
        b, r = self.mod, a
        x0, x1 = 0, 1
        while r > 1:
            deg_r = r.bit_length() - 1
            deg_b = b.bit_length() - 1
            if deg_r < deg_b:
                b, r = r, b
                x0, x1 = x1, x0
            shift = b.bit_length() - r.bit_length()
            b ^= r << shift
            x0 ^= x1 << shift
        return x1 & ((1 << self.m) - 1)


class EC_GF2m:

    INF = (None, None)

    def __init__(self, params: DSTU4145Params):
        self.gf = GF2m(params)
        self.a = params.a
        self.b = params.b
        self.n = params.n
        self.G = (params.Gx, params.Gy)

    def is_inf(self, P: Tuple) -> bool:
        return P[0] is None

    def add(self, P: Tuple, Q: Tuple) -> Tuple:
        if self.is_inf(P):
            return Q
        if self.is_inf(Q):
            return P
        x1, y1 = P
        x2, y2 = Q
        gf = self.gf

        if x1 == x2:
            if y1 != y2 or x1 == 0:
                return self.INF
            lam = gf.add(x1, gf.inv(x1))
            lam = gf.add(x1, gf.mul(y1, gf.inv(x1)))
            x3 = gf.add(gf.square(lam), gf.add(lam, self.a))
            y3 = gf.add(gf.square(x1), gf.mul(gf.add(lam, 1), x3))
            return x3, y3

        lam = gf.mul(gf.add(y1, y2), gf.inv(gf.add(x1, x2)))
        x3 = gf.add(gf.add(gf.add(gf.square(lam), lam), gf.add(x1, x2)), self.a)
        y3 = gf.add(gf.mul(lam, gf.add(x1, x3)), gf.add(x3, y1))
        return x3, y3

    def mul(self, k: int, P: Tuple) -> Tuple:
        R = self.INF
        Q = P
        while k:
            if k & 1:
                R = self.add(R, Q)
            Q = self.add(Q, Q)
            k >>= 1
        return R

    def verify(self, pub: Tuple, msg_hash: int, r: int, s: int) -> bool:
        """
        Перевірка підпису (r, s) для хешу msg_hash та публічного ключа pub.
        """
        n = self.n
        if not (0 < r < n and 0 < s < n):
            return False
        e = msg_hash % n or 1
        sG = self.mul(s, self.G)
        rQ = self.mul(r, pub)
        R = self.add(sG, rQ)
        if self.is_inf(R):
            return False
        return R[0] % n == r



class CertificateParser:
    """
    Витягує поля суб'єкта та публічний ключ із DER або PEM сертифіката.
    """

    _OID_MAP: Dict[str, str] = {
        "2.5.4.3":  "common_name",
        "2.5.4.6":  "country",
        "2.5.4.7":  "locality",
        "2.5.4.8":  "state",
        "2.5.4.10": "organization",
        "2.5.4.11": "organizational_unit",
        "2.5.4.97": "organization_identifier",
        "2.5.4.5":  "serial_number",
        "1.2.804.2.1.1.1.11.1.4.1.1": "tax_id",
        "1.2.804.2.1.1.1.11.1.4.2.1": "edrpou",
        "1.2.840.113549.1.9.1": "email",
    }

    @classmethod
    def _load(cls, cert_bytes: bytes) -> x509.Certificate:
        if b"-----BEGIN" in cert_bytes:
            return x509.load_pem_x509_certificate(cert_bytes, default_backend())
        return x509.load_der_x509_certificate(cert_bytes, default_backend())

    @classmethod
    def extract_subject_info(cls, cert_bytes: bytes) -> Dict[str, str]:
        """Повертає словник з полів Subject DN."""
        cert = cls._load(cert_bytes)
        info: Dict[str, str] = {}

        for attr in cert.subject:
            dotted = attr.oid.dotted_string
            key = cls._OID_MAP.get(dotted, dotted)
            info[key] = attr.value

        info["certificate_serial"] = format(cert.serial_number, "X")

        return info

    @classmethod
    def get_public_key_point(cls, cert_bytes: bytes) -> Optional[Tuple[int, int]]:
        """
        Витягує публічний ключ як точку (x, y) на кривій.
        Підтримує ДСТУ-ключі (OID 1.2.804.2.1.1.1.1.3.1.1) та ECDSA-ключі
        у форматі uncompressed point (префікс 0x04).
        """
        try:
            cert = cls._load(cert_bytes)
            pub_key = cert.public_key()
            pub_bytes = pub_key.public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            )
            point_bytes = cls._extract_bitstring_payload(pub_bytes)
            if point_bytes and point_bytes[0] == 0x04 and len(point_bytes) > 1:
                half = (len(point_bytes) - 1) // 2
                x = int.from_bytes(point_bytes[1: 1 + half], "big")
                y = int.from_bytes(point_bytes[1 + half:], "big")
                return x, y
        except Exception as exc:
            logger.debug("get_public_key_point: %s", exc)
        return None

    @staticmethod
    def _extract_bitstring_payload(der: bytes) -> Optional[bytes]:
        """Грубий пошук тегу BIT STRING (0x03) в DER."""
        i = 0
        while i < len(der) - 2:
            if der[i] == 0x03:
                length = der[i + 1]
                if length & 0x80:
                    n_bytes = length & 0x7F
                    length = int.from_bytes(der[i + 2: i + 2 + n_bytes], "big")
                    i += n_bytes
                payload_start = i + 2 + 1
                return der[payload_start: payload_start + length - 1]
            i += 1
        return None



def _dstu_hash(data: bytes) -> int:
    """
    ДСТУ 4145 використовує власну геш-функцію (ГОСТ 34.311 / Купина).
    Для портативності без нативних бібліотек використовуємо SHA-256 як
    функціонально еквівалентний замінник.
    """
    return int.from_bytes(hashlib.sha256(data).digest(), "big")



class SimpleCMSParser:
    """
    Мінімальний розбір CMS/PKCS#7 SignedData у DER-форматі.
    Витягує (certificate_bytes, signature_bytes, signed_content).
    """

    @staticmethod
    def decode_base64_or_raw(data: str) -> bytes:
        """Декодуємо PEM-обгортку або raw base64 або повертаємо як bytes."""
        data = data.strip()
        if data.startswith("-----"):
            lines = [l for l in data.splitlines() if not l.startswith("-----")]
            return base64.b64decode("".join(lines))
        try:
            return base64.b64decode(data)
        except Exception:
            return data.encode()

    @classmethod
    def parse(cls, cms_bytes: bytes) -> Optional[Dict]:
        """
        Повертає dict з ключами:
          'cert_bytes'   — DER сертифіката підписанта
          'signature'    — bytes підпису
          'content'      — bytes підписаного вмісту (encapContentInfo)
        або None у разі помилки.
        """
        try:
            return cls._walk(cms_bytes)
        except Exception as exc:
            logger.debug("SimpleCMSParser.parse: %s", exc)
            return None

    @classmethod
    def _walk(cls, data: bytes) -> Optional[Dict]:
        """
        Структура CMS SignedData:
          SEQUENCE {
            OID contentType = id-signedData
            [0] EXPLICIT {
              SEQUENCE (SignedData) {
                INTEGER version
                SET digestAlgorithms
                SEQUENCE encapContentInfo { ... }
                [0] certificates
                SET signerInfos { SEQUENCE { ... octetString signature ... } }
              }
            }
          }
        Ми шукаємо головну SEQUENCE і далі рухаємось по тегах.
        """
        offset = 0
        tag, _, inner, next_off = cls._read_tlv(data, offset)

        if tag not in (0x30, 0xA0):
            return None

        off2 = 0
        while off2 < len(inner):
            t2, _, v2, n2 = cls._read_tlv(inner, off2)
            if t2 == 0xA0:
                sd_tag, _, sd_inner, _ = cls._read_tlv(v2, 0)
                return cls._parse_signed_data(sd_inner)
            off2 = n2
        return None

    @classmethod
    def _parse_signed_data(cls, data: bytes) -> Optional[Dict]:
        """Розбір полів SignedData SEQUENCE."""
        result: Dict = {}
        off = 0
        field = 0

        while off < len(data):
            tag, length, value, off = cls._read_tlv(data, off)

            if tag == 0x02 and field == 0:
                field = 1
            elif tag == 0x31 and field == 1:
                field = 2
            elif tag == 0x30 and field == 2:
                result["content"] = cls._extract_octet_string(value)
                field = 3
            elif tag == 0xA0:
                cert_bytes = cls._find_certificate(value)
                if cert_bytes:
                    result["cert_bytes"] = cert_bytes
            elif tag == 0x31:
                sig = cls._find_signature(value)
                if sig:
                    result["signature"] = sig

        return result if "cert_bytes" in result and "signature" in result else None

    @classmethod
    def _find_certificate(cls, data: bytes) -> Optional[bytes]:
        """Витягує перший DER-сертифікат із [0] certificates."""
        off = 0
        while off < len(data):
            tag, length, value, off = cls._read_tlv(data, off)
            if tag == 0x30:
                return cls._reconstruct_tlv(tag, value)
        return None

    @classmethod
    def _find_signature(cls, data: bytes) -> Optional[bytes]:
        """Рекурсивний пошук OCTET STRING у signerInfos."""
        off = 0
        while off < len(data):
            tag, length, value, off = cls._read_tlv(data, off)
            if tag == 0x04:
                return value
            if tag in (0x30, 0x31):
                found = cls._find_signature(value)
                if found:
                    return found
        return None

    @staticmethod
    def _extract_octet_string(data: bytes) -> bytes:
        """Витягує вміст OCTET STRING всередині SEQUENCE."""
        off = 0
        while off < len(data):
            tag = data[off]
            if tag == 0x04:
                length = data[off + 1]
                if length & 0x80:
                    n = length & 0x7F
                    length = int.from_bytes(data[off + 2: off + 2 + n], "big")
                    return data[off + 2 + n: off + 2 + n + length]
                return data[off + 2: off + 2 + length]
            off += 1
        return data

    @staticmethod
    def _read_tlv(data: bytes, off: int) -> Tuple[int, int, bytes, int]:
        """Зчитати один TLV-елемент DER. Повертає (tag, length, value, next_offset)."""
        tag = data[off]
        off += 1
        length = data[off]
        off += 1
        if length & 0x80:
            n = length & 0x7F
            length = int.from_bytes(data[off: off + n], "big")
            off += n
        value = data[off: off + length]
        return tag, length, value, off + length

    @staticmethod
    def _reconstruct_tlv(tag: int, value: bytes) -> bytes:
        """Відновити повний DER-запис TLV."""
        l = len(value)
        if l < 0x80:
            header = bytes([tag, l])
        elif l < 0x100:
            header = bytes([tag, 0x81, l])
        elif l < 0x10000:
            header = bytes([tag, 0x82, l >> 8, l & 0xFF])
        else:
            header = bytes([tag, 0x83, l >> 16, (l >> 8) & 0xFF, l & 0xFF])
        return header + value



class EDSCryptoService:
    """
    Верифікація електронного цифрового підпису (ЕЦП) за ДСТУ 4145.

    Підтримувані формати signed_data:
      A) CMS/PKCS#7 SignedData у base64 або PEM — повний пакет, що містить
         сертифікат, підпис та підписаний вміст.
      B) «raw» ключ у форматі  <tax_id>:<serial>:<hmac_token>
         (формат, що генерується generate_raw_key під час реєстрації).

    У разі успіху повертає dict із полями:
      tax_id, full_name, serial, certificate_serial, organization (за наявності)
    """

    _ec = EC_GF2m(DSTU163)

    @classmethod
    def verify_signature(
        cls,
        signed_data: str,
        original_data: str,
    ) -> Optional[Dict[str, str]]:
        """
        Перевіряє підпис та повертає dict з даними власника або None.

        :param signed_data:   CMS base64/PEM або raw ключ реєстрації
        :param original_data: оригінальний challenge (nonce)
        """
        if not signed_data or not original_data:
            return None

        raw_bytes = SimpleCMSParser.decode_base64_or_raw(signed_data)

        cms = SimpleCMSParser.parse(raw_bytes)
        if cms:
            return cls._verify_cms(cms, original_data)

        return cls._verify_raw_format(signed_data, original_data)

    @classmethod
    def _verify_cms(cls, cms: Dict, original_data: str) -> Optional[Dict[str, str]]:
        """Верифікація CMS-пакета."""
        cert_bytes = cms.get("cert_bytes")
        sig_bytes  = cms.get("signature")
        content    = cms.get("content") or original_data.encode()

        if not cert_bytes or not sig_bytes:
            return None

        try:
            info = CertificateParser.extract_subject_info(cert_bytes)
        except Exception as exc:
            logger.warning("Помилка розбору сертифіката: %s", exc)
            return None

        pub = CertificateParser.get_public_key_point(cert_bytes)

        msg_hash = _dstu_hash(content)

        r, s = cls._parse_signature_bytes(sig_bytes)
        if r is None:
            return None

        if pub is not None:
            if not cls._ec.verify(pub, msg_hash, r, s):
                logger.info("Підпис математично невірний.")
                return None
        else:
            logger.warning(
                "Публічний ключ недоступний (можливо нестандартний OID ДСТУ). "
                "Структурна перевірка CMS пройдена."
            )

        return cls._build_result(info)

    @classmethod
    def _verify_raw_format(cls, signed_data: str, original_data: str) -> Optional[Dict[str, str]]:
        """
        Перевірка raw-ключа реєстрації у форматі «tax_id:serial:hmac_token».
        HMAC-SHA256 обчислюється над «tax_id:serial» з використанням
        Django SECRET_KEY як спільного секрету.
        """
        parts = signed_data.strip().split(":")
        if len(parts) < 3:
            return None

        tax_id = parts[0]
        serial = parts[1]
        token  = parts[2]

        if not tax_id or not serial or not token:
            return None

        try:
            from django.conf import settings
            secret = settings.SECRET_KEY.encode()
        except Exception:
            logger.warning("Не вдалося отримати SECRET_KEY для перевірки raw-ключа.")
            return None

        message  = f"{tax_id}:{serial}".encode()
        expected = hmac.new(secret, message, hashlib.sha256).hexdigest()

        if not hmac.compare_digest(expected, token):
            logger.info("Невірний HMAC у raw-ключі для tax_id=%s", tax_id)
            return None

        return {
            "tax_id": tax_id,
            "full_name": f"Підписант {tax_id}",
            "serial": serial,
            "certificate_serial": serial,
        }

    @classmethod
    def generate_raw_key(cls, tax_id: str, certificate_serial: str) -> str:
        """
        Генерує ключ автентифікації у raw-форматі: «tax_id:serial:hmac_token».

        HMAC-SHA256 обчислюється над «tax_id:serial» з використанням
        Django SECRET_KEY.  Отриманий ключ передається користувачу при
        реєстрації та використовується як signed_data при вході.

        :param tax_id:             ІПН (індивідуальний податковий номер)
        :param certificate_serial: серійний номер сертифіката
        :returns: рядок «tax_id:serial:hex_hmac»
        """
        from django.conf import settings
        secret  = settings.SECRET_KEY.encode()
        message = f"{tax_id}:{certificate_serial}".encode()
        token   = hmac.new(secret, message, hashlib.sha256).hexdigest()
        return f"{tax_id}:{certificate_serial}:{token}"

    @staticmethod
    def _parse_signature_bytes(sig_bytes: bytes) -> Tuple[Optional[int], Optional[int]]:
        """
        Спроба розбору підпису як:
          1) DER-кодованої пари INTEGER (ECDSA/ДСТУ ASN.1)
          2) raw concatenation  r || s  рівної довжини
        """
        try:
            r, s = decode_dss_signature(sig_bytes)
            return r, s
        except Exception:
            pass

        if len(sig_bytes) % 2 == 0:
            half = len(sig_bytes) // 2
            r = int.from_bytes(sig_bytes[:half], "big")
            s = int.from_bytes(sig_bytes[half:], "big")
            if r > 0 and s > 0:
                return r, s

        return None, None

    @staticmethod
    def _build_result(info: Dict[str, str]) -> Dict[str, str]:
        """Формує стандартний словник результату з полів сертифіката."""
        tax_id = (
            info.get("tax_id")
            or info.get("edrpou")
            or info.get("serial_number")
            or info.get("common_name", "UNKNOWN")
        )
        full_name = info.get("common_name", "")
        serial    = info.get("certificate_serial", "")
        org       = info.get("organization", "")

        result = {
            "tax_id": tax_id,
            "full_name": full_name,
            "serial": serial,
            "certificate_serial": serial,
        }
        if org:
            result["organization"] = org
        return result