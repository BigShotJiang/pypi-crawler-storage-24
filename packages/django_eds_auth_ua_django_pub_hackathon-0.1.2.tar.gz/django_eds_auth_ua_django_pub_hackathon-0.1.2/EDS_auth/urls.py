from django.urls import path
from . import views

urlpatterns = [
    path("challenge/", views.challenge),
    path("login/", views.login_eds),
    path("registration/", views.registration_eds),
]
