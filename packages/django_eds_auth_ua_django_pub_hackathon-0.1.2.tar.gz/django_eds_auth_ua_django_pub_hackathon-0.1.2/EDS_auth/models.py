from django.db import models
from django.conf import settings

class EDSCredential(models.Model):
    """
    Зв'язує системного користувача з ідентифікатором його ЕЦП.
    """
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="eds_credential"
    )
    tax_id = models.CharField(max_length=14, unique=True, db_index=True)
    certificate_serial = models.CharField(max_length=128, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"EDS Credential for {self.user} ({self.tax_id})"