from django.contrib.auth.backends import BaseBackend
from django.contrib.auth import get_user_model
from django.http import HttpRequest
from typing import Optional

from .crypto import EDSCryptoService
from .models import EDSCredential

User = get_user_model()

class EDSAuthenticationBackend(BaseBackend):
    """
    Бекенд автентифікації, що використовує перевірку електронного підпису.
    """
    
    def authenticate(self, request: HttpRequest, signed_data: str = None, original_data: str = None, **kwargs) -> Optional[User]:
        if not signed_data or not original_data:
            return None

        cert_data = EDSCryptoService.verify_signature(signed_data, original_data)
        
        if not cert_data:
            return None
            
        tax_id = cert_data.get("tax_id")
        
        if not tax_id:
            return None

        try:
            credential = EDSCredential.objects.select_related('user').get(tax_id=tax_id)
            return credential.user
        except EDSCredential.DoesNotExist:
            return None

    def get_user(self, user_id: int) -> Optional[User]:
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None