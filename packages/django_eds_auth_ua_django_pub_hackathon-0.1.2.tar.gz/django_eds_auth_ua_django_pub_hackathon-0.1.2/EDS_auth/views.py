import uuid

from django.contrib.auth import authenticate, get_user_model, login as auth_login
from django.core.cache import cache
from django.http import HttpRequest, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from .crypto import EDSCryptoService
from .models import EDSCredential

User = get_user_model()


# ---------------------------------------------------------------------------
# Challenge
# ---------------------------------------------------------------------------

@require_http_methods(["GET"])
def challenge(request: HttpRequest) -> JsonResponse:
    """
    Повертає одноразовий nonce (challenge) для підпису.

    GET /auth/challenge/
    Response 200:
        {
            "challenge":  "<uuid>",
            "expires_in": 300,
            "algorithm":  "DSTU4145"
        }
    """
    nonce: str = str(uuid.uuid4())
    timeout_seconds: int = 300
    cache_key: str = f"eds_challenge_{nonce}"
    cache.set(cache_key, True, timeout=timeout_seconds)

    return JsonResponse({
        "challenge":  nonce,
        "expires_in": timeout_seconds,
        "algorithm":  "DSTU4145",
    })


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

@csrf_exempt
@require_http_methods(["POST"])
def login_eds(request: HttpRequest) -> JsonResponse:
    """
    Автентифікація за допомогою ЕЦП-ключа.

    POST /auth/login/
    Body (form-encoded):
        challenge_id  — nonce, отриманий від /auth/challenge/
        signed_data   — CMS/PKCS#7 у base64/PEM  АБО  raw-ключ реєстрації
                        у форматі  «tax_id:serial:hmac_token»

    Response 200:  { "status": "success", "user": "<username>", "next": "/" }
    Response 400:  відсутні обов'язкові поля
    Response 401:  невірний підпис або незареєстрований користувач
    Response 403:  challenge не знайдено або вже використано
    """
    challenge_id: str = request.POST.get("challenge_id", "")
    signed_cms: str   = request.POST.get("signed_data", "")

    if not challenge_id or not signed_cms:
        return JsonResponse({"error": "Missing required parameters"}, status=400)

    cache_key: str = f"eds_challenge_{challenge_id}"

    if not cache.get(cache_key):
        return JsonResponse({"error": "Challenge expired or invalid"}, status=403)

    user = authenticate(
        request,
        signed_data=signed_cms,
        original_data=challenge_id,
    )

    if user is not None:
        cache.delete(cache_key)
        auth_login(request, user)
        return JsonResponse({
            "status": "success",
            "user":   user.username,
            "next":   "/",
        })

    return JsonResponse({
        "status":  "error",
        "message": "Invalid signature or unregistered user",
    }, status=401)


# ---------------------------------------------------------------------------
# Registration / Key generation
# ---------------------------------------------------------------------------

@csrf_exempt
@require_http_methods(["POST"])
def registration_eds(request: HttpRequest) -> JsonResponse:
    """
    Реєстрація користувача та генерація ключа автентифікації.

    Клієнт надсилає ІПН та серійний номер сертифіката (отриманого від АЦСК).
    Сервер:
      1. Валідує поля запиту.
      2. Створює (або оновлює) запис User + EDSCredential.
      3. Генерує HMAC-підписаний ключ у форматі «tax_id:serial:hmac_token».
      4. Повертає ключ клієнту — він зберігається та використовується
         як signed_data при наступному виклику /auth/login/.

    POST /auth/registration/
    Body (form-encoded):
        tax_id              — ІПН (до 14 символів)
        certificate_serial  — серійний номер сертифіката з АЦСК

    Response 200:
        {
            "status":  "success" | "updated",
            "key":     "<tax_id>:<serial>:<hmac_token>",
            "user":    "<username>"
        }
    Response 400:  відсутні або порожні обов'язкові поля
    Response 409:  tax_id вже прив'язано до іншого облікового запису
    """
    tax_id: str             = request.POST.get("tax_id", "").strip()
    certificate_serial: str = request.POST.get("certificate_serial", "").strip()

    if not tax_id or not certificate_serial:
        return JsonResponse({"error": "Missing required parameters"}, status=400)

    if len(tax_id) > 14:
        return JsonResponse({"error": "tax_id must be at most 14 characters"}, status=400)

    # ------------------------------------------------------------------
    # Resolve or create the Django user (username == tax_id).
    # ------------------------------------------------------------------
    user, user_created = User.objects.get_or_create(
        username=tax_id,
        defaults={"password": "!"},   # unusable password — login via EDS only
    )

    # ------------------------------------------------------------------
    # Create or update the EDS credential record.
    # If a *different* user already owns this tax_id the DB unique
    # constraint will prevent silent data corruption; we surface a 409.
    # ------------------------------------------------------------------
    try:
        credential, cred_created = EDSCredential.objects.update_or_create(
            tax_id=tax_id,
            defaults={
                "user":               user,
                "certificate_serial": certificate_serial,
            },
        )
    except Exception:
        return JsonResponse(
            {"error": "tax_id is already bound to a different account"},
            status=409,
        )

    # ------------------------------------------------------------------
    # Generate the authentication key: tax_id:serial:HMAC-SHA256
    # ------------------------------------------------------------------
    key = EDSCryptoService.generate_raw_key(tax_id, certificate_serial)

    status_label = "success" if (user_created or cred_created) else "updated"

    return JsonResponse({
        "status": status_label,
        "key":    key,
        "user":   user.username,
    })