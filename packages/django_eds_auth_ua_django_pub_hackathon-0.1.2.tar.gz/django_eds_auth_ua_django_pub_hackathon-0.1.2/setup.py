from setuptools import setup, find_packages

setup(
    name="django-eds-auth-ua-django-pub-hackathon",
    version="0.1.2",
    description="Django authentication backend using DSTU 4145 electronic digital signature",
    author="Selector0073, Mov4un72, Nanochka",
    author_email="secret@example.com",
    url="https://github.com/Selector0073/Hackathon2026",
    license="MIT",
    packages=find_packages(exclude=["test_project*"]),
    python_requires=">=3.12",
    install_requires=[
        "django>=6.0",
        "cryptography>=46.0",
    ],
    classifiers=[
        "Framework :: Django",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
    ],
)