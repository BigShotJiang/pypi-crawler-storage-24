import requests
import json
import sys
from paintmystring.paint import paint

class Translate:
    def __init__(self, first_language: str, second_language: str, text: str):
        self.first_language = first_language
        self.second_language = second_language
        self.text = text

    def translate(self) -> str:
        url = "https://translate.googleapis.com/translate_a/single"

        params = {
            "client": "gtx",
            "sl": self.first_language,
            "tl": self.second_language,
            "dt": "t",
            "q": self.text,
        }

        response = requests.get(url, params=params).content.decode("utf-8")
        response = json.loads(response)
        response = response[0][0][0]

        return response

def main():
    first_language = "en"
    second_language = "es"

    args = sys.argv[1:]

    if len(args) == 1:
        if args[0] == "-i":
            first_language = "es"
            second_language = "en"
            
    elif len(args) == 2:
        first_language = args[0]
        second_language = args[-1]

    elif len(args) >= 3:
        print("You can only specify two arguments.")
        sys.exit(1)

    while True:
        text = input(paint(">>> ").blue().bold())
        translate = Translate(first_language, second_language, text)
        translated_text = translate.translate()
        paint(
            paint(">>>").green().bold(),
            paint(translated_text).bold(),
        ).show()
        print()

if __name__ == "__main__": 
    main()
    
