# stdatamodels

[![Tests](https://github.com/spacetelescope/stdatamodels/actions/workflows/tests.yml/badge.svg)](https://github.com/spacetelescope/stdatamodels/actions/workflows/tests.yml)
[![codecov](https://codecov.io/gh/spacetelescope/stdatamodels/branch/main/graph/badge.svg?token=TrmUKaTP2t)](https://codecov.io/gh/spacetelescope/stdatamodels)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.16280288.svg)](https://doi.org/10.5281/zenodo.16280288)


Provides JWST data model classes and schemas.


## Unit Tests

A few unit tests require downloading (~500MB) data from CRDS. CRDS must be configured for these tests to pass
(see the [CRDS User Guide](https://jwst-crds.stsci.edu/static/users_guide/index.html)
for more information). Minimally (if not on the stsci vpn where the default path of
`/grp/crds/cache` is available) you will need to set `CRDS_PATH`.

```bash
export CRDS_PATH=/tmp/crds_cache/jwst_ops
```

These tests can also be skipped with the `no-crds` pytest option

```bash
pytest --no-crds
```
