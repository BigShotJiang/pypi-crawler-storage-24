import gc

import asdf
import numpy as np
import pytest

from stdatamodels import DataModel
from stdatamodels.exceptions import ValidationWarning

from .models import (
    AnyOfModel,
    BasicModel,
    DefaultsModel,
    FitsModel,
    TableModel,
    TableModelBad,
    TransformModel,
)


def test_init_from_pathlib(tmp_path):
    """Test initializing model from a PurePath object"""
    file_path = tmp_path / "test.asdf"
    with asdf.AsdfFile() as af:
        af["meta"] = {"telescope": "crystal ball"}
        af.write_to(file_path)

    model = BasicModel(file_path)

    # Test is basically, did we open the model?
    assert model.meta.telescope == "crystal ball"


def test_set_shape():
    with BasicModel((50, 50)) as dm:
        assert dm.shape == (50, 50)

        with pytest.raises(AttributeError):
            dm.shape = (42, 23)


def test_broadcast():
    with BasicModel((50, 50)) as dm:
        data = np.zeros((50,))
        dm.dq = data
        assert dm.dq.dtype == np.uint32


def test_broadcast2():
    with BasicModel() as dm:
        data = np.zeros((52, 50))
        dm.data = data

        dq = np.zeros((50,))
        dm.dq = dq


def test_delete():
    with BasicModel() as dm:
        dm.meta.telescope = "JWST"
        assert dm.meta.telescope == "JWST"
        del dm.meta.telescope
        assert dm.meta.telescope is None


def test_copy():
    with BasicModel((50, 50)) as dm:
        dm.meta.telescope = "MEADE"
        dm.meta.foo = "BAR"

        with dm.copy() as dm2:
            dm2.data[0, 0] = 42
            assert np.sum(dm.data.flatten()) == 0

            assert dm2.meta.telescope == "MEADE"
            assert dm2.meta.foo == "BAR"
            dm2.meta.foo = "BAZ"
            assert dm.meta.foo == "BAR"
            dm2.meta.origin = "STScI"
            assert dm.meta.origin is None


def test_stringify(tmp_path):
    dm = DataModel()
    assert str(dm) == "<DataModel>"

    dm = BasicModel((10, 100))
    assert str(dm) == "<BasicModel(10, 100)>"

    file_path = tmp_path / "test.asdf"
    dm.save(file_path)
    dm.close()

    with BasicModel(file_path) as dm:
        assert str(dm) == "<BasicModel(10, 100) from test.asdf>"


def test_init_with_array():
    array = np.zeros((50, 50))
    with BasicModel(array) as dm:
        assert dm.data.shape == (50, 50)


def test_init_with_array2():
    with pytest.raises(ValueError):
        array = np.zeros((50,))
        with BasicModel(array) as dm:
            dm.data  # noqa: B018


def test_init_invalid_shape():
    """Requested some number of dimensions unequal to ndim, which is set to 2"""
    with pytest.raises(ValueError):
        BasicModel((50,))


def test_init_invalid_shape2():
    """Requested more dimensions than max_ndim"""
    with BasicModel() as dm:
        schema = dm._schema
    schema["properties"]["data"]["max_ndim"] = 1
    schema["properties"]["data"]["ndim"] = None
    with pytest.raises(ValueError):
        BasicModel((50, 50), schema=schema)


def test_init_incompatible_datamodel():
    """Initialized a model with a different model type that has invalid dimensions"""
    input_model = FitsModel((50, 50))
    schema = input_model._schema
    schema["properties"]["data"]["ndim"] = 3
    with pytest.warns(ValidationWarning):
        BasicModel(input_model, schema=schema)


def test_set_array():
    with pytest.raises(ValueError):
        with BasicModel() as dm:
            data = np.zeros((50,))
            dm.data = data


def test_set_array2():
    with BasicModel() as dm:
        data = np.zeros((50, 50))
        dm.data = data


def test_base_model_has_no_arrays():
    with pytest.raises(AttributeError):
        with DataModel() as dm:
            dm.data  # noqa: B018


def test_array_type():
    with BasicModel() as dm:
        dm.dq = dm.get_default("dq")
        assert dm.dq.dtype == np.uint32


def test_primary_not_created_when_blank():
    """Primary array should not be created if not initialized with shape nor data."""
    with DefaultsModel(strict_validation=True) as im:
        assert "primary" not in im.instance
        im.validate()


def test_set_arr_to_none(tmp_path):
    """Primary array is settable to None, and this raises no ValidationError."""
    with DefaultsModel((10, 10), strict_validation=True) as im:
        im.primary = None
        im.validate()
        assert im.primary is None
        assert im.instance["primary"] is None

        # ensure save-load works properly here too
        im.save(tmp_path / "test.asdf")

    with DefaultsModel(tmp_path / "test.asdf", strict_validation=True) as im2:
        # At the moment None values do not round-trip through save and load
        # This test should be updated when this is fixed.
        assert "primary" not in im2.instance


def test_primary_created_when_shape():
    """Primary array should be created on init if initialized with shape."""
    with DefaultsModel((10, 10)) as im:
        assert im.primary.shape == (10, 10)
        # Default value for primary is set to 2.0 in the schema
        np.testing.assert_allclose(im.primary, 2.0)


def test_non_primary_not_created_when_shape():
    """Non-primary arrays shouldn't be created on init from shape."""
    with DefaultsModel((10, 10)) as im:
        assert im.data is None
        assert "data" not in im.instance


def test_get_default_arr():
    """Test get_default for non-primary array attribute gives proper shape and value."""
    with DefaultsModel((10, 10)) as im:
        default_data = im.get_default("data")
        assert default_data.shape == (10, 10)
        # Default value for data is set to 3.0 in the schema
        np.testing.assert_allclose(default_data, 3.0)


def test_hasattr_in_inconsistency():
    """
    Test that hasattr returns True for schema-defined attributes even if they are not set in the instance.

    This inconsistency could be seen as a bug, but we encode it here to
    1. ensure the behavior is not changed inadvertently, and
    2. give a specific example of the current behavior.
    """
    with DefaultsModel() as im:
        assert hasattr(im, "primary")
        assert hasattr(im, "data")
        assert not hasattr(im, "not_in_schema")
        assert "primary" not in im
        assert "data" not in im


def test_get_default_meta():
    """Test get_default for metadata attributes both with and without schema-defined defaults."""
    with DefaultsModel() as im:
        default_meta = im.meta.get_default("default_meta")
        assert default_meta == "default"
        non_default_meta = im.meta.get_default("no_default_meta")
        assert non_default_meta is None


def test_get_default_attribute_error():
    """Test get_default raises AttributeError for non-existent attribute."""
    with DefaultsModel() as im:
        with pytest.raises(AttributeError, match='has no attribute "non_existent_attribute"'):
            im.get_default("non_existent_attribute")


def test_implicit_meta_none():
    """
    Test access to undefined metadata attributes.

    Ensure returns None, even if there is a schema-defined default.
    Ensure the attribute is not set during getattr."""
    with DefaultsModel() as im:
        assert im.meta.default_meta is None
        assert im.meta.no_default_meta is None
        assert "default_meta" not in im.meta.instance
        assert "no_default_meta" not in im.meta.instance


def test_get_dtype_basic():
    with BasicModel() as dm:
        dtype = dm.get_dtype("data")
        assert dtype == np.dtype(np.float32)
        assert "data" not in dm.instance


def test_get_dtype_table():
    with TableModel() as dm:
        dtype = dm.get_dtype("table")
        assert isinstance(dtype, np.dtype)
        expected_dtype = np.dtype(
            [
                ("int16_column", "<i2"),
                ("uint16_column", "<u2"),
                ("float32_column", "<f4"),
                ("ascii_column", "S64"),
                ("float32_column_with_shape", "<f4", (3, 2)),
                ("float32_column_with_ndim", "<f4"),
                ("float32_column_with_ndim_and_shape", "<f4", (3, 2)),
                ("float32_column_with_max_ndim", "<f4"),
            ]
        )
        assert dtype == expected_dtype
        assert "table" not in dm.instance


def test_get_dtype_attribute_error():
    with BasicModel() as dm:
        with pytest.raises(AttributeError, match='has no attribute "non_existent_attribute"'):
            dm.get_dtype("non_existent_attribute")


def test_get_dtype_no_datatype():
    with BasicModel() as dm:
        with pytest.raises(
            ValueError, match='Attribute "meta" has no datatype defined in the schema.'
        ):
            dm.get_dtype("meta")


def test_copy_model():
    with DataModel() as dm:
        with DataModel(dm) as dm2:
            assert hasattr(dm2, "meta")


def test_dtype_match():
    with BasicModel() as dm:
        dm.data = np.array([[1, 2, 3]], np.float32)


def test_default_value_anyof_schema():
    """Make sure default values are set properly when anyOf in schema"""
    with AnyOfModel() as dm:
        assert dm.meta.foo is None


def test_multivalued_default_table_schema():
    """Test setting list-like default values in a table schema"""
    with TableModel((10,)) as dm:
        defaults = dm.schema["properties"]["table"]["default"]
        columns = [col["name"] for col in dm.schema["properties"]["table"]["datatype"]]
        for default, name in zip(defaults, columns, strict=False):
            if default == "NaN":
                default = np.nan
            elif isinstance(default, str):
                # allclose has trouble with string comparisons
                for elem in dm.table[name]:
                    assert elem == default
                continue
            assert np.allclose(dm.table[name], default, equal_nan=True)

        # test shapes
        shape_col = dm.table["float32_column_with_shape"]
        assert shape_col.shape == (10, 3, 2)
        ndim_col = dm.table["float32_column_with_ndim"]
        assert ndim_col.shape == (10, 0, 0)
        ndim_shape_col = dm.table["float32_column_with_ndim_and_shape"]
        assert ndim_shape_col.shape == (10, 3, 2)
        max_ndim_col = dm.table["float32_column_with_max_ndim"]
        assert max_ndim_col.shape == (10, 0, 0)


def test_multivalued_default_table_schema_bad():
    """Test error raise if the default does not match the array type"""
    with pytest.raises(ValueError):
        TableModelBad((10,))


def test_secondary_shapes():
    """
    Confirm that a non-primary array takes on the shape
    specified in the initializer.
    """
    with BasicModel((256, 256)) as dm:
        dm.area = dm.get_default("area")
        assert dm.area.shape == (256, 256)


def test_initialize_arrays_with_arglist():
    shape = (10, 10)
    area = np.full((2, 2), 13.0)
    m = BasicModel(shape, area=area)
    assert np.array_equal(m.area, area)


def test_open_asdf_model(tmp_path):
    # Open an empty asdf file, pass extra arguments
    with DataModel(ignore_unrecognized_tag=True) as model:
        assert model._asdf._ignore_unrecognized_tag

    file_path = tmp_path / "test.asdf"

    with asdf.AsdfFile() as af:
        af.write_to(file_path)

    with DataModel(file_path, ignore_unrecognized_tag=True) as model:
        assert model._asdf._ignore_unrecognized_tag


def test_update_from_dict(tmp_path):
    """Test update method from a dictionary"""
    file_path = tmp_path / "update.asdf"
    with BasicModel((5, 5)) as m:
        m.update({"foo": "bar", "baz": 42})
        m.save(file_path)

    with asdf.open(file_path) as af:
        assert af["foo"] == "bar"
        assert af["baz"] == 42


def test_update_with_node_set_none():
    """Test that update still runs and sets attributes even when dict-like node is set to None"""
    with FitsModel() as m, FitsModel() as m2:
        m.meta.telescope = "JWST"
        m.meta.exposure = None
        m2.update(m)
        assert m2.meta.telescope == "JWST"


def test_object_node_iterator():
    m = BasicModel({"meta": {"foo": "bar"}})
    items = []
    for i in m.meta.items():
        items.append(i[0])

    assert "foo" in items


def test_hasattr():
    model = DataModel({"meta": {"foo": "bar"}})
    assert model.meta.hasattr("foo")
    assert not model.meta.hasattr("baz")


def test_datamodel_raises_filenotfound(tmp_path):
    file_path = tmp_path / "missing.asdf"

    with pytest.raises(FileNotFoundError):
        DataModel(file_path)


def test_getarray_noinit_valid():
    """Test for valid value return"""
    arr = np.ones((5, 5))
    model = BasicModel(data=arr)
    fetched = model.getarray_noinit("data")
    assert (fetched == arr).all()


def test_getarray_noinit_raises():
    """Test for error when accessing non-existent array"""
    arr = np.ones((5, 5))
    model = BasicModel(data=arr)
    with pytest.raises(AttributeError):
        model.getarray_noinit("area")


def test_getarray_noinit_noinit():
    """Test that calling on a non-existent array does not initialize that array"""
    arr = np.ones((5, 5))
    model = BasicModel(data=arr)
    try:
        model.getarray_noinit("area")
    except AttributeError:
        pass
    assert "area" not in model.instance


@pytest.mark.parametrize("filename", ["null.fits", "null.asdf"])
def test_skip_serializing_null(tmp_path, filename):
    """Make sure that None is not written out to the ASDF tree"""
    file_path = tmp_path / filename
    with BasicModel() as model:
        model.meta.telescope = None
        model.save(file_path)

    with BasicModel(file_path) as model:
        # Make sure that 'telescope' is not in the tree
        assert "telescope" not in model.meta.instance


def test_delete_failed_model():
    """
    Test that a model that failed to initialize does not
    error when deleted.
    """

    class FailedModel(DataModel):
        def __init__(self, *args, **kwargs):
            # Simulate a failed init by not invoking the
            # superclass __init__.
            pass

    model = FailedModel()
    # "Asserting" no error here:
    model.__del__()


def test_on_init_hook():
    class OnInitModel(DataModel):
        def on_init(self, init):
            super().on_init(init)

            self.meta.foo = "bar"

    model = OnInitModel()
    assert model.meta.foo == "bar"


def test_on_save_hook(tmp_path):
    class OnSaveModel(DataModel):
        def on_save(self, init):
            super().on_save(init)

            self.meta.foo = "bar"

    model = OnSaveModel()
    assert "foo" not in model.meta
    model.save(tmp_path / "test.asdf")
    assert model.meta.foo == "bar"


@pytest.mark.parametrize("ModelType", [DataModel, BasicModel, TableModel, TransformModel])  # noqa: N803
def test_garbage_collectable(ModelType, tmp_path):  # noqa: N803
    # This is a regression test to attempt to avoid future changes that might
    # reintroduce the 'difficult to garbage collect' bugs fixed in PR:
    # https://github.com/spacetelescope/stdatamodels/pull/109

    def find_gen_by_id(object_id):
        for g in (0, 1, 2):
            for o in gc.get_objects(g):
                if id(o) == object_id:
                    return g
        return None

    # make a bunch of models, keep track of where they are in memory
    ofn = tmp_path / "test.fits"
    mids = set()
    for _ in range(30):
        m = ModelType()
        mid = id(m)
        # python might reuse memory for models, this is OK and
        # indicates that the previous model was collected
        mids.add(mid)
        m.save(ofn)
        del m

        # only do a generation 0 collection
        gc.collect(0)
        for mid in mids.copy():
            # check how many models are still in memory by looking for
            # objects that the garbage collector is aware of and comparing
            # the locations in memory
            gen = find_gen_by_id(mid)
            if gen is None:  # object is not tracked or was cleaned up
                mids.remove(mid)
            # models should be easy to clean up (as they often consume large
            # amounts of memory). Check here that we aren't holding onto too
            # many models which would indicate they are difficult to garbage
            # collect.
            assert len(mids) < 2


def test_from_fits_deprecation():
    with pytest.warns(DeprecationWarning, match="from_fits is deprecated"):
        DataModel.from_fits({})


def test_from_asdf_deprecation():
    with pytest.warns(DeprecationWarning, match="from_asdf is deprecated"):
        DataModel.from_asdf({})


def test_memmap_deprecation():
    with pytest.warns(DeprecationWarning, match="Memory mapping is no longer supported"):
        DataModel(memmap=True)


def test_open_from_file_with_kwargs_deprecation(tmp_path):
    """
    Test that combining init types is not allowed.

    Passing keyword arguments to the open method, which are assumed to initialize data arrays,
    raises a deprecation warning if the input type is file-like.
    """
    fn = tmp_path / "test.asdf"
    m = DataModel()
    m.save(fn)

    with pytest.warns(DeprecationWarning, match="Unrecognized keyword arguments"):
        DataModel(fn, data=np.ones((10, 10)))
