import os
from pydantic import BaseModel, Field
from typing import Optional


class NozieConfig(BaseModel):
    api_key: str = Field(..., description="Nozie Product API Key (from your dashboard)")
    container: Optional[str] = Field(
        None,
        description="Specific container name/ID to monitor. If None, monitors all running containers."
    )
    dashboard_url: str = Field(
        "https://api.nozie.ai",
        description="Nozie Backend URL"
    )
    stats_interval: int = Field(
        30,
        description="Interval in seconds between heartbeat stats reports"
    )
    error_cooldown: int = Field(
        60,
        description="Minimum seconds between error reports for the same container"
    )

    class Config:
        env_prefix = "NOZIE_"
