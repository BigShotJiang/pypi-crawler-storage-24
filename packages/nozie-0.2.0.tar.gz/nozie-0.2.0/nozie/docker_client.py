import docker
import logging
import time
import requests
from typing import Iterator, Dict, Any, List, Optional

logger = logging.getLogger(__name__)

class DockerClientWrapper:
    def __init__(self, container_name: Optional[str] = None):
        """
        Initializes the Docker client wrapper.
        If container_name is None, it targets all running containers.
        """
        self.container_name = container_name
        self._client = docker.from_env()

    def get_target_containers(self) -> List[Any]:
        """Returns the specific container or all running containers."""
        try:
            if self.container_name:
                return [self._client.containers.get(self.container_name)]
            else:
                return self._client.containers.list(filters={"status": "running"})
        except docker.errors.NotFound:
            logger.error(f"Container '{self.container_name}' not found.")
            return []
        except Exception as e:
            logger.error(f"Error fetching containers: {e}")
            return []

    def stream_logs(self, container) -> Iterator[str]:
        """
        Generator that yields log lines from the container continuously.
        Handles reconnection if the stream drops.
        """
        while True:
            try:
                # stream=True, follow=True provides an ongoing iterator of log lines
                logs = container.logs(stream=True, follow=True, tail=100)
                for line in logs:
                    yield line.decode("utf-8", errors="replace").strip()
            except requests.exceptions.ReadTimeout:
                logger.warning(f"Log stream read timeout for container {container.name}. Reconnecting in 5s...")
                time.sleep(5)
            except docker.errors.APIError as e:
                logger.error(f"Docker API error streaming logs from {container.name}: {e}. Retrying in 10s...")
                time.sleep(10)
            except Exception as e:
                logger.error(f"Unexpected error streaming logs from {container.name}: {e}. Retrying in 10s...")
                time.sleep(10)

    def get_stats(self, container) -> Dict[str, Any]:
        """
        Fetches current health stats (CPU, Memory, uptime, restarts) for a container.
        """
        try:
            stats = container.stats(stream=False)
            
            # Memory Calculation
            mem_stats = stats.get("memory_stats", {})
            mem_usage = mem_stats.get("usage", 0)
            mem_limit = mem_stats.get("limit", 0)
            mem_percent = (mem_usage / mem_limit * 100.0) if mem_limit > 0 else 0.0

            # CPU Calculation
            cpu_stats = stats.get("cpu_stats", {})
            precpu_stats = stats.get("precpu_stats", {})
            cpu_delta = cpu_stats.get("cpu_usage", {}).get("total_usage", 0) - precpu_stats.get("cpu_usage", {}).get("total_usage", 0)
            system_delta = cpu_stats.get("system_cpu_usage", 0) - precpu_stats.get("system_cpu_usage", 0)
            cpu_percent = 0.0
            if system_delta > 0.0 and cpu_delta > 0.0:
                cpu_percent = (cpu_delta / system_delta) * len(cpu_stats.get("cpu_usage", {}).get("percpu_usage", [1])) * 100.0

            # Container status
            container.reload() # Refresh attributes
            status = container.status
            restarts = container.attrs.get("RestartCount", 0)
            started_at = container.attrs.get("State", {}).get("StartedAt", "")

            return {
                "container_id": container.id[:12],
                "container_name": container.name,
                "status": status,
                "cpu_percent": round(cpu_percent, 2),
                "memory_usage_bytes": mem_usage,
                "memory_limit_bytes": mem_limit,
                "memory_percent": round(mem_percent, 2),
                "restarts": restarts,
                "started_at": started_at
            }
        except Exception as e:
            logger.error(f"Failed to get stats for container {container.name}: {e}")
            return {}
