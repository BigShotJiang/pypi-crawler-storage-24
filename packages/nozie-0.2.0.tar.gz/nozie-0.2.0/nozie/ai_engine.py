import logging
import json
from anthropic import Anthropic
from .github_client import GithubClient

logger = logging.getLogger(__name__)

class AIEngine:
    def __init__(self, api_key: str, github_client: GithubClient):
        self.client = Anthropic(api_key=api_key)
        self.github_client = github_client

    def analyze_and_fix(self, log_snippet: str):
        """
        Sends the logs to Claude to analyze.
        Claude can use the 'read_file' tool and the 'create_fix_pr' tool.
        We run a loop to handle tool calls until Claude finishes.
        """
        system_prompt = (
            "You are an expert Python DevOps engineer and autonomous AI agent called Nozie. "
            "Your job is to read server logs, identify the root cause of ERROR or FATAL messages, "
            "investigate the codebase by reading files, and finally create a GitHub Pull Request with the fix.\n"
            "Steps to follow:\n"
            "1. Read the provided log snippet.\n"
            "2. If an error is obvious, use `read_file` tool to insect the suspected failing code file.\n"
            "3. Analyze the code and generate a patched file content.\n"
            "4. Use the `create_fix_pr` tool to push the fix to GitHub. Provide a clear explanation in the PR body.\n"
            "5. If you cannot find the issue, explain why."
        )

        tools = [
            {
                "name": "read_file",
                "description": "Reads the content of a file from the repository.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "filepath": {
                            "type": "string",
                            "description": "Path to the file relative to repo root (e.g. 'src/main.py')"
                        }
                    },
                    "required": ["filepath"]
                }
            },
            {
                "name": "create_fix_pr",
                "description": "Commits a file change to a new branch and opens a Pull Request with the fix.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "Title of the Pull Request"
                        },
                        "body": {
                            "type": "string",
                            "description": "Explanation of the fix (Markdown supported)"
                        },
                        "filepath": {
                            "type": "string",
                            "description": "The path to the file you want to patch"
                        },
                        "new_content": {
                            "type": "string",
                            "description": "The exact full file content with the fix applied. MUST BE THE COMPLETE FILE."
                        }
                    },
                    "required": ["title", "body", "filepath", "new_content"]
                }
            }
        ]

        messages = [
            {
                "role": "user",
                "content": f"Container threw the following logs. Please investigate and fix:\n\n```\n{log_snippet}\n```"
            }
        ]

        logger.info("Sending log snippet to Claude for analysis.")

        try:
            # We will perform up to 5 tool-use turns to prevent infinite loops
            for _ in range(5):
                response = self.client.messages.create(
                    model="claude-3-5-sonnet-20241022",
                    max_tokens=4096,
                    system=system_prompt,
                    tools=tools,
                    messages=messages
                )

                messages.append({"role": "assistant", "content": response.content})

                if response.stop_reason == "tool_use":
                    tool_results = []
                    for block in response.content:
                        if block.type == "tool_use":
                            tool_name = block.name
                            tool_idx = block.id

                            if tool_name == "read_file":
                                filepath = block.input.get("filepath", "")
                                logger.debug(f"Claude requested to read: {filepath}")
                                content = self.github_client.get_file_content(filepath)
                                tool_results.append({
                                    "type": "tool_result",
                                    "tool_use_id": tool_idx,
                                    "content": content
                                })
                            
                            elif tool_name == "create_fix_pr":
                                title = block.input.get("title", "Fix by Nozie")
                                body = block.input.get("body", "Autonomous fix generated by Nozie Agent.")
                                filepath = block.input.get("filepath", "")
                                new_content = block.input.get("new_content", "")
                                
                                logger.info(f"Claude requested to create PR for: {filepath}")
                                pr_url = self.github_client.create_fix_pr(title, body, filepath, new_content)
                                
                                res_msg = f"Pull Request successfully created: {pr_url}" if pr_url else "Failed to create PR."
                                tool_results.append({
                                    "type": "tool_result",
                                    "tool_use_id": tool_idx,
                                    "content": res_msg
                                })

                    messages.append({
                        "role": "user",
                        "content": tool_results
                    })
                else:
                    # Final response received
                    break

            logger.info("Claude finished analysis.")

        except Exception as e:
            logger.error(f"Claude AI Engine failed during analysis: {e}")
