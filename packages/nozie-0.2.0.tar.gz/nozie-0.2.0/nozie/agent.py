import logging
import threading
import time
import re
from typing import Dict, Optional
from concurrent.futures import ThreadPoolExecutor

from .config import NozieConfig
from .docker_client import DockerClientWrapper
from .reporter import NozieReporter

logger = logging.getLogger(__name__)


class NozieAgent:
    """
    Lightweight monitoring probe.

    Runs entirely in background daemon threads — never blocks your app.
    All intelligence (AI analysis, GitHub PRs) happens on the Nozie Backend.
    The agent's only job: watch containers, collect data, POST to the backend.

    Usage:
        from nozie import NozieAgent
        NozieAgent(api_key="nz_k_...").start()
    """

    def __init__(
        self,
        api_key: str,
        container: Optional[str] = None,
        **kwargs,
    ):
        kwargs["api_key"] = api_key
        kwargs["container"] = container
        self.config = NozieConfig(**kwargs)

        self.docker_wrapper = DockerClientWrapper(self.config.container)
        self.reporter = NozieReporter(self.config.dashboard_url)

        self.executor = ThreadPoolExecutor(max_workers=5, thread_name_prefix="nozie")
        self._stop_event = threading.Event()
        self._error_pattern = re.compile(r"(ERROR|Exception|Traceback|FATAL)", re.IGNORECASE)
        # Per-container last-report timestamps to enforce cooldown
        self._last_error_report: Dict[str, float] = {}

    # ------------------------------------------------------------------
    def start(self) -> None:
        """Start background monitoring. Non-blocking."""
        logger.info("[nozie] Agent starting — monitoring containers...")
        t = threading.Thread(target=self._run, daemon=True, name="nozie-main")
        t.start()

    def stop(self) -> None:
        """Gracefully signal the agent to stop."""
        self._stop_event.set()
        self.executor.shutdown(wait=False)
        logger.info("[nozie] Agent stopped.")

    # ------------------------------------------------------------------
    def _run(self) -> None:
        # Launch stats heartbeat loop
        self.executor.submit(self._stats_loop)

        containers = self.docker_wrapper.get_target_containers()
        if not containers:
            logger.warning("[nozie] No running containers found. Will retry on next stats cycle.")
            # Keep thread alive so stats loop continues
            while not self._stop_event.is_set():
                time.sleep(self.config.stats_interval)
                new_containers = self.docker_wrapper.get_target_containers()
                for c in new_containers:
                    logger.info(f"[nozie] New container detected: {c.name}")
                    self.executor.submit(self._log_monitor_loop, c)
            return

        for c in containers:
            logger.info(f"[nozie] Attaching log monitor to: {c.name}")
            self.executor.submit(self._log_monitor_loop, c)

        while not self._stop_event.is_set():
            time.sleep(1)

    # ------------------------------------------------------------------
    def _stats_loop(self) -> None:
        """Sends container health metrics every `stats_interval` seconds."""
        while not self._stop_event.is_set():
            try:
                containers = self.docker_wrapper.get_target_containers()
                stats_list = [
                    s for c in containers
                    if (s := self.docker_wrapper.get_stats(c))
                ]
                if stats_list:
                    self.reporter.report_stats(self.config.api_key, stats_list)
            except Exception as e:
                logger.error(f"[nozie] Stats loop error: {e}")
            time.sleep(self.config.stats_interval)

    # ------------------------------------------------------------------
    def _log_monitor_loop(self, container) -> None:
        """
        Streams log lines from `container`. Maintains a 50-line rolling buffer.
        When an error keyword is detected, fires an error report (with cooldown).
        """
        log_buffer = []
        try:
            for line in self.docker_wrapper.stream_logs(container):
                if self._stop_event.is_set():
                    break

                log_buffer.append(line)
                if len(log_buffer) > 50:
                    log_buffer.pop(0)

                if self._error_pattern.search(line):
                    now = time.time()
                    last = self._last_error_report.get(container.name, 0.0)
                    if now - last >= self.config.error_cooldown:
                        self._last_error_report[container.name] = now
                        snippet = "\n".join(log_buffer)
                        logger.warning(
                            f"[nozie] Error detected in '{container.name}' — reporting to backend."
                        )
                        self.executor.submit(
                            self.reporter.report_error,
                            self.config.api_key,
                            container.name,
                            snippet,
                        )
        except Exception as e:
            logger.error(f"[nozie] Log monitor crashed for '{container.name}': {e}")
