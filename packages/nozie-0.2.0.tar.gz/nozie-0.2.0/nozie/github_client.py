import logging
import time
from github import Github
from github.GithubException import GithubException

logger = logging.getLogger(__name__)

class GithubClient:
    def __init__(self, token: str, repo_name: str):
        self._gh = Github(token)
        self.repo_name = repo_name
        self._repo = self._gh.get_repo(repo_name)

    def get_file_content(self, filepath: str) -> str:
        """
        Reads the content of a file from the default branch.
        """
        try:
            file_content = self._repo.get_contents(filepath)
            if isinstance(file_content, list):
                logger.error(f"Path '{filepath}' is a directory.")
                return ""
            return file_content.decoded_content.decode("utf-8")
        except GithubException as e:
            logger.error(f"GitHub Error reading {filepath}: {e}")
            return f"Error: File '{filepath}' not found or inaccessible."
        except Exception as e:
            logger.error(f"Unexpected error reading {filepath}: {e}")
            return f"Error: {e}"

    def create_fix_pr(self, title: str, body: str, filepath: str, new_content: str) -> str:
        """
        Creates a new branch, commits the modified file, and opens a Pull Request.
        Returns the PR HTML URL if successful, otherwise an empty string.
        """
        try:
            default_branch = self._repo.default_branch
            base_ref = self._repo.get_git_ref(f"heads/{default_branch}")
            
            # Create a unique branch name
            timestamp = int(time.time())
            new_branch_name = f"nozie-fix-{timestamp}"
            
            self._repo.create_git_ref(ref=f"refs/heads/{new_branch_name}", sha=base_ref.object.sha)
            
            # Get the current file SHA to update it
            file_content = self._repo.get_contents(filepath, ref=default_branch)
            if isinstance(file_content, list):
                raise ValueError("Target is a directory, not a file.")
            
            # Commit the update
            commit_message = f"fix: patch {filepath} by Nozie Agent"
            self._repo.update_file(
                path=filepath,
                message=commit_message,
                content=new_content,
                sha=file_content.sha,
                branch=new_branch_name
            )
            
            # Create the PR
            pr = self._repo.create_pull(
                title=title,
                body=body,
                head=new_branch_name,
                base=default_branch
            )
            
            logger.info(f"Successfully created Pull Request: {pr.html_url}")
            return pr.html_url
            
        except GithubException as e:
            logger.error(f"GitHub Error creating PR: {e}")
            return ""
        except Exception as e:
            logger.error(f"Unexpected error creating PR: {e}")
            return ""
