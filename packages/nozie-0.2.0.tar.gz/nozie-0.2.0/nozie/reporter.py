import logging
import requests
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

AGENT_VERSION = "0.2.0"


class NozieReporter:
    """
    Thin HTTP client that ships data from the local agent probe
    to the Nozie Backend API. Never crashes the host process.
    """

    def __init__(self, dashboard_url: str):
        self.base = dashboard_url.rstrip("/")
        self._stats_url = f"{self.base}/api/v1/agent/stats"
        self._error_url = f"{self.base}/api/v1/agent/error"

    # ------------------------------------------------------------------
    def _post(self, url: str, api_key: str, payload: Dict[str, Any]) -> bool:
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=10)
            resp.raise_for_status()
            return True
        except requests.exceptions.ConnectionError:
            logger.warning("Nozie backend unreachable — will retry on next cycle.")
        except requests.exceptions.Timeout:
            logger.warning("Nozie backend request timed out.")
        except requests.exceptions.HTTPError as e:
            logger.warning(f"Nozie backend returned HTTP error: {e}")
        except Exception as e:
            logger.error(f"Unexpected error contacting Nozie backend: {e}")
        return False

    # ------------------------------------------------------------------
    def report_stats(self, api_key: str, stats_list: List[Dict[str, Any]]) -> None:
        """Send periodic container health heartbeat."""
        payload = {
            "agent_version": AGENT_VERSION,
            "containers": stats_list,
        }
        if self._post(self._stats_url, api_key, payload):
            logger.debug(f"[nozie] Stats reported for {len(stats_list)} container(s).")

    def report_error(self, api_key: str, container_name: str, log_snippet: str) -> None:
        """Send an error event with the last 50 log lines as context."""
        payload = {
            "agent_version": AGENT_VERSION,
            "container_name": container_name,
            "log_snippet": log_snippet,
        }
        if self._post(self._error_url, api_key, payload):
            logger.info(f"[nozie] Error report sent to backend for container: {container_name}")
        else:
            logger.warning(f"[nozie] Could not send error report for container: {container_name}")
