from setuptools import setup, find_packages

setup(
    name="nozie",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[
        "docker>=7.0.0",
        "pydantic>=2.0.0",
        "requests>=2.31.0",
    ],
    python_requires=">=3.8",
    description="Your code, always running. Nozie fixes itself.",
    long_description=(
        "Nozie is a lightweight monitoring probe. "
        "It watches your Docker containers, detects errors, and sends them to "
        "the Nozie backend where AI analysis and GitHub auto-fix PRs happen. "
        "No AI keys or GitHub tokens needed on your server."
    ),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
