import socket
import json
from typing import Any


def main():
    ip_address = ("192.168.31.25", 1235)

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(ip_address)

    requests = [dict(name="privet")]

    client.sendall(bytes(json.dumps(requests), 'UTF-8'))

    try:
        responses: dict[str, Any] = json.loads((client.recv(1024)).decode('utf-8'))
    except Exception:
        responses = {}

    print(responses.get("privet"))


if __name__ == "__main__":
    main()
