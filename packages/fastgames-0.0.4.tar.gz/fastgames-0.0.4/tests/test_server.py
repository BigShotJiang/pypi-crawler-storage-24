import logging

from fastgames import Server, Dispatcher, Handler


def main():
    ip_address = ("192.168.31.25", 1235)

    server = Server(ip_address=ip_address)

    dispatcher = Dispatcher(
        handlers={
            "privet": Handler(function=lambda: print("privet"))
        }
    )

    server.get_clients(dispatcher)


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)

    main()
