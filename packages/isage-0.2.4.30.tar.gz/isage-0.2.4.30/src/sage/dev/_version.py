"""Version information for sage-tools package."""

# 独立硬编码版本
__version__ = "0.2.4.13"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
