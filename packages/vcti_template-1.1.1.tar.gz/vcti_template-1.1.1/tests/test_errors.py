# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for the custom exception hierarchy."""

from vcti.template.errors import (
    TemplateError,
    TemplateNotFoundError,
    TemplateRenderError,
    TemplateSyntaxError,
)


class TestExceptionHierarchy:
    def test_base_is_exception(self):
        assert issubclass(TemplateError, Exception)

    def test_not_found_inherits_base(self):
        assert issubclass(TemplateNotFoundError, TemplateError)

    def test_not_found_inherits_lookup_error(self):
        assert issubclass(TemplateNotFoundError, LookupError)

    def test_syntax_error_inherits_base(self):
        assert issubclass(TemplateSyntaxError, TemplateError)

    def test_render_error_inherits_base(self):
        assert issubclass(TemplateRenderError, TemplateError)

    def test_catch_all_with_base(self):
        """All template exceptions are catchable with TemplateError."""
        for exc_cls in (TemplateNotFoundError, TemplateSyntaxError, TemplateRenderError):
            try:
                raise exc_cls("test")
            except TemplateError:
                pass  # expected

    def test_message_preserved(self):
        exc = TemplateNotFoundError("Template 'x' not found.")
        assert str(exc) == "Template 'x' not found."
