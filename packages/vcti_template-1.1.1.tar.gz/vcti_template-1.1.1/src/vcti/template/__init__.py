# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.template — Jinja2-based template rendering engine with streaming support."""

from importlib.metadata import version

from .errors import (
    TemplateError,
    TemplateNotFoundError,
    TemplateRenderError,
    TemplateSyntaxError,
)
from .manager import TemplateManager
from .registry import TemplateRegistry

__version__ = version("vcti-template")

__all__ = [
    "__version__",
    "TemplateError",
    "TemplateManager",
    "TemplateNotFoundError",
    "TemplateRegistry",
    "TemplateRenderError",
    "TemplateSyntaxError",
]
