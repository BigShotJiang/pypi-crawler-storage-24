# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Custom exceptions for the template engine.

A dedicated hierarchy replaces bare ``KeyError`` so consumers can catch
template-specific failures without accidentally swallowing unrelated
``KeyError`` exceptions.

Example::

    from vcti.template.errors import TemplateNotFoundError

    try:
        manager.render("missing")
    except TemplateNotFoundError as exc:
        print(exc)  # Template 'missing' not found in registry or filesystem.
"""


class TemplateError(Exception):
    """Base exception for all template-engine errors."""


class TemplateNotFoundError(TemplateError, LookupError):
    """Raised when a template cannot be resolved from any source.

    Inherits from :class:`LookupError` (the stdlib parent of ``KeyError``)
    so that existing ``except LookupError`` handlers still work.
    """


class TemplateSyntaxError(TemplateError):
    """Raised when a template string contains invalid Jinja2 syntax."""


class TemplateRenderError(TemplateError):
    """Raised when rendering fails (e.g., undefined variable in strict mode)."""
