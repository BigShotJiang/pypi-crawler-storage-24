"""
cortex — evaOS memory engine public exports.

__version__ = "1.1.1"

The top-level ``cortex`` (and ``evaos``) package exposes the :class:`Cortex`
SDK class as the primary developer entry point.  Framework integrators who
need lower-level access can import :class:`~cortex.api.plugin.CortexPlugin`
directly from ``cortex.api.plugin``.

Quickstart::

    from evaos import Cortex

    cortex = Cortex(db_path="my_memory.db", profile="companion")
    await cortex.initialize()
    await cortex.wake(session_id="session_001")
    await cortex.remember("User prefers dark mode")
    context = await cortex.retrieve("What are the user's preferences?")
    await cortex.sleep(session_id="session_001")
"""

from cortex.sdk import Cortex

__all__ = ["Cortex"]
