"""
cortex/config.py — CortexConfig dataclass + TOML loader.

Central configuration for the entire Cortex system. All modules receive
their tunable parameters through CortexConfig rather than hardcoding values.

Load order (later wins):
    1. Package defaults  (cortex/config/defaults.toml — shipped with the package)
    2. User config file  (path passed to from_toml())
    3. In-process overlay dict  (e.g., CLI flags or test overrides)

Note: The cortex_config DB table stores config values for reference/audit but
is NOT read back at runtime. Config is loaded once from TOML at startup.
There is no runtime hot-reload mechanism.

Design decisions:
    - Flat dataclass (no nested objects) for simplicity — section prefixes
      (storage_, retrieval_, etc.) group related fields.
    - Every field has a sane default, so CortexConfig() with no args works.
    - TOML sections are flattened during _from_raw() via explicit mapping.

Dependencies: None (leaf module).
Dependents: Every module that needs tunable parameters — all of them.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, List, Optional

# Python 3.11+ has tomllib in stdlib; 3.10 and below need tomli (third-party).
try:
    import tomllib  # type: ignore
except ImportError:
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:
        tomllib = None  # type: ignore


_DEFAULTS_PATH = Path(__file__).parent / "config" / "defaults.toml"


@dataclass
class CortexConfig:
    """
    Runtime configuration for Cortex v3.

    Configuration is loaded once from TOML at process startup. The
    cortex_config DB table mirrors these values for reference/audit but
    is not read back at runtime — there is no hot-reload mechanism.

    Fields with a ``storage_`` prefix come from the [cortex.storage] TOML
    section; they are handled separately because they affect DB connection
    setup (before the table exists).
    """

    # ------------------------------------------------------------------ #
    # Storage / connection (M1)
    # These affect DB connection setup — read BEFORE the DB is opened.
    # ------------------------------------------------------------------ #
    storage_backend: str = "sqlite"
    """Storage backend type. Only 'sqlite' is implemented; 'postgres' planned for Phase 5."""

    storage_db_path: str = "cortex.db"
    """Path to SQLite database file. Relative paths resolved against cwd or base arg."""

    storage_enable_wal: bool = True
    """Enable Write-Ahead Logging for concurrent read performance. Almost always True."""

    storage_busy_timeout_ms: int = 5000
    """SQLite busy timeout in ms. Prevents SQLITE_BUSY on concurrent access."""

    # ------------------------------------------------------------------ #
    # Embeddings (used by M8 retrieval + M11 drift detection)
    # ------------------------------------------------------------------ #
    embedding_model: str = "text-embedding-3-small"
    """Model ID for vector embeddings. Must match what StorageAdapter stores."""

    embedding_dim: int = 1536
    """Dimensionality of embedding vectors. Must match the model's output dim."""

    # ------------------------------------------------------------------ #
    # LLM provider cascade (M13 — CortexPlugin provider selection)
    # ------------------------------------------------------------------ #
    llm_provider_priority: List[str] = field(
        default_factory=lambda: ["anthropic", "openai", "ollama"]
    )
    """Ordered list of LLM provider names to try during plugin init.

    Cortex tries each provider in order and uses the first one that
    initialises successfully (API key present, SDK installed). This lets
    operators pin a provider or define a fallback chain without code changes.

    Supported values: "anthropic", "openai", "ollama".
    """

    # ------------------------------------------------------------------ #
    # LLM models (used by M2 extraction + M4 reconciliation)
    # ------------------------------------------------------------------ #
    extraction_model: str = "gpt-4.1-nano-2025-04-14"
    """Model used by ExtractionPipeline for claim extraction. Nano = cheap + fast."""

    reconciliation_model: str = "gpt-4.1-nano-2025-04-14"
    """Model used by ReconciliationEngine for dedup decisions. Can be different from extraction."""

    dialectic_model: Optional[str] = None
    """Model used by DialecticEngine and QueryPlanner for synthesis and planning.

    When None (default), falls back to ``extraction_model``. Set this to a
    more capable model (e.g. gpt-4.1-mini) when dialectic quality matters more
    than cost, without affecting the cheaper extraction path.
    """

    # ------------------------------------------------------------------ #
    # Token budgets (M9 — TokenBudgetManager)
    # These control how much of the LLM context window is allocated to memory.
    # ------------------------------------------------------------------ #
    cornerstone_token_budget: int = 800
    """Tokens reserved exclusively for cornerstone injection. Always allocated first."""

    retrieval_token_budget: int = 3000
    """Max tokens for retrieved context (semantic + session + procedural layers)."""

    total_memory_token_budget: int = 4000
    """Hard ceiling for ALL memory content (cornerstones + retrieval). Must be
    ≥ cornerstone_token_budget + retrieval_token_budget."""

    # ------------------------------------------------------------------ #
    # Drift detection (M11 — DriftCalculator)
    # Thresholds that determine DriftCalculator actions:
    #   score < 0.1    → 'none'  (healthy)
    #   0.1 ≤ s < 0.3  → 'warn'  (log + monitor)
    #   0.3 ≤ s < 0.5  → 'restore' (auto-restore from golden copy)
    #   s ≥ 0.5        → 'alert' (restore + alert operator)
    # ------------------------------------------------------------------ #
    drift_check_threshold: float = 0.3
    """Drift score threshold that triggers auto-restore from golden copy."""

    drift_restore_threshold: float = 0.5
    """Drift score threshold that triggers operator alert (above restore)."""

    anti_compression_confidence: float = 0.9
    """Confidence threshold for anti-compression detection in cornerstones."""

    # --- Drift threshold aliases (read-only properties below) ---
    # The original field names (drift_check_threshold, drift_restore_threshold)
    # are confusingly swapped relative to the actions they trigger:
    #   drift_check_threshold  (0.3) → triggers RESTORE action
    #   drift_restore_threshold (0.5) → triggers ALERT action
    # The properties drift_restore_score and drift_alert_score provide
    # correctly named aliases. Prefer these in new code.

    # ------------------------------------------------------------------ #
    # Brain Graph (M10c — Watcher + Auto-Registration)
    # ------------------------------------------------------------------ #
    brain_graph_watch_dirs: List[str] = field(default_factory=lambda: ["docs"])
    brain_graph_include_patterns: List[str] = field(
        default_factory=lambda: ["*.md", "*.txt", "*.py"]
    )
    brain_graph_exclude_patterns: List[str] = field(
        default_factory=lambda: ["*.pyc", "__pycache__/*", "*.egg-info/*", ".git/*"]
    )
    brain_graph_debounce_seconds: float = 5.0

    # ------------------------------------------------------------------ #
    # Deprecation / lifecycle
    # ------------------------------------------------------------------ #
    deprecation_cooling_days: int = 14
    deprecation_archive_days: int = 90

    # ------------------------------------------------------------------ #
    # Session / confidence defaults (M13 — CortexPlugin lifecycle)
    # ------------------------------------------------------------------ #
    session_confidence_default: float = 0.5
    """Default confidence for newly extracted session claims."""

    promoted_confidence_default: float = 0.8
    """Confidence assigned to claims when promoted from session to long-term."""

    session_fatigue_nap_threshold: float = 0.7
    """Fatigue score at which the agent should take a short nap (compact context)."""

    session_fatigue_sleep_threshold: float = 0.9
    """Fatigue score at which the agent should sleep (full session end)."""

    # ------------------------------------------------------------------ #
    # Circadian / dream cycle
    # ------------------------------------------------------------------ #
    dream_cycle_hour_utc: int = 8
    dream_cycle_idle_timeout_sec: int = 3600
    dream_cycle_enabled: bool = True
    auto_sleep_after_minutes: int = 30
    fatigue_interval_sec: int = 300
    """Seconds between background fatigue time-increment ticks (default 5 minutes)."""

    # ------------------------------------------------------------------ #
    # Cornerstones
    # ------------------------------------------------------------------ #
    cornerstone_auto_apply: bool = False
    max_cornerstone_count: int = 10
    cornerstone_drift_threshold: float = 0.05
    cornerstone_auto_apply_threshold: Optional[float] = None
    """Confidence threshold for auto-applying evolution proposals (0.0–1.0).

    When set to a float, proposals with LLM confidence >= this threshold are
    automatically applied without operator review.  When None (the default),
    ALL proposals require manual review via apply_evolution().

    Recommended value if enabling: 0.95 — only very high-confidence, purely-
    additive changes are auto-applied.  Never set below 0.80 in production.
    """

    # ------------------------------------------------------------------ #
    # Retrieval (M8 — RetrievalPipeline)
    # ------------------------------------------------------------------ #
    retrieval_default_strategy: str = "hybrid"
    """Default retrieval strategy: 'hybrid' | 'semantic' | 'bm25'.
    Hybrid combines vector similarity (70%) with BM25 keyword match (30%)."""

    retrieval_max_tokens: int = 4000
    """Max tokens returned from a single retrieval call."""

    retrieval_vector_weight: float = 0.7
    """Weight for vector (semantic) similarity in hybrid scoring (0-1)."""

    retrieval_bm25_weight: float = 0.3
    """Weight for BM25 keyword match in hybrid scoring (0-1).
    Must satisfy: vector_weight + bm25_weight = 1.0."""

    retrieval_recency_weight: float = 0.0
    """Weight for recency bonus in hybrid scoring (default 0.0, disabled). (#271)"""

    # ------------------------------------------------------------------ #
    # Extraction misc
    # ------------------------------------------------------------------ #
    extraction_enabled: bool = True
    """Master toggle for claim extraction. When False, remember() logs the
    episode event but skips LLM extraction entirely. Useful for import-only
    or evidence-logging-only deployments."""

    coding_noise_filter: bool = True

    extraction_batch_size: int = 5
    """Max messages per LLM extraction call (batch size).
    Larger batches = fewer calls but higher per-call latency.
    Default 5 balances cost and latency for typical conversations."""

    extraction_custom_instructions: str = ""
    """Optional deployment-specific extraction rules appended to the system prompt.

    When non-empty, this string is appended after EXTRACTION_SYSTEM_PROMPT before
    the LLM call.  Use it to add project-specific memory rules without editing
    source code.

    Example (in user config TOML):
        [cortex.extraction]
        custom_instructions = \"\"\"
        ADDITIONAL RULES:
        - Always tag mentions of the project 'Cortex' under engineering category.
        - Never extract salary or compensation details.
        \"\"\"
    """

    # ------------------------------------------------------------------ #
    # LLM call budgets (M13 — cost guard rails)
    # Prevent runaway sessions from exceeding the $8/month target.
    # ------------------------------------------------------------------ #
    max_llm_calls_per_session: int = 1000
    """Hard limit on LLM calls per session (extraction + reconciliation + retrieval).
    When exhausted the plugin returns errors instead of calling the LLM.
    Resets on wake(). Set to 0 to disable."""

    max_extraction_calls_per_batch: int = 25
    """Max number of claims passed from extraction → reconciliation per remember() call.
    Excess claims are silently dropped (cheapest ones first)."""

    # ------------------------------------------------------------------ #
    # Rate limiting (#71)
    # ------------------------------------------------------------------ #
    rate_limit_rpm: int = 60
    """HTTP API sustained request rate limit (requests per minute, per identity).
    Set to 0 to disable rate limiting entirely."""

    rate_limit_burst: int = 10
    """HTTP API burst allowance (max tokens above the sustained rate).
    Allows short bursts before the per-minute limit kicks in."""

    # ------------------------------------------------------------------ #
    # Owner / multitenancy
    # ------------------------------------------------------------------ #
    owner_id: str = "default"

    # ------------------------------------------------------------------ #
    # Drift threshold aliases (properly named)
    # ------------------------------------------------------------------ #

    @property
    def drift_restore_score(self) -> float:
        """Drift score at or above which auto-restore is triggered.

        Alias for drift_check_threshold (0.3 by default). The original name
        is misleading — "check" doesn't convey that a restore happens.
        """
        return self.drift_check_threshold

    @property
    def drift_alert_score(self) -> float:
        """Drift score at or above which an operator alert is triggered.

        Alias for drift_restore_threshold (0.5 by default). The original name
        is misleading — "restore" doesn't convey that an alert happens.
        """
        return self.drift_restore_threshold

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    @classmethod
    def from_toml(
        cls,
        path: Optional[str | Path] = None,
        *,
        overlay: Optional[dict[str, Any]] = None,
    ) -> "CortexConfig":
        """
        Build a CortexConfig from TOML file(s).

        Load order (later wins):
          1. Package defaults  (cortex/config/defaults.toml)
          2. ``path`` argument (user config, if provided)
          3. ``overlay`` dict  (in-process overrides, e.g. CLI flags)
        """
        if tomllib is None:
            raise ImportError(
                "tomllib not available. "
                "Install 'tomli' (`pip install tomli`) for Python < 3.11."
            )

        raw: dict[str, Any] = {}

        # 1. Package defaults
        if _DEFAULTS_PATH.exists():
            with open(_DEFAULTS_PATH, "rb") as fh:
                raw = tomllib.load(fh)

        # 2. User-supplied config
        if path is not None:
            user_path = Path(path)
            if user_path.exists():
                with open(user_path, "rb") as fh:
                    _deep_merge(raw, tomllib.load(fh))

        # 3. In-process overlay
        if overlay:
            _deep_merge(raw, overlay)

        return cls._from_raw(raw)

    @classmethod
    def _from_raw(cls, raw: dict[str, Any]) -> "CortexConfig":
        """Flatten nested TOML dict into CortexConfig field values."""
        cortex = raw.get("cortex", {})
        storage = cortex.get("storage", {})
        embeddings = cortex.get("embeddings", {})
        llm = cortex.get("llm", {})
        extraction = cortex.get("extraction", {})
        reconciliation = cortex.get("reconciliation", {})
        token_budgets = cortex.get("token_budgets", {})
        drift = cortex.get("drift", {})
        brain_graph = cortex.get("brain_graph", {})
        cornerstones = cortex.get("cornerstones", {})
        confidence = cortex.get("confidence", {})
        fatigue = cortex.get("fatigue", {})
        circadian = cortex.get("circadian", {})
        retrieval = cortex.get("retrieval", {})
        deprecation = cortex.get("deprecation", {})
        budgets = cortex.get("budgets", {})

        kwargs: dict[str, Any] = {}

        # Top-level cortex keys
        if "version" in cortex:
            pass  # not stored in config dataclass
        if "storage_backend" in cortex:
            kwargs["storage_backend"] = cortex["storage_backend"]
        if "owner_id" in cortex:
            kwargs["owner_id"] = cortex["owner_id"]

        # Storage section
        kwargs.update({
            "storage_db_path": storage.get("db_path", "cortex.db"),
            "storage_enable_wal": storage.get("enable_wal", True),
            "storage_busy_timeout_ms": storage.get("busy_timeout_ms", 5000),
        })

        # Embeddings section
        if "model" in embeddings:
            kwargs["embedding_model"] = embeddings["model"]
        if "dim" in embeddings:
            kwargs["embedding_dim"] = embeddings["dim"]

        # LLM provider cascade
        if "provider_priority" in llm:
            priority = llm["provider_priority"]
            if isinstance(priority, list) and all(isinstance(p, str) for p in priority):
                kwargs["llm_provider_priority"] = priority

        # Extraction
        if "enabled" in extraction:
            kwargs["extraction_enabled"] = bool(extraction["enabled"])
        if "model" in extraction:
            kwargs["extraction_model"] = extraction["model"]
        if "coding_noise_filter" in extraction:
            kwargs["coding_noise_filter"] = extraction["coding_noise_filter"]
        if "batch_size" in extraction:
            kwargs["extraction_batch_size"] = int(extraction["batch_size"])
        if "custom_instructions" in extraction:
            kwargs["extraction_custom_instructions"] = str(extraction["custom_instructions"])

        # Reconciliation
        if "model" in reconciliation:
            kwargs["reconciliation_model"] = reconciliation["model"]

        # Token budgets
        if "cornerstone" in token_budgets:
            kwargs["cornerstone_token_budget"] = token_budgets["cornerstone"]
        if "retrieval" in token_budgets:
            kwargs["retrieval_token_budget"] = token_budgets["retrieval"]
        if "total_memory" in token_budgets:
            kwargs["total_memory_token_budget"] = token_budgets["total_memory"]

        # Drift detection
        if "check_threshold" in drift:
            kwargs["drift_check_threshold"] = drift["check_threshold"]
        if "restore_threshold" in drift:
            kwargs["drift_restore_threshold"] = drift["restore_threshold"]
        if "anti_compression_confidence" in drift:
            kwargs["anti_compression_confidence"] = drift["anti_compression_confidence"]

        # Brain graph watcher
        if "watch_dirs" in brain_graph:
            kwargs["brain_graph_watch_dirs"] = brain_graph["watch_dirs"]
        if "include_patterns" in brain_graph:
            kwargs["brain_graph_include_patterns"] = brain_graph["include_patterns"]
        if "exclude_patterns" in brain_graph:
            kwargs["brain_graph_exclude_patterns"] = brain_graph["exclude_patterns"]
        if "debounce_seconds" in brain_graph:
            kwargs["brain_graph_debounce_seconds"] = brain_graph["debounce_seconds"]

        # Cornerstones
        if "max_count" in cornerstones:
            kwargs["max_cornerstone_count"] = cornerstones["max_count"]
        if "drift_threshold" in cornerstones:
            kwargs["cornerstone_drift_threshold"] = cornerstones["drift_threshold"]
        if "auto_apply" in cornerstones:
            kwargs["cornerstone_auto_apply"] = cornerstones["auto_apply"]
        if "auto_apply_threshold" in cornerstones:
            val = cornerstones["auto_apply_threshold"]
            kwargs["cornerstone_auto_apply_threshold"] = float(val) if val is not None else None

        # Confidence defaults
        if "session_default" in confidence:
            kwargs["session_confidence_default"] = confidence["session_default"]
        if "promoted_default" in confidence:
            kwargs["promoted_confidence_default"] = confidence["promoted_default"]

        # Fatigue thresholds
        if "nap_threshold" in fatigue:
            kwargs["session_fatigue_nap_threshold"] = fatigue["nap_threshold"]
        if "sleep_threshold" in fatigue:
            kwargs["session_fatigue_sleep_threshold"] = fatigue["sleep_threshold"]

        # Circadian
        if "auto_sleep_after_minutes" in circadian:
            kwargs["auto_sleep_after_minutes"] = circadian["auto_sleep_after_minutes"]
        if "dream_cycle_enabled" in circadian:
            kwargs["dream_cycle_enabled"] = circadian["dream_cycle_enabled"]
        if "dream_cycle_hour_utc" in circadian:
            kwargs["dream_cycle_hour_utc"] = circadian["dream_cycle_hour_utc"]
        if "idle_timeout_sec" in circadian:
            kwargs["dream_cycle_idle_timeout_sec"] = circadian["idle_timeout_sec"]
        if "fatigue_interval_sec" in circadian:
            kwargs["fatigue_interval_sec"] = int(circadian["fatigue_interval_sec"])

        # Retrieval
        if "default_strategy" in retrieval:
            kwargs["retrieval_default_strategy"] = retrieval["default_strategy"]
        if "max_tokens" in retrieval:
            kwargs["retrieval_max_tokens"] = retrieval["max_tokens"]
        if "vector_weight" in retrieval:
            kwargs["retrieval_vector_weight"] = retrieval["vector_weight"]
        if "bm25_weight" in retrieval:
            kwargs["retrieval_bm25_weight"] = retrieval["bm25_weight"]
        if "recency_weight" in retrieval:
            kwargs["retrieval_recency_weight"] = float(retrieval["recency_weight"])

        # Deprecation
        # grace_period_hours → cooling_days (convert hours → days, min 1)
        if "grace_period_hours" in deprecation:
            kwargs["deprecation_cooling_days"] = max(
                1, deprecation["grace_period_hours"] // 24
            )
        if "archive_days" in deprecation:
            kwargs["deprecation_archive_days"] = deprecation["archive_days"]

        # LLM call budgets
        if "max_llm_calls_per_session" in budgets:
            kwargs["max_llm_calls_per_session"] = budgets["max_llm_calls_per_session"]
        if "max_extraction_calls_per_batch" in budgets:
            kwargs["max_extraction_calls_per_batch"] = budgets["max_extraction_calls_per_batch"]

        # Rate limiting (#71)
        rate_limiting = cortex.get("rate_limiting", {})
        if "rpm" in rate_limiting:
            kwargs["rate_limit_rpm"] = int(rate_limiting["rpm"])
        if "burst" in rate_limiting:
            kwargs["rate_limit_burst"] = int(rate_limiting["burst"])

        return cls(**{k: v for k, v in kwargs.items() if k in {f.name for f in fields(cls)}})

    @classmethod
    def defaults(cls) -> "CortexConfig":
        """Return config loaded purely from the package defaults.toml."""
        return cls.from_toml()

    def db_path_resolved(self, base: Optional[str | Path] = None) -> Path:
        """Resolve storage_db_path relative to *base* (or cwd if None).

        Args:
            base: Base directory for relative paths. If None, uses os.getcwd().

        Returns:
            Absolute Path to the database file.
        """
        p = Path(self.storage_db_path)
        if p.is_absolute():
            return p
        if base is not None:
            return Path(base) / p
        return Path.cwd() / p


def validate_config(config: "CortexConfig") -> List[str]:
    """
    Validate a CortexConfig instance and return a list of warning/error strings.

    Rules (#73):
    - Required fields must exist (they always do given dataclass defaults, but
      we check that they have non-sentinel values here).
    - ``extraction_model`` and ``reconciliation_model`` must be non-empty strings.
    - ``embedding_dim`` must be > 0.
    - The directory component of ``storage_db_path`` must exist (warns if not).
    - ``rate_limit_rpm`` must be >= 0; ``rate_limit_burst`` must be >= 0.

    Returns:
        List of warning strings.  Empty list = config is valid.
        Callers should log these as warnings; they do NOT raise exceptions so
        that graceful degradation is preserved.
    """
    issues: List[str] = []

    try:
        # --- Model name validation ---
        if not config.extraction_model or not config.extraction_model.strip():
            issues.append(
                "extraction_model is empty — LLM extraction will fail at runtime"
            )
        if not config.reconciliation_model or not config.reconciliation_model.strip():
            issues.append(
                "reconciliation_model is empty — reconciliation will fail at runtime"
            )

        # --- Embedding dimension ---
        if config.embedding_dim <= 0:
            issues.append(
                f"embedding_dim must be > 0, got {config.embedding_dim}"
            )

        # --- DB path directory existence ---
        db_path = Path(config.storage_db_path)
        parent = db_path.parent if not db_path.is_absolute() else db_path.parent
        # For relative paths resolve against cwd for the warning check
        resolved_parent = (Path.cwd() / db_path).parent if not db_path.is_absolute() else parent
        if not resolved_parent.exists():
            issues.append(
                f"db_path directory does not exist: '{resolved_parent}' "
                f"(from storage_db_path='{config.storage_db_path}'). "
                "Database cannot be created until this directory exists."
            )

        # --- Rate limit sanity ---
        if config.rate_limit_rpm < 0:
            issues.append(
                f"rate_limit_rpm must be >= 0 (0 = disabled), got {config.rate_limit_rpm}"
            )
        if config.rate_limit_burst < 0:
            issues.append(
                f"rate_limit_burst must be >= 0, got {config.rate_limit_burst}"
            )

        # --- Token budget consistency ---
        if config.total_memory_token_budget < (
            config.cornerstone_token_budget + config.retrieval_token_budget
        ):
            issues.append(
                "total_memory_token_budget is less than cornerstone_token_budget + "
                "retrieval_token_budget — memory context will be silently truncated"
            )
    except (TypeError, AttributeError):
        # Config is not a real CortexConfig (e.g. MagicMock or _FakeConfig in tests).
        # validate_config is a best-effort guard — never block startup.
        pass

    return issues


def _deep_merge(base: dict, override: dict) -> None:
    """Merge *override* into *base* in-place (nested dicts merged recursively)."""
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v
