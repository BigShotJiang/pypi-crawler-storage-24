"""cortex/api/routes/memory.py — Memory CRUD endpoints."""

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse

from cortex.api.deps import PREFIX, _serialise, get_plugin, plugin_holder
from cortex.api.models import (
    CategoryListResponse,
    EnhancedRememberRequest,
    EnhancedRememberResponse,
    EnhancedRetrieveRequest,
    FeedbackRequest,
    ForgetResponse,
    MemoryBrowseResponse,
    MemoryDetailResponse,
    MemoryPatchRequest,
    MemoryPatchResponse,
    MemorySearchRequest,
    MemorySearchResponse,
    RememberRequest,
    RememberResponse,
    RetrieveExplainRequest,
    RetrieveExplainResponse,
    RetrieveRequest,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def _make_routes(verify_api_key):
    """Register all memory routes with the given auth dependency."""

    @router.post(
        f"{PREFIX}/remember",
        response_model=RememberResponse,
        status_code=status.HTTP_200_OK,
        summary="Extract and store memories",
        tags=["memory"],
    )
    async def remember(
        body: RememberRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> RememberResponse:
        """
        Extract semantic claims from a conversation and persist them to memory.

        Accepts either a list of ``{role, content}`` messages or a raw text string.
        """
        # --- Input validation (#284) ---
        if isinstance(body.conversation, list):
            if len(body.conversation) == 0:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="Conversation must not be empty",
                )
            conversation = [{"role": m.role, "content": m.content} for m in body.conversation]
            total_len = sum(len(m.get("content", "")) for m in conversation)
        else:
            if body.conversation == "":
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="Conversation must not be empty",
                )
            conversation = body.conversation
            total_len = len(conversation)

        if total_len > 50000:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Conversation too long (max 50000 characters)",
            )

        report = await plugin.remember(
            conversation=conversation,
            session_id=body.session_id,
        )
        return RememberResponse(
            session_id=report.session_id,
            claims_extracted=report.claims_extracted,
            claims_stored=report.claims_stored,
            entities_resolved=report.entities_resolved,
            noise_filtered=report.noise_filtered,
            errors=report.errors,
            ok=report.ok,
        )

    @router.post(
        f"{PREFIX}/retrieve",
        summary="Retrieve context for a query",
        tags=["memory"],
    )
    async def retrieve(
        body: RetrieveRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> JSONResponse:
        """
        Retrieve relevant memories for a query, respecting an optional token budget.

        Returns the raw RetrievalResult serialised as JSON.
        """
        result = await plugin.retrieve(
            query=body.query,
            token_budget=body.token_budget,
            mode=body.mode,
            owner_id=body.owner_id,
        )
        if result is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Retrieval pipeline not available",
            )
        if hasattr(result, "__dict__"):
            data = _serialise(result.__dict__)
        else:
            data = _serialise(result)
        return JSONResponse(content=data)

    # NOTE: /memories/categories MUST come before /memories/{memory_id}
    # so FastAPI doesn't interpret "categories" as a path param.
    @router.get(
        f"{PREFIX}/memories/categories",
        response_model=CategoryListResponse,
        summary="List memory categories with counts",
        tags=["memories"],
    )
    async def list_memory_categories(
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> CategoryListResponse:
        """Return all memory categories with per-category claim counts."""
        errors: List[str] = []
        storage = getattr(plugin, "storage", None)
        if storage is None:
            errors.append("Storage not available")
            return CategoryListResponse(errors=errors)

        owner_id = getattr(plugin.config, "owner_id", "default")

        _CATEGORY_META: Dict[str, Dict[str, str]] = {
            "identity":    {"color": "#6366f1", "description": "Who the user is"},
            "personal":    {"color": "#ec4899", "description": "Personal facts and relationships"},
            "preferences": {"color": "#f59e0b", "description": "Preferences and likes/dislikes"},
            "engineering": {"color": "#10b981", "description": "Technical knowledge and projects"},
            "goals":       {"color": "#3b82f6", "description": "Goals and aspirations"},
            "misc":        {"color": "#6b7280", "description": "Miscellaneous memories"},
        }

        try:
            db_counts = await storage.get_category_counts(owner_id=owner_id)
        except Exception as exc:
            errors.append(f"Category fetch failed: {exc}")
            db_counts = []

        counts_by_name = {r["name"]: r["count"] for r in db_counts}
        all_names = set(_CATEGORY_META.keys()) | set(counts_by_name.keys())
        categories = []
        for name in sorted(all_names):
            meta = _CATEGORY_META.get(name, {"color": "#6b7280", "description": name})
            categories.append({
                "name": name,
                "count": counts_by_name.get(name, 0),
                "color": meta["color"],
                "description": meta["description"],
            })

        return CategoryListResponse(categories=categories, errors=errors)

    @router.get(
        f"{PREFIX}/memories",
        response_model=MemoryBrowseResponse,
        summary="Browse and filter memories",
        tags=["memories"],
    )
    async def browse_memories(
        page: int = 1,
        per_page: int = 50,
        time_range: str = "all",
        status: Optional[str] = None,
        category: Optional[str] = None,
        entity_name: Optional[str] = None,
        q: Optional[str] = None,
        sort_by: str = "updated_at",
        sort_order: str = "desc",
        owner_id: Optional[str] = None,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> MemoryBrowseResponse:
        """Browse semantic memories with filtering, pagination, and keyword search."""
        errors: List[str] = []
        storage = getattr(plugin, "storage", None)
        if storage is None:
            errors.append("Storage not available")
            return MemoryBrowseResponse(errors=errors)

        effective_owner = owner_id or getattr(plugin.config, "owner_id", "default")
        per_page = max(1, min(per_page, 200))
        page = max(1, page)

        try:
            result = await storage.browse_memories(
                owner_id=effective_owner,
                page=page,
                per_page=per_page,
                time_range=time_range,
                status=status,
                category=category,
                entity_name=entity_name,
                q=q,
                sort_by=sort_by,
                sort_order=sort_order,
            )
        except Exception as exc:
            err = f"Memory browse failed: {exc}"
            logger.error(err, exc_info=True)
            errors.append(err)
            return MemoryBrowseResponse(errors=errors)

        return MemoryBrowseResponse(
            items=result["items"],
            total=result["total"],
            page=result["page"],
            per_page=result["per_page"],
            pages=result["pages"],
            category_counts=result["category_counts"],
            errors=errors,
        )

    @router.get(
        f"{PREFIX}/memories/{{memory_id}}",
        response_model=MemoryDetailResponse,
        summary="Get full memory detail",
        tags=["memories"],
    )
    async def get_memory_detail(
        memory_id: str,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> MemoryDetailResponse:
        """Return full claim data, changelog, and related memories (same subject entity)."""
        errors: List[str] = []
        storage = getattr(plugin, "storage", None)
        if storage is None:
            errors.append("Storage not available")
            return MemoryDetailResponse(errors=errors)

        claim = await storage.get_claim(memory_id)
        if claim is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Memory '{memory_id}' not found",
            )

        memory_dict = _serialise(claim.__dict__) if hasattr(claim, "__dict__") else {"id": memory_id}

        try:
            changelog = await storage.get_changelog(memory_id)
        except Exception as exc:
            errors.append(f"Changelog fetch failed: {exc}")
            changelog = []

        provenance: List[Dict[str, Any]] = []
        try:
            prov_records = await storage.get_provenance(memory_id)
            for p in prov_records:
                provenance.append(_serialise(p.__dict__) if hasattr(p, "__dict__") else dict(p))
        except Exception as exc:
            errors.append(f"Provenance fetch failed: {exc}")

        related: List[Dict[str, Any]] = []
        try:
            entity_id = getattr(claim, "subject_entity_id", None)
            if entity_id:
                siblings = await storage.get_claims_by_entity(entity_id)
                for s in siblings:
                    if s.id != memory_id:
                        related.append({
                            "id": s.id,
                            "subject": s.subject,
                            "predicate": s.predicate,
                            "object_value": (s.object_value[:200] if s.object_value else ""),
                            "category": getattr(s, "category", "misc"),
                            "confidence": s.confidence,
                            "status": s.status,
                        })
                        if len(related) >= 5:
                            break
            else:
                siblings = await storage.get_claims_by_subject(
                    claim.subject,
                    owner_id=getattr(claim, "owner_id", "default"),
                )
                for s in siblings:
                    if s.id != memory_id:
                        related.append({
                            "id": s.id,
                            "subject": s.subject,
                            "predicate": s.predicate,
                            "object_value": (s.object_value[:200] if s.object_value else ""),
                            "category": getattr(s, "category", "misc"),
                            "confidence": s.confidence,
                            "status": s.status,
                        })
                        if len(related) >= 5:
                            break
        except Exception as exc:
            errors.append(f"Related memories fetch failed: {exc}")

        return MemoryDetailResponse(
            memory=memory_dict,
            changelog=changelog,
            related=related,
            provenance=provenance,
            errors=errors,
        )

    @router.delete(
        f"{PREFIX}/memories/{{memory_id}}",
        response_model=ForgetResponse,
        summary="Delete a memory (soft or hard)",
        tags=["memories"],
    )
    async def delete_memory(
        memory_id: str,
        hard: bool = False,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> ForgetResponse:
        """
        Delete a memory.

        - Soft delete (default): marks status as 'archived'.
        - Hard delete (``?hard=true``): removes row from DB.
        - Logs action='deleted' to changelog regardless.
        """
        errors: List[str] = []
        storage = getattr(plugin, "storage", None)
        if storage is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Storage not available",
            )

        claim = await storage.get_claim(memory_id)
        if claim is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Memory '{memory_id}' not found",
            )

        owner_id = getattr(claim, "owner_id", getattr(plugin.config, "owner_id", "default"))

        try:
            # Log changelog BEFORE hard delete (row will be gone after)
            existing_log = await storage.get_changelog(memory_id)
            next_version = (max((e.get("version", 0) for e in existing_log), default=0) + 1
                            if existing_log else 1)
            snapshot = f"{claim.subject} {claim.predicate} {claim.object_value}"
            action = "hard_deleted" if hard else "deleted"
            await storage.log_changelog(
                claim_id=memory_id,
                version=next_version,
                content_snapshot=snapshot,
                action=action,
                reason=f"Operator {'hard' if hard else 'soft'} delete via API",
                changed_by="operator",
            )
        except Exception as exc:
            errors.append(f"Changelog write failed: {exc}")

        try:
            await storage.delete_claim(memory_id, owner_id=owner_id, hard=hard)
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error",
            ) from exc

        return ForgetResponse(
            memory_id=memory_id,
            deleted=True,
            reason=f"Memory {'hard' if hard else 'soft'} deleted",
            errors=errors,
        )

    @router.patch(
        f"{PREFIX}/memories/{{memory_id}}",
        response_model=MemoryPatchResponse,
        summary="Update memory metadata",
        tags=["memories"],
    )
    async def patch_memory(
        memory_id: str,
        body: MemoryPatchRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> MemoryPatchResponse:
        """Update metadata fields on a memory: category, sensitivity, status, confidence."""
        errors: List[str] = []
        storage = getattr(plugin, "storage", None)
        if storage is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Storage not available",
            )

        claim = await storage.get_claim(memory_id)
        if claim is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Memory '{memory_id}' not found",
            )

        _valid_sensitivity = {"normal", "private", "secret"}
        _valid_status = {"active", "cooling", "deprecated", "archived", "superseded"}
        _valid_categories = {"identity", "personal", "preferences", "engineering", "goals", "misc"}

        updates: Dict[str, Any] = {}

        if body.category is not None:
            if body.category not in _valid_categories:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Invalid category '{body.category}'. Valid: {sorted(_valid_categories)}",
                )
            updates["category"] = body.category

        if body.sensitivity is not None:
            if body.sensitivity not in _valid_sensitivity:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Invalid sensitivity '{body.sensitivity}'. Valid: {sorted(_valid_sensitivity)}",
                )
            updates["sensitivity"] = body.sensitivity

        if body.status is not None:
            if body.status not in _valid_status:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Invalid status '{body.status}'. Valid: {sorted(_valid_status)}",
                )
            updates["status"] = body.status

        if body.confidence is not None:
            if not (0.0 <= body.confidence <= 1.0):
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="confidence must be between 0.0 and 1.0",
                )
            updates["confidence"] = body.confidence

        if not updates:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="No valid fields provided for update",
            )

        try:
            updated_claim = await storage.update_claim(memory_id, **updates)
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error",
            ) from exc

        # Log to changelog
        try:
            existing_log = await storage.get_changelog(memory_id)
            next_version = (max((e.get("version", 0) for e in existing_log), default=0) + 1
                            if existing_log else 1)
            snapshot = f"{updated_claim.subject} {updated_claim.predicate} {updated_claim.object_value}"
            change_summary = ", ".join(f"{k}={v}" for k, v in updates.items())
            await storage.log_changelog(
                claim_id=memory_id,
                version=next_version,
                content_snapshot=snapshot,
                action="metadata_updated",
                reason=f"Operator patch: {change_summary}",
                changed_by="operator",
            )
        except Exception as exc:
            errors.append(f"Changelog write failed: {exc}")

        memory_dict = _serialise(updated_claim.__dict__) if hasattr(updated_claim, "__dict__") else {"id": memory_id}
        return MemoryPatchResponse(memory=memory_dict, errors=errors)

    @router.post(
        f"{PREFIX}/feedback",
        summary="Submit memory feedback",
        tags=["feedback"],
    )
    async def submit_feedback(
        body: FeedbackRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> JSONResponse:
        """Submit positive or negative feedback for a retrieved memory."""
        result = await plugin.feedback(
            memory_id=body.memory_id,
            helpful=body.helpful,
            context=body.context,
            target_type=body.target_type,
        )
        if result is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="FeedbackSystem not available",
            )
        data = _serialise(result.__dict__) if hasattr(result, "__dict__") else str(result)
        return JSONResponse(content={"feedback": data})

    @router.post(
        f"{PREFIX}/retrieve/explain",
        response_model=RetrieveExplainResponse,
        status_code=status.HTTP_200_OK,
        summary="Retrieval with explanation",
        tags=["memory"],
    )
    async def retrieve_explain(
        body: RetrieveExplainRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> RetrieveExplainResponse:
        """Retrieve memories for a query and return explanation of retrieval process."""
        errors: List[str] = []
        results: List[Dict[str, Any]] = []
        explanation: Dict[str, Any] = {}

        storage = getattr(plugin, "storage", None)

        try:
            from cortex.core.retrieval import RetrievalConstraints, RetrievalPipeline

            pipeline = RetrievalPipeline(
                storage=storage,
                config=plugin.config,
                token_budget=getattr(plugin, "token_budget_manager", None),
                cornerstone_guardian=getattr(plugin, "cornerstone_guardian", None),
                llm=getattr(plugin, "llm", None),
            )

            constraints = RetrievalConstraints(top_k=body.limit)
            owner_id = getattr(plugin.config, "owner_id", "default")

            import asyncio
            import time

            t0 = time.monotonic()

            candidate_k = body.limit * pipeline.candidate_multiplier

            bm25_task = asyncio.create_task(
                pipeline._bm25_search(body.query, top_k=candidate_k)
            )
            vector_task = asyncio.create_task(
                pipeline._vector_search(body.query, top_k=candidate_k, owner_id=owner_id)
            )

            from cortex.core.retrieval import _normalise_bm25, rrf_fusion
            bm25_results, vector_results = await asyncio.gather(bm25_task, vector_task)

            fts_matches = len(bm25_results)
            vector_matches = len(vector_results)

            bm25_ranked = _normalise_bm25(bm25_results)
            vector_ranked = [(r.item_id, r.score) for r in vector_results]
            fused = rrf_fusion([bm25_ranked, vector_ranked], k=pipeline.rrf_k)
            rrf_scores = [
                {"item_id": item_id, "score": round(score, 6)}
                for item_id, score in fused[:body.limit]
            ]

            cornerstone_injected = False
            cornerstone_tokens = 0
            guardian = getattr(pipeline, "cornerstone_guardian", None)
            if guardian is not None:
                try:
                    cs_list = await guardian.get_cornerstones()
                    cornerstone_injected = len(cs_list) > 0
                    for cs in cs_list:
                        cs_text = getattr(cs, "content", "") or ""
                        cornerstone_tokens += pipeline._count_tokens(cs_text)
                except Exception as e:
                    logger.warning("http_server: unhandled exception: %s", e)

            total_budget = getattr(plugin.config, "retrieval_token_budget", 3000)
            remaining = total_budget

            full_result = await pipeline.retrieve(
                query=body.query,
                mode="auto",
                constraints=constraints,
                owner_id=owner_id,
            )

            strategy = getattr(full_result, "mode", "lightweight")
            tokens_used = getattr(full_result, "tokens_used", 0)
            remaining = max(0, total_budget - tokens_used - cornerstone_tokens)

            results = [
                _serialise(item.__dict__) if hasattr(item, "__dict__") else _serialise(item)
                for item in (getattr(full_result, "items", []) or [])
            ]

            explanation = {
                "strategy": strategy,
                "fts_matches": fts_matches,
                "vector_matches": vector_matches,
                "rrf_scores": rrf_scores,
                "cornerstone_injected": cornerstone_injected,
                "token_budget": {
                    "total": total_budget,
                    "used": tokens_used,
                    "remaining": remaining,
                },
            }

        except Exception as exc:
            err = f"Retrieve/explain failed: {exc}"
            logger.error(err, exc_info=True)
            errors.append(err)

        return RetrieveExplainResponse(
            results=results,
            explanation=explanation,
            errors=errors,
        )

    @router.post(
        f"{PREFIX}/memories/search",
        response_model=MemorySearchResponse,
        status_code=status.HTTP_200_OK,
        summary="Semantic memory search",
        tags=["memory"],
    )
    async def search_memories(
        body: MemorySearchRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> MemorySearchResponse:
        """Semantic search over stored memories."""
        errors: List[str] = []
        items: List[Dict[str, Any]] = []

        owner_id = body.owner_id or getattr(plugin.config, "owner_id", "default")
        filters = body.filters or {}

        try:
            result = await plugin.retrieve(
                query=body.query,
                token_budget=None,
                mode="auto",
                owner_id=owner_id,
            )

            if result is None:
                return MemorySearchResponse(
                    errors=["Retrieval pipeline not available"], total=0
                )

            raw_items = getattr(result, "items", []) or []

            category_filter = filters.get("category")
            status_filter = filters.get("status")
            entity_filter = filters.get("entity_name")

            out: List[Dict[str, Any]] = []
            for item in raw_items:
                d = _serialise(item.__dict__) if hasattr(item, "__dict__") else _serialise(item)

                if category_filter and d.get("category") != category_filter:
                    continue
                if status_filter and d.get("status") != status_filter:
                    continue
                if entity_filter:
                    subject = (d.get("subject") or "").lower()
                    obj_val = (d.get("object_value") or "").lower()
                    if entity_filter.lower() not in subject and entity_filter.lower() not in obj_val:
                        continue

                score = d.pop("score", None) or d.pop("relevance_score", None) or 0.0
                out.append({
                    "id":       d.get("item_id") or d.get("id", ""),
                    "content":  d.get("content") or d.get("object_value") or "",
                    "score":    score,
                    "category": d.get("category", ""),
                    "entity":   d.get("subject") or d.get("entity_name", ""),
                    **{k: v for k, v in d.items() if k not in
                       ("item_id", "id", "content", "object_value", "score",
                        "relevance_score", "category", "entity_name", "subject")},
                })

                if len(out) >= body.top_k:
                    break

            items = out[:body.top_k]

        except Exception as exc:
            err = f"Memory search failed: {exc}"
            logger.error(err, exc_info=True)
            errors.append(err)

        return MemorySearchResponse(items=items, total=len(items), errors=errors)

    @router.post(
        f"{PREFIX}/retrieve/v2",
        summary="Enhanced agent retrieval with optional explain",
        tags=["memory"],
    )
    async def retrieve_v2(
        body: EnhancedRetrieveRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> JSONResponse:
        """Retrieve relevant memories for a query. With explain=true, includes scoring details."""
        import time as _time

        result = await plugin.retrieve(
            query=body.query,
            token_budget=body.token_budget,
            mode=body.mode,
            owner_id=body.owner_id,
        )
        if result is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Retrieval pipeline not available",
            )

        data = _serialise(result.__dict__) if hasattr(result, "__dict__") else _serialise(result)

        if body.explain:
            data["_explain"] = {
                "mode":        getattr(result, "mode", body.mode),
                "tokens_used": getattr(result, "tokens_used", None),
                "item_count":  len(getattr(result, "items", []) or []),
                "scores": [
                    {
                        "id":    getattr(i, "item_id", None) or getattr(i, "id", ""),
                        "score": getattr(i, "score", None) or getattr(i, "relevance_score", None),
                    }
                    for i in (getattr(result, "items", []) or [])
                ],
                "query": body.query,
            }

        return JSONResponse(content=data)

    @router.post(
        f"{PREFIX}/remember/v2",
        response_model=EnhancedRememberResponse,
        status_code=status.HTTP_200_OK,
        summary="Enhanced memory write with detailed response",
        tags=["memory"],
    )
    async def remember_v2(
        body: EnhancedRememberRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> EnhancedRememberResponse:
        """Extract and store memories with enhanced response details."""
        import time as _time

        t0 = _time.monotonic()

        conversation: Any
        if isinstance(body.conversation, list):
            conversation = [{"role": m.role, "content": m.content} for m in body.conversation]
        else:
            conversation = body.conversation

        report = await plugin.remember(
            conversation=conversation,
            session_id=body.session_id,
        )

        duration_ms = int((_time.monotonic() - t0) * 1000)

        claims_added = getattr(report, "claims_added", 0) or report.claims_stored
        claims_updated = getattr(report, "claims_updated", 0) or 0
        events_logged = getattr(report, "events_logged", 0) or 0

        return EnhancedRememberResponse(
            session_id=report.session_id,
            claims_extracted=report.claims_extracted,
            claims_added=claims_added,
            claims_updated=claims_updated,
            claims_stored=report.claims_stored,
            entities_resolved=report.entities_resolved,
            noise_filtered=report.noise_filtered,
            events_logged=events_logged,
            processing_time_ms=duration_ms,
            errors=report.errors,
            ok=report.ok,
        )
