"""cortex/api/routes/sessions.py — Session lifecycle endpoints."""

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse

from cortex.api.deps import PREFIX, _serialise, get_plugin
from cortex.api.models import (
    DreamRequest,
    DreamResponse,
    SessionSleepRequest,
    SessionSleepResponse,
    SessionWakeRequest,
    SessionWakeResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def _make_routes(verify_api_key):
    """Register session routes with the given auth dependency."""

    @router.post(
        f"{PREFIX}/session/wake",
        response_model=SessionWakeResponse,
        status_code=status.HTTP_200_OK,
        summary="Start a new session (wake)",
        tags=["session"],
    )
    async def session_wake(
        body: SessionWakeRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> SessionWakeResponse:
        """Wake Cortex for a new session."""
        report = await plugin.wake(session_id=body.session_id)
        return SessionWakeResponse(
            session_id=report.session_id,
            cornerstones_loaded=report.cornerstones_loaded,
            errors=report.errors,
        )

    @router.post(
        f"{PREFIX}/session/sleep",
        response_model=SessionSleepResponse,
        status_code=status.HTTP_200_OK,
        summary="End the current session (sleep)",
        tags=["session"],
    )
    async def session_sleep(
        body: SessionSleepRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> SessionSleepResponse:
        """Gracefully close a session."""
        import time
        t0 = time.monotonic()
        report = await plugin.sleep(session_id=body.session_id)
        duration_ms = int((time.monotonic() - t0) * 1000)

        claims_consolidated = getattr(report, "memories_summarised", 0) or getattr(
            report, "claims_consolidated", 0
        )
        return SessionSleepResponse(
            session_id=report.session_id,
            claims_consolidated=claims_consolidated,
            duration_ms=duration_ms,
            errors=report.errors,
        )

    @router.post(
        f"{PREFIX}/dream",
        response_model=DreamResponse,
        status_code=status.HTTP_200_OK,
        summary="Trigger a dream cycle",
        tags=["session"],
    )
    async def dream(
        body: DreamRequest,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> DreamResponse:
        """Run a full dream-cycle consolidation (Electric Sheep)."""
        import time
        t0 = time.monotonic()
        errors: List[str] = []

        try:
            report = await plugin.dream(owner_id=body.owner_id)
            duration_ms = int((time.monotonic() - t0) * 1000)

            return DreamResponse(
                steps_completed=getattr(report, "steps_completed", 0),
                curiosity_seeds=getattr(report, "curiosity_seeds", 0),
                claims_consolidated=getattr(report, "claims_consolidated", 0),
                journal=getattr(report, "journal", ""),
                duration_ms=duration_ms,
                errors=getattr(report, "errors", []),
            )
        except Exception as exc:
            err = f"Dream cycle failed: {exc}"
            logger.error(err, exc_info=True)
            errors.append(err)
            duration_ms = int((time.monotonic() - t0) * 1000)
            return DreamResponse(duration_ms=duration_ms, errors=errors)

    # ---- Browse sessions (M13 Part 2) ----

    @router.get(
        f"{PREFIX}/sessions",
        summary="Browse sessions",
        tags=["sessions"],
    )
    async def browse_sessions(
        limit: int = 50,
        offset: int = 0,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> JSONResponse:
        """Return sessions list with turn_count, claims_created, status."""
        storage = getattr(plugin, "storage", None)
        if storage is None:
            return JSONResponse(
                content={"sessions": [], "total": 0, "errors": ["Storage not available"]}
            )
        errors: List[str] = []
        try:
            if hasattr(storage, "list_sessions"):
                sessions = await storage.list_sessions(
                    owner_id=getattr(plugin.config, "owner_id", "default"),
                    limit=limit,
                    offset=offset,
                )
                total = 0
                if hasattr(storage, "count_sessions"):
                    total = await storage.count_sessions()
                items = [
                    _serialise(s.__dict__) if hasattr(s, "__dict__") else _serialise(s)
                    for s in sessions
                ]
                return JSONResponse(content={"sessions": items, "total": total, "errors": errors})
            else:
                errors.append("Session listing not supported")
                return JSONResponse(content={"sessions": [], "total": 0, "errors": errors})
        except Exception as exc:
            err = f"Session list failed: {exc}"
            logger.error(err, exc_info=True)
            errors.append(err)
            return JSONResponse(content={"sessions": [], "total": 0, "errors": errors})

    @router.get(
        f"{PREFIX}/sessions/{{session_id}}",
        summary="Session detail",
        tags=["sessions"],
    )
    async def get_session_detail(
        session_id: str,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ) -> JSONResponse:
        """Return full session record with summary and episode count."""
        storage = getattr(plugin, "storage", None)
        if storage is None:
            raise HTTPException(503, detail="Storage not available")
        try:
            session = await storage.get_session_by_sid(
                session_id,
                owner_id=getattr(plugin.config, "owner_id", "default"),
            )
            if session is None:
                raise HTTPException(404, detail=f"Session {session_id} not found")
            data = _serialise(session.__dict__) if hasattr(session, "__dict__") else _serialise(session)

            episode_count = 0
            if hasattr(storage, "get_session_episode_count"):
                episode_count = await storage.get_session_episode_count(session_id)
            data["episode_count"] = episode_count

            return JSONResponse(content={"session": data})
        except HTTPException:
            raise
        except Exception as exc:
            logger.error("get_session_detail failed: %s", exc, exc_info=True)
            raise HTTPException(500, detail="Internal server error")
