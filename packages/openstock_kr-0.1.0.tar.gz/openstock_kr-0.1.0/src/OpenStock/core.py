# src/OpenStock/core.py
import requests
import json
import pandas as pd
import warnings 
warnings.filterwarnings(action='ignore')


class OpenStock:
    def __init__(self, api_key: str):
	    """
		api_key (str): 한국거래소 정보데이터시스템(data.krx.co.kr)에서 발급받은 OPEN API 인증키
        """    
        self.api_key = api_key
		

    def get_index(self, basDd: str, col_lan='en') -> pd.DataFrame:
        """
        한국거래소(KRX) OPEN API를 통해 특정 일자의 지수(KRX, KOSPI, KOSDAQ) 데이터를 수집하고 전처리합니다.
    
        이 함수는 세 가지 API 엔드포인트(KRX, KOSPI, KOSDAQ)를 순차적으로 호출하여 데이터를 하나의 데이터프레임으로 병합합니다. 
        네트워크 지연, 서버 에러, 빈 응답 등의 예외 상황을 내부적으로 안전하게 처리하며, 
        콤마(,)가 포함된 문자열 형태의 수치형 데이터를 실제 수치형(int, float) 데이터로 자동 변환합니다.
    
        Args:
            basDd (str): 데이터 수집 기준일자 (형식: 'YYYYMMDD', 예: '20240306').
            col_lan (str, optional): 반환할 데이터프레임의 컬럼명 언어 설정. 
                                     기본값은 'en'(영문 컬럼명 유지)이며, 'kr'로 설정 시 한국어 컬럼명으로 변경됩니다.
    
        Returns:
            pandas.DataFrame: 수집 및 수치형 변환 전처리가 완료된 지수 데이터프레임.
                              조회 일자에 데이터가 없거나 API 호출에 실패한 경우 빈 데이터프레임(Empty DataFrame)을 반환합니다.
    
        Example:
 		    >>> api_key = 'YOUR_API_KEY_HERE'
            >>> stock = OpenStock(api_key=api_key) 
            >>> df = stock.get_index('20240306', col_lan='kr')
            >>> print(df.head())
        """
        # 한국거래소 OPEN API 인증키
        headers = {'AUTH_KEY': self.api_key}
    
        # 종목명, 시가총액 추출 기준일
        params = {'basDd': basDd}
    
        # 거래소 API 호출 URL
        krx = 'https://data-dbg.krx.co.kr/svc/apis/idx/krx_dd_trd'
        ksp = 'https://data-dbg.krx.co.kr/svc/apis/idx/kospi_dd_trd'
        ksq = 'https://data-dbg.krx.co.kr/svc/apis/idx/kosdaq_dd_trd'
        urls = [krx, ksp, ksq]
    
        # 데이터 수집
        data = pd.DataFrame()
        for url in urls:
            try:
                # 1. API 호출 (타임아웃 10초 설정으로 무한 대기 방지)
                response = requests.get(url, params=params, headers=headers, timeout=10)
                
                # 2. HTTP 에러(4xx, 5xx) 발생 시 강제로 예외 발생
                response.raise_for_status() 
                
                # 3. JSON 데이터 파싱
                res_data = response.json()
                out_block = res_data.get("OutBlock_1", [])
                df = pd.DataFrame(out_block)
                
                # 4. 정상 응답이지만 데이터가 비어있는 경우 건너뛰기
                if df.empty:
                    print(f"안내: {url}에서 해당 일자의 데이터가 존재하지 않습니다.")
                    continue
    
                # 5. 데이터 병합 (ignore_index=True로 기존 reset_index 역할 대체)
                data = pd.concat([data, df], axis=0, ignore_index=True)
    
            except requests.exceptions.RequestException as e:
                # 네트워크 연결 문제, 타임아웃, HTTP 에러 등을 처리
                print(f"경고: API 호출 중 통신 오류 발생 ({url})\n상세: {e}")
                continue
            except ValueError as e:
                # JSON 디코딩 실패 등 데이터 형식 오류 처리
                print(f"경고: JSON 파싱 오류 발생 ({url})\n상세: {e}")
                continue
            except Exception as e:
                # 예상치 못한 기타 에러 처리
                print(f"경고: 알 수 없는 오류 발생 ({url})\n상세: {e}")
                continue
    
        # 모든 URL에서 데이터를 가져오지 못한 경우 빈 데이터프레임 반환
        if data.empty:
            print("수집된 데이터가 없습니다.")
            return data
    
        # 수치형 변환 대상 컬럼
        cols = ['CLSPRC_IDX', 'CMPPREVDD_IDX','FLUC_RT','OPNPRC_IDX','HGPRC_IDX','LWPRC_IDX','ACC_TRDVOL','ACC_TRDVAL','MKTCAP'] 
    
        # 이전에 안내해드린 경고 방지 방식(try-except)으로 수치형 변환 적용
        for col in cols:
            if col in data.columns: # 컬럼이 존재하는지 안전하게 확인
                clean_series = data[col].astype(str).str.replace(',', '', regex=False)
                try:
                    data[col] = pd.to_numeric(clean_series)
                except ValueError:
                    pass
    
        # 컬럼명 한국어 변경 (데이터와 컬럼 길이가 일치할 때만 변경하도록 안전장치 추가)
        if col_lan == 'kr':
            kr_cols = ['기준일자', '계열구분', '지수명', '종가', '대비', '등락률', '시가',  '고가', '저가', '거래량', '거래대금', '상장시가총액']
            if len(data.columns) == len(kr_cols):
                data.columns = kr_cols
            else:
                print("경고: 수집된 데이터의 컬럼 수와 한글 컬럼명의 수가 일치하지 않아 영문 컬럼명을 유지합니다.")
    
        return data



    
    def get_price(self, basDd: str, col_lan='en') -> pd.DataFrame:
        """
        한국거래소(KRX) OPEN API를 통해 특정 일자의 종목 시세(KOSPI, KOSDAQ) 데이터를 수집하고 전처리합니다.
    
        이 함수는 두 가지 API 엔드포인트(KOSPI, KOSDAQ)를 순차적으로 호출하여 데이터를 하나의 데이터프레임으로 병합합니다. 
        네트워크 지연, 서버 에러, 빈 응답 등의 예외 상황을 내부적으로 안전하게 처리하며, 
        콤마(,)가 포함된 문자열 형태의 수치형 데이터를 실제 수치형(int, float) 데이터로 자동 변환합니다.
    
        Args:
            basDd (str): 데이터 수집 기준일자 (형식: 'YYYYMMDD', 예: '20240306').
            col_lan (str, optional): 반환할 데이터프레임의 컬럼명 언어 설정. 
                                     기본값은 'en'(영문 컬럼명 유지)이며, 'kr'로 설정 시 한국어 컬럼명으로 변경됩니다.
    
        Returns:
            pandas.DataFrame: 수집 및 수치형 변환 전처리가 완료된 지수 데이터프레임.
                              조회 일자에 데이터가 없거나 API 호출에 실패한 경우 빈 데이터프레임(Empty DataFrame)을 반환합니다.
    
        Example:
		    >>> api_key = 'YOUR_API_KEY_HERE'
            >>> stock = OpenStock(api_key=api_key) 
            >>> df = stock.get_price('20240306', col_lan='kr')
            >>> print(df.head())
        """
        # 한국거래소 OPEN API 인증키
        headers = {'AUTH_KEY': self.api_key}
    
        # 종목명, 시가총액 추출 기준일
        params = {'basDd': basDd}
    
        # 거래소 API 호출 URL
        ksp = 'https://data-dbg.krx.co.kr/svc/apis/sto/stk_bydd_trd'
        ksq = 'https://data-dbg.krx.co.kr/svc/apis/sto/ksq_bydd_trd'
        urls = [ksp, ksq]
    
        # 데이터 수집
        data = pd.DataFrame()
        for url in urls:
            try:
                # 1. API 호출 (타임아웃 10초 설정으로 무한 대기 방지)
                response = requests.get(url, params=params, headers=headers, timeout=10)
                
                # 2. HTTP 에러(4xx, 5xx) 발생 시 강제로 예외 발생
                response.raise_for_status() 
                
                # 3. JSON 데이터 파싱
                res_data = response.json()
                out_block = res_data.get("OutBlock_1", [])
                df = pd.DataFrame(out_block)
                
                # 4. 정상 응답이지만 데이터가 비어있는 경우 건너뛰기
                if df.empty:
                    print(f"안내: {url}에서 해당 일자의 데이터가 존재하지 않습니다.")
                    continue
    
                # 5. 데이터 병합 (ignore_index=True로 기존 reset_index 역할 대체)
                data = pd.concat([data, df], axis=0, ignore_index=True)
    
            except requests.exceptions.RequestException as e:
                # 네트워크 연결 문제, 타임아웃, HTTP 에러 등을 처리
                print(f"경고: API 호출 중 통신 오류 발생 ({url})\n상세: {e}")
                continue
            except ValueError as e:
                # JSON 디코딩 실패 등 데이터 형식 오류 처리
                print(f"경고: JSON 파싱 오류 발생 ({url})\n상세: {e}")
                continue
            except Exception as e:
                # 예상치 못한 기타 에러 처리
                print(f"경고: 알 수 없는 오류 발생 ({url})\n상세: {e}")
                continue
    
        # 모든 URL에서 데이터를 가져오지 못한 경우 빈 데이터프레임 반환
        if data.empty:
            print("수집된 데이터가 없습니다.")
            return data
    
        # 수치형 변환 대상 컬럼
        cols = [ 'TDD_CLSPRC', 'CMPPREVDD_PRC', 'FLUC_RT', 'TDD_OPNPRC', 'TDD_HGPRC', 'TDD_LWPRC', 'ACC_TRDVOL', 'ACC_TRDVAL', 'MKTCAP', 'LIST_SHRS'] 
    
        # 이전에 안내해드린 경고 방지 방식(try-except)으로 수치형 변환 적용
        for col in cols:
            if col in data.columns: # 컬럼이 존재하는지 안전하게 확인
                clean_series = data[col].astype(str).str.replace(',', '', regex=False)
                try:
                    data[col] = pd.to_numeric(clean_series)
                except ValueError:
                    pass
    
        # 컬럼명 한국어 변경 (데이터와 컬럼 길이가 일치할 때만 변경하도록 안전장치 추가)
        if col_lan == 'kr':
            kr_cols = ['기준일자', '종목코드', '종목명', '시장구분', '소속부', '종가', '대비', '등락률', '시가', '고가', '저가', '거래량', '거래대금', '시가총액', '상장주식수']
            if len(data.columns) == len(kr_cols):
                data.columns = kr_cols
            else:
                print("경고: 수집된 데이터의 컬럼 수와 한글 컬럼명의 수가 일치하지 않아 영문 컬럼명을 유지합니다.")
    
        return data    



        
    def get_stockinfo(self, basDd: str, col_lan='en') -> pd.DataFrame:
        """
        한국거래소(KRX) OPEN API를 통해 특정 일자의 종목정보(KOSPI, KOSDAQ) 데이터를 수집하고 전처리합니다.
    
        이 함수는 두 가지 API 엔드포인트(KOSPI, KOSDAQ)를 순차적으로 호출하여 데이터를 하나의 데이터프레임으로 병합합니다. 
        네트워크 지연, 서버 에러, 빈 응답 등의 예외 상황을 내부적으로 안전하게 처리하며, 
        콤마(,)가 포함된 문자열 형태의 수치형 데이터를 실제 수치형(int, float) 데이터로 자동 변환합니다.
    
        Args:
            basDd (str): 데이터 수집 기준일자 (형식: 'YYYYMMDD', 예: '20240306').
            col_lan (str, optional): 반환할 데이터프레임의 컬럼명 언어 설정. 
                                     기본값은 'en'(영문 컬럼명 유지)이며, 'kr'로 설정 시 한국어 컬럼명으로 변경됩니다.
    
        Returns:
            pandas.DataFrame: 수집 및 수치형 변환 전처리가 완료된 지수 데이터프레임.
                              조회 일자에 데이터가 없거나 API 호출에 실패한 경우 빈 데이터프레임(Empty DataFrame)을 반환합니다.
    
        Example:
		    >>> api_key = 'YOUR_API_KEY_HERE'
            >>> stock = OpenStock(api_key=api_key) 
            >>> df = stock.get_stockinfo(api_key, '20240306', col_lan='kr')
            >>> print(df.head())
        """
        # 한국거래소 OPEN API 인증키
        headers = {'AUTH_KEY': api_key}
    
        # 종목명, 시가총액 추출 기준일
        params = {'basDd': basDd}
    
        # 거래소 API 호출 URL
        ksp = 'https://data-dbg.krx.co.kr/svc/apis/sto/stk_isu_base_info'
        ksq = 'https://data-dbg.krx.co.kr/svc/apis/sto/ksq_isu_base_info'
        urls = [ksp, ksq]
    
        # 데이터 수집
        data = pd.DataFrame()
        for url in urls:
            try:
                # 1. API 호출 (타임아웃 10초 설정으로 무한 대기 방지)
                response = requests.get(url, params=params, headers=headers, timeout=10)
                
                # 2. HTTP 에러(4xx, 5xx) 발생 시 강제로 예외 발생
                response.raise_for_status() 
                
                # 3. JSON 데이터 파싱
                res_data = response.json()
                out_block = res_data.get("OutBlock_1", [])
                df = pd.DataFrame(out_block)
                
                # 4. 정상 응답이지만 데이터가 비어있는 경우 건너뛰기
                if df.empty:
                    print(f"안내: {url}에서 해당 일자의 데이터가 존재하지 않습니다.")
                    continue
    
                # 5. 데이터 병합 (ignore_index=True로 기존 reset_index 역할 대체)
                data = pd.concat([data, df], axis=0, ignore_index=True)
    
            except requests.exceptions.RequestException as e:
                # 네트워크 연결 문제, 타임아웃, HTTP 에러 등을 처리
                print(f"경고: API 호출 중 통신 오류 발생 ({url})\n상세: {e}")
                continue
            except ValueError as e:
                # JSON 디코딩 실패 등 데이터 형식 오류 처리
                print(f"경고: JSON 파싱 오류 발생 ({url})\n상세: {e}")
                continue
            except Exception as e:
                # 예상치 못한 기타 에러 처리
                print(f"경고: 알 수 없는 오류 발생 ({url})\n상세: {e}")
                continue
    
        # 모든 URL에서 데이터를 가져오지 못한 경우 빈 데이터프레임 반환
        if data.empty:
            print("수집된 데이터가 없습니다.")
            return data
    
        # 수치형 변환 대상 컬럼: PARVAL(액면가) 컬럼에 무액면 값이 있어 수치형 변환 불가 
        cols = ['PARVAL', 'LIST_SHRS'] 
    
        # 이전에 안내해드린 경고 방지 방식(try-except)으로 수치형 변환 적용
        for col in cols:
            if col in data.columns: # 컬럼이 존재하는지 안전하게 확인
                clean_series = data[col].astype(str).str.replace(',', '', regex=False)
                try:
                    data[col] = pd.to_numeric(clean_series)
                except ValueError:
                    pass
    
        # 컬럼명 한국어 변경 (데이터와 컬럼 길이가 일치할 때만 변경하도록 안전장치 추가)
        if col_lan == 'kr':
            kr_cols = ['표준코드', '단축코드', '한글종목명', '한글종목약명', '영문종목명','상장일', '시장구분', '증권구분', '소속부', '주식종류', '액면가', '상장주식수']
            if len(data.columns) == len(kr_cols):
                data.columns = kr_cols
            else:
                print("경고: 수집된 데이터의 컬럼 수와 한글 컬럼명의 수가 일치하지 않아 영문 컬럼명을 유지합니다.")
    
        return data