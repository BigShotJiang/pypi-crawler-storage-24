# src/OpenStock/__init__.py

# 같은 폴더의 core.py에서 OpenStock 클래스를 가져옵니다.
from .core import OpenStock

# 패키지를 import할 때 노출할 항목을 명시합니다.
__all__ = ['OpenStock']