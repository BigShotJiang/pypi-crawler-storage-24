"""django_eds_auth package.

Django authentication backend for EDS (Electronic Digital Signature) based authentication.

Main components:
- EDSAuthBackend: Authentication backend for Django
- EDSCertificateValidator: Certificate validation utility
- EDSSignatureVerifier: Signature verification utility
- NonceManager: Nonce generation and management
"""

__version__ = "0.1.0"


# Lazy imports to avoid AppRegistryNotReady errors during Django initialization
def __getattr__(name):
    """Lazy load modules to avoid AppRegistryNotReady errors."""
    if name == "EDSAuthBackend":
        from .backends import EDSAuthBackend

        return EDSAuthBackend
    elif name == "NonceManager":
        from .backends import NonceManager

        return NonceManager
    elif name == "EDSCertificateValidator":
        from .signature_verification import EDSCertificateValidator

        return EDSCertificateValidator
    elif name == "EDSSignatureVerifier":
        from .signature_verification import EDSSignatureVerifier

        return EDSSignatureVerifier
    elif name == "CertificateValidationError":
        from .signature_verification import CertificateValidationError

        return CertificateValidationError
    elif name == "SignatureVerificationError":
        from .signature_verification import SignatureVerificationError

        return SignatureVerificationError
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "EDSAuthBackend",
    "NonceManager",
    "EDSCertificateValidator",
    "EDSSignatureVerifier",
    "CertificateValidationError",
    "SignatureVerificationError",
]
