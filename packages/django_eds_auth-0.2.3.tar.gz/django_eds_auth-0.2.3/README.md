# django-eds-auth

A secure Django authentication backend for EDS (Electronic Digital Signature) based authentication.
Uses X.509 certificates and nonce-based challenge-response for cryptographically secure authentication.

## Overview

**django-eds-auth** is a Django authentication backend that implements EDS (Electronic Digital Signature) 
based login using X.509 certificates. It provides:

- ✅ Challenge-response authentication with single-use nonces
- ✅ RSA, ECDSA, and DSA signature verification support
- ✅ X.509 certificate chain validation
- ✅ Replay attack prevention
- ✅ Comprehensive audit logging
- ✅ No private keys stored on server

## Project Structure

- `src/django_eds_auth/` - Main package code
- `example_project/` - Example Django project for testing
- `tests/` - Unit and integration tests
- `docs/` - Documentation and guides

## Quick Start

### Installation

```bash
# Install the package with development dependencies
pip install -e ".[dev]"

# Or install using pip directly
pip install django-eds-auth
```

### Configuration

1. Add to `INSTALLED_APPS` in Django settings:
```python
INSTALLED_APPS = [
    # ...
    'django_eds_auth',
]
```

2. Add authentication backend:
```python
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'django_eds_auth.backends.EDSAuthBackend',
]
```

3. Configure certificate paths (example):
```python
EDS_AUTH_SERVER_CERT_PATH = os.getenv('EDS_AUTH_SERVER_CERT_PATH', '/path/to/cert.pem')
EDS_AUTH_SERVER_KEY_PATH = os.getenv('EDS_AUTH_SERVER_KEY_PATH', '/path/to/key.pem')
EDS_AUTH_TRUSTED_CA_CERTS_PATH = os.getenv('EDS_AUTH_TRUSTED_CA_CERTS_PATH', '')
```

4. Run migrations:
```bash
python manage.py migrate
```

5. Start the development server:
```bash
cd example_project
python manage.py runserver
```

## Docker Integration

The project includes `Dockerfile` and `docker-compose.yml` for local development with PostgreSQL.

### 1) Prepare environment variables

```bash
cp .env.example .env
```

Update `.env` if needed (database credentials, Django settings, etc.).

### 2) Build and start containers

```bash
docker compose up --build
```

This starts:
- `db` - PostgreSQL 16
- `web` - Django app on `http://localhost:8000`

### 3) Run migrations inside container

In a second terminal:

```bash
docker compose exec web python example_project/manage.py migrate
```

### 4) Optional: create superuser

```bash
docker compose exec web python example_project/manage.py createsuperuser
```

### 5) Stop containers

```bash
docker compose down
```

To remove volumes too:

```bash
docker compose down -v
```

## Testing

Running the full test suite:

```bash
# Run all tests with verbose output
pytest tests/ -v

# Run with coverage report
pytest tests/ --cov=django_eds_auth --cov-report=term-missing

# Run only security tests
pytest tests/test_security_and_coverage.py -v

# Run with timing information
pytest tests/ -v --durations=10
```

Current test results: **75 tests PASSED** ✅

## Documentation

- [COVERAGE_REPORT.md](COVERAGE_REPORT.md) - Detailed test coverage analysis
- [VERIFICATION.md](VERIFICATION.md) - Requirement verification and compliance
- [IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md) - Detailed implementation guide

## License

MIT License
