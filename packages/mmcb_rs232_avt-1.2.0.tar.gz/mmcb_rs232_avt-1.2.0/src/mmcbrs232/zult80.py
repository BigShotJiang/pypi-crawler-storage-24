#!/usr/bin/env python3
"""
Set power supply parameters on a device connected by a FTDI USB to RS232
adaptors.
"""

import itertools
import sys
import types

from mmcbrs232 import mdclientlib
from mmcbrs232.ult80 import check_arguments


##############################################################################
# main
##############################################################################

def main():
    """
    Set power supply parameters on a device connected by a FTDI USB to RS232
    adaptors.
    """
    status = types.SimpleNamespace(success=0, unreserved_error_code=3)

    args = check_arguments()

    # handle ./ prefix, though this should not be present when this script is packaged
    options = sys.argv[1:]
    if not options:
        print('please specify options')
        return status.unreserved_error_code

    command = ' '.join(itertools.chain(['ult80'], options))

    mdc = mdclientlib.Rs232()
    try:
        response = mdc._reply_value(mdc._issue_serial_command(command))
    except TypeError:
        print('No response')
        return status.unreserved_error_code

    if response is None:
        print('No response')
        return status.unreserved_error_code

    print(response)
    return status.success


##############################################################################
if __name__ == '__main__':
    sys.exit(main())
