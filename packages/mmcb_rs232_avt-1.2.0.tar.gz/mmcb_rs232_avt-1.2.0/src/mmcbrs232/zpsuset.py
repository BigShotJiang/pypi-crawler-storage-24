#!/usr/bin/env python3
"""
Set power supply parameters on a device connected by a FTDI USB to RS232
adaptors.
"""

import itertools
import sys
import types

from mmcbrs232 import mdclientlib
from mmcbrs232.psuset import check_arguments


##############################################################################
# main
##############################################################################

def main():
    """
    Set power supply parameters on a device connected by a FTDI USB to RS232
    adaptors.
    """
    status = types.SimpleNamespace(success=0, unreserved_error_code=3)

    success = False
    settings = {
        'alias': None,
        'channel': None,
        'current_limit': None,
        'debug': None,
        'decimal_places': 2,
        'forwardbias': False,
        'immediate': False,
        'manufacturer': None,
        'model': None,
        'on': None,
        'peltier': False,
        'port': None,
        'quiet': False,
        'rear': None,
        'reset': False,
        'serial': None,
        'settlingtime': 0.5,
        'verbose': None,
        'voltage': None,
        'voltspersecond': 10
        }

    check_arguments(settings)

    # handle ./ prefix, though this should not be present when this script is packaged
    options = sys.argv[1:]
    if not options:
        print('please specify options')
        return status.unreserved_error_code

    command = ' '.join(itertools.chain(['psuset'], options))

    mdc = mdclientlib.Rs232()
    try:
        response = mdc._reply_value(mdc._issue_serial_command(command))
    except TypeError:
        print('No response')
        return status.unreserved_error_code

    if response is None:
        print('No response')
        return status.unreserved_error_code

    print(response)
    return status.success


##############################################################################
if __name__ == '__main__':
    sys.exit(main())
