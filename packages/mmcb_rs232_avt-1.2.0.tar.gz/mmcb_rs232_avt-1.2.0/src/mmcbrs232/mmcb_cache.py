#!/usr/bin/env python3
"""
Show the contents of the cache in human-readable form.
"""

import argparse
import json
import pprint

from mmcbrs232 import common


##############################################################################
# command line option handler
##############################################################################


def check_arguments():
    """
    Handle command line options.

    --------------------------------------------------------------------------
    args : none
    --------------------------------------------------------------------------
    returns : none
    --------------------------------------------------------------------------
    """
    parser = argparse.ArgumentParser(
        description=(
            'Show the contents of the ATLAS pixels multi-module cycling box '
            '(MMCB) cache file in human-readable form.'
        )
    ).parse_args()


##############################################################################
# main
##############################################################################

def main():
    """
    Show the contents of the cache in human-readable form.
    """
    check_arguments()

    with open(common.DEVICE_CACHE, 'r', encoding='utf-8') as cache:
        pprint.pp(json.load(cache), compact=True, width=100)


##############################################################################
if __name__ == '__main__':
    main()
