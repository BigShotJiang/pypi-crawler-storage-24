#!/usr/bin/env python3
"""
Read values from the Keithley DMM6500.
"""

import argparse
import fcntl
import itertools
import sys
import time

from mmcbrs232 import common
from mmcbrs232 import dmm_interface


##############################################################################
# command line option handler
##############################################################################


def check_arguments():
    """
    handle command line options

    --------------------------------------------------------------------------
    args : none
    --------------------------------------------------------------------------
    returns
        args : int, <class 'argparse.Namespace'>
    --------------------------------------------------------------------------
    """
    parser = argparse.ArgumentParser(
        description='Reads voltage or current from the Keithley DMM6500.'
    )

    parser.add_argument(
        'channel', nargs='?', metavar='channel',
        help=(
            'Select measurement channel. '
            'For use with the 2001-SCAN card.'
        ),
        choices=range(1, 11),
        type=int, default=None)

    parser.add_argument(
        '-p', '--plain',
        action='store_true',
        help='print the requested figure only (deprecated: use -q instead)')
    parser.add_argument(
        '-q', '--quiet',
        action='store_true',
        help='print the requested figure only')
    parser.add_argument(
        '-c', '--capacitance',
        action='store_true',
        help='Read capacitance (F)')
    parser.add_argument(
        '--currentac',
        action='store_true',
        help='Read AC current (A)')
    parser.add_argument(
        '-i', '--currentdc',
        action='store_true',
        help='Read DC current (A)')
    parser.add_argument(
        '-r', '--resistance',
        action='store_true',
        help='Read two-wire resistance (\u03a9)')
    parser.add_argument(
        '-t', '--temperature',
        action='store_true',
        help='Read temperature (\u00b0C)')
    parser.add_argument(
        '--voltageac',
        action='store_true',
        help='Read AC voltage (V)')
    parser.add_argument(
        '-v', '--voltagedc',
        action='store_true',
        help='Read DC voltage (V)')

    args = parser.parse_args()

    channel = args.channel
    del args.channel

    return channel, args


##############################################################################
# serial port identification
##############################################################################


def port_name():
    """
    Get the port name from the cache ASSUMING that there's only one instrument
    in the test environment.

    --------------------------------------------------------------------------
    args : none
    --------------------------------------------------------------------------
    returns : string or None
        e.g. '/dev/ttyUSB0'
    --------------------------------------------------------------------------
    """
    _cached_instruments = common.cache_read({'instrument'})

    _channels = []
    for _port, _details in _cached_instruments.items():
        (
            _config,
            _device_type,
            _serial_number,
            _model,
            _manufacturer,
            _device_channels,
            _release_delay,
        ) = _details

        for _device_channel in _device_channels:
            _channels.append(
                common.Channel(
                    _port,
                    _config,
                    _serial_number,
                    _model,
                    _manufacturer,
                    _device_channel,
                    _device_type,
                    _release_delay,
                    None,
                )
            )

    try:
        _channel = _channels[0]
    except IndexError:
        return None

    return _channel.port


##############################################################################
# main
##############################################################################


def main():
    """ Read values from the Keithley DMM6500 """

    channel, args = check_arguments()

    with open(common.RS232_LOCK_GLOBAL, 'a') as lock_file:

        # acquire the RS232 global lock
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)

        # --------------------------------------------------------------------

        dmm = dmm_interface.Dmm6500()
        if dmm.init_failed:
            print('could not initialise serial port')
            return 3

        if channel is not None:
            # isolate all relays
            dmm.mux_open_all_channels()
            # enable relay for given channel
            dmm.mux_close_channel(channel)

        configure = {
                'capacitance': dmm.configure_read_capacitance,
                'currentac': dmm.configure_read_ac_current,
                'currentdc': dmm.configure_read_dc_current,
                'resistance': dmm.configure_read_resistance,
                'temperature': dmm.configure_read_temperature,
                'voltagedc': dmm.configure_read_dc_voltage,
                'voltageac': dmm.configure_read_ac_voltage,
        }

        # AC quantities sometimes return None on the first attempt
        retries = 3

        success = []

        for function, required in vars(args).items():
            if not required or function == 'plain' or function == 'quiet':
                continue

            configure[function]()

            value = None
            for _ in itertools.repeat(None, retries):
                value = dmm.read_value()
                if value is not None:
                    success.append(True)
                    break
                time.sleep(0.1)

            if args.plain or args.quiet:
                print(value)
            else:
                print(f'{function}, {common.si_prefix(value)}, {value}')

        if channel is not None:
            # isolate relay
            dmm.mux_open_channel(channel)

        # --------------------------------------------------------------------

        # release the RS232 global lock
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

    return 0 if any(success) else 3


##############################################################################
if __name__ == '__main__':
    sys.exit(main())
