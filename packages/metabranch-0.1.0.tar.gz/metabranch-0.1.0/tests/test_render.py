"""Tests for Rich renderers."""

from __future__ import annotations

from rich.console import Console

from metabranch.models import (
    BranchState,
    MetabranchDefinition,
    RepoLock,
    RepoLockStatus,
    StatusResult,
    WorkflowJournal,
)
from metabranch.render import (
    render_branch_list,
    render_progress,
    render_status,
    render_workflow_summary,
)


def test_render_branch_list_outputs_table_and_empty_notice() -> None:
    console = Console(record=True, width=120)
    render_branch_list(console, [])
    assert "No metabranches known locally." in console.export_text()

    console = Console(record=True, width=120)
    render_branch_list(
        console,
        [
            MetabranchDefinition(
                name="meta",
                base_ref="master",
                branches=("feature-one", "feature-two"),
            )
        ],
    )
    output = console.export_text()
    assert "Metabranches" in output
    assert "feature-one, feature-two" in output


def test_render_status_outputs_metabranch_plain_and_workflow_views() -> None:
    console = Console(record=True, width=120)
    render_status(
        console,
        StatusResult(
            branch_name="meta",
            is_metabranch=True,
            metabranch=MetabranchDefinition(
                name="meta",
                base_ref="master",
                branches=("feature-one",),
            ),
            branch_states=(
                BranchState(
                    name="feature-one",
                    role="contained",
                    state="available",
                    in_metabranch=True,
                    not_in_metabranch=0,
                    tracking_branch="origin/feature-one",
                    ahead=2,
                    behind=1,
                ),
            ),
            tracking_branch="origin/meta",
            ahead=5,
            behind=3,
            remote_config_created_at="2026-03-12T10:00:00+00:00",
            remote_config_updated_at="2026-03-12T11:00:00+00:00",
            remote_head_updated_at="2026-03-12T12:00:00+00:00",
            active_workflow=WorkflowJournal(
                workflow_id="wf-1",
                workflow_type="rebase",
                metabranch_name="meta",
                status="blocked",
                current_step="merge:feature-one",
            ),
            repo_lock=RepoLockStatus(
                lock=RepoLock(
                    owner="wf-1",
                    workflow_id="wf-1",
                    operation="rebase",
                    metabranch_name="meta",
                ),
            ),
            local_active_metabranch="meta",
        ),
    )
    output = console.export_text()
    assert "Metabranch Status" in output
    assert "Contained Branches" in output
    assert "origin/meta" in output
    assert "origin/feature-one" in output
    assert "On Meta" in output
    assert "Not On Meta" in output
    assert "Remote Config" in output
    assert "Ahead" in output
    assert "Behind" in output
    assert "Repo Lock" in output
    assert "Workflow" in output

    console = Console(record=True, width=120)
    render_status(
        console,
        StatusResult(
            branch_name="meta",
            is_metabranch=True,
            metabranch=MetabranchDefinition(name="meta", base_ref="master"),
            repo_lock=RepoLockStatus(
                lock=RepoLock(owner="wf-2", operation="push"),
                is_stale=True,
                reason="short operation lock exceeded 300s",
            ),
        ),
    )
    stale_output = console.export_text()
    assert "Repo Lock (Stale)" in stale_output
    assert "short operation lock exceeded 300s" in stale_output

    console = Console(record=True, width=120)
    render_status(
        console,
        StatusResult(
            branch_name="meta",
            is_metabranch=True,
            metabranch=MetabranchDefinition(name="meta", base_ref="master"),
        ),
    )
    assert "none" in console.export_text()

    console = Console(record=True, width=120)
    render_status(
        console,
        StatusResult(
            branch_name="meta",
            is_metabranch=True,
            metabranch=MetabranchDefinition(name="meta", base_ref="master"),
            branch_states=(
                BranchState(
                    name="feature-one",
                    role="contained",
                    state="available",
                    in_metabranch=None,
                    not_in_metabranch=None,
                ),
            ),
        ),
    )
    assert " -" in console.export_text()

    console = Console(record=True, width=120)
    render_status(
        console,
        StatusResult(
            branch_name="feature-one",
            is_metabranch=False,
            notices=("Current branch feature-one is not a metabranch.",),
        ),
    )
    assert "Current branch feature-one is not a metabranch." in console.export_text()


def test_render_workflow_summary_supports_custom_title() -> None:
    console = Console(record=True, width=120)
    render_workflow_summary(
        console,
        WorkflowJournal(
            workflow_id="wf-1",
            workflow_type="pull",
            metabranch_name="meta",
            status="running",
            current_step="pull:feature-one",
        ),
        verb="Resuming",
    )
    output = console.export_text()
    assert "Resuming Workflow" in output
    assert "pull:feature-one" in output


def test_render_progress_outputs_trace_line() -> None:
    console = Console(record=True, width=120)
    render_progress(console, "Rebuilding metabranch contents")
    assert "Rebuilding metabranch contents" in console.export_text()
