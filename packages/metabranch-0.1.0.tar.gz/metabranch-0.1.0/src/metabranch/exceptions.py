"""Custom exceptions for the metabranch package."""


class MetabranchError(Exception):
    """Base exception for metabranch operations."""

    pass


class InvalidGitRepositoryError(MetabranchError):
    """Raised when not in a Git repository."""

    pass


class InvalidMetabranchError(MetabranchError):
    """Raised when branch is not a metabranch."""

    pass


class InvalidBranchError(MetabranchError):
    """Raised when a referenced branch is invalid or missing."""

    pass


class BranchAlreadyExistsError(MetabranchError):
    """Raised when trying to create a branch that already exists."""

    pass


class DirtyWorkingTreeError(MetabranchError):
    """Raised when a destructive workflow is attempted on a dirty worktree."""

    pass


class ActiveWorkflowError(MetabranchError):
    """Raised when another metabranch workflow must be resumed or aborted first."""

    pass


class NoActiveWorkflowError(MetabranchError):
    """Raised when resume or abort is requested without an active workflow."""

    pass


class RepoLockError(MetabranchError):
    """Raised when the repo-wide metabranch lock cannot be acquired or released."""

    pass


class EditorCancelledError(MetabranchError):
    """Raised when the reconciliation editor could not produce a usable plan."""

    pass


class InvalidReconciliationPlanError(MetabranchError):
    """Raised when the edited reconciliation plan is invalid."""

    pass


class WorkflowConflictError(MetabranchError):
    """Raised when a blocked workflow still has unresolved Git conflicts."""

    pass
