"""App-facing branch status models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class CheckoutResult(BaseModel):
    """Result for a checkout operation."""

    branch_name: str
    is_metabranch: bool

    model_config = ConfigDict(frozen=True)


class BranchState(BaseModel):
    """Status for one branch within a metabranch view."""

    name: str
    role: str
    state: str
    in_metabranch: bool | None = None
    not_in_metabranch: int | None = None
    tracking_branch: str | None = None
    ahead: int | None = None
    behind: int | None = None

    model_config = ConfigDict(frozen=True)
