"""Metabranch - Manage Git metabranches for integration testing."""

__version__ = "0.1.0"
__author__ = "yug1991"
__email__ = "yuguan91@gmail.com"

from .exceptions import (
    ActiveWorkflowError,
    BranchAlreadyExistsError,
    DirtyWorkingTreeError,
    EditorCancelledError,
    InvalidBranchError,
    InvalidGitRepositoryError,
    InvalidMetabranchError,
    InvalidReconciliationPlanError,
    MetabranchError,
    NoActiveWorkflowError,
    RepoLockError,
    WorkflowConflictError,
)
from .git import Branch, GitBranch, GitClient, Metabranch, MetabranchConfig
from .models import (
    BranchState,
    MetabranchDefinition,
    ReconciliationPlanEntry,
    RepoLock,
    RepoLockStatus,
    WorkflowJournal,
)
from .sdk import BranchClient, Clients, RepositoryClient, WorkflowClient, build_clients

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "Clients",
    "RepositoryClient",
    "BranchClient",
    "WorkflowClient",
    "build_clients",
    "MetabranchDefinition",
    "BranchState",
    "RepoLock",
    "RepoLockStatus",
    "ReconciliationPlanEntry",
    "WorkflowJournal",
    "GitClient",
    "GitBranch",
    "Metabranch",
    "MetabranchConfig",
    "Branch",
    "MetabranchError",
    "InvalidGitRepositoryError",
    "InvalidMetabranchError",
    "InvalidBranchError",
    "BranchAlreadyExistsError",
    "DirtyWorkingTreeError",
    "ActiveWorkflowError",
    "NoActiveWorkflowError",
    "RepoLockError",
    "EditorCancelledError",
    "InvalidReconciliationPlanError",
    "WorkflowConflictError",
]
