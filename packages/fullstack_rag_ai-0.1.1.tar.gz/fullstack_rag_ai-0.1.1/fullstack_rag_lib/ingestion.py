import os
from langchain_community.document_loaders import PyPDFLoader

def load_documents(path):

    documents = []

    for file in os.listdir(path):
        if file.endswith(".pdf"):
            loader = PyPDFLoader(os.path.join(path, file))
            documents.extend(loader.load())

    return documents