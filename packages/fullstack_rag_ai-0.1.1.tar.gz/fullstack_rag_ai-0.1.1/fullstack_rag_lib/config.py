DEFAULT_CONFIG = {

    "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",

    "llm_model": "llama3",

    "chunk_size": 800,

    "chunk_overlap": 100

}