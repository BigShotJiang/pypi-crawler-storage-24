from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_ollama import ChatOllama
import warnings
warnings.filterwarnings("ignore")

def ask_question(question, index_path, model, embedding_model):

    embeddings = HuggingFaceEmbeddings(
        model_name=embedding_model
    )

    vectordb = FAISS.load_local(
        index_path,
        embeddings,
        allow_dangerous_deserialization=True
    )

    docs = vectordb.similarity_search(question, k=3)

    context = "\n\n".join(d.page_content for d in docs)

    llm = ChatOllama(model=model)

    prompt = f"""
Answer using the context below.

Context:
{context}

Question:
{question}
"""

    return llm.invoke(prompt)