# Fullstack RAG AI

Fullstack RAG AI is a lightweight Python library designed to build Retrieval-Augmented Generation (RAG) systems using internal documents and local Large Language Models.

The library allows developers to transform static documentation such as runbooks, architecture documentation, reports, and knowledge base files into intelligent searchable assistants.

It provides simple functions for document ingestion, vector database creation, and question answering using modern embedding models and LLMs.

The system is designed to run locally and supports customizable embedding models and language models.

---

## Key Features

• Load documents from local folders  
• Build vector databases using FAISS  
• Generate embeddings using HuggingFace models  
• Query documents using local LLMs through Ollama  
• Persistent vector database storage  
• Configurable models and parameters  

---

## Installation

Install the library from PyPI:

pip install fullstack-rag-ai

Before using the library ensure that Ollama is installed and a model is available.

Example:

ollama pull llama3

---

## Basic Workflow

The library follows a typical Retrieval-Augmented Generation pipeline:

Documents  
↓  
Chunking  
↓  
Embeddings  
↓  
Vector Database  
↓  
Similarity Search  
↓  
LLM Response Generation

---

## Provided Functions

The library currently provides three core functions.

1. load_documents()
2. build_vector_db()
3. ask_question()

Each function is described below.

---

## load_documents()

Loads documents from a local folder.

Supported formats currently include PDF documents.

Example usage:

from fullstack_rag_lib import load_documents

documents = load_documents("./documents")

Parameters:

path  
Path to a folder containing documents.

Returns:

A list of processed document objects ready for embedding.

---

## build_vector_db()

Creates a vector database from loaded documents.

The vector database stores document embeddings for similarity search and retrieval.

Example usage:

from fullstack_rag_lib import build_vector_db

build_vector_db(
    documents=documents,
    index_path="./vector_db",
    embedding_model="sentence-transformers/all-MiniLM-L6-v2"
)

Parameters:

documents  
Documents returned by load_documents()

index_path  
Directory where the FAISS vector database will be stored

embedding_model  
Embedding model used to convert text into vector representations

Example embedding models:

sentence-transformers/all-MiniLM-L6-v2  
BAAI/bge-base-en  
intfloat/e5-base-v2

---

## ask_question()

Queries the vector database and generates an answer using an LLM.

Example usage:

from fullstack_rag_lib import ask_question

answer = ask_question(
    question="What is described in the runbook?",
    index_path="./vector_db",
    model="llama3",
    embedding_model="sentence-transformers/all-MiniLM-L6-v2"
)

print(answer)

Parameters:

question  
User query

index_path  
Location of the stored vector database

model  
LLM model used for generating answers

embedding_model  
Embedding model used for retrieval

Example LLM models:

llama3  
mistral  
phi3  
codellama

These models can be installed using Ollama.

---

## Document Folder Example

Example folder structure:

documents/
   runbook.pdf
   architecture_notes.pdf
   evaluation_report.pdf

Example ingestion workflow:

documents = load_documents("./documents")

build_vector_db(
    documents,
    "./vector_db",
    "sentence-transformers/all-MiniLM-L6-v2"
)

---

## Custom Model Configuration

Users can customize both the embedding model and the language model.

Example:

answer = ask_question(
    question="How do we patch EC2 instances?",
    index_path="./vector_db",
    model="mistral",
    embedding_model="BAAI/bge-base-en"
)

This flexibility allows the system to run on different hardware configurations.

---

## External Document Sources

Documents can also be collected from external APIs before ingestion.

Example workflow:

1. Fetch documents from an API
2. Save them locally
3. Load them using load_documents()

Example:

documents = load_documents("./downloaded_docs")

---

## Vector Database Persistence

The vector database is stored locally so embeddings do not need to be regenerated every time.

Example directory:

vector_db/

Once the database is created, users can directly query it without rebuilding embeddings.

---

## Example Use Cases

Internal knowledge assistants  
DevOps runbook search  
Cloud engineering documentation assistants  
Research document Q&A systems  
Internal company knowledge bases

---

## Future Improvements

Future versions of the library will introduce several improvements.

Incremental vector database updates  
Automatic document change detection  
Integration with document management systems such as Confluence  
API connectors for document ingestion  

A planned feature will allow updating only the embeddings of modified documents instead of rebuilding the entire vector database.

---

## License

fullstack-solutions License