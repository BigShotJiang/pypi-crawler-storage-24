"""Tests for MorgenClient."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from guten_morgen.client import MorgenClient
from guten_morgen.config import Settings
from guten_morgen.errors import AuthenticationError, MorgenAPIError, NotFoundError, RateLimitError


def _mock_transport(status: int, body: dict | str = "", headers: dict[str, str] | None = None) -> httpx.MockTransport:
    """Create a MockTransport that returns a fixed response."""

    def handler(request: httpx.Request) -> httpx.Response:
        content = json.dumps(body).encode() if isinstance(body, dict) else body.encode() if body else b""
        return httpx.Response(
            status_code=status,
            content=content,
            headers=headers or {},
        )

    return httpx.MockTransport(handler)


def _make_client(transport: httpx.MockTransport) -> MorgenClient:
    settings = Settings(api_key="test-key", max_retries=0)
    return MorgenClient(settings, transport=transport)


class TestRequestErrorMapping:
    def test_401_raises_auth_error(self) -> None:
        client = _make_client(_mock_transport(401, "Unauthorized"))
        with pytest.raises(AuthenticationError, match="Invalid or missing API key"):
            client._request("GET", "/test")

    def test_429_raises_rate_limit(self) -> None:
        client = _make_client(_mock_transport(429, "Rate limited", {"Retry-After": "30"}))
        with pytest.raises(RateLimitError, match="Retry after 30s"):
            client._request("GET", "/test")

    def test_404_raises_not_found(self) -> None:
        client = _make_client(_mock_transport(404, "Not found"))
        with pytest.raises(NotFoundError, match="/test"):
            client._request("GET", "/test")

    def test_400_raises_api_error(self) -> None:
        client = _make_client(_mock_transport(400, "Bad request"))
        with pytest.raises(MorgenAPIError, match="400"):
            client._request("GET", "/test")

    def test_200_returns_json(self) -> None:
        client = _make_client(_mock_transport(200, {"data": "ok"}))
        result = client._request("GET", "/test")
        assert result == {"data": "ok"}

    def test_204_returns_none(self) -> None:
        client = _make_client(_mock_transport(204))
        result = client._request("GET", "/test")
        assert result is None


class TestListAllEvents:
    """Tests for list_all_events — multi-account fan-out + dedup."""

    def test_queries_both_accounts(self, client: MorgenClient) -> None:
        """Events from all calendar-capable accounts are returned."""
        events = client.list_all_events("2026-02-17T00:00:00", "2026-02-17T23:59:59")
        titles = [e.title for e in events]
        assert "Standup" in titles
        assert "Dentist" in titles

    def test_deduplicates_via_morgen(self, client: MorgenClient) -> None:
        """Synced copies with '(via Morgen)' in title are removed."""
        events = client.list_all_events("2026-02-17T00:00:00", "2026-02-17T23:59:59")
        titles = [e.title for e in events]
        assert "Standup (via Morgen)" not in titles

    def test_keeps_all_originals(self, client: MorgenClient) -> None:
        """Original events from both accounts are preserved."""
        events = client.list_all_events("2026-02-17T00:00:00", "2026-02-17T23:59:59")
        # acc-1: Standup, Lunch, Tasks and Deep Work, Optional Open Hours
        # acc-2: Dentist (synced copy removed)
        assert len(events) == 5


class TestListAllEventsFiltering:
    """Tests for list_all_events filtering: account_keys, calendar_names, active_only."""

    def test_filter_by_account_key(self, client: MorgenClient) -> None:
        """Only events from matching accounts are returned."""
        events = client.list_all_events(
            "2026-02-17T00:00:00",
            "2026-02-17T23:59:59",
            account_keys=["test@example.com:google"],
        )
        account_ids = {e.accountId for e in events}
        assert account_ids == {"acc-1"}

    def test_filter_by_email_only(self, client: MorgenClient) -> None:
        """Email-only key matches any provider for that email."""
        events = client.list_all_events(
            "2026-02-17T00:00:00",
            "2026-02-17T23:59:59",
            account_keys=["personal@example.com"],
        )
        account_ids = {e.accountId for e in events}
        assert account_ids == {"acc-2"}

    def test_active_only_filters_inactive_calendars(self, client: MorgenClient) -> None:
        """active_only=True skips calendars with isActiveByDefault=False."""
        # cal-2 (Holidays) has isActiveByDefault=False, belongs to acc-1
        # Events from cal-2 should be excluded — but our fake events are all on cal-1/cal-3
        # So count should stay the same since no events are on cal-2
        events = client.list_all_events(
            "2026-02-17T00:00:00",
            "2026-02-17T23:59:59",
            active_only=True,
        )
        assert len(events) == 5  # cal-2 has no events, so no change

    def test_filter_by_calendar_name(self, client: MorgenClient) -> None:
        """Only events from calendars with matching names are returned."""
        events = client.list_all_events(
            "2026-02-17T00:00:00",
            "2026-02-17T23:59:59",
            calendar_names=["Personal Calendar"],
        )
        # Only acc-2's "Personal Calendar" matches, after dedup only "Dentist" remains
        titles = [e.title for e in events]
        assert "Dentist" in titles
        assert "Standup" not in titles

    def test_combined_account_and_calendar_filter(self, client: MorgenClient) -> None:
        """Account + calendar name filters combine."""
        events = client.list_all_events(
            "2026-02-17T00:00:00",
            "2026-02-17T23:59:59",
            account_keys=["test@example.com:google"],
            calendar_names=["Work"],
        )
        # acc-1 matches, only "Work" calendar (cal-1) events
        titles = [e.title for e in events]
        assert "Standup" in titles
        assert "Lunch" in titles

    def test_calendar_names_bypass_active_only(self, client: MorgenClient) -> None:
        """Explicit calendar_names includes inactive calendars despite active_only=True."""
        # cal-2 "Holidays" has isActiveByDefault=False — verify it's still queried

        call_args: list[tuple[str, list[str]]] = []
        original = client.list_events

        def spy(account_id: str, calendar_ids: list[str], *a: object, **kw: object) -> Any:
            call_args.append((account_id, calendar_ids))
            return original(account_id, calendar_ids, *a, **kw)  # type: ignore[arg-type]

        with patch.object(client, "list_events", side_effect=spy):
            client.list_all_events(
                "2026-02-17T00:00:00",
                "2026-02-17T23:59:59",
                calendar_names=["Holidays"],
                active_only=True,
            )
        # cal-2 ("Holidays", inactive) should have been included in the query
        acc1_calls = [cids for aid, cids in call_args if aid == "acc-1"]
        assert acc1_calls, "acc-1 should have been queried"
        assert "cal-2" in acc1_calls[0]

    def test_no_matching_accounts_returns_empty(self, client: MorgenClient) -> None:
        """Non-matching account key returns no events."""
        events = client.list_all_events(
            "2026-02-17T00:00:00",
            "2026-02-17T23:59:59",
            account_keys=["nobody@nowhere.com:google"],
        )
        assert events == []


# ---------------------------------------------------------------------------
# Retry helpers
# ---------------------------------------------------------------------------


def _make_client_with_retry(
    transport: httpx.MockTransport,
    *,
    max_retries: int = 2,
    on_retry: Any = None,
) -> MorgenClient:
    settings = Settings(api_key="test-key", max_retries=max_retries)
    return MorgenClient(settings, transport=transport, on_retry=on_retry)


def _countdown_transport(fail_count: int, retry_after: str = "5") -> httpx.MockTransport:
    """Transport that returns 429 `fail_count` times, then 200."""
    call_count = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        if call_count["n"] <= fail_count:
            return httpx.Response(
                status_code=429,
                content=b"Rate limited",
                headers={"Retry-After": retry_after},
            )
        return httpx.Response(
            status_code=200,
            content=json.dumps({"data": "ok"}).encode(),
        )

    return httpx.MockTransport(handler)


class TestRetryWithBackoff:
    def test_retries_on_429_then_succeeds(self) -> None:
        """Single 429 followed by 200 should succeed."""
        recordings: list[tuple[int, int, int]] = []

        def recorder(wait: int, attempt: int, max_r: int) -> None:
            recordings.append((wait, attempt, max_r))

        client = _make_client_with_retry(
            _countdown_transport(1),
            on_retry=recorder,
        )
        result = client._request("GET", "/test")
        assert result == {"data": "ok"}
        assert len(recordings) == 1
        assert recordings[0] == (5, 1, 2)

    def test_exhausts_retries_raises_rate_limit(self) -> None:
        """After max_retries 429s, should raise RateLimitError."""
        recordings: list[tuple[int, int, int]] = []

        def recorder(wait: int, attempt: int, max_r: int) -> None:
            recordings.append((wait, attempt, max_r))

        client = _make_client_with_retry(
            _countdown_transport(10),  # more 429s than retries
            max_retries=2,
            on_retry=recorder,
        )
        with pytest.raises(RateLimitError):
            client._request("GET", "/test")
        assert len(recordings) == 2  # called for each retry attempt

    def test_no_retry_on_non_429(self) -> None:
        """Non-429 errors should not trigger retry."""
        recordings: list[tuple[int, int, int]] = []

        def recorder(wait: int, attempt: int, max_r: int) -> None:
            recordings.append((wait, attempt, max_r))

        client = _make_client_with_retry(
            _mock_transport(400, "Bad request"),
            on_retry=recorder,
        )
        with pytest.raises(MorgenAPIError):
            client._request("GET", "/test")
        assert recordings == []

    def test_retry_after_clamped_floor(self) -> None:
        """Retry-After below 5 is clamped to 5."""
        recordings: list[tuple[int, int, int]] = []

        def recorder(wait: int, attempt: int, max_r: int) -> None:
            recordings.append((wait, attempt, max_r))

        client = _make_client_with_retry(
            _countdown_transport(1, retry_after="1"),
            on_retry=recorder,
        )
        client._request("GET", "/test")
        assert recordings[0][0] == 5

    def test_retry_after_clamped_ceiling(self) -> None:
        """Retry-After above 60 is clamped to 60."""
        recordings: list[tuple[int, int, int]] = []

        def recorder(wait: int, attempt: int, max_r: int) -> None:
            recordings.append((wait, attempt, max_r))

        client = _make_client_with_retry(
            _countdown_transport(1, retry_after="120"),
            on_retry=recorder,
        )
        client._request("GET", "/test")
        assert recordings[0][0] == 60

    def test_retry_after_missing_defaults_to_15(self) -> None:
        """Missing Retry-After header defaults to 15s."""
        recordings: list[tuple[int, int, int]] = []

        def recorder(wait: int, attempt: int, max_r: int) -> None:
            recordings.append((wait, attempt, max_r))

        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            if call_count["n"] <= 1:
                return httpx.Response(status_code=429, content=b"Rate limited")
            return httpx.Response(
                status_code=200,
                content=json.dumps({"data": "ok"}).encode(),
            )

        client = _make_client_with_retry(
            httpx.MockTransport(handler),
            on_retry=recorder,
        )
        client._request("GET", "/test")
        assert recordings[0][0] == 15

    def test_no_callback_still_retries(self) -> None:
        """Without on_retry callback, retry still works (just sleeps silently)."""
        with patch("time.sleep"):
            client = _make_client_with_retry(
                _countdown_transport(1, retry_after="5"),
                on_retry=None,
            )
            result = client._request("GET", "/test")
            assert result == {"data": "ok"}

    def test_zero_max_retries_raises_immediately(self) -> None:
        """max_retries=0 means no retry, raise on first 429."""
        client = _make_client_with_retry(
            _countdown_transport(1),
            max_retries=0,
        )
        with pytest.raises(RateLimitError):
            client._request("GET", "/test")


class TestReadTimeoutRetry:
    """ReadTimeout should be retried for GET requests only."""

    def test_get_retries_on_read_timeout_then_succeeds(self) -> None:
        """GET request that times out once then succeeds should return data."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            if call_count["n"] <= 1:
                raise httpx.ReadTimeout("timed out")
            return httpx.Response(200, content=json.dumps({"data": "ok"}).encode())

        client = _make_client_with_retry(httpx.MockTransport(handler))
        result = client._request("GET", "/test")
        assert result == {"data": "ok"}
        assert call_count["n"] == 2

    def test_get_exhausts_retries_raises_timeout_error(self) -> None:
        """GET request that always times out should raise after max_retries."""

        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("timed out")

        client = _make_client_with_retry(httpx.MockTransport(handler), max_retries=2)
        with pytest.raises(MorgenAPIError, match="timed out"):
            client._request("GET", "/test")

    def test_post_does_not_retry_on_read_timeout(self) -> None:
        """POST (non-idempotent) should NOT retry on ReadTimeout."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            raise httpx.ReadTimeout("timed out")

        client = _make_client_with_retry(httpx.MockTransport(handler), max_retries=2)
        with pytest.raises(MorgenAPIError, match="timed out"):
            client._request("POST", "/test")
        assert call_count["n"] == 1  # no retry

    def test_timeout_error_includes_proxy_hint(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Error message should mention proxy when HTTP_PROXY is set."""
        monkeypatch.delenv("HTTP_PROXY", raising=False)
        monkeypatch.delenv("http_proxy", raising=False)
        monkeypatch.delenv("https_proxy", raising=False)
        monkeypatch.setenv("HTTPS_PROXY", "http://proxy:8080")

        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("timed out")

        client = _make_client_with_retry(httpx.MockTransport(handler), max_retries=0)
        with pytest.raises(MorgenAPIError, match="proxy") as exc_info:
            client._request("GET", "/test")
        assert "HTTPS_PROXY" in str(exc_info.value)
        assert "MORGEN_TIMEOUT" in " ".join(exc_info.value.suggestions)

    def test_timeout_error_no_proxy_hint_when_no_proxy(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Error message should NOT mention proxy when no proxy env vars set."""
        monkeypatch.delenv("HTTP_PROXY", raising=False)
        monkeypatch.delenv("HTTPS_PROXY", raising=False)
        monkeypatch.delenv("http_proxy", raising=False)
        monkeypatch.delenv("https_proxy", raising=False)

        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("timed out")

        client = _make_client_with_retry(httpx.MockTransport(handler), max_retries=0)
        with pytest.raises(MorgenAPIError, match="timed out") as exc_info:
            client._request("GET", "/test")
        assert "proxy" not in str(exc_info.value).lower()

    def test_connect_timeout_retries_for_get(self) -> None:
        """ConnectTimeout should also be retried for GET requests."""
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            if call_count["n"] <= 1:
                raise httpx.ConnectTimeout("connect timed out")
            return httpx.Response(200, content=json.dumps({"data": "ok"}).encode())

        client = _make_client_with_retry(httpx.MockTransport(handler))
        result = client._request("GET", "/test")
        assert result == {"data": "ok"}
        assert call_count["n"] == 2


class TestBearerAuth:
    def test_uses_bearer_header_when_available(self) -> None:
        """Client uses Bearer auth when bearer_token is set."""
        requests_seen: list[httpx.Request] = []

        def capture_handler(request: httpx.Request) -> httpx.Response:
            requests_seen.append(request)
            return httpx.Response(200, json={"data": {"tags": []}})

        transport = httpx.MockTransport(capture_handler)
        settings = Settings(api_key="api-key", bearer_token="my-bearer")
        client = MorgenClient(settings, transport=transport)
        client._request("GET", "/tags/list")
        assert requests_seen[0].headers["authorization"] == "Bearer my-bearer"

    def test_uses_apikey_when_no_bearer(self) -> None:
        """Client uses ApiKey auth when bearer_token is None."""
        requests_seen: list[httpx.Request] = []

        def capture_handler(request: httpx.Request) -> httpx.Response:
            requests_seen.append(request)
            return httpx.Response(200, json={"data": {"tags": []}})

        transport = httpx.MockTransport(capture_handler)
        settings = Settings(api_key="api-key", bearer_token=None)
        client = MorgenClient(settings, transport=transport)
        client._request("GET", "/tags/list")
        assert requests_seen[0].headers["authorization"] == "ApiKey api-key"


class TestListTaskLists:
    def test_returns_all_lists(self, client: MorgenClient) -> None:
        lists = client.list_task_lists()
        assert len(lists) == 3
        names = [tl.name for tl in lists]
        assert "Inbox" in names
        assert "Run - Work" in names

    def test_inbox_has_role(self, client: MorgenClient) -> None:
        lists = client.list_task_lists()
        inbox = [tl for tl in lists if tl.id == "inbox"][0]
        assert inbox.role == "inbox"


class TestTaskListCRUD:
    def test_create_task_list(self, client: MorgenClient) -> None:
        result = client.create_task_list({"name": "Project: X", "color": "#ff0000"})
        assert result is not None
        assert result.name == "Project: X"

    def test_update_task_list(self, client: MorgenClient) -> None:
        result = client.update_task_list({"id": "list-work@morgen.so", "name": "Work Tasks"})
        assert result is not None
        assert result.id == "list-work@morgen.so"

    def test_delete_task_list(self, client: MorgenClient) -> None:
        # Should not raise
        client.delete_task_list("list-work@morgen.so")


class TestSocksProxySupport:
    """Verify SOCKS proxy dependencies are available for httpx."""

    def test_socksio_importable(self) -> None:
        """socksio must be installed so httpx can use SOCKS proxies from env vars."""
        import socksio  # noqa: F401

    def test_httpx_accepts_socks5_proxy(self) -> None:
        """httpx.Client should accept a socks5:// proxy URL without error."""
        client = httpx.Client(proxy="socks5://127.0.0.1:1080")
        client.close()
