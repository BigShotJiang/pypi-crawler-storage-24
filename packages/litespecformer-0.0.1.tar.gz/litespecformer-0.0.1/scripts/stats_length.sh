# python scripts/main/stats_length.py --subset_dir ../LSPD_split/train 

python scripts/main/stats_length.py --subset_dir ../LSPD_split/train  --num_processes 30