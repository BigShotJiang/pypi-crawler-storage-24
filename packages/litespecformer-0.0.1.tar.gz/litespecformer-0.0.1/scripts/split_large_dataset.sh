python scripts/main/split_large_dataset.py \
    --input_path ../LSPD/train \
    --output_dir ../LSPD_split_2/train \
    --num_subsets 2 \
    --shuffle \
    --seed 42