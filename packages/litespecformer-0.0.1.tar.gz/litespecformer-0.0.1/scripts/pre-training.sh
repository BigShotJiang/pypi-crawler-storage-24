export CUDA_VISIBLE_DEVICES=0,1,3
export HF_ENDPOINT="https://hf-mirror.com"

accelerate launch --multi_gpu --mixed_precision=fp16 --num_processes=3 \
  src/pre_training.py \
    --team_name "whenxuan-xidian-university" \
    --project_name "LiteSpecFormer-Training" \
    --experiment_name "pre-training-with-gated" \
    --scenario_name "pre-training" \
    --seed 42 \
    --resume_from_checkpoint checkpoints/LiteSpecFormer_2026-03-18_19-03-24_bs4096_lr0.0004_w0.0_b10.9_b20.999_eps1e-08_warmup1000/checkpoint-13500-2.02834-3.29063
