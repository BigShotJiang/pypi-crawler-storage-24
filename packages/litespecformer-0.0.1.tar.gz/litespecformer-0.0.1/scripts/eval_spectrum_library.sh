export CUDA_VISIBLE_DEVICES=2

for pred_len in 12 24 48 96
do
  for seq_len in 336 512
  do
    python src/eval_spectrum_library.py \
      --dataset_name "spec151" \
      --seq_len $seq_len \
      --pred_len $pred_len \
      --data_path "./data/eval/spec151_data.csv" \
      --root_path "./data/eval/spec151_data.csv" \
      --checkpoint "./results" \
      --model_params "checkpoints/LiteSpecFormer_2026-03-19_10-48-38_bs4096_lr0.0004_w0.0_b10.9_b20.999_eps1e-08_warmup1000/checkpoint-9500-2.00294-3.26513"
  done
done