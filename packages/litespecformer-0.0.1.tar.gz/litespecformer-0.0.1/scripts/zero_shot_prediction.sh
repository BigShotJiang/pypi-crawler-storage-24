export CUDA_VISIBLE_DEVICES=2

for seq_length in 512 336
do
  for prediction_length in 96 192
  do
    python src/zero_shot_prediction.py \
      --dataset_name "data/eval/Madrid" \
      --seq_length $seq_length \
      --prediction_length $prediction_length \
      --batch_size 512 \
      --checkpoint_path "checkpoints/LiteSpecFormer_2026-03-19_10-48-38_bs4096_lr0.0004_w0.0_b10.9_b20.999_eps1e-08_warmup1000/checkpoint-49500-1.96604-3.17331/model.safetensors"
  done
done