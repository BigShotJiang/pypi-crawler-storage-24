"""Scopinator CLI module."""
