# ftsaaipkg/exit_cli.py

import os

def main():
    """
    Stops the live streaming of FTSA AI MT5 Connector
    by deleting the running flag file.
    """
    RUN_FILE = os.path.join(os.path.expanduser("~"), "ftsaai_running.txt")

    if os.path.exists(RUN_FILE):
        os.remove(RUN_FILE)
        print("✅ Live streaming stopped successfully.")
    else:
        print("⚠️ No live streaming process found or already stopped.")