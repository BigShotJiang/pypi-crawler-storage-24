# FTSAAI MT5 CLI Tool

This is a local MT5 bridge for FTSA AI.

## Installation

```bash
pip install -e .
ftsai-run