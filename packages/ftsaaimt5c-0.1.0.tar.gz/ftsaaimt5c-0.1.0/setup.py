# setup.py

from setuptools import setup, find_packages

setup(
    name="FTSAAIMT5C",  # updated name for global install
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pymongo>=4.3.3",
        "python-dotenv>=1.0.0",
        "MetaTrader5>=5.0.5640",
        "click>=8.0.0",
        "requests>=2.32.5"
    ],
    entry_points={
        "console_scripts": [
            "ftsaai-run = ftsaaipkg.cli:run_cli",       # start live streaming
            "exit-ftsaai = ftsaaipkg.exit_cli:main"    # stop live streaming
        ]
    },
    python_requires='>=3.10',
    author="Kelvin Mburu",
    description="FTSA AI MT5 Connector CLI",
    include_package_data=True,
    classifiers=[
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "License :: OSI Approved :: MIT License",
    "Operating System :: Microsoft :: Windows :: Windows 10",
    "Intended Audience :: Financial and Insurance Industry",
    "Topic :: Office/Business :: Financial",
    "Development Status :: 4 - Beta"
],
)