# tubesense

[![PyPI version](https://img.shields.io/pypi/v/tubesense.svg)](https://pypi.org/project/tubesense/)
[![Python versions](https://img.shields.io/pypi/pyversions/tubesense.svg)](https://pypi.org/project/tubesense/)
[![License](https://img.shields.io/pypi/l/tubesense.svg)](https://github.com/Pointmatic/tubesense/blob/main/LICENSE)
[![Typed](https://img.shields.io/badge/typed-py.typed-blue.svg)](https://peps.python.org/pep-0561/)

A multi-dimensional semantic analysis engine for long-form content, initially targeting YouTube video transcripts.

`tubesense` segments transcripts into a hierarchical discourse structure (utterances → verses → chapters), scores each segment across the ten axes of the Multi-Dimensional Sentiment Analysis (MDSA) framework, assembles results into a semantic graph, and exposes that graph for retrieval and higher-order analysis.

> This is an early release reserving the `tubesense` package name. Full functionality is under active development.
