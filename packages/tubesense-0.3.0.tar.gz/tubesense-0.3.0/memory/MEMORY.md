# Memory Index

## Feedback
- [feedback_git_commits.md](feedback_git_commits.md) — Do not commit; user handles all git operations
