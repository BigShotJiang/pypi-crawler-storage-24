---
name: No git commits — user handles all git operations
description: User manages all git commits, staging, and tagging themselves
type: feedback
---

Do not create git commits, stage files, or push/tag. The user handles all git operations.

**Why:** User explicitly stated "You won't be committing anything. I'll do that."

**How to apply:** Never run `git add`, `git commit`, `git tag`, or `git push`. Just create/edit files and let the user handle version control.
