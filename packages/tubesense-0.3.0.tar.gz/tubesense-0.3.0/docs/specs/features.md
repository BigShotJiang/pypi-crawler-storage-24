# features.md — tubesense (Python 3.12)

**Version:** 0.1 — Pending Approval

This document describes **what** `tubesense` does from a user and system perspective. It is intentionally free of implementation details — those belong in `tech-spec.md`. All requirements here inform the tech spec, the stories, and acceptance criteria during implementation.

---

## 1. Project Overview

`tubesense` is a full-featured proof-of-concept multi-dimensional sentiment analysis engine for YouTube video transcripts. It fetches transcripts via **TubeFetch**, segments them into a hierarchical discourse structure, scores each segment across the ten sentiment axes defined in the **Multi-Dimensional Sentiment Analysis (MDSA) framework** (`docs/specs/sentiment-analysis-specification.md`), assembles results into a semantic graph, and exposes that graph for retrieval and higher-order analysis.

The sentence-level valence classifier from `sentiment-poc` (the rough PoC) is the analytical backbone — reimplemented cleanly as a first-class component of this system.

`tubesense` implements the first stage of the three-part analytical framework:

1. **Multi-Dimensional Sentiment Analysis** ← *this project* (`docs/specs/sentiment-analysis-specification.md`)
2. **Multi-Dimensional Contextual Analysis** — deferred (`docs/specs/contextual-analysis-specification.md`)
3. **Sentiment-Context Interface** — deferred (`docs/specs/interface-specification.md`)

All ten MDSA axes are within scope. Valence is implemented end-to-end first; remaining axes are added incrementally. The contextual analysis and interface layers are explicitly out of scope for this project.

---

## 2. Users & Use Cases

| User | Primary Use Case |
|---|---|
| Researcher / data scientist | Explore sentiment distributions and discourse structure interactively in JupyterLab |
| Developer | Import `tubesense` as a library to score transcripts programmatically |
| CLI user | Run the full pipeline on one or more YouTube videos from the terminal |

---

## 3. Environment Setup

- Python pinned to **3.12**
- Environment managed via `pyve` with micromamba backend; `pyve --init` sets up from project root
- Dependencies declared in `pyproject.toml` and `environment.yml`
- Apache-2.0 license from project inception
- Optional `TUBEFETCH_YT_API_KEY` and `HF_TOKEN` environment variables supported via `.env`

---

## 4. Transcript Ingestion

Transcript ingestion is handled entirely by **TubeFetch** (`pip install tubefetch`). `tubesense` does not implement YouTube API access, transcript fetching, retry logic, or media download. These are TubeFetch responsibilities.

`tubesense` consumes the following TubeFetch outputs:

| TubeFetch output | Format | `tubesense` use |
|---|---|---|
| `transcript.json` | Timestamped segments with content hash | Primary input — segments feed utterance-level analysis |
| `metadata.json` | Title, channel, duration, tags, upload date, content hash | Video-level graph node metadata |
| `video_bundle.json` | Unified metadata + transcript | Atomic input unit for pipeline runs |

Content hashes from TubeFetch are used by `tubesense` to support incremental processing — videos whose transcript hash has not changed since a prior run are skipped.

### 4.1 Input Modes

`tubesense` accepts input in the following forms:

| Input mode | Example |
|---|---|
| Single video ID or URL | `tubesense score dQw4w9WgXcQ` |
| Multiple video IDs | `tubesense score ID1 ID2 ID3` |
| File of video IDs | `tubesense score --file video_ids.txt` |
| Local TubeFetch output directory | `tubesense score --from-dir ./out/dQw4w9WgXcQ` |

When given a video ID or URL directly, `tubesense` invokes TubeFetch internally to fetch and cache the transcript before proceeding. When given a local directory, it reads TubeFetch output from disk — no network call required.

### 4.2 Caching

- TubeFetch output is cached to a configurable local directory (default: `data/tubefetch/`)
- `tubesense` output (scored graphs, reports) is cached separately (default: `data/scored/`)
- A `--force` flag re-fetches and re-scores regardless of cache state
- Incremental mode (default) skips re-scoring videos whose transcript content hash is unchanged

---

## 5. Transcript Segmentation

Before scoring, transcripts are segmented into a three-level hierarchy. TubeFetch's acoustic paragraph chunking (silence-gap-based) provides a starting signal; `tubesense` applies additional topical segmentation on top.

### 5.1 Segmentation Levels

| Level | Unit | Typical size |
|---|---|---|
| **Utterance** | Individual sentence or clause | 5–40 tokens |
| **Verse** | Topically coherent passage | 3–15 utterances |
| **Chapter** | Major topic block | 2–10 verses |

### 5.2 Segmentation Methods

**Utterance boundaries** — sentence boundary detection applied within each TubeFetch transcript segment. Each utterance retains the timestamp range from its parent TubeFetch segment.

**Verse boundaries** — embedding-based topical coherence segmentation. Sentence embeddings are computed for each utterance; verses are delineated at cosine similarity drop-offs using a sliding window. Boundary threshold is configurable.

**Chapter boundaries** — higher-level coherence segmentation over verse embeddings, using the same sliding-window approach at a coarser granularity. Explicit structural markers from TubeFetch (chapter timestamps, if present) are used as hard boundary hints.

### 5.3 Segmentation Output

The segmentation stage produces a **transcript tree**: a rooted hierarchy (video → chapters → verses → utterances). Each node records its text span, timestamp range, and level. The tree is the input to all downstream scoring and graph construction.

---

## 6. Multi-Dimensional Sentiment Scoring

`tubesense` scores transcript segments across the ten MDSA axes defined in `docs/specs/sentiment-analysis-specification.md`. That document is the authoritative specification for axis definitions, scales, anchor examples, and scoring rules. This section specifies how scoring is applied within the `tubesense` pipeline.

### 6.1 Axis Scope

All ten MDSA axes are within scope:

| Axis | Scale | Notes |
|---|---|---|
| Valence | −1.0 → +1.0 | Implemented first — sentence-level classifier from rough PoC |
| Intensity | 0 → 1.0 | |
| Subjectivity | 0 → 1.0 | |
| Certainty | −1.0 → +1.0 | |
| Outlook | −1.0 → +1.0 | Scored `null` when segment is not forward-looking |
| Register | −1.0 → +1.0 | |
| Manners | −1.0 → +1.0 | |
| Intent | −1.0 → +1.0 | |
| Irony | 0 → 1.0 | |
| Emotion | Categorical | joy, anger, fear, sadness, surprise, disgust, neutral |

### 6.2 Scoring Granularity

Scoring is applied at all three levels of the transcript tree:

- **Utterance level** — direct model inference per sentence
- **Verse level** — aggregated from constituent utterance scores; confidence-weighted mean for continuous axes; majority or plurality for categorical (Emotion)
- **Chapter level** — aggregated from constituent verse scores by the same method

Aggregation weights use `valence_confidence` from the utterance scorer as the base weight. Axis-specific confidence values are added as axes are implemented.

### 6.3 Valence Scoring (Backbone)

The valence scorer is a reimplementation of the rough PoC bespoke model:

- **Encoder:** `microsoft/deberta-v3-base` with LoRA adapters
- **Pooling:** learned attention pooling over token embeddings
- **Classifier:** MLP head, 3-class output (NEGATIVE / NEUTRAL / POSITIVE)
- **Weights:** transferred from rough PoC `models/bespoke/best-model/` — not retrained
- **Output fields per utterance:** `valence_label`, `valence_confidence`, `score_positive`, `score_neutral`, `score_negative`, `valence_polarity`

### 6.4 Remaining Axis Scoring

The remaining nine axes are scored via **zero-shot LLM inference** using the Anthropic API (Claude). A structured prompt presents the utterance text and requests a JSON score object conforming to the MDSA schema. The prompt template and axis definitions are derived directly from `docs/specs/sentiment-analysis-specification.md`.

Zero-shot LLM scoring is the baseline approach for all non-valence axes. It requires no labeled training data and can be applied immediately. Individual axes may be replaced with fine-tuned classifiers in later iterations without changing the pipeline interface.

### 6.5 Null Handling

Per the MDSA specification: if an axis is not applicable to a given segment (e.g., Outlook for a purely past-tense utterance), the value is recorded as `null` rather than `0`. The pattern of nulls is preserved in all output formats and is analytically informative.

### 6.6 Irony Flagging

Where the Irony axis score is ambiguous (score between 0.3 and 0.7), the utterance is flagged for human review in the output. This follows the MDSA specification's handling of irony ambiguity.

---

## 7. Semantic Graph Construction

After scoring, the transcript tree and all axis scores are materialized as a **directed semantic graph** — one graph per video.

### 7.1 Node Types

| Node type | Represents | Key properties |
|---|---|---|
| `Video` | Entire transcript | TubeFetch metadata, content hash, duration |
| `Chapter` | Major topic block | Timestamp range, aggregated MDSA scores |
| `Verse` | Topically coherent passage | Timestamp range, aggregated MDSA scores, topic label |
| `Utterance` | Individual sentence | Timestamp, full MDSA score vector, raw text |

### 7.2 Edge Types

| Edge type | Connects | Meaning |
|---|---|---|
| `contains` | Chapter→Verse, Verse→Utterance | Hierarchical membership |
| `follows` | Any node → next sibling | Temporal sequence |
| `shares_topic` | Non-adjacent Verse nodes | Cosine similarity above threshold |
| `sentiment_shift` | Adjacent Verse nodes | Significant polarity change between verses |

### 7.3 Graph Storage

- In-memory graph via **NetworkX** for the PoC
- Serialized to JSON (node-link format) for persistence and caching
- One graph file per video: `data/scored/{video_id}/graph.json`

---

## 8. Retrieval and Analysis

The interface layer exposes the semantic graph for querying and higher-order analysis.

### 8.1 Cross-Temporal Retrieval

Given a query — topic phrase, keyword, or sentiment condition — retrieve all matching graph nodes regardless of their temporal position in the transcript. Queries are matched against node text and topic labels via embedding similarity.

### 8.2 Sentiment Aggregation

Compute a sentiment summary at any level of the hierarchy:
- Per-axis mean, min, max, and standard deviation across constituent utterances
- Confidence-weighted aggregation (default)
- Raw (unweighted) aggregation (optional)

### 8.3 Narrative Arc

Trace valence polarity across chapters in temporal order to surface the emotional structure of a video — how sentiment evolves from opening to close.

### 8.4 Anomaly Detection

Identify utterances or verses where local sentiment diverges significantly from the enclosing chapter's aggregate — potential markers of sarcasm, irony, hedging, or topic shifts.

---

## 9. Output Formats

| Format | Description |
|---|---|
| `graph.json` | Full semantic graph in NetworkX node-link JSON format |
| `report.json` | Per-video summary: axis scores by chapter, narrative arc, anomalies |
| `utterances.parquet` | Flat table of all utterances with full MDSA score vector |
| `report.txt` | Human-readable plain-text summary for terminal output |

All outputs are written to `data/scored/{video_id}/`.

---

## 10. Library API

`tubesense` is an importable Python package.

Minimum public API:

```python
from tubesense import Pipeline, load_graph

# Run full pipeline on a video
pipeline = Pipeline(config)
graph = pipeline.run("dQw4w9WgXcQ")

# Access scores
for utterance in graph.utterances:
    print(utterance.text, utterance.scores.valence, utterance.scores.emotion)

# Query across temporal distance
results = graph.query("climate change", top_k=10)

# Load a previously scored graph
graph = load_graph("data/scored/dQw4w9WgXcQ/graph.json")
```

---

## 11. CLI

| Command | Description |
|---|---|
| `tubesense score <id>` | Fetch (if needed) and score a video end-to-end |
| `tubesense score --file <path>` | Batch score from a file of video IDs |
| `tubesense score --from-dir <path>` | Score from existing TubeFetch output directory |
| `tubesense report <id>` | Print human-readable report for a scored video |
| `tubesense query <id> <query>` | Query a scored video's graph |
| `tubesense doctor` | Validate environment, API keys, and model availability |
| `tubesense clean` | List and remove cached data |

Global flags: `--config <path>`, `--verbose`, `--force`.

`score` command additional flags:

| Flag | Description |
|---|---|
| `--axes <list>` | Comma-separated axes to score (default: all) |
| `--file <path>` | Text file of video IDs, one per line |
| `--from-dir <path>` | Use existing TubeFetch output directory |
| `--workers <int>` | Parallel workers for batch scoring (default: 3) |

---

## 12. Non-Functional Requirements

| Requirement | Target |
|---|---|
| Reproducibility | Same video + same config + same model weights = identical output |
| Transparency | Every scored node records the model or method that produced each axis score |
| Incrementality | Content hash comparison skips re-scoring unchanged videos |
| Offline capability | Once TubeFetch output and model weights are cached, scoring runs without network (except LLM axes) |
| Extensibility | Each axis scorer sits behind a clean interface — zero-shot LLM scorers are replaceable with fine-tuned models without pipeline changes |

---

## 13. Out of Scope

- Multi-Dimensional Contextual Analysis (Document 2) — deferred
- Sentiment-Context Interface (Document 3) — deferred
- Multi-speaker diarization
- Multi-transcript graph alignment
- Web UI
- Production deployment or real-time pipeline
- Fine-tuned classifiers for non-valence axes (zero-shot LLM baseline only in this project)
- Retraining the valence model (weights transferred from rough PoC, not retrained)

---

*Document version: 0.1 — Pending Approval*

---

A few notes on decisions embedded here:

The three framework specification documents are referenced by path (`docs/specs/sentiment-analysis-specification.md`) rather than summarized — no duplication. The features doc defers entirely to the spec for axis definitions, scales, and examples.

Zero-shot LLM scoring for non-valence axes is called out explicitly as a baseline with a clean swap interface — this makes the "decide during implementation" answer to the axis question workable in stories without requiring upfront commitment to classifier architecture per axis.

The `--from-dir` input mode is worth flagging: it lets `tubesense` run entirely offline against pre-fetched TubeFetch output, which is important for reproducible research runs.

Please review and approve, or flag anything to adjust. Once approved I'll proceed to `tech-spec.md`.