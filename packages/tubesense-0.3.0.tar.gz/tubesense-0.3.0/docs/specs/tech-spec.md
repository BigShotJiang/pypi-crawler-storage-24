# tech-spec.md — tubesense (Python 3.12)
**Version:** 0.1 — Pending Approval

This document defines **how** `tubesense` is built — architecture, module layout, dependencies, data models, API signatures, and cross-cutting concerns. It is the implementation companion to `features.md` and the authoritative reference for the stories in `stories.md`.

The three framework specification documents are authoritative references for analytical behaviour and are not duplicated here:

- `docs/specs/sentiment-analysis-specification.md` — MDSA axis definitions, scales, scoring rules
- `docs/specs/contextual-analysis-specification.md` — MDCA facet definitions, knowability framework (deferred)
- `docs/specs/interface-specification.md` — SCI pipeline, modulation rules, conflict detection (deferred)

---

## 1. Runtime & Tooling

| Concern | Tool | Version / Notes |
|---|---|---|
| Language | Python | 3.12 |
| Environment manager | pyve + micromamba | micromamba backend; `pyve --init` sets up from project root |
| Package manifest | `pyproject.toml` | PEP 517/518, build backend: `hatchling` |
| Dependency locking | `conda-lock` | Generates `conda-lock.yml` from `environment.yml` |
| Linter | `ruff` | Replaces flake8 + isort + pyupgrade |
| Formatter | `ruff format` | Consistent with Black style |
| Type checker | `mypy` | Strict mode (`--strict`) |
| Test runner | `pytest` | With `pytest-asyncio` for async tests |
| Coverage | `pytest-cov` | HTML + terminal reports |
| Notebook interface | JupyterLab | `>=4.0`; notebooks live in `notebooks/` |
| Transcript ingestion | TubeFetch | `pip install tubefetch`; CLI and library usage |
| LLM API | Anthropic Python SDK | Zero-shot MDSA scoring for non-valence axes |
| Concurrency | gentlify | Async batch dispatch, retry, rate limiting for LLM API calls |
| Secrets management | `python-dotenv` | Loads `HF_TOKEN`, `ANTHROPIC_API_KEY`, `TUBEFETCH_YT_API_KEY` from `.env` |

---

## 2. Dependencies

### 2.1 Runtime Dependencies

| Package | Version | Purpose |
|---|---|---|
| `tubefetch` | `>=1.4` | YouTube transcript and metadata ingestion |
| `anthropic` | `>=0.25` | Anthropic API client — zero-shot MDSA scoring |
| `transformers` | `>=4.40` | DeBERTa encoder and tokenizer |
| `torch` | `>=2.2` | PyTorch inference backend |
| `peft` | `>=0.10` | LoRA adapter loading |
| `scikit-learn` | `>=1.4` | Embedding cosine similarity, segmentation utilities |
| `networkx` | `>=3.2` | Semantic graph construction and traversal |
| `spacy` | `>=3.7` | Sentence boundary detection |
| `sentence-transformers` | `>=2.6` | Verse/chapter embedding for topical segmentation |
| `pandas` | `>=2.2` | Utterance-level scored output (parquet) |
| `pyarrow` | `>=15.0` | Parquet read/write |
| `gentlify` | `>=2.0` | Async rate limiting and retry for Anthropic API calls |
| `python-dotenv` | `>=1.0` | `.env` credential loading |
| `pyyaml` | `>=6.0` | `config.yml` parsing |
| `click` | `>=8.1` | CLI framework |
| `rich` | `>=13.0` | CLI output formatting |

### 2.2 Visualization Dependencies (notebook)

| Package | Version | Purpose |
|---|---|---|
| `matplotlib` | `>=3.8` | Static plots |
| `seaborn` | `>=0.13` | Statistical visualization |
| `plotly` | `>=5.20` | Interactive graph visualizations |
| `ipywidgets` | `>=8.1` | Notebook interactive controls |

### 2.3 Development Dependencies

| Package | Purpose |
|---|---|
| `pytest` | Test runner |
| `pytest-asyncio` | Async test support |
| `pytest-cov` | Coverage reporting |
| `ruff` | Linting and formatting |
| `mypy` | Static type checking |
| `pytest-mock` | Network and API call mocking |
| `conda-lock` | Dependency locking |

### 2.4 System Dependencies

| Dependency | Required | Notes |
|---|---|---|
| micromamba | Yes | Managed by pyve |
| Metal / MPS (Apple Silicon) | Optional | GPU-accelerated inference |
| CUDA | Optional | GPU-accelerated inference on NVIDIA hardware |
| spaCy model `en_core_web_trf` | Yes | Downloaded via `python -m spacy download en_core_web_trf` |

---

## 3. Package Structure

```
tubesense/
├── pyproject.toml
├── environment.yml
├── conda-lock.yml
├── config.yml
├── .env.example
├── .env                          # gitignored
├── .gitignore
├── LICENSE                       # Apache-2.0
├── README.md
├── CHANGELOG.md
│
├── tubesense/                    # Installable Python package
│   ├── __init__.py               # Public API re-exports
│   ├── py.typed                  # PEP 561 marker
│   ├── config.py                 # Settings dataclasses + config loading
│   ├── ingestor.py               # TubeFetch wrapper — fetch and cache
│   ├── segmentor.py              # Transcript tree construction
│   ├── scorer.py                 # MDSA scoring orchestrator
│   ├── valence.py                # Valence axis — DeBERTa + LoRA classifier
│   ├── llm_scorer.py             # Zero-shot LLM scoring — remaining 9 axes
│   ├── aggregator.py             # Verse/chapter score aggregation
│   ├── graph.py                  # Semantic graph construction and traversal
│   ├── pipeline.py               # End-to-end orchestration
│   ├── cache.py                  # Parquet + JSON + graph cache I/O
│   ├── cli.py                    # Click CLI entry point
│   └── exceptions.py             # Project-specific exception classes
│
├── notebooks/
│   ├── 01-ingestion.ipynb        # TubeFetch integration, transcript inspection
│   ├── 02-segmentation.ipynb     # Transcript tree, verse/chapter boundary tuning
│   ├── 03-valence-scoring.ipynb  # Valence classifier output inspection
│   ├── 04-mdsa-scoring.ipynb     # All-axis MDSA scores, axis distribution
│   ├── 05-graph.ipynb            # Semantic graph exploration
│   └── 06-analysis.ipynb         # Narrative arc, anomaly detection, retrieval
│
├── models/
│   └── valence/                  # Transferred bespoke model weights (gitignored)
│       └── best-model/
│
├── data/
│   ├── tubefetch/                # TubeFetch output cache (gitignored)
│   └── scored/                   # tubesense output per video (gitignored)
│       └── {video_id}/
│           ├── graph.json
│           ├── report.json
│           └── utterances.parquet
│
├── tests/
│   ├── conftest.py
│   ├── fixtures/                 # Small fixture transcripts for offline tests
│   ├── test_config.py
│   ├── test_ingestor.py
│   ├── test_segmentor.py
│   ├── test_valence.py
│   ├── test_llm_scorer.py
│   ├── test_aggregator.py
│   ├── test_graph.py
│   ├── test_pipeline.py
│   ├── test_cache.py
│   └── test_cli.py
│
└── docs/
    └── specs/
        ├── concept.md
        ├── features.md
        ├── tech-spec.md
        ├── stories.md
        ├── sentiment-analysis-specification.md
        ├── contextual-analysis-specification.md
        └── interface-specification.md
```

**`.gitignore` entries:**
```
models/valence/best-model/
data/tubefetch/
data/scored/
.env
```

---

## 4. Filename Conventions

*(Follows project-guide.md conventions)*

| File type | Convention | Examples |
|---|---|---|
| Documentation (Markdown) | Hyphens | `tech-spec.md`, `getting-started.md` |
| Python modules | Underscores (PEP 8) | `llm_scorer.py`, `segmentor.py` |
| Python package dirs | Underscores (PEP 8) | `tubesense/` |
| Notebooks | Prefix number + hyphens | `01-ingestion.ipynb` |
| Config / manifest files | Dots or hyphens | `config.yml`, `pyproject.toml` |
| Data files | Hyphens | `graph.json`, `utterances.parquet` |
| Test files | `test_` prefix + underscores | `test_segmentor.py` |

---

## 5. Key Component Design

### 5.1 `config.py` — Settings Model

```python
from dataclasses import dataclass, field

@dataclass
class IngestorConfig:
    cache_dir: str = "data/tubefetch"
    languages: list[str] = field(default_factory=lambda: ["en"])
    allow_generated: bool = True
    force: bool = False                  # force re-fetch from TubeFetch

@dataclass
class SegmentorConfig:
    verse_similarity_threshold: float = 0.85   # cosine similarity drop-off for verse boundaries
    chapter_similarity_threshold: float = 0.75 # coarser threshold for chapter boundaries
    min_utterances_per_verse: int = 3
    max_utterances_per_verse: int = 15
    spacy_model: str = "en_core_web_trf"

@dataclass
class ValenceConfig:
    model_dir: str = "models/valence/best-model"
    device: str = "auto"               # "auto" | "cpu" | "cuda" | "mps"
    batch_size: int = 32

@dataclass
class LlmScorerConfig:
    model: str = "claude-sonnet-4-6"
    max_tokens: int = 512
    axes: list[str] = field(default_factory=lambda: [
        "intensity", "subjectivity", "certainty", "outlook",
        "register", "manners", "intent", "irony", "emotion"
    ])
    max_concurrency: int = 5
    retry_attempts: int = 3

@dataclass
class GraphConfig:
    topic_similarity_threshold: float = 0.80  # edge threshold for shares_topic edges
    sentiment_shift_threshold: float = 0.40   # polarity delta threshold for sentiment_shift edges
    output_dir: str = "data/scored"

@dataclass
class AppConfig:
    ingestor: IngestorConfig = field(default_factory=IngestorConfig)
    segmentor: SegmentorConfig = field(default_factory=SegmentorConfig)
    valence: ValenceConfig = field(default_factory=ValenceConfig)
    llm: LlmScorerConfig = field(default_factory=LlmScorerConfig)
    graph: GraphConfig = field(default_factory=GraphConfig)

def load_config(path: str = "config.yml") -> AppConfig:
    """Load config.yml, merging over dataclass defaults. Returns AppConfig."""
    ...
```

### 5.2 `ingestor.py` — TubeFetch Wrapper

```python
from tubefetch import fetch_video, FetchOptions
from dataclasses import dataclass

@dataclass
class VideoBundle:
    video_id: str
    title: str
    channel: str
    duration_seconds: int
    upload_date: str
    tags: list[str]
    transcript_segments: list[TranscriptSegment]  # see §6.1
    transcript_content_hash: str
    metadata_content_hash: str

class Ingestor:
    """
    Thin wrapper around TubeFetch. Responsibilities:
    - Accept video ID, URL, or local TubeFetch output directory
    - When given ID/URL: invoke TubeFetch via library API to fetch and cache
    - When given local directory: read video_bundle.json from disk
    - Parse TubeFetch output into VideoBundle dataclass
    - Compare transcript_content_hash against cached scored output to
      determine whether re-scoring is needed (incremental mode)
    - Raise IngestorError on TubeFetch failures with a clear message

    Args:
        config: IngestorConfig
    """
    def __init__(self, config: IngestorConfig) -> None: ...

    def ingest(
        self,
        source: str,            # video ID, URL, or local directory path
        force: bool = False,
    ) -> VideoBundle: ...

    def ingest_batch(
        self,
        sources: list[str],
        workers: int = 3,
        force: bool = False,
    ) -> list[VideoBundle]: ...

    def needs_scoring(self, video_id: str, content_hash: str) -> bool:
        """
        Returns True if no scored output exists for video_id, or if the
        stored content hash differs from the current transcript hash.
        """
        ...
```

### 5.3 `segmentor.py` — Transcript Tree Construction

```python
from dataclasses import dataclass, field

@dataclass
class TranscriptSegment:
    """Raw TubeFetch segment — timestamped text chunk."""
    text: str
    start_seconds: float
    end_seconds: float

@dataclass
class Utterance:
    text: str
    start_seconds: float
    end_seconds: float
    embedding: list[float] | None = None   # populated by segmentor

@dataclass
class Verse:
    utterances: list[Utterance]
    start_seconds: float
    end_seconds: float
    embedding: list[float] | None = None   # mean of constituent utterance embeddings

@dataclass
class Chapter:
    verses: list[Verse]
    start_seconds: float
    end_seconds: float
    embedding: list[float] | None = None   # mean of constituent verse embeddings

@dataclass
class TranscriptTree:
    video_id: str
    chapters: list[Chapter]

    @property
    def utterances(self) -> list[Utterance]:
        """Flat list of all utterances in order."""
        ...

    @property
    def verses(self) -> list[Verse]:
        """Flat list of all verses in order."""
        ...


class Segmentor:
    """
    Converts a VideoBundle into a TranscriptTree.

    Processing sequence:
    1. Sentence boundary detection — spaCy applied within each TubeFetch segment
       to produce Utterances with inherited timestamp ranges
    2. Utterance embedding — sentence-transformers encodes each utterance;
       embeddings stored on Utterance.embedding
    3. Verse boundary detection — sliding-window cosine similarity over utterance
       embeddings; boundaries at drop-offs below verse_similarity_threshold
    4. Verse embedding — mean of constituent utterance embeddings
    5. Chapter boundary detection — same sliding-window approach over verse
       embeddings with chapter_similarity_threshold; TubeFetch chapter timestamp
       markers (if present) used as hard boundary overrides
    6. Chapter embedding — mean of constituent verse embeddings

    The sentence-transformers model used for embedding is
    'sentence-transformers/all-mpnet-base-v2' — general-purpose, not
    Twitter-specialized, consistent with cross-domain generalization goal.

    Args:
        config: SegmentorConfig
    """
    def __init__(self, config: SegmentorConfig) -> None: ...

    def segment(self, bundle: VideoBundle) -> TranscriptTree: ...

    def _detect_utterances(
        self, segments: list[TranscriptSegment]
    ) -> list[Utterance]: ...

    def _detect_verse_boundaries(
        self, utterances: list[Utterance]
    ) -> list[list[Utterance]]: ...

    def _detect_chapter_boundaries(
        self, verses: list[Verse],
        hard_boundaries: list[float],   # TubeFetch chapter timestamps in seconds
    ) -> list[list[Verse]]: ...
```

### 5.4 `valence.py` — Valence Classifier

```python
import torch
from dataclasses import dataclass

@dataclass
class ValenceScore:
    label: str          # "POSITIVE" | "NEUTRAL" | "NEGATIVE"
    confidence: float
    score_positive: float
    score_neutral: float
    score_negative: float
    polarity: float     # score_positive - score_negative ∈ [-1, 1]

class ValenceScorer:
    """
    Sentence-level valence classifier. Reimplementation of the rough PoC
    bespoke model architecture:
      - Encoder: microsoft/deberta-v3-base (frozen)
      - LoRA adapters on query_proj and value_proj (loaded from model_dir)
      - Attention pooling head over token embeddings
      - MLP classifier — 3-class output (NEGATIVE / NEUTRAL / POSITIVE)

    Weights are loaded from config.valence.model_dir (transferred from
    rough PoC — not retrained). The model_dir must contain adapter_config.json
    (PEFT), pytorch_model weights, tokenizer files, and config.json with
    id2label: {0: "NEGATIVE", 1: "NEUTRAL", 2: "POSITIVE"}.

    Device resolution follows the same "auto" → CUDA → MPS → CPU logic
    as the rough PoC.

    Args:
        config: ValenceConfig
    """
    def __init__(self, config: ValenceConfig) -> None: ...

    def score(self, text: str) -> ValenceScore: ...

    def score_batch(self, texts: list[str]) -> list[ValenceScore]: ...
```

### 5.5 `llm_scorer.py` — Zero-Shot MDSA Scoring

```python
import asyncio
from dataclasses import dataclass
from gentlify import Throttle, RetryConfig

@dataclass
class MdsaScores:
    """
    Full MDSA score vector for one utterance.
    All continuous axes per sentiment-analysis-specification.md.
    Valence is populated by ValenceScorer, not LlmScorer.
    Null values are preserved as None (not 0) per MDSA specification §3.
    """
    # Valence axis — populated by ValenceScorer
    valence: float | None = None
    valence_label: str | None = None
    valence_confidence: float | None = None
    score_positive: float | None = None
    score_neutral: float | None = None
    score_negative: float | None = None
    valence_polarity: float | None = None

    # LLM-scored axes
    intensity: float | None = None           # 0 → 1.0
    subjectivity: float | None = None        # 0 → 1.0
    certainty: float | None = None           # -1.0 → +1.0
    outlook: float | None = None             # -1.0 → +1.0 | None if N/A
    register: float | None = None            # -1.0 → +1.0
    manners: float | None = None             # -1.0 → +1.0
    intent: float | None = None              # -1.0 → +1.0
    irony: float | None = None               # 0 → 1.0
    emotion: str | None = None               # categorical per MDSA §2.10
    irony_ambiguous: bool = False            # True if irony score ∈ [0.3, 0.7]
    outlook_not_applicable: bool = False     # True if outlook=None because N/A


class LlmScorer:
    """
    Zero-shot MDSA scoring via Anthropic API for all non-valence axes.

    Each utterance is scored by sending a structured prompt to Claude
    containing:
    - The utterance text
    - Axis definitions and scale anchors from sentiment-analysis-specification.md
    - A JSON schema for the expected response
    - Instructions to return null for N/A axes (Outlook) per MDSA §3

    The prompt template is loaded from docs/specs/sentiment-analysis-specification.md
    axis definitions — the spec is the single source of truth for prompt content.

    Batch dispatch is managed by a gentlify Throttle:
      max_concurrency: config.llm.max_concurrency (default 5)
      retry: RetryConfig(max_attempts=3, backoff="exponential_jitter")

    Irony ambiguity flagging: if irony score ∈ [0.3, 0.7], sets
    MdsaScores.irony_ambiguous = True per MDSA specification §2.9.

    Args:
        config: LlmScorerConfig
    """
    def __init__(self, config: LlmScorerConfig) -> None: ...

    def score(self, text: str) -> MdsaScores: ...

    async def _score_batch_async(
        self, texts: list[str]
    ) -> list[MdsaScores]: ...

    def score_batch(self, texts: list[str]) -> list[MdsaScores]:
        return asyncio.run(self._score_batch_async(texts))

    def _build_prompt(self, text: str, axes: list[str]) -> str:
        """
        Construct the scoring prompt for the given axes.
        Axis definitions and scale anchors are referenced directly from
        sentiment-analysis-specification.md — not hardcoded here.
        """
        ...

    def _parse_response(self, response_text: str) -> dict[str, float | str | None]:
        """
        Parse JSON response from Claude. Strip markdown fences if present.
        Validate all returned values are within stated axis ranges.
        On parse failure: return all-None MdsaScores and log warning.
        """
        ...
```

### 5.6 `aggregator.py` — Verse and Chapter Score Aggregation

```python
from dataclasses import dataclass

@dataclass
class AggregatedScores:
    """
    Aggregated MDSA scores at verse or chapter level.
    Continuous axes: confidence-weighted mean, min, max, std.
    Emotion: plurality vote across constituent utterances.
    Null values excluded from aggregation; null_count recorded.
    """
    valence_mean: float | None
    valence_min: float | None
    valence_max: float | None
    valence_std: float | None
    intensity_mean: float | None
    # ... (same pattern for all continuous axes)
    emotion_plurality: str | None       # most common emotion category
    emotion_distribution: dict[str, int]  # counts per emotion category
    utterance_count: int
    null_counts: dict[str, int]         # per-axis count of null values excluded


class Aggregator:
    """
    Computes AggregatedScores from a list of MdsaScores.

    Aggregation method:
    - Continuous axes: confidence-weighted mean using valence_confidence
      as the weight. Falls back to unweighted mean if confidence unavailable.
    - Emotion (categorical): plurality vote. Ties broken by first occurrence.
    - Null values: excluded from computation; count recorded in null_counts.
    - Outlook N/A: excluded from aggregation (outlook_not_applicable=True
      utterances contribute to null_counts, not to mean).
    """
    def aggregate(self, scores: list[MdsaScores]) -> AggregatedScores: ...
```

### 5.7 `graph.py` — Semantic Graph

```python
import networkx as nx
from dataclasses import dataclass

@dataclass
class ScoredUtterance:
    text: str
    start_seconds: float
    end_seconds: float
    scores: MdsaScores
    verse_index: int
    chapter_index: int

@dataclass
class ScoredVerse:
    utterances: list[ScoredUtterance]
    start_seconds: float
    end_seconds: float
    scores: AggregatedScores
    embedding: list[float]
    topic_label: str | None   # populated by LLM topic inference if enabled

@dataclass
class ScoredChapter:
    verses: list[ScoredVerse]
    start_seconds: float
    end_seconds: float
    scores: AggregatedScores
    embedding: list[float]

@dataclass
class QueryResult:
    node_id: str
    node_type: str           # "utterance" | "verse" | "chapter"
    text: str
    start_seconds: float
    scores: MdsaScores | AggregatedScores
    similarity: float        # cosine similarity to query embedding


class TranscriptGraph:
    """
    Directed semantic graph for a single scored video transcript.

    Node types: Video, Chapter, Verse, Utterance.
    Edge types per features.md §7.2:
      contains — hierarchical (Chapter→Verse, Verse→Utterance)
      follows  — temporal sequence within a level
      shares_topic — cosine similarity above graph.topic_similarity_threshold
      sentiment_shift — adjacent verse valence polarity delta above
                        graph.sentiment_shift_threshold

    Built by GraphBuilder from a scored transcript tree.
    Stored as NetworkX DiGraph internally.
    Serialized to/from JSON via NetworkX node-link format.

    Args:
        graph: nx.DiGraph (constructed by GraphBuilder)
        video_id: str
    """
    def __init__(self, graph: nx.DiGraph, video_id: str) -> None: ...

    def query(
        self,
        query: str,
        top_k: int = 10,
        node_types: list[str] | None = None,
    ) -> list[QueryResult]:
        """
        Embed query string and return top_k nodes by cosine similarity.
        Optionally filter by node_type.
        """
        ...

    def narrative_arc(self) -> list[tuple[float, float]]:
        """
        Returns list of (timestamp_seconds, valence_mean) tuples at chapter level,
        in temporal order. Suitable for plotting emotional structure of the video.
        """
        ...

    def anomalies(
        self,
        threshold: float = 0.40,
    ) -> list[ScoredVerse]:
        """
        Returns verses where local valence_mean deviates from the enclosing
        chapter's valence_mean by more than threshold.
        Potential markers of sarcasm, irony, hedging, or topic shifts.
        """
        ...

    def to_json(self) -> dict: ...

    @classmethod
    def from_json(cls, data: dict) -> "TranscriptGraph": ...


class GraphBuilder:
    """
    Constructs a TranscriptGraph from a scored TranscriptTree.

    Processing sequence:
    1. Create Video root node with TubeFetch metadata
    2. Create Chapter, Verse, Utterance nodes with scores and embeddings
    3. Add contains and follows edges (structural — always present)
    4. Add shares_topic edges between non-adjacent Verse nodes whose
       embeddings exceed graph.topic_similarity_threshold
    5. Add sentiment_shift edges between adjacent Verse node pairs whose
       valence polarity delta exceeds graph.sentiment_shift_threshold

    Args:
        config: GraphConfig
    """
    def __init__(self, config: GraphConfig) -> None: ...

    def build(
        self,
        tree: TranscriptTree,
        scored_utterances: list[ScoredUtterance],
        bundle: VideoBundle,
    ) -> TranscriptGraph: ...
```

### 5.8 `pipeline.py` — End-to-End Orchestration

```python
class Pipeline:
    """
    Orchestrates the full tubesense pipeline for one or more videos:
      Ingestor → Segmentor → ValenceScorer → LlmScorer →
      Aggregator → GraphBuilder → cache.save()

    Incremental mode (default): calls Ingestor.needs_scoring() before
    scoring; skips videos whose transcript hash is unchanged.

    Args:
        config: AppConfig
    """
    def __init__(self, config: AppConfig) -> None: ...

    def run(
        self,
        source: str,
        force: bool = False,
        axes: list[str] | None = None,   # None = all axes
    ) -> TranscriptGraph: ...

    def run_batch(
        self,
        sources: list[str],
        workers: int = 3,
        force: bool = False,
        axes: list[str] | None = None,
    ) -> list[TranscriptGraph]: ...
```

### 5.9 `cli.py` — Click Entry Points

```python
import click

@click.group()
@click.option("--config", default="config.yml")
@click.option("--verbose", is_flag=True)
@click.pass_context
def cli(ctx: click.Context, config: str, verbose: bool) -> None:
    """tubesense — Multi-dimensional sentiment analysis for YouTube transcripts."""
    ...

@cli.command()
@click.argument("ids", nargs=-1)
@click.option("--file", type=click.Path(), help="Text file of video IDs")
@click.option("--from-dir", type=click.Path(), help="Local TubeFetch output directory")
@click.option("--axes", type=str, default=None, help="Comma-separated axes to score")
@click.option("--workers", type=int, default=3)
@click.option("--force", is_flag=True)
def score(
    ids: tuple[str, ...],
    file: str | None,
    from_dir: str | None,
    axes: str | None,
    workers: int,
    force: bool,
) -> None:
    """Fetch (if needed) and score one or more YouTube videos."""
    ...

@cli.command()
@click.argument("video_id")
def report(video_id: str) -> None:
    """Print human-readable sentiment report for a scored video."""
    ...

@cli.command()
@click.argument("video_id")
@click.argument("query")
@click.option("--top-k", type=int, default=10)
@click.option("--node-type", type=str, default=None,
              help="Filter by node type: utterance|verse|chapter")
def query(video_id: str, query: str, top_k: int, node_type: str | None) -> None:
    """Query a scored video's semantic graph."""
    ...

@cli.command()
def doctor() -> None:
    """
    Validate environment and dependencies. Checks:
    - Python version and architecture
    - PyTorch device availability (CUDA, MPS, CPU)
    - Valence model weights present and loadable
    - spaCy model installed
    - ANTHROPIC_API_KEY set
    - TubeFetch importable and version logged
    - TUBEFETCH_YT_API_KEY set (optional — logged if absent)
    - data/ directories exist and are writable
    Exits 0 if all required checks pass, 1 if any fail.
    """
    ...

@cli.command()
def clean() -> None:
    """List cached data and provide removal commands."""
    ...
```

### 5.10 `exceptions.py`

```python
class TubeSenseError(Exception):
    """Base exception for all tubesense errors."""

class IngestorError(TubeSenseError):
    """TubeFetch fetch or parse failure."""

class SegmentorError(TubeSenseError):
    """Transcript segmentation failure."""

class ValenceModelError(TubeSenseError):
    """Valence model load or inference failure."""

class LlmScoringError(TubeSenseError):
    """Anthropic API call failure after retries exhausted."""

class GraphError(TubeSenseError):
    """Graph construction or traversal failure."""

class CacheNotFoundError(TubeSenseError):
    """Requested scored output does not exist in cache."""

class ConfigError(TubeSenseError):
    """config.yml malformed or invalid values."""
```

---

## 6. Data Models

### 6.1 Utterance-Level Scored Output (Parquet)

Written to `data/scored/{video_id}/utterances.parquet`:

| Column | Type | Description |
|---|---|---|
| `video_id` | `str` | YouTube video ID |
| `chapter_index` | `int` | Chapter position (0-based) |
| `verse_index` | `int` | Verse position within chapter (0-based) |
| `utterance_index` | `int` | Utterance position within verse (0-based) |
| `text` | `str` | Utterance text |
| `start_seconds` | `float` | Start timestamp from TubeFetch |
| `end_seconds` | `float` | End timestamp from TubeFetch |
| `valence` | `float` | Valence polarity ∈ [−1, 1] |
| `valence_label` | `str` | NEGATIVE / NEUTRAL / POSITIVE |
| `valence_confidence` | `float` | Softmax confidence of valence prediction |
| `score_positive` | `float` | Raw POSITIVE probability |
| `score_neutral` | `float` | Raw NEUTRAL probability |
| `score_negative` | `float` | Raw NEGATIVE probability |
| `intensity` | `float\|None` | MDSA Intensity axis ∈ [0, 1] |
| `subjectivity` | `float\|None` | MDSA Subjectivity axis ∈ [0, 1] |
| `certainty` | `float\|None` | MDSA Certainty axis ∈ [−1, 1] |
| `outlook` | `float\|None` | MDSA Outlook axis ∈ [−1, 1]; null if N/A |
| `register` | `float\|None` | MDSA Register axis ∈ [−1, 1] |
| `manners` | `float\|None` | MDSA Manners axis ∈ [−1, 1] |
| `intent` | `float\|None` | MDSA Intent axis ∈ [−1, 1] |
| `irony` | `float\|None` | MDSA Irony axis ∈ [0, 1] |
| `irony_ambiguous` | `bool` | True if irony ∈ [0.3, 0.7] |
| `emotion` | `str\|None` | MDSA Emotion category |
| `outlook_not_applicable` | `bool` | True if Outlook axis is N/A |

### 6.2 Graph Output

Written to `data/scored/{video_id}/graph.json` — NetworkX node-link format. Nodes carry all scored fields from §6.1 (utterance nodes) or `AggregatedScores` fields (verse and chapter nodes) plus TubeFetch metadata (video node).

### 6.3 Report Output

Written to `data/scored/{video_id}/report.json`:

```json
{
  "video_id": "...",
  "title": "...",
  "channel": "...",
  "duration_seconds": 3600,
  "transcript_content_hash": "...",
  "chapter_count": 5,
  "verse_count": 42,
  "utterance_count": 387,
  "narrative_arc": [
    {"timestamp_seconds": 0, "valence_mean": 0.12},
    {"timestamp_seconds": 720, "valence_mean": -0.34}
  ],
  "chapter_summaries": [
    {
      "chapter_index": 0,
      "start_seconds": 0,
      "end_seconds": 720,
      "scores": { "valence_mean": 0.12, "intensity_mean": 0.45, "emotion_plurality": "neutral" }
    }
  ],
  "anomalies": [
    {
      "verse_index": 7,
      "chapter_index": 1,
      "start_seconds": 540,
      "valence_mean": -0.71,
      "chapter_valence_mean": 0.18,
      "delta": 0.89
    }
  ],
  "axes_scored": ["valence", "intensity", "subjectivity", "certainty",
                  "outlook", "register", "manners", "intent", "irony", "emotion"],
  "tubesense_version": "0.1.0",
  "scored_at": "2026-03-20T12:00:00Z"
}
```

---

## 7. Configuration

### 7.1 Precedence (highest to lowest)

1. CLI flags
2. Environment variables (`TUBESENSE_` prefix)
3. `config.yml` values
4. Dataclass defaults in `config.py`

### 7.2 Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | Yes (for LLM scoring) | Anthropic API key |
| `TUBEFETCH_YT_API_KEY` | No | YouTube Data API key for age-restricted videos |
| `HF_TOKEN` | No | HuggingFace token for model download rate-limit headroom |
| `PYTORCH_ENABLE_MPS_FALLBACK` | No | Set to `1` on Apple Silicon for CPU fallback |
| `TOKENIZERS_PARALLELISM` | No | Set to `false` to suppress HuggingFace fork warning |

---

## 8. Async & Rate Limiting

### 8.1 LLM Scoring (gentlify)

All Anthropic API calls are dispatched via a gentlify `Throttle`:

```python
throttle = Throttle(
    max_concurrency=config.llm.max_concurrency,   # default 5
    total_tasks=len(utterances),
    on_progress=_progress_callback,
    retry=RetryConfig(
        max_attempts=3,
        backoff="exponential_jitter",
        base_delay=1.0,
        max_delay=30.0,
    ),
)
```

### 8.2 TubeFetch Batch Ingestion

TubeFetch manages its own rate limiting internally. `Ingestor.ingest_batch()` uses TubeFetch's `--workers` parameter via the library API. No additional gentlify wrapper is needed for ingestion.

### 8.3 Valence Scoring

Synchronous batch inference. No async needed — PyTorch handles internal parallelism. DataLoader `num_workers=0` on MPS, `min(4, os.cpu_count())` on CUDA/CPU.

---

## 9. Testing Strategy

### 9.1 Unit Tests

| Module | What is tested |
|---|---|
| `config.py` | All config sections load from YAML; validation errors raised for invalid values |
| `ingestor.py` | `VideoBundle` parsed correctly from fixture `video_bundle.json`; `needs_scoring()` logic for hash match/mismatch; `--from-dir` path vs. live fetch path |
| `segmentor.py` | Utterance boundary detection on fixture text; verse boundary detection at known similarity drop-offs; chapter boundaries respect hard timestamp markers |
| `valence.py` | `ValenceScore` fields correct; polarity calculation; label mapping matches NEGATIVE/NEUTRAL/POSITIVE |
| `llm_scorer.py` | Prompt construction includes correct axis definitions; response parsing handles valid JSON, JSON with markdown fences, and malformed JSON; null preserved for N/A outlook; irony_ambiguous flag set correctly |
| `aggregator.py` | Confidence-weighted mean correct for known inputs; null values excluded from aggregation; emotion plurality correct for tie cases |
| `graph.py` | Node count correct for fixture tree; contains and follows edges present; shares_topic edges created above threshold and absent below; sentiment_shift edges created at correct delta |
| `cache.py` | Save/load roundtrip for graph JSON and parquet; `CacheNotFoundError` on missing file |
| `cli.py` | All commands exit 0 with `--help`; `score` with no IDs exits 1 with clear message |

### 9.2 Integration Tests

- Full pipeline on a fixture `video_bundle.json` (no live TubeFetch or Anthropic calls — both mocked)
- Graph query returns results in correct rank order on fixture data
- Narrative arc returns timestamps in temporal order

### 9.3 Coverage Target

- Minimum: **80%** overall
- `segmentor.py`, `llm_scorer.py`, `graph.py`: **90%** (core logic, highest risk)

---

## 10. Cross-Cutting Concerns

| Concern | Approach |
|---|---|
| Atomic writes | `cache.py` writes to temp file then renames — prevents partial graph or parquet files |
| Logging | `logging` stdlib; `rich` handler for CLI; `--verbose` enables DEBUG level |
| Reproducibility | Same video + same config + same model weights + same `ANTHROPIC_API_KEY` model version = identical output |
| Null preservation | `None` values are preserved through parquet (nullable columns) and JSON — never defaulted to `0` |
| Incremental processing | Content hash comparison before scoring; `--force` bypasses |
| MPS compatibility | DataLoader `num_workers=0`; `PYTORCH_ENABLE_MPS_FALLBACK=1` recommended |
| Offline capability | Once valence weights and spaCy model cached, valence scoring runs offline. LLM axes require Anthropic API access. |

---

*Document version: 0.1 — Pending Approval*

---

A few decisions worth calling out explicitly:

**`sentence-transformers/all-mpnet-base-v2`** is named as the embedding model for segmentation — it is general-purpose, consistent with the cross-domain goal, and distinct from the valence encoder (DeBERTa). Using a separate model for embeddings vs. classification is cleaner architecturally and avoids repurposing the valence encoder for a task it was not trained for.

**The LLM prompt template references the spec document** rather than hardcoding axis definitions — `_build_prompt()` loads from `sentiment-analysis-specification.md`. This means the spec is genuinely the single source of truth; updating the spec propagates to prompt behavior.

**`irony_ambiguous` and `outlook_not_applicable`** are first-class boolean columns in the parquet schema, not inferred from null values — this preserves the MDSA specification's distinction between null-because-inapplicable and null-because-unknown.

Please review and approve, or flag anything to adjust. Once approved I'll proceed to `stories.md`.