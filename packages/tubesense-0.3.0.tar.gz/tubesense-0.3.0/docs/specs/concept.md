# concept.md — TubeSense: a Multi-Dimensional, Multi-Layered Semantic Analysis Engine

**Version:** 0.1 — Approved

---

## Problem

Sentence-level sentiment scoring is a solved problem for short-form text. Long-form content — video transcripts, podcasts, lectures, interviews — presents a fundamentally different challenge: sentiment is distributed across a discourse structure, not a single utterance. Topics shift, arguments nest, speakers contradict themselves, and emotional register changes across temporal distance. Flattening this to a single score discards almost all of the signal.

This project builds the infrastructure to analyze sentiment and context across that structure.

---

## What We're Building

A **multi-dimensional semantic analysis engine** for long-form content, initially targeting YouTube video transcripts. The system segments transcripts into a hierarchical discourse structure, scores each segment across multiple sentiment axes, assembles the result into a semantic graph, and exposes that graph for retrieval and higher-order analysis.

Transcripts are fetched and extracted by **TubeFetch** — an existing open-source Python library. TubeSense begins where TubeFetch output ends.

Sentiment analysis is structured hierarchically: transcripts are broken into chapters, verses, and utterances, then mapped across those levels by topic and other semantic vectors. At the most granular level, a sentence-level valence classifier — an architectural descendant of an earlier private PoC — serves as the analytical backbone. TubeSense generalizes that foundation to long-form content across platforms.

This project implements the first stage of a planned three-part analytical framework:

1. **Sentiment Analysis** ← *this project* — ten-axis scoring per `docs/specs/sentiment-analysis-specification.md`
2. **Context Analysis** — grounding sentiment in world context per `docs/specs/contextual-analysis-specification.md`
3. **Interface Layer** — mapping sentiment × context to higher-order signals per `docs/specs/interface-specification.md`

---

## What We're Not Building Yet

- Context Analysis (Document 2) and the Interface Layer (Document 3)
- A web UI
- A production deployment or real-time pipeline
- Multi-speaker diarization
- Multi-transcript graph alignment
- A formal evaluation benchmark — evaluation criteria are defined empirically after initial implementation

---

## Origin

TubeSense is a clean-start, open-source project — new repository, new code, Apache-2.0 license from inception. The earlier private PoC codebase is not reused. The bespoke model architecture, trained weights, output schema, configuration conventions, and planning documents transfer as described in `features.md`.

---

*For requirements, see `features.md`.*
*For implementation details, see `tech-spec.md`.*

---

*Document version: 0.1 — Approved*
