# stories.md — tubesense (Python 3.12)
**Version:** 0.1 — Pending Approval

This document breaks `tubesense` into an ordered sequence of small, independently completable stories grouped into phases. Stories reference modules defined in `tech-spec.md`. The three framework specification documents (`sentiment-analysis-specification.md`, `contextual-analysis-specification.md`, `interface-specification.md`) are authoritative references for analytical behaviour and are not re-specified here.

Stories are identified by phase letter and lowercase letter (e.g. A.a, B.a). Each story that introduces code changes carries a semantic version number bumped from the prior story. Stories with no code changes (documentation, configuration only) omit the version. Each story is marked `[Planned]` until completed, then `[Done]`. Tasks use `- [ ]` (planned) or `- [x]` (completed).

---

## Introduction

- First story: **A.a** — Hello World + PyPI name reservation spike
- Starting version: **v0.1.0**
- CI/CD: yes (confirmed earlier — GitHub Actions, Codecov, PyPI trusted publishing)
- Apache-2.0 license
- Project guide phases: A (Foundation), B (Core Services), C (Pipeline & Orchestration), D (CLI & Library API), E (Testing & Quality), F (Documentation & Release), G (CI/CD & Automation)

A few decisions worth calling out:

**A.a front-loads PyPI publication** as requested — it publishes before any real functionality exists, solely to reserve the name. The release workflow is wired in A.a and reused for every subsequent tagged release with no further changes.

**A.b keeps the spike** rather than deleting it — it is useful as a reference implementation while building production modules, and it is explicitly excluded from the installed package. It can be deleted or moved to a `scripts/` archive at any time.

**C.b has no version bump** — it is a validation story, not a code story, following the project-guide convention.

**G.b has no version bump** — configuration and documentation only, same convention.

The `release.yml` workflow is created in A.a and not duplicated in G.a — CI and release are separate workflows from the start, which is cleaner than retrofitting CI later.

---

## Phase A: Foundation

Establishes the project skeleton, reserves the `tubesense` name on PyPI, wires the full critical path in a throwaway spike, and puts the config and exception infrastructure in place. No production pipeline logic is written until Phase B.

---

### Story A.a: v0.1.0 — Hello World + PyPI Name Reservation [Done]

Minimal installable package published to PyPI. The sole purpose is to reserve the `tubesense` name and prove the full publish pipeline works before any real code is written. The package does nothing except print a version string.

- [x] Create project root structure
  - [x] `pyproject.toml` — package name `tubesense`, version `0.1.0`, license `Apache-2.0`, author, Python `>=3.12`
  - [x] `environment.yml` — micromamba environment, Python 3.12, minimal deps
  - [x] `LICENSE` — Apache-2.0
  - [x] `README.md` — one-paragraph placeholder with PyPI badges (version, license, typed)
  - [x] `CHANGELOG.md` — initial entry for `0.1.0`
  - [x] `.env.example` — documents `ANTHROPIC_API_KEY`, `TUBEFETCH_YT_API_KEY`, `HF_TOKEN`, `PYTORCH_ENABLE_MPS_FALLBACK`, `TOKENIZERS_PARALLELISM`
  - [x] `.gitignore` — standard Python ignores plus `models/valence/best-model/`, `data/tubefetch/`, `data/scored/`, `.env`
- [x] Create minimal `tubesense/` package
  - [x] `tubesense/__init__.py` — exports `__version__ = "0.1.0"` only
  - [x] `tubesense/py.typed` — PEP 561 marker
- [x] Add copyright and Apache-2.0 license header to all source files
- [x] Configure PyPI trusted publisher (OIDC) for this repository on PyPI.org
  - [x] Create PyPI account and project placeholder if not already present
  - [x] Document trusted publisher setup steps in `CONTRIBUTING.md` (stub)
- [x] Create `.github/workflows/release.yml`
  - [x] Trigger: push on tags matching `v*.*.*`
  - [x] Steps: checkout, set up Python 3.12, `pip install hatchling build`, `python -m build`, publish via `pypa/gh-action-pypi-publish` with OIDC trusted publishing
- [x] Build and publish `v0.1.0` to PyPI
  - [x] Tag `v0.1.0` and confirm GitHub Actions release workflow runs and publishes
  - [ ] Verify: `pip install tubesense` succeeds and `python -c "import tubesense; print(tubesense.__version__)"` prints `0.1.0`
- [x] Add `## [0.1.0]` entry to `CHANGELOG.md`

---

### Story A.b: v0.2.0 — Stack Spike [Done]

Throwaway script in `scripts/` that wires the full critical path end-to-end before any production modules are written: TubeFetch fetches a transcript, the valence model loads and scores one sentence, the Anthropic API scores one sentence on the remaining axes, and a minimal NetworkX graph is constructed from the result. Nothing here goes into the installed package.

- [x] Create `scripts/spike_pipeline.py`
  - [x] Load a real YouTube video via TubeFetch library API (`fetch_video`) with a known short video ID; print title and segment count
  - [x] Load valence model from `models/valence/best-model/` (transferred weights from rough PoC); confirm device resolution (MPS/CUDA/CPU); run `score()` on one sentence; print `ValenceScore` fields
  - [x] Send one sentence to Anthropic API (`claude-sonnet-4-6`) with a minimal MDSA prompt; parse JSON response; print all nine non-valence axis scores
  - [x] Construct a 3-node NetworkX DiGraph (Video → Verse → Utterance) with scores attached; assert node count == 3 and edge count == 2
  - [x] Print summary: device used, valence label, all axis scores, graph node count
- [x] Add `peft>=0.10`, `transformers>=4.40`, `torch>=2.2`, `anthropic>=0.25`, `tubefetch>=1.4`, `networkx>=3.2`, `gentlify>=2.0` to `environment.yml` for spike validation
- [ ] Transfer valence model weights from rough PoC
  - [ ] Copy `models/valence/best-model/` directory into repo (gitignored)
  - [ ] Verify model loads without error on target device
- [ ] Verify spike runs end-to-end: `python scripts/spike_pipeline.py`
  - [ ] (Pending: TubeFetch re-release for Python 3.12 + valence model weights)
- [ ] Confirm all five assertions pass (TubeFetch output, valence score fields, Anthropic JSON parsed, graph shape, no exceptions)
- [ ] Note any issues (API latency, device fallback warnings, tokenizer warnings) as known items for production implementation
- [x] Spike is not deleted — kept in `scripts/` as a reference but excluded from the package
- [x] Bump version to `v0.2.0` in `pyproject.toml` and `tubesense/__init__.py`
- [x] Add `## [0.2.0]` entry to `CHANGELOG.md`

---

### Story A.c: v0.3.0 — Config and Exceptions [Done]

Implement `config.py` and `exceptions.py`. All dataclasses, validation logic, `load_config()`, and the full exception hierarchy. No other modules yet.

- [x] Create `tubesense/exceptions.py`
  - [x] `TubeSenseError` base class
  - [x] `IngestorError`, `SegmentorError`, `ValenceModelError`, `LlmScoringError`, `GraphError`, `CacheNotFoundError`, `ConfigError` — all inheriting from `TubeSenseError`
  - [x] Add Apache-2.0 header
- [x] Create `tubesense/config.py`
  - [x] `IngestorConfig` — `cache_dir`, `languages`, `allow_generated`, `force`
  - [x] `SegmentorConfig` — `verse_similarity_threshold`, `chapter_similarity_threshold`, `min_utterances_per_verse`, `max_utterances_per_verse`, `spacy_model`
  - [x] `ValenceConfig` — `model_dir`, `device`, `batch_size`
    - [x] `__post_init__` validation: `device` must be one of `"auto"`, `"cpu"`, `"cuda"`, `"mps"`
  - [x] `LlmScorerConfig` — `model`, `max_tokens`, `axes`, `max_concurrency`, `retry_attempts`
    - [x] `__post_init__` validation: `axes` must be a non-empty subset of the nine non-valence MDSA axes
  - [x] `GraphConfig` — `topic_similarity_threshold`, `sentiment_shift_threshold`, `output_dir`
  - [x] `AppConfig` — composes all sub-configs
  - [x] `load_config(path)` — loads `config.yml`, merges over dataclass defaults, raises `ConfigError` on malformed YAML or invalid values
  - [x] Add Apache-2.0 header
- [x] Create `config.yml` with all defaults per tech-spec §5.1
- [x] Write `tests/test_config.py`
  - [x] All sub-configs load from YAML correctly
  - [x] Defaults applied when keys absent from YAML
  - [x] `ConfigError` raised for invalid `device` value
  - [x] `ConfigError` raised for invalid `axes` value (unrecognised axis name)
  - [x] `ConfigError` raised for malformed YAML
- [x] Write `tests/test_exceptions.py`
  - [x] All exception classes instantiate correctly
  - [x] All inherit from `TubeSenseError`
  - [x] `TubeSenseError` inherits from `Exception`
- [x] Verify: `pytest tests/test_config.py tests/test_exceptions.py` passes
- [x] Bump version to `v0.3.0` in `pyproject.toml` and `__init__.py`
- [x] Add `## [0.3.0]` entry to `CHANGELOG.md`

---

## Phase B: Core Services

Implements each production module independently — ingestor, segmentor, valence scorer, LLM scorer, aggregator, graph builder, and cache. Each story is independently testable with mocks and fixtures; no live API calls required in tests.

---

### Story B.a: v0.4.0 — Ingestor [Planned]

Implement `tubesense/ingestor.py` — TubeFetch wrapper, `VideoBundle`, and incremental hash comparison.

- [ ] Create `tests/fixtures/` directory
  - [ ] Add a minimal `video_bundle.json` fixture (based on real TubeFetch output schema, anonymised)
  - [ ] Add a corresponding `metadata.json` and `transcript.json` fixture
- [ ] Create `tubesense/ingestor.py`
  - [ ] `TranscriptSegment` dataclass — `text`, `start_seconds`, `end_seconds`
  - [ ] `VideoBundle` dataclass — all fields per tech-spec §5.2
  - [ ] `Ingestor.__init__` — stores config, creates `cache_dir` if not exists
  - [ ] `Ingestor.ingest(source, force)` — detects local path vs. video ID/URL; routes to `_from_dir()` or `_from_tubefetch()`; returns `VideoBundle`
  - [ ] `Ingestor._from_dir(path)` — reads `video_bundle.json` from local TubeFetch output directory; parses into `VideoBundle`; raises `IngestorError` on missing or malformed file
  - [ ] `Ingestor._from_tubefetch(source)` — calls `tubefetch.fetch_video()` with `FetchOptions(bundle=True, txt_timestamps=True)`; parses result into `VideoBundle`; raises `IngestorError` on TubeFetch failure
  - [ ] `Ingestor.ingest_batch(sources, workers, force)` — calls `ingest()` per source using `concurrent.futures.ThreadPoolExecutor`; isolates per-video errors; returns list of `VideoBundle` with failed entries logged
  - [ ] `Ingestor.needs_scoring(video_id, content_hash)` — checks `data/scored/{video_id}/graph.json` existence and stored hash field; returns `True` if missing or hash differs
  - [ ] Add Apache-2.0 header
- [ ] Write `tests/test_ingestor.py`
  - [ ] `_from_dir()` parses fixture `video_bundle.json` into `VideoBundle` with correct fields
  - [ ] `_from_dir()` raises `IngestorError` on missing file
  - [ ] `_from_tubefetch()` calls TubeFetch with correct options (mocked)
  - [ ] `needs_scoring()` returns `True` when no scored output exists
  - [ ] `needs_scoring()` returns `False` when hash matches cached graph
  - [ ] `needs_scoring()` returns `True` when hash differs from cached graph
  - [ ] `ingest_batch()` isolates errors — one failing source does not prevent others from returning
- [ ] Verify: `pytest tests/test_ingestor.py` passes
- [ ] Bump version to `v0.4.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.4.0]` entry to `CHANGELOG.md`

---

### Story B.b: v0.5.0 — Segmentor [Planned]

Implement `tubesense/segmentor.py` — utterance boundary detection, verse segmentation, chapter segmentation, and the `TranscriptTree`.

- [ ] Add `spacy>=3.7` and `sentence-transformers>=2.6` to `pyproject.toml` and `environment.yml`
- [ ] Download spaCy model: `python -m spacy download en_core_web_trf` (document in `README.md` setup section)
- [ ] Create `tubesense/segmentor.py`
  - [ ] `Utterance`, `Verse`, `Chapter`, `TranscriptTree` dataclasses per tech-spec §5.3
  - [ ] `TranscriptTree.utterances` property — flat ordered list
  - [ ] `TranscriptTree.verses` property — flat ordered list
  - [ ] `Segmentor.__init__` — loads spaCy model and `sentence-transformers/all-mpnet-base-v2`; raises `SegmentorError` on load failure
  - [ ] `Segmentor._detect_utterances(segments)` — applies spaCy sentence boundary detection within each `TranscriptSegment`; inherits timestamp range from parent segment; returns flat `list[Utterance]`
  - [ ] `Segmentor._embed_utterances(utterances)` — batch encodes all utterance texts via sentence-transformers; populates `Utterance.embedding`
  - [ ] `Segmentor._detect_verse_boundaries(utterances)` — sliding-window cosine similarity; splits at drop-offs below `verse_similarity_threshold`; enforces `min_utterances_per_verse` and `max_utterances_per_verse`
  - [ ] `Segmentor._embed_verses(verses)` — mean of constituent utterance embeddings
  - [ ] `Segmentor._detect_chapter_boundaries(verses, hard_boundaries)` — sliding-window over verse embeddings below `chapter_similarity_threshold`; hard boundary timestamps from TubeFetch override algorithm
  - [ ] `Segmentor.segment(bundle)` — orchestrates all steps; returns `TranscriptTree`; raises `SegmentorError` on failure
  - [ ] Add Apache-2.0 header
- [ ] Add `tests/fixtures/transcript_segments.json` — small fixture (10 segments, 2 clear topic shifts)
- [ ] Write `tests/test_segmentor.py`
  - [ ] Utterance count correct for fixture input (known sentence boundaries)
  - [ ] Verse boundaries detected at known similarity drop-offs in fixture
  - [ ] `min_utterances_per_verse` enforced — verses below minimum are merged with neighbours
  - [ ] Chapter hard boundary overrides algorithm at known timestamp
  - [ ] `TranscriptTree.utterances` returns all utterances in correct order
  - [ ] `TranscriptTree.verses` returns all verses in correct order
  - [ ] `SegmentorError` raised when spaCy model not found (mocked)
  - [ ] (All tests use fixture data — no live TubeFetch or model download)
- [ ] Verify: `pytest tests/test_segmentor.py` passes
- [ ] Bump version to `v0.5.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.5.0]` entry to `CHANGELOG.md`

---

### Story B.c: v0.6.0 — Valence Scorer [Planned]

Implement `tubesense/valence.py` — reimplementation of the rough PoC bespoke model architecture, loading transferred weights.

- [ ] Add `transformers>=4.40`, `torch>=2.2`, `peft>=0.10` to `pyproject.toml` and `environment.yml`
- [ ] Create `tubesense/valence.py`
  - [ ] `ValenceScore` dataclass — `label`, `confidence`, `score_positive`, `score_neutral`, `score_negative`, `polarity`
  - [ ] `ValenceScorer.__init__` — resolves device (`auto` → CUDA → MPS → CPU); loads tokenizer and model from `config.valence.model_dir` via PEFT `PeftModel.from_pretrained()`; validates 3-class output with `id2label` check; raises `ValenceModelError` on load failure; logs resolved device at INFO level; recommends `PYTORCH_ENABLE_MPS_FALLBACK=1` when device is MPS
  - [ ] `ValenceScorer.score(text)` — tokenizes, runs forward pass, applies softmax, returns `ValenceScore`; `polarity = score_positive - score_negative`
  - [ ] `ValenceScorer.score_batch(texts)` — DataLoader-based batched inference; `num_workers=0` on MPS, `min(4, os.cpu_count())` on CUDA/CPU; returns `list[ValenceScore]` in input order
  - [ ] Label mapping: `{0: "NEGATIVE", 1: "NEUTRAL", 2: "POSITIVE"}` consistent with rough PoC
  - [ ] Add Apache-2.0 header
- [ ] Write `tests/test_valence.py`
  - [ ] `ValenceScore` fields all present and types correct (mocked model)
  - [ ] `polarity` computed correctly: `score_positive - score_negative`
  - [ ] `label` matches argmax of `[score_negative, score_neutral, score_positive]`
  - [ ] `confidence` equals max softmax probability
  - [ ] `ValenceModelError` raised when `model_dir` does not exist
  - [ ] `ValenceModelError` raised when model does not have 3-class output (mocked)
  - [ ] `score_batch()` returns results in input order (mocked model, 5-item input)
  - [ ] (All tests use mocked model — no live weight download)
- [ ] Verify: `pytest tests/test_valence.py` passes
- [ ] Bump version to `v0.6.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.6.0]` entry to `CHANGELOG.md`

---

### Story B.d: v0.7.0 — LLM Scorer [Planned]

Implement `tubesense/llm_scorer.py` — zero-shot MDSA scoring via Anthropic API for the nine non-valence axes.

- [ ] Add `anthropic>=0.25`, `gentlify>=2.0` to `pyproject.toml` and `environment.yml`
- [ ] Create `tubesense/llm_scorer.py`
  - [ ] `MdsaScores` dataclass — all fields per tech-spec §5.5; all non-valence fields default `None`; `irony_ambiguous: bool = False`; `outlook_not_applicable: bool = False`
  - [ ] `LlmScorer.__init__` — initialises Anthropic client; builds gentlify `Throttle` with `max_concurrency` and `RetryConfig(max_attempts=retry_attempts, backoff="exponential_jitter")`; raises `LlmScoringError` if `ANTHROPIC_API_KEY` not set
  - [ ] `LlmScorer._build_prompt(text, axes)` — constructs scoring prompt; axis definitions and scale anchors sourced from `docs/specs/sentiment-analysis-specification.md` content (loaded at init); instructs model to return only JSON, no preamble or markdown fences; instructs model to return `null` for Outlook when N/A
  - [ ] `LlmScorer._parse_response(response_text)` — strips markdown fences; parses JSON; validates all values within stated axis ranges per MDSA spec; sets `irony_ambiguous=True` if irony ∈ [0.3, 0.7]; sets `outlook_not_applicable=True` if outlook is `null`; on parse failure logs warning and returns all-`None` `MdsaScores`
  - [ ] `LlmScorer._score_batch_async(texts)` — dispatches via gentlify `Throttle`; each slot calls Anthropic API for one utterance; collects results in input order
  - [ ] `LlmScorer.score(text)` — synchronous single-text wrapper
  - [ ] `LlmScorer.score_batch(texts)` — `asyncio.run(_score_batch_async(texts))`
  - [ ] Add Apache-2.0 header
- [ ] Write `tests/test_llm_scorer.py`
  - [ ] `_build_prompt()` output contains axis names for all requested axes
  - [ ] `_build_prompt()` contains scale range for Valence (−1 to +1) as a sanity check that spec content is loaded
  - [ ] `_parse_response()` correctly parses valid JSON with all nine axes
  - [ ] `_parse_response()` strips markdown fences before parsing
  - [ ] `_parse_response()` sets `irony_ambiguous=True` for irony score of `0.5`
  - [ ] `_parse_response()` sets `irony_ambiguous=False` for irony score of `0.1`
  - [ ] `_parse_response()` sets `outlook_not_applicable=True` when outlook is `null`
  - [ ] `_parse_response()` returns all-`None` `MdsaScores` and logs warning on malformed JSON
  - [ ] `_parse_response()` raises no exception on malformed JSON (graceful degradation)
  - [ ] `score_batch()` returns results in input order (mocked Anthropic client, 3-item input)
  - [ ] `LlmScoringError` raised when `ANTHROPIC_API_KEY` not set
  - [ ] (All tests mock Anthropic API — no live API calls)
- [ ] Verify: `pytest tests/test_llm_scorer.py` passes
- [ ] Bump version to `v0.7.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.7.0]` entry to `CHANGELOG.md`

---

### Story B.e: v0.8.0 — Aggregator [Planned]

Implement `tubesense/aggregator.py` — confidence-weighted verse and chapter score aggregation.

- [ ] Create `tubesense/aggregator.py`
  - [ ] `AggregatedScores` dataclass — all fields per tech-spec §5.6; mean, min, max, std per continuous axis; `emotion_plurality`, `emotion_distribution`, `utterance_count`, `null_counts`
  - [ ] `Aggregator.aggregate(scores)` — confidence-weighted mean using `valence_confidence` as weight; falls back to unweighted mean if all confidences are `None`; excludes `None` values from all computations; records exclusion count in `null_counts`; emotion plurality by count with first-occurrence tie-breaking; `outlook_not_applicable` utterances excluded from outlook aggregation
  - [ ] Add Apache-2.0 header
- [ ] Write `tests/test_aggregator.py`
  - [ ] Confidence-weighted mean correct for 3-item fixture with known weights
  - [ ] Unweighted mean used when all `valence_confidence` are `None`
  - [ ] `None` values excluded from mean, min, max, std; `null_counts` incremented correctly
  - [ ] `emotion_plurality` returns correct plurality for 5-item fixture
  - [ ] Tie in emotion plurality broken by first occurrence
  - [ ] `outlook_not_applicable=True` utterances excluded from outlook aggregation
  - [ ] `utterance_count` reflects total input count, not count after null exclusion
- [ ] Verify: `pytest tests/test_aggregator.py` passes
- [ ] Bump version to `v0.8.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.8.0]` entry to `CHANGELOG.md`

---

### Story B.f: v0.9.0 — Graph Builder and Cache [Planned]

Implement `tubesense/graph.py` and `tubesense/cache.py` — semantic graph construction, traversal, query, and all parquet/JSON I/O.

- [ ] Add `networkx>=3.2`, `pandas>=2.2`, `pyarrow>=15.0`, `scikit-learn>=1.4` to `pyproject.toml` and `environment.yml`
- [ ] Create `tubesense/cache.py`
  - [ ] `save_graph(graph_dict, path)` — atomic write (temp file + rename); creates parent dirs
  - [ ] `load_graph(path)` — reads JSON; raises `CacheNotFoundError` if missing
  - [ ] `save_utterances(df, path)` — writes parquet atomically; nullable columns for all `None`-able fields
  - [ ] `load_utterances(path)` — reads parquet; raises `CacheNotFoundError` if missing
  - [ ] `save_report(report_dict, path)` — atomic JSON write
  - [ ] Add Apache-2.0 header
- [ ] Create `tubesense/graph.py`
  - [ ] `ScoredUtterance`, `ScoredVerse`, `ScoredChapter` dataclasses per tech-spec §5.7
  - [ ] `QueryResult` dataclass — `node_id`, `node_type`, `text`, `start_seconds`, `scores`, `similarity`
  - [ ] `TranscriptGraph.__init__` — stores `nx.DiGraph` and `video_id`
  - [ ] `TranscriptGraph.query(query, top_k, node_types)` — embeds query via sentence-transformers; computes cosine similarity against node embeddings; returns top-k `QueryResult` sorted by similarity; filters by `node_types` if provided
  - [ ] `TranscriptGraph.narrative_arc()` — returns `list[tuple[float, float]]` of `(start_seconds, valence_mean)` at chapter level in temporal order
  - [ ] `TranscriptGraph.anomalies(threshold)` — returns verses where `|verse.valence_mean - chapter.valence_mean| > threshold`
  - [ ] `TranscriptGraph.to_json()` — NetworkX node-link format; includes `video_id` and `transcript_content_hash` at top level
  - [ ] `TranscriptGraph.from_json(data)` — classmethod reconstructing from node-link dict
  - [ ] `GraphBuilder.__init__` — stores config
  - [ ] `GraphBuilder.build(tree, scored_utterances, bundle)` — creates all nodes and edges per tech-spec §5.7; `shares_topic` edges computed via pairwise verse embedding cosine similarity above `topic_similarity_threshold`; `sentiment_shift` edges computed from adjacent verse `valence_mean` delta above `sentiment_shift_threshold`
  - [ ] Add Apache-2.0 header
- [ ] Write `tests/test_graph.py`
  - [ ] Node count correct for 2-chapter, 4-verse, 8-utterance fixture tree
  - [ ] `contains` edges present for all chapter→verse and verse→utterance pairs
  - [ ] `follows` edges present between adjacent siblings at each level
  - [ ] `shares_topic` edge created between verses with similarity above threshold; absent below threshold
  - [ ] `sentiment_shift` edge created between adjacent verses with polarity delta above threshold
  - [ ] `query()` returns results in descending similarity order
  - [ ] `query()` filtered by `node_type` returns only matching node types
  - [ ] `narrative_arc()` returns chapters in temporal order
  - [ ] `anomalies()` returns only verses exceeding threshold delta
  - [ ] `to_json()` + `from_json()` roundtrip: node and edge count identical
- [ ] Write `tests/test_cache.py`
  - [ ] `save_graph()` + `load_graph()` roundtrip preserves all fields
  - [ ] `CacheNotFoundError` raised when graph file missing
  - [ ] `save_utterances()` + `load_utterances()` roundtrip preserves nullable columns as `None` not `0`
  - [ ] Atomic write: partial file not present on simulated mid-write failure
- [ ] Verify: `pytest tests/test_graph.py tests/test_cache.py` passes
- [ ] Bump version to `v0.9.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.9.0]` entry to `CHANGELOG.md`

---

## Phase C: Pipeline & Orchestration

Wires all core services into the end-to-end `Pipeline`, adds the report generator, and validates the full pipeline on a real video.

---

### Story C.a: v0.10.0 — Pipeline Orchestrator [Planned]

Implement `tubesense/pipeline.py` — end-to-end orchestration of all Phase B modules.

- [ ] Create `tubesense/pipeline.py`
  - [ ] `Pipeline.__init__` — instantiates all services (`Ingestor`, `Segmentor`, `ValenceScorer`, `LlmScorer`, `Aggregator`, `GraphBuilder`) from `AppConfig`; logs resolved device and model dir at INFO
  - [ ] `Pipeline.run(source, force, axes)` — full sequence: ingest → segment → score utterances (valence then LLM) → aggregate to verses and chapters → build graph → save outputs (graph JSON, utterances parquet, report JSON); skips scoring if `needs_scoring()` returns `False` and `force=False`; returns `TranscriptGraph`
  - [ ] `Pipeline.run_batch(sources, workers, force, axes)` — concurrent execution via `ThreadPoolExecutor`; per-video error isolation; returns `list[TranscriptGraph]`
  - [ ] Report generation inline: builds `report.json` dict from graph (narrative arc, anomalies, chapter summaries, axes scored, version, timestamp) and saves via `cache.save_report()`
  - [ ] Add Apache-2.0 header
- [ ] Write `tests/test_pipeline.py`
  - [ ] Full pipeline run on fixture `VideoBundle` with all services mocked; assert graph returned with correct node count
  - [ ] `needs_scoring()` returning `False` skips scoring (mock verifies scorer not called)
  - [ ] `force=True` overrides incremental skip
  - [ ] `axes` parameter correctly limits LLM scorer to specified subset
  - [ ] `run_batch()` with one failing source returns partial results and logs error (does not raise)
  - [ ] Report JSON written to correct path with all required keys
- [ ] Verify: `pytest tests/test_pipeline.py` passes
- [ ] Bump version to `v0.10.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.10.0]` entry to `CHANGELOG.md`

---

### Story C.b: v0.11.0 — End-to-End Integration Run [Planned]

First live pipeline run on a real YouTube video. No new code — validates that all Phase B and C modules work together on real data.

- [ ] Select a short (3–8 minute) YouTube video with clean English transcript for validation run
- [ ] Run `python scripts/spike_pipeline.py` to confirm spike still passes with current codebase
- [ ] Run full pipeline via Python library API on selected video
  - [ ] Confirm `data/tubefetch/{video_id}/` populated with TubeFetch output
  - [ ] Confirm `data/scored/{video_id}/utterances.parquet` written with correct schema
  - [ ] Confirm `data/scored/{video_id}/graph.json` written; load and check node/edge counts
  - [ ] Confirm `data/scored/{video_id}/report.json` written with `narrative_arc` and `chapter_summaries`
- [ ] Inspect output quality
  - [ ] Verse boundaries are topically coherent (spot-check manually)
  - [ ] Valence scores are directionally correct for known sentiment passages
  - [ ] LLM axis scores are plausible and within stated ranges
  - [ ] No `None` values in unexpected columns
- [ ] Run incremental mode: run pipeline again on same video without `--force`; confirm no re-scoring (scorer not called)
- [ ] Document observed verse/chapter counts and any quality issues in `CHANGELOG.md` entry for this story (no version bump)

---

## Phase D: CLI & Library API

Adds the Click CLI, public library API surface, and the JupyterLab notebooks.

---

### Story D.a: v0.12.0 — CLI [Planned]

Implement `tubesense/cli.py` — all Click commands wired to `Pipeline`.

- [ ] Create `tubesense/cli.py`
  - [ ] `cli` group — `--config`, `--verbose` global flags; loads `AppConfig` via `load_config()`; stores in Click context
  - [ ] `score` command — accepts `ids` (variadic), `--file`, `--from-dir`, `--axes`, `--workers`, `--force`; validates at least one source provided; calls `pipeline.run()` or `run_batch()`; prints per-video summary via rich
  - [ ] `report` command — accepts `video_id`; loads `report.json` from cache; prints formatted report via rich; raises `CacheNotFoundError` (exit 1) if not scored
  - [ ] `query` command — accepts `video_id`, `query` string, `--top-k`, `--node-type`; loads graph from cache; calls `graph.query()`; prints results table via rich
  - [ ] `doctor` command — all checks per tech-spec §5.9; exits 0 if all required checks pass, 1 if any fail
  - [ ] `clean` command — scans `data/tubefetch/` and `data/scored/`; prints file listing with sizes via rich; prints `rm` commands for review; does not delete automatically
  - [ ] Register `tubesense` as CLI entry point in `pyproject.toml`
  - [ ] Add Apache-2.0 header
- [ ] Write `tests/test_cli.py`
  - [ ] All commands exit 0 with `--help`
  - [ ] `tubesense score` with no IDs, no `--file`, no `--from-dir` exits 1 with clear message
  - [ ] `tubesense report` with unscored video ID exits 1 with clear message
  - [ ] `tubesense doctor` output includes all required check labels
  - [ ] `tubesense score --axes intensity,irony` passes correct axes to pipeline (mocked)
- [ ] Verify: `tubesense --help` and all subcommand `--help` flags exit 0
- [ ] Bump version to `v0.12.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.12.0]` entry to `CHANGELOG.md`

---

### Story D.b: v0.13.0 — Public Library API [Planned]

Finalise `tubesense/__init__.py` public exports and add notebooks.

- [ ] Update `tubesense/__init__.py`
  - [ ] Export `Pipeline`, `load_graph`, `AppConfig`, `load_config`, `__version__`
  - [ ] Add Apache-2.0 header
- [ ] Create `notebooks/01-ingestion.ipynb` — TubeFetch integration walkthrough; inspect `VideoBundle` fields; print segment count and first 5 segments
- [ ] Create `notebooks/02-segmentation.ipynb` — load a scored transcript; visualise verse boundary similarity curve; inspect chapter structure; tune `verse_similarity_threshold` interactively
- [ ] Create `notebooks/03-valence-scoring.ipynb` — load utterances parquet; plot valence distribution; inspect high-confidence errors; confidence histogram
- [ ] Create `notebooks/04-mdsa-scoring.ipynb` — all-axis score distributions; axis correlation heatmap; irony-ambiguous utterance browser; null rate per axis
- [ ] Create `notebooks/05-graph.ipynb` — visualise graph structure (NetworkX + matplotlib); explore `shares_topic` and `sentiment_shift` edges; run `query()` and display results
- [ ] Create `notebooks/06-analysis.ipynb` — narrative arc plot; anomaly listing; chapter-level sentiment heatmap
- [ ] Verify all notebooks run top-to-bottom without errors (using scored output from C.b)
- [ ] Bump version to `v0.13.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.13.0]` entry to `CHANGELOG.md`

---

## Phase E: Testing & Quality

Brings coverage to targets, adds edge case tests, and enforces type checking and linting.

---

### Story E.a: v0.14.0 — Coverage & Edge Cases [Planned]

- [ ] Run `pytest --cov=tubesense --cov-report=term-missing`
  - [ ] Identify all modules below 80% overall / below 90% for `segmentor.py`, `llm_scorer.py`, `graph.py`
- [ ] Add missing tests to reach coverage targets
  - [ ] `segmentor.py` edge cases: single-utterance transcript; transcript with only one topic (no verse splits); TubeFetch hard boundary at first segment
  - [ ] `llm_scorer.py` edge cases: Anthropic API timeout (mocked); response with extra unexpected JSON keys; irony score exactly at ambiguity boundary (0.3 and 0.7)
  - [ ] `graph.py` edge cases: single-chapter transcript; no `shares_topic` edges (all verses dissimilar); `query()` with `top_k` larger than node count
  - [ ] `pipeline.py` edge cases: empty transcript (zero utterances after segmentation); `axes=[]` skips LLM scorer entirely
- [ ] Run `mypy --strict tubesense/` — fix all type errors
- [ ] Run `ruff check tubesense/` — fix all warnings
- [ ] Run `ruff format tubesense/` — apply consistent formatting
- [ ] Verify: overall coverage ≥ 80%; `segmentor.py`, `llm_scorer.py`, `graph.py` ≥ 90%
- [ ] Bump version to `v0.14.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.14.0]` entry to `CHANGELOG.md`

---

## Phase F: Documentation & Release

README polish, final CHANGELOG review, and production PyPI release.

---

### Story F.a: v0.15.0 — README & Final Polish [Planned]

- [ ] Update `README.md` to production quality
  - [ ] Project description and motivation (references `concept.md` framing)
  - [ ] Architecture diagram (ASCII or Mermaid) — TubeFetch → Segmentor → Valence → LLM → Graph
  - [ ] Installation instructions: `pip install tubesense`, spaCy model download, `.env` setup
  - [ ] Quick start: CLI one-liner and library API example
  - [ ] Configuration reference: key `config.yml` fields
  - [ ] Framework specification references: link to the three `docs/specs/` documents
  - [ ] Known limitations: LLM scoring requires `ANTHROPIC_API_KEY`; valence model weights not included in PyPI package (transfer instructions)
  - [ ] Verify all badges render correctly (CI, coverage, version, license, typed)
- [ ] Final `CHANGELOG.md` review — confirm all entries accurate and complete
- [ ] Run full test suite: `pytest --cov=tubesense` — confirm targets met
- [ ] Run `mypy --strict tubesense/` — zero errors
- [ ] Run `ruff check tubesense/` — zero warnings
- [ ] Run `tubesense doctor` — all checks green
- [ ] Tag `v0.15.0` and confirm GitHub Actions release workflow publishes to PyPI
- [ ] Verify: `pip install tubesense==0.15.0` installs correctly
- [ ] Add `## [0.15.0]` entry to `CHANGELOG.md`

---

## Phase G: CI/CD & Automation

Adds GitHub Actions CI, Codecov coverage reporting, and transitions to production mode.

---

### Story G.a: v0.16.0 — GitHub Actions: Lint, Test & Coverage [Planned]

- [ ] Create `.github/workflows/ci.yml`
  - [ ] Trigger: `push` and `pull_request` on all branches
  - [ ] Matrix: Python `3.12` (single version — project pins 3.12)
  - [ ] Steps: checkout, set up micromamba from `environment.yml`, `ruff check`, `ruff format --check`, `mypy --strict tubesense/`, `pytest --cov=tubesense --cov-report=xml`
  - [ ] Upload coverage XML to Codecov via `codecov/codecov-action@v4`
- [ ] Add Codecov badge to `README.md`
- [ ] Add CI status badge to `README.md`
- [ ] Verify: push to a feature branch triggers CI and all checks pass
- [ ] Bump version to `v0.16.0` in `pyproject.toml` and `__init__.py`
- [ ] Add `## [0.16.0]` entry to `CHANGELOG.md`

---

### Story G.b: Production Mode Transition [Planned]

No version bump — configuration and documentation only.

- [ ] Enable branch protection on `main`
  - [ ] Require pull request before merging
  - [ ] Require CI status checks to pass before merge
  - [ ] Require at least 1 approval
- [ ] Finalise `CONTRIBUTING.md`
  - [ ] Development setup (`pyve --init`, spaCy model download, `.env` setup, valence weight transfer)
  - [ ] Code style (ruff, mypy strict)
  - [ ] PR process and branch naming convention
  - [ ] Release process (tag → GitHub Actions → PyPI via trusted publishing)
  - [ ] Disclosure note: LLM-assisted development with human review and direction
- [ ] Create `SECURITY.md` — vulnerability reporting via GitHub private disclosure
- [ ] Create `.github/dependabot.yml`
  - [ ] Automated dependency updates for `pip` ecosystem, weekly schedule
  - [ ] Automated updates for `github-actions` ecosystem, weekly schedule
- [ ] Verify: `CONTRIBUTING.md`, `SECURITY.md`, `dependabot.yml` present and correct
- [ ] Verify: branch protection rules active on `main`

---

*Document version: 0.1 — Approved*

---

