# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-03-20

### Added
- `tubesense/config.py` — `IngestorConfig`, `SegmentorConfig`, `ValenceConfig`, `LlmScorerConfig`, `GraphConfig`, `AppConfig` dataclasses with validation; `load_config()` merging YAML over defaults
- `tubesense/exceptions.py` — full exception hierarchy (`TubeSenseError` → `IngestorError`, `SegmentorError`, `ValenceModelError`, `LlmScoringError`, `GraphError`, `CacheNotFoundError`, `ConfigError`)
- `config.yml` — default configuration file with all settings documented
- `tests/test_config.py` — 13 tests covering defaults, YAML merging, and all validation error paths
- `tests/test_exceptions.py` — 4 tests covering instantiation, inheritance, and catchability

## [0.2.0] - 2026-03-20

### Added
- `scripts/spike_pipeline.py` — end-to-end stack spike wiring TubeFetch → valence scorer → Anthropic LLM scorer → NetworkX graph
- Spike gracefully skips TubeFetch (pending Python 3.12 re-release) and valence model (weights not yet built), so Steps 3 and 4 are runnable now
- Spike deps added to `environment.yml`: `tubefetch>=1.4`, `anthropic>=0.25`, `transformers>=4.40`, `torch>=2.2`, `peft>=0.10`, `networkx>=3.2`, `gentlify>=2.0`, `python-dotenv>=1.0`
- Fixed Anthropic model ID: `claude-sonnet-4-6` (updated from stale `claude-sonnet-4-20250514` in tech-spec and stories)

## [0.1.0] - 2026-03-20

### Added
- Initial package scaffold — reserves `tubesense` name on PyPI
- `tubesense/__init__.py` exporting `__version__ = "0.1.0"`
- `tubesense/py.typed` PEP 561 marker
- `pyproject.toml` with hatchling build backend and Apache-2.0 license
- `environment.yml` for micromamba environment setup
- `README.md` with PyPI badges
- `CHANGELOG.md` (this file)
- `.env.example` documenting required and optional environment variables
- `.gitignore` with Python, model weights, and data directory entries
- GitHub Actions `release.yml` workflow for PyPI trusted publishing on version tags
- `CONTRIBUTING.md` stub documenting PyPI trusted publisher setup
