# Copyright (c) 2026 Pointmatic
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Stack spike — Story A.b

Wires the full critical path end-to-end before any production modules are written:
  1. TubeFetch fetches a transcript
  2. Valence model loads and scores one sentence
  3. Anthropic API scores one sentence on the remaining nine MDSA axes
  4. A minimal NetworkX graph is constructed from the result

This script is intentionally throwaway — kept in scripts/ as a reference.
It is excluded from the installed package.

Usage:
    python scripts/spike_pipeline.py

Prerequisites:
    - TubeFetch installed: pip install tubefetch
    - Anthropic SDK installed: pip install anthropic
    - NetworkX installed: pip install networkx
    - .env populated with ANTHROPIC_API_KEY
    - Valence model weights at models/valence/best-model/ (see NOTE below)

NOTE — Valence model weights:
    The weights have not been built yet. When ready, copy the trained model
    directory from the rough PoC into this repo:

        cp -r /path/to/sentiment-poc/models/bespoke/best-model/ \\
              models/valence/best-model/

    The directory must contain:
        - adapter_config.json       (PEFT LoRA adapter config)
        - pytorch_model.bin         (or model.safetensors)
        - tokenizer.json            (DeBERTa tokenizer)
        - tokenizer_config.json
        - config.json               (must include id2label: {0: "NEGATIVE", 1: "NEUTRAL", 2: "POSITIVE"})
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

VIDEO_ID = "jNQXAC9IVRw"  # "Me at the zoo" — first YouTube video, 19 seconds, clean transcript
MODEL_DIR = Path("models/valence/best-model")
ANTHROPIC_MODEL = "claude-sonnet-4-6"
SAMPLE_SENTENCE = "I think that's pretty much all there is to say about that."


# ---------------------------------------------------------------------------
# Step 1: TubeFetch — fetch transcript
# ---------------------------------------------------------------------------

def step1_tubefetch(video_id: str) -> tuple[str, list[dict]]:  # type: ignore[return]
    """Fetch video metadata and transcript segments via TubeFetch."""
    print("\n── Step 1: TubeFetch ──────────────────────────────────────────")
    try:
        from tubefetch import FetchOptions, fetch_video  # type: ignore[import]
    except ImportError:
        print("  ✗ TubeFetch not installed. Run: pip install tubefetch")
        print("    (TubeFetch requires Python >=3.12 — re-release pending)")
        print("  → Skipping Step 1, using stub data.\n")
        stub_segments = [
            {"text": SAMPLE_SENTENCE, "start": 0.0, "end": 5.0},
            {"text": "Elephants are really cool.", "start": 5.0, "end": 10.0},
            {"text": "They have long trunks.", "start": 10.0, "end": 14.0},
        ]
        return "stub_title", stub_segments

    opts = FetchOptions(bundle=True)
    result = fetch_video(video_id, opts)

    title = result.metadata.title
    segments = [
        {"text": seg.text, "start": seg.start_seconds, "end": seg.end_seconds}
        for seg in result.transcript.segments
    ]

    print(f"  ✓ Title: {title}")
    print(f"  ✓ Segment count: {len(segments)}")
    print(f"  ✓ First segment: {segments[0]['text']!r}")
    return title, segments


# ---------------------------------------------------------------------------
# Step 2: Valence model — load and score one sentence
# ---------------------------------------------------------------------------

def step2_valence(sentence: str) -> dict | None:
    """Load the DeBERTa + LoRA valence classifier and score one sentence."""
    print("\n── Step 2: Valence Scorer ─────────────────────────────────────")

    if not MODEL_DIR.exists():
        print(f"  ✗ Model weights not found at {MODEL_DIR}")
        print("    To enable this step, copy trained weights from the rough PoC:")
        print(f"      cp -r /path/to/sentiment-poc/models/bespoke/best-model/ {MODEL_DIR}/")
        print("    Expected contents: adapter_config.json, pytorch_model weights,")
        print("    tokenizer files, config.json with id2label.")
        print("  → Skipping Step 2.\n")
        return None

    try:
        import torch
        from peft import PeftModel
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        # Device resolution: CUDA → MPS → CPU
        if torch.cuda.is_available():
            device = torch.device("cuda")
        elif torch.backends.mps.is_available():
            device = torch.device("mps")
        else:
            device = torch.device("cpu")
        print(f"  ✓ Device: {device}")

        tokenizer = AutoTokenizer.from_pretrained(str(MODEL_DIR))
        base_model = AutoModelForSequenceClassification.from_pretrained(
            "microsoft/deberta-v3-base", num_labels=3
        )
        model = PeftModel.from_pretrained(base_model, str(MODEL_DIR))
        model = model.to(device)
        model.eval()

        # Validate label mapping
        id2label = model.config.id2label  # type: ignore[union-attr]
        assert id2label == {0: "NEGATIVE", 1: "NEUTRAL", 2: "POSITIVE"}, (
            f"Unexpected id2label: {id2label}"
        )

        inputs = tokenizer(sentence, return_tensors="pt", truncation=True, max_length=512)
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = model(**inputs)
            probs = torch.softmax(outputs.logits, dim=-1).squeeze().cpu().tolist()

        score_neg, score_neu, score_pos = probs
        label = id2label[int(torch.argmax(outputs.logits))]
        confidence = max(probs)
        polarity = score_pos - score_neg

        result = {
            "label": label,
            "confidence": round(confidence, 4),
            "score_positive": round(score_pos, 4),
            "score_neutral": round(score_neu, 4),
            "score_negative": round(score_neg, 4),
            "polarity": round(polarity, 4),
        }
        print(f"  ✓ Sentence: {sentence!r}")
        print(f"  ✓ Label: {result['label']}  confidence: {result['confidence']}")
        print(f"  ✓ polarity: {result['polarity']}")
        return result

    except Exception as e:
        print(f"  ✗ Valence scoring failed: {e}")
        return None


# ---------------------------------------------------------------------------
# Step 3: Anthropic API — zero-shot MDSA scoring for nine non-valence axes
# ---------------------------------------------------------------------------

def step3_llm(sentence: str) -> dict:
    """Score one sentence on the nine non-valence MDSA axes via Anthropic API."""
    print("\n── Step 3: LLM Scorer (Anthropic) ─────────────────────────────")

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("  ✗ ANTHROPIC_API_KEY not set in environment / .env")
        sys.exit(1)

    try:
        import anthropic
    except ImportError:
        print("  ✗ anthropic SDK not installed. Run: pip install anthropic")
        sys.exit(1)

    prompt = f"""You are a sentiment analyst applying the Multi-Dimensional Sentiment Analysis (MDSA) framework.

Score the following sentence on these nine axes. Return ONLY a JSON object with these exact keys.
Follow the scale for each axis precisely.

Axes and scales:
- intensity: 0.0 (none) to 1.0 (extreme)
- subjectivity: 0.0 (purely objective) to 1.0 (purely subjective)
- certainty: -1.0 (maximally uncertain) to +1.0 (maximally certain)
- outlook: -1.0 (pessimistic) to +1.0 (optimistic), or null if the sentence is not forward-looking
- register: -1.0 (very informal/colloquial) to +1.0 (very formal)
- manners: -1.0 (very rude/hostile) to +1.0 (very polite/courteous)
- intent: -1.0 (strongly harmful/destructive intent) to +1.0 (strongly helpful/constructive intent)
- irony: 0.0 (no irony) to 1.0 (clearly ironic)
- emotion: one of: joy, anger, fear, sadness, surprise, disgust, neutral

Sentence: "{sentence}"

Return only the JSON object, no preamble, no markdown fences."""

    client = anthropic.Anthropic(api_key=api_key)
    message = client.messages.create(
        model=ANTHROPIC_MODEL,
        max_tokens=256,
        messages=[{"role": "user", "content": prompt}],
    )

    response_text = message.content[0].text.strip()
    # Strip markdown fences if present
    if response_text.startswith("```"):
        response_text = response_text.split("\n", 1)[1].rsplit("```", 1)[0].strip()

    scores = json.loads(response_text)

    print(f"  ✓ Sentence: {sentence!r}")
    for axis, value in scores.items():
        print(f"  ✓ {axis}: {value}")

    return scores


# ---------------------------------------------------------------------------
# Step 4: NetworkX — minimal 3-node semantic graph
# ---------------------------------------------------------------------------

def step4_graph(valence: dict | None, llm_scores: dict) -> None:
    """Construct a 3-node (Video → Verse → Utterance) NetworkX DiGraph."""
    print("\n── Step 4: Semantic Graph (NetworkX) ──────────────────────────")

    try:
        import networkx as nx
    except ImportError:
        print("  ✗ networkx not installed. Run: pip install networkx")
        sys.exit(1)

    g = nx.DiGraph()

    # Nodes
    g.add_node("video_0", type="video", video_id=VIDEO_ID)
    g.add_node("verse_0", type="verse", start_seconds=0.0, end_seconds=14.0)
    g.add_node(
        "utterance_0",
        type="utterance",
        text=SAMPLE_SENTENCE,
        start_seconds=0.0,
        end_seconds=5.0,
        valence=valence,
        llm_scores=llm_scores,
    )

    # Edges
    g.add_edge("video_0", "verse_0", type="contains")
    g.add_edge("verse_0", "utterance_0", type="contains")

    assert g.number_of_nodes() == 3, f"Expected 3 nodes, got {g.number_of_nodes()}"
    assert g.number_of_edges() == 2, f"Expected 2 edges, got {g.number_of_edges()}"

    print(f"  ✓ Nodes: {g.number_of_nodes()}")
    print(f"  ✓ Edges: {g.number_of_edges()}")
    print(f"  ✓ Node types: {[d['type'] for _, d in g.nodes(data=True)]}")
    print(f"  ✓ Edge types: {[d['type'] for _, _, d in g.edges(data=True)]}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    print("=" * 64)
    print("tubesense — Stack Spike (Story A.b)")
    print("=" * 64)

    title, segments = step1_tubefetch(VIDEO_ID)
    sample = segments[0]["text"] if segments else SAMPLE_SENTENCE

    valence = step2_valence(sample)
    llm_scores = step3_llm(sample)
    step4_graph(valence, llm_scores)

    print("\n── Summary ─────────────────────────────────────────────────────")
    print(f"  Video title  : {title}")
    print(f"  Sample text  : {sample!r}")
    if valence:
        print(f"  Valence      : {valence['label']} (polarity={valence['polarity']})")
    else:
        print("  Valence      : ⚠ skipped (model weights not yet available)")
    print(f"  LLM axes     : {list(llm_scores.keys())}")
    print(f"  Graph        : 3 nodes, 2 edges ✓")
    print("\nSpike complete.\n")


if __name__ == "__main__":
    main()
