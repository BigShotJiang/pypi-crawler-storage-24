# Copyright (c) 2026 Pointmatic
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Project-specific exception hierarchy for tubesense."""


class TubeSenseError(Exception):
    """Base exception for all tubesense errors."""


class IngestorError(TubeSenseError):
    """TubeFetch fetch or parse failure."""


class SegmentorError(TubeSenseError):
    """Transcript segmentation failure."""


class ValenceModelError(TubeSenseError):
    """Valence model load or inference failure."""


class LlmScoringError(TubeSenseError):
    """Anthropic API call failure after retries exhausted."""


class GraphError(TubeSenseError):
    """Graph construction or traversal failure."""


class CacheNotFoundError(TubeSenseError):
    """Requested scored output does not exist in cache."""


class ConfigError(TubeSenseError):
    """config.yml malformed or invalid values."""
