# Copyright (c) 2026 Pointmatic
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Settings dataclasses and config loading for tubesense."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from tubesense.exceptions import ConfigError

_VALID_DEVICES = {"auto", "cpu", "cuda", "mps"}

_ALL_LLM_AXES = {
    "intensity",
    "subjectivity",
    "certainty",
    "outlook",
    "register",
    "manners",
    "intent",
    "irony",
    "emotion",
}


@dataclass
class IngestorConfig:
    cache_dir: str = "data/tubefetch"
    languages: list[str] = field(default_factory=lambda: ["en"])
    allow_generated: bool = True
    force: bool = False


@dataclass
class SegmentorConfig:
    verse_similarity_threshold: float = 0.85
    chapter_similarity_threshold: float = 0.75
    min_utterances_per_verse: int = 3
    max_utterances_per_verse: int = 15
    spacy_model: str = "en_core_web_trf"


@dataclass
class ValenceConfig:
    model_dir: str = "models/valence/best-model"
    device: str = "auto"
    batch_size: int = 32

    def __post_init__(self) -> None:
        if self.device not in _VALID_DEVICES:
            raise ConfigError(
                f"Invalid device {self.device!r}. Must be one of: {sorted(_VALID_DEVICES)}"
            )


@dataclass
class LlmScorerConfig:
    model: str = "claude-sonnet-4-6"
    max_tokens: int = 512
    axes: list[str] = field(
        default_factory=lambda: [
            "intensity",
            "subjectivity",
            "certainty",
            "outlook",
            "register",
            "manners",
            "intent",
            "irony",
            "emotion",
        ]
    )
    max_concurrency: int = 5
    retry_attempts: int = 3

    def __post_init__(self) -> None:
        if not self.axes:
            raise ConfigError("LlmScorerConfig.axes must be a non-empty list.")
        unknown = set(self.axes) - _ALL_LLM_AXES
        if unknown:
            raise ConfigError(
                f"Unknown axis name(s): {sorted(unknown)}. "
                f"Valid axes: {sorted(_ALL_LLM_AXES)}"
            )


@dataclass
class GraphConfig:
    topic_similarity_threshold: float = 0.80
    sentiment_shift_threshold: float = 0.40
    output_dir: str = "data/scored"


@dataclass
class AppConfig:
    ingestor: IngestorConfig = field(default_factory=IngestorConfig)
    segmentor: SegmentorConfig = field(default_factory=SegmentorConfig)
    valence: ValenceConfig = field(default_factory=ValenceConfig)
    llm: LlmScorerConfig = field(default_factory=LlmScorerConfig)
    graph: GraphConfig = field(default_factory=GraphConfig)


def load_config(path: str = "config.yml") -> AppConfig:
    """Load config.yml, merging over dataclass defaults. Returns AppConfig.

    Raises ConfigError on malformed YAML or invalid values.
    """
    config_path = Path(path)
    if not config_path.exists():
        return AppConfig()

    try:
        raw = yaml.safe_load(config_path.read_text())
    except yaml.YAMLError as exc:
        raise ConfigError(f"Malformed YAML in {path}: {exc}") from exc

    if raw is None:
        return AppConfig()

    if not isinstance(raw, dict):
        raise ConfigError(f"config.yml must be a YAML mapping, got {type(raw).__name__}")

    try:
        return AppConfig(
            ingestor=IngestorConfig(**_section(raw, "ingestor")),
            segmentor=SegmentorConfig(**_section(raw, "segmentor")),
            valence=ValenceConfig(**_section(raw, "valence")),
            llm=LlmScorerConfig(**_section(raw, "llm")),
            graph=GraphConfig(**_section(raw, "graph")),
        )
    except ConfigError:
        raise
    except TypeError as exc:
        raise ConfigError(f"Invalid config key: {exc}") from exc


def _section(raw: dict[str, Any], key: str) -> dict[str, Any]:
    """Extract a config section dict, defaulting to empty if absent."""
    value = raw.get(key, {})
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ConfigError(f"config.yml section '{key}' must be a mapping, got {type(value).__name__}")
    return value  # type: ignore[return-value]
