# Copyright (c) 2026 Pointmatic
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest

from tubesense.exceptions import (
    CacheNotFoundError,
    ConfigError,
    GraphError,
    IngestorError,
    LlmScoringError,
    SegmentorError,
    TubeSenseError,
    ValenceModelError,
)


def test_all_exceptions_instantiate() -> None:
    for cls in (
        TubeSenseError,
        IngestorError,
        SegmentorError,
        ValenceModelError,
        LlmScoringError,
        GraphError,
        CacheNotFoundError,
        ConfigError,
    ):
        exc = cls("test message")
        assert str(exc) == "test message"


def test_all_inherit_from_tubesense_error() -> None:
    for cls in (
        IngestorError,
        SegmentorError,
        ValenceModelError,
        LlmScoringError,
        GraphError,
        CacheNotFoundError,
        ConfigError,
    ):
        assert issubclass(cls, TubeSenseError), f"{cls.__name__} must inherit from TubeSenseError"


def test_tubesense_error_inherits_from_exception() -> None:
    assert issubclass(TubeSenseError, Exception)


def test_exceptions_are_catchable_as_tubesense_error() -> None:
    with pytest.raises(TubeSenseError):
        raise IngestorError("fetch failed")

    with pytest.raises(TubeSenseError):
        raise ConfigError("bad yaml")
