# Copyright (c) 2026 Pointmatic
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pathlib import Path

import pytest

from tubesense.config import (
    AppConfig,
    GraphConfig,
    IngestorConfig,
    LlmScorerConfig,
    SegmentorConfig,
    ValenceConfig,
    load_config,
)
from tubesense.exceptions import ConfigError


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------


def test_defaults_all_sub_configs() -> None:
    cfg = AppConfig()
    assert cfg.ingestor.cache_dir == "data/tubefetch"
    assert cfg.ingestor.languages == ["en"]
    assert cfg.segmentor.verse_similarity_threshold == 0.85
    assert cfg.valence.device == "auto"
    assert cfg.valence.batch_size == 32
    assert cfg.llm.model == "claude-sonnet-4-6"
    assert "intensity" in cfg.llm.axes
    assert len(cfg.llm.axes) == 9
    assert cfg.graph.output_dir == "data/scored"


# ---------------------------------------------------------------------------
# load_config from YAML
# ---------------------------------------------------------------------------


def test_load_config_returns_defaults_when_file_missing(tmp_path: Path) -> None:
    cfg = load_config(str(tmp_path / "nonexistent.yml"))
    assert isinstance(cfg, AppConfig)
    assert cfg.ingestor.cache_dir == "data/tubefetch"


def test_load_config_returns_defaults_for_empty_file(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text("")
    cfg = load_config(str(p))
    assert cfg.valence.device == "auto"


def test_load_config_merges_partial_yaml(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text("valence:\n  device: cpu\n  batch_size: 16\n")
    cfg = load_config(str(p))
    assert cfg.valence.device == "cpu"
    assert cfg.valence.batch_size == 16
    # untouched sections retain defaults
    assert cfg.ingestor.cache_dir == "data/tubefetch"
    assert cfg.llm.model == "claude-sonnet-4-6"


def test_load_config_all_sections(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text(
        "ingestor:\n  cache_dir: /tmp/tf\n"
        "segmentor:\n  verse_similarity_threshold: 0.9\n"
        "valence:\n  device: cpu\n"
        "llm:\n  axes: [intensity, irony]\n"
        "graph:\n  output_dir: /tmp/scored\n"
    )
    cfg = load_config(str(p))
    assert cfg.ingestor.cache_dir == "/tmp/tf"
    assert cfg.segmentor.verse_similarity_threshold == 0.9
    assert cfg.valence.device == "cpu"
    assert cfg.llm.axes == ["intensity", "irony"]
    assert cfg.graph.output_dir == "/tmp/scored"


# ---------------------------------------------------------------------------
# Validation errors
# ---------------------------------------------------------------------------


def test_config_error_invalid_device() -> None:
    with pytest.raises(ConfigError, match="Invalid device"):
        ValenceConfig(device="gpu")


def test_config_error_invalid_device_via_yaml(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text("valence:\n  device: tpu\n")
    with pytest.raises(ConfigError, match="Invalid device"):
        load_config(str(p))


def test_config_error_empty_axes() -> None:
    with pytest.raises(ConfigError, match="non-empty"):
        LlmScorerConfig(axes=[])


def test_config_error_unknown_axis() -> None:
    with pytest.raises(ConfigError, match="Unknown axis"):
        LlmScorerConfig(axes=["intensity", "vibes"])


def test_config_error_unknown_axis_via_yaml(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text("llm:\n  axes: [intensity, notanaxis]\n")
    with pytest.raises(ConfigError, match="Unknown axis"):
        load_config(str(p))


def test_config_error_malformed_yaml(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text("valence: [\nbad yaml {{{\n")
    with pytest.raises(ConfigError, match="Malformed YAML"):
        load_config(str(p))


def test_config_error_non_mapping_section(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text("ingestor: just_a_string\n")
    with pytest.raises(ConfigError):
        load_config(str(p))


def test_config_error_unknown_key(tmp_path: Path) -> None:
    p = tmp_path / "config.yml"
    p.write_text("ingestor:\n  not_a_real_key: 42\n")
    with pytest.raises(ConfigError, match="Invalid config key"):
        load_config(str(p))
