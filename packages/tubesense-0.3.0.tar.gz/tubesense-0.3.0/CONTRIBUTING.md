# Contributing to tubesense

## PyPI Trusted Publisher Setup

`tubesense` uses [PyPI Trusted Publishing](https://docs.pypi.org/trusted-publishers/) (OIDC) for release automation. No API tokens are stored in GitHub secrets.

**One-time setup (repository owner only):**

1. Log in to [pypi.org](https://pypi.org) and create the `tubesense` project if it does not exist.
2. Go to **Manage → Publishing → Add a new publisher**.
3. Fill in:
   - **Owner:** `Pointmatic`
   - **Repository:** `tubesense`
   - **Workflow name:** `release.yml`
   - **Environment:** `pypi`
4. Save. GitHub Actions can now publish to PyPI without any stored secret.

**Also create the GitHub environment:**

1. In the GitHub repo, go to **Settings → Environments → New environment**.
2. Name it `pypi`.
3. Optionally add a required reviewer as a manual approval gate before each publish.

**Releasing a new version:**

1. Bump `version` in `pyproject.toml` and `tubesense/__init__.py`.
2. Update `CHANGELOG.md`.
3. Commit: `git commit -m "chore: bump version to vX.Y.Z"`.
4. Tag: `git tag vX.Y.Z && git push origin vX.Y.Z`.
5. The `release.yml` GitHub Actions workflow builds and publishes automatically.
