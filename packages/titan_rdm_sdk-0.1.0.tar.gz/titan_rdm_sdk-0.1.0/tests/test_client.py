"""Tests for TitanRDMClient."""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from titan_rdm_sdk import TitanRDMClient
from titan_rdm_sdk.exceptions import AuthenticationError, ValidationError


class TestClientInitialization:
    """Tests for client initialization."""

    def test_missing_url_raises_validation_error(self):
        """Test that missing URL raises ValidationError."""
        with pytest.raises(ValidationError, match="url is required"):
            TitanRDMClient(url="", client_id="id", client_secret="secret")

    def test_missing_client_id_raises_validation_error(self):
        """Test that missing client_id raises ValidationError."""
        with pytest.raises(ValidationError, match="client_id is required"):
            TitanRDMClient(url="https://example.com", client_id="", client_secret="secret")

    def test_missing_client_secret_raises_validation_error(self):
        """Test that missing client_secret raises ValidationError."""
        with pytest.raises(ValidationError, match="client_secret is required"):
            TitanRDMClient(url="https://example.com", client_id="id", client_secret="")

    def test_none_url_raises_validation_error(self):
        """Test that None URL raises ValidationError."""
        with pytest.raises(ValidationError, match="url is required"):
            TitanRDMClient(url=None, client_id="id", client_secret="secret")

    @patch("titan_rdm_sdk.client.requests.post")
    def test_successful_initialization(self, mock_post):
        """Test successful client initialization."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "token_type": "Bearer",
            "expires_in": 7200,
            "created_at": 1700000000,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        assert client.url == "https://example.com"
        assert client.access_token == "test_token"
        assert client.token_expires_at is not None

    @patch("titan_rdm_sdk.client.requests.post")
    def test_trailing_slash_removed_from_url(self, mock_post):
        """Test that trailing slash is removed from URL."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com/",
            client_id="test_id",
            client_secret="test_secret",
        )

        assert client.url == "https://example.com"


class TestAuthentication:
    """Tests for authentication flow."""

    @patch("titan_rdm_sdk.client.requests.post")
    def test_authentication_failure_raises_error(self, mock_post):
        """Test that authentication failure raises AuthenticationError."""
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {
            "error": "invalid_client",
            "error_description": "Client authentication failed",
        }
        mock_post.return_value = mock_response

        with pytest.raises(AuthenticationError, match="Authentication failed"):
            TitanRDMClient(
                url="https://example.com",
                client_id="bad_id",
                client_secret="bad_secret",
            )

    @patch("titan_rdm_sdk.client.requests.post")
    def test_authentication_request_format(self, mock_post):
        """Test that authentication request is properly formatted."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        mock_post.assert_called_once()
        call_args = mock_post.call_args
        assert call_args[0][0] == "https://example.com/oauth/token"
        assert call_args[1]["data"]["grant_type"] == "client_credentials"
        assert call_args[1]["data"]["client_id"] == "test_id"
        assert call_args[1]["data"]["client_secret"] == "test_secret"

    @patch("titan_rdm_sdk.client.requests.post")
    def test_connection_error_raises_authentication_error(self, mock_post):
        """Test that connection errors raise AuthenticationError."""
        import requests

        mock_post.side_effect = requests.RequestException("Connection failed")

        with pytest.raises(AuthenticationError, match="Failed to connect"):
            TitanRDMClient(
                url="https://example.com",
                client_id="test_id",
                client_secret="test_secret",
            )


class TestTokenRefresh:
    """Tests for token refresh functionality."""

    @patch("titan_rdm_sdk.client.requests.post")
    def test_token_is_valid_when_not_expired(self, mock_post):
        """Test that token is considered valid when not expired."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        assert client._token_is_valid() is True

    @patch("titan_rdm_sdk.client.requests.post")
    def test_token_is_invalid_when_expired(self, mock_post):
        """Test that token is considered invalid when expired."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        # Set token to expire in the past
        client.token_expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        assert client._token_is_valid() is False

    @patch("titan_rdm_sdk.client.requests.post")
    def test_token_is_invalid_when_expiring_soon(self, mock_post):
        """Test that token is considered invalid when expiring within 5 minutes."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        # Set token to expire in 3 minutes (less than 5 minute buffer)
        client.token_expires_at = datetime.now(timezone.utc) + timedelta(minutes=3)

        assert client._token_is_valid() is False


class TestGetHeaders:
    """Tests for header generation."""

    @patch("titan_rdm_sdk.client.requests.post")
    def test_get_headers_returns_correct_headers(self, mock_post):
        """Test that headers include authorization and content type."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token_123",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        headers = client._get_headers()

        assert headers["Authorization"] == "Bearer test_token_123"
        assert headers["Content-Type"] == "application/json"
        assert headers["Accept"] == "application/json"


class TestGetDownload:
    """Tests for get_download method."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_download_creates_download_instance(self, mock_request, mock_post):
        """Test that get_download returns a Download instance."""
        # Auth response
        mock_auth_response = MagicMock()
        mock_auth_response.status_code = 200
        mock_auth_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_auth_response

        # Export creation response
        mock_export_response = MagicMock()
        mock_export_response.status_code = 201
        mock_export_response.json.return_value = {
            "id": 123,
            "status": "started",
            "branch_id": 174,
            "table_definition_key": 50,
        }
        mock_request.return_value = mock_export_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        download = client.get_download(
            branch_id=174,
            table_definition_key=50,
            pattern="full",
        )

        from titan_rdm_sdk import Download

        assert isinstance(download, Download)
        assert download.id == 123
        assert download.status == "started"


class TestGetUpload:
    """Tests for get_upload method."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_upload_creates_upload_instance(self, mock_request, mock_post):
        """Test that get_upload returns an Upload instance."""
        # Auth response
        mock_auth_response = MagicMock()
        mock_auth_response.status_code = 200
        mock_auth_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_auth_response

        # Import creation response
        mock_import_response = MagicMock()
        mock_import_response.status_code = 201
        mock_import_response.json.return_value = {
            "id": 456,
            "status": "created",
            "message": "New Import Created via API",
        }
        mock_request.return_value = mock_import_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        upload = client.get_upload(
            branch_id=174,
            description="Test upload",
        )

        from titan_rdm_sdk import Upload

        assert isinstance(upload, Upload)
        assert upload.id == 456
        assert upload.status == "created"
