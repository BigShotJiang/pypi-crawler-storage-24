"""Tests for TableUpload class."""

from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from titan_rdm_sdk import TableUpload, TitanRDMClient, Upload
from titan_rdm_sdk.exceptions import APIError, UploadError, ValidationError


@pytest.fixture
def mock_client():
    """Create a mock TitanRDMClient."""
    client = MagicMock(spec=TitanRDMClient)
    client.url = "https://example.com"
    client.access_token = "test_token"
    return client


@pytest.fixture
def mock_upload(mock_client):
    """Create a mock Upload."""
    upload = MagicMock(spec=Upload)
    upload.id = 456
    upload.branch_id = 174
    return upload


class TestTableUploadInitialization:
    """Tests for TableUpload initialization."""

    def test_invalid_pattern_raises_validation_error(self, mock_client, mock_upload):
        """Test that invalid pattern raises ValidationError."""
        with pytest.raises(ValidationError, match="pattern must be one of"):
            TableUpload(
                client=mock_client,
                upload=mock_upload,
                table_definition_key=100,
                import_mapping_key=10,
                pattern="invalid",
            )

    def test_missing_table_definition_key_raises_error(self, mock_client, mock_upload):
        """Test that missing table_definition_key raises ValidationError."""
        with pytest.raises(ValidationError, match="table_definition_key is required"):
            TableUpload(
                client=mock_client,
                upload=mock_upload,
                table_definition_key=None,
                import_mapping_key=10,
            )

    def test_missing_import_mapping_key_raises_error(self, mock_client, mock_upload):
        """Test that missing import_mapping_key raises ValidationError."""
        with pytest.raises(ValidationError, match="import_mapping_key is required"):
            TableUpload(
                client=mock_client,
                upload=mock_upload,
                table_definition_key=100,
                import_mapping_key=None,
            )

    def test_successful_creation_with_full_pattern(self, mock_client, mock_upload):
        """Test successful table upload creation with full pattern."""
        mock_client._make_request.side_effect = [
            {"id": 108},  # Lookup
            {
                "id": 789,
                "status": "created",
                "signed_s3_url": "https://s3.example.com/upload",
                "s3_key": "tenant/123/file.csv",
            },
        ]

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
            pattern="full",
        )

        assert table_upload.id == 789
        assert table_upload.status == "created"
        assert table_upload.signed_s3_url == "https://s3.example.com/upload"

    def test_successful_creation_with_incremental_pattern(
        self, mock_client, mock_upload
    ):
        """Test successful table upload creation with incremental pattern."""
        mock_client._make_request.side_effect = [
            {"id": 108},
            {"id": 790, "status": "created"},
        ]

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
            pattern="incremental",
        )

        assert table_upload.pattern == "incremental"

    def test_successful_creation_with_incremental_with_delete(
        self, mock_client, mock_upload
    ):
        """Test successful table upload creation with incremental_with_delete."""
        mock_client._make_request.side_effect = [
            {"id": 108},
            {"id": 791, "status": "created"},
        ]

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
            pattern="incremental_with_delete",
        )

        assert table_upload.pattern == "incremental_with_delete"

    def test_lookup_deployed_table_definition(self, mock_client, mock_upload):
        """Test that deployed table definition lookup is made."""
        mock_client._make_request.side_effect = [
            {"id": 108, "deployed_table_definition_id": 108},
            {"id": 789, "status": "created"},
        ]

        TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
        )

        # First call should be lookup
        calls = mock_client._make_request.call_args_list
        assert calls[0] == (
            (),
            {
                "method": "GET",
                "endpoint": "/api/deployed_table_definitions/lookup",
                "params": {
                    "branch_id": 174,
                    "table_definition_key": 100,
                },
            },
        )


class TestSend:
    """Tests for send method."""

    @patch("titan_rdm_sdk.table_upload.requests.put")
    def test_send_uploads_dataframe(self, mock_put, mock_client, mock_upload):
        """Test that send uploads DataFrame to S3."""
        mock_client._make_request.side_effect = [
            {"id": 108},  # Lookup
            {
                "id": 789,
                "status": "created",
                "signed_s3_url": "https://s3.example.com/upload",
            },
            {"id": 789, "status": "uploaded"},  # Upload complete notification
        ]

        mock_put_response = MagicMock()
        mock_put_response.raise_for_status = MagicMock()
        mock_put.return_value = mock_put_response

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
        )

        df = pd.DataFrame({"id": [1, 2, 3], "name": ["A", "B", "C"]})
        result = table_upload.send(df)

        assert result is table_upload  # Returns self for chaining
        mock_put.assert_called_once()

        # Verify PUT request
        call_args = mock_put.call_args
        assert call_args[0][0] == "https://s3.example.com/upload"
        assert call_args[1]["headers"]["Content-Type"] == "text/csv"

    @patch("titan_rdm_sdk.table_upload.requests.put")
    def test_send_notifies_upload_complete(self, mock_put, mock_client, mock_upload):
        """Test that send notifies server of successful upload."""
        mock_client._make_request.side_effect = [
            {"id": 108},
            {"id": 789, "status": "created", "signed_s3_url": "https://s3.example.com"},
            {"id": 789, "status": "uploaded"},
        ]

        mock_put_response = MagicMock()
        mock_put_response.raise_for_status = MagicMock()
        mock_put.return_value = mock_put_response

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
        )

        df = pd.DataFrame({"id": [1]})
        table_upload.send(df)

        # Third call should be upload_complete
        calls = mock_client._make_request.call_args_list
        assert calls[2] == (
            (),
            {
                "method": "POST",
                "endpoint": "/api/import_tables/789/upload_complete",
            },
        )

    @patch("titan_rdm_sdk.table_upload.requests.put")
    def test_send_failure_raises_upload_error(self, mock_put, mock_client, mock_upload):
        """Test that S3 upload failure raises UploadError."""
        import requests

        mock_client._make_request.side_effect = [
            {"id": 108},  # Lookup
            {"id": 789, "status": "created", "signed_s3_url": "https://s3.example.com"},
            None,  # upload_failed notification (should not raise if it fails)
        ]

        mock_put.side_effect = requests.RequestException("Connection failed")

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
        )

        df = pd.DataFrame({"id": [1]})

        with pytest.raises(UploadError, match="S3 upload failed"):
            table_upload.send(df)

    @patch("titan_rdm_sdk.table_upload.requests.put")
    def test_send_notifies_upload_failed_on_error(
        self, mock_put, mock_client, mock_upload
    ):
        """Test that send notifies server of upload failure."""
        import requests

        mock_client._make_request.side_effect = [
            {"id": 108},
            {"id": 789, "status": "created", "signed_s3_url": "https://s3.example.com"},
            None,  # upload_failed notification
        ]

        mock_put.side_effect = requests.RequestException("Connection failed")

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
        )

        df = pd.DataFrame({"id": [1]})

        with pytest.raises(UploadError):
            table_upload.send(df)

        # Should have called upload_failed
        calls = mock_client._make_request.call_args_list
        assert calls[2][1]["endpoint"] == "/api/import_tables/789/upload_failed"

    def test_send_without_signed_url_raises_error(self, mock_client, mock_upload):
        """Test that send raises UploadError if no signed URL."""
        mock_client._make_request.side_effect = [
            {"id": 108},
            {"id": 789, "status": "created", "signed_s3_url": None},
        ]

        table_upload = TableUpload(
            client=mock_client,
            upload=mock_upload,
            table_definition_key=100,
            import_mapping_key=10,
        )

        df = pd.DataFrame({"id": [1]})

        with pytest.raises(UploadError, match="Signed S3 URL is not available"):
            table_upload.send(df)
