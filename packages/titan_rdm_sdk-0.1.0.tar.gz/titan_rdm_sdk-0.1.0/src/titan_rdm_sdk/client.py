"""Main client for TitanRDM API interactions."""

from __future__ import annotations

import threading
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any

import requests

from titan_rdm_sdk.exceptions import (
    APIError,
    AuthenticationError,
    ValidationError,
)
from titan_rdm_sdk.utils import extract_error_message

if TYPE_CHECKING:
    from titan_rdm_sdk.download import Download
    from titan_rdm_sdk.upload import Upload


class TitanRDMClient:
    """
    Client for interacting with TitanRDM Import and Export APIs.

    The main entry point for the SDK. Handles authentication and creates
    Download/Upload instances.
    """

    def __init__(self, url: str, client_id: str, client_secret: str) -> None:
        """
        Initialize the TitanRDM client and authenticate.

        Args:
            url: Base URL of the TitanRDM instance (without trailing slash).
            client_id: OAuth client ID.
            client_secret: OAuth client secret.

        Raises:
            AuthenticationError: If authentication fails.
            ValidationError: If required parameters are missing.
        """
        # Validate inputs
        if not url or not isinstance(url, str):
            raise ValidationError("url is required and must be a non-empty string")
        if not client_id or not isinstance(client_id, str):
            raise ValidationError(
                "client_id is required and must be a non-empty string"
            )
        if not client_secret or not isinstance(client_secret, str):
            raise ValidationError(
                "client_secret is required and must be a non-empty string"
            )

        self.url = url.rstrip("/")
        self.client_id = client_id
        self.client_secret = client_secret
        self.access_token: str | None = None
        self.token_expires_at: datetime | None = None
        self._token_lock = threading.Lock()

        # Authenticate on init
        self._authenticate()

    def _authenticate(self) -> str:
        """
        Authenticate with TitanRDM using OAuth 2.0 Client Credentials.

        Returns:
            The access token.

        Raises:
            AuthenticationError: If authentication fails.
        """
        token_url = f"{self.url}/oauth/token"

        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            response = requests.post(token_url, data=data, headers=headers, timeout=30)
        except requests.RequestException as e:
            raise AuthenticationError(f"Failed to connect to authentication server: {e}") from e

        if response.status_code != 200:
            try:
                error_data = response.json()
                error_msg = extract_error_message(error_data)
            except Exception:
                error_msg = response.text or f"HTTP {response.status_code}"
            raise AuthenticationError(f"Authentication failed: {error_msg}")

        try:
            token_data = response.json()
        except Exception as e:
            raise AuthenticationError(f"Invalid token response: {e}") from e

        self.access_token = token_data["access_token"]

        # Calculate token expiration
        expires_in = token_data.get("expires_in", 7200)
        created_at = token_data.get("created_at")

        if created_at:
            self.token_expires_at = datetime.fromtimestamp(
                created_at + expires_in, tz=timezone.utc
            )
        else:
            self.token_expires_at = datetime.now(timezone.utc) + timedelta(
                seconds=expires_in
            )

        return self.access_token

    def _get_headers(self) -> dict[str, str]:
        """
        Get HTTP headers for authenticated API requests.

        Returns:
            Headers including Authorization and Content-Type.
        """
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _token_is_valid(self) -> bool:
        """
        Check if the current token is still valid.

        Returns:
            True if token exists and is not expiring within 5 minutes.
        """
        if not self.access_token or not self.token_expires_at:
            return False

        # Consider token invalid if it expires within 5 minutes
        buffer = timedelta(minutes=5)
        return datetime.now(timezone.utc) < (self.token_expires_at - buffer)

    def _refresh_token_if_needed(self) -> None:
        """
        Check if token is expired or about to expire, and refresh if needed.

        Refresh if token expires within 5 minutes. Uses double-checked locking
        for thread safety.
        """
        if self._token_is_valid():
            return

        with self._token_lock:
            # Double-check inside lock (another thread may have refreshed)
            if self._token_is_valid():
                return
            self._authenticate()

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Make an authenticated API request.

        Args:
            method: HTTP method (GET, POST, etc.).
            endpoint: API endpoint (without base URL).
            json: JSON body for the request.
            params: Query parameters.

        Returns:
            JSON response as a dictionary.

        Raises:
            APIError: If the request fails.
        """
        self._refresh_token_if_needed()

        url = f"{self.url}{endpoint}"
        headers = self._get_headers()

        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=json,
                params=params,
                timeout=30,
            )
        except requests.RequestException as e:
            raise APIError(f"Request failed: {e}") from e

        if response.status_code in (200, 201):
            try:
                return response.json()
            except Exception as e:
                raise APIError(f"Invalid JSON response: {e}") from e

        # Handle error response
        try:
            error_data = response.json()
            error_msg = extract_error_message(error_data)
        except Exception:
            # Truncate HTML/long responses to avoid flooding console
            text = response.text or ""
            if len(text) > 500:
                text = text[:500] + "... [truncated]"
            error_msg = text or f"HTTP {response.status_code}"

        raise APIError(
            message=error_msg,
            status_code=response.status_code,
            response=error_data if "error_data" in dir() else None,
        )

    def get_download(
        self,
        branch_id: int,
        table_definition_key: int,
        pattern: str = "full",
        correlation_code: str | None = None,
        high_water_mark: str | None = None,
    ) -> Download:
        """
        Create a new Download (export) operation.

        Args:
            branch_id: Target branch ID (required).
            table_definition_key: Table definition key (required).
            pattern: Export pattern - 'full' or 'incremental' (default: 'full').
            correlation_code: User-defined tracking identifier (optional).
            high_water_mark: ISO 8601 timestamp for incremental exports
                (required if pattern='incremental').

        Returns:
            A new Download instance with export initiated.

        Raises:
            ValidationError: If required parameters are missing or invalid.
            APIError: If the API request fails.
        """
        from titan_rdm_sdk.download import Download

        return Download(
            client=self,
            branch_id=branch_id,
            table_definition_key=table_definition_key,
            pattern=pattern,
            correlation_code=correlation_code,
            high_water_mark=high_water_mark,
        )

    def get_upload(
        self,
        branch_id: int,
        description: str | None = None,
        correlation_code: str | None = None,
    ) -> Upload:
        """
        Create a new Upload (import) operation.

        Args:
            branch_id: Target branch ID (required).
            description: Description of the import (optional).
            correlation_code: User-defined tracking identifier (optional).

        Returns:
            A new Upload instance.

        Raises:
            ValidationError: If required parameters are missing.
            APIError: If the API request fails.
        """
        from titan_rdm_sdk.upload import Upload

        return Upload(
            client=self,
            branch_id=branch_id,
            description=description,
            correlation_code=correlation_code,
        )
