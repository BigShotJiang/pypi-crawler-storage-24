"""TableUpload class for TitanRDM table import operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pandas as pd
import requests

from titan_rdm_sdk.exceptions import APIError, UploadError, ValidationError
from titan_rdm_sdk.utils import dataframe_to_csv

if TYPE_CHECKING:
    from titan_rdm_sdk.client import TitanRDMClient
    from titan_rdm_sdk.upload import Upload


class TableUpload:
    """
    Represents a single table upload within an import operation.

    Handles uploading data to a specific table via presigned S3 URLs.
    """

    VALID_PATTERNS = ("full", "incremental", "incremental_with_delete")

    def __init__(
        self,
        client: TitanRDMClient,
        upload: Upload,
        table_definition_key: int,
        import_mapping_key: int,
        pattern: str = "full",
        correlation_code: str | None = None,
    ) -> None:
        """
        Create a new table upload within an import.

        Args:
            client: TitanRDMClient instance for API calls.
            upload: Parent Upload instance.
            table_definition_key: Target table definition key.
            import_mapping_key: Import mapping key defining column mappings.
            pattern: Import pattern ('full', 'incremental', 'incremental_with_delete').
            correlation_code: User-defined tracking identifier.

        Raises:
            ValidationError: If required parameters are missing or invalid.
            APIError: If the table upload creation fails.
        """
        # Validate pattern
        if pattern not in self.VALID_PATTERNS:
            raise ValidationError(
                f"pattern must be one of: {', '.join(self.VALID_PATTERNS)}"
            )

        if table_definition_key is None:
            raise ValidationError("table_definition_key is required")

        if import_mapping_key is None:
            raise ValidationError("import_mapping_key is required")

        self._client = client
        self._upload = upload
        self.table_definition_key = table_definition_key
        self.import_mapping_key = import_mapping_key
        self.pattern = pattern
        self.correlation_code = correlation_code

        # Attributes populated from API response
        self.id: int | None = None
        self.status: str | None = None
        self.message: str | None = None
        self.signed_s3_url: str | None = None
        self.s3_key: str | None = None
        self.created_at: str | None = None
        self.file_size: int | None = None
        self.insert_row_count: int | None = None
        self.update_row_count: int | None = None
        self.delete_row_count: int | None = None
        self.duration_secs: int | None = None
        self.start_datetime: str | None = None
        self.end_datetime: str | None = None

        # Lookup deployed table definition first
        self._lookup_deployed_table_definition()
        
        # Create the table upload
        self._create_table_upload()

    def _lookup_deployed_table_definition(self) -> None:
        """Lookup the deployed table definition."""
        response = self._client._make_request(
            method="GET",
            endpoint="/api/deployed_table_definitions/lookup",
            params={
                "branch_id": self._upload.branch_id,
                "table_definition_key": self.table_definition_key,
            },
        )
        # Store the deployed table definition ID if needed
        self.deployed_table_definition_id = response.get("deployed_table_definition_id")

    def _create_table_upload(self) -> None:
        """Create the table upload via the API."""
        payload: dict[str, Any] = {
            "import_id": self._upload.id,
            "table_definition_key": self.table_definition_key,
            "import_mapping_key": self.import_mapping_key,
            "pattern": self.pattern,
        }

        if self.correlation_code:
            payload["correlation_code"] = self.correlation_code

        response = self._client._make_request(
            method="POST",
            endpoint="/api/import_tables/new",
            json=payload,
        )

        self._update_from_response(response)

    def _update_from_response(self, data: dict[str, Any]) -> None:
        """Update attributes from API response."""
        self.id = data.get("id")
        self.status = data.get("status")
        self.message = data.get("message")
        self.signed_s3_url = data.get("signed_s3_url")
        self.s3_key = data.get("s3_key")
        self.created_at = data.get("created_date") or data.get("created_at")
        self.file_size = data.get("file_size")
        self.insert_row_count = data.get("insert_row_count")
        self.update_row_count = data.get("update_row_count")
        self.delete_row_count = data.get("delete_row_count")
        self.duration_secs = data.get("duration_secs")
        self.start_datetime = data.get("start_datetime")
        self.end_datetime = data.get("end_datetime")

        if data.get("correlation_code"):
            self.correlation_code = data["correlation_code"]

    def send(self, df: pd.DataFrame) -> TableUpload:
        """
        Upload a pandas DataFrame to TitanRDM.

        The DataFrame is converted to CSV and uploaded to S3 using the presigned URL.

        Args:
            df: pandas DataFrame containing the data to upload.

        Returns:
            self (for method chaining).

        Raises:
            UploadError: If the S3 upload fails.
            APIError: If notifying the server fails.
        """
        if not self.signed_s3_url:
            raise UploadError("Signed S3 URL is not available")

        # Convert DataFrame to CSV
        csv_data = dataframe_to_csv(df)

        # Upload to S3
        try:
            response = requests.put(
                self.signed_s3_url,
                data=csv_data,
                headers={"Content-Type": "text/csv"},
                timeout=300,
            )
            response.raise_for_status()
        except requests.RequestException as e:
            # Notify server of failure
            self._notify_upload_failed(str(e))
            raise UploadError(f"S3 upload failed: {e}") from e

        # Notify server of success
        self._notify_upload_complete()

        return self

    def _notify_upload_complete(self) -> None:
        """Notify the server that the upload completed successfully."""
        response = self._client._make_request(
            method="POST",
            endpoint=f"/api/import_tables/{self.id}/upload_complete",
        )
        self._update_from_response(response)

    def _notify_upload_failed(self, error_message: str) -> None:
        """
        Notify the server that the upload failed.

        Args:
            error_message: Description of the failure.
        """
        try:
            self._client._make_request(
                method="POST",
                endpoint=f"/api/import_tables/{self.id}/upload_failed",
                json={"message": error_message},
            )
        except APIError:
            # Don't raise if notification fails - the main error is more important
            pass
