from datasette import hookimpl
from datasette.plugins import pm
import markupsafe

hookspec_marker = pm.get_canonical_name


class DebugBarSpec:
    """Hook specification for datasette-debug-bar plugins."""

    pass


try:
    pm.parse_hookimpl_opts
except AttributeError:
    pass


def get_debug_bar_items(datasette):
    """Call all plugins that implement the debug_bar_items hook."""
    items = []
    for plugin in pm.get_plugins():
        if hasattr(plugin, "debug_bar_items"):
            result = plugin.debug_bar_items(datasette)
            if result:
                if isinstance(result, list):
                    items.extend(result)
                else:
                    items.append(result)
    return items


@hookimpl
def extra_body_script(template, database, table, columns, view_name, request, datasette):
    items = get_debug_bar_items(datasette)
    if not items:
        return ""

    items_js = []
    for item in items:
        label = item.get("label", "Debug")
        # The entrypoint is a JS function body string that receives an element
        entrypoint = item.get("entrypoint", "")
        items_js.append(
            '{label: %s, entrypoint: %s}'
            % (markupsafe.Markup(repr(label)), markupsafe.Markup(entrypoint))
        )

    items_array = ", ".join(items_js)

    return markupsafe.Markup(
        """
(function() {
    const items = [ITEMS_PLACEHOLDER];
    if (!items.length) return;

    const STORAGE_KEY = 'datasette-debug-bar';
    let state = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    // state.expanded: bool (whole bar), state.sections: {label: bool}
    if (state.expanded === undefined) state.expanded = true;
    if (!state.sections) state.sections = {};

    function saveState() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }

    const bar = document.createElement('div');
    bar.id = 'datasette-debug-bar';
    bar.style.cssText = `
        position: fixed;
        bottom: 0;
        right: 0;
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 13px;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        pointer-events: none;
    `;

    function render() {
        bar.innerHTML = '';

        if (state.expanded) {
            // Sections panel
            const panel = document.createElement('div');
            panel.style.cssText = `
                pointer-events: auto;
                background: #fff;
                border: 1px solid #bbb;
                border-bottom: none;
                border-radius: 8px 0 0 0;
                box-shadow: 0 -2px 12px rgba(0,0,0,0.1);
                min-width: 240px;
                max-height: 70vh;
                overflow-y: auto;
            `;

            items.forEach(function(item, i) {
                const sectionOpen = state.sections[item.label] !== false;

                const section = document.createElement('div');
                if (i > 0) {
                    section.style.borderTop = '1px solid #ddd';
                }

                // Collapsible header
                const header = document.createElement('div');
                header.style.cssText = `
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 6px 12px;
                    cursor: pointer;
                    user-select: none;
                    background: ${sectionOpen ? '#f5f5f5' : '#fafafa'};
                `;
                header.addEventListener('click', function() {
                    state.sections[item.label] = !sectionOpen;
                    saveState();
                    render();
                });

                const label = document.createElement('span');
                label.textContent = item.label;
                label.style.cssText = `
                    font-weight: 600;
                    font-size: 11px;
                    text-transform: uppercase;
                    color: #444;
                    letter-spacing: 0.5px;
                `;
                header.appendChild(label);

                const arrow = document.createElement('span');
                arrow.textContent = sectionOpen ? '\\u25BC' : '\\u25B6';
                arrow.style.cssText = 'font-size: 9px; color: #888;';
                header.appendChild(arrow);

                section.appendChild(header);

                if (sectionOpen) {
                    const content = document.createElement('div');
                    content.style.cssText = 'padding: 8px 12px;';
                    item.entrypoint(content);
                    section.appendChild(content);
                }

                panel.appendChild(section);
            });

            bar.appendChild(panel);
        }

        // Bottom handle bar (always visible)
        const handle = document.createElement('div');
        handle.style.cssText = `
            pointer-events: auto;
            background: linear-gradient(to bottom, #e8e8e8, #d0d0d0);
            border: 1px solid #bbb;
            border-radius: ${state.expanded ? '0' : '6px 0 0 0'};
            padding: 2px 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 8px;
            min-width: 80px;
            user-select: none;
        `;

        const text = document.createElement('span');
        text.textContent = 'Debug';
        text.style.cssText = `
            font-size: 11px;
            font-weight: 600;
            color: #555;
        `;
        handle.appendChild(text);

        // Minimize/maximize icon
        const icon = document.createElement('span');
        // Expanded: minimize (line), collapsed: maximize (expand square)
        icon.innerHTML = state.expanded
            ? '<svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 6h8" stroke="#555" stroke-width="1.5" stroke-linecap="round"/></svg>'
            : '<svg width="12" height="12" viewBox="0 0 12 12"><rect x="1.5" y="1.5" width="9" height="9" rx="1" fill="none" stroke="#555" stroke-width="1.5"/></svg>';
        icon.style.cssText = 'display: flex; align-items: center;';
        handle.appendChild(icon);

        handle.addEventListener('click', function() {
            state.expanded = !state.expanded;
            saveState();
            render();
        });

        bar.appendChild(handle);
    }

    render();
    document.body.appendChild(bar);
})();
""".replace("ITEMS_PLACEHOLDER", items_array)
    )
