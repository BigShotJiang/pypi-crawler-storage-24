from datasette.app import Datasette
import pytest
import textwrap


@pytest.mark.asyncio
async def test_plugin_is_installed():
    datasette = Datasette(memory=True)
    response = await datasette.client.get("/-/plugins.json")
    assert response.status_code == 200
    installed_plugins = {p["name"] for p in response.json()}
    assert "datasette-debug-bar" in installed_plugins


@pytest.mark.asyncio
async def test_no_bar_without_items():
    """Without any plugins providing debug_bar_items, no bar should be injected."""
    datasette = Datasette(memory=True)
    response = await datasette.client.get("/")
    assert response.status_code == 200
    assert "datasette-debug-bar" not in response.text


@pytest.mark.asyncio
async def test_bar_with_plugins_dir():
    """With sample plugins loaded via plugins_dir, the bar should appear."""
    datasette = Datasette(memory=True, plugins_dir="sample")
    response = await datasette.client.get("/")
    assert response.status_code == 200
    html = response.text
    assert "datasette-debug-bar" in html
    assert "Request Info" in html
    assert "Performance" in html


@pytest.mark.asyncio
async def test_bar_contains_both_sections():
    """Each sample plugin should create its own labeled section."""
    datasette = Datasette(memory=True, plugins_dir="sample")
    response = await datasette.client.get("/")
    html = response.text
    # Both entrypoints should be present as JS functions
    assert "location.pathname" in html  # from debug_request_info
    assert "getEntriesByType" in html  # from debug_performance
