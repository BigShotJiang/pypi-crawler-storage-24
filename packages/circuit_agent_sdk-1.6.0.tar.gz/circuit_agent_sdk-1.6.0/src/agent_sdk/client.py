"""
Low-level HTTP client used internally by the SDK.

This module provides the APIClient class that handles all HTTP communication
with the Circuit backend, including authentication, request/response logging,
and error handling.
"""

import json
import os
import uuid
from pathlib import Path
from typing import Any, TypeVar

import requests
from pydantic import BaseModel

from .types.config import (
    API_BASE_URL_DEPLOYED,
    API_BASE_URL_DEV_LOCAL,
    API_BASE_URL_LOCAL,
    API_BASE_URL_STAGING,
    SDKConfig,
)

T = TypeVar("T", bound=BaseModel)


class APIError(Exception):
    """
    Custom exception for API errors that includes structured error details.

    Attributes:
        message: Detailed error message from API (or None if not provided)
        error: Short error category/title from API (or None if not provided)
        status_code: HTTP status code (if available)
    """

    def __init__(
        self,
        message: str | None = None,
        error: str | None = None,
        status_code: int | None = None,
    ):
        # Use message if available, otherwise error, otherwise generic message
        display_message = message or error or "API request failed"
        super().__init__(display_message)
        self.message = message
        self.error = error
        self.status_code = status_code

    def __str__(self) -> str:
        """Returns the most detailed error information available."""
        result = self.message or self.error or "API request failed"
        return str(result)


class APIClient:
    """
    Low-level HTTP client used internally by the SDK.

    - Automatically detects Lambda environment and uses VPC proxy
    - Falls back to HTTP requests for local development with session token auth
    - Adds session ID and agent slug headers automatically

    Authentication:
    - Lambda environments: No additional auth needed (VPC proxy handles it)
    - Local development: Session token from CLI auth config if available
    - Always includes session ID and agent slug headers for validation

    Although this class can be used directly, most users should interact with
    higher-level abstractions like AgentSdk and AgentUtils.

    Example:
        ```python
        from agent_sdk import SDKConfig
        from agent_sdk.client import APIClient

        config = SDKConfig(session_id=123)
        client = APIClient(config)

        # Make authenticated requests
        response = client.post("/v1/logs", [{"type": "observe", "message": "test"}])
        ```
    """

    def __init__(self, config: SDKConfig) -> None:
        """
        Create an API client.

        Args:
            config: SDK configuration containing session ID, base URL, and other settings
        """
        self.config = config
        self.base_url = config.base_url or self._get_default_base_url()

    def _is_deployed(self) -> bool:
        """Check if running in a Circuit-hosted (VPC) environment."""
        # Primary: Check for CIRCUIT_DEPLOYED (set by upload service)
        if os.environ.get("CIRCUIT_DEPLOYED") == "true":
            return True
        # Fallback: Check for Lambda-specific environment variables
        return (
            os.environ.get("AWS_LAMBDA_FUNCTION_NAME") is not None
            or os.environ.get("LAMBDA_TASK_ROOT") is not None
            or os.environ.get("AWS_EXECUTION_ENV") is not None
        )

    def _is_staging(self) -> bool:
        """Check if CIRCUIT_BACKEND is set to staging."""
        return os.environ.get("CIRCUIT_BACKEND") == "staging"

    def _is_local_backend(self) -> bool:
        """Check if CIRCUIT_BACKEND is set to local."""
        return os.environ.get("CIRCUIT_BACKEND") == "local"

    def _get_default_base_url(self) -> str:
        """Get default base URL based on environment."""
        # Priority: CIRCUIT_DEPLOYED > CIRCUIT_BACKEND=local > CIRCUIT_BACKEND=staging > Public
        if self._is_deployed():
            # Use internal VPC URL for Circuit-hosted agents
            return API_BASE_URL_DEPLOYED
        elif self._is_local_backend():
            # Use local API URL (set by CLI --stage local)
            return API_BASE_URL_DEV_LOCAL
        elif self._is_staging():
            # Use staging API URL (set by CLI --stage staging)
            return API_BASE_URL_STAGING
        else:
            # Default to public API URL
            return API_BASE_URL_LOCAL

    def _get_auth_headers(self) -> dict[str, str]:
        """
        Generate authentication headers for requests.

        Authentication priority:
        1. Circuit environment: No Authorization header (VPC proxy handles auth)
        2. Authorization header from request: Use if provided
        3. Filesystem lookup: Fall back to local auth config

        Returns:
            Dictionary of headers to include in requests
        """
        headers: dict[str, str] = {}

        # Always include session ID header
        if self.config.session_id:
            headers["X-Session-Id"] = str(self.config.session_id)

        # Include agent slug if available (for deployed agents)
        agent_slug = self._get_agent_slug()
        if agent_slug:
            headers["X-Agent-Slug"] = agent_slug

        # For deployed environments, we don't need additional auth
        # as the VPC proxy handles authentication
        if self._is_deployed():
            return headers

        # Use Authorization header from incoming request if provided
        if self.config.authorization_header:
            headers["Authorization"] = self.config.authorization_header
            return headers

        # Fall back to local development session token
        try:
            auth_config = self._load_auth_config()
            if auth_config and auth_config.get("sessionToken"):
                headers["Authorization"] = f"Bearer {auth_config['sessionToken']}"
        except Exception:
            # Auth config not available, continue without auth
            pass

        # Add X-API-Key header if CIRCUIT_DEV_API_KEY is set (for local development)
        dev_api_key = os.environ.get("CIRCUIT_DEV_API_KEY")
        if dev_api_key:
            headers["X-API-Key"] = dev_api_key

        return headers

    def _get_agent_slug(self) -> str | None:
        """Get agent slug from environment variables."""
        # Check for agent slug in environment variables
        return os.environ.get("CIRCUIT_AGENT_SLUG")

    def _load_auth_config(self) -> dict[str, Any] | None:
        """
        Try to load auth config from the same location the CLI uses.

        Returns:
            Auth configuration dictionary or None if not available
        """
        # Try main config directory first
        try:
            home = Path.home()
            auth_path = home / ".config" / "circuit" / "auth.json"

            if auth_path.exists():
                with open(auth_path, encoding="utf-8") as f:
                    main_data: dict[str, Any] = json.load(f)
                    return main_data
        except Exception:
            # Auth config not available in main directory
            pass

        # Try fallback directory
        try:
            home = Path.home()
            auth_path = home / ".circuit" / "auth.json"

            if auth_path.exists():
                with open(auth_path, encoding="utf-8") as f:
                    fallback_data: dict[str, Any] = json.load(f)
                    return fallback_data
        except Exception:
            # Auth config not available in fallback directory
            pass

        return None

    def _make_request(
        self, method: str, endpoint: str, data: Any = None
    ) -> dict[str, Any] | list[Any]:
        """
        Perform a JSON HTTP request.

        Automatically attaches auth headers.
        Raises helpful errors when the HTTP response is not ok.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API path beginning with /v1/...
            data: Optional JSON payload to serialize

        Returns:
            Parsed JSON response

        Raises:
            requests.RequestException: When response.ok is False or other HTTP errors
        """
        url = f"{self.base_url}{endpoint}"

        auth_headers = self._get_auth_headers()
        default_headers = {
            "Content-Type": "application/json",
            "x-circuit-request-id": str(uuid.uuid4()),
            **auth_headers,
        }

        # Prepare request data
        json_data = None
        if data is not None:
            if isinstance(data, BaseModel):
                # Use mode='json' for proper JSON serialization with by_alias for field name mapping
                # Use exclude_unset=True to omit fields never set (for .optional() in schemas)
                # Keep fields explicitly set to None for .nullable() fields that require null
                json_data = data.model_dump(
                    mode="json", by_alias=True, exclude_unset=True
                )
            else:
                json_data = data

        try:
            response = requests.request(
                method=method,
                url=url,
                headers=default_headers,
                json=json_data,
                timeout=900,
            )

            if not response.ok:
                try:
                    error_data = response.json()
                except Exception:
                    error_data = {}

                error_string = error_data.get("error", "Unknown error")

                raise APIError(
                    message=error_string,
                    error=error_string,
                    status_code=response.status_code,
                )

            response_data: dict[str, Any] | list[Any] = response.json()
            return response_data

        except APIError:
            # Re-raise our custom API errors as-is
            raise
        except requests.RequestException as e:
            # Wrap other request exceptions (network errors, timeouts, etc.)
            raise APIError(
                message=str(e),
                error="Request failed",
            ) from e

    def get(self, endpoint: str) -> dict[str, Any] | list[Any]:
        """
        HTTP GET convenience method.

        Args:
            endpoint: API path beginning with /v1/...

        Returns:
            Parsed JSON response
        """
        return self._make_request("GET", endpoint)

    def post(self, endpoint: str, data: Any = None) -> dict[str, Any] | list[Any]:
        """
        HTTP POST convenience method sending a JSON body.

        Args:
            endpoint: API path beginning with /v1/...
            data: Optional JSON payload to serialize

        Returns:
            Parsed JSON response
        """
        return self._make_request("POST", endpoint, data)

    def delete(self, endpoint: str) -> dict[str, Any] | list[Any]:
        """
        HTTP DELETE convenience method.

        Args:
            endpoint: API path beginning with /v1/...

        Returns:
            Parsed JSON response
        """
        return self._make_request("DELETE", endpoint)
