"""LSMC Atlas - Clinical Sequencing Customer Portal."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("lsmc-atlas")
except PackageNotFoundError:
    __version__ = "0+unknown"
