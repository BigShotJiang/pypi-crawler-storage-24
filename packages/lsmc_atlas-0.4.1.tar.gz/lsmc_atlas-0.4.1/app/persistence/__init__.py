"""Persistence abstractions for Atlas."""
