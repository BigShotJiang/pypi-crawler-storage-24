"""TapDB-backed repository adapter for Atlas logistics domain."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

SHIPMENT_TEMPLATE_CODE = "atlas/logistics/shipment/1.0/"
SHIPMENT_REV_TEMPLATE_CODE = "atlas/logistics/shipment-revision/1.0/"
TEST_KIT_TEMPLATE_CODE = "atlas/logistics/test-kit/1.0/"
TEST_KIT_REV_TEMPLATE_CODE = "atlas/logistics/test-kit-revision/1.0/"

SHIPMENT_PREFIX = "SHP"
SHIPMENT_REV_PREFIX = "SHR"
TEST_KIT_PREFIX = "TKT"
TEST_KIT_REV_PREFIX = "TKR"

# Shipment/TestKit physical containment is represented as TapDB lineage edges:
# child=<contained item> -> parent=<container>, relationship_type="contained_in".
CONTAINMENT_RELATIONSHIP_TYPE = "contained_in"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbShipmentRecord:
    euid: str
    tenant_id: uuid.UUID
    shipment_number: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbShipmentRevisionRecord:
    euid: str
    shipment_id: str
    revision_no: int
    status: str
    carrier: str | None
    tracking_number: str | None
    origin_site_id: str | None
    origin_address: dict | None
    destination_address: dict | None
    shipped_at: datetime | None
    delivered_at: datetime | None
    received_at: datetime | None
    temperature_requirement: str | None
    special_instructions: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


@dataclass
class TapdbTestKitRecord:
    euid: str
    tenant_id: uuid.UUID
    kit_barcode: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbTestKitRevisionRecord:
    euid: str
    test_kit_id: str
    revision_no: int
    kit_type: str | None
    status: str
    origin_site_id: str | None
    expiration_date: datetime | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


class TapdbLogisticsRepository:
    """Shipment/TestKit persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def generate_next_shipment_number(self) -> str:
        max_num = 0
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            match = re.fullmatch(r"SHP-(\d+)", shipment.shipment_number or "")
            if not match:
                continue
            max_num = max(max_num, int(match.group(1)))
        return f"SHP-{max_num + 1}"

    def create_shipment(
        self,
        *,
        tenant_id: uuid.UUID,
        shipment_number: str,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)

        shipment_instance = self.factory.create_instance(
            session=self.db,
            template_code=SHIPMENT_TEMPLATE_CODE,
            name=shipment_number,
            properties={
                "tenant_id": str(tenant_id),
                "shipment_number": shipment_number,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        shipment_euid = shipment_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=SHIPMENT_REV_TEMPLATE_CODE,
            name=f"{shipment_number}-rev-1",
            properties={
                "shipment_id": shipment_euid,
                "revision_no": 1,
                "status": "DRAFT",
                "carrier": getattr(data, "carrier", None),
                "tracking_number": getattr(data, "tracking_number", None),
                "origin_site_id": getattr(data, "origin_site_id", None),
                "origin_address": getattr(data, "origin_address", None),
                "destination_address": getattr(data, "destination_address", None),
                "shipped_at": None,
                "delivered_at": None,
                "received_at": None,
                "temperature_requirement": getattr(data, "temperature_requirement", None),
                "special_instructions": getattr(data, "special_instructions", None),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=shipment_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_shipment(shipment_instance), self._to_shipment_revision(revision_instance)

    def create_shipment_revision(
        self,
        *,
        shipment_id: str,
        status: str,
        carrier: str | None,
        tracking_number: str | None,
        origin_site_id: str | None,
        origin_address: dict | None,
        destination_address: dict | None,
        shipped_at: datetime | None,
        delivered_at: datetime | None,
        received_at: datetime | None,
        temperature_requirement: str | None,
        special_instructions: str | None,
        note: str | None,
        created_by: uuid.UUID | None,
    ) -> TapdbShipmentRevisionRecord | None:
        shipment = self.get_shipment_by_id(shipment_id=shipment_id, tenant_id=None)
        if shipment is None:
            return None
        latest = self.get_latest_shipment_revision(shipment_id)
        if latest is None:
            return None
        shipment_instance = self._resolve_shipment_instance(shipment_id)
        if shipment_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=SHIPMENT_REV_TEMPLATE_CODE,
            name=f"{shipment.shipment_number}-rev-{latest.revision_no + 1}",
            properties={
                "shipment_id": shipment_id,
                "revision_no": latest.revision_no + 1,
                "status": status,
                "carrier": carrier,
                "tracking_number": tracking_number,
                "origin_site_id": origin_site_id,
                "origin_address": origin_address,
                "destination_address": destination_address,
                "shipped_at": shipped_at.isoformat() if shipped_at else None,
                "delivered_at": delivered_at.isoformat() if delivered_at else None,
                "received_at": received_at.isoformat() if received_at else None,
                "temperature_requirement": temperature_requirement,
                "special_instructions": special_instructions,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=shipment_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_shipment_revision(revision_instance)

    def get_shipment_by_id(
        self,
        *,
        shipment_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbShipmentRecord | None:
        instance = self._resolve_shipment_instance(shipment_id)
        if instance is None or instance.is_deleted:
            return None
        shipment = self._to_shipment(instance)
        if tenant_id is not None and shipment.tenant_id != tenant_id:
            return None
        return shipment

    def get_shipment_by_number(
        self,
        *,
        shipment_number: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord] | None:
        normalized = (shipment_number or "").strip()
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            if shipment.shipment_number != normalized:
                continue
            if tenant_id is not None and shipment.tenant_id != tenant_id:
                continue
            revision = self.get_latest_shipment_revision(shipment.euid)
            if revision is None:
                return None
            return shipment, revision
        return None

    def get_shipment_by_tracking_number(
        self,
        *,
        tracking_number: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbShipmentRecord | None:
        normalized = (tracking_number or "").strip()
        if not normalized:
            return None
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            if tenant_id is not None and shipment.tenant_id != tenant_id:
                continue
            revision = self.get_latest_shipment_revision(shipment.euid)
            if revision is None:
                continue
            if (revision.tracking_number or "") == normalized:
                return shipment
        return None

    def list_shipments(
        self,
        *,
        tenant_id: uuid.UUID | None,
        skip: int,
        limit: int,
    ) -> list[tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord | None]]:
        rows: list[tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord | None]] = []
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            if tenant_id is not None and shipment.tenant_id != tenant_id:
                continue
            rows.append((shipment, self.get_latest_shipment_revision(shipment.euid)))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def get_latest_shipment_revision(
        self,
        shipment_id: str,
    ) -> TapdbShipmentRevisionRecord | None:
        shipment_instance = self._resolve_shipment_instance(shipment_id)
        if shipment_instance is None:
            return None
        children = get_child_instances(self.db, shipment_instance, SHIPMENT_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_shipment_revision(c) for c in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    def create_test_kit(
        self,
        *,
        tenant_id: uuid.UUID,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> TapdbTestKitRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        kit_barcode = str(getattr(data, "kit_barcode", "") or "").strip()

        test_kit_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_KIT_TEMPLATE_CODE,
            name=kit_barcode,
            properties={
                "tenant_id": str(tenant_id),
                "kit_barcode": kit_barcode,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        test_kit_euid = test_kit_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_KIT_REV_TEMPLATE_CODE,
            name=f"{kit_barcode}-rev-1",
            properties={
                "test_kit_id": test_kit_euid,
                "revision_no": 1,
                "kit_type": getattr(data, "kit_type", None),
                "status": "CREATED",
                "origin_site_id": getattr(data, "origin_site_id", None),
                "expiration_date": (
                    data.expiration_date.isoformat()
                    if getattr(data, "expiration_date", None)
                    else None
                ),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_kit_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_test_kit(test_kit_instance)

    def create_test_kit_revision(
        self,
        *,
        test_kit_id: str,
        kit_type: str | None,
        status: str,
        origin_site_id: str | None,
        expiration_date: datetime | None,
        note: str | None,
        created_by: uuid.UUID | None,
    ) -> TapdbTestKitRevisionRecord | None:
        test_kit = self.get_test_kit_by_id(test_kit_id=test_kit_id, tenant_id=None)
        if test_kit is None:
            return None
        latest = self.get_latest_test_kit_revision(test_kit_id)
        if latest is None:
            return None
        test_kit_instance = self._resolve_test_kit_instance(test_kit_id)
        if test_kit_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_KIT_REV_TEMPLATE_CODE,
            name=f"{test_kit.kit_barcode}-rev-{latest.revision_no + 1}",
            properties={
                "test_kit_id": test_kit_id,
                "revision_no": latest.revision_no + 1,
                "kit_type": kit_type,
                "status": status,
                "origin_site_id": origin_site_id,
                "expiration_date": expiration_date.isoformat() if expiration_date else None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_kit_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_test_kit_revision(revision_instance)

    def get_test_kit_by_id(
        self,
        *,
        test_kit_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbTestKitRecord | None:
        instance = self._resolve_test_kit_instance(test_kit_id)
        if instance is None or instance.is_deleted:
            return None
        test_kit = self._to_test_kit(instance)
        if tenant_id is not None and test_kit.tenant_id != tenant_id:
            return None
        return test_kit

    def get_test_kit_by_barcode(
        self,
        *,
        barcode: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbTestKitRecord | None:
        normalized = (barcode or "").strip()
        for instance in self._instances_for_template(TEST_KIT_TEMPLATE_CODE):
            test_kit = self._to_test_kit(instance)
            if test_kit.kit_barcode != normalized:
                continue
            if tenant_id is not None and test_kit.tenant_id != tenant_id:
                continue
            return test_kit
        return None

    def list_test_kits(
        self,
        *,
        tenant_id: uuid.UUID | None,
        skip: int,
        limit: int,
    ) -> list[TapdbTestKitRecord]:
        rows: list[TapdbTestKitRecord] = []
        for instance in self._instances_for_template(TEST_KIT_TEMPLATE_CODE):
            test_kit = self._to_test_kit(instance)
            if tenant_id is not None and test_kit.tenant_id != tenant_id:
                continue
            rows.append(test_kit)
        rows.sort(
            key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def get_latest_test_kit_revision(
        self,
        test_kit_id: str,
    ) -> TapdbTestKitRevisionRecord | None:
        test_kit_instance = self._resolve_test_kit_instance(test_kit_id)
        if test_kit_instance is None:
            return None
        children = get_child_instances(self.db, test_kit_instance, TEST_KIT_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_test_kit_revision(c) for c in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    # ---------------------------------------------------------------------
    # Containment (TapDB lineage)
    # ---------------------------------------------------------------------

    def add_item_to_shipment(
        self,
        *,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None,
        created_by: uuid.UUID | None,
    ) -> bool:
        """Add an item to a shipment via TapDB lineage (idempotent).

        Returns True if a new relationship was created or re-activated.
        """
        shipment_instance = self._resolve_shipment_instance(shipment_id)
        if shipment_instance is None:
            raise ValueError(f"Shipment not found: {shipment_id}")

        child_instance: generic_instance | None = None
        if item_type == "TestKit":
            child_instance = self._resolve_test_kit_instance(item_id)
        elif item_type == "Shipment":
            child_instance = self._resolve_shipment_instance(item_id)
        else:
            raise ValueError(f"Unsupported shipment item_type: {item_type}")

        if child_instance is None:
            raise ValueError(f"{item_type} not found: {item_id}")

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == shipment_instance.uid,
                generic_instance_lineage.child_instance_uid == child_instance.uid,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is not None and not existing.is_deleted:
            return False

        props: dict[str, Any] = {}
        if reason:
            props["reason"] = reason
        if created_by:
            props["created_by"] = str(created_by)

        if existing is not None:
            existing.is_deleted = False
            existing.json_addl = {"properties": props} if props else (existing.json_addl or None)
            self.db.flush()
            return True

        lineage = self.factory.link_instances(
            session=self.db,
            parent=shipment_instance,
            child=child_instance,
            relationship_type=CONTAINMENT_RELATIONSHIP_TYPE,
        )
        if props:
            lineage.json_addl = {"properties": props}
        self.db.flush()
        return True

    def remove_item_from_shipment(
        self,
        *,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None,
        created_by: uuid.UUID | None,
    ) -> bool:
        """Remove an item from a shipment via TapDB lineage (idempotent).

        Returns True if an existing relationship was marked deleted.
        """
        shipment_instance = self._resolve_shipment_instance(shipment_id)
        if shipment_instance is None:
            raise ValueError(f"Shipment not found: {shipment_id}")

        child_instance: generic_instance | None = None
        if item_type == "TestKit":
            child_instance = self._resolve_test_kit_instance(item_id)
        elif item_type == "Shipment":
            child_instance = self._resolve_shipment_instance(item_id)
        else:
            raise ValueError(f"Unsupported shipment item_type: {item_type}")

        if child_instance is None:
            raise ValueError(f"{item_type} not found: {item_id}")

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == shipment_instance.uid,
                generic_instance_lineage.child_instance_uid == child_instance.uid,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            return False

        props: dict[str, Any] = {}
        if reason:
            props["reason"] = reason
        if created_by:
            props["created_by"] = str(created_by)

        existing.is_deleted = True
        if props:
            existing.json_addl = {"properties": props}
        self.db.flush()
        return True

    def list_shipment_contents(self, shipment_id: str) -> list[dict[str, Any]]:
        """Return the current contents of a shipment (TapDB lineage)."""
        shipment_instance = self._resolve_shipment_instance(shipment_id)
        if shipment_instance is None:
            return []

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == shipment_instance.uid,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt)
        )
        edges = list(self.db.execute(stmt).scalars().all())
        if not edges:
            return []

        child_uids = [edge.child_instance_uid for edge in edges]
        inst_stmt = select(generic_instance).where(generic_instance.uid.in_(child_uids))
        instances = list(self.db.execute(inst_stmt).scalars().all())
        instance_by_uid = {row.uid: row for row in instances}

        contents: list[dict[str, Any]] = []
        for edge in edges:
            inst = instance_by_uid.get(edge.child_instance_uid)
            if inst is None:
                continue
            record_type = None
            template_code = f"{inst.category}/{inst.type}/{inst.subtype}/{inst.version}/"
            if template_code == TEST_KIT_TEMPLATE_CODE:
                record_type = "TestKit"
            elif template_code == SHIPMENT_TEMPLATE_CODE:
                record_type = "Shipment"
            else:
                record_type = "Unknown"
            contents.append(
                {
                    "type": record_type,
                    "id": inst.euid,
                    "added_at": (edge.created_dt.isoformat() if edge.created_dt else None),
                }
            )
        return contents

    def get_shipment_containment_tree(self, shipment_id: str) -> dict[str, Any]:
        """Return shipment -> test kit tree used by the shipment detail page."""
        kit_euids: list[str] = []
        for item in self.list_shipment_contents(shipment_id):
            if item.get("type") != "TestKit":
                continue
            euid = item.get("id")
            if euid:
                kit_euids.append(str(euid))

        test_kits: list[dict[str, Any]] = []
        for kit_euid in kit_euids:
            kit = self.get_test_kit_by_id(test_kit_id=kit_euid, tenant_id=None)
            if kit is None:
                continue
            latest = self.get_latest_test_kit_revision(kit_euid)
            test_kits.append(
                {
                    "id": kit.euid,
                    "barcode": kit.kit_barcode,
                    "type": latest.kit_type if latest else None,
                    "specimens": [],
                }
            )

        return {"test_kits": test_kits, "direct_specimens": []}

    def list_test_kit_contents(self, test_kit_id: str) -> list[dict[str, Any]]:
        """Return the current contents of a test kit (children via TapDB lineage)."""
        kit_instance = self._resolve_test_kit_instance(test_kit_id)
        if kit_instance is None:
            return []

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == kit_instance.uid,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt)
        )
        edges = list(self.db.execute(stmt).scalars().all())
        if not edges:
            return []

        child_uids = [edge.child_instance_uid for edge in edges]
        inst_stmt = select(generic_instance).where(generic_instance.uid.in_(child_uids))
        instances = list(self.db.execute(inst_stmt).scalars().all())
        instance_by_uid = {row.uid: row for row in instances}

        contents: list[dict[str, Any]] = []
        for edge in edges:
            inst = instance_by_uid.get(edge.child_instance_uid)
            if inst is None:
                continue
            contents.append(
                {
                    "type": "Container",
                    "id": inst.euid,
                    "added_at": (edge.created_dt.isoformat() if edge.created_dt else None),
                }
            )
        return contents

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(SHIPMENT_TEMPLATE_CODE, "Atlas Shipment", SHIPMENT_PREFIX)
        self._ensure_template(
            SHIPMENT_REV_TEMPLATE_CODE,
            "Atlas Shipment Revision",
            SHIPMENT_REV_PREFIX,
        )
        self._ensure_template(TEST_KIT_TEMPLATE_CODE, "Atlas Test Kit", TEST_KIT_PREFIX)
        self._ensure_template(
            TEST_KIT_REV_TEMPLATE_CODE,
            "Atlas Test Kit Revision",
            TEST_KIT_REV_PREFIX,
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(self, template_code: str, name: str, instance_prefix: str) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl={"managed_by": "lsmc-atlas", "domain": "logistics"},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _to_shipment(self, instance: generic_instance) -> TapdbShipmentRecord:
        props = self._instance_properties(instance)
        return TapdbShipmentRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            shipment_number=str(props.get("shipment_number") or instance.name or ""),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_shipment_revision(self, instance: generic_instance) -> TapdbShipmentRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbShipmentRevisionRecord(
            euid=instance.euid,
            shipment_id=str(props.get("shipment_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            status=str(props.get("status") or "DRAFT"),
            carrier=props.get("carrier"),
            tracking_number=props.get("tracking_number"),
            origin_site_id=props.get("origin_site_id"),
            origin_address=props.get("origin_address")
            if isinstance(props.get("origin_address"), dict)
            else None,
            destination_address=props.get("destination_address")
            if isinstance(props.get("destination_address"), dict)
            else None,
            shipped_at=_to_dt(props.get("shipped_at")),
            delivered_at=_to_dt(props.get("delivered_at")),
            received_at=_to_dt(props.get("received_at")),
            temperature_requirement=props.get("temperature_requirement"),
            special_instructions=props.get("special_instructions"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_test_kit(self, instance: generic_instance) -> TapdbTestKitRecord:
        props = self._instance_properties(instance)
        return TapdbTestKitRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            kit_barcode=str(props.get("kit_barcode") or instance.name or ""),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_test_kit_revision(self, instance: generic_instance) -> TapdbTestKitRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbTestKitRevisionRecord(
            euid=instance.euid,
            test_kit_id=str(props.get("test_kit_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            kit_type=props.get("kit_type"),
            status=str(props.get("status") or "CREATED"),
            origin_site_id=props.get("origin_site_id"),
            expiration_date=_to_dt(props.get("expiration_date")),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    # ------------------------------------------------------------------
    # EUID-first resolvers
    # ------------------------------------------------------------------

    def _resolve_shipment_instance(
        self,
        shipment_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve a shipment instance by EUID."""
        euid = str(shipment_id)
        return get_instance_by_euid(self.db, SHIPMENT_TEMPLATE_CODE, euid)

    def _resolve_test_kit_instance(
        self,
        test_kit_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve a test kit instance by EUID."""
        euid = str(test_kit_id)
        return get_instance_by_euid(self.db, TEST_KIT_TEMPLATE_CODE, euid)
