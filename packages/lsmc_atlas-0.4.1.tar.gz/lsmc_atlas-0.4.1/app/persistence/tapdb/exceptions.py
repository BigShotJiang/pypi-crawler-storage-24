"""TapDB-backed repository adapter for Atlas exceptions domain."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

EXCEPTION_TEMPLATE_CODE = "atlas/events/exception/1.0/"
EXCEPTION_REV_TEMPLATE_CODE = "atlas/events/exception-revision/1.0/"

EXCEPTION_PREFIX = "EXP"
EXCEPTION_REV_PREFIX = "EXR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbExceptionRecord:
    euid: str
    tenant_id: uuid.UUID
    exception_number: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbExceptionRevisionRecord:
    revision_id: str
    exception_id: str
    revision_no: int
    exception_type: str
    status: str
    trigger_entity_type: str | None
    trigger_entity_id: str | None
    scanned_data: dict | None
    order_id: str | None
    external_object_id: str | None
    shipment_id: str | None
    assigned_to: str | None
    resolution_notes: str | None
    resolved_at: datetime | None
    resolved_by: str | None
    note: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


class TapdbExceptionRepository:
    """Exception persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def generate_next_exception_number(self, tenant_id: uuid.UUID) -> str:
        tenant_key = str(tenant_id)
        max_num = 0
        for instance in self._instances_for_template(EXCEPTION_TEMPLATE_CODE):
            exception = self._to_exception(instance)
            if str(exception.tenant_id) != tenant_key:
                continue
            match = re.fullmatch(r"EXC-(\d{1,})", exception.exception_number)
            if not match:
                continue
            max_num = max(max_num, int(match.group(1)))
        return f"EXC-{max_num + 1:06d}"

    def create_exception(
        self,
        tenant_id: uuid.UUID,
        exception_number: str,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbExceptionRecord, TapdbExceptionRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        exception_props = {
            "tenant_id": str(tenant_id),
            "exception_number": exception_number,
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }

        exception_instance = self.factory.create_instance(
            session=self.db,
            template_code=EXCEPTION_TEMPLATE_CODE,
            name=exception_number,
            properties=exception_props,
        )
        exception_euid = exception_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=EXCEPTION_REV_TEMPLATE_CODE,
            name=f"{exception_number}-rev-1",
            properties={
                "exception_id": exception_euid,
                "revision_no": 1,
                "exception_type": data.exception_type,
                "status": data.status,
                "trigger_entity_type": data.trigger_entity_type,
                "trigger_entity_id": (
                    str(data.trigger_entity_id) if data.trigger_entity_id else None
                ),
                "scanned_data": data.scanned_data,
                "order_id": str(data.order_id) if data.order_id else None,
                "external_object_id": (
                    str(data.external_object_id) if data.external_object_id else None
                ),
                "shipment_id": str(data.shipment_id) if data.shipment_id else None,
                "assigned_to": str(data.assigned_to) if data.assigned_to else None,
                "resolution_notes": data.resolution_notes,
                "resolved_at": data.resolved_at.isoformat() if data.resolved_at else None,
                "resolved_by": str(data.resolved_by) if data.resolved_by else None,
                "note": data.note,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )

        self.factory.link_instances(
            session=self.db,
            parent=exception_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()

        return self._to_exception(exception_instance), self._to_revision(revision_instance)

    def get_exception_with_revision(
        self,
        exception_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbExceptionRecord, TapdbExceptionRevisionRecord] | None:
        exception = self._get_exception_by_id(exception_id, tenant_id)
        if exception is None:
            return None
        revision = self.get_latest_revision(exception_id)
        if revision is None:
            return None
        return exception, revision

    def get_exception_by_number(
        self,
        exception_number: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbExceptionRecord, TapdbExceptionRevisionRecord] | None:
        tenant_key = str(tenant_id) if tenant_id else None
        for instance in self._instances_for_template(EXCEPTION_TEMPLATE_CODE):
            exception = self._to_exception(instance)
            if tenant_key and str(exception.tenant_id) != tenant_key:
                continue
            if exception.exception_number != exception_number:
                continue
            revision = self.get_latest_revision(exception.euid)
            if revision is None:
                return None
            return exception, revision
        return None

    def list_exceptions(
        self,
        tenant_id: uuid.UUID | None,
        skip: int = 0,
        limit: int = 50,
        status_filter: str | None = None,
        exception_type_filter: str | None = None,
    ) -> list[tuple[TapdbExceptionRecord, TapdbExceptionRevisionRecord]]:
        tenant_key = str(tenant_id) if tenant_id else None
        rows: list[tuple[TapdbExceptionRecord, TapdbExceptionRevisionRecord]] = []

        for instance in self._instances_for_template(EXCEPTION_TEMPLATE_CODE):
            exception = self._to_exception(instance)
            if tenant_key and str(exception.tenant_id) != tenant_key:
                continue
            revision = self.get_latest_revision(exception.euid)
            if revision is None:
                continue
            if status_filter and revision.status != status_filter:
                continue
            if exception_type_filter and revision.exception_type != exception_type_filter:
                continue
            rows.append((exception, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def update_exception(
        self,
        exception_id: str,
        tenant_id: uuid.UUID | None,
        data: Any,
        updated_by: uuid.UUID | None,
    ) -> tuple[TapdbExceptionRecord, TapdbExceptionRevisionRecord] | None:
        result = self.get_exception_with_revision(exception_id=exception_id, tenant_id=tenant_id)
        if result is None:
            return None
        exception, latest = result
        now = datetime.now(UTC)

        revision = self.factory.create_instance(
            session=self.db,
            template_code=EXCEPTION_REV_TEMPLATE_CODE,
            name=f"{exception.exception_number}-rev-{latest.revision_no + 1}",
            properties={
                "exception_id": exception_id,
                "revision_no": latest.revision_no + 1,
                "exception_type": latest.exception_type,
                "status": data.status if data.status is not None else latest.status,
                "trigger_entity_type": latest.trigger_entity_type,
                "trigger_entity_id": latest.trigger_entity_id,
                "scanned_data": latest.scanned_data,
                "order_id": latest.order_id,
                "external_object_id": latest.external_object_id,
                "shipment_id": latest.shipment_id,
                "assigned_to": (
                    str(data.assigned_to) if data.assigned_to is not None else latest.assigned_to
                ),
                "resolution_notes": (
                    data.resolution_notes
                    if data.resolution_notes is not None
                    else latest.resolution_notes
                ),
                "resolved_at": latest.resolved_at.isoformat() if latest.resolved_at else None,
                "resolved_by": latest.resolved_by,
                "note": data.note,
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
            },
        )

        exception_instance = get_instance_by_euid(self.db, EXCEPTION_TEMPLATE_CODE, exception_id)
        if exception_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=exception_instance,
                child=revision,
                relationship_type="revision",
            )
        self.db.commit()

        return exception, self._to_revision(revision)

    def resolve_exception(
        self,
        exception_id: str,
        tenant_id: uuid.UUID | None,
        resolution_notes: str,
        resolved_by: uuid.UUID | None,
    ) -> tuple[TapdbExceptionRecord, TapdbExceptionRevisionRecord] | None:
        result = self.get_exception_with_revision(exception_id=exception_id, tenant_id=tenant_id)
        if result is None:
            return None
        exception, latest = result
        now = datetime.now(UTC)

        revision = self.factory.create_instance(
            session=self.db,
            template_code=EXCEPTION_REV_TEMPLATE_CODE,
            name=f"{exception.exception_number}-rev-{latest.revision_no + 1}",
            properties={
                "exception_id": exception_id,
                "revision_no": latest.revision_no + 1,
                "exception_type": latest.exception_type,
                "status": "RESOLVED",
                "trigger_entity_type": latest.trigger_entity_type,
                "trigger_entity_id": latest.trigger_entity_id,
                "scanned_data": latest.scanned_data,
                "order_id": latest.order_id,
                "external_object_id": latest.external_object_id,
                "shipment_id": latest.shipment_id,
                "assigned_to": latest.assigned_to,
                "resolution_notes": resolution_notes,
                "resolved_at": now.isoformat(),
                "resolved_by": str(resolved_by) if resolved_by else None,
                "note": "Exception resolved",
                "created_by": str(resolved_by) if resolved_by else None,
                "created_at": now.isoformat(),
            },
        )

        exception_instance = get_instance_by_euid(self.db, EXCEPTION_TEMPLATE_CODE, exception_id)
        if exception_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=exception_instance,
                child=revision,
                relationship_type="revision",
            )
        self.db.commit()

        return exception, self._to_revision(revision)

    def get_latest_revision(self, exception_id: str) -> TapdbExceptionRevisionRecord | None:
        exception_instance = get_instance_by_euid(self.db, EXCEPTION_TEMPLATE_CODE, exception_id)
        if exception_instance is None:
            return None
        children = get_child_instances(self.db, exception_instance, EXCEPTION_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_revision(c) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    def _get_exception_by_id(
        self,
        exception_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbExceptionRecord | None:
        instance = get_instance_by_euid(self.db, EXCEPTION_TEMPLATE_CODE, exception_id)
        if instance is None or instance.is_deleted:
            return None
        if not self._matches_template(instance, EXCEPTION_TEMPLATE_CODE):
            return None
        exception = self._to_exception(instance)
        if tenant_id and str(exception.tenant_id) != str(tenant_id):
            return None
        return exception

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            EXCEPTION_TEMPLATE_CODE,
            EXCEPTION_PREFIX,
            "Atlas Exception",
            {"managed_by": "lsmc-atlas", "domain": "exceptions"},
        )
        self._ensure_template(
            EXCEPTION_REV_TEMPLATE_CODE,
            EXCEPTION_REV_PREFIX,
            "Atlas Exception Revision",
            {"managed_by": "lsmc-atlas", "domain": "exceptions"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_exception(self, instance: generic_instance) -> TapdbExceptionRecord:
        props = self._instance_properties(instance)
        return TapdbExceptionRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            exception_number=str(props.get("exception_number") or instance.name),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_revision(self, instance: generic_instance) -> TapdbExceptionRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbExceptionRevisionRecord(
            revision_id=instance.euid,
            exception_id=str(props.get("exception_id") or ""),
            revision_no=int(props.get("revision_no") or 1),
            exception_type=str(props.get("exception_type") or ""),
            status=str(props.get("status") or "OPEN"),
            trigger_entity_type=props.get("trigger_entity_type"),
            trigger_entity_id=props.get("trigger_entity_id"),
            scanned_data=props.get("scanned_data"),
            order_id=props.get("order_id"),
            external_object_id=props.get("external_object_id"),
            shipment_id=props.get("shipment_id"),
            assigned_to=props.get("assigned_to"),
            resolution_notes=props.get("resolution_notes"),
            resolved_at=_to_dt(props.get("resolved_at")),
            resolved_by=props.get("resolved_by"),
            note=props.get("note"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )
