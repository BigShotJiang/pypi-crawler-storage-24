"""TapDB-backed repository adapter for Atlas people domain."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, date, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

PATIENT_TEMPLATE_CODE = "atlas/people/patient/1.0/"
PATIENT_REV_TEMPLATE_CODE = "atlas/people/patient-revision/1.0/"
CLINICIAN_TEMPLATE_CODE = "atlas/people/clinician/1.0/"
CLINICIAN_REV_TEMPLATE_CODE = "atlas/people/clinician-revision/1.0/"

PATIENT_PREFIX = "PAT"
PATIENT_REV_PREFIX = "PTR"
CLINICIAN_PREFIX = "CNP"
CLINICIAN_REV_PREFIX = "CNR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


def _to_date(value: Any) -> date | None:
    if value is None:
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        try:
            return date.fromisoformat(candidate)
        except ValueError:
            return None
    return None


def _date_to_str(value: date | None) -> str | None:
    if value is None:
        return None
    return value.isoformat()


@dataclass
class TapdbPatientRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbPatientRevisionRecord:
    euid: str
    patient_id: str  # EUID of parent patient
    revision_no: int
    first_name: str
    last_name: str
    middle_name: str | None
    date_of_birth: date | None
    sex: str | None
    mrn: str | None
    email: str | None
    phone: str | None
    address: dict | None
    family_relationships: dict | None
    clinical_notes: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


@dataclass
class TapdbClinicianRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbClinicianRevisionRecord:
    euid: str
    clinician_id: str  # EUID of parent clinician
    revision_no: int
    first_name: str
    last_name: str
    credentials: str | None
    npi: str | None
    specialty: str | None
    email: str | None
    phone: str | None
    fax: str | None
    addresses: list[dict] | None
    site_id: str | None
    is_active: bool
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


class TapdbPeopleRepository:
    """People persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    # ------------------------------------------------------------------
    # Patient methods
    # ------------------------------------------------------------------

    def create_patient(
        self,
        tenant_id: uuid.UUID,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbPatientRecord, TapdbPatientRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        patient_properties = {
            "tenant_id": str(tenant_id),
            "site_id": str(getattr(data, "site_id", "") or ""),
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }

        patient_instance = self.factory.create_instance(
            session=self.db,
            template_code=PATIENT_TEMPLATE_CODE,
            name=f"patient-{now.timestamp()}",
            properties=patient_properties,
        )

        patient_euid = patient_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=PATIENT_REV_TEMPLATE_CODE,
            name=f"patient-{patient_euid}-rev-1",
            properties={
                "patient_id": patient_euid,
                "revision_no": 1,
                "first_name": data.first_name,
                "last_name": data.last_name,
                "middle_name": data.middle_name,
                "date_of_birth": _date_to_str(data.date_of_birth),
                "sex": data.sex,
                "mrn": data.mrn,
                "email": data.email,
                "phone": data.phone,
                "address": data.address,
                "family_relationships": None,
                "clinical_notes": data.clinical_notes,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )

        self.factory.link_instances(
            session=self.db,
            parent=patient_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()

        return self._to_patient(patient_instance), self._to_patient_revision(revision_instance)

    def get_patient_with_revision(
        self,
        patient_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbPatientRecord, TapdbPatientRevisionRecord] | None:
        patient = self._get_patient_by_id(patient_id, tenant_id)
        if patient is None:
            return None
        revision = self.get_latest_patient_revision(patient_id)
        if revision is None:
            return None
        return patient, revision

    def list_patients(
        self,
        tenant_id: uuid.UUID | None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[tuple[TapdbPatientRecord, TapdbPatientRevisionRecord]]:
        tenant_key = str(tenant_id) if tenant_id else None
        rows: list[tuple[TapdbPatientRecord, TapdbPatientRevisionRecord]] = []

        for instance in self._instances_for_template(PATIENT_TEMPLATE_CODE):
            patient = self._to_patient(instance)
            if tenant_key and str(patient.tenant_id) != tenant_key:
                continue
            revision = self.get_latest_patient_revision(patient.euid)
            if revision is None:
                continue
            rows.append((patient, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[offset : offset + limit]

    def search_patients_by_mrn(
        self,
        mrn: str,
        tenant_id: uuid.UUID | None,
    ) -> list[tuple[TapdbPatientRecord, TapdbPatientRevisionRecord]]:
        rows = self.list_patients(tenant_id=tenant_id, limit=1_000_000, offset=0)
        return [(patient, revision) for patient, revision in rows if revision.mrn == mrn]

    def search_patients_by_name(
        self,
        name: str,
        tenant_id: uuid.UUID | None,
        limit: int = 100,
    ) -> list[tuple[TapdbPatientRecord, TapdbPatientRevisionRecord]]:
        pattern = name.lower()
        rows = self.list_patients(tenant_id=tenant_id, limit=1_000_000, offset=0)
        filtered: list[tuple[TapdbPatientRecord, TapdbPatientRevisionRecord]] = []
        for patient, revision in rows:
            first = (revision.first_name or "").lower()
            last = (revision.last_name or "").lower()
            if pattern in first or pattern in last:
                filtered.append((patient, revision))
            if len(filtered) >= limit:
                break
        return filtered

    def update_patient(
        self,
        patient_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbPatientRecord, TapdbPatientRevisionRecord] | None:
        result = self.get_patient_with_revision(patient_id, tenant_id=tenant_id)
        if result is None:
            return None
        patient, latest = result
        now = datetime.now(UTC)

        revision = self.factory.create_instance(
            session=self.db,
            template_code=PATIENT_REV_TEMPLATE_CODE,
            name=f"patient-{patient_id}-rev-{latest.revision_no + 1}",
            properties={
                "patient_id": patient_id,
                "revision_no": latest.revision_no + 1,
                "first_name": data.first_name if data.first_name is not None else latest.first_name,
                "last_name": data.last_name if data.last_name is not None else latest.last_name,
                "middle_name": (
                    data.middle_name if data.middle_name is not None else latest.middle_name
                ),
                "date_of_birth": _date_to_str(
                    data.date_of_birth if data.date_of_birth is not None else latest.date_of_birth
                ),
                "sex": data.sex if data.sex is not None else latest.sex,
                "mrn": data.mrn if data.mrn is not None else latest.mrn,
                "email": data.email if data.email is not None else latest.email,
                "phone": data.phone if data.phone is not None else latest.phone,
                "address": data.address if data.address is not None else latest.address,
                "family_relationships": None,
                "clinical_notes": (
                    data.clinical_notes
                    if data.clinical_notes is not None
                    else latest.clinical_notes
                ),
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
                "note": data.note,
            },
        )

        patient_instance = self._resolve_patient_instance(patient_id)
        if patient_instance is not None:
            if hasattr(data, "site_id") and data.site_id is not None:
                patient_props = self._instance_properties(patient_instance)
                patient_props["site_id"] = str(data.site_id)
                patient_instance.json_addl = {"properties": patient_props}
            self.factory.link_instances(
                session=self.db,
                parent=patient_instance,
                child=revision,
                relationship_type="revision",
            )

        self.db.commit()
        return patient, self._to_patient_revision(revision)

    def get_latest_patient_revision(
        self,
        patient_id: str,
    ) -> TapdbPatientRevisionRecord | None:
        patient_instance = self._resolve_patient_instance(patient_id)
        if patient_instance is None:
            return None
        children = get_child_instances(self.db, patient_instance, PATIENT_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_patient_revision(c) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    # ------------------------------------------------------------------
    # Clinician methods
    # ------------------------------------------------------------------

    def create_clinician(
        self,
        tenant_id: uuid.UUID,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        clinician_properties = {
            "tenant_id": str(tenant_id),
            "site_id": str(getattr(data, "site_id", "") or ""),
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }

        clinician_instance = self.factory.create_instance(
            session=self.db,
            template_code=CLINICIAN_TEMPLATE_CODE,
            name=f"clinician-{now.timestamp()}",
            properties=clinician_properties,
        )

        clinician_euid = clinician_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=CLINICIAN_REV_TEMPLATE_CODE,
            name=f"clinician-{clinician_euid}-rev-1",
            properties={
                "clinician_id": clinician_euid,
                "revision_no": 1,
                "first_name": data.first_name,
                "last_name": data.last_name,
                "credentials": data.credentials,
                "npi": data.npi,
                "specialty": data.specialty,
                "email": data.email,
                "phone": data.phone,
                "fax": data.fax,
                "addresses": data.addresses,
                "site_id": str(data.site_id) if data.site_id else None,
                "is_active": True,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )

        self.factory.link_instances(
            session=self.db,
            parent=clinician_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()

        return self._to_clinician(clinician_instance), self._to_clinician_revision(
            revision_instance
        )

    def get_clinician_with_revision(
        self,
        clinician_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord] | None:
        clinician = self._get_clinician_by_id(clinician_id, tenant_id)
        if clinician is None:
            return None
        revision = self.get_latest_clinician_revision(clinician_id)
        if revision is None:
            return None
        return clinician, revision

    def list_clinicians(
        self,
        tenant_id: uuid.UUID | None,
        skip: int = 0,
        limit: int = 100,
        active_only: bool = True,
    ) -> list[tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord]]:
        tenant_key = str(tenant_id) if tenant_id else None
        rows: list[tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord]] = []

        for instance in self._instances_for_template(CLINICIAN_TEMPLATE_CODE):
            clinician = self._to_clinician(instance)
            if tenant_key and str(clinician.tenant_id) != tenant_key:
                continue
            revision = self.get_latest_clinician_revision(clinician.euid)
            if revision is None:
                continue
            if active_only and not revision.is_active:
                continue
            rows.append((clinician, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def get_clinician_by_npi(
        self,
        npi: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord] | None:
        rows = self.list_clinicians(
            tenant_id=tenant_id,
            skip=0,
            limit=1_000_000,
            active_only=False,
        )
        for clinician, revision in rows:
            if revision.npi == npi:
                return clinician, revision
        return None

    def search_clinicians_by_name(
        self,
        name: str,
        tenant_id: uuid.UUID | None,
        limit: int = 100,
    ) -> list[tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord]]:
        pattern = name.lower()
        rows = self.list_clinicians(
            tenant_id=tenant_id,
            skip=0,
            limit=1_000_000,
            active_only=False,
        )
        filtered: list[tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord]] = []
        for clinician, revision in rows:
            first = (revision.first_name or "").lower()
            last = (revision.last_name or "").lower()
            if pattern in first or pattern in last:
                filtered.append((clinician, revision))
            if len(filtered) >= limit:
                break
        return filtered

    def update_clinician(
        self,
        clinician_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbClinicianRecord, TapdbClinicianRevisionRecord] | None:
        result = self.get_clinician_with_revision(clinician_id, tenant_id=tenant_id)
        if result is None:
            return None
        clinician, latest = result
        now = datetime.now(UTC)

        revision = self.factory.create_instance(
            session=self.db,
            template_code=CLINICIAN_REV_TEMPLATE_CODE,
            name=f"clinician-{clinician_id}-rev-{latest.revision_no + 1}",
            properties={
                "clinician_id": clinician_id,
                "revision_no": latest.revision_no + 1,
                "first_name": data.first_name if data.first_name is not None else latest.first_name,
                "last_name": data.last_name if data.last_name is not None else latest.last_name,
                "credentials": (
                    data.credentials if data.credentials is not None else latest.credentials
                ),
                "npi": data.npi if data.npi is not None else latest.npi,
                "specialty": data.specialty if data.specialty is not None else latest.specialty,
                "email": data.email if data.email is not None else latest.email,
                "phone": data.phone if data.phone is not None else latest.phone,
                "fax": data.fax if data.fax is not None else latest.fax,
                "addresses": data.addresses if data.addresses is not None else latest.addresses,
                "site_id": (
                    str(data.site_id)
                    if data.site_id is not None
                    else (str(latest.site_id) if latest.site_id else None)
                ),
                "is_active": data.is_active if data.is_active is not None else latest.is_active,
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
                "note": data.note,
            },
        )

        clinician_instance = self._resolve_clinician_instance(clinician_id)
        if clinician_instance is not None:
            clinician_props = self._instance_properties(clinician_instance)
            clinician_props["site_id"] = (
                str(data.site_id)
                if data.site_id is not None
                else (str(latest.site_id) if latest.site_id else "")
            )
            clinician_instance.json_addl = {"properties": clinician_props}
            self.factory.link_instances(
                session=self.db,
                parent=clinician_instance,
                child=revision,
                relationship_type="revision",
            )

        self.db.commit()
        return clinician, self._to_clinician_revision(revision)

    def get_latest_clinician_revision(
        self,
        clinician_id: str,
    ) -> TapdbClinicianRevisionRecord | None:
        clinician_instance = self._resolve_clinician_instance(clinician_id)
        if clinician_instance is None:
            return None
        children = get_child_instances(self.db, clinician_instance, CLINICIAN_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_clinician_revision(c) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_patient_by_id(
        self,
        patient_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbPatientRecord | None:
        instance = self._resolve_patient_instance(patient_id)
        if instance is None or instance.is_deleted:
            return None
        patient = self._to_patient(instance)
        if tenant_id is not None and str(patient.tenant_id) != str(tenant_id):
            return None
        return patient

    def _get_clinician_by_id(
        self,
        clinician_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbClinicianRecord | None:
        instance = self._resolve_clinician_instance(clinician_id)
        if instance is None or instance.is_deleted:
            return None
        clinician = self._to_clinician(instance)
        if tenant_id is not None and str(clinician.tenant_id) != str(tenant_id):
            return None
        return clinician

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            PATIENT_TEMPLATE_CODE,
            PATIENT_PREFIX,
            "Atlas Patient",
            {"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._ensure_template(
            PATIENT_REV_TEMPLATE_CODE,
            PATIENT_REV_PREFIX,
            "Atlas Patient Revision",
            {"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._ensure_template(
            CLINICIAN_TEMPLATE_CODE,
            CLINICIAN_PREFIX,
            "Atlas Clinician",
            {"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._ensure_template(
            CLINICIAN_REV_TEMPLATE_CODE,
            CLINICIAN_REV_PREFIX,
            "Atlas Clinician Revision",
            {"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_patient(self, instance: generic_instance) -> TapdbPatientRecord:
        props = self._instance_properties(instance)
        return TapdbPatientRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_patient_revision(self, instance: generic_instance) -> TapdbPatientRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbPatientRevisionRecord(
            euid=instance.euid,
            patient_id=str(props.get("patient_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            first_name=str(props.get("first_name") or ""),
            last_name=str(props.get("last_name") or ""),
            middle_name=props.get("middle_name"),
            date_of_birth=_to_date(props.get("date_of_birth")),
            sex=props.get("sex"),
            mrn=props.get("mrn"),
            email=props.get("email"),
            phone=props.get("phone"),
            address=props.get("address"),
            family_relationships=props.get("family_relationships"),
            clinical_notes=props.get("clinical_notes"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_clinician(self, instance: generic_instance) -> TapdbClinicianRecord:
        props = self._instance_properties(instance)
        return TapdbClinicianRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_clinician_revision(self, instance: generic_instance) -> TapdbClinicianRevisionRecord:
        props = self._instance_properties(instance)
        addresses = props.get("addresses")
        if isinstance(addresses, list):
            addresses = [item for item in addresses if isinstance(item, dict)]
        else:
            addresses = None

        return TapdbClinicianRevisionRecord(
            euid=instance.euid,
            clinician_id=str(props.get("clinician_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            first_name=str(props.get("first_name") or ""),
            last_name=str(props.get("last_name") or ""),
            credentials=props.get("credentials"),
            npi=props.get("npi"),
            specialty=props.get("specialty"),
            email=props.get("email"),
            phone=props.get("phone"),
            fax=props.get("fax"),
            addresses=addresses,
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            is_active=bool(props.get("is_active", True)),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    # ------------------------------------------------------------------
    # EUID-first resolvers
    # ------------------------------------------------------------------

    def _resolve_patient_instance(
        self,
        patient_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve a patient instance by EUID."""
        euid = str(patient_id)
        return get_instance_by_euid(self.db, PATIENT_TEMPLATE_CODE, euid)

    def _resolve_clinician_instance(
        self,
        clinician_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve a clinician instance by EUID."""
        euid = str(clinician_id)
        return get_instance_by_euid(self.db, CLINICIAN_TEMPLATE_CODE, euid)
