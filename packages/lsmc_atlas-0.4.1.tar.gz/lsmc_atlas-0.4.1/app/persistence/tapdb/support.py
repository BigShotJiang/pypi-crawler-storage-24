"""TapDB-backed repository adapter for Atlas support tickets."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

TICKET_TEMPLATE_CODE = "atlas/events/support-ticket/1.0/"
TICKET_REV_TEMPLATE_CODE = "atlas/events/support-ticket-revision/1.0/"

TICKET_PREFIX = "SPT"
TICKET_REV_PREFIX = "SPR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbSupportTicketRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    ticket_number: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbSupportTicketRevisionRecord:
    euid: str
    ticket_id: str
    revision_no: int
    subject: str
    description: str
    ticket_type: str
    priority: str
    status: str
    assigned_to: uuid.UUID | None
    related_order_id: str | None
    related_shipment_id: str | None
    resolution_notes: str | None
    resolved_at: datetime | None
    resolved_by: uuid.UUID | None
    created_at: datetime | None
    created_by: uuid.UUID | None


class TapdbSupportRepository:
    """Support ticket persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def generate_next_ticket_number(self) -> str:
        max_num = 0
        for instance in self._instances_for_template(TICKET_TEMPLATE_CODE):
            ticket = self._to_ticket(instance)
            parts = ticket.ticket_number.split("-")
            try:
                if len(parts) == 2 and parts[0] == "TKT":
                    max_num = max(max_num, int(parts[1]))
                elif len(parts) == 3 and parts[0] == "TKT":
                    max_num = max(max_num, int(parts[2]))
            except (TypeError, ValueError):
                continue
        return f"TKT-{max_num + 1}"

    def create_ticket(
        self,
        tenant_id: uuid.UUID,
        ticket_number: str,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbSupportTicketRecord, TapdbSupportTicketRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        ticket_props = {
            "tenant_id": str(tenant_id),
            "site_id": str(getattr(data, "site_id", "") or ""),
            "ticket_number": ticket_number,
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }

        ticket_instance = self.factory.create_instance(
            session=self.db,
            template_code=TICKET_TEMPLATE_CODE,
            name=ticket_number,
            properties=ticket_props,
        )
        self.db.flush()  # ensure EUID is assigned

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TICKET_REV_TEMPLATE_CODE,
            name=f"{ticket_number}-rev-1",
            properties={
                "ticket_id": ticket_instance.euid,
                "revision_no": 1,
                "subject": data.subject,
                "description": data.description,
                "ticket_type": data.ticket_type,
                "priority": data.priority,
                "status": data.status,
                "assigned_to": str(data.assigned_to) if data.assigned_to else None,
                "related_order_id": str(data.related_order_id) if data.related_order_id else None,
                "related_shipment_id": (
                    str(data.related_shipment_id) if data.related_shipment_id else None
                ),
                "resolution_notes": data.resolution_notes,
                "resolved_at": data.resolved_at.isoformat() if data.resolved_at else None,
                "resolved_by": str(data.resolved_by) if data.resolved_by else None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )

        self.factory.link_instances(
            session=self.db,
            parent=ticket_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()

        return self._to_ticket(ticket_instance), self._to_revision(revision_instance)

    def get_ticket_with_revision(
        self,
        ticket_id: str,
        tenant_id: uuid.UUID,
    ) -> tuple[TapdbSupportTicketRecord, TapdbSupportTicketRevisionRecord] | None:
        ticket = self._get_ticket_by_id(ticket_id, tenant_id)
        if ticket is None:
            return None
        revision = self.get_latest_revision(ticket_id)
        if revision is None:
            return None
        return ticket, revision

    def get_ticket_by_number(
        self,
        ticket_number: str,
        tenant_id: uuid.UUID,
    ) -> tuple[TapdbSupportTicketRecord, TapdbSupportTicketRevisionRecord] | None:
        for instance in self._instances_for_template(TICKET_TEMPLATE_CODE):
            ticket = self._to_ticket(instance)
            if str(ticket.tenant_id) != str(tenant_id):
                continue
            if ticket.ticket_number != ticket_number:
                continue
            revision = self.get_latest_revision(ticket.euid)
            if revision is None:
                return None
            return ticket, revision
        return None

    def list_tickets(
        self,
        tenant_id: uuid.UUID,
        skip: int = 0,
        limit: int = 50,
        status: str | None = None,
        ticket_type: str | None = None,
        assigned_to: uuid.UUID | None = None,
    ) -> list[tuple[TapdbSupportTicketRecord, TapdbSupportTicketRevisionRecord]]:
        assigned_key = str(assigned_to) if assigned_to else None
        rows: list[tuple[TapdbSupportTicketRecord, TapdbSupportTicketRevisionRecord]] = []

        for instance in self._instances_for_template(TICKET_TEMPLATE_CODE):
            ticket = self._to_ticket(instance)
            if str(ticket.tenant_id) != str(tenant_id):
                continue

            revision = self.get_latest_revision(ticket.euid)
            if revision is None:
                continue

            if status and revision.status != status:
                continue
            if ticket_type and revision.ticket_type != ticket_type:
                continue
            if assigned_key and str(revision.assigned_to) != assigned_key:
                continue

            rows.append((ticket, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def update_ticket(
        self,
        ticket_id: str,
        tenant_id: uuid.UUID,
        data: Any,
        updated_by: uuid.UUID | None,
    ) -> tuple[TapdbSupportTicketRecord, TapdbSupportTicketRevisionRecord] | None:
        result = self.get_ticket_with_revision(ticket_id=ticket_id, tenant_id=tenant_id)
        if result is None:
            return None
        ticket, latest = result
        now = datetime.now(UTC)

        revision = self.factory.create_instance(
            session=self.db,
            template_code=TICKET_REV_TEMPLATE_CODE,
            name=f"{ticket.ticket_number}-rev-{latest.revision_no + 1}",
            properties={
                "ticket_id": ticket_id,
                "revision_no": latest.revision_no + 1,
                "subject": data.subject if data.subject is not None else latest.subject,
                "description": data.description
                if data.description is not None
                else latest.description,
                "ticket_type": data.ticket_type
                if data.ticket_type is not None
                else latest.ticket_type,
                "priority": data.priority if data.priority is not None else latest.priority,
                "status": data.status if data.status is not None else latest.status,
                "assigned_to": (
                    str(data.assigned_to)
                    if data.assigned_to is not None
                    else (str(latest.assigned_to) if latest.assigned_to else None)
                ),
                "related_order_id": latest.related_order_id,
                "related_shipment_id": latest.related_shipment_id,
                "resolution_notes": (
                    data.resolution_notes
                    if data.resolution_notes is not None
                    else latest.resolution_notes
                ),
                "resolved_at": (
                    data.resolved_at.isoformat()
                    if getattr(data, "resolved_at", None)
                    else (latest.resolved_at.isoformat() if latest.resolved_at else None)
                ),
                "resolved_by": (
                    str(data.resolved_by)
                    if getattr(data, "resolved_by", None)
                    else (str(latest.resolved_by) if latest.resolved_by else None)
                ),
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
            },
        )

        ticket_instance = get_instance_by_euid(self.db, TICKET_TEMPLATE_CODE, ticket_id)
        if ticket_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=ticket_instance,
                child=revision,
                relationship_type="revision",
            )

        self.db.commit()
        return ticket, self._to_revision(revision)

    def resolve_ticket(
        self,
        ticket_id: str,
        tenant_id: uuid.UUID,
        resolution_notes: str,
        resolver_id: uuid.UUID | None,
    ) -> tuple[TapdbSupportTicketRecord, TapdbSupportTicketRevisionRecord] | None:
        data = type(
            "ResolvePayload",
            (),
            {
                "subject": None,
                "description": None,
                "ticket_type": None,
                "priority": None,
                "status": "RESOLVED",
                "assigned_to": None,
                "resolution_notes": resolution_notes,
                "resolved_at": datetime.now(UTC),
                "resolved_by": resolver_id,
            },
        )()
        return self.update_ticket(ticket_id, tenant_id, data, updated_by=resolver_id)

    def get_latest_revision(
        self,
        ticket_id: str,
    ) -> TapdbSupportTicketRevisionRecord | None:
        ticket_instance = get_instance_by_euid(self.db, TICKET_TEMPLATE_CODE, ticket_id)
        if ticket_instance is None:
            return None
        children = get_child_instances(self.db, ticket_instance, TICKET_REV_TEMPLATE_CODE)
        revisions: list[TapdbSupportTicketRevisionRecord] = []
        for child in children:
            if self._matches_template(child, TICKET_REV_TEMPLATE_CODE):
                revisions.append(self._to_revision(child))
        if not revisions:
            return None
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    def _get_ticket_by_id(
        self,
        ticket_id: str,
        tenant_id: uuid.UUID,
    ) -> TapdbSupportTicketRecord | None:
        instance = get_instance_by_euid(self.db, TICKET_TEMPLATE_CODE, ticket_id)
        if instance is None or instance.is_deleted:
            return None
        if not self._matches_template(instance, TICKET_TEMPLATE_CODE):
            return None
        ticket = self._to_ticket(instance)
        if str(ticket.tenant_id) != str(tenant_id):
            return None
        return ticket

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            TICKET_TEMPLATE_CODE,
            TICKET_PREFIX,
            "Atlas Support Ticket",
            {"managed_by": "lsmc-atlas", "domain": "support"},
        )
        self._ensure_template(
            TICKET_REV_TEMPLATE_CODE,
            TICKET_REV_PREFIX,
            "Atlas Support Ticket Revision",
            {"managed_by": "lsmc-atlas", "domain": "support"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_ticket(self, instance: generic_instance) -> TapdbSupportTicketRecord:
        props = self._instance_properties(instance)
        return TapdbSupportTicketRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            ticket_number=str(props.get("ticket_number") or instance.name),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_revision(self, instance: generic_instance) -> TapdbSupportTicketRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbSupportTicketRevisionRecord(
            euid=instance.euid,
            ticket_id=str(props.get("ticket_id") or ""),
            revision_no=int(props.get("revision_no") or 1),
            subject=str(props.get("subject") or ""),
            description=str(props.get("description") or ""),
            ticket_type=str(props.get("ticket_type") or ""),
            priority=str(props.get("priority") or ""),
            status=str(props.get("status") or ""),
            assigned_to=_parse_uuid(props.get("assigned_to")),
            related_order_id=props.get("related_order_id"),
            related_shipment_id=props.get("related_shipment_id"),
            resolution_notes=props.get("resolution_notes"),
            resolved_at=_to_dt(props.get("resolved_at")),
            resolved_by=_parse_uuid(props.get("resolved_by")),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )
