"""TapDB-backed persistence adapters for Atlas."""

from app.persistence.tapdb.api_clients import (
    TapdbAPIClientRecord,
    TapdbAPIClientRepository,
    TapdbAPIClientRevisionRecord,
    TapdbAPIClientUsageLogRecord,
)
from app.persistence.tapdb.test_definitions import TapdbTestDefinitionRecord, TapdbTestDefinitionRepository
from app.persistence.tapdb.audit import TapdbAuditEventRecord, TapdbAuditRepository
from app.persistence.tapdb.backend import is_tapdb_backend_enabled
from app.persistence.tapdb.client import TapdbClientBundle, build_tapdb_client_bundle
from app.persistence.tapdb.documents import (
    TapdbDocumentRecord,
    TapdbDocumentRepository,
    TapdbDocumentRevisionRecord,
)
from app.persistence.tapdb.documents import (
    TapdbLinkEventRecord as TapdbDocumentLinkEventRecord,
)
from app.persistence.tapdb.exceptions import (
    TapdbExceptionRecord,
    TapdbExceptionRepository,
    TapdbExceptionRevisionRecord,
)
from app.persistence.tapdb.groups import TapdbUserGroupRepository
from app.persistence.tapdb.manifests import (
    TapdbManifestRecord,
    TapdbManifestRepository,
    TapdbManifestRevisionRecord,
)
from app.persistence.tapdb.orgs import (
    TapdbOrganizationRecord,
    TapdbOrganizationRevisionRecord,
    TapdbOrgRepository,
    TapdbSiteRecord,
    TapdbSiteRevisionRecord,
)
from app.persistence.tapdb.people import (
    TapdbClinicianRecord,
    TapdbClinicianRevisionRecord,
    TapdbPatientRecord,
    TapdbPatientRevisionRecord,
    TapdbPeopleRepository,
)
from app.persistence.tapdb.support import (
    TapdbSupportRepository,
    TapdbSupportTicketRecord,
    TapdbSupportTicketRevisionRecord,
)
from app.persistence.tapdb.themes import TapdbThemeRepository, TapdbThemeState
from app.persistence.tapdb.user_api_tokens import (
    TapdbUserAPITokenRecord,
    TapdbUserAPITokenRepository,
    TapdbUserAPITokenRevisionRecord,
    TapdbUserAPITokenUsageLogRecord,
)
from app.persistence.tapdb.users import TapdbUserProfileRecord, TapdbUserRepository
from app.persistence.tapdb.webhooks import (
    TapdbWebhookDeliveryLogRecord,
    TapdbWebhookRepository,
    TapdbWebhookSubscriptionRecord,
    TapdbWebhookSubscriptionRevisionRecord,
)

__all__ = [
    "TapdbTestDefinitionRecord",
    "TapdbTestDefinitionRepository",
    "TapdbAPIClientRecord",
    "TapdbAPIClientRepository",
    "TapdbAPIClientRevisionRecord",
    "TapdbAPIClientUsageLogRecord",
    "TapdbAuditEventRecord",
    "TapdbAuditRepository",
    "TapdbClientBundle",
    "TapdbDocumentRecord",
    "TapdbDocumentRepository",
    "TapdbDocumentRevisionRecord",
    "TapdbDocumentLinkEventRecord",
    "TapdbExceptionRecord",
    "TapdbExceptionRepository",
    "TapdbExceptionRevisionRecord",
    "TapdbUserGroupRepository",
    "TapdbManifestRecord",
    "TapdbManifestRepository",
    "TapdbManifestRevisionRecord",
    "TapdbOrganizationRecord",
    "TapdbOrganizationRevisionRecord",
    "TapdbOrgRepository",
    "TapdbPatientRecord",
    "TapdbPatientRevisionRecord",
    "TapdbPeopleRepository",
    "TapdbClinicianRecord",
    "TapdbClinicianRevisionRecord",
    "TapdbSupportRepository",
    "TapdbSupportTicketRecord",
    "TapdbSupportTicketRevisionRecord",
    "TapdbSiteRecord",
    "TapdbSiteRevisionRecord",
    "TapdbThemeRepository",
    "TapdbThemeState",
    "TapdbUserAPITokenRecord",
    "TapdbUserAPITokenRepository",
    "TapdbUserAPITokenRevisionRecord",
    "TapdbUserAPITokenUsageLogRecord",
    "TapdbUserProfileRecord",
    "TapdbUserRepository",
    "TapdbWebhookDeliveryLogRecord",
    "TapdbWebhookRepository",
    "TapdbWebhookSubscriptionRecord",
    "TapdbWebhookSubscriptionRevisionRecord",
    "build_tapdb_client_bundle",
    "is_tapdb_backend_enabled",
]
