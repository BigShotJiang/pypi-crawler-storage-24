"""TapDB-backed repository adapter for Atlas user groups."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

GROUP_TEMPLATE_CODE = "atlas/auth/user-group/1.0/"
GROUP_REVISION_TEMPLATE_CODE = "atlas/auth/user-group-revision/1.0/"
GROUP_MEMBERSHIP_TEMPLATE_CODE = "atlas/auth/user-group-membership/1.0/"

GROUP_INSTANCE_PREFIX = "GRP"
GROUP_REVISION_INSTANCE_PREFIX = "GRR"
GROUP_MEMBERSHIP_INSTANCE_PREFIX = "MEM"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass(frozen=True)
class TapdbGroupRecord:
    """Contract-compatible group identity object."""

    euid: str
    group_code: str
    tenant_id: uuid.UUID | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass(frozen=True)
class TapdbGroupRevisionRecord:
    """Contract-compatible group revision object."""

    euid: str
    group_id: str
    revision_no: int
    name: str
    description: str | None
    access_scope: str
    default_roles: list[str] | None
    is_system_group: bool
    is_active: bool
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None = None


@dataclass(frozen=True)
class TapdbGroupMembershipRecord:
    """Contract-compatible membership object."""

    euid: str
    user_id: uuid.UUID
    group_id: str
    joined_at: datetime | None
    added_by: uuid.UUID | None
    is_active: bool
    deactivated_at: datetime | None
    deactivated_by: uuid.UUID | None

    @property
    def created_at(self) -> datetime | None:
        """Compatibility alias used by existing API/web routes."""
        return self.joined_at


class TapdbUserGroupRepository:
    """UserGroup persistence backed by TapDB templates/instances/lineages."""

    def __init__(self, db: Session, tenant_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_bootstrapped = False

    def create_group(
        self,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbGroupRecord, TapdbGroupRevisionRecord]:
        """Create group + revision instances and link them by lineage."""
        self._ensure_templates_bootstrapped()

        group_properties = {
            "group_code": data.group_code,
            "tenant_id": str(self.tenant_id) if self.tenant_id else None,
            "created_by": str(created_by) if created_by else None,
        }
        group_instance = self.factory.create_instance(
            session=self.db,
            template_code=GROUP_TEMPLATE_CODE,
            name=data.group_code,
            properties=group_properties,
        )

        access_scope = getattr(data.access_scope, "value", data.access_scope)
        revision_properties = {
            "group_id": group_instance.euid,
            "group_code": data.group_code,
            "revision_no": 1,
            "name": data.name,
            "description": data.description,
            "access_scope": str(access_scope),
            "default_roles": data.default_roles,
            "is_system_group": False,
            "is_active": True,
            "created_by": str(created_by) if created_by else None,
            "note": None,
        }
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=GROUP_REVISION_TEMPLATE_CODE,
            name=f"{data.group_code}-rev-1",
            properties=revision_properties,
        )

        self.factory.link_instances(
            session=self.db,
            parent=group_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()

        return (
            self._to_group_record(group_instance),
            self._to_revision_record(revision_instance),
        )

    def get_group_by_code(self, group_code: str) -> Any | None:
        """Return a contract-level group payload for the latest revision."""
        group_instance = self._find_group_instance_by_code(group_code)
        if group_instance is None:
            return None

        revision = self._find_latest_group_revision(group_instance)
        revision_props = self._instance_properties(revision) if revision else {}

        member_count = 0
        for membership in self._list_membership_instances(group_instance):
            props = self._instance_properties(membership)
            if bool(props.get("is_active", True)):
                member_count += 1

        from app.domain.services.groups import GroupInfo

        return GroupInfo(
            euid=group_instance.euid,
            group_code=str(
                self._instance_properties(group_instance).get("group_code") or group_code
            ),
            name=str(revision_props.get("name") or group_code),
            description=revision_props.get("description"),
            access_scope=str(revision_props.get("access_scope") or "TENANT"),
            default_roles=revision_props.get("default_roles"),
            is_system_group=bool(revision_props.get("is_system_group", False)),
            is_active=bool(revision_props.get("is_active", True)),
            member_count=member_count,
        )

    def list_group_members(self, group_euid: str) -> list[TapdbGroupMembershipRecord]:
        """List membership instances linked to the group."""
        group_instance = self._resolve_group_instance(group_euid)
        if group_instance is None:
            return []
        memberships = [
            self._to_membership_record(instance)
            for instance in self._list_membership_instances(group_instance)
        ]
        memberships.sort(
            key=lambda m: m.joined_at or datetime.min.replace(tzinfo=UTC), reverse=True
        )
        return memberships

    def remove_user_from_group(
        self,
        user_id: uuid.UUID,
        group_euid: str,
        removed_by: uuid.UUID | None,
    ) -> TapdbGroupMembershipRecord | None:
        """Soft-deactivate an active membership."""
        group_instance = self._resolve_group_instance(group_euid)
        if group_instance is None:
            return None
        membership = self._find_membership(group_instance=group_instance, user_id=user_id)
        if membership is None:
            return None

        props = self._instance_properties(membership)
        if not bool(props.get("is_active", True)):
            return None

        props["is_active"] = False
        props["deactivated_at"] = datetime.now(UTC).isoformat()
        props["deactivated_by"] = str(removed_by) if removed_by else None
        self._write_instance_properties(membership, props)
        self.db.commit()
        return self._to_membership_record(membership)

    def add_user_to_group(
        self,
        user_id: uuid.UUID,
        group_euid: str,
        added_by: uuid.UUID | None,
    ) -> TapdbGroupMembershipRecord:
        """Create or reactivate membership for a user in a group."""
        self._ensure_templates_bootstrapped()
        group_instance = self._resolve_group_instance(group_euid)
        if group_instance is None:
            raise ValueError(f"Group instance not found for euid={group_euid}")

        existing = self._find_membership(group_instance=group_instance, user_id=user_id)
        if existing is not None:
            props = self._instance_properties(existing)
            if not bool(props.get("is_active", True)):
                props["is_active"] = True
                props["deactivated_at"] = None
                props["deactivated_by"] = None
                self._write_instance_properties(existing, props)
                self.db.commit()
            return self._to_membership_record(existing)

        membership_properties = {
            "user_id": str(user_id),
            "group_id": group_euid,
            "added_by": str(added_by) if added_by else None,
            "is_active": True,
            "deactivated_at": None,
            "deactivated_by": None,
        }
        membership = self.factory.create_instance(
            session=self.db,
            template_code=GROUP_MEMBERSHIP_TEMPLATE_CODE,
            name=f"group-{group_euid}-member-{user_id}",
            properties=membership_properties,
        )

        self.factory.link_instances(
            session=self.db,
            parent=group_instance,
            child=membership,
            relationship_type="membership",
        )
        self.db.commit()
        return self._to_membership_record(membership)

    def _ensure_templates_bootstrapped(self) -> None:
        if self._templates_bootstrapped:
            return

        self._ensure_template(
            template_code=GROUP_TEMPLATE_CODE,
            template_name="Atlas User Group",
            instance_prefix=GROUP_INSTANCE_PREFIX,
            instance_polymorphic_identity="actor_instance",
        )
        self._ensure_template(
            template_code=GROUP_REVISION_TEMPLATE_CODE,
            template_name="Atlas User Group Revision",
            instance_prefix=GROUP_REVISION_INSTANCE_PREFIX,
            instance_polymorphic_identity="actor_instance",
        )
        self._ensure_template(
            template_code=GROUP_MEMBERSHIP_TEMPLATE_CODE,
            template_name="Atlas User Group Membership",
            instance_prefix=GROUP_MEMBERSHIP_INSTANCE_PREFIX,
            instance_polymorphic_identity="actor_instance",
        )

        self._templates_bootstrapped = True
        self.db.flush()

    def _ensure_template(
        self,
        template_code: str,
        template_name: str,
        instance_prefix: str,
        instance_polymorphic_identity: str,
    ) -> generic_template:
        category, type_, subtype, version = _parse_template_code(template_code)
        self._ensure_prefix_sequence(instance_prefix)

        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is not None:
            if existing.is_deleted:
                existing.is_deleted = False
            return existing

        template = generic_template(
            name=template_name,
            polymorphic_discriminator="actor_template",
            category=category,
            type=type_,
            subtype=subtype,
            version=version,
            instance_prefix=instance_prefix,
            instance_polymorphic_identity=instance_polymorphic_identity,
            json_addl={"managed_by": "lsmc-atlas", "domain": "groups"},
            bstatus="active",
            is_singleton=False,
            is_deleted=False,
        )
        self.db.add(template)
        self.db.flush()
        self.templates.clear_cache()
        return template

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _find_group_instance_by_code(self, group_code: str) -> generic_instance | None:
        stmt = (
            select(generic_instance)
            .where(
                *self._instance_template_filters(GROUP_TEMPLATE_CODE),
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        normalized_code = group_code.strip().upper()
        for candidate in self.db.execute(stmt).scalars().all():
            props = self._instance_properties(candidate)
            code = str(props.get("group_code", "")).strip().upper()
            if code == normalized_code:
                return candidate
        return None

    def _resolve_group_instance(self, group_euid: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, GROUP_TEMPLATE_CODE, group_euid)

    def _find_latest_group_revision(
        self, group_instance: generic_instance
    ) -> generic_instance | None:
        revisions = get_child_instances(self.db, group_instance, GROUP_REVISION_TEMPLATE_CODE)
        if not revisions:
            return None
        revisions.sort(key=self._revision_sort_key, reverse=True)
        return revisions[0]

    def _list_membership_instances(
        self, group_instance: generic_instance
    ) -> list[generic_instance]:
        return get_child_instances(self.db, group_instance, GROUP_MEMBERSHIP_TEMPLATE_CODE)

    def _find_membership(
        self, group_instance: generic_instance, user_id: uuid.UUID
    ) -> generic_instance | None:
        needle = str(user_id)
        for instance in self._list_membership_instances(group_instance):
            props = self._instance_properties(instance)
            if str(props.get("user_id", "")).strip() == needle:
                return instance
        return None

    def _instance_template_filters(self, template_code: str) -> list[Any]:
        category, type_, subtype, version = _parse_template_code(template_code)
        return [
            generic_instance.category == category,
            generic_instance.type == type_,
            generic_instance.subtype == subtype,
            generic_instance.version == version,
        ]

    def _revision_sort_key(self, revision: generic_instance) -> tuple[int, datetime]:
        props = self._instance_properties(revision)
        revision_no = int(props.get("revision_no") or 0)
        created_dt = revision.created_dt or datetime.min.replace(tzinfo=UTC)
        return (revision_no, created_dt)

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _write_instance_properties(self, instance: generic_instance, props: dict[str, Any]) -> None:
        json_addl = dict(instance.json_addl or {})
        json_addl["properties"] = props
        instance.json_addl = json_addl
        flag_modified(instance, "json_addl")

    def _to_group_record(self, instance: generic_instance) -> TapdbGroupRecord:
        props = self._instance_properties(instance)
        return TapdbGroupRecord(
            euid=instance.euid,
            group_code=str(props.get("group_code") or instance.name),
            tenant_id=_parse_uuid(props.get("tenant_id")),
            created_at=instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_revision_record(
        self,
        instance: generic_instance,
    ) -> TapdbGroupRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbGroupRevisionRecord(
            euid=instance.euid,
            group_id=str(props.get("group_id") or ""),
            revision_no=int(props.get("revision_no") or 1),
            name=str(props.get("name") or instance.name),
            description=props.get("description"),
            access_scope=str(props.get("access_scope") or "TENANT"),
            default_roles=props.get("default_roles"),
            is_system_group=bool(props.get("is_system_group", False)),
            is_active=bool(props.get("is_active", True)),
            created_at=instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_membership_record(
        self,
        instance: generic_instance,
    ) -> TapdbGroupMembershipRecord:
        props = self._instance_properties(instance)
        user_id = _parse_uuid(props.get("user_id")) or uuid.UUID(int=0)
        return TapdbGroupMembershipRecord(
            euid=instance.euid,
            user_id=user_id,
            group_id=str(props.get("group_id") or ""),
            joined_at=instance.created_dt,
            added_by=_parse_uuid(props.get("added_by")),
            is_active=bool(props.get("is_active", True)),
            deactivated_at=_to_dt(props.get("deactivated_at")),
            deactivated_by=_parse_uuid(props.get("deactivated_by")),
        )
        return None
