"""TapDB-backed repository adapter for Atlas webhooks."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import Select, or_, select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_instance_by_euid

WEBHOOK_TEMPLATE_CODE = "atlas/events/webhook-subscription/1.0/"
WEBHOOK_REV_TEMPLATE_CODE = "atlas/events/webhook-subscription-revision/1.0/"
WEBHOOK_LOG_TEMPLATE_CODE = "atlas/events/webhook-delivery/1.0/"

WEBHOOK_PREFIX = "WHS"
WEBHOOK_REV_PREFIX = "WHR"
WEBHOOK_LOG_PREFIX = "WHG"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


def _build_subscription_select(tenant_id: uuid.UUID, skip: int, limit: int) -> Select:
    category, type_, subtype, version = _parse_template_code(WEBHOOK_TEMPLATE_CODE)
    tenant_key = str(tenant_id)
    tenant_prop = generic_instance.json_addl["properties"]["tenant_id"].as_string()
    return (
        select(generic_instance)
        .where(
            generic_instance.category == category,
            generic_instance.type == type_,
            generic_instance.subtype == subtype,
            generic_instance.version == version,
            generic_instance.is_deleted.is_(False),
            or_(
                generic_instance.tenant_id == tenant_id,
                tenant_prop == tenant_key,
            ),
        )
        .order_by(generic_instance.created_dt.desc())
        .offset(skip)
        .limit(limit)
    )


def _build_latest_revision_select(subscription_id: str) -> Select:
    category, type_, subtype, version = _parse_template_code(WEBHOOK_REV_TEMPLATE_CODE)
    subscription_prop = generic_instance.json_addl["properties"]["subscription_id"].as_string()
    revision_no = generic_instance.json_addl["properties"]["revision_no"].as_integer()
    return (
        select(generic_instance)
        .where(
            generic_instance.category == category,
            generic_instance.type == type_,
            generic_instance.subtype == subtype,
            generic_instance.version == version,
            generic_instance.is_deleted.is_(False),
            subscription_prop == subscription_id,
        )
        .order_by(revision_no.desc().nullslast(), generic_instance.created_dt.desc())
        .limit(1)
    )


@dataclass
class TapdbWebhookSubscriptionRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    subscription_name: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbWebhookSubscriptionRevisionRecord:
    subscription_id: str
    revision_id: str
    revision_no: int
    url: str
    secret: str
    event_types: list[str]
    is_active: bool
    headers: dict | None
    timeout_seconds: int
    max_retries: int
    note: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbWebhookDeliveryLogRecord:
    euid: str
    tenant_id: uuid.UUID
    subscription_id: str
    event_type: str
    event_id: str
    payload: dict
    url: str
    attempt_number: int
    http_status: int | None
    response_body: str | None
    error_message: str | None
    delivered_at: datetime | None


class TapdbWebhookRepository:
    """Webhook persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_subscription(
        self,
        tenant_id: uuid.UUID,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbWebhookSubscriptionRecord, TapdbWebhookSubscriptionRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        subscription_props = {
            "tenant_id": str(tenant_id),
            "site_id": str(getattr(data, "site_id", "") or ""),
            "subscription_name": data.subscription_name,
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }

        subscription_instance = self.factory.create_instance(
            session=self.db,
            template_code=WEBHOOK_TEMPLATE_CODE,
            name=data.subscription_name,
            properties=subscription_props,
            tenant_id=tenant_id,
        )
        subscription_euid = subscription_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=WEBHOOK_REV_TEMPLATE_CODE,
            name=f"{data.subscription_name}-rev-1",
            properties={
                "subscription_id": subscription_euid,
                "revision_no": 1,
                "url": data.url,
                "secret": data.secret,
                "event_types": data.event_types,
                "is_active": True,
                "headers": data.headers,
                "timeout_seconds": data.timeout_seconds,
                "max_retries": data.max_retries,
                "note": None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
            tenant_id=tenant_id,
        )
        self.factory.link_instances(
            session=self.db,
            parent=subscription_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_subscription(subscription_instance), self._to_revision(revision_instance)

    def get_subscription(
        self,
        subscription_id: str,
        tenant_id: uuid.UUID,
    ) -> tuple[TapdbWebhookSubscriptionRecord, TapdbWebhookSubscriptionRevisionRecord] | None:
        subscription = self._get_subscription_by_id(subscription_id, tenant_id)
        if subscription is None:
            return None
        revision = self.get_latest_revision(subscription_id)
        if revision is None:
            return None
        return subscription, revision

    def list_subscriptions(
        self,
        tenant_id: uuid.UUID,
        skip: int = 0,
        limit: int = 100,
    ) -> list[tuple[TapdbWebhookSubscriptionRecord, TapdbWebhookSubscriptionRevisionRecord]]:
        rows: list[
            tuple[TapdbWebhookSubscriptionRecord, TapdbWebhookSubscriptionRevisionRecord]
        ] = []
        for instance in (
            self.db.execute(_build_subscription_select(tenant_id=tenant_id, skip=skip, limit=limit))
            .scalars()
            .all()
        ):
            subscription = self._to_subscription(instance)
            revision = self.get_latest_revision(subscription.euid)
            if revision is None:
                continue
            rows.append((subscription, revision))
        return rows

    def update_subscription(
        self,
        tenant_id: uuid.UUID,
        subscription_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
    ) -> tuple[TapdbWebhookSubscriptionRecord, TapdbWebhookSubscriptionRevisionRecord] | None:
        result = self.get_subscription(subscription_id, tenant_id)
        if result is None:
            return None
        subscription, current_revision = result
        now = datetime.now(UTC)

        revision = self.factory.create_instance(
            session=self.db,
            template_code=WEBHOOK_REV_TEMPLATE_CODE,
            name=f"{subscription.subscription_name}-rev-{current_revision.revision_no + 1}",
            properties={
                "subscription_id": subscription_id,
                "revision_no": current_revision.revision_no + 1,
                "url": data.url if data.url is not None else current_revision.url,
                "secret": data.secret if data.secret is not None else current_revision.secret,
                "event_types": (
                    data.event_types
                    if data.event_types is not None
                    else current_revision.event_types
                ),
                "is_active": (
                    data.is_active if data.is_active is not None else current_revision.is_active
                ),
                "headers": data.headers if data.headers is not None else current_revision.headers,
                "timeout_seconds": (
                    data.timeout_seconds
                    if data.timeout_seconds is not None
                    else current_revision.timeout_seconds
                ),
                "max_retries": (
                    data.max_retries
                    if data.max_retries is not None
                    else current_revision.max_retries
                ),
                "note": data.note,
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
            },
            tenant_id=tenant_id,
        )
        subscription_instance = get_instance_by_euid(
            self.db, WEBHOOK_TEMPLATE_CODE, subscription_id
        )
        if subscription_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=subscription_instance,
                child=revision,
                relationship_type="revision",
            )
        self.db.commit()
        return subscription, self._to_revision(revision)

    def list_active_subscriptions_for_event(
        self,
        tenant_id: uuid.UUID,
        event_type: str,
    ) -> list[tuple[TapdbWebhookSubscriptionRecord, TapdbWebhookSubscriptionRevisionRecord]]:
        rows = self.list_subscriptions(tenant_id=tenant_id, skip=0, limit=1_000_000)
        return [
            (subscription, revision)
            for subscription, revision in rows
            if revision.is_active and event_type in revision.event_types
        ]

    def log_delivery(
        self,
        tenant_id: uuid.UUID,
        subscription_id: str,
        event_type: str,
        event_id: str,
        payload: dict,
        url: str,
        attempt_number: int,
        http_status: int | None,
        response_body: str | None,
        error_message: str | None,
    ) -> None:
        self._ensure_templates()
        now = datetime.now(UTC)
        log_props = {
            "tenant_id": str(tenant_id),
            "subscription_id": subscription_id,
            "event_type": event_type,
            "event_id": event_id,
            "payload": payload,
            "url": url,
            "attempt_number": attempt_number,
            "http_status": http_status,
            "response_body": response_body,
            "error_message": error_message,
            "delivered_at": now.isoformat(),
        }

        log_instance = self.factory.create_instance(
            session=self.db,
            template_code=WEBHOOK_LOG_TEMPLATE_CODE,
            name=f"{event_type}-attempt-{attempt_number}",
            properties=log_props,
            tenant_id=tenant_id,
        )

        subscription_instance = get_instance_by_euid(
            self.db, WEBHOOK_TEMPLATE_CODE, subscription_id
        )
        if subscription_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=subscription_instance,
                child=log_instance,
                relationship_type="delivery_log",
            )
        self.db.commit()

    def get_delivery_logs(
        self,
        tenant_id: uuid.UUID,
        subscription_id: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
    ) -> list[TapdbWebhookDeliveryLogRecord]:
        tenant_key = str(tenant_id)
        rows: list[TapdbWebhookDeliveryLogRecord] = []

        for instance in self._instances_for_template(WEBHOOK_LOG_TEMPLATE_CODE):
            log = self._to_delivery_log(instance)
            if str(log.tenant_id) != tenant_key:
                continue
            if subscription_id and log.subscription_id != subscription_id:
                continue
            if event_type and log.event_type != event_type:
                continue
            rows.append(log)

        rows.sort(
            key=lambda row: row.delivered_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[:limit]

    def get_latest_revision(
        self,
        subscription_id: str,
    ) -> TapdbWebhookSubscriptionRevisionRecord | None:
        instance = self.db.execute(
            _build_latest_revision_select(subscription_id=subscription_id)
        ).scalar_one_or_none()
        if instance is None:
            return None
        return self._to_revision(instance)

    def _get_subscription_by_id(
        self,
        subscription_id: str,
        tenant_id: uuid.UUID,
    ) -> TapdbWebhookSubscriptionRecord | None:
        instance = get_instance_by_euid(self.db, WEBHOOK_TEMPLATE_CODE, subscription_id)
        if instance is None or instance.is_deleted:
            return None
        if not self._matches_template(instance, WEBHOOK_TEMPLATE_CODE):
            return None
        subscription = self._to_subscription(instance)
        if str(subscription.tenant_id) != str(tenant_id):
            return None
        return subscription

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            WEBHOOK_TEMPLATE_CODE,
            WEBHOOK_PREFIX,
            "Atlas Webhook Subscription",
            {"managed_by": "lsmc-atlas", "domain": "webhooks"},
        )
        self._ensure_template(
            WEBHOOK_REV_TEMPLATE_CODE,
            WEBHOOK_REV_PREFIX,
            "Atlas Webhook Subscription Revision",
            {"managed_by": "lsmc-atlas", "domain": "webhooks"},
        )
        self._ensure_template(
            WEBHOOK_LOG_TEMPLATE_CODE,
            WEBHOOK_LOG_PREFIX,
            "Atlas Webhook Delivery Log",
            {"managed_by": "lsmc-atlas", "domain": "webhooks"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_subscription(self, instance: generic_instance) -> TapdbWebhookSubscriptionRecord:
        props = self._instance_properties(instance)
        return TapdbWebhookSubscriptionRecord(
            euid=instance.euid,
            tenant_id=instance.tenant_id or _parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            subscription_name=str(props.get("subscription_name") or instance.name),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_revision(self, instance: generic_instance) -> TapdbWebhookSubscriptionRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbWebhookSubscriptionRevisionRecord(
            subscription_id=str(props.get("subscription_id") or ""),
            revision_id=instance.euid,
            revision_no=int(props.get("revision_no") or 1),
            url=str(props.get("url") or ""),
            secret=str(props.get("secret") or ""),
            event_types=[str(item) for item in (props.get("event_types") or [])],
            is_active=bool(props.get("is_active", True)),
            headers=props.get("headers"),
            timeout_seconds=int(props.get("timeout_seconds") or 30),
            max_retries=int(props.get("max_retries") or 3),
            note=props.get("note"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_delivery_log(self, instance: generic_instance) -> TapdbWebhookDeliveryLogRecord:
        props = self._instance_properties(instance)
        return TapdbWebhookDeliveryLogRecord(
            euid=instance.euid,
            tenant_id=instance.tenant_id or _parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            subscription_id=str(props.get("subscription_id") or ""),
            event_type=str(props.get("event_type") or ""),
            event_id=str(props.get("event_id") or ""),
            payload=props.get("payload") or {},
            url=str(props.get("url") or ""),
            attempt_number=int(props.get("attempt_number") or 1),
            http_status=(
                int(props.get("http_status")) if props.get("http_status") is not None else None
            ),
            response_body=props.get("response_body"),
            error_message=props.get("error_message"),
            delivered_at=_to_dt(props.get("delivered_at")) or instance.created_dt,
        )
