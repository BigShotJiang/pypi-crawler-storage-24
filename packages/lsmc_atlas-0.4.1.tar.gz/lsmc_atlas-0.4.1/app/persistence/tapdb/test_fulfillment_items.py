"""TapDB-backed persistence for Atlas test fulfillment items."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import (
    get_child_instances,
    get_instance_by_euid,
    get_parent_instances,
)
from app.persistence.tapdb.trfs import TEST_TEMPLATE_CODE

TEST_FULFILLMENT_ITEM_TEMPLATE_CODE = "atlas/requisition/test-fulfillment-item/1.0/"
TEST_FULFILLMENT_ITEM_PREFIX = "TFM"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbTestFulfillmentItemRecord:
    euid: str
    tenant_id: uuid.UUID
    test_euid: str
    required_material_type: str | None
    platform: str | None
    routing_hint: str | None
    intake_policy: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


class TapdbTestFulfillmentItemRepository:
    """Persistence adapter for fulfillment items linked to Atlas Tests."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_fulfillment_item(
        self,
        *,
        tenant_id: uuid.UUID,
        test_euid: str,
        required_material_type: str | None,
        platform: str | None,
        routing_hint: str | None,
        intake_policy: str | None,
        created_by: uuid.UUID | None,
    ) -> TapdbTestFulfillmentItemRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_euid)
        if test_instance is None or test_instance.is_deleted:
            raise ValueError(f"Test not found: {test_euid}")

        instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_FULFILLMENT_ITEM_TEMPLATE_CODE,
            name=f"fulfillment-item:{test_euid}",
            properties={
                "tenant_id": str(tenant_id),
                "required_material_type": required_material_type,
                "platform": platform,
                "routing_hint": routing_hint,
                "intake_policy": intake_policy,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_instance,
            child=instance,
            relationship_type="fulfillment_item",
        )
        self.db.flush()
        return self._to_fulfillment_item(instance)

    def get_fulfillment_item(
        self,
        fulfillment_item_euid: str,
    ) -> TapdbTestFulfillmentItemRecord | None:
        instance = get_instance_by_euid(
            self.db,
            TEST_FULFILLMENT_ITEM_TEMPLATE_CODE,
            fulfillment_item_euid,
        )
        if instance is None or instance.is_deleted:
            return None
        return self._to_fulfillment_item(instance)

    def list_fulfillment_items_for_test(
        self,
        *,
        test_euid: str,
        tenant_id: uuid.UUID | None,
    ) -> list[TapdbTestFulfillmentItemRecord]:
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_euid)
        if test_instance is None or test_instance.is_deleted:
            return []
        rows = [
            self._to_fulfillment_item(child)
            for child in get_child_instances(
                self.db, test_instance, TEST_FULFILLMENT_ITEM_TEMPLATE_CODE
            )
        ]
        if tenant_id is not None:
            rows = [row for row in rows if row.tenant_id == tenant_id]
        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC))
        return rows

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_prefix_sequence(TEST_FULFILLMENT_ITEM_PREFIX)
        category, type_, subtype, version = _parse_template_code(TEST_FULFILLMENT_ITEM_TEMPLATE_CODE)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name="Atlas Test Fulfillment Item",
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=TEST_FULFILLMENT_ITEM_PREFIX,
                    instance_polymorphic_identity="actor_instance",
                    json_addl={"managed_by": "lsmc-atlas", "domain": "requisition"},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        elif existing.instance_prefix != TEST_FULFILLMENT_ITEM_PREFIX:
            existing.instance_prefix = TEST_FULFILLMENT_ITEM_PREFIX
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties") if isinstance(raw, dict) else None
        return dict(props) if isinstance(props, dict) else {}

    def _to_fulfillment_item(self, instance: generic_instance) -> TapdbTestFulfillmentItemRecord:
        props = self._instance_properties(instance)
        parent_tests = get_parent_instances(self.db, instance, TEST_TEMPLATE_CODE)
        test_euid = parent_tests[0].euid if parent_tests else ""
        return TapdbTestFulfillmentItemRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            test_euid=str(test_euid or ""),
            required_material_type=(
                str(props.get("required_material_type"))
                if props.get("required_material_type")
                else None
            ),
            platform=str(props.get("platform")) if props.get("platform") else None,
            routing_hint=str(props.get("routing_hint")) if props.get("routing_hint") else None,
            intake_policy=str(props.get("intake_policy")) if props.get("intake_policy") else None,
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )
