"""LSMC Hub - Delivery Models (Artifact, ReleasePackage)."""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, String, text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class ReleasePackageStatus(StrEnum):
    """ReleasePackage status values."""

    DRAFT = "DRAFT"
    PENDING_REVIEW = "PENDING_REVIEW"
    APPROVED = "APPROVED"
    RELEASED = "RELEASED"
    REVOKED = "REVOKED"


class Artifact(Base):
    """
    Artifact table (immutable, non-authoritative).

    Artifacts are references to reports/data produced by LIMS or other systems.
    Hub is NOT authoritative for these - it stores:
    - source_system: where the artifact came from
    - source_uid: the authoritative ID in that system
    - checksum: to verify integrity

    Artifacts are immutable - they are never updated, only referenced.
    """

    __tablename__ = "artifact"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Source system info (Hub is NOT authoritative)
    source_system: Mapped[str] = mapped_column(String(100), nullable=False)
    source_uid: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    # File info
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    content_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    size_bytes: Mapped[int | None] = mapped_column(nullable=True)

    # Integrity
    checksum_algorithm: Mapped[str] = mapped_column(String(20), nullable=False, default="sha256")
    checksum: Mapped[str] = mapped_column(String(128), nullable=False)

    # S3 location (copy of the artifact)
    s3_bucket: Mapped[str | None] = mapped_column(String(255), nullable=True)
    s3_key: Mapped[str | None] = mapped_column(String(1024), nullable=True)

    # Artifact type (e.g., "report_pdf", "vcf", "bam", "fastq")
    artifact_type: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Additional metadata (named artifact_metadata to avoid SQLAlchemy reserved name)
    artifact_metadata: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Optional linkage to Order (for filtering artifacts by order)
    order_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("order.id"),
        nullable=True,
        index=True,
    )

    # Optional linkage to FulfillmentRun (for filtering artifacts by assay run)
    fulfillment_run_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("assay_run.id"),
        nullable=True,
        index=True,
    )

    # Audit (immutable after creation)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )


class ReleasePackage(Base):
    """
    ReleasePackage identity table.

    ReleasePackages bundle artifacts for delivery to clients.
    The same artifact can be included in multiple release packages.
    """

    __tablename__ = "release_package"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Human-readable package number
    package_number: Mapped[str] = mapped_column(String(50), nullable=False, unique=True, index=True)

    # Associated order
    order_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("order.id"),
        nullable=True,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["ReleasePackageRevision"]] = relationship(
        back_populates="release_package",
        order_by="ReleasePackageRevision.revision_no",
    )


class ReleasePackageRevision(Base):
    """ReleasePackage revision table."""

    __tablename__ = "release_package_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    release_package_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("release_package.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Status
    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=ReleasePackageStatus.DRAFT.value
    )

    # Artifact IDs included in this release
    artifact_ids: Mapped[list[str]] = mapped_column(ARRAY(UUID), nullable=False, default=list)

    # Release info
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    released_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Notes
    release_notes: Mapped[str | None] = mapped_column(nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    release_package: Mapped["ReleasePackage"] = relationship(back_populates="revisions")
