"""LSMC Atlas - Error Log Model.

Append-only table for persisting application error logs.
Stores unhandled exceptions with trace IDs for debugging and audit.

IMPORTANT: No PHI/PII is stored here beyond username (email).
Stack traces and request paths are safe to log (they are server internals).
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, String, Text, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.persistence.tapdb.orm_models.base import Base


class ErrorLog(Base):
    """
    Error log table (append-only).

    Records unhandled application exceptions for internal audit and debugging.
    Each row corresponds to one invocation of the global exception handler.
    """

    __tablename__ = "error_log"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    # Trace ID shown to the user — the correlation key
    trace_id: Mapped[str] = mapped_column(
        String(36),
        nullable=False,
        unique=True,
        index=True,
    )

    # Timestamp of the error (UTC)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        index=True,
    )

    # Request context
    method: Mapped[str] = mapped_column(String(10), nullable=False)
    path: Mapped[str] = mapped_column(String(2048), nullable=False)
    username: Mapped[str] = mapped_column(String(255), nullable=False, default="anonymous")
    client_ip: Mapped[str | None] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)

    # Exception info
    exception_type: Mapped[str] = mapped_column(String(255), nullable=False)
    exception_message: Mapped[str] = mapped_column(Text, nullable=False)
    stack_trace: Mapped[str | None] = mapped_column(Text, nullable=True)

    # HTTP status returned to user (usually 500)
    status_code: Mapped[int] = mapped_column(nullable=False, default=500)

    # Whether the error was resolved/acknowledged (for internal triage)
    resolved: Mapped[bool] = mapped_column(nullable=False, default=False)
