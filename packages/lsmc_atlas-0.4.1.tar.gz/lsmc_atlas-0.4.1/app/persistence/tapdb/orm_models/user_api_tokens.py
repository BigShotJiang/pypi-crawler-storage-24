"""LSMC Hub - User API Token Models.

Provides user-facing API token management:
- UserAPIToken: Token identity (created by users with API_ACCESS group)
- UserAPITokenRevision: Token metadata revisions (append-only)
- UserAPITokenUsageLog: Usage tracking for monitoring and audit
"""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class TokenStatus(StrEnum):
    """API token status."""

    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"


class TokenScope(StrEnum):
    """API token access scope.

    Controls the maximum effective permissions a token can have,
    regardless of the owning user's actual roles.
    """

    EXT_ORG = "ext_org"  # Tenant-scoped external access (max: EXTERNAL_USER)
    LSMC_INTERNAL = "lsmc_internal"  # LSMC staff cross-tenant access (max: INTERNAL_USER)
    ATLAS_ADMIN = "atlas_admin"  # Full admin API access (no constraint)


class UserAPIToken(Base):
    """User API Token identity table.

    Represents a personal API token created by a user with API_ACCESS group membership.
    Token scope constrains effective permissions regardless of the owning user's roles.
    """

    __tablename__ = "user_api_token"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Owner of the token (user who created it)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
        index=True,
    )

    # Token name/description for user reference
    token_name: Mapped[str] = mapped_column(String(100), nullable=False)

    # Token prefix for identification in logs (e.g., "lsmc_abc123...")
    token_prefix: Mapped[str] = mapped_column(String(20), nullable=False)

    # Token scope — constrains effective permissions
    scope: Mapped[str] = mapped_column(String(30), nullable=False, default=TokenScope.EXT_ORG.value)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    # Relationships
    revisions: Mapped[list["UserAPITokenRevision"]] = relationship(
        back_populates="token",
        order_by="UserAPITokenRevision.revision_no",
    )
    usage_logs: Mapped[list["UserAPITokenUsageLog"]] = relationship(
        back_populates="token",
    )


class UserAPITokenRevision(Base):
    """User API Token revision table (append-only).

    Tracks changes to token configuration and status.
    """

    __tablename__ = "user_api_token_revision"

    token_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("user_api_token.id"),
        primary_key=True,
    )

    revision_no: Mapped[int] = mapped_column(Integer, primary_key=True)

    # Hashed token value (never store plaintext)
    token_hash: Mapped[str] = mapped_column(String(128), nullable=False, index=True)

    # Token status
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=TokenStatus.ACTIVE.value
    )

    # Expiration
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    # Last used timestamp (updated on each use)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Revocation info (if revoked)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    revocation_reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Revision metadata
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Relationships
    token: Mapped["UserAPIToken"] = relationship(back_populates="revisions")

    __table_args__ = (
        Index("ix_user_api_token_revision_token", "token_id"),
        Index("ix_user_api_token_revision_hash", "token_hash"),
        Index("ix_user_api_token_revision_status", "status"),
    )


class UserAPITokenUsageLog(Base):
    """User API Token usage log table (append-only).

    Tracks API usage for monitoring, audit, and rate limiting.
    """

    __tablename__ = "user_api_token_usage_log"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    token_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("user_api_token.id"),
        nullable=False,
        index=True,
    )

    # Request details
    endpoint: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    http_method: Mapped[str] = mapped_column(String(10), nullable=False)
    response_status: Mapped[int] = mapped_column(Integer, nullable=False)

    # Security context
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)

    # Timing
    request_timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
        index=True,
    )

    # Optional request/response metadata (no PHI!)
    request_metadata: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Relationships
    token: Mapped["UserAPIToken"] = relationship(back_populates="usage_logs")

    __table_args__ = (
        Index("ix_user_api_token_usage_log_token", "token_id"),
        Index("ix_user_api_token_usage_log_endpoint", "endpoint"),
        Index("ix_user_api_token_usage_log_timestamp", "request_timestamp"),
    )
