"""LSMC Hub - Ordering Models (Order, TestOrder, AssayRef)."""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, String, text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class OrderStatus(StrEnum):
    """Order status values.

    As of Step 7, order status is derived from assay run states.
    The derived values are: DRAFT, ORDERED, IN_PROGRESS, QC_HOLD, RESULTS_READY, CLOSED_NO_RESULTS.

    Legacy values (SUBMITTED, RECEIVING_IN_PROGRESS, ACTIVE, COMPLETED_REPORT_READY)
    are kept for backward compatibility with existing revisions.
    """

    # New derived statuses (from assay states per Step 7)
    DRAFT = "DRAFT"
    ORDERED = "ORDERED"  # Any assay is ORDERED or RECEIVED
    IN_PROGRESS = "IN_PROGRESS"  # Any assay is ACCESSIONED or IN_PROGRESS
    QC_HOLD = "QC_HOLD"  # Any assay is QC_HOLD
    RESULTS_READY = "RESULTS_READY"  # All assays terminal, at least one has results
    CLOSED_NO_RESULTS = "CLOSED_NO_RESULTS"  # All assays terminal, none have results

    # Legacy statuses (still valid in database, but no longer used for new rollups)
    SUBMITTED = "SUBMITTED"  # Legacy: mapped to ORDERED
    ABANDONED = "ABANDONED"
    RECEIVING_IN_PROGRESS = "RECEIVING_IN_PROGRESS"  # Legacy: mapped to ORDERED
    ON_HOLD = "ON_HOLD"  # Legacy: mapped to QC_HOLD
    ACTIVE = "ACTIVE"  # Legacy: mapped to IN_PROGRESS
    COMPLETED_REPORT_READY = "COMPLETED_REPORT_READY"  # Legacy: mapped to RESULTS_READY
    RELEASED = "RELEASED"  # Still used for published results sets
    AMENDED = "AMENDED"  # Still used for amendments
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"


class OrderType(StrEnum):
    """Order type values."""

    RESEARCH = "RESEARCH"
    CLINICAL = "CLINICAL"
    OTHER = "OTHER"


class TestOrderStatus(StrEnum):
    """TestOrder status values."""

    PENDING = "PENDING"
    SPECIMEN_RECEIVED = "SPECIMEN_RECEIVED"
    IN_PROGRESS = "IN_PROGRESS"
    FAILED = "FAILED"
    ON_HOLD = "ON_HOLD"
    COMPLETED = "COMPLETED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"


class Order(Base):
    """
    Order identity table.

    Orders represent a clinical request (digital TRF equivalent).
    Order.product_orders = 1..* TestOrder
    """

    __tablename__ = "order"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Human-readable order number (e.g., ORD-2024-00001)
    order_number: Mapped[str] = mapped_column(String(50), nullable=False, unique=True, index=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["OrderRevision"]] = relationship(
        back_populates="order",
        order_by="OrderRevision.revision_no",
    )
    test_orders: Mapped[list["TestOrder"]] = relationship(
        back_populates="order",
    )


class OrderRevision(Base):
    """
    Order revision table (append-only snapshots).

    Contains order data that can change over time.
    """

    __tablename__ = "order_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    order_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("order.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Patient reference
    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("patient.id"),
        nullable=False,
    )

    # Ordering clinician
    clinician_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("clinician.id"),
        nullable=True,
    )

    # Order type (Research, Clinical, Other)
    order_type: Mapped[str] = mapped_column(
        String(50), nullable=False, default=OrderType.CLINICAL.value
    )

    # Order status (computed/rollup but stored for query efficiency)
    status: Mapped[str] = mapped_column(String(50), nullable=False, default=OrderStatus.DRAFT.value)

    # Priority
    is_stat: Mapped[bool] = mapped_column(nullable=False, default=False)
    priority_notes: Mapped[str | None] = mapped_column(nullable=True)

    # Clinical context
    indication: Mapped[str | None] = mapped_column(nullable=True)
    clinical_notes: Mapped[str | None] = mapped_column(nullable=True)
    icd10_codes: Mapped[list[str] | None] = mapped_column(ARRAY(String), nullable=True)

    # Billing info (stored as JSON for flexibility)
    billing_info: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Dates
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    order: Mapped["Order"] = relationship(back_populates="revisions")


class TestOrder(Base):
    """
    TestOrder identity table.

    TestOrders represent individual tests within an Order.
    TestOrder.assays = 1..* AssayRef
    External material objects link to TestOrders via LinkEvent (many-to-many).
    """

    __tablename__ = "test_order"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    order_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("order.id"),
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    order: Mapped["Order"] = relationship(back_populates="test_orders")
    revisions: Mapped[list["TestOrderRevision"]] = relationship(
        back_populates="test_order",
        order_by="TestOrderRevision.revision_no",
    )


class TestOrderRevision(Base):
    """TestOrder revision table (append-only snapshots)."""

    __tablename__ = "test_order_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    test_order_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("test_order.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Test type / product
    product_code: Mapped[str] = mapped_column(String(100), nullable=False)
    product_name: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Assays (list of assay codes)
    fulfillment_route_codes: Mapped[list[str]] = mapped_column(ARRAY(String), nullable=False)

    # Status
    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=TestOrderStatus.PENDING.value
    )

    # Specimen requirements
    specimen_type_required: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Notes
    special_instructions: Mapped[str | None] = mapped_column(nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    test_order: Mapped["TestOrder"] = relationship(back_populates="revisions")


class AssayRef(Base):
    """
    Assay reference/catalog table.

    This is a placeholder catalog of available assays.
    In production, this might be synced from a LIMS or external system.
    """

    __tablename__ = "assay_ref"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    # Assay identification
    code: Mapped[str] = mapped_column(String(50), nullable=False, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(nullable=True)

    # Category (e.g., "whole_genome", "exome", "panel")
    category: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Technology (e.g., "short_read", "long_read", "hybrid")
    technology: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Specimen requirements
    specimen_types: Mapped[list[str] | None] = mapped_column(ARRAY(String), nullable=True)

    # Status
    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
