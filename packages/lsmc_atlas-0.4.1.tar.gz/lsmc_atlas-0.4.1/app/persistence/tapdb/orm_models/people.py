"""LSMC Hub - People Models (Patient, Clinician)."""

import uuid
from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, String, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class Patient(Base):
    """
    Patient identity table.

    Patients belong to a tenant (organization). This table is immutable.
    Family relationships are tracked in PatientRevision.
    """

    __tablename__ = "patient"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["PatientRevision"]] = relationship(
        back_populates="patient",
        order_by="PatientRevision.revision_no",
    )


class PatientRevision(Base):
    """
    Patient revision table (append-only snapshots).

    Contains the actual patient data that can change over time.
    """

    __tablename__ = "patient_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("patient.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Patient demographics
    first_name: Mapped[str] = mapped_column(String(255), nullable=False)
    last_name: Mapped[str] = mapped_column(String(255), nullable=False)
    middle_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    date_of_birth: Mapped[date | None] = mapped_column(Date, nullable=True)
    sex: Mapped[str | None] = mapped_column(String(20), nullable=True)  # M, F, Other, Unknown

    # External identifiers (MRN, etc.) - stored in external_identifier table
    # but we keep a denormalized MRN here for convenience
    mrn: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)

    # Contact info
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    address: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Family relationships (references to other PatientIDs)
    # e.g., {"mother": "uuid", "father": "uuid", "proband": true}
    family_relationships: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Additional clinical context
    clinical_notes: Mapped[str | None] = mapped_column(nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    patient: Mapped["Patient"] = relationship(back_populates="revisions")


class Clinician(Base):
    """
    Clinician identity table.

    Clinicians can be associated with multiple organizations (via ClinicianRevision).
    """

    __tablename__ = "clinician"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["ClinicianRevision"]] = relationship(
        back_populates="clinician",
        order_by="ClinicianRevision.revision_no",
    )


class ClinicianRevision(Base):
    """
    Clinician revision table (append-only snapshots).

    Contains clinician data including NPI, specialty, contact info.
    """

    __tablename__ = "clinician_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    clinician_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("clinician.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Clinician info
    first_name: Mapped[str] = mapped_column(String(255), nullable=False)
    last_name: Mapped[str] = mapped_column(String(255), nullable=False)
    credentials: Mapped[str | None] = mapped_column(String(100), nullable=True)  # MD, DO, PhD, etc.

    # NPI (National Provider Identifier)
    npi: Mapped[str | None] = mapped_column(String(20), nullable=True, index=True)

    # Specialty
    specialty: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Contact info
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    fax: Mapped[str | None] = mapped_column(String(50), nullable=True)

    # Practice address(es)
    addresses: Mapped[list[dict] | None] = mapped_column(JSONB, nullable=True)

    # Associated site within the organization
    site_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("site.id"),
        nullable=True,
    )

    # Status
    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    clinician: Mapped["Clinician"] = relationship(back_populates="revisions")
