"""LSMC Hub - API Client Models.

API client management for external system integration.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.persistence.tapdb.orm_models.base import Base


class APIClient(Base):
    """
    API client table (identity).

    Represents an external system or service that can access the internal API.
    """

    __tablename__ = "api_client"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    client_name: Mapped[str] = mapped_column(String(100), nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    __table_args__ = (Index("ix_api_client_tenant", "tenant_id"),)


class APIClientRevision(Base):
    """
    API client revision table (append-only).

    Tracks changes to API client configuration.
    """

    __tablename__ = "api_client_revision"

    client_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("api_client.id"),
        primary_key=True,
    )

    revision_no: Mapped[int] = mapped_column(primary_key=True)

    api_key: Mapped[str] = mapped_column(String(100), nullable=False, index=True)  # Hashed API key

    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    permissions: Mapped[list[str]] = mapped_column(
        JSONB, nullable=False
    )  # List of allowed operations

    allowed_endpoints: Mapped[list[str] | None] = mapped_column(
        JSONB, nullable=True
    )  # Specific endpoints allowed

    rate_limit_per_minute: Mapped[int | None] = mapped_column(nullable=True)  # Rate limit

    ip_allowed_list: Mapped[list[str] | None] = mapped_column(
        JSONB, nullable=True
    )  # IP allowed list

    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    note: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    __table_args__ = (
        Index("ix_api_client_revision_client", "client_id"),
        Index("ix_api_client_revision_api_key", "api_key"),
        Index("ix_api_client_revision_active", "is_active"),
    )


class APIClientUsageLog(Base):
    """
    API client usage log table (append-only).

    Tracks API usage for monitoring and billing.
    """

    __tablename__ = "api_client_usage_log"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    client_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("api_client.id"),
        nullable=False,
        index=True,
    )

    endpoint: Mapped[str] = mapped_column(String(200), nullable=False, index=True)

    method: Mapped[str] = mapped_column(String(10), nullable=False)

    status_code: Mapped[int] = mapped_column(nullable=False)

    ip_address: Mapped[str | None] = mapped_column(String(50), nullable=True)

    request_size_bytes: Mapped[int | None] = mapped_column(nullable=True)

    response_size_bytes: Mapped[int | None] = mapped_column(nullable=True)

    duration_ms: Mapped[int | None] = mapped_column(nullable=True)

    accessed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
        index=True,
    )

    __table_args__ = (
        Index("ix_api_client_usage_log_tenant", "tenant_id"),
        Index("ix_api_client_usage_log_client", "client_id"),
        Index("ix_api_client_usage_log_accessed_at", "accessed_at"),
    )
