"""LSMC Hub - Exception Models (for intake exception queue)."""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, String, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class ExceptionType(StrEnum):
    """Exception types for intake workflow."""

    MISSING_ID = "MISSING_ID"  # Barcode/ID not found in system
    AMBIGUOUS_MATCH = "AMBIGUOUS_MATCH"  # Multiple possible matches
    MISMATCH = "MISMATCH"  # Data doesn't match expected
    MISSING_DATA = "MISSING_DATA"  # Required data missing
    DAMAGED_SPECIMEN = "DAMAGED_SPECIMEN"  # Physical damage
    WRONG_SPECIMEN_TYPE = "WRONG_SPECIMEN_TYPE"  # Type mismatch
    OTHER = "OTHER"  # Other issues


class ExceptionStatus(StrEnum):
    """Exception resolution status."""

    OPEN = "OPEN"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    RESOLVED = "RESOLVED"
    ESCALATED = "ESCALATED"
    CLOSED = "CLOSED"


class Exception(Base):
    """
    Exception identity table.

    Tracks intake exceptions that require manual intervention.
    """

    __tablename__ = "exception"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Human-readable exception number
    exception_number: Mapped[str] = mapped_column(
        String(50), nullable=False, unique=True, index=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["ExceptionRevision"]] = relationship(
        back_populates="exception",
        order_by="ExceptionRevision.revision_no",
    )


class ExceptionRevision(Base):
    """Exception revision table."""

    __tablename__ = "exception_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    exception_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("exception.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Exception details
    exception_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=ExceptionStatus.OPEN.value, index=True
    )

    # What triggered the exception
    trigger_entity_type: Mapped[str | None] = mapped_column(
        String(50), nullable=True
    )  # e.g., "EXTERNAL_OBJECT", "SHIPMENT"
    trigger_entity_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Scanned/input data that caused the exception
    scanned_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Related entities (optional)
    order_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("order.id"),
        nullable=True,
    )

    external_object_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    shipment_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("shipment.id"),
        nullable=True,
    )

    # Assignment
    assigned_to: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Resolution
    resolution_notes: Mapped[str | None] = mapped_column(nullable=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    resolved_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationship
    exception: Mapped["Exception"] = relationship(back_populates="revisions")
