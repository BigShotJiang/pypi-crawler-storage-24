"""TapDB-backed repository adapter for Atlas TRFs and Tests."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

TRF_TEMPLATE_CODE = "atlas/requisition/trf/1.0/"
TRF_REV_TEMPLATE_CODE = "atlas/requisition/trf-revision/1.0/"
TEST_TEMPLATE_CODE = "atlas/requisition/test/1.0/"
TEST_REV_TEMPLATE_CODE = "atlas/requisition/test-revision/1.0/"

TRF_PREFIX = "TRF"
TRF_REV_PREFIX = "TRR"
TEST_PREFIX = "TST"
TEST_REV_PREFIX = "TSR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


def _as_str_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return []


@dataclass
class TapdbTrfRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    order_number: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbTrfRevisionRecord:
    euid: str
    order_id: str
    revision_no: int
    patient_id: str | None
    clinician_id: str | None
    order_type: str
    status: str
    is_stat: bool
    priority_notes: str | None
    indication: str | None
    clinical_notes: str | None
    icd10_codes: list[str] | None
    billing_info: dict | None
    submitted_at: datetime | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


@dataclass
class TapdbTestRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    order_id: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbTestRevisionRecord:
    euid: str
    test_order_id: str
    revision_no: int
    product_code: str
    product_name: str | None
    fulfillment_route_codes: list[str]
    status: str
    specimen_type_required: str | None
    specimen_type: str | None
    priority: str
    special_instructions: str | None
    clinical_notes: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


class TapdbTrfRepository:
    """TRF/Test persistence backed by TapDB templates and instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_trf(
        self,
        *,
        tenant_id: uuid.UUID,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbTrfRecord, TapdbTrfRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)

        trf_instance = self.factory.create_instance(
            session=self.db,
            template_code=TRF_TEMPLATE_CODE,
            name="trf",
            properties={
                "tenant_id": str(tenant_id),
                "site_id": str(getattr(data, "site_id", "") or ""),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        trf_euid = trf_instance.euid
        trf_props = self._instance_properties(trf_instance)
        trf_props["order_number"] = trf_euid
        trf_instance.name = trf_euid
        trf_instance.json_addl = {"properties": trf_props}

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TRF_REV_TEMPLATE_CODE,
            name=f"{trf_euid}-rev-1",
            properties={
                "order_id": trf_euid,
                "revision_no": 1,
                "clinician_id": str(data.clinician_id) if data.clinician_id else None,
                "order_type": str(data.order_type),
                "status": "DRAFT",
                "is_stat": bool(data.is_stat),
                "priority_notes": data.priority_notes,
                "indication": data.indication,
                "clinical_notes": data.clinical_notes,
                "icd10_codes": data.icd10_codes,
                "billing_info": data.billing_info,
                "submitted_at": None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=trf_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_trf(trf_instance), self._to_trf_revision(revision_instance)

    def create_test(
        self,
        *,
        tenant_id: uuid.UUID,
        trf_id: str,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbTestRecord, TapdbTestRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)

        fulfillment_route_codes = self._resolved_fulfillment_route_codes(data)
        product_code = getattr(data, "product_code", None) or (
            fulfillment_route_codes[0] if fulfillment_route_codes else "GEN"
        )
        specimen_type_required = getattr(data, "specimen_type_required", None) or getattr(
            data, "specimen_type", None
        )
        special_instructions = getattr(data, "special_instructions", None) or getattr(
            data, "clinical_notes", None
        )
        priority = getattr(data, "priority", None) or "NORMAL"

        test_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_TEMPLATE_CODE,
            name=f"{product_code}-test",
            properties={
                "tenant_id": str(tenant_id),
                "site_id": str(getattr(data, "site_id", "") or ""),
                "order_id": str(trf_id),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        test_instance.name = test_instance.euid

        trf_instance = self._resolve_trf_instance(trf_id)
        if trf_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=trf_instance,
                child=test_instance,
                relationship_type="contains",
            )

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_REV_TEMPLATE_CODE,
            name=f"{test_instance.euid}-rev-1",
            properties={
                "test_order_id": test_instance.euid,
                "revision_no": 1,
                "product_code": product_code,
                "product_name": getattr(data, "product_name", None),
                "fulfillment_route_codes": fulfillment_route_codes,
                "status": "PENDING",
                "specimen_type_required": specimen_type_required,
                "specimen_type": specimen_type_required,
                "priority": priority,
                "special_instructions": special_instructions,
                "clinical_notes": special_instructions,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_test(test_instance), self._to_test_revision(revision_instance)

    def get_trf_with_revision(
        self,
        *,
        trf_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbTrfRecord, TapdbTrfRevisionRecord] | None:
        trf = self.get_trf_by_id(trf_id=trf_id, tenant_id=tenant_id)
        if trf is None:
            return None
        revision = self.get_latest_trf_revision(trf_id)
        if revision is None:
            return None
        return trf, revision

    def get_trf_by_number_with_revision(
        self,
        *,
        trf_number: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbTrfRecord, TapdbTrfRevisionRecord] | None:
        trf = self.get_trf_by_number(trf_number=trf_number, tenant_id=tenant_id)
        if trf is None:
            return None
        revision = self.get_latest_trf_revision(trf.euid)
        if revision is None:
            return None
        return trf, revision

    def get_trf_by_id(
        self,
        *,
        trf_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbTrfRecord | None:
        instance = self._resolve_trf_instance(trf_id)
        if instance is None or instance.is_deleted:
            return None
        record = self._to_trf(instance)
        if tenant_id is not None and record.tenant_id != tenant_id:
            return None
        return record

    def get_trf_by_number(
        self,
        *,
        trf_number: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbTrfRecord | None:
        normalized = (trf_number or "").strip()
        for instance in self._instances_for_template(TRF_TEMPLATE_CODE):
            record = self._to_trf(instance)
            if record.order_number != normalized:
                continue
            if tenant_id is not None and record.tenant_id != tenant_id:
                continue
            return record
        return None

    def list_trfs(
        self,
        *,
        tenant_id: uuid.UUID | None,
        limit: int,
        offset: int,
    ) -> list[tuple[TapdbTrfRecord, TapdbTrfRevisionRecord]]:
        rows: list[tuple[TapdbTrfRecord, TapdbTrfRevisionRecord]] = []
        for instance in self._instances_for_template(TRF_TEMPLATE_CODE):
            trf = self._to_trf(instance)
            if tenant_id is not None and trf.tenant_id != tenant_id:
                continue
            revision = self.get_latest_trf_revision(trf.euid)
            if revision is None:
                continue
            rows.append((trf, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[offset : offset + limit]

    def update_trf(
        self,
        *,
        trf_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbTrfRecord, TapdbTrfRevisionRecord] | None:
        result = self.get_trf_with_revision(trf_id=trf_id, tenant_id=tenant_id)
        if result is None:
            return None
        trf, latest = result

        trf_instance = self._resolve_trf_instance(trf_id)
        if trf_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TRF_REV_TEMPLATE_CODE,
            name=f"{trf.euid}-rev-{latest.revision_no + 1}",
            properties={
                "order_id": trf_id,
                "revision_no": latest.revision_no + 1,
                "clinician_id": (
                    str(data.clinician_id)
                    if data.clinician_id is not None
                    else (latest.clinician_id or None)
                ),
                "order_type": data.order_type if data.order_type is not None else latest.order_type,
                "status": latest.status,
                "is_stat": data.is_stat if data.is_stat is not None else latest.is_stat,
                "priority_notes": (
                    data.priority_notes
                    if data.priority_notes is not None
                    else latest.priority_notes
                ),
                "indication": data.indication if data.indication is not None else latest.indication,
                "clinical_notes": (
                    data.clinical_notes
                    if data.clinical_notes is not None
                    else latest.clinical_notes
                ),
                "icd10_codes": data.icd10_codes
                if data.icd10_codes is not None
                else latest.icd10_codes,
                "billing_info": data.billing_info
                if data.billing_info is not None
                else latest.billing_info,
                "submitted_at": latest.submitted_at.isoformat() if latest.submitted_at else None,
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
                "note": data.note,
            },
        )
        if getattr(data, "site_id", None) is not None:
            trf_props = self._instance_properties(trf_instance)
            trf_props["site_id"] = str(data.site_id)
            trf_instance.json_addl = {"properties": trf_props}
        self.factory.link_instances(
            session=self.db,
            parent=trf_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return trf, self._to_trf_revision(revision_instance)

    def change_trf_status(
        self,
        *,
        trf_id: str,
        new_status: str,
        reason: str | None,
        updated_by: uuid.UUID | None,
        tenant_id: uuid.UUID | None,
        submitted_at: datetime | None = None,
    ) -> tuple[TapdbTrfRecord, TapdbTrfRevisionRecord] | None:
        result = self.get_trf_with_revision(trf_id=trf_id, tenant_id=tenant_id)
        if result is None:
            return None
        trf, latest = result
        trf_instance = self._resolve_trf_instance(trf_id)
        if trf_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TRF_REV_TEMPLATE_CODE,
            name=f"{trf.euid}-rev-{latest.revision_no + 1}",
            properties={
                "order_id": trf_id,
                "revision_no": latest.revision_no + 1,
                "clinician_id": latest.clinician_id or None,
                "order_type": latest.order_type,
                "status": new_status,
                "is_stat": latest.is_stat,
                "priority_notes": latest.priority_notes,
                "indication": latest.indication,
                "clinical_notes": latest.clinical_notes,
                "icd10_codes": latest.icd10_codes,
                "billing_info": latest.billing_info,
                "submitted_at": (
                    submitted_at.isoformat()
                    if submitted_at is not None
                    else (latest.submitted_at.isoformat() if latest.submitted_at else None)
                ),
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
                "note": reason,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=trf_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return trf, self._to_trf_revision(revision_instance)

    def get_test_by_id(
        self,
        *,
        test_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbTestRecord | None:
        instance = self._resolve_test_instance(test_id)
        if instance is None or instance.is_deleted:
            return None
        record = self._to_test(instance)
        if tenant_id is not None and record.tenant_id != tenant_id:
            return None
        return record

    def list_tests(
        self,
        *,
        trf_id: str,
        tenant_id: uuid.UUID | None,
    ) -> list[TapdbTestRecord]:
        rows: list[TapdbTestRecord] = []
        for instance in self._instances_for_template(TEST_TEMPLATE_CODE):
            record = self._to_test(instance)
            if record.order_id != str(trf_id):
                continue
            if tenant_id is not None and record.tenant_id != tenant_id:
                continue
            rows.append(record)
        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC))
        return rows

    def get_test_with_revision(
        self,
        *,
        test_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbTestRecord, TapdbTestRevisionRecord] | None:
        test = self.get_test_by_id(test_id=test_id, tenant_id=tenant_id)
        if test is None:
            return None
        revision = self.get_latest_test_revision(test_id)
        if revision is None:
            return None
        return test, revision

    def get_latest_test_revision(self, test_id: str) -> TapdbTestRevisionRecord | None:
        test_instance = self._resolve_test_instance(test_id)
        if test_instance is None:
            return None
        children = get_child_instances(self.db, test_instance, TEST_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_test_revision(child) for child in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    def change_test_status(
        self,
        *,
        test_id: str,
        new_status: str,
        reason: str | None,
        updated_by: uuid.UUID | None,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbTestRecord, TapdbTestRevisionRecord] | None:
        result = self.get_test_with_revision(test_id=test_id, tenant_id=tenant_id)
        if result is None:
            return None
        test, latest = result

        test_instance = self._resolve_test_instance(test_id)
        if test_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_REV_TEMPLATE_CODE,
            name=f"{test.euid}-rev-{latest.revision_no + 1}",
            properties={
                "test_order_id": test_id,
                "revision_no": latest.revision_no + 1,
                "product_code": latest.product_code,
                "product_name": latest.product_name,
                "fulfillment_route_codes": latest.fulfillment_route_codes,
                "status": new_status,
                "specimen_type_required": latest.specimen_type_required,
                "specimen_type": latest.specimen_type,
                "priority": latest.priority,
                "special_instructions": latest.special_instructions,
                "clinical_notes": latest.clinical_notes,
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
                "note": reason,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return test, self._to_test_revision(revision_instance)

    def get_latest_trf_revision(self, trf_id: str) -> TapdbTrfRevisionRecord | None:
        trf_instance = self._resolve_trf_instance(trf_id)
        if trf_instance is None:
            return None
        children = get_child_instances(self.db, trf_instance, TRF_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_trf_revision(child) for child in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(TRF_TEMPLATE_CODE, "Atlas TRF", TRF_PREFIX)
        self._ensure_template(TRF_REV_TEMPLATE_CODE, "Atlas TRF Revision", TRF_REV_PREFIX)
        self._ensure_template(TEST_TEMPLATE_CODE, "Atlas Test", TEST_PREFIX)
        self._ensure_template(TEST_REV_TEMPLATE_CODE, "Atlas Test Revision", TEST_REV_PREFIX)
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(self, template_code: str, name: str, instance_prefix: str) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl={"managed_by": "lsmc-atlas", "domain": "requisition"},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
            return

        if existing.is_deleted:
            existing.is_deleted = False
        if existing.instance_prefix != instance_prefix:
            existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _to_trf(self, instance: generic_instance) -> TapdbTrfRecord:
        props = self._instance_properties(instance)
        return TapdbTrfRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            order_number=str(props.get("order_number") or instance.euid or ""),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_trf_revision(self, instance: generic_instance) -> TapdbTrfRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbTrfRevisionRecord(
            euid=instance.euid,
            order_id=str(props.get("order_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            patient_id=props.get("patient_id"),
            clinician_id=props.get("clinician_id"),
            order_type=str(props.get("order_type") or "CLINICAL"),
            status=str(props.get("status") or "DRAFT"),
            is_stat=bool(props.get("is_stat", False)),
            priority_notes=props.get("priority_notes"),
            indication=props.get("indication"),
            clinical_notes=props.get("clinical_notes"),
            icd10_codes=_as_str_list(props.get("icd10_codes")) or None,
            billing_info=props.get("billing_info")
            if isinstance(props.get("billing_info"), dict)
            else None,
            submitted_at=_to_dt(props.get("submitted_at")),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_test(self, instance: generic_instance) -> TapdbTestRecord:
        props = self._instance_properties(instance)
        return TapdbTestRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            order_id=str(props.get("order_id", "")),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_test_revision(self, instance: generic_instance) -> TapdbTestRevisionRecord:
        props = self._instance_properties(instance)
        specimen_type = props.get("specimen_type") or props.get("specimen_type_required")
        clinical_notes = props.get("clinical_notes") or props.get("special_instructions")
        return TapdbTestRevisionRecord(
            euid=instance.euid,
            test_order_id=str(props.get("test_order_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            product_code=str(props.get("product_code") or ""),
            product_name=props.get("product_name"),
            fulfillment_route_codes=_as_str_list(props.get("fulfillment_route_codes")),
            status=str(props.get("status") or "PENDING"),
            specimen_type_required=specimen_type,
            specimen_type=specimen_type,
            priority=str(props.get("priority") or "NORMAL"),
            special_instructions=clinical_notes,
            clinical_notes=clinical_notes,
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _resolve_trf_instance(self, trf_id: str | uuid.UUID) -> generic_instance | None:
        return get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, str(trf_id))

    def _resolve_test_instance(self, test_id: str | uuid.UUID) -> generic_instance | None:
        return get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, str(test_id))

    @staticmethod
    def _resolved_fulfillment_route_codes(data: Any) -> list[str]:
        direct = _as_str_list(getattr(data, "fulfillment_route_codes", None))
        if direct:
            return direct

        fulfillment_routes = getattr(data, "fulfillment_routes", None)
        if not isinstance(fulfillment_routes, list):
            return []

        resolved: list[str] = []
        for route in fulfillment_routes:
            if isinstance(route, (tuple, list)):
                if route and str(route[0]).strip():
                    resolved.append(str(route[0]).strip())
                continue
            code = getattr(route, "fulfillment_route_code", None)
            if code and str(code).strip():
                resolved.append(str(code).strip())
        return resolved
