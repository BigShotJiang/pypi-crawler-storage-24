"""Contract-preserving projection helpers for TapDB repository adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AtlasProjectionRule:
    """Defines how a legacy Atlas entity maps to TapDB objects."""

    entity_name: str
    template_code: str
    instance_prefix: str


def project_tapdb_instance_to_legacy_payload(instance: Any) -> dict[str, Any]:
    """Project a TapDB instance into legacy API/service payload shape.

    Phase 2 implementation will provide domain-specific projections.
    """
    json_addl = getattr(instance, "json_addl", {}) or {}
    payload = dict(json_addl)
    payload.setdefault("euid", getattr(instance, "euid", ""))
    payload.setdefault("template_code", getattr(instance, "template_code", ""))
    return payload
