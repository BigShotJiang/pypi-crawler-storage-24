"""LSMC Hub - Patient API Routes.

External API for managing patients with tenant scoping.
"""

from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user
from app.db.engine import get_db
from app.domain.services.people import PatientCreate, PatientService

router = APIRouter(prefix="/api/patients", tags=["patients"])


# --- Request/Response Schemas ---


class PatientCreateRequest(BaseModel):
    """Request to create a patient."""

    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    date_of_birth: date
    sex: str | None = Field(None, pattern="^(M|F|U|O)$")
    mrn: str | None = Field(None, max_length=50)
    email: str | None = Field(None, max_length=255)
    phone: str | None = Field(None, max_length=50)
    address_line1: str | None = None
    address_line2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = "US"
    site_id: str | None = None


class PatientUpdateRequest(BaseModel):
    """Request to update a patient (creates new revision)."""

    first_name: str | None = Field(None, min_length=1, max_length=100)
    last_name: str | None = Field(None, min_length=1, max_length=100)
    date_of_birth: date | None = None
    sex: str | None = Field(None, pattern="^(M|F|U|O)$")
    mrn: str | None = Field(None, max_length=50)
    email: str | None = Field(None, max_length=255)
    phone: str | None = Field(None, max_length=50)
    address_line1: str | None = None
    address_line2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    site_id: str | None = None


class PatientResponse(BaseModel):
    """Patient response."""

    id: str
    euid: str | None = None
    tenant_id: str
    first_name: str
    last_name: str
    date_of_birth: str
    sex: str | None
    mrn: str | None
    email: str | None
    phone: str | None
    city: str | None
    state: str | None
    revision_no: int
    created_at: str


class PatientListResponse(BaseModel):
    """List of patients."""

    items: list[PatientResponse]
    total: int


def _patient_to_response(patient, revision) -> PatientResponse:
    """Convert patient + revision to response."""
    addr = revision.address if revision and revision.address else {}
    return PatientResponse(
        id=patient.euid,
        euid=patient.euid,
        tenant_id=str(patient.tenant_id),
        first_name=revision.first_name,
        last_name=revision.last_name,
        date_of_birth=revision.date_of_birth.isoformat(),
        sex=revision.sex,
        mrn=revision.mrn,
        email=revision.email,
        phone=revision.phone,
        city=addr.get("city"),
        state=addr.get("state"),
        revision_no=revision.revision_no,
        created_at=patient.created_at.isoformat(),
    )


# --- Endpoints ---


@router.get("", response_model=PatientListResponse)
async def list_patients(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
    search: str | None = None,
) -> PatientListResponse:
    """List patients for tenant."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = PatientService(db, current_user.tenant_id, current_user.sub)

    if search:
        patients = svc.search_by_name(search, limit=limit, cross_tenant=cross_tenant)
    else:
        patients = svc.list_patients(skip=skip, limit=limit, cross_tenant=cross_tenant)

    items = [_patient_to_response(p, r) for p, r in patients]
    return PatientListResponse(items=items, total=len(items))


@router.get("/{patient_id}", response_model=PatientResponse)
async def get_patient(
    patient_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> PatientResponse:
    """Get patient by ID (EUID)."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = PatientService(db, current_user.tenant_id, current_user.sub)
    result = svc.get(patient_id, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Patient not found")

    patient, revision = result
    return _patient_to_response(patient, revision)


@router.post("", response_model=PatientResponse, status_code=status.HTTP_201_CREATED)
async def create_patient(
    request: PatientCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> PatientResponse:
    """Create a new patient."""
    svc = PatientService(db, current_user.tenant_id, current_user.sub)
    patient, revision = svc.create(
        PatientCreate(
            first_name=request.first_name,
            last_name=request.last_name,
            date_of_birth=request.date_of_birth,
            sex=request.sex,
            mrn=request.mrn,
            email=request.email,
            phone=request.phone,
            address_line1=request.address_line1,
            address_line2=request.address_line2,
            city=request.city,
            state=request.state,
            postal_code=request.postal_code,
            country=request.country,
            site_id=request.site_id,
        )
    )
    return _patient_to_response(patient, revision)


@router.patch("/{patient_id}", response_model=PatientResponse)
async def update_patient(
    patient_id: str,
    request: PatientUpdateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> PatientResponse:
    """Update patient (creates new revision)."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = PatientService(db, current_user.tenant_id, current_user.sub)

    # Build update dict from non-None fields
    updates = {k: v for k, v in request.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No fields to update",
        )

    result = svc.update(patient_id, updates, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Patient not found")

    patient, revision = result
    return _patient_to_response(patient, revision)


@router.get("/by-mrn/{mrn}", response_model=PatientResponse)
async def get_patient_by_mrn(
    mrn: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> PatientResponse:
    """Get patient by MRN."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = PatientService(db, current_user.tenant_id, current_user.sub)
    result = svc.get_by_mrn(mrn, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Patient not found")

    patient, revision = result
    return _patient_to_response(patient, revision)
