"""LSMC Hub - Document API Routes.

API for uploading and managing documents.
"""

import logging
import uuid
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user, require_internal
from app.db.engine import get_db
from app.domain.services.documents import DocumentService, DocumentUpload
from app.settings import settings

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/documents",
    tags=["documents"],
    dependencies=[Depends(require_internal)],
)


# --- Request/Response Schemas ---


class DocumentResponse(BaseModel):
    """Document response."""

    euid: str
    filename: str
    content_type: str | None
    size_bytes: int | None
    document_type: str | None
    s3_bucket: str | None
    s3_key: str | None
    created_at: str
    created_by: str | None


class DocumentListResponse(BaseModel):
    """List of documents."""

    items: list[DocumentResponse]
    total: int


class DocumentUploadResponse(BaseModel):
    """Response from document upload."""

    document_euid: str
    filename: str
    size_bytes: int
    s3_bucket: str
    s3_key: str


VALID_ENTITY_TYPES = Literal[
    "ORDER", "SHIPMENT", "TESTKIT", "MANIFEST", "PATIENT", "CLINICIAN", "AssayRef"
]


class DocumentLinkRequest(BaseModel):
    """Request to link document to entity."""

    entity_type: VALID_ENTITY_TYPES
    entity_id: str


# --- Helper Functions ---


def _document_to_response(document, revision) -> DocumentResponse:
    """Convert document + revision to response."""
    return DocumentResponse(
        euid=document.euid,
        filename=revision.filename,
        content_type=revision.content_type,
        size_bytes=revision.size_bytes,
        document_type=revision.document_type,
        s3_bucket=revision.s3_bucket,
        s3_key=revision.s3_key,
        created_at=document.created_at.isoformat(),
        created_by=str(document.created_by) if document.created_by else None,
    )


# --- Endpoints ---


@router.get("", response_model=DocumentListResponse)
async def list_documents(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
    document_type: str | None = Query(None),
) -> DocumentListResponse:
    """List documents for tenant."""
    svc = DocumentService(db, current_user.tenant_id, current_user.sub)
    documents = svc.list_documents(skip=skip, limit=limit, document_type=document_type)

    items = [_document_to_response(d, r) for d, r in documents]
    return DocumentListResponse(items=items, total=len(items))


@router.get("/{document_euid}", response_model=DocumentResponse)
async def get_document(
    document_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> DocumentResponse:
    """Get document by EUID."""
    svc = DocumentService(db, current_user.tenant_id, current_user.sub)
    result = svc.get(document_euid)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")

    document, revision = result
    return _document_to_response(document, revision)


@router.post("", response_model=DocumentUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    file: UploadFile = File(...),
    document_type: str | None = Form(None),
    note: str | None = Form(None),
) -> DocumentUploadResponse:
    """Upload a document to S3."""
    svc = DocumentService(db, current_user.tenant_id, current_user.sub)

    # Read file content with size limit
    content = await file.read(settings.max_upload_size_bytes + 1)
    if len(content) > settings.max_upload_size_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File too large. Maximum size is {settings.max_upload_size_bytes // (1024 * 1024)} MB.",
        )

    # Upload
    result = svc.upload(
        DocumentUpload(
            filename=file.filename or "unknown",
            content=content,
            content_type=file.content_type,
            document_type=document_type,
            note=note,
        ),
        created_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )

    return DocumentUploadResponse(
        document_euid=result.document_euid,
        filename=file.filename or "unknown",
        size_bytes=result.size_bytes,
        s3_bucket=result.s3_bucket,
        s3_key=result.s3_key,
    )


@router.get("/{document_euid}/download")
async def download_document(
    document_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    """Get a signed URL to download a document."""
    svc = DocumentService(db, current_user.tenant_id, current_user.sub)

    # Generate signed URL
    url = svc.get_download_url(document_euid, expires_in=3600)

    if not url:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")

    # Audit log the download
    svc.audit_download(
        document_euid,
        downloaded_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )

    # Redirect to signed URL
    return RedirectResponse(url=url, status_code=status.HTTP_302_FOUND)


@router.post("/{document_euid}/link", status_code=status.HTTP_204_NO_CONTENT)
async def link_document(
    document_euid: str,
    request: DocumentLinkRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    """Link a document to an entity (order, shipment, etc.)."""
    svc = DocumentService(db, current_user.tenant_id, current_user.sub)

    try:
        svc.link_to_entity(
            document_euid,
            request.entity_type,
            request.entity_id,
            created_by=uuid.UUID(current_user.sub) if current_user.sub else None,
        )
    except ValueError as e:
        logger.warning("Document link error: %s", e)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Document or entity not found."
        )


@router.get("/linked/{entity_type}/{entity_id}", response_model=DocumentListResponse)
async def get_linked_documents(
    entity_type: VALID_ENTITY_TYPES,
    entity_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> DocumentListResponse:
    """Get all documents linked to an entity."""
    svc = DocumentService(db, current_user.tenant_id, current_user.sub)
    documents = svc.get_linked_documents(entity_type, entity_id)

    items = [_document_to_response(d, r) for d, r in documents]
    return DocumentListResponse(items=items, total=len(items))
