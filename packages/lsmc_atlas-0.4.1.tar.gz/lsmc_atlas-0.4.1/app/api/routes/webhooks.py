"""LSMC Hub - Webhook API Routes.

API endpoints for managing webhook subscriptions.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user, require_read_write
from app.db.engine import get_db
from app.domain.enums import WebhookEventType
from app.domain.services.webhooks import (
    WebhookService,
    WebhookSubscriptionCreate,
    WebhookSubscriptionUpdate,
)

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


# --- Request/Response Schemas ---


class WebhookSubscriptionCreateRequest(BaseModel):
    """Request to create a webhook subscription."""

    subscription_name: str = Field(..., min_length=1, max_length=100)
    url: str = Field(..., min_length=1, max_length=500)
    secret: str = Field(..., min_length=8, max_length=100)
    event_types: list[str] = Field(..., min_items=1)
    headers: dict[str, str] | None = None
    timeout_seconds: int = Field(default=30, ge=5, le=300)
    max_retries: int = Field(default=3, ge=0, le=10)
    site_id: str | None = None


class WebhookSubscriptionUpdateRequest(BaseModel):
    """Request to update a webhook subscription."""

    url: str | None = Field(None, min_length=1, max_length=500)
    secret: str | None = Field(None, min_length=8, max_length=100)
    event_types: list[str] | None = Field(None, min_items=1)
    is_active: bool | None = None
    headers: dict[str, str] | None = None
    timeout_seconds: int | None = Field(None, ge=5, le=300)
    max_retries: int | None = Field(None, ge=0, le=10)
    note: str | None = None


class WebhookSubscriptionResponse(BaseModel):
    """Response for webhook subscription."""

    id: str
    euid: str | None = None
    tenant_id: str
    subscription_name: str
    url: str
    event_types: list[str]
    is_active: bool
    timeout_seconds: int
    max_retries: int
    created_at: str
    revision_no: int


class WebhookDeliveryLogResponse(BaseModel):
    """Response for webhook delivery log."""

    id: str
    subscription_id: str
    event_type: str
    event_id: str
    url: str
    attempt_number: int
    http_status: int | None
    error_message: str | None
    delivered_at: str


# --- Endpoints ---


@router.get("/event-types")
async def list_event_types() -> dict:
    """List all available webhook event types."""
    return {
        "event_types": [{"value": event.value, "name": event.name} for event in WebhookEventType]
    }


@router.post("", status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_read_write)])
async def create_subscription(
    request: WebhookSubscriptionCreateRequest,
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(get_current_user),
) -> WebhookSubscriptionResponse:
    """Create a new webhook subscription."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    webhook_svc = WebhookService(db, tenant_id)

    data = WebhookSubscriptionCreate(
        subscription_name=request.subscription_name,
        url=request.url,
        secret=request.secret,
        event_types=request.event_types,
        headers=request.headers,
        timeout_seconds=request.timeout_seconds,
        max_retries=request.max_retries,
        site_id=request.site_id,
    )

    subscription, revision = webhook_svc.create(data, created_by=user_id)

    return WebhookSubscriptionResponse(
        id=subscription.euid,
        euid=subscription.euid,
        tenant_id=str(subscription.tenant_id),
        subscription_name=subscription.subscription_name,
        url=revision.url,
        event_types=revision.event_types,
        is_active=revision.is_active,
        timeout_seconds=revision.timeout_seconds,
        max_retries=revision.max_retries,
        created_at=subscription.created_at.isoformat(),
        revision_no=revision.revision_no,
    )


@router.get("")
async def list_subscriptions(
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(get_current_user),
    skip: int = 0,
    limit: int = 100,
) -> dict:
    """List all webhook subscriptions for the tenant."""
    tenant_id = current_user.tenant_id
    webhook_svc = WebhookService(db, tenant_id)

    results = webhook_svc.list(skip=skip, limit=limit)

    return {
        "subscriptions": [
            WebhookSubscriptionResponse(
                id=str(sub.euid),
                euid=getattr(sub, "euid", None),
                tenant_id=str(sub.tenant_id),
                subscription_name=sub.subscription_name,
                url=rev.url,
                event_types=rev.event_types,
                is_active=rev.is_active,
                timeout_seconds=rev.timeout_seconds,
                max_retries=rev.max_retries,
                created_at=sub.created_at.isoformat(),
                revision_no=rev.revision_no,
            )
            for sub, rev in results
        ]
    }


@router.get("/{subscription_id}")
async def get_subscription(
    subscription_id: str,
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(get_current_user),
) -> WebhookSubscriptionResponse:
    """Get a webhook subscription by EUID."""
    tenant_id = current_user.tenant_id
    webhook_svc = WebhookService(db, tenant_id)

    result = webhook_svc.get(subscription_id)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook subscription not found",
        )

    subscription, revision = result

    return WebhookSubscriptionResponse(
        id=subscription.euid,
        euid=subscription.euid,
        tenant_id=str(subscription.tenant_id),
        subscription_name=subscription.subscription_name,
        url=revision.url,
        event_types=revision.event_types,
        is_active=revision.is_active,
        timeout_seconds=revision.timeout_seconds,
        max_retries=revision.max_retries,
        created_at=subscription.created_at.isoformat(),
        revision_no=revision.revision_no,
    )


@router.patch("/{subscription_id}", dependencies=[Depends(require_read_write)])
async def update_subscription(
    subscription_id: str,
    request: WebhookSubscriptionUpdateRequest,
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(get_current_user),
) -> WebhookSubscriptionResponse:
    """Update a webhook subscription."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    webhook_svc = WebhookService(db, tenant_id)

    data = WebhookSubscriptionUpdate(
        url=request.url,
        secret=request.secret,
        event_types=request.event_types,
        is_active=request.is_active,
        headers=request.headers,
        timeout_seconds=request.timeout_seconds,
        max_retries=request.max_retries,
        note=request.note,
    )

    result = webhook_svc.update(subscription_id, data, updated_by=user_id)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook subscription not found",
        )

    subscription, revision = result

    return WebhookSubscriptionResponse(
        id=subscription.euid,
        euid=subscription.euid,
        tenant_id=str(subscription.tenant_id),
        subscription_name=subscription.subscription_name,
        url=revision.url,
        event_types=revision.event_types,
        is_active=revision.is_active,
        timeout_seconds=revision.timeout_seconds,
        max_retries=revision.max_retries,
        created_at=subscription.created_at.isoformat(),
        revision_no=revision.revision_no,
    )


@router.get("/{subscription_id}/logs")
async def get_delivery_logs(
    subscription_id: str,
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(get_current_user),
    limit: int = 100,
) -> dict:
    """Get delivery logs for a webhook subscription."""
    tenant_id = current_user.tenant_id
    webhook_svc = WebhookService(db, tenant_id)

    logs = webhook_svc.get_delivery_logs(subscription_id=subscription_id, limit=limit)

    return {
        "logs": [
            WebhookDeliveryLogResponse(
                id=str(log.euid),
                subscription_id=str(log.subscription_id),
                event_type=log.event_type,
                event_id=str(log.event_id),
                url=log.url,
                attempt_number=log.attempt_number,
                http_status=log.http_status,
                error_message=log.error_message,
                delivered_at=log.delivered_at.isoformat(),
            )
            for log in logs
        ]
    }
