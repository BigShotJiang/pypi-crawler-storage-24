"""LSMC Hub - Support Ticket API Routes.

External API endpoints for support ticket management.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user
from app.db.engine import get_db
from app.domain.services.support import SupportTicketService, TicketCreate, TicketUpdate

router = APIRouter(prefix="/api/support", tags=["support"])


# --- Request/Response Models ---


class TicketCreateRequest(BaseModel):
    """Request to create a support ticket."""

    subject: str = Field(..., max_length=500, description="Ticket subject")
    description: str = Field(..., description="Detailed description")
    ticket_type: str = Field(..., description="Ticket type (TECHNICAL, BILLING, etc.)")
    priority: str = Field(default="NORMAL", description="Priority (LOW, NORMAL, HIGH, URGENT)")
    related_order_id: str | None = Field(None, description="Related order EUID")
    related_shipment_id: str | None = Field(None, description="Related shipment EUID")
    site_id: str | None = Field(None, description="Site EUID")


class TicketUpdateRequest(BaseModel):
    """Request to update a support ticket."""

    subject: str | None = Field(None, max_length=500)
    description: str | None = None
    ticket_type: str | None = None
    priority: str | None = None
    status: str | None = None


class TicketResponse(BaseModel):
    """Support ticket response."""

    id: str
    tenant_id: str
    ticket_number: str
    subject: str
    description: str
    ticket_type: str
    priority: str
    status: str
    assigned_to: str | None
    related_order_id: str | None
    related_shipment_id: str | None
    resolution_notes: str | None
    resolved_at: str | None
    resolved_by: str | None
    created_at: str
    created_by: str | None
    revision_no: int

    class Config:
        from_attributes = True


class TicketListResponse(BaseModel):
    """List of support tickets."""

    tickets: list[TicketResponse]
    total: int


# --- Endpoints ---


@router.post("", response_model=TicketResponse, status_code=status.HTTP_201_CREATED)
def create_ticket(
    data: TicketCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    """
    Create a new support ticket.
    """
    svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
    ticket, revision = svc.create(
        TicketCreate(
            subject=data.subject,
            description=data.description,
            ticket_type=data.ticket_type,
            priority=data.priority,
            related_order_id=data.related_order_id,
            related_shipment_id=data.related_shipment_id,
            site_id=data.site_id,
        ),
        created_by=current_user.sub_uuid,
    )

    return TicketResponse(
        id=ticket.euid,
        tenant_id=ticket.tenant_id,
        ticket_number=ticket.ticket_number,
        subject=revision.subject,
        description=revision.description,
        ticket_type=revision.ticket_type,
        priority=revision.priority,
        status=revision.status,
        assigned_to=revision.assigned_to,
        related_order_id=revision.related_order_id,
        related_shipment_id=revision.related_shipment_id,
        resolution_notes=revision.resolution_notes,
        resolved_at=revision.resolved_at.isoformat() if revision.resolved_at else None,
        resolved_by=revision.resolved_by,
        created_at=ticket.created_at.isoformat(),
        created_by=ticket.created_by,
        revision_no=revision.revision_no,
    )


@router.get("", response_model=TicketListResponse)
def list_tickets(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    status: str | None = Query(None),
    ticket_type: str | None = Query(None),
):
    """
    List support tickets.
    """
    svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
    tickets = svc.list_tickets(
        skip=skip,
        limit=limit,
        status=status,
        ticket_type=ticket_type,
    )

    return TicketListResponse(
        tickets=[
            TicketResponse(
                id=ticket.euid,
                tenant_id=ticket.tenant_id,
                ticket_number=ticket.ticket_number,
                subject=revision.subject,
                description=revision.description,
                ticket_type=revision.ticket_type,
                priority=revision.priority,
                status=revision.status,
                assigned_to=revision.assigned_to,
                related_order_id=revision.related_order_id,
                related_shipment_id=revision.related_shipment_id,
                resolution_notes=revision.resolution_notes,
                resolved_at=revision.resolved_at.isoformat() if revision.resolved_at else None,
                resolved_by=revision.resolved_by,
                created_at=ticket.created_at.isoformat(),
                created_by=ticket.created_by,
                revision_no=revision.revision_no,
            )
            for ticket, revision in tickets
        ],
        total=len(tickets),
    )


@router.get("/{ticket_id}", response_model=TicketResponse)
def get_ticket(
    ticket_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    """
    Get a support ticket by ID.
    """
    svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
    result = svc.get_by_id(ticket_id)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ticket not found",
        )

    ticket, revision = result

    return TicketResponse(
        id=ticket.euid,
        tenant_id=ticket.tenant_id,
        ticket_number=ticket.ticket_number,
        subject=revision.subject,
        description=revision.description,
        ticket_type=revision.ticket_type,
        priority=revision.priority,
        status=revision.status,
        assigned_to=revision.assigned_to,
        related_order_id=revision.related_order_id,
        related_shipment_id=revision.related_shipment_id,
        resolution_notes=revision.resolution_notes,
        resolved_at=revision.resolved_at.isoformat() if revision.resolved_at else None,
        resolved_by=revision.resolved_by,
        created_at=ticket.created_at.isoformat(),
        created_by=ticket.created_by,
        revision_no=revision.revision_no,
    )


@router.patch("/{ticket_id}", response_model=TicketResponse)
def update_ticket(
    ticket_id: str,
    data: TicketUpdateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    """
    Update a support ticket (creates new revision).
    """
    svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
    result = svc.update(
        ticket_id,
        TicketUpdate(
            subject=data.subject,
            description=data.description,
            ticket_type=data.ticket_type,
            priority=data.priority,
            status=data.status,
        ),
        updated_by=current_user.sub_uuid,
    )

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ticket not found",
        )

    ticket, revision = result

    return TicketResponse(
        id=ticket.euid,
        tenant_id=ticket.tenant_id,
        ticket_number=ticket.ticket_number,
        subject=revision.subject,
        description=revision.description,
        ticket_type=revision.ticket_type,
        priority=revision.priority,
        status=revision.status,
        assigned_to=revision.assigned_to,
        related_order_id=revision.related_order_id,
        related_shipment_id=revision.related_shipment_id,
        resolution_notes=revision.resolution_notes,
        resolved_at=revision.resolved_at.isoformat() if revision.resolved_at else None,
        resolved_by=revision.resolved_by,
        created_at=ticket.created_at.isoformat(),
        created_by=ticket.created_by,
        revision_no=revision.revision_no,
    )
