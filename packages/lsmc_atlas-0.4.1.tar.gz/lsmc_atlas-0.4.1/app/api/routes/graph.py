"""Read-only graph viewer API routes."""

from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user
from app.auth.rbac import Permission, has_permission
from app.db.engine import get_db
from app.domain.services.graph_viewer import (
    GraphObjectNotFoundError,
    GraphPermissionError,
    GraphViewerService,
)
from app.settings import settings

router = APIRouter(prefix="/api/graph", tags=["graph"])


def _build_service(db: Session, current_user: CurrentUser) -> GraphViewerService:
    return GraphViewerService(
        db,
        current_user.tenant_id,
        can_cross_tenant=has_permission(current_user.roles, Permission.CROSS_TENANT_READ),
    )


@router.get("/data")
async def get_graph_data(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    start_euid: str | None = Query(None),
    depth: int = Query(
        default=settings.graph_default_depth,
        ge=1,
        le=settings.graph_max_depth,
    ),
    tenant_id: uuid.UUID | None = Query(None),
) -> dict:
    """Return Cytoscape elements for the graph viewer."""
    service = _build_service(db, current_user)
    try:
        return service.get_graph_data(
            start_euid=start_euid,
            depth=depth,
            requested_tenant_id=tenant_id,
        )
    except GraphPermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


@router.get("/object/{euid}")
async def get_graph_object(
    euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    tenant_id: uuid.UUID | None = Query(None),
) -> dict:
    """Return object detail payload for node/edge side panel rendering."""
    service = _build_service(db, current_user)
    try:
        return service.get_object_detail(euid=euid, requested_tenant_id=tenant_id)
    except GraphPermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except GraphObjectNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
