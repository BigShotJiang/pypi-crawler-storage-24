"""LSMC Hub - User Group Management API Routes.

Provides endpoints for managing user groups and memberships.
Requires ADMIN or MANAGE_GROUPS permission.
"""

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.dependencies import RequireInternalStaff
from app.db.engine import get_db
from app.domain.enums import AccessScope, SystemGroup
from app.domain.services.groups import GroupCreate, UserGroupService

router = APIRouter(prefix="/api/groups", tags=["groups"])


class GroupCreateRequest(BaseModel):
    """Request to create a new group."""

    group_code: str
    name: str
    description: str | None = None
    access_scope: AccessScope = AccessScope.TENANT
    default_roles: list[str] | None = None


class GroupResponse(BaseModel):
    """Group information response."""

    euid: str
    group_code: str
    name: str
    description: str | None
    access_scope: str
    default_roles: list[str] | None
    is_system_group: bool
    is_active: bool
    member_count: int


class MembershipRequest(BaseModel):
    """Request to add/remove group membership."""

    user_id: uuid.UUID


@router.get("/", response_model=list[GroupResponse])
async def list_groups(
    current_user: RequireInternalStaff,
    db: Session = Depends(get_db),
) -> list[GroupResponse]:
    """List all groups in the current tenant."""
    service = UserGroupService(db, current_user.tenant_id)
    groups = []
    for sg in SystemGroup:
        info = service.get_group_by_code(sg.value)
        if info:
            groups.append(GroupResponse(**info.__dict__))
    return groups


@router.post("/", response_model=GroupResponse, status_code=status.HTTP_201_CREATED)
async def create_group(
    request: GroupCreateRequest,
    current_user: RequireInternalStaff,
    db: Session = Depends(get_db),
) -> GroupResponse:
    """Create a new user group."""
    # Check if group code already exists
    service = UserGroupService(db, current_user.tenant_id)
    existing = service.get_group_by_code(request.group_code)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Group with code '{request.group_code}' already exists",
        )

    group_data = GroupCreate(
        group_code=request.group_code,
        name=request.name,
        description=request.description,
        access_scope=request.access_scope,
        default_roles=request.default_roles,
    )

    group, revision = service.create_group(group_data, current_user.sub_uuid)

    return GroupResponse(
        euid=group.euid,
        group_code=group.group_code,
        name=revision.name,
        description=revision.description,
        access_scope=revision.access_scope,
        default_roles=revision.default_roles,
        is_system_group=revision.is_system_group,
        is_active=revision.is_active,
        member_count=0,
    )


@router.get("/{group_code}", response_model=GroupResponse)
async def get_group(
    group_code: str,
    current_user: RequireInternalStaff,
    db: Session = Depends(get_db),
) -> GroupResponse:
    """Get a group by code."""
    service = UserGroupService(db, current_user.tenant_id)
    info = service.get_group_by_code(group_code)
    if not info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Group '{group_code}' not found",
        )
    return GroupResponse(**info.__dict__)


@router.post("/{group_code}/members", status_code=status.HTTP_201_CREATED)
async def add_member(
    group_code: str,
    request: MembershipRequest,
    current_user: RequireInternalStaff,
    db: Session = Depends(get_db),
) -> dict:
    """Add a user to a group."""
    service = UserGroupService(db, current_user.tenant_id)
    info = service.get_group_by_code(group_code)
    if not info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Group '{group_code}' not found",
        )

    membership = service.add_user_to_group(
        user_id=request.user_id,
        group_euid=info.euid,
        added_by=current_user.sub_uuid,
    )

    return {
        "status": "success",
        "user_id": str(request.user_id),
        "group_code": group_code,
        "added_at": membership.created_at.isoformat() if membership.created_at else None,
    }


@router.get("/system-groups")
async def list_system_groups(current_user: RequireInternalStaff) -> dict:
    """List all available system groups."""
    return {
        "system_groups": [
            {"code": sg.value, "name": sg.value.replace("_", " ").title()} for sg in SystemGroup
        ]
    }
