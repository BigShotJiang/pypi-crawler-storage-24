"""Ursa integration endpoints for Atlas beta result return."""

from __future__ import annotations

import uuid
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy.orm import Session

from app.api.routes.internal import verify_internal_api_key
from app.auth.rate_limiting import rate_limit_dependency
from app.db.engine import get_db
from app.domain.services.storage_policies import StoragePolicyService
from app.domain.services.ursa_integration import (
    UrsaArtifactInput,
    UrsaResultReturnRequest,
    UrsaResultReturnService,
)

router = APIRouter(prefix="/api/integrations/ursa/v1", tags=["integrations-ursa"])


class UrsaArtifactRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    artifact_euid: str
    artifact_type: str | None = None
    storage_uri: str | None = None
    filename: str | None = None
    mime_type: str | None = None
    size_bytes: int | None = None
    checksum_sha256: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class UrsaAnalysisResultRequestBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    atlas_tenant_id: str
    atlas_trf_euid: str
    atlas_test_euid: str
    atlas_test_fulfillment_item_euid: str
    analysis_euid: str
    run_euid: str
    sequenced_library_assignment_euid: str
    flowcell_id: str
    lane: str
    library_barcode: str
    analysis_type: str
    result_status: str
    review_state: str
    source_system: Literal["daylily-ursa"] = "daylily-ursa"
    result_payload: dict[str, Any] = Field(default_factory=dict)
    artifacts: list[UrsaArtifactRequest] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_tenant_id(self) -> UrsaAnalysisResultRequestBody:
        try:
            uuid.UUID(str(self.atlas_tenant_id))
        except ValueError as exc:
            raise ValueError("atlas_tenant_id must be a UUID string") from exc
        return self


class UrsaAnalysisResultResponse(BaseModel):
    accepted: bool
    idempotent_replay: bool
    atlas_tenant_id: str
    atlas_trf_euid: str
    atlas_test_euid: str
    analysis_euid: str
    fulfillment_run_euid: str
    fulfillment_output_euid: str
    artifact_euids: list[str]
    results_set_euid: str | None = None


class UrsaReturnTargetRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    atlas_tenant_id: str
    atlas_trf_euid: str
    atlas_test_euid: str

    @model_validator(mode="after")
    def validate_tenant_id(self) -> UrsaReturnTargetRequest:
        try:
            uuid.UUID(str(self.atlas_tenant_id))
        except ValueError as exc:
            raise ValueError("atlas_tenant_id must be a UUID string") from exc
        return self


class UrsaReturnTargetResponse(BaseModel):
    storage_policy_euid: str
    storage_policy_scope: Literal["organization", "site"]
    atlas_tenant_id: str
    atlas_site_euid: str
    atlas_trf_euid: str
    atlas_test_euid: str
    access_mode: str
    region: str
    bucket: str
    key_prefix: str
    storage_uri_prefix: str


@router.post(
    "/fulfillment-items/{fulfillment_item_euid}/analysis-results",
    response_model=UrsaAnalysisResultResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(verify_internal_api_key), Depends(rate_limit_dependency("api"))],
)
async def return_analysis_result(
    fulfillment_item_euid: str,
    request: UrsaAnalysisResultRequestBody,
    db: Session = Depends(get_db),
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key")] = "",
) -> UrsaAnalysisResultResponse:
    if not idempotency_key.strip():
        raise HTTPException(status_code=400, detail="Idempotency-Key header is required")
    if request.atlas_test_fulfillment_item_euid != fulfillment_item_euid:
        raise HTTPException(
            status_code=400,
            detail="Path fulfillment_item_euid does not match body",
        )

    tenant_id = uuid.UUID(str(request.atlas_tenant_id))
    service = UrsaResultReturnService(db, tenant_id)
    try:
        result = service.apply(
            UrsaResultReturnRequest(
                atlas_tenant_id=request.atlas_tenant_id,
                atlas_trf_euid=request.atlas_trf_euid,
                atlas_test_euid=request.atlas_test_euid,
                atlas_test_fulfillment_item_euid=request.atlas_test_fulfillment_item_euid,
                analysis_euid=request.analysis_euid,
                run_euid=request.run_euid,
                sequenced_library_assignment_euid=request.sequenced_library_assignment_euid,
                flowcell_id=request.flowcell_id,
                lane=request.lane,
                library_barcode=request.library_barcode,
                analysis_type=request.analysis_type,
                result_status=request.result_status,
                review_state=request.review_state,
                source_system=request.source_system,
                result_payload=request.result_payload,
                artifacts=[
                    UrsaArtifactInput(
                        artifact_euid=artifact.artifact_euid,
                        artifact_type=artifact.artifact_type,
                        storage_uri=artifact.storage_uri,
                        filename=artifact.filename,
                        mime_type=artifact.mime_type,
                        size_bytes=artifact.size_bytes,
                        checksum_sha256=artifact.checksum_sha256,
                        metadata=artifact.metadata,
                    )
                    for artifact in request.artifacts
                ],
            )
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return UrsaAnalysisResultResponse(
        accepted=True,
        idempotent_replay=result.idempotent_replay,
        atlas_tenant_id=request.atlas_tenant_id,
        atlas_trf_euid=request.atlas_trf_euid,
        atlas_test_euid=request.atlas_test_euid,
        analysis_euid=request.analysis_euid,
        fulfillment_run_euid=result.fulfillment_run_euid,
        fulfillment_output_euid=result.fulfillment_output_euid,
        artifact_euids=result.artifact_euids,
        results_set_euid=result.results_set_euid,
    )


@router.post(
    "/return-targets/resolve",
    response_model=UrsaReturnTargetResponse,
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(verify_internal_api_key), Depends(rate_limit_dependency("api"))],
)
async def resolve_return_target(
    request: UrsaReturnTargetRequest,
    db: Session = Depends(get_db),
) -> UrsaReturnTargetResponse:
    service = StoragePolicyService(db)
    try:
        resolved = service.resolve_ursa_return_target(
            atlas_tenant_id=request.atlas_tenant_id,
            atlas_trf_euid=request.atlas_trf_euid,
            atlas_test_euid=request.atlas_test_euid,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return UrsaReturnTargetResponse(
        storage_policy_euid=resolved.effective_policy.policy.policy_euid,
        storage_policy_scope=resolved.effective_policy.scope,
        atlas_tenant_id=resolved.atlas_tenant_id,
        atlas_site_euid=resolved.atlas_site_euid,
        atlas_trf_euid=resolved.atlas_trf_euid,
        atlas_test_euid=resolved.atlas_test_euid,
        access_mode=resolved.effective_policy.policy.access_mode,
        region=resolved.effective_policy.policy.region,
        bucket=resolved.bucket,
        key_prefix=resolved.key_prefix,
        storage_uri_prefix=resolved.storage_uri_prefix,
    )
