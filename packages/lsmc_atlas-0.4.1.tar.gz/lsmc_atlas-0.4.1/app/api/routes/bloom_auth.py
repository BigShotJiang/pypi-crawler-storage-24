"""Shared auth helpers for Bloom integration routes."""

from __future__ import annotations

import uuid

from fastapi import HTTPException, status

from app.auth.dependencies import IntegrationClientPrincipal

CROSS_TENANT_READ_PERMISSION = "cross_tenant:read"
CROSS_TENANT_WRITE_PERMISSION = "cross_tenant:write"


def resolve_tenant_from_header(
    *,
    principal: IntegrationClientPrincipal,
    tenant_header: str,
    required_cross_tenant_permission: str,
) -> uuid.UUID:
    """Resolve tenant from `X-Atlas-Tenant-Id` and enforce cross-tenant permission.

    Rules:
    - Header is required (Bloom always sends it).
    - If the requested tenant matches the integration client's tenant, allow without
      requiring cross-tenant permissions.
    - If the requested tenant differs, require the relevant cross-tenant permission.
    """
    raw = (tenant_header or "").strip()
    if not raw:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Atlas-Tenant-Id header is required",
        )

    try:
        tenant_id = uuid.UUID(raw)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Atlas-Tenant-Id must be a valid UUID",
        ) from exc

    # Single-tenant mode: allow the org-scoped integration client to operate on its own tenant
    # without requiring cross-tenant permissions.
    if tenant_id == principal.tenant_id:
        return tenant_id

    permissions = set(principal.permissions or [])
    if "*" not in permissions and required_cross_tenant_permission not in permissions:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(f"Integration client missing permission {required_cross_tenant_permission}"),
        )

    return tenant_id
