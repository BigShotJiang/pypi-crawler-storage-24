"""LSMC Hub - Barcode Printing API Routes."""

import logging
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, require_internal_api
from app.db.engine import get_db
from app.domain.services.barcode_printing import (
    BarcodePrintService,
    EntityType,
    LabelType,
    PrintRequest,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/barcode", tags=["barcode"])


# =============================================================================
# Request/Response Models
# =============================================================================


class PrinterResponse(BaseModel):
    """Printer information response."""

    name: str
    ip_address: str
    model: str | None = None
    lab: str
    available_label_styles: list[str] | None = None


class PrintLabelRequest(BaseModel):
    """Request to print a barcode label."""

    entity_type: str  # TestKit, Shipment, Manifest
    entity_id: str
    barcode: str
    label_type: str = "tube_2inX1in"
    printer_name: str | None = None
    lab: str = "lsmc-lab"
    alt_a: str = ""
    alt_b: str = ""
    alt_c: str = ""
    alt_d: str = ""
    copies: int = 1


class PrintLabelResponse(BaseModel):
    """Response from print operation."""

    success: bool
    message: str
    print_job_id: str | None = None


class PrintTestKitRequest(BaseModel):
    """Request to print a TestKit label."""

    testkit_id: str
    barcode: str
    kit_type: str | None = None
    printer_name: str | None = None
    copies: int = 1


class ServiceStatusResponse(BaseModel):
    """Status of the barcode printing service."""

    available: bool
    printer_count: int
    printers: list[PrinterResponse]


# =============================================================================
# Endpoints
# =============================================================================


@router.get("/status", response_model=ServiceStatusResponse)
def get_barcode_service_status(
    current_user: Annotated[CurrentUser, Depends(require_internal_api)],
    db: Session = Depends(get_db),
) -> ServiceStatusResponse:
    """Get the status of the barcode printing service."""
    svc = BarcodePrintService(db, current_user.tenant_id, current_user.sub)
    printers = svc.get_configured_printers()

    return ServiceStatusResponse(
        available=svc.is_available(),
        printer_count=len(printers),
        printers=[
            PrinterResponse(
                name=p.name,
                ip_address=p.ip_address,
                model=p.model,
                lab=p.lab,
                available_label_styles=p.available_label_styles,
            )
            for p in printers
        ],
    )


@router.get("/printers", response_model=list[PrinterResponse])
def list_printers(
    current_user: Annotated[CurrentUser, Depends(require_internal_api)],
    db: Session = Depends(get_db),
) -> list[PrinterResponse]:
    """List configured printers."""
    svc = BarcodePrintService(db, current_user.tenant_id, current_user.sub)
    printers = svc.get_configured_printers()

    return [
        PrinterResponse(
            name=p.name,
            ip_address=p.ip_address,
            model=p.model,
            lab=p.lab,
            available_label_styles=p.available_label_styles,
        )
        for p in printers
    ]


@router.post("/print", response_model=PrintLabelResponse)
def print_label(
    request: PrintLabelRequest,
    current_user: Annotated[CurrentUser, Depends(require_internal_api)],
    db: Session = Depends(get_db),
) -> PrintLabelResponse:
    """Print a barcode label (internal staff only)."""
    svc = BarcodePrintService(db, current_user.tenant_id, current_user.sub)

    # Validate entity type
    try:
        entity_type = EntityType(request.entity_type)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid entity type: {request.entity_type}",
        )

    # Validate label type
    try:
        label_type = LabelType(request.label_type)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid label type: {request.label_type}",
        )

    result = svc.print_label(
        PrintRequest(
            entity_type=entity_type,
            entity_id=uuid.UUID(request.entity_id),
            barcode=request.barcode,
            label_type=label_type,
            printer_name=request.printer_name,
            lab=request.lab,
            alt_a=request.alt_a,
            alt_b=request.alt_b,
            alt_c=request.alt_c,
            alt_d=request.alt_d,
            copies=request.copies,
        )
    )

    return PrintLabelResponse(
        success=result.success,
        message=result.message,
        print_job_id=result.print_job_id,
    )


@router.post("/print/testkit", response_model=PrintLabelResponse)
def print_testkit_label(
    request: PrintTestKitRequest,
    current_user: Annotated[CurrentUser, Depends(require_internal_api)],
    db: Session = Depends(get_db),
) -> PrintLabelResponse:
    """Print a TestKit barcode label."""
    svc = BarcodePrintService(db, current_user.tenant_id, current_user.sub)

    result = svc.print_testkit_label(
        testkit_id=uuid.UUID(request.testkit_id),
        barcode=request.barcode,
        kit_type=request.kit_type,
        printer_name=request.printer_name,
        copies=request.copies,
    )

    return PrintLabelResponse(
        success=result.success,
        message=result.message,
        print_job_id=result.print_job_id,
    )


@router.post("/discover")
def discover_printers(
    ip_stub: str,
    current_user: Annotated[CurrentUser, Depends(require_internal_api)],
    db: Session = Depends(get_db),
) -> list[PrinterResponse]:
    """Discover Zebra printers on the network (admin only)."""
    svc = BarcodePrintService(db, current_user.tenant_id, current_user.sub)

    try:
        printers = svc.discover_printers(ip_stub)
        return [
            PrinterResponse(
                name=p.name,
                ip_address=p.ip_address,
                model=p.model,
                lab=p.lab,
                available_label_styles=p.available_label_styles,
            )
            for p in printers
        ]
    except RuntimeError as e:
        logger.error("Barcode printer discovery failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Printer service is currently unavailable.",
        )
