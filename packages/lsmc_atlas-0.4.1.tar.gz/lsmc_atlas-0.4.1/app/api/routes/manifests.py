"""LSMC Hub - Manifest API Routes.

API for uploading and managing manifests.
"""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user, require_internal
from app.db.engine import get_db
from app.domain.services.manifests import ManifestService

router = APIRouter(
    prefix="/api/manifests",
    tags=["manifests"],
    dependencies=[Depends(require_internal)],
)


# --- Request/Response Schemas ---


class ManifestItemResponse(BaseModel):
    """Manifest item response."""

    specimen_barcode: str
    specimen_type: str | None
    patient_id: str | None
    order_number: str | None
    collection_date: str | None
    notes: str | None


class ManifestResponse(BaseModel):
    """Manifest response."""

    id: str
    euid: str | None = None
    manifest_number: str
    tenant_id: str
    items: list[dict] | None
    shipment_id: str | None
    created_at: str
    items_count: int


class ManifestListResponse(BaseModel):
    """List of manifests."""

    items: list[ManifestResponse]
    total: int


class ManifestUploadResponse(BaseModel):
    """Response from manifest upload."""

    manifest_id: str
    manifest_number: str
    items_created: int
    materials_registered: int
    errors: list[str] | None = None
    warnings: list[str] | None = None


class ManifestParseResponse(BaseModel):
    """Response from manifest parse (preview)."""

    success: bool
    items: list[ManifestItemResponse] | None = None
    errors: list[str] | None = None
    warnings: list[str] | None = None


# --- Helper Functions ---


def _manifest_to_response(manifest, revision) -> ManifestResponse:
    """Convert manifest + revision to response."""
    return ManifestResponse(
        id=getattr(manifest, "euid", None) or str(manifest.id),
        euid=getattr(manifest, "euid", None),
        manifest_number=manifest.manifest_number,
        tenant_id=str(manifest.tenant_id),
        items=revision.items,
        shipment_id=str(revision.shipment_id) if revision.shipment_id else None,
        created_at=manifest.created_at.isoformat(),
        items_count=len(revision.items) if revision.items else 0,
    )


# --- Endpoints ---


@router.get("", response_model=ManifestListResponse)
async def list_manifests(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
) -> ManifestListResponse:
    """List manifests for tenant."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ManifestService(db, current_user.tenant_id, current_user.sub)
    manifests = svc.list_manifests(skip=skip, limit=limit, cross_tenant=cross_tenant)

    items = [_manifest_to_response(m, r) for m, r in manifests]
    return ManifestListResponse(items=items, total=len(items))


@router.get("/{manifest_number}", response_model=ManifestResponse)
async def get_manifest(
    manifest_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ManifestResponse:
    """Get manifest by manifest_number. Uses human-readable identifier in URL."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ManifestService(db, current_user.tenant_id, current_user.sub)
    result = svc.get_by_manifest_number(manifest_number, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Manifest {manifest_number} not found",
        )

    manifest, revision = result
    return _manifest_to_response(manifest, revision)


@router.post("/parse", response_model=ManifestParseResponse)
async def parse_manifest(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    file: UploadFile = File(...),
) -> ManifestParseResponse:
    """Parse a manifest file (CSV or Excel) without creating it.

    This is a preview endpoint to validate the file before upload.
    """
    svc = ManifestService(db, current_user.tenant_id, current_user.sub)

    # Read file content
    content = await file.read()

    # Determine file type and parse
    if file.filename and file.filename.endswith(".csv"):
        result = svc.parse_csv(content)
    elif file.filename and (file.filename.endswith(".xlsx") or file.filename.endswith(".xls")):
        result = svc.parse_excel(content)
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unsupported file type. Only CSV and Excel files are supported.",
        )

    # Convert items to response format
    items = None
    if result.items:
        items = [
            ManifestItemResponse(
                specimen_barcode=item.specimen_barcode,
                specimen_type=item.specimen_type,
                patient_id=item.patient_id,
                order_number=item.order_number,
                collection_date=item.collection_date,
                notes=item.notes,
            )
            for item in result.items
        ]

    return ManifestParseResponse(
        success=result.success,
        items=items,
        errors=result.errors,
        warnings=result.warnings,
    )


@router.post("/upload", response_model=ManifestUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_manifest(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    file: UploadFile = File(...),
    shipment_id: str | None = Form(None),
) -> ManifestUploadResponse:
    """Upload and create a manifest from CSV or Excel file."""
    svc = ManifestService(db, current_user.tenant_id, current_user.sub)

    # Read file content
    content = await file.read()

    # Determine file type and parse
    if file.filename and file.filename.endswith(".csv"):
        parse_result = svc.parse_csv(content)
    elif file.filename and (file.filename.endswith(".xlsx") or file.filename.endswith(".xls")):
        parse_result = svc.parse_excel(content)
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unsupported file type. Only CSV and Excel files are supported.",
        )

    # Check parse result
    if not parse_result.success or not parse_result.items:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to parse file: {', '.join(parse_result.errors or ['Unknown error'])}",
        )

    # Create manifest
    shipment_uuid = uuid.UUID(shipment_id) if shipment_id else None
    created_by = uuid.UUID(current_user.sub) if current_user.sub else None

    create_result = svc.create_manifest(
        items=parse_result.items,
        shipment_id=shipment_uuid,
        created_by=created_by,
    )

    return ManifestUploadResponse(
        manifest_id=str(create_result.manifest_id),
        manifest_number=create_result.manifest_number,
        items_created=create_result.items_created,
        materials_registered=create_result.materials_registered,
        errors=create_result.errors,
        warnings=parse_result.warnings,
    )
