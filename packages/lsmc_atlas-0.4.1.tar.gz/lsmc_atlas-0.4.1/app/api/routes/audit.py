"""LSMC Hub - Audit Export API Routes.

Provides endpoints for exporting audit history data in TSV format.
All exports are tenant-scoped and require AUDIT_EXPORT permission.
"""

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.auth.dependencies import RequireAuditExport
from app.db.engine import get_db
from app.domain.services.audit_export import AuditEntityType, AuditExportService

router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("/export/{entity_type}")
async def export_audit_history(
    entity_type: AuditEntityType,
    current_user: RequireAuditExport,
    db: Session = Depends(get_db),
    entity_id: str | None = Query(None, description="Filter by specific entity ID (EUID)"),
    start_date: datetime | None = Query(None, description="Filter by start date"),
    end_date: datetime | None = Query(None, description="Filter by end date"),
) -> Response:
    """Export audit history for an entity type as TSV.

    Requires AUDIT_EXPORT permission. Exports are tenant-scoped.

    Returns a TSV file with the audit history.
    """
    service = AuditExportService(db, current_user.tenant_id)

    result = service.export_entity_history(
        entity_type=entity_type,
        user_id=current_user.sub_uuid,
        entity_id=entity_id,
        start_date=start_date,
        end_date=end_date,
    )

    filename = f"{entity_type.value}_audit_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}.tsv"

    return Response(
        content=result.tsv_content,
        media_type="text/tab-separated-values",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Row-Count": str(result.row_count),
        },
    )


@router.get("/export-types")
async def list_export_types(
    current_user: RequireAuditExport,
) -> dict:
    """List available audit export entity types."""
    return {
        "entity_types": [{"code": et.value, "name": et.value.title()} for et in AuditEntityType]
    }
