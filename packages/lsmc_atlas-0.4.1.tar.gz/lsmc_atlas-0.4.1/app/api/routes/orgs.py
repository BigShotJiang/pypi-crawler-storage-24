"""LSMC Hub - Organization & Site API Routes.

External API for managing organizations and sites.
"""

from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import (
    CurrentUser,
    get_current_user,
    require_org_admin_api,
    require_role,
)
from app.auth.rbac import EXTERNAL_ASSIGNABLE_ROLES, ORG_ADMIN_ASSIGNABLE_ROLES, Role
from app.db.engine import get_db
from app.domain.services.orgs import (
    OrganizationCreate,
    OrganizationService,
    SiteCreate,
    SiteService,
)
from app.domain.services.storage_policies import StoragePolicyService, StoragePolicyUpsert

router = APIRouter(prefix="/api/organizations", tags=["organizations"])


# --- Request/Response Schemas ---


class OrganizationCreateRequest(BaseModel):
    """Request to create an organization."""

    name: str = Field(..., min_length=1, max_length=255)
    display_name: str | None = Field(None, max_length=255)
    org_type: str = Field("CLINIC", pattern="^(CLINIC|LAB|COLLABORATOR|OTHER)$")
    owner_user_id: str | None = None
    initial_site_name: str | None = Field(None, max_length=255)
    initial_site_code: str | None = Field(None, max_length=64)
    initial_site_contact_email: str | None = None
    initial_site_contact_phone: str | None = None


class OrganizationResponse(BaseModel):
    """Organization response."""

    id: str
    euid: str | None = None
    name: str
    display_name: str | None
    org_type: str
    owner_user_id: str | None = None
    is_active: bool
    created_at: str


class SiteCreateRequest(BaseModel):
    """Request to create a site."""

    name: str = Field(..., min_length=1, max_length=255)
    address_line1: str | None = None
    address_line2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = "US"


class SiteResponse(BaseModel):
    """Site response."""

    id: str
    euid: str | None = None
    organization_id: str
    name: str
    address_line1: str | None
    city: str | None
    state: str | None
    postal_code: str | None
    country: str | None
    is_active: bool


class OrganizationListResponse(BaseModel):
    """List of organizations."""

    items: list[OrganizationResponse]
    total: int


class SiteListResponse(BaseModel):
    """List of sites."""

    items: list[SiteResponse]
    total: int


# --- Organization Endpoints ---


@router.get("", response_model=OrganizationListResponse)
async def list_organizations(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100,
) -> OrganizationListResponse:
    """List organizations accessible to current user."""
    svc = OrganizationService(db)

    # Internal users see all, external only their tenant
    if current_user.is_internal:
        orgs = svc.list_all()
    else:
        # External user only sees their own org (look up by tenant UUID)
        org = svc.get_by_uid(current_user.tenant_id)
        orgs = [org] if org else []

    items = []
    for o in orgs:
        result = svc.get_with_revision(o.euid)
        if result:
            _, rev = result
            items.append(
                OrganizationResponse(
                    id=o.euid,
                    euid=o.euid,
                    name=rev.name,
                    display_name=rev.display_name,
                    org_type=rev.org_type,
                    owner_user_id=str(rev.owner_user_id) if rev.owner_user_id else None,
                    is_active=rev.is_active,
                    created_at=o.created_at.isoformat(),
                )
            )
    return OrganizationListResponse(items=items, total=len(items))


@router.get("/{org_id}", response_model=OrganizationResponse)
async def get_organization(
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> OrganizationResponse:
    """Get organization by ID (EUID)."""
    svc = OrganizationService(db)
    result = svc.get_with_revision(org_id)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")

    org, rev = result
    # Check access — compare internal UUID with tenant_id
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    return OrganizationResponse(
        id=org.euid,
        euid=org.euid,
        name=rev.name,
        display_name=rev.display_name,
        org_type=rev.org_type,
        owner_user_id=str(rev.owner_user_id) if rev.owner_user_id else None,
        is_active=rev.is_active,
        created_at=org.created_at.isoformat(),
    )


@router.post(
    "",
    response_model=OrganizationResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_role(Role.ADMIN))],
)
async def create_organization(
    request: OrganizationCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> OrganizationResponse:
    """Create a new organization (admin only)."""
    svc = OrganizationService(db)
    org = svc.create(
        OrganizationCreate(
            name=request.name,
            display_name=request.display_name,
            org_type=request.org_type,
            owner_user_id=request.owner_user_id,
            initial_site_name=request.initial_site_name,
            initial_site_code=request.initial_site_code,
            initial_site_contact_email=request.initial_site_contact_email,
            initial_site_contact_phone=request.initial_site_contact_phone,
        ),
        created_by=current_user.sub_uuid,
    )

    # Get the revision for response fields
    result = svc.get_with_revision(org.euid)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to read back created organization",
        )
    _, rev = result
    return OrganizationResponse(
        id=org.euid,
        euid=org.euid,
        name=rev.name,
        display_name=rev.display_name,
        org_type=rev.org_type,
        owner_user_id=str(rev.owner_user_id) if rev.owner_user_id else None,
        is_active=rev.is_active,
        created_at=org.created_at.isoformat(),
    )


class OrganizationUpdateRequest(BaseModel):
    """Request to update an organization."""

    name: str | None = Field(None, min_length=1, max_length=255)
    display_name: str | None = Field(None, max_length=255)
    org_type: str | None = Field(None, pattern="^(CLINIC|LAB|COLLABORATOR|OTHER)$")
    contact_email: str | None = None
    contact_phone: str | None = None
    owner_user_id: str | None = None
    is_active: bool | None = None


class StoragePolicyUpsertRequest(BaseModel):
    bucket: str = Field(..., min_length=3, max_length=255)
    region: str = Field(..., min_length=2, max_length=64)
    base_prefix: str = Field(default="", max_length=1024)
    access_mode: Literal["customer_bucket", "lsmc_managed"] = "lsmc_managed"
    assume_role_arn: str | None = Field(default=None, max_length=512)
    kms_key_arn: str | None = Field(default=None, max_length=512)
    allowed_artifact_classes: list[str] = Field(default_factory=list)
    enabled: bool = True


class StoragePolicyResponse(BaseModel):
    storage_policy_euid: str
    storage_policy_scope: Literal["organization", "site"]
    organization_euid: str
    site_euid: str | None
    bucket: str
    region: str
    base_prefix: str
    access_mode: Literal["customer_bucket", "lsmc_managed"]
    assume_role_arn: str | None
    kms_key_arn: str | None
    allowed_artifact_classes: list[str]
    enabled: bool
    created_at: str | None = None
    modified_at: str | None = None


@router.patch(
    "/{org_id}",
    response_model=OrganizationResponse,
    dependencies=[Depends(require_role(Role.ADMIN))],
)
async def update_organization(
    org_id: str,
    request: OrganizationUpdateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> OrganizationResponse:
    """Update an organization (admin only)."""
    from app.domain.services.orgs import OrganizationUpdate

    svc = OrganizationService(db)
    org = svc.resolve(org_id)

    if not org:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")

    updated_org = svc.update(
        org_id,
        OrganizationUpdate(
            name=request.name,
            display_name=request.display_name,
            org_type=request.org_type,
            contact_email=request.contact_email,
            contact_phone=request.contact_phone,
            owner_user_id=request.owner_user_id,
            is_active=request.is_active,
        ),
        updated_by=current_user.sub_uuid,
    )

    if not updated_org:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")

    # Get the latest revision to return the data
    result = svc.get_with_revision(org_id)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")

    _, revision = result
    return OrganizationResponse(
        id=updated_org.euid,
        euid=updated_org.euid,
        name=revision.name,
        display_name=revision.display_name,
        org_type=revision.org_type,
        owner_user_id=str(revision.owner_user_id) if revision.owner_user_id else None,
        is_active=revision.is_active,
        created_at=updated_org.created_at.isoformat(),
    )


def _storage_policy_response(
    scope: Literal["organization", "site"], record
) -> StoragePolicyResponse:
    return StoragePolicyResponse(
        storage_policy_euid=record.policy_euid,
        storage_policy_scope=scope,
        organization_euid=record.organization_euid,
        site_euid=record.site_euid,
        bucket=record.bucket,
        region=record.region,
        base_prefix=record.base_prefix,
        access_mode=record.access_mode,
        assume_role_arn=record.assume_role_arn,
        kms_key_arn=record.kms_key_arn,
        allowed_artifact_classes=list(record.allowed_artifact_classes or []),
        enabled=bool(record.enabled),
        created_at=record.created_at.isoformat() if record.created_at else None,
        modified_at=record.modified_at.isoformat() if record.modified_at else None,
    )


@router.get(
    "/{org_id}/storage-policy",
    response_model=StoragePolicyResponse,
    dependencies=[Depends(require_org_admin_api)],
)
async def get_organization_storage_policy(
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin_api)],
    db: Session = Depends(get_db),
) -> StoragePolicyResponse:
    org_result = OrganizationService(db).get_with_revision(org_id)
    if org_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    org, _revision = org_result
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    policy = StoragePolicyService(db).get_org_policy(org_id)
    if policy is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Organization storage policy not found",
        )
    return _storage_policy_response("organization", policy)


@router.put(
    "/{org_id}/storage-policy",
    response_model=StoragePolicyResponse,
    dependencies=[Depends(require_org_admin_api)],
)
async def upsert_organization_storage_policy(
    org_id: str,
    request: StoragePolicyUpsertRequest,
    current_user: Annotated[CurrentUser, Depends(require_org_admin_api)],
    db: Session = Depends(get_db),
) -> StoragePolicyResponse:
    org_result = OrganizationService(db).get_with_revision(org_id)
    if org_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    org, _revision = org_result
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    try:
        policy = StoragePolicyService(db).upsert_org_policy(
            organization_euid=org_id,
            data=StoragePolicyUpsert(
                bucket=request.bucket,
                region=request.region,
                base_prefix=request.base_prefix,
                access_mode=request.access_mode,
                assume_role_arn=request.assume_role_arn,
                kms_key_arn=request.kms_key_arn,
                allowed_artifact_classes=request.allowed_artifact_classes,
                enabled=request.enabled,
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    return _storage_policy_response("organization", policy)


@router.get(
    "/{org_id}/sites/{site_id}/storage-policy",
    response_model=StoragePolicyResponse,
    dependencies=[Depends(require_org_admin_api)],
)
async def get_site_storage_policy(
    org_id: str,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin_api)],
    db: Session = Depends(get_db),
) -> StoragePolicyResponse:
    org_result = OrganizationService(db).get_with_revision(org_id)
    if org_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    org, _revision = org_result
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    site = SiteService(db).get_by_id(site_id)
    if site is None or str(site.organization_id) != str(org.euid):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")

    policy = StoragePolicyService(db).get_site_policy(
        organization_euid=org_id,
        site_euid=site_id,
    )
    if policy is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Site storage policy override not found",
        )
    return _storage_policy_response("site", policy)


@router.put(
    "/{org_id}/sites/{site_id}/storage-policy",
    response_model=StoragePolicyResponse,
    dependencies=[Depends(require_org_admin_api)],
)
async def upsert_site_storage_policy(
    org_id: str,
    site_id: str,
    request: StoragePolicyUpsertRequest,
    current_user: Annotated[CurrentUser, Depends(require_org_admin_api)],
    db: Session = Depends(get_db),
) -> StoragePolicyResponse:
    org_result = OrganizationService(db).get_with_revision(org_id)
    if org_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    org, _revision = org_result
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    site = SiteService(db).get_by_id(site_id)
    if site is None or str(site.organization_id) != str(org.euid):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")

    try:
        policy = StoragePolicyService(db).upsert_site_policy(
            organization_euid=org_id,
            site_euid=site_id,
            data=StoragePolicyUpsert(
                bucket=request.bucket,
                region=request.region,
                base_prefix=request.base_prefix,
                access_mode=request.access_mode,
                assume_role_arn=request.assume_role_arn,
                kms_key_arn=request.kms_key_arn,
                allowed_artifact_classes=request.allowed_artifact_classes,
                enabled=request.enabled,
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    return _storage_policy_response("site", policy)


@router.delete(
    "/{org_id}/sites/{site_id}/storage-policy",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(require_org_admin_api)],
)
async def clear_site_storage_policy(
    org_id: str,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin_api)],
    db: Session = Depends(get_db),
) -> None:
    org_result = OrganizationService(db).get_with_revision(org_id)
    if org_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    org, _revision = org_result
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    site = SiteService(db).get_by_id(site_id)
    if site is None or str(site.organization_id) != str(org.euid):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")

    StoragePolicyService(db).clear_site_policy(
        organization_euid=org_id,
        site_euid=site_id,
    )


@router.get(
    "/{org_id}/storage-policy/effective",
    response_model=StoragePolicyResponse,
    dependencies=[Depends(require_org_admin_api)],
)
async def get_effective_storage_policy(
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin_api)],
    db: Session = Depends(get_db),
    site_euid: str | None = None,
) -> StoragePolicyResponse:
    org_result = OrganizationService(db).get_with_revision(org_id)
    if org_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    org, _revision = org_result
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    if site_euid:
        site = SiteService(db).get_by_id(site_euid)
        if site is None or str(site.organization_id) != str(org.euid):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")

    try:
        effective = StoragePolicyService(db).resolve_effective_policy(
            organization_euid=org_id,
            site_euid=site_euid,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    return _storage_policy_response(effective.scope, effective.policy)


# --- Organization Users Endpoints ---


class OrganizationUserCreateRequest(BaseModel):
    """Request to invite a user to an organization.

    Atlas creates the Cognito account automatically via AdminCreateUser.
    The admin only provides email, name, and roles.
    """

    email: str = Field(..., min_length=1)
    name: str | None = None
    roles: list[str] = Field(default_factory=list)


class OrganizationUserResponse(BaseModel):
    """User response."""

    id: str
    cognito_sub: str
    email: str
    name: str | None
    roles: list[str]
    is_active: bool


class OrganizationUserListResponse(BaseModel):
    """List of users."""

    items: list[OrganizationUserResponse]
    total: int


@router.get("/{org_id}/users", response_model=OrganizationUserListResponse)
async def list_organization_users(
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> OrganizationUserListResponse:
    """List users in an organization."""
    from app.domain.services.users import UserService

    # Verify organization exists
    svc = OrganizationService(db)
    org = svc.resolve(org_id)
    if not org:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")

    # Check access — compare internal UUID with tenant_id
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    user_svc = UserService(db, current_user.sub_uuid)
    users = user_svc.list_users(tenant_id=org.uid, limit=100)

    items = [
        OrganizationUserResponse(
            id=u.euid,
            cognito_sub=u.cognito_sub,
            email=u.email,
            name=u.name,
            roles=u.roles,
            is_active=u.is_active,
        )
        for u in users
    ]
    return OrganizationUserListResponse(items=items, total=len(items))


@router.post(
    "/{org_id}/users", response_model=OrganizationUserResponse, status_code=status.HTTP_201_CREATED
)
async def create_organization_user(
    org_id: str,
    request: OrganizationUserCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> OrganizationUserResponse:
    """Create a user in an organization."""
    from app.domain.services.users import UserCreate, UserService

    # Verify organization exists
    svc = OrganizationService(db)
    org = svc.resolve(org_id)
    if not org:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")

    # Check access — compare internal UUID with tenant_id
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    # Validate roles for external users (org admins get wider set)
    if not current_user.is_internal:
        if current_user.is_org_admin:
            allowed_roles = ORG_ADMIN_ASSIGNABLE_ROLES
        else:
            allowed_roles = EXTERNAL_ASSIGNABLE_ROLES
        invalid_roles = set(request.roles) - allowed_roles
        if invalid_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Cannot assign roles: {invalid_roles}",
            )

    user_svc = UserService(db, current_user.sub_uuid)
    user = user_svc.invite(
        UserCreate(
            email=request.email,
            name=request.name,
            tenant_id=org.uid,
            roles=request.roles,
        )
    )

    return OrganizationUserResponse(
        id=user.euid,
        cognito_sub=user.cognito_sub,
        email=user.email,
        name=user.name,
        roles=user.roles,
        is_active=user.is_active,
    )


# --- Site Endpoints ---


sites_router = APIRouter(prefix="/api/organizations/{org_id}/sites", tags=["sites"])


@sites_router.get("", response_model=SiteListResponse)
async def list_sites(
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> SiteListResponse:
    """List sites for an organization."""
    # Verify org exists and check access
    org_svc = OrganizationService(db)
    org = org_svc.resolve(org_id)
    if not org:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    svc = SiteService(db)
    sites = svc.list_by_organization(org_id)

    items = []
    for s in sites:
        latest_rev = s.revisions[-1] if s.revisions else None
        if latest_rev:
            addr = latest_rev.address or {}
            items.append(
                SiteResponse(
                    id=s.euid,
                    euid=s.euid,
                    organization_id=str(s.organization_id),
                    name=latest_rev.name,
                    address_line1=addr.get("line1", ""),
                    city=addr.get("city", ""),
                    state=addr.get("state", ""),
                    postal_code=addr.get("postal_code", ""),
                    country=addr.get("country", "US"),
                    is_active=latest_rev.is_active,
                )
            )
    return SiteListResponse(items=items, total=len(items))


@sites_router.post("", response_model=SiteResponse, status_code=status.HTTP_201_CREATED)
async def create_site(
    org_id: str,
    request: SiteCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> SiteResponse:
    """Create a new site."""
    # Verify org exists and check access
    org_svc = OrganizationService(db)
    org = org_svc.resolve(org_id)
    if not org:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")
    if not current_user.is_internal and current_user.tenant_id != org.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    # Build address dict from request fields
    address = {
        "line1": request.address_line1,
        "line2": request.address_line2,
        "city": request.city,
        "state": request.state,
        "postal_code": request.postal_code,
        "country": request.country or "US",
    }

    svc = SiteService(db)
    site = svc.create(
        SiteCreate(
            organization_id=org_id,
            name=request.name,
            address=address,
        ),
        created_by=current_user.sub_uuid,
    )

    # Get the latest revision to return the data
    latest_rev = site.revisions[-1] if site.revisions else None
    if latest_rev:
        addr = latest_rev.address or {}
        return SiteResponse(
            id=site.euid,
            euid=site.euid,
            organization_id=str(site.organization_id),
            name=latest_rev.name,
            address_line1=addr.get("line1", ""),
            city=addr.get("city", ""),
            state=addr.get("state", ""),
            postal_code=addr.get("postal_code", ""),
            country=addr.get("country", "US"),
            is_active=latest_rev.is_active,
        )
    else:
        # Fallback response
        return SiteResponse(
            id=site.euid,
            euid=site.euid,
            organization_id=str(site.organization_id),
            name=request.name,
            address_line1=request.address_line1 or "",
            city=request.city or "",
            state=request.state or "",
            postal_code=request.postal_code or "",
            country=request.country or "US",
            is_active=True,
        )
