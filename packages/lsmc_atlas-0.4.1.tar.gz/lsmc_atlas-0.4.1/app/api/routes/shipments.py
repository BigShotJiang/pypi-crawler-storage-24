"""LSMC Hub - Shipment API Routes.

External API for managing shipments and test kits.
"""

from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user
from app.db.engine import get_db
from app.domain.services.shipments import (
    ShipmentCreate,
    ShipmentService,
    TestKitCreate,
    TestKitService,
)

router = APIRouter(prefix="/api/shipments", tags=["shipments"])


# --- Request/Response Schemas ---


class ShipmentCreateRequest(BaseModel):
    """Request to create a shipment."""

    tracking_number: str | None = None
    carrier: str | None = None
    origin_site_id: str | None = None
    destination: str = Field(..., pattern="^(LSMC_LAB|CLIENT|OTHER)$")


class TestKitCreateRequest(BaseModel):
    """Request to create a test kit."""

    kit_barcode: str = Field(..., min_length=1, max_length=100)
    kit_type: str | None = None
    origin_site_id: str | None = None


class ContainmentRequest(BaseModel):
    """Request to add/remove item from container."""

    item_type: str = Field(..., pattern="^(TestKit|Shipment)$")
    item_id: str


class ShipmentResponse(BaseModel):
    """Shipment response."""

    id: str
    euid: str | None = None
    shipment_number: str
    tenant_id: str
    tracking_number: str | None
    carrier: str | None
    status: str
    origin_address: dict | None = None
    destination_address: dict | None = None
    created_at: str


class TestKitResponse(BaseModel):
    """Test kit response."""

    id: str
    euid: str | None = None
    tenant_id: str
    kit_barcode: str
    kit_type: str | None
    origin_site_id: str | None = None
    created_at: str


class ShipmentListResponse(BaseModel):
    """List of shipments."""

    items: list[ShipmentResponse]
    total: int


class TestKitListResponse(BaseModel):
    """List of test kits."""

    items: list[TestKitResponse]
    total: int


def _shipment_to_response(shipment, revision) -> ShipmentResponse:
    """Convert shipment to response."""
    return ShipmentResponse(
        id=shipment.euid,
        euid=getattr(shipment, "euid", None),
        shipment_number=shipment.shipment_number,
        tenant_id=str(shipment.tenant_id),
        tracking_number=revision.tracking_number if revision else None,
        carrier=revision.carrier if revision else None,
        status=revision.status if revision else "CREATED",
        origin_address=revision.origin_address if revision else None,
        destination_address=revision.destination_address if revision else None,
        created_at=shipment.created_at.isoformat(),
    )


def _testkit_to_response(kit, revision=None) -> TestKitResponse:
    """Convert test kit to response.

    TapDB stores TestKit fields across identity + revision records.
    In the TapDB-only path, the identity record has no ``kit_type``.
    """

    created_at = getattr(kit, "created_at", None)
    if created_at is None:
        created_at = datetime.now(UTC)

    return TestKitResponse(
        id=kit.euid,
        euid=getattr(kit, "euid", None),
        tenant_id=str(kit.tenant_id),
        kit_barcode=kit.kit_barcode,
        kit_type=getattr(revision, "kit_type", None)
        if revision
        else getattr(kit, "kit_type", None),
        origin_site_id=(
            getattr(revision, "origin_site_id", None)
            if revision
            else getattr(kit, "origin_site_id", None)
        ),
        created_at=created_at.isoformat(),
    )


# --- Shipment Endpoints ---


@router.get("", response_model=ShipmentListResponse)
def list_shipments(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
) -> ShipmentListResponse:
    """List shipments for tenant."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ShipmentService(db, current_user.tenant_id)
    shipments = svc.list_shipments(skip=skip, limit=limit, cross_tenant=cross_tenant)

    items = [_shipment_to_response(s, r) for s, r in shipments]
    return ShipmentListResponse(items=items, total=len(items))


@router.get("/{shipment_number}", response_model=ShipmentResponse)
def get_shipment(
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ShipmentResponse:
    """Get shipment by shipment_number. Uses human-readable identifier in URL."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ShipmentService(db, current_user.tenant_id)
    result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shipment {shipment_number} not found",
        )

    shipment, revision = result
    return _shipment_to_response(shipment, revision)


@router.post("", response_model=ShipmentResponse, status_code=status.HTTP_201_CREATED)
def create_shipment(
    request: ShipmentCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ShipmentResponse:
    """Create a new shipment."""
    svc = ShipmentService(db, current_user.tenant_id)
    try:
        shipment, revision = svc.create(
            ShipmentCreate(
                tracking_number=request.tracking_number,
                carrier=request.carrier,
                origin_site_id=request.origin_site_id,
                destination_address={"type": request.destination} if request.destination else None,
            )
        )
    except SQLAlchemyError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Shipment create unavailable: {exc.__class__.__name__}",
        ) from exc
    return _shipment_to_response(shipment, revision)


@router.post("/{shipment_number}/contents", status_code=status.HTTP_201_CREATED)
def add_to_shipment(
    shipment_number: str,
    request: ContainmentRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> dict:
    """Add an item to a shipment. Uses human-readable shipment_number in URL."""
    svc = ShipmentService(db, current_user.tenant_id)

    # Get shipment by number to get its ID
    result = svc.get_by_shipment_number(shipment_number)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shipment {shipment_number} not found",
        )

    shipment, _rev = result
    try:
        svc.add_content(shipment.euid, request.item_type, request.item_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_410_GONE, detail=str(exc)) from exc
    return {"status": "added", "shipment_number": shipment_number}


@router.delete("/{shipment_number}/contents")
def remove_from_shipment(
    shipment_number: str,
    request: ContainmentRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> dict:
    """Remove an item from a shipment (creates REMOVE event, doesn't delete).

    Uses human-readable shipment_number in URL.
    """
    svc = ShipmentService(db, current_user.tenant_id)

    # Get shipment by number to get its ID
    result = svc.get_by_shipment_number(shipment_number)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shipment {shipment_number} not found",
        )

    shipment, _rev = result
    try:
        svc.remove_content(shipment.euid, request.item_type, request.item_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_410_GONE, detail=str(exc)) from exc
    return {"status": "removed", "shipment_number": shipment_number}


# --- TestKit Endpoints ---

testkits_router = APIRouter(prefix="/api/testkits", tags=["testkits"])


@testkits_router.get("", response_model=TestKitListResponse)
def list_testkits(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
) -> TestKitListResponse:
    """List test kits for tenant."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = TestKitService(db, current_user.tenant_id)
    kits = svc.list_kits(skip=skip, limit=limit, cross_tenant=cross_tenant)

    items: list[TestKitResponse] = []
    for kit in kits:
        # N+1 is acceptable here (limit <= 200); avoids coupling this endpoint
        # to any particular persistence backend.
        rev = svc._get_latest_revision(kit.euid)
        items.append(_testkit_to_response(kit, rev))
    return TestKitListResponse(items=items, total=len(items))


@testkits_router.post("", response_model=TestKitResponse, status_code=status.HTTP_201_CREATED)
def create_testkit(
    request: TestKitCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> TestKitResponse:
    """Create a new test kit."""
    svc = TestKitService(db, current_user.tenant_id)
    kit = svc.create(
        TestKitCreate(
            kit_barcode=request.kit_barcode,
            kit_type=request.kit_type,
            origin_site_id=request.origin_site_id,
        ),
        created_by=current_user.sub_uuid,
    )

    rev = svc._get_latest_revision(kit.euid)
    return _testkit_to_response(kit, rev)
