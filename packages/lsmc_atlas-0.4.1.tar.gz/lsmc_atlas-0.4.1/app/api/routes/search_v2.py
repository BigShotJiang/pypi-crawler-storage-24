"""Unified search v2 API routes."""

from __future__ import annotations

import csv
import io
import json
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Response
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user
from app.auth.rbac import Permission, has_permission
from app.db.engine import get_db
from app.search.contracts import (
    SearchExportRequest,
    SearchExportResponse,
    SearchQueryRequest,
    SearchQueryResponse,
    SearchResultItem,
)
from app.search.service import UnifiedSearchService

router = APIRouter(prefix="/api/search/v2", tags=["search-v2"])
alias_router = APIRouter(prefix="/api/v1/search/v2", tags=["search-v2"])

_ALIAS_DEPRECATION_HEADERS = {
    "Deprecation": "true",
    "Sunset": "Wed, 30 Sep 2026 00:00:00 GMT",
}


def _with_alias_headers(response: Response, successor: str) -> None:
    for key, value in _ALIAS_DEPRECATION_HEADERS.items():
        response.headers[key] = value
    response.headers["Link"] = f'<{successor}>; rel="successor-version"'


def _build_service(db: Session, current_user: CurrentUser) -> UnifiedSearchService:
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    return UnifiedSearchService(
        db,
        current_user.tenant_id,
        cross_tenant=cross_tenant,
    )


def _export_row(item: SearchResultItem) -> dict[str, str]:
    return {
        "record_type": item.record_type,
        "source_kind": item.source_kind,
        "uid": str(item.uid),
        "euid": item.euid or "",
        "name": item.name,
        "created_at": item.created_at or "",
        "modified_at": item.modified_at or "",
        "category": item.category,
        "type": item.type,
        "subtype": item.subtype,
        "version": item.version,
        "is_deleted": str(item.is_deleted).lower(),
        "metadata": json.dumps(item.metadata, sort_keys=True, default=str),
    }


def _to_tsv(items: list[SearchResultItem]) -> str:
    buffer = io.StringIO()
    fields = [
        "record_type",
        "source_kind",
        "uuid",
        "euid",
        "name",
        "created_at",
        "modified_at",
        "category",
        "type",
        "subtype",
        "version",
        "is_deleted",
        "metadata",
    ]
    writer = csv.DictWriter(buffer, fieldnames=fields, delimiter="\t", extrasaction="ignore")
    writer.writeheader()
    for item in items:
        writer.writerow(_export_row(item))
    return buffer.getvalue()


def _export_filename(fmt: str) -> str:
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    suffix = "json" if fmt == "json" else "tsv"
    return f"atlas_search_v2_{stamp}.{suffix}"


@router.post("/query", response_model=SearchQueryResponse)
async def search_query(
    request: SearchQueryRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> SearchQueryResponse:
    """Run unified search v2 query."""
    service = _build_service(db, current_user)
    return service.query(request)


@alias_router.post("/query", response_model=SearchQueryResponse)
async def search_query_alias(
    request: SearchQueryRequest,
    response: Response,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> SearchQueryResponse:
    """Compatibility alias for unified search query."""
    _with_alias_headers(response, "/api/search/v2/query")
    service = _build_service(db, current_user)
    return service.query(request)


@router.post("/export", response_model=None)
async def search_export(
    request: SearchExportRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> Response:
    """Export unified search v2 results as JSON or TSV."""
    service = _build_service(db, current_user)
    items, timing_ms, truncated = service.collect_export_rows(request)
    filename = _export_filename(request.format)

    if request.format == "json":
        body = SearchExportResponse(
            items=items,
            row_count=len(items),
            timing_ms=timing_ms,
            truncated=truncated,
        )
        return JSONResponse(content=body.model_dump())

    return Response(
        content=_to_tsv(items),
        media_type="text/tab-separated-values",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Row-Count": str(len(items)),
            "X-Truncated": str(truncated).lower(),
            "X-Timing-Ms": str(timing_ms),
        },
    )


@alias_router.post("/export", response_model=None)
async def search_export_alias(
    request: SearchExportRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> Response:
    """Compatibility alias for unified search export."""
    service = _build_service(db, current_user)
    items, timing_ms, truncated = service.collect_export_rows(request)
    filename = _export_filename(request.format)

    if request.format == "json":
        body = SearchExportResponse(
            items=items,
            row_count=len(items),
            timing_ms=timing_ms,
            truncated=truncated,
        )
        response = JSONResponse(content=body.model_dump())
    else:
        response = Response(
            content=_to_tsv(items),
            media_type="text/tab-separated-values",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "X-Row-Count": str(len(items)),
                "X-Truncated": str(truncated).lower(),
                "X-Timing-Ms": str(timing_ms),
            },
        )

    _with_alias_headers(response, "/api/search/v2/export")
    return response
