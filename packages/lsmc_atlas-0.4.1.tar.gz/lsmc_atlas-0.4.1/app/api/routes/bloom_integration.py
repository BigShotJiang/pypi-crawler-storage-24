"""Bloom integration endpoints for Atlas beta contracts."""

from __future__ import annotations

import hashlib
import hmac
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy.orm import Session

from app.api.routes.bloom_auth import CROSS_TENANT_WRITE_PERMISSION, resolve_tenant_from_header
from app.auth.dependencies import RequireBloomIntegrationClient
from app.db.engine import get_db
from app.domain.services.bloom_bridge import (
    AcceptedMaterialRequest,
    ContainerSpecimenBridgeService,
)
from app.domain.services.bloom_status_events import (
    BloomStatusEventNotFoundError,
    BloomStatusEventService,
    BloomStatusEventTenantMismatchError,
)
from app.domain.services.external_objects import OrgBloomConfigService
from app.integrations.bloom_client import BloomClientError, resolve_secret_value
from app.settings import settings

router = APIRouter(prefix="/api/integrations/bloom/v1", tags=["integrations-bloom"])


def _resolve_actor_uuid(principal: RequireBloomIntegrationClient) -> uuid.UUID | None:
    try:
        return principal.client_id
    except Exception:
        return None


@dataclass
class _IntegrationIdentity:
    tenant_id: uuid.UUID
    actor_id: uuid.UUID | None


def _identity(principal: RequireBloomIntegrationClient) -> _IntegrationIdentity:
    return _IntegrationIdentity(
        tenant_id=principal.tenant_id,
        actor_id=_resolve_actor_uuid(principal),
    )


class AcceptedMaterialRequestBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    trf_euid: str
    test_euids: list[str] = Field(min_length=1)
    patient_euid: str
    shipment_euid: str | None = None
    testkit_euid: str | None = None
    origin_site_id: str | None = None
    specimen_template_code: str = "content/specimen/blood-whole/1.0"
    specimen_name: str | None = None
    container_euid: str | None = None
    container_template_code: str = Field(
        default_factory=lambda: settings.bloom_default_container_template_code
    )
    status: str = "active"
    properties: dict[str, Any] = Field(default_factory=dict)
    starting_queue: Literal["extraction_prod", "extraction_rnd"]
    queue_metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_links(self) -> AcceptedMaterialRequestBody:
        if not (self.shipment_euid or "").strip() and not (self.testkit_euid or "").strip():
            raise ValueError("At least one of shipment_euid or testkit_euid is required")
        return self


class AcceptedMaterialResponse(BaseModel):
    accepted: bool
    idempotent_replay: bool
    trf_euid: str
    test_euids: list[str]
    fulfillment_item_euids: list[str]
    patient_euid: str
    container_external_object_euid: str
    specimen_external_object_euid: str
    container_euid: str | None
    specimen_euid: str
    starting_queue: str
    current_queue: str


class BloomEventRequest(BaseModel):
    organization_id: str
    event_id: str
    event_type: str
    payload: dict[str, Any] = Field(default_factory=dict)


class TestStatusEventRequest(BaseModel):
    event_id: str = Field(..., min_length=1, max_length=200)
    status: str = Field(
        ...,
        pattern="^(IN_PROGRESS|COMPLETED|FAILED|ON_HOLD|CANCELED|REJECTED)$",
    )
    occurred_at: datetime
    reason: str | None = None
    container_euid: str | None = None
    specimen_euid: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class TestStatusEventResponse(BaseModel):
    applied: bool
    idempotent_replay: bool
    test_euid: str
    test_status: str
    trf_euid: str
    trf_number: str
    trf_status: str
    status_event_id: str | None = None
    trf_status_event_id: str | None = None


@router.post(
    "/materials/accepted",
    response_model=AcceptedMaterialResponse,
    status_code=status.HTTP_201_CREATED,
)
def register_accepted_material(
    request: AcceptedMaterialRequestBody,
    principal: RequireBloomIntegrationClient,
    db: Session = Depends(get_db),
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key")] = "",
) -> AcceptedMaterialResponse:
    if not idempotency_key.strip():
        raise HTTPException(status_code=400, detail="Idempotency-Key header is required")

    ctx = _identity(principal)
    svc = ContainerSpecimenBridgeService(db, ctx.tenant_id)
    try:
        result = svc.register_accepted_material(
            AcceptedMaterialRequest(
                trf_euid=request.trf_euid,
                test_euids=request.test_euids,
                patient_euid=request.patient_euid,
                shipment_euid=request.shipment_euid,
                testkit_euid=request.testkit_euid,
                origin_site_id=request.origin_site_id,
                specimen_template_code=request.specimen_template_code,
                specimen_name=request.specimen_name,
                container_euid=request.container_euid,
                container_template_code=request.container_template_code,
                status=request.status,
                properties=request.properties,
                starting_queue=request.starting_queue,
                queue_metadata=request.queue_metadata,
                idempotency_key=idempotency_key,
            ),
            actor_id=ctx.actor_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except BloomClientError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return AcceptedMaterialResponse(
        accepted=True,
        idempotent_replay=(not result.created) or result.queue_idempotent_replay,
        trf_euid=request.trf_euid,
        test_euids=request.test_euids,
        fulfillment_item_euids=result.fulfillment_item_euids,
        patient_euid=request.patient_euid,
        container_external_object_euid=result.container_external_object_euid,
        specimen_external_object_euid=result.specimen_external_object_euid,
        container_euid=result.container_euid,
        specimen_euid=result.specimen_euid,
        starting_queue=result.starting_queue,
        current_queue=result.current_queue,
    )


@router.post(
    "/tests/{test_euid}/status-events",
    response_model=TestStatusEventResponse,
    status_code=status.HTTP_200_OK,
)
def push_test_status_event(
    test_euid: str,
    request: TestStatusEventRequest,
    principal: RequireBloomIntegrationClient,
    db: Session = Depends(get_db),
    atlas_tenant_id: str = Header("", alias="X-Atlas-Tenant-Id"),
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key")] = "",
) -> TestStatusEventResponse:
    if not idempotency_key.strip():
        raise HTTPException(status_code=400, detail="Idempotency-Key header is required")

    tenant_id = resolve_tenant_from_header(
        principal=principal,
        tenant_header=atlas_tenant_id,
        required_cross_tenant_permission=CROSS_TENANT_WRITE_PERMISSION,
    )
    actor_id = _resolve_actor_uuid(principal)
    svc = BloomStatusEventService(db, tenant_id)

    try:
        result = svc.apply_test_status_event(
            test_euid=test_euid,
            event_id=request.event_id,
            idempotency_key=idempotency_key,
            status=request.status,
            occurred_at=request.occurred_at,
            reason=request.reason,
            container_euid=request.container_euid,
            specimen_euid=request.specimen_euid,
            metadata=request.metadata,
            actor_id=actor_id,
        )
    except BloomStatusEventNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except BloomStatusEventTenantMismatchError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return TestStatusEventResponse(
        applied=result.applied,
        idempotent_replay=result.idempotent_replay,
        test_euid=str(result.test_euid),
        test_status=result.test_status,
        trf_euid=str(result.trf_euid),
        trf_number=result.trf_number,
        trf_status=result.trf_status,
        status_event_id=str(result.status_event_id) if result.status_event_id else None,
        trf_status_event_id=(
            str(result.trf_status_event_id) if result.trf_status_event_id else None
        ),
    )


@router.post("/events", status_code=status.HTTP_202_ACCEPTED)
async def receive_bloom_event(
    request: Request,
    payload: BloomEventRequest,
    db: Session = Depends(get_db),
    bloom_signature: Annotated[str, Header(alias="X-Bloom-Signature")] = "",
    bloom_event_id: Annotated[str, Header(alias="X-Bloom-Event-Id")] = "",
) -> dict[str, str]:
    if not bloom_signature.strip():
        raise HTTPException(status_code=400, detail="X-Bloom-Signature header is required")
    if not bloom_event_id.strip():
        raise HTTPException(status_code=400, detail="X-Bloom-Event-Id header is required")
    if bloom_event_id.strip() != payload.event_id.strip():
        raise HTTPException(status_code=400, detail="Event ID header mismatch")

    config_service = OrgBloomConfigService(db)
    cfg = config_service.get(payload.organization_id)
    if cfg is None or not cfg.enabled:
        raise HTTPException(status_code=404, detail="No enabled Bloom config for organization")
    if not cfg.bloom_webhook_secret_ref:
        raise HTTPException(status_code=400, detail="Missing Bloom webhook secret reference")

    raw_body = await request.body()
    expected = hmac.new(
        resolve_secret_value(cfg.bloom_webhook_secret_ref).encode("utf-8"),
        raw_body,
        hashlib.sha256,
    ).hexdigest()
    provided = bloom_signature.strip().lower().removeprefix("sha256=")
    if not hmac.compare_digest(expected, provided):
        raise HTTPException(status_code=401, detail="Invalid Bloom webhook signature")

    is_new = config_service.mark_webhook_event_received(
        provider="bloom",
        tenant_id=payload.organization_id,
        event_id=payload.event_id,
    )
    if not is_new:
        return {"status": "duplicate"}

    bridge = ContainerSpecimenBridgeService(db, payload.organization_id)
    try:
        bridge.apply_bloom_event(
            event_type=payload.event_type,
            event_payload=payload.payload,
            actor_id=None,
        )
    except (BloomClientError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=f"Event processing failed: {exc}") from exc
    db.commit()
    return {"status": "processed"}
