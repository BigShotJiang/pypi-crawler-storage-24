"""Atlas lookup endpoints consumed by Bloom reference validation."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from app.api.routes.bloom_auth import CROSS_TENANT_READ_PERMISSION, resolve_tenant_from_header
from app.auth.dependencies import RequireBloomIntegrationClient
from app.db.engine import get_db
from app.domain.services.bloom_query_context import (
    BloomQueryContextService,
    ContainerContextInconsistentError,
    ContainerNotFoundError,
    ContainerTenantMismatchError,
)
from app.domain.services.people import PatientService
from app.domain.services.shipments import ShipmentService, TestKitService
from app.domain.services.trfs import TrfService

router = APIRouter(prefix="/api/integrations/bloom/v1/lookups", tags=["integrations-bloom"])


@router.get("/trfs/{trf_euid}", status_code=status.HTTP_200_OK)
def get_trf_lookup(
    trf_euid: str,
    principal: RequireBloomIntegrationClient,
    db: Session = Depends(get_db),
) -> dict[str, str | None]:
    trf = TrfService(db, principal.tenant_id).get_by_id(trf_euid, cross_tenant=False)
    if trf is None:
        raise HTTPException(status_code=404, detail=f"TRF not found: {trf_euid}")
    obj, revision = trf
    return {
        "trf_euid": obj.euid,
        "trf_number": obj.order_number,
        "atlas_tenant_id": str(obj.tenant_id),
        "status": revision.status if revision else None,
    }


@router.get("/patients/{patient_id}", status_code=status.HTTP_200_OK)
def get_patient_lookup(
    patient_id: str,
    principal: RequireBloomIntegrationClient,
    db: Session = Depends(get_db),
) -> dict[str, str | None]:
    patient = PatientService(db, principal.tenant_id).get(patient_id, cross_tenant=False)
    if patient is None:
        raise HTTPException(status_code=404, detail=f"Patient not found: {patient_id}")
    obj, revision = patient
    return {
        "patient_euid": obj.euid,
        "atlas_tenant_id": str(obj.tenant_id),
        "mrn": revision.mrn if revision else None,
    }


@router.get("/shipments/{shipment_number}", status_code=status.HTTP_200_OK)
def get_shipment_lookup(
    shipment_number: str,
    principal: RequireBloomIntegrationClient,
    db: Session = Depends(get_db),
) -> dict[str, str | None]:
    shipment = ShipmentService(db, principal.tenant_id).get_by_shipment_number(
        shipment_number,
        cross_tenant=False,
    )
    if shipment is None:
        raise HTTPException(status_code=404, detail=f"Shipment not found: {shipment_number}")
    obj, revision = shipment
    return {
        "shipment_number": obj.shipment_number,
        "shipment_euid": obj.euid,
        "atlas_tenant_id": str(obj.tenant_id),
        "status": revision.status if revision else None,
    }


@router.get("/testkits/{kit_barcode}", status_code=status.HTTP_200_OK)
def get_testkit_lookup(
    kit_barcode: str,
    principal: RequireBloomIntegrationClient,
    db: Session = Depends(get_db),
) -> dict[str, str | None]:
    service = TestKitService(db, principal.tenant_id)
    kit = service.get_by_barcode(kit_barcode, cross_tenant=False)
    if kit is None:
        raise HTTPException(status_code=404, detail=f"TestKit not found: {kit_barcode}")
    with_revision = service.get_with_revision(kit.euid, cross_tenant=False)
    revision = with_revision[1] if with_revision else None
    return {
        "kit_barcode": kit.kit_barcode,
        "testkit_euid": kit.euid,
        "atlas_tenant_id": str(kit.tenant_id),
        "status": revision.status if revision else None,
    }


@router.get("/containers/{container_euid}/trf-context", status_code=status.HTTP_200_OK)
def get_container_trf_context(
    container_euid: str,
    principal: RequireBloomIntegrationClient,
    db: Session = Depends(get_db),
    atlas_tenant_id: str = Header("", alias="X-Atlas-Tenant-Id"),
) -> dict:
    tenant_id = resolve_tenant_from_header(
        principal=principal,
        tenant_header=atlas_tenant_id,
        required_cross_tenant_permission=CROSS_TENANT_READ_PERMISSION,
    )
    svc = BloomQueryContextService(db, tenant_id)
    try:
        return svc.get_trf_context_for_container(container_euid)
    except ContainerNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ContainerTenantMismatchError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ContainerContextInconsistentError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
