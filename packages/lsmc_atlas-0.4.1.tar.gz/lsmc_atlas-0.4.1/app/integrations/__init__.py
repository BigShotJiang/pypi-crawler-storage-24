"""Application integration helpers."""
