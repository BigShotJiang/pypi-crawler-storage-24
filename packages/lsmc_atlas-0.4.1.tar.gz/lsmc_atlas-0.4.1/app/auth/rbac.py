"""LSMC Hub - Role-Based Access Control.

Defines roles and permissions for the application.
Roles:
- READ_ONLY: Can view own tenant's records but cannot create/modify anything except profile
- READ_WRITE: Can create/modify/soft-delete own tenant's records (append-only pattern)
- EXTERNAL_USER: Clinic/collaborator users (can see own tenant data) - maps to READ_WRITE
- EXTERNAL_USER_ADMIN: Org admin — manages users/tokens/settings within own tenant
- INTERNAL_USER: LSMC staff (can see all tenants, intake operations)
- ADMIN: Full administrative access

Permission model:
- Read-only users can only view their own tenant's data
- Read-write users can create/modify within their tenant
- External users have read-write access scoped to their tenant
- External user admins can manage org users, tokens, and settings within their tenant
- Internal users can access all tenants but have limited admin capabilities
- Admins have full access to all operations
"""

from enum import StrEnum


class Role(StrEnum):
    """User roles in LSMC Hub."""

    READ_ONLY = "READ_ONLY"  # View-only access within own tenant
    READ_WRITE = "READ_WRITE"  # Create/modify within own tenant
    EXTERNAL_USER = "EXTERNAL_USER"  # External clinic/collaborator (effectively READ_WRITE)
    EXTERNAL_USER_ADMIN = "EXTERNAL_USER_ADMIN"  # Org admin (manage users/tokens/settings)
    INTERNAL_USER = "INTERNAL_USER"  # LSMC internal staff
    ADMIN = "ADMIN"  # Full administrative access


class Permission(StrEnum):
    """Permissions in LSMC Hub."""

    # Profile operations (all users)
    PROFILE_READ = "profile:read"
    PROFILE_UPDATE = "profile:update"

    # Order operations
    ORDER_CREATE = "order:create"
    ORDER_READ = "order:read"
    ORDER_UPDATE = "order:update"
    ORDER_SUBMIT = "order:submit"
    ORDER_CANCEL = "order:cancel"

    # Patient operations
    PATIENT_CREATE = "patient:create"
    PATIENT_READ = "patient:read"
    PATIENT_UPDATE = "patient:update"

    # Shipment operations
    SHIPMENT_CREATE = "shipment:create"
    SHIPMENT_READ = "shipment:read"
    SHIPMENT_UPDATE = "shipment:update"

    # Intake operations (internal only)
    INTAKE_SCAN = "intake:scan"
    INTAKE_MATCH = "intake:match"
    INTAKE_EXCEPTION = "intake:exception"

    # Release operations
    RELEASE_READ = "release:read"
    RELEASE_CREATE = "release:create"  # Internal only

    # Audit operations
    AUDIT_READ = "audit:read"
    AUDIT_EXPORT = "audit:export"

    # Admin operations
    ADMIN_USERS = "admin:users"
    ADMIN_TENANTS = "admin:tenants"
    ADMIN_AUDIT = "admin:audit"
    ADMIN_GROUPS = "admin:groups"
    ADMIN_THEMES = "admin:themes"

    # Cross-tenant access
    CROSS_TENANT_READ = "cross_tenant:read"

    # Theme operations
    THEME_READ = "theme:read"
    THEME_UPDATE = "theme:update"
    THEME_SCRAPE = "theme:scrape"  # LSMC staff only - web scraping for theme generation

    # Org-admin operations (tenant-scoped)
    ORG_USER_MANAGE = "org:user_manage"
    ORG_API_TOKEN_MANAGE = "org:api_token_manage"
    ORG_SETTINGS_UPDATE = "org:settings_update"
    ORG_AUDIT_READ = "org:audit_read"


# Role-to-permission mappings
ROLE_PERMISSIONS: dict[Role, set[Permission]] = {
    Role.READ_ONLY: {
        # View only - no create/update permissions
        Permission.PROFILE_READ,
        Permission.PROFILE_UPDATE,  # Can update own profile settings
        Permission.ORDER_READ,
        Permission.PATIENT_READ,
        Permission.SHIPMENT_READ,
        Permission.RELEASE_READ,
        Permission.AUDIT_READ,
        Permission.THEME_READ,
    },
    Role.READ_WRITE: {
        # Full create/modify within tenant
        Permission.PROFILE_READ,
        Permission.PROFILE_UPDATE,
        Permission.ORDER_CREATE,
        Permission.ORDER_READ,
        Permission.ORDER_UPDATE,
        Permission.ORDER_SUBMIT,
        Permission.ORDER_CANCEL,
        Permission.PATIENT_CREATE,
        Permission.PATIENT_READ,
        Permission.PATIENT_UPDATE,
        Permission.SHIPMENT_CREATE,
        Permission.SHIPMENT_READ,
        Permission.SHIPMENT_UPDATE,
        Permission.RELEASE_READ,
        Permission.AUDIT_READ,
        Permission.AUDIT_EXPORT,
        Permission.THEME_READ,
        Permission.THEME_UPDATE,
    },
    Role.EXTERNAL_USER: {
        # Same as READ_WRITE for backward compatibility
        Permission.PROFILE_READ,
        Permission.PROFILE_UPDATE,
        Permission.ORDER_CREATE,
        Permission.ORDER_READ,
        Permission.ORDER_UPDATE,
        Permission.ORDER_SUBMIT,
        Permission.ORDER_CANCEL,
        Permission.PATIENT_CREATE,
        Permission.PATIENT_READ,
        Permission.PATIENT_UPDATE,
        Permission.SHIPMENT_CREATE,
        Permission.SHIPMENT_READ,
        Permission.SHIPMENT_UPDATE,
        Permission.RELEASE_READ,
        Permission.AUDIT_READ,
        Permission.AUDIT_EXPORT,
        Permission.THEME_READ,
        Permission.THEME_UPDATE,
    },
    Role.EXTERNAL_USER_ADMIN: {
        # All EXTERNAL_USER permissions
        Permission.PROFILE_READ,
        Permission.PROFILE_UPDATE,
        Permission.ORDER_CREATE,
        Permission.ORDER_READ,
        Permission.ORDER_UPDATE,
        Permission.ORDER_SUBMIT,
        Permission.ORDER_CANCEL,
        Permission.PATIENT_CREATE,
        Permission.PATIENT_READ,
        Permission.PATIENT_UPDATE,
        Permission.SHIPMENT_CREATE,
        Permission.SHIPMENT_READ,
        Permission.SHIPMENT_UPDATE,
        Permission.RELEASE_READ,
        Permission.AUDIT_READ,
        Permission.AUDIT_EXPORT,
        Permission.THEME_READ,
        Permission.THEME_UPDATE,
        # Plus org-admin capabilities (tenant-scoped)
        Permission.ORG_USER_MANAGE,
        Permission.ORG_API_TOKEN_MANAGE,
        Permission.ORG_SETTINGS_UPDATE,
        Permission.ORG_AUDIT_READ,
    },
    Role.INTERNAL_USER: {
        # All external permissions
        Permission.PROFILE_READ,
        Permission.PROFILE_UPDATE,
        Permission.ORDER_CREATE,
        Permission.ORDER_READ,
        Permission.ORDER_UPDATE,
        Permission.ORDER_SUBMIT,
        Permission.ORDER_CANCEL,
        Permission.PATIENT_CREATE,
        Permission.PATIENT_READ,
        Permission.PATIENT_UPDATE,
        Permission.SHIPMENT_CREATE,
        Permission.SHIPMENT_READ,
        Permission.SHIPMENT_UPDATE,
        Permission.RELEASE_READ,
        Permission.AUDIT_READ,
        Permission.AUDIT_EXPORT,
        Permission.THEME_READ,
        Permission.THEME_UPDATE,
        # Plus internal-only
        Permission.INTAKE_SCAN,
        Permission.INTAKE_MATCH,
        Permission.INTAKE_EXCEPTION,
        Permission.RELEASE_CREATE,
        Permission.CROSS_TENANT_READ,
        Permission.THEME_SCRAPE,
    },
    Role.ADMIN: {
        # All permissions
        *Permission,
    },
}


def has_permission(roles: list[str], permission: Permission) -> bool:
    """Check if any of the given roles has the specified permission.

    Args:
        roles: List of role names
        permission: Permission to check

    Returns:
        True if any role has the permission
    """
    for role_name in roles:
        try:
            role = Role(role_name)
            if permission in ROLE_PERMISSIONS.get(role, set()):
                return True
        except ValueError:
            # Unknown role, skip
            continue
    return False


def has_role(roles: list[str], required_role: Role) -> bool:
    """Check if the user has a specific role.

    Args:
        roles: List of role names
        required_role: Role to check for

    Returns:
        True if user has the role
    """
    return required_role.value in roles


def is_internal(roles: list[str]) -> bool:
    """Check if user has internal or admin access."""
    return has_role(roles, Role.INTERNAL_USER) or has_role(roles, Role.ADMIN)


def is_admin(roles: list[str]) -> bool:
    """Check if user has admin access."""
    return has_role(roles, Role.ADMIN)


def is_org_admin(roles: list[str]) -> bool:
    """Check if user has org-admin access (external_user_admin or global admin)."""
    return has_role(roles, Role.EXTERNAL_USER_ADMIN) or has_role(roles, Role.ADMIN)


def is_read_only(roles: list[str]) -> bool:
    """Check if user has only read-only access (no write permissions)."""
    return (
        has_role(roles, Role.READ_ONLY)
        and not has_role(roles, Role.READ_WRITE)
        and not has_role(roles, Role.EXTERNAL_USER)
        and not has_role(roles, Role.EXTERNAL_USER_ADMIN)
        and not has_role(roles, Role.INTERNAL_USER)
        and not has_role(roles, Role.ADMIN)
    )


def can_write(roles: list[str]) -> bool:
    """Check if user has write permissions within their tenant."""
    return (
        has_role(roles, Role.READ_WRITE)
        or has_role(roles, Role.EXTERNAL_USER)
        or has_role(roles, Role.EXTERNAL_USER_ADMIN)
        or has_role(roles, Role.INTERNAL_USER)
        or has_role(roles, Role.ADMIN)
    )


def can_access_tenant(user_roles: list[str], user_tenant_id: str, target_tenant_id: str) -> bool:
    """Check if user can access data from a specific tenant.

    Args:
        user_roles: User's roles
        user_tenant_id: User's assigned tenant
        target_tenant_id: Tenant being accessed

    Returns:
        True if access is allowed
    """
    # Same tenant is always allowed
    if user_tenant_id == target_tenant_id:
        return True

    # Cross-tenant requires permission
    return has_permission(user_roles, Permission.CROSS_TENANT_READ)


# ---------------------------------------------------------------------------
# Assignable-role constants (centralizes the scattered hardcoded sets)
# ---------------------------------------------------------------------------

# Roles that an org admin (EXTERNAL_USER_ADMIN) can assign within their tenant
ORG_ADMIN_ASSIGNABLE_ROLES: set[str] = {
    Role.EXTERNAL_USER.value,
    Role.EXTERNAL_USER_ADMIN.value,
    Role.READ_WRITE.value,
    Role.READ_ONLY.value,
}

# Roles that a regular external user can assign
EXTERNAL_ASSIGNABLE_ROLES: set[str] = {
    Role.EXTERNAL_USER.value,
    Role.READ_WRITE.value,
    Role.READ_ONLY.value,
}
