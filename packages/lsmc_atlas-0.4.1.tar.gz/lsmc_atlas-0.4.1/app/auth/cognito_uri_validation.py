"""Validation helpers for Cognito callback/logout URI configuration."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from daylily_cognito import CognitoAuth

_LOCAL_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0"}
ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME = "atlas"


@dataclass(frozen=True)
class CognitoURIRecord:
    """A discovered URI and where it was sourced from."""

    source: str
    uri: str


@dataclass(frozen=True)
class CognitoURIIssue:
    """A URI validation issue."""

    source: str
    uri: str
    message: str


@dataclass
class CognitoURIValidationResult:
    """Result of Cognito URI validation for a target Atlas port."""

    expected_port: int
    records: list[CognitoURIRecord] = field(default_factory=list)
    issues: list[CognitoURIIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.issues


@dataclass(frozen=True)
class CognitoClientNameRecord:
    """A discovered Cognito app client name and where it was sourced from."""

    source: str
    client_name: str


@dataclass(frozen=True)
class CognitoClientNameIssue:
    """A Cognito app client name validation issue."""

    source: str
    client_name: str
    message: str


@dataclass
class CognitoClientNameValidationResult:
    """Result of validating the Cognito app client name."""

    expected_client_name: str
    records: list[CognitoClientNameRecord] = field(default_factory=list)
    issues: list[CognitoClientNameIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.issues


def _read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values

    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        if key:
            values[key] = value
    return values


def _iter_daycog_env_files(daycog_config_dir: Path) -> list[Path]:
    if not daycog_config_dir.exists():
        return []
    return sorted(daycog_config_dir.glob("*.env"), key=lambda p: p.name.lower())


def _iter_matching_daycog_entries(
    *,
    daycog_config_dir: Path,
    pool_id: str,
    app_client_id: str,
) -> list[tuple[Path, dict[str, str]]]:
    entries: list[tuple[Path, dict[str, str]]] = []
    selected_pool = (pool_id or "").strip()
    selected_client = (app_client_id or "").strip()
    for env_file in _iter_daycog_env_files(daycog_config_dir):
        values = _read_env_file(env_file)
        if (values.get("COGNITO_USER_POOL_ID") or "").strip() != selected_pool:
            continue
        file_client = (values.get("COGNITO_APP_CLIENT_ID") or "").strip()
        if selected_client and file_client and file_client != selected_client:
            continue
        entries.append((env_file, values))
    return entries


def _collect_daycog_uri_records(
    *,
    daycog_config_dir: Path,
    pool_id: str,
    app_client_id: str,
) -> list[CognitoURIRecord]:
    records: list[CognitoURIRecord] = []
    for env_file, values in _iter_matching_daycog_entries(
        daycog_config_dir=daycog_config_dir,
        pool_id=pool_id,
        app_client_id=app_client_id,
    ):
        callback_url = (values.get("COGNITO_CALLBACK_URL") or "").strip()
        logout_url = (values.get("COGNITO_LOGOUT_URL") or "").strip()
        redirect_url = (values.get("COGNITO_REDIRECT_URI") or "").strip()

        if callback_url:
            records.append(
                CognitoURIRecord(
                    source=f"daycog:{env_file.name}:COGNITO_CALLBACK_URL",
                    uri=callback_url,
                )
            )
        if logout_url:
            records.append(
                CognitoURIRecord(
                    source=f"daycog:{env_file.name}:COGNITO_LOGOUT_URL",
                    uri=logout_url,
                )
            )
        if redirect_url:
            records.append(
                CognitoURIRecord(
                    source=f"daycog:{env_file.name}:COGNITO_REDIRECT_URI",
                    uri=redirect_url,
                )
            )
    return records


def _collect_daycog_client_name_records(
    *,
    daycog_config_dir: Path,
    pool_id: str,
    app_client_id: str,
) -> list[CognitoClientNameRecord]:
    records: list[CognitoClientNameRecord] = []
    for env_file, values in _iter_matching_daycog_entries(
        daycog_config_dir=daycog_config_dir,
        pool_id=pool_id,
        app_client_id=app_client_id,
    ):
        records.append(
            CognitoClientNameRecord(
                source=f"daycog:{env_file.name}:COGNITO_CLIENT_NAME",
                client_name=(values.get("COGNITO_CLIENT_NAME") or "").strip(),
            )
        )
    return records


def _describe_user_pool_client(
    *,
    pool_id: str,
    app_client_id: str,
    region: str,
    profile: str | None,
) -> dict[str, Any]:
    auth = CognitoAuth(
        region=region,
        user_pool_id=pool_id,
        app_client_id=app_client_id,
        app_client_secret=None,
        profile=profile or None,
    )
    response = auth.cognito.describe_user_pool_client(
        UserPoolId=pool_id,
        ClientId=app_client_id,
    )
    return response.get("UserPoolClient", {})


def _fetch_aws_uri_records(
    *,
    pool_id: str,
    app_client_id: str,
    region: str,
    profile: str | None,
) -> list[CognitoURIRecord]:
    user_pool_client = _describe_user_pool_client(
        pool_id=pool_id,
        app_client_id=app_client_id,
        region=region,
        profile=profile,
    )

    records: list[CognitoURIRecord] = []
    for idx, uri in enumerate(user_pool_client.get("CallbackURLs") or []):
        if uri:
            records.append(CognitoURIRecord(source=f"AWS:CallbackURLs[{idx}]", uri=str(uri)))
    for idx, uri in enumerate(user_pool_client.get("LogoutURLs") or []):
        if uri:
            records.append(CognitoURIRecord(source=f"AWS:LogoutURLs[{idx}]", uri=str(uri)))

    default_redirect = (user_pool_client.get("DefaultRedirectURI") or "").strip()
    if default_redirect:
        records.append(CognitoURIRecord(source="AWS:DefaultRedirectURI", uri=default_redirect))
    return records


def _fetch_aws_client_name(
    *,
    pool_id: str,
    app_client_id: str,
    region: str,
    profile: str | None,
) -> str:
    user_pool_client = _describe_user_pool_client(
        pool_id=pool_id,
        app_client_id=app_client_id,
        region=region,
        profile=profile,
    )
    return str(user_pool_client.get("ClientName") or "").strip()


def _validate_record_port(record: CognitoURIRecord, expected_port: int) -> CognitoURIIssue | None:
    parsed = urlparse(record.uri)
    if parsed.scheme not in {"http", "https"}:
        return CognitoURIIssue(
            source=record.source,
            uri=record.uri,
            message="URI must use http or https scheme",
        )
    if not parsed.hostname:
        return CognitoURIIssue(
            source=record.source,
            uri=record.uri,
            message="URI is missing a hostname",
        )

    hostname = parsed.hostname.lower()
    if hostname not in _LOCAL_HOSTS:
        return None

    resolved_port = parsed.port or (443 if parsed.scheme == "https" else 80)
    if resolved_port != expected_port:
        return CognitoURIIssue(
            source=record.source,
            uri=record.uri,
            message=f"Local URI port {resolved_port} does not match Atlas port {expected_port}",
        )
    return None


def validate_cognito_uri_ports(
    *,
    expected_port: int,
    pool_id: str,
    app_client_id: str,
    region: str,
    profile: str | None = None,
    settings_redirect_uri: str | None = None,
    settings_logout_uri: str | None = None,
    daycog_config_dir: Path | None = None,
    include_aws: bool = True,
) -> CognitoURIValidationResult:
    """Validate callback/logout URIs for the bound Cognito pool/app.

    Localhost-style URIs must use the provided ``expected_port``.
    """
    if expected_port < 1 or expected_port > 65535:
        raise ValueError(f"expected_port must be a valid TCP port, got {expected_port}")

    result = CognitoURIValidationResult(expected_port=expected_port)
    selected_pool = (pool_id or "").strip()
    selected_client = (app_client_id or "").strip()
    selected_region = (region or "").strip()

    if settings_redirect_uri:
        result.records.append(
            CognitoURIRecord(source="settings.cognito_redirect_uri", uri=settings_redirect_uri)
        )
    if settings_logout_uri:
        result.records.append(
            CognitoURIRecord(source="settings.cognito_logout_url", uri=settings_logout_uri)
        )

    if selected_pool:
        cfg_dir = daycog_config_dir or (Path.home() / ".config" / "daycog")
        result.records.extend(
            _collect_daycog_uri_records(
                daycog_config_dir=cfg_dir,
                pool_id=selected_pool,
                app_client_id=selected_client,
            )
        )
    else:
        result.warnings.append("No Cognito pool ID is configured; skipped daycog URI validation.")

    if include_aws:
        if selected_pool and selected_client and selected_region:
            try:
                result.records.extend(
                    _fetch_aws_uri_records(
                        pool_id=selected_pool,
                        app_client_id=selected_client,
                        region=selected_region,
                        profile=profile,
                    )
                )
            except Exception as exc:  # pragma: no cover - exercised via CLI at runtime
                result.warnings.append(f"Unable to inspect AWS app client URIs: {exc}")
        else:
            result.warnings.append(
                "Skipped AWS URI validation because pool ID, app client ID, or region is missing."
            )

    unique_records: list[CognitoURIRecord] = []
    seen: set[tuple[str, str]] = set()
    for record in result.records:
        key = (record.source, record.uri)
        if key in seen:
            continue
        seen.add(key)
        unique_records.append(record)
    result.records = unique_records

    if not result.records:
        result.warnings.append("No callback/logout/redirect URIs were discovered for validation.")

    for record in result.records:
        issue = _validate_record_port(record, expected_port)
        if issue:
            result.issues.append(issue)

    return result


def validate_cognito_app_client_name(
    *,
    expected_client_name: str,
    pool_id: str,
    app_client_id: str,
    region: str,
    profile: str | None = None,
    settings_client_name: str | None = None,
    daycog_config_dir: Path | None = None,
    include_aws: bool = True,
) -> CognitoClientNameValidationResult:
    """Validate that the bound Cognito app client name matches expectations."""
    expected_name = (expected_client_name or "").strip()
    if not expected_name:
        raise ValueError("expected_client_name cannot be empty")

    result = CognitoClientNameValidationResult(expected_client_name=expected_name)
    selected_pool = (pool_id or "").strip()
    selected_client = (app_client_id or "").strip()
    selected_region = (region or "").strip()

    if settings_client_name is not None:
        result.records.append(
            CognitoClientNameRecord(
                source="settings.cognito_client_name",
                client_name=(settings_client_name or "").strip(),
            )
        )

    if selected_pool:
        cfg_dir = daycog_config_dir or (Path.home() / ".config" / "daycog")
        result.records.extend(
            _collect_daycog_client_name_records(
                daycog_config_dir=cfg_dir,
                pool_id=selected_pool,
                app_client_id=selected_client,
            )
        )
    else:
        result.warnings.append(
            "No Cognito pool ID is configured; skipped daycog client-name validation."
        )

    if include_aws:
        if selected_pool and selected_client and selected_region:
            try:
                result.records.append(
                    CognitoClientNameRecord(
                        source="AWS:ClientName",
                        client_name=_fetch_aws_client_name(
                            pool_id=selected_pool,
                            app_client_id=selected_client,
                            region=selected_region,
                            profile=profile,
                        ),
                    )
                )
            except Exception as exc:  # pragma: no cover - exercised via CLI at runtime
                result.warnings.append(f"Unable to inspect AWS app client name: {exc}")
        else:
            result.warnings.append(
                "Skipped AWS client-name validation because pool ID, app client ID, or region is missing."
            )

    unique_records: list[CognitoClientNameRecord] = []
    seen: set[tuple[str, str]] = set()
    for record in result.records:
        key = (record.source, record.client_name)
        if key in seen:
            continue
        seen.add(key)
        unique_records.append(record)
    result.records = unique_records

    if not result.records:
        result.warnings.append("No app client names were discovered for validation.")

    for record in result.records:
        if not record.client_name:
            result.issues.append(
                CognitoClientNameIssue(
                    source=record.source,
                    client_name=record.client_name,
                    message=f"Missing app client name; expected '{expected_name}'",
                )
            )
            continue
        if record.client_name != expected_name:
            result.issues.append(
                CognitoClientNameIssue(
                    source=record.source,
                    client_name=record.client_name,
                    message=f"App client name is '{record.client_name}', expected '{expected_name}'",
                )
            )

    return result
