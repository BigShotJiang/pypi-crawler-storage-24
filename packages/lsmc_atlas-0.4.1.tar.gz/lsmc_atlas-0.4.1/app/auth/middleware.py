"""LSMC Hub - Authentication Middleware.

Provides SessionMiddleware configuration and CSRF protection.
"""

import hashlib
import hmac
import secrets

from fastapi import FastAPI, HTTPException, Request, status
from starlette.middleware.sessions import SessionMiddleware

from app.settings import settings


def setup_session_middleware(app: FastAPI) -> None:
    """Configure session middleware for the application.

    Session settings:
    - HttpOnly: Always (prevents XSS access to session cookie)
    - Secure: True in production (requires HTTPS)
    - SameSite: Lax (protects against CSRF while allowing navigation)
    """
    app.add_middleware(
        SessionMiddleware,
        secret_key=settings.secret_key,
        max_age=settings.session_max_age,
        same_site="lax",
        https_only=not settings.debug,  # Secure cookie in production
        session_cookie=settings.session_cookie_name,
    )


def generate_csrf_token(session_id: str) -> str:
    """Generate a CSRF token tied to the session.

    Args:
        session_id: The session identifier

    Returns:
        CSRF token string
    """
    # Use HMAC to tie token to session
    return hmac.new(
        settings.secret_key.encode(),
        session_id.encode(),
        hashlib.sha256,
    ).hexdigest()


def verify_csrf_token(request: Request, token: str) -> bool:
    """Verify a CSRF token.

    Args:
        request: The request containing the session
        token: The token to verify

    Returns:
        True if token is valid
    """
    session_id = request.session.get("_csrf_session_id")
    if not session_id:
        return False

    expected = generate_csrf_token(session_id)
    return hmac.compare_digest(token, expected)


async def csrf_protect(request: Request) -> None:
    """CSRF protection for form POST requests.

    Should be called on routes that handle form submissions.
    Checks for valid CSRF token in form data or header.

    Raises:
        HTTPException 403: If CSRF validation fails
    """
    # Only protect POST/PUT/PATCH/DELETE
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return

    # Skip for API calls with Bearer token (they don't use sessions)
    auth_header = request.headers.get("authorization", "")
    if auth_header.startswith("Bearer lsmc_"):
        return

    # Ensure session has CSRF session ID
    if "_csrf_session_id" not in request.session:
        request.session["_csrf_session_id"] = secrets.token_urlsafe(32)

    # Check for CSRF token in form data or header
    token = None

    # Try form data first
    content_type = request.headers.get("content-type", "")
    if "application/x-www-form-urlencoded" in content_type:
        form = await request.form()
        token = form.get("csrf_token")

    # Try header if not in form
    if not token:
        token = request.headers.get("X-CSRF-Token")

    if not token or not verify_csrf_token(request, token):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF validation failed",
        )


def get_csrf_token(request: Request) -> str:
    """Get or create CSRF token for templates.

    Args:
        request: The request with session

    Returns:
        CSRF token to include in forms
    """
    if "_csrf_session_id" not in request.session:
        request.session["_csrf_session_id"] = secrets.token_urlsafe(32)

    return generate_csrf_token(request.session["_csrf_session_id"])


def add_csrf_to_context(request: Request, context: dict) -> dict:
    """Add CSRF token to template context.

    Args:
        request: The request
        context: Template context dict

    Returns:
        Updated context with csrf_token
    """
    context["csrf_token"] = get_csrf_token(request)
    return context
