"""LSMC Atlas - AWS Cognito OIDC Authentication + Google OAuth.

Provides OIDC login redirect URL builder, callback token exchange,
JWT validation with cached JWKs, Cognito group-to-role mapping,
and Google OAuth integration via daylily-cognito.
"""

import logging
import time
from dataclasses import dataclass
from typing import Any

import httpx
from daylily_cognito import (
    build_authorization_url,
    build_google_authorization_url,
    exchange_authorization_code,
    exchange_google_code_for_tokens,
    fetch_google_userinfo,
)
from daylily_cognito import build_logout_url as dc_build_logout_url
from jose import JWTError, jwt
from jose.exceptions import ExpiredSignatureError

from app.settings import settings

logger = logging.getLogger(__name__)


class CognitoAuthError(Exception):
    """Raised when Cognito authentication fails."""

    pass


@dataclass
class CognitoUserInfo:
    """User information extracted from Cognito tokens."""

    sub: str  # Cognito subject (unique user ID)
    email: str
    name: str | None
    cognito_groups: list[str]  # Raw Cognito group names
    roles: list[str]  # Mapped LSMC Hub roles
    email_verified: bool = False
    custom_attributes: dict[str, Any] | None = None  # Custom Cognito attributes

    @property
    def tenant_id_from_attribute(self) -> str | None:
        """Get tenant_id from custom Cognito attribute if present."""
        if self.custom_attributes:
            # Try common attribute names for tenant/organization
            for key in ["custom:tenant_id", "custom:organization_id", "custom:org_id"]:
                if key in self.custom_attributes:
                    return self.custom_attributes[key]
        return None


class JWKSCache:
    """Cache for Cognito JWKS (JSON Web Key Set)."""

    def __init__(self, ttl_seconds: int = 3600):
        self._jwks: dict[str, Any] | None = None
        self._fetched_at: float = 0
        self._ttl = ttl_seconds

    def _is_expired(self) -> bool:
        return time.time() - self._fetched_at > self._ttl

    async def get_jwks(self) -> dict[str, Any]:
        """Get JWKS, fetching from Cognito if expired or not cached."""
        if self._jwks is None or self._is_expired():
            await self._fetch_jwks()
        return self._jwks  # type: ignore

    async def _fetch_jwks(self) -> None:
        """Fetch JWKS from Cognito."""
        async with httpx.AsyncClient() as client:
            response = await client.get(settings.cognito_jwks_url)
            response.raise_for_status()
            self._jwks = response.json()
            self._fetched_at = time.time()

    def get_key(self, kid: str) -> dict[str, Any] | None:
        """Get a specific key from the cached JWKS by key ID."""
        if self._jwks is None:
            return None
        for key in self._jwks.get("keys", []):
            if key.get("kid") == kid:
                return key
        return None


# Global JWKS cache instance
_jwks_cache = JWKSCache()


def build_login_url(state: str | None = None, nonce: str | None = None) -> str:
    """Build the Cognito OIDC authorization URL for login redirect.

    Args:
        state: Optional state parameter for CSRF protection
        nonce: Optional nonce for replay attack prevention (not supported by library)

    Returns:
        Full authorization URL to redirect the user to
    """
    # Note: daylily-cognito's build_authorization_url doesn't support nonce parameter.
    # If nonce is needed in the future, this would need custom implementation.
    if nonce:
        logger.debug("nonce parameter provided but not supported by daylily-cognito library")
    return build_authorization_url(
        domain=settings.cognito_domain,
        client_id=settings.cognito_app_client_id,
        redirect_uri=settings.cognito_redirect_uri,
        state=state,
    )


def build_logout_url(redirect_uri: str | None = None) -> str:
    """Build the Cognito logout URL.

    Args:
        redirect_uri: URL to redirect to after logout

    Returns:
        Full logout URL
    """
    # Prefer explicit redirect URI, then daycog-provided logout URL, then root URL fallback.
    logout_target = (
        redirect_uri
        or settings.cognito_logout_url
        or settings.cognito_redirect_uri.replace("/auth/callback", "")
    )
    return dc_build_logout_url(
        domain=settings.cognito_domain,
        client_id=settings.cognito_app_client_id,
        logout_uri=logout_target,
    )


async def exchange_code_for_tokens(code: str) -> dict[str, Any]:
    """Exchange authorization code for tokens via daylily-cognito.

    Uses daylily_cognito.exchange_authorization_code() which makes a
    synchronous POST to the Cognito /oauth2/token endpoint.

    Args:
        code: The authorization code from the callback

    Returns:
        Token response containing access_token, id_token, refresh_token

    Raises:
        CognitoAuthError: If token exchange fails
    """
    try:
        return exchange_authorization_code(
            domain=settings.cognito_domain,
            client_id=settings.cognito_app_client_id,
            code=code,
            redirect_uri=settings.cognito_redirect_uri,
            client_secret=settings.cognito_app_client_secret or None,
        )
    except RuntimeError as e:
        raise CognitoAuthError(str(e)) from e


async def validate_id_token(id_token: str) -> dict[str, Any]:
    """Validate a Cognito ID token and return its claims.

    Args:
        id_token: The JWT ID token to validate

    Returns:
        Token claims (sub, email, name, etc.)

    Raises:
        CognitoAuthError: If token validation fails
    """
    try:
        # Get unverified header to find the key ID
        unverified_header = jwt.get_unverified_header(id_token)
        kid = unverified_header.get("kid")

        if not kid:
            raise CognitoAuthError("Token missing key ID (kid)")

        # Get JWKS and find the matching key
        jwks = await _jwks_cache.get_jwks()
        key = None
        for k in jwks.get("keys", []):
            if k.get("kid") == kid:
                key = k
                break

        if not key:
            # Key not found - refresh cache and try again
            await _jwks_cache._fetch_jwks()
            jwks = await _jwks_cache.get_jwks()
            for k in jwks.get("keys", []):
                if k.get("kid") == kid:
                    key = k
                    break

        if not key:
            raise CognitoAuthError(f"Unable to find key with kid: {kid}")

        # Validate the token
        claims = jwt.decode(
            id_token,
            key,
            algorithms=["RS256"],
            audience=settings.cognito_app_client_id,
            issuer=settings.cognito_issuer,
            options={
                "verify_at_hash": False,  # We don't have access_token here
            },
        )

        return claims

    except ExpiredSignatureError:
        raise CognitoAuthError("Token has expired")
    except JWTError as e:
        raise CognitoAuthError(f"Token validation failed: {e}")


async def validate_access_token(access_token: str) -> dict[str, Any]:
    """Validate a Cognito access token and return its claims.

    Args:
        access_token: The JWT access token to validate

    Returns:
        Token claims

    Raises:
        CognitoAuthError: If token validation fails
    """
    try:
        unverified_header = jwt.get_unverified_header(access_token)
        kid = unverified_header.get("kid")

        if not kid:
            raise CognitoAuthError("Token missing key ID (kid)")

        jwks = await _jwks_cache.get_jwks()
        key = None
        for k in jwks.get("keys", []):
            if k.get("kid") == kid:
                key = k
                break

        if not key:
            await _jwks_cache._fetch_jwks()
            jwks = await _jwks_cache.get_jwks()
            for k in jwks.get("keys", []):
                if k.get("kid") == kid:
                    key = k
                    break

        if not key:
            raise CognitoAuthError(f"Unable to find key with kid: {kid}")

        # Access tokens use different claims than ID tokens
        claims = jwt.decode(
            access_token,
            key,
            algorithms=["RS256"],
            issuer=settings.cognito_issuer,
            options={
                "verify_aud": False,  # Access tokens don't have audience
            },
        )

        return claims

    except ExpiredSignatureError:
        raise CognitoAuthError("Token has expired")
    except JWTError as e:
        raise CognitoAuthError(f"Token validation failed: {e}")


def extract_cognito_groups(claims: dict[str, Any]) -> list[str]:
    """Extract Cognito User Pool groups from token claims.

    Cognito includes groups in the 'cognito:groups' claim for both
    ID tokens and access tokens.

    Args:
        claims: Decoded JWT claims

    Returns:
        List of group names (may be empty if user has no groups)
    """
    groups = claims.get("cognito:groups", [])
    if isinstance(groups, list):
        return groups
    return []


async def get_user_info_from_tokens(
    id_token: str, access_token: str | None = None
) -> CognitoUserInfo:
    """Extract complete user information from Cognito tokens.

    Validates the ID token, extracts user claims, maps Cognito groups
    to LSMC Hub roles, and returns a structured user info object.

    Args:
        id_token: The JWT ID token from Cognito
        access_token: Optional access token (groups may also be in access token)

    Returns:
        CognitoUserInfo with all extracted user data

    Raises:
        CognitoAuthError: If token validation fails
    """
    # Validate and decode ID token
    id_claims = await validate_id_token(id_token)

    # Extract basic user info
    sub = id_claims.get("sub", "")
    email = id_claims.get("email", "")
    name = id_claims.get("name") or id_claims.get("cognito:username")
    email_verified = id_claims.get("email_verified", False)

    # Extract Cognito groups (primarily from ID token)
    cognito_groups = extract_cognito_groups(id_claims)

    # If access token provided and no groups in ID token, try access token
    if not cognito_groups and access_token:
        try:
            access_claims = await validate_access_token(access_token)
            cognito_groups = extract_cognito_groups(access_claims)
        except CognitoAuthError:
            # Access token validation failed, proceed without groups from it
            logger.warning("Could not extract groups from access token")

    # Map Cognito groups to LSMC Hub roles
    roles = settings.map_cognito_groups_to_roles(cognito_groups)

    # If no roles mapped from groups, user might need to be manually provisioned
    # or we use a default role
    if not roles:
        logger.info(f"User {sub} ({email}) has no mapped roles from groups: {cognito_groups}")

    # Extract custom attributes (anything starting with 'custom:')
    custom_attributes = {k: v for k, v in id_claims.items() if k.startswith("custom:")}

    return CognitoUserInfo(
        sub=sub,
        email=email,
        name=name,
        cognito_groups=cognito_groups,
        roles=roles,
        email_verified=email_verified,
        custom_attributes=custom_attributes if custom_attributes else None,
    )


# ---------------------------------------------------------------------------
# Google OAuth helpers
# ---------------------------------------------------------------------------


def build_google_login_url(state: str | None = None) -> str:
    """Build Google OAuth2 authorization URL.

    Args:
        state: CSRF state token (auto-generated if None)

    Returns:
        Full Google authorization URL
    """
    kwargs: dict[str, Any] = {
        "client_id": settings.google_client_id,
        "redirect_uri": settings.google_redirect_uri,
        "state": state,
    }
    if settings.google_hd:
        kwargs["hd"] = settings.google_hd
    return build_google_authorization_url(**kwargs)


def exchange_google_code(code: str) -> dict[str, Any]:
    """Exchange Google authorization code for tokens.

    Args:
        code: Authorization code from Google callback

    Returns:
        Dict with access_token, id_token, etc.

    Raises:
        CognitoAuthError: If exchange fails
    """
    try:
        return exchange_google_code_for_tokens(
            client_id=settings.google_client_id,
            client_secret=settings.google_client_secret,
            code=code,
            redirect_uri=settings.google_redirect_uri,
        )
    except RuntimeError as e:
        raise CognitoAuthError(str(e)) from e


def get_google_userinfo(access_token: str) -> dict[str, Any]:
    """Fetch user profile from Google userinfo endpoint.

    Args:
        access_token: Google OAuth2 access token

    Returns:
        User profile dict with email, name, sub, etc.

    Raises:
        CognitoAuthError: If request fails
    """
    try:
        return fetch_google_userinfo(access_token)
    except RuntimeError as e:
        raise CognitoAuthError(str(e)) from e
