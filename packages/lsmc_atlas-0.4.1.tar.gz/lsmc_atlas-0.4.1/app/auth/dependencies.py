"""LSMC Hub - Authentication Dependencies.

FastAPI dependencies for authentication and authorization:
- get_current_user: Get the authenticated user from session
- get_current_tenant: Get the current tenant ID
- require_role: Decorator/dependency for role-based access
"""

import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.auth.rbac import Permission, Role, has_permission, has_role, is_read_only
from app.db.engine import get_db
from app.domain.services.api_clients import APIClientService
from app.domain.services.user_api_tokens import UserAPITokenService
from app.domain.services.users import UserService


@dataclass
class CurrentUser:
    """Authenticated user context."""

    sub: str  # Cognito subject ID
    email: str
    name: str | None
    tenant_id: uuid.UUID
    roles: list[str]

    @property
    def id(self) -> str:
        """Alias for sub."""
        return self.sub

    @property
    def user_id(self) -> uuid.UUID | None:
        """User ID as UUID for database operations.

        Alias for sub_uuid. Use this when passing to service layers
        that expect a UUID for created_by/updated_by fields.
        """
        return self.sub_uuid

    @property
    def sub_uuid(self) -> uuid.UUID | None:
        """UUID version of `sub` when possible.

        The DB stores `created_by` as UUID. Cognito `sub` is typically UUID-like,
        but in dev mode we defensively handle non-UUID subjects.
        """
        try:
            return uuid.UUID(self.sub)
        except (TypeError, ValueError):
            return None

    def has_role(self, role: Role) -> bool:
        """Check if user has a specific role."""
        return has_role(self.roles, role)

    def has_permission(self, permission: Permission) -> bool:
        """Check if user has a specific permission."""
        return has_permission(self.roles, permission)

    @property
    def is_internal(self) -> bool:
        """Check if user is internal staff or admin."""
        return self.has_role(Role.INTERNAL_USER) or self.has_role(Role.ADMIN)

    @property
    def is_admin(self) -> bool:
        """Check if user is admin."""
        return self.has_role(Role.ADMIN)

    @property
    def is_org_admin(self) -> bool:
        """Check if user is an org admin (external_user_admin or global admin)."""
        return self.has_role(Role.EXTERNAL_USER_ADMIN) or self.has_role(Role.ADMIN)

    @property
    def can_write(self) -> bool:
        """Check if user has write permissions (not read-only)."""
        return not is_read_only(self.roles)


def _is_uuid_str(value: object) -> bool:
    """Check if value is a valid UUID string."""
    if not isinstance(value, str):
        return False
    try:
        uuid.UUID(value)
        return True
    except ValueError:
        return False


def _get_current_user_from_session(request: Request) -> CurrentUser | None:
    """Extract current user from session, or return None if not authenticated.

    Sessions are invalidated when:
    - No user_sub in session
    - Session is from a different server instance (server was restarted)
    - User has been deactivated in the database (checked every 5 minutes)
    """
    session = request.session

    # Check for authenticated session
    if "user_sub" not in session:
        return None

    # Check if session is from the current server instance (invalidate on restart)
    from app.auth.session import get_server_instance_id

    session_instance_id = session.get("server_instance_id")
    current_instance_id = get_server_instance_id()
    if session_instance_id != current_instance_id:
        # Session is from a previous server instance - clear it
        session.clear()
        return None

    # Periodic re-validation: check DB every 5 minutes
    last_validated = session.get("_last_db_validated")
    now = datetime.now(UTC)
    revalidation_interval = timedelta(minutes=5)

    parsed_last_validated: datetime | None = None
    if isinstance(last_validated, str) and last_validated:
        try:
            parsed_last_validated = datetime.fromisoformat(last_validated)
            if parsed_last_validated.tzinfo is None:
                parsed_last_validated = parsed_last_validated.replace(tzinfo=UTC)
            else:
                parsed_last_validated = parsed_last_validated.astimezone(UTC)
        except ValueError:
            parsed_last_validated = None

    needs_revalidation = (
        parsed_last_validated is None
        or (now - parsed_last_validated) > revalidation_interval
    )

    if needs_revalidation:
        # Re-check user status and roles from database
        from app.db.engine import SessionLocal

        try:
            db = SessionLocal()
            try:
                user_profile = UserService(db).get_by_cognito_sub(session["user_sub"])

                if not user_profile or not user_profile.is_active:
                    # User deactivated — invalidate session
                    session.clear()
                    return None

                # Update session with current DB values
                session["email"] = user_profile.email
                session["name"] = user_profile.name
                session["roles"] = user_profile.roles or []
                if user_profile.tenant_id:
                    session["tenant_id"] = str(user_profile.tenant_id)
                session["_last_db_validated"] = now.isoformat()
            finally:
                db.close()
        except Exception:
            # If DB check fails, allow session to continue
            # (don't lock out users due to transient DB issues)
            pass

    return CurrentUser(
        sub=session["user_sub"],
        email=session.get("email", ""),
        name=session.get("name"),
        tenant_id=uuid.UUID(session["tenant_id"]),
        roles=session.get("roles", []),
    )


def get_current_user(
    request: Request,
    db: Session = Depends(get_db),
) -> CurrentUser:
    """Get the current authenticated user from session OR API token.

    Returns:
        CurrentUser with authenticated user info

    Raises:
        HTTPException 401: If user is not authenticated
    """
    # 1. Check Session (Web UI)
    user = _get_current_user_from_session(request)
    if user:
        return user

    # 2. Check API Token (Bearer lsmc_...)
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer lsmc_"):
        try:
            token_str = auth_header[7:]
            svc = UserAPITokenService(db)

            # Validate token
            result = svc.validate(token_str)

            if result.is_valid:
                try:
                    request_metadata = {
                        "path": request.url.path,
                        "query_params": dict(request.query_params),
                        "headers": {
                            "content-type": request.headers.get("content-type"),
                            "accept": request.headers.get("accept"),
                            "referer": request.headers.get("referer"),
                        },
                    }

                    svc.update_last_used(result.token_id)
                    svc.log_usage(
                        token_id=result.token_id,
                        tenant_id=result.tenant_id,
                        endpoint=request.url.path,
                        http_method=request.method,
                        response_status=200,
                        ip_address=request.client.host if request.client else None,
                        user_agent=request.headers.get("user-agent"),
                        request_metadata=request_metadata,
                    )
                except Exception:
                    pass

                user_profile = UserService(db).get_by_cognito_sub(str(result.user_id))

                if user_profile and user_profile.is_active:
                    return CurrentUser(
                        sub=user_profile.cognito_sub,
                        email=user_profile.email,
                        name=user_profile.name,
                        tenant_id=result.tenant_id,
                        roles=user_profile.roles or [],
                    )
        except Exception:
            # Fall through to generic 401
            pass

    # 3. Auth Failed - RAISE 401
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )


class WebAuthRedirect(Exception):
    """Exception to trigger redirect to login page for web routes."""

    pass


async def get_current_user_web(request: Request) -> CurrentUser:
    """Get the current authenticated user, redirecting to login if not authenticated.

    Use this dependency for web routes (HTML pages) that should redirect to
    the login page instead of returning 401 JSON.

    Args:
        request: The FastAPI request

    Returns:
        CurrentUser with authenticated user info

    Raises:
        WebAuthRedirect: If user is not authenticated (caught by exception handler)
    """
    user = _get_current_user_from_session(request)
    if user is None:
        raise WebAuthRedirect()
    return user


async def get_current_tenant(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> uuid.UUID:
    """Get the current tenant ID from the authenticated user.

    Args:
        current_user: The authenticated user

    Returns:
        The tenant UUID
    """
    return current_user.tenant_id


def require_role(*required_roles: Role) -> Callable:
    """Create a dependency that requires specific roles.

    Args:
        *required_roles: One or more roles required (user needs at least one)

    Returns:
        A FastAPI dependency function
    """

    async def role_checker(
        current_user: Annotated[CurrentUser, Depends(get_current_user)],
    ) -> CurrentUser:
        """Check if user has any of the required roles."""
        for role in required_roles:
            if current_user.has_role(role):
                return current_user

        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Requires one of roles: {[r.value for r in required_roles]}",
        )

    return role_checker


def require_permission(permission: Permission) -> Callable:
    """Create a dependency that requires a specific permission.

    Args:
        permission: The permission required

    Returns:
        A FastAPI dependency function
    """

    async def permission_checker(
        current_user: Annotated[CurrentUser, Depends(get_current_user)],
    ) -> CurrentUser:
        """Check if user has the required permission."""
        if not current_user.has_permission(permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires permission: {permission.value}",
            )
        return current_user

    return permission_checker


# Common dependency shortcuts
RequireAuth = Annotated[CurrentUser, Depends(get_current_user)]
RequireAuthWeb = Annotated[CurrentUser, Depends(get_current_user_web)]
RequireInternal = Annotated[CurrentUser, Depends(require_role(Role.INTERNAL_USER, Role.ADMIN))]
RequireInternalStaff = RequireInternal  # Alias used by groups module
RequireAdmin = Annotated[CurrentUser, Depends(require_role(Role.ADMIN))]


async def require_internal(
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
) -> CurrentUser:
    """Require user to be internal staff or admin.

    Uses get_current_user_web so that unauthenticated web requests redirect
    to the login page instead of returning 401 JSON.
    """
    if not current_user.is_internal:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Internal access required",
        )
    return current_user


async def require_internal_api(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> CurrentUser:
    """Require user to be internal staff or admin (for API routes).

    Uses get_current_user so that unauthenticated API requests return
    401 JSON instead of redirecting to login page.
    """
    if not current_user.is_internal:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Internal access required",
        )
    return current_user


async def require_read_write(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> CurrentUser:
    """Require user to have write permissions (not read-only).

    Rejects READ_ONLY users from performing create/modify operations.
    """
    if is_read_only(current_user.roles):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Write access required. Your account has read-only permissions.",
        )
    return current_user


async def require_read_write_web(
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
) -> CurrentUser:
    """Require user to have write permissions (web routes).

    Same as require_read_write but uses get_current_user_web so that
    unauthenticated web requests redirect to the login page instead of
    returning 401 JSON.
    """
    if is_read_only(current_user.roles):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Write access required. Your account has read-only permissions.",
        )
    return current_user


async def require_audit_export(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> CurrentUser:
    """Require permission to export audit data."""
    if not current_user.has_permission(Permission.AUDIT_EXPORT):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Audit export permission required",
        )
    return current_user


async def require_org_admin(
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
) -> CurrentUser:
    """Require user to be an org admin or global admin (web routes).

    Uses get_current_user_web so unauthenticated web requests redirect to login.
    """
    if not current_user.is_org_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization admin access required",
        )
    return current_user


async def require_org_admin_api(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> CurrentUser:
    """Require user to be an org admin or global admin (API routes).

    Uses get_current_user so unauthenticated API requests return 401 JSON.
    """
    if not current_user.is_org_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization admin access required",
        )
    return current_user


# Annotated shortcuts for new permission checks
RequireReadWrite = Annotated[CurrentUser, Depends(require_read_write)]
RequireAuditExport = Annotated[CurrentUser, Depends(require_audit_export)]
RequireOrgAdmin = Annotated[CurrentUser, Depends(require_org_admin)]
RequireOrgAdminApi = Annotated[CurrentUser, Depends(require_org_admin_api)]


# --- API Docs Access Control ---

# Roles allowed to access /docs, /redoc, /openapi.json
_DOCS_ALLOWED_ROLES = {Role.ADMIN, Role.INTERNAL_USER, Role.EXTERNAL_USER_ADMIN}


async def require_docs_access(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> CurrentUser:
    """Require authenticated user with a role that grants API docs access.

    Allowed roles: ADMIN, INTERNAL_USER, EXTERNAL_USER_ADMIN.
    Blocks EXTERNAL_USER and unauthenticated requests.
    """
    if not any(current_user.has_role(role) for role in _DOCS_ALLOWED_ROLES):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="API documentation access requires ADMIN, INTERNAL_USER, or EXTERNAL_USER_ADMIN role",
        )
    return current_user


# --- User API Token Authentication ---


def _constrain_roles_by_scope(roles: list[str], scope: str | None) -> list[str]:
    """Constrain user roles based on token scope.

    Ensures tokens cannot exceed their scope regardless of the user's actual roles.

    Scope mapping:
    - ext_org:        effective max is EXTERNAL_USER (no admin, no internal, no cross-tenant)
    - lsmc_internal:  effective max is INTERNAL_USER (no admin)
    - atlas_admin:    no constraint (user's actual roles)
    - None/unknown:   defaults to ext_org (most restrictive)
    """
    from app.domain.enums import TokenScope

    if scope == TokenScope.ATLAS_ADMIN.value:
        return roles  # No constraint

    if scope == TokenScope.LSMC_INTERNAL.value:
        # Cap at INTERNAL_USER — strip ADMIN
        allowed = {
            Role.READ_ONLY.value,
            Role.READ_WRITE.value,
            Role.EXTERNAL_USER.value,
            Role.EXTERNAL_USER_ADMIN.value,
            Role.INTERNAL_USER.value,
        }
        constrained = [r for r in roles if r in allowed]
        # Ensure at least INTERNAL_USER is present if user had ADMIN
        if not constrained or (
            Role.ADMIN.value in roles and Role.INTERNAL_USER.value not in constrained
        ):
            constrained.append(Role.INTERNAL_USER.value)
        return constrained

    # Default: ext_org (most restrictive) — cap at EXTERNAL_USER
    allowed = {
        Role.READ_ONLY.value,
        Role.READ_WRITE.value,
        Role.EXTERNAL_USER.value,
    }
    constrained = [r for r in roles if r in allowed]
    # Ensure at least EXTERNAL_USER is present if user had higher roles
    if not constrained:
        constrained.append(Role.EXTERNAL_USER.value)
    return constrained


async def get_current_user_from_token(
    request: Request,
    db: Session = Depends(get_db),
) -> CurrentUser | None:
    """Authenticate user via Bearer token (user API token).

    Returns CurrentUser if valid token provided, None otherwise.
    Does not raise exceptions - caller decides if auth is optional.
    Token scope constrains effective permissions.
    """
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return None

    token = auth_header[7:]  # Strip "Bearer " prefix

    # Check if it looks like a user API token (starts with lsmc_)
    if not token.startswith("lsmc_"):
        return None

    svc = UserAPITokenService(db)
    result = svc.validate(token)

    if not result.is_valid:
        return None

    # Note: result.user_id is the cognito_sub stored as UUID, not the profile PK.
    user_profile = UserService(db).get_by_cognito_sub(str(result.user_id))
    if not user_profile or not user_profile.is_active:
        return None

    # Update last_used_at and log usage (fire and forget pattern)
    try:
        svc.update_last_used(result.token_id)
        svc.log_usage(
            token_id=result.token_id,
            tenant_id=result.tenant_id,
            endpoint=str(request.url.path),
            http_method=request.method,
            response_status=200,  # Will be updated by middleware
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("User-Agent"),
        )
    except Exception:
        pass  # Don't fail auth on logging errors

    # Constrain roles based on token scope
    effective_roles = _constrain_roles_by_scope(user_profile.roles or [], result.scope)

    return CurrentUser(
        sub=str(result.user_id),
        email=user_profile.email,
        name=user_profile.name,
        tenant_id=result.tenant_id,
        roles=effective_roles,
    )


async def get_current_user_or_token(
    request: Request,
    db: Session = Depends(get_db),
) -> CurrentUser:
    """Get user from session OR valid API token.

    Priority:
    1. Session-based authentication (for browser users)
    2. Bearer token authentication (for API clients)

    Raises 401 if neither is valid.
    """
    # Try session first
    user = _get_current_user_from_session(request)
    if user:
        return user

    # Try API token
    user = await get_current_user_from_token(request, db)
    if user:
        return user

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )


# Annotated shortcut for API routes that accept both session and token auth
RequireAuthOrToken = Annotated[CurrentUser, Depends(get_current_user_or_token)]


@dataclass
class IntegrationClientPrincipal:
    """Authenticated integration client context."""

    client_id: uuid.UUID
    tenant_id: uuid.UUID
    client_name: str
    permissions: list[str]
    allowed_endpoints: list[str] | None


async def get_bloom_integration_client(
    request: Request,
    db: Session = Depends(get_db),
) -> IntegrationClientPrincipal:
    """Authenticate Bloom integration calls via org-scoped API client credentials."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = auth_header[7:].strip()
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    svc = APIClientService(db, tenant_id=uuid.UUID(int=0))
    validated = svc.validate_api_key_any_tenant(token)
    if validated is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid integration token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    client, revision = validated
    permissions = list(revision.permissions or [])
    if "bloom:atlas:write" not in permissions and "*" not in permissions:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Integration client missing permission bloom:atlas:write",
        )

    allowed_endpoints = revision.allowed_endpoints or []
    if allowed_endpoints:
        path = request.url.path
        if not any(path.startswith(prefix) for prefix in allowed_endpoints):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Integration client not allowed for this endpoint",
            )

    try:
        tenant_svc = APIClientService(db, tenant_id=client.tenant_id)
        tenant_svc.log_usage(
            client_id=client.id,
            endpoint=str(request.url.path),
            method=request.method,
            status_code=200,
            ip_address=request.client.host if request.client else None,
        )
    except Exception:
        pass

    return IntegrationClientPrincipal(
        client_id=client.id,
        tenant_id=client.tenant_id,
        client_name=client.client_name,
        permissions=permissions,
        allowed_endpoints=revision.allowed_endpoints,
    )


RequireBloomIntegrationClient = Annotated[
    IntegrationClientPrincipal,
    Depends(get_bloom_integration_client),
]
