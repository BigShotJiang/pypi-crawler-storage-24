"""LSMC Hub - CAPTCHA Integration.

Provides CAPTCHA verification for sensitive operations.
Supports multiple providers (Google reCAPTCHA, hCaptcha, or simple challenge).
"""

import hashlib
import secrets
import time
from dataclasses import dataclass
from enum import StrEnum

import httpx
from fastapi import HTTPException, Request, status

from app.settings import settings


class CaptchaProvider(StrEnum):
    """Supported CAPTCHA providers."""

    RECAPTCHA_V2 = "recaptcha_v2"
    RECAPTCHA_V3 = "recaptcha_v3"
    HCAPTCHA = "hcaptcha"
    SIMPLE = "simple"  # Built-in simple challenge for dev/testing
    DISABLED = "disabled"


@dataclass
class CaptchaConfig:
    """CAPTCHA configuration."""

    provider: CaptchaProvider = CaptchaProvider.SIMPLE
    site_key: str = ""
    secret_key: str = ""
    score_threshold: float = 0.5  # For reCAPTCHA v3


# Simple challenge store (in-memory, for dev/testing)
_simple_challenges: dict[str, tuple[str, float]] = {}


def generate_simple_challenge() -> dict[str, str]:
    """Generate a simple math challenge for dev/testing."""
    import random

    a = random.randint(1, 20)
    b = random.randint(1, 20)
    answer = str(a + b)

    challenge_id = secrets.token_urlsafe(16)
    _simple_challenges[challenge_id] = (
        hashlib.sha256(answer.encode()).hexdigest(),
        time.time() + 300,  # 5 minute expiry
    )

    return {
        "challenge_id": challenge_id,
        "question": f"What is {a} + {b}?",
        "type": "simple",
    }


def verify_simple_challenge(challenge_id: str, answer: str) -> bool:
    """Verify a simple challenge answer."""
    if challenge_id not in _simple_challenges:
        return False

    expected_hash, expiry = _simple_challenges[challenge_id]

    # Check expiry
    if time.time() > expiry:
        del _simple_challenges[challenge_id]
        return False

    # Verify answer
    answer_hash = hashlib.sha256(answer.strip().encode()).hexdigest()
    if answer_hash == expected_hash:
        del _simple_challenges[challenge_id]
        return True

    return False


async def verify_recaptcha(token: str, config: CaptchaConfig) -> bool:
    """Verify Google reCAPTCHA token."""
    url = "https://www.google.com/recaptcha/api/siteverify"
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url,
            data={
                "secret": config.secret_key,
                "response": token,
            },
        )
        result = response.json()

        if config.provider == CaptchaProvider.RECAPTCHA_V3:
            return result.get("success", False) and result.get("score", 0) >= config.score_threshold
        return result.get("success", False)


async def verify_hcaptcha(token: str, config: CaptchaConfig) -> bool:
    """Verify hCaptcha token."""
    url = "https://hcaptcha.com/siteverify"
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url,
            data={
                "secret": config.secret_key,
                "response": token,
            },
        )
        result = response.json()
        return result.get("success", False)


# Default configuration (can be overridden in settings)
_captcha_config = CaptchaConfig(
    provider=CaptchaProvider.SIMPLE,
)


def get_captcha_config() -> CaptchaConfig:
    """Get the current CAPTCHA configuration."""
    return CaptchaConfig(
        provider=CaptchaProvider(settings.captcha_provider),
        site_key=settings.captcha_site_key,
        secret_key=settings.captcha_secret_key,
        score_threshold=settings.captcha_score_threshold,
    )


async def verify_captcha(
    token: str | None = None,
    challenge_id: str | None = None,
    answer: str | None = None,
) -> bool:
    """Verify CAPTCHA based on configured provider.

    Args:
        token: CAPTCHA token from provider (reCAPTCHA, hCaptcha)
        challenge_id: ID for simple challenge
        answer: Answer for simple challenge
    """
    config = get_captcha_config()

    if config.provider == CaptchaProvider.DISABLED:
        return True

    if config.provider == CaptchaProvider.SIMPLE:
        if not challenge_id or not answer:
            return False
        return verify_simple_challenge(challenge_id, answer)

    if not token:
        return False

    if config.provider in (CaptchaProvider.RECAPTCHA_V2, CaptchaProvider.RECAPTCHA_V3):
        return await verify_recaptcha(token, config)

    if config.provider == CaptchaProvider.HCAPTCHA:
        return await verify_hcaptcha(token, config)

    return False


async def require_captcha(request: Request) -> None:
    """FastAPI dependency that requires valid CAPTCHA.

    For form submissions, expects:
    - captcha_token (for reCAPTCHA/hCaptcha)
    - challenge_id + captcha_answer (for simple challenge)
    """
    config = get_captcha_config()
    if config.provider == CaptchaProvider.DISABLED:
        return

    content_type = request.headers.get("content-type", "")

    if "application/json" in content_type:
        body = await request.json()
        token = body.get("captcha_token")
        challenge_id = body.get("challenge_id")
        answer = body.get("captcha_answer")
    elif "form" in content_type:
        form = await request.form()
        token = form.get("captcha_token")
        challenge_id = form.get("challenge_id")
        answer = form.get("captcha_answer")
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Unsupported content type"
        )

    if not await verify_captcha(token=token, challenge_id=challenge_id, answer=answer):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="CAPTCHA verification failed"
        )
