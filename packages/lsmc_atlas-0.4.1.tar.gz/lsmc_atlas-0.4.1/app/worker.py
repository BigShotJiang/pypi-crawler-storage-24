#!/usr/bin/env python
"""LSMC Hub - Standalone Background Job Worker.

This module provides a standalone worker process for running background jobs
independently of the web application. In production, you should:

1. Run the web application with background jobs disabled:
   ENABLE_BACKGROUND_JOBS=false uvicorn app.main:app --workers 4

2. Run this worker as a separate process:
   python -m app.worker

This separation allows:
- Independent scaling of web workers vs job workers
- Preventing job failures from affecting web request handling
- Running jobs on dedicated hardware if needed

Usage:
    # Run as module
    python -m app.worker

    # Or directly
    python app/worker.py

    # With custom tracking interval (seconds)
    TRACKING_UPDATE_INTERVAL=3600 python -m app.worker
"""

import asyncio
import logging
import signal
import sys
from typing import NoReturn

# Configure logging before other imports
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


async def run_worker() -> NoReturn:
    """Run the background job worker.

    This function starts the scheduler and runs indefinitely until
    interrupted (SIGINT/SIGTERM).
    """
    from app.db.engine import SessionLocal
    from app.domain.services.background_jobs import get_scheduler, run_tracking_update_job
    from app.settings import settings

    logger.info("Starting LSMC Hub Background Worker")
    logger.info(f"Tracking update interval: {settings.tracking_update_interval}s")

    scheduler = get_scheduler()

    # Setup signal handlers for graceful shutdown
    shutdown_event = asyncio.Event()

    def handle_shutdown(signum, frame):
        logger.info(f"Received signal {signum}, initiating graceful shutdown...")
        shutdown_event.set()

    signal.signal(signal.SIGINT, handle_shutdown)
    signal.signal(signal.SIGTERM, handle_shutdown)

    try:
        # Start the scheduler
        await scheduler.start()
        logger.info("Scheduler started")

        # Schedule FedEx tracking updates
        scheduler.schedule_recurring(
            "fedex_tracking_update",
            run_tracking_update_job,
            interval_seconds=settings.tracking_update_interval,
            db_factory=SessionLocal,
        )
        logger.info("FedEx tracking job scheduled")

        # Wait for shutdown signal
        logger.info("Worker running. Press Ctrl+C to stop.")
        await shutdown_event.wait()

    except Exception as e:
        logger.error(f"Worker error: {e}")
        raise
    finally:
        # Graceful shutdown
        logger.info("Stopping scheduler...")
        await scheduler.stop()
        logger.info("Worker stopped")


def main() -> None:
    """Main entry point for the worker process."""
    try:
        asyncio.run(run_worker())
    except KeyboardInterrupt:
        logger.info("Worker interrupted")
    except Exception as e:
        logger.error(f"Worker failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
