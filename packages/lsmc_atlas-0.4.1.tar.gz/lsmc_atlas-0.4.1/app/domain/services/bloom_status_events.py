"""Apply Bloom-driven Test status events with deterministic TRF rollup."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from daylily_tapdb.models.instance import generic_instance

from app.domain.enums import OrderStatus, TestOrderStatus
from app.domain.services.trfs import TestService, TrfService
from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid
from app.persistence.tapdb.trfs import (
    TEST_REV_TEMPLATE_CODE,
    TEST_TEMPLATE_CODE,
    TRF_REV_TEMPLATE_CODE,
)

_TERMINAL_TEST_ORDER_STATUSES = {
    TestOrderStatus.COMPLETED.value,
    TestOrderStatus.FAILED.value,
    TestOrderStatus.CANCELED.value,
    TestOrderStatus.REJECTED.value,
}


def compute_order_status_from_tests(statuses: list[str]) -> OrderStatus:
    """Compute TRF status from child Test statuses."""
    normalized = [
        str(value or "").strip().upper() for value in statuses if str(value or "").strip()
    ]

    if any(value == TestOrderStatus.ON_HOLD.value for value in normalized):
        return OrderStatus.QC_HOLD

    if normalized and all(value in _TERMINAL_TEST_ORDER_STATUSES for value in normalized):
        if any(value == TestOrderStatus.COMPLETED.value for value in normalized):
            return OrderStatus.RESULTS_READY
        return OrderStatus.CLOSED_NO_RESULTS

    if any(
        value in {TestOrderStatus.IN_PROGRESS.value, TestOrderStatus.SPECIMEN_RECEIVED.value}
        for value in normalized
    ):
        return OrderStatus.IN_PROGRESS

    return OrderStatus.ORDERED


@dataclass
class BloomStatusEventResult:
    applied: bool
    idempotent_replay: bool
    test_euid: str
    test_status: str
    trf_euid: str
    trf_number: str
    trf_status: str
    status_event_id: str | None
    trf_status_event_id: str | None


class BloomStatusEventNotFoundError(ValueError):
    """Raised when target Test is not found for tenant."""


class BloomStatusEventTenantMismatchError(ValueError):
    """Raised when requested tenant does not match target Test tenant."""


class BloomStatusEventService:
    """Service for applying Bloom status events to Atlas Tests."""

    def __init__(self, db, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.orders = TrfService(db, tenant_id)
        self.test_orders = TestService(db, tenant_id)

    @staticmethod
    def _instance_properties(instance: generic_instance) -> dict[str, Any]:
        payload = instance.json_addl if isinstance(instance.json_addl, dict) else {}
        props = payload.get("properties")
        if isinstance(props, dict):
            return props
        return {}

    def _iter_revision_instances(
        self, *, entity_type: str, entity_euid: str
    ) -> list[generic_instance]:
        if entity_type == "Test":
            instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, entity_euid)
            template_code = TEST_REV_TEMPLATE_CODE
        elif entity_type == "TRF":
            from app.persistence.tapdb.trfs import TRF_TEMPLATE_CODE

            instance = get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, entity_euid)
            template_code = TRF_REV_TEMPLATE_CODE
        else:
            return []
        if instance is None:
            return []
        revisions = get_child_instances(self.db, instance, template_code)

        def _revision_no(child: generic_instance) -> int:
            props = self._instance_properties(child)
            try:
                return int(props.get("revision_no") or 0)
            except (TypeError, ValueError):
                return 0

        revisions.sort(key=_revision_no, reverse=True)
        return revisions

    def apply_test_status_event(
        self,
        *,
        test_euid: str,
        event_id: str,
        idempotency_key: str,
        status: str,
        occurred_at: datetime,
        reason: str | None = None,
        container_euid: str | None = None,
        specimen_euid: str | None = None,
        metadata: dict[str, Any] | None = None,
        actor_id: uuid.UUID | None = None,
    ) -> BloomStatusEventResult:
        target_status = TestOrderStatus(str(status).strip().upper())
        self._ensure_test_exists(test_euid)

        existing_event_revision_euid = self._find_revision_for_event_id(
            entity_type="Test",
            entity_euid=test_euid,
            event_id=event_id,
        )
        if existing_event_revision_euid is not None:
            return self._build_result(
                test_euid=test_euid,
                status_event_id=existing_event_revision_euid,
                applied=False,
                idempotent_replay=True,
                trf_status_event_id=None,
            )

        event_reason = reason.strip() if reason and reason.strip() else "Bloom status event"
        event_reason = (
            f"{event_reason} "
            f"[event_id={event_id}; idempotency_key={idempotency_key}; occurred_at={occurred_at.isoformat()}; "
            f"container_euid={container_euid or ''}; specimen_euid={specimen_euid or ''}; metadata={metadata or {}}]"
        )

        changed = self.test_orders.change_status(
            test_euid,
            target_status,
            reason=event_reason,
            updated_by=actor_id,
            cross_tenant=False,
        )
        if changed is None:
            raise BloomStatusEventNotFoundError(f"Test not found: {test_euid}")

        test_status_event_id = self._latest_revision_euid_for_status(
            entity_type="Test",
            entity_euid=test_euid,
            status=target_status.value,
        )
        trf_status_event_id = self._apply_trf_rollup(
            trf_euid=changed.order_id,
            event_id=event_id,
            actor_id=actor_id,
        )

        return self._build_result(
            test_euid=test_euid,
            status_event_id=test_status_event_id,
            applied=True,
            idempotent_replay=False,
            trf_status_event_id=trf_status_event_id,
        )

    def _apply_trf_rollup(
        self,
        *,
        trf_euid: str,
        event_id: str,
        actor_id: uuid.UUID | None,
    ) -> str | None:
        trf_result = self.orders.get(trf_euid, cross_tenant=False)
        if trf_result is None:
            raise BloomStatusEventNotFoundError(f"TRF not found for Test: {trf_euid}")
        trf, current_trf_revision = trf_result

        tests = self.test_orders.list_for_trf(trf_euid, cross_tenant=False)
        statuses = [revision.status for _test, revision, _assays in tests if revision is not None]
        derived = compute_order_status_from_tests(statuses)
        if current_trf_revision and current_trf_revision.status == derived.value:
            return None

        changed = self.orders.change_status(
            trf.euid,
            derived,
            reason=f"Bloom rollup from Test states [event_id={event_id}]",
            updated_by=actor_id,
            cross_tenant=False,
        )
        if changed is None:
            return None

        return self._latest_revision_euid_for_status(
            entity_type="TRF",
            entity_euid=trf.euid,
            status=derived.value,
        )

    def _build_result(
        self,
        *,
        test_euid: str,
        status_event_id: str | None,
        applied: bool,
        idempotent_replay: bool,
        trf_status_event_id: str | None,
    ) -> BloomStatusEventResult:
        test_result = self.test_orders.get_with_revision(test_euid, cross_tenant=False)
        if test_result is None:
            raise BloomStatusEventNotFoundError(f"Test not found: {test_euid}")
        test, test_revision = test_result
        trf_result = self.orders.get(test.order_id, cross_tenant=False)
        if trf_result is None:
            raise BloomStatusEventNotFoundError(f"TRF not found for Test: {test.order_id}")
        trf, trf_revision = trf_result
        return BloomStatusEventResult(
            applied=applied,
            idempotent_replay=idempotent_replay,
            test_euid=test_euid,
            test_status=test_revision.status if test_revision else "",
            trf_euid=trf.euid,
            trf_number=trf.order_number,
            trf_status=trf_revision.status if trf_revision else "",
            status_event_id=status_event_id,
            trf_status_event_id=trf_status_event_id,
        )

    def _find_revision_for_event_id(
        self,
        *,
        entity_type: str,
        entity_euid: str,
        event_id: str,
    ) -> str | None:
        token = f"event_id={event_id}"
        for revision in self._iter_revision_instances(
            entity_type=entity_type, entity_euid=entity_euid
        ):
            note = str(self._instance_properties(revision).get("note") or "")
            if token in note:
                return revision.euid
        return None

    def _latest_revision_euid_for_status(
        self,
        *,
        entity_type: str,
        entity_euid: str,
        status: str,
    ) -> str | None:
        target = str(status or "").strip().upper()
        for revision in self._iter_revision_instances(
            entity_type=entity_type, entity_euid=entity_euid
        ):
            revision_status = (
                str(self._instance_properties(revision).get("status") or "").strip().upper()
            )
            if revision_status == target:
                return revision.euid
        return None

    def _ensure_test_exists(self, test_euid: str):
        test = self.test_orders.get_by_id(test_euid, cross_tenant=False)
        if test is None:
            cross_tenant = self.test_orders.get_by_id(test_euid, cross_tenant=True)
            if cross_tenant is not None and cross_tenant.tenant_id != self.tenant_id:
                raise BloomStatusEventTenantMismatchError(
                    f"Tenant mismatch for Test {test_euid}: "
                    f"requested={self.tenant_id} actual={cross_tenant.tenant_id}"
                )
            raise BloomStatusEventNotFoundError(f"Test not found: {test_euid}")
        return test
