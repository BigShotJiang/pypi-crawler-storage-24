"""LSMC Hub - Audit Export Service.

Provides TSV export functionality for audit data.
All exports are tenant-scoped and audit-logged.
"""

from __future__ import annotations

import csv
import io
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from sqlalchemy.orm import Session

from app.domain.enums import AuditAction
from app.domain.services.audit import AuditService
from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid
from app.persistence.tapdb.logistics import (
    SHIPMENT_REV_TEMPLATE_CODE,
    SHIPMENT_TEMPLATE_CODE,
    TapdbLogisticsRepository,
)
from app.persistence.tapdb.people import (
    CLINICIAN_REV_TEMPLATE_CODE,
    CLINICIAN_TEMPLATE_CODE,
    PATIENT_REV_TEMPLATE_CODE,
    PATIENT_TEMPLATE_CODE,
    TapdbPeopleRepository,
)
from app.persistence.tapdb.trfs import (
    TRF_REV_TEMPLATE_CODE,
    TRF_TEMPLATE_CODE,
    TapdbTrfRepository,
)


class AuditEntityType(StrEnum):
    """Entities with audit history export support."""

    ORDER = "order"
    PATIENT = "patient"
    CLINICIAN = "clinician"
    SHIPMENT = "shipment"


# Columns to include in TSV export (excluding sensitive data)
EXPORT_COLUMNS = {
    AuditEntityType.ORDER: [
        "order_id",
        "order_number",
        "revision_no",
        "order_type",
        "status",
        "is_stat",
        "indication",
        "submitted_at",
        "order_created_at",
        "revision_created_at",
        "revision_created_by",
        "revision_note",
    ],
    AuditEntityType.PATIENT: [
        "patient_id",
        "revision_no",
        "first_name",
        "last_name",
        "date_of_birth",
        "sex",
        "mrn",
        "patient_created_at",
        "revision_created_at",
        "revision_created_by",
        "revision_note",
    ],
    AuditEntityType.CLINICIAN: [
        "clinician_id",
        "revision_no",
        "first_name",
        "last_name",
        "credentials",
        "npi",
        "specialty",
        "is_active",
        "clinician_created_at",
        "revision_created_at",
        "revision_created_by",
        "revision_note",
    ],
    AuditEntityType.SHIPMENT: [
        "shipment_id",
        "shipment_number",
        "revision_no",
        "status",
        "carrier",
        "tracking_number",
        "shipped_at",
        "received_at",
        "shipment_created_at",
        "revision_created_at",
        "revision_created_by",
        "revision_note",
    ],
}


@dataclass
class AuditExportResult:
    """Result of an audit export operation."""

    entity_type: AuditEntityType
    row_count: int
    tsv_content: str
    exported_at: datetime


class AuditExportService:
    """Service for exporting audit history data from TapDB records."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id

    def export_entity_history(
        self,
        entity_type: AuditEntityType,
        user_id: uuid.UUID | None,
        entity_id: str | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
    ) -> AuditExportResult:
        """Export audit history for an entity type to TSV."""
        columns = EXPORT_COLUMNS[entity_type]
        rows = self._build_rows(
            entity_type=entity_type,
            entity_id=entity_id,
            start_date=start_date,
            end_date=end_date,
        )

        output = io.StringIO()
        writer = csv.writer(output, delimiter="\t")
        writer.writerow(columns)
        for row in rows:
            writer.writerow([self._format_value(row.get(column)) for column in columns])

        tsv_content = output.getvalue()

        audit_svc = AuditService(db=self.db, tenant_id=self.tenant_id, user_id=str(user_id))
        audit_svc.log(
            action=AuditAction.DOWNLOAD,
            entity_type=f"AuditExport:{entity_type.value}",
            entity_id=entity_id,
            user_id=user_id,
            details={
                "row_count": len(rows),
                "start_date": start_date.isoformat() if start_date else None,
                "end_date": end_date.isoformat() if end_date else None,
            },
        )

        return AuditExportResult(
            entity_type=entity_type,
            row_count=len(rows),
            tsv_content=tsv_content,
            exported_at=datetime.now(UTC),
        )

    def _build_rows(
        self,
        *,
        entity_type: AuditEntityType,
        entity_id: str | None,
        start_date: datetime | None,
        end_date: datetime | None,
    ) -> list[dict[str, Any]]:
        if entity_type == AuditEntityType.ORDER:
            return self._order_rows(entity_id=entity_id, start_date=start_date, end_date=end_date)
        if entity_type == AuditEntityType.PATIENT:
            return self._patient_rows(entity_id=entity_id, start_date=start_date, end_date=end_date)
        if entity_type == AuditEntityType.CLINICIAN:
            return self._clinician_rows(
                entity_id=entity_id, start_date=start_date, end_date=end_date
            )
        if entity_type == AuditEntityType.SHIPMENT:
            return self._shipment_rows(
                entity_id=entity_id, start_date=start_date, end_date=end_date
            )
        return []

    @staticmethod
    def _in_range(
        value: datetime | None,
        *,
        start_date: datetime | None,
        end_date: datetime | None,
    ) -> bool:
        if value is None:
            return start_date is None and end_date is None
        if start_date and value < start_date:
            return False
        if end_date and value > end_date:
            return False
        return True

    def _order_rows(
        self,
        *,
        entity_id: str | None,
        start_date: datetime | None,
        end_date: datetime | None,
    ) -> list[dict[str, Any]]:
        repo = TapdbTrfRepository(self.db)
        rows: list[dict[str, Any]] = []
        trfs = repo.list_trfs(tenant_id=self.tenant_id, limit=1_000_000, offset=0)
        for trf, _latest_revision in trfs:
            if entity_id and trf.euid != entity_id:
                continue
            trf_instance = get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, trf.euid)
            if trf_instance is None:
                continue
            revisions = [
                repo._to_trf_revision(child)
                for child in get_child_instances(self.db, trf_instance, TRF_REV_TEMPLATE_CODE)
            ]  # noqa: SLF001
            revisions.sort(key=lambda revision: revision.revision_no)
            for revision in revisions:
                if not self._in_range(
                    revision.created_at,
                    start_date=start_date,
                    end_date=end_date,
                ):
                    continue
                rows.append(
                    {
                        "order_id": trf.euid,
                        "order_number": trf.order_number,
                        "revision_no": revision.revision_no,
                        "order_type": revision.order_type,
                        "status": revision.status,
                        "is_stat": revision.is_stat,
                        "indication": revision.indication,
                        "submitted_at": revision.submitted_at,
                        "order_created_at": trf.created_at,
                        "revision_created_at": revision.created_at,
                        "revision_created_by": revision.created_by,
                        "revision_note": revision.note,
                    }
                )
        rows.sort(key=lambda row: row.get("revision_created_at") or datetime.min)
        return rows

    def _patient_rows(
        self,
        *,
        entity_id: str | None,
        start_date: datetime | None,
        end_date: datetime | None,
    ) -> list[dict[str, Any]]:
        repo = TapdbPeopleRepository(self.db)
        rows: list[dict[str, Any]] = []
        patients = repo.list_patients(tenant_id=self.tenant_id, limit=1_000_000, offset=0)
        for patient, _latest_revision in patients:
            if entity_id and patient.euid != entity_id:
                continue
            patient_instance = get_instance_by_euid(self.db, PATIENT_TEMPLATE_CODE, patient.euid)
            if patient_instance is None:
                continue
            revisions = [
                repo._to_patient_revision(child)
                for child in get_child_instances(
                    self.db, patient_instance, PATIENT_REV_TEMPLATE_CODE
                )
            ]  # noqa: SLF001
            revisions.sort(key=lambda revision: revision.revision_no)
            for revision in revisions:
                if not self._in_range(
                    revision.created_at,
                    start_date=start_date,
                    end_date=end_date,
                ):
                    continue
                rows.append(
                    {
                        "patient_id": patient.euid,
                        "revision_no": revision.revision_no,
                        "first_name": revision.first_name,
                        "last_name": revision.last_name,
                        "date_of_birth": revision.date_of_birth,
                        "sex": revision.sex,
                        "mrn": revision.mrn,
                        "patient_created_at": patient.created_at,
                        "revision_created_at": revision.created_at,
                        "revision_created_by": revision.created_by,
                        "revision_note": revision.note,
                    }
                )
        rows.sort(key=lambda row: row.get("revision_created_at") or datetime.min)
        return rows

    def _clinician_rows(
        self,
        *,
        entity_id: str | None,
        start_date: datetime | None,
        end_date: datetime | None,
    ) -> list[dict[str, Any]]:
        repo = TapdbPeopleRepository(self.db)
        rows: list[dict[str, Any]] = []
        clinicians = repo.list_clinicians(
            tenant_id=self.tenant_id,
            skip=0,
            limit=1_000_000,
            active_only=False,
        )
        for clinician, _latest_revision in clinicians:
            if entity_id and clinician.euid != entity_id:
                continue
            clinician_instance = get_instance_by_euid(
                self.db, CLINICIAN_TEMPLATE_CODE, clinician.euid
            )
            if clinician_instance is None:
                continue
            revisions = [
                repo._to_clinician_revision(child)
                for child in get_child_instances(
                    self.db, clinician_instance, CLINICIAN_REV_TEMPLATE_CODE
                )
            ]  # noqa: SLF001
            revisions.sort(key=lambda revision: revision.revision_no)
            for revision in revisions:
                if not self._in_range(
                    revision.created_at,
                    start_date=start_date,
                    end_date=end_date,
                ):
                    continue
                rows.append(
                    {
                        "clinician_id": clinician.euid,
                        "revision_no": revision.revision_no,
                        "first_name": revision.first_name,
                        "last_name": revision.last_name,
                        "credentials": revision.credentials,
                        "npi": revision.npi,
                        "specialty": revision.specialty,
                        "is_active": revision.is_active,
                        "clinician_created_at": clinician.created_at,
                        "revision_created_at": revision.created_at,
                        "revision_created_by": revision.created_by,
                        "revision_note": revision.note,
                    }
                )
        rows.sort(key=lambda row: row.get("revision_created_at") or datetime.min)
        return rows

    def _shipment_rows(
        self,
        *,
        entity_id: str | None,
        start_date: datetime | None,
        end_date: datetime | None,
    ) -> list[dict[str, Any]]:
        repo = TapdbLogisticsRepository(self.db)
        rows: list[dict[str, Any]] = []
        shipments = repo.list_shipments(tenant_id=self.tenant_id, skip=0, limit=1_000_000)
        for shipment, _latest_revision in shipments:
            if entity_id and shipment.euid != entity_id:
                continue
            shipment_instance = get_instance_by_euid(self.db, SHIPMENT_TEMPLATE_CODE, shipment.euid)
            if shipment_instance is None:
                continue
            revisions = [
                repo._to_shipment_revision(child)
                for child in get_child_instances(
                    self.db, shipment_instance, SHIPMENT_REV_TEMPLATE_CODE
                )
            ]  # noqa: SLF001
            revisions.sort(key=lambda revision: revision.revision_no)
            for revision in revisions:
                if not self._in_range(
                    revision.created_at,
                    start_date=start_date,
                    end_date=end_date,
                ):
                    continue
                rows.append(
                    {
                        "shipment_id": shipment.euid,
                        "shipment_number": shipment.shipment_number,
                        "revision_no": revision.revision_no,
                        "status": revision.status,
                        "carrier": revision.carrier,
                        "tracking_number": revision.tracking_number,
                        "shipped_at": revision.shipped_at,
                        "received_at": revision.received_at,
                        "shipment_created_at": shipment.created_at,
                        "revision_created_at": revision.created_at,
                        "revision_created_by": revision.created_by,
                        "revision_note": revision.note,
                    }
                )
        rows.sort(key=lambda row: row.get("revision_created_at") or datetime.min)
        return rows

    @staticmethod
    def _format_value(value: Any) -> str:
        """Format a value for TSV output."""
        if value is None:
            return ""
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, uuid.UUID):
            return str(value)
        return str(value)
