"""TapDB lineage links between Test Kits and TRFs."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.domain.services.trfs import TrfService
from app.persistence.tapdb.euid_helpers import get_instance_by_euid
from app.persistence.tapdb.logistics import TEST_KIT_TEMPLATE_CODE, TapdbLogisticsRepository
from app.persistence.tapdb.trfs import TRF_TEMPLATE_CODE

REL_TRF_CONTAINED_IN_TESTKIT = "trf_contained_in_testkit"


@dataclass(frozen=True)
class LinkedTrf:
    trf_euid: str
    trf_number: str
    status: str | None
    linked_at: datetime | None


class TestKitTrfLinkService:
    """Manage TRF membership links for a test kit."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._logistics_repo: TapdbLogisticsRepository | None = None

    def _repo(self) -> TapdbLogisticsRepository:
        if self._logistics_repo is None:
            self._logistics_repo = TapdbLogisticsRepository(self.db)
        return self._logistics_repo

    @staticmethod
    def _instance_properties(instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties") if isinstance(raw, dict) else None
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _instance_tenant_id(self, instance: generic_instance) -> uuid.UUID | None:
        props = self._instance_properties(instance)
        value = props.get("tenant_id")
        if isinstance(value, uuid.UUID):
            return value
        if isinstance(value, str) and value.strip():
            try:
                return uuid.UUID(value)
            except ValueError:
                return None
        return None

    def _assert_tenant_scope(self, instance: generic_instance, *, label: str) -> None:
        tenant_value = self._instance_tenant_id(instance)
        if tenant_value is not None and tenant_value != self.tenant_id:
            raise ValueError(f"Cross-tenant write denied for {label}")

    def _resolve_testkit_instance(self, testkit_euid: str) -> generic_instance:
        testkit = get_instance_by_euid(self.db, TEST_KIT_TEMPLATE_CODE, testkit_euid)
        if testkit is None:
            raise ValueError(f"TestKit not found: {testkit_euid}")
        self._assert_tenant_scope(testkit, label="test kit")
        return testkit

    def _resolve_trf_instance(self, trf_euid: str) -> generic_instance:
        trf = get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, trf_euid)
        if trf is None:
            raise ValueError(f"TRF not found: {trf_euid}")
        self._assert_tenant_scope(trf, label="TRF")
        return trf

    def link_trf(self, *, testkit_euid: str, trf_euid: str, created_by: uuid.UUID | None) -> bool:
        """Create or reactivate a TRF->TestKit membership relation.

        Returns True when a relation is created/reactivated, False when already active.
        """
        testkit = self._resolve_testkit_instance(testkit_euid)
        trf = self._resolve_trf_instance(trf_euid)

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == testkit.uid,
                generic_instance_lineage.child_instance_uid == trf.uid,
                generic_instance_lineage.relationship_type == REL_TRF_CONTAINED_IN_TESTKIT,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()

        props: dict[str, Any] = {}
        if created_by is not None:
            props["created_by"] = str(created_by)

        if existing is not None and not existing.is_deleted:
            if props:
                existing.json_addl = {"properties": props}
                self.db.flush()
            return False

        if existing is not None and existing.is_deleted:
            existing.is_deleted = False
            if props:
                existing.json_addl = {"properties": props}
            self.db.flush()
            return True

        lineage = self._repo().factory.link_instances(
            session=self.db,
            parent=testkit,
            child=trf,
            relationship_type=REL_TRF_CONTAINED_IN_TESTKIT,
        )
        if props:
            lineage.json_addl = {"properties": props}
        self.db.flush()
        return True

    def unlink_trf(self, *, testkit_euid: str, trf_euid: str, removed_by: uuid.UUID | None) -> bool:
        """Soft-delete a TRF->TestKit membership relation (idempotent)."""
        testkit = self._resolve_testkit_instance(testkit_euid)
        trf = self._resolve_trf_instance(trf_euid)

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == testkit.uid,
                generic_instance_lineage.child_instance_uid == trf.uid,
                generic_instance_lineage.relationship_type == REL_TRF_CONTAINED_IN_TESTKIT,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            return False

        existing.is_deleted = True
        if removed_by is not None:
            existing.json_addl = {"properties": {"removed_by": str(removed_by)}}
        self.db.flush()
        return True

    def list_linked_trfs(self, *, testkit_euid: str) -> list[LinkedTrf]:
        """List active TRFs linked to a test kit."""
        try:
            testkit = self._resolve_testkit_instance(testkit_euid)
        except ValueError:
            return []

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == testkit.uid,
                generic_instance_lineage.relationship_type == REL_TRF_CONTAINED_IN_TESTKIT,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt.asc(), generic_instance_lineage.uid.asc())
        )
        edges = list(self.db.execute(stmt).scalars().all())
        if not edges:
            return []

        child_uids = [edge.child_instance_uid for edge in edges]
        inst_stmt = select(generic_instance).where(generic_instance.uid.in_(child_uids))
        instances = list(self.db.execute(inst_stmt).scalars().all())
        trf_by_uid = {inst.uid: inst for inst in instances if not inst.is_deleted}

        trf_service = TrfService(self.db, self.tenant_id)
        linked: list[LinkedTrf] = []
        for edge in edges:
            trf_instance = trf_by_uid.get(edge.child_instance_uid)
            if trf_instance is None:
                continue
            tenant_value = self._instance_tenant_id(trf_instance)
            if tenant_value is not None and tenant_value != self.tenant_id:
                continue
            trf_result = trf_service.get_by_id(trf_instance.euid, cross_tenant=False)
            if trf_result is None:
                linked.append(
                    LinkedTrf(
                        trf_euid=trf_instance.euid,
                        trf_number=trf_instance.euid,
                        status=None,
                        linked_at=edge.created_dt,
                    )
                )
                continue
            trf, trf_revision = trf_result
            linked.append(
                LinkedTrf(
                    trf_euid=trf.euid,
                    trf_number=trf.order_number,
                    status=trf_revision.status,
                    linked_at=edge.created_dt,
                )
            )
        return linked
