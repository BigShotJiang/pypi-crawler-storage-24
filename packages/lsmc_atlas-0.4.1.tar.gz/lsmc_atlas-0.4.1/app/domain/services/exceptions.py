"""LSMC Hub - Exception Service.

Provides operations for managing intake exceptions with:
- Tenant scoping
- Exception creation from intake failures
- Assignment and resolution workflow
- Audit logging
"""

import uuid
from dataclasses import dataclass
from typing import Any

from app.domain.enums import AuditAction, ExceptionStatus, ExceptionType
from app.domain.services.audit_utils import log_tapdb_audit_event
from app.domain.services.webhook_emitter import emit_exception_created, emit_exception_resolved


@dataclass
class ExceptionCreate:
    """Data for creating a new exception."""

    exception_type: ExceptionType
    trigger_entity_type: str | None = None
    trigger_entity_id: str | None = None
    scanned_data: dict | None = None
    order_id: str | None = None
    external_object_id: str | None = None
    shipment_id: str | None = None
    note: str | None = None


@dataclass
class ExceptionUpdate:
    """Data for updating an exception (creates new revision)."""

    status: ExceptionStatus | None = None
    assigned_to: uuid.UUID | None = None
    resolution_notes: str | None = None
    note: str | None = None


class ExceptionService:
    """Service for managing exceptions."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: str | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.exceptions import TapdbExceptionRepository

            self._tapdb_repo = TapdbExceptionRepository(self.db)
        return self._tapdb_repo

    def _generate_exception_number(self) -> str:
        """Generate a unique exception number."""
        return self._repo().generate_next_exception_number(self.tenant_id)

    def create(
        self,
        data: ExceptionCreate,
        created_by: uuid.UUID | None = None,
    ):
        """Create a new exception."""
        payload = type(
            "ExceptionCreatePayload",
            (),
            {
                "exception_type": data.exception_type.value,
                "status": ExceptionStatus.OPEN.value,
                "trigger_entity_type": data.trigger_entity_type,
                "trigger_entity_id": data.trigger_entity_id,
                "scanned_data": data.scanned_data,
                "order_id": data.order_id,
                "external_object_id": data.external_object_id,
                "shipment_id": data.shipment_id,
                "assigned_to": None,
                "resolution_notes": None,
                "resolved_at": None,
                "resolved_by": None,
                "note": data.note,
            },
        )()

        exception_number = self._generate_exception_number()
        exception, revision = self._repo().create_exception(
            tenant_id=self.tenant_id,
            exception_number=exception_number,
            data=payload,
            created_by=created_by,
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=created_by,
            action=AuditAction.CREATE,
            entity_type="EXCEPTION",
            entity_id=exception.euid,
            details={
                "exception_number": exception.exception_number,
                "exception_type": data.exception_type.value,
            },
        )
        self.db.commit()

        emit_exception_created(
            self.db,
            self.tenant_id,
            exception.euid,
            exception.exception_number,
            data.exception_type.value,
        )

        return exception, revision

    def get(
        self,
        exception_id: str,
        cross_tenant: bool = False,
    ):
        """Get exception by ID with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_exception_with_revision(
            exception_id=exception_id,
            tenant_id=tenant_scope,
        )

    def get_by_exception_number(
        self,
        exception_number: str,
        cross_tenant: bool = False,
    ):
        """Get exception by exception_number with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_exception_by_number(
            exception_number=exception_number,
            tenant_id=tenant_scope,
        )

    def list_exceptions(
        self,
        skip: int = 0,
        limit: int = 50,
        status_filter: str | None = None,
        exception_type_filter: str | None = None,
        cross_tenant: bool = False,
    ):
        """List exceptions with optional filters."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_exceptions(
            tenant_id=tenant_scope,
            skip=skip,
            limit=limit,
            status_filter=status_filter,
            exception_type_filter=exception_type_filter,
        )

    def update(
        self,
        exception_id: str,
        data: ExceptionUpdate,
        updated_by: uuid.UUID | None = None,
    ):
        """Update exception (creates new revision)."""
        payload = type(
            "ExceptionUpdatePayload",
            (),
            {
                "status": data.status.value if data.status else None,
                "assigned_to": data.assigned_to,
                "resolution_notes": data.resolution_notes,
                "note": data.note,
            },
        )()
        result = self._repo().update_exception(
            exception_id=exception_id,
            tenant_id=self.tenant_id,
            data=payload,
            updated_by=updated_by,
        )
        if not result:
            return None

        exception, new_revision = result
        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=updated_by,
            action=AuditAction.UPDATE,
            entity_type="EXCEPTION",
            entity_id=exception.euid,
            details={
                "exception_number": exception.exception_number,
                "status": new_revision.status,
            },
        )
        self.db.commit()

        return exception, new_revision

    def assign(
        self,
        exception_id: str,
        assigned_to: uuid.UUID,
        assigned_by: uuid.UUID | None = None,
    ):
        """Assign exception to a user."""
        return self.update(
            exception_id,
            ExceptionUpdate(
                status=ExceptionStatus.ASSIGNED,
                assigned_to=assigned_to,
                note=f"Assigned to user {assigned_to}",
            ),
            assigned_by,
        )

    def resolve(
        self,
        exception_id: str,
        resolution_notes: str,
        resolved_by: uuid.UUID | None = None,
    ):
        """Resolve an exception."""
        result = self._repo().resolve_exception(
            exception_id=exception_id,
            tenant_id=self.tenant_id,
            resolution_notes=resolution_notes,
            resolved_by=resolved_by,
        )
        if not result:
            return None

        exception, new_revision = result

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=resolved_by,
            action=AuditAction.UPDATE,
            entity_type="EXCEPTION",
            entity_id=exception.euid,
            details={
                "exception_number": exception.exception_number,
                "status": "RESOLVED",
                "resolution_notes": resolution_notes,
            },
        )
        self.db.commit()

        emit_exception_resolved(
            self.db,
            self.tenant_id,
            exception.euid,
            exception.exception_number,
        )

        return exception, new_revision

    def escalate(
        self,
        exception_id: str,
        escalated_by: uuid.UUID | None = None,
    ):
        """Escalate an exception."""
        return self.update(
            exception_id,
            ExceptionUpdate(
                status=ExceptionStatus.ESCALATED,
                note="Exception escalated for review",
            ),
            escalated_by,
        )

    def close(
        self,
        exception_id: str,
        closed_by: uuid.UUID | None = None,
    ):
        """Close an exception."""
        return self.update(
            exception_id,
            ExceptionUpdate(
                status=ExceptionStatus.CLOSED,
                note="Exception closed",
            ),
            closed_by,
        )
