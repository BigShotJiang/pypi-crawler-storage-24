"""LSMC Hub - User Group Management Service.

Provides operations for:
- Managing user groups
- Assigning/removing users from groups
- Querying group memberships
"""

import uuid
from dataclasses import dataclass
from typing import Any

from app.domain.enums import AccessScope


@dataclass
class GroupCreate:
    """Data for creating a user group."""

    group_code: str
    name: str
    description: str | None = None
    access_scope: AccessScope = AccessScope.TENANT
    default_roles: list[str] | None = None


@dataclass
class GroupInfo:
    """Group information DTO."""

    euid: str
    group_code: str
    name: str
    description: str | None
    access_scope: str
    default_roles: list[str] | None
    is_system_group: bool
    is_active: bool
    member_count: int = 0


class UserGroupService:
    """Service for user group management."""

    def __init__(self, db: Any, tenant_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self._tapdb_repo: Any | None = None

    def _tapdb_repository(self) -> Any:
        if self._tapdb_repo is None:
            from app.persistence.tapdb.groups import TapdbUserGroupRepository

            self._tapdb_repo = TapdbUserGroupRepository(self.db, self.tenant_id)
        return self._tapdb_repo

    def create_group(
        self,
        data: GroupCreate,
        created_by: uuid.UUID | None,
    ) -> tuple[Any, Any]:
        """Create a new user group."""
        return self._tapdb_repository().create_group(data, created_by)

    def get_group_by_code(self, group_code: str) -> GroupInfo | None:
        """Get a group by its code."""
        return self._tapdb_repository().get_group_by_code(group_code)

    def list_group_members(
        self,
        group_euid: str,
    ) -> list[Any]:
        """List all memberships (active and inactive) for a group."""
        return self._tapdb_repository().list_group_members(group_euid)

    def remove_user_from_group(
        self,
        user_id: uuid.UUID,
        group_euid: str,
        removed_by: uuid.UUID | None,
    ) -> Any | None:
        """Deactivate a user's membership in a group (append-only pattern)."""
        return self._tapdb_repository().remove_user_from_group(user_id, group_euid, removed_by)

    def add_user_to_group(
        self,
        user_id: uuid.UUID,
        group_euid: str,
        added_by: uuid.UUID | None,
    ) -> Any:
        """Add a user to a group."""
        return self._tapdb_repository().add_user_to_group(user_id, group_euid, added_by)
