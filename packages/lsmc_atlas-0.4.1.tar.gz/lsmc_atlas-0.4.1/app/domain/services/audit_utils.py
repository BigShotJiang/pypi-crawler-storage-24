"""Audit logging helpers for TapDB-backed services."""

from __future__ import annotations

import uuid
from typing import Any

from app.domain.enums import AuditAction
from app.domain.services.audit import AuditService


def log_tapdb_audit_event(
    db: Any,
    *,
    tenant_id: uuid.UUID | None,
    user_id: uuid.UUID | None,
    action: AuditAction,
    entity_type: str,
    entity_id: uuid.UUID | None,
    details: dict | None = None,
) -> None:
    """Best-effort TapDB audit event logging.

    Unit test doubles often provide only ``add``/``commit`` without SQL execution;
    in that case we skip audit persistence so service behavior remains testable.
    """
    if not hasattr(db, "execute"):
        return

    AuditService(db, tenant_id=tenant_id).log(
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=details,
        user_id=user_id,
    )
