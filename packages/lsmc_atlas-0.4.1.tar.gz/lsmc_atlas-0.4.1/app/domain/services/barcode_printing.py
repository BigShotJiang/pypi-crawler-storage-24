"""LSMC Hub - Barcode Printing Service.

Integrates zebra_day library for printing barcodes on Zebra label printers.
Used during accessioning/intake workflows to print labels for:
- TestKitID
- ShipmentID
- ManifestID
"""

import logging
import uuid
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from app.domain.enums import AuditAction
from app.domain.services.audit import AuditService

logger = logging.getLogger(__name__)

# Try to import zebra_day, gracefully handle if not installed
try:
    import zebra_day.print_mgr as zdpm

    ZEBRA_DAY_AVAILABLE = True
except ImportError:
    ZEBRA_DAY_AVAILABLE = False
    logger.warning("zebra_day not installed. Barcode printing will be disabled.")


class LabelType(StrEnum):
    """Label types supported for printing."""

    TUBE_2IN_X_1IN = "tube_2inX1in"
    TUBE_2IN_X_03IN = "tube_2inX0.3in"
    PLATE_1IN_X_025IN = "plate_1inX0.25in"
    TEST_2IN_X_1IN = "test_2inX1in"


class EntityType(StrEnum):
    """Entity types that can have barcodes printed."""

    TESTKIT = "TestKit"
    SHIPMENT = "Shipment"
    MANIFEST = "Manifest"


@dataclass
class PrintRequest:
    """Request to print a barcode label."""

    entity_type: EntityType
    entity_id: uuid.UUID
    barcode: str
    label_type: LabelType = LabelType.TUBE_2IN_X_1IN
    printer_name: str | None = None
    lab: str = "lsmc-lab"
    alt_a: str = ""  # Additional label field
    alt_b: str = ""
    alt_c: str = ""
    alt_d: str = ""
    copies: int = 1


@dataclass
class PrintResult:
    """Result of a print operation."""

    success: bool
    message: str
    print_job_id: str | None = None
    zpl_code: str | None = None


@dataclass
class PrinterInfo:
    """Information about a configured printer."""

    name: str
    ip_address: str
    model: str | None = None
    lab: str = "lsmc-lab"
    available_label_styles: list[str] | None = None


class BarcodePrintService:
    """Service for printing barcode labels using zebra_day."""

    def __init__(
        self,
        db: Any,
        tenant_id: uuid.UUID,
        actor_id: str | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.actor_id = actor_id
        self._zpl: Any = None

    def _get_zpl_manager(self) -> Any:
        """Get or create the ZPL manager instance."""
        if not ZEBRA_DAY_AVAILABLE:
            raise RuntimeError("zebra_day library is not installed")
        if self._zpl is None:
            self._zpl = zdpm.zpl()
        return self._zpl

    def get_configured_printers(self) -> list[PrinterInfo]:
        """Get list of configured printers."""
        if not ZEBRA_DAY_AVAILABLE:
            return []

        try:
            zpl = self._get_zpl_manager()
            printers = []

            for lab_name, lab_printers in zpl.printers.get("labs", {}).items():
                for printer_name, printer_info in lab_printers.items():
                    if printer_name == "Download-Label-png":
                        continue  # Skip the PNG download option
                    printers.append(
                        PrinterInfo(
                            name=printer_name,
                            ip_address=printer_info.get("ip_address", printer_name),
                            model=printer_info.get("model"),
                            lab=lab_name,
                            available_label_styles=printer_info.get("label_zpl_styles", []),
                        )
                    )
            return printers
        except Exception as e:
            logger.error(f"Error getting configured printers: {e}")
            return []

    def discover_printers(self, ip_stub: str) -> list[PrinterInfo]:
        """Discover Zebra printers on the network."""
        if not ZEBRA_DAY_AVAILABLE:
            raise RuntimeError("zebra_day library is not installed")

        try:
            zpl = self._get_zpl_manager()
            zpl.probe_zebra_printers_add_to_printers_json(ip_stub)
            return self.get_configured_printers()
        except Exception as e:
            logger.error(f"Error discovering printers: {e}")
            raise

    def print_label(self, request: PrintRequest) -> PrintResult:
        """Print a barcode label."""
        if not ZEBRA_DAY_AVAILABLE:
            return PrintResult(
                success=False,
                message="zebra_day library is not installed",
            )

        try:
            zpl = self._get_zpl_manager()

            # Find printer
            printer_name = request.printer_name
            lab = request.lab

            if not printer_name:
                # Use first available printer
                printers = self.get_configured_printers()
                if not printers:
                    return PrintResult(
                        success=False,
                        message="No printers configured",
                    )
                printer_name = printers[0].name
                lab = printers[0].lab

            # Print requested number of copies
            zpl_code = None
            for _ in range(request.copies):
                zpl_code = zpl.print_zpl(
                    lab=lab,
                    printer_name=printer_name,
                    label_zpl_style=request.label_type.value,
                    uid_barcode=request.barcode,
                    alt_a=request.alt_a,
                    alt_b=request.alt_b,
                    alt_c=request.alt_c,
                    alt_d=request.alt_d,
                )

            # Audit log the print operation
            print_job_id = str(uuid.uuid4())
            audit_svc = AuditService(
                db=self.db,
                tenant_id=self.tenant_id,
                user_id=self.actor_id,
            )
            audit_svc.log(
                action=AuditAction.CREATE,
                entity_type=request.entity_type.value,
                entity_id=request.entity_id,
                user_id=uuid.UUID(self.actor_id) if self.actor_id else None,
                details={
                    "action": "BARCODE_PRINTED",
                    "barcode": request.barcode,
                    "printer": printer_name,
                    "label_type": request.label_type.value,
                    "copies": request.copies,
                    "print_job_id": print_job_id,
                },
            )

            return PrintResult(
                success=True,
                message=f"Printed {request.copies} label(s) to {printer_name}",
                print_job_id=print_job_id,
                zpl_code=zpl_code,
            )

        except Exception as e:
            logger.error(f"Error printing label: {e}")
            return PrintResult(
                success=False,
                message=str(e),
            )

    def print_testkit_label(
        self,
        testkit_id: uuid.UUID,
        barcode: str,
        kit_type: str | None = None,
        printer_name: str | None = None,
        copies: int = 1,
    ) -> PrintResult:
        """Print a label for a TestKit."""
        return self.print_label(
            PrintRequest(
                entity_type=EntityType.TESTKIT,
                entity_id=testkit_id,
                barcode=barcode,
                label_type=LabelType.TUBE_2IN_X_1IN,
                printer_name=printer_name,
                alt_a=kit_type or "KIT",
                copies=copies,
            )
        )

    def print_shipment_label(
        self,
        shipment_id: uuid.UUID,
        tracking_number: str,
        carrier: str | None = None,
        printer_name: str | None = None,
        copies: int = 1,
    ) -> PrintResult:
        """Print a label for a Shipment."""
        return self.print_label(
            PrintRequest(
                entity_type=EntityType.SHIPMENT,
                entity_id=shipment_id,
                barcode=tracking_number,
                label_type=LabelType.TUBE_2IN_X_1IN,
                printer_name=printer_name,
                alt_a=carrier or "",
                alt_b="SHIPMENT",
                copies=copies,
            )
        )

    def is_available(self) -> bool:
        """Check if barcode printing is available."""
        return ZEBRA_DAY_AVAILABLE
