"""LSMC Hub - Audit Service.

Provides operations for:
- Querying audit logs
- Filtering and searching audit events
- Exporting audit logs
"""

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.domain.enums import AuditAction


@dataclass
class AuditEventData:
    """Audit event data."""

    event_id: str
    tenant_id: str | None
    user_id: str | None
    action: str
    entity_type: str | None
    entity_id: str | None
    details: dict | None
    ip_address: str | None
    user_agent: str | None
    created_at: datetime


@dataclass
class AuditFilter:
    """Filter for audit events."""

    action: str | None = None
    entity_type: str | None = None
    entity_id: str | None = None
    user_id: uuid.UUID | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None


class AuditService:
    """Service for audit log operations."""

    def __init__(self, db: Any, tenant_id: uuid.UUID | None = None, user_id: str | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.audit import TapdbAuditRepository

            self._tapdb_repo = TapdbAuditRepository(self.db)
        return self._tapdb_repo

    def list_events(
        self,
        filter: AuditFilter | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> list[AuditEventData]:
        """List audit events with optional filtering."""
        filter = filter or AuditFilter()
        events = self._repo().list_events(
            tenant_id=self.tenant_id,
            action=filter.action,
            entity_type=filter.entity_type,
            entity_id=filter.entity_id,
            user_id=filter.user_id,
            date_from=filter.date_from,
            date_to=filter.date_to,
            skip=skip,
            limit=limit,
        )
        return [
            AuditEventData(
                event_id=event.euid,
                tenant_id=str(event.tenant_id) if event.tenant_id else None,
                user_id=str(event.user_id) if event.user_id else None,
                action=event.action,
                entity_type=event.entity_type,
                entity_id=str(event.entity_id) if event.entity_id else None,
                details=event.details,
                ip_address=event.ip_address,
                user_agent=event.user_agent,
                created_at=event.created_at or datetime.min,
            )
            for event in events
        ]

    def get_for_entity(
        self,
        entity_type: str,
        entity_id: str,
        limit: int = 100,
    ) -> list[AuditEventData]:
        """Get all audit events for a specific entity."""
        filter = AuditFilter(entity_type=entity_type, entity_id=entity_id)
        return self.list_events(filter=filter, limit=limit)

    def log(
        self,
        action: AuditAction,
        entity_type: str | None = None,
        entity_id: str | None = None,
        details: dict | None = None,
        user_id: uuid.UUID | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ):
        """Create an audit log entry."""
        return self._repo().create_event(
            tenant_id=self.tenant_id,
            user_id=user_id,
            action=action.value,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details,
            ip_address=ip_address,
            user_agent=user_agent,
        )

    def count(self, filter: AuditFilter | None = None) -> int:
        """Count audit events matching filter."""
        filter = filter or AuditFilter()
        return self._repo().count_events(
            tenant_id=self.tenant_id,
            action=filter.action,
            entity_type=filter.entity_type,
            entity_id=filter.entity_id,
            user_id=filter.user_id,
            date_from=filter.date_from,
            date_to=filter.date_to,
        )
