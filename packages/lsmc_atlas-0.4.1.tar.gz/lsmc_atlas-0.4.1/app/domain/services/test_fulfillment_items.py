"""Service layer for Atlas test fulfillment items."""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from app.domain.services.trfs import TestService
from app.persistence.tapdb.test_fulfillment_items import (
    TapdbTestFulfillmentItemRecord,
    TapdbTestFulfillmentItemRepository,
)


@dataclass
class TestFulfillmentItemCreate:
    required_material_type: str | None = None
    platform: str | None = None
    routing_hint: str | None = None
    intake_policy: str | None = None


class TestFulfillmentItemService:
    """Creates and resolves fulfillment items for Atlas Tests."""

    def __init__(self, db, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.repo = TapdbTestFulfillmentItemRepository(db)
        self.tests = TestService(db, tenant_id)

    def list_for_test(self, test_euid: str) -> list[TapdbTestFulfillmentItemRecord]:
        return self.repo.list_fulfillment_items_for_test(
            test_euid=test_euid,
            tenant_id=self.tenant_id,
        )

    def get(self, fulfillment_item_euid: str) -> TapdbTestFulfillmentItemRecord | None:
        item = self.repo.get_fulfillment_item(fulfillment_item_euid)
        if item is None or item.tenant_id != self.tenant_id:
            return None
        return item

    def create(
        self,
        *,
        test_euid: str,
        data: TestFulfillmentItemCreate,
        created_by: uuid.UUID | None = None,
    ) -> TapdbTestFulfillmentItemRecord:
        return self.repo.create_fulfillment_item(
            tenant_id=self.tenant_id,
            test_euid=test_euid,
            required_material_type=data.required_material_type,
            platform=data.platform,
            routing_hint=data.routing_hint,
            intake_policy=data.intake_policy,
            created_by=created_by,
        )

    def ensure_default_for_test(
        self,
        *,
        test_euid: str,
        created_by: uuid.UUID | None = None,
    ) -> TapdbTestFulfillmentItemRecord:
        existing = self.list_for_test(test_euid)
        if existing:
            return existing[0]

        resolved = self.tests.get_with_revision(test_euid, cross_tenant=False)
        if resolved is None:
            raise ValueError(f"Test not found: {test_euid}")
        _test, revision = resolved
        return self.create(
            test_euid=test_euid,
            data=TestFulfillmentItemCreate(
                required_material_type=revision.specimen_type_required or revision.specimen_type,
                platform=_infer_platform(revision.fulfillment_route_codes),
                routing_hint="standard",
                intake_policy="single_material_ok",
            ),
            created_by=created_by,
        )


def _infer_platform(fulfillment_route_codes: list[str]) -> str:
    for code in fulfillment_route_codes or []:
        normalized = str(code).upper()
        if "ONT" in normalized:
            return "ONT"
    return "ILMN"
