"""TapDB-backed graph viewer service for read-only Atlas graph exploration."""

from __future__ import annotations

import uuid
from collections import deque
from datetime import datetime
from typing import Any

from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from sqlalchemy import and_, desc, or_, select
from sqlalchemy.orm import Session, aliased

from app.settings import settings


class GraphViewerError(RuntimeError):
    """Base graph viewer exception."""


class GraphPermissionError(GraphViewerError):
    """Raised when a graph request violates tenant permission rules."""


class GraphObjectNotFoundError(GraphViewerError):
    """Raised when a graph object cannot be resolved in visible scope."""


_CATEGORY_COLORS: dict[str, str] = {
    "workflow": "#19f0a0",
    "workflow_step": "#8cf254",
    "container": "#9c6bff",
    "content": "#3fd5ff",
    "equipment": "#ff7448",
    "data": "#ffe86b",
    "actor": "#ff8ed1",
    "action": "#ffab45",
    "test_requisition": "#ffc56e",
    "health_event": "#ff6a7a",
    "file": "#79ec8f",
    "subject": "#8fb2ff",
}
_DEFAULT_NODE_COLOR = "#8a8a8a"


def _as_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (TypeError, ValueError):
        return None


def _as_json_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _iso(value: Any) -> str | None:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, str):
        raw = value.strip()
        return raw or None
    return None


def _instance_tenant_id(instance: generic_instance) -> uuid.UUID | None:
    json_addl = _as_json_dict(instance.json_addl)
    direct = _as_uuid(json_addl.get("tenant_id"))
    if direct is not None:
        return direct

    properties = _as_json_dict(json_addl.get("properties"))
    return _as_uuid(properties.get("tenant_id"))


class GraphViewerService:
    """Builds graph viewer payloads from TapDB instance/lineage/template records."""

    def __init__(self, db: Session, tenant_id: uuid.UUID, *, can_cross_tenant: bool):
        self.db = db
        self.tenant_id = tenant_id
        self.can_cross_tenant = can_cross_tenant

    def resolve_tenant_scope(self, requested_tenant_id: uuid.UUID | None) -> uuid.UUID:
        """Resolve effective tenant scope for the request."""
        if requested_tenant_id is None:
            return self.tenant_id
        if requested_tenant_id == self.tenant_id:
            return requested_tenant_id
        if not self.can_cross_tenant:
            raise GraphPermissionError("Cross-tenant graph access requires cross_tenant:read")
        return requested_tenant_id

    def get_graph_data(
        self,
        *,
        start_euid: str | None,
        depth: int,
        requested_tenant_id: uuid.UUID | None,
    ) -> dict[str, Any]:
        """Return Cytoscape graph elements and metadata."""
        tenant_scope = self.resolve_tenant_scope(requested_tenant_id)
        effective_depth = max(1, min(depth, settings.graph_max_depth))

        if (start_euid or "").strip():
            nodes, edges, truncated = self._build_start_graph(
                start_euid=(start_euid or "").strip(),
                depth=effective_depth,
                tenant_scope=tenant_scope,
            )
        else:
            nodes, edges, truncated = self._build_recent_graph(tenant_scope=tenant_scope)

        return {
            "elements": {
                "nodes": nodes,
                "edges": edges,
            },
            "meta": {
                "start_euid": (start_euid or "").strip() or None,
                "depth": effective_depth,
                "tenant_id": str(tenant_scope),
                "node_count": len(nodes),
                "edge_count": len(edges),
                "truncated": truncated,
            },
        }

    def get_object_detail(
        self,
        *,
        euid: str,
        requested_tenant_id: uuid.UUID | None,
    ) -> dict[str, Any]:
        """Return detail payload for an instance/template/lineage object."""
        tenant_scope = self.resolve_tenant_scope(requested_tenant_id)
        clean_euid = (euid or "").strip()
        if not clean_euid:
            raise GraphObjectNotFoundError("Object not found")

        instance = (
            self.db.execute(
                select(generic_instance).where(
                    and_(
                        generic_instance.euid == clean_euid,
                        generic_instance.is_deleted.is_(False),
                    )
                )
            )
            .scalars()
            .first()
        )
        if instance is not None and self._instance_visible(instance, tenant_scope):
            return self._instance_detail(instance)

        template = (
            self.db.execute(
                select(generic_template).where(
                    and_(
                        generic_template.euid == clean_euid,
                        generic_template.is_deleted.is_(False),
                    )
                )
            )
            .scalars()
            .first()
        )
        if template is not None:
            return self._template_detail(template)

        lineage_row = self._find_visible_lineage(clean_euid, tenant_scope)
        if lineage_row is not None:
            lineage, parent, child = lineage_row
            return self._lineage_detail(lineage=lineage, parent=parent, child=child)

        raise GraphObjectNotFoundError(f"Object not found: {clean_euid}")

    def _build_start_graph(
        self,
        *,
        start_euid: str,
        depth: int,
        tenant_scope: uuid.UUID,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], bool]:
        start_obj = (
            self.db.execute(
                select(generic_instance).where(
                    and_(
                        generic_instance.euid == start_euid,
                        generic_instance.is_deleted.is_(False),
                    )
                )
            )
            .scalars()
            .first()
        )
        if start_obj is None or not self._instance_visible(start_obj, tenant_scope):
            return [], [], False

        max_nodes = max(1, settings.graph_max_nodes)
        max_edges = max(1, settings.graph_max_edges)

        node_map: dict[str, dict[str, Any]] = {}
        edge_map: dict[str, dict[str, Any]] = {}
        queued_ids: set[str] = {start_obj.euid}
        queue: deque[tuple[generic_instance, int]] = deque([(start_obj, 0)])
        truncated = False

        while queue and not truncated:
            current, level = queue.popleft()
            current_id = current.euid
            if not current_id or current_id in node_map:
                continue

            if len(node_map) >= max_nodes:
                truncated = True
                break

            node_map[current_id] = self._node_payload(current)

            if level >= depth:
                continue

            for lineage, parent, child in self._adjacent_visible_lineage(
                instance_uid=current.uid,
                tenant_scope=tenant_scope,
            ):
                edge_id = lineage.euid or f"lineage-{lineage.uid}"
                if edge_id not in edge_map:
                    if len(edge_map) >= max_edges:
                        truncated = True
                        break
                    edge_map[edge_id] = self._edge_payload(
                        lineage=lineage,
                        parent=parent,
                        child=child,
                    )

                neighbor = child if parent.uid == current.uid else parent
                neighbor_id = neighbor.euid
                if not neighbor_id:
                    continue
                if neighbor_id in node_map or neighbor_id in queued_ids:
                    continue

                if len(node_map) + len(queued_ids) >= max_nodes:
                    truncated = True
                    continue

                queue.append((neighbor, level + 1))
                queued_ids.add(neighbor_id)

        nodes = sorted(node_map.values(), key=lambda item: item["data"]["id"])
        visible_node_ids = {node["data"]["id"] for node in nodes}
        edges = [
            edge
            for edge in edge_map.values()
            if edge["data"].get("source") in visible_node_ids
            and edge["data"].get("target") in visible_node_ids
        ]
        edges.sort(key=lambda item: item["data"]["id"])
        return nodes, edges, truncated

    def _build_recent_graph(
        self,
        *,
        tenant_scope: uuid.UUID,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], bool]:
        max_nodes = max(1, settings.graph_max_nodes)
        max_edges = max(1, settings.graph_max_edges)

        candidates = self._fetch_recent_visible_instances(
            tenant_scope=tenant_scope,
            limit=max_nodes + 1,
        )
        node_truncated = len(candidates) > max_nodes
        instances = candidates[:max_nodes]

        node_map = {inst.euid: self._node_payload(inst) for inst in instances if inst.euid}
        if not node_map:
            return [], [], node_truncated

        lineage_rows = self._lineage_for_instance_set(
            instance_uids=[inst.uid for inst in instances if inst.euid],
            tenant_scope=tenant_scope,
            limit=max_edges + 1,
        )
        edge_truncated = len(lineage_rows) > max_edges

        edge_map: dict[str, dict[str, Any]] = {}
        for lineage, parent, child in lineage_rows[:max_edges]:
            edge_id = lineage.euid or f"lineage-{lineage.uid}"
            edge_payload = self._edge_payload(lineage=lineage, parent=parent, child=child)
            source = edge_payload["data"]["source"]
            target = edge_payload["data"]["target"]
            if source in node_map and target in node_map:
                edge_map[edge_id] = edge_payload

        nodes = sorted(node_map.values(), key=lambda item: item["data"]["id"])
        edges = sorted(edge_map.values(), key=lambda item: item["data"]["id"])
        return nodes, edges, node_truncated or edge_truncated

    def _instance_visible(self, instance: generic_instance, tenant_scope: uuid.UUID) -> bool:
        instance_tenant_id = _instance_tenant_id(instance)
        if instance_tenant_id is None:
            return False
        return instance_tenant_id == tenant_scope

    def _fetch_recent_visible_instances(
        self,
        *,
        tenant_scope: uuid.UUID,
        limit: int,
    ) -> list[generic_instance]:
        batch_size = max(200, min(2000, limit * 3))
        offset = 0
        found: list[generic_instance] = []

        while len(found) < limit and offset <= batch_size * 20:
            stmt = (
                select(generic_instance)
                .where(generic_instance.is_deleted.is_(False))
                .order_by(
                    desc(generic_instance.modified_dt),
                    desc(generic_instance.created_dt),
                    desc(generic_instance.uid),
                )
                .offset(offset)
                .limit(batch_size)
            )
            batch = self.db.execute(stmt).scalars().all()
            if not batch:
                break

            for instance in batch:
                if not instance.euid:
                    continue
                if not self._instance_visible(instance, tenant_scope):
                    continue
                found.append(instance)
                if len(found) >= limit:
                    break

            offset += batch_size

        return found

    def _adjacent_visible_lineage(
        self,
        *,
        instance_uid: int,
        tenant_scope: uuid.UUID,
    ) -> list[tuple[generic_instance_lineage, generic_instance, generic_instance]]:
        parent_alias = aliased(generic_instance)
        child_alias = aliased(generic_instance)

        stmt = (
            select(generic_instance_lineage, parent_alias, child_alias)
            .join(parent_alias, parent_alias.uid == generic_instance_lineage.parent_instance_uid)
            .join(child_alias, child_alias.uid == generic_instance_lineage.child_instance_uid)
            .where(
                and_(
                    generic_instance_lineage.is_deleted.is_(False),
                    parent_alias.is_deleted.is_(False),
                    child_alias.is_deleted.is_(False),
                    or_(
                        generic_instance_lineage.parent_instance_uid == instance_uid,
                        generic_instance_lineage.child_instance_uid == instance_uid,
                    ),
                )
            )
            .order_by(desc(generic_instance_lineage.created_dt), desc(generic_instance_lineage.uid))
        )

        rows = self.db.execute(stmt).all()
        visible: list[tuple[generic_instance_lineage, generic_instance, generic_instance]] = []
        for lineage, parent, child in rows:
            if not self._instance_visible(parent, tenant_scope):
                continue
            if not self._instance_visible(child, tenant_scope):
                continue
            if not parent.euid or not child.euid:
                continue
            visible.append((lineage, parent, child))
        return visible

    def _lineage_for_instance_set(
        self,
        *,
        instance_uids: list[int],
        tenant_scope: uuid.UUID,
        limit: int,
    ) -> list[tuple[generic_instance_lineage, generic_instance, generic_instance]]:
        if not instance_uids:
            return []

        parent_alias = aliased(generic_instance)
        child_alias = aliased(generic_instance)

        stmt = (
            select(generic_instance_lineage, parent_alias, child_alias)
            .join(parent_alias, parent_alias.uid == generic_instance_lineage.parent_instance_uid)
            .join(child_alias, child_alias.uid == generic_instance_lineage.child_instance_uid)
            .where(
                and_(
                    generic_instance_lineage.is_deleted.is_(False),
                    parent_alias.is_deleted.is_(False),
                    child_alias.is_deleted.is_(False),
                    generic_instance_lineage.parent_instance_uid.in_(instance_uids),
                    generic_instance_lineage.child_instance_uid.in_(instance_uids),
                )
            )
            .order_by(desc(generic_instance_lineage.created_dt), desc(generic_instance_lineage.uid))
            .limit(limit)
        )

        rows = self.db.execute(stmt).all()
        visible: list[tuple[generic_instance_lineage, generic_instance, generic_instance]] = []
        for lineage, parent, child in rows:
            if not self._instance_visible(parent, tenant_scope):
                continue
            if not self._instance_visible(child, tenant_scope):
                continue
            if not parent.euid or not child.euid:
                continue
            visible.append((lineage, parent, child))
        return visible

    def _find_visible_lineage(
        self,
        euid: str,
        tenant_scope: uuid.UUID,
    ) -> tuple[generic_instance_lineage, generic_instance, generic_instance] | None:
        parent_alias = aliased(generic_instance)
        child_alias = aliased(generic_instance)

        stmt = (
            select(generic_instance_lineage, parent_alias, child_alias)
            .join(parent_alias, parent_alias.uid == generic_instance_lineage.parent_instance_uid)
            .join(child_alias, child_alias.uid == generic_instance_lineage.child_instance_uid)
            .where(
                and_(
                    generic_instance_lineage.euid == euid,
                    generic_instance_lineage.is_deleted.is_(False),
                    parent_alias.is_deleted.is_(False),
                    child_alias.is_deleted.is_(False),
                )
            )
        )

        row = self.db.execute(stmt).first()
        if row is None:
            return None

        lineage, parent, child = row
        if not self._instance_visible(parent, tenant_scope):
            return None
        if not self._instance_visible(child, tenant_scope):
            return None
        if not parent.euid or not child.euid:
            return None
        return lineage, parent, child

    def _node_payload(self, instance: generic_instance) -> dict[str, Any]:
        return {
            "data": {
                "id": instance.euid,
                "euid": instance.euid,
                "name": instance.name or instance.euid,
                "type": instance.type,
                "obj_type": instance.type,
                "category": instance.category,
                "subtype": instance.subtype,
                "version": instance.version,
                "bstatus": instance.bstatus,
                "color": _CATEGORY_COLORS.get(instance.category, _DEFAULT_NODE_COLOR),
            }
        }

    def _edge_payload(
        self,
        *,
        lineage: generic_instance_lineage,
        parent: generic_instance,
        child: generic_instance,
    ) -> dict[str, Any]:
        return {
            "data": {
                "id": lineage.euid or f"lineage-{lineage.uid}",
                "source": child.euid,
                "target": parent.euid,
                "relationship_type": lineage.relationship_type or "generic",
            }
        }

    def _instance_detail(self, instance: generic_instance) -> dict[str, Any]:
        return {
            "record_type": "instance",
            "uid": instance.uid,
            "euid": instance.euid,
            "name": instance.name,
            "type": instance.type,
            "obj_type": instance.type,
            "category": instance.category,
            "subtype": instance.subtype,
            "version": instance.version,
            "bstatus": instance.bstatus,
            "json_addl": _as_json_dict(instance.json_addl),
            "created_dt": _iso(instance.created_dt),
            "modified_dt": _iso(instance.modified_dt),
        }

    def _template_detail(self, template: generic_template) -> dict[str, Any]:
        return {
            "record_type": "template",
            "uid": template.uid,
            "euid": template.euid,
            "name": template.name,
            "type": template.type,
            "obj_type": template.type,
            "category": template.category,
            "subtype": template.subtype,
            "version": template.version,
            "bstatus": template.bstatus,
            "json_addl": _as_json_dict(template.json_addl),
            "created_dt": _iso(template.created_dt),
            "modified_dt": _iso(template.modified_dt),
        }

    def _lineage_detail(
        self,
        *,
        lineage: generic_instance_lineage,
        parent: generic_instance,
        child: generic_instance,
    ) -> dict[str, Any]:
        return {
            "record_type": "lineage",
            "uid": lineage.uid,
            "euid": lineage.euid,
            "name": lineage.name,
            "type": lineage.type,
            "obj_type": lineage.type,
            "category": lineage.category,
            "subtype": lineage.subtype,
            "version": lineage.version,
            "bstatus": lineage.bstatus,
            "json_addl": _as_json_dict(lineage.json_addl),
            "created_dt": _iso(lineage.created_dt),
            "modified_dt": _iso(lineage.modified_dt),
            "source": child.euid,
            "target": parent.euid,
            "relationship_type": lineage.relationship_type or "generic",
            "parent_instance_uid": parent.uid,
            "child_instance_uid": child.uid,
        }
