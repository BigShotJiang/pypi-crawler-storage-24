"""Shared tenant-site resolution for site-scoped Atlas objects."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from app.domain.services.orgs import OrganizationService, SiteService


@dataclass(frozen=True)
class TenantSiteOption:
    """Display-ready site option for create/edit flows."""

    id: str
    name: str
    site_code: str | None = None
    is_active: bool = True


def list_tenant_site_options(
    db: Any,
    tenant_id: uuid.UUID,
    *,
    active_only: bool = True,
) -> list[TenantSiteOption]:
    """List sites for a tenant's organization, normalized for form usage."""
    org_result = OrganizationService(db).get_with_revision_by_uid(tenant_id)
    if org_result is None:
        return []
    organization, _revision = org_result

    rows: list[TenantSiteOption] = []
    for site in SiteService(db).list_by_organization(organization.euid, active_only=active_only):
        latest = site.revisions[-1] if getattr(site, "revisions", None) else None
        if latest is None:
            continue
        rows.append(
            TenantSiteOption(
                id=site.euid,
                name=latest.name,
                site_code=latest.site_code,
                is_active=bool(latest.is_active),
            )
        )
    return rows


def resolve_tenant_site_euid(
    db: Any,
    tenant_id: uuid.UUID,
    requested_site_euid: str | None,
    *,
    active_only: bool = True,
) -> str:
    """Resolve and validate site selection for tenant-scoped writes.

    Rules:
    - If exactly one active site exists, auto-select it when no site is provided.
    - If multiple active sites exist, explicit site selection is required.
    - Provided site must belong to the tenant organization.
    - Organization must have at least one active site.
    """
    options = list_tenant_site_options(db, tenant_id, active_only=active_only)
    if not options:
        raise ValueError("Organization must have at least one active site")

    requested = (requested_site_euid or "").strip()
    valid_ids = {row.id for row in options}
    if requested:
        if requested not in valid_ids:
            raise ValueError("Selected site does not belong to this organization")
        return requested

    if len(options) == 1:
        return options[0].id

    raise ValueError("Site selection is required for organizations with multiple active sites")
