"""LSMC Hub - Document Service.

Provides operations for:
- Uploading documents to S3
- Generating signed URLs for download
- Managing document metadata
- Linking documents to entities (orders, shipments, etc.)
"""

import hashlib
import uuid
from dataclasses import dataclass
from typing import Any

import boto3
from botocore.exceptions import ClientError

from app.domain.enums import AuditAction, LinkAction
from app.domain.services.audit_utils import log_tapdb_audit_event
from app.integrations.dewey_client import DeweyClient, DeweyClientError
from app.settings import settings


@dataclass
class DocumentUpload:
    """Data for uploading a document."""

    filename: str
    content: bytes
    content_type: str | None = None
    document_type: str | None = None
    note: str | None = None


@dataclass
class DocumentUploadResult:
    """Result of document upload."""

    document_euid: str
    s3_bucket: str
    s3_key: str
    size_bytes: int
    dewey_artifact_euid: str | None = None


class DocumentService:
    """Service for managing documents."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: str | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._s3_client = None
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.documents import TapdbDocumentRepository

            self._tapdb_repo = TapdbDocumentRepository(self.db)
        return self._tapdb_repo

    @property
    def s3_client(self):
        """Lazy-load S3 client."""
        if self._s3_client is None:
            session = boto3.Session(profile_name=settings.aws_profile)
            self._s3_client = session.client("s3", region_name=settings.s3_region)
        return self._s3_client

    def _generate_s3_key(self, document_key: str, filename: str) -> str:
        """Generate S3 key for document.

        Format: {tenant_id}/documents/{document_key}/{filename}
        """
        return f"{self.tenant_id}/documents/{document_key}/{filename}"

    def _calculate_checksum(self, content: bytes) -> str:
        """Calculate SHA256 checksum of content."""
        return hashlib.sha256(content).hexdigest()

    def upload(
        self,
        data: DocumentUpload,
        created_by: uuid.UUID | None = None,
    ) -> DocumentUploadResult:
        """Upload a document to S3 and create database record."""
        provisional_key = self._generate_s3_key(str(uuid.uuid4()), data.filename)

        try:
            self.s3_client.put_object(
                Bucket=settings.s3_bucket,
                Key=provisional_key,
                Body=data.content,
                ContentType=data.content_type or "application/octet-stream",
                Metadata={
                    "tenant_id": str(self.tenant_id),
                    "uploaded_by": str(created_by) if created_by else "unknown",
                },
            )
        except ClientError as e:
            raise RuntimeError(f"Failed to upload to S3: {str(e)}") from e

        payload = type(
            "DocumentCreatePayload",
            (),
            {
                "filename": data.filename,
                "content_type": data.content_type,
                "size_bytes": len(data.content),
                "s3_bucket": settings.s3_bucket,
                "s3_key": provisional_key,
                "document_type": data.document_type,
                "note": data.note,
            },
        )()

        document, _revision = self._repo().create_document(
            tenant_id=self.tenant_id,
            data=payload,
            created_by=created_by,
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=created_by,
            action=AuditAction.CREATE,
            entity_type="DOCUMENT",
            entity_id=None,  # type: ignore[arg-type]
            details={
                "document_euid": document.euid,
                "filename": data.filename,
                "size_bytes": len(data.content),
                "document_type": data.document_type,
                "s3_key": provisional_key,
            },
        )
        self.db.commit()

        dewey_artifact_euid: str | None = None
        if settings.dewey_enabled:
            dewey = DeweyClient(
                base_url=settings.dewey_base_url,
                token=settings.dewey_api_token,
                timeout_seconds=float(settings.dewey_request_timeout_seconds),
                verify_ssl=bool(settings.dewey_verify_ssl),
            )
            try:
                dewey_artifact_euid = dewey.import_artifact(
                    artifact_type=data.document_type or "document",
                    storage_uri=f"s3://{settings.s3_bucket}/{provisional_key}",
                    metadata={
                        "producer_system": "atlas",
                        "producer_object_euid": document.euid,
                        "original_filename": data.filename,
                        "content_type": data.content_type or "application/octet-stream",
                        "size": len(data.content),
                        "atlas_tenant_id": str(self.tenant_id),
                    },
                    idempotency_key=f"atlas-document:{self.tenant_id}:{document.euid}:{provisional_key}",
                )
            except DeweyClientError as exc:
                raise RuntimeError(f"Failed to register document artifact in Dewey: {exc}") from exc

        return DocumentUploadResult(
            document_euid=document.euid,
            s3_bucket=settings.s3_bucket,
            s3_key=provisional_key,
            size_bytes=len(data.content),
            dewey_artifact_euid=dewey_artifact_euid,
        )

    def get_download_url(self, document_euid: str, expires_in: int = 3600) -> str | None:
        """Generate a signed URL for downloading a document."""
        result = self.get(document_euid)
        if not result:
            return None

        _document, revision = result
        if not revision.s3_bucket or not revision.s3_key:
            return None

        try:
            url = self.s3_client.generate_presigned_url(
                "get_object",
                Params={
                    "Bucket": revision.s3_bucket,
                    "Key": revision.s3_key,
                },
                ExpiresIn=expires_in,
            )
            return url
        except ClientError as e:
            raise RuntimeError(f"Failed to generate signed URL: {str(e)}") from e

    def get(self, document_euid: str):
        """Get document by EUID with latest revision."""
        return self._repo().get_document(document_euid=document_euid, tenant_id=self.tenant_id)

    def list_documents(
        self,
        skip: int = 0,
        limit: int = 50,
        document_type: str | None = None,
    ):
        """List documents for tenant."""
        return self._repo().list_documents(
            tenant_id=self.tenant_id,
            skip=skip,
            limit=limit,
            document_type=document_type,
        )

    def link_to_entity(
        self,
        document_euid: str,
        entity_type: str,
        entity_id: str,
        created_by: uuid.UUID | None = None,
    ) -> None:
        """Link a document to an entity (order, shipment, etc.)."""
        if not self.get(document_euid):
            raise ValueError(f"Document {document_euid} not found")

        self._repo().add_link_event(
            tenant_id=self.tenant_id,
            action=LinkAction.LINK.value,
            source_type="DOCUMENT",
            source_id=document_euid,
            target_type=entity_type,
            target_id=entity_id,
            created_by=created_by,
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=created_by,
            action=AuditAction.UPDATE,
            entity_type="DOCUMENT",
            entity_id=None,  # type: ignore[arg-type]
            details={
                "action": "link",
                "document_euid": document_euid,
                "target_entity_type": entity_type,
                "target_entity_id": str(entity_id),
            },
        )
        self.db.commit()

    def unlink_from_entity(
        self,
        document_euid: str,
        entity_type: str,
        entity_id: str,
        created_by: uuid.UUID | None = None,
    ) -> None:
        """Unlink a document from an entity."""
        self._repo().add_link_event(
            tenant_id=self.tenant_id,
            action=LinkAction.UNLINK.value,
            source_type="DOCUMENT",
            source_id=document_euid,
            target_type=entity_type,
            target_id=entity_id,
            created_by=created_by,
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=created_by,
            action=AuditAction.UPDATE,
            entity_type="DOCUMENT",
            entity_id=None,  # type: ignore[arg-type]
            details={
                "action": "unlink",
                "document_euid": document_euid,
                "target_entity_type": entity_type,
                "target_entity_id": str(entity_id),
            },
        )
        self.db.commit()

    def get_linked_documents(self, entity_type: str, entity_id: str):
        """Get all documents linked to an entity (excluding unlinked)."""
        return self._repo().get_linked_documents(
            tenant_id=self.tenant_id,
            entity_type=entity_type,
            entity_id=entity_id,
        )

    def audit_download(
        self,
        document_euid: str,
        downloaded_by: uuid.UUID | None = None,
    ) -> None:
        """Audit log a document download."""
        result = self.get(document_euid)
        if not result:
            return

        _document, revision = result
        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=downloaded_by,
            action=AuditAction.DOWNLOAD,
            entity_type="DOCUMENT",
            entity_id=None,  # type: ignore[arg-type]
            details={
                "document_euid": document_euid,
                "filename": revision.filename,
                "document_type": revision.document_type,
            },
        )
        self.db.commit()
