"""Polling fallback for Bloom external specimen synchronization."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from app.domain.services.bloom_bridge import AtlasReferences, ContainerSpecimenBridgeService
from app.domain.services.external_objects import OrgBloomConfigService, OrgBloomConfigUpsert
from app.domain.services.trfs import TrfService


@dataclass
class BloomPollResult:
    tenant_id: str
    trfs_polled: int
    synced_items: int
    started_at: datetime
    finished_at: datetime


class BloomPollingService:
    """Poll Bloom by Atlas references and reconcile external-object mirrors."""

    def __init__(self, db: Session, tenant_id):
        self.db = db
        self.tenant_id = tenant_id
        self.bridge = ContainerSpecimenBridgeService(db, tenant_id)
        self.org_configs = OrgBloomConfigService(db)

    def poll_for_trf_euids(self, trf_euids: list[str]) -> BloomPollResult:
        started_at = datetime.now(UTC)
        synced = 0
        polled = 0
        seen: set[str] = set()

        for trf_euid in trf_euids:
            clean = str(trf_euid or "").strip()
            if not clean:
                continue
            polled += 1
            refs = AtlasReferences(atlas_trf_euid=clean)
            for item in self.bridge.list_specimens_by_reference(refs):
                specimen_euid = str(item.get("specimen_euid") or item.get("euid") or "").strip()
                if not specimen_euid:
                    continue
                status = str(item.get("status") or "")
                refs_hash = str(item.get("atlas_refs") or "")
                dedupe_key = f"{specimen_euid}:{status}:{refs_hash}"
                if dedupe_key in seen:
                    continue
                seen.add(dedupe_key)
                synced += 1

        finished_at = datetime.now(UTC)
        self._persist_checkpoint(
            {
                "last_polled_at": finished_at.isoformat(),
                "trfs_polled": polled,
                "synced_items": synced,
            }
        )
        return BloomPollResult(
            tenant_id=str(self.tenant_id),
            trfs_polled=polled,
            synced_items=synced,
            started_at=started_at,
            finished_at=finished_at,
        )

    def poll_all_active_trfs(self, *, limit: int = 200) -> BloomPollResult:
        trf_rows = TrfService(self.db, self.tenant_id).list_trfs(limit=limit, offset=0)
        trf_euids = [row[0].euid for row in trf_rows]
        return self.poll_for_trf_euids(trf_euids)

    def _persist_checkpoint(self, checkpoint: dict[str, Any]) -> None:
        cfg = self.org_configs.get(self.tenant_id)
        if cfg is None:
            return
        metadata = dict(cfg.metadata or {})
        metadata["polling_checkpoint"] = checkpoint
        self.org_configs.upsert(
            self.tenant_id,
            OrgBloomConfigUpsert(
                enabled=cfg.enabled,
                bloom_base_url=cfg.bloom_base_url,
                bloom_api_key_secret_ref=cfg.bloom_api_key_secret_ref,
                bloom_webhook_secret_ref=cfg.bloom_webhook_secret_ref,
                bloom_service_user=cfg.bloom_service_user,
                last_verified_at=cfg.last_verified_at,
                metadata=metadata,
            ),
            actor_id=None,
        )


async def run_bloom_polling_job(db_factory):
    """Background job entrypoint to poll Bloom for all enabled orgs."""
    db = db_factory()
    try:
        config_service = OrgBloomConfigService(db)
        for cfg in config_service.list_enabled():
            try:
                BloomPollingService(db, cfg.organization_id).poll_all_active_trfs()
            except Exception:
                # Keep polling other orgs if one fails.
                continue
    finally:
        db.close()
