"""LSMC Hub - People Services (Patient, Clinician).

Provides CRUD operations with:
- Tenant scoping
- Append-only revision pattern
- Audit logging
"""

import logging
import uuid
from dataclasses import dataclass
from datetime import date
from typing import Any

from app.domain.enums import AuditAction

logger = logging.getLogger(__name__)


@dataclass
class PatientCreate:
    """Data for creating a new patient."""

    first_name: str
    last_name: str
    middle_name: str | None = None
    date_of_birth: date | None = None
    sex: str | None = None
    mrn: str | None = None
    email: str | None = None
    phone: str | None = None
    address_line1: str | None = None
    address_line2: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    clinical_notes: str | None = None
    site_id: str | None = None


@dataclass
class PatientUpdate:
    """Data for updating a patient (creates new revision)."""

    first_name: str | None = None
    last_name: str | None = None
    middle_name: str | None = None
    date_of_birth: date | None = None
    sex: str | None = None
    mrn: str | None = None
    email: str | None = None
    phone: str | None = None
    address: dict | None = None
    clinical_notes: str | None = None
    site_id: str | None = None
    note: str | None = None


@dataclass
class ClinicianCreate:
    """Data for creating a new clinician."""

    first_name: str
    last_name: str
    credentials: str | None = None
    npi: str | None = None
    specialty: str | None = None
    email: str | None = None
    phone: str | None = None
    fax: str | None = None
    addresses: list[dict] | None = None
    site_id: str | None = None


@dataclass
class ClinicianUpdate:
    """Data for updating a clinician (creates new revision)."""

    first_name: str | None = None
    last_name: str | None = None
    credentials: str | None = None
    npi: str | None = None
    specialty: str | None = None
    email: str | None = None
    phone: str | None = None
    fax: str | None = None
    addresses: list[dict] | None = None
    site_id: str | None = None
    is_active: bool | None = None
    note: str | None = None


class PatientService:
    """Service for patient operations with tenant scoping."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.people import TapdbPeopleRepository

            self._tapdb_repo = TapdbPeopleRepository(self.db)
        return self._tapdb_repo

    def _log_audit_event(
        self,
        *,
        tenant_id: uuid.UUID,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        user_id: uuid.UUID | None = None,
        details: dict | None = None,
    ) -> None:
        """Best-effort audit logging via TapDB-backed AuditService."""
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db,
                tenant_id=tenant_id,
                user_id=str(user_id) if user_id else None,
            ).log(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
                user_id=user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.warning(
                "Audit logging failed for %s %s in tenant %s",
                entity_type,
                entity_id,
                tenant_id,
                exc_info=True,
            )

    def create(
        self,
        data: PatientCreate,
        created_by: uuid.UUID | None = None,
    ):
        """Create a new patient with initial revision."""
        address = None
        if any(
            [
                data.address_line1,
                data.address_line2,
                data.city,
                data.state,
                data.postal_code,
                data.country,
            ]
        ):
            address = {
                "address_line1": data.address_line1,
                "address_line2": data.address_line2,
                "city": data.city,
                "state": data.state,
                "postal_code": data.postal_code,
                "country": data.country,
            }

        from app.domain.services.site_scope import resolve_tenant_site_euid

        resolved_site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.site_id)

        repo_payload = type(
            "PatientCreatePayload",
            (),
            {
                "first_name": data.first_name,
                "last_name": data.last_name,
                "middle_name": data.middle_name,
                "date_of_birth": data.date_of_birth,
                "sex": data.sex,
                "mrn": data.mrn,
                "email": data.email,
                "phone": data.phone,
                "address": address,
                "clinical_notes": data.clinical_notes,
                "site_id": resolved_site_id,
            },
        )()

        patient, revision = self._repo().create_patient(
            tenant_id=self.tenant_id,
            data=repo_payload,
            created_by=created_by,
        )

        self._log_audit_event(
            tenant_id=self.tenant_id,
            action=AuditAction.CREATE,
            entity_type="Patient",
            entity_id=patient.euid,
            user_id=created_by,
        )
        return patient, revision

    def get_by_id(self, patient_id: str, cross_tenant: bool = False):
        """Get patient by ID (EUID) with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_patient_with_revision(patient_id=patient_id, tenant_id=tenant_scope)

    def get(self, patient_id: str, cross_tenant: bool = False):
        """Get patient by ID (EUID) with latest revision (alias for get_by_id)."""
        return self.get_by_id(patient_id, cross_tenant=cross_tenant)

    def get_by_mrn(self, mrn: str, cross_tenant: bool = False):
        """Get single patient by MRN with latest revision."""
        results = self.search_by_mrn(mrn, cross_tenant=cross_tenant)
        return results[0] if results else None

    def list_patients(
        self,
        limit: int = 100,
        offset: int = 0,
        skip: int | None = None,
        cross_tenant: bool = False,
    ):
        """List patients with their latest revisions."""
        actual_offset = skip if skip is not None else offset
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_patients(
            tenant_id=tenant_scope,
            limit=limit,
            offset=actual_offset,
        )

    def search_by_mrn(self, mrn: str, cross_tenant: bool = False):
        """Search patients by MRN with their latest revisions."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().search_patients_by_mrn(mrn=mrn, tenant_id=tenant_scope)

    def search_by_name(self, name: str, limit: int = 100, cross_tenant: bool = False):
        """Search patients by name (first or last, case-insensitive)."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().search_patients_by_name(name=name, tenant_id=tenant_scope, limit=limit)

    @staticmethod
    def _normalize_patient_update(data: PatientUpdate | dict) -> PatientUpdate:
        if isinstance(data, PatientUpdate):
            return data

        normalized = dict(data)
        # API payloads may include flat address fields.
        address_keys = [
            "address_line1",
            "address_line2",
            "city",
            "state",
            "postal_code",
            "country",
        ]
        if any(k in normalized for k in address_keys):
            normalized["address"] = {
                "address_line1": normalized.pop("address_line1", None),
                "address_line2": normalized.pop("address_line2", None),
                "city": normalized.pop("city", None),
                "state": normalized.pop("state", None),
                "postal_code": normalized.pop("postal_code", None),
                "country": normalized.pop("country", None),
            }

        allowed = {
            "first_name",
            "last_name",
            "middle_name",
            "date_of_birth",
            "sex",
            "mrn",
            "email",
            "phone",
            "address",
            "clinical_notes",
            "site_id",
            "note",
        }
        filtered = {k: v for k, v in normalized.items() if k in allowed}
        return PatientUpdate(**filtered)

    def update(
        self,
        patient_id: str,
        data: PatientUpdate | dict,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ):
        """Update patient by creating a new revision."""
        payload = self._normalize_patient_update(data)
        if payload.site_id is not None:
            from app.domain.services.site_scope import resolve_tenant_site_euid

            target_tenant_id = self.tenant_id
            if cross_tenant:
                existing = self._repo().get_patient_with_revision(patient_id, tenant_id=None)
                if existing is not None:
                    target_tenant_id = existing[0].tenant_id
            payload.site_id = resolve_tenant_site_euid(self.db, target_tenant_id, payload.site_id)
        tenant_scope = None if cross_tenant else self.tenant_id

        result = self._repo().update_patient(
            patient_id=patient_id,
            data=payload,
            updated_by=updated_by,
            tenant_id=tenant_scope,
        )
        if not result:
            return None

        patient, revision = result
        self._log_audit_event(
            tenant_id=patient.tenant_id,
            action=AuditAction.UPDATE,
            entity_type="Patient",
            entity_id=patient_id,
            user_id=updated_by,
        )
        return patient, revision


class ClinicianService:
    """Service for clinician operations with tenant scoping."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.people import TapdbPeopleRepository

            self._tapdb_repo = TapdbPeopleRepository(self.db)
        return self._tapdb_repo

    def _log_audit_event(
        self,
        *,
        tenant_id: uuid.UUID,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        user_id: uuid.UUID | None = None,
        details: dict | None = None,
    ) -> None:
        """Best-effort audit logging via TapDB-backed AuditService."""
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db,
                tenant_id=tenant_id,
                user_id=str(user_id) if user_id else None,
            ).log(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
                user_id=user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.warning(
                "Audit logging failed for %s %s in tenant %s",
                entity_type,
                entity_id,
                tenant_id,
                exc_info=True,
            )

    def create(
        self,
        data: ClinicianCreate,
        created_by: uuid.UUID | None = None,
    ):
        """Create a new clinician with initial revision."""
        from app.domain.services.site_scope import resolve_tenant_site_euid

        data.site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.site_id)
        clinician, revision = self._repo().create_clinician(
            tenant_id=self.tenant_id,
            data=data,
            created_by=created_by,
        )

        self._log_audit_event(
            tenant_id=self.tenant_id,
            action=AuditAction.CREATE,
            entity_type="Clinician",
            entity_id=clinician.euid,
            user_id=created_by,
        )
        return clinician, revision

    def get_by_id(self, clinician_id: str, cross_tenant: bool = False):
        """Get clinician by ID (EUID) with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_clinician_with_revision(
            clinician_id=clinician_id,
            tenant_id=tenant_scope,
        )

    def get(self, clinician_id: str, cross_tenant: bool = False):
        """Get clinician by ID (EUID) with latest revision (alias for get_by_id)."""
        return self.get_by_id(clinician_id, cross_tenant=cross_tenant)

    def list_clinicians(
        self,
        skip: int = 0,
        limit: int = 100,
        active_only: bool = True,
        cross_tenant: bool = False,
    ):
        """List clinicians with their latest revisions."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_clinicians(
            tenant_id=tenant_scope,
            skip=skip,
            limit=limit,
            active_only=active_only,
        )

    def search_by_npi(self, npi: str, cross_tenant: bool = False):
        """Search clinician by NPI with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_clinician_by_npi(npi=npi, tenant_id=tenant_scope)

    def get_by_npi(self, npi: str, cross_tenant: bool = False):
        """Get single clinician by NPI with latest revision."""
        return self.search_by_npi(npi, cross_tenant=cross_tenant)

    def search_by_name(self, name: str, limit: int = 100, cross_tenant: bool = False):
        """Search clinicians by name with latest revisions."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().search_clinicians_by_name(
            name=name,
            tenant_id=tenant_scope,
            limit=limit,
        )

    def update(
        self,
        clinician_id: str,
        data: ClinicianUpdate | dict,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ):
        """Update clinician by creating a new revision."""
        if isinstance(data, dict):
            data = ClinicianUpdate(**data)
        if data.site_id is not None:
            from app.domain.services.site_scope import resolve_tenant_site_euid

            target_tenant_id = self.tenant_id
            if cross_tenant:
                existing = self._repo().get_clinician_with_revision(clinician_id, tenant_id=None)
                if existing is not None:
                    target_tenant_id = existing[0].tenant_id
            data.site_id = resolve_tenant_site_euid(self.db, target_tenant_id, data.site_id)

        tenant_scope = None if cross_tenant else self.tenant_id
        result = self._repo().update_clinician(
            clinician_id=clinician_id,
            data=data,
            updated_by=updated_by,
            tenant_id=tenant_scope,
        )
        if not result:
            return None

        clinician, revision = result
        self._log_audit_event(
            tenant_id=clinician.tenant_id,
            action=AuditAction.UPDATE,
            entity_type="Clinician",
            entity_id=clinician_id,
            user_id=updated_by,
        )
        return clinician, revision
