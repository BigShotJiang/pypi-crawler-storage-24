"""Atlas persisted storage-policy resolution and canonical path services."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Literal

from app.domain.services.orgs import OrganizationService, SiteService
from app.domain.services.people import PatientService
from app.domain.services.trfs import TestService, TrfService
from app.persistence.tapdb.storage_policies import (
    TapdbStoragePolicyRecord,
    TapdbStoragePolicyRepository,
)

StorageAccessMode = Literal["customer_bucket", "lsmc_managed"]
StorageScope = Literal["patient", "trf", "test"]


@dataclass(frozen=True)
class StoragePolicyUpsert:
    bucket: str
    region: str
    base_prefix: str = ""
    access_mode: StorageAccessMode = "lsmc_managed"
    assume_role_arn: str | None = None
    kms_key_arn: str | None = None
    allowed_artifact_classes: list[str] | None = None
    enabled: bool = True


@dataclass(frozen=True)
class EffectiveStoragePolicy:
    scope: Literal["organization", "site"]
    policy: TapdbStoragePolicyRecord


@dataclass(frozen=True)
class StorageTarget:
    effective_policy: EffectiveStoragePolicy
    bucket: str
    key: str
    storage_uri: str


@dataclass(frozen=True)
class UrsaReturnTarget:
    effective_policy: EffectiveStoragePolicy
    atlas_tenant_id: str
    atlas_site_euid: str
    atlas_trf_euid: str
    atlas_test_euid: str
    bucket: str
    key_prefix: str
    storage_uri_prefix: str


def _clean_segment(value: str) -> str:
    return str(value or "").strip().strip("/")


def _join_key(*parts: str) -> str:
    normalized = [_clean_segment(part) for part in parts if _clean_segment(part)]
    return "/".join(normalized)


def _require_tenant_uuid(value: str) -> uuid.UUID:
    try:
        return uuid.UUID(str(value))
    except ValueError as exc:
        raise ValueError("atlas_tenant_id must be a UUID string") from exc


class StoragePolicyService:
    """Service for org/site storage policy persistence and effective resolution."""

    def __init__(self, db):
        self.db = db
        self._repo: TapdbStoragePolicyRepository | None = None
        self._orgs: OrganizationService | None = None
        self._sites: SiteService | None = None

    def _repository(self) -> TapdbStoragePolicyRepository:
        if self._repo is None:
            self._repo = TapdbStoragePolicyRepository(self.db)
        return self._repo

    def _org_service(self) -> OrganizationService:
        if self._orgs is None:
            self._orgs = OrganizationService(self.db)
        return self._orgs

    def _site_service(self) -> SiteService:
        if self._sites is None:
            self._sites = SiteService(self.db)
        return self._sites

    def resolve_organization_euid_for_tenant(self, atlas_tenant_id: str) -> str:
        tenant_uuid = _require_tenant_uuid(atlas_tenant_id)
        org = self._org_service().get_by_uid(tenant_uuid)
        if org is None:
            raise ValueError(f"Organization not found for tenant: {atlas_tenant_id}")
        return str(org.euid)

    def upsert_org_policy(
        self,
        *,
        organization_euid: str,
        data: StoragePolicyUpsert,
        actor_id: uuid.UUID | None = None,
    ) -> TapdbStoragePolicyRecord:
        self._require_org_exists(organization_euid)
        normalized = self._normalized_upsert(data)
        return self._repository().upsert_org_policy(
            organization_euid=str(organization_euid).strip(),
            bucket=normalized.bucket,
            region=normalized.region,
            base_prefix=normalized.base_prefix,
            access_mode=normalized.access_mode,
            assume_role_arn=normalized.assume_role_arn,
            kms_key_arn=normalized.kms_key_arn,
            allowed_artifact_classes=normalized.allowed_artifact_classes or [],
            enabled=normalized.enabled,
            actor_id=actor_id,
        )

    def upsert_site_policy(
        self,
        *,
        organization_euid: str,
        site_euid: str,
        data: StoragePolicyUpsert,
        actor_id: uuid.UUID | None = None,
    ) -> TapdbStoragePolicyRecord:
        self._require_site_in_org(organization_euid=organization_euid, site_euid=site_euid)
        normalized = self._normalized_upsert(data)
        return self._repository().upsert_site_policy(
            organization_euid=str(organization_euid).strip(),
            site_euid=str(site_euid).strip(),
            bucket=normalized.bucket,
            region=normalized.region,
            base_prefix=normalized.base_prefix,
            access_mode=normalized.access_mode,
            assume_role_arn=normalized.assume_role_arn,
            kms_key_arn=normalized.kms_key_arn,
            allowed_artifact_classes=normalized.allowed_artifact_classes or [],
            enabled=normalized.enabled,
            actor_id=actor_id,
        )

    def clear_site_policy(self, *, organization_euid: str, site_euid: str) -> bool:
        self._require_site_in_org(organization_euid=organization_euid, site_euid=site_euid)
        return self._repository().clear_site_policy(
            organization_euid=str(organization_euid).strip(),
            site_euid=str(site_euid).strip(),
        )

    def get_org_policy(self, organization_euid: str) -> TapdbStoragePolicyRecord | None:
        return self._repository().get_org_policy(str(organization_euid).strip())

    def get_site_policy(
        self,
        *,
        organization_euid: str,
        site_euid: str,
    ) -> TapdbStoragePolicyRecord | None:
        return self._repository().get_site_policy(
            str(organization_euid).strip(),
            str(site_euid).strip(),
        )

    def resolve_effective_policy(
        self,
        *,
        organization_euid: str,
        site_euid: str | None,
    ) -> EffectiveStoragePolicy:
        clean_org = _clean_segment(organization_euid)
        clean_site = _clean_segment(site_euid or "")

        site_policy = None
        if clean_site:
            site_policy = self.get_site_policy(
                organization_euid=clean_org,
                site_euid=clean_site,
            )
            if site_policy is not None and site_policy.enabled:
                return EffectiveStoragePolicy(scope="site", policy=site_policy)

        org_policy = self.get_org_policy(clean_org)
        if org_policy is not None and org_policy.enabled:
            return EffectiveStoragePolicy(scope="organization", policy=org_policy)

        raise ValueError("No enabled storage policy exists for the requested organization/site")

    def build_target(
        self,
        *,
        scope: StorageScope,
        organization_euid: str,
        site_euid: str | None,
        patient_euid: str | None,
        trf_euid: str | None,
        test_euid: str | None,
        filename: str,
    ) -> StorageTarget:
        clean_filename = _clean_segment(filename or "artifact.bin") or "artifact.bin"
        effective = self.resolve_effective_policy(
            organization_euid=organization_euid,
            site_euid=site_euid,
        )
        policy = effective.policy

        if scope == "patient":
            clean_patient = _clean_segment(patient_euid or "")
            if not clean_patient:
                raise ValueError("atlas_patient_euid is required for patient storage scope")
            key = _join_key(policy.base_prefix, "patients", clean_patient, clean_filename)
        elif scope == "trf":
            clean_site = _clean_segment(site_euid or "")
            clean_trf = _clean_segment(trf_euid or "")
            if not clean_site or not clean_trf:
                raise ValueError("atlas_site_euid and atlas_trf_euid are required for trf scope")
            key = _join_key(
                policy.base_prefix,
                "sites",
                clean_site,
                "trfs",
                clean_trf,
                clean_filename,
            )
        else:
            clean_site = _clean_segment(site_euid or "")
            clean_trf = _clean_segment(trf_euid or "")
            clean_test = _clean_segment(test_euid or "")
            if not clean_site or not clean_trf or not clean_test:
                raise ValueError(
                    "atlas_site_euid, atlas_trf_euid, and atlas_test_euid are required for test scope"
                )
            key = _join_key(
                policy.base_prefix,
                "sites",
                clean_site,
                "trfs",
                clean_trf,
                "tests",
                clean_test,
                clean_filename,
            )

        return StorageTarget(
            effective_policy=effective,
            bucket=policy.bucket,
            key=key,
            storage_uri=f"s3://{policy.bucket}/{key}",
        )

    def authorize_release(
        self,
        *,
        atlas_tenant_id: str,
        patient_euid: str | None,
        trf_euid: str | None,
        test_euid: str | None,
    ) -> tuple[bool, str]:
        tenant_uuid = _require_tenant_uuid(atlas_tenant_id)
        patients = PatientService(self.db, tenant_uuid)
        trfs = TrfService(self.db, tenant_uuid)
        tests = TestService(self.db, tenant_uuid)

        clean_patient = _clean_segment(patient_euid or "")
        clean_trf = _clean_segment(trf_euid or "")
        clean_test = _clean_segment(test_euid or "")

        if not any([clean_patient, clean_trf, clean_test]):
            return False, "At least one Atlas patient/trf/test reference is required"

        if clean_patient:
            patient = patients.get(clean_patient, cross_tenant=False)
            if patient is None:
                return False, f"Patient not found: {clean_patient}"
        if clean_trf:
            trf = trfs.get_by_id(clean_trf, cross_tenant=False)
            if trf is None:
                return False, f"TRF not found: {clean_trf}"
        if clean_test:
            test = tests.get_by_id(clean_test, cross_tenant=False)
            if test is None:
                return False, f"Test not found: {clean_test}"
            if clean_trf and str(test.order_id) != clean_trf:
                return False, "Provided atlas_test_euid does not belong to atlas_trf_euid"
        return True, "Atlas release authorization check passed"

    def resolve_ursa_return_target(
        self,
        *,
        atlas_tenant_id: str,
        atlas_trf_euid: str,
        atlas_test_euid: str,
    ) -> UrsaReturnTarget:
        tenant_uuid = _require_tenant_uuid(atlas_tenant_id)
        organization_euid = self.resolve_organization_euid_for_tenant(atlas_tenant_id)

        trfs = TrfService(self.db, tenant_uuid)
        tests = TestService(self.db, tenant_uuid)

        trf_pair = trfs.get_by_id(atlas_trf_euid, cross_tenant=False)
        if trf_pair is None:
            raise ValueError(f"TRF not found: {atlas_trf_euid}")
        trf, _trf_revision = trf_pair

        test = tests.get_by_id(atlas_test_euid, cross_tenant=False)
        if test is None:
            raise ValueError(f"Test not found: {atlas_test_euid}")
        if str(test.order_id) != str(trf.euid):
            raise ValueError(f"Test {atlas_test_euid} does not belong to TRF {atlas_trf_euid}")

        site_euid = _clean_segment(test.site_id or trf.site_id or "")
        if not site_euid:
            raise ValueError(
                "No site is associated with the supplied TRF/Test; cannot resolve test-scoped target"
            )

        self._require_site_in_org(organization_euid=organization_euid, site_euid=site_euid)
        effective = self.resolve_effective_policy(
            organization_euid=organization_euid,
            site_euid=site_euid,
        )

        key_prefix = _join_key(
            effective.policy.base_prefix,
            "sites",
            site_euid,
            "trfs",
            _clean_segment(atlas_trf_euid),
            "tests",
            _clean_segment(atlas_test_euid),
        )
        return UrsaReturnTarget(
            effective_policy=effective,
            atlas_tenant_id=str(tenant_uuid),
            atlas_site_euid=site_euid,
            atlas_trf_euid=_clean_segment(atlas_trf_euid),
            atlas_test_euid=_clean_segment(atlas_test_euid),
            bucket=effective.policy.bucket,
            key_prefix=key_prefix,
            storage_uri_prefix=f"s3://{effective.policy.bucket}/{key_prefix}/",
        )

    def _require_org_exists(self, organization_euid: str) -> None:
        org = self._org_service().get_by_id(str(organization_euid).strip())
        if org is None:
            raise ValueError(f"Organization not found: {organization_euid}")

    def _require_site_in_org(self, *, organization_euid: str, site_euid: str) -> None:
        self._require_org_exists(organization_euid)
        site = self._site_service().get_by_id(str(site_euid).strip())
        if site is None:
            raise ValueError(f"Site not found: {site_euid}")
        if str(site.organization_id) != str(organization_euid):
            raise ValueError(
                f"Site {site_euid} does not belong to organization {organization_euid}"
            )

    def _normalized_upsert(self, data: StoragePolicyUpsert) -> StoragePolicyUpsert:
        bucket = _clean_segment(data.bucket)
        region = _clean_segment(data.region)
        base_prefix = _clean_segment(data.base_prefix or "")
        if not bucket:
            raise ValueError("bucket is required")
        if not region:
            raise ValueError("region is required")
        access_mode = str(data.access_mode or "").strip()
        if access_mode not in {"customer_bucket", "lsmc_managed"}:
            raise ValueError("access_mode must be customer_bucket or lsmc_managed")

        return StoragePolicyUpsert(
            bucket=bucket,
            region=region,
            base_prefix=base_prefix,
            access_mode=access_mode,  # type: ignore[arg-type]
            assume_role_arn=str(data.assume_role_arn or "").strip() or None,
            kms_key_arn=str(data.kms_key_arn or "").strip() or None,
            allowed_artifact_classes=[
                str(item).strip()
                for item in (data.allowed_artifact_classes or [])
                if str(item).strip()
            ],
            enabled=bool(data.enabled),
        )
