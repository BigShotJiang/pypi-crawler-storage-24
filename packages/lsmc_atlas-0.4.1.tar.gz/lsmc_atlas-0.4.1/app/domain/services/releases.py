"""LSMC Hub - Release Package Service (TapDB-only runtime)."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from app.domain.enums import AuditAction, ReleasePackageStatus
from app.domain.services.audit import AuditService
from app.domain.services.webhook_emitter import (
    emit_artifact_available,
    emit_release_package_created,
    emit_release_package_released,
)
from app.persistence.tapdb.releases_repo import (
    TapdbArtifactRecord as Artifact,
)
from app.persistence.tapdb.releases_repo import (
    TapdbReleasePackageRecord as ReleasePackage,
)
from app.persistence.tapdb.releases_repo import (
    TapdbReleasePackageRevisionRecord as ReleasePackageRevision,
)
from app.persistence.tapdb.releases_repo import TapdbReleaseRepository

logger = logging.getLogger(__name__)


def generate_package_number(db: Session) -> str:
    """Generate the next `REL-N` package number from TapDB state."""
    return TapdbReleaseRepository(db).generate_next_package_number()


def _coerce_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, TypeError):
        return None


@dataclass
class ArtifactCreate:
    """Data for registering an artifact."""

    source_system: str
    source_uid: str
    filename: str
    checksum: str
    checksum_algorithm: str = "sha256"
    content_type: str | None = None
    size_bytes: int | None = None
    artifact_type: str | None = None
    s3_bucket: str | None = None
    s3_key: str | None = None
    metadata: dict | None = None
    order_id: str | None = None
    fulfillment_run_id: str | None = None


@dataclass
class ReleasePackageCreate:
    """Data for creating a release package."""

    order_id: str | None = None
    artifact_ids: list[str] | None = None
    release_notes: str | None = None
    # Backward-compatible fields still sent by some internal callers.
    release_type: str | None = None
    notes: str | None = None


class ReleaseService:
    """Service for release package operations."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._tapdb_repo: TapdbReleaseRepository | None = None

    def _repo(self) -> TapdbReleaseRepository:
        if self._tapdb_repo is None:
            self._tapdb_repo = TapdbReleaseRepository(self.db)
        return self._tapdb_repo

    def _log_audit_event(
        self,
        *,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        user_id: uuid.UUID | None,
        details: dict | None = None,
    ) -> None:
        try:
            AuditService(self.db, tenant_id=self.tenant_id).log(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
                user_id=user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.warning(
                "Audit logging failed for %s %s in tenant %s",
                entity_type,
                entity_id,
                self.tenant_id,
                exc_info=True,
            )

    @staticmethod
    def _artifact_filter_match(
        artifact: Artifact,
        *,
        order_id: str | None,
        fulfillment_run_id: str | None,
    ) -> bool:
        if order_id is None and fulfillment_run_id is None:
            return True
        metadata = (
            artifact.artifact_metadata if isinstance(artifact.artifact_metadata, dict) else {}
        )
        if order_id is not None and str(metadata.get("order_id") or "") != str(order_id):
            return False
        if fulfillment_run_id is not None and str(metadata.get("fulfillment_run_id") or "") != str(
            fulfillment_run_id
        ):
            return False
        return True

    def register_artifact(
        self,
        data: ArtifactCreate,
        created_by: uuid.UUID | None = None,
    ) -> Artifact:
        """Register a new artifact (from LIMS/external systems)."""
        existing = self.get_artifact_by_source(data.source_system, data.source_uid)
        if existing:
            return existing

        metadata = dict(data.metadata or {})
        if data.order_id:
            metadata.setdefault("order_id", str(data.order_id))
        if data.fulfillment_run_id:
            metadata.setdefault("fulfillment_run_id", str(data.fulfillment_run_id))

        artifact = self._repo().create_artifact(
            tenant_id=self.tenant_id,
            source_system=data.source_system,
            source_uid=data.source_uid,
            filename=data.filename,
            checksum=data.checksum,
            checksum_algorithm=data.checksum_algorithm,
            content_type=data.content_type,
            size_bytes=data.size_bytes,
            artifact_type=data.artifact_type,
            s3_bucket=data.s3_bucket,
            s3_key=data.s3_key,
            metadata=metadata,
            created_by=created_by,
        )

        self._log_audit_event(
            action=AuditAction.CREATE,
            entity_type="Artifact",
            entity_id=artifact.euid,
            user_id=created_by,
            details={"source_system": data.source_system, "source_uid": data.source_uid},
        )
        self.db.commit()

        emit_artifact_available(
            self.db,
            self.tenant_id,
            artifact.euid,
            data.source_system,
            data.source_uid,
            data.artifact_type,
        )
        return artifact

    def get_artifact_by_id(self, artifact_id: str, cross_tenant: bool = False) -> Artifact | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_artifact_by_id(artifact_id=artifact_id, tenant_id=tenant_scope)

    def get_artifact_by_source(
        self, source_system: str, source_uid: str, cross_tenant: bool = False
    ) -> Artifact | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_artifact_by_source(
            source_system=source_system,
            source_uid=source_uid,
            tenant_id=tenant_scope,
        )

    def create_package(
        self,
        data: ReleasePackageCreate,
        created_by: uuid.UUID | None = None,
    ) -> ReleasePackage:
        """Create a new release package."""
        package_number = generate_package_number(self.db)
        if data.release_notes is None and data.notes:
            data.release_notes = data.notes

        package, _revision = self._repo().create_package(
            tenant_id=self.tenant_id,
            package_number=package_number,
            data=data,
            created_by=created_by,
        )
        self._log_audit_event(
            action=AuditAction.CREATE,
            entity_type="ReleasePackage",
            entity_id=package.euid,
            user_id=created_by,
            details={"package_number": package_number},
        )
        self.db.commit()

        emit_release_package_created(
            self.db,
            self.tenant_id,
            package.euid,
            package_number,
            data.order_id,
        )
        return package

    def get_by_id(self, package_id: str, cross_tenant: bool = False) -> ReleasePackage | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_package_by_id(package_id=package_id, tenant_id=tenant_scope)

    def get(
        self, package_id: str, cross_tenant: bool = False
    ) -> tuple[ReleasePackage, ReleasePackageRevision | None] | None:
        package = self.get_by_id(package_id, cross_tenant=cross_tenant)
        if not package:
            return None
        return (package, self._get_latest_revision(package.euid))

    def get_by_package_number(
        self, package_number: str, cross_tenant: bool = False
    ) -> tuple[ReleasePackage, ReleasePackageRevision | None] | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_package_by_number(
            package_number=package_number, tenant_id=tenant_scope
        )

    def list_packages(
        self,
        skip: int = 0,
        limit: int = 50,
        order_id: str | None = None,
        cross_tenant: bool = False,
    ) -> list[tuple[ReleasePackage, ReleasePackageRevision | None]]:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_packages(
            tenant_id=tenant_scope,
            skip=skip,
            limit=limit,
            order_id=order_id,
        )

    def get_artifact(self, artifact_id: str, cross_tenant: bool = False) -> Artifact | None:
        return self.get_artifact_by_id(artifact_id, cross_tenant=cross_tenant)

    def list_artifacts(
        self,
        *,
        skip: int = 0,
        limit: int = 50,
        order_id: str | None = None,
        fulfillment_run_id: str | None = None,
        cross_tenant: bool = False,
    ) -> list[Artifact]:
        tenant_scope = None if cross_tenant else self.tenant_id
        artifacts = self._repo().list_artifacts(
            tenant_id=tenant_scope,
            skip=0,
            limit=max(limit + skip, 10_000),
        )
        filtered = [
            item
            for item in artifacts
            if self._artifact_filter_match(item, order_id=order_id, fulfillment_run_id=fulfillment_run_id)
        ]
        return filtered[skip : skip + limit]

    def add_artifact(
        self,
        package_id: str,
        artifact_id: str,
        created_by: uuid.UUID | None = None,
    ) -> ReleasePackage | None:
        package = self.get_by_id(package_id)
        if not package:
            return None
        latest = self._get_latest_revision(package.euid)
        if not latest or latest.status != ReleasePackageStatus.DRAFT.value:
            return None

        artifact_ids = list(latest.artifact_ids)
        if artifact_id not in artifact_ids:
            artifact_ids.append(artifact_id)

        revision = self._repo().create_package_revision(
            package_id=package.euid,
            status=latest.status,
            artifact_ids=artifact_ids,
            release_notes=latest.release_notes,
            released_at=latest.released_at,
            released_by=latest.released_by,
            note=f"Added artifact {artifact_id}",
            created_by=created_by,
        )
        if revision is None:
            return None

        self._log_audit_event(
            action=AuditAction.UPDATE,
            entity_type="ReleasePackage",
            entity_id=package.euid,
            user_id=created_by,
            details={"action": "ADD_ARTIFACT", "artifact_id": artifact_id},
        )
        self.db.commit()
        return package

    def change_status(
        self,
        package_id: str,
        new_status: ReleasePackageStatus,
        reason: str | None = None,
        updated_by: uuid.UUID | None = None,
    ) -> ReleasePackage | None:
        package = self.get_by_id(package_id)
        if not package:
            return None
        latest = self._get_latest_revision(package.euid)
        if latest is None:
            return None

        if latest.status == new_status.value:
            return package

        released_at = (
            datetime.now(UTC)
            if new_status == ReleasePackageStatus.RELEASED
            else latest.released_at
        )
        released_by = (
            updated_by if new_status == ReleasePackageStatus.RELEASED else latest.released_by
        )

        revision = self._repo().create_package_revision(
            package_id=package.euid,
            status=new_status.value,
            artifact_ids=list(latest.artifact_ids),
            release_notes=latest.release_notes,
            released_at=released_at,
            released_by=released_by,
            note=reason,
            created_by=updated_by,
        )
        if revision is None:
            return None

        self._log_audit_event(
            action=AuditAction.STATUS_CHANGE,
            entity_type="ReleasePackage",
            entity_id=package.euid,
            user_id=updated_by,
            details={"old_status": latest.status, "new_status": new_status.value, "reason": reason},
        )
        self.db.commit()
        return package

    def release(
        self,
        package_id: str,
        released_by: uuid.UUID | None = None,
    ) -> ReleasePackage | None:
        package_bundle = self.get(package_id)
        if package_bundle is None:
            return None
        package, latest = package_bundle
        if latest is None or latest.status != ReleasePackageStatus.APPROVED.value:
            return None

        result = self.change_status(
            package.euid,
            ReleasePackageStatus.RELEASED,
            reason="Released to client",
            updated_by=released_by,
        )
        if result is None:
            return None

        released_revision = self._get_latest_revision(package.euid)
        self._log_audit_event(
            action=AuditAction.STATUS_CHANGE,
            entity_type="ReleasePackage",
            entity_id=package.euid,
            user_id=released_by,
            details={"action": "RELEASE", "artifact_count": len(latest.artifact_ids)},
        )
        self.db.commit()

        emit_release_package_released(
            self.db,
            self.tenant_id,
            package.euid,
            package.package_number,
        )
        # Keep backward compatibility for callers expecting refreshed release timestamp.
        if released_revision is not None:
            logger.debug(
                "Release %s now in %s at %s",
                package.euid,
                released_revision.status,
                released_revision.released_at,
            )
        return result

    def re_release(
        self,
        package_id: str,
        additional_artifact_ids: list[str] | None = None,
        release_notes: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> ReleasePackage | None:
        package = self.get_by_id(package_id)
        if not package:
            return None
        latest = self._get_latest_revision(package.euid)
        if latest is None:
            return None

        artifact_ids = list(latest.artifact_ids)
        for artifact_id in additional_artifact_ids or []:
            if artifact_id not in artifact_ids:
                artifact_ids.append(artifact_id)

        revision = self._repo().create_package_revision(
            package_id=package.euid,
            status=ReleasePackageStatus.RELEASED.value,
            artifact_ids=artifact_ids,
            release_notes=release_notes if release_notes is not None else latest.release_notes,
            released_at=datetime.now(UTC),
            released_by=created_by,
            note="Re-released",
            created_by=created_by,
        )
        if revision is None:
            return None

        self._log_audit_event(
            action=AuditAction.UPDATE,
            entity_type="ReleasePackage",
            entity_id=package.euid,
            user_id=created_by,
            details={"action": "RE_RELEASE", "revision_no": revision.revision_no},
        )
        self.db.commit()
        return package

    def list_by_order(self, order_id: str, cross_tenant: bool = False) -> list[ReleasePackage]:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_by_order(order_id=order_id, tenant_id=tenant_scope)

    def get_artifacts(self, package_id: str) -> list[Artifact]:
        latest = self._get_latest_revision(package_id)
        if not latest or not latest.artifact_ids:
            return []

        artifacts: list[Artifact] = []
        for artifact_id in latest.artifact_ids:
            artifact = self._repo().get_artifact_by_id(
                artifact_id=artifact_id,
                tenant_id=self.tenant_id,
            )
            if artifact is not None:
                artifacts.append(artifact)
        return artifacts

    def _get_latest_revision(self, package_id: str) -> ReleasePackageRevision | None:
        return self._repo().get_latest_revision(package_id)
