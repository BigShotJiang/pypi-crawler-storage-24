"""Test graph relationships (TapDB lineage).

This module implements:
- Test ↔ Patient links with explicit roles
- Test ↔ Test links

Terminology note:
- Atlas uses TRF for the parent requisition and Test for the child requested assay object.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from sqlalchemy import select

from app.domain.enums import OrderPatientRole
from app.persistence.tapdb.euid_helpers import get_instance_by_euid
from app.persistence.tapdb.people import PATIENT_TEMPLATE_CODE, TapdbPeopleRepository
from app.persistence.tapdb.trfs import TEST_TEMPLATE_CODE, TapdbTrfRepository

REL_ORDER_PATIENT = "order_patient"
REL_LINKED_ORDER = "linked_order"


@dataclass(frozen=True)
class OrderPatientLink:
    patient_euid: str
    role: OrderPatientRole


@dataclass(frozen=True)
class LinkedOrder:
    order_euid: str
    link_type: str


class OrderRelationshipService:
    """Graph-native ordering relationships using TapDB lineage edges."""

    def __init__(self, db: Any, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._orders_repo: TapdbTrfRepository | None = None
        self._people_repo: TapdbPeopleRepository | None = None

    def _orders(self) -> TapdbTrfRepository:
        if self._orders_repo is None:
            self._orders_repo = TapdbTrfRepository(self.db)
        return self._orders_repo

    def _people(self) -> TapdbPeopleRepository:
        if self._people_repo is None:
            self._people_repo = TapdbPeopleRepository(self.db)
        return self._people_repo

    def _properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties") if isinstance(raw, dict) else None
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _instance_tenant_id(self, instance: generic_instance) -> uuid.UUID | None:
        props = self._properties(instance)
        value = props.get("tenant_id")
        if isinstance(value, uuid.UUID):
            return value
        if isinstance(value, str) and value.strip():
            try:
                return uuid.UUID(value)
            except ValueError:
                return None
        return None

    def _get_visible_instance_by_uid(self, instance_uid: int) -> generic_instance | None:
        stmt = (
            select(generic_instance)
            .where(generic_instance.uid == instance_uid, generic_instance.is_deleted.is_(False))
            .limit(1)
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def _ensure_lineage(
        self,
        *,
        parent: generic_instance,
        child: generic_instance,
        relationship_type: str,
        properties: dict[str, Any] | None = None,
    ) -> generic_instance_lineage:
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == parent.uid,
                generic_instance_lineage.child_instance_uid == child.uid,
                generic_instance_lineage.relationship_type == relationship_type,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is not None and not existing.is_deleted:
            if properties:
                existing.json_addl = {"properties": dict(properties)}
            self.db.flush()
            return existing
        if existing is not None and existing.is_deleted:
            existing.is_deleted = False
            if properties:
                existing.json_addl = {"properties": dict(properties)}
            self.db.flush()
            return existing

        lineage = self._orders().factory.link_instances(
            session=self.db,
            parent=parent,
            child=child,
            relationship_type=relationship_type,
        )
        if properties:
            lineage.json_addl = {"properties": dict(properties)}
        self.db.flush()
        return lineage

    def _validate_patient_links(self, links: list[OrderPatientLink]) -> None:
        if not links:
            raise ValueError("Order requires at least one patient link")

        # Enforce uniqueness for certain roles.
        unique_roles = {OrderPatientRole.PROBAND, OrderPatientRole.FATHER, OrderPatientRole.MOTHER}
        seen_unique: set[OrderPatientRole] = set()
        for link in links:
            if link.role in unique_roles:
                if link.role in seen_unique:
                    raise ValueError(f"Only one {link.role.value} may be linked to an order")
                seen_unique.add(link.role)

    def ensure_order_patient_links(
        self,
        *,
        order_euid: str,
        links: list[OrderPatientLink],
        replace: bool = False,
    ) -> None:
        """Ensure lineage edges exist for each (order, patient, role).

        If replace=True, any existing order_patient edges for the order are deleted first.
        """
        self._validate_patient_links(links)

        order_inst = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, order_euid)
        if order_inst is None:
            raise ValueError(f"Order not found: {order_euid}")
        if (self._instance_tenant_id(order_inst) or self.tenant_id) != self.tenant_id:
            raise ValueError("Cross-tenant write denied")

        if replace:
            stmt = select(generic_instance_lineage).where(
                generic_instance_lineage.child_instance_uid == order_inst.uid,
                generic_instance_lineage.relationship_type == REL_ORDER_PATIENT,
                generic_instance_lineage.is_deleted.is_(False),
            )
            for edge in self.db.execute(stmt).scalars().all():
                edge.is_deleted = True

        for link in links:
            patient_inst = get_instance_by_euid(self.db, PATIENT_TEMPLATE_CODE, link.patient_euid)
            if patient_inst is None:
                raise ValueError(f"Patient not found: {link.patient_euid}")
            if (self._instance_tenant_id(patient_inst) or self.tenant_id) != self.tenant_id:
                raise ValueError("Cross-tenant write denied")

            self._ensure_lineage(
                parent=patient_inst,
                child=order_inst,
                relationship_type=REL_ORDER_PATIENT,
                properties={"role": link.role.value},
            )

    def list_order_patient_links(self, *, order_euid: str) -> list[OrderPatientLink]:
        order_inst = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, order_euid)
        if order_inst is None:
            return []
        if (self._instance_tenant_id(order_inst) or self.tenant_id) != self.tenant_id:
            return []

        stmt = select(generic_instance_lineage).where(
            generic_instance_lineage.child_instance_uid == order_inst.uid,
            generic_instance_lineage.relationship_type == REL_ORDER_PATIENT,
            generic_instance_lineage.is_deleted.is_(False),
        )
        edges = list(self.db.execute(stmt).scalars().all())
        links: list[OrderPatientLink] = []
        for edge in edges:
            parent = self._get_visible_instance_by_uid(edge.parent_instance_uid)
            if parent is None:
                continue
            if (self._instance_tenant_id(parent) or self.tenant_id) != self.tenant_id:
                continue
            props = (
                (edge.json_addl or {}).get("properties")
                if isinstance(edge.json_addl, dict)
                else None
            )
            role_raw = props.get("role") if isinstance(props, dict) else None
            try:
                role = OrderPatientRole(str(role_raw))
            except ValueError:
                role = OrderPatientRole.OTHER

            links.append(OrderPatientLink(patient_euid=parent.euid, role=role))

        # stable ordering
        links.sort(key=lambda item: (item.role.value, item.patient_euid))
        return links

    def link_orders(
        self,
        *,
        source_order_euid: str,
        target_order_euid: str,
        link_type: str = "generic",
    ) -> None:
        if source_order_euid == target_order_euid:
            raise ValueError("Cannot link an order to itself")

        source = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, source_order_euid)
        target = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, target_order_euid)
        if source is None:
            raise ValueError(f"Order not found: {source_order_euid}")
        if target is None:
            raise ValueError(f"Order not found: {target_order_euid}")

        if (self._instance_tenant_id(source) or self.tenant_id) != self.tenant_id:
            raise ValueError("Cross-tenant write denied")
        if (self._instance_tenant_id(target) or self.tenant_id) != self.tenant_id:
            raise ValueError("Cross-tenant write denied")

        self._ensure_lineage(
            parent=target,
            child=source,
            relationship_type=REL_LINKED_ORDER,
            properties={"link_type": str(link_type or "generic")},
        )

    def list_linked_orders(self, *, source_order_euid: str) -> list[LinkedOrder]:
        source = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, source_order_euid)
        if source is None:
            return []
        if (self._instance_tenant_id(source) or self.tenant_id) != self.tenant_id:
            return []

        stmt = select(generic_instance_lineage).where(
            generic_instance_lineage.child_instance_uid == source.uid,
            generic_instance_lineage.relationship_type == REL_LINKED_ORDER,
            generic_instance_lineage.is_deleted.is_(False),
        )
        edges = list(self.db.execute(stmt).scalars().all())
        linked: list[LinkedOrder] = []
        for edge in edges:
            parent = self._get_visible_instance_by_uid(edge.parent_instance_uid)
            if parent is None:
                continue
            if (self._instance_tenant_id(parent) or self.tenant_id) != self.tenant_id:
                continue
            props = (
                (edge.json_addl or {}).get("properties")
                if isinstance(edge.json_addl, dict)
                else None
            )
            link_type = (
                str(props.get("link_type") or "generic") if isinstance(props, dict) else "generic"
            )
            linked.append(LinkedOrder(order_euid=parent.euid, link_type=link_type))
        linked.sort(key=lambda item: (item.link_type, item.order_euid))
        return linked
