"""LSMC Hub - Domain Policies.

Business rules and policies for:
- Order status rollups
- Permission checks
"""

from app.domain.policies.permissions import PermissionService, require_entity_permission

__all__ = [
    "OrderRollupService",
    "compute_order_status",
    "PermissionService",
    "require_entity_permission",
]


def __getattr__(name: str):
    """Lazy-load rollup policy symbols to avoid import cycles."""
    if name in {"OrderRollupService", "compute_order_status"}:
        from app.domain.policies.rollups import OrderRollupService, compute_order_status

        if name == "OrderRollupService":
            return OrderRollupService
        return compute_order_status
    raise AttributeError(name)
