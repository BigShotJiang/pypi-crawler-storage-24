"""LSMC Hub - API Client Web Routes.

Server-rendered pages for API client management.
"""

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_read_write_web
from app.db.engine import get_db
from app.domain.services.api_clients import (
    APIClientCreate,
    APIClientService,
    APIClientUpdate,
)
from app.domain.services.site_scope import list_tenant_site_options
from app.web.templates import templates

router = APIRouter(prefix="/api-clients", tags=["web-api-clients"])

# Available permissions for API clients
AVAILABLE_PERMISSIONS = [
    "artifact:read",
    "artifact:write",
    "order:read",
    "order:write",
    "shipment:read",
    "shipment:write",
    "manifest:read",
    "manifest:write",
    "release:read",
    "webhook:trigger",
]


@router.get("", response_class=HTMLResponse)
async def list_api_clients(
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """List all API clients."""
    tenant_id = current_user.tenant_id
    svc = APIClientService(db, tenant_id)

    clients = svc.list()

    return templates.TemplateResponse(
        "api_clients/list.html",
        {
            "request": request,
            "current_user": current_user,
            "clients": clients,
            "now": datetime.now(UTC),
        },
    )


@router.get("/new", response_class=HTMLResponse)
async def new_api_client_form(
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Show form to create a new API client."""
    site_options = list_tenant_site_options(db, current_user.tenant_id)
    return templates.TemplateResponse(
        "api_clients/form.html",
        {
            "request": request,
            "current_user": current_user,
            "client": None,
            "revision": None,
            "available_permissions": AVAILABLE_PERMISSIONS,
            "site_options": site_options,
            "selected_site_id": site_options[0].id if len(site_options) == 1 else None,
        },
    )


@router.post("/new", dependencies=[Depends(require_read_write_web)])
async def create_api_client(
    request: Request,
    client_name: str = Form(...),
    permissions: list[str] = Form(...),
    allowed_endpoints: str = Form(None),
    rate_limit_per_minute: int = Form(None),
    ip_allowed_list: str = Form(None),
    expires_at: str = Form(None),
    site_id: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Create a new API client."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    svc = APIClientService(db, tenant_id)

    # Parse multi-line inputs
    allowed_endpoints_list = (
        [e.strip() for e in allowed_endpoints.split("\n") if e.strip()]
        if allowed_endpoints
        else None
    )
    ip_allowed_list_parsed = (
        [ip.strip() for ip in ip_allowed_list.split("\n") if ip.strip()]
        if ip_allowed_list
        else None
    )
    expires_at_dt = datetime.fromisoformat(expires_at) if expires_at else None

    data = APIClientCreate(
        client_name=client_name,
        permissions=permissions,
        allowed_endpoints=allowed_endpoints_list,
        rate_limit_per_minute=rate_limit_per_minute,
        ip_allowed_list=ip_allowed_list_parsed,
        expires_at=expires_at_dt,
        site_id=(site_id or "").strip() or None,
    )

    try:
        client, revision, api_key = svc.create(data, created_by=user_id)
    except ValueError as exc:
        site_options = list_tenant_site_options(db, tenant_id)
        return templates.TemplateResponse(
            "api_clients/form.html",
            {
                "request": request,
                "current_user": current_user,
                "client": None,
                "revision": None,
                "available_permissions": AVAILABLE_PERMISSIONS,
                "site_options": site_options,
                "selected_site_id": (site_id or "").strip() or None,
                "error": str(exc),
            },
            status_code=400,
        )

    # Show the API key page
    return templates.TemplateResponse(
        "api_clients/show_key.html",
        {
            "request": request,
            "current_user": current_user,
            "client": client,
            "api_key": api_key,
            "action": "created",
        },
    )


@router.get("/{client_id}", response_class=HTMLResponse)
async def api_client_detail(
    request: Request,
    client_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Show API client detail."""
    tenant_id = current_user.tenant_id
    svc = APIClientService(db, tenant_id)

    result = svc.get(client_id)
    if not result:
        return RedirectResponse(url="/api-clients", status_code=303)

    client, revision = result

    # Get recent usage logs
    usage_logs = svc.get_usage_logs(client_id=client_id, limit=20)

    return templates.TemplateResponse(
        "api_clients/detail.html",
        {
            "request": request,
            "current_user": current_user,
            "client": client,
            "revision": revision,
            "usage_logs": usage_logs,
            "now": datetime.now(UTC),
        },
    )


@router.get("/{client_id}/edit", response_class=HTMLResponse)
async def edit_api_client_form(
    request: Request,
    client_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Show form to edit an API client."""
    tenant_id = current_user.tenant_id
    svc = APIClientService(db, tenant_id)

    result = svc.get(client_id)
    if not result:
        return RedirectResponse(url="/api-clients", status_code=303)

    client, revision = result
    site_options = list_tenant_site_options(db, tenant_id)

    return templates.TemplateResponse(
        "api_clients/form.html",
        {
            "request": request,
            "current_user": current_user,
            "client": client,
            "revision": revision,
            "available_permissions": AVAILABLE_PERMISSIONS,
            "site_options": site_options,
            "selected_site_id": getattr(client, "site_id", None),
        },
    )


@router.post("/{client_id}/edit", dependencies=[Depends(require_read_write_web)])
async def update_api_client(
    request: Request,
    client_id: str,
    permissions: list[str] = Form(...),
    allowed_endpoints: str = Form(None),
    rate_limit_per_minute: int = Form(None),
    ip_allowed_list: str = Form(None),
    expires_at: str = Form(None),
    is_active: bool = Form(False),
    note: str = Form(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Update an API client."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    svc = APIClientService(db, tenant_id)

    # Parse multi-line inputs
    allowed_endpoints_list = (
        [e.strip() for e in allowed_endpoints.split("\n") if e.strip()]
        if allowed_endpoints
        else None
    )
    ip_allowed_list_parsed = (
        [ip.strip() for ip in ip_allowed_list.split("\n") if ip.strip()]
        if ip_allowed_list
        else None
    )
    expires_at_dt = datetime.fromisoformat(expires_at) if expires_at else None

    data = APIClientUpdate(
        is_active=is_active,
        permissions=permissions,
        allowed_endpoints=allowed_endpoints_list,
        rate_limit_per_minute=rate_limit_per_minute,
        ip_allowed_list=ip_allowed_list_parsed,
        expires_at=expires_at_dt,
        note=note,
    )

    result = svc.update(client_id, data, updated_by=user_id)
    if not result:
        return RedirectResponse(url="/api-clients", status_code=303)

    return RedirectResponse(
        url=f"/api-clients/{client_id}",
        status_code=303,
    )


@router.post("/{client_id}/rotate-key", dependencies=[Depends(require_read_write_web)])
async def rotate_api_key(
    request: Request,
    client_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Rotate the API key for a client."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    svc = APIClientService(db, tenant_id)

    result = svc.rotate_key(client_id, rotated_by=user_id)
    if not result:
        return RedirectResponse(url="/api-clients", status_code=303)

    client, revision, api_key = result

    # Show the API key page
    return templates.TemplateResponse(
        "api_clients/show_key.html",
        {
            "request": request,
            "current_user": current_user,
            "client": client,
            "api_key": api_key,
            "action": "rotated",
        },
    )
