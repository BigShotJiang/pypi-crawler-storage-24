"""LSMC Hub - Webhook Web Routes.

Server-rendered pages for webhook management.
"""

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.auth.dependencies import get_current_user, require_read_write_web
from app.db.engine import get_db
from app.domain.enums import WebhookEventType
from app.domain.services.site_scope import list_tenant_site_options
from app.domain.services.webhooks import (
    WebhookService,
    WebhookSubscriptionCreate,
    WebhookSubscriptionUpdate,
)
from app.web.templates import templates

router = APIRouter(prefix="/webhooks", tags=["web-webhooks"])


@router.get("", response_class=HTMLResponse)
async def list_webhooks(
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """List all webhook subscriptions."""
    tenant_id = current_user.tenant_id
    webhook_svc = WebhookService(db, tenant_id)

    subscriptions = webhook_svc.list()

    return templates.TemplateResponse(
        "webhooks/list.html",
        {
            "request": request,
            "current_user": current_user,
            "subscriptions": subscriptions,
        },
    )


@router.get("/new", response_class=HTMLResponse)
async def new_webhook_form(
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Show form to create a new webhook subscription."""
    available_event_types = [event.value for event in WebhookEventType]
    site_options = list_tenant_site_options(db, current_user.tenant_id)

    return templates.TemplateResponse(
        "webhooks/form.html",
        {
            "request": request,
            "current_user": current_user,
            "subscription": None,
            "revision": None,
            "available_event_types": available_event_types,
            "site_options": site_options,
            "selected_site_id": site_options[0].id if len(site_options) == 1 else None,
        },
    )


@router.post("/new", dependencies=[Depends(require_read_write_web)])
async def create_webhook(
    request: Request,
    subscription_name: str = Form(...),
    url: str = Form(...),
    secret: str = Form(...),
    event_types: list[str] = Form(...),
    timeout_seconds: int = Form(30),
    max_retries: int = Form(3),
    note: str = Form(None),
    site_id: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Create a new webhook subscription."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    webhook_svc = WebhookService(db, tenant_id)

    data = WebhookSubscriptionCreate(
        subscription_name=subscription_name,
        url=url,
        secret=secret,
        event_types=event_types,
        timeout_seconds=timeout_seconds,
        max_retries=max_retries,
        site_id=(site_id or "").strip() or None,
    )

    try:
        subscription, _ = webhook_svc.create(data, created_by=user_id)
    except ValueError as exc:
        available_event_types = [event.value for event in WebhookEventType]
        site_options = list_tenant_site_options(db, tenant_id)
        return templates.TemplateResponse(
            "webhooks/form.html",
            {
                "request": request,
                "current_user": current_user,
                "subscription": None,
                "revision": None,
                "available_event_types": available_event_types,
                "site_options": site_options,
                "selected_site_id": (site_id or "").strip() or None,
                "error": str(exc),
            },
            status_code=400,
        )

    return RedirectResponse(
        url=f"/webhooks/{subscription.euid}",
        status_code=303,
    )


@router.get("/{subscription_id}", response_class=HTMLResponse)
async def webhook_detail(
    request: Request,
    subscription_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Show webhook subscription detail."""
    tenant_id = current_user.tenant_id
    webhook_svc = WebhookService(db, tenant_id)

    result = webhook_svc.get(subscription_id)
    if not result:
        return RedirectResponse(url="/webhooks", status_code=303)

    subscription, revision = result

    # Get recent delivery logs
    delivery_logs = webhook_svc.get_delivery_logs(subscription_id=subscription_id, limit=10)

    return templates.TemplateResponse(
        "webhooks/detail.html",
        {
            "request": request,
            "current_user": current_user,
            "subscription": subscription,
            "revision": revision,
            "delivery_logs": delivery_logs,
        },
    )


@router.get("/{subscription_id}/edit", response_class=HTMLResponse)
async def edit_webhook_form(
    request: Request,
    subscription_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Show form to edit a webhook subscription."""
    tenant_id = current_user.tenant_id
    webhook_svc = WebhookService(db, tenant_id)

    result = webhook_svc.get(subscription_id)
    if not result:
        return RedirectResponse(url="/webhooks", status_code=303)

    subscription, revision = result
    available_event_types = [event.value for event in WebhookEventType]
    site_options = list_tenant_site_options(db, tenant_id)

    return templates.TemplateResponse(
        "webhooks/form.html",
        {
            "request": request,
            "current_user": current_user,
            "subscription": subscription,
            "revision": revision,
            "available_event_types": available_event_types,
            "site_options": site_options,
            "selected_site_id": getattr(subscription, "site_id", None),
        },
    )


@router.post("/{subscription_id}/edit", dependencies=[Depends(require_read_write_web)])
async def update_webhook(
    request: Request,
    subscription_id: str,
    url: str = Form(...),
    secret: str = Form(...),
    event_types: list[str] = Form(...),
    timeout_seconds: int = Form(30),
    max_retries: int = Form(3),
    is_active: bool = Form(False),
    note: str = Form(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Update a webhook subscription."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    webhook_svc = WebhookService(db, tenant_id)

    data = WebhookSubscriptionUpdate(
        url=url,
        secret=secret,
        event_types=event_types,
        is_active=is_active,
        timeout_seconds=timeout_seconds,
        max_retries=max_retries,
        note=note,
    )

    result = webhook_svc.update(subscription_id, data, updated_by=user_id)
    if not result:
        return RedirectResponse(url="/webhooks", status_code=303)

    return RedirectResponse(
        url=f"/webhooks/{subscription_id}",
        status_code=303,
    )
