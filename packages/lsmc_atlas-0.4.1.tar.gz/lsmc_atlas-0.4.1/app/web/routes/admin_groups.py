"""LSMC Atlas - Admin System Group Management Web Routes.

Provides web UI for managing System Group memberships.
Restricted to users with ADMIN role.
"""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.middleware import csrf_protect
from app.db.engine import get_db
from app.domain.enums import SystemGroup
from app.domain.services.groups import UserGroupService
from app.domain.services.users import UserService
from app.web.flash import flash
from app.web.routes.pages import get_template_context, require_admin
from app.web.templates import templates

router = APIRouter(prefix="/admin/groups", tags=["admin-groups"])


@router.get("", response_class=HTMLResponse)
async def admin_groups_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """List all system groups with member counts."""
    ctx = get_template_context(request, current_user, db)
    service = UserGroupService(db, current_user.tenant_id)

    groups = []
    for sg in SystemGroup:
        info = service.get_group_by_code(sg.value)
        if info:
            groups.append(info)

    ctx["groups"] = groups
    return templates.TemplateResponse("admin/groups.html", ctx)


@router.get("/{group_code}", response_class=HTMLResponse)
async def admin_group_detail(
    request: Request,
    group_code: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show group detail with members."""
    service = UserGroupService(db, current_user.tenant_id)
    info = service.get_group_by_code(group_code)
    if not info:
        raise HTTPException(status_code=404, detail=f"Group '{group_code}' not found")

    memberships = service.list_group_members(info.euid)
    user_svc = UserService(db)

    # Resolve user profiles for memberships
    # user_id in UserGroupMembership is the Cognito sub (stored as UUID)
    cognito_subs = [str(m.user_id) for m in memberships]
    profiles_by_sub = {
        profile.cognito_sub: profile for profile in user_svc.list_by_cognito_subs(cognito_subs)
    }

    members = []
    for m in memberships:
        profile = profiles_by_sub.get(str(m.user_id))
        members.append(
            {
                "membership": m,
                "email": profile.email if profile else str(m.user_id),
                "name": profile.name if profile else None,
                "is_active": m.is_active,
            }
        )

    ctx = get_template_context(request, current_user, db)
    ctx["group"] = info
    ctx["members"] = members
    return templates.TemplateResponse("admin/group_detail.html", ctx)


@router.post(
    "/{group_code}/add-member",
    dependencies=[Depends(csrf_protect)],
)
async def admin_group_add_member(
    request: Request,
    group_code: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
    user_email: str = Form(...),
):
    """Add a user to a system group by email."""
    service = UserGroupService(db, current_user.tenant_id)
    info = service.get_group_by_code(group_code)
    if not info:
        raise HTTPException(status_code=404, detail=f"Group '{group_code}' not found")

    # Look up user by email
    user_svc = UserService(db, current_user.sub_uuid)
    profile = user_svc.get_by_email(user_email.strip())
    if not profile:
        flash(request, f"No user found with email '{user_email.strip()}'", "error")
        return RedirectResponse(
            url=f"/admin/groups/{group_code}", status_code=status.HTTP_303_SEE_OTHER
        )

    service.add_user_to_group(
        user_id=uuid.UUID(profile.cognito_sub),
        group_euid=info.euid,
        added_by=current_user.sub_uuid,
    )
    flash(request, f"Added {profile.email} to {info.name}", "success")
    return RedirectResponse(
        url=f"/admin/groups/{group_code}", status_code=status.HTTP_303_SEE_OTHER
    )


@router.post(
    "/{group_code}/remove-member",
    dependencies=[Depends(csrf_protect)],
)
async def admin_group_remove_member(
    request: Request,
    group_code: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
    user_id: uuid.UUID = Form(...),
):
    """Remove (deactivate) a user's membership in a system group."""
    service = UserGroupService(db, current_user.tenant_id)
    info = service.get_group_by_code(group_code)
    if not info:
        raise HTTPException(status_code=404, detail=f"Group '{group_code}' not found")

    result = service.remove_user_from_group(
        user_id=user_id,
        group_euid=info.euid,
        removed_by=current_user.sub_uuid,
    )
    if result:
        flash(request, f"Removed member from {info.name}", "success")
    else:
        flash(request, "Member not found or already inactive", "warning")

    return RedirectResponse(
        url=f"/admin/groups/{group_code}", status_code=status.HTTP_303_SEE_OTHER
    )
