"""LSMC Atlas - Global Exception Handler.

Catches all unhandled exceptions and returns generic error responses.
Logs full details server-side with a unique trace ID for debugging.
Persists error details to the error_log database table for auditing.
Never exposes internal details (stack traces, DB state, PII) to users.
"""

import logging
import traceback
import uuid
from datetime import UTC, datetime

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

logger = logging.getLogger("lsmc_atlas.errors")

_error_templates = Jinja2Templates(directory="app/web/templates")

# Generic messages — never leak internals
GENERIC_500_MESSAGE = "An unexpected error occurred. Please try again or contact support."
GENERIC_ERROR_HEADING = "An Unexpected Error Occurred"


def _get_username(request: Request) -> str:
    """Extract username from session without exposing PII in logs."""
    try:
        return request.session.get("email", "anonymous")
    except Exception:
        return "anonymous"


def _get_client_ip(request: Request) -> str:
    """Extract client IP address."""
    try:
        if request.client:
            return request.client.host
    except Exception:
        pass
    return "unknown"


def _get_full_path(request: Request) -> str:
    """Get full URL path with query string."""
    full_path = str(request.url.path)
    if request.url.query:
        full_path = f"{full_path}?{request.url.query}"
    return full_path


def _is_api_request(request: Request) -> bool:
    """Determine if the request expects JSON (API) or HTML (browser)."""
    if request.url.path.startswith("/api/"):
        return True
    accept = request.headers.get("accept", "")
    return "application/json" in accept and "text/html" not in accept


def _log_exception(
    trace_id: str,
    request: Request,
    exc: Exception,
    username: str,
    client_ip: str,
    timestamp: str,
) -> None:
    """Log full exception details server-side. Username is logged; no PHI/PII beyond that."""
    full_path = _get_full_path(request)

    logger.error(
        "Unhandled exception | trace_id=%s | timestamp=%s | user=%s | ip=%s | method=%s | path=%s | "
        "exception_type=%s | message=%s",
        trace_id,
        timestamp,
        username,
        client_ip,
        request.method,
        full_path,
        type(exc).__name__,
        str(exc),
    )
    # Use format_exception(exc) directly — more reliable than format_exc()
    # which depends on sys.exc_info() and may be empty outside an except block
    tb_str = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    logger.error("Traceback for trace_id=%s:\n%s", trace_id, tb_str)


def _persist_error_to_db(
    trace_id: str,
    occurred_at: datetime,
    request: Request,
    exc: Exception,
    username: str,
    client_ip: str,
    status_code: int = 500,
) -> None:
    """Persist error details to durable storage.

    The legacy relational `error_log` table is removed in TapDB-only mode.
    Keep this as a no-op until error persistence is fully migrated onto TapDB
    object templates.
    """
    _ = (trace_id, occurred_at, request, exc, username, client_ip, status_code)
    logger.debug("Skipping legacy error_log persistence; trace_id=%s", trace_id)


async def global_exception_handler(request: Request, exc: Exception) -> HTMLResponse | JSONResponse:
    """Handle all unhandled exceptions with a generic response.

    - Generates a unique trace ID for correlation.
    - Logs full details server-side.
    - Returns only generic info to the user (trace ID, timestamp, username).
    """
    trace_id = str(uuid.uuid4())
    timestamp_utc = datetime.now(UTC)
    timestamp_iso = timestamp_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    timestamp_display = timestamp_utc.strftime("%B %d, %Y at %H:%M UTC")
    username = _get_username(request)
    client_ip = _get_client_ip(request)

    _log_exception(trace_id, request, exc, username, client_ip, timestamp_iso)

    # Persist to database (non-blocking — falls back to file logging on failure)
    _persist_error_to_db(trace_id, timestamp_utc, request, exc, username, client_ip)

    # Determine if the user has an active session (for conditional UI)
    is_authenticated = username != "anonymous"

    if _is_api_request(request):
        return JSONResponse(
            status_code=500,
            content={
                "detail": GENERIC_500_MESSAGE,
                "trace_id": trace_id,
                "timestamp": timestamp_iso,
            },
        )

    # HTML response — render the error modal overlay
    try:
        return _error_templates.TemplateResponse(
            "errors/500.html",
            {
                "request": request,
                "trace_id": trace_id,
                "username": username,
                "is_authenticated": is_authenticated,
                "timestamp_display": timestamp_display,
                "timestamp_iso": timestamp_iso,
                "error_heading": GENERIC_ERROR_HEADING,
                "error_message": GENERIC_500_MESSAGE,
            },
            status_code=500,
        )
    except Exception:
        # Fallback if template rendering itself fails
        logger.error("Failed to render 500 template for trace_id=%s", trace_id)
        return HTMLResponse(
            content=(
                f"<html><body><h1>{GENERIC_ERROR_HEADING}</h1>"
                f"<p>{GENERIC_500_MESSAGE}</p>"
                f"<p>Reference: {trace_id}</p></body></html>"
            ),
            status_code=500,
        )
