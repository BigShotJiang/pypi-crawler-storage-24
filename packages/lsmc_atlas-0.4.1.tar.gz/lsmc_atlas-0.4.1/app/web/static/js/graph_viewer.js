/* Atlas graph viewer (read-only) */

(() => {
    const config = window.AtlasGraphConfig || {};

    const graphPath = config.graphPath || "/api/graph/data";
    const graphPagePath = config.graphPagePath || "/graph";
    const objectPathTemplate = config.objectPathTemplate || "/api/graph/object/{euid}";
    const canCrossTenant = !!config.canCrossTenant;

    const TAP_WINDOW_MS = 700;
    const WAVE_STEP_MS = 260;
    const WAVE_GLOW_MS = 520;

    let cy = null;
    const tapTracker = new Map();

    function byId(id) {
        return document.getElementById(id);
    }

    function setStatus(message, level) {
        const el = byId("graph-status");
        if (!el) {
            return;
        }
        el.textContent = message;
        el.className = "graph-status";
        if (level) {
            el.classList.add(level);
        }
    }

    function escapeHtml(value) {
        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#39;");
    }

    function prettyJson(value) {
        const safeValue = value === undefined ? {} : value;
        return JSON.stringify(safeValue === null ? {} : safeValue, null, 2);
    }

    function currentTenant() {
        if (!canCrossTenant) {
            return "";
        }
        const input = byId("graph-tenant-id");
        return input ? (input.value || "").trim() : "";
    }

    function currentDepth() {
        const input = byId("graph-depth");
        const value = Number.parseInt(input ? input.value : "", 10);
        return Number.isFinite(value) ? value : (config.defaultDepth || 4);
    }

    function currentStartEuid() {
        const input = byId("graph-start-euid");
        return input ? (input.value || "").trim() : "";
    }

    function buildGraphRequestUrl() {
        const depth = currentDepth();
        const startEuid = currentStartEuid();

        const params = new URLSearchParams();
        params.set("depth", String(depth));
        if (startEuid) {
            params.set("start_euid", startEuid);
        }
        if (canCrossTenant) {
            const tenantId = currentTenant();
            if (tenantId) {
                params.set("tenant_id", tenantId);
            }
        }

        return `${graphPath}?${params.toString()}`;
    }

    function buildObjectDetailUrl(euid) {
        const encoded = encodeURIComponent(euid);
        const base = objectPathTemplate.replace("{euid}", encoded);
        if (!canCrossTenant) {
            return base;
        }

        const tenantId = currentTenant();
        if (!tenantId) {
            return base;
        }
        return `${base}?tenant_id=${encodeURIComponent(tenantId)}`;
    }

    function updateHistoryState() {
        const params = new URLSearchParams();
        const depth = currentDepth();
        const startEuid = currentStartEuid();

        params.set("depth", String(depth));
        if (startEuid) {
            params.set("start_euid", startEuid);
        }
        if (canCrossTenant) {
            const tenantId = currentTenant();
            if (tenantId) {
                params.set("tenant_id", tenantId);
            }
        }
        window.history.replaceState({}, "", `${graphPagePath}?${params.toString()}`);
    }

    function updateLegend(nodes) {
        const legend = byId("graph-legend");
        if (!legend) {
            return;
        }

        const map = new Map();
        (nodes || []).forEach((node) => {
            const data = node.data || {};
            if (!data.category || !data.color || map.has(data.category)) {
                return;
            }
            map.set(data.category, data.color);
        });

        if (map.size === 0) {
            legend.innerHTML = "<span class=\"text-muted\">No nodes loaded.</span>";
            return;
        }

        const items = Array.from(map.entries())
            .sort((left, right) => left[0].localeCompare(right[0]))
            .map(
                ([category, color]) =>
                    `<span class=\"legend-item\"><span class=\"legend-swatch\" ` +
                    `style=\"background:${escapeHtml(color)}\"></span>${escapeHtml(category)}</span>`
            )
            .join("");

        legend.innerHTML = items;
    }

    function topLevelValue(key, value) {
        if (value === null || value === undefined || value === "") {
            return '<span class="text-muted">-</span>';
        }
        if (key === "json_addl") {
            return '<span class="text-muted">Rendered below</span>';
        }
        if (typeof value === "object") {
            return `<code>${escapeHtml(JSON.stringify(value))}</code>`;
        }
        return escapeHtml(String(value));
    }

    function renderDetailPanel(objectData, graphData) {
        const detail = byId("graph-detail-content");
        if (!detail) {
            return;
        }

        const merged = { ...(objectData || {}) };
        if (!Object.prototype.hasOwnProperty.call(merged, "euid") && graphData && graphData.id) {
            merged.euid = graphData.id;
        }

        const preferredKeys = [
            "record_type",
            "uuid",
            "euid",
            "name",
            "category",
            "type",
            "subtype",
            "version",
            "bstatus",
            "source",
            "target",
            "relationship_type",
            "created_dt",
            "modified_dt",
        ];

        const orderedKeys = preferredKeys.filter((key) => Object.hasOwn(merged, key));
        Object.keys(merged)
            .filter((key) => !orderedKeys.includes(key) && key !== "json_addl")
            .sort()
            .forEach((key) => orderedKeys.push(key));

        const rows = orderedKeys
            .map(
                (key) =>
                    `<div class=\"detail-key\">${escapeHtml(key)}</div>` +
                    `<div class=\"detail-value\">${topLevelValue(key, merged[key])}</div>`
            )
            .join("");

        const jsonAddl = Object.hasOwn(merged, "json_addl") ? merged.json_addl : {};

        detail.innerHTML =
            `<div class=\"detail-grid\">${rows || '<span class="text-muted">No details.</span>'}</div>` +
            `<div class=\"detail-key\">json_addl</div>` +
            `<pre class=\"json-block\">${escapeHtml(prettyJson(jsonAddl))}</pre>`;
    }

    async function fetchObjectDetail(euid) {
        const response = await fetch(buildObjectDetailUrl(euid), {
            headers: { Accept: "application/json" },
        });

        if (!response.ok) {
            let payload = {};
            try {
                payload = await response.json();
            } catch (_error) {
                payload = {};
            }
            throw new Error(payload.detail || `Failed to load details (${response.status})`);
        }

        return response.json();
    }

    async function showElementDetail(graphData) {
        const detail = byId("graph-detail-content");
        if (detail) {
            detail.innerHTML = "<span class=\"text-muted\">Loading details...</span>";
        }

        try {
            const objectData = await fetchObjectDetail(graphData.id);
            renderDetailPanel(objectData, graphData);
        } catch (error) {
            renderDetailPanel(graphData, graphData);
            setStatus(`Detail lookup failed: ${error.message}`, "warn");
        }
    }

    function registerTapSequence(nodeId, button) {
        const key = `${nodeId}|${button}`;
        const now = Date.now();
        const previous = tapTracker.get(key);

        let count = 1;
        if (previous && now - previous.lastTs <= TAP_WINDOW_MS) {
            count = previous.count + 1;
        }

        tapTracker.set(key, { count, lastTs: now });
        if (count >= 3) {
            tapTracker.set(key, { count: 0, lastTs: now });
            return true;
        }
        return false;
    }

    function collectWaveLevels(startNode, direction) {
        const levels = [];
        const seen = new Set([startNode.id()]);
        let frontier = cy.collection(startNode);

        while (frontier.length > 0) {
            let next = cy.collection();
            frontier.forEach((node) => {
                const neighbors =
                    direction === "children"
                        ? node.incomers("edge").sources()
                        : node.outgoers("edge").targets();

                neighbors.forEach((neighbor) => {
                    const nid = neighbor.id();
                    if (seen.has(nid)) {
                        return;
                    }
                    seen.add(nid);
                    next = next.add(neighbor);
                });
            });

            if (next.length === 0) {
                break;
            }

            levels.push(next);
            frontier = next;
        }

        return levels;
    }

    function runWave(startNode, direction) {
        if (!cy || !startNode) {
            return;
        }

        const levels = collectWaveLevels(startNode, direction);
        if (levels.length === 0) {
            setStatus(`No ${direction} found for ${startNode.id()}.`, "warn");
            return;
        }

        const className = direction === "children" ? "wave-child" : "wave-parent";
        setStatus(`Running ${direction} wave from ${startNode.id()}...`, "ok");

        levels.forEach((group, index) => {
            window.setTimeout(() => {
                group.addClass(className);
                window.setTimeout(() => group.removeClass(className), WAVE_GLOW_MS);
            }, index * WAVE_STEP_MS);
        });
    }

    function styleConfig() {
        return [
            {
                selector: "node",
                style: {
                    "background-color": "data(color)",
                    label: "data(id)",
                    color: "#f9fbff",
                    "font-size": "10px",
                    "font-weight": "700",
                    "text-wrap": "wrap",
                    "text-max-width": "120px",
                    "text-valign": "bottom",
                    "text-margin-y": "5px",
                    width: "38px",
                    height: "38px",
                    "border-width": "2px",
                    "border-color": "#20242f",
                    "text-outline-color": "#05070c",
                    "text-outline-width": "2px",
                    "shadow-color": "#000",
                    "shadow-opacity": 0.22,
                    "shadow-blur": 5,
                },
            },
            {
                selector: "node:selected",
                style: {
                    "border-width": "4px",
                    "border-color": "#ffffff",
                    "background-color": "#e64a6f",
                },
            },
            {
                selector: "node.wave-child",
                style: {
                    "background-color": "#ff62b2",
                    "border-color": "#ffd8eb",
                    "border-width": "5px",
                    "shadow-color": "#ff62b2",
                    "shadow-opacity": 0.9,
                    "shadow-blur": 26,
                },
            },
            {
                selector: "node.wave-parent",
                style: {
                    "background-color": "#2edbff",
                    "border-color": "#d1f7ff",
                    "border-width": "5px",
                    "shadow-color": "#2edbff",
                    "shadow-opacity": 0.9,
                    "shadow-blur": 26,
                },
            },
            {
                selector: "edge",
                style: {
                    width: 2,
                    "line-color": "#6f7a92",
                    "curve-style": "bezier",
                    "target-arrow-shape": "triangle",
                    "target-arrow-color": "#6f7a92",
                    "target-arrow-fill": "filled",
                    "arrow-scale": 1.4,
                    "target-distance-from-node": 6,
                },
            },
            {
                selector: "edge:selected",
                style: {
                    width: 3,
                    "line-color": "#ffc46f",
                    "target-arrow-color": "#ffc46f",
                },
            },
        ];
    }

    function selectedLayoutName() {
        const select = byId("graph-layout");
        return select ? select.value : "dagre";
    }

    function applyLayout() {
        if (!cy) {
            return;
        }

        const name = selectedLayoutName();
        const options = {
            dagre: { name: "dagre", rankDir: "BT", nodeSep: 45, rankSep: 80 },
            cose: { name: "cose", animate: true, animationDuration: 500 },
            breadthfirst: { name: "breadthfirst", directed: true, spacingFactor: 1.5 },
            circle: { name: "circle" },
            grid: { name: "grid" },
        };

        cy.layout(options[name] || { name }).run();
    }

    function renderNoData(message) {
        const container = byId("graph-canvas");
        if (!container) {
            return;
        }

        container.innerHTML = `<div class=\"graph-loading\">${escapeHtml(message)}</div>`;
        updateLegend([]);
    }

    function initGraph(elements) {
        const container = byId("graph-canvas");
        if (!container) {
            return;
        }

        container.innerHTML = "";
        if (cy) {
            cy.destroy();
            cy = null;
        }

        cy = window.cytoscape({
            container,
            elements,
            style: styleConfig(),
            layout: { name: "dagre", rankDir: "BT", nodeSep: 45, rankSep: 80 },
            minZoom: 0.1,
            maxZoom: 3,
            wheelSensitivity: 0.28,
        });

        cy.on("tap", "node", async (event) => {
            const node = event.target;
            await showElementDetail(node.data());
            if (registerTapSequence(node.id(), "left")) {
                runWave(node, "children");
            }
        });

        cy.on("cxttap", "node", async (event) => {
            const node = event.target;
            await showElementDetail(node.data());
            if (registerTapSequence(node.id(), "right")) {
                runWave(node, "parents");
            }
        });

        cy.on("tap", "edge", async (event) => {
            await showElementDetail(event.target.data());
        });

        cy.on("cxttap", "edge", async (event) => {
            await showElementDetail(event.target.data());
        });

        applyLayout();
    }

    async function loadGraph() {
        renderNoData("Loading graph data...");

        try {
            const response = await fetch(buildGraphRequestUrl(), {
                headers: { Accept: "application/json" },
                credentials: "same-origin",
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.detail || `Failed to load graph data (${response.status})`);
            }

            const elements = data.elements || { nodes: [], edges: [] };
            const nodes = Array.isArray(elements.nodes) ? elements.nodes : [];
            const edges = Array.isArray(elements.edges) ? elements.edges : [];

            if (nodes.length === 0) {
                renderNoData("No visible graph data for this scope.");
                setStatus("No graph data found.", "warn");
                updateHistoryState();
                return;
            }

            initGraph({ nodes, edges });
            updateLegend(nodes);
            updateHistoryState();

            const meta = data.meta || {};
            if (meta.truncated) {
                setStatus(
                    `Loaded ${meta.node_count || nodes.length} nodes and ` +
                        `${meta.edge_count || edges.length} edges (truncated).`,
                    "warn"
                );
            } else {
                setStatus(
                    `Loaded ${meta.node_count || nodes.length} nodes and ` +
                        `${meta.edge_count || edges.length} edges.`,
                    "ok"
                );
            }
        } catch (error) {
            renderNoData(`Error: ${error.message}`);
            setStatus(`Load failed: ${error.message}`, "error");
        }
    }

    function fitView() {
        if (!cy) {
            return;
        }
        cy.fit(undefined, 40);
        setStatus("Fit view applied.", "ok");
    }

    function installHandlers() {
        const loadBtn = byId("graph-load");
        const fitBtn = byId("graph-fit");
        const layout = byId("graph-layout");
        const startInput = byId("graph-start-euid");
        const depthInput = byId("graph-depth");
        const tenantInput = byId("graph-tenant-id");

        if (loadBtn) {
            loadBtn.addEventListener("click", () => {
                void loadGraph();
            });
        }
        if (fitBtn) {
            fitBtn.addEventListener("click", fitView);
        }
        if (layout) {
            layout.addEventListener("change", applyLayout);
        }

        [startInput, depthInput, tenantInput].forEach((input) => {
            if (!input) {
                return;
            }
            input.addEventListener("keydown", (event) => {
                if (event.key !== "Enter") {
                    return;
                }
                event.preventDefault();
                void loadGraph();
            });
        });
    }

    function bootstrapDefaults() {
        const startInput = byId("graph-start-euid");
        const depthInput = byId("graph-depth");
        const tenantInput = byId("graph-tenant-id");

        if (startInput && config.defaultStartEuid && !startInput.value) {
            startInput.value = config.defaultStartEuid;
        }
        if (depthInput && config.defaultDepth && !depthInput.value) {
            depthInput.value = String(config.defaultDepth);
        }
        if (tenantInput && config.defaultTenantId && !tenantInput.value) {
            tenantInput.value = config.defaultTenantId;
        }
    }

    document.addEventListener("DOMContentLoaded", () => {
        if (!window.cytoscape) {
            setStatus("Cytoscape failed to load.", "error");
            return;
        }

        if (window.cytoscapeDagre && typeof window.cytoscape.use === "function") {
            window.cytoscape.use(window.cytoscapeDagre);
        }

        bootstrapDefaults();
        installHandlers();
        void loadGraph();
    });
})();
