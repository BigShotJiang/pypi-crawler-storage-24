"""TapDB passthrough commands for LSMC Atlas CLI."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

import os
from pathlib import Path

import typer
from rich.console import Console

from app.integrations.tapdb_runtime import (
    DEFAULT_AWS_PROFILE,
    DEFAULT_AWS_REGION,
    DEFAULT_TAPDB_DATABASE_NAME,
    TapDBRuntimeError,
    run_tapdb_cli,
)

tapdb_app = typer.Typer(help="TapDB lifecycle wrappers")
bootstrap_app = typer.Typer(help="TapDB bootstrap wrappers")
tapdb_app.add_typer(bootstrap_app, name="bootstrap")
console = Console()

PROJECT_ROOT = Path(__file__).parent.parent.parent


def _resolve_runtime_defaults(
    *,
    profile: str,
    region: str,
    namespace: str,
) -> tuple[str, str, str]:
    resolved_profile = profile.strip() or os.environ.get("AWS_PROFILE", DEFAULT_AWS_PROFILE)
    resolved_region = region.strip() or os.environ.get("AWS_REGION", DEFAULT_AWS_REGION)
    resolved_namespace = namespace.strip() or os.environ.get(
        "TAPDB_DATABASE_NAME", DEFAULT_TAPDB_DATABASE_NAME
    )
    return resolved_profile, resolved_region, resolved_namespace


def _run_wrapper(
    *,
    args: list[str],
    target: str,
    profile: str,
    region: str,
    namespace: str,
    tapdb_env: str | None = None,
) -> None:
    resolved_profile, resolved_region, resolved_namespace = _resolve_runtime_defaults(
        profile=profile,
        region=region,
        namespace=namespace,
    )
    try:
        result = run_tapdb_cli(
            args=args,
            target=target,
            profile=resolved_profile,
            region=resolved_region,
            namespace=resolved_namespace,
            tapdb_env=tapdb_env,
            cwd=PROJECT_ROOT,
        )
    except TapDBRuntimeError as exc:
        console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(1) from exc

    if result.stdout:
        console.print(result.stdout.rstrip())
    if result.stderr:
        console.print(result.stderr.rstrip(), style="yellow")


@bootstrap_app.command("local")
def bootstrap_local(
    no_gui: bool = typer.Option(True, "--no-gui/--gui", help="Skip or run TapDB UI startup"),
    profile: str = typer.Option(DEFAULT_AWS_PROFILE, "--profile", help="AWS profile"),
    region: str = typer.Option(DEFAULT_AWS_REGION, "--region", help="AWS region"),
    namespace: str = typer.Option(
        DEFAULT_TAPDB_DATABASE_NAME, "--namespace", help="TapDB database namespace"
    ),
):
    """Run tapdb bootstrap local."""
    args = ["bootstrap", "local"]
    if no_gui:
        args.append("--no-gui")
    _run_wrapper(
        args=args,
        target="local",
        profile=profile,
        region=region,
        namespace=namespace,
    )


@bootstrap_app.command("aurora")
def bootstrap_aurora(
    cluster: str = typer.Option(..., "--cluster", help="Aurora cluster identifier"),
    no_gui: bool = typer.Option(True, "--no-gui/--gui", help="Skip or run TapDB UI startup"),
    profile: str = typer.Option(DEFAULT_AWS_PROFILE, "--profile", help="AWS profile"),
    region: str = typer.Option(DEFAULT_AWS_REGION, "--region", help="AWS region"),
    namespace: str = typer.Option(
        DEFAULT_TAPDB_DATABASE_NAME, "--namespace", help="TapDB database namespace"
    ),
):
    """Run tapdb bootstrap aurora."""
    args = ["bootstrap", "aurora", "--cluster", cluster, "--region", region]
    if no_gui:
        args.append("--no-gui")
    _run_wrapper(
        args=args,
        target="aurora",
        profile=profile,
        region=region,
        namespace=namespace,
    )


@tapdb_app.command(
    "db",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def db_passthrough(
    ctx: typer.Context,
    target: str = typer.Option("local", "--target", help="Atlas DB target: local or aurora"),
    tapdb_env: str = typer.Option("", "--tapdb-env", help="Override TAPDB_ENV"),
    profile: str = typer.Option(DEFAULT_AWS_PROFILE, "--profile", help="AWS profile"),
    region: str = typer.Option(DEFAULT_AWS_REGION, "--region", help="AWS region"),
    namespace: str = typer.Option(
        DEFAULT_TAPDB_DATABASE_NAME, "--namespace", help="TapDB database namespace"
    ),
):
    """Pass through to `tapdb db ...`."""
    if not ctx.args:
        console.print("[red]✗[/red] Missing subcommand. Example: atlas tapdb db schema status dev")
        raise typer.Exit(1)
    _run_wrapper(
        args=["db", *ctx.args],
        target=target,
        profile=profile,
        region=region,
        namespace=namespace,
        tapdb_env=tapdb_env or None,
    )


@tapdb_app.command(
    "pg",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def pg_passthrough(
    ctx: typer.Context,
    target: str = typer.Option("local", "--target", help="Atlas DB target: local or aurora"),
    tapdb_env: str = typer.Option("", "--tapdb-env", help="Override TAPDB_ENV"),
    profile: str = typer.Option(DEFAULT_AWS_PROFILE, "--profile", help="AWS profile"),
    region: str = typer.Option(DEFAULT_AWS_REGION, "--region", help="AWS region"),
    namespace: str = typer.Option(
        DEFAULT_TAPDB_DATABASE_NAME, "--namespace", help="TapDB database namespace"
    ),
):
    """Pass through to `tapdb pg ...`."""
    if not ctx.args:
        console.print("[red]✗[/red] Missing subcommand. Example: atlas tapdb pg status")
        raise typer.Exit(1)
    _run_wrapper(
        args=["pg", *ctx.args],
        target=target,
        profile=profile,
        region=region,
        namespace=namespace,
        tapdb_env=tapdb_env or None,
    )


@tapdb_app.command(
    "aurora",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def aurora_passthrough(
    ctx: typer.Context,
    tapdb_env: str = typer.Option("", "--tapdb-env", help="Override TAPDB_ENV"),
    profile: str = typer.Option(DEFAULT_AWS_PROFILE, "--profile", help="AWS profile"),
    region: str = typer.Option(DEFAULT_AWS_REGION, "--region", help="AWS region"),
    namespace: str = typer.Option(
        DEFAULT_TAPDB_DATABASE_NAME, "--namespace", help="TapDB database namespace"
    ),
):
    """Pass through to `tapdb aurora ...`."""
    if not ctx.args:
        console.print("[red]✗[/red] Missing subcommand. Example: atlas tapdb aurora status prod")
        raise typer.Exit(1)
    _run_wrapper(
        args=["aurora", *ctx.args],
        target="aurora",
        profile=profile,
        region=region,
        namespace=namespace,
        tapdb_env=tapdb_env or None,
    )


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register the tapdb command group."""
    registry.add_typer_app(None, tapdb_app, "tapdb", "TapDB lifecycle wrappers")
