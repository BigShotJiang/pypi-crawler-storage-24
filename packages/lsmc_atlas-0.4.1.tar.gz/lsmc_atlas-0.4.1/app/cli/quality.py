"""Code quality commands for LSMC Atlas CLI."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console

quality_app = typer.Typer(help="Code quality commands (lint, format, typecheck)")
console = Console()

# Get project root
PROJECT_ROOT = Path(__file__).parent.parent.parent

# Directories to check
CHECK_DIRS = ["app/", "tests/", "scripts/"]


@quality_app.command("lint")
def lint(
    fix: bool = typer.Option(False, "--fix", "-f", help="Auto-fix issues"),
):
    """Run ruff linter."""
    console.print("[cyan]Running linter...[/cyan]")

    cmd = [sys.executable, "-m", "ruff", "check"] + CHECK_DIRS

    if fix:
        cmd.append("--fix")

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    raise typer.Exit(result.returncode)


@quality_app.command("format")
def format_code(
    check: bool = typer.Option(False, "--check", "-c", help="Check only, don't modify"),
):
    """Format code with ruff."""
    console.print(f"[cyan]{'Checking' if check else 'Formatting'} code...[/cyan]")

    cmd = [sys.executable, "-m", "ruff", "format"] + CHECK_DIRS

    if check:
        cmd.append("--check")

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)

    if not check and result.returncode == 0:
        # Also run ruff check --fix for import sorting
        console.print("[cyan]Fixing import order...[/cyan]")
        fix_cmd = [sys.executable, "-m", "ruff", "check", "--fix"] + CHECK_DIRS
        subprocess.run(fix_cmd, cwd=PROJECT_ROOT, capture_output=True)

    raise typer.Exit(result.returncode)


@quality_app.command("typecheck")
def typecheck():
    """Run mypy type checker."""
    console.print("[cyan]Running type checker...[/cyan]")

    cmd = [sys.executable, "-m", "mypy", "app/"]

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    raise typer.Exit(result.returncode)


@quality_app.command("check")
def check_all():
    """Run all quality checks (lint + typecheck + tests)."""
    checks = [
        ("Lint", [sys.executable, "-m", "ruff", "check"] + CHECK_DIRS),
        ("Format", [sys.executable, "-m", "ruff", "format", "--check"] + CHECK_DIRS),
        (
            "Tests",
            [
                sys.executable,
                "-m",
                "pytest",
                "tests/",
                "-v",
                "--tb=short",
                "-m",
                "not db and not postgres",
            ],
        ),
    ]

    failed = []

    for name, cmd in checks:
        console.print(f"\n[cyan]Running {name}...[/cyan]")
        result = subprocess.run(cmd, cwd=PROJECT_ROOT)
        if result.returncode != 0:
            failed.append(name)
            console.print(f"[red]✗[/red]  {name} failed")
        else:
            console.print(f"[green]✓[/green]  {name} passed")

    if failed:
        console.print(f"\n[red]✗[/red]  {len(failed)} check(s) failed: {', '.join(failed)}")
        raise typer.Exit(1)
    else:
        console.print("\n[green]✓[/green]  All checks passed")


@quality_app.command("templates")
def templates(
    fix: bool = typer.Option(False, "--fix", "-f", help="Auto-fix issues"),
):
    """Lint Jinja2 templates with djlint."""
    console.print("[cyan]Linting templates...[/cyan]")

    templates_dir = PROJECT_ROOT / "app" / "web" / "templates"
    cmd = [sys.executable, "-m", "djlint", str(templates_dir), "--profile=jinja"]

    if fix:
        cmd.append("--reformat")

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    raise typer.Exit(result.returncode)


# ── Plugin registration ──────────────────────────────────────────────────────


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register the quality command group."""
    registry.add_typer_app(None, quality_app, "quality", "Code quality (lint, format, typecheck)")
