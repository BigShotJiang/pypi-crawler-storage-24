"""Cognito management commands for LSMC Atlas.

Operational Cognito lifecycle is delegated to the daylily-cognito CLI (`daycog`).
Atlas stores only `authentication.cognito.user_pool_id` in its config; runtime
Cognito details are resolved from daycog per-pool env files.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import urlparse

import typer
from rich.console import Console

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

from app.auth.cognito_uri_validation import (
    ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
    CognitoClientNameValidationResult,
    CognitoURIValidationResult,
    validate_cognito_app_client_name,
    validate_cognito_uri_ports,
)
from app.settings import get_config_file_path, settings

cognito_app = typer.Typer(help="Cognito auth integration commands (via daycog)")
console = Console()
PROJECT_ROOT = Path(__file__).parent.parent.parent
_DAYCOG_SETUP_OPTIONS: set[str] | None = None
_DAYCOG_COMMAND_OPTIONS: dict[str, set[str]] = {}
_DAYCOG_ENV_FILENAME_PATTERN = re.compile(
    r"^(?P<pool>.+)\.(?P<region>[a-z]{2}(?:-[a-z0-9]+)+-\d+)(?:\.(?P<app>.+))?\.env$"
)


def _log_env(source: str, **vars: str) -> None:
    """Log env values to .tmpenv.log with basic secret/key redaction."""
    sensitive_tokens = ("SECRET", "KEY")
    log_file = PROJECT_ROOT / ".tmpenv.log"
    timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")

    with open(log_file, "a", encoding="utf-8") as f:
        f.write("\n# ============================================\n")
        f.write(f"# Source: {source}\n")
        f.write(f"# Logged: {timestamp}\n")
        f.write("# ============================================\n")
        for key, value in vars.items():
            masked = (
                "***REDACTED***"
                if any(token in key.upper() for token in sensitive_tokens)
                else value
            )
            f.write(f"{key}={masked}\n")


def _read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values

    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        if key:
            values[key] = value

    return values


def _daycog_config_dir() -> Path:
    return Path.home() / ".config" / "daycog"


def _iter_daycog_env_files() -> list[Path]:
    cfg_dir = _daycog_config_dir()
    if not cfg_dir.exists():
        return []

    files = sorted(cfg_dir.glob("*.env"))
    return sorted(
        files,
        key=lambda p: (_daycog_env_file_priority(p), p.name.lower()),
    )


def _daycog_env_file_priority(path: Path) -> int:
    """Sort daycog env files by specificity.

    Priority:
    0. <pool>.<region>.env
    1. <pool>.<region>.<app>.env
    2. legacy <pool>.env
    3. default.env
    """
    if path.name == "default.env":
        return 3

    pool_name, region, app_name = _parse_daycog_env_filename(path)
    if pool_name and region and not app_name:
        return 0
    if pool_name and region and app_name:
        return 1
    return 2


def _parse_daycog_env_filename(path: Path) -> tuple[str, str, str]:
    """Extract pool/region/app context from daycog env filenames.

    Returns empty strings for unknown fields.
    """
    if path.name == "default.env":
        return "", "", ""

    match = _DAYCOG_ENV_FILENAME_PATTERN.match(path.name)
    if match:
        return (
            (match.group("pool") or "").strip(),
            (match.group("region") or "").strip(),
            (match.group("app") or "").strip(),
        )

    # Legacy fallback (<pool>.env)
    if path.suffix == ".env":
        return path.stem.strip(), "", ""

    return "", "", ""


def _infer_region_from_pool_id(pool_id: str) -> str:
    if "_" not in pool_id:
        return ""
    return pool_id.split("_", 1)[0].strip()


def _find_pool_env_file_by_id(pool_id: str) -> tuple[Path, dict[str, str]]:
    target = (pool_id or "").strip()
    if not target:
        raise RuntimeError("Empty Cognito pool ID")

    for env_file in _iter_daycog_env_files():
        values = _read_env_file(env_file)
        if (values.get("COGNITO_USER_POOL_ID") or "").strip() == target:
            return env_file, values

    raise RuntimeError(
        f"No daycog env file maps to pool ID {target}. "
        f"Expected a file in {_daycog_config_dir()} with COGNITO_USER_POOL_ID={target}."
    )


def _find_pool_env_file_by_name_region(pool_name: str, region: str) -> tuple[Path, dict[str, str]]:
    selected_pool = (pool_name or "").strip()
    selected_region = (region or "").strip()
    for env_file in _iter_daycog_env_files():
        candidate_pool, candidate_region, candidate_app = _parse_daycog_env_filename(env_file)
        if (
            candidate_pool == selected_pool
            and candidate_region == selected_region
            and not candidate_app
        ):
            return env_file, _read_env_file(env_file)

    # Compatibility fallback for legacy (<pool>.env)
    legacy_path = _daycog_config_dir() / f"{selected_pool}.env"
    if legacy_path.exists():
        return legacy_path, _read_env_file(legacy_path)

    raise RuntimeError(
        f"No daycog pool env found for {selected_pool} ({selected_region}). "
        f"Expected {_daycog_config_dir()}/{selected_pool}.{selected_region}.env."
    )


def _resolve_bound_pool_context(pool_id: str) -> tuple[str, str, Path, dict[str, str]]:
    env_file, values = _find_pool_env_file_by_id(pool_id)
    pool_name, region, _app_name = _parse_daycog_env_filename(env_file)
    resolved_region = (
        (region or "").strip()
        or (values.get("COGNITO_REGION") or "").strip()
        or (values.get("AWS_REGION") or "").strip()
        or _infer_region_from_pool_id(pool_id)
    )
    return pool_name.strip(), resolved_region, env_file, values


def _resolve_profile(
    *,
    explicit_profile: str | None = None,
    daycog_values: dict[str, str] | None = None,
) -> str:
    from_daycog = (daycog_values or {}).get("AWS_PROFILE", "")
    return (
        explicit_profile or from_daycog or os.environ.get("AWS_PROFILE") or settings.aws_profile
    ).strip()


def _build_daycog_proc_env(
    daycog_values: dict[str, str] | None = None,
    *,
    profile: str | None = None,
    region: str | None = None,
) -> dict[str, str]:
    proc_env = os.environ.copy()
    if daycog_values:
        proc_env.update(daycog_values)
    selected_profile = (profile or "").strip()
    selected_region = (region or "").strip()
    if selected_profile:
        proc_env["AWS_PROFILE"] = selected_profile
    if selected_region:
        proc_env["AWS_REGION"] = selected_region
        proc_env["COGNITO_REGION"] = selected_region
    return proc_env


def _safe_pool_name(raw: str) -> str:
    sanitized = re.sub(r"[^a-zA-Z0-9-]+", "-", raw).strip("-").lower()
    return re.sub(r"-{2,}", "-", sanitized)


def _run_daycog(args: list[str], env: dict[str, str] | None = None) -> str:
    cmd = ["daycog", *args]
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env,
    )
    if result.returncode != 0:
        output = (result.stdout + "\n" + result.stderr).strip()
        raise RuntimeError(output or f"daycog failed ({result.returncode})")
    return (result.stdout or "").strip()


def _get_daycog_setup_options() -> set[str]:
    """Return supported `daycog setup` long options (e.g. --callback-url)."""
    global _DAYCOG_SETUP_OPTIONS
    if _DAYCOG_SETUP_OPTIONS is None:
        _DAYCOG_SETUP_OPTIONS = _get_daycog_command_options("setup")
    return _DAYCOG_SETUP_OPTIONS


def _get_daycog_command_options(command: str) -> set[str]:
    """Return supported long options for a daycog command."""
    cached = _DAYCOG_COMMAND_OPTIONS.get(command)
    if cached is not None:
        return cached

    help_env = os.environ.copy()
    # Prevent rich help truncation so option names can be parsed reliably.
    help_env["COLUMNS"] = "240"
    result = subprocess.run(
        ["daycog", command, "--help"],
        capture_output=True,
        text=True,
        env=help_env,
    )
    if result.returncode != 0:
        output = (result.stdout + "\n" + result.stderr).strip()
        raise RuntimeError(output or f"daycog {command} --help failed ({result.returncode})")

    output = f"{result.stdout}\n{result.stderr}"
    options = set(re.findall(r"--[a-z0-9][a-z0-9-]*", output))
    _DAYCOG_COMMAND_OPTIONS[command] = options
    return options


def _ensure_supported_or_raise(
    supported: set[str],
    option: str,
    enabled: bool,
    feature_name: str,
) -> None:
    """Fail with an actionable message when a requested feature is unavailable."""
    if enabled and option not in supported:
        raise RuntimeError(
            f"Installed daycog does not support {feature_name} ({option}). "
            "Upgrade daylily-cognito/daycog to >=0.1.24."
        )


def _load_atlas_config() -> dict:
    config_path = get_config_file_path()
    if not config_path.exists():
        return {}

    raw = config_path.read_text(encoding="utf-8")
    try:
        import yaml  # type: ignore

        return yaml.safe_load(raw) or {}
    except ModuleNotFoundError:
        return json.loads(raw) if raw.strip() else {}


def _save_atlas_config(config: dict) -> Path:
    config_path = get_config_file_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import yaml  # type: ignore

        config_path.write_text(
            yaml.dump(config, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )
    except ModuleNotFoundError:
        config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")

    return config_path


def _write_pool_id_to_atlas_config(pool_id: str) -> Path:
    config = _load_atlas_config()

    auth = config.setdefault("authentication", {})
    auth["mode"] = "cognito"
    cognito_cfg = auth.setdefault("cognito", {})
    cognito_cfg["user_pool_id"] = pool_id

    # Keep Atlas config pool-centric; resolve runtime values from daycog.
    for key in (
        "region",
        "app_client_id",
        "app_client_secret",
        "client_name",
        "domain",
        "redirect_uri",
        "callback_url",
        "logout_url",
    ):
        cognito_cfg.pop(key, None)

    return _save_atlas_config(config)


def _get_configured_pool_id() -> str:
    config = _load_atlas_config()
    auth = config.get("authentication") or {}
    cognito_cfg = auth.get("cognito") or {}
    pool_id = (cognito_cfg.get("user_pool_id") or "").strip()
    if pool_id:
        return pool_id

    # Fallback for environments where settings env var overrides are in use.
    return (os.environ.get("COGNITO_USER_POOL_ID") or settings.cognito_user_pool_id or "").strip()


def _resolve_selected_pool_name_region(
    *,
    pool_name: str | None = None,
    region: str | None = None,
    profile: str | None = None,
    pool_id: str | None = None,
) -> tuple[str, str, str, Path, dict[str, str]]:
    """Resolve pool context for daycog commands requiring --pool-name and --region."""
    explicit_pool_name = (_safe_pool_name(pool_name) if pool_name else "").strip()
    selected_pool_id = (pool_id or "").strip() or _get_configured_pool_id()
    bound_pool_name = ""
    bound_region = ""
    env_file = _daycog_config_dir() / "default.env"
    values: dict[str, str] = {}

    if selected_pool_id:
        bound_pool_name, bound_region, env_file, values = _resolve_bound_pool_context(
            selected_pool_id
        )
    elif not explicit_pool_name:
        raise RuntimeError("No Cognito pool configured in Atlas; run `atlas cognito build` first.")

    selected_pool_name = (explicit_pool_name or bound_pool_name).strip()
    selected_region = (
        (region or "").strip()
        or bound_region
        or (values.get("COGNITO_REGION") or "").strip()
        or (values.get("AWS_REGION") or "").strip()
        or _infer_region_from_pool_id(selected_pool_id)
        or (os.environ.get("AWS_REGION") or "").strip()
        or (settings.aws_region or "").strip()
    )
    if not selected_pool_name:
        raise RuntimeError(
            "Unable to determine Cognito pool name from daycog context. "
            "Pass --pool-name explicitly."
        )
    if not selected_region:
        raise RuntimeError(
            "Unable to determine Cognito region from daycog context. Pass --region explicitly."
        )

    selected_profile = _resolve_profile(explicit_profile=profile, daycog_values=values)
    return selected_pool_name, selected_region, selected_profile, env_file, values


def _resolve_expected_atlas_port(explicit_port: int | None) -> int:
    if explicit_port is not None:
        return explicit_port

    env_port = (os.environ.get("ATLAS_PORT") or "").strip()
    if env_port.isdigit():
        return int(env_port)

    parsed = urlparse(settings.cognito_redirect_uri)
    if parsed.hostname in {"localhost", "127.0.0.1", "0.0.0.0"} and parsed.port:
        return parsed.port

    return 8915


def _resolve_requested_client_name(raw_client_name: object) -> str:
    if isinstance(raw_client_name, str):
        selected = raw_client_name
    else:
        # Typer's OptionInfo appears here when command functions are called directly in tests.
        selected = ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME

    trimmed = selected.strip()
    if not trimmed:
        raise typer.BadParameter("client_name cannot be empty")
    return trimmed


def _print_uri_validation_result(result: CognitoURIValidationResult) -> None:
    console.print("")
    console.print(
        f"[bold]URI Validation[/bold] (local URI expected port: [cyan]{result.expected_port}[/cyan])"
    )

    if result.records:
        for record in result.records:
            console.print(f"[dim]- {record.source}: {record.uri}[/dim]")
    else:
        console.print("[yellow]⚠[/yellow] No callback/logout/redirect URIs found to validate.")

    for warning in result.warnings:
        console.print(f"[yellow]⚠[/yellow] {warning}")

    if result.ok:
        console.print("[green]✓[/green] URI validation passed")
        return

    console.print("[red]✗[/red] URI validation failed")
    for issue in result.issues:
        console.print(f"  [red]-[/red] {issue.source}: {issue.message} ({issue.uri})")


def _print_client_name_validation_result(result: CognitoClientNameValidationResult) -> None:
    console.print("")
    console.print(
        "[bold]App Client Name Validation[/bold] "
        f"(expected: [cyan]{result.expected_client_name}[/cyan])"
    )
    if result.records:
        for record in result.records:
            shown = record.client_name if record.client_name else "(missing)"
            console.print(f"[dim]- {record.source}: {shown}[/dim]")
    else:
        console.print("[yellow]⚠[/yellow] No app client names found to validate.")

    for warning in result.warnings:
        console.print(f"[yellow]⚠[/yellow] {warning}")

    if result.ok:
        console.print("[green]✓[/green] App client name validation passed")
        return

    console.print("[red]✗[/red] App client name validation failed")
    for issue in result.issues:
        shown = issue.client_name if issue.client_name else "(missing)"
        console.print(f"  [red]-[/red] {issue.source}: {issue.message} ({shown})")


def _run_bound_pool_uri_validation(
    *,
    pool_id: str,
    bound_region: str,
    values: dict[str, str],
    expected_port: int,
    include_aws: bool,
) -> CognitoURIValidationResult:
    selected_profile = _resolve_profile(daycog_values=values)
    selected_region = (
        (bound_region or "").strip()
        or (values.get("COGNITO_REGION") or "").strip()
        or (values.get("AWS_REGION") or "").strip()
        or settings.cognito_region
        or settings.aws_region
    )
    client_id = (
        values.get("COGNITO_APP_CLIENT_ID") or settings.cognito_app_client_id or ""
    ).strip()

    return validate_cognito_uri_ports(
        expected_port=expected_port,
        pool_id=pool_id,
        app_client_id=client_id,
        region=selected_region,
        profile=selected_profile,
        settings_redirect_uri=settings.cognito_redirect_uri,
        settings_logout_uri=settings.cognito_logout_url,
        include_aws=include_aws,
    )


def _run_bound_pool_client_name_validation(
    *,
    pool_id: str,
    bound_region: str,
    values: dict[str, str],
    include_aws: bool,
) -> CognitoClientNameValidationResult:
    selected_profile = _resolve_profile(daycog_values=values)
    selected_region = (
        (bound_region or "").strip()
        or (values.get("COGNITO_REGION") or "").strip()
        or (values.get("AWS_REGION") or "").strip()
        or settings.cognito_region
        or settings.aws_region
    )
    client_id = (
        values.get("COGNITO_APP_CLIENT_ID") or settings.cognito_app_client_id or ""
    ).strip()

    return validate_cognito_app_client_name(
        expected_client_name=ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        pool_id=pool_id,
        app_client_id=client_id,
        region=selected_region,
        profile=selected_profile,
        settings_client_name=settings.cognito_client_name,
        include_aws=include_aws,
    )


@cognito_app.command("build")
def cognito_build(
    pool_name: str = typer.Option(
        "lsmc-atlas-gui-users",
        "--pool-name",
        "-n",
        help="Cognito pool name",
    ),
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="AWS profile (default: AWS_PROFILE env var or Atlas aws.profile)",
    ),
    region: str = typer.Option("us-east-1", "--region", "-r", help="AWS region"),
    port: int = typer.Option(
        8915,
        "--port",
        "-p",
        help="Callback port used when --callback-url is not provided",
    ),
    client_name: str = typer.Option(
        ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        "--client-name",
        help="App client name (Atlas default: atlas)",
    ),
    domain_prefix: str | None = typer.Option(
        None,
        "--domain-prefix",
        help="Hosted UI domain prefix (daycog default: pool name)",
    ),
    attach_domain: bool = typer.Option(
        True,
        "--attach-domain/--no-attach-domain",
        help="Attach/ensure Cognito Hosted UI domain",
    ),
    callback_path: str = typer.Option(
        "/auth/callback",
        "--callback-path",
        help="Callback path used with --port when --callback-url is not set",
    ),
    callback_url: str | None = typer.Option(
        None,
        "--callback-url",
        help="Full callback URL override for daycog setup",
    ),
    logout_url: str | None = typer.Option(
        None,
        "--logout-url",
        help="Optional logout URL for app client",
    ),
    print_exports: bool = typer.Option(
        False,
        "--print-exports",
        help="Print shell export lines from daycog setup output",
    ),
    autoprovision: bool = typer.Option(
        False,
        "--autoprovision",
        help="Reuse existing app client matching --client-name when present",
    ),
    generate_secret: bool = typer.Option(
        False,
        "--generate-secret",
        help="Create app client with GenerateSecret=True",
    ),
    oauth_flows: str = typer.Option(
        "code",
        "--oauth-flows",
        help="Comma-separated OAuth flows (e.g. code,implicit)",
    ),
    scopes: str = typer.Option(
        "openid,email,profile",
        "--scopes",
        help="Comma-separated OAuth scopes",
    ),
    idp: str = typer.Option(
        "COGNITO",
        "--idp",
        help="Comma-separated identity providers",
    ),
    password_min_length: int = typer.Option(
        8,
        "--password-min-length",
        help="Minimum password length",
    ),
    require_uppercase: bool = typer.Option(
        True,
        "--require-uppercase/--no-require-uppercase",
        help="Require uppercase letters in password policy",
    ),
    require_lowercase: bool = typer.Option(
        True,
        "--require-lowercase/--no-require-lowercase",
        help="Require lowercase letters in password policy",
    ),
    require_numbers: bool = typer.Option(
        True,
        "--require-numbers/--no-require-numbers",
        help="Require numbers in password policy",
    ),
    require_symbols: bool = typer.Option(
        False,
        "--require-symbols/--no-require-symbols",
        help="Require symbols in password policy",
    ),
    mfa: str = typer.Option(
        "off",
        "--mfa",
        help="MFA mode: off, optional, required",
    ),
    tags: str | None = typer.Option(
        None,
        "--tags",
        help="Comma-separated tags in key=value format",
    ),
) -> None:
    """Create/reuse Cognito pool via daycog and bind pool ID into Atlas config."""
    selected_pool = _safe_pool_name(pool_name)
    selected_client_name = _resolve_requested_client_name(client_name)
    selected_profile = _resolve_profile(explicit_profile=profile)
    setup_options = _get_daycog_setup_options()
    proc_env = _build_daycog_proc_env(profile=selected_profile, region=region)

    args = ["setup", "--name", selected_pool]
    if "--region" in setup_options:
        args.extend(["--region", region])
    if "--profile" in setup_options and selected_profile:
        args.extend(["--profile", selected_profile])
    _ensure_supported_or_raise(
        setup_options,
        "--client-name",
        True,
        "custom client names",
    )
    if "--client-name" in setup_options:
        args.extend(["--client-name", selected_client_name])

    _ensure_supported_or_raise(
        setup_options,
        "--domain-prefix",
        domain_prefix is not None,
        "custom Hosted UI domain prefixes",
    )
    if domain_prefix and "--domain-prefix" in setup_options:
        args.extend(["--domain-prefix", domain_prefix])

    _ensure_supported_or_raise(
        setup_options,
        "--attach-domain",
        attach_domain is not True,
        "Hosted UI domain attachment toggles",
    )
    if not attach_domain and "--no-attach-domain" in setup_options:
        args.append("--no-attach-domain")

    _ensure_supported_or_raise(
        setup_options,
        "--callback-url",
        callback_url is not None,
        "explicit callback URL",
    )
    if callback_url:
        if "--callback-url" in setup_options:
            args.extend(["--callback-url", callback_url])
    else:
        if "--port" in setup_options:
            args.extend(["--port", str(port)])
        if "--callback-path" in setup_options:
            args.extend(["--callback-path", callback_path])
        elif callback_path != "/auth/callback":
            raise RuntimeError(
                "Installed daycog does not support --callback-path. "
                "Upgrade daylily-cognito/daycog to >=0.1.24."
            )

    _ensure_supported_or_raise(
        setup_options,
        "--logout-url",
        logout_url is not None,
        "custom logout URL",
    )
    if logout_url and "--logout-url" in setup_options:
        args.extend(["--logout-url", logout_url])

    _ensure_supported_or_raise(
        setup_options,
        "--print-exports",
        print_exports,
        "export printing",
    )
    if print_exports and "--print-exports" in setup_options:
        args.append("--print-exports")

    _ensure_supported_or_raise(
        setup_options,
        "--autoprovision",
        autoprovision,
        "app client autoprovision/reuse",
    )
    if autoprovision and "--autoprovision" in setup_options:
        args.append("--autoprovision")

    _ensure_supported_or_raise(
        setup_options,
        "--generate-secret",
        generate_secret,
        "app client secrets",
    )
    if generate_secret and "--generate-secret" in setup_options:
        args.append("--generate-secret")

    _ensure_supported_or_raise(
        setup_options,
        "--oauth-flows",
        oauth_flows != "code",
        "custom OAuth flows",
    )
    if "--oauth-flows" in setup_options and oauth_flows:
        args.extend(["--oauth-flows", oauth_flows])

    _ensure_supported_or_raise(
        setup_options,
        "--scopes",
        scopes != "openid,email,profile",
        "custom OAuth scopes",
    )
    if "--scopes" in setup_options and scopes:
        args.extend(["--scopes", scopes])

    _ensure_supported_or_raise(
        setup_options,
        "--idp",
        idp != "COGNITO",
        "custom identity providers",
    )
    if "--idp" in setup_options and idp:
        args.extend(["--idp", idp])

    _ensure_supported_or_raise(
        setup_options,
        "--password-min-length",
        password_min_length != 8,
        "custom password minimum length",
    )
    if "--password-min-length" in setup_options:
        args.extend(["--password-min-length", str(password_min_length)])

    _ensure_supported_or_raise(
        setup_options,
        "--mfa",
        mfa.lower() != "off",
        "custom MFA mode",
    )
    if "--mfa" in setup_options:
        args.extend(["--mfa", mfa])

    _ensure_supported_or_raise(
        setup_options,
        "--require-uppercase",
        require_uppercase is not True,
        "password uppercase toggle",
    )
    if "--require-uppercase" in setup_options:
        args.append("--require-uppercase" if require_uppercase else "--no-require-uppercase")

    _ensure_supported_or_raise(
        setup_options,
        "--require-lowercase",
        require_lowercase is not True,
        "password lowercase toggle",
    )
    if "--require-lowercase" in setup_options:
        args.append("--require-lowercase" if require_lowercase else "--no-require-lowercase")

    _ensure_supported_or_raise(
        setup_options,
        "--require-numbers",
        require_numbers is not True,
        "password number toggle",
    )
    if "--require-numbers" in setup_options:
        args.append("--require-numbers" if require_numbers else "--no-require-numbers")

    _ensure_supported_or_raise(
        setup_options,
        "--require-symbols",
        require_symbols is not False,
        "password symbol toggle",
    )
    if "--require-symbols" in setup_options:
        args.append("--require-symbols" if require_symbols else "--no-require-symbols")

    _ensure_supported_or_raise(
        setup_options,
        "--tags",
        tags is not None,
        "pool/client tagging",
    )
    if tags and "--tags" in setup_options:
        args.extend(["--tags", tags])

    console.print(
        f"[cyan]Setting up Cognito pool[/cyan] [bold]{selected_pool}[/bold] "
        f"in [bold]{region}[/bold]"
    )
    _run_daycog(args, env=proc_env)

    pool_env_path, values = _find_pool_env_file_by_name_region(selected_pool, region)
    pool_id = (values.get("COGNITO_USER_POOL_ID") or "").strip()
    if not pool_id:
        # Some setups may only persist context in app-specific files.
        for env_file in _iter_daycog_env_files():
            candidate_pool, candidate_region, _candidate_app = _parse_daycog_env_filename(env_file)
            if candidate_pool != selected_pool or candidate_region != region:
                continue
            candidate_values = _read_env_file(env_file)
            pool_id = (candidate_values.get("COGNITO_USER_POOL_ID") or "").strip()
            if pool_id:
                pool_env_path = env_file
                values = candidate_values
                break
    if not pool_id:
        raise RuntimeError(f"daycog setup completed but pool ID was not found in {pool_env_path}.")

    cfg_path = _write_pool_id_to_atlas_config(pool_id)
    console.print(f"[green]✓[/green] Bound Cognito pool ID in Atlas config: {pool_id}")
    console.print(f"  Atlas config: [dim]{cfg_path}[/dim]")
    console.print(f"  daycog env:   [dim]{pool_env_path}[/dim]")


@cognito_app.command("bind")
def cognito_bind(
    pool_id: str = typer.Option(..., "--pool-id", help="Existing Cognito user pool ID"),
) -> None:
    """Bind an existing Cognito pool ID into Atlas config."""
    trimmed = pool_id.strip()
    if not trimmed:
        raise typer.BadParameter("pool_id cannot be empty")

    cfg_path = _write_pool_id_to_atlas_config(trimmed)
    console.print(f"[green]✓[/green] Bound pool ID in Atlas config: {trimmed}")
    console.print(f"  Atlas config: [dim]{cfg_path}[/dim]")


@cognito_app.command("status")
def cognito_status(
    port: int | None = typer.Option(
        None,
        "--port",
        help="Atlas app port used to validate localhost callback/logout URIs (default: ATLAS_PORT or 8915)",
    ),
    check_aws: bool = typer.Option(
        True,
        "--check-aws/--no-check-aws",
        help="Validate URI values stored in the Cognito app client (AWS API)",
    ),
) -> None:
    """Show Atlas Cognito binding and mapped daycog pool env file."""
    pool_id = _get_configured_pool_id()
    if not pool_id:
        console.print("[yellow]⚠[/yellow] No Cognito pool configured in Atlas")
        console.print("   Run: [cyan]atlas cognito build[/cyan]")
        raise typer.Exit(1)

    pool_name, bound_region, env_file, values = _resolve_bound_pool_context(pool_id)
    region = bound_region or "(missing)"
    client_id = values.get("COGNITO_APP_CLIENT_ID") or "(missing)"
    client_name = values.get("COGNITO_CLIENT_NAME") or "(missing)"
    callback_url = values.get("COGNITO_CALLBACK_URL") or "(missing)"
    logout_url = values.get("COGNITO_LOGOUT_URL") or "(missing)"
    domain = values.get("COGNITO_DOMAIN") or "(missing)"
    profile = values.get("AWS_PROFILE") or "(missing)"

    if pool_name:
        console.print(f"[green]✓[/green] Pool name:  {pool_name}")
    console.print(f"[green]✓[/green] Pool ID:    {pool_id}")
    console.print(f"[green]✓[/green] daycog env: {env_file}")
    console.print(f"[green]✓[/green] Region:     {region}")
    console.print(f"[green]✓[/green] Client ID:  {client_id}")
    console.print(f"[green]✓[/green] Client name: {client_name}")
    console.print(f"[green]✓[/green] Callback:   {callback_url}")
    console.print(f"[green]✓[/green] Logout URL: {logout_url}")
    console.print(f"[green]✓[/green] Domain:     {domain}")
    console.print(f"[green]✓[/green] Profile:    {profile}")

    expected_port = _resolve_expected_atlas_port(port)
    uri_validation = _run_bound_pool_uri_validation(
        pool_id=pool_id,
        bound_region=bound_region,
        values=values,
        expected_port=expected_port,
        include_aws=check_aws,
    )
    _print_uri_validation_result(uri_validation)
    client_name_validation = _run_bound_pool_client_name_validation(
        pool_id=pool_id,
        bound_region=bound_region,
        values=values,
        include_aws=check_aws,
    )
    _print_client_name_validation_result(client_name_validation)
    if not uri_validation.ok or not client_name_validation.ok:
        raise typer.Exit(1)


@cognito_app.command("validate-uris")
def cognito_validate_uris(
    port: int = typer.Option(
        8915,
        "--port",
        help="Atlas app port used to validate localhost callback/logout URIs",
    ),
    check_aws: bool = typer.Option(
        True,
        "--check-aws/--no-check-aws",
        help="Validate URI values stored in the Cognito app client (AWS API)",
    ),
) -> None:
    """Validate callback/logout/redirect URI ports for the bound Cognito pool/app."""
    pool_id = _get_configured_pool_id()
    if not pool_id:
        console.print("[yellow]⚠[/yellow] No Cognito pool configured in Atlas")
        console.print("   Run: [cyan]atlas cognito build[/cyan]")
        raise typer.Exit(1)

    _pool_name, bound_region, _env_file, values = _resolve_bound_pool_context(pool_id)
    uri_validation = _run_bound_pool_uri_validation(
        pool_id=pool_id,
        bound_region=bound_region,
        values=values,
        expected_port=port,
        include_aws=check_aws,
    )
    _print_uri_validation_result(uri_validation)
    client_name_validation = _run_bound_pool_client_name_validation(
        pool_id=pool_id,
        bound_region=bound_region,
        values=values,
        include_aws=check_aws,
    )
    _print_client_name_validation_result(client_name_validation)
    if not uri_validation.ok or not client_name_validation.ok:
        raise typer.Exit(1)


@cognito_app.command("add-user")
def cognito_add_user(
    email: str = typer.Argument(..., help="User email"),
    password: str = typer.Option(..., "--password", "-p", help="Initial password"),
    no_verify: bool = typer.Option(
        True,
        "--no-verify/--verify-email",
        help="Set permanent password and mark email verified",
    ),
) -> None:
    """Create a Cognito user in the Atlas-bound pool via daycog."""
    pool_id = _get_configured_pool_id()
    if not pool_id:
        console.print(
            "[red]✗[/red] No Cognito pool configured. Run [cyan]atlas cognito build[/cyan]."
        )
        raise typer.Exit(1)

    env_file, values = _find_pool_env_file_by_id(pool_id)
    selected_region = (
        values.get("COGNITO_REGION")
        or values.get("AWS_REGION")
        or _infer_region_from_pool_id(pool_id)
    )
    selected_profile = _resolve_profile(daycog_values=values)
    proc_env = _build_daycog_proc_env(values, profile=selected_profile, region=selected_region)

    args = ["add-user", email, "--password", password]
    if no_verify:
        args.append("--no-verify")
    _run_daycog(args, env=proc_env)

    console.print(f"[green]✓[/green] Created Cognito user: {email}")
    console.print(f"  Pool: [dim]{pool_id}[/dim]")
    console.print(f"  daycog env: [dim]{env_file}[/dim]")


@cognito_app.command("set-password")
def cognito_set_password(
    email: str = typer.Option(..., "--email", "-e", help="User email"),
    password: str = typer.Option(..., "--password", "-p", help="New password"),
) -> None:
    """Set a Cognito user password in the Atlas-bound pool via daycog."""
    pool_id = _get_configured_pool_id()
    if not pool_id:
        console.print(
            "[red]✗[/red] No Cognito pool configured. Run [cyan]atlas cognito build[/cyan]."
        )
        raise typer.Exit(1)

    env_file, values = _find_pool_env_file_by_id(pool_id)
    selected_region = (
        values.get("COGNITO_REGION")
        or values.get("AWS_REGION")
        or _infer_region_from_pool_id(pool_id)
    )
    selected_profile = _resolve_profile(daycog_values=values)
    proc_env = _build_daycog_proc_env(values, profile=selected_profile, region=selected_region)

    _run_daycog(["set-password", "--email", email, "--password", password], env=proc_env)
    console.print(f"[green]✓[/green] Updated password for: {email}")
    console.print(f"  Pool: [dim]{pool_id}[/dim]")
    console.print(f"  daycog env: [dim]{env_file}[/dim]")


@cognito_app.command("delete")
def cognito_delete(
    pool_name: str | None = typer.Option(None, "--pool-name", help="Cognito pool name to delete"),
    pool_id: str | None = typer.Option(None, "--pool-id", help="Cognito pool ID to delete"),
    profile: str | None = typer.Option(None, "--profile", help="AWS profile"),
    region: str | None = typer.Option(None, "--region", "-r", help="AWS region"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    delete_domain_first: bool = typer.Option(
        False,
        "--delete-domain-first",
        help="Delete pool domain first (required in some Cognito account states)",
    ),
) -> None:
    """Delete a Cognito pool via daycog."""
    selected_pool_id = (pool_id or "").strip() or _get_configured_pool_id()
    selected_pool_name = _safe_pool_name(pool_name) if pool_name else ""

    if not selected_pool_id and not selected_pool_name:
        console.print(
            "[red]✗[/red] Provide --pool-name/--pool-id or configure Atlas Cognito first."
        )
        raise typer.Exit(1)

    resolved_region = (region or "").strip()
    daycog_values: dict[str, str] = {}
    if selected_pool_id:
        try:
            _bound_pool_name, bound_region, _env_file, daycog_values = _resolve_bound_pool_context(
                selected_pool_id
            )
            if not selected_pool_name:
                selected_pool_name = _bound_pool_name
            if not resolved_region:
                resolved_region = bound_region
        except RuntimeError:
            if not selected_pool_name:
                raise

    if not resolved_region:
        resolved_region = (os.environ.get("AWS_REGION") or settings.aws_region).strip()
    selected_profile = _resolve_profile(explicit_profile=profile, daycog_values=daycog_values)

    if not resolved_region:
        raise RuntimeError(
            "Unable to resolve region for delete operation. Pass --region explicitly."
        )

    args = ["delete-pool", "--region", resolved_region]
    if selected_pool_name:
        args.extend(["--pool-name", selected_pool_name])
    elif selected_pool_id:
        args.extend(["--pool-id", selected_pool_id])

    if selected_profile:
        args.extend(["--profile", selected_profile])
    if delete_domain_first:
        args.append("--delete-domain-first")
    if force:
        args.append("--force")

    proc_env = _build_daycog_proc_env(
        daycog_values, profile=selected_profile, region=resolved_region
    )
    _run_daycog(args, env=proc_env)
    console.print("[green]✓[/green] Deleted Cognito pool")


def _print_daycog_output(output: str) -> None:
    if output:
        console.print(output)


@cognito_app.command("list-apps")
def cognito_list_apps(
    pool_name: str | None = typer.Option(
        None,
        "--pool-name",
        help="Cognito pool name (defaults to Atlas-bound pool)",
    ),
    profile: str | None = typer.Option(None, "--profile", help="AWS profile"),
    region: str | None = typer.Option(None, "--region", "-r", help="AWS region"),
) -> None:
    """List Cognito app clients for the selected pool."""
    selected_pool, selected_region, selected_profile, _env_file, values = (
        _resolve_selected_pool_name_region(
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    proc_env = _build_daycog_proc_env(values, profile=selected_profile, region=selected_region)
    args = ["list-apps", "--pool-name", selected_pool, "--region", selected_region]
    if selected_profile:
        args.extend(["--profile", selected_profile])
    _print_daycog_output(_run_daycog(args, env=proc_env))


@cognito_app.command("add-app")
def cognito_add_app(
    app_name: str = typer.Option(..., "--app-name", help="New app client name"),
    callback_url: str = typer.Option(..., "--callback-url", help="OAuth callback URL"),
    pool_name: str | None = typer.Option(
        None,
        "--pool-name",
        help="Cognito pool name (defaults to Atlas-bound pool)",
    ),
    profile: str | None = typer.Option(None, "--profile", help="AWS profile"),
    region: str | None = typer.Option(None, "--region", "-r", help="AWS region"),
    logout_url: str | None = typer.Option(None, "--logout-url", help="Optional logout URL"),
    generate_secret: bool = typer.Option(
        False,
        "--generate-secret",
        help="Create app client with GenerateSecret=True",
    ),
    oauth_flows: str = typer.Option("code", "--oauth-flows", help="Comma-separated OAuth flows"),
    scopes: str = typer.Option(
        "openid,email,profile",
        "--scopes",
        help="Comma-separated OAuth scopes",
    ),
    idp: str = typer.Option("COGNITO", "--idp", help="Comma-separated identity providers"),
    set_default: bool = typer.Option(
        True,
        "--set-default/--no-set-default",
        help="Update pool/default daycog env context to this app",
    ),
) -> None:
    """Add a new app client to an existing Cognito pool."""
    selected_pool, selected_region, selected_profile, _env_file, values = (
        _resolve_selected_pool_name_region(
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    add_options = _get_daycog_command_options("add-app")
    proc_env = _build_daycog_proc_env(values, profile=selected_profile, region=selected_region)

    args = [
        "add-app",
        "--pool-name",
        selected_pool,
        "--app-name",
        app_name,
        "--callback-url",
        callback_url,
        "--region",
        selected_region,
    ]
    if selected_profile:
        args.extend(["--profile", selected_profile])

    _ensure_supported_or_raise(
        add_options, "--logout-url", logout_url is not None, "custom logout URL"
    )
    if logout_url:
        args.extend(["--logout-url", logout_url])

    _ensure_supported_or_raise(
        add_options,
        "--generate-secret",
        generate_secret,
        "app client secrets",
    )
    if generate_secret and "--generate-secret" in add_options:
        args.append("--generate-secret")

    _ensure_supported_or_raise(
        add_options,
        "--oauth-flows",
        oauth_flows != "code",
        "custom OAuth flows",
    )
    if oauth_flows and "--oauth-flows" in add_options:
        args.extend(["--oauth-flows", oauth_flows])

    _ensure_supported_or_raise(
        add_options,
        "--scopes",
        scopes != "openid,email,profile",
        "custom OAuth scopes",
    )
    if scopes and "--scopes" in add_options:
        args.extend(["--scopes", scopes])

    _ensure_supported_or_raise(
        add_options,
        "--idp",
        idp != "COGNITO",
        "custom identity providers",
    )
    if idp and "--idp" in add_options:
        args.extend(["--idp", idp])

    _ensure_supported_or_raise(
        add_options, "--set-default", set_default, "daycog default context updates"
    )
    if set_default and "--set-default" in add_options:
        args.append("--set-default")

    _print_daycog_output(_run_daycog(args, env=proc_env))


@cognito_app.command("edit-app")
def cognito_edit_app(
    pool_name: str | None = typer.Option(
        None,
        "--pool-name",
        help="Cognito pool name (defaults to Atlas-bound pool)",
    ),
    app_name: str | None = typer.Option(None, "--app-name", help="Existing app client name"),
    client_id: str | None = typer.Option(None, "--client-id", help="Existing app client ID"),
    new_app_name: str | None = typer.Option(None, "--new-app-name", help="Rename app client"),
    profile: str | None = typer.Option(None, "--profile", help="AWS profile"),
    region: str | None = typer.Option(None, "--region", "-r", help="AWS region"),
    callback_url: str | None = typer.Option(None, "--callback-url", help="Override callback URL"),
    logout_url: str | None = typer.Option(None, "--logout-url", help="Override logout URL"),
    oauth_flows: str | None = typer.Option(
        None, "--oauth-flows", help="Comma-separated OAuth flows"
    ),
    scopes: str | None = typer.Option(None, "--scopes", help="Comma-separated OAuth scopes"),
    idp: str | None = typer.Option(None, "--idp", help="Comma-separated identity providers"),
    set_default: bool = typer.Option(
        True,
        "--set-default/--no-set-default",
        help="Update pool/default daycog env context to this app",
    ),
) -> None:
    """Edit an existing Cognito app client."""
    if not app_name and not client_id:
        raise typer.BadParameter("Provide one of --app-name or --client-id")

    selected_pool, selected_region, selected_profile, _env_file, values = (
        _resolve_selected_pool_name_region(
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    edit_options = _get_daycog_command_options("edit-app")
    proc_env = _build_daycog_proc_env(values, profile=selected_profile, region=selected_region)

    args = ["edit-app", "--pool-name", selected_pool, "--region", selected_region]
    if app_name:
        args.extend(["--app-name", app_name])
    if client_id:
        args.extend(["--client-id", client_id])
    if selected_profile:
        args.extend(["--profile", selected_profile])

    _ensure_supported_or_raise(
        edit_options,
        "--new-app-name",
        new_app_name is not None,
        "renaming app clients",
    )
    if new_app_name:
        args.extend(["--new-app-name", new_app_name])

    _ensure_supported_or_raise(
        edit_options,
        "--callback-url",
        callback_url is not None,
        "custom callback URL",
    )
    if callback_url:
        args.extend(["--callback-url", callback_url])

    _ensure_supported_or_raise(
        edit_options,
        "--logout-url",
        logout_url is not None,
        "custom logout URL",
    )
    if logout_url:
        args.extend(["--logout-url", logout_url])

    _ensure_supported_or_raise(
        edit_options,
        "--oauth-flows",
        oauth_flows is not None,
        "custom OAuth flows",
    )
    if oauth_flows:
        args.extend(["--oauth-flows", oauth_flows])

    _ensure_supported_or_raise(
        edit_options,
        "--scopes",
        scopes is not None,
        "custom OAuth scopes",
    )
    if scopes:
        args.extend(["--scopes", scopes])

    _ensure_supported_or_raise(
        edit_options,
        "--idp",
        idp is not None,
        "custom identity providers",
    )
    if idp:
        args.extend(["--idp", idp])

    _ensure_supported_or_raise(
        edit_options,
        "--set-default",
        set_default,
        "daycog default context updates",
    )
    if set_default and "--set-default" in edit_options:
        args.append("--set-default")

    _print_daycog_output(_run_daycog(args, env=proc_env))


@cognito_app.command("remove-app")
def cognito_remove_app(
    pool_name: str | None = typer.Option(
        None,
        "--pool-name",
        help="Cognito pool name (defaults to Atlas-bound pool)",
    ),
    app_name: str | None = typer.Option(None, "--app-name", help="App client name"),
    client_id: str | None = typer.Option(None, "--client-id", help="App client ID"),
    profile: str | None = typer.Option(None, "--profile", help="AWS profile"),
    region: str | None = typer.Option(None, "--region", "-r", help="AWS region"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    delete_config: bool = typer.Option(
        True,
        "--delete-config/--keep-config",
        help="Delete per-app daycog env file",
    ),
) -> None:
    """Remove an app client from a Cognito pool."""
    if not app_name and not client_id:
        raise typer.BadParameter("Provide one of --app-name or --client-id")

    selected_pool, selected_region, selected_profile, _env_file, values = (
        _resolve_selected_pool_name_region(
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    remove_options = _get_daycog_command_options("remove-app")
    proc_env = _build_daycog_proc_env(values, profile=selected_profile, region=selected_region)

    args = ["remove-app", "--pool-name", selected_pool, "--region", selected_region]
    if app_name:
        args.extend(["--app-name", app_name])
    if client_id:
        args.extend(["--client-id", client_id])
    if selected_profile:
        args.extend(["--profile", selected_profile])
    if force:
        args.append("--force")

    _ensure_supported_or_raise(
        remove_options,
        "--delete-config",
        delete_config is not True,
        "custom config file retention",
    )
    if not delete_config:
        args.append("--keep-config")

    _print_daycog_output(_run_daycog(args, env=proc_env))


@cognito_app.command("add-google-idp")
def cognito_add_google_idp(
    pool_name: str | None = typer.Option(
        None,
        "--pool-name",
        help="Cognito pool name (defaults to Atlas-bound pool)",
    ),
    app_name: str | None = typer.Option(None, "--app-name", help="App client name"),
    client_id: str | None = typer.Option(None, "--client-id", help="App client ID"),
    profile: str | None = typer.Option(None, "--profile", help="AWS profile"),
    region: str | None = typer.Option(None, "--region", "-r", help="AWS region"),
    google_client_id: str | None = typer.Option(
        None,
        "--google-client-id",
        help="Google OAuth client ID",
    ),
    google_client_secret: str | None = typer.Option(
        None,
        "--google-client-secret",
        help="Google OAuth client secret",
    ),
    google_client_json: str | None = typer.Option(
        None,
        "--google-client-json",
        help="Path to Google OAuth client JSON",
    ),
    scopes: str = typer.Option("openid email profile", "--scopes", help="Google authorize scopes"),
) -> None:
    """Configure Google IdP and enable it for an app client."""
    if not app_name and not client_id:
        raise typer.BadParameter("Provide one of --app-name or --client-id")

    selected_pool, selected_region, selected_profile, _env_file, values = (
        _resolve_selected_pool_name_region(
            pool_name=pool_name,
            region=region,
            profile=profile,
        )
    )
    google_options = _get_daycog_command_options("add-google-idp")
    proc_env = _build_daycog_proc_env(values, profile=selected_profile, region=selected_region)

    args = ["add-google-idp", "--pool-name", selected_pool, "--region", selected_region]
    if app_name:
        args.extend(["--app-name", app_name])
    if client_id:
        args.extend(["--client-id", client_id])
    if selected_profile:
        args.extend(["--profile", selected_profile])
    _ensure_supported_or_raise(
        google_options,
        "--scopes",
        scopes != "openid email profile",
        "custom Google OAuth scopes",
    )
    if scopes and "--scopes" in google_options:
        args.extend(["--scopes", scopes])

    _ensure_supported_or_raise(
        google_options,
        "--google-client-id",
        google_client_id is not None,
        "explicit Google client ID",
    )
    if google_client_id:
        args.extend(["--google-client-id", google_client_id])

    _ensure_supported_or_raise(
        google_options,
        "--google-client-secret",
        google_client_secret is not None,
        "explicit Google client secret",
    )
    if google_client_secret:
        args.extend(["--google-client-secret", google_client_secret])

    _ensure_supported_or_raise(
        google_options,
        "--google-client-json",
        google_client_json is not None,
        "Google credentials via client JSON",
    )
    if google_client_json:
        args.extend(["--google-client-json", google_client_json])

    _print_daycog_output(_run_daycog(args, env=proc_env))


@cognito_app.command("setup-with-google")
def cognito_setup_with_google(
    pool_name: str = typer.Option(
        "lsmc-atlas-gui-users",
        "--pool-name",
        "-n",
        help="Cognito pool name",
    ),
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="AWS profile (default: AWS_PROFILE env var or Atlas aws.profile)",
    ),
    region: str = typer.Option("us-east-1", "--region", "-r", help="AWS region"),
    port: int = typer.Option(
        8915,
        "--port",
        "-p",
        help="Callback port used when --callback-url is not provided",
    ),
    client_name: str = typer.Option(
        ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        "--client-name",
        help="App client name (Atlas default: atlas)",
    ),
    domain_prefix: str | None = typer.Option(
        None,
        "--domain-prefix",
        help="Hosted UI domain prefix (daycog default: pool name)",
    ),
    attach_domain: bool = typer.Option(
        True,
        "--attach-domain/--no-attach-domain",
        help="Attach/ensure Cognito Hosted UI domain",
    ),
    callback_path: str = typer.Option(
        "/auth/callback",
        "--callback-path",
        help="Callback path used with --port when --callback-url is not set",
    ),
    callback_url: str | None = typer.Option(
        None,
        "--callback-url",
        help="Full callback URL override for daycog setup-with-google",
    ),
    logout_url: str | None = typer.Option(
        None,
        "--logout-url",
        help="Optional logout URL for app client",
    ),
    print_exports: bool = typer.Option(
        False,
        "--print-exports",
        help="Print shell export lines from daycog setup-with-google output",
    ),
    autoprovision: bool = typer.Option(
        False,
        "--autoprovision",
        help="Reuse existing app client matching --client-name when present",
    ),
    generate_secret: bool = typer.Option(
        False,
        "--generate-secret",
        help="Create app client with GenerateSecret=True",
    ),
    oauth_flows: str = typer.Option(
        "code",
        "--oauth-flows",
        help="Comma-separated OAuth flows (e.g. code,implicit)",
    ),
    scopes: str = typer.Option(
        "openid,email,profile",
        "--scopes",
        help="Comma-separated OAuth scopes",
    ),
    idp: str = typer.Option(
        "COGNITO",
        "--idp",
        help="Comma-separated identity providers",
    ),
    password_min_length: int = typer.Option(
        8,
        "--password-min-length",
        help="Minimum password length",
    ),
    require_uppercase: bool = typer.Option(
        True,
        "--require-uppercase/--no-require-uppercase",
        help="Require uppercase letters in password policy",
    ),
    require_lowercase: bool = typer.Option(
        True,
        "--require-lowercase/--no-require-lowercase",
        help="Require lowercase letters in password policy",
    ),
    require_numbers: bool = typer.Option(
        True,
        "--require-numbers/--no-require-numbers",
        help="Require numbers in password policy",
    ),
    require_symbols: bool = typer.Option(
        False,
        "--require-symbols/--no-require-symbols",
        help="Require symbols in password policy",
    ),
    mfa: str = typer.Option(
        "off",
        "--mfa",
        help="MFA mode: off, optional, required",
    ),
    tags: str | None = typer.Option(
        None,
        "--tags",
        help="Comma-separated tags in key=value format",
    ),
    google_client_id: str | None = typer.Option(
        None,
        "--google-client-id",
        help="Google OAuth client ID",
    ),
    google_client_secret: str | None = typer.Option(
        None,
        "--google-client-secret",
        help="Google OAuth client secret",
    ),
    google_client_json: str | None = typer.Option(
        None,
        "--google-client-json",
        help="Path to Google OAuth client JSON",
    ),
    google_scopes: str = typer.Option(
        "openid email profile",
        "--google-scopes",
        help="Google authorize scopes",
    ),
) -> None:
    """Provision pool/app and configure Google IdP via daycog in one command."""
    selected_pool = _safe_pool_name(pool_name)
    selected_client_name = _resolve_requested_client_name(client_name)
    selected_profile = _resolve_profile(explicit_profile=profile)
    setup_google_options = _get_daycog_command_options("setup-with-google")
    proc_env = _build_daycog_proc_env(profile=selected_profile, region=region)

    args = ["setup-with-google", "--name", selected_pool]
    if "--region" in setup_google_options:
        args.extend(["--region", region])
    if "--profile" in setup_google_options and selected_profile:
        args.extend(["--profile", selected_profile])
    if "--client-name" in setup_google_options:
        args.extend(["--client-name", selected_client_name])
    _ensure_supported_or_raise(
        setup_google_options,
        "--client-name",
        True,
        "custom client names",
    )

    _ensure_supported_or_raise(
        setup_google_options,
        "--domain-prefix",
        domain_prefix is not None,
        "custom Hosted UI domain prefixes",
    )
    if domain_prefix and "--domain-prefix" in setup_google_options:
        args.extend(["--domain-prefix", domain_prefix])

    _ensure_supported_or_raise(
        setup_google_options,
        "--attach-domain",
        attach_domain is not True,
        "Hosted UI domain attachment toggles",
    )
    if not attach_domain and "--no-attach-domain" in setup_google_options:
        args.append("--no-attach-domain")

    _ensure_supported_or_raise(
        setup_google_options,
        "--callback-url",
        callback_url is not None,
        "explicit callback URL",
    )
    if callback_url:
        if "--callback-url" in setup_google_options:
            args.extend(["--callback-url", callback_url])
    else:
        if "--port" in setup_google_options:
            args.extend(["--port", str(port)])
        if "--callback-path" in setup_google_options:
            args.extend(["--callback-path", callback_path])
        elif callback_path != "/auth/callback":
            raise RuntimeError(
                "Installed daycog does not support --callback-path. "
                "Upgrade daylily-cognito/daycog to >=0.1.24."
            )

    _ensure_supported_or_raise(
        setup_google_options,
        "--logout-url",
        logout_url is not None,
        "custom logout URL",
    )
    if logout_url and "--logout-url" in setup_google_options:
        args.extend(["--logout-url", logout_url])

    _ensure_supported_or_raise(
        setup_google_options,
        "--print-exports",
        print_exports,
        "export printing",
    )
    if print_exports and "--print-exports" in setup_google_options:
        args.append("--print-exports")

    _ensure_supported_or_raise(
        setup_google_options,
        "--autoprovision",
        autoprovision,
        "app client autoprovision/reuse",
    )
    if autoprovision and "--autoprovision" in setup_google_options:
        args.append("--autoprovision")

    _ensure_supported_or_raise(
        setup_google_options,
        "--generate-secret",
        generate_secret,
        "app client secrets",
    )
    if generate_secret and "--generate-secret" in setup_google_options:
        args.append("--generate-secret")

    _ensure_supported_or_raise(
        setup_google_options,
        "--oauth-flows",
        oauth_flows != "code",
        "custom OAuth flows",
    )
    if "--oauth-flows" in setup_google_options and oauth_flows:
        args.extend(["--oauth-flows", oauth_flows])

    _ensure_supported_or_raise(
        setup_google_options,
        "--scopes",
        scopes != "openid,email,profile",
        "custom OAuth scopes",
    )
    if "--scopes" in setup_google_options and scopes:
        args.extend(["--scopes", scopes])

    _ensure_supported_or_raise(
        setup_google_options,
        "--idp",
        idp != "COGNITO",
        "custom identity providers",
    )
    if "--idp" in setup_google_options and idp:
        args.extend(["--idp", idp])

    _ensure_supported_or_raise(
        setup_google_options,
        "--password-min-length",
        password_min_length != 8,
        "custom password minimum length",
    )
    if "--password-min-length" in setup_google_options:
        args.extend(["--password-min-length", str(password_min_length)])

    _ensure_supported_or_raise(
        setup_google_options,
        "--mfa",
        mfa.lower() != "off",
        "custom MFA mode",
    )
    if "--mfa" in setup_google_options:
        args.extend(["--mfa", mfa])

    _ensure_supported_or_raise(
        setup_google_options,
        "--require-uppercase",
        require_uppercase is not True,
        "password uppercase toggle",
    )
    if "--require-uppercase" in setup_google_options:
        args.append("--require-uppercase" if require_uppercase else "--no-require-uppercase")

    _ensure_supported_or_raise(
        setup_google_options,
        "--require-lowercase",
        require_lowercase is not True,
        "password lowercase toggle",
    )
    if "--require-lowercase" in setup_google_options:
        args.append("--require-lowercase" if require_lowercase else "--no-require-lowercase")

    _ensure_supported_or_raise(
        setup_google_options,
        "--require-numbers",
        require_numbers is not True,
        "password number toggle",
    )
    if "--require-numbers" in setup_google_options:
        args.append("--require-numbers" if require_numbers else "--no-require-numbers")

    _ensure_supported_or_raise(
        setup_google_options,
        "--require-symbols",
        require_symbols is not False,
        "password symbol toggle",
    )
    if "--require-symbols" in setup_google_options:
        args.append("--require-symbols" if require_symbols else "--no-require-symbols")

    _ensure_supported_or_raise(
        setup_google_options,
        "--tags",
        tags is not None,
        "pool/client tagging",
    )
    if tags and "--tags" in setup_google_options:
        args.extend(["--tags", tags])

    _ensure_supported_or_raise(
        setup_google_options,
        "--google-client-id",
        google_client_id is not None,
        "explicit Google client ID",
    )
    if google_client_id and "--google-client-id" in setup_google_options:
        args.extend(["--google-client-id", google_client_id])

    _ensure_supported_or_raise(
        setup_google_options,
        "--google-client-secret",
        google_client_secret is not None,
        "explicit Google client secret",
    )
    if google_client_secret and "--google-client-secret" in setup_google_options:
        args.extend(["--google-client-secret", google_client_secret])

    _ensure_supported_or_raise(
        setup_google_options,
        "--google-client-json",
        google_client_json is not None,
        "Google credentials via client JSON",
    )
    if google_client_json and "--google-client-json" in setup_google_options:
        args.extend(["--google-client-json", google_client_json])

    _ensure_supported_or_raise(
        setup_google_options,
        "--google-scopes",
        google_scopes != "openid email profile",
        "custom Google OAuth scopes",
    )
    if google_scopes and "--google-scopes" in setup_google_options:
        args.extend(["--google-scopes", google_scopes])

    console.print(
        f"[cyan]Setting up Cognito pool + Google IdP[/cyan] [bold]{selected_pool}[/bold] "
        f"in [bold]{region}[/bold]"
    )
    _run_daycog(args, env=proc_env)

    pool_env_path, values = _find_pool_env_file_by_name_region(selected_pool, region)
    pool_id = (values.get("COGNITO_USER_POOL_ID") or "").strip()
    if not pool_id:
        raise RuntimeError(
            f"daycog setup-with-google completed but pool ID was not found in {pool_env_path}."
        )

    cfg_path = _write_pool_id_to_atlas_config(pool_id)
    console.print(f"[green]✓[/green] Bound Cognito pool ID in Atlas config: {pool_id}")
    console.print(f"  Atlas config: [dim]{cfg_path}[/dim]")
    console.print(f"  daycog env:   [dim]{pool_env_path}[/dim]")


@cognito_app.command("sync-config")
def sync_config() -> None:
    """Re-write Atlas config to retain only the current Cognito pool ID binding."""
    pool_id = _get_configured_pool_id()
    if not pool_id:
        console.print("[red]✗[/red] No Cognito pool configured.")
        raise typer.Exit(1)

    cfg_path = _write_pool_id_to_atlas_config(pool_id)
    console.print("[green]✓[/green] Atlas config normalized for pool-id-only Cognito config")
    console.print(f"  Pool ID: [dim]{pool_id}[/dim]")
    console.print(f"  Atlas config: [dim]{cfg_path}[/dim]")


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register the cognito command group."""
    registry.add_typer_app(None, cognito_app, "cognito", "Cognito management (via daycog)")
