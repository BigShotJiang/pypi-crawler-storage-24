"""Extra config subcommands for LSMC Atlas CLI.

These are registered under the built-in ``config`` group provided by cli-core-yo.
Built-in commands (path, init, show, validate, edit, reset) come from the framework;
this plugin adds Atlas-specific extras: clean, shell, routes, info.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

console = Console()

# Get project root
PROJECT_ROOT = Path(__file__).parent.parent.parent


# ── Command callbacks ────────────────────────────────────────────────────────


def _clean() -> None:
    """Remove cached files and build artifacts."""
    console.print("[cyan]Cleaning cached files...[/cyan]")

    patterns = [
        ("__pycache__", "d"),
        (".pytest_cache", "d"),
        (".mypy_cache", "d"),
        (".ruff_cache", "d"),
        ("htmlcov", "d"),
        ("*.pyc", "f"),
        (".coverage", "f"),
    ]

    for pattern, ptype in patterns:
        if ptype == "d":
            for p in PROJECT_ROOT.rglob(pattern):
                if p.is_dir():
                    shutil.rmtree(p)
                    console.print(f"  [green]✓[/green] Removed {p.relative_to(PROJECT_ROOT)}")
        else:
            for p in PROJECT_ROOT.rglob(pattern):
                if p.is_file():
                    p.unlink()
                    console.print(f"  [green]✓[/green] Removed {p.relative_to(PROJECT_ROOT)}")

    console.print("[green]Done![/green]")


def _shell() -> None:
    """Open IPython shell with app context."""
    console.print("[cyan]Starting interactive shell with app context...[/cyan]")

    setup_code = """
import sys
sys.path.insert(0, '.')

print('\\nLoading LSMC Atlas context...')

from app.db.engine import SessionLocal, engine
from app.settings import settings
from sqlalchemy import text

db = SessionLocal()

print()
print('Available objects:')
print('  db        - SQLAlchemy session (auto-created)')
print('  engine    - SQLAlchemy engine')
print('  settings  - App settings')
print('  text      - SQLAlchemy text() for raw SQL')
print()
print('Example: db.execute(text("SELECT * FROM organization")).fetchall()')
print()
"""

    subprocess.run(
        [sys.executable, "-m", "IPython", "-i", "-c", setup_code],
        cwd=PROJECT_ROOT,
    )


def _routes() -> None:
    """List all registered API routes."""
    console.print("[cyan]Registered API routes:[/cyan]")

    code = """
from app.main import create_app

app = create_app()

routes = []
for route in app.routes:
    if hasattr(route, 'methods') and hasattr(route, 'path'):
        for method in route.methods:
            if method not in ('HEAD', 'OPTIONS'):
                routes.append((method, route.path, getattr(route, 'name', '')))

routes.sort(key=lambda x: (x[1], x[0]))

print()
print(f"{'Method':<8} {'Path':<50} {'Name'}")
print('-' * 80)
for method, path, name in routes:
    print(f"{method:<8} {path:<50} {name}")
print()
print(f"Total: {len(routes)} routes")
"""

    subprocess.run([sys.executable, "-c", code], cwd=PROJECT_ROOT)


def _info() -> None:
    """Show environment and configuration information."""
    from rich.table import Table

    from app.settings import config_file_exists, get_config_file_path

    config_file = get_config_file_path()

    console.print()
    console.print("[bold blue]Configuration Source[/bold blue]")
    if config_file_exists():
        console.print(f"  [green]●[/green] YAML: {config_file}")
    else:
        console.print(f"  [dim]○[/dim] YAML: {config_file} (not found)")

    env_file = PROJECT_ROOT / ".env"
    if env_file.exists():
        console.print(f"  [yellow]●[/yellow] .env: {env_file} (deprecated)")
    console.print()

    table = Table(title="Effective Configuration")
    table.add_column("Setting", style="cyan")
    table.add_column("Value")

    vars_to_show = [
        "DATABASE_URL",
        "AUTH_MODE",
        "DEBUG",
        "SECRET_KEY",
        "AWS_PROFILE",
        "S3_REGION",
        "COGNITO_USER_POOL_ID",
        "COGNITO_APP_CLIENT_ID",
    ]

    for var in vars_to_show:
        value = os.environ.get(var, "")
        if value:
            if "SECRET" in var or "PASSWORD" in var:
                table.add_row(var, "****")
            elif len(value) > 50:
                table.add_row(var, value[:47] + "...")
            else:
                table.add_row(var, value)
        else:
            table.add_row(var, "[dim]not set[/dim]")

    console.print(table)


# ── Plugin registration ──────────────────────────────────────────────────────


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register extra config subcommands."""
    registry.add_command("config", "clean", _clean, "Remove cached files and build artifacts")
    registry.add_command("config", "shell", _shell, "Open IPython shell with app context")
    registry.add_command("config", "routes", _routes, "List all registered API routes")
    registry.add_command("config", "status", _info, "Show environment and configuration status")
