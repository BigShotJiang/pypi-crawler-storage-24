"""Testing commands for LSMC Atlas CLI."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console

test_app = typer.Typer(help="Testing commands")
console = Console()

# Get project root
PROJECT_ROOT = Path(__file__).parent.parent.parent


@test_app.command("run")
def run(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    pattern: str = typer.Option("", "--pattern", "-k", help="Run tests matching pattern"),
    path: str = typer.Argument("tests/", help="Test path or file"),
):
    """Run unit tests (no DB required)."""
    console.print("[cyan]Running unit tests...[/cyan]")

    cmd = [sys.executable, "-m", "pytest", path, "-m", "not db and not postgres"]

    if verbose:
        cmd.append("-v")
    else:
        cmd.extend(["-v", "--tb=short"])

    if pattern:
        cmd.extend(["-k", pattern])

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    raise typer.Exit(result.returncode)


@test_app.command("all")
def all_tests(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    pattern: str = typer.Option("", "--pattern", "-k", help="Run tests matching pattern"),
):
    """Run all tests including database tests."""
    console.print("[cyan]Running all tests...[/cyan]")

    cmd = [sys.executable, "-m", "pytest", "tests/", "-v"]

    if not verbose:
        cmd.append("--tb=short")

    if pattern:
        cmd.extend(["-k", pattern])

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    raise typer.Exit(result.returncode)


@test_app.command("db")
def db_tests(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
):
    """Run only database tests."""
    console.print("[cyan]Running database tests...[/cyan]")

    cmd = [sys.executable, "-m", "pytest", "tests/", "-v", "-m", "db or postgres"]

    if not verbose:
        cmd.append("--tb=short")

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    raise typer.Exit(result.returncode)


@test_app.command("cov")
def coverage(
    html: bool = typer.Option(False, "--html", help="Generate HTML coverage report"),
    unit_only: bool = typer.Option(False, "--unit-only", help="Run only unit tests (no DB)"),
):
    """Run tests with coverage report (fail if below 70%)."""
    console.print("[cyan]Running tests with coverage...[/cyan]")

    cmd = [
        sys.executable,
        "-m",
        "pytest",
        "tests/",
        "-v",
        "--cov=app",
        "--cov-report=term-missing",
        "--cov-fail-under=50",
    ]

    if unit_only:
        cmd.extend(["-m", "not db and not postgres"])

    if html:
        cmd.append("--cov-report=html")

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)

    if html and result.returncode == 0:
        console.print("\n[green]✓[/green]  HTML report: [cyan]htmlcov/index.html[/cyan]")

    raise typer.Exit(result.returncode)


@test_app.command("watch")
def watch(
    pattern: str = typer.Option("", "--pattern", "-k", help="Run tests matching pattern"),
):
    """Run tests in watch mode (requires pytest-watch)."""
    console.print("[cyan]Running tests in watch mode...[/cyan]")
    console.print("[dim](Press Ctrl+C to stop)[/dim]\n")

    cmd = [
        sys.executable,
        "-m",
        "pytest_watch",
        "--",
        "-v",
        "--tb=short",
        "-m",
        "not db and not postgres",
    ]

    if pattern:
        cmd.extend(["-k", pattern])

    try:
        result = subprocess.run(cmd, cwd=PROJECT_ROOT)
        raise typer.Exit(result.returncode)
    except KeyboardInterrupt:
        console.print("\n[yellow]⚠[/yellow]  Watch mode stopped")
    except FileNotFoundError:
        console.print("[red]✗[/red]  pytest-watch not installed")
        console.print("   Install with: [cyan]pip install pytest-watch[/cyan]")
        raise typer.Exit(1)


# ── Plugin registration ──────────────────────────────────────────────────────


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register the test command group."""
    registry.add_typer_app(None, test_app, "test", "Testing commands")
