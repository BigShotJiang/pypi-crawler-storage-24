"""LSMC Atlas CLI — built on cli-core-yo.

Uses CliSpec + create_app() for standardised CLI scaffolding.
All command groups are registered as plugins via their ``register()`` functions.
"""

from __future__ import annotations

import os
from pathlib import Path

import yaml
from cli_core_yo.app import create_app, run
from cli_core_yo.spec import CliSpec, ConfigSpec, EnvSpec, PluginSpec, XdgSpec

from app.integrations.tapdb_runtime import (
    DEFAULT_AWS_PROFILE,
    DEFAULT_AWS_REGION,
    DEFAULT_TAPDB_DATABASE_NAME,
    TAPDB_REQUIRED_VERSION,
    TapDBRuntimeError,
    ensure_tapdb_version,
)

# ── Config validator ────────────────────────────────────────────────────────


def _validate_atlas_config(content: str) -> list[str]:
    """Validate LSMC Atlas configuration YAML.

    Returns a list of human-readable error strings (empty == valid).
    """
    try:
        config = yaml.safe_load(content)
    except yaml.YAMLError as exc:
        return [f"YAML parse error: {exc}"]

    if not isinstance(config, dict):
        return ["Root YAML object must be a mapping"]

    errors: list[str] = []

    # Required top-level sections
    for section in ("application", "database"):
        if section not in config or not config[section]:
            errors.append(f"Missing or empty required section: '{section}'")

    # database settings
    db = config.get("database") or {}
    if isinstance(db, dict):
        backend = str(db.get("backend", "tapdb")).strip().lower()
        if backend == "tapdb":
            target = str(db.get("target", "local")).strip().lower()
            if target not in {"local", "aurora"}:
                errors.append("database.target must be one of: local, aurora")
        elif not db.get("url"):
            errors.append("database.url is required when database.backend is not 'tapdb'")

    # authentication section sanity
    auth = config.get("authentication") or {}
    if isinstance(auth, dict):
        mode = auth.get("mode", "dev")
        if mode == "cognito":
            cognito = auth.get("cognito") or {}
            if not cognito.get("user_pool_id"):
                errors.append("authentication.cognito.user_pool_id is required when mode='cognito'")

    return errors


# ── Info hook ───────────────────────────────────────────────────────────────


def _atlas_info_hook() -> list[tuple[str, str]]:
    """Extra rows for the built-in ``info`` command."""
    rows: list[tuple[str, str]] = []

    # Project root
    project_root = Path(__file__).parent.parent.parent
    rows.append(("Project Root", str(project_root)))

    # Database URL (masked)
    db_url = os.environ.get("DATABASE_URL", "")
    if db_url:
        if "@" in db_url:
            parts = db_url.split("@")
            rows.append(("Database", f"...@{parts[-1]}"))
        else:
            rows.append(("Database", db_url))
    else:
        rows.append(("Database", "(not set)"))

    # Auth mode
    rows.append(("Auth Mode", os.environ.get("AUTH_MODE", "cognito")))

    # AWS
    rows.append(("AWS Profile", os.environ.get("AWS_PROFILE", DEFAULT_AWS_PROFILE)))
    rows.append(("AWS Region", os.environ.get("AWS_REGION", DEFAULT_AWS_REGION)))
    rows.append(
        ("TapDB Namespace", os.environ.get("TAPDB_DATABASE_NAME", DEFAULT_TAPDB_DATABASE_NAME))
    )
    rows.append(("TapDB Env", os.environ.get("TAPDB_ENV", "dev")))

    # Dev server status
    state_dir = Path.home() / ".lsmc-atlas"
    pid_file = state_dir / "server.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)
            rows.append(("Dev Server", f"Running (PID {pid})"))
        except (ValueError, ProcessLookupError, PermissionError):
            rows.append(("Dev Server", "Stopped"))
    else:
        rows.append(("Dev Server", "Stopped"))

    return rows


# ── Runtime guard ────────────────────────────────────────────────────────────


def _ensure_tapdb_dependency() -> None:
    """Fail fast when required TapDB dependency is missing or incorrect."""
    try:
        ensure_tapdb_version()
    except TapDBRuntimeError as exc:
        raise SystemExit(
            "Atlas CLI startup failed. "
            f"Install daylily-tapdb=={TAPDB_REQUIRED_VERSION} "
            "or use the supported local editable override. "
            f"Details: {exc}"
        ) from exc


_ensure_tapdb_dependency()


# ── CliSpec ─────────────────────────────────────────────────────────────────

spec = CliSpec(
    prog_name="atlas",
    app_display_name="LSMC Atlas",
    dist_name="lsmc-atlas",
    root_help="LSMC Atlas — Development CLI for the clinical sequencing customer portal.",
    xdg=XdgSpec(
        app_dir_name="lsmc-atlas",
    ),
    config=ConfigSpec(
        primary_filename="config.yaml",
        template_resource=("app", "etc/lsmc-atlas-config-template.yaml"),
        validator=_validate_atlas_config,
    ),
    env=EnvSpec(
        active_env_var="LSMC_ATLAS_ACTIVE",
        project_root_env_var="LSMC_ATLAS_PROJECT_ROOT",
        activate_script_name="atlas_activate",
        deactivate_script_name="atlas_deactivate",
    ),
    plugins=PluginSpec(
        explicit=[
            "app.cli.server.register",
            "app.cli.db.register",
            "app.cli.tapdb.register",
            "app.cli.test.register",
            "app.cli.quality.register",
            "app.cli.users.register",
            "app.cli.cognito.register",
            "app.cli.config_extra.register",
            "app.cli.certs.register",
            "app.cli.integrations.register",
        ],
    ),
    info_hooks=[_atlas_info_hook],
)

app = create_app(spec)


def main() -> None:
    """Main CLI entry point."""
    raise SystemExit(run(spec))
