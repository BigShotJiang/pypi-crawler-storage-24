# LSMC Atlas

LSMC Atlas is the customer-facing and organization-facing portal in this workspace.

It owns:

- authenticated web UI and tenant-scoped portal pages
- patient, clinician, organization, site, shipment, TRF, test, document, and support workflows
- API clients and user-token management
- storage policy authority for release targets
- integration seams to Bloom, Dewey, and Ursa

It does not own:

- wet-lab material state
- artifact registry identity
- analysis execution state
- core TapDB runtime lifecycle outside its own wrappers

## Runtime Shape

Primary package: `app`

Primary entrypoints:

- app entrypoint: `app.main:create_app`
- CLI command: `atlas`

Primary CLI groups:

- `atlas server`: start, stop, restart, status, logs, worker
- `atlas db`: build, seed, reset, nuke
- `atlas tapdb`: TapDB passthrough lifecycle commands
- `atlas integrations bloom`: config, verification, provisioning, polling
- `atlas users`, `atlas cognito`, `atlas certs`, `atlas quality`, `atlas test`

## Quick Start

```bash
conda env create -f atlas_env.yaml
source atlas_activate
atlas db build --target local
atlas certs install
atlas certs create
atlas server start --port 8915
```

`atlas server start --no-ssl` is available for quick local smoke runs, but the normal dev path is HTTPS.

## Core API Areas

Current API modules include:

- auth and session endpoints under `/auth`
- organization, site, patient, clinician, group, shipment, manifest, document, release, support, and audit routes under `/api/*`
- Bloom integration routes under `/api/integrations/bloom/v1/*`
- Dewey integration routes under `/api/integrations/dewey/v1/*`
- Ursa integration routes under `/api/integrations/ursa/v1/*`
- search under `/api/search/v2/*`
- graph explorer under `/api/graph/*`
- barcode, intake, fulfillment-run, webhook, and internal service routes

## Integration Boundaries

### Bloom

Atlas is the intake and fulfillment authority. It records accepted or rejected outcomes, then calls Bloom to create and advance physical material state.

Current Bloom-facing areas:

- intake outcomes
- Bloom accepted-material sync
- Bloom lookups
- Bloom status events and webhooks

See [docs/atlas_bloom_contract.md](docs/atlas_bloom_contract.md).

### Dewey and Ursa

Atlas exposes internal authenticated seams for:

- Dewey storage-target resolution
- Dewey release authorization
- Ursa return-target resolution
- Ursa analysis result return

Storage policy is persisted in Atlas and can be set at org scope with optional site override.

## Search and Graph

Atlas includes:

- unified search at `/search` and `/api/search/v2/*`
- a read-only graph explorer at `/graph` and `/api/graph/*`

See the focused docs for those features.

## Timezone Policy

- runtime and persisted timestamps are UTC
- display timezone is user-configurable via TapDB-backed `system_user` preferences
- canonical preference key: `display_timezone`

## Current Docs

- [Docs index](docs/README.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Atlas-Bloom contract](docs/atlas_bloom_contract.md)
- [Search V2](docs/SEARCH_V2.md)
- [Graph viewer](docs/GRAPH_VIEWER.md)
- [Authentication](docs/AUTHENTICATION.md)

Historical execution plans remain in `docs/` for background and migration context.

<!-- release-sweep: 2026-03-10 -->
 
