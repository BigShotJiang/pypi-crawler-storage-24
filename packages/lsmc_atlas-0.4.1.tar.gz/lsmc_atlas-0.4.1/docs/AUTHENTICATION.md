# Atlas Authentication Setup

Atlas uses AWS Cognito for authentication, sharing a User Pool with bloom
and daylily-ursa for consistent authentication across all three applications.

## Configuration

Create `~/.config/lsmc-atlas/config.yaml`:

```yaml
authentication:
  mode: cognito
  cognito:
    # Atlas stores only pool ID. Runtime region/client/domain are
    # resolved from daycog files by matching pool ID, preferring:
    #   ~/.config/daycog/<pool>.<region>.env
    #   ~/.config/daycog/<pool>.<region>.<app>.env
    #   ~/.config/daycog/default.env
    user_pool_id: us-east-1_examplePoolId

  # Allowed email domains for authentication
  # Empty list blocks all domains. Use ["*"] to allow all domains.
  allowed_email_domains:
    - lsmc.bio
    - lsmc.com
    - lsmc.life
    - daylilyinformatics.com
    - dyly.bio

  # Map Cognito groups to roles
  group_role_map:
    admin: ADMIN
    analysts: ANALYST
    viewers: VIEWER
```

Create or sync the pool config with daycog (via Atlas wrapper):
Advanced flags shown below require `daycog >= 0.1.24`.

```bash
source ../../daylily/daylily-cognito/daycog_activate
export AWS_PROFILE=lsmc
export AWS_REGION=us-east-1
atlas cognito build --pool-name lsmc-atlas-gui-users \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --client-name lsmc-atlas-gui-client \
  --domain-prefix lsmc-atlas-gui-users \
  --attach-domain \
  --callback-url https://localhost:8915/auth/callback \
  --logout-url https://localhost:8915/

# One-shot pool + app + Google IdP setup
atlas cognito setup-with-google --pool-name lsmc-atlas-gui-users \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --client-name lsmc-atlas-gui-client \
  --domain-prefix lsmc-atlas-gui-users \
  --attach-domain \
  --callback-url https://localhost:8915/auth/callback \
  --google-client-json /path/to/google_client.json

# Manage additional app clients in the same pool
atlas cognito list-apps
atlas cognito add-app --app-name lsmc-atlas-gui-v2 \
  --callback-url https://localhost:8915/auth/callback
atlas cognito edit-app --app-name lsmc-atlas-gui-v2 --set-default
atlas cognito remove-app --app-name lsmc-atlas-gui-v2 --force
atlas cognito add-google-idp --app-name lsmc-atlas-gui-client \
  --google-client-json /path/to/google_client.json
```

## Roles

| Role | Description |
|------|-------------|
| `ADMIN` | System administrator — full access across all tenants |
| `INTERNAL_USER` | LSMC staff — intake, matching, results, cross-tenant views |
| `EXTERNAL_USER_ADMIN` | Org admin — manage users/tokens/settings within own tenant |
| `EXTERNAL_USER` | Clinic/collaborator — tenant-scoped ordering, patient, shipment access |
| `READ_WRITE` | Modifier role — combined with EXTERNAL_USER for data entry |
| `READ_ONLY` | Viewer role — combined with EXTERNAL_USER for read-only access |

### Cognito Group → Role Mapping (defaults)

| Cognito Group | Atlas Roles |
|---------------|-------------|
| `lsmc-admins` | `ADMIN` |
| `lsmc-staff` | `INTERNAL_USER` |
| `lsmc-customers` | `EXTERNAL_USER` |
| `lsmc-customer-admins` | `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN` |
| `customer-admins` | `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN` |

These defaults are in `app/settings.py` under `DEFAULT_COGNITO_GROUP_ROLE_MAP`.

## API Token Scopes

API tokens have a `scope` field that constrains the token's effective permissions regardless of the user's actual roles. See [TOKEN_SCOPES.md](TOKEN_SCOPES.md) for full reference.

## Running the Server

```bash
# Start in foreground
atlas server start

# Start in background
atlas server start --background

# Stop server
atlas server stop

# View logs
atlas server logs
```

## Shared Cognito Pool

All three applications (lsmc-atlas, bloom, daylily-ursa) share a single Cognito User Pool:

- **Pool ID:** `us-west-2_pUqKyIM1N`
- **Region:** `us-west-2`
- **Domain:** `lsmc-shared-dev-puqkyim1n.auth.us-west-2.amazoncognito.com`

This ensures users can authenticate with the same credentials across all applications.

## Email Domain Restrictions

Authentication is restricted to the following allowed email domains:
- lsmc.bio
- lsmc.com
- lsmc.life
- daylilyinformatics.com
- dyly.bio

To allow all domains, set `allowed_email_domains: ["*"]`
To block all domains (disable auth), set `allowed_email_domains: []`
To block specific domains, add them to `blocked_email_domains` (takes precedence over allowed list).

## See Also

- [daylily-cognito](https://github.com/Daylily-Informatics/daylily-cognito) - Shared auth library
- [bloom](https://github.com/Daylily-Informatics/bloom) - Bloom configuration
- [daylily-ursa](https://github.com/Daylily-Informatics/daylily-ursa) - URSA configuration
