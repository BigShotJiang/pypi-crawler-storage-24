# Atlas Bloom Tube + Kit/TRF Linking Execution Plan

## Scope
- Repository: `lsmc-atlas` only.
- Goal: add Atlas-side GUI workflows for Bloom tube creation with optional specimen, restore shipment add-specimen routes, and add test kit TRF link/tube actions.

## Plan
1. Extend Bloom bridge service
- Add a new Atlas flow that creates a Bloom container from `test_euid` and optional link fields.
- Allow optional `patient_euid`; when present, create/spec-link specimen; when absent, persist tube-only.
- Validate that `test_euid` resolves in tenant and that `shipment_euid` and `testkit_euid` are not both set.
- Persist external-object mappings + relations for Test and TRF always, plus optional Shipment/TestKit and optional specimen relations.
- Keep queue transitions out of this flow.

2. Restore shipment add-specimen UI endpoint
- Add `GET /shipments/{shipment_number}/add-specimen` form page.
- Add `POST /shipments/{shipment_number}/add-specimen` submit handler that defaults linkage to the selected shipment.
- Remove stale shipment detail actions that target removed biospecimen endpoints.

3. Add test kit TRF + tube workflows
- Add `POST /testkits/{testkit_id}/link-trf` and `POST /testkits/{testkit_id}/unlink-trf`.
- Persist relation as TapDB lineage edge `trf_contained_in_testkit`, idempotent add.
- Add `POST /testkits/{testkit_id}/create-bloom-tube` using the new bridge flow and auto-link TRF to kit.
- Render linked TRF list with unlink controls on kit detail page.

4. Update TRF test material form
- Allow optional patient for `/trfs/tests/{test_euid}/request-material`.
- Route uses the new bridge flow and supports optional shipment/testkit source linkage.

5. Tests
- Add route-level + behavior tests for shipment add-specimen and test kit link/tube actions.
- Add matrix checks for tube-only vs tube+specimen linking and source-link validation (`shipment`, `testkit`, both rejected).
- Add regression assertion that shipment detail no longer renders removed biospecimen HTMX endpoints.

## Constraints
- No schema migration.
- No Bloom repo/API contract changes.
- EUID-first linking and tenant scoping enforced in Atlas.
