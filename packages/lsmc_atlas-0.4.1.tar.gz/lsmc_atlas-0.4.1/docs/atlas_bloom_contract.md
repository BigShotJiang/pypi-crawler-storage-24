# Atlas Bloom Contract

Status: current beta contract
Date: 2026-03-08

## Atlas To Bloom

Atlas sends accepted material to Bloom with:

- Atlas tenant ID
- Atlas TRF EUID
- Atlas patient EUID
- Atlas Test EUIDs
- explicit Atlas test fulfillment item EUIDs
- optional shipment or test kit EUID context
- optional site routing context
- queue intent

Atlas does not send private UUIDs or hidden database identifiers.

## Bloom To Atlas

Bloom returns and Atlas stores:

- `container_euid`
- `specimen_euid`
- queue and status projections
- fulfillment-item-linked external object mappings
- run resolver output keyed by `run_euid + flowcell_id + lane + library_barcode`

Ingress queue transitions for accepted material are applied to `container_euid` (the lab-moving unit), not the specimen EUID.

Atlas stores Bloom material only as:

- external-object mappings
- container external-object relations back to TRFs, Tests, test fulfillment items, shipments, and test kits
- specimen external-object relations for patient + containment only

## Intake Outcomes

Atlas intake owns the customer-facing outcome:

- `ACCEPTED`
- `HOLD`
- `REJECTED`

Only `ACCEPTED` triggers Bloom material handoff.

## Effective Bloom Config

Atlas resolves Bloom config in this order:

1. enabled site config
2. enabled organization config
3. no config

The effective config source is shown on the Atlas Test material-request page.

## Resolver Output

Bloom returns:

- `sequenced_library_assignment_euid`
- `atlas_tenant_id`
- `atlas_trf_euid`
- `atlas_test_euid`
- `atlas_test_fulfillment_item_euid`

## Identifier Rules

- Public Atlas integration APIs use EUID fields only.
- TRF and Test EUIDs are the canonical public identities.
- Test fulfillment items are the canonical handoff and return unit.
- XIDs are lookup metadata only.
- Bloom private IDs and Atlas internal UUIDs are not part of the supported contract.
