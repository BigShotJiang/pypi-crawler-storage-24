# Atlas TRF/Test Cutover Status

Status: implemented
Date: 2026-03-08

## Live Product Shape

- Public Atlas web routes are ` /trfs* ` and ` /trfs/tests* `.
- Public Atlas APIs are keyed by opaque EUIDs, not UUIDs or sequential order numbers.
- Public ` /orders* ` is retired. There is no compatibility redirect or alias.
- TRFs and Tests are minted from TapDB-backed Atlas templates:
  - TRF: `atlas/requisition/trf/1.0/`
  - TRF revision: `atlas/requisition/trf-revision/1.0/`
  - Test: `atlas/requisition/test/1.0/`
  - Test revision: `atlas/requisition/test-revision/1.0/`
- Test kit detail no longer depends on retired containment-event queries.

## Current Authority Boundary

- Atlas owns organizations, sites, patients, clinicians, shipments, test kits, TRFs, Tests, intake outcomes, and customer-facing result projection.
- Bloom owns containers, specimens, queue state, lineage, pools, and sequencing runs.
- Atlas links Bloom-owned material through explicit external-object mappings and relations.

## Bloom Integration Model

- Bloom config can be stored at either scope:
  - organization
  - site
- Site config overrides organization config when enabled.
- If no enabled site config exists, Atlas falls back to the enabled organization config.
- Atlas exposes both CLI and web management for these settings.

## Test Workflow

- TRF detail shows each Test by Test EUID.
- Each Test EUID links to a dedicated Test detail page.
- The Test detail page supports:
  - patient linking
  - Bloom material request submission
  - linked Bloom material display
  - Test status display
  - effective Bloom config source display

## Hard Cuts

- No public `/orders` routes remain.
- No public `order_number` routing remains.
- No public API responses are keyed by Atlas internal UUIDs.
- No retired manifest-side biospecimen auto-create behavior remains.
- No retired test-kit containment-event dependency remains.

## Validation Focus

- test kit create redirects to a working detail page
- `/trfs*` works and `/orders*` is absent
- TRF detail shows clickable Test EUIDs
- Test detail loads by Test EUID
- Atlas intake records `ACCEPTED`, `HOLD`, or `REJECTED`
- accepted material uses the Bloom bridge and explicit external links
- org/site Bloom config resolution is deterministic
