# Zero-Compatibility Rename Refactor Plan (Atlas + Bloom + Ursa)

Date: 2026-03-09
Owner: Codex execution
Mode: Hard cut, no backward compatibility, no legacy aliases

## Scope

Implement a hard-cut terminology and contract refactor across Atlas, Bloom, and Ursa.

Canonical targets:
- Test catalog noun: `TestDefinition*`
- Fulfillment unit noun: `TestFulfillmentItem*`
- Runtime noun: `FulfillmentRun*` + `FulfillmentRunState` + `FulfillmentOutput*`
- TRF test route list field: `fulfillment_routes`
- Route code keys: `fulfillment_route_code`, `fulfillment_route_codes`
- Atlas/Bloom/Ursa contract key: `atlas_test_fulfillment_item_euid`

Semantic correction:
- `ResultsSet` becomes `TRF.test`-scoped (`test_euid`) and supports many sets per test.
- New output after publish creates a new draft set for that same test.
- UI term is “Release Bundle”; API object name remains `ResultsSet`.

## Non-negotiables applied

1. No redirects, aliases, dual fields, or compatibility shims.
2. Old route paths removed in same phase as replacement.
3. Old payload keys removed in same phase as replacement.
4. Dead code/tests/docs removed with each change group.

## Execution phases

### Phase 1: plan commit + baseline
- Commit this plan document first.
- Confirm baseline test gates are green before changing semantics.

### Phase 2: Atlas catalog/admin hard cut
- Rename service/repo/module/classes from `Assay*` to `TestDefinition*`.
- Replace `/admin/assays*` with `/admin/test-definitions*` only.
- Replace `lab_assay` term with `lab_method` in UI labels, metadata keys, and docs.
- Delete old admin templates/routes/tests/docs tied to `assays` naming.

Test gate:
- `pytest -q tests/test_test_definitions_tapdb_cutover.py tests/test_admin_test_definition_bloom_link.py tests/test_web_smoke.py`

### Phase 3: Atlas fulfillment-item hard cut
- Rename `TestProcessItem*` to `TestFulfillmentItem*` in service/repo/models/routes/tests.
- Replace fields with:
  - `atlas_test_fulfillment_item_euid`
  - `fulfillment_item_euids`
  - `container_test_fulfillment_items`
- Remove all process-item key variants and references.

Test gate:
- `pytest -q tests/test_test_fulfillment_items.py tests/test_bloom_tube_kit_linking_web.py tests/test_ursa_integration_api.py`

### Phase 4: Atlas runtime hard cut
- Rename runtime modules/types:
  - `AssayRun*` -> `FulfillmentRun*`
  - `AssayState` -> `FulfillmentRunState`
  - `AssayResult*` -> `FulfillmentOutput*`
  - `assay_state_machine` -> `fulfillment_state_machine`
- Replace `/api/assay-runs*` with `/api/fulfillment-runs*`.
- Update webhook/event payload keys (`fulfillment_run_id`, `fulfillment_run_count`, etc.).

Test gate:
- `pytest -q tests/test_fulfillment_runs_api.py tests/test_fulfillment_runs.py tests/test_fulfillment_state_machine.py tests/test_api_smoke.py`

### Phase 5: Atlas TRF/Test route-field hard cut
- Replace `fulfillment_route_code`/`fulfillment_route_codes` with `fulfillment_route_code`/`fulfillment_route_codes` where route semantics are intended.
- Canonical TRF test list field is `fulfillment_routes`.
- Remove legacy `assays` list fields and old route keys from API/UI/templates/tests.

Test gate:
- `pytest -q tests/test_trf_order_api.py tests/test_gui_object_creation_matrix.py tests/test_web_crud.py`

### Phase 6: ResultsSet semantics + Ursa return hard cut
- Remodel `ResultsSet` persistence/linkage around `test_euid`.
- Permit many `ResultsSet` rows per test lifecycle.
- On new output after publish for same test: create new draft set.
- Hard-cut Ursa return endpoint to:
  - `/api/integrations/ursa/v1/fulfillment-items/{fulfillment_item_euid}/analysis-results`
- Response keys:
  - `fulfillment_run_euid`
  - `fulfillment_output_euid`
- Remove old process-item endpoint and old assay response keys.

Test gate:
- `pytest -q tests/test_ursa_result_return_service.py tests/test_ursa_integration_api.py tests/test_fulfillment_runs_api.py`

### Phase 7: Bloom resolver/contract hard cut
- Rename resolver and bridge contract keys to `atlas_test_fulfillment_item_euid`.
- Rename relation/reference naming to fulfillment-item terminology.
- Remove old process-item keys from schemas/domain/API/tests/docs.

Bloom test gates:
- `pytest --no-cov -q tests/test_run_resolver.py tests/test_api_atlas_bridge.py tests/test_beta_cross_repo_smoke.py`
- `pytest --no-cov -q tests/test_gui_endpoints.py -k "assays or workflow or queue"`

### Phase 8: Ursa contract hard cut
- Consume new Bloom resolver key and Atlas endpoint path.
- Remove old process-item and assay return naming everywhere.

Ursa test gate:
- `pytest -q tests/test_result_return.py tests/test_bloom_resolver_client.py tests/test_analysis_ingest.py tests/test_analysis_store_relationships.py tests/test_route_coverage.py`

### Phase 9: Docs and test-surface convergence
- Update Atlas/Bloom/Ursa docs and READMEs to canonical terms only.
- Rename/delete retired tests and docs with no backward text left in active surfaces.

## Stop conditions

Stop and report immediately if:
- A semantic mismatch appears (especially ResultsSet scope/lifecycle).
- A required shared-library change blocks clean hard cut.
- Any fix would require compatibility aliasing to proceed.

## Reporting

After each phase:
- Record exact test command(s) run.
- Record pass/fail and failures.
- Summarize breaking changes and rename map updates.
