# Atlas -> TapDB Domain Mapping

Status: current beta guidance
Date: 2026-03-08

## Ownership

- Atlas owns customer-facing intent and process:
  - organizations
  - sites
  - patients
  - clinicians
  - shipments
  - test kits
  - TRFs
  - Tests
  - intake outcomes
  - customer-facing result projection
- Bloom owns physical material truth and wet-lab execution state.
- Atlas stores Bloom objects only through external-object mappings and explicit relations.

## Identifier Rules

- Public Atlas identity is always the TapDB EUID.
- EUIDs are opaque.
- XIDs are metadata only, never join truth.
- Public APIs must not leak internal UUIDs.

## Core TapDB Templates

| Atlas Entity | Template Code | Prefix | Notes |
|---|---|---|---|
| Organization | `atlas/core/organization/1.0/` | `RGX` | customer org authority |
| OrganizationRevision | `atlas/core/organization-revision/1.0/` | `RGR` | revision payload |
| Site | `atlas/core/site/1.0/` | `STX` | org child |
| SiteRevision | `atlas/core/site-revision/1.0/` | `STR` | revision payload |
| Patient | `atlas/people/patient/1.0/` | `PAT` | customer-facing patient |
| PatientRevision | `atlas/people/patient-revision/1.0/` | `PATR` | demographics and notes |
| Clinician | `atlas/people/clinician/1.0/` | `CLN` | provider/doctor record |
| ClinicianRevision | `atlas/people/clinician-revision/1.0/` | `CLNR` | contact and specialty |
| TRF | `atlas/requisition/trf/1.0/` | `TRF` | public requisition identity |
| TRFRevision | `atlas/requisition/trf-revision/1.0/` | `TRR` | TRF status and metadata |
| Test | `atlas/requisition/test/1.0/` | `TST` | child requested assay object |
| TestRevision | `atlas/requisition/test-revision/1.0/` | `TSR` | Test status and assay metadata |
| Shipment | `atlas/logistics/shipment/1.0/` | `SHP` | intake/shipping surface |
| ShipmentRevision | `atlas/logistics/shipment-revision/1.0/` | `SHPR` | addresses and tracking payload |
| TestKit | `atlas/logistics/test-kit/1.0/` | `KIT` | customer kit/package surface |
| TestKitRevision | `atlas/logistics/test-kit-revision/1.0/` | `KITR` | packaging/config metadata |
| Manifest | `atlas/logistics/manifest/1.0/` | `MAN` | intake paperwork metadata only |
| ManifestRevision | `atlas/logistics/manifest-revision/1.0/` | `MAR` | uploaded manifest items |
| Document | `atlas/logistics/document/1.0/` | `DOC` | shipment/TRF/customer documents |
| DocumentRevision | `atlas/logistics/document-revision/1.0/` | `DOCR` | metadata and tags |
| ExternalObject | `atlas/integration/external-object/1.0/` | `EXB` | Bloom object mapping |
| ExternalObjectRelation | `atlas/integration/external-object-relation/1.0/` | `EXR` | links Bloom objects to Atlas entities |
| Artifact | `atlas/delivery/artifact/1.0/` | `ART` | Atlas result artifact reference |
| ReleasePackage | `atlas/delivery/release-package/1.0/` | `RPK` | Atlas release grouping |
| ReleasePackageRevision | `atlas/delivery/release-package-revision/1.0/` | `RPKR` | release state and payload |

## Relationship Rules

- Organization -> Site
- Site -> Patient
- Site -> Clinician
- Site -> TRF
- Site -> Test
- Site -> Family
- Site -> Shipment
- Site -> TestKit
- Site -> SupportTicket
- Site -> APIClient
- Site -> WebhookSubscription
- Shipment -> TestKit
- TRF -> TRFRevision
- TRF -> Test
- Test -> TestRevision
- Patient <-> Test uses explicit lineage links with role metadata
- Atlas entity <-> Bloom entity uses ExternalObject + ExternalObjectRelation

## Site-Scoped Linkage Invariant

- Only `Site` and `OrganizationUser` link directly to `Organization`.
- Tenant-scoped object creation uses a shared site resolver:
  - one active site: auto-assign
  - multiple active sites: explicit site required
  - cross-tenant site assignment: rejected
- Organizations must always retain at least one active site.

## Bloom Config Projection

- Organization-level Bloom config is stored in Atlas.
- Site-level Bloom config is stored in Atlas.
- Effective Bloom config resolution is:
  1. enabled site config
  2. enabled organization config
  3. no config

## Tube + Collection Event Model

- Atlas does not own physical tube or specimen state. Bloom `container` and `specimen` objects remain authoritative.
- Atlas persists Bloom material linkage through TapDB `ExternalObject` and `ExternalObjectRelation` records.
- Atlas owns `CollectionEvent` as the patient-facing collection record created when an empty Bloom tube is filled with a patient specimen.
- Direct Atlas tube links can target any combination of:
  - `Test`
  - `Shipment`
  - `TestKit`
  - `Site`
- New patient linkage truth is:
  - `CollectionEvent -> Patient`
  - `Bloom container external object -> CollectionEvent`
  - `Bloom specimen external object -> CollectionEvent`
- Atlas no longer treats direct specimen-to-patient linkage as the primary write path for new tube fills.
- Collection-event metadata mirrored to Bloom includes:
  - `collected_at`
  - `site_euid`
  - `collection_type`
  - `collected_by`
  - expected verification values such as MRN, DOB, name, and label text

## Retired Shapes

- `Order` / `TestOrder` naming is retired from the public Atlas surface.
- `atlas/ordering/order/*` and `atlas/ordering/test-order/*` are not the live Atlas TRF/Test templates.
- Atlas is not authoritative for biospecimens, containers, or Bloom queue state.
