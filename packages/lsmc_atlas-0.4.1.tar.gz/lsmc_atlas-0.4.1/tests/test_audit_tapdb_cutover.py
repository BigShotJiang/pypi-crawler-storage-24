"""Unit tests for TapDB cutover behavior in AuditService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from types import SimpleNamespace

from app.domain.services.audit import AuditFilter, AuditService
from app.persistence.tapdb.orm_models.events import AuditAction


@dataclass
class _MockDB:
    pass


class _FakeAuditRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.event = SimpleNamespace(
            euid=f"ADE-{uuid.uuid4().int % 10000}",
            tenant_id=tenant_id,
            user_id=uuid.uuid4(),
            action=AuditAction.CREATE.value,
            entity_type="ORDER",
            entity_id=uuid.uuid4(),
            details={"k": "v"},
            ip_address="127.0.0.1",
            user_agent="pytest",
            created_at=datetime.now(UTC),
        )

    def list_events(
        self,
        tenant_id,
        action=None,
        entity_type=None,
        entity_id=None,
        user_id=None,
        date_from=None,
        date_to=None,
        skip=0,
        limit=100,
    ):
        self.calls.append("list_events")
        return [self.event]

    def create_event(
        self,
        tenant_id,
        user_id,
        action,
        entity_type,
        entity_id,
        details,
        ip_address,
        user_agent,
    ):
        self.calls.append("create_event")
        self.event.action = action
        self.event.entity_type = entity_type
        self.event.entity_id = entity_id
        self.event.details = details
        self.event.user_id = user_id
        self.event.ip_address = ip_address
        self.event.user_agent = user_agent
        return self.event

    def count_events(
        self,
        tenant_id,
        action=None,
        entity_type=None,
        entity_id=None,
        user_id=None,
        date_from=None,
        date_to=None,
    ):
        self.calls.append("count_events")
        return 5


def test_audit_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = AuditService(_MockDB(), tenant_id=tenant_id, user_id=str(uuid.uuid4()))
    repo = _FakeAuditRepo(tenant_id)

    monkeypatch.setattr(svc, "_repo", lambda: repo)

    listed = svc.list_events(
        filter=AuditFilter(action=AuditAction.CREATE.value),
        skip=0,
        limit=10,
    )
    assert len(listed) == 1
    assert listed[0].action == AuditAction.CREATE.value

    logged = svc.log(
        action=AuditAction.UPDATE,
        entity_type="ORDER",
        entity_id=uuid.uuid4(),
        details={"status": "UPDATED"},
        user_id=uuid.uuid4(),
        ip_address="10.0.0.1",
        user_agent="pytest-agent",
    )
    assert logged.action == AuditAction.UPDATE.value

    count = svc.count(filter=AuditFilter(entity_type="ORDER"))
    assert count == 5

    entity_events = svc.get_for_entity("ORDER", uuid.uuid4(), limit=5)
    assert len(entity_events) == 1

    assert repo.calls == [
        "list_events",
        "create_event",
        "count_events",
        "list_events",
    ]
