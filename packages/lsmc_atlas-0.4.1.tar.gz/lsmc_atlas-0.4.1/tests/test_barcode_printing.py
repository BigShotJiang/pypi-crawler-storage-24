"""Tests for barcode printing service."""

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def simple_client() -> TestClient:
    """Create a test client without DB dependencies."""
    with TestClient(app) as c:
        yield c


class TestBarcodePrintingService:
    """Tests for BarcodePrintService."""

    def test_service_available_flag_when_not_installed(self):
        """Test that ZEBRA_DAY_AVAILABLE is False when zebra_day is not installed."""
        from app.domain.services.barcode_printing import ZEBRA_DAY_AVAILABLE

        # In test env, zebra_day is typically not installed
        # This test verifies the graceful degradation works
        assert isinstance(ZEBRA_DAY_AVAILABLE, bool)

    def test_service_is_available_method(self):
        """Test is_available method returns expected value."""
        from app.domain.services.barcode_printing import (
            ZEBRA_DAY_AVAILABLE,
            BarcodePrintService,
        )

        service = BarcodePrintService(db=None, tenant_id=None)
        assert service.is_available() == ZEBRA_DAY_AVAILABLE

    def test_entity_type_enum_values(self):
        """Test EntityType enum has expected values."""
        from app.domain.services.barcode_printing import EntityType

        assert EntityType.TESTKIT.value == "TestKit"
        assert EntityType.SHIPMENT.value == "Shipment"
        assert EntityType.MANIFEST.value == "Manifest"

    def test_label_type_enum_values(self):
        """Test LabelType enum has expected values."""
        from app.domain.services.barcode_printing import LabelType

        assert LabelType.TUBE_2IN_X_1IN.value == "tube_2inX1in"
        assert LabelType.TUBE_2IN_X_03IN.value == "tube_2inX0.3in"
        assert LabelType.PLATE_1IN_X_025IN.value == "plate_1inX0.25in"

    def test_print_request_dataclass(self):
        """Test PrintRequest dataclass creation."""
        from app.domain.services.barcode_printing import EntityType, PrintRequest

        request = PrintRequest(
            entity_type=EntityType.TESTKIT,
            entity_id="TK-001",
            barcode="TK-001-BARCODE",
            label_type="tube_2inX1in",
        )
        assert request.entity_type == EntityType.TESTKIT
        assert request.barcode == "TK-001-BARCODE"
        assert request.copies == 1  # Default


@pytest.mark.db
class TestBarcodeAPI:
    """Tests for barcode API endpoints."""

    def test_barcode_status_endpoint(self, simple_client: TestClient):
        """Test GET /api/barcode/status returns status info."""
        response = simple_client.get("/api/barcode/status")
        # Auth required, but should not error on the route itself
        assert response.status_code in (200, 401, 403)

    def test_barcode_printers_endpoint_requires_auth(self, simple_client: TestClient):
        """Test GET /api/barcode/printers requires authentication."""
        response = simple_client.get("/api/barcode/printers")
        assert response.status_code in (401, 403)


class TestBarcodePrintRequest:
    """Tests for barcode print request schemas."""

    def test_print_request_schema_validation(self):
        """Test that print request schema validates correctly."""
        from app.api.routes.barcode import PrintLabelRequest

        # Valid request with required fields
        req = PrintLabelRequest(
            entity_type="TestKit",
            entity_id="TK-001",
            barcode="TK-001-BARCODE",
            label_type="tube_2inX1in",
            copies=2,
        )
        assert req.copies == 2
        assert req.entity_type == "TestKit"

    def test_print_request_defaults(self):
        """Test that print request has sensible defaults."""
        from app.api.routes.barcode import PrintLabelRequest

        req = PrintLabelRequest(
            entity_type="TestKit",
            entity_id="TK-001",
            barcode="TK-001-BC",
        )
        assert req.label_type == "tube_2inX1in"
        assert req.copies == 1
        assert req.lab == "lsmc-lab"
