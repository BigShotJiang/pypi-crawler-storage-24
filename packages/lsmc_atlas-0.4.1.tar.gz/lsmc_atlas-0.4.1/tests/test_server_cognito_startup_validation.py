"""Tests for Cognito startup-time validation in atlas server CLI."""

from __future__ import annotations

from types import SimpleNamespace
from urllib.parse import urlencode

import pytest
import typer

from app.auth import cognito as cognito_auth
from app.cli import server


def _mock_ok_validation(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        server,
        "validate_cognito_uri_ports",
        lambda **_kwargs: SimpleNamespace(ok=True, warnings=[], issues=[]),
    )
    monkeypatch.setattr(
        server,
        "validate_cognito_app_client_name",
        lambda **_kwargs: SimpleNamespace(ok=True, warnings=[], issues=[]),
    )
    monkeypatch.setattr(server, "_validate_generated_login_authorize_url", lambda _port: [])


def _set_min_cognito_settings(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(server.settings, "auth_mode", "cognito", raising=False)
    monkeypatch.setattr(server.settings, "cognito_user_pool_id", "us-east-1_pool123", raising=False)
    monkeypatch.setattr(server.settings, "cognito_app_client_id", "client-123", raising=False)
    monkeypatch.setattr(server.settings, "cognito_region", "us-east-1", raising=False)
    monkeypatch.setattr(server.settings, "cognito_aws_profile", "lsmc", raising=False)
    monkeypatch.setattr(
        server.settings, "cognito_domain", "example.auth.us-east-1.amazoncognito.com", raising=False
    )
    monkeypatch.setattr(
        server.settings,
        "cognito_logout_url",
        "https://localhost:8915/",
        raising=False,
    )
    monkeypatch.setattr(
        server.settings,
        "cognito_redirect_uri",
        "https://localhost:8915/auth/callback",
        raising=False,
    )


def test_validate_generated_login_authorize_url_requires_redirect_uri(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _build_login_url(**_kwargs: object) -> str:
        return "https://example.auth.us-east-1.amazoncognito.com/oauth2/authorize?client_id=abc&response_type=code"

    monkeypatch.setattr(
        cognito_auth,
        "build_login_url",
        _build_login_url,
    )

    issues = server._validate_generated_login_authorize_url(8915)
    assert any("redirect_uri" in issue for issue in issues)


def test_validate_generated_login_authorize_url_flags_local_port_mismatch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    query = urlencode(
        {
            "client_id": "abc",
            "response_type": "code",
            "redirect_uri": "https://localhost:8912/auth/callback",
        }
    )

    def _build_login_url(**_kwargs: object) -> str:
        return f"https://example.auth.us-east-1.amazoncognito.com/oauth2/authorize?{query}"

    monkeypatch.setattr(
        cognito_auth,
        "build_login_url",
        _build_login_url,
    )

    issues = server._validate_generated_login_authorize_url(8915)
    assert any("does not match Atlas server port 8915" in issue for issue in issues)


def test_validate_generated_login_authorize_url_passes_for_matching_port(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    query = urlencode(
        {
            "client_id": "abc",
            "response_type": "code",
            "redirect_uri": "https://localhost:8915/auth/callback",
        }
    )

    def _build_login_url(**_kwargs: object) -> str:
        return f"https://example.auth.us-east-1.amazoncognito.com/oauth2/authorize?{query}"

    monkeypatch.setattr(
        cognito_auth,
        "build_login_url",
        _build_login_url,
    )

    issues = server._validate_generated_login_authorize_url(8915)
    assert issues == []


def test_server_startup_validation_fails_when_redirect_uri_setting_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _set_min_cognito_settings(monkeypatch)
    _mock_ok_validation(monkeypatch)
    monkeypatch.setattr(server.settings, "cognito_redirect_uri", "", raising=False)

    with pytest.raises(typer.Exit):
        server._validate_cognito_uris_for_server_port(8915)
