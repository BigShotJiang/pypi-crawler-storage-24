"""API tests for org-admin storage policy management surfaces."""

from __future__ import annotations

from collections.abc import Generator

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import get_current_user
from app.db.engine import get_db
from app.domain.services.orgs import OrganizationService, SiteService
from app.main import app

pytestmark = pytest.mark.db


@pytest.fixture
def org_admin_client(db_session, admin_user) -> Generator[TestClient, None, None]:
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_current_user():
        return admin_user

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user

    with TestClient(app) as client:
        yield client

    app.dependency_overrides.clear()


def test_org_and_site_storage_policy_crud_flow(org_admin_client, db_session, admin_user):
    org = OrganizationService(db_session).get_by_uid(admin_user.tenant_id)
    assert org is not None
    site = SiteService(db_session).list_by_organization(org.euid, active_only=False)[0]

    put_org = org_admin_client.put(
        f"/api/organizations/{org.euid}/storage-policy",
        json={
            "bucket": "org-policy-bucket",
            "region": "us-west-2",
            "base_prefix": "orgbase",
            "access_mode": "lsmc_managed",
            "enabled": True,
        },
    )
    assert put_org.status_code == 200, put_org.text
    org_body = put_org.json()
    assert org_body["storage_policy_scope"] == "organization"
    assert org_body["bucket"] == "org-policy-bucket"

    get_org = org_admin_client.get(f"/api/organizations/{org.euid}/storage-policy")
    assert get_org.status_code == 200, get_org.text
    assert get_org.json()["storage_policy_euid"] == org_body["storage_policy_euid"]

    put_site = org_admin_client.put(
        f"/api/organizations/{org.euid}/sites/{site.euid}/storage-policy",
        json={
            "bucket": "site-policy-bucket",
            "region": "us-east-1",
            "base_prefix": "sitebase",
            "access_mode": "customer_bucket",
            "enabled": True,
        },
    )
    assert put_site.status_code == 200, put_site.text
    site_body = put_site.json()
    assert site_body["storage_policy_scope"] == "site"
    assert site_body["bucket"] == "site-policy-bucket"

    effective_site = org_admin_client.get(
        f"/api/organizations/{org.euid}/storage-policy/effective",
        params={"site_euid": site.euid},
    )
    assert effective_site.status_code == 200, effective_site.text
    assert effective_site.json()["storage_policy_scope"] == "site"

    clear_site = org_admin_client.delete(
        f"/api/organizations/{org.euid}/sites/{site.euid}/storage-policy"
    )
    assert clear_site.status_code == 204, clear_site.text

    effective_after_clear = org_admin_client.get(
        f"/api/organizations/{org.euid}/storage-policy/effective",
        params={"site_euid": site.euid},
    )
    assert effective_after_clear.status_code == 200, effective_after_clear.text
    assert effective_after_clear.json()["storage_policy_scope"] == "organization"
