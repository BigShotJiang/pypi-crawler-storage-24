"""Tests for Atlas Dewey integration storage/authorization seams."""

from __future__ import annotations

import uuid

import pytest

from app.domain.services.orgs import OrganizationService, SiteService
from app.domain.services.storage_policies import StoragePolicyService, StoragePolicyUpsert

pytestmark = pytest.mark.db


def test_storage_target_requires_internal_api_key(client):
    response = client.post(
        "/api/integrations/dewey/v1/storage-targets/resolve",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "scope": "patient",
            "filename": "upload.pdf",
            "atlas_patient_euid": "PAT-1",
        },
    )
    assert response.status_code == 401


def test_storage_target_resolves_test_scope_path(internal_client, db_session, tenant_id):
    org = OrganizationService(db_session).get_by_uid(uuid.UUID(str(tenant_id)))
    assert org is not None
    sites = SiteService(db_session).list_by_organization(org.euid, active_only=False)
    assert sites
    site = sites[0]

    policy = StoragePolicyService(db_session).upsert_org_policy(
        organization_euid=org.euid,
        data=StoragePolicyUpsert(
            bucket="atlas-org-bucket",
            region="us-west-2",
            base_prefix="beta",
            access_mode="lsmc_managed",
            enabled=True,
        ),
        actor_id=None,
    )

    payload = {
        "atlas_tenant_id": str(tenant_id),
        "scope": "test",
        "filename": "result.vcf.gz",
        "atlas_site_euid": site.euid,
        "atlas_trf_euid": "TRF-1",
        "atlas_test_euid": "TEST-1",
    }
    response = internal_client.post(
        "/api/integrations/dewey/v1/storage-targets/resolve",
        json=payload,
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["atlas_tenant_id"] == str(tenant_id)
    assert body["organization_euid"] == org.euid
    assert body["storage_policy_euid"] == policy.policy_euid
    assert body["storage_policy_scope"] == "organization"
    assert body["bucket"] == "atlas-org-bucket"
    assert body["key"] == f"beta/sites/{site.euid}/trfs/TRF-1/tests/TEST-1/result.vcf.gz"
    assert (
        body["storage_uri"]
        == f"s3://atlas-org-bucket/beta/sites/{site.euid}/trfs/TRF-1/tests/TEST-1/result.vcf.gz"
    )
    assert body["access_mode"] == "lsmc_managed"


def test_release_authorization_rejects_empty_context(internal_client, tenant_id):
    response = internal_client.post(
        "/api/integrations/dewey/v1/authorizations/release",
        json={"atlas_tenant_id": str(tenant_id)},
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["authorized"] is False
    assert "required" in body["reason"].lower()


def test_release_authorization_rejects_unknown_test(internal_client, tenant_id):
    response = internal_client.post(
        "/api/integrations/dewey/v1/authorizations/release",
        json={
            "atlas_tenant_id": str(tenant_id),
            "atlas_test_euid": "TEST-DOES-NOT-EXIST",
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["authorized"] is False
    assert "test not found" in body["reason"].lower()
