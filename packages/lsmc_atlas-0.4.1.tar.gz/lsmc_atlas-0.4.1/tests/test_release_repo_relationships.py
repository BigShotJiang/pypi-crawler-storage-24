"""Regression tests for TapDB release package relationship storage."""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy.orm import Session

from app.domain.services.releases import ArtifactCreate, ReleaseService
from app.persistence.tapdb.euid_helpers import get_instance_by_euid
from app.persistence.tapdb.releases_repo import (
    RELEASE_ARTIFACT_TEMPLATE_CODE,
    RELEASE_PACKAGE_REV_TEMPLATE_CODE,
    TapdbReleaseRepository,
)


@pytest.mark.db
def test_release_revision_artifacts_are_derived_from_reference_objects(db_session: Session):
    repo = TapdbReleaseRepository(db_session)
    tenant_id = uuid.uuid4()
    package, revision = repo.create_package(
        tenant_id=tenant_id,
        package_number="REL-9001",
        data=type(
            "ReleaseData",
            (),
            {"order_id": None, "artifact_ids": ["ART-1", "ART-2"], "release_notes": "beta"},
        )(),
        created_by=None,
    )

    latest = repo.get_latest_revision(package.euid)
    assert latest is not None
    assert latest.artifact_ids == ["ART-1", "ART-2"]

    stored = get_instance_by_euid(db_session, RELEASE_PACKAGE_REV_TEMPLATE_CODE, revision.euid)
    props = repo._instance_properties(stored)
    assert "artifact_ids" not in props
    assert latest.release_package_id == package.euid


@pytest.mark.db
def test_release_service_registers_artifact_via_tapdb_when_orm_table_is_missing(
    db_session: Session,
):
    tenant_id = uuid.uuid4()
    service = ReleaseService(db_session, tenant_id)

    created = service.register_artifact(
        ArtifactCreate(
            source_system="daylily-ursa",
            source_uid="analysis:artifact-1",
            filename="report.pdf",
            checksum="abc123",
            artifact_type="report_pdf",
            s3_bucket="beta-smoke-bucket",
            s3_key="RUN-1/report.pdf",
            metadata={"analysis_euid": "AN-1"},
        ),
        created_by=None,
    )

    assert created.euid.startswith("ART-")
    assert created.filename == "report.pdf"

    fetched = service.get_artifact_by_source("daylily-ursa", "analysis:artifact-1")
    assert fetched is not None
    assert fetched.euid == created.euid

    stored = get_instance_by_euid(db_session, RELEASE_ARTIFACT_TEMPLATE_CODE, created.euid)
    assert stored is not None
    props = TapdbReleaseRepository(db_session)._instance_properties(stored)
    assert props["source_system"] == "daylily-ursa"
    assert props["source_uid"] == "analysis:artifact-1"
    assert "order_id" not in props
    assert "fulfillment_run_id" not in props
