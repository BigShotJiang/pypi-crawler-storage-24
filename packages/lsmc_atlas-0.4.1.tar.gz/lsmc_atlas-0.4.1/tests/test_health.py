"""Tests for health check endpoint."""

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client() -> TestClient:
    """Create a test client."""
    return TestClient(app)


def test_health_check(client: TestClient) -> None:
    """Test that health check returns 200 OK."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "version" in data


def test_health_check_version(client: TestClient) -> None:
    """Test that health check returns correct version."""
    from app import __version__

    response = client.get("/health")
    data = response.json()
    assert data["version"] == __version__
