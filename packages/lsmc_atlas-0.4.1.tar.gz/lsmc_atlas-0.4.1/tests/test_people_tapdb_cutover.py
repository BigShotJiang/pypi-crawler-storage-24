"""Unit tests for TapDB cutover behavior in people services."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, date, datetime
from types import SimpleNamespace

from app.domain.services.people import (
    ClinicianCreate,
    ClinicianService,
    ClinicianUpdate,
    PatientCreate,
    PatientService,
)


@dataclass
class _MockDB:
    def add(self, _obj):
        return None

    def commit(self):
        return None


class _FakePeopleRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.tenant_id = tenant_id

        self.patient = SimpleNamespace(
            id=uuid.uuid4(),
            tenant_id=tenant_id,
            created_at=datetime.now(UTC),
            euid="PAT-001",
        )
        self.patient_revision = SimpleNamespace(
            revision_id=uuid.uuid4(),
            patient_id=self.patient.euid,
            revision_no=1,
            first_name="Alice",
            last_name="Patient",
            middle_name=None,
            date_of_birth=date(1990, 1, 1),
            sex="F",
            mrn="MRN-1",
            email="alice@example.com",
            phone="555-0100",
            address={"city": "Seattle", "state": "WA"},
            family_relationships={},
            clinical_notes=None,
        )

        self.clinician = SimpleNamespace(
            id=uuid.uuid4(),
            tenant_id=tenant_id,
            created_at=datetime.now(UTC),
            euid="CLN-001",
        )
        self.clinician_revision = SimpleNamespace(
            revision_id=uuid.uuid4(),
            clinician_id=self.clinician.euid,
            revision_no=1,
            first_name="Chris",
            last_name="Doctor",
            credentials="MD",
            npi="12345",
            specialty="Oncology",
            email="doc@example.com",
            phone="555-0200",
            fax=None,
            addresses=None,
            site_id=None,
            is_active=True,
        )

    # Patient methods
    def create_patient(self, tenant_id, data, created_by):
        self.calls.append("create_patient")
        self.patient_revision.first_name = data.first_name
        self.patient_revision.last_name = data.last_name
        self.patient_revision.date_of_birth = data.date_of_birth
        self.patient_revision.address = data.address
        self.patient_revision.mrn = data.mrn
        return self.patient, self.patient_revision

    def get_patient_with_revision(self, patient_id, tenant_id):
        self.calls.append("get_patient_with_revision")
        if patient_id != self.patient.euid:
            return None
        return self.patient, self.patient_revision

    def list_patients(self, tenant_id, limit=100, offset=0):
        self.calls.append("list_patients")
        return [(self.patient, self.patient_revision)]

    def search_patients_by_mrn(self, mrn, tenant_id):
        self.calls.append("search_patients_by_mrn")
        if self.patient_revision.mrn == mrn:
            return [(self.patient, self.patient_revision)]
        return []

    def search_patients_by_name(self, name, tenant_id, limit=100):
        self.calls.append("search_patients_by_name")
        return [(self.patient, self.patient_revision)]

    def update_patient(self, patient_id, data, updated_by, tenant_id):
        self.calls.append("update_patient")
        if data.address is not None:
            self.patient_revision.address = data.address
        return self.patient, self.patient_revision

    # Clinician methods
    def create_clinician(self, tenant_id, data, created_by):
        self.calls.append("create_clinician")
        self.clinician_revision.first_name = data.first_name
        self.clinician_revision.last_name = data.last_name
        self.clinician_revision.npi = data.npi
        return self.clinician, self.clinician_revision

    def get_clinician_with_revision(self, clinician_id, tenant_id):
        self.calls.append("get_clinician_with_revision")
        if clinician_id != self.clinician.euid:
            return None
        return self.clinician, self.clinician_revision

    def list_clinicians(self, tenant_id, skip=0, limit=100, active_only=True):
        self.calls.append("list_clinicians")
        return [(self.clinician, self.clinician_revision)]

    def get_clinician_by_npi(self, npi, tenant_id):
        self.calls.append("get_clinician_by_npi")
        if self.clinician_revision.npi == npi:
            return self.clinician, self.clinician_revision
        return None

    def search_clinicians_by_name(self, name, tenant_id, limit=100):
        self.calls.append("search_clinicians_by_name")
        return [(self.clinician, self.clinician_revision)]

    def update_clinician(self, clinician_id, data, updated_by, tenant_id):
        self.calls.append("update_clinician")
        if data.specialty is not None:
            self.clinician_revision.specialty = data.specialty
        return self.clinician, self.clinician_revision


def test_people_services_delegate_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    repo = _FakePeopleRepo(tenant_id)

    patient_svc = PatientService(_MockDB(), tenant_id=tenant_id)
    clinician_svc = ClinicianService(_MockDB(), tenant_id=tenant_id)

    monkeypatch.setattr(
        "app.domain.services.site_scope.resolve_tenant_site_euid",
        lambda _db, _tenant_id, site_euid, **_kwargs: site_euid or "STX-TEST",
    )
    monkeypatch.setattr(patient_svc, "_repo", lambda: repo)
    monkeypatch.setattr(clinician_svc, "_repo", lambda: repo)

    created_patient = patient_svc.create(
        PatientCreate(
            first_name="Alice",
            last_name="Patient",
            date_of_birth=date(1990, 1, 1),
            mrn="MRN-1",
            address_line1="123 Main",
            city="Seattle",
            state="WA",
        )
    )
    assert created_patient[0].euid == repo.patient.euid

    assert patient_svc.get(repo.patient.euid) is not None
    assert len(patient_svc.list_patients(limit=10)) == 1
    assert patient_svc.get_by_mrn("MRN-1") is not None
    assert len(patient_svc.search_by_name("Ali")) == 1

    updated_patient = patient_svc.update(
        repo.patient.euid,
        {
            "address_line1": "456 New",
            "city": "Portland",
            "state": "OR",
        },
    )
    assert updated_patient is not None
    assert updated_patient[1].address["city"] == "Portland"

    created_clinician = clinician_svc.create(
        ClinicianCreate(
            first_name="Chris",
            last_name="Doctor",
            npi="12345",
            specialty="Oncology",
        )
    )
    assert created_clinician[0].euid == repo.clinician.euid

    assert clinician_svc.get(repo.clinician.euid) is not None
    assert len(clinician_svc.list_clinicians(limit=10)) == 1
    assert clinician_svc.get_by_npi("12345") is not None
    assert len(clinician_svc.search_by_name("Chris")) == 1

    updated_clinician = clinician_svc.update(
        repo.clinician.euid,
        ClinicianUpdate(specialty="Pathology"),
    )
    assert updated_clinician is not None
    assert updated_clinician[1].specialty == "Pathology"

    assert "create_patient" in repo.calls
    assert "update_patient" in repo.calls
    assert "create_clinician" in repo.calls
    assert "update_clinician" in repo.calls
