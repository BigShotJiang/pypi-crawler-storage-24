"""Repository guard: Atlas runtime code must not use direct Postgres tooling."""

from __future__ import annotations

import re
from pathlib import Path

FORBIDDEN_COMMAND_PATTERNS = {
    "psql": re.compile(r"\bpsql\b"),
    "pg_ctl": re.compile(r"\bpg_ctl\b"),
    "initdb": re.compile(r"\binitdb\b"),
    "createdb": re.compile(r"\bcreatedb\b"),
    "dropdb": re.compile(r"\bdropdb\b"),
    "pg_isready": re.compile(r"\bpg_isready\b"),
    "pg_dump": re.compile(r"\bpg_dump\b"),
    "pg_restore": re.compile(r"\bpg_restore\b"),
}

CHECK_PATHS = ("app", "atlas_activate")
TEXT_SUFFIXES = {".py", ".sh", ".bash", ".zsh"}
SUBPROCESS_CALL_PATTERN = re.compile(r"subprocess\.(?:run|Popen)\((.*?)\)", re.DOTALL)
POSTGRES_BINARY_ARG_PATTERN = re.compile(r"(['\"])postgres\1")


def _iter_files(repo_root: Path) -> list[Path]:
    files: list[Path] = []
    for entry in CHECK_PATHS:
        path = repo_root / entry
        if path.is_file():
            files.append(path)
            continue
        for candidate in path.rglob("*"):
            if candidate.is_file() and candidate.suffix in TEXT_SUFFIXES:
                files.append(candidate)
    return files


def test_no_direct_postgres_tool_commands_in_atlas_codebase():
    repo_root = Path(__file__).resolve().parents[1]
    offenders: list[str] = []

    for file_path in _iter_files(repo_root):
        content = file_path.read_text(encoding="utf-8")
        for label, pattern in FORBIDDEN_COMMAND_PATTERNS.items():
            if pattern.search(content):
                offenders.append(f"{file_path.relative_to(repo_root)} -> {label}")

    assert not offenders, "Found forbidden direct Postgres tooling references:\\n" + "\\n".join(
        offenders
    )


def test_no_direct_postgres_binary_invocation_in_subprocess_calls():
    repo_root = Path(__file__).resolve().parents[1]
    offenders: list[str] = []

    for file_path in _iter_files(repo_root):
        content = file_path.read_text(encoding="utf-8")
        for call in SUBPROCESS_CALL_PATTERN.findall(content):
            if POSTGRES_BINARY_ARG_PATTERN.search(call):
                offenders.append(f"{file_path.relative_to(repo_root)} -> postgres")

    assert not offenders, "Found direct postgres binary subprocess calls:\\n" + "\\n".join(
        offenders
    )
