"""Append-only behavior tests for TapDB-backed domain services."""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy.orm import Session

from app.domain.enums import OrderStatus
from app.domain.services.orgs import OrganizationService, OrganizationUpdate
from app.domain.services.people import PatientCreate, PatientService, PatientUpdate
from app.domain.services.trfs import TrfCreate, TrfService, TrfUpdate
from tests.tapdb_test_helpers import ensure_tapdb_org


def _create_patient(db_session: Session, tenant_uuid: uuid.UUID):
    return PatientService(db_session, tenant_uuid).create(
        PatientCreate(first_name="John", last_name="Doe"),
        created_by=uuid.uuid4(),
    )[0]


def _create_order(db_session: Session, tenant_uuid: uuid.UUID):
    order, _rev = TrfService(db_session, tenant_uuid).create(
        data=TrfCreate(order_type="CLINICAL"),
        tests=None,
        created_by=uuid.uuid4(),
    )
    return order, None


@pytest.mark.db
class TestIdentityTablesAppendOnly:
    """Identity objects keep stable IDs/created timestamps across revisions."""

    def test_organization_created_immutable(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid, name="append-org")
        svc = OrganizationService(db_session)

        # Look up org by UUID to get the EUID
        org_rec = svc.get_by_uid(tenant_uuid)
        assert org_rec is not None, "Org not found after ensure_tapdb_org"
        org_euid = org_rec.euid

        org_before, rev_before = svc.get_with_revision(org_euid)
        svc.update(
            org_euid,
            OrganizationUpdate(display_name="Append Org Updated"),
            updated_by=uuid.uuid4(),
        )
        org_after, rev_after = svc.get_with_revision(org_euid)

        assert org_after.uid == org_before.uid
        assert org_after.created_at == org_before.created_at
        assert rev_after.revision_no == rev_before.revision_no + 1

    def test_patient_created_immutable(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        svc = PatientService(db_session, tenant_uuid)

        patient_before, rev_before = svc.create(
            PatientCreate(first_name="Jane", last_name="Doe"),
            created_by=uuid.uuid4(),
        )
        patient_after, rev_after = svc.update(
            patient_before.euid,
            PatientUpdate(last_name="Smith"),
            updated_by=uuid.uuid4(),
        )

        assert patient_after.euid == patient_before.euid
        assert patient_after.created_at == patient_before.created_at
        assert rev_after.revision_no == rev_before.revision_no + 1

    def test_order_created_immutable(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        order_svc = TrfService(db_session, tenant_uuid)
        order_before, _ = _create_order(db_session, tenant_uuid)

        order_after, rev_after = order_svc.update(
            order_before.euid,
            TrfUpdate(indication="updated-indication"),
            updated_by=uuid.uuid4(),
        )

        assert order_after.euid == order_before.euid
        assert order_after.created_at == order_before.created_at
        assert rev_after.revision_no >= 2


@pytest.mark.db
class TestRevisionTablesAppendOnly:
    """Updates append revisions instead of mutating prior revision content."""

    def test_organization_revision_creates_new_row(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid, name="Org v1")
        svc = OrganizationService(db_session)

        # Look up org by UUID to get the EUID
        org_rec = svc.get_by_uid(tenant_uuid)
        assert org_rec is not None
        org_euid = org_rec.euid

        _, rev1 = svc.get_with_revision(org_euid)

        svc.update(
            org_euid,
            OrganizationUpdate(name="Org v2", org_type="hospital"),
            updated_by=uuid.uuid4(),
        )
        _, rev2 = svc.get_with_revision(org_euid)

        assert rev1.revision_no == 1
        assert rev2.revision_no == 2
        assert rev2.name == "Org v2"
        assert rev2.org_type == "hospital"

    def test_patient_revision_creates_new_row(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        svc = PatientService(db_session, tenant_uuid)

        patient, rev1 = svc.create(
            PatientCreate(first_name="John", last_name="Doe"),
            created_by=uuid.uuid4(),
        )
        _, rev2 = svc.update(
            patient.euid, PatientUpdate(last_name="Smith"), updated_by=uuid.uuid4()
        )
        _, rev3 = svc.update(
            patient.euid, PatientUpdate(last_name="Jones"), updated_by=uuid.uuid4()
        )

        assert rev1.revision_no == 1
        assert rev2.revision_no == 2
        assert rev3.revision_no == 3
        assert rev1.last_name == "Doe"
        assert rev2.last_name == "Smith"
        assert rev3.last_name == "Jones"

    def test_order_revision_creates_new_row(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        order_svc = TrfService(db_session, tenant_uuid)
        order, _ = _create_order(db_session, tenant_uuid)
        _, rev1 = order_svc.get(order.euid)

        _, rev2 = order_svc.change_status(
            order.euid, OrderStatus.SUBMITTED, reason="submit", updated_by=uuid.uuid4()
        )
        _, rev3 = order_svc.change_status(
            order.euid, OrderStatus.CANCELED, reason="cancel", updated_by=uuid.uuid4()
        )

        assert rev1.revision_no == 1
        assert rev2.revision_no == 2
        assert rev3.revision_no == 3
        assert rev2.status == OrderStatus.SUBMITTED.value
        assert rev3.status == OrderStatus.CANCELED.value


@pytest.mark.db
class TestPostgresDeleteTriggers:
    """Hard-delete operations are intentionally absent in TapDB service APIs."""

    def test_delete_organization_blocked(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        svc = OrganizationService(db_session)
        with pytest.raises(AttributeError):
            svc.delete(tenant_uuid)  # type: ignore[attr-defined]

    def test_delete_patient_blocked(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        svc = PatientService(db_session, tenant_uuid)
        patient = _create_patient(db_session, tenant_uuid)
        with pytest.raises(AttributeError):
            svc.delete(patient.euid)  # type: ignore[attr-defined]

    def test_delete_order_blocked(self, db_session: Session, tenant_id: str):
        tenant_uuid = uuid.UUID(tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        svc = TrfService(db_session, tenant_uuid)
        order, _ = _create_order(db_session, tenant_uuid)
        with pytest.raises(AttributeError):
            svc.delete(order.euid)  # type: ignore[attr-defined]
