from __future__ import annotations

from datetime import UTC, datetime

from app.web.templates import datetime_filter


def test_datetime_filter_converts_to_user_display_timezone():
    dt = datetime(2026, 1, 25, 15, 50, 16, tzinfo=UTC)
    rendered = datetime_filter(
        dt,
        {"datetime_format": "standard", "display_timezone": "America/Los_Angeles"},
    )
    assert rendered.startswith("2026-01-25 07:50:16")


def test_datetime_filter_treats_naive_datetime_as_utc():
    dt = datetime(2026, 1, 25, 15, 50, 16)
    rendered = datetime_filter(
        dt,
        {"datetime_format": "standard", "display_timezone": "America/New_York"},
    )
    assert rendered.startswith("2026-01-25 10:50:16")


def test_datetime_filter_invalid_timezone_falls_back_to_utc():
    dt = datetime(2026, 1, 25, 15, 50, 16, tzinfo=UTC)
    rendered = datetime_filter(
        dt,
        {"datetime_format": "standard", "display_timezone": "Invalid/Zone"},
    )
    assert rendered.startswith("2026-01-25 15:50:16")
