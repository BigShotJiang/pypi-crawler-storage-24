"""Web tests for TRF.test patient linking family relationship inference."""

from __future__ import annotations

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="family-link@test.org",
        name="Family Link Tester",
        tenant_id=tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def setup_tenant(db_session: Session, tenant_id: uuid.UUID):
    ensure_tapdb_org(db_session, tenant_id, name="family-link-tenant", display_name="Family Link")
    db_session.flush()


def _client(db_session: Session, user: CurrentUser) -> TestClient:
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        yield db_session

    def override_user():
        return user

    async def override_csrf():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    return TestClient(app)


def _create_patient(
    db: Session, tenant_id: uuid.UUID, actor: uuid.UUID, *, first_name: str, last_name: str
):
    from app.domain.services.people import PatientCreate, PatientService

    patient, _ = PatientService(db, tenant_id, actor).create(
        PatientCreate(first_name=first_name, last_name=last_name),
        created_by=actor,
    )
    return patient


def _create_trf_and_test(db: Session, tenant_id: uuid.UUID, actor: uuid.UUID):
    from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService

    trf, _ = TrfService(db, tenant_id).create(
        TrfCreate(order_type="CLINICAL"),
        tests=[
            TestCreate(
                product_code="WGS-001",
                fulfillment_route_codes=["WGS"],
                specimen_type_required="blood-whole",
            )
        ],
        patient_links=[],
        created_by=actor,
    )
    test = TestService(db, tenant_id).list_for_trf(trf.euid)[0][0]
    return trf, test


def test_trf_test_link_parent_after_proband_creates_parent_child_edge(
    db_session: Session, user: CurrentUser, setup_tenant
):
    from app.domain.services.patient_relationships import PatientRelationshipService

    client = _client(db_session, user)
    try:
        actor = user.sub_uuid
        _trf, test = _create_trf_and_test(db_session, user.tenant_id, actor)
        proband = _create_patient(
            db_session, user.tenant_id, actor, first_name="Child", last_name="Tester"
        )
        father = _create_patient(
            db_session, user.tenant_id, actor, first_name="Father", last_name="Tester"
        )

        proband_resp = client.post(
            f"/trfs/tests/{test.euid}/patient",
            data={"patient_euid": proband.euid, "role": "PROBAND"},
            follow_redirects=False,
        )
        assert proband_resp.status_code == status.HTTP_303_SEE_OTHER

        father_resp = client.post(
            f"/trfs/tests/{test.euid}/patient",
            data={"patient_euid": father.euid, "role": "FATHER"},
            follow_redirects=False,
        )
        assert father_resp.status_code == status.HTTP_303_SEE_OTHER

        db_session.expire_all()
        graph = PatientRelationshipService(db_session, user.tenant_id).get_patient_family_graph(
            proband.euid
        )
        assert graph.father_id == father.euid
    finally:
        app.dependency_overrides.clear()


@pytest.mark.parametrize(
    ("role", "graph_field"),
    [("FATHER", "father_id"), ("MOTHER", "mother_id")],
)
def test_trf_test_link_proband_after_parent_creates_parent_child_edge(
    db_session: Session,
    user: CurrentUser,
    setup_tenant,
    role: str,
    graph_field: str,
):
    from app.domain.services.patient_relationships import PatientRelationshipService

    client = _client(db_session, user)
    try:
        actor = user.sub_uuid
        _trf, test = _create_trf_and_test(db_session, user.tenant_id, actor)
        proband = _create_patient(
            db_session, user.tenant_id, actor, first_name="Child2", last_name="Tester"
        )
        parent = _create_patient(
            db_session, user.tenant_id, actor, first_name=f"{role.title()}2", last_name="Tester"
        )

        parent_resp = client.post(
            f"/trfs/tests/{test.euid}/patient",
            data={"patient_euid": parent.euid, "role": role},
            follow_redirects=False,
        )
        assert parent_resp.status_code == status.HTTP_303_SEE_OTHER

        proband_resp = client.post(
            f"/trfs/tests/{test.euid}/patient",
            data={"patient_euid": proband.euid, "role": "PROBAND"},
            follow_redirects=False,
        )
        assert proband_resp.status_code == status.HTTP_303_SEE_OTHER

        db_session.expire_all()
        graph = PatientRelationshipService(db_session, user.tenant_id).get_patient_family_graph(
            proband.euid
        )
        assert getattr(graph, graph_field) == parent.euid
    finally:
        app.dependency_overrides.clear()
