"""Security regression tests — batch 3.

Covers:
  NEW-1  Open redirect validation (_safe_redirect_url)
  NEW-2  Secret logging redaction (_log_env)
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from app.web.routes.pages import _safe_redirect_url

# ---------------------------------------------------------------------------
# NEW-1 — Open redirect validation
# ---------------------------------------------------------------------------


def test_safe_redirect_rejects_absolute_url():
    assert _safe_redirect_url("https://evil.com") == "/trfs/new"


def test_safe_redirect_rejects_protocol_relative():
    assert _safe_redirect_url("//evil.com") == "/trfs/new"


def test_safe_redirect_rejects_empty():
    assert _safe_redirect_url("") == "/trfs/new"


def test_safe_redirect_accepts_relative_path():
    assert _safe_redirect_url("/trfs/new") == "/trfs/new"


def test_safe_redirect_accepts_nested_path():
    assert _safe_redirect_url("/shipments/new?foo=bar") == "/shipments/new?foo=bar"


# ---------------------------------------------------------------------------
# NEW-2 — Secret logging redaction (_log_env)
# ---------------------------------------------------------------------------


@pytest.fixture()
def _patch_project_root(tmp_path: Path):
    """Redirect _log_env output to a temp directory."""
    with patch("app.cli.cognito.PROJECT_ROOT", tmp_path):
        yield tmp_path


def _read_log(tmp_path: Path) -> str:
    return (tmp_path / ".tmpenv.log").read_text()


def test_log_env_redacts_secret_values(_patch_project_root: Path):
    from app.cli.cognito import _log_env

    _log_env("test", COGNITO_APP_CLIENT_SECRET="super-secret")
    content = _read_log(_patch_project_root)
    assert "***REDACTED***" in content
    assert "super-secret" not in content


def test_log_env_redacts_key_values(_patch_project_root: Path):
    from app.cli.cognito import _log_env

    _log_env("test", API_KEY="my-key")
    content = _read_log(_patch_project_root)
    assert "***REDACTED***" in content
    assert "my-key" not in content


def test_log_env_does_not_redact_non_sensitive(_patch_project_root: Path):
    from app.cli.cognito import _log_env

    _log_env("test", AUTH_MODE="cognito")
    content = _read_log(_patch_project_root)
    assert "AUTH_MODE=cognito" in content


def test_log_env_redacts_case_insensitive(_patch_project_root: Path):
    from app.cli.cognito import _log_env

    _log_env("test", client_secret="val")
    content = _read_log(_patch_project_root)
    assert "***REDACTED***" in content
    assert "val" not in content or "client_secret=val" not in content
