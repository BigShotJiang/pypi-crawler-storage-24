"""Tests for Atlas Bloom lookup endpoints."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

import app.api.routes.bloom_lookups as bloom_lookups
import app.auth.dependencies as auth_deps
from app.auth.dependencies import IntegrationClientPrincipal, get_bloom_integration_client
from app.db.engine import get_db
from app.main import app

pytestmark = pytest.mark.db


@pytest.fixture
def lookup_client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


@pytest.fixture
def authed_lookup_client(db_session):
    tenant_id = uuid.uuid4()

    def override_get_db():
        yield db_session

    def override_integration_client():
        return IntegrationClientPrincipal(
            client_id=uuid.uuid4(),
            tenant_id=tenant_id,
            client_name="lookup-test-client",
            permissions=["bloom:atlas:write"],
            allowed_endpoints=["/api/integrations/bloom/v1/lookups"],
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_bloom_integration_client] = override_integration_client
    with TestClient(app) as client:
        yield client, tenant_id
    app.dependency_overrides.clear()


@pytest.fixture
def cross_tenant_lookup_client(db_session):
    tenant_id = uuid.uuid4()

    def override_get_db():
        yield db_session

    def override_integration_client():
        return IntegrationClientPrincipal(
            client_id=uuid.uuid4(),
            tenant_id=tenant_id,
            client_name="lookup-cross-tenant-client",
            permissions=["bloom:atlas:write", "cross_tenant:read"],
            allowed_endpoints=["/api/integrations/bloom/v1/lookups"],
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_bloom_integration_client] = override_integration_client
    with TestClient(app) as client:
        yield client, tenant_id
    app.dependency_overrides.clear()


def test_lookup_requires_integration_token(lookup_client):
    resp = lookup_client.get("/api/integrations/bloom/v1/lookups/trfs/TRF-1001")
    assert resp.status_code == 401


def test_lookup_respects_allowed_endpoints(lookup_client, monkeypatch):
    class FakeAPIClientService:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def validate_api_key_any_tenant(self, _api_key):
            return (
                SimpleNamespace(
                    id=uuid.uuid4(),
                    tenant_id=uuid.uuid4(),
                    client_name="blocked-lookup-client",
                ),
                SimpleNamespace(
                    permissions=["bloom:atlas:write"],
                    allowed_endpoints=["/api/integrations/bloom/v1/specimens"],
                ),
            )

        def log_usage(self, **kwargs):
            return None

    monkeypatch.setattr(auth_deps, "APIClientService", FakeAPIClientService)

    client = lookup_client
    resp = client.get(
        "/api/integrations/bloom/v1/lookups/trfs/TRF-1001",
        headers={"Authorization": "Bearer blocked-token"},
    )
    assert resp.status_code == 403
    assert "not allowed" in resp.json()["detail"].lower()


def test_trf_lookup_returns_minimal_payload(monkeypatch, authed_lookup_client):
    client, tenant_id = authed_lookup_client

    class FakeTrfService:
        def __init__(self, db, provided_tenant_id):
            self.tenant_id = provided_tenant_id

        def get_by_id(self, trf_euid, cross_tenant=False):
            assert cross_tenant is False
            oid = uuid.uuid4()
            return (
                SimpleNamespace(
                    id=oid, euid=trf_euid, tenant_id=self.tenant_id, order_number=trf_euid
                ),
                SimpleNamespace(status="created"),
            )

    monkeypatch.setattr(bloom_lookups, "TrfService", FakeTrfService)
    resp = client.get("/api/integrations/bloom/v1/lookups/trfs/TRF-1001")
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["trf_euid"] == "TRF-1001"
    assert payload["trf_number"] == "TRF-1001"
    assert payload["atlas_tenant_id"] == str(tenant_id)
    assert payload["status"] == "created"


def test_patient_lookup_returns_minimal_payload(monkeypatch, authed_lookup_client):
    client, tenant_id = authed_lookup_client
    patient_id = uuid.uuid4()

    class FakePatientService:
        def __init__(self, db, provided_tenant_id):
            self.tenant_id = provided_tenant_id

        def get(self, patient_uuid, cross_tenant=False):
            assert cross_tenant is False
            return (
                SimpleNamespace(id=patient_uuid, euid=str(patient_uuid), tenant_id=self.tenant_id),
                SimpleNamespace(mrn="MRN-1001"),
            )

    monkeypatch.setattr(bloom_lookups, "PatientService", FakePatientService)
    resp = client.get(f"/api/integrations/bloom/v1/lookups/patients/{patient_id}")
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["patient_euid"] == str(patient_id)
    assert payload["atlas_tenant_id"] == str(tenant_id)
    assert payload["mrn"] == "MRN-1001"


def test_shipment_lookup_returns_minimal_payload(monkeypatch, authed_lookup_client):
    client, tenant_id = authed_lookup_client

    class FakeShipmentService:
        def __init__(self, db, provided_tenant_id):
            self.tenant_id = provided_tenant_id

        def get_by_shipment_number(self, shipment_number, cross_tenant=False):
            assert cross_tenant is False
            ship_id = uuid.uuid4()
            return (
                SimpleNamespace(
                    id=ship_id,
                    euid=str(ship_id),
                    tenant_id=self.tenant_id,
                    shipment_number=shipment_number,
                ),
                SimpleNamespace(status="in_transit"),
            )

    monkeypatch.setattr(bloom_lookups, "ShipmentService", FakeShipmentService)
    resp = client.get("/api/integrations/bloom/v1/lookups/shipments/SHP-2001")
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["shipment_number"] == "SHP-2001"
    assert payload["atlas_tenant_id"] == str(tenant_id)
    assert payload["status"] == "in_transit"


def test_testkit_lookup_returns_minimal_payload(monkeypatch, authed_lookup_client):
    client, tenant_id = authed_lookup_client
    testkit_id = uuid.uuid4()

    class FakeTestKitService:
        def __init__(self, db, provided_tenant_id):
            self.tenant_id = provided_tenant_id

        def get_by_barcode(self, kit_barcode, cross_tenant=False):
            assert cross_tenant is False
            return SimpleNamespace(
                id=testkit_id,
                euid=str(testkit_id),
                tenant_id=self.tenant_id,
                kit_barcode=kit_barcode,
            )

        def get_with_revision(self, record_id, cross_tenant=False):
            assert cross_tenant is False
            assert record_id == str(testkit_id)
            return (
                SimpleNamespace(id=record_id, euid=record_id),
                SimpleNamespace(status="assigned"),
            )

    monkeypatch.setattr(bloom_lookups, "TestKitService", FakeTestKitService)
    resp = client.get("/api/integrations/bloom/v1/lookups/testkits/KIT-3001")
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["kit_barcode"] == "KIT-3001"
    assert payload["atlas_tenant_id"] == str(tenant_id)
    assert payload["status"] == "assigned"


def test_container_trf_context_requires_tenant_header(cross_tenant_lookup_client):
    client, _tenant_id = cross_tenant_lookup_client
    resp = client.get("/api/integrations/bloom/v1/lookups/containers/CX-1/trf-context")
    assert resp.status_code == 400
    assert "X-Atlas-Tenant-Id" in resp.json()["detail"]


def test_container_trf_context_requires_cross_tenant_permission(db_session):
    tenant_id = uuid.uuid4()

    def override_get_db():
        yield db_session

    def override_integration_client():
        return IntegrationClientPrincipal(
            client_id=uuid.uuid4(),
            tenant_id=tenant_id,
            client_name="lookup-no-cross-tenant",
            permissions=["bloom:atlas:write"],
            allowed_endpoints=["/api/integrations/bloom/v1/lookups"],
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_bloom_integration_client] = override_integration_client
    with TestClient(app) as client:
        resp = client.get(
            "/api/integrations/bloom/v1/lookups/containers/CX-1/trf-context",
            headers={"X-Atlas-Tenant-Id": str(uuid.uuid4())},
        )
    app.dependency_overrides.clear()
    assert resp.status_code == 403
    assert "cross_tenant:read" in resp.json()["detail"]


def test_container_trf_context_happy_path(monkeypatch, cross_tenant_lookup_client):
    client, tenant_id = cross_tenant_lookup_client

    class FakeContextService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def get_trf_context_for_container(self, container_euid):
            assert container_euid == "CX-123"
            return {
                "atlas_tenant_id": str(tenant_id),
                "container": {"external_euid": "CX-123"},
                "order": {"order_number": "ORD-1001"},
                "patient": {"patient_euid": str(uuid.uuid4())},
                "test_orders": [],
                "links": {},
            }

    monkeypatch.setattr(bloom_lookups, "BloomQueryContextService", FakeContextService)
    resp = client.get(
        "/api/integrations/bloom/v1/lookups/containers/CX-123/trf-context",
        headers={"X-Atlas-Tenant-Id": str(tenant_id)},
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["atlas_tenant_id"] == str(tenant_id)
    assert payload["container"]["external_euid"] == "CX-123"
    assert payload["order"]["order_number"] == "ORD-1001"


def test_container_trf_context_maps_not_found(monkeypatch, cross_tenant_lookup_client):
    client, tenant_id = cross_tenant_lookup_client

    class FakeContextService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def get_trf_context_for_container(self, container_euid):
            raise bloom_lookups.ContainerNotFoundError(f"Container not found: {container_euid}")

    monkeypatch.setattr(bloom_lookups, "BloomQueryContextService", FakeContextService)
    resp = client.get(
        "/api/integrations/bloom/v1/lookups/containers/CX-404/trf-context",
        headers={"X-Atlas-Tenant-Id": str(tenant_id)},
    )
    assert resp.status_code == 404


def test_container_trf_context_maps_tenant_mismatch(monkeypatch, cross_tenant_lookup_client):
    client, tenant_id = cross_tenant_lookup_client

    class FakeContextService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def get_trf_context_for_container(self, container_euid):
            raise bloom_lookups.ContainerTenantMismatchError(
                f"Container tenant mismatch: requested={tenant_id} actual={uuid.uuid4()}"
            )

    monkeypatch.setattr(bloom_lookups, "BloomQueryContextService", FakeContextService)
    resp = client.get(
        "/api/integrations/bloom/v1/lookups/containers/CX-MISMATCH/trf-context",
        headers={"X-Atlas-Tenant-Id": str(tenant_id)},
    )
    assert resp.status_code == 409
    assert "tenant mismatch" in resp.json()["detail"].lower()


def test_container_trf_context_maps_inconsistent(monkeypatch, cross_tenant_lookup_client):
    client, tenant_id = cross_tenant_lookup_client

    class FakeContextService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def get_trf_context_for_container(self, container_euid):
            raise bloom_lookups.ContainerContextInconsistentError("Inconsistent relation topology")

    monkeypatch.setattr(bloom_lookups, "BloomQueryContextService", FakeContextService)
    resp = client.get(
        "/api/integrations/bloom/v1/lookups/containers/CX-409/trf-context",
        headers={"X-Atlas-Tenant-Id": str(tenant_id)},
    )
    assert resp.status_code == 409
