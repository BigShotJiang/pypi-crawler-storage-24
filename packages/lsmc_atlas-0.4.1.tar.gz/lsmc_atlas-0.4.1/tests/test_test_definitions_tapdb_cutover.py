"""Unit tests for TapDB cutover behavior in TestDefinitionService."""

from __future__ import annotations

from dataclasses import dataclass

from app.domain.services.test_definitions import TestDefinitionCreate, TestDefinitionService, TestDefinitionUpdate


@dataclass
class _MockDB:
    pass


class _FakeRepo:
    def __init__(self):
        self.calls: list[tuple[str, tuple, dict]] = []

    def _record(self, name: str, *args, **kwargs):
        self.calls.append((name, args, kwargs))

    def create(self, data):
        self._record("create", data)
        return {"id": "new"}

    def get_by_euid(self, assay_euid):
        self._record("get_by_euid", assay_euid)
        return {"euid": assay_euid}

    def get_by_code(self, code):
        self._record("get_by_code", code)
        return {"code": code}

    def list_all(self, active_only=True, category=None, technology=None):
        self._record(
            "list_all",
            active_only,
            category,
            technology,
        )
        return [{"code": "A1"}]

    def update(self, assay_euid, data):
        self._record("update", assay_euid, data)
        return {"euid": assay_euid, "updated": True}

    def deactivate(self, assay_euid):
        self._record("deactivate", assay_euid)
        return {"euid": assay_euid, "is_active": False}

    def get_categories(self):
        self._record("get_categories")
        return ["hematology"]

    def get_technologies(self):
        self._record("get_technologies")
        return ["NGS"]


def test_assay_service_delegates_to_tapdb_repo(monkeypatch):
    service = TestDefinitionService(_MockDB())
    repo = _FakeRepo()
    monkeypatch.setattr(service, "_repo", lambda: repo)

    assay_euid = "ASY-001"
    assert service.create(TestDefinitionCreate(code="A1", name="Assay A1")) == {"id": "new"}
    assert service.get_by_euid(assay_euid) == {"euid": assay_euid}
    assert service.get_by_code("A1") == {"code": "A1"}
    assert service.list_all(active_only=False, category="x", technology="y") == [{"code": "A1"}]
    assert service.update(assay_euid, TestDefinitionUpdate(name="Updated")) == {
        "euid": assay_euid,
        "updated": True,
    }
    assert service.deactivate(assay_euid) == {"euid": assay_euid, "is_active": False}
    assert service.get_categories() == ["hematology"]
    assert service.get_technologies() == ["NGS"]

    call_names = [call[0] for call in repo.calls]
    assert call_names == [
        "create",
        "get_by_euid",
        "get_by_code",
        "list_all",
        "update",
        "deactivate",
        "get_categories",
        "get_technologies",
    ]
