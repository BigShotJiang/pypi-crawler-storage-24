"""Tests for CAPTCHA integration."""

from app.auth.captcha import (
    CaptchaConfig,
    CaptchaProvider,
    generate_simple_challenge,
    verify_simple_challenge,
)


class TestSimpleCaptcha:
    """Test the simple CAPTCHA challenge system."""

    def test_generate_challenge(self):
        """Test challenge generation."""
        result = generate_simple_challenge()

        assert "challenge_id" in result
        assert "question" in result
        assert "type" in result
        assert result["type"] == "simple"
        assert "+" in result["question"]

    def test_verify_correct_answer(self):
        """Test verification with correct answer."""
        challenge = generate_simple_challenge()

        # Parse the question to get the expected answer
        question = challenge["question"]
        # Extract numbers from "What is X + Y?"
        parts = question.replace("What is ", "").replace("?", "").split(" + ")
        expected_answer = str(int(parts[0]) + int(parts[1]))

        result = verify_simple_challenge(challenge["challenge_id"], expected_answer)
        assert result is True

    def test_verify_wrong_answer(self):
        """Test verification with wrong answer."""
        challenge = generate_simple_challenge()

        result = verify_simple_challenge(challenge["challenge_id"], "9999")
        assert result is False

    def test_verify_invalid_challenge_id(self):
        """Test verification with invalid challenge ID."""
        result = verify_simple_challenge("invalid-id", "42")
        assert result is False

    def test_challenge_can_only_be_used_once(self):
        """Test that a challenge is consumed after successful verification."""
        challenge = generate_simple_challenge()
        question = challenge["question"]
        parts = question.replace("What is ", "").replace("?", "").split(" + ")
        answer = str(int(parts[0]) + int(parts[1]))

        # First verification should succeed
        assert verify_simple_challenge(challenge["challenge_id"], answer)

        # Second verification should fail (challenge consumed)
        assert not verify_simple_challenge(challenge["challenge_id"], answer)

    def test_challenge_with_whitespace_answer(self):
        """Test that whitespace in answer is handled."""
        challenge = generate_simple_challenge()
        question = challenge["question"]
        parts = question.replace("What is ", "").replace("?", "").split(" + ")
        answer = str(int(parts[0]) + int(parts[1]))

        # Add whitespace
        result = verify_simple_challenge(challenge["challenge_id"], f"  {answer}  ")
        assert result is True


class TestCaptchaConfig:
    """Test CAPTCHA configuration."""

    def test_default_config(self):
        """Test default configuration values."""
        config = CaptchaConfig()

        assert config.provider == CaptchaProvider.SIMPLE
        assert config.site_key == ""
        assert config.secret_key == ""
        assert config.score_threshold == 0.5

    def test_custom_config(self):
        """Test custom configuration."""
        config = CaptchaConfig(
            provider=CaptchaProvider.RECAPTCHA_V3,
            site_key="test-site-key",
            secret_key="test-secret-key",
            score_threshold=0.7,
        )

        assert config.provider == CaptchaProvider.RECAPTCHA_V3
        assert config.site_key == "test-site-key"
        assert config.score_threshold == 0.7


class TestCaptchaProviders:
    """Test CAPTCHA provider enum."""

    def test_all_providers_defined(self):
        """Test that all expected providers are defined."""
        assert CaptchaProvider.RECAPTCHA_V2.value == "recaptcha_v2"
        assert CaptchaProvider.RECAPTCHA_V3.value == "recaptcha_v3"
        assert CaptchaProvider.HCAPTCHA.value == "hcaptcha"
        assert CaptchaProvider.SIMPLE.value == "simple"
        assert CaptchaProvider.DISABLED.value == "disabled"
