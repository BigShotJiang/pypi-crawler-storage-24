"""Guardrails for TapDB hard-cut migration."""

from __future__ import annotations

import re
from pathlib import Path

LEGACY_MODEL_PATTERN = re.compile(r"\bapp\.db\.models\b")
ALEMBIC_PATTERN = re.compile(r"\balembic\b")
POSTGRES_BACKEND_PATTERN = re.compile(
    r"(" + "backend=" + "post" + "gres|database_" + "backend.*" + "post" + "gres)"
)
EXTERNAL_UUID_ASSIGN_PATTERN = re.compile(r"\bexternal_uuid\s*=")
EXTERNAL_UUID_PROPERTY_PATTERN = re.compile(r"['\"]external_uuid['\"]\s*:")
ORM_MODELS_IMPORT_PATTERN = re.compile(r"\bapp\.persistence\.tapdb\.orm_models\b")
LEGACY_RUNTIME_SQL_PATTERN = re.compile(
    r"(?i)\b(from|join|into|update)\s+([a-z_]+\.)?"
    r"(order_revision|shipment_revision|exception_revision|release_package|release_package_revision|"
    r"status_event|shipment_tracking_snapshot|shipment_tracking_event)\b"
)
LEGACY_RUNTIME_VIEW_PATTERN = re.compile(
    r"\b(order|patient|clinician|shipment)_audit_history_v\b",
    flags=re.IGNORECASE,
)
LEGACY_BIOSPECIMEN_SYMBOL_PATTERN = re.compile(
    r"\b(BioSpecimen|BioSpecimenRevision|BioSpecimenStatus)\b"
)
LEGACY_BIOSPECIMEN_ROUTE_PATTERN = re.compile(r"['\"]/(api/)?biospecimens(?:/|['\"])\b")
LEGACY_LINK_SPECIMEN_ROUTE_PATTERN = re.compile(r"['\"]/[^'\"]*link-specimen[^'\"]*['\"]")

REMOVED_BLOOM_CREATE_ROUTES = (
    "/api/integrations/bloom/v1/patients",
    "/api/integrations/bloom/v1/clinicians",
    "/api/integrations/bloom/v1/orders",
    "/api/integrations/bloom/v1/packages",
)

# Hard cutover: no allowlist remains.
LEGACY_IMPORT_ALLOWLIST: set[str] = set()

# When removing legacy tests/modules, require at least one replacement test.
REMOVED_TEST_REPLACEMENTS: dict[str, list[str]] = {
    "tests/test_tenant_compat.py": [
        "test_auto_provision_uses_first_active_org_when_no_configured_tenant",
        "test_auto_provision_bootstraps_tenant_when_none_exist",
    ],
}


def _iter_python_files(root: Path):
    app_root = root / "app"
    migration_prefix = "app/db/" + "migrations/"
    for path in app_root.rglob("*.py"):
        rel = path.relative_to(root).as_posix()
        if rel.startswith("app/db/models/"):
            continue
        if rel.startswith(migration_prefix):
            continue
        yield path, rel


def _iter_runtime_python_files(root: Path):
    for path, rel in _iter_python_files(root):
        if rel.startswith("app/persistence/tapdb/orm_models/"):
            continue
        yield path, rel


def test_no_unplanned_legacy_model_imports_in_runtime():
    repo_root = Path(__file__).resolve().parents[1]
    offenders: list[str] = []

    for path, rel in _iter_python_files(repo_root):
        content = path.read_text(encoding="utf-8")
        if LEGACY_MODEL_PATTERN.search(content) and rel not in LEGACY_IMPORT_ALLOWLIST:
            offenders.append(rel)

    assert not offenders, "Unexpected legacy model imports:\n" + "\n".join(sorted(offenders))


def test_no_alembic_references_in_runtime_cli():
    repo_root = Path(__file__).resolve().parents[1]
    targets = [
        repo_root / "app" / "cli",
        repo_root / "atlas_activate",
    ]
    offenders: list[str] = []

    for target in targets:
        files = [target] if target.is_file() else list(target.rglob("*.py"))
        for file_path in files:
            text = file_path.read_text(encoding="utf-8")
            if ALEMBIC_PATTERN.search(text):
                offenders.append(str(file_path.relative_to(repo_root)))

    assert not offenders, "Runtime CLI still references Alembic:\n" + "\n".join(sorted(offenders))


def test_no_postgres_backend_compat_references():
    repo_root = Path(__file__).resolve().parents[1]
    targets = [
        repo_root / "app" / "settings.py",
        repo_root / "README.md",
        repo_root / "app" / "etc" / "lsmc-atlas-config-template.yaml",
        repo_root / "config" / "lsmc-atlas-config-example.yaml",
    ]
    offenders: list[str] = []
    for target in targets:
        text = target.read_text(encoding="utf-8")
        if POSTGRES_BACKEND_PATTERN.search(text):
            offenders.append(str(target.relative_to(repo_root)))

    assert not offenders, "Found postgres backend compatibility references:\n" + "\n".join(
        offenders
    )


def test_removed_legacy_tests_have_replacement_coverage():
    repo_root = Path(__file__).resolve().parents[1]
    auth_test_text = (repo_root / "tests" / "test_auth_cognito.py").read_text(encoding="utf-8")

    for removed_path, replacement_tests in REMOVED_TEST_REPLACEMENTS.items():
        removed_exists = (repo_root / removed_path).exists()
        assert not removed_exists, f"Legacy test still present: {removed_path}"
        for test_name in replacement_tests:
            assert test_name in auth_test_text, (
                f"Missing replacement test '{test_name}' for removed legacy surface {removed_path}"
            )


def test_no_external_uuid_persistence_in_bloom_integration_stack():
    repo_root = Path(__file__).resolve().parents[1]
    targets = [
        repo_root / "app" / "domain" / "services" / "bloom_bridge.py",
        repo_root / "app" / "domain" / "services" / "external_objects.py",
        repo_root / "app" / "persistence" / "tapdb" / "external_objects.py",
        repo_root / "app" / "api" / "routes" / "bloom_integration.py",
    ]
    offenders: list[str] = []
    for target in targets:
        text = target.read_text(encoding="utf-8")
        if EXTERNAL_UUID_ASSIGN_PATTERN.search(text) or EXTERNAL_UUID_PROPERTY_PATTERN.search(text):
            offenders.append(str(target.relative_to(repo_root)))

    assert not offenders, "Found forbidden external_uuid persistence references:\n" + "\n".join(
        sorted(offenders)
    )


def test_removed_bloom_create_routes_not_registered():
    repo_root = Path(__file__).resolve().parents[1]
    route_file = repo_root / "app" / "api" / "routes" / "bloom_integration.py"
    text = route_file.read_text(encoding="utf-8")
    offenders = [path for path in REMOVED_BLOOM_CREATE_ROUTES if path in text]
    assert not offenders, "Removed Bloom create routes are still present:\n" + "\n".join(offenders)


def test_main_does_not_mount_legacy_orders_alias_router():
    repo_root = Path(__file__).resolve().parents[1]
    main_text = (repo_root / "app" / "main.py").read_text(encoding="utf-8")
    assert "include_router(orders.router)" not in main_text


def test_runtime_has_no_orm_models_imports_outside_orm_models_package():
    repo_root = Path(__file__).resolve().parents[1]
    offenders: list[str] = []

    for path, rel in _iter_runtime_python_files(repo_root):
        content = path.read_text(encoding="utf-8")
        if ORM_MODELS_IMPORT_PATTERN.search(content):
            offenders.append(rel)

    assert not offenders, "Runtime code imports orm_models directly:\n" + "\n".join(
        sorted(offenders)
    )


def test_runtime_has_no_legacy_sql_table_or_view_references():
    repo_root = Path(__file__).resolve().parents[1]
    offenders: list[str] = []

    for path, rel in _iter_runtime_python_files(repo_root):
        content = path.read_text(encoding="utf-8")
        if LEGACY_RUNTIME_SQL_PATTERN.search(content) or LEGACY_RUNTIME_VIEW_PATTERN.search(
            content
        ):
            offenders.append(rel)

    assert not offenders, "Runtime code still references legacy SQL tables/views:\n" + "\n".join(
        sorted(offenders)
    )


def test_runtime_has_no_legacy_biospecimen_symbols():
    repo_root = Path(__file__).resolve().parents[1]
    offenders: list[str] = []

    for path, rel in _iter_runtime_python_files(repo_root):
        content = path.read_text(encoding="utf-8")
        if LEGACY_BIOSPECIMEN_SYMBOL_PATTERN.search(content):
            offenders.append(rel)

    assert not offenders, "Runtime code still references legacy BioSpecimen symbols:\n" + "\n".join(
        sorted(offenders)
    )


def test_runtime_has_no_legacy_biospecimen_routes():
    repo_root = Path(__file__).resolve().parents[1]
    offenders: list[str] = []

    for path, rel in _iter_runtime_python_files(repo_root):
        content = path.read_text(encoding="utf-8")
        if LEGACY_BIOSPECIMEN_ROUTE_PATTERN.search(
            content
        ) or LEGACY_LINK_SPECIMEN_ROUTE_PATTERN.search(content):
            offenders.append(rel)

    assert not offenders, "Runtime code still registers legacy biospecimen routes:\n" + "\n".join(
        sorted(offenders)
    )
