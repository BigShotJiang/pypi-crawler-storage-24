"""Tests for Atlas intake accept/hold/reject material outcomes."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

import app.api.routes.intake as intake_routes
from app.auth.dependencies import CurrentUser, get_current_user, require_internal
from app.db.engine import get_db
from app.main import app

pytestmark = pytest.mark.db


@pytest.fixture
def intake_client(db_session):
    tenant_id = uuid.uuid4()

    def override_get_db():
        yield db_session

    async def override_require_internal():
        return None

    def override_get_current_user():
        return CurrentUser(
            sub=str(uuid.uuid4()),
            email="internal@example.com",
            name="Internal User",
            tenant_id=tenant_id,
            roles=["INTERNAL_USER"],
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[require_internal] = override_require_internal
    app.dependency_overrides[get_current_user] = override_get_current_user
    with TestClient(app) as client:
        yield client, tenant_id
    app.dependency_overrides.clear()


def test_intake_accept_outcome_routes_into_bloom_queue(monkeypatch, intake_client):
    client, _tenant_id = intake_client

    class FakeIntakeService:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def record_material_outcome(self, data, *, actor_id=None):
            assert data.trf_euid == "TRF-1"
            assert data.test_euids == ["TST-1", "TST-2"]
            assert data.outcome.value == "ACCEPTED"
            assert data.starting_queue == "extraction_prod"
            assert data.idempotency_key.startswith("atlas-intake:TRF-1:ACCEPTED:")
            return SimpleNamespace(
                outcome="ACCEPTED",
                accepted=True,
                trf_euid="TRF-1",
                trf_status="IN_PROGRESS",
                test_euids=["TST-1", "TST-2"],
                fulfillment_item_euids=["TPI-1", "TPI-2"],
                test_statuses={
                    "TST-1": "SPECIMEN_RECEIVED",
                    "TST-2": "SPECIMEN_RECEIVED",
                },
                patient_euid="PAT-1",
                container_euid="CNT-1",
                specimen_euid="SP-1",
                current_queue="extraction_prod",
            )

    monkeypatch.setattr(intake_routes, "IntakeService", FakeIntakeService)
    resp = client.post(
        "/api/intake/outcomes",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1", "TST-2"],
            "patient_euid": "PAT-1",
            "outcome": "ACCEPTED",
            "shipment_euid": "SHP-1",
            "starting_queue": "extraction_prod",
        },
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["accepted"] is True
    assert payload["trf_status"] == "IN_PROGRESS"
    assert payload["fulfillment_item_euids"] == ["TPI-1", "TPI-2"]
    assert payload["container_euid"] == "CNT-1"
    assert payload["specimen_euid"] == "SP-1"
    assert payload["current_queue"] == "extraction_prod"


def test_intake_hold_outcome_updates_customer_facing_status(monkeypatch, intake_client):
    client, _tenant_id = intake_client

    class FakeIntakeService:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def record_material_outcome(self, data, *, actor_id=None):
            assert data.outcome.value == "HOLD"
            return SimpleNamespace(
                outcome="HOLD",
                accepted=False,
                trf_euid="TRF-1",
                trf_status="QC_HOLD",
                test_euids=["TST-1"],
                fulfillment_item_euids=[],
                test_statuses={"TST-1": "ON_HOLD"},
                patient_euid="PAT-1",
                container_euid=None,
                specimen_euid=None,
                current_queue=None,
            )

    monkeypatch.setattr(intake_routes, "IntakeService", FakeIntakeService)
    resp = client.post(
        "/api/intake/outcomes",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "outcome": "HOLD",
            "testkit_euid": "KIT-1",
        },
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["accepted"] is False
    assert payload["trf_status"] == "QC_HOLD"
    assert payload["test_statuses"] == {"TST-1": "ON_HOLD"}


def test_intake_outcome_validates_shipment_or_testkit(intake_client):
    client, _tenant_id = intake_client
    resp = client.post(
        "/api/intake/outcomes",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "outcome": "REJECTED",
        },
    )
    assert resp.status_code == 422
    assert "At least one of shipment_euid or testkit_euid is required" in resp.text


def test_intake_outcome_accepts_shipment_only(monkeypatch, intake_client):
    client, _tenant_id = intake_client

    class FakeIntakeService:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def record_material_outcome(self, data, *, actor_id=None):
            assert data.shipment_euid == "SHP-1"
            assert data.testkit_euid is None
            return SimpleNamespace(
                outcome=data.outcome.value,
                accepted=False,
                trf_euid=data.trf_euid,
                trf_status="REJECTED",
                test_euids=data.test_euids,
                fulfillment_item_euids=[],
                test_statuses={data.test_euids[0]: "REJECTED"},
                patient_euid=data.patient_euid,
                container_euid=None,
                specimen_euid=None,
                current_queue=None,
            )

    monkeypatch.setattr(intake_routes, "IntakeService", FakeIntakeService)
    resp = client.post(
        "/api/intake/outcomes",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "outcome": "REJECTED",
            "shipment_euid": "SHP-1",
        },
    )
    assert resp.status_code == 200


def test_intake_outcome_accepts_testkit_only(monkeypatch, intake_client):
    client, _tenant_id = intake_client

    class FakeIntakeService:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def record_material_outcome(self, data, *, actor_id=None):
            assert data.shipment_euid is None
            assert data.testkit_euid == "KIT-1"
            return SimpleNamespace(
                outcome=data.outcome.value,
                accepted=False,
                trf_euid=data.trf_euid,
                trf_status="ON_HOLD",
                test_euids=data.test_euids,
                fulfillment_item_euids=[],
                test_statuses={data.test_euids[0]: "ON_HOLD"},
                patient_euid=data.patient_euid,
                container_euid=None,
                specimen_euid=None,
                current_queue=None,
            )

    monkeypatch.setattr(intake_routes, "IntakeService", FakeIntakeService)
    resp = client.post(
        "/api/intake/outcomes",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "outcome": "HOLD",
            "testkit_euid": "KIT-1",
        },
    )
    assert resp.status_code == 200


def test_intake_outcome_accepts_shipment_and_testkit(monkeypatch, intake_client):
    client, _tenant_id = intake_client

    class FakeIntakeService:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def record_material_outcome(self, data, *, actor_id=None):
            assert data.shipment_euid == "SHP-1"
            assert data.testkit_euid == "KIT-1"
            return SimpleNamespace(
                outcome=data.outcome.value,
                accepted=False,
                trf_euid=data.trf_euid,
                trf_status="ON_HOLD",
                test_euids=data.test_euids,
                fulfillment_item_euids=[],
                test_statuses={data.test_euids[0]: "ON_HOLD"},
                patient_euid=data.patient_euid,
                container_euid=None,
                specimen_euid=None,
                current_queue=None,
            )

    monkeypatch.setattr(intake_routes, "IntakeService", FakeIntakeService)
    resp = client.post(
        "/api/intake/outcomes",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "outcome": "HOLD",
            "shipment_euid": "SHP-1",
            "testkit_euid": "KIT-1",
        },
    )
    assert resp.status_code == 200
