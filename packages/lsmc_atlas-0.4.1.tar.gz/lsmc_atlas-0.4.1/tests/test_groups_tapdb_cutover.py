"""Unit tests for staged TapDB cutover in UserGroupService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from app.domain.services.groups import GroupCreate, UserGroupService
from app.persistence.tapdb.orm_models.groups import AccessScope


class _FakeRepo:
    def __init__(self):
        self.calls: list[tuple[str, tuple, dict]] = []

    def _record(self, name: str, *args, **kwargs):
        self.calls.append((name, args, kwargs))

    def create_group(self, data, created_by):
        self._record("create_group", data, created_by)
        return ("group-obj", "revision-obj")

    def get_group_by_code(self, group_code):
        self._record("get_group_by_code", group_code)
        return {"code": group_code}

    def list_group_members(self, group_id):
        self._record("list_group_members", group_id)
        return ["member"]

    def remove_user_from_group(self, user_id, group_id, removed_by):
        self._record("remove_user_from_group", user_id, group_id, removed_by)
        return "removed"

    def add_user_to_group(self, user_id, group_id, added_by):
        self._record("add_user_to_group", user_id, group_id, added_by)
        return "added"


@dataclass
class _MockDB:
    pass


def test_service_delegates_to_tapdb_repo(monkeypatch):
    service = UserGroupService(_MockDB(), tenant_id=uuid.uuid4())
    fake_repo = _FakeRepo()

    monkeypatch.setattr(service, "_tapdb_repository", lambda: fake_repo)

    created_by = uuid.uuid4()
    group_id = uuid.uuid4()
    user_id = uuid.uuid4()
    group_data = GroupCreate(
        group_code="TEST_GROUP",
        name="Test Group",
        description="desc",
        access_scope=AccessScope.SYSTEM,
        default_roles=["ADMIN"],
    )

    assert service.create_group(group_data, created_by) == ("group-obj", "revision-obj")
    assert service.get_group_by_code("TEST_GROUP") == {"code": "TEST_GROUP"}
    assert service.list_group_members(group_id) == ["member"]
    assert service.add_user_to_group(user_id, group_id, created_by) == "added"
    assert service.remove_user_from_group(user_id, group_id, created_by) == "removed"

    call_names = [call[0] for call in fake_repo.calls]
    assert call_names == [
        "create_group",
        "get_group_by_code",
        "list_group_members",
        "add_user_to_group",
        "remove_user_from_group",
    ]
