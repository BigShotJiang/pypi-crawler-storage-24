"""Tests for Atlas Bloom integration beta APIs."""

from __future__ import annotations

import hashlib
import hmac
import json
import uuid
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

import app.api.routes.bloom_integration as bloom_routes
import app.auth.dependencies as auth_deps
from app.auth.dependencies import IntegrationClientPrincipal, get_bloom_integration_client
from app.db.engine import get_db
from app.main import app

pytestmark = pytest.mark.db


@pytest.fixture
def api_client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


@pytest.fixture
def authed_api_client(db_session):
    tenant_id = uuid.uuid4()

    def override_get_db():
        yield db_session

    def override_integration_client():
        return IntegrationClientPrincipal(
            client_id=uuid.uuid4(),
            tenant_id=tenant_id,
            client_name="bloom-test-client",
            permissions=["bloom:atlas:write"],
            allowed_endpoints=["/api/integrations/bloom/v1"],
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_bloom_integration_client] = override_integration_client
    with TestClient(app) as client:
        yield client, tenant_id
    app.dependency_overrides.clear()


@pytest.fixture
def cross_tenant_authed_api_client(db_session):
    tenant_id = uuid.uuid4()

    def override_get_db():
        yield db_session

    def override_integration_client():
        return IntegrationClientPrincipal(
            client_id=uuid.uuid4(),
            tenant_id=tenant_id,
            client_name="bloom-cross-tenant-client",
            permissions=["bloom:atlas:write", "cross_tenant:write"],
            allowed_endpoints=["/api/integrations/bloom/v1"],
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_bloom_integration_client] = override_integration_client
    with TestClient(app) as client:
        yield client, tenant_id
    app.dependency_overrides.clear()


def test_bloom_accept_material_requires_bearer_token(api_client):
    resp = api_client.post(
        "/api/integrations/bloom/v1/materials/accepted",
        json={"trf_euid": "TRF-1", "test_euids": ["TST-1"], "patient_euid": "PAT-1"},
    )
    assert resp.status_code == 401


def test_legacy_material_routes_removed(api_client):
    removed = (
        ("post", "/api/integrations/bloom/v1/containers"),
        ("post", "/api/integrations/bloom/v1/specimens"),
        ("get", "/api/integrations/bloom/v1/specimens/by-reference"),
    )
    for method, path in removed:
        resp = getattr(api_client, method)(path)
        assert resp.status_code == 404


def test_accept_material_rejects_missing_shipment_or_testkit(authed_api_client):
    client, _tenant_id = authed_api_client
    resp = client.post(
        "/api/integrations/bloom/v1/materials/accepted",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "starting_queue": "extraction_prod",
        },
        headers={"Idempotency-Key": "idem-1"},
    )
    assert resp.status_code == 422
    assert "At least one of shipment_euid or testkit_euid is required" in resp.text


def test_accept_material_rejects_legacy_payload_keys(authed_api_client):
    client, _tenant_id = authed_api_client
    resp = client.post(
        "/api/integrations/bloom/v1/materials/accepted",
        json={
            "order_number": "ORD-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "shipment_euid": "SHP-1",
            "starting_queue": "extraction_prod",
        },
        headers={"Idempotency-Key": "idem-2"},
    )
    assert resp.status_code == 422
    assert "extra_forbidden" in resp.text


def test_accept_material_requires_idempotency_header(authed_api_client):
    client, _tenant_id = authed_api_client
    resp = client.post(
        "/api/integrations/bloom/v1/materials/accepted",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "shipment_euid": "SHP-1",
            "starting_queue": "extraction_prod",
        },
    )
    assert resp.status_code == 400
    assert "Idempotency-Key" in resp.json()["detail"]


def test_accept_material_propagates_validation_error(monkeypatch, authed_api_client):
    client, tenant_id = authed_api_client

    class FakeBridge:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def register_accepted_material(self, data, actor_id=None):
            raise ValueError("TRF not found: TRF-NOPE")

    monkeypatch.setattr(bloom_routes, "ContainerSpecimenBridgeService", FakeBridge)
    resp = client.post(
        "/api/integrations/bloom/v1/materials/accepted",
        json={
            "trf_euid": "TRF-NOPE",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "shipment_euid": "SHP-1",
            "starting_queue": "extraction_prod",
        },
        headers={"Idempotency-Key": "idem-3"},
    )
    assert resp.status_code == 422
    assert "TRF not found" in resp.json()["detail"]


def test_accept_material_happy_path(monkeypatch, authed_api_client):
    client, tenant_id = authed_api_client

    class FakeBridge:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def register_accepted_material(self, data, actor_id=None):
            assert data.trf_euid == "TRF-1"
            assert data.test_euids == ["TST-1", "TST-2"]
            assert data.starting_queue == "extraction_prod"
            return SimpleNamespace(
                container_external_object_euid="EXB-1",
                specimen_external_object_euid="EXB-2",
                container_euid="CNT-1",
                specimen_euid="SP-1",
                starting_queue="extraction_prod",
                current_queue="extraction_prod",
                created=True,
                queue_idempotent_replay=False,
                fulfillment_item_euids=["TPI-1", "TPI-2"],
            )

    monkeypatch.setattr(bloom_routes, "ContainerSpecimenBridgeService", FakeBridge)
    resp = client.post(
        "/api/integrations/bloom/v1/materials/accepted",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1", "TST-2"],
            "patient_euid": "PAT-1",
            "shipment_euid": "SHP-1",
            "starting_queue": "extraction_prod",
            "properties": {"received_barcode": "BC-1001"},
        },
        headers={"Idempotency-Key": "idem-4"},
    )
    assert resp.status_code == 201
    payload = resp.json()
    assert payload["accepted"] is True
    assert payload["idempotent_replay"] is False
    assert payload["trf_euid"] == "TRF-1"
    assert payload["test_euids"] == ["TST-1", "TST-2"]
    assert payload["fulfillment_item_euids"] == ["TPI-1", "TPI-2"]
    assert payload["container_euid"] == "CNT-1"
    assert payload["specimen_euid"] == "SP-1"
    assert payload["current_queue"] == "extraction_prod"


def test_bloom_webhook_signature_and_duplicate_handling(api_client, monkeypatch):
    seen_events: set[tuple[str, str]] = set()
    bridge_calls: list[tuple[str, dict]] = []

    class FakeConfigService:
        def __init__(self, db):
            self.db = db

        def get(self, organization_id):
            return SimpleNamespace(
                enabled=True,
                bloom_webhook_secret_ref="env:FAKE_BLOOM_WEBHOOK_SECRET",
                bloom_base_url="https://bloom.local",
                bloom_api_key_secret_ref="env:FAKE_BLOOM_API_KEY",
            )

        def mark_webhook_event_received(self, *, provider, tenant_id, event_id):
            key = (str(tenant_id), event_id)
            if key in seen_events:
                return False
            seen_events.add(key)
            return True

    class FakeBridge:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def apply_bloom_event(self, *, event_type, event_payload, actor_id=None):
            bridge_calls.append((event_type, event_payload))

    monkeypatch.setattr(bloom_routes, "OrgBloomConfigService", FakeConfigService)
    monkeypatch.setattr(bloom_routes, "ContainerSpecimenBridgeService", FakeBridge)
    monkeypatch.setattr(bloom_routes, "resolve_secret_value", lambda _ref: "super-secret")

    org_id = str(uuid.uuid4())
    body_obj = {
        "organization_id": org_id,
        "event_id": "evt-abc-123",
        "event_type": "container.status_changed",
        "payload": {"euid": "CNT0001", "status": "received"},
    }
    body = json.dumps(body_obj, separators=(",", ":")).encode("utf-8")
    signature = hmac.new(b"super-secret", body, hashlib.sha256).hexdigest()

    headers = {
        "Content-Type": "application/json",
        "X-Bloom-Signature": f"sha256={signature}",
        "X-Bloom-Event-Id": "evt-abc-123",
    }

    first = api_client.post("/api/integrations/bloom/v1/events", content=body, headers=headers)
    assert first.status_code == 202
    assert first.json()["status"] == "processed"
    assert len(bridge_calls) == 1

    second = api_client.post("/api/integrations/bloom/v1/events", content=body, headers=headers)
    assert second.status_code == 202
    assert second.json()["status"] == "duplicate"
    assert len(bridge_calls) == 1


def test_test_status_event_requires_idempotency_header(cross_tenant_authed_api_client):
    client, tenant_id = cross_tenant_authed_api_client
    resp = client.post(
        f"/api/integrations/bloom/v1/tests/{uuid.uuid4()}/status-events",
        json={
            "event_id": "evt-status-1",
            "status": "IN_PROGRESS",
            "occurred_at": "2026-03-03T00:00:00Z",
        },
        headers={"X-Atlas-Tenant-Id": str(tenant_id)},
    )
    assert resp.status_code == 400
    assert "Idempotency-Key" in resp.json()["detail"]


def test_test_status_event_requires_tenant_header(cross_tenant_authed_api_client):
    client, _tenant_id = cross_tenant_authed_api_client
    resp = client.post(
        f"/api/integrations/bloom/v1/tests/{uuid.uuid4()}/status-events",
        json={
            "event_id": "evt-status-2",
            "status": "IN_PROGRESS",
            "occurred_at": "2026-03-03T00:00:00Z",
        },
        headers={"Idempotency-Key": "idem-status-1"},
    )
    assert resp.status_code == 400
    assert "X-Atlas-Tenant-Id" in resp.json()["detail"]


def test_test_status_event_happy_path(monkeypatch, cross_tenant_authed_api_client):
    client, tenant_id = cross_tenant_authed_api_client
    test_euid = "TST-123"

    class FakeStatusService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def apply_test_status_event(self, **kwargs):
            assert kwargs["test_euid"] == test_euid
            return SimpleNamespace(
                applied=True,
                idempotent_replay=False,
                test_euid=test_euid,
                test_status="IN_PROGRESS",
                trf_euid="TRF-1",
                trf_number="TRF-1",
                trf_status="IN_PROGRESS",
                status_event_id="SE-1",
                trf_status_event_id="SE-2",
            )

    monkeypatch.setattr(bloom_routes, "BloomStatusEventService", FakeStatusService)
    resp = client.post(
        f"/api/integrations/bloom/v1/tests/{test_euid}/status-events",
        json={
            "event_id": "evt-status-3",
            "status": "IN_PROGRESS",
            "occurred_at": "2026-03-03T00:00:00Z",
        },
        headers={
            "X-Atlas-Tenant-Id": str(tenant_id),
            "Idempotency-Key": "idem-status-2",
        },
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["test_euid"] == test_euid
    assert payload["trf_euid"] == "TRF-1"
    assert payload["trf_number"] == "TRF-1"


def test_test_status_event_maps_not_found(monkeypatch, cross_tenant_authed_api_client):
    client, tenant_id = cross_tenant_authed_api_client

    class FakeStatusService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def apply_test_status_event(self, **kwargs):
            raise bloom_routes.BloomStatusEventNotFoundError("Test not found")

    monkeypatch.setattr(bloom_routes, "BloomStatusEventService", FakeStatusService)
    resp = client.post(
        "/api/integrations/bloom/v1/tests/TST-404/status-events",
        json={
            "event_id": "evt-status-404",
            "status": "FAILED",
            "occurred_at": "2026-03-03T00:00:00Z",
        },
        headers={
            "X-Atlas-Tenant-Id": str(tenant_id),
            "Idempotency-Key": "idem-status-404",
        },
    )
    assert resp.status_code == 404


def test_restricted_global_token_cannot_call_creation_endpoints(api_client, monkeypatch):
    class FakeAPIClientService:
        def __init__(self, db, tenant_id):
            self.db = db
            self.tenant_id = tenant_id

        def validate_api_key_any_tenant(self, _api_key):
            return (
                SimpleNamespace(
                    id=uuid.uuid4(),
                    tenant_id=uuid.uuid4(),
                    client_name="restricted-bloom-client",
                ),
                SimpleNamespace(
                    permissions=["bloom:atlas:write", "cross_tenant:read", "cross_tenant:write"],
                    allowed_endpoints=["/api/integrations/bloom/v1/lookups/containers"],
                ),
            )

        def log_usage(self, **kwargs):
            return None

    monkeypatch.setattr(auth_deps, "APIClientService", FakeAPIClientService)
    resp = api_client.post(
        "/api/integrations/bloom/v1/materials/accepted",
        json={
            "trf_euid": "TRF-1",
            "test_euids": ["TST-1"],
            "patient_euid": "PAT-1",
            "shipment_euid": "SHP-1",
            "starting_queue": "extraction_prod",
        },
        headers={
            "Authorization": "Bearer restricted-token",
            "Idempotency-Key": "blocked-create-1",
        },
    )
    assert resp.status_code == 403
    assert "not allowed" in resp.json()["detail"].lower()
