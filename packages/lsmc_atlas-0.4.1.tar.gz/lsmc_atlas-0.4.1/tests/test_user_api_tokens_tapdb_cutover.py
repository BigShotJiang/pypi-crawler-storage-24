"""Unit tests for TapDB cutover behavior in UserAPITokenService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

from app.domain.services import user_api_tokens as token_service
from app.domain.services.user_api_tokens import TokenCreate, UserAPITokenService


@dataclass
class _MockDB:
    added: list[object]

    def __init__(self):
        self.added = []

    def add(self, obj):
        self.added.append(obj)

    def commit(self):
        return None


class _FakeGroupRepo:
    def __init__(self, user_id: uuid.UUID):
        self.user_id = user_id
        self.calls: list[str] = []
        self.group = SimpleNamespace(id=uuid.uuid4(), euid=f"GRP-{uuid.uuid4().int % 10000}")

    def get_group_by_code(self, group_code):
        self.calls.append("get_group_by_code")
        return self.group

    def list_group_members(self, group_id):
        self.calls.append("list_group_members")
        return [SimpleNamespace(user_id=self.user_id, is_active=True)]


class _FakeTokenRepo:
    def __init__(self, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.calls: list[str] = []
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.token = SimpleNamespace(
            id=uuid.uuid4(),
            euid=f"UAT-{uuid.uuid4().int % 10000}",
            tenant_id=tenant_id,
            user_id=user_id,
            token_name="Test Token",
            token_prefix="lsmc_test...",
            scope="ext_org",
            created_at=datetime.now(UTC),
        )
        self.revision = SimpleNamespace(
            token_id=self.token.euid,
            revision_id=uuid.uuid4(),
            revision_no=1,
            token_hash="",
            status="ACTIVE",
            expires_at=datetime.now(UTC) + timedelta(days=90),
            last_used_at=None,
            revoked_at=None,
            revoked_by=None,
            revocation_reason=None,
        )
        self.logs = [SimpleNamespace(id=uuid.uuid4())]

    def create_token(self, **kwargs):
        self.calls.append("create_token")
        self.token.token_name = kwargs["token_name"]
        self.token.token_prefix = kwargs["token_prefix"]
        self.token.scope = kwargs["scope"]
        self.revision.token_hash = kwargs["token_hash"]
        self.revision.expires_at = kwargs["expires_at"]
        self.revision.status = "ACTIVE"
        return self.token, self.revision

    def list_tokens(self, tenant_id, user_id=None, skip=0, limit=100):
        self.calls.append("list_tokens")
        return [self.token]

    def get_latest_revision(self, token_id):
        self.calls.append("get_latest_revision")
        if token_id == self.token.euid:
            return self.revision
        return None

    def count_usage(self, token_id):
        self.calls.append("count_usage")
        return len(self.logs)

    def get_token(self, token_id, tenant_id=None):
        self.calls.append("get_token")
        if token_id != self.token.euid:
            return None
        return self.token, self.revision

    def create_revision(self, **kwargs):
        self.calls.append("create_revision")
        self.revision = SimpleNamespace(
            token_id=kwargs["token_id"],
            revision_id=uuid.uuid4(),
            revision_no=kwargs["revision_no"],
            token_hash=kwargs["token_hash"],
            status=kwargs["status"],
            expires_at=kwargs["expires_at"],
            last_used_at=kwargs["last_used_at"],
            revoked_at=kwargs["revoked_at"],
            revoked_by=kwargs["revoked_by"],
            revocation_reason=kwargs["revocation_reason"],
        )
        return self.revision

    def find_latest_revision_by_hash(self, token_hash):
        self.calls.append("find_latest_revision_by_hash")
        if token_hash == self.revision.token_hash:
            return self.revision
        return None

    def log_usage(self, **kwargs):
        self.calls.append("log_usage")

    def get_usage_logs(self, token_id, limit=100):
        self.calls.append("get_usage_logs")
        return self.logs

    def get_usage_stats(self, token_id):
        self.calls.append("get_usage_stats")
        return {
            "total_requests": len(self.logs),
            "endpoints": {"/api/patients": 1},
            "status_codes": {200: 1},
            "last_request_at": datetime.now(UTC),
        }

    def count_tokens(self, tenant_id=None, user_id=None):
        self.calls.append("count_tokens")
        return 1


def test_user_api_token_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    user_id = uuid.uuid4()
    svc = UserAPITokenService(_MockDB(), tenant_id=tenant_id)

    fake_token_repo = _FakeTokenRepo(tenant_id=tenant_id, user_id=user_id)
    fake_group_repo = _FakeGroupRepo(user_id=user_id)

    monkeypatch.setattr(svc, "_repo", lambda: fake_token_repo)
    monkeypatch.setattr(svc, "_groups", lambda: fake_group_repo)
    monkeypatch.setattr(token_service, "generate_token", lambda: "lsmc_plain_token")

    assert svc.user_has_api_access(user_id) is True

    token, revision, plaintext = svc.create(
        user_id=user_id,
        data=TokenCreate(token_name="Cutover Token", expires_in_days=30, scope="ext_org"),
        created_by=user_id,
    )
    assert token.token_name == "Cutover Token"
    assert plaintext == "lsmc_plain_token"

    listed = svc.list_user_tokens(user_id)
    assert len(listed) == 1

    token_result = svc.get_token(token.euid)
    assert token_result is not None

    validated = svc.validate("lsmc_plain_token")
    assert validated.is_valid is True
    assert validated.user_id == user_id

    revoked = svc.revoke(token.euid, revoked_by=user_id, reason="security")
    assert revoked is not None
    assert revoked[1].status == "REVOKED"

    svc.update_last_used(token.euid)
    svc.log_usage(
        token_id=token.euid,
        tenant_id=tenant_id,
        endpoint="/api/patients",
        http_method="GET",
        response_status=200,
    )

    logs = svc.get_usage_logs(token.euid)
    assert logs == fake_token_repo.logs

    stats = svc.get_usage_stats(token.euid)
    assert stats["total_requests"] == 1

    admin_list = svc.list_all_tokens()
    assert len(admin_list) == 1

    assert svc.count_tokens() == 1

    assert "create_token" in fake_token_repo.calls
    assert "find_latest_revision_by_hash" in fake_token_repo.calls
    assert "create_revision" in fake_token_repo.calls
    assert "log_usage" in fake_token_repo.calls
    assert "get_usage_logs" in fake_token_repo.calls
    assert "get_usage_stats" in fake_token_repo.calls
    assert "count_tokens" in fake_token_repo.calls
