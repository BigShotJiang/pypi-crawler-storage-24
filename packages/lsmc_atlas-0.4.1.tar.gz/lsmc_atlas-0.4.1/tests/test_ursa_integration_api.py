"""Tests for the Atlas Ursa result-return integration API."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest

import app.api.routes.ursa_integration as ursa_routes

pytestmark = pytest.mark.db


def test_ursa_return_requires_internal_api_key(client):
    resp = client.post(
        "/api/integrations/ursa/v1/fulfillment-items/TPC-1/analysis-results",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-1",
            "atlas_test_fulfillment_item_euid": "TPC-1",
            "analysis_euid": "AN-1",
            "run_euid": "RUN-1",
            "sequenced_library_assignment_euid": "SQA-1",
            "flowcell_id": "FLOW-1",
            "lane": "1",
            "library_barcode": "LIB-1",
            "analysis_type": "WGS",
            "result_status": "COMPLETED",
            "review_state": "APPROVED",
            "source_system": "daylily-ursa",
            "result_payload": {},
            "artifacts": [],
        },
        headers={"Idempotency-Key": "idem-1"},
    )
    assert resp.status_code == 401


def test_ursa_return_requires_idempotency_header(internal_client):
    resp = internal_client.post(
        "/api/integrations/ursa/v1/fulfillment-items/TPC-1/analysis-results",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-1",
            "atlas_test_fulfillment_item_euid": "TPC-1",
            "analysis_euid": "AN-1",
            "run_euid": "RUN-1",
            "sequenced_library_assignment_euid": "SQA-1",
            "flowcell_id": "FLOW-1",
            "lane": "1",
            "library_barcode": "LIB-1",
            "analysis_type": "WGS",
            "result_status": "COMPLETED",
            "review_state": "APPROVED",
            "source_system": "daylily-ursa",
            "result_payload": {},
            "artifacts": [],
        },
    )
    assert resp.status_code == 400
    assert "Idempotency-Key" in resp.json()["detail"]


def test_ursa_return_rejects_path_body_mismatch(internal_client):
    resp = internal_client.post(
        "/api/integrations/ursa/v1/fulfillment-items/TPC-1/analysis-results",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-2",
            "atlas_test_fulfillment_item_euid": "TPC-2",
            "analysis_euid": "AN-1",
            "run_euid": "RUN-1",
            "sequenced_library_assignment_euid": "SQA-1",
            "flowcell_id": "FLOW-1",
            "lane": "1",
            "library_barcode": "LIB-1",
            "analysis_type": "WGS",
            "result_status": "COMPLETED",
            "review_state": "APPROVED",
            "source_system": "daylily-ursa",
            "result_payload": {},
            "artifacts": [],
        },
        headers={"Idempotency-Key": "idem-2"},
    )
    assert resp.status_code == 400
    assert "does not match body" in resp.json()["detail"]


def test_ursa_return_rejects_legacy_payload_keys(internal_client):
    resp = internal_client.post(
        "/api/integrations/ursa/v1/fulfillment-items/TPC-1/analysis-results",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-1",
            "atlas_test_fulfillment_item_euid": "TPC-1",
            "analysis_euid": "AN-1",
            "run_euid": "RUN-1",
            "sequenced_library_assignment_euid": "SQA-1",
            "flowcell_id": "FLOW-1",
            "lane": "1",
            "library_barcode": "LIB-1",
            "analysis_type": "WGS",
            "result_status": "COMPLETED",
            "review_state": "APPROVED",
            "source_system": "daylily-ursa",
            "tenant_id": str(uuid.uuid4()),
            "result_payload": {},
            "artifacts": [],
        },
        headers={"Idempotency-Key": "idem-3"},
    )
    assert resp.status_code == 422
    assert "extra_forbidden" in resp.text


def test_ursa_return_happy_path(monkeypatch, internal_client):
    tenant_id = uuid.uuid4()

    class FakeService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def apply(self, data):
            assert data.atlas_trf_euid == "TRF-1"
            assert data.atlas_test_euid == "TST-1"
            assert data.atlas_test_fulfillment_item_euid == "TPC-1"
            assert data.analysis_euid == "AN-1"
            assert data.artifacts[0].artifact_euid == "AT-1"
            return SimpleNamespace(
                fulfillment_run_euid="ASR-1",
                fulfillment_output_euid="RES-1",
                artifact_euids=["ART-1"],
                results_set_euid="RS-1",
                idempotent_replay=False,
            )

    monkeypatch.setattr(ursa_routes, "UrsaResultReturnService", FakeService)

    resp = internal_client.post(
        "/api/integrations/ursa/v1/fulfillment-items/TPC-1/analysis-results",
        json={
            "atlas_tenant_id": str(tenant_id),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-1",
            "atlas_test_fulfillment_item_euid": "TPC-1",
            "analysis_euid": "AN-1",
            "run_euid": "RUN-1",
            "sequenced_library_assignment_euid": "SQA-1",
            "flowcell_id": "FLOW-1",
            "lane": "1",
            "library_barcode": "LIB-1",
            "analysis_type": "WGS",
            "result_status": "COMPLETED",
            "review_state": "APPROVED",
            "source_system": "daylily-ursa",
            "result_payload": {"variants": []},
            "artifacts": [
                {
                    "artifact_euid": "AT-1",
                }
            ],
        },
        headers={"Idempotency-Key": "idem-4"},
    )

    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert body["accepted"] is True
    assert body["idempotent_replay"] is False
    assert body["fulfillment_run_euid"] == "ASR-1"
    assert body["fulfillment_output_euid"] == "RES-1"
    assert body["artifact_euids"] == ["ART-1"]
    assert body["results_set_euid"] == "RS-1"


def test_ursa_return_target_requires_internal_api_key(client):
    resp = client.post(
        "/api/integrations/ursa/v1/return-targets/resolve",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-1",
        },
    )
    assert resp.status_code == 401


def test_ursa_return_target_happy_path(monkeypatch, internal_client):
    class FakeStoragePolicyService:
        def __init__(self, db):
            _ = db

        def resolve_ursa_return_target(self, **kwargs):
            assert kwargs["atlas_tenant_id"]
            assert kwargs["atlas_trf_euid"] == "TRF-1"
            assert kwargs["atlas_test_euid"] == "TST-1"
            return SimpleNamespace(
                effective_policy=SimpleNamespace(
                    scope="site",
                    policy=SimpleNamespace(
                        policy_euid="SPT-1",
                        access_mode="lsmc_managed",
                        region="us-west-2",
                    ),
                ),
                atlas_tenant_id=kwargs["atlas_tenant_id"],
                atlas_site_euid="SITE-1",
                atlas_trf_euid="TRF-1",
                atlas_test_euid="TST-1",
                bucket="atlas-bucket",
                key_prefix="sites/SITE-1/trfs/TRF-1/tests/TST-1",
                storage_uri_prefix="s3://atlas-bucket/sites/SITE-1/trfs/TRF-1/tests/TST-1/",
            )

    monkeypatch.setattr(ursa_routes, "StoragePolicyService", FakeStoragePolicyService)

    resp = internal_client.post(
        "/api/integrations/ursa/v1/return-targets/resolve",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-1",
        },
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["storage_policy_euid"] == "SPT-1"
    assert body["storage_policy_scope"] == "site"
    assert body["atlas_site_euid"] == "SITE-1"
    assert body["bucket"] == "atlas-bucket"
    assert body["key_prefix"] == "sites/SITE-1/trfs/TRF-1/tests/TST-1"


def test_ursa_return_target_surfaces_validation_error(monkeypatch, internal_client):
    class FakeStoragePolicyService:
        def __init__(self, db):
            _ = db

        def resolve_ursa_return_target(self, **kwargs):
            _ = kwargs
            raise ValueError("Test TST-1 does not belong to TRF TRF-1")

    monkeypatch.setattr(ursa_routes, "StoragePolicyService", FakeStoragePolicyService)
    resp = internal_client.post(
        "/api/integrations/ursa/v1/return-targets/resolve",
        json={
            "atlas_tenant_id": str(uuid.uuid4()),
            "atlas_trf_euid": "TRF-1",
            "atlas_test_euid": "TST-1",
        },
    )
    assert resp.status_code == 400
    assert "does not belong" in resp.json()["detail"]
