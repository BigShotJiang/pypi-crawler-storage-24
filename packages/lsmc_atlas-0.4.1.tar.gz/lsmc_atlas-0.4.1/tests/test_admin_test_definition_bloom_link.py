"""Admin UI tests for Bloom lab_method linkage on Test (Assay) catalog items."""

from __future__ import annotations

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def admin_user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="admin@lsmc.bio",
        name="Admin User",
        tenant_id=tenant_id,
        roles=[Role.ADMIN.value],
    )


@pytest.fixture
def setup_tenant(db_session: Session, tenant_id: uuid.UUID):
    ensure_tapdb_org(db_session, tenant_id, name="test-tenant", display_name="Test Tenant")
    db_session.flush()


def _client(db_session: Session, user: CurrentUser) -> TestClient:
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        yield db_session

    def override_user():
        return user

    async def override_csrf():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    return TestClient(app)


@pytest.mark.db
def test_admin_assay_can_link_bloom_lab_method_euid(
    db_session: Session, admin_user: CurrentUser, setup_tenant
):
    from app.domain.services.test_definitions import TestDefinitionService
    from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

    c = _client(db_session, admin_user)
    try:
        resp = c.post(
            "/admin/test-definitions/create",
            data={
                "code": "SMK-LAB-1",
                "name": "Smoke Test Catalog Item",
                "bloom_lab_method_euid": "LAB-ASY-123",
            },
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER, resp.text[:2000]

        assay = TestDefinitionService(db_session).get_by_code("SMK-LAB-1")
        assert assay is not None

        global_tenant_id = uuid.UUID(int=0)
        ext_repo = TapdbExternalObjectRepository(db_session)
        rels = ext_repo.list_relations_for_local_entity(
            tenant_id=global_tenant_id,
            local_entity_type="Test",
            local_entity_id=assay.euid,
        )
        rels = [r for r in rels if r.relation_type == "lab_method_for_test"]
        assert len(rels) == 1

        ext = ext_repo.get_external_object_by_id(rels[0].external_object_id)
        assert ext is not None
        assert ext.provider == "bloom"
        assert ext.object_type == "lab_method"
        assert ext.external_euid == "LAB-ASY-123"

        # UI renders it on detail page
        resp = c.get(f"/admin/test-definitions/{assay.euid}")
        assert resp.status_code == status.HTTP_200_OK
        assert "LAB-ASY-123" in resp.text
    finally:
        app.dependency_overrides.clear()


@pytest.mark.db
def test_admin_assay_specimen_types_are_normalized_and_updateable(
    db_session: Session, admin_user: CurrentUser, setup_tenant
):
    from app.domain.services.test_definitions import TestDefinitionService

    c = _client(db_session, admin_user)
    try:
        resp = c.post(
            "/admin/test-definitions/create",
            data={
                "code": "SMK-SP-1",
                "name": "Specimen Type Catalog Item",
                "specimen_types": "blood, saliva, BLOOD, buccal_swab",
            },
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER, resp.text[:2000]

        assay_svc = TestDefinitionService(db_session)
        assay = assay_svc.get_by_code("SMK-SP-1")
        assert assay is not None
        assert assay.specimen_types == ["BLOOD", "SALIVA", "BUCCAL_SWAB"]

        resp = c.post(
            f"/admin/test-definitions/{assay.euid}/edit",
            data={
                "name": "Specimen Type Catalog Item Updated",
                "description": "Updated specimen policy",
                "category": "sequencing",
                "technology": "short_read_ilmn",
                "specimen_types": "urine, saliva, URINE",
                "is_active": "true",
            },
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER, resp.text[:2000]

        updated = assay_svc.get_by_euid(assay.euid)
        assert updated is not None
        assert updated.specimen_types == ["URINE", "SALIVA"]

        resp = c.get(f"/admin/test-definitions/{assay.euid}")
        assert resp.status_code == status.HTTP_200_OK
        assert "Allowed Specimen Types" in resp.text
        assert "URINE, SALIVA" in resp.text
    finally:
        app.dependency_overrides.clear()
