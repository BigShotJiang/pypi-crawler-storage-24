"""Tests for rate limiting middleware."""

from app.auth.rate_limiting import (
    RateLimitConfig,
    RateLimiter,
    get_limiter,
)


class TestRateLimiter:
    """Test the RateLimiter class."""

    def test_basic_rate_limit_allows_requests(self):
        """Test that requests within limits are allowed."""
        config = RateLimitConfig(requests_per_minute=10, requests_per_hour=100)
        limiter = RateLimiter(config)

        for i in range(10):
            allowed, msg = limiter.check_rate_limit("test_key")
            assert allowed, f"Request {i + 1} should be allowed"
            assert msg is None

    def test_rate_limit_blocks_after_exceeding(self):
        """Test that requests are blocked after exceeding limit."""
        config = RateLimitConfig(
            requests_per_minute=5, requests_per_hour=100, block_duration_seconds=60
        )
        limiter = RateLimiter(config)

        # Use up all requests
        for _ in range(5):
            limiter.check_rate_limit("test_key")

        # Next request should be blocked
        allowed, msg = limiter.check_rate_limit("test_key")
        assert not allowed
        assert "rate limit" in msg.lower()

    def test_burst_limit(self):
        """Test burst limit protection."""
        config = RateLimitConfig(
            requests_per_minute=100,
            requests_per_hour=1000,
            burst_limit=3,
            block_duration_seconds=60,
        )
        limiter = RateLimiter(config)

        # Make 3 rapid requests (burst limit)
        for _ in range(3):
            allowed, _ = limiter.check_rate_limit("burst_key")
            assert allowed

        # 4th request within same second should trigger burst block
        allowed, msg = limiter.check_rate_limit("burst_key")
        assert not allowed
        assert "burst" in msg.lower()

    def test_different_keys_are_isolated(self):
        """Test that rate limits are tracked per key."""
        config = RateLimitConfig(requests_per_minute=3)
        limiter = RateLimiter(config)

        # Exhaust key1
        for _ in range(3):
            limiter.check_rate_limit("key1")

        # key1 should be blocked
        allowed1, _ = limiter.check_rate_limit("key1")
        assert not allowed1

        # key2 should still work
        allowed2, _ = limiter.check_rate_limit("key2")
        assert allowed2

    def test_is_blocked(self):
        """Test is_blocked method."""
        config = RateLimitConfig(requests_per_minute=1, block_duration_seconds=60)
        limiter = RateLimiter(config)

        # Make request to start tracking
        limiter.check_rate_limit("blocked_key")
        # Exhaust and trigger block
        limiter.check_rate_limit("blocked_key")

        assert limiter.is_blocked("blocked_key")
        assert not limiter.is_blocked("other_key")

    def test_get_remaining(self):
        """Test remaining count calculation."""
        config = RateLimitConfig(requests_per_minute=10, requests_per_hour=100)
        limiter = RateLimiter(config)

        # Make 3 requests
        for _ in range(3):
            limiter.check_rate_limit("count_key")

        remaining = limiter.get_remaining("count_key")
        assert remaining["remaining_per_minute"] == 7
        assert remaining["remaining_per_hour"] == 97


class TestGetLimiter:
    """Test the get_limiter factory function.

    These tests allow both dev and production default profiles because
    larger suites may adjust runtime settings before this module executes.
    """

    def test_get_default_limiter(self):
        """Test getting default limiter."""
        limiter = get_limiter()
        assert limiter is not None
        assert limiter.config.requests_per_minute in {60, 600}

    def test_get_auth_limiter(self):
        """Test getting auth limiter."""
        limiter = get_limiter("auth")
        assert limiter.config.requests_per_minute in {10, 100}
        assert limiter.config.burst_limit in {3, 20}

    def test_get_api_limiter(self):
        """Test getting API limiter."""
        limiter = get_limiter("api")
        assert limiter.config.requests_per_minute in {120, 600}

    def test_get_sensitive_limiter(self):
        """Test getting sensitive operations limiter."""
        limiter = get_limiter("sensitive")
        assert limiter.config.requests_per_minute in {5, 50}

    def test_get_auth_callback_limiter(self):
        """Test getting callback-specific auth limiter."""
        limiter = get_limiter("auth_callback")
        assert limiter.config.requests_per_minute in {60, 300}
        assert limiter.config.burst_limit in {10, 30}

    def test_get_unknown_returns_default(self):
        """Test that unknown limiter type returns default profile."""
        default = get_limiter()
        limiter = get_limiter("nonexistent")
        assert limiter.config.requests_per_minute == default.config.requests_per_minute
