"""API tests for canonical TRF/Test routes."""

from __future__ import annotations

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.domain.services.people import (
    ClinicianCreate,
    ClinicianService,
    PatientCreate,
    PatientService,
)
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def api_user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="api-user@lsmc.bio",
        name="API User",
        tenant_id=tenant_id,
        roles=[Role.INTERNAL_USER.value],
    )


@pytest.fixture
def setup_tenant(db_session: Session, tenant_id: uuid.UUID) -> None:
    ensure_tapdb_org(db_session, tenant_id, name="trf-api-org", display_name="TRF API Org")
    db_session.flush()


def create_api_client(db_session: Session, user: CurrentUser) -> TestClient:
    from app.auth.dependencies import (
        get_current_user,
        get_current_user_or_token,
        get_current_user_web,
    )

    def override_get_db():
        yield db_session

    def override_get_current_user():
        return user

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user
    app.dependency_overrides[get_current_user_or_token] = override_get_current_user
    app.dependency_overrides[get_current_user_web] = override_get_current_user
    return TestClient(app)


def _create_patient(db_session: Session, user: CurrentUser, *, first_name: str, last_name: str):
    svc = PatientService(db_session, user.tenant_id, uuid.UUID(user.sub))
    patient, _revision = svc.create(
        PatientCreate(first_name=first_name, last_name=last_name),
        created_by=uuid.UUID(user.sub),
    )
    return patient


def _create_clinician(db_session: Session, user: CurrentUser):
    svc = ClinicianService(db_session, user.tenant_id, uuid.UUID(user.sub))
    clinician, _revision = svc.create(
        ClinicianCreate(first_name="Chris", last_name="Clinician"),
        created_by=uuid.UUID(user.sub),
    )
    return clinician


@pytest.mark.db
def test_post_trfs_creates_trf(db_session: Session, api_user: CurrentUser, setup_tenant):
    client = create_api_client(db_session, api_user)
    try:
        clinician = _create_clinician(db_session, api_user)
        resp = client.post(
            "/api/trfs",
            json={
                "clinician_id": str(clinician.euid),
                "trf_type": "CLINICAL",
                "clinical_notes": "Initial TRF",
            },
        )
        assert resp.status_code == status.HTTP_201_CREATED
        body = resp.json()
        assert body["trf_euid"].startswith("TRF")
        assert body["trf_number"] == body["trf_euid"]
        assert body["clinician_id"] == str(clinician.euid)
        assert body["trf_type"] == "CLINICAL"
    finally:
        app.dependency_overrides.clear()


@pytest.mark.db
def test_post_tests_enforces_unique_proband_role(
    db_session: Session, api_user: CurrentUser, setup_tenant
):
    client = create_api_client(db_session, api_user)
    try:
        trf_resp = client.post("/api/trfs", json={"trf_type": "CLINICAL"})
        assert trf_resp.status_code == status.HTTP_201_CREATED
        trf_euid = trf_resp.json()["trf_euid"]

        p1 = _create_patient(db_session, api_user, first_name="A", last_name="One")
        p2 = _create_patient(db_session, api_user, first_name="B", last_name="Two")

        resp = client.post(
            f"/api/trfs/{trf_euid}/tests",
            json={
                "patients": [
                    {"patient_euid": str(p1.euid), "role": "PROBAND"},
                    {"patient_euid": str(p2.euid), "role": "PROBAND"},
                ],
                "fulfillment_routes": [
                    {
                        "fulfillment_route_code": "WGS",
                        "fulfillment_route_name": "Whole Genome",
                    }
                ],
                "priority": "NORMAL",
            },
        )
        assert resp.status_code == status.HTTP_400_BAD_REQUEST
        assert "Only one PROBAND" in resp.json()["detail"]
    finally:
        app.dependency_overrides.clear()


@pytest.mark.db
def test_create_and_get_test_by_euid(db_session: Session, api_user: CurrentUser, setup_tenant):
    client = create_api_client(db_session, api_user)
    try:
        trf_resp = client.post("/api/trfs", json={"trf_type": "CLINICAL"})
        assert trf_resp.status_code == status.HTTP_201_CREATED
        trf_euid = trf_resp.json()["trf_euid"]

        patient = _create_patient(db_session, api_user, first_name="Pat", last_name="Graph")

        create_resp = client.post(
            f"/api/trfs/{trf_euid}/tests",
            json={
                "patients": [{"patient_euid": str(patient.euid), "role": "PROBAND"}],
                "fulfillment_routes": [
                    {
                        "fulfillment_route_code": "WGS",
                        "fulfillment_route_name": "Whole Genome",
                    },
                    {
                        "fulfillment_route_code": "RNA",
                        "fulfillment_route_name": "RNA",
                    },
                ],
                "specimen_type": "blood-whole",
                "priority": "NORMAL",
            },
        )
        assert create_resp.status_code == status.HTTP_201_CREATED
        test_euid = create_resp.json()["euid"]
        assert test_euid.startswith("TST")

        get_resp = client.get(f"/api/trfs/tests/{test_euid}")
        assert get_resp.status_code == status.HTTP_200_OK
        payload = get_resp.json()
        assert payload["trf_euid"] == trf_euid
        assert payload["patients"][0]["patient_euid"] == str(patient.euid)
        assert payload["patients"][0]["role"] == "PROBAND"
        assert {
            route["fulfillment_route_code"] for route in payload["fulfillment_routes"]
        } == {"WGS", "RNA"}
    finally:
        app.dependency_overrides.clear()


@pytest.mark.db
def test_test_links_are_idempotent(db_session: Session, api_user: CurrentUser, setup_tenant):
    client = create_api_client(db_session, api_user)
    try:
        p1 = _create_patient(db_session, api_user, first_name="One", last_name="Alpha")
        p2 = _create_patient(db_session, api_user, first_name="Two", last_name="Beta")

        trf1 = client.post("/api/trfs", json={"trf_type": "CLINICAL"}).json()["trf_euid"]
        trf2 = client.post("/api/trfs", json={"trf_type": "CLINICAL"}).json()["trf_euid"]

        test1 = client.post(
            f"/api/trfs/{trf1}/tests",
            json={
                "patients": [{"patient_euid": str(p1.euid), "role": "PROBAND"}],
                "fulfillment_routes": [{"fulfillment_route_code": "WGS"}],
            },
        ).json()["euid"]
        test2 = client.post(
            f"/api/trfs/{trf2}/tests",
            json={
                "patients": [{"patient_euid": str(p2.euid), "role": "PROBAND"}],
                "fulfillment_routes": [{"fulfillment_route_code": "RNA"}],
            },
        ).json()["euid"]

        self_resp = client.post(
            f"/api/trfs/tests/{test1}/links",
            json={"target_test_euid": test1, "link_type": "generic"},
        )
        assert self_resp.status_code == status.HTTP_400_BAD_REQUEST

        first_link = client.post(
            f"/api/trfs/tests/{test1}/links",
            json={"target_test_euid": test2, "link_type": "generic"},
        )
        assert first_link.status_code == status.HTTP_200_OK

        second_link = client.post(
            f"/api/trfs/tests/{test1}/links",
            json={"target_test_euid": test2, "link_type": "generic"},
        )
        assert second_link.status_code == status.HTTP_200_OK

        get_resp = client.get(f"/api/trfs/tests/{test1}")
        assert get_resp.status_code == status.HTTP_200_OK
        linked_ids = [item["test_euid"] for item in get_resp.json()["linked_tests"]]
        assert linked_ids.count(test2) == 1
    finally:
        app.dependency_overrides.clear()
