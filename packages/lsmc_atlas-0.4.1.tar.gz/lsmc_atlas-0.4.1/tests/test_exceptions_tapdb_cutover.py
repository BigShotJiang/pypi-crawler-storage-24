"""Unit tests for TapDB cutover behavior in ExceptionService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from types import SimpleNamespace

from app.domain.services import exceptions as exceptions_service
from app.domain.services.exceptions import ExceptionCreate, ExceptionService, ExceptionUpdate
from app.persistence.tapdb.orm_models.exceptions import ExceptionStatus, ExceptionType


@dataclass
class _MockDB:
    def add(self, _obj):
        return None

    def commit(self):
        return None


class _FakeExceptionRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.exception = SimpleNamespace(
            id=uuid.uuid4(),
            euid=f"EXC-{uuid.uuid4().int % 10000}",
            tenant_id=tenant_id,
            exception_number="EXC-000001",
            created_at=datetime.now(UTC),
            created_by=uuid.uuid4(),
        )
        self.revision = SimpleNamespace(
            revision_id=uuid.uuid4(),
            exception_id=self.exception.euid,
            revision_no=1,
            exception_type=ExceptionType.MISSING_ID.value,
            status=ExceptionStatus.OPEN.value,
            trigger_entity_type=None,
            trigger_entity_id=None,
            scanned_data=None,
            order_id=None,
            external_object_id=None,
            shipment_id=None,
            assigned_to=None,
            resolution_notes=None,
            resolved_at=None,
            resolved_by=None,
            note=None,
            created_at=datetime.now(UTC),
            created_by=self.exception.created_by,
        )

    def generate_next_exception_number(self, tenant_id):
        self.calls.append("generate_next_exception_number")
        return "EXC-000001"

    def create_exception(self, tenant_id, exception_number, data, created_by):
        self.calls.append("create_exception")
        self.exception.exception_number = exception_number
        self.revision.exception_type = data.exception_type
        self.revision.status = data.status
        return self.exception, self.revision

    def get_exception_with_revision(self, exception_id, tenant_id):
        self.calls.append("get_exception_with_revision")
        if exception_id != self.exception.euid:
            return None
        return self.exception, self.revision

    def get_exception_by_number(self, exception_number, tenant_id):
        self.calls.append("get_exception_by_number")
        if exception_number != self.exception.exception_number:
            return None
        return self.exception, self.revision

    def list_exceptions(
        self,
        tenant_id,
        skip=0,
        limit=50,
        status_filter=None,
        exception_type_filter=None,
    ):
        self.calls.append("list_exceptions")
        return [(self.exception, self.revision)]

    def update_exception(self, exception_id, tenant_id, data, updated_by):
        self.calls.append("update_exception")
        if data.status is not None:
            self.revision.status = data.status
        if data.assigned_to is not None:
            self.revision.assigned_to = data.assigned_to
        if data.note is not None:
            self.revision.note = data.note
        return self.exception, self.revision

    def resolve_exception(self, exception_id, tenant_id, resolution_notes, resolved_by):
        self.calls.append("resolve_exception")
        self.revision.status = ExceptionStatus.RESOLVED.value
        self.revision.resolution_notes = resolution_notes
        self.revision.resolved_by = resolved_by
        self.revision.resolved_at = datetime.now(UTC)
        return self.exception, self.revision


def _noop(*_args, **_kwargs):
    return None


def test_exception_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = ExceptionService(_MockDB(), tenant_id=tenant_id, user_id=str(uuid.uuid4()))
    repo = _FakeExceptionRepo(tenant_id)

    monkeypatch.setattr(svc, "_repo", lambda: repo)
    monkeypatch.setattr(exceptions_service, "emit_exception_created", _noop)
    monkeypatch.setattr(exceptions_service, "emit_exception_resolved", _noop)

    created = svc.create(
        ExceptionCreate(exception_type=ExceptionType.MISSING_ID),
        created_by=uuid.uuid4(),
    )
    assert created[0].exception_number == "EXC-000001"

    assert svc.get(repo.exception.euid) is not None
    assert svc.get_by_exception_number("EXC-000001") is not None
    assert len(svc.list_exceptions()) == 1

    assigned_to = uuid.uuid4()
    updated = svc.update(
        repo.exception.euid,
        ExceptionUpdate(status=ExceptionStatus.ASSIGNED, assigned_to=assigned_to),
        updated_by=uuid.uuid4(),
    )
    assert updated is not None
    assert updated[1].status == ExceptionStatus.ASSIGNED.value
    assert updated[1].assigned_to == assigned_to

    resolved = svc.resolve(
        repo.exception.euid, resolution_notes="Handled", resolved_by=uuid.uuid4()
    )
    assert resolved is not None
    assert resolved[1].status == ExceptionStatus.RESOLVED.value

    escalated = svc.escalate(repo.exception.euid, escalated_by=uuid.uuid4())
    assert escalated is not None
    assert escalated[1].status == ExceptionStatus.ESCALATED.value

    closed = svc.close(repo.exception.euid, closed_by=uuid.uuid4())
    assert closed is not None
    assert closed[1].status == ExceptionStatus.CLOSED.value

    assert repo.calls == [
        "generate_next_exception_number",
        "create_exception",
        "get_exception_with_revision",
        "get_exception_by_number",
        "list_exceptions",
        "update_exception",
        "resolve_exception",
        "update_exception",
        "update_exception",
    ]
