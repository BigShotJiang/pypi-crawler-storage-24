"""Web integration tests for Atlas Families feature.

Covers:
- /families list + create + detail
- membership edges (patient -> family)
- parent edges (father_of, mother_of)
- sibling edges (sibling_of symmetric)
"""

from __future__ import annotations

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="customer@acme-genetics.com",
        name="Customer User",
        tenant_id=tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def setup_tenant(db_session: Session, tenant_id: uuid.UUID):
    ensure_tapdb_org(db_session, tenant_id, name="test-tenant", display_name="Test Tenant")
    db_session.flush()


def create_test_client(db_session: Session, user: CurrentUser) -> TestClient:
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        yield db_session

    def override_get_current_user():
        return user

    async def override_csrf_protect():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user
    app.dependency_overrides[get_current_user_web] = override_get_current_user
    app.dependency_overrides[csrf_protect] = override_csrf_protect
    return TestClient(app)


@pytest.mark.db
def test_families_create_list_and_detail(db_session: Session, user: CurrentUser, setup_tenant):
    client = create_test_client(db_session, user)
    try:
        # Create
        resp = client.post(
            "/families/new",
            data={"name": "Doe Family", "notes": "Test notes"},
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER
        location = resp.headers.get("location") or ""
        assert location.startswith("/families/")
        family_id = location.split("/families/", 1)[1]
        assert family_id

        # Force session to see committed data from the POST
        db_session.expire_all()

        # List includes the family
        resp = client.get("/families")
        assert resp.status_code == status.HTTP_200_OK
        assert "Families" in resp.text
        assert "Doe Family" in resp.text

        # Detail renders
        resp = client.get(f"/families/{family_id}")
        assert resp.status_code == status.HTTP_200_OK
        assert "Doe Family" in resp.text
    finally:
        app.dependency_overrides.clear()


@pytest.mark.db
def test_family_relationship_edges_member_parent_sibling(
    db_session: Session, user: CurrentUser, setup_tenant
):
    from app.domain.services.patient_relationships import PatientRelationshipService
    from app.domain.services.people import PatientCreate, PatientService

    client = create_test_client(db_session, user)
    try:
        # Create family
        resp = client.post(
            "/families/new",
            data={"name": "Smith Family", "notes": ""},
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER
        family_id = resp.headers["location"].split("/families/", 1)[1]

        # Create patients
        patient_svc = PatientService(db_session, user.tenant_id, uuid.UUID(user.sub))
        child, _ = patient_svc.create(
            PatientCreate(first_name="Child", last_name="Smith"),
            created_by=uuid.UUID(user.sub),
        )
        father, _ = patient_svc.create(
            PatientCreate(first_name="Father", last_name="Smith"),
            created_by=uuid.UUID(user.sub),
        )
        mother, _ = patient_svc.create(
            PatientCreate(first_name="Mother", last_name="Smith"),
            created_by=uuid.UUID(user.sub),
        )
        sibling, _ = patient_svc.create(
            PatientCreate(first_name="Sibling", last_name="Smith"),
            created_by=uuid.UUID(user.sub),
        )

        # Add membership
        resp = client.post(
            f"/families/{family_id}/members/add",
            data={"patient_id": str(child.euid)},
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER

        # Set parents
        resp = client.post(
            f"/families/{family_id}/relationships/set-parent",
            data={
                "child_patient_id": str(child.euid),
                "parent_patient_id": str(father.euid),
                "parent_type": "father",
            },
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER
        resp = client.post(
            f"/families/{family_id}/relationships/set-parent",
            data={
                "child_patient_id": str(child.euid),
                "parent_patient_id": str(mother.euid),
                "parent_type": "mother",
            },
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER

        # Add sibling (symmetric edges)
        resp = client.post(
            f"/families/{family_id}/relationships/add-sibling",
            data={"patient_id_a": str(child.euid), "patient_id_b": str(sibling.euid)},
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER

        # Verify graph edges via service
        rel_svc = PatientRelationshipService(db_session, user.tenant_id)
        graph = rel_svc.get_patient_family_graph(child.euid)

        assert family_id in graph.family_ids
        assert graph.father_id == father.euid
        assert graph.mother_id == mother.euid
        assert sibling.euid in graph.sibling_ids

        # Family detail should show member name (sanity)
        resp = client.get(f"/families/{family_id}")
        assert resp.status_code == status.HTTP_200_OK
        assert "Child Smith" in resp.text
    finally:
        app.dependency_overrides.clear()


@pytest.mark.db
def test_family_set_parent_auto_links_missing_members(
    db_session: Session, user: CurrentUser, setup_tenant
):
    from app.domain.services.patient_relationships import PatientRelationshipService
    from app.domain.services.people import PatientCreate, PatientService

    client = create_test_client(db_session, user)
    try:
        resp = client.post(
            "/families/new",
            data={"name": "Auto Link Parent Family", "notes": ""},
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER
        family_id = resp.headers["location"].split("/families/", 1)[1]

        patient_svc = PatientService(db_session, user.tenant_id, uuid.UUID(user.sub))
        child, _ = patient_svc.create(
            PatientCreate(first_name="ChildAuto", last_name="Parent"),
            created_by=uuid.UUID(user.sub),
        )
        father, _ = patient_svc.create(
            PatientCreate(first_name="FatherAuto", last_name="Parent"),
            created_by=uuid.UUID(user.sub),
        )

        resp = client.post(
            f"/families/{family_id}/relationships/set-parent",
            data={
                "child_patient_id": str(child.euid),
                "parent_patient_id": str(father.euid),
                "parent_type": "father",
            },
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER

        rel_svc = PatientRelationshipService(db_session, user.tenant_id)
        member_euids = rel_svc.list_family_member_euids(family_id)
        assert child.euid in member_euids
        assert father.euid in member_euids

        graph = rel_svc.get_patient_family_graph(child.euid)
        assert family_id in graph.family_ids
        assert graph.father_id == father.euid
    finally:
        app.dependency_overrides.clear()


@pytest.mark.db
def test_family_add_sibling_auto_links_missing_members(
    db_session: Session, user: CurrentUser, setup_tenant
):
    from app.domain.services.patient_relationships import PatientRelationshipService
    from app.domain.services.people import PatientCreate, PatientService

    client = create_test_client(db_session, user)
    try:
        resp = client.post(
            "/families/new",
            data={"name": "Auto Link Sibling Family", "notes": ""},
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER
        family_id = resp.headers["location"].split("/families/", 1)[1]

        patient_svc = PatientService(db_session, user.tenant_id, uuid.UUID(user.sub))
        patient_a, _ = patient_svc.create(
            PatientCreate(first_name="SiblingAutoA", last_name="Link"),
            created_by=uuid.UUID(user.sub),
        )
        patient_b, _ = patient_svc.create(
            PatientCreate(first_name="SiblingAutoB", last_name="Link"),
            created_by=uuid.UUID(user.sub),
        )

        resp = client.post(
            f"/families/{family_id}/relationships/add-sibling",
            data={"patient_id_a": str(patient_a.euid), "patient_id_b": str(patient_b.euid)},
            follow_redirects=False,
        )
        assert resp.status_code == status.HTTP_303_SEE_OTHER

        rel_svc = PatientRelationshipService(db_session, user.tenant_id)
        member_euids = rel_svc.list_family_member_euids(family_id)
        assert patient_a.euid in member_euids
        assert patient_b.euid in member_euids

        graph = rel_svc.get_patient_family_graph(patient_a.euid)
        assert family_id in graph.family_ids
        assert patient_b.euid in graph.sibling_ids
    finally:
        app.dependency_overrides.clear()
