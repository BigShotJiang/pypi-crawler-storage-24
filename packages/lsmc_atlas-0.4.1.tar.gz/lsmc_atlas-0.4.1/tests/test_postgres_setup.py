"""TapDB runtime integration tests for Atlas database URL resolution."""

from __future__ import annotations

import sys
import types

import pytest

from app.integrations import tapdb_runtime


def test_database_url_is_derived_from_tapdb_config(monkeypatch):
    monkeypatch.setattr(tapdb_runtime, "ensure_tapdb_version", lambda: "0.1.35")
    monkeypatch.setattr(
        tapdb_runtime,
        "_get_tapdb_db_config_for_env",
        lambda env: {
            "host": "localhost",
            "port": "6432",
            "user": "atlas_user",
            "password": "atlas_pw",
            "database": f"atlas_{env}",
        },
    )

    db_url = tapdb_runtime.export_database_url_for_target(
        target="local",
        profile="lsmc",
        region="us-west-2",
        namespace="lsmc-atlas",
    )

    assert db_url == "postgresql+psycopg2://atlas_user:atlas_pw@localhost:6432/atlas_dev"


def test_local_target_maps_to_dev(monkeypatch):
    called: list[str] = []

    monkeypatch.setattr(tapdb_runtime, "ensure_tapdb_version", lambda: "0.1.35")

    def _fake_get_cfg(env: str) -> dict[str, str]:
        called.append(env)
        return {
            "host": "localhost",
            "port": "5432",
            "user": "u",
            "password": "",
            "database": "d",
        }

    monkeypatch.setattr(tapdb_runtime, "_get_tapdb_db_config_for_env", _fake_get_cfg)
    tapdb_runtime.export_database_url_for_target(target="local")
    assert called == ["dev"]


def test_aurora_target_maps_to_prod(monkeypatch):
    called: list[str] = []

    monkeypatch.setattr(tapdb_runtime, "ensure_tapdb_version", lambda: "0.1.35")

    def _fake_get_cfg(env: str) -> dict[str, str]:
        called.append(env)
        return {
            "host": "aurora.cluster.local",
            "port": "5432",
            "user": "u",
            "password": "",
            "database": "d",
        }

    monkeypatch.setattr(tapdb_runtime, "_get_tapdb_db_config_for_env", _fake_get_cfg)
    tapdb_runtime.export_database_url_for_target(target="aurora")
    assert called == ["prod"]


def test_ensure_tapdb_version_allows_local_override(monkeypatch):
    monkeypatch.setattr(tapdb_runtime.importlib.metadata, "version", lambda _: "0.1.35.dev0")
    monkeypatch.setattr(tapdb_runtime, "_is_local_tapdb_override_install", lambda: True)
    monkeypatch.setitem(
        sys.modules,
        "daylily_tapdb",
        types.SimpleNamespace(__version__="0.1.35.dev0"),
    )

    assert tapdb_runtime.ensure_tapdb_version("0.1.35") == "0.1.35.dev0"


def test_ensure_tapdb_version_rejects_non_local_mismatch(monkeypatch):
    monkeypatch.setattr(tapdb_runtime.importlib.metadata, "version", lambda _: "0.1.14.dev0")
    monkeypatch.setattr(tapdb_runtime, "_is_local_tapdb_override_install", lambda: False)
    monkeypatch.setitem(
        sys.modules,
        "daylily_tapdb",
        types.SimpleNamespace(__version__="0.1.14.dev0"),
    )

    with pytest.raises(tapdb_runtime.TapDBRuntimeError):
        tapdb_runtime.ensure_tapdb_version("0.1.35")
