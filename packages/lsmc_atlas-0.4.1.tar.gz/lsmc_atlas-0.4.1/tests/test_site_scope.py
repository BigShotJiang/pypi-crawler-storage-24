"""Site-scoped linkage invariants for tenant objects."""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy.orm import Session

from app.domain.services.orgs import SiteCreate, SiteService, SiteUpdate
from app.domain.services.site_scope import resolve_tenant_site_euid
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.mark.db
def test_one_site_org_auto_resolves_site(db_session: Session):
    tenant_id = uuid.uuid4()
    org = ensure_tapdb_org(
        db_session, tenant_id, name="auto-site-org", display_name="Auto Site Org"
    )

    sites = SiteService(db_session).list_by_organization(org.euid, active_only=True)
    assert len(sites) == 1

    resolved = resolve_tenant_site_euid(db_session, tenant_id, None)
    assert resolved == sites[0].euid


@pytest.mark.db
def test_multi_site_org_requires_explicit_site(db_session: Session):
    tenant_id = uuid.uuid4()
    org = ensure_tapdb_org(
        db_session, tenant_id, name="multi-site-org", display_name="Multi Site Org"
    )

    SiteService(db_session).create(
        SiteCreate(
            organization_id=org.euid,
            name="Second Site",
            site_code="SECOND",
        ),
        created_by=None,
    )

    with pytest.raises(ValueError, match="Site selection is required"):
        resolve_tenant_site_euid(db_session, tenant_id, None)


@pytest.mark.db
def test_cross_tenant_site_selection_is_rejected(db_session: Session):
    tenant_a = uuid.uuid4()
    tenant_b = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_a, name="org-a", display_name="Org A")
    org_b = ensure_tapdb_org(db_session, tenant_b, name="org-b", display_name="Org B")

    site_b = SiteService(db_session).list_by_organization(org_b.euid, active_only=True)[0]

    with pytest.raises(ValueError, match="does not belong"):
        resolve_tenant_site_euid(db_session, tenant_a, site_b.euid)


@pytest.mark.db
def test_organization_must_keep_at_least_one_active_site(db_session: Session):
    tenant_id = uuid.uuid4()
    org = ensure_tapdb_org(db_session, tenant_id, name="min-site-org", display_name="Min Site Org")

    site = SiteService(db_session).list_by_organization(org.euid, active_only=True)[0]

    with pytest.raises(ValueError, match="at least one active site"):
        SiteService(db_session).update(site.euid, SiteUpdate(is_active=False), updated_by=None)
