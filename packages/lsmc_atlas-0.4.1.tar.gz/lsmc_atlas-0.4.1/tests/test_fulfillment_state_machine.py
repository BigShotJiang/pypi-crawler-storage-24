"""Tests for Assay State Machine Policy (Step 4).

Pure Python tests (no DB required) that verify:
1. Valid transitions for every state
2. Invalid transitions rejected
3. QC_HOLD → RESULTED requires override
4. Terminal states reject transitions (except FAILED → AMENDED)
5. derive_order_status() logic
"""

import pytest

from app.domain.policies.fulfillment_state_machine import (
    ALLOWED_TRANSITIONS,
    ORDER_TERMINAL_FOR_ROLLUP,
    TERMINAL_STATES,
    FulfillmentRunState,
    DerivedOrderStatus,
    TransitionError,
    can_transition,
    derive_order_status,
    is_terminal,
    validate_transition,
)


class TestAssayStateEnum:
    """Test FulfillmentRunState enum has all 10 canonical states."""

    def test_all_states_present(self):
        """All 10 canonical states are defined."""
        expected = {
            "DRAFT",
            "ORDERED",
            "RECEIVED",
            "ACCESSIONED",
            "IN_PROGRESS",
            "QC_HOLD",
            "FAILED",
            "RESULTED",
            "AMENDED",
            "CANCELLED",
        }
        actual = {s.value for s in FulfillmentRunState}
        assert actual == expected

    def test_state_count(self):
        """Exactly 10 states."""
        assert len(FulfillmentRunState) == 10


class TestTerminalStates:
    """Test terminal state identification."""

    def test_terminal_states_set(self):
        """CANCELLED, FAILED, AMENDED are terminal."""
        assert {FulfillmentRunState.CANCELLED, FulfillmentRunState.FAILED, FulfillmentRunState.AMENDED} == TERMINAL_STATES

    def test_is_terminal_true(self):
        """is_terminal returns True for terminal states."""
        assert is_terminal(FulfillmentRunState.CANCELLED) is True
        assert is_terminal(FulfillmentRunState.FAILED) is True
        assert is_terminal(FulfillmentRunState.AMENDED) is True

    def test_is_terminal_false(self):
        """is_terminal returns False for non-terminal states."""
        non_terminal = [
            FulfillmentRunState.DRAFT,
            FulfillmentRunState.ORDERED,
            FulfillmentRunState.RECEIVED,
            FulfillmentRunState.ACCESSIONED,
            FulfillmentRunState.IN_PROGRESS,
            FulfillmentRunState.QC_HOLD,
            FulfillmentRunState.RESULTED,
        ]
        for state in non_terminal:
            assert is_terminal(state) is False, f"{state} should not be terminal"


class TestAllowedTransitions:
    """Test ALLOWED_TRANSITIONS mapping."""

    def test_draft_transitions(self):
        """DRAFT can go to ORDERED or CANCELLED."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.DRAFT] == {FulfillmentRunState.ORDERED, FulfillmentRunState.CANCELLED}

    def test_ordered_transitions(self):
        """ORDERED can go to RECEIVED or CANCELLED."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.ORDERED] == {
            FulfillmentRunState.RECEIVED,
            FulfillmentRunState.CANCELLED,
        }

    def test_received_transitions(self):
        """RECEIVED can go to ACCESSIONED, FAILED, or CANCELLED."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.RECEIVED] == {
            FulfillmentRunState.ACCESSIONED,
            FulfillmentRunState.FAILED,
            FulfillmentRunState.CANCELLED,
        }

    def test_accessioned_transitions(self):
        """ACCESSIONED can go to IN_PROGRESS or FAILED."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.ACCESSIONED] == {
            FulfillmentRunState.IN_PROGRESS,
            FulfillmentRunState.FAILED,
        }

    def test_in_progress_transitions(self):
        """IN_PROGRESS can go to RESULTED, QC_HOLD, or FAILED."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.IN_PROGRESS] == {
            FulfillmentRunState.RESULTED,
            FulfillmentRunState.QC_HOLD,
            FulfillmentRunState.FAILED,
        }

    def test_qc_hold_transitions(self):
        """QC_HOLD can go to IN_PROGRESS, FAILED, or RESULTED (with override)."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.QC_HOLD] == {
            FulfillmentRunState.IN_PROGRESS,
            FulfillmentRunState.FAILED,
            FulfillmentRunState.RESULTED,
        }

    def test_failed_transitions(self):
        """FAILED can only go to AMENDED (rare, with justification)."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.FAILED] == {FulfillmentRunState.AMENDED}

    def test_resulted_transitions(self):
        """RESULTED can only go to AMENDED."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.RESULTED] == {FulfillmentRunState.AMENDED}

    def test_amended_no_transitions(self):
        """AMENDED is terminal - no transitions allowed."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.AMENDED] == set()

    def test_cancelled_no_transitions(self):
        """CANCELLED is terminal - no transitions allowed."""
        assert ALLOWED_TRANSITIONS[FulfillmentRunState.CANCELLED] == set()


class TestValidateTransition:
    """Test validate_transition function."""

    def test_valid_draft_to_ordered(self):
        """DRAFT → ORDERED is valid."""
        validate_transition(FulfillmentRunState.DRAFT, FulfillmentRunState.ORDERED)  # Should not raise

    def test_valid_ordered_to_received(self):
        """ORDERED → RECEIVED is valid."""
        validate_transition(FulfillmentRunState.ORDERED, FulfillmentRunState.RECEIVED)

    def test_valid_in_progress_to_resulted(self):
        """IN_PROGRESS → RESULTED is valid."""
        validate_transition(FulfillmentRunState.IN_PROGRESS, FulfillmentRunState.RESULTED)

    def test_invalid_draft_to_resulted(self):
        """DRAFT → RESULTED is invalid (skipping states)."""
        with pytest.raises(TransitionError) as exc_info:
            validate_transition(FulfillmentRunState.DRAFT, FulfillmentRunState.RESULTED)
        assert "not allowed" in str(exc_info.value).lower()

    def test_invalid_ordered_to_in_progress(self):
        """ORDERED → IN_PROGRESS is invalid (must go through RECEIVED)."""
        with pytest.raises(TransitionError):
            validate_transition(FulfillmentRunState.ORDERED, FulfillmentRunState.IN_PROGRESS)

    def test_terminal_state_rejects_transition(self):
        """Terminal states reject transitions."""
        with pytest.raises(TransitionError):
            validate_transition(FulfillmentRunState.CANCELLED, FulfillmentRunState.ORDERED)
        with pytest.raises(TransitionError):
            validate_transition(FulfillmentRunState.AMENDED, FulfillmentRunState.RESULTED)

    def test_failed_to_amended_allowed(self):
        """FAILED → AMENDED is allowed (rare case)."""
        validate_transition(FulfillmentRunState.FAILED, FulfillmentRunState.AMENDED)

    def test_qc_hold_to_resulted_requires_override(self):
        """QC_HOLD → RESULTED requires qc_override=True."""
        with pytest.raises(TransitionError) as exc_info:
            validate_transition(FulfillmentRunState.QC_HOLD, FulfillmentRunState.RESULTED, qc_override=False)
        assert "override" in str(exc_info.value).lower()

    def test_qc_hold_to_resulted_with_override(self):
        """QC_HOLD → RESULTED succeeds with qc_override=True."""
        validate_transition(FulfillmentRunState.QC_HOLD, FulfillmentRunState.RESULTED, qc_override=True)

    def test_qc_hold_to_in_progress_no_override_needed(self):
        """QC_HOLD → IN_PROGRESS doesn't need override."""
        validate_transition(FulfillmentRunState.QC_HOLD, FulfillmentRunState.IN_PROGRESS, qc_override=False)

    def test_idempotent_same_state(self):
        """Transition to same state is allowed (idempotent)."""
        # This should not raise - idempotent transitions are handled at service level
        # but the policy should allow it
        for _state in FulfillmentRunState:
            # Same state transitions are handled by service layer, not policy
            pass


class TestCanTransition:
    """Test can_transition helper function."""

    def test_can_transition_valid(self):
        """can_transition returns True for valid transitions."""
        assert can_transition(FulfillmentRunState.DRAFT, FulfillmentRunState.ORDERED) is True
        assert can_transition(FulfillmentRunState.ORDERED, FulfillmentRunState.RECEIVED) is True
        assert can_transition(FulfillmentRunState.IN_PROGRESS, FulfillmentRunState.RESULTED) is True

    def test_can_transition_invalid(self):
        """can_transition returns False for invalid transitions."""
        assert can_transition(FulfillmentRunState.DRAFT, FulfillmentRunState.RESULTED) is False
        assert can_transition(FulfillmentRunState.CANCELLED, FulfillmentRunState.ORDERED) is False

    def test_can_transition_qc_hold_to_resulted(self):
        """can_transition returns True for QC_HOLD → RESULTED (override check is elsewhere)."""
        # Note: can_transition doesn't check qc_override; that's checked in validate_transition
        assert can_transition(FulfillmentRunState.QC_HOLD, FulfillmentRunState.RESULTED) is True

    def test_can_transition_qc_hold_to_in_progress(self):
        """can_transition returns True for QC_HOLD → IN_PROGRESS."""
        assert can_transition(FulfillmentRunState.QC_HOLD, FulfillmentRunState.IN_PROGRESS) is True


class TestDeriveOrderStatus:
    """Test derive_order_status function."""

    def test_no_assays_returns_draft(self):
        """No assays returns DRAFT."""
        assert derive_order_status([]) == DerivedOrderStatus.DRAFT

    def test_all_draft_returns_draft(self):
        """All DRAFT assays returns DRAFT."""
        assert derive_order_status([FulfillmentRunState.DRAFT, FulfillmentRunState.DRAFT]) == DerivedOrderStatus.DRAFT

    def test_any_ordered_returns_ordered(self):
        """Any ORDERED assay returns ORDERED."""
        assert derive_order_status([FulfillmentRunState.ORDERED]) == DerivedOrderStatus.ORDERED
        assert (
            derive_order_status([FulfillmentRunState.DRAFT, FulfillmentRunState.ORDERED])
            == DerivedOrderStatus.ORDERED
        )

    def test_any_received_returns_ordered(self):
        """Any RECEIVED assay returns ORDERED (awaiting accessioning)."""
        assert derive_order_status([FulfillmentRunState.RECEIVED]) == DerivedOrderStatus.ORDERED

    def test_any_accessioned_returns_in_progress(self):
        """Any ACCESSIONED assay returns IN_PROGRESS."""
        assert derive_order_status([FulfillmentRunState.ACCESSIONED]) == DerivedOrderStatus.IN_PROGRESS

    def test_any_in_progress_returns_in_progress(self):
        """Any IN_PROGRESS assay returns IN_PROGRESS."""
        assert derive_order_status([FulfillmentRunState.IN_PROGRESS]) == DerivedOrderStatus.IN_PROGRESS

    def test_any_qc_hold_returns_qc_hold(self):
        """Any QC_HOLD assay returns QC_HOLD (highest priority)."""
        assert derive_order_status([FulfillmentRunState.QC_HOLD]) == DerivedOrderStatus.QC_HOLD
        assert (
            derive_order_status([FulfillmentRunState.IN_PROGRESS, FulfillmentRunState.QC_HOLD])
            == DerivedOrderStatus.QC_HOLD
        )

    def test_all_terminal_with_results_returns_results_ready(self):
        """All terminal with at least one RESULTED/AMENDED returns RESULTS_READY."""
        assert derive_order_status([FulfillmentRunState.RESULTED]) == DerivedOrderStatus.RESULTS_READY
        assert (
            derive_order_status([FulfillmentRunState.RESULTED, FulfillmentRunState.AMENDED])
            == DerivedOrderStatus.RESULTS_READY
        )
        assert (
            derive_order_status([FulfillmentRunState.RESULTED, FulfillmentRunState.CANCELLED])
            == DerivedOrderStatus.RESULTS_READY
        )

    def test_all_terminal_no_results_returns_closed(self):
        """All terminal with no results returns CLOSED_NO_RESULTS."""
        assert derive_order_status([FulfillmentRunState.CANCELLED]) == DerivedOrderStatus.CLOSED_NO_RESULTS
        assert derive_order_status([FulfillmentRunState.FAILED]) == DerivedOrderStatus.CLOSED_NO_RESULTS
        assert (
            derive_order_status([FulfillmentRunState.CANCELLED, FulfillmentRunState.FAILED])
            == DerivedOrderStatus.CLOSED_NO_RESULTS
        )

    def test_qc_hold_priority_over_in_progress(self):
        """QC_HOLD takes priority over IN_PROGRESS."""
        states = [FulfillmentRunState.IN_PROGRESS, FulfillmentRunState.QC_HOLD, FulfillmentRunState.ACCESSIONED]
        assert derive_order_status(states) == DerivedOrderStatus.QC_HOLD

    def test_in_progress_priority_over_ordered(self):
        """IN_PROGRESS takes priority over ORDERED."""
        states = [FulfillmentRunState.ORDERED, FulfillmentRunState.IN_PROGRESS]
        assert derive_order_status(states) == DerivedOrderStatus.IN_PROGRESS


class TestOrderTerminalForRollup:
    """Test ORDER_TERMINAL_FOR_ROLLUP set."""

    def test_terminal_for_rollup_states(self):
        """RESULTED, AMENDED, CANCELLED, FAILED are terminal for rollup."""
        assert {
            FulfillmentRunState.RESULTED,
            FulfillmentRunState.AMENDED,
            FulfillmentRunState.CANCELLED,
            FulfillmentRunState.FAILED,
        } == ORDER_TERMINAL_FOR_ROLLUP
