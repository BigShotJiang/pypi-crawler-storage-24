"""Unit tests for TapDB cutover behavior in UserService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from app.domain.services.users import UserCreate, UserService, UserUpdate


@dataclass
class _MockDB:
    def add(self, _obj):
        return None

    def commit(self):
        return None

    def refresh(self, _obj):
        return None


class _FakeRepo:
    def __init__(self):
        self.calls: list[tuple[str, tuple, dict]] = []
        self.user = type(
            "UserRecord",
            (),
            {
                "id": uuid.uuid4(),
                "euid": f"PRF-{uuid.uuid4().int % 10000}",
                "cognito_sub": "sub-1",
                "tenant_id": uuid.uuid4(),
                "email": "user@example.com",
                "name": "User",
                "roles": ["EXTERNAL_USER"],
                "is_active": True,
                "preferences": {},
            },
        )()

    def _record(self, name: str, *args, **kwargs):
        self.calls.append((name, args, kwargs))

    def get_user_by_email_in_tenant(self, email, tenant_id):
        self._record("get_user_by_email_in_tenant", email, tenant_id)
        return None

    def get_user_by_sub(self, cognito_sub):
        self._record("get_user_by_sub", cognito_sub)
        if cognito_sub == self.user.cognito_sub:
            return self.user
        return None

    def create_user(self, data):
        self._record("create_user", data)
        self.user.cognito_sub = data.cognito_sub
        self.user.email = data.email
        self.user.name = data.name
        self.user.tenant_id = data.tenant_id
        self.user.roles = data.roles
        self.user.is_active = True
        return self.user

    def get_user_by_id(self, user_id):
        self._record("get_user_by_id", user_id)
        if user_id == self.user.euid:
            return self.user
        return None

    def get_user_by_email(self, email):
        self._record("get_user_by_email", email)
        if email == self.user.email:
            return self.user
        return None

    def list_users_by_subs(self, subs):
        self._record("list_users_by_subs", subs)
        return [self.user] if self.user.cognito_sub in subs else []

    def list_users(self, tenant_id=None, skip=0, limit=50, is_active=None):
        self._record("list_users", tenant_id, skip, limit, is_active)
        return [self.user]

    def update_user(self, user_id, data):
        self._record("update_user", user_id, data)
        if data.name is not None:
            self.user.name = data.name
        if data.email is not None:
            self.user.email = data.email
        if data.roles is not None:
            self.user.roles = data.roles
        if data.is_active is not None:
            self.user.is_active = data.is_active
        return self.user

    def set_last_login(self, user_id, dt):
        self._record("set_last_login", user_id, dt)

    def update_preferences(self, user_id, prefs):
        self._record("update_preferences", user_id, prefs)
        self.user.preferences = prefs
        return self.user


class _FakeOrgRepo:
    def get_org_by_uid(self, uid):
        return {"id": uid}


def test_user_service_delegates_to_tapdb_repo(monkeypatch):
    repo = _FakeRepo()
    org_repo = _FakeOrgRepo()
    svc = UserService(_MockDB())
    monkeypatch.setattr(svc, "_repo", lambda: repo)
    monkeypatch.setattr(svc, "_org_repo", lambda: org_repo)

    tenant_id = repo.user.tenant_id
    created = svc.create(
        UserCreate(
            email="new@example.com",
            name="New",
            tenant_id=tenant_id,
            roles=["EXTERNAL_USER"],
            cognito_sub="sub-new",
        )
    )
    assert created.email == "new@example.com"

    fetched = svc.get_by_cognito_sub("sub-new")
    assert fetched is not None

    updated = svc.update(
        created.euid,
        UserUpdate(name="Updated User", roles=["READ_WRITE"]),
    )
    assert updated is not None
    assert updated.name == "Updated User"
    assert updated.roles == ["READ_WRITE"]

    listed = svc.list_users(tenant_id=tenant_id)
    assert len(listed) == 1

    assert svc.get_by_email("new@example.com") is not None
    assert svc.list_by_cognito_subs(["sub-new"])

    svc.update_last_login(created.euid)
    saved = svc.update_preferences(created.euid, {"datetime_format": "precise"})
    assert saved is not None
    assert saved.preferences == {"datetime_format": "precise"}

    call_names = [call[0] for call in repo.calls]
    assert "create_user" in call_names
    assert "update_user" in call_names
    assert "set_last_login" in call_names
    assert "update_preferences" in call_names
