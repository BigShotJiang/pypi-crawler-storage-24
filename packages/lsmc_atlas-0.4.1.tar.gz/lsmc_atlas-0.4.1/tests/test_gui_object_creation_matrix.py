"""GUI object creation matrix integration test."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org


def create_test_client(db_session: Session, user: CurrentUser) -> TestClient:
    """Create a test client with DB/user overrides and CSRF bypass."""
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_current_user():
        return user

    async def override_csrf():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_current_user
    app.dependency_overrides[get_current_user_web] = override_current_user
    app.dependency_overrides[csrf_protect] = override_csrf
    return TestClient(app)


@pytest.fixture
def matrix_tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def matrix_admin_user(matrix_tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="matrix-admin@lsmc.bio",
        name="Matrix Admin",
        tenant_id=matrix_tenant_id,
        roles=[Role.ADMIN.value],
    )


@pytest.fixture
def matrix_external_user(matrix_tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="matrix-external@acme-genetics.com",
        name="Matrix External",
        tenant_id=matrix_tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def matrix_internal_user(matrix_tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="matrix-internal@lsmc.bio",
        name="Matrix Internal",
        tenant_id=matrix_tenant_id,
        roles=[Role.INTERNAL_USER.value],
    )


@pytest.fixture
def setup_tenant(db_session: Session, matrix_tenant_id: uuid.UUID) -> SimpleNamespace:
    org = ensure_tapdb_org(
        db_session,
        matrix_tenant_id,
        name=f"matrix-tenant-{uuid.uuid4().hex[:8]}",
        display_name="Matrix Tenant",
    )
    db_session.flush()
    return SimpleNamespace(id=matrix_tenant_id, euid=org.euid)


@pytest.mark.db
def test_gui_object_creation_matrix(
    db_session: Session,
    setup_tenant,
    matrix_admin_user: CurrentUser,
    matrix_external_user: CurrentUser,
    matrix_internal_user: CurrentUser,
):
    """Create one of each GUI-creatable object and verify persistence."""
    from app.domain.services.api_clients import APIClientService
    from app.domain.services.families import FamilyService
    from app.domain.services.orgs import OrganizationService, SiteService
    from app.domain.services.people import ClinicianService, PatientService
    from app.domain.services.releases import ReleaseService
    from app.domain.services.shipments import ShipmentService, TestKitService
    from app.domain.services.support import SupportTicketService
    from app.domain.services.test_definitions import TestDefinitionService
    from app.domain.services.trfs import TrfService
    from app.domain.services.users import UserService
    from app.domain.services.webhooks import WebhookService

    suffix = uuid.uuid4().hex[:8]

    admin_client = create_test_client(db_session, matrix_admin_user)
    try:
        # Organization (with required initial site)
        created_org_name = f"matrix-org-{suffix}"
        created_org_initial_site_name = f"Matrix Initial Site {suffix}"
        response = admin_client.post(
            "/admin/organizations/create",
            data={
                "name": created_org_name,
                "display_name": f"Matrix Org {suffix}",
                "org_type": "clinic",
                "initial_site_name": created_org_initial_site_name,
                "initial_site_code": f"MSI-{suffix[:4].upper()}",
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        org_service = OrganizationService(db_session)
        created_org_euid = None
        for org in org_service.list_all(active_only=False):
            org_with_revision = org_service.get_with_revision(org.euid)
            if org_with_revision and org_with_revision[1].name == created_org_name:
                created_org_euid = org.euid
                break
        assert created_org_euid is not None

        created_org_sites = SiteService(db_session).list_by_organization(
            created_org_euid, active_only=False
        )
        assert any(
            site.revisions and site.revisions[-1].name == created_org_initial_site_name
            for site in created_org_sites
        )

        # Site
        tenant_site_code = f"MXS-{suffix[:4].upper()}"
        response = admin_client.post(
            f"/admin/organizations/{setup_tenant.euid}/sites/new",
            data={
                "name": f"Matrix Tenant Site {suffix}",
                "site_code": tenant_site_code,
                "address_line1": "1 Matrix Way",
                "city": "Boston",
                "state": "MA",
                "postal_code": "02108",
            },
            follow_redirects=False,
        )
        assert response.status_code in (status.HTTP_302_FOUND, status.HTTP_303_SEE_OTHER)

        tenant_sites = SiteService(db_session).list_by_organization(
            setup_tenant.euid, active_only=False
        )
        tenant_site = next(
            (
                site
                for site in tenant_sites
                if site.revisions and site.revisions[-1].site_code == tenant_site_code
            ),
            None,
        )
        assert tenant_site is not None

        # User
        matrix_user_email = f"matrix-user-{suffix}@acme.com"
        response = admin_client.post(
            f"/admin/organizations/{setup_tenant.euid}/users/new",
            data={
                "email": matrix_user_email,
                "name": "Matrix Org User",
                "roles": "EXTERNAL_USER",
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        created_user = UserService(db_session).get_by_email(matrix_user_email)
        assert created_user is not None
        assert created_user.tenant_id == setup_tenant.id

        # Assay
        fulfillment_route_code = f"MX{suffix[:6].upper()}"
        response = admin_client.post(
            "/admin/test-definitions/create",
            data={
                "code": fulfillment_route_code,
                "name": f"Matrix Assay {suffix}",
                "specimen_types": "blood, saliva, BLOOD",
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        assay = TestDefinitionService(db_session).get_by_code(fulfillment_route_code)
        assert assay is not None
        assert assay.specimen_types == ["BLOOD", "SALIVA"]
    finally:
        admin_client.close()
        app.dependency_overrides.clear()

    external_client = create_test_client(db_session, matrix_external_user)
    try:
        # Patient
        patient_mrn = f"MRN-{suffix.upper()}"
        response = external_client.post(
            "/patients/new",
            data={
                "first_name": "Matrix",
                "last_name": "Patient",
                "date_of_birth": "1990-01-02",
                "sex": "F",
                "mrn": patient_mrn,
                "email": f"matrix-patient-{suffix}@example.com",
                "site_id": tenant_site.euid,
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        patient_service = PatientService(
            db_session, matrix_external_user.tenant_id, matrix_external_user.sub_uuid
        )
        patient_rows = patient_service.list_patients(limit=200)
        patient_entry = next(
            (
                (patient, revision)
                for patient, revision in patient_rows
                if revision.mrn == patient_mrn
            ),
            None,
        )
        assert patient_entry is not None
        patient_euid = patient_entry[0].euid

        # Clinician
        clinician_npi = f"{int(suffix[:8], 16) % 10_000_000_000:010d}"
        response = external_client.post(
            "/clinicians/new",
            data={
                "first_name": "Matrix",
                "last_name": "Clinician",
                "credentials": "MD",
                "specialty": "Genetics",
                "npi": clinician_npi,
                "email": f"matrix-clinician-{suffix}@clinic.org",
                "site_id": tenant_site.euid,
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        clinician_service = ClinicianService(
            db_session, matrix_external_user.tenant_id, matrix_external_user.sub_uuid
        )
        clinician_rows = clinician_service.list_clinicians(limit=200, active_only=False)
        clinician_entry = next(
            (
                (clinician, revision)
                for clinician, revision in clinician_rows
                if revision.npi == clinician_npi
            ),
            None,
        )
        assert clinician_entry is not None

        # TRF/Test intent
        trf_note = f"Matrix TRF Note {suffix}"
        response = external_client.post(
            "/trfs/new",
            data={
                "patient_id": str(patient_euid),
                "order_type": "CLINICAL",
                "clinical_notes": trf_note,
                "site_id": tenant_site.euid,
                "test_orders[0][fulfillment_route_code]": fulfillment_route_code,
                "test_orders[0][specimen_type]": "blood-whole",
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        trf_service = TrfService(db_session, matrix_external_user.tenant_id)
        trf_rows = trf_service.list_trfs(limit=200)
        trf_entry = next(
            (
                (trf, revision)
                for trf, revision in trf_rows
                if revision and revision.clinical_notes == trf_note
            ),
            None,
        )
        assert trf_entry is not None
        trf_euid = trf_entry[0].euid

        # Test kit
        kit_barcode = f"KIT-MATRIX-{suffix.upper()}"
        response = external_client.post(
            "/testkits/create",
            data={
                "kit_barcode": kit_barcode,
                "kit_type": "COLLECTION",
                "origin_site_id": tenant_site.euid,
                "expiration_date": "2028-01-01",
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        test_kit_service = TestKitService(db_session, matrix_external_user.tenant_id)
        test_kit = test_kit_service.get_by_barcode(kit_barcode)
        assert test_kit is not None
        kit_with_revision = test_kit_service.get_with_revision(test_kit.euid)
        assert kit_with_revision is not None
        _kit, kit_revision = kit_with_revision
        assert str(kit_revision.origin_site_id) == str(tenant_site.euid)

        # Shipment
        tracking_number = f"MXTRACK{suffix.upper()}"
        response = external_client.post(
            "/shipments/new",
            data={
                "carrier": "FedEx",
                "tracking_number": tracking_number,
                "origin_site_id": tenant_site.euid,
                "special_instructions": "Matrix shipment",
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        shipment = ShipmentService(
            db_session, matrix_external_user.tenant_id
        ).get_by_tracking_number(tracking_number)
        assert shipment is not None

        # Family
        family_name = f"Matrix Family {suffix}"
        response = external_client.post(
            "/families/new",
            data={
                "name": family_name,
                "notes": "Matrix family notes",
                "site_id": tenant_site.euid,
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        family_rows = FamilyService(
            db_session, matrix_external_user.tenant_id, matrix_external_user.sub_uuid
        ).list_families(limit=200)
        assert any(revision.name == family_name for _family, revision in family_rows)

        # Support ticket
        ticket_subject = f"Matrix Support {suffix}"
        response = external_client.post(
            "/support/create",
            data={
                "subject": ticket_subject,
                "description": "Matrix support test ticket",
                "ticket_type": "TECHNICAL",
                "priority": "NORMAL",
                "site_id": tenant_site.euid,
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        support_rows = SupportTicketService(
            db_session, matrix_external_user.tenant_id, matrix_external_user.sub_uuid
        ).list_tickets(limit=200)
        assert any(revision.subject == ticket_subject for _ticket, revision in support_rows)

        # API client
        api_client_name = f"Matrix API Client {suffix}"
        response = external_client.post(
            "/api-clients/new",
            data={
                "client_name": api_client_name,
                "permissions": ["order:read", "shipment:read"],
                "site_id": tenant_site.euid,
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_200_OK

        api_client_rows = APIClientService(db_session, matrix_external_user.tenant_id).list(
            limit=200
        )
        assert any(client.client_name == api_client_name for client, _revision in api_client_rows)

        # Webhook subscription
        webhook_name = f"Matrix Webhook {suffix}"
        response = external_client.post(
            "/webhooks/new",
            data={
                "subscription_name": webhook_name,
                "url": f"https://example.com/hooks/{suffix}",
                "secret": "matrix-secret",
                "event_types": ["order.created", "release.package.created"],
                "timeout_seconds": "30",
                "max_retries": "3",
                "site_id": tenant_site.euid,
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        webhook_rows = WebhookService(db_session, matrix_external_user.tenant_id).list(limit=200)
        assert any(
            subscription.subscription_name == webhook_name
            for subscription, _revision in webhook_rows
        )
    finally:
        external_client.close()
        app.dependency_overrides.clear()

    internal_client = create_test_client(db_session, matrix_internal_user)
    try:
        # Results package
        release_notes = f"Matrix Release {suffix}"
        response = internal_client.post(
            "/results/create",
            data={
                "order_id": str(trf_euid),
                "release_notes": release_notes,
                "action": "draft",
            },
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        release_rows = ReleaseService(db_session, matrix_internal_user.tenant_id).list_packages(
            limit=200
        )
        assert any(
            str(package.order_id) == str(trf_euid)
            and revision
            and revision.release_notes == release_notes
            for package, revision in release_rows
        )
    finally:
        internal_client.close()
        app.dependency_overrides.clear()
