"""Tests for tenant isolation across service and API layers (TapDB-native setup)."""

import uuid
from datetime import date

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Permission, Role, has_permission
from app.db.engine import get_db
from app.domain.enums import OrderPatientRole
from app.domain.services.order_relationships import OrderPatientLink
from app.domain.services.people import PatientCreate, PatientService
from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org


def _create_patient(
    db_session: Session,
    *,
    tenant_id: uuid.UUID,
    user_id: uuid.UUID,
    first_name: str,
    last_name: str,
) -> str:
    patient, _ = PatientService(db_session, tenant_id, user_id).create(
        PatientCreate(
            first_name=first_name,
            last_name=last_name,
            date_of_birth=date(1990, 1, 1),
            sex="M",
        ),
        created_by=user_id,
    )
    return patient.euid


def _create_order(
    db_session: Session,
    *,
    tenant_id: uuid.UUID,
    user_id: uuid.UUID,
    patient_id: str,
) -> tuple[str, str]:
    order, _ = TrfService(db_session, tenant_id).create(
        TrfCreate(clinician_id=None, order_type="CLINICAL"),
        tests=[
            TestCreate(
                product_code="WGS-001",
                fulfillment_route_codes=["WGS"],
                specimen_type_required="blood-whole",
            )
        ],
        patient_links=[OrderPatientLink(patient_euid=patient_id, role=OrderPatientRole.PROBAND)],
        created_by=user_id,
    )
    return order.euid, order.order_number


def _first_child_order_id(
    db_session: Session,
    *,
    tenant_id: uuid.UUID,
    trf_euid: str,
) -> str:
    rows = TestService(db_session, tenant_id).list_for_trf(trf_euid, cross_tenant=True)
    assert rows, "Expected at least one child order in test setup"
    child_order, _child_rev, _assays = rows[0]
    return child_order.euid


@pytest.mark.db
class TestServiceTenantIsolation:
    """Test tenant isolation at the service layer."""

    def test_patient_service_filters_by_tenant(
        self, db_session: Session, tenant_id: str, other_tenant_id: str, test_user: CurrentUser
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        p1 = _create_patient(
            db_session,
            tenant_id=tenant_uuid,
            user_id=test_user.sub_uuid,
            first_name="John",
            last_name="Doe",
        )
        _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=test_user.sub_uuid,
            first_name="Jane",
            last_name="Smith",
        )

        service = PatientService(db_session, test_user.tenant_id, test_user.sub)
        patients = service.list_patients()

        assert len(patients) == 1
        patient, revision = patients[0]
        assert str(patient.euid) == str(p1)
        assert revision.first_name == "John"

    def test_cannot_get_other_tenant_patient_by_id(
        self, db_session: Session, tenant_id: str, other_tenant_id: str, test_user: CurrentUser
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        hidden_patient_id = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=test_user.sub_uuid,
            first_name="Hidden",
            last_name="Patient",
        )

        service = PatientService(db_session, test_user.tenant_id, test_user.sub)
        assert service.get_by_id(hidden_patient_id) is None


@pytest.mark.db
class TestInternalUserCrossTenantService:
    """Test INTERNAL_USER cross-tenant access behavior."""

    def test_internal_user_can_list_patients_cross_tenant(
        self, db_session: Session, tenant_id: str, other_tenant_id: str, internal_user: CurrentUser
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        p1 = _create_patient(
            db_session,
            tenant_id=tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Own",
            last_name="Tenant",
        )
        p2 = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Other",
            last_name="Tenant",
        )

        service = PatientService(db_session, internal_user.tenant_id, internal_user.sub)
        own_only_ids = {str(p.euid) for p, _ in service.list_patients()}
        assert str(p1) in own_only_ids
        assert str(p2) not in own_only_ids

        all_ids = {str(p.euid) for p, _ in service.list_patients(cross_tenant=True)}
        assert str(p1) in all_ids
        assert str(p2) in all_ids

    def test_internal_user_can_get_other_tenant_patient_by_id(
        self, db_session: Session, tenant_id: str, other_tenant_id: str, internal_user: CurrentUser
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        other_patient_id = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Cross",
            last_name="Access",
        )

        service = PatientService(db_session, internal_user.tenant_id, internal_user.sub)
        assert service.get_by_id(other_patient_id) is None

        result = service.get_by_id(other_patient_id, cross_tenant=True)
        assert result is not None
        _, revision = result
        assert revision.first_name == "Cross"

    def test_internal_user_can_list_orders_cross_tenant(
        self, db_session: Session, tenant_id: str, other_tenant_id: str, internal_user: CurrentUser
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        own_patient = _create_patient(
            db_session,
            tenant_id=tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Own",
            last_name="Patient",
        )
        other_patient = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Other",
            last_name="Patient",
        )

        _, own_order_number = _create_order(
            db_session,
            tenant_id=tenant_uuid,
            user_id=internal_user.sub_uuid,
            patient_id=own_patient,
        )
        _, other_order_number = _create_order(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            patient_id=other_patient,
        )

        svc = TrfService(db_session, internal_user.tenant_id)
        own_numbers = {order.order_number for order, _ in svc.list_trfs()}
        assert own_order_number in own_numbers
        assert other_order_number not in own_numbers

        all_numbers = {order.order_number for order, _ in svc.list_trfs(cross_tenant=True)}
        assert own_order_number in all_numbers
        assert other_order_number in all_numbers

    def test_internal_user_can_get_other_tenant_order_by_id(
        self, db_session: Session, tenant_id: str, other_tenant_id: str, internal_user: CurrentUser
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        patient_id = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Cross",
            last_name="Order",
        )
        order_id, order_number = _create_order(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            patient_id=patient_id,
        )

        svc = TrfService(db_session, internal_user.tenant_id)
        assert svc.get_by_id(order_id) is None

        result = svc.get_by_id(order_id, cross_tenant=True)
        assert result is not None
        order, _ = result
        assert order.order_number == order_number


@pytest.mark.db
class TestCrossTenantPermissions:
    """Verify CROSS_TENANT_READ permission assignment."""

    def test_internal_user_has_cross_tenant_read(self, internal_user: CurrentUser):
        assert has_permission(internal_user.roles, Permission.CROSS_TENANT_READ) is True

    def test_admin_has_cross_tenant_read(self, admin_user: CurrentUser):
        assert has_permission(admin_user.roles, Permission.CROSS_TENANT_READ) is True

    def test_external_user_lacks_cross_tenant_read(self, test_user: CurrentUser):
        assert has_permission(test_user.roles, Permission.CROSS_TENANT_READ) is False

    def test_external_admin_lacks_cross_tenant_read(self):
        user = CurrentUser(
            sub=str(uuid.uuid4()),
            email="orgadmin@acme.com",
            name="Org Admin",
            tenant_id=uuid.uuid4(),
            roles=[Role.EXTERNAL_USER_ADMIN.value],
        )
        assert has_permission(user.roles, Permission.CROSS_TENANT_READ) is False


@pytest.mark.db
class TestExternalCannotEscalate:
    """Verify external users cannot force cross-tenant access."""

    def test_external_user_cross_tenant_flag_has_no_effect_without_permission(
        self, db_session: Session, tenant_id: str, other_tenant_id: str, test_user: CurrentUser
    ):
        assert has_permission(test_user.roles, Permission.CROSS_TENANT_READ) is False


@pytest.mark.db
class TestAPITenantIsolation:
    """Test tenant isolation at the API layer."""

    def test_api_orders_filtered_by_tenant(
        self,
        db_session: Session,
        tenant_id: str,
        other_tenant_id: str,
        test_user: CurrentUser,
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        p1 = _create_patient(
            db_session,
            tenant_id=tenant_uuid,
            user_id=test_user.sub_uuid,
            first_name="Mine",
            last_name="Patient",
        )
        p2 = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=test_user.sub_uuid,
            first_name="Other",
            last_name="Patient",
        )
        own_trf_euid, _ = _create_order(
            db_session,
            tenant_id=tenant_uuid,
            user_id=test_user.sub_uuid,
            patient_id=p1,
        )
        other_trf_euid, _ = _create_order(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=test_user.sub_uuid,
            patient_id=p2,
        )
        own_child_order_id = _first_child_order_id(
            db_session, tenant_id=tenant_uuid, trf_euid=own_trf_euid
        )
        other_child_order_id = _first_child_order_id(
            db_session, tenant_id=other_tenant_uuid, trf_euid=other_trf_euid
        )

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        def override_get_current_user():
            return test_user

        from app.auth.dependencies import get_current_user, get_current_user_or_token

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = override_get_current_user
        app.dependency_overrides[get_current_user_or_token] = override_get_current_user

        try:
            client = TestClient(app)
            own_response = client.get(f"/api/trfs/tests/{own_child_order_id}")
            assert own_response.status_code == 200
            other_response = client.get(f"/api/trfs/tests/{other_child_order_id}")
            assert other_response.status_code == 404
        finally:
            app.dependency_overrides.clear()

    def test_api_cannot_access_other_tenant_order_by_id(
        self,
        db_session: Session,
        tenant_id: str,
        other_tenant_id: str,
        test_user: CurrentUser,
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        p = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=test_user.sub_uuid,
            first_name="Secret",
            last_name="Patient",
        )
        _, other_order_number = _create_order(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=test_user.sub_uuid,
            patient_id=p,
        )

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        def override_get_current_user():
            return test_user

        from app.auth.dependencies import get_current_user, get_current_user_or_token

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = override_get_current_user
        app.dependency_overrides[get_current_user_or_token] = override_get_current_user

        try:
            client = TestClient(app)
            response = client.get(f"/api/orders/{other_order_number}")
            assert response.status_code == 404
        finally:
            app.dependency_overrides.clear()


@pytest.mark.db
class TestInternalUserCrossTenantAPI:
    """Test INTERNAL_USER cross-tenant behavior at API layer."""

    def test_api_internal_user_sees_all_orders(
        self,
        db_session: Session,
        tenant_id: str,
        other_tenant_id: str,
        internal_user: CurrentUser,
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        p1 = _create_patient(
            db_session,
            tenant_id=tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Internal",
            last_name="Mine",
        )
        p2 = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Internal",
            last_name="Other",
        )
        own_trf_euid, _ = _create_order(
            db_session,
            tenant_id=tenant_uuid,
            user_id=internal_user.sub_uuid,
            patient_id=p1,
        )
        other_trf_euid, _ = _create_order(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            patient_id=p2,
        )
        own_child_order_id = _first_child_order_id(
            db_session, tenant_id=tenant_uuid, trf_euid=own_trf_euid
        )
        other_child_order_id = _first_child_order_id(
            db_session, tenant_id=other_tenant_uuid, trf_euid=other_trf_euid
        )

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        def override_get_current_user():
            return internal_user

        from app.auth.dependencies import get_current_user, get_current_user_or_token

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = override_get_current_user
        app.dependency_overrides[get_current_user_or_token] = override_get_current_user

        try:
            client = TestClient(app)
            own_response = client.get(f"/api/trfs/tests/{own_child_order_id}")
            assert own_response.status_code == 200
            other_response = client.get(f"/api/trfs/tests/{other_child_order_id}")
            assert other_response.status_code == 200
        finally:
            app.dependency_overrides.clear()

    def test_api_internal_user_can_get_other_tenant_order(
        self,
        db_session: Session,
        tenant_id: str,
        other_tenant_id: str,
        internal_user: CurrentUser,
    ):
        tenant_uuid = uuid.UUID(tenant_id)
        other_tenant_uuid = uuid.UUID(other_tenant_id)
        ensure_tapdb_org(db_session, tenant_uuid)
        ensure_tapdb_org(db_session, other_tenant_uuid)

        p = _create_patient(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            first_name="Cross",
            last_name="API",
        )
        other_trf_euid, _ = _create_order(
            db_session,
            tenant_id=other_tenant_uuid,
            user_id=internal_user.sub_uuid,
            patient_id=p,
        )
        other_child_order_id = _first_child_order_id(
            db_session, tenant_id=other_tenant_uuid, trf_euid=other_trf_euid
        )

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        def override_get_current_user():
            return internal_user

        from app.auth.dependencies import get_current_user, get_current_user_or_token

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = override_get_current_user
        app.dependency_overrides[get_current_user_or_token] = override_get_current_user

        try:
            client = TestClient(app)
            response = client.get(f"/api/trfs/tests/{other_child_order_id}")
            assert response.status_code == 200
            assert response.json()["id"] == other_child_order_id
        finally:
            app.dependency_overrides.clear()
