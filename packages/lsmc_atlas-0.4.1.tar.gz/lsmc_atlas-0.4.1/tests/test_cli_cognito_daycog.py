"""Unit tests for atlas daycog-backed Cognito CLI helpers."""

from __future__ import annotations

from pathlib import Path

import pytest

from app.cli import cognito as cognito_cli


def _write_env(path: Path, values: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"{key}={value}" for key, value in values.items()]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def test_parse_daycog_env_filename_variants() -> None:
    pool, region, app = cognito_cli._parse_daycog_env_filename(
        Path("lsmc-atlas-gui-users.us-east-1.env")
    )
    assert pool == "lsmc-atlas-gui-users"
    assert region == "us-east-1"
    assert app == ""

    pool, region, app = cognito_cli._parse_daycog_env_filename(
        Path("lsmc-atlas-gui-users.us-east-1.lsmc-atlas-gui-client.env")
    )
    assert pool == "lsmc-atlas-gui-users"
    assert region == "us-east-1"
    assert app == "lsmc-atlas-gui-client"

    pool, region, app = cognito_cli._parse_daycog_env_filename(Path("legacy-pool.env"))
    assert pool == "legacy-pool"
    assert region == ""
    assert app == ""


def test_iter_daycog_env_files_prefers_region_scoped_pool_files(
    monkeypatch, tmp_path: Path
) -> None:
    cfg_dir = tmp_path / "daycog"
    _write_env(cfg_dir / "default.env", {"COGNITO_USER_POOL_ID": "us-east-1_default"})
    _write_env(cfg_dir / "legacy-pool.env", {"COGNITO_USER_POOL_ID": "us-east-1_legacy"})
    _write_env(
        cfg_dir / "lsmc-atlas-gui-users.us-east-1.lsmc-atlas-gui-client.env",
        {"COGNITO_USER_POOL_ID": "us-east-1_app"},
    )
    _write_env(
        cfg_dir / "lsmc-atlas-gui-users.us-east-1.env",
        {"COGNITO_USER_POOL_ID": "us-east-1_pool"},
    )

    monkeypatch.setattr(cognito_cli, "_daycog_config_dir", lambda: cfg_dir)

    files = cognito_cli._iter_daycog_env_files()
    assert [p.name for p in files] == [
        "lsmc-atlas-gui-users.us-east-1.env",
        "lsmc-atlas-gui-users.us-east-1.lsmc-atlas-gui-client.env",
        "legacy-pool.env",
        "default.env",
    ]


def test_find_pool_env_file_by_name_region_prefers_pool_file(monkeypatch, tmp_path: Path) -> None:
    cfg_dir = tmp_path / "daycog"
    _write_env(
        cfg_dir / "lsmc-atlas-gui-users.us-east-1.env",
        {"COGNITO_USER_POOL_ID": "us-east-1_pool"},
    )
    _write_env(
        cfg_dir / "lsmc-atlas-gui-users.us-east-1.lsmc-atlas-gui-client.env",
        {"COGNITO_USER_POOL_ID": "us-east-1_pool"},
    )
    monkeypatch.setattr(cognito_cli, "_daycog_config_dir", lambda: cfg_dir)

    env_file, values = cognito_cli._find_pool_env_file_by_name_region(
        "lsmc-atlas-gui-users",
        "us-east-1",
    )

    assert env_file.name == "lsmc-atlas-gui-users.us-east-1.env"
    assert values["COGNITO_USER_POOL_ID"] == "us-east-1_pool"


def test_resolve_selected_pool_name_region_from_pool_id(monkeypatch, tmp_path: Path) -> None:
    cfg_dir = tmp_path / "daycog"
    _write_env(
        cfg_dir / "lsmc-atlas-gui-users.us-east-1.env",
        {
            "COGNITO_USER_POOL_ID": "us-east-1_pool123",
            "AWS_PROFILE": "lsmc",
            "AWS_REGION": "us-east-1",
        },
    )
    monkeypatch.setattr(cognito_cli, "_daycog_config_dir", lambda: cfg_dir)

    pool_name, region, profile, env_file, values = cognito_cli._resolve_selected_pool_name_region(
        pool_id="us-east-1_pool123"
    )
    assert pool_name == "lsmc-atlas-gui-users"
    assert region == "us-east-1"
    assert profile == "lsmc"
    assert env_file.name == "lsmc-atlas-gui-users.us-east-1.env"
    assert values["COGNITO_USER_POOL_ID"] == "us-east-1_pool123"


def test_resolve_selected_pool_name_region_allows_explicit_pool_without_binding(
    monkeypatch,
) -> None:
    monkeypatch.setattr(cognito_cli, "_get_configured_pool_id", lambda: "")
    pool_name, region, profile, _env_file, _values = cognito_cli._resolve_selected_pool_name_region(
        pool_name="LSMC Atlas GUI Users",
        region="us-east-1",
        profile="lsmc",
        pool_id="",
    )
    assert pool_name == "lsmc-atlas-gui-users"
    assert region == "us-east-1"
    assert profile == "lsmc"


def test_cognito_build_passes_domain_options_to_daycog(monkeypatch) -> None:
    captured: dict[str, list[str]] = {}

    monkeypatch.setattr(
        cognito_cli, "_resolve_profile", lambda explicit_profile=None: explicit_profile or "lsmc"
    )
    monkeypatch.setattr(
        cognito_cli,
        "_get_daycog_setup_options",
        lambda: {
            "--region",
            "--profile",
            "--client-name",
            "--domain-prefix",
            "--attach-domain",
            "--no-attach-domain",
            "--callback-url",
            "--logout-url",
            "--print-exports",
        },
    )
    monkeypatch.setattr(cognito_cli, "_build_daycog_proc_env", lambda **_kwargs: {})
    monkeypatch.setattr(cognito_cli, "_ensure_supported_or_raise", lambda *_args, **_kwargs: None)

    def _fake_run_daycog(args: list[str], env=None) -> str:  # noqa: ANN001
        captured["args"] = args
        return ""

    monkeypatch.setattr(cognito_cli, "_run_daycog", _fake_run_daycog)
    monkeypatch.setattr(
        cognito_cli,
        "_find_pool_env_file_by_name_region",
        lambda _pool, _region: (
            Path("/tmp/daycog/pool.env"),
            {"COGNITO_USER_POOL_ID": "us-east-1_testPool"},
        ),
    )
    monkeypatch.setattr(
        cognito_cli, "_write_pool_id_to_atlas_config", lambda _pool_id: Path("/tmp/config.yaml")
    )

    cognito_cli.cognito_build(
        pool_name="lsmc-atlas-gui-users",
        profile="lsmc",
        region="us-east-1",
        domain_prefix="lsmc-atlas-gui-users",
        attach_domain=False,
        callback_url="https://localhost:8915/auth/callback",
        mfa="off",
    )

    args = captured["args"]
    assert args[0] == "setup"
    assert "--client-name" in args
    assert args[args.index("--client-name") + 1] == "atlas"
    assert "--domain-prefix" in args
    assert "lsmc-atlas-gui-users" in args
    assert "--no-attach-domain" in args


def test_cognito_setup_with_google_passes_domain_options_to_daycog(monkeypatch) -> None:
    captured: dict[str, list[str]] = {}

    monkeypatch.setattr(
        cognito_cli, "_resolve_profile", lambda explicit_profile=None: explicit_profile or "lsmc"
    )
    monkeypatch.setattr(
        cognito_cli,
        "_get_daycog_command_options",
        lambda _command: {
            "--region",
            "--profile",
            "--client-name",
            "--domain-prefix",
            "--attach-domain",
            "--no-attach-domain",
            "--callback-url",
            "--logout-url",
            "--print-exports",
        },
    )
    monkeypatch.setattr(cognito_cli, "_build_daycog_proc_env", lambda **_kwargs: {})
    monkeypatch.setattr(cognito_cli, "_ensure_supported_or_raise", lambda *_args, **_kwargs: None)

    def _fake_run_daycog(args: list[str], env=None) -> str:  # noqa: ANN001
        captured["args"] = args
        return ""

    monkeypatch.setattr(cognito_cli, "_run_daycog", _fake_run_daycog)
    monkeypatch.setattr(
        cognito_cli,
        "_find_pool_env_file_by_name_region",
        lambda _pool, _region: (
            Path("/tmp/daycog/pool.env"),
            {"COGNITO_USER_POOL_ID": "us-east-1_testPool"},
        ),
    )
    monkeypatch.setattr(
        cognito_cli, "_write_pool_id_to_atlas_config", lambda _pool_id: Path("/tmp/config.yaml")
    )

    cognito_cli.cognito_setup_with_google(
        pool_name="lsmc-atlas-gui-users",
        profile="lsmc",
        region="us-east-1",
        domain_prefix="lsmc-atlas-gui-users",
        attach_domain=False,
        callback_url="https://localhost:8915/auth/callback",
        mfa="off",
    )

    args = captured["args"]
    assert args[0] == "setup-with-google"
    assert "--client-name" in args
    assert args[args.index("--client-name") + 1] == "atlas"
    assert "--domain-prefix" in args
    assert "lsmc-atlas-gui-users" in args
    assert "--no-attach-domain" in args


def test_read_env_file_ignores_comments_and_unquotes_values(tmp_path: Path) -> None:
    env_file = tmp_path / "pool.env"
    env_file.write_text(
        "\n".join(
            [
                "# comment",
                "COGNITO_USER_POOL_ID=us-east-1_pool123",
                "QUOTED_DOUBLE=\"value\"",
                "QUOTED_SINGLE='value2'",
                " SPACED_KEY = spaced ",
                "INVALID_LINE_WITHOUT_EQUALS",
            ]
        ),
        encoding="utf-8",
    )
    values = cognito_cli._read_env_file(env_file)
    assert values["COGNITO_USER_POOL_ID"] == "us-east-1_pool123"
    assert values["QUOTED_DOUBLE"] == "value"
    assert values["QUOTED_SINGLE"] == "value2"
    assert values["SPACED_KEY"] == "spaced"
    assert "INVALID_LINE_WITHOUT_EQUALS" not in values


def test_resolve_profile_precedence(monkeypatch) -> None:
    monkeypatch.setattr(cognito_cli.settings, "aws_profile", "settings-profile", raising=False)
    monkeypatch.setenv("AWS_PROFILE", "env-profile")
    assert (
        cognito_cli._resolve_profile(
            explicit_profile="explicit-profile",
            daycog_values={"AWS_PROFILE": "daycog-profile"},
        )
        == "explicit-profile"
    )
    assert cognito_cli._resolve_profile(daycog_values={"AWS_PROFILE": "daycog-profile"}) == "daycog-profile"
    assert cognito_cli._resolve_profile(daycog_values={}) == "env-profile"


def test_build_daycog_proc_env_applies_profile_and_region(monkeypatch) -> None:
    monkeypatch.setenv("AWS_PROFILE", "base-profile")
    env = cognito_cli._build_daycog_proc_env(
        {"X": "1"},
        profile="override-profile",
        region="us-east-2",
    )
    assert env["X"] == "1"
    assert env["AWS_PROFILE"] == "override-profile"
    assert env["AWS_REGION"] == "us-east-2"
    assert env["COGNITO_REGION"] == "us-east-2"


def test_safe_pool_name_sanitizes_symbols() -> None:
    assert cognito_cli._safe_pool_name("LSMC Atlas GUI Users!!!") == "lsmc-atlas-gui-users"


def test_get_daycog_command_options_parses_help_output_and_caches(monkeypatch) -> None:
    cognito_cli._DAYCOG_COMMAND_OPTIONS.clear()
    calls = {"count": 0}

    class _Result:
        returncode = 0
        stdout = "--region --profile --callback-url"
        stderr = ""

    def _fake_run(*_args, **_kwargs):
        calls["count"] += 1
        return _Result()

    monkeypatch.setattr(cognito_cli.subprocess, "run", _fake_run)
    options1 = cognito_cli._get_daycog_command_options("setup")
    options2 = cognito_cli._get_daycog_command_options("setup")
    assert "--region" in options1
    assert "--callback-url" in options1
    assert options1 == options2
    assert calls["count"] == 1


def test_get_daycog_command_options_raises_when_help_fails(monkeypatch) -> None:
    cognito_cli._DAYCOG_COMMAND_OPTIONS.clear()

    class _Result:
        returncode = 2
        stdout = "bad"
        stderr = "help failed"

    monkeypatch.setattr(cognito_cli.subprocess, "run", lambda *_args, **_kwargs: _Result())
    with pytest.raises(RuntimeError, match="help failed"):
        cognito_cli._get_daycog_command_options("setup")


def test_ensure_supported_or_raise_behaves_as_expected() -> None:
    cognito_cli._ensure_supported_or_raise({"--x"}, "--x", True, "feature-x")
    cognito_cli._ensure_supported_or_raise({"--x"}, "--y", False, "feature-y")
    with pytest.raises(RuntimeError, match="feature-y"):
        cognito_cli._ensure_supported_or_raise({"--x"}, "--y", True, "feature-y")


def test_resolve_expected_atlas_port_precedence(monkeypatch) -> None:
    monkeypatch.setattr(
        cognito_cli.settings,
        "cognito_redirect_uri",
        "https://localhost:9123/auth/callback",
        raising=False,
    )
    monkeypatch.delenv("ATLAS_PORT", raising=False)
    assert cognito_cli._resolve_expected_atlas_port(9999) == 9999
    monkeypatch.setenv("ATLAS_PORT", "9001")
    assert cognito_cli._resolve_expected_atlas_port(None) == 9001
    monkeypatch.delenv("ATLAS_PORT", raising=False)
    assert cognito_cli._resolve_expected_atlas_port(None) == 9123


def test_resolve_requested_client_name_handles_non_string_and_blank() -> None:
    assert cognito_cli._resolve_requested_client_name(object()) == "atlas"
    with pytest.raises(Exception):
        cognito_cli._resolve_requested_client_name("   ")
