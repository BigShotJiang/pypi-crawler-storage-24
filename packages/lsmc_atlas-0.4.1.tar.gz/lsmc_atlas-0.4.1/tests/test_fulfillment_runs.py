"""Tests for TapDB-backed assay workflow services."""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy.orm import Session

from app.domain.enums import FulfillmentRunState, OrderPatientRole
from app.domain.services.fulfillment_runs import (
    AmendmentCreate,
    FulfillmentOutputService,
    FulfillmentRunCreate,
    FulfillmentRunService,
    ResultCreate,
    ResultsSetService,
    TransitionData,
)
from app.domain.services.order_relationships import OrderPatientLink
from app.domain.services.people import PatientCreate, PatientService
from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService
from app.persistence.tapdb.euid_helpers import get_instance_by_euid
from app.persistence.tapdb.fulfillment_run_repo import (
    FULFILLMENT_OUTPUT_TEMPLATE_CODE,
    FULFILLMENT_RUN_TEMPLATE_CODE,
    RESULTS_SET_TEMPLATE_CODE,
    TapdbFulfillmentRunRepository,
)
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.fixture
def order_with_test_order(db_session: Session, tenant_id: str):
    """Create TapDB-native order + test-order fixture."""
    tenant_uuid = uuid.UUID(tenant_id)
    ensure_tapdb_org(db_session, tenant_uuid)

    patient, _ = PatientService(db_session, tenant_uuid).create(
        PatientCreate(first_name="Test", last_name="Patient"),
        created_by=uuid.uuid4(),
    )

    order, _ = TrfService(db_session, tenant_uuid).create(
        data=TrfCreate(order_type="CLINICAL"),
        tests=[
            TestCreate(
                product_code="WGS-001",
                fulfillment_route_codes=["WGS", "CNV"],
                specimen_type_required="blood-whole",
            )
        ],
        patient_links=[OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)],
        created_by=uuid.uuid4(),
    )

    test_order_rows = TestService(db_session, tenant_uuid).list_for_trf(order.euid)
    assert test_order_rows
    test_order, _, _ = test_order_rows[0]
    return order, test_order, tenant_uuid


@pytest.mark.db
class TestAssayRunService:
    """Test FulfillmentRunService operations."""

    def test_create_fulfillment_run(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        svc = FulfillmentRunService(db_session, tenant_uuid)
        ar, ar_rev = svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=uuid.uuid4(),
        )

        assert ar.order_id == order.euid
        assert ar.test_order_id == test_order.euid
        assert ar.fulfillment_route_code == "WGS"
        assert ar_rev.status == FulfillmentRunState.DRAFT.value
        assert ar_rev.revision_no == 1

        repo = TapdbFulfillmentRunRepository(db_session)
        stored = get_instance_by_euid(db_session, FULFILLMENT_RUN_TEMPLATE_CODE, ar.euid)
        props = repo._instance_properties(stored)
        assert "order_id" not in props
        assert "test_order_id" not in props

    def test_transition_draft_to_ordered(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        svc = FulfillmentRunService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        ar, _ = svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        _, ar_rev = svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.ORDERED, note="Order submitted"),
            transition_by=user_id,
        )
        assert ar_rev.status == FulfillmentRunState.ORDERED.value
        assert ar_rev.revision_no == 2
        assert ar_rev.note == "Order submitted"

    def test_transition_invalid_rejected(self, db_session: Session, order_with_test_order):
        from app.domain.services.fulfillment_runs import InvalidTransitionError

        order, test_order, tenant_uuid = order_with_test_order
        svc = FulfillmentRunService(db_session, tenant_uuid)
        user_id = uuid.uuid4()
        ar, _ = svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )

        with pytest.raises(InvalidTransitionError):
            svc.transition(
                ar.euid,
                TransitionData(target_state=FulfillmentRunState.RESULTED),
                transition_by=user_id,
            )

    def test_transition_idempotent(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        svc = FulfillmentRunService(db_session, tenant_uuid)
        user_id = uuid.uuid4()
        ar, _ = svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        _, ar_rev1 = svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.ORDERED),
            transition_by=user_id,
        )
        _, ar_rev2 = svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.ORDERED),
            transition_by=user_id,
        )
        assert ar_rev1.revision_no == 2
        assert ar_rev2.revision_no == 2

    def test_qc_hold_requires_reason(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        svc = FulfillmentRunService(db_session, tenant_uuid)
        user_id = uuid.uuid4()
        ar, _ = svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )

        for state in (
            FulfillmentRunState.ORDERED,
            FulfillmentRunState.RECEIVED,
            FulfillmentRunState.ACCESSIONED,
            FulfillmentRunState.IN_PROGRESS,
        ):
            svc.transition(ar.euid, TransitionData(target_state=state), transition_by=user_id)

        _, ar_rev = svc.transition(
            ar.euid,
            TransitionData(
                target_state=FulfillmentRunState.QC_HOLD,
                qc_hold_reason="Sample contamination suspected",
            ),
            transition_by=user_id,
        )
        assert ar_rev.status == FulfillmentRunState.QC_HOLD.value
        assert ar_rev.qc_hold_reason == "Sample contamination suspected"

    def test_qc_hold_to_resulted_requires_override(
        self, db_session: Session, order_with_test_order
    ):
        from app.domain.services.fulfillment_runs import InvalidTransitionError

        order, test_order, tenant_uuid = order_with_test_order
        svc = FulfillmentRunService(db_session, tenant_uuid)
        user_id = uuid.uuid4()
        ar, _ = svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )

        for state in (
            FulfillmentRunState.ORDERED,
            FulfillmentRunState.RECEIVED,
            FulfillmentRunState.ACCESSIONED,
            FulfillmentRunState.IN_PROGRESS,
        ):
            svc.transition(ar.euid, TransitionData(target_state=state), transition_by=user_id)
        svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.QC_HOLD, qc_hold_reason="QC issue"),
            transition_by=user_id,
        )

        with pytest.raises(InvalidTransitionError):
            svc.transition(
                ar.euid,
                TransitionData(target_state=FulfillmentRunState.RESULTED, qc_override=False),
                transition_by=user_id,
            )

        _, ar_rev = svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.RESULTED, qc_override=True),
            transition_by=user_id,
        )
        assert ar_rev.status == FulfillmentRunState.RESULTED.value
        assert ar_rev.qc_override is True

    def test_list_for_trf(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        svc = FulfillmentRunService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="CNV"
            ),
            created_by=user_id,
        )

        runs = svc.list_for_trf(order.euid)
        assert len(runs) == 2
        fulfillment_route_codes = {ar.fulfillment_route_code for ar, _ in runs}
        assert fulfillment_route_codes == {"WGS", "CNV"}


@pytest.mark.db
class TestAssayResultService:
    """Test FulfillmentOutputService operations."""

    def test_create_result(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        ar_svc = FulfillmentRunService(db_session, tenant_uuid)
        result_svc = FulfillmentOutputService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        ar, _ = ar_svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        for state in (
            FulfillmentRunState.ORDERED,
            FulfillmentRunState.RECEIVED,
            FulfillmentRunState.ACCESSIONED,
            FulfillmentRunState.IN_PROGRESS,
            FulfillmentRunState.RESULTED,
        ):
            ar_svc.transition(ar.euid, TransitionData(target_state=state), transition_by=user_id)

        result = result_svc.create(
            fulfillment_run_euid=ar.euid,
            data=ResultCreate(
                result_payload={"variants": [{"gene": "BRCA1", "classification": "pathogenic"}]},
                artifact_ids=[],
            ),
            created_by=user_id,
        )
        assert result.version_no == 1
        assert result.result_payload["variants"][0]["gene"] == "BRCA1"

    def test_result_relationships_are_graph_derived_not_json_fields(
        self, db_session: Session, order_with_test_order
    ):
        order, test_order, tenant_uuid = order_with_test_order
        ar_svc = FulfillmentRunService(db_session, tenant_uuid)
        result_svc = FulfillmentOutputService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        ar, _ = ar_svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        result = result_svc.create(
            fulfillment_run_euid=ar.euid,
            data=ResultCreate(result_payload={"variants": []}, artifact_ids=["ART-1", "ART-2"]),
            created_by=user_id,
        )

        repo = TapdbFulfillmentRunRepository(db_session)
        stored = get_instance_by_euid(db_session, FULFILLMENT_OUTPUT_TEMPLATE_CODE, result.euid)
        props = repo._instance_properties(stored)

        assert "fulfillment_run_euid" not in props
        assert "artifact_ids" not in props
        assert repo.get_fulfillment_output(result.euid, tenant_uuid).artifact_ids == [
            "ART-1",
            "ART-2",
        ]

    def test_result_analysis_context_is_reference_object_not_payload(
        self, db_session: Session, order_with_test_order
    ):
        order, test_order, tenant_uuid = order_with_test_order
        ar_svc = FulfillmentRunService(db_session, tenant_uuid)
        result_svc = FulfillmentOutputService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        ar, _ = ar_svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        result = result_svc.create(
            fulfillment_run_euid=ar.euid,
            data=ResultCreate(
                result_payload={"variants": []},
                artifact_ids=[],
                analysis_context={
                    "analysis_euid": "AN-REF-1",
                    "source_system": "daylily-ursa",
                    "run_euid": "RUN-REF-1",
                    "sequenced_library_assignment_euid": "SQA-REF-1",
                    "flowcell_id": "FLOW-REF-1",
                    "lane": "1",
                    "library_barcode": "LIB-REF-1",
                    "atlas_trf_euid": order.euid,
                    "atlas_test_euid": test_order.euid,
                    "atlas_test_fulfillment_item_euid": "TPC-REF-1",
                    "analysis_type": "WGS",
                    "review_state": "APPROVED",
                    "result_status": "COMPLETED",
                },
            ),
            created_by=user_id,
        )

        repo = TapdbFulfillmentRunRepository(db_session)
        stored = get_instance_by_euid(db_session, FULFILLMENT_OUTPUT_TEMPLATE_CODE, result.euid)
        props = repo._instance_properties(stored)
        assert "analysis_context" not in (props.get("result_payload") or {})
        ref = repo._analysis_context_for_result(stored)
        assert ref is not None
        assert ref["analysis_euid"] == "AN-REF-1"
        assert result_svc.get_by_analysis_euid(ar.euid, "AN-REF-1").euid == result.euid

        ref_rows = repo._artifact_euids_for_parent(stored)
        assert ref_rows == []

    def test_create_amendment(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        ar_svc = FulfillmentRunService(db_session, tenant_uuid)
        result_svc = FulfillmentOutputService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        ar, _ = ar_svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        for state in (
            FulfillmentRunState.ORDERED,
            FulfillmentRunState.RECEIVED,
            FulfillmentRunState.ACCESSIONED,
            FulfillmentRunState.IN_PROGRESS,
            FulfillmentRunState.RESULTED,
        ):
            ar_svc.transition(ar.euid, TransitionData(target_state=state), transition_by=user_id)

        original = result_svc.create(
            fulfillment_run_euid=ar.euid,
            data=ResultCreate(result_payload={"variants": []}, artifact_ids=[]),
            created_by=user_id,
        )

        ar_svc.transition(
            ar.euid, TransitionData(target_state=FulfillmentRunState.AMENDED), transition_by=user_id
        )

        amendment = result_svc.create_amendment(
            fulfillment_run_euid=ar.euid,
            data=AmendmentCreate(
                original_result_euid=original.euid,
                amend_reason="Corrected variant classification",
                result_payload={"variants": [{"gene": "BRCA1", "classification": "VUS"}]},
                artifact_ids=[],
            ),
            created_by=user_id,
        )
        assert amendment.version_no == 2
        assert amendment.amends_result_euid == original.euid
        assert amendment.amend_reason == "Corrected variant classification"
        assert result_svc.get(original.euid).result_payload == {"variants": []}


@pytest.mark.db
class TestResultsSetService:
    """Test ResultsSetService operations."""

    def test_get_or_create_for_test(self, db_session: Session, order_with_test_order):
        _order, test_order, tenant_uuid = order_with_test_order
        rs_svc = ResultsSetService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        rs = rs_svc.get_or_create_for_test(test_order.euid, created_by=user_id)
        assert rs.test_euid == test_order.euid
        assert rs.published_at is None

        repo = TapdbFulfillmentRunRepository(db_session)
        stored = get_instance_by_euid(db_session, RESULTS_SET_TEMPLATE_CODE, rs.euid)
        props = repo._instance_properties(stored)
        assert "order_id" not in props

        rs2 = rs_svc.get_or_create_for_test(test_order.euid, created_by=user_id)
        assert rs2.euid == rs.euid

        rs_svc.publish(rs.euid, published_by=user_id)
        rs3 = rs_svc.get_or_create_for_test(test_order.euid, created_by=user_id)
        assert rs3.euid != rs.euid
        assert rs3.test_euid == test_order.euid
        assert rs3.published_at is None

    def test_publish_results_set(self, db_session: Session, order_with_test_order):
        _order, test_order, tenant_uuid = order_with_test_order
        rs_svc = ResultsSetService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        rs = rs_svc.get_or_create_for_test(test_order.euid, created_by=user_id)
        assert rs.published_at is None
        rs = rs_svc.publish(rs.euid, published_by=user_id)
        assert rs.published_at is not None
        assert rs.published_by == user_id

        rs2 = rs_svc.publish(rs.euid, published_by=user_id)
        assert rs2.published_at == rs.published_at

    def test_add_fulfillment_run_to_results_set(self, db_session: Session, order_with_test_order):
        order, test_order, tenant_uuid = order_with_test_order
        ar_svc = FulfillmentRunService(db_session, tenant_uuid)
        rs_svc = ResultsSetService(db_session, tenant_uuid)
        user_id = uuid.uuid4()

        ar, _ = ar_svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=user_id,
        )
        rs = rs_svc.get_or_create_for_test(test_order.euid, created_by=user_id)
        rs_svc.add_fulfillment_run(rs.euid, ar.euid)

        assays = rs_svc.get_fulfillment_runs_for_results_set(rs.euid)
        assert len(assays) == 1
        assert assays[0].euid == ar.euid

        rs_svc.add_fulfillment_run(rs.euid, ar.euid)
        assays = rs_svc.get_fulfillment_runs_for_results_set(rs.euid)
        assert len(assays) == 1

    def test_results_set_membership_is_lineage_derived(
        self, db_session: Session, order_with_test_order
    ):
        order, test_order, tenant_uuid = order_with_test_order
        ar_svc = FulfillmentRunService(db_session, tenant_uuid)
        rs_svc = ResultsSetService(db_session, tenant_uuid)
        ar, _ = ar_svc.create(
            data=FulfillmentRunCreate(
                order_id=order.euid, test_order_id=test_order.euid, fulfillment_route_code="WGS"
            ),
            created_by=uuid.uuid4(),
        )
        rs = rs_svc.get_or_create_for_test(test_order.euid, created_by=None)

        link = rs_svc.add_fulfillment_run(rs.euid, ar.euid)
        assert link.results_set_euid == rs.euid
        assert link.fulfillment_run_euid == ar.euid
