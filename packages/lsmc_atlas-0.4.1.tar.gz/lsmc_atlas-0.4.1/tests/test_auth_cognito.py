"""Tests for Cognito authentication flow + Google OAuth.

Tests cover:
1. Login route - state generation, session storage, redirect URL
2. Callback route - state validation, token exchange, user lookup, session creation
3. Logout route - session clearing, redirect
4. Session persistence across requests
5. Error handling (invalid state, missing code, OAuth errors)
6. Google OAuth login and callback flow
7. Refactored exchange_code_for_tokens (daylily-cognito delegation)
"""

import uuid
from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.api.routes.auth import _auto_provision_user
from app.auth.cognito import CognitoUserInfo, build_login_url, build_logout_url
from app.db.engine import get_db
from app.domain.services.orgs import OrganizationCreate, OrganizationService
from app.domain.services.users import UserCreate, UserService
from app.main import app
from app.settings import settings

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def unauthenticated_client(db_session: Session):
    """Create a test client without authentication override (for testing auth flow)."""

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db

    # Use TestClient with cookies enabled.
    # Set base_url to localhost so the Host header matches the Cognito
    # callback URI domain — otherwise the login route's host-validation
    # redirect fires and tests see an intermediate 302 instead of the
    # Cognito redirect.
    with TestClient(app, base_url="https://localhost:8915", cookies={}) as client:
        yield client

    app.dependency_overrides.clear()


@pytest.fixture
def test_organization(db_session: Session) -> Any:
    """Create a test organization for user provisioning."""
    return OrganizationService(db_session).create(
        OrganizationCreate(name=f"test-org-{uuid.uuid4().hex[:8]}"),
        created_by=None,
    )


@pytest.fixture
def existing_user_profile(db_session: Session, test_organization: Any) -> Any:
    """Create a user profile that exists in the database."""
    return UserService(db_session).create(
        UserCreate(
            cognito_sub="cognito-sub-12345",
            email="existing@lsmc.com",
            name="Existing User",
            tenant_id=test_organization.uid,
            roles=["EXTERNAL_USER"],
        )
    )


@pytest.fixture
def mock_cognito_user() -> CognitoUserInfo:
    """Create a mock Cognito user response."""
    return CognitoUserInfo(
        sub="cognito-sub-12345",
        email="existing@lsmc.com",
        name="Existing User",
        cognito_groups=["lsmc-customers"],
        roles=["EXTERNAL_USER"],
        email_verified=True,
    )


# ============================================================================
# Test: URL Building Functions
# ============================================================================


class TestURLBuilding:
    """Tests for login and logout URL construction."""

    def test_build_login_url_basic(self):
        """Test login URL construction without state."""
        url = build_login_url()
        assert settings.cognito_domain in url
        assert "client_id=" in url
        assert "response_type=code" in url
        assert "scope=openid" in url
        assert "redirect_uri=" in url

    def test_build_login_url_with_state(self):
        """Test login URL includes state parameter."""
        url = build_login_url(state="test-state-123")
        assert "state=test-state-123" in url

    def test_build_login_url_with_nonce(self):
        """Test login URL works when nonce parameter is provided.

        Note: daylily-cognito library doesn't support nonce parameter.
        The function should still work, but the nonce won't be included in the URL.
        """
        url = build_login_url(nonce="test-nonce-456")
        # URL should be valid even though nonce is not supported
        assert settings.cognito_domain in url
        assert "client_id=" in url
        # Note: nonce is NOT expected in URL (daylily-cognito limitation)
        # assert "nonce=test-nonce-456" in url  # Not supported by library

    def test_build_logout_url_basic(self):
        """Test logout URL construction."""
        url = build_logout_url()
        assert settings.cognito_domain in url
        assert "client_id=" in url
        assert "logout_uri=" in url

    def test_build_logout_url_custom_redirect(self):
        """Test logout URL with custom redirect."""
        url = build_logout_url(redirect_uri="https://example.com/goodbye")
        # URL will be encoded, so check for the encoded version
        assert "example.com" in url
        assert "goodbye" in url

    def test_build_logout_url_includes_client_id(self):
        """Test logout URL includes the correct client_id parameter."""
        url = build_logout_url()
        assert f"client_id={settings.cognito_app_client_id}" in url

    def test_build_logout_url_default_redirects_to_root(self):
        """Test logout URL default redirect is the root URL (not /auth/callback)."""
        url = build_logout_url()
        # The default should redirect to root, not /auth/callback
        # This is the URL that must be registered in Cognito App Client's Sign out URLs
        assert "logout_uri=" in url
        # Should NOT include /auth/callback in the logout redirect
        assert "/auth/callback" not in url or "%2Fauth%2Fcallback" not in url

    def test_build_logout_url_is_properly_encoded(self):
        """Test logout URL parameters are properly URL-encoded."""
        url = build_logout_url(redirect_uri="https://localhost:8915/some/path?query=value")
        # The redirect URI should be URL-encoded
        assert "logout_uri=" in url
        # Colon and slashes should be encoded
        assert "%3A" in url or ":" not in url.split("logout_uri=")[1].split("&")[0]

    def test_build_logout_url_uses_https_domain(self):
        """Test logout URL uses https:// scheme for the Cognito domain."""
        url = build_logout_url()
        assert url.startswith("https://")

    def test_build_logout_url_includes_logout_endpoint(self):
        """Test logout URL points to the /logout endpoint."""
        url = build_logout_url()
        # The URL path should be /logout
        assert "/logout?" in url


# ============================================================================
# Test: Login Route
# ============================================================================


class TestLoginRoute:
    """Tests for GET /auth/login."""

    @pytest.mark.db
    def test_login_redirects_to_cognito(self, unauthenticated_client: TestClient):
        """Test login redirects to Cognito authorize URL."""
        response = unauthenticated_client.get("/auth/login", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        location = response.headers.get("location", "")
        assert settings.cognito_domain in location
        assert "state=" in location

    @pytest.mark.db
    def test_login_stores_state_in_session(self, unauthenticated_client: TestClient):
        """Test login stores OAuth state in session cookie."""
        unauthenticated_client.get("/auth/login", follow_redirects=False)

        # Session cookie should be set
        assert settings.session_cookie_name in unauthenticated_client.cookies

    @pytest.mark.db
    def test_login_port_mismatch_returns_500(self, unauthenticated_client: TestClient):
        """If redirect URI port differs from request port, login should fail fast."""
        with patch.object(settings, "cognito_redirect_uri", "https://localhost:8912/auth/callback"):
            response = unauthenticated_client.get("/auth/login", follow_redirects=False)

        assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
        assert "Cognito redirect URI port mismatch" in response.json()["detail"]

    @pytest.mark.db
    def test_login_missing_redirect_uri_returns_500(self, unauthenticated_client: TestClient):
        """If redirect URI is blank, return explicit config error before Cognito redirect."""
        with patch.object(settings, "cognito_redirect_uri", ""):
            response = unauthenticated_client.get("/auth/login", follow_redirects=False)

        assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
        assert "Cognito login config is incomplete" in response.json()["detail"]
        assert "cognito_redirect_uri" in response.json()["detail"]


# ============================================================================
# Test: Callback Route
# ============================================================================


class TestCallbackRoute:
    """Tests for GET /auth/callback."""

    @pytest.mark.db
    def test_callback_missing_code_returns_400(self, unauthenticated_client: TestClient):
        """Test callback without code returns 400."""
        response = unauthenticated_client.get(
            "/auth/callback?state=test-state", follow_redirects=False
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "Missing authorization code" in response.json()["detail"]

    @pytest.mark.db
    def test_callback_invalid_state_returns_400(self, unauthenticated_client: TestClient):
        """Test callback with invalid state returns 400."""
        response = unauthenticated_client.get(
            "/auth/callback?code=test-code&state=invalid-state", follow_redirects=False
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "Invalid state parameter" in response.json()["detail"]

    @pytest.mark.db
    def test_callback_oauth_error_returns_400(self, unauthenticated_client: TestClient):
        """Test callback with OAuth error returns error details."""
        response = unauthenticated_client.get(
            "/auth/callback?error=access_denied&error_description=User+cancelled",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "OAuth error" in response.json()["detail"]
        assert "access_denied" in response.json()["detail"]

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    @patch("app.api.routes.auth.get_user_info_from_tokens")
    def test_callback_valid_flow_creates_session(
        self,
        mock_get_user_info,
        mock_exchange,
        unauthenticated_client: TestClient,
        existing_user_profile: Any,
        mock_cognito_user: CognitoUserInfo,
    ):
        """Test complete valid callback flow creates session and redirects."""
        # Setup mocks
        mock_exchange.return_value = {
            "id_token": "mock-id-token",
            "access_token": "mock-access-token",
        }
        mock_get_user_info.return_value = mock_cognito_user

        # First, call login to get state in session
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        # Extract state from redirect URL
        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        # Now call callback with valid state
        response = unauthenticated_client.get(
            f"/auth/callback?code=valid-code&state={state}", follow_redirects=False
        )

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/"

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    @patch("app.api.routes.auth.get_user_info_from_tokens")
    def test_callback_unknown_user_is_auto_provisioned(
        self,
        mock_get_user_info,
        mock_exchange,
        unauthenticated_client: TestClient,
        db_session: Session,
        test_organization: Any,
    ):
        """Authenticated unknown users are auto-provisioned on callback."""
        # User not in database
        unknown_user = CognitoUserInfo(
            sub="unknown-sub",
            email="unknown@lsmc.com",
            name="Unknown User",
            cognito_groups=[],
            roles=[],
            email_verified=True,
        )

        mock_exchange.return_value = {
            "id_token": "mock-id-token",
            "access_token": "mock-access-token",
        }
        mock_get_user_info.return_value = unknown_user

        # First, get state from login
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        response = unauthenticated_client.get(
            f"/auth/callback?code=valid-code&state={state}", follow_redirects=False
        )

        assert response.status_code == 302
        assert response.headers.get("location") == "/"
        created = UserService(db_session).get_by_cognito_sub("unknown-sub")
        assert created is not None
        assert created.email == "unknown@lsmc.com"


# ============================================================================
# Test: Logout Route
# ============================================================================


class TestLogoutRoute:
    """Tests for POST/GET /auth/logout."""

    @pytest.mark.db
    def test_logout_post_redirects_to_cognito_logout(self, unauthenticated_client: TestClient):
        """Test POST logout redirects to Cognito logout URL."""
        response = unauthenticated_client.post("/auth/logout", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        location = response.headers.get("location", "")
        # Should redirect to Cognito logout URL
        assert "logout" in location
        assert settings.cognito_app_client_id in location

    @pytest.mark.db
    def test_logout_get_redirects_to_cognito_logout(self, unauthenticated_client: TestClient):
        """Test GET /auth/logout also redirects to Cognito logout URL."""
        response = unauthenticated_client.get("/auth/logout", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        location = response.headers.get("location", "")
        assert "logout" in location


# ============================================================================
# Test: Session State Persistence
# ============================================================================


class TestSessionPersistence:
    """Tests for session state persistence across requests."""

    @pytest.mark.db
    def test_session_state_persists_between_requests(self, unauthenticated_client: TestClient):
        """Test that OAuth state stored in session persists across requests."""
        # Call login to generate state
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)

        # Extract state from redirect URL
        import urllib.parse

        location = login_response.headers.get("location", "")
        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        original_state = params.get("state", [""])[0]

        assert original_state, "State should be generated"

        # Make another request (simulating browser returning from Cognito)
        # The session should still have the state
        # We can verify by attempting callback with the correct state

        # Note: In a real test with mocked Cognito, this would succeed
        # Here we just verify the state is in the URL
        assert len(original_state) > 20  # Token should be substantial


# ============================================================================
# Test: CognitoUserInfo
# ============================================================================


class TestCognitoUserInfo:
    """Tests for CognitoUserInfo dataclass."""

    def test_tenant_id_from_attribute_found(self):
        """Test extracting tenant_id from custom attributes."""
        user = CognitoUserInfo(
            sub="test-sub",
            email="test@lsmc.com",
            name="Test",
            cognito_groups=[],
            roles=[],
            custom_attributes={"custom:tenant_id": "abc-123"},
        )

        assert user.tenant_id_from_attribute == "abc-123"

    def test_tenant_id_from_attribute_org_id(self):
        """Test extracting tenant_id from org_id attribute."""
        user = CognitoUserInfo(
            sub="test-sub",
            email="test@lsmc.com",
            name="Test",
            cognito_groups=[],
            roles=[],
            custom_attributes={"custom:org_id": "org-456"},
        )

        assert user.tenant_id_from_attribute == "org-456"

    def test_tenant_id_from_attribute_none(self):
        """Test tenant_id is None when no custom attributes."""
        user = CognitoUserInfo(
            sub="test-sub",
            email="test@lsmc.com",
            name="Test",
            cognito_groups=[],
            roles=[],
        )

        assert user.tenant_id_from_attribute is None


# ============================================================================
# Test: Session Middleware Configuration
# ============================================================================


@pytest.mark.db
class TestSessionMiddleware:
    """Tests for session middleware configuration.

    These tests verify the session cookie settings that caused the
    original OAuth state validation failure (missing DEBUG=true meant
    https_only=True, which blocked cookies on http://localhost).
    """

    def test_session_cookie_is_set_on_login(self, unauthenticated_client: TestClient):
        """Test that session cookie is set during login flow."""
        unauthenticated_client.get("/auth/login", follow_redirects=False)

        # Session cookie should be set
        assert settings.session_cookie_name in unauthenticated_client.cookies

    def test_session_cookie_persists_across_requests(self, unauthenticated_client: TestClient):
        """Test that session cookie persists and is sent on subsequent requests."""
        # First request sets the session
        unauthenticated_client.get("/auth/login", follow_redirects=False)
        initial_cookie = unauthenticated_client.cookies.get(settings.session_cookie_name)

        # Second request should send the same session
        unauthenticated_client.get("/auth/login", follow_redirects=False)
        second_cookie = unauthenticated_client.cookies.get(settings.session_cookie_name)

        assert initial_cookie is not None
        assert second_cookie is not None


# ============================================================================
# Test: Full OAuth Flow Integration
# ============================================================================


class TestFullOAuthFlow:
    """Integration tests for complete OAuth flow (login -> callback)."""

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    @patch("app.api.routes.auth.get_user_info_from_tokens")
    def test_complete_oauth_flow_success(
        self,
        mock_get_user_info,
        mock_exchange,
        unauthenticated_client: TestClient,
        existing_user_profile: Any,
        mock_cognito_user: CognitoUserInfo,
    ):
        """Test complete flow: login -> callback -> session created."""
        import urllib.parse

        mock_exchange.return_value = {
            "id_token": "mock-id-token",
            "access_token": "mock-access-token",
        }
        mock_get_user_info.return_value = mock_cognito_user

        # Step 1: Call login to initiate flow
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        assert login_response.status_code == 302

        # Extract state from redirect URL
        location = login_response.headers.get("location", "")
        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        # Verify state was generated
        assert state, "State should be generated and included in redirect"
        assert len(state) > 20, "State should be a secure token"

        # Step 2: Simulate callback from Cognito with the same state
        callback_response = unauthenticated_client.get(
            f"/auth/callback?code=auth-code-from-cognito&state={state}", follow_redirects=False
        )

        # Should redirect to home on success
        assert callback_response.status_code == 302
        assert callback_response.headers.get("location") == "/"

    @pytest.mark.db
    def test_oauth_flow_state_mismatch_fails(
        self,
        unauthenticated_client: TestClient,
    ):
        """Test that mismatched state between login and callback fails."""
        # Step 1: Call login to generate state
        unauthenticated_client.get("/auth/login", follow_redirects=False)

        # Step 2: Call callback with DIFFERENT state
        callback_response = unauthenticated_client.get(
            "/auth/callback?code=auth-code&state=completely-wrong-state", follow_redirects=False
        )

        # Should fail with 400
        assert callback_response.status_code == 400
        assert "Invalid state parameter" in callback_response.json()["detail"]

    @pytest.mark.db
    def test_oauth_flow_state_not_set_fails(
        self,
        unauthenticated_client: TestClient,
    ):
        """Test that callback without prior login (no state) fails.

        This simulates the original bug: if session cookie isn't
        persisted (e.g., https_only=True on http), the session
        appears empty on callback.
        """
        # Call callback directly WITHOUT calling login first
        # (simulates session not being persisted)
        callback_response = unauthenticated_client.get(
            "/auth/callback?code=auth-code&state=some-state", follow_redirects=False
        )

        # Should fail because session has no oauth_state
        assert callback_response.status_code == 400
        assert "Invalid state parameter" in callback_response.json()["detail"]


# ============================================================================
# Test: Authentication Bounces (Protected Pages Redirect to Login)
# ============================================================================


class TestAuthenticationBounces:
    """Tests for unauthenticated access to protected pages.

    Protected pages should redirect to /auth/login instead of returning
    401/403 errors.
    """

    @pytest.mark.db
    def test_dashboard_redirects_to_login(self, unauthenticated_client: TestClient):
        """Test unauthenticated request to / redirects to /auth/login."""
        response = unauthenticated_client.get("/", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/auth/login"

    @pytest.mark.db
    def test_trfs_redirect_to_login(self, unauthenticated_client: TestClient):
        """Test unauthenticated request to /trfs redirects to /auth/login."""
        response = unauthenticated_client.get("/trfs", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/auth/login"

    @pytest.mark.db
    def test_patients_redirects_to_login(self, unauthenticated_client: TestClient):
        """Test unauthenticated request to /patients redirects to /auth/login."""
        response = unauthenticated_client.get("/patients", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/auth/login"

    @pytest.mark.db
    def test_shipments_redirects_to_login(self, unauthenticated_client: TestClient):
        """Test unauthenticated request to /shipments redirects to /auth/login."""
        response = unauthenticated_client.get("/shipments", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/auth/login"

    @pytest.mark.db
    def test_biospecimens_path_is_not_registered(self, unauthenticated_client: TestClient):
        """Legacy biospecimen routes are removed and should return 404."""
        response = unauthenticated_client.get("/biospecimens", follow_redirects=False)

        assert response.status_code == status.HTTP_404_NOT_FOUND

    @pytest.mark.db
    def test_clinicians_redirects_to_login(self, unauthenticated_client: TestClient):
        """Test unauthenticated request to /clinicians redirects to /auth/login."""
        response = unauthenticated_client.get("/clinicians", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/auth/login"

    @pytest.mark.db
    def test_admin_settings_redirects_to_login(self, unauthenticated_client: TestClient):
        """Test unauthenticated request to /admin/settings redirects to /auth/login."""
        response = unauthenticated_client.get("/admin/settings", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/auth/login"

    @pytest.mark.db
    def test_results_redirects_to_login(self, unauthenticated_client: TestClient):
        """Test unauthenticated request to /results redirects to /auth/login."""
        response = unauthenticated_client.get("/results", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/auth/login"


# ============================================================================
# Test: Login Page Behavior
# ============================================================================


class TestLoginPageBehavior:
    """Tests for /auth/login page behavior."""

    @pytest.mark.db
    def test_login_accessible_without_auth(self, unauthenticated_client: TestClient):
        """Test /auth/login is accessible without authentication."""
        response = unauthenticated_client.get("/auth/login", follow_redirects=False)

        # Should redirect to Cognito authorize URL (302)
        assert response.status_code == status.HTTP_302_FOUND
        location = response.headers.get("location", "")
        assert settings.cognito_domain in location

    @pytest.mark.db
    def test_login_includes_state_parameter(self, unauthenticated_client: TestClient):
        """Test /auth/login redirect includes state parameter for CSRF protection."""
        response = unauthenticated_client.get("/auth/login", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        location = response.headers.get("location", "")
        assert "state=" in location

    @pytest.mark.db
    def test_login_includes_required_oauth_params(self, unauthenticated_client: TestClient):
        """Test /auth/login redirect includes required OAuth parameters."""
        response = unauthenticated_client.get("/auth/login", follow_redirects=False)

        location = response.headers.get("location", "")
        assert "client_id=" in location
        assert "response_type=code" in location
        assert "redirect_uri=" in location
        assert "scope=" in location


# ============================================================================
# Test: Token Exchange Failures
# ============================================================================


class TestTokenExchangeFailures:
    """Tests for handling token exchange failures in callback."""

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    def test_callback_token_exchange_failure_returns_401(
        self,
        mock_exchange,
        unauthenticated_client: TestClient,
    ):
        """Test callback handles token exchange failure with 401."""
        from app.auth.cognito import CognitoAuthError

        mock_exchange.side_effect = CognitoAuthError("Invalid authorization code")

        # First, get state from login
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        # Now call callback with valid state but bad code
        response = unauthenticated_client.get(
            f"/auth/callback?code=invalid-code&state={state}", follow_redirects=False
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED
        assert "Authentication failed" in response.json()["detail"]

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    def test_callback_no_id_token_returns_400(
        self,
        mock_exchange,
        unauthenticated_client: TestClient,
    ):
        """Test callback handles missing ID token."""
        mock_exchange.return_value = {"access_token": "mock-access"}  # No id_token

        # First, get state from login
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        response = unauthenticated_client.get(
            f"/auth/callback?code=valid-code&state={state}", follow_redirects=False
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "No ID token" in response.json()["detail"]


# ============================================================================
# Test: Inactive User Rejection
# ============================================================================


class TestInactiveUserRejection:
    """Tests for rejecting disabled/inactive users."""

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    @patch("app.api.routes.auth.get_user_info_from_tokens")
    def test_callback_inactive_user_redirects_to_logout(
        self,
        mock_get_user_info,
        mock_exchange,
        unauthenticated_client: TestClient,
        db_session: Session,
    ):
        """Test callback redirects inactive/disabled users to logout."""
        from app.domain.services.orgs import OrganizationCreate, OrganizationService
        from app.domain.services.users import UserCreate, UserService, UserUpdate

        tenant = OrganizationService(db_session).create(
            OrganizationCreate(name=f"inactive-user-org-{uuid.uuid4().hex[:8]}"),
            created_by=None,
        )
        user_svc = UserService(db_session)
        inactive_user = user_svc.create(
            UserCreate(
                cognito_sub="inactive-sub-12345",
                email="inactive@lsmc.com",
                name="Inactive User",
                tenant_id=tenant.uid,
                roles=["EXTERNAL_USER"],
            )
        )
        user_svc.update(inactive_user.euid, UserUpdate(is_active=False))

        mock_exchange.return_value = {
            "id_token": "mock-id-token",
            "access_token": "mock-access-token",
        }
        mock_get_user_info.return_value = CognitoUserInfo(
            sub="inactive-sub-12345",
            email="inactive@lsmc.com",
            name="Inactive User",
            cognito_groups=[],
            roles=["EXTERNAL_USER"],
        )

        # First, get state from login
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        response = unauthenticated_client.get(
            f"/auth/callback?code=valid-code&state={state}", follow_redirects=False
        )

        assert response.status_code == 302
        location = response.headers.get("location", "")
        assert location.startswith("https://localhost:8915/auth/error")
        assert "reason=account_disabled" in location


# ============================================================================
# Test: User Auto-Provisioning
# ============================================================================


class TestUserAutoProvisioning:
    """Tests for auto-provisioning users from Cognito."""

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    @patch("app.api.routes.auth.get_user_info_from_tokens")
    def test_callback_auto_provisions_new_user(
        self,
        mock_get_user_info,
        mock_exchange,
        unauthenticated_client: TestClient,
        db_session: Session,
    ):
        """Test callback auto-provisions new users when enabled."""
        from app.domain.services.orgs import OrganizationCreate, OrganizationService
        from app.domain.services.users import UserService

        tenant = OrganizationService(db_session).create(
            OrganizationCreate(name=f"autoprov-org-{uuid.uuid4().hex[:8]}"),
            created_by=None,
        )

        new_user_info = CognitoUserInfo(
            sub="new-user-sub-12345",
            email="newuser@lsmc.com",
            name="New User",
            cognito_groups=["lsmc-customers"],
            roles=["EXTERNAL_USER"],
            custom_attributes={"custom:tenant_id": str(tenant.uid)},
        )

        mock_exchange.return_value = {
            "id_token": "mock-id-token",
            "access_token": "mock-access-token",
        }
        mock_get_user_info.return_value = new_user_info

        # First, get state from login
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        # Mock settings to enable auto-provision
        with patch.object(settings, "cognito_auto_provision_users", True):
            response = unauthenticated_client.get(
                f"/auth/callback?code=valid-code&state={state}", follow_redirects=False
            )

        # Should succeed and redirect home
        assert response.status_code == status.HTTP_302_FOUND
        assert response.headers.get("location") == "/"

        # Verify user was created in TapDB
        created_user = UserService(db_session).get_by_cognito_sub("new-user-sub-12345")
        assert created_user is not None
        assert created_user.email == "newuser@lsmc.com"
        assert created_user.tenant_id == tenant.uid

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    @patch("app.api.routes.auth.get_user_info_from_tokens")
    def test_callback_auto_provision_uses_default_tenant(
        self,
        mock_get_user_info,
        mock_exchange,
        unauthenticated_client: TestClient,
        db_session: Session,
    ):
        """Test auto-provisioning uses default tenant when no custom attribute."""
        from app.domain.services.orgs import OrganizationCreate, OrganizationService
        from app.domain.services.users import UserService

        tenant = OrganizationService(db_session).create(
            OrganizationCreate(name=f"default-tenant-org-{uuid.uuid4().hex[:8]}"),
            created_by=None,
        )

        new_user_info = CognitoUserInfo(
            sub="default-tenant-user-sub",
            email="defaulttenant@lsmc.com",
            name="Default Tenant User",
            cognito_groups=["lsmc-customers"],
            roles=["EXTERNAL_USER"],
            # No custom tenant_id attribute
        )

        mock_exchange.return_value = {
            "id_token": "mock-id-token",
            "access_token": "mock-access-token",
        }
        mock_get_user_info.return_value = new_user_info

        # First, get state from login
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        # Mock settings to enable auto-provision with a default tenant
        with (
            patch.object(settings, "cognito_auto_provision_users", True),
            patch.object(settings, "cognito_default_tenant_id", str(tenant.uid)),
        ):
            response = unauthenticated_client.get(
                f"/auth/callback?code=valid-code&state={state}", follow_redirects=False
            )

        # Should succeed
        assert response.status_code == status.HTTP_302_FOUND

        # Verify user was created with default tenant in TapDB
        created_user = UserService(db_session).get_by_cognito_sub("default-tenant-user-sub")
        assert created_user is not None
        assert created_user.tenant_id == tenant.uid

    def test_auto_provision_returns_none_when_tenant_validation_fails(self):
        """Validation errors during auto-provision should not raise from callback path."""
        cognito_user = CognitoUserInfo(
            sub="tenant-missing-sub",
            email="tenant-missing@lsmc.com",
            name="Missing Tenant",
            cognito_groups=["lsmc-customers"],
            roles=["EXTERNAL_USER"],
        )

        with (
            patch.object(
                settings, "cognito_default_tenant_id", "00000000-0000-0000-0000-000000000001"
            ),
            patch("app.api.routes.auth.UserService") as mock_user_service_cls,
        ):
            mock_user_service_cls.return_value.create.side_effect = ValueError(
                "Tenant 00000000-0000-0000-0000-000000000001 not found"
            )
            result = _auto_provision_user(db=object(), cognito_user=cognito_user)

        assert result is None

    def test_auto_provision_uses_first_active_org_when_no_configured_tenant(self):
        """Auto-provision should fall back to the first active org when no tenant is configured."""
        fallback_tenant_id = uuid.uuid4()
        captured: dict[str, Any] = {}

        cognito_user = CognitoUserInfo(
            sub="fallback-active-org-sub",
            email="fallback-active-org@lsmc.com",
            name="Fallback Active Org",
            cognito_groups=["lsmc-customers"],
            roles=["EXTERNAL_USER"],
        )

        class FakeOrganizationService:
            def __init__(self, _db):
                pass

            def get_by_uid(self, _org_uid):
                return None

            def list_all(self, active_only=True):
                assert active_only is True
                return [SimpleNamespace(uid=fallback_tenant_id)]

            def create(self, *_args, **_kwargs):
                raise AssertionError("Should not create org when active org fallback exists")

        class FakeUserService:
            def __init__(self, _db):
                pass

            def create(self, data):
                captured["tenant_id"] = data.tenant_id
                return SimpleNamespace(
                    euid=f"PRF-{uuid.uuid4().hex[:6]}",
                    tenant_id=data.tenant_id,
                    email=data.email,
                    is_active=True,
                    roles=data.roles,
                )

        with (
            patch.object(settings, "cognito_default_tenant_id", None),
            patch("app.api.routes.auth.OrganizationService", FakeOrganizationService),
            patch("app.api.routes.auth.UserService", FakeUserService),
        ):
            created = _auto_provision_user(db=object(), cognito_user=cognito_user)

        assert created is not None
        assert created.tenant_id == fallback_tenant_id
        assert captured["tenant_id"] == fallback_tenant_id

    def test_auto_provision_bootstraps_tenant_when_none_exist(self):
        """Auto-provision should create a fallback tenant when none exist."""
        bootstrapped_tenant_id = uuid.uuid4()
        captured: dict[str, Any] = {"org_create_name": None, "tenant_id": None}

        cognito_user = CognitoUserInfo(
            sub="fallback-bootstrap-sub",
            email="fallback-bootstrap@lsmc.com",
            name="Fallback Bootstrap",
            cognito_groups=["lsmc-customers"],
            roles=["EXTERNAL_USER"],
        )

        class FakeOrganizationService:
            def __init__(self, _db):
                pass

            def get_by_uid(self, _org_uid):
                return None

            def list_all(self, active_only=True):
                assert active_only is True
                return []

            def create(self, org_create, created_by=None):
                assert created_by is None
                captured["org_create_name"] = org_create.name
                return SimpleNamespace(uid=bootstrapped_tenant_id)

        class FakeUserService:
            def __init__(self, _db):
                pass

            def create(self, data):
                captured["tenant_id"] = data.tenant_id
                return SimpleNamespace(
                    euid=f"PRF-{uuid.uuid4().hex[:6]}",
                    tenant_id=data.tenant_id,
                    email=data.email,
                    is_active=True,
                    roles=data.roles,
                )

        with (
            patch.object(settings, "cognito_default_tenant_id", None),
            patch("app.api.routes.auth.OrganizationService", FakeOrganizationService),
            patch("app.api.routes.auth.UserService", FakeUserService),
        ):
            created = _auto_provision_user(db=object(), cognito_user=cognito_user)

        assert created is not None
        assert created.tenant_id == bootstrapped_tenant_id
        assert captured["tenant_id"] == bootstrapped_tenant_id
        assert isinstance(captured["org_create_name"], str)
        assert captured["org_create_name"].startswith("atlas-auto-provision-")


# ============================================================================
# Test: Group to Role Mapping
# ============================================================================


class TestGroupRoleMapping:
    """Tests for Cognito group to LSMC Atlas role mapping."""

    def test_lsmc_admins_maps_to_admin(self):
        """Test lsmc-admins group maps to ADMIN role."""
        groups = ["lsmc-admins"]
        roles = settings.map_cognito_groups_to_roles(groups)
        assert "ADMIN" in roles

    def test_lsmc_staff_maps_to_internal(self):
        """Test lsmc-staff group maps to INTERNAL_USER role."""
        groups = ["lsmc-staff"]
        roles = settings.map_cognito_groups_to_roles(groups)
        assert "INTERNAL_USER" in roles

    def test_lsmc_customers_maps_to_external(self):
        """Test lsmc-customers group maps to EXTERNAL_USER role."""
        groups = ["lsmc-customers"]
        roles = settings.map_cognito_groups_to_roles(groups)
        assert "EXTERNAL_USER" in roles

    def test_multiple_groups_map_to_multiple_roles(self):
        """Test user with multiple groups gets multiple roles."""
        groups = ["lsmc-admins", "lsmc-staff"]
        roles = settings.map_cognito_groups_to_roles(groups)
        assert "ADMIN" in roles
        assert "INTERNAL_USER" in roles

    def test_unknown_group_maps_to_empty(self):
        """Test unknown group doesn't crash and returns empty."""
        groups = ["unknown-group-xyz"]
        roles = settings.map_cognito_groups_to_roles(groups)
        # Unknown groups should not add any roles
        assert "unknown-group-xyz" not in roles


# ============================================================================
# Test: CognitoAuthError Handling
# ============================================================================


class TestCognitoAuthErrorHandling:
    """Tests for proper handling of CognitoAuthError."""

    @pytest.mark.db
    @patch("app.api.routes.auth.exchange_code_for_tokens")
    def test_cognito_auth_error_returns_401(
        self,
        mock_exchange,
        unauthenticated_client: TestClient,
    ):
        """Test CognitoAuthError is caught and returns 401."""
        from app.auth.cognito import CognitoAuthError

        mock_exchange.side_effect = CognitoAuthError("Token expired")

        # First, get state from login
        login_response = unauthenticated_client.get("/auth/login", follow_redirects=False)
        location = login_response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)
        params = urllib.parse.parse_qs(parsed.query)
        state = params.get("state", [""])[0]

        response = unauthenticated_client.get(
            f"/auth/callback?code=bad-code&state={state}", follow_redirects=False
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED
        assert "Authentication failed" in response.json()["detail"]


# ============================================================================
# Test: Server Instance Session Invalidation
# ============================================================================


class TestServerInstanceSessionInvalidation:
    """Tests for session invalidation on server restart."""

    def test_get_server_instance_id_returns_string(self):
        """Test server instance ID is a non-empty string."""
        from app.auth.session import get_server_instance_id

        instance_id = get_server_instance_id()
        assert isinstance(instance_id, str)
        assert len(instance_id) > 0

    def test_get_server_instance_id_is_consistent(self):
        """Test server instance ID remains constant within the same process."""
        from app.auth.session import get_server_instance_id

        id1 = get_server_instance_id()
        id2 = get_server_instance_id()
        assert id1 == id2

    @pytest.mark.db
    def test_session_with_wrong_instance_id_is_invalidated(
        self, unauthenticated_client: TestClient
    ):
        """Test that sessions with wrong server_instance_id are invalidated."""
        # Patch the session check to simulate a session from a different server instance
        with patch("app.auth.session.get_server_instance_id", return_value="different-instance-id"):
            # Try to access a protected route - should redirect to login
            # Note: "/" is the dashboard route
            response = unauthenticated_client.get("/", follow_redirects=False)

            # Should redirect to login (session invalid due to instance mismatch)
            assert response.status_code == status.HTTP_302_FOUND
            assert "/auth/login" in response.headers.get("location", "")


# ============================================================================
# Test: Logout URL Validation (Cognito App Client Configuration)
# ============================================================================


class TestLogoutURLValidation:
    """Tests for Cognito logout URL validation and configuration."""

    @pytest.fixture(autouse=True)
    def _set_cognito_settings(self):
        """Provide non-empty Cognito settings so URL construction is testable."""
        with (
            patch.object(settings, "cognito_app_client_id", "test-client-id-123"),
            patch.object(
                settings,
                "cognito_domain",
                "test.auth.us-west-2.amazoncognito.com",
            ),
            patch.object(settings, "cognito_redirect_uri", "https://localhost:8915/auth/callback"),
            patch.object(settings, "cognito_logout_url", ""),
        ):
            yield

    def test_logout_url_format_matches_cognito_requirements(self):
        """Test logout URL format matches Cognito /logout endpoint requirements."""
        url = build_logout_url()

        # Parse the URL
        import urllib.parse

        parsed = urllib.parse.urlparse(url)

        # Should be HTTPS
        assert parsed.scheme == "https"

        # Should have /logout path
        assert parsed.path == "/logout"

        # Should have required query parameters
        params = urllib.parse.parse_qs(parsed.query)
        assert "client_id" in params
        assert "logout_uri" in params

    def test_logout_url_client_id_matches_settings(self):
        """Test logout URL client_id matches the configured app client ID."""
        url = build_logout_url()

        import urllib.parse

        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query)

        assert params["client_id"][0] == settings.cognito_app_client_id

    def test_logout_url_domain_matches_settings(self):
        """Test logout URL domain matches the configured Cognito domain."""
        url = build_logout_url()

        import urllib.parse

        parsed = urllib.parse.urlparse(url)

        # Domain should match (may or may not include https://)
        expected_domain = settings.cognito_domain
        if expected_domain.startswith("https://"):
            expected_domain = expected_domain[8:]

        assert parsed.netloc == expected_domain

    def test_logout_url_redirects_to_valid_target(self):
        """Test logout URL redirect target is a valid localhost URL."""
        url = build_logout_url()

        import urllib.parse

        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query)

        logout_uri = params["logout_uri"][0]
        logout_parsed = urllib.parse.urlparse(logout_uri)

        # Should redirect to localhost (for local development)
        assert logout_parsed.netloc == "localhost:8915"

    @pytest.mark.db
    def test_logout_route_generates_valid_cognito_url(self, unauthenticated_client: TestClient):
        """Test the logout route generates a valid Cognito logout URL."""
        response = unauthenticated_client.post("/auth/logout", follow_redirects=False)

        assert response.status_code == status.HTTP_302_FOUND
        location = response.headers.get("location", "")

        import urllib.parse

        parsed = urllib.parse.urlparse(location)

        # Should be Cognito domain
        assert "cognito" in parsed.netloc or settings.cognito_domain in location

        # Should have /logout path
        assert parsed.path == "/logout"

        # Should have required parameters
        params = urllib.parse.parse_qs(parsed.query)
        assert "client_id" in params
        assert "logout_uri" in params


# ================================================================================
# Email Domain Validation Tests
# ================================================================================


class TestEmailDomainValidation:
    """Tests for email domain allowed/blocked list validation."""

    def test_empty_email_returns_error(self):
        """Empty email should return error."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=["lsmc.bio"])
        valid, error = s.validate_email_domain("")
        assert not valid
        assert "required" in error.lower()

    def test_email_without_at_returns_error(self):
        """Email without @ should return error."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=["lsmc.bio"])
        valid, error = s.validate_email_domain("notanemail")
        assert not valid
        assert "invalid" in error.lower()

    def test_email_with_empty_domain_returns_error(self):
        """Email with empty domain should return error."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=["lsmc.bio"])
        valid, error = s.validate_email_domain("user@")
        assert not valid
        assert "missing domain" in error.lower()

    def test_empty_allowed_list_blocks_all(self):
        """Empty allowed_email_domains list should block all domains."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=[])
        valid, error = s.validate_email_domain("user@lsmc.bio")
        assert not valid
        assert "not enabled" in error.lower()

    def test_wildcard_allows_all(self):
        """['*'] should allow all domains."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=["*"])
        valid, error = s.validate_email_domain("user@anydomain.com")
        assert valid
        assert error == ""

    def test_allowed_domain_accepted(self):
        """Email from allowed domain should be accepted."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=["lsmc.bio", "lsmc.com"])
        valid, error = s.validate_email_domain("user@lsmc.bio")
        assert valid
        assert error == ""

    def test_non_allowed_domain_blocked(self):
        """Email from non-allowed domain should be blocked."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=["lsmc.bio", "lsmc.com"])
        valid, error = s.validate_email_domain("user@gmail.com")
        assert not valid
        assert "gmail.com" in error
        assert "not allowed" in error.lower()

    def test_domain_matching_is_case_insensitive(self):
        """Domain matching should be case-insensitive."""
        from app.settings import Settings

        s = Settings(allowed_email_domains=["LSMC.BIO"])
        valid, error = s.validate_email_domain("user@lsmc.bio")
        assert valid
        assert error == ""

        valid2, error2 = s.validate_email_domain("user@LSMC.BIO")
        assert valid2
        assert error2 == ""

    def test_all_required_domains_allowed(self):
        """All required domains from the spec should be allowed."""
        from app.settings import Settings

        required_domains = [
            "lsmc.bio",
            "lsmc.com",
            "lsmc.life",
            "daylilyinformatics.com",
            "dyly.bio",
        ]
        s = Settings(allowed_email_domains=required_domains)

        for domain in required_domains:
            valid, error = s.validate_email_domain(f"test@{domain}")
            assert valid, f"Domain {domain} should be allowed"
            assert error == ""


# ============================================================================
# Test: Refactored exchange_code_for_tokens (daylily-cognito delegation)
# ============================================================================


class TestExchangeCodeDelegation:
    """Verify exchange_code_for_tokens delegates to daylily_cognito."""

    @patch("app.auth.cognito.exchange_authorization_code")
    def test_delegates_to_daylily_cognito(self, mock_exchange):
        """Token exchange calls daylily_cognito.exchange_authorization_code."""
        import asyncio

        from app.auth.cognito import exchange_code_for_tokens

        mock_exchange.return_value = {"access_token": "at", "id_token": "it"}
        result = asyncio.run(exchange_code_for_tokens("test-code"))
        assert result == {"access_token": "at", "id_token": "it"}
        mock_exchange.assert_called_once_with(
            domain=settings.cognito_domain,
            client_id=settings.cognito_app_client_id,
            code="test-code",
            redirect_uri=settings.cognito_redirect_uri,
            client_secret=settings.cognito_app_client_secret or None,
        )

    @patch("app.auth.cognito.exchange_authorization_code")
    def test_wraps_runtime_error_as_cognito_error(self, mock_exchange):
        """RuntimeError from library is wrapped in CognitoAuthError."""
        import asyncio

        from app.auth.cognito import CognitoAuthError, exchange_code_for_tokens

        mock_exchange.side_effect = RuntimeError("token endpoint failed")
        with pytest.raises(CognitoAuthError, match="token endpoint failed"):
            asyncio.run(exchange_code_for_tokens("bad-code"))


# ============================================================================
# Test: Google OAuth Login Route
# ============================================================================


@pytest.mark.db
class TestGoogleLogin:
    """Tests for GET /auth/google/login."""

    def test_google_login_disabled_returns_404(self, unauthenticated_client: TestClient):
        """When google_oauth_enabled=False, /auth/google/login returns 404."""
        with patch.object(settings, "google_oauth_enabled", False):
            response = unauthenticated_client.get("/auth/google/login", follow_redirects=False)
        assert response.status_code == status.HTTP_404_NOT_FOUND

    @patch("app.api.routes.auth.build_google_login_url")
    def test_google_login_redirects_to_google(
        self, mock_build_url, unauthenticated_client: TestClient
    ):
        """When enabled, redirects to Google authorization URL."""
        mock_build_url.return_value = "https://accounts.google.com/o/oauth2/v2/auth?client_id=test"
        with patch.object(settings, "google_oauth_enabled", True):
            response = unauthenticated_client.get("/auth/google/login", follow_redirects=False)
        assert response.status_code == status.HTTP_302_FOUND
        location = response.headers.get("location", "")
        assert "accounts.google.com" in location
        mock_build_url.assert_called_once()

    @patch("app.api.routes.auth.build_google_login_url")
    def test_google_login_stores_state_in_session(
        self, mock_build_url, unauthenticated_client: TestClient
    ):
        """State token is stored in session for CSRF validation."""
        mock_build_url.return_value = "https://accounts.google.com/o/oauth2/v2/auth?state=abc"
        with patch.object(settings, "google_oauth_enabled", True):
            unauthenticated_client.get("/auth/google/login", follow_redirects=False)
        # The state was passed to build_google_login_url
        call_kwargs = mock_build_url.call_args
        assert call_kwargs.kwargs.get("state") is not None


# ============================================================================
# Test: Google OAuth Callback Route
# ============================================================================


@pytest.mark.db
class TestGoogleCallback:
    """Tests for GET /auth/google/callback."""

    def test_google_callback_disabled_returns_404(self, unauthenticated_client: TestClient):
        """When google_oauth_enabled=False, callback returns 404."""
        with patch.object(settings, "google_oauth_enabled", False):
            response = unauthenticated_client.get(
                "/auth/google/callback?code=test&state=test",
                follow_redirects=False,
            )
        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_google_callback_error_param_returns_400(self, unauthenticated_client: TestClient):
        """Google error parameter results in 400."""
        with patch.object(settings, "google_oauth_enabled", True):
            response = unauthenticated_client.get(
                "/auth/google/callback?error=access_denied",
                follow_redirects=False,
            )
        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "access_denied" in response.json()["detail"]

    def test_google_callback_missing_code_returns_400(self, unauthenticated_client: TestClient):
        """Missing authorization code returns 400."""
        with patch.object(settings, "google_oauth_enabled", True):
            response = unauthenticated_client.get(
                "/auth/google/callback?state=test",
                follow_redirects=False,
            )
        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "Missing authorization code" in response.json()["detail"]

    def test_google_callback_invalid_state_returns_400(self, unauthenticated_client: TestClient):
        """Mismatched CSRF state returns 400."""
        with patch.object(settings, "google_oauth_enabled", True):
            response = unauthenticated_client.get(
                "/auth/google/callback?code=test&state=wrong",
                follow_redirects=False,
            )
        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "Invalid state parameter" in response.json()["detail"]

    @patch("app.api.routes.auth.get_google_userinfo")
    @patch("app.api.routes.auth.exchange_google_code")
    @patch("app.api.routes.auth.build_google_login_url")
    def test_google_callback_valid_flow_creates_session(
        self,
        mock_build_url,
        mock_exchange,
        mock_userinfo,
        unauthenticated_client: TestClient,
        existing_user_profile: Any,
    ):
        """Complete valid Google callback creates session and redirects."""
        mock_build_url.return_value = "https://accounts.google.com/o/oauth2/v2/auth?state=s"
        mock_exchange.return_value = {"access_token": "gat-123", "id_token": "git-123"}
        mock_userinfo.return_value = {
            "sub": "google-sub-99",
            "email": existing_user_profile.email,
            "name": existing_user_profile.name,
        }

        # Step 1: initiate Google login to get state in session
        with patch.object(settings, "google_oauth_enabled", True):
            login_resp = unauthenticated_client.get("/auth/google/login", follow_redirects=False)
        assert login_resp.status_code == status.HTTP_302_FOUND

        # Extract the state that was passed to build_google_login_url
        call_kwargs = mock_build_url.call_args
        state_value = call_kwargs.kwargs.get("state")

        # Step 2: call callback with matching state
        with patch.object(settings, "google_oauth_enabled", True):
            cb_resp = unauthenticated_client.get(
                f"/auth/google/callback?code=gcode&state={state_value}",
                follow_redirects=False,
            )
        assert cb_resp.status_code == status.HTTP_302_FOUND
        assert cb_resp.headers.get("location") == "/"

    @patch("app.api.routes.auth.get_google_userinfo")
    @patch("app.api.routes.auth.exchange_google_code")
    @patch("app.api.routes.auth.build_google_login_url")
    def test_google_callback_blocked_domain_redirects_to_error(
        self,
        mock_build_url,
        mock_exchange,
        mock_userinfo,
        unauthenticated_client: TestClient,
    ):
        """Email from blocked domain redirects to error page."""
        mock_build_url.return_value = "https://accounts.google.com/auth?state=s"
        mock_exchange.return_value = {"access_token": "gat"}
        mock_userinfo.return_value = {
            "sub": "g-sub",
            "email": "evil@blocked.com",
            "name": "Evil User",
        }

        with (
            patch.object(settings, "google_oauth_enabled", True),
            patch.object(settings, "blocked_email_domains", ["blocked.com"]),
        ):
            _login_resp = unauthenticated_client.get("/auth/google/login", follow_redirects=False)
            state = mock_build_url.call_args.kwargs.get("state")
            cb_resp = unauthenticated_client.get(
                f"/auth/google/callback?code=c&state={state}",
                follow_redirects=False,
            )
        assert cb_resp.status_code == 302
        assert "blocked_domain" in cb_resp.headers.get(
            "location", ""
        ) or "/auth/error" in cb_resp.headers.get("location", "")

    @patch("app.api.routes.auth.get_google_userinfo")
    @patch("app.api.routes.auth.exchange_google_code")
    @patch("app.api.routes.auth.build_google_login_url")
    def test_google_callback_auto_provisions_user(
        self,
        mock_build_url,
        mock_exchange,
        mock_userinfo,
        unauthenticated_client: TestClient,
        db_session: Session,
    ):
        """New Google user is auto-provisioned when enabled."""
        from app.domain.services.orgs import OrganizationCreate, OrganizationService
        from app.domain.services.users import UserService

        tenant = OrganizationService(db_session).create(
            OrganizationCreate(name=f"google-autoprov-org-{uuid.uuid4().hex[:8]}"),
            created_by=None,
        )

        mock_build_url.return_value = "https://accounts.google.com/auth?state=s"
        mock_exchange.return_value = {"access_token": "gat"}
        mock_userinfo.return_value = {
            "sub": "new-google-sub-555",
            "email": "newgoogle@lsmc.com",
            "name": "New Google User",
        }

        with (
            patch.object(settings, "google_oauth_enabled", True),
            patch.object(settings, "cognito_auto_provision_users", True),
            patch.object(settings, "cognito_default_tenant_id", str(tenant.uid)),
        ):
            _login_resp = unauthenticated_client.get("/auth/google/login", follow_redirects=False)
            state = mock_build_url.call_args.kwargs.get("state")
            cb_resp = unauthenticated_client.get(
                f"/auth/google/callback?code=c&state={state}",
                follow_redirects=False,
            )
        assert cb_resp.status_code == status.HTTP_302_FOUND

        # Verify user was created
        user = UserService(db_session).get_by_email("newgoogle@lsmc.com")
        assert user is not None
        assert user.cognito_sub == "google_new-google-sub-555"
        assert user.tenant_id == tenant.uid

    @patch("app.api.routes.auth.get_google_userinfo")
    @patch("app.api.routes.auth.exchange_google_code")
    @patch("app.api.routes.auth.build_google_login_url")
    def test_google_callback_disabled_user_redirects_to_error(
        self,
        mock_build_url,
        mock_exchange,
        mock_userinfo,
        unauthenticated_client: TestClient,
        db_session: Session,
    ):
        """Disabled user redirects to error page even with valid Google tokens."""
        from app.domain.services.orgs import OrganizationCreate, OrganizationService
        from app.domain.services.users import UserCreate, UserService, UserUpdate

        tenant = OrganizationService(db_session).create(
            OrganizationCreate(name=f"google-disabled-org-{uuid.uuid4().hex[:8]}"),
            created_by=None,
        )
        user_svc = UserService(db_session)
        disabled_user = user_svc.create(
            UserCreate(
                cognito_sub="google_disabled-sub",
                email="disabled@lsmc.com",
                name="Disabled Google User",
                tenant_id=tenant.uid,
                roles=["EXTERNAL_USER"],
            )
        )
        user_svc.update(disabled_user.euid, UserUpdate(is_active=False))

        mock_build_url.return_value = "https://accounts.google.com/auth?state=s"
        mock_exchange.return_value = {"access_token": "gat"}
        mock_userinfo.return_value = {
            "sub": "disabled-sub",
            "email": "disabled@lsmc.com",
            "name": "Disabled Google User",
        }

        with patch.object(settings, "google_oauth_enabled", True):
            _login_resp = unauthenticated_client.get("/auth/google/login", follow_redirects=False)
            state = mock_build_url.call_args.kwargs.get("state")
            cb_resp = unauthenticated_client.get(
                f"/auth/google/callback?code=c&state={state}",
                follow_redirects=False,
            )
        assert cb_resp.status_code == 302
        assert "account_disabled" in cb_resp.headers.get(
            "location", ""
        ) or "/auth/error" in cb_resp.headers.get("location", "")


# ============================================================================
# Test: Google OAuth Helper Functions
# ============================================================================


class TestGoogleHelpers:
    """Tests for Google OAuth helper functions in cognito.py."""

    @patch("app.auth.cognito.build_google_authorization_url")
    def test_build_google_login_url_passes_settings(self, mock_build):
        """build_google_login_url uses settings values."""
        from app.auth.cognito import build_google_login_url

        mock_build.return_value = "https://accounts.google.com/auth"
        with (
            patch.object(settings, "google_client_id", "test-gid"),
            patch.object(settings, "google_redirect_uri", "http://localhost/cb"),
            patch.object(settings, "google_hd", ""),
        ):
            result = build_google_login_url(state="s123")
        mock_build.assert_called_once_with(
            client_id="test-gid",
            redirect_uri="http://localhost/cb",
            state="s123",
        )
        assert result == "https://accounts.google.com/auth"

    @patch("app.auth.cognito.build_google_authorization_url")
    def test_build_google_login_url_includes_hd_when_set(self, mock_build):
        """hd parameter is included when google_hd is non-empty."""
        from app.auth.cognito import build_google_login_url

        mock_build.return_value = "https://accounts.google.com/auth"
        with (
            patch.object(settings, "google_client_id", "gid"),
            patch.object(settings, "google_redirect_uri", "http://localhost/cb"),
            patch.object(settings, "google_hd", "lsmc.bio"),
        ):
            build_google_login_url(state="s")
        call_kwargs = mock_build.call_args.kwargs
        assert call_kwargs["hd"] == "lsmc.bio"

    @patch("app.auth.cognito.exchange_google_code_for_tokens")
    def test_exchange_google_code_wraps_error(self, mock_exchange):
        """RuntimeError from library is wrapped in CognitoAuthError."""
        from app.auth.cognito import CognitoAuthError, exchange_google_code

        mock_exchange.side_effect = RuntimeError("bad request")
        with pytest.raises(CognitoAuthError, match="bad request"):
            exchange_google_code("bad-code")

    @patch("app.auth.cognito.fetch_google_userinfo")
    def test_get_google_userinfo_wraps_error(self, mock_fetch):
        """RuntimeError from library is wrapped in CognitoAuthError."""
        from app.auth.cognito import CognitoAuthError, get_google_userinfo

        mock_fetch.side_effect = RuntimeError("invalid token")
        with pytest.raises(CognitoAuthError, match="invalid token"):
            get_google_userinfo("bad-token")


# =============================================================================
# Issue #19 — Default settings verification
# =============================================================================


class TestProductionDefaults:
    """Verify production-ready defaults (issue #19).

    The Settings class should default to cognito auth and HTTPS redirect URIs
    so new installations are secure by default.
    """

    def test_default_auth_mode_is_cognito(self):
        """Settings default auth_mode should be 'cognito'."""
        from app.settings import Settings

        # Build a fresh Settings with no env overrides to check class defaults
        field_info = Settings.model_fields["auth_mode"]
        assert field_info.default == "cognito"

    def test_default_cognito_redirect_uri_is_https(self):
        """Cognito redirect URI default should use HTTPS."""
        from app.settings import Settings

        field_info = Settings.model_fields["cognito_redirect_uri"]
        assert field_info.default.startswith("https://")

    def test_default_google_redirect_uri_is_https(self):
        """Google redirect URI default should use HTTPS."""
        from app.settings import Settings

        field_info = Settings.model_fields["google_redirect_uri"]
        assert field_info.default.startswith("https://")
