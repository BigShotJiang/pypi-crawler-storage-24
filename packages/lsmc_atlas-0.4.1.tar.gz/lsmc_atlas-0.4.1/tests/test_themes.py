"""Tests for UI theming functionality."""

import uuid
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.persistence.tapdb.orm_models.themes import (
    BaseTheme,
    SkinConfiguration,
    SkinConfigurationRevision,
)
from tests.tapdb_test_helpers import ensure_tapdb_org


class TestThemeModels:
    """Test theme model definitions."""

    def test_base_theme_enum(self):
        """Test BaseTheme enum values."""
        assert BaseTheme.DEFAULT.value == "default"
        assert BaseTheme.BOLD.value == "bold"
        assert BaseTheme.PROFESSIONAL.value == "professional"
        assert BaseTheme.MINIMAL.value == "minimal"

    def test_all_themes_available(self):
        """Test all expected themes are defined."""
        themes = [t.value for t in BaseTheme]
        assert "default" in themes
        assert "bold" in themes
        assert "professional" in themes
        assert "minimal" in themes
        assert len(themes) == 4

    def test_skin_configuration_model_structure(self):
        """Test SkinConfiguration model has required fields."""
        columns = {c.name for c in SkinConfiguration.__table__.columns}
        assert "id" in columns
        assert "tenant_id" in columns
        assert "skin_code" in columns
        assert "created_at" in columns
        assert "created_by" in columns

    def test_skin_configuration_revision_model_structure(self):
        """Test SkinConfigurationRevision model has required fields."""
        columns = {c.name for c in SkinConfigurationRevision.__table__.columns}
        assert "revision_id" in columns
        assert "skin_id" in columns
        assert "revision_no" in columns
        assert "base_theme" in columns
        assert "custom_css" in columns
        assert "css_variables" in columns
        assert "is_active" in columns


class TestThemeRoutes:
    """Test theme API routes structure."""

    def test_available_themes_list(self):
        """Test that expected themes are defined in routes."""
        from app.api.routes.themes import AVAILABLE_THEMES

        theme_codes = [t.code for t in AVAILABLE_THEMES]
        assert "default" in theme_codes
        assert "bold" in theme_codes
        assert "professional" in theme_codes
        assert "minimal" in theme_codes

    def test_theme_info_structure(self):
        """Test ThemeInfo structure."""
        from app.api.routes.themes import ThemeInfo

        theme = ThemeInfo(code="test", name="Test Theme", description="A test theme")

        assert theme.code == "test"
        assert theme.name == "Test Theme"
        assert theme.description == "A test theme"


class TestThemeCSSFiles:
    """Test theme CSS file existence and structure."""

    def test_bold_theme_css_exists(self):
        """Test bold theme CSS file exists."""
        import os

        css_path = "app/web/static/css/themes/bold.css"
        assert os.path.exists(css_path)

    def test_professional_theme_css_exists(self):
        """Test professional theme CSS file exists."""
        import os

        css_path = "app/web/static/css/themes/professional.css"
        assert os.path.exists(css_path)

    def test_minimal_theme_css_exists(self):
        """Test minimal theme CSS file exists."""
        import os

        css_path = "app/web/static/css/themes/minimal.css"
        assert os.path.exists(css_path)

    def test_bold_theme_has_data_theme_selector(self):
        """Test bold theme CSS uses correct selector."""
        with open("app/web/static/css/themes/bold.css") as f:
            content = f.read()
            assert '[data-theme="bold"]' in content

    def test_professional_theme_has_data_theme_selector(self):
        """Test professional theme CSS uses correct selector."""
        with open("app/web/static/css/themes/professional.css") as f:
            content = f.read()
            assert '[data-theme="professional"]' in content

    def test_minimal_theme_has_data_theme_selector(self):
        """Test minimal theme CSS uses correct selector."""
        with open("app/web/static/css/themes/minimal.css") as f:
            content = f.read()
            assert '[data-theme="minimal"]' in content


class TestRoleIndicators:
    """Test role indicator CSS classes."""

    def test_role_indicator_css_exists(self):
        """Test role indicator CSS is defined in main theme."""
        with open("app/web/static/css/theme.css") as f:
            content = f.read()
            assert ".role-indicator" in content
            assert ".role-admin" in content
            assert ".role-staff" in content
            assert ".role-customer" in content

    def test_role_badge_css_exists(self):
        """Test role badge CSS is defined in main theme."""
        with open("app/web/static/css/theme.css") as f:
            content = f.read()
            assert ".role-badge" in content
            assert ".role-badge-admin" in content
            assert ".role-badge-lsmc_staff" in content


@pytest.fixture
def tenant_org(db_session, tenant_id):
    """Create a tenant organization for theme tests."""
    org_id = uuid.UUID(tenant_id)
    ensure_tapdb_org(
        db_session,
        org_id,
        name="test-organization",
        display_name="Test Organization",
        org_type="CUSTOMER",
    )
    db_session.flush()
    return SimpleNamespace(id=org_id)


@pytest.fixture
def client_with_org(db_session, test_user, tenant_org):
    """Create a test client with DB session, user, and tenant organization."""
    from app.auth.dependencies import get_current_user
    from app.db.engine import get_db
    from app.main import app

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_current_user():
        return test_user

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user

    with TestClient(app) as c:
        yield c

    app.dependency_overrides.clear()


@pytest.mark.db
class TestThemeAPI:
    """Test theme API endpoints with database."""

    def test_list_themes(self, client: TestClient):
        """Test listing available themes."""
        response = client.get("/api/themes/")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) == 4
        codes = [t["code"] for t in data]
        assert "default" in codes
        assert "bold" in codes
        assert "professional" in codes
        assert "minimal" in codes

    def test_get_current_theme_default(self, client: TestClient):
        """Test getting current theme returns default when not set."""
        response = client.get("/api/themes/current")
        assert response.status_code == 200
        data = response.json()
        assert data["theme"] == "default"
        assert data["custom_css"] is None

    def test_select_theme_form_data(self, client_with_org: TestClient):
        """Test selecting a theme with form-urlencoded data."""
        response = client_with_org.post(
            "/api/themes/select",
            data={"theme": "bold"},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "success"
        assert data["theme"] == "bold"

    def test_select_theme_persists(self, client_with_org: TestClient):
        """Test that selected theme persists and can be retrieved."""
        # Select bold theme
        response = client_with_org.post(
            "/api/themes/select",
            data={"theme": "professional"},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        assert response.status_code == 200

        # Get current theme should return professional
        response = client_with_org.get("/api/themes/current")
        assert response.status_code == 200
        data = response.json()
        assert data["theme"] == "professional"

    def test_select_invalid_theme(self, client: TestClient):
        """Test selecting an invalid theme returns error."""
        response = client.post(
            "/api/themes/select",
            data={"theme": "nonexistent"},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        assert response.status_code == 400
        data = response.json()
        assert "Invalid theme" in data["detail"]

    def test_select_theme_without_theme_param(self, client: TestClient):
        """Test selecting theme without theme parameter returns error."""
        response = client.post(
            "/api/themes/select",
            data={},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        assert response.status_code == 400
        data = response.json()
        assert "Missing required field" in data["detail"]

    def test_select_theme_multiple_revisions(self, client_with_org: TestClient):
        """Test that changing themes creates new revisions (append-only)."""
        # Select first theme
        response = client_with_org.post(
            "/api/themes/select",
            data={"theme": "bold"},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        assert response.status_code == 200

        # Select second theme
        response = client_with_org.post(
            "/api/themes/select",
            data={"theme": "minimal"},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        assert response.status_code == 200

        # Current should be minimal
        response = client_with_org.get("/api/themes/current")
        assert response.status_code == 200
        assert response.json()["theme"] == "minimal"

    def test_unauthenticated_list_themes(self):
        """Test listing themes without authentication."""
        from fastapi.testclient import TestClient as TC

        from app.main import app

        with TC(app) as c:
            response = c.get("/api/themes/")
            # List themes is public
            assert response.status_code == 200

    def test_unauthenticated_select_theme(self):
        """Test selecting theme without authentication fails."""
        from fastapi.testclient import TestClient as TC

        from app.main import app

        # Clear any overrides so no mock user is injected
        app.dependency_overrides.clear()

        with TC(app) as c:
            response = c.post(
                "/api/themes/select",
                data={"theme": "bold"},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            assert response.status_code == 401
