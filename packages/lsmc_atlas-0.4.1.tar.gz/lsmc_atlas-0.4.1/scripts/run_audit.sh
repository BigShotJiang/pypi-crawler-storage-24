#!/bin/bash
source atlas_activate
python scripts/audit_test_coverage.py

