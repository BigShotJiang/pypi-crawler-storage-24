#!/usr/bin/env python3
"""Demo script: Create order workflow via Atlas API.

Creates an order with 2 tests (WGS + analysis), shipment, kit, and specimen.

Usage:
    source atlas_activate
    python scripts/api_demo_create_order_flow.py

    # With explicit session cookie (for Cognito mode):
    python scripts/api_demo_create_order_flow.py --cookie "session=..."
"""

import argparse
import sys
from datetime import datetime

import httpx

# --- Configuration ---
BASE_URL = "http://localhost:8915"

# Data to use (from seeded database)
PATIENT_ID = "aaaa1111-1111-1111-1111-111111111111"  # Emily Johnson
CLINICIAN_ID = "cccc1111-1111-1111-1111-111111111111"  # Sarah Chen


# Global client for session persistence
_client: httpx.Client | None = None


def init_client(cookie: str | None = None) -> bool:
    """Initialize HTTP client, attempting to get a session if needed."""
    global _client

    if cookie:
        # Use provided cookie - server uses lsmc_session cookie name
        clean_cookie = cookie.replace("session=", "").replace("lsmc_session=", "")
        _client = httpx.Client(timeout=30, cookies={"lsmc_session": clean_cookie})
        return True

    # Try to get a session by hitting /auth/login (requires Cognito)
    with httpx.Client(timeout=30, follow_redirects=False) as temp_client:
        # First, try to access /auth/me to see if we already have a session
        # Cognito login requires browser-based OAuth flow
        resp = temp_client.get(f"{BASE_URL}/auth/login")

        if resp.status_code == 302:
            # Check if we got a session cookie
            session_cookie = None
            for cookie_name in ["session", "lsmc_session"]:
                if cookie_name in resp.cookies:
                    session_cookie = resp.cookies[cookie_name]
                    break

            if session_cookie:
                # Check if redirect is to home (dev mode) or Cognito (prod mode)
                location = resp.headers.get("location", "")
                if location == "/" or location.startswith(BASE_URL):
                    # Dev mode - session is ready
                    _client = httpx.Client(
                        timeout=30,
                        cookies={"session": session_cookie}
                        if "session" in resp.cookies
                        else {"lsmc_session": session_cookie},
                    )
                    return True

    return False


def api_call(method: str, path: str, data: dict | None = None) -> dict:
    """Make an authenticated API call using session cookie."""
    global _client
    if _client is None:
        raise RuntimeError("Client not initialized")

    url = f"{BASE_URL}{path}"
    resp = _client.request(method, url, json=data)

    if not resp.is_success:
        print(f"✗ {method} {path} → {resp.status_code}")
        print(f"  Response: {resp.text[:500]}")
        sys.exit(1)

    print(f"✓ {method} {path} → {resp.status_code}")
    return resp.json() if resp.text else {}


def main():
    global _client

    parser = argparse.ArgumentParser(description="Create order workflow via Atlas API")
    parser.add_argument("--cookie", help="Session cookie value (e.g., 'session=...')")
    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("LSMC Atlas API Demo: Create Order Workflow")
    print("=" * 60 + "\n")

    # Step 1: Initialize client and authenticate
    print("Step 1: Authenticate")

    if not init_client(args.cookie):
        print("✗ Could not initialize session automatically.")
        print("  The server may be in Cognito mode.")
        print("\n  Options:")
        print("  1. Log in via browser and provide --cookie")
        print("  2. Switch to dev mode in config.yaml")
        sys.exit(1)

    # Verify authentication
    try:
        me_resp = _client.get(f"{BASE_URL}/auth/me")
        if not me_resp.is_success:
            print(f"✗ Authentication failed: {me_resp.status_code}")
            print("  Make sure you're logged in and the session cookie is valid")
            sys.exit(1)
        user_info = me_resp.json()
        print(f"✓ Authenticated as {user_info.get('email', 'unknown')}")
    except Exception as e:
        print(f"✗ Failed to verify authentication: {e}")
        sys.exit(1)

    # Step 2: Create order with 2 test orders (WGS + analysis)
    print("\nStep 2: Create order with 2 tests (WGS + Analysis)")
    order_data = {
        "patient_id": PATIENT_ID,
        "clinician_id": CLINICIAN_ID,
        "order_type": "CLINICAL",
        "clinical_notes": "Demo order created via API script",
        "test_orders": [
            {
                "fulfillment_routes": [
                    {"fulfillment_route_code": "WGS", "assay_name": "Whole Genome Sequencing"}
                ],
                "specimen_type": "Blood",
                "priority": "NORMAL",
                "clinical_notes": "WGS test for patient",
            },
            {
                "fulfillment_routes": [
                    {"fulfillment_route_code": "ANALYSIS", "assay_name": "Bioinformatics Analysis"}
                ],
                "specimen_type": "DNA",
                "priority": "STAT",
                "clinical_notes": "Priority analysis",
            },
        ],
    }
    order = api_call("POST", "/api/orders", order_data)
    order_number = order["order_number"]
    print(f"  → Created Order: {order_number}")

    # Step 3: Create shipment
    print("\nStep 3: Create shipment")
    shipment_data = {
        "tracking_number": f"DEMO-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        "carrier": "FedEx",
        "destination": "LSMC_LAB",
    }
    shipment = api_call("POST", "/api/shipments", shipment_data)
    shipment_number = shipment["shipment_number"]
    print(f"  → Created Shipment: {shipment_number}")

    # Step 4: Create test kit
    print("\nStep 4: Create test kit")
    kit_barcode = f"KIT-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    kit_data = {"kit_barcode": kit_barcode, "kit_type": "Blood Collection Kit"}
    kit = api_call("POST", "/api/testkits", kit_data)
    kit_id = kit["id"]
    print(f"  → Created TestKit: {kit_barcode} (ID: {kit_id})")

    # Step 5: Add kit to shipment
    print("\nStep 5: Add kit to shipment")
    containment = {"item_type": "TestKit", "item_id": kit_id}
    api_call("POST", f"/api/shipments/{shipment_number}/contents", containment)
    print(f"  → Added TestKit to Shipment {shipment_number}")

    # Step 6: Create biospecimen
    print("\nStep 6: Create biospecimen")
    specimen_barcode = f"SPEC-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    specimen_data = {
        "specimen_barcode": specimen_barcode,
        "specimen_type": "Whole Blood",
        "collection_date": datetime.now().isoformat(),
    }
    specimen = api_call("POST", "/api/biospecimens", specimen_data)
    specimen_id = specimen["id"]
    print(f"  → Created BioSpecimen: {specimen_barcode} (ID: {specimen_id})")

    # Step 7: Add specimen to shipment (containing it alongside the kit)
    print("\nStep 7: Add specimen to shipment")
    specimen_containment = {"item_type": "BioSpecimen", "item_id": specimen_id}
    api_call("POST", f"/api/shipments/{shipment_number}/contents", specimen_containment)
    print(f"  → Added BioSpecimen to Shipment {shipment_number}")

    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Order Number:     {order_number}")
    print(f"Test Orders:      {len(order.get('test_orders', []))} (WGS + Analysis)")
    print(f"Shipment Number:  {shipment_number}")
    print(f"TestKit Barcode:  {kit_barcode}")
    print(f"Specimen Barcode: {specimen_barcode}")
    print(f"\nView order at: {BASE_URL}/orders/{order_number}")
    print("=" * 60 + "\n")

    # Cleanup
    _client.close()


if __name__ == "__main__":
    main()
