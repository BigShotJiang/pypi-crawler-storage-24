#!/usr/bin/env python3
"""
Test runner script for LSMC Hub.

This script ensures tests are run with the correct conda environment
and provides convenient options for different test scenarios.
"""

import os
import subprocess
import sys
from pathlib import Path

# Path to the conda environment's Python
CONDA_PYTHON = "/Users/daylily/miniconda3/envs/LSMC_HUB/bin/python"


def run_command(cmd: list[str]) -> int:
    """Run a command and return the exit code."""
    print(f"Running: {' '.join(cmd)}")
    return subprocess.run(cmd).returncode


def main():
    """Main test runner."""
    # Change to project root
    project_root = Path(__file__).parent.parent
    os.chdir(project_root)

    if len(sys.argv) < 2:
        print("Usage: python scripts/run_tests.py [all|unit|db|specific-file]")
        print("Examples:")
        print("  python scripts/run_tests.py all          # Run all tests")
        print("  python scripts/run_tests.py unit         # Run unit tests only")
        print("  python scripts/run_tests.py db           # Run database tests only")
        print("  python scripts/run_tests.py tests/test_matching.py  # Run specific file")
        return 1

    test_type = sys.argv[1]

    if test_type == "all":
        cmd = [CONDA_PYTHON, "-m", "pytest", "tests/", "-v"]
    elif test_type == "unit":
        cmd = [CONDA_PYTHON, "-m", "pytest", "tests/", "-v", "-m", "not db and not postgres"]
    elif test_type == "db":
        cmd = [CONDA_PYTHON, "-m", "pytest", "tests/", "-v", "-m", "db or postgres"]
    elif test_type.startswith("tests/"):
        cmd = [CONDA_PYTHON, "-m", "pytest", test_type, "-v"]
    else:
        print(f"Unknown test type: {test_type}")
        return 1

    return run_command(cmd)


if __name__ == "__main__":
    sys.exit(main())
