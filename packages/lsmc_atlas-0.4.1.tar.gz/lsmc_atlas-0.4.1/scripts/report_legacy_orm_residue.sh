#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

PATTERN='app\.db\.models|app\.persistence\.tapdb\.orm_models'

# Use grep -rE as a portable fallback (rg may not be installed in CI)
SEARCH_DIRS="app scripts tests"
SEARCH_FILES=""
for f in docs README.md INIT.md config; do
  [ -e "$f" ] && SEARCH_FILES="$SEARCH_FILES $f"
done

file_count=$(grep -rlE "$PATTERN" $SEARCH_DIRS $SEARCH_FILES 2>/dev/null | wc -l | tr -d ' ')
line_count=$(grep -rnE "$PATTERN" $SEARCH_DIRS $SEARCH_FILES 2>/dev/null | wc -l | tr -d ' ')

printf 'legacy_orm_files_remaining=%s\n' "$file_count"
printf 'legacy_orm_lines_remaining=%s\n' "$line_count"
printf 'legacy_orm_files_list_begin\n'
grep -rlE "$PATTERN" $SEARCH_DIRS $SEARCH_FILES 2>/dev/null | sort || true
printf 'legacy_orm_files_list_end\n'
