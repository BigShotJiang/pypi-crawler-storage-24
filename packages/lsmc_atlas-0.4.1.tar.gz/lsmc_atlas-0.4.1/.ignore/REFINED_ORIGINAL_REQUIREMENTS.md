LSMC Hub — Augment-ready implementation blueprint

(FastAPI + Jinja2 UI + Postgres + AWS Cognito; append-only; portal is not authoritative for report/data UIDs; styling inspired by lsmc.com)

1) Your clarifications incorporated (non‑negotiables)
1.1 “Hub” naming

System name: LSMC Hub.

1.2 UID authority boundaries

LSMC Hub IS authoritative for:

OrderID

ShipmentID (physical package UID)

TestKitID

ManifestID

ReleasePackageID (digital delivery package UID)

Internal audit/event IDs

LSMC Hub IS NOT authoritative for:

Report UID(s) and Data UID(s) produced by LIMS / downstream systems
(Hub stores them as external artifacts and tracks release packages that deliver them.)

1.3 Append-only / no delete

No DELETE anywhere for business objects.

Prefer no UPDATE for business objects; changes must be new revisions/events.

“Fixes” happen via reversal events (e.g., UNLINK after LINK), not deletion.

1.4 Identifier naming changes

BioSpecimenID (not “Specimen”)

TestKitID (not “KitID”)

PatientID (+ family relationships)

OrderID

Keep ManifestID (you like it; agreed)

1.5 Additional identity objects you called out

ClinicianID (NPI, specialty, addresses)

OrderingOrganizationID (+ Sites)

External IDs for patient/source, order, biospecimen, etc.

1.6 Status deltas

Order status: add Abandoned (draft timed out / never submitted).

BioSpecimen: add MIA, Active (Active = accepted/processing).

1.7 Complex containment + gaps

You want to model “things can be inside things,” with gaps and cross-patient mixing:

Shipment → 0..* (TestKits | BioSpecimens | Documents | Shipments)

TestKit → 0..* (BioSpecimens | Documents)

Any of the above can contain materials from multiple patients.

The system must still make it easy to “work back” from any received item to patient, clinician, organization, and order context.

2) Product model changes (Order → TestOrder → Assay, and specimen mapping)
2.1 Ordering structure

Order.product_orders = 1..* TestOrder

TestOrder.assays = 1..* AssayRef

AssayRef is a reference to the eventual “product specification owning system”

For now: assay_code, assay_name, assay_version, specimen_requirements_ref

2.2 Hard part: specimen ↔ test orders

A single TestKit can include:

Multiple BioSpecimens for the same patient/source

Multiple TestOrders (possibly across patients)

A BioSpecimen can be linked to:

Exactly one patient (eventually)

One or many TestOrders / assays (many-to-many)

Implementation requirement:
Model BioSpecimen ↔ TestOrder as append-only link events, not a single mutable foreign key.

3) Architecture (simple, durable, “build tonight”)
3.1 Stack

Backend: FastAPI (async), structured logging

UI: Jinja2 templates served from FastAPI

DB: PostgreSQL (Docker Compose local)

Auth: AWS Cognito (OIDC)

Storage: S3 (documents, reports, data pointers)

Optional: HTMX for “fast but not SPA” interactions (scan/match UI benefits massively)

3.2 System boundaries

Hub: ordering, logistics objects, matching UX, release packaging, client access + API

LIMS: specimen authority later, processing truth, report/data generation, detailed pipeline states

Integration: LIMS pushes events and artifacts into Hub (internal API), Hub exposes client API and UI.

4) Append-only data design (do this first)
4.1 “Identity + Revisions + Events” pattern

For each core entity:

Identity table (created once, immutable): {Entity} (…ID, tenant_id, created_at, created_by)

Revision table (append-only snapshots): {Entity}Revision (entity_id, revision_id, revision_no, created_at, created_by, payload_jsonb)

Event tables (append-only): status changes, link/unlink, tracking updates, etc.

No deletes.
No in-place updates to business meaning.
If you must store derived “current state” for speed, it must be rebuildable from revision/event streams.

4.2 “Current views” for performance

Create Postgres views for current snapshot of each entity:

Example pattern:

order_current_v = DISTINCT ON (order_id) … ORDER BY revision_no DESC

same for patient, clinician, shipment, biospecimen, testkit, manifest.

This keeps UI/API queries clean without violating append-only.

4.3 Database enforcement

Add DB triggers preventing DELETE on all identity/revision/event tables.

Strongly consider preventing UPDATE on revision/event tables as well.

5) Canonical identifiers (v1)
5.1 Hub IDs (UUIDv7 recommended; UUIDv4 acceptable)

OrderID

PatientID

ClinicianID

OrganizationID

SiteID

BioSpecimenID

TestKitID

ShipmentID

ManifestID

ReleasePackageID

DocumentID

ArtifactID (Hub record pointing to LIMS artifact UID; Hub not authoritative)

5.2 External IDs (per tenant)

Implement generic external ID mapping:

ExternalIdentifier(entity_type, entity_id, system_name, external_id, created_at)
Examples:

EHR MRN, biobank donor ID, collaborator sample ID, external order ID, etc.

6) Status model (order rollup + granular statuses)
6.1 BioSpecimenStatus (event-sourced)

Minimum:

EXPECTED (created during order entry)

RECEIVED (physical receipt logged)

MATCHED (linked to an order/test orders)

ACTIVE (accepted into workflow; often when LIMS acknowledges)

MIA (expected but not received by configured threshold)

ON_HOLD

REJECTED

6.2 TestOrderStatus (line-item level)

Minimum:

REQUESTED / SUBMITTED

SPECIMEN_PENDING

IN_PROCESS

ON_HOLD

COMPLETED

RELEASED

CANCELED / REJECTED

6.3 OrderStatus (rollup; also event-sourced for auditability)

OrderStatus should be derived but you may also emit explicit events when rollup changes.

Suggested states:

DRAFT

SUBMITTED

ABANDONED (auto after inactivity window)

RECEIVING_IN_PROGRESS (some expected items received, not all matched/accepted)

ON_HOLD (any blocking hold)

ACTIVE (processing started)

COMPLETED_REPORT_READY

RELEASED

AMENDED

CANCELED / REJECTED

6.4 Rollup algorithm (deterministic precedence)

Compute rollup in this order (highest precedence wins):

If order canceled → CANCELED

If rejected → REJECTED

If any TestOrder/BioSpecimen in ON_HOLD → ON_HOLD

If any report released and any amended → AMENDED else RELEASED

If all TestOrders completed but none released → COMPLETED_REPORT_READY

If any TestOrder in process OR any BioSpecimen ACTIVE → ACTIVE

If any shipment received or BioSpecimen received → RECEIVING_IN_PROGRESS

If submitted → SUBMITTED

If draft and aged out → ABANDONED else DRAFT

7) Containment + linking model (shipments, kits, biospecimens, documents, nested shipments)

This is the heart of your “gaps + inside things” requirement.

7.1 Generic containment events

Create one table to represent containment relationships and reversals:

ContainmentEvent

event_id

parent_type enum: SHIPMENT | TEST_KIT | SHIPMENT_PACKAGE | …

parent_id

child_type enum: SHIPMENT | TEST_KIT | BIOSPECIMEN | DOCUMENT | MANIFEST

child_id

action enum: ADD | REMOVE

quantity (optional; default 1)

created_at, created_by, note

Rules

No cycles allowed when child_type=SHIPMENT (enforce at app layer, optionally with DB constraint via recursive query check).

“Remove” does not delete; it appends a REMOVE event.

7.2 Matching/linking events

Similarly, linking BioSpecimens to Orders/TestOrders:

BioSpecimenOrderLinkEvent (LINK/UNLINK)

BioSpecimenTestOrderLinkEvent (LINK/UNLINK)

BioSpecimenPatientLinkEvent (LINK/UNLINK; often implied by match)

This makes corrections possible without mutation.

8) Reports/Data: Artifacts + Release Packages (you explicitly want re-release visibility)
8.1 Artifact (non-authoritative UID)

Artifact is Hub’s record of a LIMS-produced object.

artifact_id (Hub ID)

source_system (e.g., LIMS)

source_uid (authoritative UID from LIMS)

artifact_type: CLINICAL_REPORT_PDF | RESULTS_JSON | FASTQ | BAM | VCF | OTHER

checksum_sha256 (required for “same data released again” tracking)

storage_uri (S3 URL or opaque pointer)

created_at

8.2 ReleasePackage (authoritative in Hub)

Represents one delivery event (UI download package, API delivery batch, redelivery, etc.)

ReleasePackageID

created_at, created_by

release_reason (initial release, redelivery, amendment, customer request)

released_to (org/site/user/api-client)

Items: ReleasePackageItem append-only ADD/REMOVE events (or simple append-only rows if you never remove items)

Re-release detection

A report/data is “same” if checksum_sha256 matches (or same source_uid).

Hub UI should show “Previously released on … (n times)” per artifact.

9) UI styling guidance (match lsmc.com)

From lsmc.com, the visual language is:

Monochrome/industrial imagery and backgrounds (grid/automation photography)

Large, confident headings, minimal ornamentation

Clean spacing, high contrast, simple nav

9.1 Design tokens (implement as CSS variables)

--bg: #0b0b0c

--panel: #121214

--text: #f3f3f3

--muted: #b7b7b7

--border: #2a2a2e

--focus: #ffffff (high-contrast focus ring)

Accent color: keep extremely restrained (optional: a single cool-gray/steel)

9.2 Layout

App shell: left nav (collapsed icons) + main panel

Order/Intake screens: “dense but calm” tables, minimal color, rely on typography and spacing

Status pills: grayscale with subtle border; only use color for critical holds/errors if needed.

10) LSMC Hub web pages (v1 “comprehensive first attempt”)
External (Clients)

Dashboard: counts by status, holds, recently released

Orders

List/search

Create Order (wizard)

Order detail (timeline, test orders, biospecimens, documents, shipments, releases)

Patients

Patient search + detail

Family relationships editor (append-only relationship events)

Clinicians

Directory/search, clinician profile revisions

Shipments

Create shipment (with tracking)

Shipment detail (containment tree, manifest, receipt status)

Test Kits

Inventory + request resupply (optional now)

Results / Releases

Released artifacts list

Release package detail + download

API Access

Create API client, rotate keys, webhook config

Support

Create ticket, view tickets

Internal (LSMC Staff)

Receiving

Log package receipt (ShipmentID creation if needed)

Scan & Match (core)

Scan BioSpecimenID / ShipmentID / OrderID / TestKitID

Auto-match or candidate list

LINK/UNLINK events

Exception Queue

Reasons: missing identifiers, ambiguous match, mismatch, missing data

Paper intake order entry (exception path)

Release admin (high-level)

View artifacts, create release packages, audit

Admin

Tenant/org management

Test catalog (assay refs)

RBAC / user management

Audit viewer

11) API surface (v1)
11.1 External client API (JWT from Cognito)

GET /api/orders?status=&q=&date_from=&date_to=

POST /api/orders (creates identity + first revision)

POST /api/orders/{order_id}/revisions

GET /api/orders/{order_id}

GET /api/orders/{order_id}/timeline

POST /api/shipments

GET /api/shipments/{shipment_id}

POST /api/manifests (upload)

GET /api/releases / GET /api/releases/{release_package_id}

GET /api/artifacts/{artifact_id}/download (signed URL)

11.2 Internal integration API (LIMS → Hub)

Use separate auth (mTLS or internal API key + IP allowlist).

POST /internal/events (status events, matching acknowledgements)

POST /internal/artifacts (register report/data artifacts)

POST /internal/orders/{order_id}/status (optional explicit)

POST /internal/biospecimens/{biospecimen_id}/status

11.3 Webhooks (Hub → client)

order.status.changed

order.estimated_tat.changed

artifact.available

release.package.created

exception.created

12) Repo structure (single service, simple)
lsmc-hub/
  app/
    main.py
    settings.py
    logging.py

    auth/
      cognito.py
      dependencies.py
      rbac.py

    db/
      engine.py
      migrations/          # alembic
      models/              # identity/revision/event models
      views.sql            # create *_current_v views

    domain/
      services/
        orders.py
        shipments.py
        matching.py
        releases.py
      policies/
        rollups.py
        validations.py

    api/
      routes/
        orders.py
        patients.py
        clinicians.py
        shipments.py
        manifests.py
        releases.py
        webhooks.py
        internal.py

    web/
      routes/
        pages.py            # Jinja page handlers
      templates/
        base.html
        dashboard.html
        orders/
        intake/
        shipments/
        ...
      static/
        css/
          theme.css
        img/
          hero-grid.jpg     # optional local copy
        js/
          htmx.min.js       # optional
  scripts/
    seed_dev_data.py
  docker-compose.yml
  Dockerfile
  Makefile
  requirements.txt
  requirements-dev.txt
  .augment/
    rules/
    code_review_guidelines.yaml
  AGENTS.md
  README.md

13) AWS Cognito setup (minimal but correct)

Create:

User Pool (email sign-in)

App client (OIDC Authorization Code flow)

Hosted UI domain (for login)

Callback URLs:

http://localhost:8000/auth/callback

staging/prod URLs later

Logout URLs similarly

User Pool Groups mapped to Hub roles (e.g., client_admin, client_user, lsmc_intake, lsmc_admin)

Hub requirements:

UI sessions: store tokens server-side (signed cookie session) or store only session id and keep tokens in server cache (recommended).

API: validate JWT using JWKs.

14) Augment integration (rules + review guidelines)

Augment Rules live in .augment/rules/ and support always_apply and agent_requested types with YAML frontmatter.
Augment Code Review can be guided via .augment/code_review_guidelines.yaml.

14.1 Create these rule files (copy/paste verbatim)
.augment/rules/00-project-context.md
---
type: always_apply
---

# LSMC Hub — Project Context

LSMC Hub is a CLIA/CAP/NYS-facing client + internal web portal for clinical sequencing logistics:
- External users place digital Orders and create Shipments/Manifests.
- Internal users receive packages and scan/match BioSpecimens to Orders.
- Hub is authoritative for OrderID, ShipmentID, TestKitID, BioSpecimenID (for now), ManifestID, ReleasePackageID.
- Hub is NOT authoritative for report/data UIDs; it stores LIMS artifacts and tracks ReleasePackages that deliver them.

Non-negotiables:
- Append-only. No DELETE for business entities. Prefer no UPDATE; use revisions and events.
- Corrections are reversal events (UNLINK, REMOVE), never destructive edits.
- Multi-tenant. Strong tenant isolation.
- Full audit trail for all PHI-affecting actions.

.augment/rules/01-architecture.md
---
type: always_apply
---

# Architecture Rules

- Stack: FastAPI + Jinja2 templates + Postgres + AWS Cognito OIDC.
- Keep UI server-rendered; minimal JS. HTMX is allowed for dynamic interactions (scan/match).
- Separate modules: auth/, db/, domain/services/, api/routes/, web/routes+templates/.
- Use Postgres views for *_current_v snapshots from append-only revision tables.
- Implement internal ingestion endpoints for LIMS events/artifacts with separate auth.

.augment/rules/02-data-model-append-only.md
---
type: always_apply
---

# Append-only Data Modeling

For core entities: Identity table + Revision table + Event tables.

Rules:
- Never delete rows in identity/revision/event tables.
- Avoid UPDATE on revision/event tables.
- Any “edit” creates a new revision row (revision_no increments).
- Any “unlink/remove” is an appended event with action=REMOVE/UNLINK.
- Provide Postgres views for current snapshots:
  - order_current_v, patient_current_v, clinician_current_v, shipment_current_v, biospecimen_current_v, testkit_current_v, manifest_current_v.
- Add DB triggers to reject DELETE statements on these tables.

.augment/rules/03-security-phi.md
---
type: always_apply
---

# Security / PHI Rules

- Do not log PHI/PII in plaintext logs.
- Audit log all actions that view/download reports/data or change linkages/matching.
- Enforce tenant isolation in every query.
- CSRF protection for browser POSTs (if using cookies).
- Strong session cookie settings: HttpOnly, Secure in prod, SameSite=Lax/Strict.
- Validate Cognito JWTs; verify issuer/audience; cache JWKs.

.augment/rules/04-python-quality.md
---
type: always_apply
---

# Python Quality Rules

- Python 3.11+
- Use ruff for linting and formatting.
- Use mypy for type checking where practical.
- Use pytest for tests.
- Prefer pydantic models for request/response schemas.
- Write small, testable domain services; keep route handlers thin.

.augment/rules/10-ui-style-lsmc.md
---
type: agent_requested
description: "UI look/feel inspired by lsmc.com: monochrome industrial, high-contrast, minimal."
---

# UI Style (LSMC-inspired)

- Dark background, light text, restrained borders and status pills.
- Large headings, generous spacing, minimal ornamentation.
- Tables are dense but readable; avoid bright colors.
- Use CSS variables for theme tokens and consistent spacing scale.
- Keep navigation simple: Dashboard, Orders, Shipments, Results, Support, Admin.

.augment/rules/11-api-conventions.md
---
type: agent_requested
description: "API design conventions for LSMC Hub (external + internal + webhooks)."
---

# API Conventions

- External API is tenant-scoped and requires Cognito JWT.
- Internal API uses separate auth and is never exposed publicly.
- IDs are UUIDs returned as strings.
- Every create/edit returns the new revision and audit event id.
- Prefer event-sourced endpoints for status/link changes.

14.2 Code review guidelines (optional but valuable)

Create .augment/code_review_guidelines.yaml:

areas:
  security:
    description: "Security & PHI handling"
    globs: ["app/**"]
    rules:
      - id: "no_phi_in_logs"
        description: "Do not log PHI/PII in app logs or exception traces."
        severity: "high"
      - id: "tenant_isolation"
        description: "Every DB query must be tenant-scoped unless explicitly internal/admin with audit."
        severity: "high"

  data_integrity:
    description: "Append-only and auditability"
    globs: ["app/db/**", "app/domain/**"]
    rules:
      - id: "no_deletes"
        description: "Do not add DELETE operations for business entities; use reversal events."
        severity: "high"
      - id: "revision_instead_of_update"
        description: "Edits must create new revisions; avoid mutating prior rows."
        severity: "high"

14.3 Root AGENTS.md (helps other tooling too)

Augment supports hierarchical discovery via AGENTS.md and CLAUDE.md.
Create AGENTS.md at repo root with a short restatement of the core rules (or reference the .augment/rules set).

15) The Augment build plan (task list + prompts)

Below is a sequenced plan you can paste into Augment Agent as a “thread task list”. The key is to get data model + auth + shell UI working early, then add modules.

Phase 0 — scaffold

Prompt to Augment Agent

Scaffold a FastAPI + Jinja2 project per the repo tree. Add docker-compose Postgres, Alembic, ruff/mypy/pytest, and a Makefile. Create .augment/rules files exactly as specified. No business logic yet—just app boot, health endpoint, base template, and static CSS.

Acceptance:

make dev runs Hub on localhost

GET /health returns ok

Base template renders with theme.css

Phase 1 — DB + append-only primitives

Prompt

Implement identity + revision + event base patterns in SQLAlchemy. Add migrations and create Postgres views for current snapshots. Add DB triggers preventing DELETE on business tables. Provide helper functions: create_identity(), add_revision(), append_event(), get_current_snapshot().

Acceptance:

Can create and list Organizations via direct script

Views *_current_v exist

Phase 2 — Cognito auth + RBAC + tenant isolation

Prompt

Add AWS Cognito OIDC login for browser UI and JWT validation for API. Implement RBAC roles and tenant scoping dependency. Add a “Who am I” page showing tenant + roles. Never log tokens.

Acceptance:

Login works with Cognito Hosted UI

API rejects unauthenticated requests

Tenant scoping enforced

Phase 3 — Core entities: Org/Site/Clinician/Patient

Prompt

Implement CRUD as append-only revisions for Organization, Site, Clinician, Patient, and PatientRelationship. Build basic UI pages (list/detail/create) and API endpoints.

Acceptance:

Create patient, link family relationship via event, view history

Phase 4 — Orders + TestOrders + AssayRef

Prompt

Implement Order identity+revisions, TestOrder identity+revisions, and AssayRef lookup table. Build Create Order wizard UI, Order detail UI, and API endpoints. Include Abandoned logic (background job or computed). Implement status rollup function per spec.

Acceptance:

Submit order with multiple TestOrders and patient/clinician/org references

Order rollup computed correctly

Phase 5 — Shipments, TestKits, BioSpecimens, Documents, Manifests

Prompt

Implement Shipment, TestKit, BioSpecimen, Document, Manifest entities with containment events (ADD/REMOVE) and link events. Support nested shipments. Create shipment UI (create/detail) with tracking events. Create manifest upload and validation stub.

Acceptance:

Shipment can contain kits and biospecimens

REMOVE events work without deletes

Phase 6 — Internal intake Scan & Match + Exception Queue

Prompt

Build internal “Scan & Match” page optimized for barcode wedge scanners. Implement matching by direct ID, then fallback to candidate search (simple fuzzy stub). Add exception queue objects and flows. All actions append audit + link events.

Acceptance:

Scan BioSpecimenID → link to Order/TestOrders

Unlink creates UNLINK event

Ambiguous match routes to exception queue

Phase 7 — Artifacts + Release Packages + Results UI

Prompt

Implement Artifact registration (internal API) and ReleasePackage creation (staff UI). Allow same artifact to be released multiple times; show prior release count based on checksum/source_uid. Add client Results list and download via signed URL stub.

Acceptance:

Internal can register artifact

Staff can create ReleasePackage

Client can see and download released report

Phase 8 — Client API + Webhooks

Prompt

Implement API clients, scoped API keys (or OAuth client creds), and webhook subscriptions. Emit webhook events for order status change and release package creation. Add delivery logs with retries.

Acceptance:

Client system can receive webhook for release

Delivery attempts are logged append-only

16) “Link out” to analysis UI (daylily)

Add a nav item Analysis Workspace:

Reads ANALYSIS_UI_URL env var

Opens in new tab

If SSO later: keep placeholder for signed redirect.

17) Minimal local dev commands (Mac + Ubuntu)

Makefile targets

make venv

make install

make db (starts docker compose)

make migrate

make seed

make dev (uvicorn reload)

make test

docker-compose

postgres + volume

optional pgadmin

If you want one “mega prompt” to paste into Augment Agent

Tell me and I’ll condense Phase 0–8 into a single instruction block with explicit file-by-file outputs (still append-only and Cognito-based), but I’d personally run it as phases to keep diffs reviewable.

Next best step from here: I can produce the exact DB schema (tables + columns + indexes) for v1 using the identity/revision/event pattern above (so Augment can generate Alembic migrations cleanly on the first pass).