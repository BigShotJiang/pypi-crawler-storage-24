---
type: agent_requested
description: "API design conventions for LSMC Atlas (external + internal + webhooks)."
---

# API Conventions

## Contract Design Philosophy: Routes as Contract (Option B)

LSMC Atlas follows a **routes-as-contract** design pattern:

1. **Route handlers define the canonical API** — Request/response Pydantic schemas in route files are the source of truth
2. **Service layer adapts to routes** — Services implement what routes need, not vice versa
3. **API stability over internal flexibility** — External contracts change rarely; internal implementation can evolve

### Practical Guidelines

- When adding a feature, define the route/schema FIRST, then implement the service
- If a service method signature doesn't match what the route needs, modify the SERVICE
- Never change a route's public contract to accommodate service internals
- Use DTOs in routes; services can use different internal representations

### Example Pattern

```python
# Route defines the contract (source of truth)
@router.post("/orders")
async def create_order(
    data: OrderCreateRequest,  # Request schema defined here
    current_user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> OrderCreateResponse:  # Response schema defined here
    svc = OrderService(db, current_user.tenant_id)
    order, revision = svc.create(
        OrderCreate(  # Adapt to service's internal DTO
            patient_id=data.patient_id,
            clinician_id=data.clinician_id,
            ...
        ),
        created_by=current_user.user_id,
    )
    return OrderCreateResponse.from_domain(order, revision)
```

## General API Conventions

- External API is tenant-scoped and requires Cognito JWT (or dev auth in development)
- Internal API uses separate auth (API key) and is never exposed publicly
- IDs are UUIDs returned as strings
- Every create/edit returns the new revision and `audit_event_id`
- Prefer event-sourced endpoints for status/link changes
- Webhooks must be signed; include idempotency keys

## Endpoint Patterns

### External API (`/api/v1/`)

- `GET /orders` — List orders for tenant
- `GET /orders/{id}` — Get single order with latest revision
- `POST /orders` — Create new order (returns order + revision)
- `PATCH /orders/{id}` — Update order (creates new revision)
- `GET /shipments` — List shipments for tenant
- `GET /releases` — List release packages

### Internal API (`/api/v1/internal/`)

- `POST /internal/intake/match` — Match biospecimen to order
- `POST /internal/artifacts` — Push artifact from LIMS
- `POST /internal/status-events` — Push status change from LIMS

### Webhook Events

All webhook events include:
- `event_type` — e.g., `order.created`, `order.status.changed`
- `event_id` — UUID for idempotency
- `timestamp` — ISO8601 timestamp
- `data` — Event-specific payload

Signature: `X-Webhook-Signature: sha256={hmac_signature}`
