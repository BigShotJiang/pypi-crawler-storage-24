---
type: always_apply
---

# Cross-System API Boundary

Non-negotiable integration rule:

- Bloom may only be interacted with via Bloom HTTP APIs.
- Atlas may only be interacted with via Atlas HTTP APIs.

Required behavior:

- Do not perform cross-system direct database reads/writes.
- Do not call cross-system internal service functions or import internal modules as an integration path.
- Do not rely on cross-system local filesystem state as an integration contract.

Enforcement guidance:

- For Bloom integration from Atlas, use documented Bloom endpoints only.
- For Atlas integration from Bloom (or other systems), use documented Atlas endpoints only.
- Treat any direct DB or internal-code coupling across systems as a policy violation.
