---
type: always_apply
---

# Security / PHI Rules

- Do not log PHI/PII in plaintext logs.
- Audit log all actions that:
  - view or download reports/data
  - create/edit orders
  - link/unlink/match biospecimens
  - change billing/insurance fields
  - change permissions, roles, tenants
- Enforce tenant isolation in every query (external users must never cross tenants).
- Implement CSRF protection for browser POSTs when using cookies.
- Session cookie settings (prod): HttpOnly, Secure, SameSite=Lax (or Strict).
- Validate Cognito JWTs (issuer, audience) and cache JWKs.
- Rate-limit auth and download endpoints.
