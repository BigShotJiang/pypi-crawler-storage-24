---
type: always_apply
---

# Architecture Rules

Stack (simple, durable):
- Backend: FastAPI (Python 3.11+).
- UI: Server-rendered Jinja2 templates served by FastAPI.
- DB: PostgreSQL.
- Auth: AWS Cognito (OIDC).
- File storage: S3 (documents, artifact pointers, release packages).

Interaction style:
- Keep the UI server-rendered. Use minimal JavaScript.
- HTMX is allowed (recommended) for high-throughput flows like Scan & Match.

System boundaries:
- Atlas owns ordering/logistics/matching UX + client API.
- LIMS owns authoritative biospecimen tracking eventually, processing truth, and generating reports/data artifacts.
- LIMS pushes events/artifacts into Atlas through internal endpoints with separate auth.

Local dev:
- This project uses **conda** for environment management.
- Prefer running **Postgres from conda** (not Docker) using a repo script like `./install_pg.sh` (initdb + pg_ctl on a dedicated port and PGDATA under the repo).

Code organization:
- Keep route handlers thin; put business logic in domain/services.
- Use Postgres views *_current_v to query latest revision snapshots.
