"""OpenClaw adapter."""
