"""CLI commands for neoskills."""
