"""CRUD operations for the restaurants table."""

from typing import Optional

from sqlalchemy import func
from sqlalchemy.orm import selectinload
from sqlmodel import select

from viper_db.models.experience import Experience
from viper_db.models.restaurant import Restaurant
from viper_db.utils.db import get_session


class RestaurantsDAO:
    @property
    def session(self):
        return get_session()

    async def upsert(self, data) -> Restaurant:
        existing = await self.session.get(Restaurant, data.experience_id)
        if existing:
            for key, val in data.model_dump(exclude_unset=True).items():
                setattr(existing, key, val)
            await self.session.commit()
            await self.session.refresh(existing)
            return existing

        restaurant = Restaurant(**data.model_dump())
        self.session.add(restaurant)
        await self.session.commit()
        await self.session.refresh(restaurant)
        return restaurant

    async def get_by_id(self, experience_id: int) -> Optional[Restaurant]:
        return await self.session.get(Restaurant, experience_id)

    async def get_all(self) -> list[Restaurant]:
        result = await self.session.execute(select(Restaurant))
        return list(result.scalars().all())

    async def get_active_resy_roster(self) -> list[dict]:
        """Return (experience_id, resy_venue_id, resy_name)
        for active restaurants with Resy IDs."""
        result = await self.session.execute(
            select(
                Restaurant.experience_id,
                Restaurant.resy_venue_id,
                Restaurant.resy_name,
            )
            .join(Experience, Experience.id == Restaurant.experience_id)
            .where(
                Restaurant.resy_venue_id.is_not(None),
                Experience.is_active == True,  # noqa: E712
            )
        )
        return [
            {
                "experience_id": row[0],
                "resy_venue_id": row[1],
                "resy_name": row[2],
            }
            for row in result.fetchall()
        ]

    async def get_paginated(
        self, page: int = 1, page_size: int = 20
    ) -> tuple[list[Restaurant], int]:
        count_result = await self.session.execute(
            select(func.count()).select_from(Restaurant)
        )
        total = count_result.scalar_one()

        offset = (page - 1) * page_size
        result = await self.session.execute(
            select(Restaurant)
            .join(Experience, Restaurant.experience_id == Experience.id)
            .options(
                selectinload(Restaurant.experience).selectinload(Experience.neighborhood)
            )
            .order_by(Experience.name.asc(), Restaurant.experience_id.asc())
            .offset(offset)
            .limit(page_size)
        )
        return list(result.scalars().all()), total


restaurants_dao = RestaurantsDAO()
