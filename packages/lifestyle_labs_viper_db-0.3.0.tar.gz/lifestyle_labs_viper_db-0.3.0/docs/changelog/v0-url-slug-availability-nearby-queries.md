# Changelog v0

## 2026-03-22 — Add url_slug to availability search and nearby queries

### Problem

The `get_experiences_available_on_date` DAO method already JOINed the `restaurants` table but only selected `r.cuisine`. The `url_slug` column (needed for building Resy booking URLs) was not included, forcing the agent to either guess the slug or use `experience_id` in URLs — which produces broken links.

Similarly, `get_nearby_candidates` returned `resy_venue_id` and `resy_name` from the restaurant record but omitted `url_slug`.

### Changes

**dao/availability_slots.py**

- Added `r.url_slug` to the SELECT clause in `get_experiences_available_on_date`.
- Added `r.url_slug` to the GROUP BY clause.
- Included `url_slug` in the returned dict for each row.

**dao/experiences.py**

- Added `url_slug` to the dict returned by `get_nearby_candidates`, sourced from `restaurant.url_slug`.
