from synmax.vulcan.v2.vulcan_client import VulcanApiClient
import json

VulcanApiClient._write_stub()
# access_token = os.environ.get("ACCESS_TOKEN")

claims_dict = {
    "claims": [
        {"claim_name": "vulcan_datacenters", "claim_json": {"name": "vulcan_datacenters", "type": "api", "filters": {}}},
        {"claim_name": "vulcan_underconstruction", "claim_json": {"name": "vulcan_underconstruction", "type": "api", "filters": {}}},
        {"claim_name": "vulcan_lng_projects", "claim_json": {"name": "vulcan_lng_projects", "type": "api", "filters": {}}},
        {"claim_name": "vulcan_metadata_history", "claim_json": {"name": "vulcan_metadata_history", "type": "api", "filters": {}}},
        {"claim_name": "vulcan_project_rankings", "claim_json": {"name": "vulcan_project_rankings", "type": "api", "filters": {}}},
        {"claim_name": "vulcan_iir_data", "claim_json": {"name": "vulcan_iir_data", "type": "api", "filters": {}}},
        {"claim_name": "vulcan_infrastructure_watch_extended", "claim_json": {"name": "vulcan_infrastructure_watch_extended", "type": "api", "filters": {}}},
    ]
}

client = VulcanApiClient(access_token='eyJwcm9qZWN0X2lkIjogIlN5bm1heCBjb21tZXJjaWFsIEFQSSIsICJwcml2YXRlX2tleSI6ICIwQndzX0ExMFpkdVQyaWlNLS1lbXh3Mk5BNUkxa09kdFNVai04RjVvNzU4IiwgImNsaWVudF9pZCI6ICJGZWxpeCBLZXkiLCAidHlwZSI6ICJvbmVfeWVhcl9saWNlbnNlZF9jdXN0b21lciIsICJzdGFydF9kYXRlIjogIjAzLzE5LzIwMjQiLCAiZW5kX2RhdGUiOiAiMDMvMTkvMjAyNSIsICJ0cmlhbF9saWNlbnNlIjogZmFsc2UsICJpc3N1ZV9kYXRldGltZSI6ICIxOS0wMy0yMDI0IDE0OjI0OjA4IiwgImFkbWluX3VzZXIiOiBmYWxzZSwgInVzZXJfcm9sZXMiOiBbImh5cGVyaW9uIiwgInZ1bGNhbiJdfQ==')


payload = {}

got = client.infrastructure_watch_extended()
df = got.df()
print(df)

print(got)