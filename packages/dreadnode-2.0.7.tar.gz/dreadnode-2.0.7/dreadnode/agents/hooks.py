"""Core agent hooks: backoff, metrics, and summarization.

These hooks are included by default in every agent created by the server.
"""

import asyncio
import contextlib
import random
import time
import typing as t
from dataclasses import dataclass

from loguru import logger

from dreadnode.agents.events import (
    AgentError,
    AgentEvent,
    AgentStep,
    ToolEnd,
    ToolStart,
)
from dreadnode.agents.reactions import Reaction, Retry
from dreadnode.core.hook import Hook, hook
from dreadnode.generators.chat import Chat
from dreadnode.generators.generator import Generator
from dreadnode.generators.message import Message, make_compaction_message

if t.TYPE_CHECKING:
    from datetime import datetime


# =============================================================================
# Backoff
# =============================================================================


def _make_backoff_hook(
    exception_types: tuple[type[Exception], ...],
    *,
    max_tries: int = 8,
    max_time: float = 300.0,
    base_factor: float = 1.0,
    jitter: bool = True,
):
    """Create a backoff hook for specific exception types."""
    tries = 0
    start_time: float | None = None
    last_step_seen = -1

    @hook(AgentEvent)
    async def backoff_hook(event: AgentEvent) -> Reaction | None:
        nonlocal tries, start_time, last_step_seen

        if isinstance(event, AgentStep):
            if event.step > last_step_seen:
                tries = 0
                start_time = None
                last_step_seen = event.step
            return None

        if not isinstance(event, AgentError) or not isinstance(event.error, exception_types):
            return None

        if start_time is None:
            start_time = time.monotonic()

        if tries >= max_tries:
            logger.warning(f"Backoff aborted: max tries ({max_tries}) exceeded.")
            return None

        if (time.monotonic() - start_time) >= max_time:
            logger.warning(f"Backoff aborted: max time ({max_time:.2f}s) exceeded.")
            return None

        tries += 1
        seconds = base_factor * (2 ** (tries - 1))
        if jitter:
            seconds += random.uniform(0, base_factor)

        logger.warning(f"Backing off {seconds:.2f}s (try {tries}/{max_tries})")
        await asyncio.sleep(seconds)
        return Retry()

    return backoff_hook


# Pre-instantiated for common LLM rate limit errors
backoff_on_ratelimit: Hook | None = None
try:
    import litellm.exceptions

    backoff_on_ratelimit = _make_backoff_hook(
        (litellm.exceptions.RateLimitError, litellm.exceptions.APIError),
    )
except ImportError:
    pass


# =============================================================================
# Tool Metrics
# =============================================================================


def tool_metrics(*, detailed: bool = False) -> Hook:
    """
    Creates an agent hook to log metrics about tool usage, execution time, and success rates.

    Args:
        detailed: If True, logs metrics for each specific tool in addition to general stats.
                  If False, only logs aggregate statistics across all tools.

    Returns:
        A Hook instance that can be registered with an agent.
    """
    _start_times: dict[str, datetime] = {}

    @hook(AgentEvent)
    async def tool_metrics(event: AgentEvent) -> None:
        from dreadnode import log_metric

        if isinstance(event, ToolStart):
            log_metric("tool/total_count", 1)
            _start_times[event.tool_call.id] = event.timestamp

            if detailed:
                tool_name = event.tool_call.name
                log_metric(f"tool/count.{tool_name}", 1)

        elif isinstance(event, ToolEnd):
            tool_name = event.tool_call.name
            start_time = _start_times.pop(event.tool_call.id, event.timestamp)
            duration_seconds = (event.timestamp - start_time).total_seconds()

            log_metric("tool/total_time", duration_seconds)
            log_metric("tool/success_rate", 1)

            if detailed:
                log_metric(f"tool/time.{tool_name}", duration_seconds)
                log_metric(f"tool/avg_time.{tool_name}", duration_seconds)
                log_metric(f"tool/success_rate.{tool_name}", 1)

    return tool_metrics


# =============================================================================
# Summarization
# =============================================================================

CONTEXT_LENGTH_ERROR_PATTERNS = [
    "context_length_exceeded",
    "context window",
    "token limit",
    "maximum context length",
    "is too long",
]


@dataclass
class Summary:
    analysis: str
    summary: str
    chat: Chat


async def summarize_conversation(conversation: str, *, guidance: str = "") -> Summary:  # type: ignore[empty-body]
    """
    Your task is to create a detailed summary of the conversation so far, paying close attention to the user's explicit requests and your previous actions.
    This summary should be thorough in capturing technical details, code patterns, and architectural decisions that would be essential for continuing development work without losing context.

    Before providing your final summary, wrap your analysis in <analysis> tags to organize your thoughts and ensure you've covered all necessary points. In your analysis process:

    1. Chronologically analyze each message and section of the conversation. For each section thoroughly identify:
    - The user's explicit requests and intents
    - Your approach to addressing the user's requests
    - Key decisions, technical concepts and code patterns
    - Specific technical details like paths, usernames, structured objects, and code
    - Tool interactions performed with a specific focus on intent and outcome
    - Errors that you ran into and how you fixed them
    - Pay special attention to specific user feedback that you received, especially if the user told you to do something differently.

    2. Double-check for technical accuracy and completeness, addressing each required element thoroughly.

    Your summary should include the following sections:

    1. Primary Request and Intent: Capture all of the user's explicit requests and intents in detail
    2. Key Technical Concepts: List all important technical concepts, technologies, and frameworks discussed.
    3. Files and Code Sections: Enumerate specific files and code sections examined, modified, or created. Pay special attention to the most recent messages and include full code snippets where applicable and include a summary of why this file read or edit is important.
    4. Errors and fixes: List all errors that you ran into, and how you fixed them. Pay special attention to specific user feedback that you received, especially if the user told you to do something differently.
    5. Problem Solving: Document problems solved and any ongoing troubleshooting efforts.
    6. All user messages: List ALL user messages that are not tool results. These are critical for understanding the users' feedback and changing intent.
    7. Pending Tasks: Outline any pending tasks that you have explicitly been asked to work on.
    8. Current Work: Describe in detail precisely what was being worked on immediately before this summary request, paying special attention to the most recent messages from both user and assistant. Include file names and code snippets where applicable.
    9. Optional Next Step: List the next step that you will take that is related to the most recent work you were doing. IMPORTANT: ensure that this step is DIRECTLY in line with the user's explicit requests, and the task you were working on immediately before this summary request. If your last task was concluded, then only list next steps if they are explicitly in line with the users request. Do not start on tangential requests without confirming with the user first.
    If there is a next step, include direct quotes from the most recent conversation showing exactly what task you were working on and where you left off. This should be verbatim to ensure there's no drift in task interpretation.

    Here's an example of how your output should be structured:

    <example>
    <analysis>
    [Your thought process, ensuring all points are covered thoroughly and accurately]
    </analysis>

    <summary>
    1. Primary Request and Intent:
    [Detailed description]

    2. Key Technical Details:

    - [Concept 1]
    - [Concept 2]
    - [Object 1]
    - [...]

    3. Tool Interactions:

    - [Tool Call 1]: [Description of what the tool did, inputs, outputs]
    - [Tool Call 2]: ...
    - [...]

    4. Errors and fixes:

    - [Detailed description of error 1]:
        - [How you fixed the error]
        - [User feedback on the error if any]
    - [...]

    5. Problem Solving:
    [Description of solved problems and ongoing troubleshooting]

    6. All user messages:

    - [Detailed non tool use user message]
    - [...]

    7. Pending Tasks:

    - [Task 1]
    - [Task 2]
    - [...]

    8. Current Work:
    [Precise description of current work]

    9. Optional Next Step:
    [Optional Next step to take]

    </summary>
    </example>

    Please provide your summary based on the conversation so far, following this structure and ensuring precision and thoroughness in your response.

    There may be additional summarization guidance provided. If so, remember to follow these instructions when creating the above summary.
    """


def _is_context_length_error(error: BaseException) -> bool:
    """Checks if an exception is likely due to exceeding the context window."""
    with contextlib.suppress(ImportError):
        from litellm.exceptions import ContextWindowExceededError

        if isinstance(error, ContextWindowExceededError):
            return True

    error_str = str(error).lower()
    return any(pattern in error_str for pattern in CONTEXT_LENGTH_ERROR_PATTERNS)


def find_summarization_boundary(
    messages: list[Message],
    min_messages_to_keep: int = 10,
) -> int:
    """Find a clean message boundary for summarization.

    Walks messages from the start and finds the latest safe split point that
    leaves at least ``min_messages_to_keep`` messages in the "keep" portion.
    Safe boundaries are after a simple assistant message (no tool calls) or
    after the last tool result in a consecutive tool-result sequence.

    Returns:
        Index splitting ``messages[:boundary]`` (to summarize) from
        ``messages[boundary:]`` (to keep).  Returns ``0`` when no valid
        boundary exists.
    """
    best_boundary = 0
    for i, message in enumerate(messages):
        if len(messages) - i <= min_messages_to_keep:
            break
        is_simple_assistant = message.role == "assistant" and not getattr(
            message, "tool_calls", None
        )
        is_last_tool = message.role == "tool" and (
            i + 1 == len(messages) or messages[i + 1].role != "tool"
        )
        if is_simple_assistant or is_last_tool:
            best_boundary = i + 1
    return best_boundary


def _get_model_context_budget(model_or_generator: "str | Generator | None") -> int:
    """Usable token budget for automatic compaction threshold.

    Returns 75% of the model's max input tokens when known via LiteLLM
    metadata, otherwise a conservative 100_000 fallback.
    """
    model_str = model_or_generator
    if hasattr(model_or_generator, "model"):
        model_str = model_or_generator.model
    if not isinstance(model_str, str):
        return 100_000
    try:
        import litellm

        lookup = model_str
        while lookup not in litellm.model_cost:
            if "/" not in lookup:
                break
            lookup = "/".join(lookup.split("/")[1:])
        if lookup in litellm.model_cost:
            info = litellm.model_cost[lookup]
            max_input = info.get("max_input_tokens") or info.get("max_tokens", 0)
            if max_input and max_input > 0:
                return int(max_input * 0.75)
    except Exception:  # noqa: S110 - best-effort model metadata fallback should stay quiet
        pass
    return 100_000


def _make_summarize_hook(
    model: str | Generator | None = None,
    max_tokens: int = 100_000,
    min_messages_to_keep: int = 10,
    guidance: str = "",
) -> "Hook":
    """Create a hook that auto-summarizes when context gets too long."""
    if min_messages_to_keep < 2:
        raise ValueError("min_messages_to_keep must be at least 2.")

    @hook(AgentEvent)  # Decorator on the INNER function, not the factory
    async def _summarize_hook(event: AgentEvent) -> Reaction | None:
        # Threshold compaction only — overflow recovery is agent-owned
        # (handled by Agent._try_overflow_recovery at the error site).
        if not isinstance(event, AgentStep):
            return None

        budget = _get_model_context_budget(event.generator) if event.generator else max_tokens
        if event.usage.total_tokens <= 0 or event.usage.total_tokens <= budget:
            return None

        summarizer_model = model or event.generator
        if summarizer_model is None:
            return None

        event_messages = getattr(event, "messages", None)
        if not event_messages:
            return None

        messages = list(event_messages)
        if len(messages) <= min_messages_to_keep:
            return None

        system_message: Message | None = (
            messages.pop(0) if messages and messages[0].role == "system" else None
        )

        best_boundary = find_summarization_boundary(messages, min_messages_to_keep)
        if best_boundary == 0:
            return None

        to_summarize = messages[:best_boundary]
        to_keep = messages[best_boundary:]
        if not to_summarize:
            return None

        summary = await summarize_conversation.bind(summarizer_model)(  # ty: ignore[unresolved-attribute]  # .bind() added by generator framework at runtime
            "\n".join(str(msg) for msg in to_summarize),
            guidance=guidance,
        )

        new_messages: list[Message] = []
        if system_message:
            new_messages.append(system_message)
        new_messages.append(
            make_compaction_message(
                summary.summary,
                messages_compacted=len(to_summarize),
                trigger="threshold",
            )
        )
        new_messages.extend(to_keep)

        # Always Retry — replaces messages rather than extending them.
        # Continue would append new_messages to the existing list (agent.py),
        # leaving the old messages in place. Retry replaces them.
        return Retry(messages=new_messages)

    return _summarize_hook


# Pre-instantiated with defaults -- this is what the wrapper discovers
summarize_when_long = _make_summarize_hook()


# =============================================================================
# Default Hooks
# =============================================================================


def default_hooks() -> list:
    """Core hooks every agent should have."""
    from dreadnode.agents import stopping

    hooks: list = [
        tool_metrics(),
        summarize_when_long,
        stopping.step_count(50, name="server_step_limit"),
    ]
    if backoff_on_ratelimit is not None:
        hooks.insert(0, backoff_on_ratelimit)
    return hooks
