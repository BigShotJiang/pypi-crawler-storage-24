"""Declarative reward recipes for hosted training runtimes.

These recipes are intentionally lightweight and runtime-focused so they can be
used from sandboxes and API workers without importing the heavier reward
aggregation stack.
"""

from __future__ import annotations

import hashlib
import typing as t
from dataclasses import dataclass, field


@dataclass(slots=True)
class RewardPromptRow:
    """Minimal prompt-row information needed by declarative reward recipes."""

    expected_output: str | None = None
    reward: float | None = None
    metadata: dict[str, t.Any] = field(default_factory=dict)
    template_context: dict[str, str | int | None] = field(default_factory=dict)


@dataclass(slots=True)
class RewardTaskDefinition:
    """Minimal task metadata needed by declarative reward recipes."""

    reference: str
    verification: dict[str, t.Any] | None = None


@dataclass(slots=True)
class RewardEvaluationContext:
    """Inputs available to a reward recipe during rollout scoring."""

    completion: str
    prompt_row: RewardPromptRow
    task: RewardTaskDefinition | None = None
    recipe_params: dict[str, t.Any] = field(default_factory=dict)


@dataclass(slots=True)
class RewardEvaluationResult:
    """Normalized reward output from a declarative recipe."""

    reward: float
    metrics: dict[str, t.Any] = field(default_factory=dict)


class RewardRecipeRegistry:
    """Resolve declarative reward recipes into executable scorers."""

    def __init__(self) -> None:
        self._recipes: dict[
            str, t.Callable[[RewardEvaluationContext], RewardEvaluationResult]
        ] = {
            "contains_v1": self._contains_v1,
            "exact_match_v1": self._exact_match_v1,
            "trajectory_imitation_v1": self._trajectory_imitation_v1,
            "row_reward_v1": self._row_reward_v1,
            "task_verifier_v1": self._task_verifier_v1,
        }

    def evaluate(
        self,
        *,
        reward_recipe: dict[str, t.Any] | None,
        completion: str,
        prompt_row: RewardPromptRow,
        task: RewardTaskDefinition | None,
    ) -> RewardEvaluationResult:
        recipe_name = "row_reward_v1"
        recipe_params: dict[str, t.Any] = {}
        if reward_recipe is not None:
            recipe_name = str(reward_recipe.get("name") or recipe_name)
            params = reward_recipe.get("params")
            if isinstance(params, dict):
                recipe_params = params

        recipe = self._recipes.get(recipe_name)
        if recipe is None:
            raise ValueError(f"Unknown reward recipe: {recipe_name}")

        return recipe(
            RewardEvaluationContext(
                completion=completion,
                prompt_row=prompt_row,
                task=task,
                recipe_params=recipe_params,
            )
        )

    def _contains_v1(self, context: RewardEvaluationContext) -> RewardEvaluationResult:
        needle = context.recipe_params.get("needle")
        if not isinstance(needle, str) or not needle:
            raise ValueError("contains_v1 requires params.needle")

        passed = needle in context.completion
        reward = float(
            context.recipe_params.get("reward_if_true", 1.0 if passed else 0.0)
        )
        if not passed:
            reward = float(context.recipe_params.get("reward_if_false", 0.0))

        return RewardEvaluationResult(
            reward=reward,
            metrics={"reward/passed": passed, "reward/recipe": "contains_v1"},
        )

    def _exact_match_v1(self, context: RewardEvaluationContext) -> RewardEvaluationResult:
        expected = context.recipe_params.get("expected")
        if not isinstance(expected, str) or not expected:
            expected = context.prompt_row.expected_output
        if not expected:
            raise ValueError("exact_match_v1 requires an expected output")

        passed = context.completion.strip() == expected.strip()
        reward = 1.0 if passed else 0.0
        return RewardEvaluationResult(
            reward=reward,
            metrics={"reward/passed": passed, "reward/recipe": "exact_match_v1"},
        )

    def _row_reward_v1(self, context: RewardEvaluationContext) -> RewardEvaluationResult:
        reward = context.prompt_row.reward
        if reward is None:
            reward = float(context.recipe_params.get("default", 0.0))
        return RewardEvaluationResult(
            reward=reward,
            metrics={"reward/recipe": "row_reward_v1"},
        )

    def _trajectory_imitation_v1(
        self,
        context: RewardEvaluationContext,
    ) -> RewardEvaluationResult:
        expected = context.recipe_params.get("expected")
        if not isinstance(expected, str) or not expected:
            expected = context.prompt_row.expected_output
        if not expected:
            raise ValueError("trajectory_imitation_v1 requires an expected output")

        passed = context.completion.strip() == expected.strip()
        if passed:
            reward = context.prompt_row.reward
            if reward is None:
                reward = float(context.recipe_params.get("reward_if_true", 1.0))
        else:
            reward = float(context.recipe_params.get("reward_if_false", 0.0))

        return RewardEvaluationResult(
            reward=float(reward),
            metrics={
                "reward/passed": passed,
                "reward/recipe": "trajectory_imitation_v1",
                "reward/base_reward": context.prompt_row.reward,
            },
        )

    def _task_verifier_v1(self, context: RewardEvaluationContext) -> RewardEvaluationResult:
        verification = context.task.verification if context.task is not None else None
        if not isinstance(verification, dict):
            raise TypeError("task_verifier_v1 requires a task with verification config")

        method = verification.get("method")
        if method != "flag":
            raise ValueError(
                "task_verifier_v1 currently supports only flag-based task verification"
            )

        flag_hash = verification.get("flag_hash")
        if not isinstance(flag_hash, str) or not flag_hash.startswith("sha256:"):
            raise ValueError("task_verifier_v1 requires verification.flag_hash")

        normalized = context.completion.strip()
        computed_hash = f"sha256:{hashlib.sha256(normalized.encode()).hexdigest()}"
        passed = computed_hash == flag_hash
        reward = float(
            context.recipe_params.get("reward_if_true", 1.0 if passed else 0.0)
        )
        if not passed:
            reward = float(context.recipe_params.get("reward_if_false", 0.0))

        return RewardEvaluationResult(
            reward=reward,
            metrics={
                "reward/passed": passed,
                "reward/recipe": "task_verifier_v1",
                "reward/computed_flag_hash": computed_hash,
            },
        )


__all__ = [
    "RewardEvaluationContext",
    "RewardEvaluationResult",
    "RewardPromptRow",
    "RewardRecipeRegistry",
    "RewardTaskDefinition",
]
