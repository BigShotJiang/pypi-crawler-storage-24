"""Model-specific renderers for encoding OpenAI conversations into token sequences.

Each renderer knows how to format tool calls, thinking traces, and role headers
for a specific model family. The base class provides shared logic for
supervised-example construction (autoregressive shift + weight masking).
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from enum import StrEnum
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    from dreadnode.training.etl.worlds import ChatToolCall, OpenAIMessage, ToolSchema


class TrainOnWhat(StrEnum):
    """Which assistant tokens to include in the loss."""

    ALL_ASSISTANT_MESSAGES = "all_assistant_messages"
    LAST_ASSISTANT_MESSAGE = "last_assistant_message"


class Renderer(ABC):
    """Base class for model-specific conversation renderers."""

    def __init__(self, tokenizer: Any) -> None:
        self._tokenizer = tokenizer

    @abstractmethod
    def encode_conversation(
        self,
        messages: list[OpenAIMessage],
        tools: list[ToolSchema] | None = None,
    ) -> tuple[list[int], list[float]]:
        """Encode a conversation into tokens and per-token weights.

        Returns:
            Tuple of (tokens, weights) where weights are 1.0 for assistant
            tokens and 0.0 for everything else.
        """
        ...

    def build_supervised_example(
        self,
        messages: list[OpenAIMessage],
        tools: list[ToolSchema] | None = None,
        train_on_what: TrainOnWhat = TrainOnWhat.ALL_ASSISTANT_MESSAGES,
    ) -> tuple[list[int], list[float]]:
        """Encode and apply train_on_what masking.

        Returns tokens and weights BEFORE autoregressive shift — the caller
        (datum builder) handles the shift.
        """
        tokens, weights = self.encode_conversation(messages, tools)

        if train_on_what == TrainOnWhat.LAST_ASSISTANT_MESSAGE:
            weights = _mask_all_but_last_assistant(messages, tokens, weights, self)

        return tokens, weights

    def _encode(self, text: str, *, add_special_tokens: bool = False) -> list[int]:
        return self._tokenizer.encode(text, add_special_tokens=add_special_tokens)


def _mask_all_but_last_assistant(
    messages: list[OpenAIMessage],
    tokens: list[int],
    weights: list[float],
    renderer: Renderer,
) -> list[float]:
    """Zero out weights for all assistant segments except the last one."""
    last_assistant_idx = -1
    for i, msg in enumerate(messages):
        if msg.get("role") == "assistant":
            last_assistant_idx = i
    if last_assistant_idx < 0:
        return weights

    # Find the approximate token offset of the last assistant message
    # by re-encoding all prior messages and measuring length
    new_weights = [0.0] * len(weights)
    # Walk through and only keep weights for the last assistant region
    # We mark assistant regions by finding contiguous 1.0 blocks
    regions: list[tuple[int, int]] = []
    in_region = False
    start = 0
    for i, w in enumerate(weights):
        if w > 0 and not in_region:
            in_region = True
            start = i
        elif w == 0 and in_region:
            in_region = False
            regions.append((start, i))
    if in_region:
        regions.append((start, len(weights)))

    if regions:
        last_start, last_end = regions[-1]
        for i in range(last_start, last_end):
            new_weights[i] = weights[i]

    return new_weights


# ---------------------------------------------------------------------------
# Qwen3 Renderer
# ---------------------------------------------------------------------------


class Qwen3Renderer(Renderer):
    """Renderer for Qwen 3.x models.

    Uses ``<|im_start|>`` / ``<|im_end|>`` chat-ML style framing.
    """

    def encode_conversation(
        self,
        messages: list[OpenAIMessage],
        tools: list[ToolSchema] | None = None,
    ) -> tuple[list[int], list[float]]:
        tokens: list[int] = []
        weights: list[float] = []
        first = True

        # If tools provided, inject tool definitions into a system preamble
        if tools:
            tool_text = self._format_tools(tools)
            header = "<|im_start|>system\n"
            footer = "<|im_end|>\n"
            h_toks = self._encode(header, add_special_tokens=first)
            first = False
            tokens.extend(h_toks)
            weights.extend([0.0] * len(h_toks))
            b_toks = self._encode(tool_text)
            tokens.extend(b_toks)
            weights.extend([0.0] * len(b_toks))
            f_toks = self._encode(footer)
            tokens.extend(f_toks)
            weights.extend([0.0] * len(f_toks))

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            tool_calls = msg.get("tool_calls")
            tool_call_id = msg.get("tool_call_id")
            is_assistant = role == "assistant"

            header = f"<|im_start|>{role}\n"
            h_toks = self._encode(header, add_special_tokens=first)
            first = False
            tokens.extend(h_toks)
            weights.extend([0.0] * len(h_toks))

            # Build body
            body_parts: list[str] = []
            if content:
                body_parts.append(content)
            if tool_calls:
                for tc in tool_calls:
                    func = tc.get("function", {})
                    tc_text = (
                        "<tool_call>\n"
                        + json.dumps(
                            {"name": func.get("name", ""), "arguments": func.get("arguments", "")},
                            ensure_ascii=False,
                        )
                        + "\n</tool_call>"
                    )
                    body_parts.append(tc_text)
            if role == "tool":
                body_text = f"<tool_response>\n{content}\n</tool_response>" if content else ""
                if tool_call_id:
                    body_text = body_text  # tool_call_id not explicitly rendered in Qwen3
            else:
                body_text = "\n".join(body_parts)

            body_text_final = body_text if body_text else ""
            b_toks = self._encode(body_text_final)
            tokens.extend(b_toks)
            weights.extend([1.0 if is_assistant else 0.0] * len(b_toks))

            footer = "<|im_end|>\n"
            f_toks = self._encode(footer)
            tokens.extend(f_toks)
            weights.extend([1.0 if is_assistant else 0.0] * len(f_toks))

        return tokens, weights

    def _format_tools(self, tools: list[ToolSchema]) -> str:
        lines = ["# Tools\n\nYou have access to the following tools:\n"]
        for tool in tools:
            func = tool.get("function", {})
            lines.append(
                json.dumps(
                    {
                        "type": "function",
                        "function": {
                            "name": func.get("name", ""),
                            "description": func.get("description", ""),
                            "parameters": func.get("parameters", {}),
                        },
                    },
                    ensure_ascii=False,
                )
            )
        lines.append(
            "\nWhen you need to call a tool, use <tool_call> tags with the tool name and arguments."
        )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Nemotron3 Renderer
# ---------------------------------------------------------------------------


class Nemotron3Renderer(Renderer):
    """Renderer for Nemotron 3 models.

    Uses the same ``<|im_start|>`` / ``<|im_end|>`` framing as Qwen but
    renders tool declarations in XML format within the system message and
    tool calls as XML-structured parameters.
    """

    def encode_conversation(
        self,
        messages: list[OpenAIMessage],
        tools: list[ToolSchema] | None = None,
    ) -> tuple[list[int], list[float]]:
        tokens: list[int] = []
        weights: list[float] = []
        first = True

        if tools:
            tool_text = self._format_tools_xml(tools)
            header = "<|im_start|>system\n"
            footer = "<|im_end|>\n"
            h_toks = self._encode(header, add_special_tokens=first)
            first = False
            tokens.extend(h_toks)
            weights.extend([0.0] * len(h_toks))
            b_toks = self._encode(tool_text)
            tokens.extend(b_toks)
            weights.extend([0.0] * len(b_toks))
            f_toks = self._encode(footer)
            tokens.extend(f_toks)
            weights.extend([0.0] * len(f_toks))

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            tool_calls = msg.get("tool_calls")
            is_assistant = role == "assistant"

            header = f"<|im_start|>{role}\n"
            h_toks = self._encode(header, add_special_tokens=first)
            first = False
            tokens.extend(h_toks)
            weights.extend([0.0] * len(h_toks))

            body_parts: list[str] = []
            if content:
                body_parts.append(content)
            if tool_calls:
                for tc in tool_calls:
                    func = tc.get("function", {})
                    name = func.get("name", "")
                    args_str = func.get("arguments", "{}")
                    tc_text = (
                        "<tool_call>\n"
                        f"<name>{name}</name>\n"
                        f"<arguments>{args_str}</arguments>\n"
                        "</tool_call>"
                    )
                    body_parts.append(tc_text)
            if role == "tool":
                body_text = f"<tool_response>\n{content}\n</tool_response>" if content else ""
            else:
                body_text = "\n".join(body_parts)

            b_toks = self._encode(body_text if body_text else "")
            tokens.extend(b_toks)
            weights.extend([1.0 if is_assistant else 0.0] * len(b_toks))

            footer = "<|im_end|>\n"
            f_toks = self._encode(footer)
            tokens.extend(f_toks)
            weights.extend([1.0 if is_assistant else 0.0] * len(f_toks))

        return tokens, weights

    def _format_tools_xml(self, tools: list[ToolSchema]) -> str:
        lines = ["<tools>"]
        for tool in tools:
            func = tool.get("function", {})
            name = func.get("name", "")
            desc = func.get("description", "")
            params = json.dumps(func.get("parameters", {}), ensure_ascii=False)
            lines.append(
                f"<tool>\n<name>{name}</name>\n"
                f"<description>{desc}</description>\n"
                f"<parameters>{params}</parameters>\n</tool>"
            )
        lines.append("</tools>")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# GPT OSS Renderer
# ---------------------------------------------------------------------------


class GptOssRenderer(Renderer):
    """Renderer for GPT OSS models.

    Uses ``<|start|>`` / ``<|end|>`` delimiters with ``<|message|>``,
    ``<|call|>``, ``<|return|>`` markers for tool interaction, and
    TypeScript-style function signatures for tool definitions.
    """

    def encode_conversation(
        self,
        messages: list[OpenAIMessage],
        tools: list[ToolSchema] | None = None,
    ) -> tuple[list[int], list[float]]:
        tokens: list[int] = []
        weights: list[float] = []
        first = True

        if tools:
            tool_text = self._format_tools_typescript(tools)
            header = "<|start|>system<|message|>"
            h_toks = self._encode(header, add_special_tokens=first)
            first = False
            tokens.extend(h_toks)
            weights.extend([0.0] * len(h_toks))
            b_toks = self._encode(tool_text)
            tokens.extend(b_toks)
            weights.extend([0.0] * len(b_toks))
            f_toks = self._encode("<|end|>")
            tokens.extend(f_toks)
            weights.extend([0.0] * len(f_toks))

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            tool_calls = msg.get("tool_calls")
            tool_call_id = msg.get("tool_call_id")
            is_assistant = role == "assistant"

            if role == "tool":
                # Tool results use <|return|>
                # Try to find the function name from tool_call_id context
                return_name = tool_call_id or "function"
                header = f"<|start|>tool<|return|>{return_name}\n"
                h_toks = self._encode(header, add_special_tokens=first)
                first = False
                tokens.extend(h_toks)
                weights.extend([0.0] * len(h_toks))
                b_toks = self._encode(content if content else "")
                tokens.extend(b_toks)
                weights.extend([0.0] * len(b_toks))
                f_toks = self._encode("<|end|>")
                tokens.extend(f_toks)
                weights.extend([0.0] * len(f_toks))
                continue

            header = f"<|start|>{role}<|message|>"
            h_toks = self._encode(header, add_special_tokens=first)
            first = False
            tokens.extend(h_toks)
            weights.extend([0.0] * len(h_toks))

            # Handle thinking via harmony channels
            if is_assistant and content and "<think>" in content:
                # Split thinking and final content
                parts = content.split("</think>", 1)
                if len(parts) == 2:
                    think_content = parts[0].replace("<think>", "").strip()
                    final_content = parts[1].strip()
                    if think_content:
                        channel_toks = self._encode(f"<|channel|>analysis\n{think_content}\n<|channel|>final\n")
                        tokens.extend(channel_toks)
                        weights.extend([1.0] * len(channel_toks))
                    if final_content:
                        b_toks = self._encode(final_content)
                        tokens.extend(b_toks)
                        weights.extend([1.0] * len(b_toks))
                else:
                    b_toks = self._encode(content)
                    tokens.extend(b_toks)
                    weights.extend([1.0] * len(b_toks))
            elif content:
                b_toks = self._encode(content)
                tokens.extend(b_toks)
                weights.extend([1.0 if is_assistant else 0.0] * len(b_toks))

            # Tool calls
            if tool_calls:
                for tc in tool_calls:
                    func = tc.get("function", {})
                    name = func.get("name", "")
                    args_str = func.get("arguments", "{}")
                    call_text = f"<|call|>functions.{name}\n{args_str}"
                    c_toks = self._encode(call_text)
                    tokens.extend(c_toks)
                    weights.extend([1.0 if is_assistant else 0.0] * len(c_toks))

            f_toks = self._encode("<|end|>")
            tokens.extend(f_toks)
            weights.extend([1.0 if is_assistant else 0.0] * len(f_toks))

        return tokens, weights

    def _format_tools_typescript(self, tools: list[ToolSchema]) -> str:
        lines = ["// Available functions:\n"]
        for tool in tools:
            func = tool.get("function", {})
            name = func.get("name", "")
            desc = func.get("description", "")
            params = func.get("parameters", {})
            props = params.get("properties", {})
            required = set(params.get("required", []))
            param_parts: list[str] = []
            for pname, pdef in props.items():
                ptype = pdef.get("type", "string")
                optional = "" if pname in required else "?"
                param_parts.append(f"{pname}{optional}: {ptype}")
            sig = ", ".join(param_parts)
            lines.append(f"// {desc}")
            lines.append(f"function {name}({sig}): void;")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# RoleColon Renderer (generic fallback)
# ---------------------------------------------------------------------------


class RoleColonRenderer(Renderer):
    """Generic fallback renderer using ``Role:\\ncontent\\n`` format.

    Equivalent to the existing ``convert_messages_to_datum`` logic. Does not
    have structured tool call support — tool calls are linearized to text.
    """

    def encode_conversation(
        self,
        messages: list[OpenAIMessage],
        tools: list[ToolSchema] | None = None,
    ) -> tuple[list[int], list[float]]:
        tokens: list[int] = []
        weights: list[float] = []
        first = True

        for msg in messages:
            role = _normalize_role(msg.get("role", "user"))
            content = msg.get("content", "") or ""
            tool_calls = msg.get("tool_calls")
            is_assistant = role == "assistant"

            # Linearize tool calls into content if present
            if tool_calls:
                tc_parts: list[str] = []
                for tc in tool_calls:
                    func = tc.get("function", {})
                    tc_parts.append(
                        f'<tool_call name="{func.get("name", "")}">'
                        f'{func.get("arguments", "")}</tool_call>'
                    )
                if content:
                    content = content + "\n\n" + "\n".join(tc_parts)
                else:
                    content = "\n".join(tc_parts)

            header = f"{role.capitalize()}:\n"
            h_toks = self._encode(header, add_special_tokens=first)
            first = False
            tokens.extend(h_toks)
            weights.extend([0.0] * len(h_toks))

            body = f"{content.strip()}\n" if content.strip() else "\n"
            b_toks = self._encode(body)
            tokens.extend(b_toks)
            weights.extend([1.0 if is_assistant else 0.0] * len(b_toks))

        return tokens, weights


def _normalize_role(role: str) -> str:
    mapping = {
        "user": "user",
        "human": "user",
        "assistant": "assistant",
        "ai": "assistant",
        "model": "assistant",
        "system": "system",
        "tool": "tool",
    }
    return mapping.get(role.strip().lower(), "user")


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_renderer(model_name: str, tokenizer: Any) -> Renderer:
    """Select a renderer based on model name pattern matching."""
    lower = model_name.lower()
    if "qwen" in lower:
        return Qwen3Renderer(tokenizer)
    if "nemotron" in lower:
        return Nemotron3Renderer(tokenizer)
    if "gpt" in lower:
        return GptOssRenderer(tokenizer)
    return RoleColonRenderer(tokenizer)


__all__ = [
    "GptOssRenderer",
    "Nemotron3Renderer",
    "Qwen3Renderer",
    "Renderer",
    "RoleColonRenderer",
    "TrainOnWhat",
    "get_renderer",
]
