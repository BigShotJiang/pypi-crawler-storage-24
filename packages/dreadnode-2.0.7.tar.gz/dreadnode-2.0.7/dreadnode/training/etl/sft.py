"""Reusable SFT ETL helpers for hosted training datasets."""

from __future__ import annotations

import typing as t
from dataclasses import dataclass

from dreadnode.training.etl._common import (
    apply_system_prompt,
    normalize_messages,
    normalize_optional_string,
    normalize_prompt,
)

if t.TYPE_CHECKING:
    from dreadnode.datasets.dataset import Dataset
    from dreadnode.datasets.local import LocalDataset


@dataclass(slots=True)
class SFTConversation:
    """Normalized conversation row for supervised fine-tuning."""

    messages: list[dict[str, str]]
    metadata: dict[str, t.Any]


def load_sft_conversations_from_dataset(
    dataset: Dataset | LocalDataset,
    *,
    split: str | None = None,
    limit: int | None = None,
    system_prompt: str | None = None,
) -> list[SFTConversation]:
    """Load a published dataset into normalized SFT conversations."""

    table = dataset.load(split=split)
    records = [record for record in table.to_pylist() if isinstance(record, dict)]
    conversations = convert_records_to_sft_conversations(
        records,
        system_prompt=system_prompt,
    )
    if limit is None:
        return conversations
    return conversations[:limit]


def convert_records_to_sft_conversations(
    records: list[dict[str, t.Any]],
    *,
    system_prompt: str | None = None,
) -> list[SFTConversation]:
    """Convert record dictionaries into SFT conversations."""

    conversations = [
        _normalize_sft_conversation(record=record, system_prompt=system_prompt)
        for record in records
    ]
    return [conversation for conversation in conversations if conversation is not None]


def _normalize_sft_conversation(
    *,
    record: dict[str, t.Any],
    system_prompt: str | None,
) -> SFTConversation | None:
    messages = normalize_messages(record.get("messages"))

    if not messages:
        prompt = normalize_prompt(record)
        completion = normalize_optional_string(
            record.get("expected_output")
            or record.get("target")
            or record.get("answer")
            or record.get("output")
        )
        if prompt and completion:
            messages = [
                {"role": "user", "content": prompt},
                {"role": "assistant", "content": completion},
            ]

    if not messages:
        return None

    normalized_messages = apply_system_prompt(
        system_prompt=system_prompt,
        messages=messages,
    )
    metadata = {
        key: value
        for key, value in record.items()
        if key not in {"messages", "prompt", "input", "question", "task_prompt"}
    }
    return SFTConversation(messages=normalized_messages, metadata=metadata)


__all__ = [
    "SFTConversation",
    "convert_records_to_sft_conversations",
    "load_sft_conversations_from_dataset",
]
