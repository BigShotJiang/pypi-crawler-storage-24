"""Full-screen session picker — browse, search, select, or delete sessions.

Renders using Rich Text objects into Static widgets (same pattern as
CapabilitiesScreen) — no DataTable or Input widgets.

Layout:
  ⌕ Search…  1/N
  > First user message preview truncated to fit the terminal width...
    23h ago · default · 9 msgs
    Second session preview...
    3d ago · coder · 22 msgs
"""

from __future__ import annotations

import typing as t
from datetime import UTC, datetime

from rich.text import Text
from textual.containers import VerticalScroll
from textual.screen import Screen
from textual.widgets import Static

from dreadnode.app.tui.screens.base import _bind_status_bar_to_app
from dreadnode.app.tui.theme import ACCENT, FG, FG_FAINTEST, FG_MUTED, FG_SUBTLE
from dreadnode.app.tui.widgets.status_bar import StatusBar

if t.TYPE_CHECKING:
    from textual.app import ComposeResult
    from textual.events import Key

    from dreadnode.app.tui.app import SessionRecord


def _relative_time(iso_ts: str | None) -> str:
    """Format an ISO timestamp as a human-friendly relative string."""
    if not iso_ts:
        return "-"
    try:
        dt = datetime.fromisoformat(iso_ts)
    except ValueError:
        return iso_ts[:16]
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    now = datetime.now(tz=UTC)
    delta = now - dt
    seconds = int(delta.total_seconds())
    if seconds < 0:
        return "just now"
    if seconds < 60:
        return "just now"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m ago"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h ago"
    days = hours // 24
    if days < 7:
        return f"{days}d ago"
    return dt.strftime("%b %d")


def _conversation_preview(record: SessionRecord, max_len: int = 100) -> str:
    """Extract a preview — prefer server-provided preview, fall back to transcript."""
    # Server-provided preview (from SessionInfo.preview)
    if record.info.preview:
        text = record.info.preview.strip().replace("\n", " ")
        if len(text) > max_len:
            return text[: max_len - 1] + "\u2026"
        return text
    # Fall back to scanning transcript (only available for active/loaded sessions)
    for entry in record.transcript:
        if entry.kind == "user":
            text = entry.body.strip().replace("\n", " ")
            if len(text) > max_len:
                return text[: max_len - 1] + "\u2026"
            return text
    return ""


def _filter_sessions(
    sessions: list[tuple[str, SessionRecord]], query: str
) -> list[tuple[str, SessionRecord]]:
    """Filter sessions by query matching against preview, agent, session id."""
    if not query:
        return sessions
    q = query.lower()
    return [
        (sid, rec)
        for sid, rec in sessions
        if q in _conversation_preview(rec).lower()
        or q in (rec.info.agent or rec.info.capability or "default").lower()
        or q in sid.lower()
    ]


class SessionPickerScreen(Screen[str | None]):
    """Full-screen session picker with inline search and keyboard navigation."""

    def __init__(
        self,
        sessions: dict[str, SessionRecord],
        active_session_id: str | None = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(**kwargs)
        self._sessions = dict(sessions)
        self._active_session_id = active_session_id
        self._sorted: list[tuple[str, SessionRecord]] = []
        self._visible: list[tuple[str, SessionRecord]] = []
        self._cursor: int = 0
        self._search_query: str = ""
        self._pending_deletes: list[str] = []

    def compose(self) -> ComposeResult:
        yield Static(id="session-header")
        yield Static(id="session-search")
        with VerticalScroll(id="session-scroll"):
            yield Static(id="session-content")
        yield Static(id="session-hint-bar")
        yield StatusBar(id="global-status-bar")

    def on_mount(self) -> None:
        _bind_status_bar_to_app(self, self.query_one("#global-status-bar", StatusBar))

        # Sort sessions by created_at descending
        self._sorted = sorted(
            self._sessions.items(),
            key=lambda item: item[1].info.created_at or "",
            reverse=True,
        )
        self._render_all()

    # ── Keyboard handling ────────────────────────────────────────────────

    def on_key(self, event: Key) -> None:
        key = event.key

        # Let control sequences and function keys pass through to app bindings
        if key.startswith("ctrl+") or (key.startswith("f") and key[1:].isdigit()):
            return

        if key == "up":
            if self._visible:
                self._cursor = max(0, self._cursor - 1)
                self._render_content()
                self._scroll_to_cursor()
        elif key == "down":
            if self._visible:
                self._cursor = min(len(self._visible) - 1, self._cursor + 1)
                self._render_content()
                self._scroll_to_cursor()
        elif key == "enter":
            if self._visible and 0 <= self._cursor < len(self._visible):
                sid = self._visible[self._cursor][0]
                self._dismiss_with_deletes(sid)
        elif key == "escape":
            if self._search_query:
                self._search_query = ""
                self._cursor = 0
                self._render_all()
            else:
                self._dismiss_with_deletes(None)
        elif key == "backspace":
            if self._search_query:
                self._search_query = self._search_query[:-1]
                self._cursor = 0
                self._render_all()
        elif event.character == "n" and not self._search_query:
            self._dismiss_with_deletes("__new__")
        elif event.character == "d" and not self._search_query:
            self._delete_current()
        elif event.character and event.character.isprintable() and len(event.character) == 1:
            self._search_query += event.character
            self._cursor = 0
            self._render_all()
        else:
            return

        event.prevent_default()
        event.stop()

    def _dismiss_with_deletes(self, result: str | None) -> None:
        """Dismiss the screen, bundling any pending deletes into the result."""
        if self._pending_deletes:
            deletes = ",".join(self._pending_deletes)
            if result is None:
                self.dismiss(f"__deletes__:{deletes}")
            else:
                self.dismiss(f"__deletes__:{deletes}|{result}")
        else:
            self.dismiss(result)

    def _delete_current(self) -> None:
        if not self._visible or self._cursor >= len(self._visible):
            return
        sid = self._visible[self._cursor][0]
        self._sessions.pop(sid, None)
        self._sorted = [(s, r) for s, r in self._sorted if s != sid]
        self._pending_deletes.append(sid)
        self._cursor = min(self._cursor, max(0, len(self._sorted) - 1))
        self._render_all()

    def _scroll_to_cursor(self) -> None:
        """Ensure the cursor row is visible in the scroll container."""
        scroll = self.query_one("#session-scroll", VerticalScroll)
        # Each session entry is ~3 lines; estimate target and ensure visible
        entry_height = 3
        target_y = self._cursor * entry_height
        viewport_top = scroll.scroll_offset.y
        viewport_height = scroll.size.height

        if target_y < viewport_top:
            scroll.scroll_to(y=target_y, animate=False)
        elif target_y + entry_height > viewport_top + viewport_height:
            scroll.scroll_to(y=target_y + entry_height - viewport_height, animate=False)

    # ── Rendering ────────────────────────────────────────────────────────

    def _render_all(self) -> None:
        self._render_header()
        self._render_content()
        self._render_hints()

    def _render_header(self) -> None:
        text = Text()
        text.append(" Sessions", style=f"bold {FG}")
        total = len(self._sessions)
        text.append(f"  {total}", style=FG_MUTED)
        text.append("\n")
        text.append(" Browse and resume conversation sessions", style=FG_FAINTEST)
        self.query_one("#session-header", Static).update(text)

    def _render_search(self) -> None:
        text = Text()
        if self._search_query:
            text.append(f" \u2315 {self._search_query}", style=FG)
            text.append("\u2581", style=FG_FAINTEST)
        else:
            text.append(" \u2315 Search\u2026", style=FG_FAINTEST)
        if self._visible:
            text.append(f"  {self._cursor + 1}/{len(self._visible)}", style=FG_FAINTEST)
        self.query_one("#session-search", Static).update(text)

    def _render_content(self) -> None:
        self._visible = _filter_sessions(self._sorted, self._search_query)
        self._cursor = min(self._cursor, max(0, len(self._visible) - 1))

        self._render_search()

        text = Text()

        if not self._visible:
            if self._search_query:
                text.append(f'  No matches for "{self._search_query}"\n', style=FG_MUTED)
            else:
                text.append("  No sessions yet\n\n", style=FG_MUTED)
                text.append("  Press ", style=FG_FAINTEST)
                text.append("N", style=FG_SUBTLE)
                text.append(" to start a new session.\n", style=FG_FAINTEST)
        else:
            for i, (sid, record) in enumerate(self._visible):
                is_active = sid == self._active_session_id
                preview = _conversation_preview(record)
                agent = record.info.agent or record.info.capability or "default"
                created = _relative_time(record.info.created_at)
                msgs = record.info.message_count

                # Line 1: cursor + preview
                if i == self._cursor:
                    text.append(" \u276f ", style=f"bold {ACCENT}")
                elif is_active:
                    text.append(" \u25cf ", style=ACCENT)
                else:
                    text.append("   ")

                preview_style = FG if (i == self._cursor or is_active) else FG_SUBTLE
                text.append(preview, style=preview_style)
                text.append("\n")

                # Line 2: metadata
                text.append("   ", style=FG_FAINTEST)
                text.append(created, style=FG_FAINTEST)
                text.append(" \u00b7 ", style=FG_FAINTEST)
                text.append(agent, style=FG_FAINTEST)
                text.append(" \u00b7 ", style=FG_FAINTEST)
                text.append(f"{msgs} msg{'s' if msgs != 1 else ''}", style=FG_FAINTEST)
                text.append("\n\n")

        self.query_one("#session-content", Static).update(text)

    def _render_hints(self) -> None:
        text = Text()
        text.append(" ")
        hints = [
            ("Enter", "select"),
            ("N", "new"),
            ("D", "delete"),
            ("Esc", "back"),
            ("Type", "search"),
        ]
        for i, (key, action) in enumerate(hints):
            if i > 0:
                text.append(" \u00b7 ", style=FG_FAINTEST)
            text.append(key, style=FG_MUTED)
            text.append(f" {action}", style=FG_FAINTEST)
        self.query_one("#session-hint-bar", Static).update(text)
