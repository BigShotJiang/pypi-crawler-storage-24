"""Inline model picker overlay for the Dreadnode TUI.

Renders as an OptionList above the composer (same pattern as SlashOverlay),
toggled visible/hidden via CSS class. The composer routes arrow keys to it
when active.
"""

from __future__ import annotations

import typing as t

from rich.text import Text
from textual.message import Message
from textual.widgets.option_list import Option

from dreadnode.app.tui.model_variants import display_name
from dreadnode.app.tui.theme import BRAND, FG_FAINTEST, FG_MUTED
from dreadnode.app.tui.widgets.overlay_mixin import OverlayMixin


def _extract_provider(model_id: str) -> str:
    """Extract provider from model ID (e.g. 'anthropic/claude-opus-4-6' -> 'anthropic')."""
    if "/" in model_id:
        return model_id.split("/", maxsplit=1)[0]
    return ""


class ModelPickerOverlay(OverlayMixin):
    """Inline overlay for selecting an LLM model."""

    class ModelSelected(Message):
        """Posted when a model is selected."""

        def __init__(self, model_id: str) -> None:
            self.model_id = model_id
            super().__init__()

    def show_models(
        self,
        models: list[str],
        current: str,
        *,
        platform_models: list[dict[str, t.Any]] | None = None,
    ) -> None:
        """Populate the list with dot markers and provider names."""
        self.clear_options()
        current_index = 0
        idx = 0

        def add_model_option(model_id: str, name_override: str | None = None) -> None:
            nonlocal current_index, idx
            label = Text()
            is_current = model_id == current

            # Selection dot
            if is_current:
                label.append(" \u25cf ", style=BRAND)
                current_index = idx
            else:
                label.append(" \u25cb ", style=FG_FAINTEST)

            # Model name
            label.append(
                name_override or display_name(model_id), style="bold" if is_current else ""
            )

            # Provider
            provider = _extract_provider(model_id)
            if provider:
                label.append(f"  \u00b7  {provider}", style=FG_FAINTEST)

            self.add_option(Option(label, id=model_id))
            idx += 1

        platform_entries: list[tuple[str, str | None]] = []
        if platform_models:
            for entry in platform_models:
                if not isinstance(entry, dict):
                    continue
                model_id = entry.get("id")
                if not isinstance(model_id, str):
                    continue
                if not entry.get("enabled", True):
                    continue
                name = entry.get("name") if isinstance(entry.get("name"), str) else None
                platform_entries.append((model_id, name))

        if platform_entries:
            self.add_option(Option(Text(" Dreadnode", style=f"bold {FG_MUTED}"), disabled=True))
            idx += 1
            for model_id, name in platform_entries:
                add_model_option(model_id, name_override=name)
            self.add_option(None)

        for model_id in models:
            if model_id.startswith("dn/"):
                continue
            add_model_option(model_id)

        self.highlighted = current_index
        self.add_class("-visible")

    def move_highlight(self, direction: int) -> None:
        """Move the highlight with wrapping (cycles past ends)."""
        if self.option_count == 0:
            return
        current = self.highlighted if self.highlighted is not None else 0
        self.highlighted = (current + direction) % self.option_count

    def select_highlighted(self) -> bool:
        """Select the currently highlighted option. Returns True if handled."""
        if not self.is_visible or self.option_count == 0:
            return False
        idx = self.highlighted
        if idx is not None and 0 <= idx < self.option_count:
            option = self.get_option_at_index(idx)
            if option.id:
                self.post_message(self.ModelSelected(option.id))
                self.hide()
                return True
        return False

    def on_option_list_option_selected(self, event: OverlayMixin.OptionSelected) -> None:
        """Handle click/enter on an option."""
        if event.option.id:
            self.post_message(self.ModelSelected(event.option.id))
            self.hide()
