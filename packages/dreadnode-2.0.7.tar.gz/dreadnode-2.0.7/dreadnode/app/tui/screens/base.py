"""Base screen that includes Zone 4 global nav bar on all pushed screens."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.text import Text
from textual.screen import Screen
from textual.widgets import Static

from dreadnode.app.tui.theme import FG_FAINTEST, FG_MUTED
from dreadnode.app.tui.widgets.status_bar import StatusBar

if TYPE_CHECKING:
    from textual.app import ComposeResult

from loguru import logger

_KEY_MAP: dict[str, str] = {
    "escape": "Esc",
}


def _bind_status_bar_to_app(screen: Screen[object], bar: StatusBar) -> None:
    """Mirror app reactives into a pushed screen's local StatusBar."""
    try:
        from dreadnode.app.tui.app import DreadnodeTextualApp

        app = screen.app
        if not isinstance(app, DreadnodeTextualApp):
            return

        def make_watcher(attr: str):
            def update(_old: str, new: str) -> None:
                setattr(bar, attr, new)

            return update

        for attr in (
            "connection",
            "runtime_connected",
            "workspace_label",
            "remote_info",
            "update_available",
        ):
            screen.watch(app, attr, make_watcher(attr), init=True)
    except Exception:
        logger.opt(exception=True).debug("Failed to bind StatusBar state")


class _HintBar(Static):
    """Single-line bar showing visible keybindings for the current screen."""

    DEFAULT_CSS = f"""
    _HintBar {{
        height: 1;
        padding: 0 2;
        color: {FG_FAINTEST};
    }}
    """

    def __init__(self, hints: list[tuple[str, str]], **kwargs: object) -> None:
        super().__init__(**kwargs)
        self._hints = hints

    def render(self) -> Text:
        t = Text(no_wrap=True, overflow="ellipsis")
        for i, (key, desc) in enumerate(self._hints):
            t.append(key, style=FG_MUTED)
            t.append(f" {desc}", style=FG_FAINTEST)
            if i < len(self._hints) - 1:
                t.append("  ")
        return t


class DreadnodeScreen(Screen[None]):
    """Base class for all pushed screens — automatically includes Zone 4 StatusBar.

    Subclasses override ``compose_content()`` instead of ``compose()``.
    """

    def compose_content(self) -> ComposeResult:
        """Override this in subclasses to yield screen-specific content."""
        return
        yield  # Make it a generator

    def _collect_hints(self) -> list[tuple[str, str]]:
        """Gather (key, description) pairs from show=True bindings."""
        hints: list[tuple[str, str]] = []
        for _key, binding in self._bindings:
            if not binding.show:
                continue
            raw = binding.key
            label = _KEY_MAP.get(raw, raw.capitalize() if len(raw) == 1 else raw.title())
            hints.append((label, binding.description))
        return hints

    def compose(self) -> ComposeResult:
        yield from self.compose_content()
        hints = self._collect_hints()
        if hints:
            yield _HintBar(hints, id="screen-hints")
        yield StatusBar(id="global-status-bar")

    def on_mount(self) -> None:
        """Bind app-level status to the pushed screen's StatusBar."""
        _bind_status_bar_to_app(self, self.query_one("#global-status-bar", StatusBar))
