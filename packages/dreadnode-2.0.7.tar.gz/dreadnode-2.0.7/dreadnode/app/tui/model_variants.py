"""Provider-based variant registry for thinking/reasoning effort levels.

Maps (provider, effort_label) → provider-specific API params that get
passed through GenerateParams.extra → LiteLLM acompletion() kwargs.

Provider is inferred from the model string. The platform catalog's
"reasoning" capability gates which models actually support variants.
When catalog is unavailable, variants are offered optimistically —
LiteLLM's drop_params:true silently drops unsupported params.
"""

from __future__ import annotations

import typing as t

if t.TYPE_CHECKING:
    from rich.text import Text

# ---------------------------------------------------------------------------
# Provider → effort → API params
# ---------------------------------------------------------------------------

_ANTHROPIC_VARIANTS: dict[str, dict[str, t.Any]] = {
    "low": {"reasoning_effort": "low"},
    "medium": {"reasoning_effort": "medium"},
    "high": {"reasoning_effort": "high"},
    "max": {"reasoning_effort": "max"},
}

_OPENAI_VARIANTS: dict[str, dict[str, t.Any]] = {
    "low": {"reasoning_effort": "low"},
    "medium": {"reasoning_effort": "medium"},
    "high": {"reasoning_effort": "high"},
}

_GOOGLE_VARIANTS: dict[str, dict[str, t.Any]] = {
    "high": {"thinking_config": {"include_thoughts": True, "thinking_budget": 16000}},
    "max": {"thinking_config": {"include_thoughts": True, "thinking_budget": 24576}},
}

_PROVIDER_VARIANTS: dict[str, dict[str, dict[str, t.Any]]] = {
    "anthropic": _ANTHROPIC_VARIANTS,
    "openai": _OPENAI_VARIANTS,
    "google": _GOOGLE_VARIANTS,
}

# ---------------------------------------------------------------------------
# Model string → provider
# ---------------------------------------------------------------------------

# Known providers (for explicit provider/ prefix validation)
_KNOWN_PROVIDERS = {"anthropic", "openai", "google", "groq", "openrouter"}

# Known model prefixes that map to providers without explicit provider/ prefix
_BARE_MODEL_PROVIDERS: list[tuple[str, str]] = [
    ("claude-", "anthropic"),
    ("gemini-", "google"),
    ("gpt-", "openai"),
    ("o1-", "openai"),
    ("o3-", "openai"),
    ("o4-", "openai"),
]

# dn/ prefix models → real provider (platform-hosted via LiteLLM proxy)
_DN_PREFIX_PROVIDERS: list[tuple[str, str]] = [
    ("dn/claude-", "anthropic"),
    ("dn/gpt-", "openai"),
    ("dn/gemini-", "google"),
    ("dn/o1-", "openai"),
    ("dn/o3-", "openai"),
    ("dn/o4-", "openai"),
    ("dn/openrouter/", "openrouter"),
]


def infer_provider(model: str) -> str | None:
    """Infer the LLM provider from a model identifier string.

    Handles formats: "provider/model", "dn/model", "model" (bare).
    """
    lower = model.lower()

    # Explicit provider/ prefix
    if "/" in lower and not lower.startswith("dn/"):
        provider = lower.split("/", 1)[0]
        # Normalize gemini → google
        if provider == "gemini":
            provider = "google"
        # Only return known providers
        if provider in _KNOWN_PROVIDERS:
            return provider
        return None

    # dn/ prefix (platform proxy)
    for prefix, provider in _DN_PREFIX_PROVIDERS:
        if lower.startswith(prefix):
            return provider

    # Bare model name
    for prefix, provider in _BARE_MODEL_PROVIDERS:
        if lower.startswith(prefix):
            return provider

    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_variants(
    model: str,
    *,
    reasoning: bool | None = None,
) -> dict[str, dict[str, t.Any]]:
    """Return available effort variants for a model.

    Args:
        model: Model identifier string (e.g. "anthropic/claude-opus-4-6")
        reasoning: Whether model supports reasoning (from platform catalog).
            True = yes, return provider variants.
            False = no, return empty dict.
            None = unknown (no catalog), optimistically return provider variants.
    """
    if reasoning is False:
        return {}

    provider = infer_provider(model)
    if provider is None:
        return {}

    return dict(_PROVIDER_VARIANTS.get(provider, {}))


# ---------------------------------------------------------------------------
# Sane defaults per provider
# ---------------------------------------------------------------------------

_PROVIDER_DEFAULT_EFFORT: dict[str, str] = {
    "anthropic": "medium",
    "openai": "medium",
    "google": "high",
}


def default_effort(model: str) -> str | None:
    """Return the default thinking effort level for a model, or None if unsupported."""
    provider = infer_provider(model)
    if provider is None:
        return None
    return _PROVIDER_DEFAULT_EFFORT.get(provider)


def cycle_variant(
    variants: dict[str, dict[str, t.Any]],
    current: str | None,
) -> str | None:
    """Advance to the next variant label, wrapping to None after last."""
    if not variants:
        return None
    keys = list(variants.keys())
    if current is None:
        return keys[0]
    try:
        idx = keys.index(current)
    except ValueError:
        return keys[0]
    next_idx = idx + 1
    if next_idx >= len(keys):
        return None
    return keys[next_idx]


# ---------------------------------------------------------------------------
# Human-friendly display names
# ---------------------------------------------------------------------------

# Map model ID substrings → short display names.
# Order: more specific patterns first so longest match wins naturally.
_MODEL_DISPLAY_NAMES: dict[str, str] = {
    # Anthropic — versioned (e.g. claude-opus-4-6) and base (e.g. claude-sonnet-4-20250514)
    "claude-opus-4-6": "Opus 4.6",
    "claude-sonnet-4-6": "Sonnet 4.6",
    "claude-opus-4-5": "Opus 4.5",
    "claude-sonnet-4-5": "Sonnet 4.5",
    "claude-haiku-4-5": "Haiku 4.5",
    "claude-haiku-3-5": "Haiku 3.5",
    "claude-sonnet-3-5": "Sonnet 3.5",
    "claude-opus-4": "Opus 4",
    "claude-sonnet-4": "Sonnet 4",
    "claude-haiku-4": "Haiku 4",
    # OpenAI
    "gpt-5.4-mini": "GPT-5.4 Mini",
    "gpt-5.4": "GPT-5.4",
    "gpt-5.3-codex": "GPT-5.3-Codex",
    "gpt-5.2-codex": "GPT-5.2-Codex",
    "gpt-5.2": "GPT-5.2",
    "gpt-5-nano": "GPT-5 Nano",
    "gpt-4.1-mini": "GPT-4.1 Mini",
    "gpt-4.1-nano": "GPT-4.1 Nano",
    "gpt-4.1": "GPT-4.1",
    "gpt-4o-mini": "GPT-4o Mini",
    "gpt-4o": "GPT-4o",
    "o3-mini": "o3 Mini",
    "o4-mini": "o4 Mini",
    "o3": "o3",
    # Google
    "gemini-3.1-pro": "Gemini 3.1 Pro",
    "gemini-3.1-flash-lite": "Gemini 3.1 Flash Lite",
    "gemini-2.5-pro": "Gemini 2.5 Pro",
    "gemini-2.5-flash": "Gemini 2.5 Flash",
    "gemini-2.0-flash": "Gemini 2.0 Flash",
    # OpenRouter
    "kimi-k2.5": "Kimi K2.5",
    "qwen3-coder-next": "Qwen3 Coder Next",
}

# Ordered list of common model IDs for the model picker fallback.
KNOWN_MODELS: list[str] = [
    "anthropic/claude-opus-4-6",
    "anthropic/claude-sonnet-4-6",
    "openai/gpt-5.4-2026-03-05",
    "openai/gpt-5.4-mini-2026-03-17",
    "openai/gpt-5.3-codex",
    "openai/o3",
    "openai/o4-mini",
    "gemini/gemini-3.1-pro-preview",
    "gemini/gemini-3.1-flash-lite-preview",
    "openrouter/moonshotai/kimi-k2.5",
    "openrouter/qwen/qwen3-coder-next",
]


def _strip_provider(model: str) -> str:
    """Strip provider prefix (e.g. 'anthropic/', 'dn/') from a model string."""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def display_name(model: str) -> str:
    """Return a short human-friendly display name for a model.

    Strips the provider prefix, then looks up the longest matching
    substring in ``_MODEL_DISPLAY_NAMES``.  Falls back to the
    stripped model ID when no match is found.
    """
    bare = _strip_provider(model).lower()

    # Normalize both sides: dots ↔ dashes so "claude-opus-4.5" matches "claude-opus-4-5"
    bare_norm = bare.replace(".", "-")
    best_key: str | None = None
    for key in _MODEL_DISPLAY_NAMES:
        key_norm = key.replace(".", "-")
        if key_norm in bare_norm:
            if best_key is None or len(key_norm) > len(best_key.replace(".", "-")):
                best_key = key

    if best_key is not None:
        return _MODEL_DISPLAY_NAMES[best_key]

    return _strip_provider(model)


def display_name_with_effort(model: str, effort: str | None) -> str:
    """Return display name optionally suffixed with the effort level.

    Example: ``"Opus 4.6 (High)"`` when *effort* is ``"high"``.
    Returns plain ``display_name(model)`` when *effort* is None or empty.
    """
    name = display_name(model)
    if effort:
        return f"{name} ({effort.capitalize()})"
    return name


# ---------------------------------------------------------------------------
# Token formatting & model context limits
# ---------------------------------------------------------------------------


_model_max_cache: dict[str, int | None] = {}


def get_model_max_input_tokens(model: str) -> int | None:
    """Look up the max input token limit for a model via litellm metadata.

    Returns None if the model is unknown. Results are cached per model string.
    """
    if model in _model_max_cache:
        return _model_max_cache[model]

    result: int | None = None
    try:
        import os

        # Env vars are the canonical way to suppress litellm noise —
        # same mechanism as _suppress_library_noise() in print_mode.py
        os.environ.setdefault("LITELLM_LOG", "ERROR")
        os.environ.setdefault("LITELLM_SUPPRESS_DEBUG_INFO", "1")

        import litellm

        # Strip dn/ proxy prefix for lookup
        lookup = model
        lookup = lookup.removeprefix("dn/")

        while lookup not in litellm.model_cost:
            if "/" not in lookup:
                break
            lookup = "/".join(lookup.split("/")[1:])

        if lookup in litellm.model_cost:
            info = litellm.model_cost[lookup]
            max_input = info.get("max_input_tokens") or info.get("max_tokens", 0)
            if max_input and max_input > 0:
                result = int(max_input)
    except Exception:  # noqa: S110
        pass

    _model_max_cache[model] = result
    return result


def _fmt_tokens(n: int) -> str:
    """Format a raw token count as a compact string (no suffix)."""
    if n < 1_000:
        return str(n)
    if n >= 999_500:
        m = n / 1_000_000
        formatted = f"{m:.1f}"
        formatted = formatted.removesuffix(".0")
        return f"{formatted}M"
    k = n / 1_000
    if k >= 100:
        return f"{k:.0f}k"
    # 1k-99.9k — one decimal, strip trailing .0
    formatted = f"{k:.1f}"
    formatted = formatted.removesuffix(".0")
    return f"{formatted}k"


def format_tokens(tokens: int, limit: int | None = None) -> str:
    """Format a token count for display, with optional context limit.

    Examples:
        format_tokens(834)              → "834 tok"
        format_tokens(1_200)            → "1.2k tok"
        format_tokens(53_422)           → "53.4k tok"
        format_tokens(200_000)          → "200k tok"
        format_tokens(53_422, 200_000)  → "53.4k/200k tok"
    """
    result = _fmt_tokens(tokens)
    if limit is not None and limit > 0:
        result += f"/{_fmt_tokens(limit)}"
    return f"{result} tok"


def render_tokens(tokens: int, limit: int | None = None) -> Text:
    """Build a styled Rich Text for token display.

    The current count brightens as usage approaches the limit,
    fading from muted → subtle → accent for a gentle visual cue:
      - <50%:  muted grey
      - 50-75%: lighter grey
      - >75%:  brand accent
    """
    from rich.text import Text

    from dreadnode.app.tui.theme import ACCENT, FG_FAINTEST, FG_MUTED, FG_SUBTLE

    count_style = FG_MUTED
    if limit is not None and limit > 0:
        ratio = tokens / limit
        if ratio >= 0.75:
            count_style = ACCENT
        elif ratio >= 0.5:
            count_style = FG_SUBTLE

    result = Text(no_wrap=True)
    result.append(_fmt_tokens(tokens), style=count_style)
    if limit is not None and limit > 0:
        result.append("/", style=FG_FAINTEST)
        result.append(_fmt_tokens(limit), style=FG_FAINTEST)
    result.append(" tok", style=FG_FAINTEST)
    return result
