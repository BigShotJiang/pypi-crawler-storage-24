from __future__ import annotations

import asyncio
import contextlib
import json
import os
import re
import time
import typing as t
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
from textual import events, on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.reactive import reactive
from textual.theme import Theme
from textual.widgets import Static, TextArea

from dreadnode.app.api.client import ApiClient, AuthenticationError
from dreadnode.app.api.models import HumanInputResponse, HumanPrompt, HumanPromptOption
from dreadnode.app.server.session import ServerConfig, UserConfig, urls_match
from dreadnode.app.tui.client import (
    DEFAULT_MODEL,
    RuntimeInfo,
    RuntimeServerClient,
    SessionInfo,
)
from dreadnode.app.tui.commands import (
    DEFAULT_PLATFORM_URL,
    SlashCommand,
    _active_profile,
    _delete_active_profile,
    _format_tool_label,
    _login_with_api_key,
    _parse_login_args,
    _platform_client,
    _save_profile,
    _summarize_tool_result,
    _transcript_from_messages,
)

if t.TYPE_CHECKING:
    from textual.events import Key

    from dreadnode.app.tui.connection import SessionStateBundle
    from dreadnode.app.tui.screens.workspaces import SwitchRequest
    from dreadnode.app.tui.update_check import UpdateInfo

from loguru import logger

from dreadnode.app.tui.event_contract import NormalizedEvent, normalize_event
from dreadnode.app.tui.screens import (
    AuthModal,
    CapabilitiesScreen,
    ConsoleScreen,
    EnvironmentScreen,
    EvaluationsScreen,
    RuntimeScreen,
    SandboxScreen,
    SecretsScreen,
    SessionPickerScreen,
    TracesScreen,
    WorkspaceScreen,
)
from dreadnode.app.tui.screens.mcp import McpScreen
from dreadnode.app.tui.screens.model_picker import ModelPickerOverlay
from dreadnode.app.tui.theme import (
    ACCENT,
    BG,
    BRAND,
    ERROR,
    FG,
    FG_FAINTEST,
    FG_MUTED,
    FG_SUBTLE,
    INFO,
    SUCCESS,
    WARNING,
)
from dreadnode.app.tui.turn_reducer import (
    ToolRun,
    TurnState,
    reduce_event,
    reduce_human_prompt_response,
)
from dreadnode.app.tui.widgets import (
    ConversationView,
    Flash,
    MentionOverlay,
    MessageQueue,
    PermissionPrompt,
    SlashOverlay,
    StreamingDraft,
    ToolProgress,
    TranscriptEntry,
    Welcome,
    render_help,
)
from dreadnode.app.tui.widgets.agent_dialog import AgentDialog
from dreadnode.app.tui.widgets.composer import ComposerInput
from dreadnode.app.tui.widgets.context_bar import ContextBar, PageStatus
from dreadnode.app.tui.widgets.skills_dialog import SkillsDialog
from dreadnode.app.tui.widgets.status_bar import StatusBar
from dreadnode.app.tui.widgets.tools_dialog import ToolsDialog
from dreadnode.core.log import (
    enable_tui_capture,
    install_stdlib_intercept,
    log_buffer,
)


@dataclass(slots=True)
class SessionRecord:
    """UI-side cache for one runtime session."""

    info: SessionInfo
    model: str
    transcript: list[TranscriptEntry] = field(default_factory=list)
    title: str | None = None


_MAX_HISTORY = 500
_HISTORY_FILE = Path.home() / ".dreadnode" / "prompt-history.jsonl"
_ERROR_PREFIX_PATTERN = re.compile(
    r"^(?:litellm\.)?(?P<error_type>[A-Za-z_][\w]*)\s*:\s*(?P<message>.+)$"
)
_PROXY_UNREACHABLE_MESSAGE = (
    "Cannot reach Dreadnode model proxy. Check your connection or switch to a BYOK model."
)
_DN_LOGIN_MESSAGE = "Sign in to use dn/ models — run /login"
_DN_KEY_EXPIRED_MESSAGE = "Dreadnode model key expired — re-authenticating..."
_PLATFORM_MODELS_UNAVAILABLE_MESSAGE = "Platform-hosted models are not available"
_MODEL_NOT_FOUND_PATTERN = re.compile(r"model\s+.+\s+not\s+found|model_not_found", re.IGNORECASE)
_PROXY_UNREACHABLE_SNIPPETS = (
    "connection error",
    "connecterror",
    "connection timeout",
    "connect timeout",
    "timed out",
    "name or service not known",
    "temporary failure in name resolution",
    "getaddrinfo failed",
    "nodename nor servname",
    "failed to establish a new connection",
    "max retries exceeded",
)
_DREADNODE_LLM_BASE_ENV = "DREADNODE_LLM_BASE"
_DREADNODE_LLM_API_KEY_ENV = "DREADNODE_LLM_API_KEY"
_LITELLM_REFRESH_WINDOW = timedelta(minutes=5)


def _enrich_error_body(
    body: str,
    error_type: str | None,
    status_code: int | None = None,
) -> str:
    """Append error type or HTTP status to the error body for user context."""
    if status_code is not None:
        return f"{body} (HTTP {status_code})"
    if error_type:
        return f"{body} ({error_type})"
    return body


def _classify_error_message(
    error_text: str | None,
    error_type: str | None,
) -> tuple[str | None, str | None, bool]:
    if not error_text:
        return (None, error_type, False)
    match = _ERROR_PREFIX_PATTERN.match(error_text)
    inferred_type = None
    cleaned = error_text
    if match:
        inferred_type = match.group("error_type")
        cleaned = match.group("message")
    resolved_type = error_type or inferred_type
    return (cleaned, resolved_type, resolved_type == "AuthenticationError")


def _split_missing_api_key_message(error_text: str) -> tuple[str, str] | None:
    parts = error_text.split(" — ", 1)
    if len(parts) != 2:
        return None
    title = parts[0].strip()
    if title.lower() != "missing api key":
        return None
    return (title, parts[1].strip())


def _is_missing_proxy_config_error(error_text: str) -> bool:
    return error_text.strip().lower().startswith("missing proxy configuration")


def _is_proxy_unreachable_error(error_text: str, error_type: str | None = None) -> bool:
    lowered = error_text.lower()
    if error_type in {"APIConnectionError", "ConnectionError", "ConnectError", "TimeoutError"}:
        return True
    return any(snippet in lowered for snippet in _PROXY_UNREACHABLE_SNIPPETS)


def _is_key_expired_error(error_text: str, error_type: str | None = None) -> bool:
    lowered = error_text.lower()
    if error_type and error_type != "AuthenticationError":
        return False
    if "401" in error_text or "403" in error_text:
        return True
    return any(token in lowered for token in ("expired", "invalid api key", "key expired"))


def _is_model_not_found_error(error_text: str, error_type: str | None = None) -> bool:
    if error_type in {"NotFoundError", "ModelNotFoundError"}:
        return True
    return bool(_MODEL_NOT_FOUND_PATTERN.search(error_text))


class DreadnodeTextualApp(App[None]):
    """Server-first Textual frontend for the Dreadnode runtime."""

    CSS_PATH = "dreadnode.tcss"
    ENABLE_COMMAND_PALETTE = False

    BINDINGS: t.ClassVar[list[Binding]] = [
        Binding("ctrl+b", "open_sessions", "Sessions", show=False),
        Binding("ctrl+w", "open_workspaces", "Workspaces", show=False),
        Binding("ctrl+o", "toggle_output_mode", "Output", show=False),
        Binding("ctrl+p", "open_capabilities", "Caps", show=False),
        Binding("ctrl+r", "open_runtimes", "Runs", show=False),
        Binding("ctrl+t", "open_traces", "Traces", show=False),
        Binding("ctrl+e", "open_evaluations", "Evals", show=False),
        Binding("f5", "open_console", "Console", show=False),
        Binding("ctrl+a", "select_agent", "Agent", show=False),
        Binding("f9", "run_update", "Update", show=False),
        Binding("ctrl+k", "select_model", "Model", show=False),
        Binding("ctrl+shift+k", "cycle_effort", "Effort", show=False),
        Binding("ctrl+n", "new_session", "New", show=False),
        Binding("ctrl+c", "request_quit", "Quit", show=False),
        Binding("tab", "cycle_focus", "Focus", show=False),
        Binding("escape", "handle_escape", "Escape", show=False),
    ]

    # -- Reactives bound to widgets via data_bind --
    status_text: reactive[str] = reactive("Booting")
    session_label: reactive[str] = reactive("none")
    busy: reactive[bool] = reactive(False)
    authenticated: reactive[bool] = reactive(False)
    agent_name: reactive[str] = reactive("default")
    working_dir: reactive[str] = reactive("")
    connection: reactive[str] = reactive("local")
    runtime_connected: reactive[bool] = reactive(False)
    total_tokens: reactive[int] = reactive(0)
    model_max_tokens: reactive[int] = reactive(0)
    workspace_label: reactive[str] = reactive("")
    model_name: reactive[str] = reactive("")
    effort_label: reactive[str] = reactive("")
    runtime_health: reactive[tuple[tuple[str, str, str, str], ...]] = reactive(())
    update_available: reactive[str] = reactive("")
    remote_info: reactive[str] = reactive("")
    output_mode: reactive[str] = reactive("compact")

    def watch_model_name(self, value: str) -> None:
        """Update model_max_tokens when the active model changes."""
        from dreadnode.app.tui.model_variants import get_model_max_input_tokens

        self.model_max_tokens = get_model_max_input_tokens(value) or 0

    def __init__(
        self,
        server_url: str | None = None,
        platform_url: str | None = None,
        resume_session_id: str | None = None,
        initial_model: str | None = None,
        initial_agent: str | None = None,
        initial_prompt: str | None = None,
        capabilities_dirs: list[str] | None = None,
        capabilities: list[str] | None = None,
        system_prompt: str | None = None,
    ) -> None:
        super().__init__()
        self.scroll_sensitivity_y = 5
        self.server_url = server_url
        self._platform_override = platform_url
        self._resume_session_id = resume_session_id
        self._initial_agent = initial_agent
        self._initial_prompt = initial_prompt
        self.model: str = initial_model or self._default_model_from_active_profile()
        from dreadnode.app.tui.connection import RuntimeConnectionManager

        self._connection_manager = RuntimeConnectionManager(
            local_client=RuntimeServerClient(
                server_url=server_url,
                auto_start=server_url is None,
                capability_dirs=capabilities_dirs,
                enabled_capabilities=capabilities,
                system_prompt_append=system_prompt,
            ),
            on_stash_state=self._stash_session_state,
            on_restore_state=self._restore_session_state,
            on_after_connect=self._on_remote_connected,
            on_after_disconnect=self._on_remote_disconnected,
        )
        self.runtime_info: RuntimeInfo | None = None
        self.sessions: dict[str, SessionRecord] = {}
        self.active_session_id: str | None = None
        self._draft_active = False
        self._turn_state: dict[str, TurnState] = {}
        self._tool_call_widgets: dict[str, t.Any] = {}
        self._last_auth_error: dict[str, str] = {}
        # Apply sane default thinking effort for the initial model
        from dreadnode.app.tui.model_variants import default_effort

        _initial_effort = default_effort(self.model)
        self.thinking_enabled: bool = _initial_effort is not None
        # Per-model variant state: model_id → effort label (e.g. "high")
        # Empty string means user explicitly disabled thinking for that model.
        self._model_variants: dict[str, str] = {}
        if _initial_effort:
            self._model_variants[self.model] = _initial_effort
            self.effort_label = _initial_effort
        self._show_thinking: bool = True  # Expanded by default
        self._inline_activity_sessions: set[str] = set()

        # Prompt history
        self._prompt_history: list[str] = []
        self._history_index: int = -1
        self._history_stash: str = ""

        # Turn counting for separators
        self._turn_counts: dict[str, int] = {}

        # Message queue (per-session)
        self._pending_messages: dict[str, list[str]] = {}

        # Permission tracking
        self._session_allowlist: dict[str, set[str]] = {}

        # Platform model + LiteLLM proxy state
        self._platform_models: list[dict[str, t.Any]] = []
        self._litellm_key_expires_at: datetime | None = None

        # Double-tap tracking for quit (shared by Escape and Ctrl+C)
        self._last_quit_time: float = 0.0

        # Update check state
        self._update_check_done: bool = False

        # Skill names for slash overlay and command dispatch: set of (name, description)
        self._skill_names: set[tuple[str, str]] = set()

        # Load persistent prompt history
        self._load_prompt_history()

        # Sync model name to status bar
        self.model_name = self.model

        # Make unrecognised syntax tokens (Token.Error) render as plain text
        # instead of alarming red — Pygments often misclassifies unlabelled blocks.
        from pygments.token import Token
        from textual.highlight import HighlightTheme

        HighlightTheme.STYLES[Token.Error] = "$text 80%"

        self.register_theme(
            Theme(
                name="dreadnode",
                primary=BRAND,
                secondary=SUCCESS,
                accent=INFO,
                warning=WARNING,
                error=ERROR,
                success=SUCCESS,
                dark=True,
                background=BG,
                surface=BG,
                panel=BG,
                variables={
                    # Calm markdown headers — avoid primary orange bleeding in
                    "markdown-h1-color": FG,
                    "markdown-h1-text-style": "bold",
                    "markdown-h2-color": FG,
                    "markdown-h2-text-style": "bold",
                    "markdown-h3-color": FG_SUBTLE,
                    "markdown-h3-text-style": "bold",
                    "markdown-h4-color": FG_SUBTLE,
                    "markdown-h4-text-style": "bold",
                    "markdown-h5-color": FG_MUTED,
                    "markdown-h5-text-style": "bold",
                    "markdown-h6-color": FG_MUTED,
                    "markdown-h6-text-style": "bold",
                },
            )
        )
        self.theme = "dreadnode"

    @property
    def server_client(self) -> RuntimeServerClient:
        """Active runtime client — follows local/remote switching."""
        return self._connection_manager.active_client

    @property
    def generate_params_extra(self) -> dict[str, t.Any]:
        """Build generate_params_extra from current thinking/effort settings."""
        if not self.thinking_enabled or not self.effort_label:
            return {}
        from dreadnode.app.tui.model_variants import get_variants

        variants = get_variants(self.model)
        if self.effort_label in variants:
            return dict(variants[self.effort_label])
        return {}

    # ==================================================================
    # Compose
    # ==================================================================

    def compose(self) -> ComposeResult:
        with Vertical(id="main-body"):
            yield self._build_welcome()
            yield ConversationView(
                id="conversation",
            )
            yield ToolProgress(id="tool-progress")
            yield PermissionPrompt(id="human-prompt")
            yield SlashOverlay(id="slash-overlay")
            yield MentionOverlay(id="mention-overlay")
            yield ModelPickerOverlay(id="model-picker-overlay")
            yield AgentDialog(id="agent-dialog")
            yield SkillsDialog(id="skills-dialog")
            yield ToolsDialog(id="tools-dialog")
            yield Flash(id="flash")
            yield MessageQueue(id="message-queue")
            yield self._build_context_bar()  # Zone 1
            yield Horizontal(  # Zone 2
                Static("> ", id="prompt-char"),
                ComposerInput(id="composer"),
                id="composer-bar",
            )
            yield self._build_page_status()  # Zone 3
        yield self._build_status_bar()  # Zone 4

    def _build_welcome(self) -> Welcome:
        try:
            from dreadnode.version import VERSION
        except Exception:
            logger.opt(exception=True).debug("Could not import VERSION")
            version = ""
        else:
            version = f"v{VERSION}"
        welcome = Welcome(id="welcome")
        welcome.version = version
        welcome.working_dir = str(Path.cwd())
        return welcome

    def _build_context_bar(self) -> ContextBar:
        bar = ContextBar(id="context-bar")
        bar.data_bind(
            agent_name=DreadnodeTextualApp.agent_name,
            model_name=DreadnodeTextualApp.model_name,
            effort_label=DreadnodeTextualApp.effort_label,
            busy=DreadnodeTextualApp.busy,
            status_text=DreadnodeTextualApp.status_text,
            output_mode=DreadnodeTextualApp.output_mode,
        )
        return bar

    def _build_page_status(self) -> PageStatus:
        status = PageStatus(id="page-status")
        status.data_bind(
            total_tokens=DreadnodeTextualApp.total_tokens,
            model_max_tokens=DreadnodeTextualApp.model_max_tokens,
            runtime_issues=DreadnodeTextualApp.runtime_health,
        )
        return status

    def _build_status_bar(self) -> StatusBar:
        bar = StatusBar(id="status-bar")
        bar.data_bind(
            connection=DreadnodeTextualApp.connection,
            runtime_connected=DreadnodeTextualApp.runtime_connected,
            workspace_label=DreadnodeTextualApp.workspace_label,
            update_available=DreadnodeTextualApp.update_available,
            remote_info=DreadnodeTextualApp.remote_info,
        )
        return bar

    # ==================================================================
    # Watchers
    # ==================================================================

    def watch_authenticated(self, value: bool) -> None:
        try:
            from textual.app import ScreenStackError
            from textual.css.query import NoMatches

            composer = self.query_one("#composer", ComposerInput)
        except (NoMatches, ScreenStackError):
            logger.debug("watch_authenticated: composer not found in DOM")
            return
        composer.disabled = not value
        try:
            composer_bar = self.query_one("#composer-bar")
            composer_bar.set_class(not value, "-disabled")
        except (NoMatches, ScreenStackError):
            logger.opt(exception=True).debug("Composer bar update failed")
        if value:
            composer.focus()

    # ==================================================================
    # Lifecycle
    # ==================================================================

    def on_mount(self) -> None:
        enable_tui_capture()
        install_stdlib_intercept()
        self._set_composer_enabled(False)
        # Hide conversation while welcome is showing
        self.query_one("#conversation", ConversationView).display = False
        self._sync_conversation()
        self._sync_sessions()
        self._update_context()
        self._boot()
        self._check_for_update()

    async def on_unmount(self) -> None:
        await self._connection_manager.close()

    # ==================================================================
    # Input handling (using @on for explicit event binding)
    # ==================================================================

    @on(TextArea.Changed, "#composer")
    def _on_composer_changed(self, event: TextArea.Changed) -> None:
        slash_overlay = self.query_one("#slash-overlay", SlashOverlay)
        mention_overlay = self.query_one("#mention-overlay", MentionOverlay)
        skills_dialog = self.query_one("#skills-dialog", SkillsDialog)
        value = event.text_area.text

        if self._active_human_prompt() is not None:
            slash_overlay.hide()
            mention_overlay.hide()
            return

        # Skills browse mode: dialog is open, typing filters it
        if skills_dialog.is_visible:
            skills_dialog.filter(value)
            return

        # Slash commands: /foo
        if value.startswith("/") and " " not in value:
            mention_overlay.hide()
            skill_commands = [
                SlashCommand(f"/{name}", desc) for name, desc in sorted(self._skill_names)
            ]
            slash_overlay.filter_commands(value, extra_commands=skill_commands)
            return

        # @ mentions: show agents from capabilities
        at_match = re.search(r"@(\S*)$", value)
        if at_match:
            slash_overlay.hide()
            mention_overlay.filter(at_match.group(1))
            return

        slash_overlay.hide()
        mention_overlay.hide()

    @on(ComposerInput.Submitted)
    def _on_composer_submitted(self, event: ComposerInput.Submitted) -> None:
        value = event.value
        logger.debug(
            "Composer submitted | length={} | has_session={}",
            len(value),
            self.active_session_id is not None,
        )
        self.query_one("#slash-overlay", SlashOverlay).hide()
        self.query_one("#mention-overlay", MentionOverlay).hide()
        self._dismiss_welcome()

        if not value:
            return

        prompt = self._active_human_prompt()
        if prompt is not None:
            self._submit_human_prompt_response(prompt, value)
            return

        # Slash commands always execute immediately (never queued)
        if value.startswith("/"):
            self._handle_command(value)
            return

        # Shell commands always execute immediately
        if value.startswith("!"):
            shell_cmd = value[1:].strip()
            if shell_cmd:
                self._execute_shell(shell_cmd)
            return

        # Bare exit/quit commands (matches OpenCode behavior)
        if value.strip().lower() in {"exit", "quit", ":q"}:
            self.exit()
            return

        # Store in history (in-memory + persistent file)
        if value and (not self._prompt_history or self._prompt_history[-1] != value):
            self._prompt_history.append(value)
            if len(self._prompt_history) > _MAX_HISTORY:
                self._prompt_history.pop(0)
            self._save_prompt_entry(value)
        self._history_index = -1

        # If busy, queue the message instead of sending
        if self.busy:
            self._enqueue_message(value)
            return

        if at_match := re.match(r"^@(\S+)\s+([\s\S]+)$", value):
            self._send_chat_to_agent(at_match.group(2), at_match.group(1))
        else:
            # Show user message + thinking indicator immediately (before @work schedules)
            # so the first render frame already shows the conversation with user input.
            # For new sessions (no active session yet), we still show thinking state
            # immediately so the UI feels responsive during session creation.
            session = self._active_session()
            conv = self.query_one("#conversation", ConversationView)
            if session is not None:
                sid = session.info.session_id
                self._turn_counts.setdefault(sid, 0)
                self._turn_counts[sid] += 1
                entry = TranscriptEntry(
                    kind="user", title="user", body=value, turn=self._turn_counts[sid]
                )
                record = self.sessions.get(sid)
                if record is not None:
                    record.transcript.append(entry)
                conv.append_entry(entry)
            self._set_status("Thinking", busy=True)
            self.query_one("#tool-progress", ToolProgress).show_activity("thinking")
            self._send_chat(value, _user_entry_shown=session is not None)

    def _submit_human_prompt_response(self, prompt: HumanPrompt, raw_value: str) -> None:
        """Handle composer submission while a human prompt is active."""
        value = raw_value.strip()
        if not value:
            return

        action = "submit"
        text: str | None = value
        selected_option: str | None = None

        if prompt.kind == "approval":
            lowered = value.lower()
            if lowered in {"allow_session", "allow session", "session"}:
                action = "allow_session"
                text = None
            elif lowered in {"deny", "no", "n"}:
                action = "deny"
                text = None
            elif lowered in {"allow", "approve", "yes", "y"}:
                action = "approve"
                text = None
            else:
                action = "deny"
                text = None

        if prompt.kind in {"input", "choice"} and prompt.options:
            matched = self._match_prompt_option(prompt.options, value)
            if matched is not None:
                selected_option = matched
                text = None
            elif not prompt.allow_free_text:
                self._flash("Please select a valid option", severity="warning")
                return

        sid = self.active_session_id
        if sid:
            self._append_transcript(
                TranscriptEntry(kind="user", title="user", body=value),
                sid,
            )
            status_body = "Prompt response sent"
            if action in {"cancel", "deny"}:
                status_body = "Prompt cancelled"
            elif action in {"approve", "allow_session"}:
                status_body = "Prompt approved"
            self._append_transcript(
                TranscriptEntry(kind="system", title="system", body=status_body),
                sid,
            )

        self.query_one("#human-prompt", PermissionPrompt).hide_prompt()
        self.query_one("#composer", ComposerInput).placeholder = ""

        self._send_human_input_response(
            prompt.request_id,
            action,
            text=text,
            selected_option=selected_option,
            tool_name=prompt.source_tool_name,
        )

    @staticmethod
    def _match_prompt_option(options: list[HumanPromptOption], value: str) -> str | None:
        value = value.strip()
        if not value:
            return None
        if value.isdigit():
            idx = int(value) - 1
            if 0 <= idx < len(options):
                return options[idx].label
        lowered = value.lower()
        for option in options:
            if option.label.lower() == lowered:
                return option.label
        return None

    @on(ComposerInput.HelpRequested)
    def _on_help_requested(self) -> None:
        """Show help inline when ? is pressed in empty composer."""
        self._show_help()

    def on_key(self, event: Key) -> None:
        """Global key routing for history and vim-style navigation."""
        # Only handle keys on the main screen where composer/conversation exist
        composer_results = self.screen.query(ComposerInput)
        conversation_results = self.screen.query(ConversationView)
        if not len(composer_results) or not len(conversation_results):
            return
        composer = composer_results.first()
        conversation = conversation_results.first()

        # ? shows help when conversation is focused (composer handled via HelpRequested)
        if event.key == "question_mark" and conversation.has_focus:
            event.prevent_default()
            event.stop()
            self._show_help()
            return

        # Prompt history & queue retract: Up when cursor is on first line
        if event.key == "up" and composer.has_focus:
            on_first_line = not self._has_active_overlay() and composer.cursor_location[0] == 0
            if on_first_line and not composer.text and self._has_queued_messages():
                event.prevent_default()
                message = self._retract_last_queued()
                if message:
                    self._set_composer_text(composer, message)
                return
            if on_first_line:
                event.prevent_default()
                self._history_navigate(-1)
                return

        if event.key == "down" and composer.has_focus:
            last_row = len(composer.document.lines) - 1
            if not self._has_active_overlay() and composer.cursor_location[0] >= last_row:
                event.prevent_default()
                self._history_navigate(1)
                return

        # Vim-like navigation when conversation is focused
        if conversation.has_focus:
            if event.key == "j":
                event.prevent_default()
                conversation.scroll_down(animate=False)
                return
            if event.key == "k":
                event.prevent_default()
                conversation.scroll_up(animate=False)
                return
            if event.key == "g":
                event.prevent_default()
                conversation.scroll_home(animate=False)
                return
            if event.key == "G":
                event.prevent_default()
                conversation.scroll_end(animate=False)
                return
            if event.key == "ctrl+u":
                event.prevent_default()
                conversation.scroll_up(animate=False)
                conversation.scroll_up(animate=False)
                conversation.scroll_up(animate=False)
                return
            if event.key == "ctrl+d":
                event.prevent_default()
                conversation.scroll_down(animate=False)
                conversation.scroll_down(animate=False)
                conversation.scroll_down(animate=False)
                return
            if event.key == "y":
                event.prevent_default()
                self._copy_last_assistant()
                return

    def _focus_composer_if_interactive(self) -> None:
        """Restore composer focus when input should accept typing."""
        composer = self.query_one("#composer", ComposerInput)
        if composer.disabled:
            return
        composer.focus()

    @on(events.Click, "#conversation")
    def _on_conversation_clicked(self, _event: events.Click) -> None:
        """Clicks in the chat area should return typing focus to the composer."""
        if self._has_active_overlay():
            return
        self._focus_composer_if_interactive()

    def _has_active_overlay(self) -> bool:
        """Check if any overlay (slash/mention/model/agent/tools) is currently visible."""
        slash = self.query_one("#slash-overlay", SlashOverlay)
        mention = self.query_one("#mention-overlay", MentionOverlay)
        picker = self.query_one("#model-picker-overlay", ModelPickerOverlay)
        agent = self.query_one("#agent-dialog", AgentDialog)
        skills = self.query_one("#skills-dialog", SkillsDialog)
        tools = self.query_one("#tools-dialog", ToolsDialog)
        return (
            slash.is_visible
            or mention.is_visible
            or picker.is_visible
            or agent.is_visible
            or skills.is_visible
            or tools.is_visible
        )

    @on(SlashOverlay.SlashSelected)
    def _on_slash_selected(self, event: SlashOverlay.SlashSelected) -> None:
        composer = self.query_one("#composer", ComposerInput)
        from dreadnode.app.tui.commands import SLASH_COMMANDS

        cmd_def = next((c for c in SLASH_COMMANDS if c.name == event.command), None)
        # Builtins without a hint and all skills take no args — execute immediately
        is_skill = cmd_def is None and any(
            name == event.command.lstrip("/") for name, _ in self._skill_names
        )
        if is_skill or (cmd_def and not cmd_def.hint):
            composer.load_text("")
            self._handle_command(event.command)
            return
        text = event.command + " "
        composer.load_text(text)
        composer.move_cursor_relative(rows=0, columns=len(text))
        composer.focus()

    @on(MentionOverlay.AgentSelected)
    def _on_agent_mentioned(self, event: MentionOverlay.AgentSelected) -> None:
        composer = self.query_one("#composer", ComposerInput)
        # Replace the @prefix at the end with the selected agent name
        current = composer.value
        at_match = re.search(r"@\S*$", current)
        if at_match:
            before = current[: at_match.start()]
            text = f"{before}@{event.agent_name} "
        else:
            text = f"{current}@{event.agent_name} "
        composer.load_text(text)
        composer.move_cursor_relative(rows=0, columns=len(text))
        composer.focus()

    @on(PermissionPrompt.Action)
    def _on_human_prompt_action(self, event: PermissionPrompt.Action) -> None:
        self._send_human_input_response(event.request_id, event.action)

    # ==================================================================
    # Actions (keybindings)
    # ==================================================================

    def action_open_sessions(self) -> None:
        if self._is_screen_open(SessionPickerScreen):
            return
        self._dismiss_pushed_screens()
        logger.debug("Screen push | screen=SessionPickerScreen")
        self.push_screen(
            SessionPickerScreen(
                sessions=dict(self.sessions),
                active_session_id=self.active_session_id,
            ),
            callback=self._on_session_picked,
        )

    def _on_session_picked(self, result: str | None) -> None:
        if result is None:
            return

        # Parse deletes prefix: "__deletes__:id1,id2" or "__deletes__:id1,id2|action"
        delete_ids: list[str] = []
        action: str | None = None
        if result.startswith("__deletes__:"):
            payload = result[len("__deletes__:") :]
            if "|" in payload:
                deletes_part, action = payload.split("|", 1)
            else:
                deletes_part = payload
            delete_ids = [sid for sid in deletes_part.split(",") if sid]
        else:
            action = result

        self._apply_session_picker_result(delete_ids, action)

    @work(exclusive=True, group="session")
    async def _apply_session_picker_result(self, delete_ids: list[str], action: str | None) -> None:
        """Process all deletes and then the selected action from the session picker."""
        for sid in delete_ids:
            try:
                await self.server_client.delete_session(sid)
            except Exception:
                logger.opt(exception=True).warning("Session delete failed | session={}", sid[:8])
            self.sessions.pop(sid, None)
            self._pending_messages.pop(sid, None)

        if action == "__new__":
            self._dismiss_welcome()
            await self.__create_new_session()
            return

        if action and action in self.sessions:
            # Inline the switch logic — cannot call _switch_session here
            # because it's also @work(exclusive=True, group="session").
            session_id = action
            self._dismiss_welcome()
            if self.active_session_id is not None:
                self._inline_activity_sessions.discard(self.active_session_id)
            self.active_session_id = session_id
            self._turn_state.setdefault(session_id, TurnState.empty(session_id))
            restored_model = self.sessions[session_id].model
            if restored_model != self.model:
                self._on_model_changed(restored_model)
            self.total_tokens = 0
            session = self.sessions.get(session_id)
            if session and not session.transcript and session.info.message_count > 0:
                await self._rebuild_transcript_from_server(session)
            else:
                self._sync_conversation()
            self.query_one("#draft", StreamingDraft).clear_stream()
            self._draft_active = False
            self._sync_sessions()
            self._sync_queue()
            self._update_context()
            self._write_activity(f"Switched to session {session_id[:8]}", style="info")
            return

        # Deletes-only (Escape) — ensure we still have a valid active session
        if delete_ids and self.active_session_id not in self.sessions:
            self.active_session_id = next(iter(self.sessions), None) if self.sessions else None
            if self.active_session_id is None:
                await self.__create_new_session()
                return
            restored_model = self.sessions[self.active_session_id].model
            if restored_model != self.model:
                self._on_model_changed(restored_model)
            self._sync_conversation()
            self._sync_queue()
            self._update_context()

    def action_new_session(self) -> None:
        self._create_new_session()

    def action_select_model(self) -> None:
        """Toggle model picker overlay."""
        self._open_model_picker()

    def _open_model_picker(self) -> None:
        """Show the inline model picker overlay."""
        from dreadnode.app.tui.model_variants import KNOWN_MODELS

        overlay = self.query_one("#model-picker-overlay", ModelPickerOverlay)
        if overlay.is_visible:
            overlay.hide()
            return

        platform_models = list(self._platform_models)
        models = list(KNOWN_MODELS)
        if self.model not in models and not self.model.startswith("dn/"):
            models.insert(0, self.model)
        overlay.show_models(models, self.model, platform_models=platform_models)

    @on(ModelPickerOverlay.ModelSelected)
    def _on_model_picker_selected(self, event: ModelPickerOverlay.ModelSelected) -> None:
        if event.model_id != self.model:
            self._on_model_changed(event.model_id)
            self._run_command(self._persist_default_model_choice, event.model_id)
            self._flash(f"Model: {event.model_id}", severity="info")

    def action_select_agent(self) -> None:
        """Toggle agent picker dialog."""
        dialog = self.query_one("#agent-dialog", AgentDialog)
        if dialog.is_visible:
            dialog.hide()
            return
        if not self.runtime_info:
            self._flash("No runtime info available", severity="warning")
            return
        dialog.show_agents(self._collect_agents(), current=self.agent_name)

    @on(AgentDialog.AgentSelected)
    def _on_agent_dialog_selected(self, event: AgentDialog.AgentSelected) -> None:
        if event.agent_name != self.agent_name:
            self._start_agent_session(event.agent_name)
            self._flash(f"Agent: {event.agent_name}", severity="info")

    def _open_mcp_screen(self) -> None:
        """Push MCP server management screen."""
        if self._is_screen_open(McpScreen):
            return
        servers = self._collect_mcp_servers()
        self._dismiss_pushed_screens()
        self.push_screen(McpScreen(runtime_client=self.server_client, servers=servers))

    def _open_theme_showcase(self) -> None:
        """Push hidden theme showcase screen."""
        from dreadnode.app.tui.screens.theme_showcase import ThemeShowcaseScreen

        if self._is_screen_open(ThemeShowcaseScreen):
            return
        self._dismiss_pushed_screens()
        self.push_screen(ThemeShowcaseScreen())

    def _collect_mcp_servers(self) -> list[dict[str, t.Any]]:
        """Extract MCP server info from runtime info components."""
        if not self.runtime_info:
            return []
        servers: list[dict[str, t.Any]] = []
        for cap in self.runtime_info.capabilities:
            for comp in cap.components or []:
                kind = comp.get("kind") if isinstance(comp, dict) else getattr(comp, "kind", None)
                if kind == "mcp_server":
                    _get = (
                        comp.get
                        if isinstance(comp, dict)
                        else lambda k, d=None, _comp=comp: getattr(_comp, k, d)
                    )
                    servers.append(
                        {
                            "name": _get("name", "?"),
                            "status": _get("status", "?"),
                            "error": _get("error"),
                            "detail": _get("detail"),
                            "qualified_name": _get("qualified_name"),
                            "capability": _get("capability") or cap.name,
                            "transport": _get("transport"),
                            "tool_count": _get("tool_count", 0),
                        }
                    )
        return servers

    def _collect_component_issues(self) -> list[dict[str, str | None]]:
        """Extract all component health issues from runtime info."""
        if not self.runtime_info:
            return []
        issues: list[dict[str, str | None]] = []
        for cap in self.runtime_info.capabilities:
            for comp in cap.components or []:
                _get = (
                    comp.get
                    if isinstance(comp, dict)
                    else lambda k, d=None, _comp=comp: getattr(_comp, k, d)
                )
                status = _get("status", "ok")
                if status in ("error", "degraded"):
                    issues.append(
                        {
                            "name": _get("name", "?"),
                            "kind": _get("kind", "?"),
                            "status": status,
                            "error": _get("error"),
                            "detail": _get("detail"),
                        }
                    )
        return issues

    def _update_runtime_health(self) -> None:
        """Compute runtime_health issue groups for Zone 3 (PageStatus)."""
        issues = self._collect_component_issues()

        def _summarize(items: list[dict[str, str | None]], max_names: int = 2) -> str:
            names = ", ".join(str(i.get("name", "?")) for i in items[:max_names])
            if len(items) > max_names:
                names += f" +{len(items) - max_names}"
            return names

        mcp_issues = [i for i in issues if i.get("kind") == "mcp_server"]
        other_issues = [i for i in issues if i.get("kind") != "mcp_server"]

        groups: list[tuple[str, str, str, str]] = []
        if mcp_issues:
            groups.append(("MCP", _summarize(mcp_issues), "/mcp", "error"))
        if other_issues:
            groups.append(("components", _summarize(other_issues), "/capabilities", "error"))

        # Include capability updates
        if self.runtime_info:
            updates = [cap for cap in self.runtime_info.capabilities if cap.update_available]
            if updates:
                names = ", ".join(cap.name for cap in updates[:2])
                if len(updates) > 2:
                    names += f" +{len(updates) - 2}"
                groups.append(("updates", names, "/capabilities", "update"))

        self.runtime_health = tuple(groups)

    def action_cycle_effort(self) -> None:
        """Cycle through thinking effort levels for the current model."""
        from dreadnode.app.tui.model_variants import cycle_variant, get_variants

        variants = get_variants(self.model)
        if not variants:
            return  # Silent no-op for unsupported models

        current = self.effort_label if self.thinking_enabled else None
        next_label = cycle_variant(variants, current)

        if next_label is None:
            # Cycling past max → disable (store "" to preserve user choice)
            self.thinking_enabled = False
            self._model_variants[self.model] = ""
            self.effort_label = ""
            self._flash("Thinking disabled", severity="info")
        else:
            self.thinking_enabled = True
            self._model_variants[self.model] = next_label
            self.effort_label = next_label
            self._flash(f"Thinking: {next_label}", severity="info")

    def _is_screen_open(self, screen_type: type) -> bool:
        """Check if a screen of the given type is anywhere in the stack."""
        return any(isinstance(s, screen_type) for s in self.screen_stack)

    def _dismiss_pushed_screens(self) -> None:
        """Pop all pushed screens so we return to the base screen before opening a new one."""
        while len(self.screen_stack) > 1:
            self.pop_screen()

    def action_open_console(self) -> None:
        if self._is_screen_open(ConsoleScreen):
            return
        self._dismiss_pushed_screens()
        logger.debug("Screen push | screen=ConsoleScreen")
        self.push_screen(ConsoleScreen(log_buffer))

    def action_open_traces(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("traces")

    def action_open_evaluations(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("evaluations")

    def action_open_runtimes(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("runtimes")

    def action_open_capabilities(self) -> None:
        self._open_capabilities_screen()

    def action_open_workspaces(self) -> None:
        if not self._require_authenticated():
            return
        self._open_workspaces_screen()

    def action_run_update(self) -> None:
        """Trigger /update via f9 keybinding."""
        self._run_command(self._update_command)

    def action_cycle_focus(self) -> None:
        """Cycle focus between composer and conversation."""
        composer = self.query_one("#composer", ComposerInput)
        conversation = self.query_one("#conversation", ConversationView)
        if composer.has_focus:
            conversation.focus()
        else:
            composer.focus()

    def action_request_quit(self) -> None:
        """Ctrl+C: interrupt if busy, then double-press to quit."""
        now = time.monotonic()

        # If busy, interrupt first
        if self.busy:
            if self._cancel_active_prompt():
                self._flash("Prompt cancelled", severity="warning")
                self._last_quit_time = now
                return
            self.workers.cancel_group(self, "session")
            self._cancel_server_turn()
            self._commit_draft_to_transcript(self.active_session_id or "")
            self._set_status("Interrupted", busy=False)
            self._set_composer_enabled(True)
            self.query_one("#composer", ComposerInput).focus()
            self._flash("Interrupted — press again to quit", severity="warning")
            self._last_quit_time = now
            return

        # Double-press to quit
        if (now - self._last_quit_time) < 3.0:
            self.exit()
            return

        self._last_quit_time = now
        self._flash("Press Ctrl+C again to quit", severity="warning")

    def action_handle_escape(self) -> None:
        """Escape priority: dismiss overlays → clear composer → retract queue → interrupt → quit."""
        composer = self.query_one("#composer", ComposerInput)

        # 1. Dismiss overlays if visible
        if self._has_active_overlay():
            self.query_one("#slash-overlay", SlashOverlay).hide()
            self.query_one("#mention-overlay", MentionOverlay).hide()
            self.query_one("#model-picker-overlay", ModelPickerOverlay).hide()
            self.query_one("#agent-dialog", AgentDialog).hide()
            self.query_one("#skills-dialog", SkillsDialog).hide()
            self.query_one("#tools-dialog", ToolsDialog).hide()
            return

        # 2. Clear composer if non-empty
        if composer.value:
            composer.clear_pastes()
            composer.value = ""
            return

        # 3. Retract queued message back into composer for editing
        if not self.busy and self._has_queued_messages():
            message = self._retract_last_queued()
            if message:
                composer.load_text(message)
                composer.move_cursor_relative(rows=9999, columns=9999)
            return

        # 4. Interrupt busy agent
        if self.busy:
            if self._cancel_active_prompt():
                self._flash("Prompt cancelled", severity="warning")
                return
            self.workers.cancel_group(self, "session")
            self._cancel_server_turn()
            self._commit_draft_to_transcript(self.active_session_id or "")
            self._set_status("Interrupted", busy=False)
            self._set_composer_enabled(True)
            composer.focus()
            self._flash("Interrupted", severity="warning")
            return

        # 5. Nothing to do — just ensure composer has focus
        composer.focus()

    def _cancel_server_turn(self) -> None:
        """Fire-and-forget: tell the server to cancel the active turn."""
        sid = self.active_session_id
        if not sid:
            return

        async def _do_cancel() -> None:
            try:
                await self.server_client.cancel_session(sid)
            except Exception:
                logger.debug("Server cancel request failed (session may already be idle)")

        asyncio.get_running_loop().create_task(_do_cancel())

    def _require_authenticated(self) -> bool:
        if not self.authenticated:
            self._flash(
                "Not authenticated — use /login to connect to the platform",
                severity="warning",
            )
            return False
        return True

    # ==================================================================
    # Boot & runtime
    # ==================================================================

    def _resolved_server_url(self) -> str:
        """Return resolved server URL: --platform > DREADNODE_SERVER > profile URL > default."""
        if self._platform_override:
            return self._platform_override
        env_override = os.environ.get("DREADNODE_SERVER")
        if env_override:
            return env_override
        try:
            _name, profile = _active_profile()
        except Exception:
            logger.opt(exception=True).debug("Failed to load active profile")
            profile = None
        if profile and profile.url:
            return profile.url
        return DEFAULT_PLATFORM_URL

    def _platform_override_url(self) -> str | None:
        """Return an explicit platform URL override, if set."""
        if self._platform_override:
            return self._platform_override
        env_override = os.environ.get("DREADNODE_SERVER")
        if env_override:
            return env_override
        return None

    def _profile_for_server_url(self, server_url: str) -> tuple[str | None, ServerConfig | None]:
        """Return the saved profile matching a server URL, preferring the active profile."""
        try:
            user_config = UserConfig.read(Path.home() / ".dreadnode" / "config.yaml")
        except Exception:
            logger.opt(exception=True).debug("Failed to read user config")
            return None, None
        # Prefer the active profile when multiple profiles share the same URL.
        active_name = user_config.active_profile_name
        if active_name:
            active = user_config.servers.get(active_name)
            if active and urls_match(active.url, server_url):
                return active_name, active
        for name, profile in user_config.servers.items():
            if urls_match(profile.url, server_url):
                return name, profile
        return None, None

    def _show_auth_modal(
        self,
        server_url: str | None = None,
        force_new_key: bool = False,
        reason: str | None = None,
    ) -> None:
        from dreadnode.version import VERSION

        # If the connection-error screen is up (retry succeeded but hit auth),
        # dismiss it before showing auth so it doesn't linger in the stack.
        self._dismiss_connection_error_screen()

        resolved_url = server_url or self._resolved_server_url()
        update_banner = (
            f"Update available: v{VERSION} \u2192 v{self.update_available} \u2014 press F9 to update now, or /update after login"
            if self.update_available
            else None
        )
        self.runtime_connected = True  # stop boot spinner — auth flow takes over
        logger.debug("Screen push | screen=AuthModal url={}", resolved_url)
        self.push_screen(
            AuthModal(
                resolved_url,
                force_new_key=force_new_key,
                reason=reason,
                update_banner=update_banner,
            ),
            callback=self._on_auth_complete,
        )

    def _on_auth_complete(self, result: ServerConfig | None) -> None:
        if result is None:
            self.exit()
            return
        self._run_command(self._apply_auth_profile, result)

    async def _apply_auth_profile(self, profile: ServerConfig) -> None:
        self._clear_platform_proxy_state()
        self.model = self._model_from_profile(profile)
        self.model_name = self.model
        # Update connection manager API context for keepalive
        if profile.default_organization and profile.default_workspace:
            api = ApiClient(profile.url, api_key=profile.api_key)
            self._connection_manager.set_api_context(
                api, profile.default_organization, profile.default_workspace
            )
        self._connection_manager.local_client.set_platform_profile(profile)

        if self._connection_manager.local_client.is_started:
            self._set_status("Restarting server", busy=True)
            await self._connection_manager.local_client.restart()
        else:
            self._set_status("Starting server", busy=True)
            await self._connection_manager.local_client.start()

        await self._refresh_runtime()
        await self._refresh_server_sessions()
        try:
            await self._refresh_platform_models_and_key(
                ApiClient(profile.url, api_key=profile.api_key)
            )
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        if self.active_session_id is None:
            await self.__create_new_session()
        self.authenticated = True
        self.runtime_connected = True
        self._write_activity(
            f"Connected as {profile.username or profile.user_key or 'user'}",
            style="success",
        )
        self._set_status("Ready", busy=False)
        self._set_composer_enabled(True)
        self.query_one("#composer", ComposerInput).focus()

    @work(exit_on_error=False)
    async def _check_for_update(self) -> None:
        """Background version check — never blocks boot."""
        try:
            from dreadnode.app.tui.update_check import check_for_update

            info = await check_for_update()
            if info:
                self.update_available = info.latest
                # Safe: Welcome stays in DOM after dismiss (hidden via CSS class, not removed)
                self.query_one("#welcome", Welcome).update_info = info
                # If auth modal is already showing, push update info into it
                self._try_update_auth_modal_banner(info)
        finally:
            self._update_check_done = True

    def _try_update_auth_modal_banner(self, info: UpdateInfo) -> None:
        """Push update banner into the auth modal if it's currently showing."""
        try:
            from dreadnode.app.tui.screens.auth import AuthModal
            from dreadnode.version import VERSION

            screen = self.screen
            if isinstance(screen, AuthModal):
                banner = f"Update available: v{VERSION} \u2192 v{info.latest} \u2014 press F9 to update now, or /update after login"
                screen.query_one("#auth-update-banner", Static).update(f"[bold yellow]{banner}[/]")
        except Exception:
            logger.opt(exception=True).debug("Failed to update auth modal banner")

    @work(exit_on_error=False)
    async def _boot(self) -> None:
        boot_t0 = time.monotonic()
        self._clear_platform_proxy_state()
        self._set_status("Starting runtime", busy=True)
        override_url = self._platform_override_url()
        if override_url:
            matched_name, profile = self._profile_for_server_url(override_url)
            if matched_name and profile:
                # Set matched profile as active so the rest of the app is consistent
                try:
                    config_path = Path.home() / ".dreadnode" / "config.yaml"
                    user_config = UserConfig.read(config_path)
                    if user_config.active != matched_name:
                        user_config.active = matched_name
                        user_config.write(config_path)
                        logger.info("Activated profile {!r} for {}", matched_name, override_url)
                except Exception:
                    logger.opt(exception=True).debug("Failed to update active profile")
        else:
            try:
                _name, profile = _active_profile()
            except Exception:
                logger.opt(exception=True).debug("Failed to load active profile")
                profile = None

        self.authenticated = False

        if override_url and profile is None:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal(override_url)
            return

        platform_profile: ServerConfig | None = None
        if (
            profile
            and profile.api_key
            and profile.default_organization
            and profile.default_workspace
        ):
            platform_profile = profile

        if platform_profile is None:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal()
            return

        masked = (
            platform_profile.api_key[:6] + "..." if len(platform_profile.api_key) > 6 else "***"
        )
        logger.info(
            "Boot: validating key {} against {} (org={}, workspace={})",
            masked,
            platform_profile.url,
            platform_profile.default_organization,
            platform_profile.default_workspace,
        )

        api = ApiClient(platform_profile.url, api_key=platform_profile.api_key)
        backoffs = [1.0, 2.0, 4.0]
        response: httpx.Response | None = None
        t0 = time.monotonic()
        for attempt in range(len(backoffs) + 1):
            try:
                response = await asyncio.to_thread(api._request, "GET", "/user")
            except httpx.RequestError as exc:
                logger.warning("Boot: connection attempt {} failed: {}", attempt + 1, exc)
                if attempt < len(backoffs):
                    await asyncio.sleep(backoffs[attempt])
                    continue
                logger.warning(
                    "Boot: cannot reach {} after {} attempts", platform_profile.url, attempt + 1
                )
                self._enter_connection_failed(
                    f"Unable to reach {platform_profile.url}",
                )
                return

            if response.status_code == 401:
                self._set_status("Authentication required", busy=False)
                logger.warning("Boot: API key rejected (401) by {}", platform_profile.url)
                self._show_auth_modal(reason="Your session has expired — please sign in again")
                return

            if response.is_success:
                logger.debug("Boot timing | validate_key={:.0f}ms", (time.monotonic() - t0) * 1000)
                break

            # Server error (5xx) — retry with backoff
            if response.status_code >= 500 and attempt < len(backoffs):
                await asyncio.sleep(backoffs[attempt])
                continue

            logger.warning(
                "Boot: server error ({}) from {}", response.status_code, platform_profile.url
            )
            self._enter_connection_failed(
                f"Server error ({response.status_code}) at {platform_profile.url}",
            )
            return

        org = platform_profile.default_organization
        workspace = platform_profile.default_workspace
        if not org or not workspace:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal(reason="Incomplete profile — please sign in again")
            return

        try:
            t0 = time.monotonic()
            await asyncio.to_thread(api.get_organization, org)
            workspaces = await asyncio.to_thread(api.list_workspaces, org)
            logger.debug(
                "Boot timing | validate_org_workspace={:.0f}ms", (time.monotonic() - t0) * 1000
            )
        except Exception as exc:
            self._set_status("Authentication required", busy=False)
            logger.warning("Boot: failed to validate org/workspace: {}", exc)
            self._show_auth_modal(reason="Could not verify your account — please sign in again")
            return

        if not any(getattr(ws, "key", None) == workspace for ws in workspaces):
            self._set_status("Authentication required", busy=False)
            logger.warning("Boot: workspace {!r} not found in org {!r}", workspace, org)
            self._show_auth_modal(reason="Workspace not found — please sign in again")
            return

        try:
            self._connection_manager.set_api_context(api, org, workspace)
            self._connection_manager.local_client.set_platform_profile(platform_profile)
            t0 = time.monotonic()
            await self._connection_manager.local_client.start()
            logger.debug("Boot timing | runtime_start={:.0f}ms", (time.monotonic() - t0) * 1000)
            t0 = time.monotonic()
            await self._refresh_runtime()
            logger.debug("Boot timing | refresh_runtime={:.0f}ms", (time.monotonic() - t0) * 1000)
            t0 = time.monotonic()
            await self._refresh_server_sessions()
            logger.debug("Boot timing | refresh_sessions={:.0f}ms", (time.monotonic() - t0) * 1000)
            try:
                t0 = time.monotonic()
                await self._refresh_platform_models_and_key(api)
                logger.debug(
                    "Boot timing | platform_models_and_key={:.0f}ms", (time.monotonic() - t0) * 1000
                )
            except AuthenticationError:
                self._handle_authentication_error("Session expired — please sign in again")
            # Resume a specific session if requested, otherwise start fresh.
            if self._resume_session_id:
                await self._resume_requested_session()
            else:
                self.active_session_id = None
                self._sync_conversation()
            self.authenticated = True
            self._refresh_skill_names()
            logger.info("Boot timing | total={:.0f}ms", (time.monotonic() - boot_t0) * 1000)
            self.runtime_connected = True
            # Dismiss the connection-error screen if it's still up (retry succeeded).
            self._dismiss_connection_error_screen()
            self._write_activity("Connected to Dreadnode runtime", style="success")
            self._set_status("Ready", busy=False)
            self._set_composer_enabled(True)
            self.query_one("#composer", ComposerInput).focus()
            # Apply CLI overrides: --agent and/or --prompt
            # Skipped when resuming — the resumed session already has an agent.
            initial_agent = self._initial_agent
            initial_prompt = self._initial_prompt
            self._initial_agent = None
            self._initial_prompt = None
            if not self._resume_session_id and (initial_agent or initial_prompt):
                # Validate agent name before creating a session
                if initial_agent:
                    available = {"default"} | {
                        a.name
                        for c in (self.runtime_info.capabilities if self.runtime_info else [])
                        for a in c.agents
                    }
                    if initial_agent not in available:
                        self._flash(f"Unknown agent: {initial_agent}", severity="warning")
                        initial_agent = None
                self._dismiss_welcome()
                agent_arg = (
                    None if (not initial_agent or initial_agent == "default") else initial_agent
                )
                await self.__create_new_session(agent=agent_arg)
                if initial_prompt:
                    self._send_chat(initial_prompt)
            elif self._resume_session_id and initial_prompt:
                # Send --prompt into the resumed session
                self._dismiss_welcome()
                self._send_chat(initial_prompt)
        except Exception as exc:
            self.authenticated = False
            self.runtime_connected = True
            self._write_activity(str(exc), style="error")
            self._flash(str(exc), severity="error")
            self._set_status("Connection failed", busy=False)
            self._set_composer_enabled(False)

    def _collect_agents(self) -> list[dict[str, str]]:
        """Build agent list from loaded capabilities, always including 'default'."""
        agents: list[dict[str, str]] = [
            {
                "name": "default",
                "description": "Default agent",
                "model": "inherit",
                "capability": "built-in",
            },
        ]
        seen = {"default"}
        if self.runtime_info:
            for cap in self.runtime_info.capabilities:
                for agent in cap.agents:
                    if agent.name not in seen:
                        agents.append(
                            {
                                "name": agent.name,
                                "description": agent.description or "",
                                "model": agent.model or "inherit",
                                "capability": cap.name,
                            }
                        )
                        seen.add(agent.name)
        return agents

    def _proxy_error_override(
        self,
        error_text: str | None,
        error_type: str | None,
    ) -> tuple[str | None, str | None, bool]:
        """Return (message override, flash message, reauth) for dn/ proxy errors."""
        if not error_text:
            return (None, None, False)
        if not self.model.startswith("dn/"):
            return (None, None, False)
        if _is_missing_proxy_config_error(error_text):
            return (_DN_LOGIN_MESSAGE, None, False)
        if _is_model_not_found_error(error_text, error_type):
            available = sorted(self._platform_model_ids())
            if available:
                message = "Model not available on proxy. Available models: " + ", ".join(available)
            else:
                message = "Model not available on proxy."
            return (message, None, False)
        if _is_proxy_unreachable_error(error_text, error_type):
            return (_PROXY_UNREACHABLE_MESSAGE, _PROXY_UNREACHABLE_MESSAGE, False)
        if _is_key_expired_error(error_text, error_type):
            return (_DN_KEY_EXPIRED_MESSAGE, _DN_KEY_EXPIRED_MESSAGE, True)
        return (None, None, False)

    async def _refresh_runtime(self) -> None:
        self.runtime_info = await self.server_client.fetch_runtime_info()
        logger.debug(
            "Runtime refresh | capabilities={}",
            len(self.runtime_info.capabilities) if self.runtime_info else 0,
        )
        self._update_runtime_health()
        self.query_one("#mention-overlay", MentionOverlay).set_agents(self._collect_agents())
        self.working_dir = self.runtime_info.working_dir or ""
        self._sync_sessions()
        self._update_context()

    async def _refresh_server_sessions(self) -> None:
        session_infos = await self.server_client.list_sessions()
        logger.debug("Sessions refresh | count={}", len(session_infos))
        refreshed: dict[str, SessionRecord] = {}
        for si in session_infos:
            record = self.sessions.get(si.session_id)
            if record is None:
                refreshed[si.session_id] = SessionRecord(info=si, model=self.model)
            else:
                transcript = record.transcript
                if si.message_count != len(transcript):
                    transcript = []
                refreshed[si.session_id] = SessionRecord(
                    info=si,
                    model=record.model,
                    transcript=transcript,
                    title=record.title,
                )
        self.sessions = refreshed
        self._turn_state = {
            sid: self._turn_state.get(sid, TurnState.empty(sid)) for sid in refreshed
        }
        if self.active_session_id not in self.sessions:
            self.active_session_id = next(iter(self.sessions), None)
        if self.active_session_id is not None:
            active_model = self.sessions[self.active_session_id].model
            if active_model != self.model:
                self._on_model_changed(active_model)
            # Load transcript from server if local cache is empty but session has history
            active = self.sessions[self.active_session_id]
            if not active.transcript and active.info.message_count > 0:
                await self._rebuild_transcript_from_server(active)
        self._sync_sessions()
        self._sync_conversation()
        self._update_context()

    # ==================================================================
    # Session management (all async methods use @work)
    # ==================================================================

    @work(exclusive=True, group="session")
    async def _create_new_session(self, agent: str | None = None) -> None:
        await self.__create_new_session(agent)

    async def __create_new_session(self, agent: str | None = None) -> None:
        """Inner implementation -- callable from both @work and plain await."""
        self._set_status("Creating session", busy=True)
        selected_agent = None if agent == "default" else agent
        logger.info("Session create | agent={} model={}", selected_agent or "default", self.model)
        session_info = await self.server_client.create_session(
            agent=selected_agent,
            model=self.model,
            generate_params_extra=self.generate_params_extra or None,
        )
        timestamp = datetime.now(UTC).astimezone().strftime("%Y-%m-%d %H:%M")
        title = f"Session {timestamp}"
        self.sessions[session_info.session_id] = SessionRecord(
            info=session_info,
            model=self.model,
            title=title,
        )
        logger.info(
            "Session created | session={} agent={}",
            session_info.session_id[:8],
            selected_agent or "default",
        )
        self.active_session_id = session_info.session_id
        self._turn_state[session_info.session_id] = TurnState.empty(session_info.session_id)
        self._inline_activity_sessions.discard(session_info.session_id)
        self._turn_counts[session_info.session_id] = 0

        self.total_tokens = 0
        self._sync_conversation()
        self.query_one("#draft", StreamingDraft).clear_stream()
        self._draft_active = False
        self._sync_sessions()
        self._update_context()
        self._set_status("Ready", busy=False)
        self._write_activity(
            (
                f"Started session {title} for agent {selected_agent}"
                if selected_agent
                else f"Started session {title} with default runtime"
            ),
            style="info",
        )

    @work(exclusive=True, group="session")
    async def _reset_active_session(self) -> None:
        session = self._active_session()
        if session is None:
            self._flash("No active session to reset", severity="warning")
            return
        logger.info("Session reset | session={}", session.info.session_id[:8])
        await self.server_client.reset_session(session.info.session_id)
        session.transcript.clear()
        session.info.message_count = 0
        self._turn_state[session.info.session_id] = TurnState.empty(session.info.session_id)
        self._inline_activity_sessions.discard(session.info.session_id)
        self._turn_counts.pop(session.info.session_id, None)
        self._pending_messages.pop(session.info.session_id, None)

        self._sync_conversation()
        self.query_one("#draft", StreamingDraft).clear_stream()
        self._draft_active = False
        self._sync_sessions()
        self._sync_queue()
        display = session.info.session_id[:8]
        self._flash(f"Reset session {display}", severity="info")
        self._write_activity(f"Reset session {display}", style="info")

    async def _update_command(self) -> None:
        """Handle /update — check for updates and run upgrade."""
        import asyncio

        from dreadnode.app.tui.update_check import (
            check_for_update,
            detect_upgrade_command,
            verify_upgrade,
        )

        # If no known update, re-check PyPI (user explicitly asked)
        if not self.update_available:
            self._flash("Checking for updates...", severity="info")
            logger.info("Update check: user requested /update, checking PyPI")
            info = await check_for_update()
            if info:
                self.update_available = info.latest
                logger.info("Update check: {} -> {} available", info.current, info.latest)
            else:
                self._flash("Already up to date", severity="info")
                logger.info("Update check: already up to date")
                return

        # Dismiss welcome so the activity messages are visible
        self._dismiss_welcome()

        cmd = detect_upgrade_command()
        cmd_display = " ".join(cmd) if isinstance(cmd, list) else cmd
        logger.info("Update: running {}", cmd_display)
        self._flash("Updating Dreadnode...", severity="info")

        try:
            if isinstance(cmd, list):
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
            else:
                proc = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
            stdout_bytes, stderr_bytes = await proc.communicate()
        except Exception as exc:
            logger.error("Update: subprocess failed: {}", exc)
            self._write_activity(f"Update failed: {exc}", style="error")
            self._flash("Update failed", severity="error")
            return

        stdout_text = stdout_bytes.decode(errors="replace").strip()
        stderr_text = stderr_bytes.decode(errors="replace").strip()

        if proc.returncode == 0:
            logger.info("Update: success (rc=0)\nstdout: {}\nstderr: {}", stdout_text, stderr_text)
            from rich.text import Text as RichText

            verified = await asyncio.to_thread(verify_upgrade, self.update_available)
            if verified:
                logger.info("Update: verified new version {}", verified)
                msg = RichText()
                msg.append("✓ ", style=f"bold {SUCCESS}")
                msg.append(f"Updated to v{verified}", style=f"bold {SUCCESS}")
                msg.append(" — restart ", style=FG_SUBTLE)
                msg.append("dn", style=f"bold {FG}")
                msg.append(" to use the new version", style=FG_SUBTLE)
                conv = self.query_one("#conversation", ConversationView)
                conv.write(RichText())  # spacer
                conv.write(msg)
                conv.write(RichText())  # spacer
                self._flash("Updated — restart dn to apply", severity="success")
                self.update_available = ""
                self.query_one("#welcome", Welcome).update_info = None
            else:
                logger.warning(
                    "Update: command succeeded but version not verified (expected {})",
                    self.update_available,
                )
                msg = RichText()
                msg.append("⚠ ", style=f"bold {WARNING}")
                msg.append(
                    "Update command succeeded but version unchanged", style=f"bold {WARNING}"
                )
                msg.append(
                    " — you may have multiple installations. Check which dn is on your PATH.",
                    style=FG_SUBTLE,
                )
                conv = self.query_one("#conversation", ConversationView)
                conv.write(RichText())  # spacer
                conv.write(msg)
                conv.write(RichText())  # spacer
                self._flash("Update may not have applied — see details above", severity="warning")
        else:
            logger.error(
                "Update: failed (rc={})\nstdout: {}\nstderr: {}",
                proc.returncode,
                stdout_text,
                stderr_text,
            )
            error_text = stderr_text or "Unknown error"
            from rich.text import Text as RichText

            msg = RichText()
            msg.append("✗ ", style=f"bold {ERROR}")
            msg.append("Update failed\n", style=f"bold {ERROR}")
            msg.append(error_text, style=FG_MUTED)
            conv = self.query_one("#conversation", ConversationView)
            conv.write(RichText())  # spacer
            conv.write(msg)
            conv.write(RichText())  # spacer
            self._flash("Update failed — see details above", severity="error")

    async def _compact_command(self, args: list[str] | None = None) -> None:
        """Handle /compact [guidance] command."""
        session = self._active_session()
        if session is None:
            self._flash("No active session", severity="warning")
            return
        guidance = " ".join(args) if args else ""
        logger.info(
            "Session compact | session={} guidance={}", session.info.session_id[:8], bool(guidance)
        )
        self._flash("Compacting conversation...", severity="info")
        try:
            result = await self.server_client.compact_session(
                session.info.session_id,
                guidance=guidance,
            )
        except Exception as exc:
            logger.warning(
                "Session compact failed | session={} error={}", session.info.session_id[:8], exc
            )
            self._flash(f"Compact failed: {exc}", severity="error")
            return
        status = result.get("status", "failed")
        if status == "completed":
            before = result.get("messages_before", 0)
            after = result.get("messages_after", 0)
            logger.info(
                "Session compact done | session={} before={} after={}",
                session.info.session_id[:8],
                before,
                after,
            )
            # Rebuild transcript from server-side compacted messages
            await self._rebuild_transcript_from_server(session)
            self._flash(f"Compacted: {before} → {after} messages", severity="success")
        elif status == "skipped":
            self._flash(f"Compact skipped: {result.get('reason', 'unknown')}", severity="info")
        else:
            self._flash(f"Compact failed: {result.get('reason', 'unknown')}", severity="error")

    async def _rebuild_transcript_from_server(self, session: SessionRecord) -> None:
        """Fetch current messages from server and rebuild the local transcript."""
        try:
            messages = await self.server_client.fetch_session_messages(
                session.info.session_id,
            )
        except Exception:
            logger.opt(exception=True).warning("Failed to fetch messages for transcript rebuild")
            self._flash("Could not load session history", severity="warning")
            return

        session.transcript = _transcript_from_messages(messages)
        self._sync_conversation()

    @work(exclusive=True, group="session")
    async def _switch_session(self, session_id: str) -> None:
        logger.info("Session switch | session={}", session_id[:8])
        self._dismiss_welcome()
        if self.active_session_id is not None:
            self._inline_activity_sessions.discard(self.active_session_id)
        self.active_session_id = session_id
        self._turn_state.setdefault(session_id, TurnState.empty(session_id))
        restored_model = self.sessions[session_id].model
        if restored_model != self.model:
            self._on_model_changed(restored_model)

        self.total_tokens = 0
        # If the local transcript is empty but the server has messages,
        # load from server so session restore/switch shows history.
        session = self.sessions.get(session_id)
        if session and not session.transcript and session.info.message_count > 0:
            await self._rebuild_transcript_from_server(session)
        else:
            self._sync_conversation()
        self.query_one("#draft", StreamingDraft).clear_stream()
        self._draft_active = False
        self._sync_sessions()
        self._sync_queue()
        self._update_context()
        display = session_id[:8]
        self._write_activity(f"Switched to session {display}", style="info")

    async def _resume_requested_session(self) -> None:
        """Resume a session requested via --resume CLI flag."""
        prefix = self._resume_session_id or ""
        matches = [sid for sid in self.sessions if sid.startswith(prefix)]
        if len(matches) == 1:
            self.active_session_id = matches[0]
            session = self.sessions[self.active_session_id]
            if not session.transcript and session.info.message_count > 0:
                await self._rebuild_transcript_from_server(session)
            else:
                self._sync_conversation()
            self._dismiss_welcome()
            self._update_context()
            self._write_activity(f"Resumed session {matches[0][:8]}", style="info")
        elif len(matches) > 1:
            self.active_session_id = None
            self._sync_conversation()
            self._flash(
                f"Multiple sessions match '{prefix}' — use a longer prefix", severity="warning"
            )
        else:
            self.active_session_id = None
            self._sync_conversation()
            self._flash(f"No session found matching '{prefix}'", severity="warning")

    @work(exclusive=True, group="session")
    async def _start_agent_session(self, agent_name: str) -> None:
        if self.runtime_info is None:
            self._flash("Runtime metadata is not loaded", severity="warning")
            return
        available = {"default"} | {a.name for c in self.runtime_info.capabilities for a in c.agents}
        if agent_name not in available:
            self._flash(f"Unknown agent: {agent_name}", severity="warning")
            return
        if self._active_session() is None:
            await self.__create_new_session(agent=None if agent_name == "default" else agent_name)
            return
        self._set_active_session_agent(agent_name)

    # ==================================================================
    # Chat
    # ==================================================================

    @work(exit_on_error=False, exclusive=True, group="session")
    async def _send_chat(self, message: str, _user_entry_shown: bool = False) -> None:
        send_t0 = time.monotonic()
        session = self._active_session()
        if session is None:
            t0 = time.monotonic()
            await self.__create_new_session()
            logger.debug("Send timing | create_session={:.0f}ms", (time.monotonic() - t0) * 1000)
            session = self._active_session()
            if session is None:
                self._flash("Failed to create a session", severity="error")
                return

        tp = self.query_one("#tool-progress", ToolProgress)
        if not _user_entry_shown:
            self._set_status("Thinking", busy=True)
            tp.show_activity("thinking")

            sid = session.info.session_id
            self._turn_counts.setdefault(sid, 0)
            self._turn_counts[sid] += 1
            self._append_transcript(
                TranscriptEntry(
                    kind="user", title="user", body=message, turn=self._turn_counts[sid]
                ),
                sid,
            )

        logger.info(
            "Chat send | session={} model={} agent={} length={}",
            session.info.session_id[:8],
            self.model,
            session.info.agent or "default",
            len(message),
        )
        try:
            t0 = time.monotonic()
            await self._ensure_litellm_key_fresh()
            logger.debug(
                "Send timing | ensure_litellm_key={:.0f}ms", (time.monotonic() - t0) * 1000
            )
            logger.debug(
                "Send timing | pre_stream_total={:.0f}ms", (time.monotonic() - send_t0) * 1000
            )
            first_event = True
            async for event in self.server_client.stream_chat(
                session_id=session.info.session_id,
                message=message,
                model=self.model,
                agent=None if session.info.agent == "default" else session.info.agent,
                generate_params_extra=self.generate_params_extra or None,
            ):
                if first_event:
                    logger.debug(
                        "Send timing | first_sse_event={:.0f}ms",
                        (time.monotonic() - send_t0) * 1000,
                    )
                    first_event = False
                self._handle_event(event, session.info.session_id)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Chat stream failed")
            self._append_transcript(
                TranscriptEntry(kind="error", title="error", body=str(exc)), session.info.session_id
            )
            self._write_activity(str(exc), style="error")
        finally:
            self._commit_draft_to_transcript(session.info.session_id)
            tp.hide_tool()

            if session.info.session_id in self.sessions:
                self.sessions[session.info.session_id].info.message_count = len(
                    self.sessions[session.info.session_id].transcript
                )
                self._sync_sessions()

            self._drain_queue(session.info.session_id)

    @work(exit_on_error=False, exclusive=True, group="session")
    async def _execute_shell(self, command: str) -> None:
        session = self._active_session()
        sid = session.info.session_id if session else "shell"
        self._append_transcript(
            TranscriptEntry(kind="user", title="shell", body=f"$ {command}"), sid
        )
        self._set_status("Running", busy=True)
        tp = self.query_one("#tool-progress", ToolProgress)
        tp.show_activity("running")
        try:
            result = await self.server_client.execute_shell(command)
            stdout = result.get("stdout", "").strip()
            stderr = result.get("stderr", "").strip()
            exit_code = result.get("exitCode", 0)
            output = stdout
            if stderr:
                output = f"{output}\n{stderr}" if output else stderr
            if exit_code != 0:
                output = f"{output}\n[exit {exit_code}]"
            self._append_transcript(
                TranscriptEntry(
                    kind="tool" if exit_code == 0 else "error",
                    title="shell",
                    body=output or "(no output)",
                    meta=f"exit {exit_code}",
                ),
                sid,
            )
        except Exception as exc:
            logger.exception("Shell execution failed")
            self._append_transcript(
                TranscriptEntry(kind="error", title="shell", body=str(exc)), sid
            )
        finally:
            tp.hide_tool()
            self._set_status("Ready", busy=False)

    @work(exit_on_error=False, exclusive=True, group="session")
    async def _send_chat_to_agent(self, message: str, agent_name: str) -> None:
        session = self._active_session()
        if session is None:
            await self.__create_new_session()
            session = self._active_session()
        if session is None:
            return
        # Inline the chat logic to avoid nesting @work calls
        self._set_status("Thinking", busy=True)
        tp = self.query_one("#tool-progress", ToolProgress)
        tp.show_activity("thinking")

        logger.info(
            "Chat send @agent | session={} model={} agent={} length={}",
            session.info.session_id[:8],
            self.model,
            agent_name,
            len(message),
        )
        try:
            await self._ensure_litellm_key_fresh()
            sid = session.info.session_id
            self._turn_counts.setdefault(sid, 0)
            self._turn_counts[sid] += 1
            self._append_transcript(
                TranscriptEntry(
                    kind="user", title="user", body=message, turn=self._turn_counts[sid]
                ),
                sid,
            )

            async for event in self.server_client.stream_chat(
                session_id=session.info.session_id,
                message=message,
                model=self.model,
                agent=agent_name,
                generate_params_extra=self.generate_params_extra or None,
            ):
                self._handle_event(event, session.info.session_id)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Agent chat failed")
            self._append_transcript(
                TranscriptEntry(kind="error", title="error", body=str(exc)), session.info.session_id
            )
            self._write_activity(str(exc), style="error")
        finally:
            self._commit_draft_to_transcript(session.info.session_id)
            tp.hide_tool()

            if session.info.session_id in self.sessions:
                self.sessions[session.info.session_id].info.message_count = len(
                    self.sessions[session.info.session_id].transcript
                )
                self._sync_sessions()

            self._drain_queue(session.info.session_id)

    # ==================================================================
    # Permission handling
    # ==================================================================

    @work(exit_on_error=False)
    async def _send_permission_response(
        self, request_id: str, decision: str, tool_name: str = ""
    ) -> None:
        """Send a permission decision back to the server."""
        logger.info("Permission response | decision={} tool={}", decision, tool_name or "n/a")
        session = self._active_session()
        if session is None:
            return

        # Track allow_session decisions by tool name
        if decision == "allow_session" and tool_name:
            sid = session.info.session_id
            if sid not in self._session_allowlist:
                self._session_allowlist[sid] = set()
            self._session_allowlist[sid].add(tool_name)

        try:
            await self.server_client.send_permission_response(
                session.info.session_id,
                request_id,
                decision,
            )
            self._set_status("Resuming", busy=True)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Permission response failed")
            self._write_activity(f"Permission response error: {exc}", style="error")
            self._set_composer_enabled(self.authenticated)
            if self.authenticated:
                self.query_one("#composer", ComposerInput).focus()
            self._set_status("Ready", busy=False)

    @work(exit_on_error=False)
    async def _send_human_input_response(
        self,
        request_id: str,
        action: str,
        *,
        text: str | None = None,
        selected_option: str | None = None,
        tool_name: str | None = None,
    ) -> None:
        """Send a human input response back to the server."""
        logger.info("Human input response | action={} tool={}", action, tool_name or "n/a")
        session = self._active_session()
        if session is None:
            return

        if action == "allow_session" and tool_name:
            sid = session.info.session_id
            if sid not in self._session_allowlist:
                self._session_allowlist[sid] = set()
            self._session_allowlist[sid].add(tool_name)

        response = HumanInputResponse(
            request_id=request_id,
            action=action,
            text=text,
            selected_option=selected_option,
        )

        try:
            await self.server_client.send_human_input_response(session.info.session_id, response)
            if action in {"submit", "approve", "allow_session"}:
                self._set_status("Resuming", busy=True)
            else:
                self._set_status("Ready", busy=False)
            self._apply_human_prompt_response(session.info.session_id, action)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Human input response failed")
            self._write_activity(f"Human response error: {exc}", style="error")
            self._set_composer_enabled(self.authenticated)
            if self.authenticated:
                self.query_one("#composer", ComposerInput).focus()
            self._set_status("Ready", busy=False)

    # ==================================================================
    # Event handling
    # ==================================================================

    def _sync_progress_indicator(self, state: TurnState) -> None:
        """Update the progress indicator based on current turn state."""
        tp = self.query_one("#tool-progress", ToolProgress)
        running = [r for r in state.tool_runs.values() if r.status == "running"]

        if state.phase == "running_tools" and running:
            if len(running) == 1:
                tp.show_tool(running[0].tool_name)
            elif len(running) == 2:
                names = ", ".join(r.tool_name for r in running)
                tp.show_activity(names)
            else:
                names = ", ".join(r.tool_name for r in running[:2])
                tp.show_activity(f"{names}, +{len(running) - 2}")
        elif state.phase == "generating":
            if self._draft_active:
                tp.show_activity("streaming")
            else:
                tp.show_activity("thinking")
        elif state.phase in ("completed", "failed", "idle"):
            # Idle between tool_end and next generation — show thinking
            # unless the turn is actually done
            if state.phase == "idle" and state.tool_runs:
                tp.show_activity("thinking")
            else:
                tp.hide_tool()
        # awaiting_permission / awaiting_input — keep current state

    def _handle_event(self, event: dict[str, t.Any], session_id: str) -> None:
        normalized = normalize_event(event, session_id)
        prev_state = self._turn_state.get(session_id, TurnState.empty(session_id))
        next_state = reduce_event(prev_state, normalized)
        self._turn_state[session_id] = next_state

        event_type = normalized.type
        payload = self._event_payload(normalized)

        if normalized.usage_total_tokens is not None:
            self.total_tokens = max(self.total_tokens, normalized.usage_total_tokens)

        if event_type == "cancelled":
            logger.debug("Server confirmed turn cancellation for session {}", session_id[:8])
            return

        if event_type == "generation_content":
            # Render text immediately — fires BEFORE tools (ENG-5879)
            if normalized.reasoning_content and self._show_thinking:
                self._append_transcript(
                    TranscriptEntry(
                        kind="thinking",
                        title="Thinking",
                        body=normalized.reasoning_content,
                    ),
                    session_id,
                )

            text = normalized.assistant_delta or ""
            if text:
                draft = self.query_one("#draft", StreamingDraft)
                if not self._draft_active:
                    draft.start_stream()
                    self._draft_active = True
                draft.append_token(text)
            self._sync_progress_indicator(next_state)
            return

        if event_type == "generation_end":
            return

        if event_type == "generation_step":
            return

        if event_type == "tool_start":
            if self._draft_active:
                draft = self.query_one("#draft", StreamingDraft)
                if draft._buffer.strip():
                    self._commit_draft_to_transcript(session_id)
                else:
                    draft.clear_stream()
                    self._draft_active = False
            # Mount a ToolCall widget showing the tool name immediately
            run = self._tool_run_for_event(next_state, normalized)
            if run is not None and self.active_session_id == session_id:
                from dreadnode.app.tui.widgets.tool import ToolCall

                widget = ToolCall(
                    name=run.label,
                    classes="entry tool-entry",
                )
                self._tool_call_widgets[run.tool_call_id] = widget
                conv = self.query_one("#conversation", ConversationView)
                self.call_after_refresh(conv.append_entry_widget, widget)
            self._sync_progress_indicator(next_state)
            return

        if event_type == "tool_end":
            run = self._tool_run_for_event(next_state, normalized)
            tool_name = run.tool_name if run is not None else (normalized.tool_name or "tool")
            label = (
                run.label
                if run is not None
                else _format_tool_label(tool_name, normalized.tool_args or {})
            )
            summary = _summarize_tool_result(
                tool_name, normalized.tool_args or {}, payload.get("result")
            )
            full_details = self._tool_result_details(payload.get("result"))
            # Update the in-progress widget in place, or append a new one
            widget = self._tool_call_widgets.pop(run.tool_call_id if run else "", None)
            if widget is not None:
                widget.complete(meta=summary, details=full_details)
            else:
                # No in-progress widget (e.g. session replay) — append normally
                conv = self.query_one(ConversationView)
                self.call_after_refresh(
                    conv.append_entry,
                    TranscriptEntry(kind="tool", title=label, body=full_details, meta=summary),
                    scroll=False,
                )
            # Always record in transcript with full details for session replay
            record = self.sessions.get(session_id)
            if record is not None:
                record.transcript.append(
                    TranscriptEntry(kind="tool", title=label, body=full_details, meta=summary)
                )
            self._sync_progress_indicator(next_state)
            conv = self.query_one(ConversationView)
            self.call_after_refresh(conv.scroll_end, animate=False)
            return

        if event_type == "tool_step":
            return

        if event_type == "tool_error":
            logger.error("Tool error: {}", normalized.error_text)
            run = self._tool_run_for_event(next_state, normalized)
            label = (
                run.label
                if run is not None
                else _format_tool_label(
                    normalized.tool_name or "tool",
                    normalized.tool_args or {},
                )
            )
            error = normalized.error_text or "Tool error"
            # Update the in-progress widget, or append a new error entry
            widget = self._tool_call_widgets.pop(run.tool_call_id if run else "", None)
            if widget is not None:
                widget.complete(error=error)
            # Always record in transcript
            self._append_transcript(
                TranscriptEntry(kind="error", title=label, body=error),
                session_id,
            )
            return

        if event_type == "generation_error":
            logger.error(
                "Generation error: {} (type={})", normalized.error_text, normalized.error_type
            )
            error_text, _, is_auth_error = _classify_error_message(
                normalized.error_text,
                normalized.error_type,
            )
            title = "generation"
            body = error_text or "Generation error"
            override, flash_message, reauth = self._proxy_error_override(
                error_text or "",
                normalized.error_type,
            )
            if override:
                body = override
                if flash_message:
                    self._flash(flash_message, severity="warning")
                if reauth:
                    self._run_command(self._provision_litellm_key)
            split = None
            if error_text:
                split = _split_missing_api_key_message(error_text)
                if split:
                    title, body = split
            if not override and not split:
                body = _enrich_error_body(body, normalized.error_type)
            self._append_transcript(
                TranscriptEntry(kind="error", title=title, body=body),
                session_id,
            )
            if is_auth_error and error_text:
                self._last_auth_error[session_id] = error_text
            return

        if event_type == "compaction":
            status = (normalized.raw or {}).get("data", {}).get("compaction_status", "")
            if status == "completed":
                self._flash("Context auto-compacted", severity="info")
            return

        if event_type == "agent_stalled":
            logger.warning("Agent stalled: {}", normalized.error_text)
            self._append_transcript(
                TranscriptEntry(
                    kind="error", title="agent", body=normalized.error_text or "Agent stalled"
                ),
                session_id,
            )
            return

        if event_type == "agent_error":
            logger.error("Agent error: {} (type={})", normalized.error_text, normalized.error_type)
            if normalized.error_text:
                error_text, _, is_auth_error = _classify_error_message(
                    normalized.error_text,
                    normalized.error_type,
                )
                override, flash_message, reauth = self._proxy_error_override(
                    error_text or "",
                    normalized.error_type,
                )
                body = override or error_text or normalized.error_text
                if override and flash_message:
                    self._flash(flash_message, severity="warning")
                if override and reauth:
                    self._run_command(self._provision_litellm_key)
                if not override:
                    body = _enrich_error_body(body, normalized.error_type)
                self._append_transcript(
                    TranscriptEntry(
                        kind="error",
                        title="agent",
                        body=body,
                    ),
                    session_id,
                )
                if is_auth_error and error_text:
                    self._last_auth_error[session_id] = error_text
            return

        if event_type == "agent_end":
            stop_reason = str(payload.get("stop_reason", "")).lower()
            logger.debug(
                "Agent end | session={} | stop_reason={} | status={} | error={}",
                session_id[:8],
                stop_reason or "finished",
                normalized.status or "ok",
                normalized.error_text or "none",
            )
            if normalized.error_text:
                logger.error(
                    "Agent ended with error: {} (type={}, payload={})",
                    normalized.error_text,
                    normalized.error_type,
                    payload,
                )
                error_text, _, is_auth_error = _classify_error_message(
                    normalized.error_text,
                    normalized.error_type,
                )
                override, flash_message, reauth = self._proxy_error_override(
                    error_text or "",
                    normalized.error_type,
                )
                body = override or error_text or normalized.error_text
                if is_auth_error and error_text:
                    last_auth_error = self._last_auth_error.get(session_id)
                    if last_auth_error == error_text:
                        return
                if override and flash_message:
                    self._flash(flash_message, severity="warning")
                if override and reauth:
                    self._run_command(self._provision_litellm_key)
                if not override:
                    body = _enrich_error_body(body, normalized.error_type)
                self._append_transcript(
                    TranscriptEntry(
                        kind="error",
                        title="agent",
                        body=body,
                    ),
                    session_id,
                )
                if is_auth_error and error_text:
                    self._last_auth_error[session_id] = error_text
            elif normalized.status == "errored" or stop_reason == "error":
                logger.error("Agent ended with error status (no error text)")
                self._append_transcript(
                    TranscriptEntry(kind="error", title="agent", body="run ended with an error"),
                    session_id,
                )
            elif stop_reason == "max_steps_reached":
                logger.warning(
                    "Agent hit max steps | session={} | payload={}",
                    session_id[:8],
                    payload,
                )
                self._append_transcript(
                    TranscriptEntry(
                        kind="error",
                        title="agent",
                        body="stopped — reached the maximum number of steps. Send a follow-up message to continue.",
                    ),
                    session_id,
                )
            elif stop_reason == "stalled":
                logger.warning(
                    "Agent stalled | session={} | payload={}",
                    session_id[:8],
                    payload,
                )
                self._append_transcript(
                    TranscriptEntry(
                        kind="error",
                        title="agent",
                        body="stopped — agent appears stalled. Send a follow-up message to continue.",
                    ),
                    session_id,
                )
            return

        if event_type == "human_prompt":
            prompt = normalized.human_prompt
            if prompt is None:
                return

            sid = self.active_session_id or ""
            if prompt.kind == "approval" and prompt.source_tool_name:
                allowed = (
                    sid in self._session_allowlist
                    and prompt.source_tool_name in self._session_allowlist[sid]
                )
                if allowed:
                    self._send_human_input_response(
                        prompt.request_id,
                        "approve",
                        tool_name=prompt.source_tool_name,
                    )
                    return

            self._set_composer_enabled(self.authenticated)
            status = "Awaiting approval" if prompt.kind == "approval" else "Awaiting input"
            self._set_status(status, busy=True)
            widget = self.query_one("#human-prompt", PermissionPrompt)
            self.call_after_refresh(widget.show_prompt, prompt)
            if prompt.kind != "approval":
                composer = self.query_one("#composer", ComposerInput)
                composer.placeholder = "Type your response and press Enter..."
                self.call_after_refresh(composer.focus)
            else:
                self.query_one("#composer", ComposerInput).placeholder = ""
            if prompt.question:
                prompt_body = prompt.question
                if prompt.options:
                    options_text = "\n".join(
                        f"{idx}. {option.label}"
                        for idx, option in enumerate(prompt.options, start=1)
                    )
                    prompt_body = f"{prompt_body}\n{options_text}"
                self._append_transcript(
                    TranscriptEntry(kind="tool", title="ask_user", body=prompt_body),
                    session_id,
                )
            return

        if event_type == "runtime_error":
            logger.error("Runtime error: {}", normalized.error_text)
            status = payload.get("status") if isinstance(payload, dict) else None
            if status is None and isinstance(payload, dict):
                status = payload.get("status_code")
            try:
                status_code = int(status) if status is not None else None
            except (TypeError, ValueError):
                status_code = None
            if status_code == 401:
                logger.warning("Runtime returned 401 during chat — triggering re-auth")
                raise AuthenticationError("401: Unauthorized")
            if status_code == 403:
                logger.warning(
                    "Runtime returned 403 during chat — insufficient permissions: {}",
                    normalized.error_text,
                )
            override, flash_message, reauth = self._proxy_error_override(
                normalized.error_text,
                None,
            )
            self._write_activity(
                normalized.error_text or str(payload.get("error", "Runtime error")),
                style="error",
            )
            if normalized.error_text:
                body = override or normalized.error_text
                if not override:
                    body = _enrich_error_body(body, normalized.error_type, status_code)
                self._append_transcript(
                    TranscriptEntry(kind="error", title="runtime", body=body),
                    session_id,
                )
                if override and flash_message:
                    self._flash(flash_message, severity="warning")
                if override and reauth:
                    self._run_command(self._provision_litellm_key)
            return

    def _event_payload(self, event: NormalizedEvent) -> dict[str, t.Any]:
        raw = event.raw if isinstance(event.raw, dict) else {}
        payload = raw.get("data") if isinstance(raw.get("data"), dict) else raw
        if isinstance(payload, dict):
            return payload
        return {}

    def _tool_run_for_event(self, state: TurnState, event: NormalizedEvent) -> ToolRun | None:
        if event.tool_call_id:
            run = state.tool_runs.get(event.tool_call_id)
            if run is not None:
                return run
        if event.tool_name:
            for key in reversed(state.tool_order):
                run = state.tool_runs.get(key)
                if run is None:
                    continue
                if run.tool_name == event.tool_name:
                    return run
        return None

    def _tool_result_details(self, result: t.Any, max_len: int = 1600) -> str:
        """Render detailed tool result text for expanded transcript mode."""
        if result is None:
            return ""

        if isinstance(result, str):
            text = result.strip()
        elif isinstance(result, (dict, list)):
            try:
                text = json.dumps(result, indent=2, sort_keys=True)
            except TypeError:
                text = str(result)
        else:
            text = str(result)

        if not text:
            return ""
        if len(text) > max_len:
            return f"{text[:max_len]}..."
        return text

    def _active_human_prompt(self, session_id: str | None = None) -> HumanPrompt | None:
        """Return the active human prompt for a session, if any."""
        sid = session_id or self.active_session_id
        if not sid:
            return None
        state = self._turn_state.get(sid)
        if state is None:
            return None
        return state.pending_human_prompt

    def _apply_human_prompt_response(self, session_id: str, action: str) -> None:
        """Apply a local human prompt response to turn state."""
        state = self._turn_state.get(session_id)
        if state is None:
            return
        self._turn_state[session_id] = reduce_human_prompt_response(state, action=action)

    def _cancel_active_prompt(self) -> bool:
        """Cancel the active human prompt if one is present."""
        prompt = self._active_human_prompt()
        if prompt is None:
            return False
        self.query_one("#human-prompt", PermissionPrompt).hide_prompt()
        self.query_one("#composer", ComposerInput).placeholder = ""
        self._send_human_input_response(
            prompt.request_id,
            "cancel",
            tool_name=prompt.source_tool_name,
        )
        return True

    # ==================================================================
    # Message queue
    # ==================================================================

    def _enqueue_message(self, message: str) -> None:
        """Add a message to the queue for the active session."""
        sid = self.active_session_id
        if not sid:
            return
        self._pending_messages.setdefault(sid, []).append(message)
        self._sync_queue()

    def _has_queued_messages(self) -> bool:
        """Check if the active session has queued messages."""
        sid = self.active_session_id
        if not sid:
            return False
        return bool(self._pending_messages.get(sid))

    def _retract_last_queued(self) -> str | None:
        """Pop the last queued message and return it (for editing)."""
        sid = self.active_session_id
        if not sid:
            return None
        queue = self._pending_messages.get(sid, [])
        if not queue:
            return None
        message = queue.pop()
        self._sync_queue()
        return message

    def _sync_queue(self) -> None:
        """Update the queue widget to reflect current state."""
        sid = self.active_session_id
        queue = self._pending_messages.get(sid, []) if sid else []
        self.query_one("#message-queue", MessageQueue).set_messages(queue)

    def _drain_queue(self, session_id: str) -> None:
        """After a turn ends, auto-send the next queued message or go idle."""
        # If busy was already cleared by an interrupt handler, don't auto-send
        if not self.busy:
            return

        queue = self._pending_messages.get(session_id, [])
        if queue and self.active_session_id == session_id:
            message = queue.pop(0)
            self._sync_queue()
            # Route @agent messages to the correct agent
            if at_match := re.match(r"^@(\S+)\s+([\s\S]+)$", message):
                self._send_chat_to_agent(at_match.group(2), at_match.group(1))
            else:
                self._send_chat(message)
        else:
            self._set_status("Ready", busy=False)
            if self.authenticated:
                self.query_one("#composer", ComposerInput).focus()

    # ==================================================================
    # Command dispatch
    # ==================================================================

    def _handle_command(self, raw: str) -> None:
        parts = raw[1:].split()
        cmd = parts[0].lower() if parts else ""
        args = parts[1:]

        if not self.authenticated and cmd not in {
            "quit",
            "exit",
            "q",
            "help",
            "login",
            "console",
            "thinking",
            "version",
            "update",
        }:
            self._flash(
                "Not authenticated — use /login to connect to the platform",
                severity="warning",
            )
            return

        dispatch: dict[str, t.Callable[[], None]] = {
            "quit": self.exit,
            "exit": self.exit,
            "q": self.exit,
            "help": self._show_help,
            "new": lambda: self._create_new_session(),
            "reset": lambda: self._reset_active_session(),
            "sessions": self.action_open_sessions,
            "agents": self._write_agent_listing,
            "reload": lambda: self._run_command(self._reload_capabilities_command),
            "login": lambda: self._run_command(self._login_command, args),
            "logout": lambda: self._run_command(self._logout_command),
            "workspace": lambda: (
                self._open_workspaces_screen()
                if not args
                else self._run_command(self._switch_workspace_command, args)
            ),
            "workspaces": lambda: self._open_workspaces_screen(),
            "models": self._open_model_picker,
            "runtimes": lambda: self._open_platform_screen("runtimes"),
            "environments": lambda: self._open_platform_screen("environments"),
            "env": lambda: self._open_platform_screen("environments"),
            "secrets": lambda: self._open_platform_screen("secrets"),
            "console": self.action_open_console,
            "traces": lambda: self._open_platform_screen("traces"),
            "sandboxes": lambda: self._open_platform_screen("sandboxes"),
            "evaluations": lambda: self._open_platform_screen("evaluations"),
            "capabilities": lambda: self._open_capabilities_screen(),
            "caps": lambda: self._open_capabilities_screen(),
            "mcp": self._open_mcp_screen,
            "copy": self._copy_last_assistant,
            "compact": lambda: self._run_command(self._compact_command, args),
            "tools": lambda: self._open_tools_dialog(),
            "update": lambda: self._run_command(self._update_command),
            "theme": self._open_theme_showcase,
        }

        if cmd in dispatch:
            dispatch[cmd]()
            return

        # Commands with required args
        if cmd == "agent":
            if not args:
                self._flash("Usage: /agent <name>", severity="warning")
            else:
                self._start_agent_session(args[0])
            return

        if cmd == "model":
            if not args:
                self._flash(f"Current model: {self.model}", severity="info")
            else:
                self._on_model_changed(args[0])
                self._run_command(self._persist_default_model_choice, args[0])
                self._flash(f"Model set to {args[0]}", severity="info")
            return

        if cmd == "version":
            from dreadnode.version import VERSION

            self._flash(f"Dreadnode v{VERSION}", severity="info")
            return

        if cmd in {"whoami", "getuid"}:
            self._run_command(self._whoami_command)
            return

        if cmd == "projects":
            if args:
                self._run_command(self._projects_command, args)
            else:
                self._open_workspaces_screen()
            return

        if cmd == "rename":
            if not args:
                self._flash("Usage: /rename <title>", severity="warning")
            else:
                new_title = " ".join(args)
                self._rename_session(new_title)
            return

        if cmd == "export":
            filename = args[0] if args else None
            self._export_session(filename)
            return

        if cmd == "thinking":
            self._handle_thinking_command(args)
            return

        if cmd == "skills":
            self._open_skills_dialog()
            return

        # Check if the command matches a skill name (skills are first-class commands)
        known_skill_names = {name for name, _desc in self._skill_names}
        if cmd in known_skill_names:
            self._run_command(self._load_skill_command, cmd, " ".join(args))
            return

        self._flash(f"Unknown command: /{cmd}", severity="warning")

    @work(group="command", exclusive=True)
    async def _run_command(self, coro_fn: t.Callable[..., t.Awaitable[None]], *args: t.Any) -> None:
        """Generic worker for async command implementations."""
        try:
            await coro_fn(*args)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Command {} failed", getattr(coro_fn, "__name__", coro_fn))
            self._flash(str(exc), severity="warning")

    def _handle_thinking_command(self, args: list[str]) -> None:
        """Handle /thinking command for effort level control."""
        from dreadnode.app.tui.model_variants import get_variants

        if not args:
            if self.thinking_enabled and self.effort_label:
                self._flash(f"Thinking: enabled ({self.effort_label})", severity="info")
            else:
                self._flash("Thinking: disabled", severity="info")
            return

        arg = args[0].lower()

        if arg == "show":
            self._show_thinking = True
            self._flash("Thinking blocks visible", severity="info")
            return

        if arg == "hide":
            self._show_thinking = False
            self._flash("Thinking blocks hidden", severity="info")
            return

        if arg == "off":
            self.thinking_enabled = False
            self._model_variants[self.model] = ""
            self.effort_label = ""
            self._flash("Thinking disabled", severity="info")
            return

        variants = get_variants(self.model)

        if arg == "on":
            if not variants:
                self._flash(f"Model {self.model} does not support thinking", severity="warning")
                return
            self.thinking_enabled = True
            label = next(iter(variants))
            self._model_variants[self.model] = label
            self.effort_label = label
            self._flash(f"Thinking enabled ({label})", severity="info")
            return

        # Named effort level
        if arg in variants:
            self.thinking_enabled = True
            self._model_variants[self.model] = arg
            self.effort_label = arg
            self._flash(f"Thinking: {arg}", severity="info")
            return

        available = ", ".join(variants.keys()) if variants else "none for this model"
        self._flash(f"Unknown effort level '{arg}'. Available: {available}", severity="warning")

    # ==================================================================
    # Command implementations
    # ==================================================================

    async def _list_sessions_command(self) -> None:
        await self._refresh_server_sessions()
        self._write_session_listing()

    async def _reload_capabilities_command(self) -> None:
        self.runtime_info = await self._connection_manager.local_client.reload_capabilities()
        self._update_runtime_health()
        self.query_one("#mention-overlay", MentionOverlay).set_agents(self._collect_agents())
        self.working_dir = self.runtime_info.working_dir or ""
        self._sync_sessions()
        self._update_context()
        cap_count = len(self.runtime_info.capabilities)
        agent_count = sum(len(c.agents) for c in self.runtime_info.capabilities)
        self._refresh_skill_names()
        self._flash(
            f"Reloaded {cap_count} capabilities, {agent_count} agents",
            severity="success",
        )

    @work(group="skill_names")
    async def _refresh_skill_names(self) -> None:
        """Fetch skill names for slash overlay and command dispatch."""
        try:
            skills = await self.server_client.fetch_skills()
            # Filter out skills whose names collide with built-in commands
            from dreadnode.app.tui.commands import SLASH_COMMANDS

            builtin = {c.name.lstrip("/") for c in SLASH_COMMANDS}
            self._skill_names = {(s.name, s.description) for s in skills if s.name not in builtin}
            logger.debug("Skills refresh | count={}", len(self._skill_names))
        except Exception:
            logger.opt(exception=True).debug("Failed to refresh skill names")

    async def _login_command(self, args: list[str] | None = None) -> None:
        self._set_status("Logging in", busy=True)
        try:
            server_url, api_key = _parse_login_args(
                args or [],
                default_platform_url=self._resolved_server_url(),
            )
        except ValueError as exc:
            self._flash(str(exc), severity="warning")
            self._set_status("Ready", busy=False)
            return
        if api_key is None:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal(server_url)
            return

        try:
            profile = await asyncio.to_thread(_login_with_api_key, server_url, api_key)
        except Exception as exc:
            self._set_status("Authentication required", busy=False)
            logger.warning("Login failed: {}", exc)
            self._show_auth_modal(server_url, reason="Login failed — please try again")
            return
        self._write_activity(f"Logged in on {profile.url}", style="success")
        self._write_activity(
            "Restarting runtime to apply platform authentication. Active runs will stop; local chat history is preserved.",
            style="warning",
        )
        self._flash(
            "Restarting runtime to apply platform authentication",
            severity="warning",
        )
        await self._apply_auth_profile(profile)

    async def _logout_command(self) -> None:
        logout_server_url = self._resolved_server_url()
        try:
            _name, profile = _active_profile()
        except Exception:
            profile = None
            logger.opt(exception=True).warning(
                "Failed to read active profile for API key revocation"
            )
        if profile and profile.api_key and profile.url:
            try:
                api = ApiClient(profile.url, api_key=profile.api_key)
                await asyncio.to_thread(api.revoke_self_api_key)
            except Exception:
                logger.opt(exception=True).warning("Failed to revoke API key during logout")
        removed: str | None = None
        try:
            removed = _delete_active_profile()
        except Exception as exc:
            self._flash(f"Failed to delete saved credentials: {exc}", severity="warning")
        self._write_activity(
            "Deleting saved credentials. Restarting runtime without platform sync. "
            "Active runs will stop; local chat history is preserved.",
            style="warning",
        )
        if removed:
            self._flash(
                f"Logged out from {removed}; saved credentials deleted; restarting runtime without platform sync",
                severity="warning",
            )
        else:
            self._flash(
                "No saved profile found; restarting runtime without platform sync",
                severity="warning",
            )
        self._connection_manager.local_client.clear_platform_profile()
        self._clear_platform_proxy_state()
        self.authenticated = False

        if self._connection_manager.local_client.is_started:
            self._set_status("Restarting server", busy=True)
            await self._connection_manager.local_client.restart()
            await self._refresh_runtime()
            await self._refresh_server_sessions()
            if self.active_session_id is None:
                await self.__create_new_session()
        self._set_status("Ready", busy=False)
        self._show_auth_modal(logout_server_url, force_new_key=True)

    async def _whoami_command(self) -> None:
        if not self.authenticated:
            self._flash("Not logged in", severity="warning")
            return
        name, profile = _active_profile()
        if name is None or profile is None:
            self._flash("Not logged in. Use /login first.", severity="warning")
            return
        from dreadnode.app.tui.widgets.whoami import WhoAmI

        self._dismiss_welcome()
        widget = WhoAmI(
            name,
            profile.url,
            username=profile.username,
            email=profile.email,
            organization=profile.default_organization,
            workspace=profile.default_workspace,
            project=profile.default_project,
            classes="entry",
        )
        conv = self.query_one("#conversation", ConversationView)
        self.call_after_refresh(conv.append_entry_widget, widget)

    @work(exclusive=True, group="skills_fetch")
    async def _open_skills_dialog(self) -> None:
        """Fetch skills and open the skills browser below the composer."""
        dialog = self.query_one("#skills-dialog", SkillsDialog)
        if dialog.is_visible:
            dialog.hide()
            return
        try:
            skills = await self.server_client.fetch_skills()
        except Exception:
            logger.opt(exception=True).warning("Failed to fetch skills for dialog")
            self._flash("Failed to fetch skills", severity="warning")
            return
        if not skills:
            self._flash("No skills available", severity="info")
            return
        composer = self.query_one("#composer", ComposerInput)
        composer.load_text("")
        dialog.show_skills([(s.name, s.description) for s in skills])
        composer.focus()

    @on(SkillsDialog.SkillSelected)
    def _on_skill_selected(self, event: SkillsDialog.SkillSelected) -> None:
        """When a skill is selected from the dialog, prefill the composer."""
        composer = self.query_one("#composer", ComposerInput)
        text = f"/{event.skill_name} "
        composer.load_text(text)
        composer.move_cursor_relative(rows=0, columns=len(text))
        composer.focus()

    async def _load_skill_command(self, name: str, extra: str = "") -> None:
        """Handle /<skill-name> [context] — fetch rendered skill content and send as user message.

        Sends the same content the load_skill tool would produce, matching
        the OpenCode pattern of sending skill content as a plain user message.
        """
        try:
            content = await self.server_client.fetch_skill_content(name)
        except Exception:
            logger.opt(exception=True).warning("Failed to load skill | name={}", name)
            self._flash(f"Skill '{name}' not found", severity="warning")
            return

        parts = [content]
        if extra.strip():
            parts.extend(["", extra.strip()])
        self._send_chat("\n".join(parts))

    async def _workspace_info_command(self) -> None:
        try:
            _name, profile = _active_profile()
        except Exception as exc:
            self._flash(str(exc), severity="warning")
            return
        if profile is None:
            self._flash("Not logged in. Use /login first.", severity="warning")
            return
        for label, value in [
            ("org", profile.default_organization),
            ("workspace", profile.default_workspace),
            ("project", profile.default_project),
        ]:
            if value:
                self._write_activity(f"{label} {value}", style="info")

    async def _switch_workspace_command(self, args: list[str]) -> None:
        if not self.authenticated:
            self._flash(
                "Not authenticated — use /login to connect to the platform",
                severity="warning",
            )
            return
        if not args:
            self._flash("Usage: /workspace <key>", severity="warning")
            return
        workspace_key = args[0]

        try:
            profile_name, profile = _active_profile()
        except Exception as exc:
            self._flash(str(exc), severity="warning")
            return
        if profile_name is None or profile is None:
            self._flash("Not logged in. Use /login first.", severity="warning")
            return

        org = profile.default_organization
        if not org:
            self._flash("No organization configured. Use /login first.", severity="warning")
            return

        try:
            api, _profile = await asyncio.to_thread(_platform_client)
            workspace = await asyncio.to_thread(api.get_workspace, org, workspace_key)
        except Exception as exc:
            self._flash(str(exc), severity="warning")
            return

        if workspace is None:
            self._flash(f"Workspace not found: {workspace_key}", severity="error")
            return

        if profile.default_workspace == workspace_key:
            self._flash(f"Already on workspace: {workspace_key}", severity="info")
            return

        default_project = await asyncio.to_thread(api.get_default_project_key, org, workspace_key)
        updated_profile = profile.model_copy(
            update={
                "default_workspace": workspace_key,
                "default_project": default_project,
            }
        )

        try:
            await asyncio.to_thread(_save_profile, profile_name, updated_profile)
        except Exception as exc:
            self._flash(f"Failed to save profile: {exc}", severity="error")
            return

        await self._apply_auth_profile(updated_profile)
        self._flash(
            f"Switched to workspace: {workspace.name} — sessions cleared",
            severity="success",
        )

    async def _workspaces_command(self) -> None:
        api, profile = await asyncio.to_thread(_platform_client)
        workspaces = await asyncio.to_thread(api.list_workspaces, profile.default_organization)
        if not workspaces:
            self._flash("No workspaces found", severity="warning")
            return
        for ws in workspaces:
            is_active = ws.key == profile.default_workspace
            marker = " \u2190 active" if is_active else ""
            default_marker = " (default)" if ws.is_default else ""
            self._write_activity(
                f"{ws.key} \u00b7 {ws.name}{marker}{default_marker}",
                style="success" if is_active else "info",
            )

    async def _projects_command(self, args: list[str] | None = None) -> None:
        api, profile = await asyncio.to_thread(_platform_client)
        org = profile.default_organization
        workspace = args[0] if args else profile.default_workspace
        if not org or not workspace:
            self._flash("No org/workspace. Use /login first.", severity="warning")
            return
        projects = await asyncio.to_thread(api.list_projects, org, workspace)
        if not projects:
            self._flash("No projects found", severity="warning")
            return
        for p in projects:
            self._write_activity(f"{p.key} \u00b7 {p.name}", style="info")

    async def _models_command(self) -> None:
        api, profile = await asyncio.to_thread(_platform_client)
        models = await asyncio.to_thread(api.list_models, profile.default_organization)
        if not models:
            self._flash("No models found", severity="warning")
            return
        for m in models:
            self._write_activity(f"{m.name} \u00b7 {m.latest_version or 'n/a'}", style="info")

    @staticmethod
    def _model_from_profile(profile: ServerConfig | None) -> str:
        """Resolve the default model from a saved profile."""
        if profile and profile.default_model:
            return profile.default_model
        return DEFAULT_MODEL

    def _default_model_from_active_profile(self) -> str:
        """Load the active profile's default model without blocking startup."""
        if self._platform_override:
            return DEFAULT_MODEL
        try:
            _name, profile = _active_profile()
        except Exception:
            logger.opt(exception=True).debug("Could not load profile for default model")
            profile = None
        return self._model_from_profile(profile)

    async def _persist_default_model_choice(self, model: str) -> None:
        """Persist an explicit user model selection into the active profile."""
        try:
            profile_name, profile = await asyncio.to_thread(_active_profile)
        except Exception:
            logger.opt(exception=True).debug("Could not persist model choice")
            return

        if profile_name is None or profile is None or profile.default_model == model:
            return

        updated_profile = profile.model_copy(update={"default_model": model})
        await asyncio.to_thread(_save_profile, profile_name, updated_profile)

    def action_toggle_output_mode(self) -> None:
        """Toggle output mode between compact and expanded (^O).

        Controls how much detail is shown for tool results and other
        expandable content in the conversation view.
        """
        new_mode: t.Literal["compact", "expanded"] = (
            "expanded" if self.output_mode == "compact" else "compact"
        )
        self.output_mode = new_mode
        from dreadnode.app.tui.widgets.conversation import ThinkingBlock
        from dreadnode.app.tui.widgets.tool import ToolCall as ToolCallWidget

        try:
            conv = self.query_one("#conversation", ConversationView)
            for tc in conv.query(ToolCallWidget):
                tc.refresh(layout=True)
            expanded = new_mode == "expanded"
            for tb in conv.query(ThinkingBlock):
                tb.display = expanded
        except Exception:
            logger.debug("Could not refresh output mode widgets")
        self._flash(f"Output: {new_mode}", severity="info")

    @work(exclusive=True, group="tools_fetch")
    async def _open_tools_dialog(self) -> None:
        """Fetch tools and open the tools browser dialog."""
        dialog = self.query_one("#tools-dialog", ToolsDialog)
        if dialog.is_visible:
            dialog.hide()
            return
        try:
            tools = await self.server_client.fetch_tools()
        except Exception:
            logger.opt(exception=True).warning("Failed to fetch tools for dialog")
            self._flash("Failed to fetch tools", severity="warning")
            return
        dialog.show_tools(tools)

    # ==================================================================
    # Platform screens
    # ==================================================================

    _SCREEN_TYPES: t.ClassVar[dict[str, type]] = {
        "traces": TracesScreen,
        "runtimes": RuntimeScreen,
        "environments": EnvironmentScreen,
        "secrets": SecretsScreen,
        "sandboxes": SandboxScreen,
        "evaluations": EvaluationsScreen,
        "console": ConsoleScreen,
        "capabilities": CapabilitiesScreen,
    }

    def _open_platform_screen(self, screen_name: str) -> None:
        """Open a platform browser screen (traces, sandboxes, evaluations)."""
        screen_type = self._SCREEN_TYPES.get(screen_name)
        if screen_type and self._is_screen_open(screen_type):
            return
        self._dismiss_pushed_screens()
        logger.debug("Screen push | screen={}", screen_name)
        try:
            api, profile = _platform_client()

            org = profile.default_organization
            workspace = profile.default_workspace
            project = profile.default_project
            if not org or not workspace:
                self._flash("No org/workspace. Use /login first.", severity="warning")
                return

            if screen_name == "traces" and not project:
                project = api.get_default_project_key(org, workspace)
                if project:
                    name, current_profile = _active_profile()
                    if name and current_profile is not None:
                        current_profile.default_project = project
                        user_config = UserConfig.read(Path.home() / ".dreadnode" / "config.yaml")
                        user_config.servers[name] = current_profile
                        user_config.write(Path.home() / ".dreadnode" / "config.yaml")

            if screen_name == "traces":
                if not project:
                    self._flash("No default project. Use /projects first.", severity="warning")
                    return
                self.push_screen(TracesScreen(api, org, workspace, project))
            elif screen_name == "runtimes":
                self.push_screen(
                    RuntimeScreen(api, org, workspace, connection_manager=self._connection_manager)
                )
            elif screen_name == "environments":
                self.push_screen(EnvironmentScreen(api, org, workspace))
            elif screen_name == "secrets":
                self.push_screen(SecretsScreen(api))
            elif screen_name == "sandboxes":
                self.push_screen(SandboxScreen(api, org, workspace))
            elif screen_name == "evaluations":
                self.push_screen(EvaluationsScreen(api, org, workspace))
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Failed to open {} screen", screen_name)
            self._flash(str(exc), severity="warning")

    def _open_workspaces_screen(self) -> None:
        """Open the workspace & project browser."""
        if self._is_screen_open(WorkspaceScreen):
            return
        self._dismiss_pushed_screens()
        try:
            api, profile = _platform_client()
            org = profile.default_organization
            workspace = profile.default_workspace
            project = profile.default_project
            if not org:
                self._flash("No organization. Use /login first.", severity="warning")
                return
            self.push_screen(
                WorkspaceScreen(api, org, workspace or "", project),
                callback=self._on_workspace_screen_dismiss,
            )
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Failed to open workspaces screen")
            self._flash(str(exc), severity="warning")

    def _on_workspace_screen_dismiss(self, result: SwitchRequest | None) -> None:
        """Handle workspace/project switch request from WorkspaceScreen."""
        if result is None:
            return
        self._do_context_switch(result)

    @work(exclusive=True, group="context_switch")
    async def _do_context_switch(self, request: SwitchRequest) -> None:
        """Execute a full context switch: update profile, restart runtime."""
        try:
            profile_name, profile = _active_profile()
        except Exception as exc:
            self._flash(str(exc), severity="warning")
            return
        if profile_name is None or profile is None:
            self._flash("Not logged in. Use /login first.", severity="warning")
            return

        org_key = request.org_key
        workspace_key = request.workspace_key
        project_key = request.project_key

        # If no explicit project, resolve the default for the target workspace
        if not project_key:
            try:
                api, _ = await asyncio.to_thread(_platform_client)
                project_key = await asyncio.to_thread(
                    api.get_default_project_key, org_key, workspace_key
                )
            except Exception:
                project_key = None

        # Check if anything actually changed
        if (
            profile.default_organization == org_key
            and profile.default_workspace == workspace_key
            and profile.default_project == project_key
        ):
            self._flash("Already on this context", severity="info")
            return

        # Update profile
        updated_profile = profile.model_copy(
            update={
                "default_organization": org_key,
                "default_workspace": workspace_key,
                "default_project": project_key,
            }
        )

        try:
            await asyncio.to_thread(_save_profile, profile_name, updated_profile)
        except Exception as exc:
            self._flash(f"Failed to save profile: {exc}", severity="error")
            return

        # _apply_auth_profile handles session clearing via restart() → reset_app_state()
        await self._apply_auth_profile(updated_profile)
        self._flash(
            f"Switched to {workspace_key}/{project_key or 'default'}",
            severity="success",
        )

    def _open_capabilities_screen(self) -> None:
        """Open the dedicated capabilities manager for the active runtime."""
        if self._is_screen_open(CapabilitiesScreen):
            return
        self._dismiss_pushed_screens()
        logger.debug("Screen push | screen=CapabilitiesScreen")
        try:
            api: ApiClient | None = None
            org: str | None = None
            workspace: str | None = None
            runtime_id: str | None = None

            try:
                api_client, profile = _platform_client()
                api = api_client
                org = profile.default_organization
                workspace = profile.default_workspace
            except AuthenticationError:
                raise  # re-raise auth errors for the outer handler
            except Exception:
                logger.debug("Not logged in to platform; opening local-only capabilities screen")

            if self.runtime_info is not None:
                runtime_id = getattr(self.runtime_info, "runtime_id", None)

            is_sandbox = getattr(self.runtime_info, "host_type", "local") == "sandbox"
            self.push_screen(
                CapabilitiesScreen(
                    runtime_client=self.server_client,
                    api=api,
                    org=org,
                    workspace=workspace,
                    runtime_id=runtime_id,
                    is_sandbox=is_sandbox,
                ),
                callback=self._on_capabilities_dismiss,
            )
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Failed to open capabilities screen")
            self._flash(str(exc), severity="warning")

    def _on_capabilities_dismiss(self, _result: t.Any) -> None:
        """Refresh runtime info after capabilities screen closes."""
        self._run_command(self._refresh_runtime)

    # ==================================================================
    # Prompt history
    # ==================================================================

    def _load_prompt_history(self) -> None:
        """Load prompt history from persistent JSONL file."""
        try:
            if not _HISTORY_FILE.is_file():
                return
            entries: list[str] = []
            for raw_line in _HISTORY_FILE.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    text = json.loads(line).get("text", "")
                except (json.JSONDecodeError, AttributeError):
                    logger.debug("Skipping malformed history entry")
                    continue
                if text and (not entries or entries[-1] != text):
                    entries.append(text)
            self._prompt_history = entries[-_MAX_HISTORY:]
        except OSError:
            logger.opt(exception=True).debug("Could not read prompt history file")

    def _save_prompt_entry(self, text: str) -> None:
        """Append a single prompt entry to the persistent history file."""
        try:
            _HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
            with _HISTORY_FILE.open("a", encoding="utf-8") as f:
                f.write(json.dumps({"text": text}) + "\n")
        except OSError:
            logger.opt(exception=True).debug("Could not write prompt history entry")

    def _history_navigate(self, direction: int) -> None:
        """Navigate prompt history. direction: -1 for up, 1 for down."""
        if not self._prompt_history:
            return
        composer = self.query_one("#composer", ComposerInput)

        if self._history_index == -1:
            if direction == -1:
                self._history_stash = composer.value
                self._history_index = len(self._prompt_history) - 1
            else:
                return
        else:
            new_index = self._history_index + direction
            if new_index < 0:
                return
            if new_index >= len(self._prompt_history):
                self._history_index = -1
                self._set_composer_text(composer, self._history_stash)
                return
            self._history_index = new_index

        self._set_composer_text(composer, self._prompt_history[self._history_index])

    def _set_composer_text(self, composer: ComposerInput, text: str) -> None:
        """Replace composer text and move cursor to end."""
        composer.clear_pastes()
        composer.load_text(text)
        end = composer.document.end
        composer.move_cursor(end)

    # ==================================================================
    # Copy and export
    # ==================================================================

    def _copy_to_os_clipboard(self, text: str) -> None:
        """Copy text to OS clipboard with fallback for terminals without OSC 52."""
        import shutil
        import subprocess
        import sys

        # Sanitize: replace unrepresentable characters so encode() never raises
        safe_text = text.encode("utf-8", errors="replace").decode("utf-8")

        # Try Textual's OSC 52 first (works in iTerm2, WezTerm, kitty, etc.)
        with contextlib.suppress(Exception):
            self.copy_to_clipboard(safe_text)

        # Also try native clipboard commands as fallback
        if sys.platform == "darwin":
            cmd = "pbcopy"
        elif shutil.which("xclip"):
            cmd = "xclip -selection clipboard"
        elif shutil.which("xsel"):
            cmd = "xsel --clipboard --input"
        elif shutil.which("wl-copy"):
            cmd = "wl-copy"
        else:
            return
        with contextlib.suppress(subprocess.SubprocessError, FileNotFoundError, OSError):
            subprocess.run(  # noqa: S603 - command is selected from a fixed local allowlist
                cmd.split(),
                input=safe_text.encode("utf-8"),
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

    def _copy_last_assistant(self) -> None:
        """Copy the last assistant message to clipboard."""
        session = self._active_session()
        if session is None:
            return
        for entry in reversed(session.transcript):
            if entry.kind == "assistant":
                self._copy_to_os_clipboard(entry.body)
                self._flash("Copied to clipboard", severity="success")
                return
        self._flash("No assistant message to copy", severity="warning")

    @work(group="command", exclusive=True)
    async def _export_session(self, filename: str | None = None) -> None:
        """Export session transcript to a markdown file."""
        session = self._active_session()
        if session is None:
            self._flash("No active session to export", severity="warning")
            return

        if filename is None:
            sid_prefix = session.info.session_id[:8]
            filename = f"session-{sid_prefix}.md"

        lines: list[str] = []
        title = session.info.session_id[:8]
        lines.append(f"# {title}\n")

        for entry in session.transcript:
            if entry.kind == "user":
                lines.append(f"> {entry.body}\n")
            elif entry.kind == "assistant":
                lines.append(f"{entry.body}\n")
            elif entry.kind == "tool":
                lines.append(f"```\n{entry.title}: {entry.body}\n```\n")
            elif entry.kind == "error":
                lines.append(f"**Error:** {entry.body}\n")

        content = "\n".join(lines)
        try:
            Path(filename).write_text(content, encoding="utf-8")
            self._flash(f"Exported to {filename}", severity="success")
        except Exception as exc:
            self._flash(f"Export failed: {exc}", severity="error")

    # ==================================================================
    # Session title
    # ==================================================================

    def _rename_session(self, new_title: str) -> None:
        """Rename the active session."""
        session = self._active_session()
        if session is None:
            self._flash("No active session to rename", severity="warning")
            return
        logger.info("Session rename | session={} title={}", session.info.session_id[:8], new_title)
        session.title = new_title
        self._sync_sessions()
        self._update_context()
        self._flash(f"Session renamed to '{new_title}'", severity="success")

    # ==================================================================
    # Internal helpers
    # ==================================================================

    def _active_session(self) -> SessionRecord | None:
        if self.active_session_id is None:
            return None
        return self.sessions.get(self.active_session_id)

    def _set_active_session_agent(self, agent_name: str) -> None:
        """Update the active session's primary agent without recreating the session."""
        session = self._active_session()
        if session is None:
            return
        if agent_name == "default":
            session.info.agent = None
            session.info.capability = None
            self._sync_sessions()
            self._update_context()
            return
        session.info.agent = agent_name
        capability_name = self._capability_for_agent(agent_name)
        if capability_name is not None:
            session.info.capability = capability_name
        self._sync_sessions()
        self._update_context()

    def _append_transcript(
        self, entry: TranscriptEntry, session_id: str, *, scroll: bool = True
    ) -> None:
        record = self.sessions.get(session_id)
        if record is None:
            return
        record.transcript.append(entry)
        if self.active_session_id == session_id:
            conv = self.query_one("#conversation", ConversationView)
            self.call_after_refresh(conv.append_entry, entry, scroll=scroll)

    def _commit_draft_to_transcript(self, session_id: str) -> None:
        """Flush live draft text into transcript and reset draft widget state."""
        draft = self.query_one("#draft", StreamingDraft)
        content = draft.finish_stream()
        turn_state = self._turn_state.get(session_id)
        if turn_state is not None:
            turn_state.draft_text = ""
            if turn_state.phase == "generating":
                turn_state.phase = "idle"
        if content.strip():
            self._append_transcript(
                TranscriptEntry(kind="assistant", title="assistant", body=content),
                session_id,
            )
        draft.clear_stream()
        self._draft_active = False

    def _sync_conversation(self) -> None:
        try:
            conversation = self.query_one("#conversation", ConversationView)
        except Exception:
            return  # Widget already torn down during shutdown
        session = self._active_session()
        if session is None:
            conversation.show_empty()
        else:
            conversation.load_session(session.transcript)

    def _sync_sessions(self) -> None:
        """Kept as a no-op — session state is shown via the session picker screen."""

    def _capability_for_agent(self, agent_name: str) -> str | None:
        """Return the loaded capability name for a unique agent match."""
        if self.runtime_info is None:
            return None
        matches = [
            capability.name
            for capability in self.runtime_info.capabilities
            for agent in capability.agents
            if agent.name == agent_name
        ]
        if len(matches) == 1:
            return matches[0]
        return None

    def _platform_model_ids(self) -> list[str]:
        return [model["id"] for model in self._platform_models if model.get("enabled", True)]

    def _clear_platform_proxy_state(self) -> None:
        self._platform_models = []
        self._litellm_key_expires_at = None
        os.environ.pop(_DREADNODE_LLM_BASE_ENV, None)
        os.environ.pop(_DREADNODE_LLM_API_KEY_ENV, None)

    @staticmethod
    def _parse_expires_at(value: t.Any) -> datetime | None:
        if not isinstance(value, str) or not value.strip():
            return None
        candidate = value.strip()
        if candidate.endswith("Z"):
            candidate = f"{candidate[:-1]}+00:00"
        try:
            parsed = datetime.fromisoformat(candidate)
        except ValueError:
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed

    @staticmethod
    def _extract_platform_models(payload: dict[str, t.Any]) -> list[dict[str, t.Any]]:
        models = payload.get("models") if isinstance(payload, dict) else None
        if isinstance(models, dict):
            entries: list[dict[str, t.Any]] = []
            for model_id, entry in models.items():
                if not isinstance(model_id, str):
                    continue
                if isinstance(entry, dict):
                    merged = dict(entry)
                    merged.setdefault("id", model_id)
                    entries.append(merged)
                else:
                    entries.append({"id": model_id})
        elif isinstance(models, list):
            entries = [entry for entry in models if isinstance(entry, dict)]
        else:
            return []

        results: list[dict[str, t.Any]] = []
        for entry in entries:
            model_id = entry.get("id")
            if not isinstance(model_id, str) or not model_id.startswith("dn/"):
                continue
            enabled = True
            status = entry.get("status")
            name = None
            if "enabled" in entry:
                enabled = bool(entry.get("enabled"))
            if isinstance(entry.get("name"), str):
                name = entry.get("name")
            result: dict[str, t.Any] = {"id": model_id, "enabled": enabled, "status": status}
            if name:
                result["name"] = name
            results.append(result)
        return results

    @staticmethod
    def _is_litellm_service_unavailable(exc: Exception) -> bool:
        message = str(exc)
        if "503" in message:
            return True
        status_code = getattr(getattr(exc, "response", None), "status_code", None)
        return status_code == 503

    async def _refresh_platform_models_and_key(self, api: ApiClient) -> None:
        self._clear_platform_proxy_state()
        try:
            t0 = time.monotonic()
            preferences = await asyncio.to_thread(api.get_user_preferences)
            logger.debug(
                "Boot timing | get_user_preferences={:.0f}ms", (time.monotonic() - t0) * 1000
            )
        except Exception as exc:
            logger.warning("Failed to fetch user preferences: {}", exc)
            return

        self._platform_models = self._extract_platform_models(preferences)
        if not self._platform_models:
            return
        await self._provision_litellm_key(api)

    async def _provision_litellm_key(self, api: ApiClient | None = None) -> None:
        if api is None and not self.authenticated:
            return
        org = self._connection_manager._org
        if api is None:
            try:
                api, _profile = _platform_client()
                if org is None:
                    org = _profile.default_organization
            except Exception:
                logger.debug("Cannot provision LiteLLM key: no platform client available")
                return
        if not org:
            logger.debug("Cannot provision LiteLLM key: no org context available")
            return
        try:
            t0 = time.monotonic()
            result = await asyncio.to_thread(api.provision_inference_key, org)
            logger.debug(
                "LiteLLM key provisioned | elapsed={:.0f}ms", (time.monotonic() - t0) * 1000
            )
        except Exception as exc:
            if self._is_litellm_service_unavailable(exc):
                self._flash(_PLATFORM_MODELS_UNAVAILABLE_MESSAGE, severity="info")
                self._clear_platform_proxy_state()
                return
            logger.warning("Failed to provision LiteLLM key: {}", exc)
            self._flash("Failed to provision LiteLLM key", severity="warning")
            return

        base_url = result.get("base_url") or result.get("url")
        api_key = result.get("api_key") or result.get("key")
        if isinstance(base_url, str) and isinstance(api_key, str):
            os.environ[_DREADNODE_LLM_BASE_ENV] = base_url
            os.environ[_DREADNODE_LLM_API_KEY_ENV] = api_key

        self._litellm_key_expires_at = self._parse_expires_at(
            result.get("expires_at") or result.get("expiresAt")
        )

    async def _ensure_litellm_key_fresh(self, *, now: datetime | None = None) -> None:
        if not self.authenticated:
            return
        if not self._platform_models:
            return
        current_time = now or datetime.now(UTC)
        expires_at = self._litellm_key_expires_at
        if expires_at is None:
            await self._provision_litellm_key()
            return
        if expires_at <= current_time + _LITELLM_REFRESH_WINDOW:
            await self._provision_litellm_key()

    def _on_model_changed(self, new_model: str) -> None:
        """Restore per-model variant state after model switch."""
        self.model = new_model
        active = self._active_session()
        if active is not None:
            active.model = new_model
        if new_model in self._model_variants:
            # User has an explicit preference for this model (including "" for off)
            stored = self._model_variants[new_model]
            if stored:
                from dreadnode.app.tui.model_variants import get_variants

                variants = get_variants(new_model)
                if stored in variants:
                    self.thinking_enabled = True
                    self.effort_label = stored
                else:
                    # Model doesn't support this variant anymore
                    del self._model_variants[new_model]
                    self.thinking_enabled = False
                    self.effort_label = ""
            else:
                # User explicitly disabled thinking for this model
                self.thinking_enabled = False
                self.effort_label = ""
        else:
            # First time seeing this model — apply sane default
            from dreadnode.app.tui.model_variants import default_effort

            fallback = default_effort(new_model)
            if fallback:
                self.thinking_enabled = True
                self.effort_label = fallback
                self._model_variants[new_model] = fallback
            else:
                self.thinking_enabled = False
                self.effort_label = ""
        self._update_context()

    # ==================================================================
    # Session state stash/restore (for runtime switching)
    # ==================================================================

    def _stash_session_state(self) -> SessionStateBundle:
        from dreadnode.app.tui.connection import SessionStateBundle as _Bundle

        return _Bundle(
            sessions=dict(self.sessions),
            active_session_id=self.active_session_id,
            turn_counts=dict(self._turn_counts),
            session_allowlist={k: set(v) for k, v in self._session_allowlist.items()},
            turn_state=dict(self._turn_state),
            pending_messages={k: list(v) for k, v in self._pending_messages.items()},
            draft_active=self._draft_active,
            inline_activity_sessions=set(self._inline_activity_sessions),
        )

    def _restore_session_state(self, bundle: SessionStateBundle) -> None:
        self.sessions = bundle.sessions
        self.active_session_id = bundle.active_session_id
        self._turn_counts = bundle.turn_counts
        self._session_allowlist = bundle.session_allowlist
        self._turn_state = bundle.turn_state
        self._pending_messages = bundle.pending_messages
        self._draft_active = bundle.draft_active
        self._inline_activity_sessions = bundle.inline_activity_sessions
        self._sync_sessions()
        self._sync_conversation()
        self._update_context()
        self._update_remote_status()

    async def _on_remote_connected(self) -> None:
        """Called after RuntimeConnectionManager.connect() succeeds.

        Clears local session state from the UI, refreshes runtime info and
        sessions from the remote server, and updates the status bar.
        """
        # Clear local sessions/state from the UI (local bundle is already stashed)
        self.sessions = {}
        self.active_session_id = None
        self._turn_state = {}
        self._pending_messages = {}
        self._draft_active = False
        self._inline_activity_sessions = set()
        self._turn_counts = {}
        self._session_allowlist = {}

        # Refresh from the remote server
        await self._refresh_runtime()
        await self._refresh_server_sessions()

        # If no session exists on the remote, create one
        if self.active_session_id is None:
            await self.__create_new_session()

        self._update_remote_status()
        self._sync_conversation()

    async def _on_remote_disconnected(self) -> None:
        """Called after RuntimeConnectionManager.disconnect() succeeds.

        Local session state is already restored by on_restore_state callback.
        This refreshes runtime info from the local server and updates the UI.
        """
        await self._refresh_runtime()
        await self._refresh_server_sessions()
        self._update_remote_status()

    def _update_remote_status(self) -> None:
        """Update status bar to reflect remote/local connection state."""
        if self._connection_manager.is_remote:
            info = self._connection_manager.connection_info
            if info:
                self.remote_info = f"remote · {info.runtime_id[:8]}"
            else:
                self.remote_info = "remote"
        else:
            self.remote_info = ""

    def _update_context(self) -> None:
        active = self._active_session()
        if active:
            self.session_label = active.info.session_id[:8]
            self.agent_name = active.info.agent or active.info.capability or "default"
        else:
            self.session_label = "none"
            self.agent_name = "default"
        if self._connection_manager.is_remote:
            info = self._connection_manager.connection_info
            self.connection = f"remote · {info.runtime_id[:8]}" if info else "remote"
        elif self.server_url is not None:
            from urllib.parse import urlparse

            hostname = urlparse(self.server_url).hostname or self.server_url
            self.connection = f"remote · {hostname}"
        else:
            self.connection = "local"
        self.model_name = self.model
        try:
            _name, profile = _active_profile()
        except Exception:
            logger.opt(exception=True).debug("Could not load profile for context update")
            profile = None
        if profile and profile.default_workspace:
            if profile.default_project:
                self.workspace_label = f"{profile.default_workspace}/{profile.default_project}"
            else:
                self.workspace_label = profile.default_workspace
        else:
            self.workspace_label = ""

    def _dismiss_welcome(self) -> None:
        """Hide the welcome screen and show the conversation."""
        welcome = self.query_one("#welcome", Welcome)
        if welcome.is_visible:
            welcome.dismiss()
            self.query_one("#conversation", ConversationView).display = True

    def _show_inline_activity(self, session_id: str, label: str) -> None:
        """Render a removable activity indicator inline in the conversation."""
        if session_id in self._inline_activity_sessions:
            return
        self._inline_activity_sessions.add(session_id)
        if self.active_session_id != session_id:
            return
        conv = self.query_one("#conversation", ConversationView)
        conv.write_activity(f"{label}...")

    def _clear_inline_activity(self, session_id: str) -> None:
        """Remove the inline activity indicator."""
        if session_id not in self._inline_activity_sessions:
            return
        self._inline_activity_sessions.discard(session_id)
        conv = self.query_one("#conversation", ConversationView)
        conv.clear_activity()

    def _set_composer_enabled(self, enabled: bool) -> None:
        """Toggle composer and its visual state."""
        self.query_one("#composer", ComposerInput).disabled = not enabled
        bar = self.query_one("#composer-bar")
        if enabled:
            bar.remove_class("-disabled")
        else:
            bar.add_class("-disabled")

    def _set_status(self, text: str, *, busy: bool | None = None) -> None:
        self.status_text = text
        if busy is not None:
            self.busy = busy

    def _flash(self, message: str, *, severity: str = "info") -> None:
        self.call_after_refresh(self.query_one("#flash", Flash).flash, message, severity=severity)

    def _enter_connection_failed(self, message: str) -> None:
        """Show or update the connection-error modal.

        If the screen is already mounted (e.g. after a retry failure), it is
        updated in-place so the user never sees the main screen flash through.
        """
        from dreadnode.app.tui.screens.connection_error import ConnectionErrorScreen

        self.runtime_connected = True  # stop boot spinner

        # Update in-place if the screen is already showing.
        if isinstance(self.screen, ConnectionErrorScreen):
            self.screen.show_error(message)
            return

        self.push_screen(
            ConnectionErrorScreen(message),
            callback=self._on_connection_error_dismiss,
        )

    def _dismiss_connection_error_screen(self) -> None:
        """Pop the connection-error screen if it is currently showing."""
        from dreadnode.app.tui.screens.connection_error import ConnectionErrorScreen

        if isinstance(self.screen, ConnectionErrorScreen):
            self.screen.dismiss(True)

    def _on_connection_error_dismiss(self, retry: bool | None) -> None:
        if retry:
            # Should not happen — retries now go through RetryRequested.
            self._boot()
        else:
            self.exit()

    def on_connection_error_screen_retry_requested(self) -> None:
        """Handle retry from ConnectionErrorScreen — schedule _boot()."""
        self.call_later(self._boot)

    def _handle_authentication_error(self, message: str) -> None:
        logger.warning("Auth error triggered: {}", message)
        self.authenticated = False
        self._clear_platform_proxy_state()
        self._show_auth_modal(self._resolved_server_url(), reason=message)

    def _write_activity(self, message: str, *, style: str = "info") -> None:
        """Write an activity message inline in the conversation."""
        color = {
            "info": FG_MUTED,
            "success": FG_MUTED,
            "warning": WARNING,
            "error": ERROR,
        }.get(style, FG_MUTED)
        self.call_after_refresh(
            self.query_one("#conversation", ConversationView).write_system,
            message,
            style=color,
        )

    def _show_help(self) -> None:
        """Write help content inline into the conversation view."""
        self._dismiss_welcome()
        conv = self.query_one("#conversation", ConversationView)
        conv.write(render_help())

    def _write_session_listing(self) -> None:
        """Write formatted session list inline in the conversation."""
        from rich.text import Text as RichText

        if not self.sessions:
            self._flash("No active sessions", severity="warning")
            return

        conversation = self.query_one("#conversation", ConversationView)
        header = RichText()
        header.append("· ", style=INFO)
        header.append(f"Sessions ({len(self.sessions)})", style=f"bold {INFO}")
        conversation.write(header)

        for sid in sorted(self.sessions.keys(), reverse=True):
            rec = self.sessions[sid]
            display = rec.title or sid[:8]
            line = RichText()
            is_active = sid == self.active_session_id
            line.append("  ● " if is_active else "  ○ ", style=ACCENT if is_active else FG_FAINTEST)
            line.append(f"{display:<20}", style=FG if is_active else FG_SUBTLE)
            line.append(rec.info.agent or rec.info.capability or "default", style=FG_MUTED)
            line.append(f"  {rec.info.message_count} msgs", style=FG_FAINTEST)
            line.append(f"  {sid[:8]}", style=FG_FAINTEST)
            conversation.write(line)

    def _write_agent_listing(self) -> None:
        """Write formatted agent list inline in the conversation."""
        from rich.text import Text as RichText

        if self.runtime_info is None:
            self._flash("Runtime not loaded", severity="warning")
            return
        agents = [a for c in self.runtime_info.capabilities for a in c.agents]
        if not agents:
            self._flash("No agents loaded", severity="warning")
            return

        conversation = self.query_one("#conversation", ConversationView)
        header = RichText()
        header.append("· ", style=INFO)
        header.append(f"Agents ({len(agents)})", style=f"bold {INFO}")
        conversation.write(header)

        for a in agents:
            line = RichText()
            line.append(f"  {a.name:<20}", style=f"bold {FG}")
            line.append(a.capability, style=FG_MUTED)
            if a.model and a.model != "inherit":
                line.append(f"  {a.model}", style=FG_FAINTEST)
            conversation.write(line)
