"""Widgets and helpers for displaying tool calls."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from rich.text import Text
from textual.reactive import reactive
from textual.widget import Widget

from dreadnode.app.tui.theme import ACCENT, FG_FAINTEST, FG_MUTED

if TYPE_CHECKING:
    from rich.console import RenderableType


def render_tool_call(
    label: str,
    *,
    meta: str | None = None,
    details: str = "",
) -> Text:
    """Render a tool call as Rich Text.

    Pure rendering function — no awareness of display modes.
    Used by ToolCall.render() as the single output path.
    """
    text = Text()
    text.append("│ ", style=FG_FAINTEST)

    match = re.match(r"^([a-zA-Z0-9_-]+)\((.*)\)$", label)
    if match:
        name, args = match.groups()
        text.append(name, style=ACCENT)
        text.append(f"({args})", style=FG_MUTED)
    else:
        text.append(label, style=ACCENT)

    if meta:
        text.append("\n│ ↳ ", style=FG_FAINTEST)
        text.append(meta, style=FG_FAINTEST)

    if details:
        lines = details.splitlines()
        prefix = "\n│   " if meta else "\n│ ↳ "
        text.append(f"{prefix}{lines[0]}", style=FG_FAINTEST)
        for line in lines[1:]:
            text.append(f"\n│   {line}", style=FG_FAINTEST)

    return text


class ToolCall(Widget):
    """A widget to display a tool call — in-progress or completed.

    Used by both the live SSE path (tool_start → tool_end) and the
    transcript rebuild path. Stores full data; display mode is resolved
    at render time via app._output_mode.
    """

    tool_name: reactive[str] = reactive("")
    meta: reactive[str] = reactive("")
    details: reactive[str] = reactive("")
    error: reactive[str] = reactive("")

    def __init__(
        self,
        *,
        name: str,
        details: str = "",
        meta: str | None = None,
        error: str | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(**kwargs)
        self.tool_name = name
        self.details = details
        self.meta = meta or ""
        self.error = error or ""

    def _get_visible_details(self) -> str:
        """Return details respecting the app-level output mode.

        Applies 8-line truncation for display. The full details are
        always stored on the widget — truncation is render-time only.
        """
        if not self.details:
            return ""
        try:
            mode = self.app.output_mode  # type: ignore[attr-defined]
        except Exception:
            mode = "compact"
        if mode != "expanded":
            return ""
        lines = self.details.splitlines()
        if len(lines) > 8:
            omitted = len(lines) - 6
            return "\n".join(lines[:3] + [f"... {omitted} lines omitted ..."] + lines[-3:])
        return self.details

    def complete(
        self,
        *,
        meta: str | None = None,
        details: str = "",
        error: str | None = None,
    ) -> None:
        """Transition from in-progress to completed state."""
        if meta is not None:
            self.meta = meta
        self.details = details
        if error:
            self.error = error

    def render(self) -> RenderableType:
        """Render the tool call."""
        if self.error:
            return render_tool_call(self.tool_name, meta=f"error: {self.error}")
        visible_details = self._get_visible_details()
        return render_tool_call(
            self.tool_name,
            meta=None if visible_details else (self.meta or None),
            details=visible_details,
        )
