"""Headless execution mode for ``dn --print``."""

import os
import sys
import typing as t

from loguru import logger

from dreadnode.app.tui.client import DEFAULT_MODEL, RuntimeServerClient
from dreadnode.app.tui.event_contract import NormalizedEvent, normalize_event


async def run_print_mode(
    prompt: str,
    *,
    model: str | None = None,
    agent: str | None = None,
    capabilities_dirs: list[str] | None = None,
    capabilities: list[str] | None = None,
    system_prompt: str | None = None,
    server_url: str | None = None,
    platform_url: str | None = None,
) -> None:
    """Run a single prompt headlessly: stream response text to stdout, progress to stderr."""

    # Resolve model: explicit flag > profile default > hardcoded default
    if model is None:
        model = _resolve_default_model(platform_url)

    client = RuntimeServerClient(
        server_url=server_url,
        auto_start=server_url is None,
        capability_dirs=capabilities_dirs,
        enabled_capabilities=capabilities,
        system_prompt_append=system_prompt,
    )

    # Load platform profile if available
    _apply_platform_profile(client, platform_url)

    # Suppress noisy library output (litellm ANSI errors, etc.) from stdout/stderr
    # by redirecting litellm's output during the run.
    _suppress_library_noise()

    await client.start()

    # Validate --agent and --capability against loaded runtime
    runtime = await client.fetch_runtime_info()
    _validate_runtime_args(runtime, agent=agent, capabilities=capabilities)

    session = await client.create_session(agent=agent, model=model)
    session_id = session.session_id

    try:
        async for raw_event in client.stream_chat(
            session_id=session_id,
            message=prompt,
            model=model,
            agent=agent,
        ):
            event = normalize_event(raw_event, session_id)
            done = await _handle_event(event, client, session_id)
            if done:
                break
    except KeyboardInterrupt:
        raise SystemExit(130) from None
    except Exception as exc:
        _error(str(exc))
        raise SystemExit(1) from exc
    finally:
        # Final newline to ensure clean stdout
        sys.stdout.write("\n")
        sys.stdout.flush()
        await client.close()


async def _handle_event(
    event: NormalizedEvent,
    client: RuntimeServerClient,
    session_id: str,
) -> bool:
    """Process a single normalized event. Returns True when the turn is done."""
    etype = event.type

    if etype == "generation_step":
        if event.assistant_delta:
            sys.stdout.write(event.assistant_delta)
            sys.stdout.flush()

    elif etype == "generation_error":
        _error(event.error_text or "Generation error")
        raise SystemExit(1)

    elif etype == "human_prompt":
        prompt = event.human_prompt
        if prompt is None:
            return False

        if prompt.kind == "approval":
            await client.send_permission_response(
                session_id,
                prompt.request_id,
                "approve",
            )
        else:
            # Cannot handle interactive input in headless mode
            _error(f"Interactive input required: {prompt.question}")
            raise SystemExit(1)

    elif etype in {"agent_end", "error"}:
        if etype == "error":
            _error(event.error_text or "unknown error")
        return True

    return False


def _error(message: str) -> None:
    """Write an error message to stderr."""
    sys.stderr.write(f"error: {message}\n")
    sys.stderr.flush()


def _suppress_library_noise() -> None:
    """Suppress noisy library output that leaks to stdout/stderr.

    litellm in particular prints ANSI-colored error messages directly
    to stdout, which corrupts piped output.
    """
    os.environ.setdefault("LITELLM_LOG", "ERROR")
    os.environ.setdefault("LITELLM_SUPPRESS_DEBUG_INFO", "1")


def _apply_platform_profile(
    client: RuntimeServerClient,
    platform_url: str | None,
) -> None:
    """Load and apply the platform profile to the client."""
    try:
        from dreadnode.app.server.session import ServerConfig, UserConfig, urls_match

        cache_dir = _get_cache_dir()
        config = UserConfig.read(cache_dir / "config.yaml")

        if platform_url:
            # Find profile matching the override URL
            for profile in config.servers.values():
                if urls_match(profile.url, platform_url):
                    client.set_platform_profile(profile)
                    return
            # No matching profile — create a minimal one
            client.set_platform_profile(
                ServerConfig(url=platform_url, api_key="", default_organization=None)
            )
        elif config.active and config.active in config.servers:
            client.set_platform_profile(config.servers[config.active])
    except Exception:
        logger.debug("Could not load platform profile", exc_info=True)


def _validate_runtime_args(
    runtime: t.Any,
    *,
    agent: str | None,
    capabilities: list[str] | None,
) -> None:
    """Validate CLI args against loaded runtime state. Exits on mismatch."""
    enabled = [c for c in runtime.capabilities if getattr(c, "enabled", True)]
    loaded_capabilities = {c.name for c in enabled}
    available_agents = {"default"} | {a.name for c in enabled for a in c.agents}

    # Check --capability values matched something that loaded
    if capabilities:
        missing = [c for c in capabilities if c not in loaded_capabilities]
        if missing:
            _error(f"unknown capability(ies): {', '.join(missing)}")
            if loaded_capabilities:
                _error(f"available: {', '.join(sorted(loaded_capabilities))}")
            else:
                _error("no capabilities are loaded")
            raise SystemExit(1)

    # Check --agent exists
    if agent and agent not in available_agents:
        _error(f"unknown agent: {agent}")
        _error(f"available: {', '.join(sorted(available_agents))}")
        raise SystemExit(1)


def _resolve_default_model(platform_url: str | None) -> str:
    """Resolve default model from profile, falling back to DEFAULT_MODEL."""
    if platform_url:
        return DEFAULT_MODEL
    try:
        from dreadnode.app.server.session import UserConfig

        cache_dir = _get_cache_dir()
        config = UserConfig.read(cache_dir / "config.yaml")
        if config.active and config.active in config.servers:
            profile = config.servers[config.active]
            if profile.default_model:
                return profile.default_model
    except Exception:
        logger.debug("Could not load profile for default model", exc_info=True)
    return DEFAULT_MODEL


def _get_cache_dir() -> t.Any:
    """Get the Dreadnode cache directory."""
    from pathlib import Path

    return Path.home() / ".dreadnode"
