"""AIRT subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    PlatformConfig,
    _parse_json_object_option,
    _parse_json_option,
    _print_json,
    _render_airt_assessment,
    _render_airt_assessment_list,
    _render_airt_reports,
    configured_dreadnode,
    console,
    require_workspace_context,
)

cli = cyclopts.App(name="airt", help="AI red teaming for models and agents.")


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@cli.command()
def create(
    *,
    name: str,
    project_id: str,
    description: t.Annotated[str | None, cyclopts.Parameter(help="Assessment description")] = None,
    session_id: t.Annotated[str | None, cyclopts.Parameter(help="Session ID to associate")] = None,
    target_config: t.Annotated[
        str | None, cyclopts.Parameter(help="Target configuration as JSON")
    ] = None,
    attacker_config: t.Annotated[
        str | None, cyclopts.Parameter(help="Attacker configuration as JSON")
    ] = None,
    attack_manifest: t.Annotated[
        str | None, cyclopts.Parameter(help="Attack manifest as JSON")
    ] = None,
    workflow_run_id: t.Annotated[str | None, cyclopts.Parameter(help="Workflow run ID")] = None,
    workflow_script: t.Annotated[
        str | None, cyclopts.Parameter(help="Workflow script content")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Create a new AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.create_airt_assessment(
        org,
        workspace,
        name=name,
        project_id=project_id,
        description=description,
        session_id=session_id,
        target_config=_parse_json_object_option(target_config, field_name="--target-config"),
        attacker_config=_parse_json_object_option(attacker_config, field_name="--attacker-config"),
        attack_manifest=_parse_json_option(attack_manifest, field_name="--attack-manifest"),
        workflow_run_id=workflow_run_id,
        workflow_script=workflow_script,
    )
    _render_airt_assessment(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID filter")] = None,
    page: int = 1,
    page_size: int = 50,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """List AIRT assessments."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.list_airt_assessments(
        org,
        workspace,
        project_id=project_id,
        page=page,
        page_size=page_size,
    )
    _render_airt_assessment_list(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    assessment_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get an AIRT assessment by ID."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_assessment(org, workspace, assessment_id)
    _render_airt_assessment(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


@cli.command()
def update(
    assessment_id: str,
    *,
    name: t.Annotated[str | None, cyclopts.Parameter(help="New assessment name")] = None,
    description: t.Annotated[
        str | None, cyclopts.Parameter(help="New assessment description")
    ] = None,
    status: t.Annotated[
        t.Literal["pending", "running", "completed", "failed"] | None,
        cyclopts.Parameter(help="Assessment status"),
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Update an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.update_airt_assessment(
        org,
        workspace,
        assessment_id,
        status=status,
        name=name,
        description=description,
    )
    _render_airt_assessment(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command()
def delete(
    assessment_id: str,
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Delete an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    client.delete_airt_assessment(org, workspace, assessment_id)
    console.print(f"Deleted AIRT assessment [dim]{assessment_id}[/dim]")


# ---------------------------------------------------------------------------
# reports
# ---------------------------------------------------------------------------


@cli.command()
def reports(
    assessment_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """List reports for an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.list_airt_reports(org, workspace, assessment_id)
    _render_airt_reports(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# report
# ---------------------------------------------------------------------------


@cli.command()
def report(
    assessment_id: str,
    report_id: str,
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get a specific report for an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_report(org, workspace, assessment_id, report_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# analytics
# ---------------------------------------------------------------------------


@cli.command()
def analytics(
    assessment_id: str,
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get analytics for an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_analytics(org, workspace, assessment_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# traces
# ---------------------------------------------------------------------------


@cli.command()
def traces(
    assessment_id: str,
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get trace stats for an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_trace_stats(org, workspace, assessment_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# attacks
# ---------------------------------------------------------------------------


@cli.command()
def attacks(
    assessment_id: str,
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get attack spans for an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_attack_spans(org, workspace, assessment_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# trials
# ---------------------------------------------------------------------------


@cli.command()
def trials(
    assessment_id: str,
    *,
    attack_name: t.Annotated[str | None, cyclopts.Parameter(help="Filter by attack name")] = None,
    min_score: t.Annotated[float | None, cyclopts.Parameter(help="Minimum score filter")] = None,
    jailbreaks_only: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    limit: t.Annotated[int, cyclopts.Parameter(help="Maximum results to return")] = 100,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get trial spans for an AIRT assessment."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_trial_spans(
        org,
        workspace,
        assessment_id,
        attack_name=attack_name,
        min_score=min_score,
        jailbreaks_only=jailbreaks_only,
        limit=limit,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# project-summary
# ---------------------------------------------------------------------------


@cli.command(name="project-summary")
def project_summary(
    project: str,
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get a summary for an AIRT project."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_project_summary(org, workspace, project)
    _print_json(payload)


# ---------------------------------------------------------------------------
# findings
# ---------------------------------------------------------------------------


@cli.command()
def findings(
    project: str,
    *,
    severity: t.Annotated[str | None, cyclopts.Parameter(help="Severity filter")] = None,
    category: t.Annotated[str | None, cyclopts.Parameter(help="Category filter")] = None,
    attack_name: t.Annotated[str | None, cyclopts.Parameter(help="Attack name filter")] = None,
    min_score: t.Annotated[float | None, cyclopts.Parameter(help="Minimum score filter")] = None,
    sort_by: t.Literal["score", "severity", "category", "attack_name", "created_at"] = "score",
    sort_dir: t.Literal["asc", "desc"] = "desc",
    page: int = 1,
    page_size: int = 50,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get findings for an AIRT project."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.get_airt_project_findings(
        org,
        workspace,
        project,
        severity=severity,
        category=category,
        attack_name=attack_name,
        min_score=min_score,
        sort_by=sort_by,
        sort_dir=sort_dir,
        page=page,
        page_size=page_size,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# generate-project-report
# ---------------------------------------------------------------------------


@cli.command(name="generate-project-report")
def generate_project_report(
    project: str,
    *,
    format: t.Literal["markdown", "json", "both"] = "both",
    model_profile: t.Annotated[str | None, cyclopts.Parameter(help="Model profile as JSON")] = None,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Generate a report for an AIRT project."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="AIRT")
    payload = client.generate_airt_project_report(
        org,
        workspace,
        project,
        fmt=format,
        model_profile=_parse_json_object_option(model_profile, field_name="--model-profile"),
    )
    _print_json(payload)
