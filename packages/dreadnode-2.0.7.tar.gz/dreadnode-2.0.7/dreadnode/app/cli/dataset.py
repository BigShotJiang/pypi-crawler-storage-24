"""Dataset subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    RegistryConfig,
    _parse_versioned_ref,
    _print_json,
    _render_package_list,
    configured_dreadnode,
    console,
    require_registry_context,
)

cli = cyclopts.App(name="dataset", help="Manage datasets.")


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


@cli.command()
def push(
    path: str,
    *,
    name: str | None = None,
    skip_upload: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Build and push a dataset artifact."""
    dn = configured_dreadnode(registry)
    result = dn.push_dataset(path, name=name, skip_upload=skip_upload)
    if not result.success:
        raise SystemExit("; ".join(result.errors) or "Dataset push failed")

    if result.package_name is None or result.package_version is None:
        raise SystemExit("Dataset push returned incomplete metadata")

    name = result.package_name
    version = result.package_version
    if skip_upload or not dn.can_sync:
        console.print(f"Built [cyan]{name}[/cyan]@[dim]{version}[/dim]")
        return
    digest = result.manifest_digest or "unknown"
    console.print(f"Pushed [cyan]{name}[/cyan]@[dim]{version}[/dim] [dim]({digest})[/dim]")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """List dataset artifacts in the organization."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    packages = client.list_datasets(org)
    _render_package_list(packages, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command(name="get-metadata")
def get_metadata(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Get metadata of a dataset artifact (NAME@VERSION)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    package = client.get_dataset(org, name, version)
    _print_json(package)


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command()
def delete(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Delete a dataset artifact (NAME@VERSION)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    client.delete_dataset(org, name, version)
    console.print(f"Deleted [dim]{org}/[/dim][cyan]{name}[/cyan]@[dim]{version}[/dim]")


# ---------------------------------------------------------------------------
# download
# ---------------------------------------------------------------------------


@cli.command()
def download(
    ref: str,
    *,
    output: str | None = None,
    split: str | None = None,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Download a dataset file (NAME@VERSION)."""
    import urllib.request

    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    result = client.download_dataset(org, name, version, split=split)
    url = result.get("url")
    if not url:
        raise SystemExit(f"Download not ready: {result.get('status', 'unknown')}")

    if output:
        filename = result.get("filename", f"{name}-{version}")
        dest = output if output != "-" else filename
        print(f"Downloading {filename}...")
        urllib.request.urlretrieve(url, dest)  # noqa: S310
        print(f"Saved to {dest}")
    else:
        print(f"Download URL (expires {result.get('expires_at', 'soon')}):")
        print(url)
