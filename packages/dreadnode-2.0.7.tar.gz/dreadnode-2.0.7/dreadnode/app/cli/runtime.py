"""Runtime subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    PlatformConfig,
    _render_runtime,
    _render_runtime_list,
    configured_dreadnode,
    require_workspace_context,
)

cli = cyclopts.App(name="runtime", help="Manage agent runtime environments.")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """List available runtimes."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="Runtime")
    payload = client.list_runtimes(org, workspace)
    _render_runtime_list(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    runtime_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get details of a runtime."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_workspace_context(dn, label="Runtime")
    payload = client.get_runtime(org, workspace, runtime_id)
    _render_runtime(payload, as_json=as_json)
