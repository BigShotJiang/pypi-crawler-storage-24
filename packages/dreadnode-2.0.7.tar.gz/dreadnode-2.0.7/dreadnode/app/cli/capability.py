"""Capability subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    RegistryConfig,
    _parse_versioned_ref,
    _print_json,
    _render_capability_list,
    _sync_progress,
    configured_dreadnode,
    console,
    require_registry_context,
)

cli = cyclopts.App(name="capability", help="Manage agent definitions, tools, and skills.")


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


@cli.command()
def push(
    path: str,
    *,
    name: str | None = None,
    skip_upload: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Build and push a capability artifact."""
    dn = configured_dreadnode(registry)
    try:
        result = dn.push_capability(
            path,
            name=name,
            skip_upload=skip_upload,
            force=force,
            public=public,
        )
    except (ValueError, RuntimeError) as exc:
        raise SystemExit(str(exc)) from exc

    name = result.name
    version = result.version
    if result.status == "built":
        console.print(f"Built [cyan]{name}[/cyan]@[dim]{version}[/dim]")
    elif result.status == "up_to_date":
        console.print(f"[cyan]{name}[/cyan]@[dim]{version}[/dim] already up to date")
    else:
        digest = result.digest or "unknown"
        console.print(f"Pushed [cyan]{name}[/cyan]@[dim]{version}[/dim] [dim]({digest})[/dim]")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    name: str | None = None,
    limit: int = 50,
    offset: int = 0,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """List capability artifacts in the organization."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    payload = client.list_capabilities(org, name=name, limit=limit, offset=offset)
    _render_capability_list(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Get details of a capability artifact (NAME@VERSION)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    payload = client.get_capability(org, name, version)
    _print_json(payload)


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command()
def delete(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Delete a capability artifact (NAME@VERSION)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    client.delete_capability(org, name, version)
    console.print(f"Deleted [dim]{org}/[/dim][cyan]{name}[/cyan]@[dim]{version}[/dim]")


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


@cli.command()
def update(
    ref: str,
    *,
    public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    private: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Update capability metadata such as visibility (NAME@VERSION).

    Exactly one of --public or --private must be provided.
    """
    if public == private:
        raise SystemExit("Exactly one of --public or --private must be provided")

    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    payload = client.update_capability_artifact(
        org,
        name,
        version,
        is_public=public,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# sync
# ---------------------------------------------------------------------------


@cli.command()
def sync(
    directory: str,
    *,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Sync capabilities from a directory to the platform."""
    dn = configured_dreadnode(registry)
    result = dn.sync_capabilities(
        directory,
        force=force,
        public=public,
        on_progress=_sync_progress,
    )

    total = len(result.uploaded) + len(result.skipped) + len(result.failed)
    console.print(
        f"\nSynced {total} capability(ies): "
        f"[green]uploaded={len(result.uploaded)}[/green] "
        f"[dim]skipped={len(result.skipped)}[/dim] "
        f"[red]failed={len(result.failed)}[/red]"
    )
    if not result.ok:
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


@cli.command()
def validate(
    path: str,
    *,
    strict: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
) -> None:
    """Validate capability definitions."""
    from pathlib import Path

    from dreadnode.capabilities.capability import Capability

    resolved = Path(path).resolve()
    if not resolved.exists():
        console.print(f"[red]Path not found:[/red] {resolved}")
        raise SystemExit(1)

    # If path contains capability.yaml directly, validate just that one
    if (resolved / "capability.yaml").exists():
        dirs = [resolved]
    else:
        # Discover all capability subdirectories
        dirs = sorted(
            d for d in resolved.iterdir() if d.is_dir() and (d / "capability.yaml").exists()
        )
        if not dirs:
            console.print(
                f"[red]No capability.yaml found in {resolved} or its subdirectories[/red]"
            )
            raise SystemExit(1)

    errors: list[tuple[str, str]] = []
    warnings: list[str] = []

    for cap_dir in dirs:
        dir_name = cap_dir.name
        try:
            cap = Capability(cap_dir)
            agents = cap.agents
            tools = cap.tools
            skills = cap.skills_paths or []
            mcp = cap.mcp_server_defs

            health_errors = [h for h in cap.component_health if h.get("status") == "error"]

            parts = []
            parts.append(f"agents={len(agents)}")
            parts.append(f"tools={len(tools)}")
            parts.append(f"skills={len(skills)}")
            parts.append(f"mcp={len(mcp)}")
            summary = ", ".join(parts)

            if health_errors:
                warnings.append(cap.name)
                console.print(f"  [yellow]WARN[/yellow] {cap.name}@{cap.version} ({summary})")
                for h in health_errors:
                    console.print(f"       {h.get('component', '?')}: {h.get('error', 'unknown')}")
            else:
                console.print(f"  [green]OK[/green]   {cap.name}@{cap.version} ({summary})")
        except (ValueError, FileNotFoundError) as exc:
            errors.append((dir_name, str(exc)))
            console.print(f"  [red]FAIL[/red] {dir_name}: {exc}")

    total = len(dirs)
    failed = len(errors)
    warned = len(warnings)
    ok_count = total - failed - warned
    console.print(
        f"\nValidated {total} capability(ies): "
        f"[green]{ok_count} ok[/green], [yellow]{warned} warn[/yellow], [red]{failed} failed[/red]"
    )
    if errors or (strict and warnings):
        raise SystemExit(1)
