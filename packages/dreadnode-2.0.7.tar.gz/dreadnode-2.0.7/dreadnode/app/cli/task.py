"""Task subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    RegistryConfig,
    _list_all_tasks,
    _parse_task_ref,
    _print_json,
    _render_list,
    _summarize_task,
    _sync_progress,
    configured_dreadnode,
    console,
    require_registry_context,
)

cli = cyclopts.App(name="task", help="Manage security tasks.")


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


@cli.command()
def push(
    path: str,
    *,
    name: str | None = None,
    skip_upload: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Build and push a task artifact."""
    dn = configured_dreadnode(registry)
    result = dn.push_environment(
        path, name=name, skip_upload=skip_upload, force=force, public=public
    )
    if not result.success:
        raise SystemExit("; ".join(result.errors) or "Task push failed")

    if result.package_name is None or result.package_version is None:
        raise SystemExit("Task push returned incomplete metadata")

    name = result.package_name
    version = result.package_version
    if skip_upload or not dn.can_sync:
        console.print(f"Built [cyan]{name}[/cyan]@[dim]{version}[/dim]")
        return
    if result.blobs_uploaded == 0 and result.blobs_skipped > 0:
        console.print(f"[cyan]{name}[/cyan]@[dim]{version}[/dim] already up to date")
        return
    digest = result.manifest_digest or "unknown"
    console.print(f"Pushed [cyan]{name}[/cyan]@[dim]{version}[/dim] [dim]({digest})[/dim]")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """List task artifacts in the organization."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    tasks = _list_all_tasks(client, org)
    _render_list(
        tasks,
        as_json=as_json,
        summary=lambda p: _summarize_task(p, org=org),
        empty_msg="No tasks found",
    )


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Get details of a task artifact (NAME@latest)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    task_name, _ = _parse_task_ref(ref, field_name="ref", organization=org)
    payload = client.get_task(org, task_name)
    _print_json(payload)


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command()
def delete(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Delete a task artifact (NAME@latest)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    task_name, version = _parse_task_ref(ref, field_name="ref", organization=org)
    client.delete_task(org, task_name)
    console.print(f"Deleted [dim]{org}/[/dim][cyan]{task_name}[/cyan]@[dim]{version}[/dim]")


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


@cli.command()
def update(
    ref: str,
    *,
    public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    private: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Update task metadata such as visibility (NAME@latest).

    Exactly one of --public or --private must be provided.
    """
    if public == private:
        raise SystemExit("Exactly one of --public or --private must be provided")

    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    task_name, _ = _parse_task_ref(ref, field_name="ref", organization=org)
    payload = client.update_task_visibility(
        org,
        task_name,
        is_public=public,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# sync
# ---------------------------------------------------------------------------


@cli.command()
def sync(
    directory: str,
    *,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    workers: t.Annotated[int, cyclopts.Parameter(help="Parallel upload workers.")] = 8,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Sync task environments from a directory to the platform."""
    dn = configured_dreadnode(registry)
    result = dn.sync_environments(
        directory,
        force=force,
        public=public,
        max_workers=workers,
        on_progress=_sync_progress,
        on_status=lambda msg: console.print(msg),
    )

    total = len(result.uploaded) + len(result.skipped) + len(result.failed)
    console.print(
        f"\nSynced {total} task(s): "
        f"[green]uploaded={len(result.uploaded)}[/green] "
        f"[dim]skipped={len(result.skipped)}[/dim] "
        f"[red]failed={len(result.failed)}[/red]"
    )
    if not result.ok:
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


@cli.command()
def validate(
    path: str,
    *,
    strict: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    build: t.Annotated[
        bool, cyclopts.Parameter(negative=(), help="Run docker compose build for each task")
    ] = False,
) -> None:
    """Validate task definitions (recursively discovers task directories)."""
    import subprocess
    from pathlib import Path

    from dreadnode.packaging.task_validation import (
        ValidationIssue,
        discover_task_directories,
        validate_task_directory,
    )

    resolved = Path(path).resolve()
    if not resolved.exists():
        console.print(f"[red]Path not found:[/red] {resolved}")
        raise SystemExit(1)

    if (resolved / "task.yaml").is_file():
        dirs = [resolved]
        conflicts: list[tuple[Path, Path]] = []
    else:
        dirs, conflicts = discover_task_directories(resolved)
        if not dirs:
            console.print(f"[red]No task.yaml found in {resolved} or its subdirectories[/red]")
            raise SystemExit(1)

    errors: list[tuple[str, str]] = []
    warnings: list[str] = []

    for parent, nested in conflicts:
        rel_parent = parent.relative_to(resolved) if parent != resolved else Path(parent.name)
        rel_nested = nested.relative_to(resolved) if nested != resolved else Path(nested.name)
        errors.append((str(rel_nested), f"task nested inside another task ({rel_parent})"))
        console.print(f"  [red]FAIL[/red] {rel_nested}")
        console.print(f"       layout: task nested inside another task ({rel_parent})")

    for task_dir in dirs:
        dir_name = task_dir.name
        try:
            issues = validate_task_directory(task_dir, root_dir=resolved)
            errs = [i for i in issues if i.level == "error"]
            warns = [i for i in issues if i.level == "warning"]

            # Docker build check (only if metadata validation passed and --build set)
            if build and not errs and (task_dir / "docker-compose.yaml").is_file():
                result = subprocess.run(
                    ["docker", "compose", "build"],  # noqa: S607
                    cwd=task_dir,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if result.returncode != 0:
                    # Extract last meaningful line from stderr for the summary
                    stderr_lines = [ln for ln in result.stderr.strip().splitlines() if ln.strip()]
                    summary = stderr_lines[-1] if stderr_lines else "build failed"
                    errs.append(ValidationIssue("error", "docker-build", summary))

            if errs:
                errors.append((dir_name, "; ".join(i.message for i in errs)))
                console.print(f"  [red]FAIL[/red] {dir_name}")
                for i in errs:
                    console.print(f"       {i.component}: {i.message}")
            elif warns:
                warnings.append(dir_name)
                console.print(f"  [yellow]WARN[/yellow] {dir_name}")
                for i in warns:
                    console.print(f"       {i.component}: {i.message}")
            else:
                console.print(f"  [green]OK[/green]   {dir_name}")
        except Exception as exc:
            errors.append((dir_name, str(exc)))
            console.print(f"  [red]FAIL[/red] {dir_name}: {exc}")

    total = len(dirs)
    failed = len(errors)
    warned = len(warnings)
    ok_count = total - failed - warned
    console.print(
        f"\nValidated {total} task(s): "
        f"[green]{ok_count} ok[/green], [yellow]{warned} warn[/yellow], [red]{failed} failed[/red]"
    )
    if errors or (strict and warnings):
        raise SystemExit(1)
