"""Optimize subcommands for the cyclopts CLI."""

import json
import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    PlatformConfig,
    _parse_versioned_ref,
    _render_optimization_artifacts,
    _render_optimization_job,
    _render_optimization_job_list,
    _render_optimization_logs,
    _wait_for_optimization_job,
    configured_dreadnode,
    require_optimization_context,
)

RewardRecipeChoice = t.Literal[
    "contains_v1",
    "exact_match_v1",
    "row_reward_v1",
    "trajectory_imitation_v1",
]

OptimizationStatus = t.Literal[
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]

OptimizationBackend = t.Literal["gepa"]

TargetKind = t.Literal["capability_agent"]

cli = cyclopts.App(name="optimize", help="Optimize agents with jobs.")


# ---------------------------------------------------------------------------
# submit (default command — runs when `dn optimize` has no subcommand)
# ---------------------------------------------------------------------------


@cli.command(name="submit")
def submit(
    *,
    model: t.Annotated[str, cyclopts.Parameter(help="Model identifier")],
    capability: t.Annotated[
        str,
        cyclopts.Parameter(help="Capability ref in NAME@VERSION form"),
    ],
    dataset: t.Annotated[
        str,
        cyclopts.Parameter(help="Training dataset ref in NAME@VERSION form"),
    ],
    reward_recipe: t.Annotated[
        RewardRecipeChoice,
        cyclopts.Parameter(
            help="Hosted reward recipe name",
        ),
    ],
    val_dataset: t.Annotated[
        str | None,
        cyclopts.Parameter(
            help="Optional validation dataset ref in NAME@VERSION form",
        ),
    ] = None,
    reward_params: t.Annotated[
        str | None, cyclopts.Parameter(help="Reward recipe parameters as JSON")
    ] = None,
    agent_name: t.Annotated[
        str | None,
        cyclopts.Parameter(
            help="Optional agent name when the capability exports multiple agents",
        ),
    ] = None,
    objective: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Optional natural-language optimization objective"),
    ] = None,
    name: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Optional optimization job name"),
    ] = None,
    project_ref: t.Annotated[
        str | None, cyclopts.Parameter(help="Project reference for tracking")
    ] = None,
    run_ref: t.Annotated[str | None, cyclopts.Parameter(help="Run reference for tracking")] = None,
    tag: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(negative_iterable=(), help="Tag for the job (repeatable)"),
    ] = None,
    seed: t.Annotated[
        int | None, cyclopts.Parameter(help="Random seed for reproducibility")
    ] = None,
    max_metric_calls: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum metric evaluation calls")
    ] = None,
    reflection_lm: t.Annotated[
        str | None, cyclopts.Parameter(help="Language model for reflection steps")
    ] = None,
    max_reflection_examples: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum examples for reflection")
    ] = None,
    max_side_info_chars: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum characters of side information")
    ] = None,
    track_best_outputs: t.Annotated[
        bool,
        cyclopts.Parameter(negative=()),
    ] = False,
    display_progress_bar: t.Annotated[
        bool,
        cyclopts.Parameter(negative=()),
    ] = False,
    capture_traces: t.Annotated[
        bool,
        cyclopts.Parameter(negative="--no-capture-traces"),
    ] = True,
    include_outputs: t.Annotated[
        bool,
        cyclopts.Parameter(negative="--no-include-outputs"),
    ] = True,
    include_errors: t.Annotated[
        bool,
        cyclopts.Parameter(negative="--no-include-errors"),
    ] = True,
    wait: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Submit a hosted optimization job."""
    from dreadnode.app.api.models import (
        CapabilityRef,
        CreateGEPAOptimizationJobRequest,
        DatasetRef,
        OptimizationJobConfig,
        RewardRecipe,
    )

    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)

    capability_name, capability_version = _parse_versioned_ref(
        capability,
        field_name="--capability",
    )
    dataset_name, dataset_version = _parse_versioned_ref(
        dataset,
        field_name="--dataset",
    )

    val_dataset_ref: DatasetRef | None = None
    if val_dataset:
        val_dataset_name, val_dataset_version = _parse_versioned_ref(
            val_dataset,
            field_name="--val-dataset",
        )
        val_dataset_ref = DatasetRef(name=val_dataset_name, version=val_dataset_version)

    parsed_reward_params: dict[str, t.Any] = {}
    if reward_params:
        try:
            raw_params = json.loads(reward_params)
        except json.JSONDecodeError as exc:
            raise SystemExit("--reward-params must be valid JSON") from exc
        if not isinstance(raw_params, dict):
            raise SystemExit("--reward-params must decode to a JSON object")
        parsed_reward_params = raw_params

    config_kwargs: dict[str, t.Any] = {
        "capture_traces": capture_traces,
        "include_outputs": include_outputs,
        "include_errors": include_errors,
    }
    if seed is not None:
        config_kwargs["seed"] = seed
    if max_metric_calls is not None:
        config_kwargs["max_metric_calls"] = max_metric_calls
    if reflection_lm is not None:
        config_kwargs["reflection_lm"] = reflection_lm
    if max_reflection_examples is not None:
        config_kwargs["max_reflection_examples"] = max_reflection_examples
    if max_side_info_chars is not None:
        config_kwargs["max_side_info_chars"] = max_side_info_chars
    if track_best_outputs:
        config_kwargs["track_best_outputs"] = True
    if display_progress_bar:
        config_kwargs["display_progress_bar"] = True

    request = CreateGEPAOptimizationJobRequest(
        name=name,
        model=model,
        project_ref=project_ref,
        run_ref=run_ref,
        capability_ref=CapabilityRef(
            name=capability_name,
            version=capability_version,
        ),
        agent_name=agent_name,
        dataset_ref=DatasetRef(name=dataset_name, version=dataset_version),
        val_dataset_ref=val_dataset_ref,
        reward_recipe=RewardRecipe(
            name=reward_recipe,
            params=parsed_reward_params,
        ),
        components=["instructions"],
        objective=objective,
        config=OptimizationJobConfig(**config_kwargs),
        tags=list(tag or []),
    )
    job = client.create_optimization_job(org, workspace, request)
    if wait:
        job = _wait_for_optimization_job(
            client,
            org=org,
            workspace=workspace,
            job_id=job.id,
            poll_interval_sec=poll_interval_sec,
            timeout_sec=timeout_sec,
        )
    _render_optimization_job(job, as_json=as_json)
    if wait and job.status != "completed":
        raise SystemExit(job.error or f"Optimization job {job.id} ended with status {job.status}")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    page: t.Annotated[int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))] = 1,
    page_size: t.Annotated[
        int,
        cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1)),
    ] = 20,
    status: OptimizationStatus | None = None,
    backend: OptimizationBackend | None = None,
    target_kind: TargetKind | None = None,
    project_ref: t.Annotated[
        str | None, cyclopts.Parameter(help="Project reference filter")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """List hosted optimization jobs."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)
    jobs = client.list_optimization_jobs(
        org,
        workspace,
        page=page,
        page_size=page_size,
        status=status,
        backend=backend,
        target_kind=target_kind,
        project_ref=project_ref,
    )
    _render_optimization_job_list(jobs, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get a hosted optimization job."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)
    job = client.get_optimization_job(org, workspace, job_id)
    _render_optimization_job(job, as_json=as_json)


# ---------------------------------------------------------------------------
# wait
# ---------------------------------------------------------------------------


@cli.command()
def wait(
    job_id: str,
    *,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Wait for a hosted optimization job to reach a terminal state."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)
    job = _wait_for_optimization_job(
        client,
        org=org,
        workspace=workspace,
        job_id=job_id,
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )
    _render_optimization_job(job, as_json=as_json)
    if job.status != "completed":
        raise SystemExit(job.error or f"Optimization job {job.id} ended with status {job.status}")


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


@cli.command()
def logs(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Show hosted optimization logs."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)
    log_data = client.list_optimization_job_logs(org, workspace, job_id)
    _render_optimization_logs(log_data, as_json=as_json)


# ---------------------------------------------------------------------------
# artifacts
# ---------------------------------------------------------------------------


@cli.command()
def artifacts(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Show hosted optimization artifacts."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)
    artifact_data = client.get_optimization_job_artifacts(org, workspace, job_id)
    _render_optimization_artifacts(artifact_data, as_json=as_json)


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------


@cli.command()
def cancel(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Cancel a hosted optimization job."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)
    job = client.cancel_optimization_job(org, workspace, job_id)
    _render_optimization_job(job, as_json=as_json)


# ---------------------------------------------------------------------------
# retry
# ---------------------------------------------------------------------------


@cli.command()
def retry(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Retry a terminal hosted optimization job."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_optimization_context(dn)
    job = client.retry_optimization_job(org, workspace, job_id)
    _render_optimization_job(job, as_json=as_json)
