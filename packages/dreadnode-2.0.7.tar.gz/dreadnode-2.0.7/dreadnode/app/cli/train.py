"""Train subcommands for the cyclopts CLI."""

import json
import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    PlatformConfig,
    _build_optional_reward_recipe,
    _parse_versioned_ref,
    _render_training_artifacts,
    _render_training_job,
    _render_training_job_list,
    _render_training_logs,
    _wait_for_training_job,
    configured_dreadnode,
    require_training_context,
)

RLAlgorithm = t.Literal["importance_sampling", "ppo"]
ExecutionMode = t.Literal["sync", "one_step_off_async", "fully_async"]
TrainingStatus = t.Literal["queued", "running", "completed", "failed", "cancelled"]
TrainingBackend = t.Literal["tinker"]
TrainerType = t.Literal["sft", "rl"]

cli = cyclopts.App(name="train", help="Fine-tune models with hosted SFT and RL jobs.")


# ---------------------------------------------------------------------------
# sft
# ---------------------------------------------------------------------------


@cli.command()
def sft(
    *,
    model: t.Annotated[str, cyclopts.Parameter(help="Model identifier")],
    capability: t.Annotated[
        str,
        cyclopts.Parameter(help="Capability ref in NAME@VERSION form"),
    ],
    dataset: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Training dataset ref in NAME@VERSION form"),
    ] = None,
    trajectory_dataset: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(
            negative_iterable=(),
            help="Trajectory dataset ref in NAME@VERSION form (repeatable)",
        ),
    ] = None,
    eval_dataset: t.Annotated[
        str | None,
        cyclopts.Parameter(
            help="Evaluation dataset ref in NAME@VERSION form",
        ),
    ] = None,
    name: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Optional training job name"),
    ] = None,
    project_ref: t.Annotated[
        str | None, cyclopts.Parameter(help="Project reference for tracking")
    ] = None,
    run_ref: t.Annotated[str | None, cyclopts.Parameter(help="Run reference for tracking")] = None,
    tag: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(negative_iterable=(), help="Tag for the job (repeatable)"),
    ] = None,
    max_sequence_length: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum sequence length")
    ] = None,
    batch_size: t.Annotated[int | None, cyclopts.Parameter(help="Training batch size")] = None,
    gradient_accumulation_steps: t.Annotated[
        int | None, cyclopts.Parameter(help="Gradient accumulation steps")
    ] = None,
    learning_rate: t.Annotated[float | None, cyclopts.Parameter(help="Learning rate")] = None,
    steps: t.Annotated[int | None, cyclopts.Parameter(help="Number of training steps")] = None,
    epochs: t.Annotated[int | None, cyclopts.Parameter(help="Number of training epochs")] = None,
    lora_rank: t.Annotated[int | None, cyclopts.Parameter(help="LoRA rank")] = None,
    lora_alpha: t.Annotated[int | None, cyclopts.Parameter(help="LoRA alpha")] = None,
    checkpoint_interval: t.Annotated[
        int | None, cyclopts.Parameter(help="Steps between checkpoints")
    ] = None,
    wait: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Submit a hosted SFT training job."""
    from dreadnode.app.api.models import (
        CapabilityRef,
        CreateTinkerSFTJobRequest,
        DatasetRef,
        TinkerSFTJobConfig,
    )

    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)

    capability_name, capability_version = _parse_versioned_ref(
        capability,
        field_name="--capability",
    )

    dataset_ref: DatasetRef | None = None
    if dataset:
        dataset_name, dataset_version = _parse_versioned_ref(
            dataset,
            field_name="--dataset",
        )
        dataset_ref = DatasetRef(name=dataset_name, version=dataset_version)

    trajectory_dataset_refs: list[DatasetRef] = []
    for raw_ref in list(trajectory_dataset or []):
        trajectory_name, trajectory_version = _parse_versioned_ref(
            raw_ref,
            field_name="--trajectory-dataset",
        )
        trajectory_dataset_refs.append(DatasetRef(name=trajectory_name, version=trajectory_version))

    eval_dataset_ref: DatasetRef | None = None
    if eval_dataset:
        eval_name, eval_version = _parse_versioned_ref(
            eval_dataset,
            field_name="--eval-dataset",
        )
        eval_dataset_ref = DatasetRef(name=eval_name, version=eval_version)

    request = CreateTinkerSFTJobRequest(
        name=name,
        model=model,
        project_ref=project_ref,
        run_ref=run_ref,
        capability_ref=CapabilityRef(
            name=capability_name,
            version=capability_version,
        ),
        tags=list(tag or []),
        config=TinkerSFTJobConfig(
            dataset_ref=dataset_ref,
            trajectory_dataset_refs=trajectory_dataset_refs,
            eval_dataset_ref=eval_dataset_ref,
            max_sequence_length=max_sequence_length,
            batch_size=batch_size,
            gradient_accumulation_steps=gradient_accumulation_steps,
            learning_rate=learning_rate,
            steps=steps,
            epochs=epochs,
            lora_rank=lora_rank,
            lora_alpha=lora_alpha,
            checkpoint_interval=checkpoint_interval,
        ),
    )
    job = client.create_training_job(org, workspace, request)
    if wait:
        job = _wait_for_training_job(
            client,
            org=org,
            workspace=workspace,
            job_id=job.id,
            poll_interval_sec=poll_interval_sec,
            timeout_sec=timeout_sec,
        )
    _render_training_job(job, as_json=as_json)
    if wait and job.status != "completed":
        raise SystemExit(job.error or f"Training job {job.id} ended with status {job.status}")


# ---------------------------------------------------------------------------
# rl
# ---------------------------------------------------------------------------


@cli.command()
def rl(
    *,
    model: t.Annotated[str, cyclopts.Parameter(help="Model identifier")],
    capability: t.Annotated[
        str,
        cyclopts.Parameter(help="Capability ref in NAME@VERSION form"),
    ],
    algorithm: RLAlgorithm,
    prompt_dataset: t.Annotated[
        str | None,
        cyclopts.Parameter(
            help="Prompt dataset ref in NAME@VERSION form",
        ),
    ] = None,
    trajectory_dataset: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(
            negative_iterable=(),
            help="Trajectory dataset ref in NAME@VERSION form (repeatable)",
        ),
    ] = None,
    world_manifest_id: t.Annotated[
        str | None, cyclopts.Parameter(help="World manifest ID for environment")
    ] = None,
    world_runtime_id: t.Annotated[str | None, cyclopts.Parameter(help="World runtime ID")] = None,
    world_agent_name: t.Annotated[
        str | None, cyclopts.Parameter(help="Agent name in the world")
    ] = None,
    world_goal: t.Annotated[
        str | None, cyclopts.Parameter(help="Goal for world-based training")
    ] = None,
    task: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Task ref"),
    ] = None,
    reward_recipe: t.Annotated[str | None, cyclopts.Parameter(help="Reward recipe name")] = None,
    reward_params: t.Annotated[
        str | None, cyclopts.Parameter(help="Reward recipe parameters as JSON")
    ] = None,
    world_reward: t.Annotated[
        str | None, cyclopts.Parameter(help="World reward policy name")
    ] = None,
    world_reward_params: t.Annotated[
        str | None, cyclopts.Parameter(help="World reward policy parameters as JSON")
    ] = None,
    execution_mode: ExecutionMode = "sync",
    prompt_split: t.Annotated[
        str | None, cyclopts.Parameter(help="Dataset split for prompts")
    ] = None,
    name: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Optional training job name"),
    ] = None,
    project_ref: t.Annotated[
        str | None, cyclopts.Parameter(help="Project reference for tracking")
    ] = None,
    run_ref: t.Annotated[str | None, cyclopts.Parameter(help="Run reference for tracking")] = None,
    tag: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(negative_iterable=(), help="Tag for the job (repeatable)"),
    ] = None,
    steps: t.Annotated[int | None, cyclopts.Parameter(help="Number of training steps")] = None,
    lora_rank: t.Annotated[int | None, cyclopts.Parameter(help="LoRA rank")] = None,
    max_turns: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum conversation turns")
    ] = None,
    max_episode_steps: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum steps per episode")
    ] = None,
    num_rollouts: t.Annotated[
        int | None, cyclopts.Parameter(help="Number of rollouts per step")
    ] = None,
    batch_size: t.Annotated[int | None, cyclopts.Parameter(help="Training batch size")] = None,
    learning_rate: t.Annotated[float | None, cyclopts.Parameter(help="Learning rate")] = None,
    weight_sync_interval: t.Annotated[
        int | None, cyclopts.Parameter(help="Steps between weight syncs")
    ] = None,
    max_steps_off_policy: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum off-policy steps")
    ] = None,
    max_new_tokens: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum new tokens per generation")
    ] = None,
    temperature: t.Annotated[float | None, cyclopts.Parameter(help="Sampling temperature")] = None,
    stop: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(negative_iterable=(), help="Stop sequence (repeatable)"),
    ] = None,
    checkpoint_interval: t.Annotated[
        int | None, cyclopts.Parameter(help="Steps between checkpoints")
    ] = None,
    wait: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Submit a hosted RL training job."""
    from dreadnode.app.api.models import (
        CapabilityRef,
        CreateTinkerRLJobRequest,
        DatasetRef,
        TinkerRLJobConfig,
        WorldRewardPolicy,
    )

    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)

    capability_name, capability_version = _parse_versioned_ref(
        capability,
        field_name="--capability",
    )

    prompt_dataset_ref: DatasetRef | None = None
    if prompt_dataset:
        prompt_name, prompt_version = _parse_versioned_ref(
            prompt_dataset,
            field_name="--prompt-dataset",
        )
        prompt_dataset_ref = DatasetRef(name=prompt_name, version=prompt_version)

    trajectory_dataset_refs: list[DatasetRef] = []
    for raw_ref in list(trajectory_dataset or []):
        trajectory_name, trajectory_version = _parse_versioned_ref(
            raw_ref,
            field_name="--trajectory-dataset",
        )
        trajectory_dataset_refs.append(DatasetRef(name=trajectory_name, version=trajectory_version))

    if prompt_dataset_ref is None and not trajectory_dataset_refs and world_manifest_id is None:
        raise SystemExit(
            "dn train rl requires --prompt-dataset, --world-manifest-id, or at least one --trajectory-dataset"
        )

    parsed_world_reward: WorldRewardPolicy | None = None
    if world_reward:
        parsed_world_reward_params: dict[str, t.Any] = {}
        if world_reward_params:
            try:
                raw_params = json.loads(world_reward_params)
            except json.JSONDecodeError as exc:
                raise SystemExit("--world-reward-params must be valid JSON") from exc
            if not isinstance(raw_params, dict):
                raise SystemExit("--world-reward-params must decode to a JSON object")
            parsed_world_reward_params = raw_params
        parsed_world_reward = WorldRewardPolicy(
            name=world_reward,
            params=parsed_world_reward_params,
        )

    request = CreateTinkerRLJobRequest(
        name=name,
        model=model,
        project_ref=project_ref,
        run_ref=run_ref,
        capability_ref=CapabilityRef(
            name=capability_name,
            version=capability_version,
        ),
        tags=list(tag or []),
        config=TinkerRLJobConfig(
            algorithm=algorithm,
            task_ref=task,
            world_manifest_id=world_manifest_id,
            world_runtime_id=world_runtime_id,
            world_agent_name=world_agent_name,
            world_goal=world_goal,
            prompt_dataset_ref=prompt_dataset_ref,
            trajectory_dataset_refs=trajectory_dataset_refs,
            reward_recipe=_build_optional_reward_recipe(reward_recipe, reward_params),
            world_reward=parsed_world_reward,
            execution_mode=execution_mode,
            prompt_split=prompt_split,
            steps=steps,
            lora_rank=lora_rank,
            max_turns=max_turns,
            max_episode_steps=max_episode_steps,
            num_rollouts=num_rollouts,
            batch_size=batch_size,
            learning_rate=learning_rate,
            weight_sync_interval=weight_sync_interval,
            max_steps_off_policy=max_steps_off_policy,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            stop=list(stop or []) or None,
            checkpoint_interval=checkpoint_interval,
        ),
    )
    job = client.create_training_job(org, workspace, request)
    if wait:
        job = _wait_for_training_job(
            client,
            org=org,
            workspace=workspace,
            job_id=job.id,
            poll_interval_sec=poll_interval_sec,
            timeout_sec=timeout_sec,
        )
    _render_training_job(job, as_json=as_json)
    if wait and job.status != "completed":
        raise SystemExit(job.error or f"Training job {job.id} ended with status {job.status}")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    page: t.Annotated[int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))] = 1,
    page_size: t.Annotated[
        int,
        cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1)),
    ] = 20,
    status: TrainingStatus | None = None,
    backend: TrainingBackend | None = None,
    trainer_type: TrainerType | None = None,
    project_ref: t.Annotated[
        str | None, cyclopts.Parameter(help="Project reference filter")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """List hosted training jobs."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)
    jobs = client.list_training_jobs(
        org,
        workspace,
        page=page,
        page_size=page_size,
        status=status,
        backend=backend,
        trainer_type=trainer_type,
        project_ref=project_ref,
    )
    _render_training_job_list(jobs, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get a hosted training job."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)
    job = client.get_training_job(org, workspace, job_id)
    _render_training_job(job, as_json=as_json)


# ---------------------------------------------------------------------------
# wait
# ---------------------------------------------------------------------------


@cli.command()
def wait(
    job_id: str,
    *,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Wait for a hosted training job to reach a terminal state."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)
    job = _wait_for_training_job(
        client,
        org=org,
        workspace=workspace,
        job_id=job_id,
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )
    _render_training_job(job, as_json=as_json)
    if job.status != "completed":
        raise SystemExit(job.error or f"Training job {job.id} ended with status {job.status}")


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


@cli.command()
def logs(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Show hosted training logs."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)
    log_data = client.list_training_job_logs(org, workspace, job_id)
    _render_training_logs(log_data, as_json=as_json)


# ---------------------------------------------------------------------------
# artifacts
# ---------------------------------------------------------------------------


@cli.command()
def artifacts(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Show hosted training artifacts."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)
    artifact_data = client.get_training_job_artifacts(org, workspace, job_id)
    _render_training_artifacts(artifact_data, as_json=as_json)


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------


@cli.command()
def cancel(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Cancel a hosted training job."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_training_context(dn)
    job = client.cancel_training_job(org, workspace, job_id)
    _render_training_job(job, as_json=as_json)
