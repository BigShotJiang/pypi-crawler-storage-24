"""Evaluation subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    PlatformConfig,
    _print_json,
    _render_evaluation,
    _render_evaluation_list,
    configured_dreadnode,
    require_evaluation_context,
)

cli = cyclopts.App(name="evaluation", help="Manage agent evaluation jobs.")

CleanupPolicy = t.Literal["always", "on_success"]


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@cli.command()
def create(
    name: t.Annotated[str, cyclopts.Parameter(name="name", help="Evaluation name")],
    *,
    task: t.Annotated[
        list[str],
        cyclopts.Parameter(
            name="--task", negative_iterable=(), help="Task name (repeatable, required)"
        ),
    ],
    runtime_id: t.Annotated[str | None, cyclopts.Parameter(help="Runtime environment ID")] = None,
    model: t.Annotated[str | None, cyclopts.Parameter(help="Model identifier")] = None,
    capability: t.Annotated[
        str | None, cyclopts.Parameter(help="Capability to load for the evaluation")
    ] = None,
    concurrency: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum concurrent evaluation jobs")
    ] = None,
    task_timeout_sec: t.Annotated[
        int | None, cyclopts.Parameter(help="Timeout per task in seconds")
    ] = None,
    cleanup_policy: CleanupPolicy | None = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Create a new evaluation."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_evaluation_context(dn)
    request: dict[str, t.Any] = {"name": name}
    if task:
        request["task_names"] = task
    if runtime_id:
        request["runtime_id"] = runtime_id
    if model:
        request["model"] = model
    if capability:
        request["capability"] = capability
    if concurrency is not None:
        request["concurrency"] = concurrency
    if task_timeout_sec is not None:
        request["task_timeout_sec"] = task_timeout_sec
    if cleanup_policy:
        request["cleanup_policy"] = cleanup_policy
    payload = client.create_evaluation(org, workspace, request)
    _render_evaluation(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


EvaluationStatus = t.Literal["pending", "running", "completed", "failed", "cancelled"]


@cli.command(name="list")
def list_(
    *,
    page: t.Annotated[int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))] = 1,
    page_size: t.Annotated[
        int,
        cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1)),
    ] = 50,
    status: EvaluationStatus | None = None,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID filter")] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """List evaluations."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_evaluation_context(dn)
    payload = client.list_evaluation_jobs(
        org,
        workspace,
        page=page,
        page_size=page_size,
        status=status,
        project_id=project_id,
    )
    _render_evaluation_list(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    evaluation_id: t.Annotated[str, cyclopts.Parameter(name="evaluation-id")],
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get details of an evaluation."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_evaluation_context(dn)
    payload = client.get_evaluation_job(org, workspace, evaluation_id)
    _render_evaluation(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# jobs
# ---------------------------------------------------------------------------


@cli.command()
def jobs(
    evaluation_id: t.Annotated[str, cyclopts.Parameter(name="evaluation-id")],
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """List items/jobs for an evaluation."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_evaluation_context(dn)
    payload = client.list_evaluation_items(org, workspace, evaluation_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# transcript
# ---------------------------------------------------------------------------


@cli.command()
def transcript(
    evaluation_id: t.Annotated[str, cyclopts.Parameter(name="evaluation-id")],
    item_id: t.Annotated[str, cyclopts.Parameter(name="item-id")],
    *,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Get the transcript for an evaluation item."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_evaluation_context(dn)
    payload = client.get_evaluation_item_transcript(
        org,
        workspace,
        evaluation_id,
        item_id,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------


@cli.command()
def cancel(
    evaluation_id: t.Annotated[str, cyclopts.Parameter(name="evaluation-id")],
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Cancel an evaluation."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_evaluation_context(dn)
    payload = client.cancel_evaluation(org, workspace, evaluation_id)
    _render_evaluation(payload, as_json=as_json)


# ---------------------------------------------------------------------------
# retry
# ---------------------------------------------------------------------------


@cli.command()
def retry(
    evaluation_id: t.Annotated[str, cyclopts.Parameter(name="evaluation-id")],
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformConfig = PlatformConfig(),
) -> None:
    """Retry failed jobs in an evaluation."""
    dn = configured_dreadnode(platform)
    org, workspace, client = require_evaluation_context(dn)
    payload = client.retry_failed_evaluation(org, workspace, evaluation_id)
    _render_evaluation(payload, as_json=as_json)
