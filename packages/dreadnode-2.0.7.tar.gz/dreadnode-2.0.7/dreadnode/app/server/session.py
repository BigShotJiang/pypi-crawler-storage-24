from __future__ import annotations

import contextlib
import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import urlparse

import yaml
from pydantic import BaseModel

from dreadnode.core.util import valid_key

if TYPE_CHECKING:
    from uuid import UUID

    from dreadnode.app.api.client import ApiClient
    from dreadnode.app.api.models import Organization, Project, User, Workspace

# Default path for user configuration
DEFAULT_CONFIG_PATH = Path.home() / ".dreadnode" / "config.yaml"

# Hostnames that are equivalent for URL comparison
_LOCALHOST_ALIASES = frozenset({"localhost", "127.0.0.1", "::1"})


def _normalize_url(url: str) -> str:
    """Normalize a URL for comparison: strip trailing slash, canonicalize localhost variants."""
    parsed = urlparse(url.rstrip("/"))
    host = parsed.hostname or ""
    if host in _LOCALHOST_ALIASES:
        host = "localhost"
    port = parsed.port
    # Rebuild with normalized host
    netloc = host if port is None else f"{host}:{port}"
    return f"{parsed.scheme}://{netloc}{parsed.path}"


def urls_match(a: str, b: str) -> bool:
    """Compare two URLs, treating localhost/127.0.0.1/::1 as equivalent."""
    return _normalize_url(a) == _normalize_url(b)


class ServerConfig(BaseModel):
    """Server specific authentication data and API URL."""

    url: str
    user_key: str | None = None
    email: str | None = None
    username: str | None = None
    api_key: str
    default_model: str | None = None
    default_organization: str | None = None
    default_workspace: str | None = None
    default_project: str | None = None

    @classmethod
    def load(cls, path: Path) -> ServerConfig:
        """Load server config from a YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Profile not found: {path}")

        with path.open("r") as f:
            return cls.model_validate(yaml.safe_load(f))

    def save(self, path: Path) -> None:
        """Save server config to a YAML file."""
        if not path.parent.exists():
            path.parent.mkdir(parents=True, mode=0o700)

        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            yaml.dump(self.model_dump(mode="json", exclude_none=True), f)


class UserConfig(BaseModel):
    """User configuration supporting multiple server profiles."""

    active: str | None = None
    servers: dict[str, ServerConfig] = {}

    def _update_active(self) -> None:
        """If active is not set, set it to the first available server."""
        if self.active not in self.servers:
            self.active = next(iter(self.servers)) if self.servers else None

    @property
    def active_profile_name(self) -> str | None:
        """Get the name of the active profile."""
        self._update_active()
        return self.active

    @classmethod
    def read(cls, path: Path | None = None) -> UserConfig:
        """Read the user configuration from the file system or return an empty instance."""
        path = path or DEFAULT_CONFIG_PATH
        if not path.exists():
            return cls()

        with path.open("r") as f:
            return cls.model_validate(yaml.safe_load(f))

    def write(self, path: Path | None = None) -> None:
        """Write the user configuration to the file system."""
        path = path or DEFAULT_CONFIG_PATH
        self._update_active()

        if not path.parent.exists():
            path.parent.mkdir(parents=True, mode=0o700)

        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            yaml.dump(self.model_dump(mode="json"), f)

    def get_server_config(self, profile: str | None = None) -> ServerConfig:
        """Get the server configuration for the given profile."""
        profile = profile or self.active
        if not profile:
            raise RuntimeError("No profile is set, use [bold]dreadnode login[/] to authenticate")

        if profile not in self.servers:
            raise RuntimeError(f"No server configuration for profile: {profile}")

        return self.servers[profile]

    def set_server_config(self, config: ServerConfig, profile: str | None = None) -> UserConfig:
        """Set the server configuration for the given profile."""
        resolved_profile = profile or self.active
        if resolved_profile is None:
            raise RuntimeError("No profile specified and no active profile set")
        self.servers[resolved_profile] = config
        return self

    def get_profile_server(self, profile: str | None = None) -> str | None:
        """Get the server URL from the user config for a given profile."""
        with contextlib.suppress(Exception):
            server_config = self.get_server_config(profile)
            return server_config.url
        return None

    def get_profile_api_key(self, profile: str | None = None) -> str | None:
        """Get the API key from the user config for a given profile."""
        with contextlib.suppress(Exception):
            server_config = self.get_server_config(profile)
            return server_config.api_key
        return None


@dataclass(frozen=True)
class Session:
    """
    Session manages RBAC resolution for organization, workspace, and project.

    It encapsulates the logic for resolving and validating the user's access
    to organizations, workspaces, and projects.
    """

    api: ApiClient
    organization: Organization
    workspace: Workspace
    project: Project | None
    user: User

    @property
    def org_key(self) -> str:
        """Get the organization key."""
        return self.organization.key

    @property
    def workspace_key(self) -> str:
        """Get the workspace key."""
        return self.workspace.key

    @property
    def project_key(self) -> str | None:
        """Get the project key, or None if no project is set."""
        return self.project.key if self.project else None


def _resolve_organization(api: ApiClient, org_key: str) -> Organization:
    """Resolve the organization to use based on configuration."""
    if isinstance(org_key, str) and not valid_key(org_key):
        raise RuntimeError(
            f'Invalid Organization Key: "{org_key}". '
            "The expected characters are lowercase letters, numbers, and hyphens (-)."
        )

    organization = api.get_organization(org_key)
    if not organization:
        raise RuntimeError(f"Organization '{org_key}' not found.")

    return organization


def _resolve_workspace(api: ApiClient, org_key: str, workspace_key: str) -> Workspace:
    """Resolve the workspace to use based on configuration."""
    if isinstance(workspace_key, str) and not valid_key(workspace_key):
        raise RuntimeError(
            f'Invalid Workspace Key: "{workspace_key}". '
            "The expected characters are lowercase letters, numbers, and hyphens (-)."
        )

    workspace = api.get_workspace(org_key, workspace_key)
    if not workspace:
        raise RuntimeError("No default workspace found. Please specify a workspace.")

    return workspace


def _resolve_project(
    api: ApiClient, org_key: str, workspace_key: str, project_key: str | None
) -> Project | None:
    """Resolve the project to use based on configuration."""
    if not project_key:
        return None

    if not valid_key(project_key):
        raise RuntimeError(
            f'Invalid Project Key: "{project_key}". '
            "The expected characters are lowercase letters, numbers, and hyphens (-)."
        )

    try:
        return api.get_project(org_key, workspace_key, project_key)
    except RuntimeError as e:
        if "404" not in str(e):
            raise
        return None


def _resolve_default_workspace(api: ApiClient, org_key: str) -> Workspace:
    """Auto-resolve the default workspace for an organization.

    Picks the workspace marked ``is_default``, or the first available workspace.
    Raises if the organization has no workspaces.
    """
    workspaces = api.list_workspaces(org_key)
    if not workspaces:
        raise RuntimeError(
            f"No workspaces found in organization '{org_key}'. "
            "Create a workspace first or specify one explicitly."
        )
    for ws in workspaces:
        if getattr(ws, "is_default", False):
            return ws
    return workspaces[0]


def resolve_session(
    api: ApiClient,
    organization: str | UUID | None = None,
    workspace: str | UUID | None = None,
    project: str | UUID | None = None,
) -> Session:
    """Resolve RBAC hierarchy and return immutable Session.

    Organization and workspace are auto-resolved when not specified:
    - Organization: picked automatically if the user belongs to exactly one.
    - Workspace: the default workspace for the organization, or the first available.
    """
    if not organization:
        raise RuntimeError("Organization is required")

    org_key = str(organization)
    org = _resolve_organization(api, org_key)
    user = api.get_user()

    if workspace:
        workspace_key = str(workspace)
        ws = _resolve_workspace(api, org_key, workspace_key)
    else:
        ws = _resolve_default_workspace(api, org_key)

    project_key = str(project) if project else None
    proj = _resolve_project(api, org_key, ws.key, project_key)

    return Session(
        api=api,
        organization=org,
        workspace=ws,
        project=proj,
        user=user,
    )
