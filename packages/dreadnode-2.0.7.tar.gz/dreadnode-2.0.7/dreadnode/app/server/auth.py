"""Bearer token authentication middleware for sandbox runtime servers."""

from __future__ import annotations

import os
import secrets
import typing as t

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse, Response

if t.TYPE_CHECKING:
    from starlette.requests import Request

# Paths that never require authentication
_PUBLIC_PATHS = frozenset({"/api/health"})


class SandboxAuthMiddleware(BaseHTTPMiddleware):
    """Validate Bearer token against SANDBOX_AUTH_TOKEN env var.

    When SANDBOX_AUTH_TOKEN is set, all /api/* requests (except /api/health)
    must include a matching Authorization: Bearer <token> header.
    When unset, all requests pass through (local/in-process mode).
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        token = os.environ.get("SANDBOX_AUTH_TOKEN")
        if token is None:
            return await call_next(request)

        if request.method == "OPTIONS":
            return await call_next(request)

        path = request.url.path
        if path in _PUBLIC_PATHS or not path.startswith("/api/"):
            return await call_next(request)

        auth_header = request.headers.get("authorization", "")
        if not auth_header.startswith("Bearer "):
            return JSONResponse(
                {"detail": "Authorization header with Bearer token required"},
                status_code=401,
            )

        provided_token = auth_header[7:]
        if not secrets.compare_digest(provided_token, token):
            return JSONResponse(
                {"detail": "Invalid authorization token"},
                status_code=401,
            )

        return await call_next(request)
