"""Assessment orchestrator for AI Red Teaming.

Coordinates multi-attack assessments with automatic result tracking.

Usage::

    from dreadnode.airt import Assessment, tap_attack

    assessment = Assessment(
        name="My Assessment",
        target=target,
        model="groq/llama-3.3-70b-versatile",
        goal="Extract sensitive information",
    )

    await assessment.run(tap_attack)                                    # baseline
    await assessment.run(tap_attack, transforms=[adapt_language("es")]) # with transform
    await assessment.done()
"""

from __future__ import annotations

import contextlib
import contextvars
import os
import typing as t
import uuid
from pathlib import Path

from loguru import logger

from dreadnode.airt.analytics.engine import AttackResult

if t.TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable

    from dreadnode.airt.analytics.types import GoalCategory
    from dreadnode.app.api.client import ApiClient
    from dreadnode.app.server.session import Session
    from dreadnode.core.task import Task
    from dreadnode.optimization.study import Study

_current_assessment: contextvars.ContextVar[Assessment | None] = contextvars.ContextVar(
    "_current_assessment", default=None
)


def _get_platform_context() -> tuple[ApiClient, Session] | None:
    """Get the API client and session if connected to the platform."""
    try:
        from dreadnode.app.main import DEFAULT_INSTANCE

        if DEFAULT_INSTANCE.can_sync:
            return DEFAULT_INSTANCE.api, DEFAULT_INSTANCE.session
    except Exception:
        logger.debug("Unable to resolve platform context for AIRT assessment")
    return None


class Assessment:
    """Orchestrates multi-attack assessments.

    Accepts attack factories or pre-built Study instances via ``run()``,
    tracks results, and auto-completes when done.

    Example::

        assessment = Assessment(name="...", target=target, model=MODEL, goal="...")
        await assessment.run(tap_attack)
        await assessment.run(tap_attack, transforms=[adapt_language("es")])
        await assessment.done()
    """

    def __init__(
        self,
        name: str,
        *,
        target: Task[..., str] | None = None,
        model: str | None = None,
        goal: str | None = None,
        goal_category: str | None = None,
        attack_defaults: dict[str, t.Any] | None = None,
        description: str | None = None,
        session_id: str | None = None,
        target_config: dict[str, t.Any] | None = None,
        attacker_config: dict[str, t.Any] | None = None,
        attack_manifest: list[dict[str, t.Any]] | None = None,
        workflow_run_id: str | None = None,
        workflow_script: str | None = None,
        project_id: str | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.target = target
        self.model = model
        self.goal = goal
        self.goal_category = goal_category
        self._attack_defaults = attack_defaults or {}

        if target_config is None and model is not None:
            target_config = {"model": model}
        if attacker_config is None and model is not None:
            attacker_config = {"model": model, "evaluator_model": model}

        self.target_config = target_config
        self.attacker_config = attacker_config
        self._attack_manifest = attack_manifest
        self._workflow_run_id = workflow_run_id
        self._workflow_script = workflow_script
        self._project_id = project_id

        self._session_id = session_id or os.environ.get("DREADNODE_SESSION_ID")
        if self._session_id is None:
            session_file = Path("~/.dreadnode_session_id").expanduser()
            if session_file.is_file():
                with contextlib.suppress(OSError):
                    self._session_id = session_file.read_text(encoding="utf-8").strip() or None

        self._assessment_id: str | None = None
        self._attack_results: list[AttackResult] = []
        self._attack_run_ids: dict[int, str] = {}  # index in _attack_results -> platform run_id
        self._tracing_enabled: bool = False
        self._auto_registered: bool = False
        self._context_token: contextvars.Token[Assessment | None] | None = None

    @property
    def assessment_id(self) -> str | None:
        """Platform assessment ID, or None if not registered."""
        return self._assessment_id

    @property
    def attack_results(self) -> list[AttackResult]:
        """All collected attack results."""
        return list(self._attack_results)

    # =========================================================================
    # Platform Registration
    # =========================================================================

    async def register(self) -> str | None:
        """Register this assessment with the platform.

        Returns:
            The platform assessment ID, or None if offline.
        """
        ctx = _get_platform_context()
        if ctx is None:
            logger.debug("SDK offline -- assessment not registered with platform")
            return None

        api, session = ctx
        project_id = self._project_id
        if project_id is None and session.project is not None:
            project_id = session.project.id

        if project_id is None:
            logger.warning("No project_id available -- cannot register assessment")
            return None

        try:
            result = api.create_airt_assessment(
                session.org_key,
                session.workspace_key,
                name=self.name,
                project_id=project_id,
                description=self.description,
                session_id=self._session_id,
                target_config=self.target_config,
                attacker_config=self.attacker_config,
                attack_manifest=self._attack_manifest,
                workflow_run_id=self._workflow_run_id,
                workflow_script=self._workflow_script,
            )
        except Exception as e:
            logger.error(f"Failed to register assessment: {e}")
            return None

        self._assessment_id = result["id"]
        logger.info(f"Assessment registered: {self._assessment_id}")
        return self._assessment_id

    # =========================================================================
    # Tracing
    # =========================================================================

    @contextlib.asynccontextmanager
    async def trace(self) -> AsyncIterator[Assessment]:
        """Context manager that enables tracing and auto-completes on exit.

        Usage::

            async with assessment.trace():
                await assessment.run(study1)
                await assessment.run(study2)
            # auto-completes on exit
        """
        token = _current_assessment.set(self)
        try:
            self._tracing_enabled = True
            yield self
        except Exception:
            self._tracing_enabled = False
            await self.fail(reason="Exception during trace")
            raise
        else:
            await self._finalize()
        finally:
            self._tracing_enabled = False
            _current_assessment.reset(token)

    async def _finalize(self) -> None:
        """Upload pending results, mark complete, flush traces."""
        if not self._attack_results:
            return

        for i, result in enumerate(self._attack_results):
            if i not in self._attack_run_ids:
                await self.upload_result(result)

        await self.complete()

        with contextlib.suppress(Exception):
            import dreadnode as dn

            dn.shutdown()

    async def run(
        self,
        attack: Study[t.Any] | Callable[..., Study[t.Any]],
        /,
        **kwargs: t.Any,
    ) -> t.Any:
        """Run an attack and upload its result.

        Accepts either a pre-built Study or an attack factory function.
        When given a factory, assessment defaults (goal, target, model)
        are filled in automatically.

        Args:
            attack: A Study instance, or an attack factory function
                (``tap_attack``, ``pair_attack``, ``goat_attack``, etc.).
            **kwargs: When ``attack`` is a factory, these override
                assessment defaults (transforms, n_iterations, etc.).

        Returns:
            The StudyResult from the attack execution.

        Examples::

            # Pass a factory — assessment fills in goal/target/model
            await assessment.run(tap_attack)
            await assessment.run(tap_attack, transforms=[adapt_language("es")])
            await assessment.run(pair_attack, n_streams=20)

            # Pass a pre-built Study (TUI/capability path)
            study = tap_attack(goal, target, model, model, ...)
            await assessment.run(study)
        """
        await self._ensure_started()

        from dreadnode.optimization.study import Study as StudyClass

        if isinstance(attack, StudyClass):
            study = attack
        elif callable(attack):
            study = self._build_study(attack, **kwargs)
        else:
            raise TypeError(
                f"Expected a Study instance or attack factory callable, got {type(attack).__name__}"
            )

        if self._assessment_id and not study.airt_assessment_id:
            study.airt_assessment_id = self._assessment_id

        from dreadnode.airt.analytics.types import GoalCategory

        result = await study.run()

        try:
            goal_category: GoalCategory = GoalCategory(study.airt_goal_category)
        except (ValueError, KeyError):
            goal_category = GoalCategory.JAILBREAK_GENERAL

        ar = AttackResult.from_study(
            result,
            attack_name=study.airt_attack_name or study.name,
            goal=study.airt_goal or "",
            goal_category=goal_category,
            compliance_tags=study.compliance_tags,
            transforms_applied=study.airt_transforms or [],
            execution_time_s=getattr(result, "execution_time_s", 0.0),
        )
        self._attack_results.append(ar)
        await self.upload_result(ar)

        return result

    def _build_study(
        self,
        factory: Callable[..., Study[t.Any]],
        **kwargs: t.Any,
    ) -> Study[t.Any]:
        """Create a Study from an attack factory using assessment defaults.

        The factory's first 4 positional args (goal, target, attacker_model,
        evaluator_model) are filled from assessment defaults. Remaining
        kwargs are merged: assessment.attack_defaults < per-call kwargs.
        """
        goal = kwargs.pop("goal", None) or self.goal
        target = kwargs.pop("target", None) or self.target
        model = kwargs.pop("model", None) or self.model

        if goal is None:
            raise ValueError("goal must be set on the assessment or passed to run()")
        if target is None:
            raise ValueError("target must be set on the assessment or passed to run()")
        if model is None:
            raise ValueError("model must be set on the assessment or passed to run()")

        merged = {**self._attack_defaults, **kwargs}
        merged.setdefault("airt_goal_category", self.goal_category)
        merged.setdefault("airt_target_model", model)

        return factory(goal, target, model, model, **merged)

    async def _ensure_started(self) -> None:
        """Auto-register and enable tracing on first run() call."""
        if not self._auto_registered:
            self._auto_registered = True
            await self.register()
            if not self._tracing_enabled:
                self._context_token = _current_assessment.set(self)
                self._tracing_enabled = True
                import atexit

                atexit.register(self._atexit_finalize)

    def _atexit_finalize(self) -> None:
        """Synchronous atexit handler that finalizes the assessment."""
        if not self._attack_results or not self._tracing_enabled:
            return
        import asyncio

        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                self._pending_task = loop.create_task(self.done())
            else:
                loop.run_until_complete(self.done())
        except RuntimeError:
            with contextlib.suppress(Exception):
                asyncio.run(self.done())

    async def done(self) -> None:
        """Finalize the assessment: upload pending results, complete, flush.

        Optional — called automatically via atexit or trace() exit.
        Call explicitly to ensure finalization happens before your script ends.
        """
        try:
            await self._finalize()
        finally:
            self._tracing_enabled = False
            if self._context_token is not None:
                with contextlib.suppress(ValueError):
                    _current_assessment.reset(self._context_token)
                self._context_token = None

    # =========================================================================
    # Result Upload
    # =========================================================================

    async def upload_result(self, result: AttackResult) -> str | None:
        """Register and upload an attack result to the platform.

        Args:
            result: The AttackResult to upload.

        Returns:
            The platform run ID, or None if offline.
        """
        ctx = _get_platform_context()
        if ctx is None or self._assessment_id is None:
            return None

        api, session = ctx
        org = session.org_key
        ws = session.workspace_key

        try:
            trace_id = uuid.uuid4().hex
            run_data = api.register_airt_attack_run(
                org,
                ws,
                self._assessment_id,
                attack_name=result.attack_name,
                goal=result.goal,
                goal_category=result.goal_category.value,
                transforms_applied=result.transforms_applied,
                compliance_tags=result.compliance_tags,
                trace_id=trace_id,
            )
            run_id = run_data["id"]

            api.upload_airt_attack_result(
                org,
                ws,
                self._assessment_id,
                run_id,
                attack_result_json=result.to_dict(),
                best_score=result.best_score,
                total_trials=result.total_trials,
                finished_trials=len(result.finished_trials),
                execution_time_s=result.execution_time_s,
            )
        except Exception as e:
            logger.error(f"Failed to upload attack result: {e}")
            return None

        idx = len(self._attack_results) - 1
        if result in self._attack_results:
            idx = self._attack_results.index(result)
        self._attack_run_ids[idx] = run_id

        logger.info(f"Attack result uploaded: {result.attack_name} -> {run_id}")
        return run_id

    # =========================================================================
    # Lifecycle
    # =========================================================================

    async def complete(self) -> bool:
        """Mark the assessment as completed.

        Returns:
            True if successfully marked, False otherwise.
        """
        ctx = _get_platform_context()
        if ctx is None or self._assessment_id is None:
            return False

        api, session = ctx
        try:
            api.update_airt_assessment(
                session.org_key,
                session.workspace_key,
                self._assessment_id,
                status="completed",
            )
        except Exception as e:
            logger.error(f"Failed to complete assessment: {e}")
            return False

        logger.info("Assessment marked as completed")
        return True

    async def fail(self, reason: str | None = None) -> bool:
        """Mark the assessment as failed on the platform.

        Args:
            reason: Optional failure reason.

        Returns:
            True if successfully marked, False otherwise.
        """
        ctx = _get_platform_context()
        if ctx is None or self._assessment_id is None:
            return False

        api, session = ctx
        try:
            kwargs: dict[str, t.Any] = {"status": "failed"}
            if reason:
                kwargs["description"] = f"{self.description or ''}\n\nFailure: {reason}".strip()
            api.update_airt_assessment(
                session.org_key,
                session.workspace_key,
                self._assessment_id,
                **kwargs,
            )
        except Exception as e:
            logger.error(f"Failed to mark assessment as failed: {e}")
            return False

        logger.info("Assessment marked as failed")
        return True
