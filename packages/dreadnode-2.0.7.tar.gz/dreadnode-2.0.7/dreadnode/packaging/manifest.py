from __future__ import annotations

import typing as t

from pydantic import BaseModel, ConfigDict, Field


class BaseManifest(BaseModel):
    """Base manifest with artifact tracking."""

    artifacts: dict[str, str] = Field(default_factory=dict)  # path -> oid
    artifacts_hash: str | None = None


class DatasetManifest(BaseManifest):
    """Dataset-specific manifest."""

    summary: str | None = None
    format: str = "parquet"
    data_schema: dict[str, str] = Field(default_factory=dict)
    row_count: int | None = None
    splits: dict[str, str] | None = None  # split_name -> artifact_path


class ModelManifest(BaseManifest):
    """Model-specific manifest."""

    summary: str | None = None
    framework: str = "safetensors"
    task: str | None = None
    architecture: str | None = None


class EnvironmentManifest(BaseManifest):
    """Environment-specific manifest."""


# ============================================================================
# Capability Manifest
# ============================================================================


class CapabilityManifest(BaseManifest):
    """Capability manifest stored in OCI config and on disk."""

    model_config = ConfigDict(populate_by_name=True, serialize_by_alias=True)

    schema_version: int = Field(default=1, alias="schema")
    name: str = ""
    version: str = ""
    description: str = ""
    agents: list[str] | None = None
    tools: list[str] | None = None
    skills: list[str] | None = None
    mcp: dict[str, t.Any] | None = None
    author: dict[str, str] | None = None
    license: str | None = None
    repository: str | None = None
    keywords: list[str] = Field(default_factory=list)


# Mapping from singular type name to manifest class
MANIFEST_TYPES: dict[str, type[BaseManifest]] = {
    "dataset": DatasetManifest,
    "model": ModelManifest,
    "environment": EnvironmentManifest,
    "capability": CapabilityManifest,
}
