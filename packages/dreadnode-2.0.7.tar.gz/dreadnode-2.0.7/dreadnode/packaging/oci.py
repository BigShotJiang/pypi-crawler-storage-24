"""OCI Distribution client for Dreadnode packages.

Push/pull capabilities, datasets, models, and environments as OCI artifacts.
Uses httpx (already a dependency) — no external OCI library needed.

OCI image layout per package:
  - Config blob: JSON manifest (CapabilityManifest, DatasetManifest, etc.)
  - Layer(s): tar.gz of package directory, or individual CAS blobs

Custom media types:
  - application/vnd.dreadnode.config.v1+json   (config blob)
  - application/vnd.dreadnode.layer.v1.tar+gzip (directory archive)
  - application/vnd.dreadnode.blob.v1           (individual CAS blob)
"""

from __future__ import annotations

import gzip
import hashlib
import inspect
import io
import json
import os
import tarfile
import typing as t
from dataclasses import dataclass, field
from pathlib import Path
from typing import Self
from urllib.parse import urljoin

import httpx
import yaml

if t.TYPE_CHECKING:
    from dreadnode.storage.storage import Storage

# -- Media Types ---------------------------------------------------------------

MEDIA_OCI_MANIFEST = "application/vnd.oci.image.manifest.v1+json"
MEDIA_CONFIG = "application/vnd.dreadnode.config.v1+json"
MEDIA_LAYER_TAR_GZ = "application/vnd.dreadnode.layer.v1.tar+gzip"
MEDIA_BLOB = "application/vnd.dreadnode.blob.v1"

# -- Annotation Keys ----------------------------------------------------------

ANN_TYPE = "io.dreadnode.type"
ANN_NAME = "io.dreadnode.name"
ANN_VERSION = "io.dreadnode.version"
ANN_PATH = "io.dreadnode.path"

# -- Excluded paths during build -----------------------------------------------

_DEFAULT_EXCLUDES = {".git", "__pycache__", ".DS_Store", "dist", ".venv", "node_modules"}
_EXCLUDED_SUFFIXES = {".pyc", ".pyo"}


# ==============================================================================
# Data Types
# ==============================================================================


@dataclass
class Descriptor:
    """OCI content descriptor."""

    media_type: str
    digest: str
    size: int
    annotations: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, t.Any]:
        d: dict[str, t.Any] = {
            "mediaType": self.media_type,
            "digest": self.digest,
            "size": self.size,
        }
        if self.annotations:
            d["annotations"] = self.annotations
        return d


@dataclass
class OCIImage:
    """An OCI image ready for push."""

    config: Descriptor
    layers: list[Descriptor]
    annotations: dict[str, str]
    config_bytes: bytes
    layer_data: dict[str, bytes]  # digest -> bytes

    def manifest_dict(self) -> dict[str, t.Any]:
        return {
            "schemaVersion": 2,
            "mediaType": MEDIA_OCI_MANIFEST,
            "config": self.config.to_dict(),
            "layers": [layer.to_dict() for layer in self.layers],
            "annotations": self.annotations,
        }

    def manifest_bytes(self) -> bytes:
        return json.dumps(self.manifest_dict(), indent=2).encode()


@dataclass
class PushResult:
    success: bool
    manifest_digest: str | None = None
    blobs_pushed: int = 0
    blobs_existed: int = 0
    errors: list[str] = field(default_factory=list)


@dataclass
class PullResult:
    success: bool
    dest: Path | None = None
    config: dict[str, t.Any] | None = None
    errors: list[str] = field(default_factory=list)


# ==============================================================================
# Build
# ==============================================================================


def _sha256(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def _descriptor(
    data: bytes, media_type: str, annotations: dict[str, str] | None = None
) -> Descriptor:
    return Descriptor(
        media_type=media_type,
        digest=_sha256(data),
        size=len(data),
        annotations=annotations or {},
    )


def _should_exclude(rel_parts: tuple[str, ...]) -> bool:
    """Check if a path should be excluded from the archive."""
    for part in rel_parts:
        if part in _DEFAULT_EXCLUDES:
            return True
    return any(rel_parts[-1].endswith(s) for s in _EXCLUDED_SUFFIXES) if rel_parts else False


def build_directory_image(
    source_dir: Path,
    config: dict[str, t.Any],
    *,
    package_type: str,
    name: str,
    version: str,
) -> OCIImage:
    """Build an OCI image from a directory (capabilities, environments).

    The entire directory becomes a single tar.gz layer.
    The config dict becomes the OCI config blob.
    """
    source_dir = source_dir.resolve()

    # Create tar.gz of source directory (deterministic: zero timestamps and metadata)
    buf = io.BytesIO()
    gz = gzip.GzipFile(fileobj=buf, mode="wb", mtime=0)
    with tarfile.open(fileobj=gz, mode="w") as tar:
        for item in sorted(source_dir.rglob("*")):
            if not item.is_file():
                continue
            rel = item.relative_to(source_dir)
            if _should_exclude(rel.parts):
                continue
            info = tar.gettarinfo(item, arcname=str(rel))
            info.mtime = 0
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            with item.open("rb") as f:
                tar.addfile(info, f)
    gz.close()

    layer_bytes = buf.getvalue()

    annotations = {
        ANN_TYPE: package_type,
        ANN_NAME: name,
        ANN_VERSION: version,
    }

    config_bytes = json.dumps(config, indent=2, sort_keys=True).encode()
    config_desc = _descriptor(config_bytes, MEDIA_CONFIG)
    layer_desc = _descriptor(layer_bytes, MEDIA_LAYER_TAR_GZ)

    return OCIImage(
        config=config_desc,
        layers=[layer_desc],
        annotations=annotations,
        config_bytes=config_bytes,
        layer_data={layer_desc.digest: layer_bytes},
    )


def build_manifest_image(
    config: dict[str, t.Any],
    *,
    package_type: str,
    name: str,
    version: str,
) -> OCIImage:
    """Build an OCI image that is just a manifest/config (datasets, models).

    The OCI image contains only the metadata manifest as the config blob.
    No layers — actual artifact blobs (parquet, safetensors, etc.) live in
    S3/CAS and are referenced by digest in the manifest's ``artifacts`` dict.

    At pull time, the consumer reads the config to get artifact pointers,
    then resolves them from CAS/S3.
    """
    annotations = {
        ANN_TYPE: package_type,
        ANN_NAME: name,
        ANN_VERSION: version,
    }

    config_bytes = json.dumps(config, indent=2, sort_keys=True).encode()
    config_desc = _descriptor(config_bytes, MEDIA_CONFIG)

    return OCIImage(
        config=config_desc,
        layers=[],
        annotations=annotations,
        config_bytes=config_bytes,
        layer_data={},
    )


# ==============================================================================
# OCI Registry Client
# ==============================================================================


class OCIRegistryClient:
    """OCI Distribution v2 registry client.

    Supports push/pull of blobs and manifests via the standard
    OCI Distribution Specification endpoints.
    """

    def __init__(
        self,
        registry_url: str,
        *,
        auth: tuple[str, str] | None = None,
        token: str | None = None,
        timeout: float = 300.0,
    ) -> None:
        self._base_url = registry_url.rstrip("/")

        headers: dict[str, str] = {"User-Agent": "dreadnode-sdk/2.0"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        auth_param = httpx.BasicAuth(auth[0], auth[1]) if auth else None

        self._client = httpx.Client(
            base_url=self._base_url,
            headers=headers,
            auth=auth_param,
            timeout=timeout,
            follow_redirects=True,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # -- Blob operations -------------------------------------------------------

    @staticmethod
    def _org_from_name(name: str) -> str:
        """Extract the org segment from an OCI repository name."""
        org, _, _ = name.partition("/")
        if not org:
            raise ValueError(f"Invalid OCI repository name: {name!r}")
        return org

    def blob_exists(self, name: str, digest: str) -> bool:
        """HEAD /v2/<name>/blobs/<digest>"""
        org = self._org_from_name(name)
        resp = self._client.head(f"/api/v1/{org}/blobs/{digest}")
        return resp.status_code == 200

    def push_blob(self, name: str, data: bytes, digest: str) -> bool:
        """Push a blob via monolithic upload. Returns True if newly pushed, False if existed."""
        if self.blob_exists(name, digest):
            return False

        # Initiate upload
        resp = self._client.post(f"/api/v1/{name}/blobs/uploads/")
        resp.raise_for_status()

        location = resp.headers.get("Location", "")
        if not location:
            raise RuntimeError("Registry did not return upload location")

        # Resolve relative location
        if not location.startswith("http"):
            location = urljoin(f"{self._base_url.rstrip('/')}/", location)

        # Complete the upload with digest
        sep = "&" if "?" in location else "?"
        resp = self._client.put(
            f"{location}{sep}digest={digest}",
            content=data,
            headers={"Content-Type": "application/octet-stream"},
        )
        resp.raise_for_status()
        return True

    def pull_blob(self, name: str, digest: str) -> bytes:
        """GET /v2/<name>/blobs/<digest>"""
        org = self._org_from_name(name)
        resp = self._client.get(f"/api/v1/{org}/blobs/{digest}")
        resp.raise_for_status()
        return resp.content

    # -- Manifest operations ---------------------------------------------------

    def push_manifest(self, name: str, reference: str, manifest: bytes) -> str:
        """PUT /v2/<name>/manifests/<reference>. Returns the digest."""
        resp = self._client.put(
            f"/api/v1/{name}/manifests/{reference}",
            content=manifest,
            headers={"Content-Type": MEDIA_OCI_MANIFEST},
        )
        resp.raise_for_status()
        return resp.headers.get("Docker-Content-Digest", _sha256(manifest))

    def pull_manifest(self, name: str, reference: str) -> dict[str, t.Any]:
        """GET /v2/<name>/manifests/<reference>"""
        resp = self._client.get(
            f"/api/v1/{name}/manifests/{reference}",
            headers={"Accept": MEDIA_OCI_MANIFEST},
        )
        resp.raise_for_status()
        return resp.json()

    def list_tags(self, name: str) -> list[str]:
        """GET /v2/<name>/tags/list"""
        resp = self._client.get(f"/api/v1/{name}/tags/list")
        if resp.status_code == 404:
            return []
        resp.raise_for_status()
        return resp.json().get("tags", [])

    # -- High-level push/pull --------------------------------------------------

    def push(self, name: str, tag: str, image: OCIImage) -> PushResult:
        """Push an OCI image (config + layers + manifest) to the registry."""
        result = PushResult(success=False)
        try:
            # Push config blob
            if self.push_blob(name, image.config_bytes, image.config.digest):
                result.blobs_pushed += 1
            else:
                result.blobs_existed += 1

            # Push layer blobs
            for layer in image.layers:
                data = image.layer_data[layer.digest]
                if self.push_blob(name, data, layer.digest):
                    result.blobs_pushed += 1
                else:
                    result.blobs_existed += 1

            # Push manifest
            manifest_bytes = image.manifest_bytes()
            digest = self.push_manifest(name, tag, manifest_bytes)

            result.success = True
            result.manifest_digest = digest
        except (httpx.HTTPError, RuntimeError, ValueError) as exc:
            result.errors.append(str(exc))

        return result

    def pull(self, name: str, reference: str, dest: Path) -> PullResult:
        """Pull an OCI image and extract to dest."""
        result = PullResult(success=False)
        try:
            manifest = self.pull_manifest(name, reference)

            # Pull config
            config_digest = manifest["config"]["digest"]
            config_bytes = self.pull_blob(name, config_digest)
            result.config = json.loads(config_bytes)

            # Pull and extract layers
            dest.mkdir(parents=True, exist_ok=True)
            for layer in manifest.get("layers", []):
                layer_digest = layer["digest"]
                media_type = layer.get("mediaType", "")
                layer_bytes = self.pull_blob(name, layer_digest)

                if media_type == MEDIA_LAYER_TAR_GZ:
                    _safe_extract_tar(layer_bytes, dest)
                elif media_type == MEDIA_BLOB:
                    path_ann = layer.get("annotations", {}).get(ANN_PATH)
                    if path_ann:
                        file_dest = dest / path_ann
                        file_dest.parent.mkdir(parents=True, exist_ok=True)
                        file_dest.write_bytes(layer_bytes)

            result.success = True
            result.dest = dest
        except (
            httpx.HTTPError,
            json.JSONDecodeError,
            KeyError,
            OSError,
            RuntimeError,
            tarfile.TarError,
            ValueError,
        ) as exc:
            result.errors.append(str(exc))

        return result


# ==============================================================================
# Capability convenience functions
# ==============================================================================


def build_capability(source_dir: Path, *, name: str | None = None) -> OCIImage:
    """Build an OCI image from a capability directory.

    Resolves capability.yaml into a full manifest, then packages
    the directory as a tar.gz layer with the manifest as config.
    """
    import asyncio

    from dreadnode.capabilities.loader import load_capability

    cap = asyncio.run(load_capability(source_dir))
    skill_paths: list[str] = []
    for skill_root in sorted(cap.skills_paths or []):
        if skill_root.is_dir():
            for entry in sorted(skill_root.iterdir()):
                if not entry.is_dir():
                    continue
                if not (entry / "SKILL.md").exists():
                    continue
                skill_paths.append(str(entry.relative_to(cap.path)))
        elif skill_root.name.upper() == "SKILL.MD":
            skill_paths.append(str(skill_root.parent.relative_to(cap.path)))

    manifest_dict = json.loads(cap.manifest.model_dump_json())
    capability_root = cap.path.resolve()

    def _tool_source_path(tool: t.Any) -> str | None:
        source_target = getattr(tool.fn, "func", tool.fn)
        source_file = inspect.getsourcefile(source_target)
        if source_file is None:
            return None
        try:
            return str(Path(source_file).resolve().relative_to(capability_root))
        except ValueError:
            return None

    config_dict: dict[str, t.Any] = {
        "capability_manifest": manifest_dict,
        "agents": [
            {
                "name": agent.name,
                "description": agent.description,
                "model": agent.model,
            }
            for agent in cap.agents
        ],
        "tools": [
            {
                "name": tool.name,
                "description": tool.description,
                "path": _tool_source_path(tool),
            }
            for tool in cap.tools
        ],
        "skills": skill_paths,
        "mcp_servers": [
            {
                "name": server.name,
                "description": (
                    manifest_dict.get("mcp", {})
                    .get("servers", {})
                    .get(server.name, {})
                    .get("description")
                ),
            }
            for server in cap.mcp_server_defs
        ],
    }
    resolved_name = name or cap.name
    version = cap.version

    return build_directory_image(
        source_dir,
        config_dict,
        package_type="capability",
        name=resolved_name,
        version=version,
    )


def build_dataset(
    source_dir: Path,
    storage: Storage,
    *,
    name: str | None = None,
) -> OCIImage:
    """Build a manifest-only OCI image from a dataset source directory."""
    from dreadnode.datasets.local import LocalDataset

    dataset = LocalDataset.from_dir(source_dir, storage)
    return build_manifest_image(
        json.loads(dataset.manifest.model_dump_json()),
        package_type="dataset",
        name=name or dataset.name,
        version=dataset.version,
    )


def build_model(
    source_dir: Path,
    storage: Storage,
    *,
    name: str | None = None,
) -> OCIImage:
    """Build a manifest-only OCI image from a model source directory."""
    from dreadnode.models.local import LocalModel

    model = LocalModel.from_dir(source_dir, storage)
    return build_manifest_image(
        json.loads(model.manifest.model_dump_json()),
        package_type="model",
        name=name or model.name,
        version=model.version,
    )


def _load_task_config(source_dir: Path) -> dict[str, t.Any]:
    """Load and validate task.yaml from a task/environment directory."""
    task_yaml_path = source_dir / "task.yaml"
    if not task_yaml_path.is_file():
        raise FileNotFoundError(f"task.yaml not found in {source_dir}")

    task_config = yaml.safe_load(task_yaml_path.read_text())
    if not isinstance(task_config, dict):
        raise TypeError("task.yaml must contain a YAML mapping")
    return task_config


def _build_task_like_image(
    source_dir: Path,
    *,
    package_type: t.Literal["environment", "task"],
    name: str | None = None,
    version: str = "latest",
) -> OCIImage:
    """Build a directory-backed OCI image from task.yaml metadata."""
    task_config = _load_task_config(source_dir)
    resolved_name = name or source_dir.name
    return build_directory_image(
        source_dir,
        task_config,
        package_type=package_type,
        name=resolved_name,
        version=version,
    )


def build_environment(
    source_dir: Path,
    *,
    name: str | None = None,
    version: str = "latest",
) -> OCIImage:
    """Build an OCI image from an environment directory described by task.yaml."""
    return _build_task_like_image(
        source_dir,
        package_type="environment",
        name=name,
        version=version,
    )


def build_task(
    source_dir: Path,
    *,
    name: str | None = None,
    version: str = "latest",
) -> OCIImage:
    """Build an OCI image from a task directory.

    The task.yaml content becomes the OCI config blob and the task directory
    is packaged as a single tar.gz layer.
    """
    return _build_task_like_image(
        source_dir,
        package_type="task",
        name=name,
        version=version,
    )


# ==============================================================================
# Safety
# ==============================================================================


def _safe_extract_tar(data: bytes, dest: Path) -> None:
    """Extract a tar.gz archive with path traversal protection."""
    dest = dest.resolve()
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
        for member in tar.getmembers():
            member_path = (dest / member.name).resolve()
            if not str(member_path).startswith(str(dest) + os.sep) and member_path != dest:
                raise ValueError(f"Path traversal detected in archive: {member.name}")
            if member.issym() or member.islnk():
                raise ValueError(f"Symlinks not allowed in archive: {member.name}")
        tar.extractall(dest, filter="data")
