"""
User interaction tools for agents.

These tools allow agents to ask for clarification, present options,
and get user input during execution.
"""

import asyncio
import typing as t
from contextvars import ContextVar, Token
from uuid import uuid4

from loguru import logger
from pydantic import BaseModel

from dreadnode.agents.tools import Toolset, tool, tool_method
from dreadnode.app.api.models import HumanInputResponse, HumanPrompt, HumanPromptOption
from dreadnode.core.meta import Config

# Context variable for user input callback
# This allows the CLI to inject its input handler
_user_input_callback: ContextVar[t.Callable[[str, list[str] | None], t.Awaitable[str]] | None] = (
    ContextVar("user_input_callback", default=None)
)

HumanPromptHandler = t.Callable[[HumanPrompt], t.Awaitable[HumanInputResponse]]
_human_prompt_handler: ContextVar[HumanPromptHandler | None] = ContextVar(
    "human_prompt_handler",
    default=None,
)


def set_user_input_callback(
    callback: t.Callable[[str, list[str] | None], t.Awaitable[str]],
) -> None:
    """
    Set the callback for getting user input.

    The callback receives:
    - question: The question to ask
    - options: Optional list of choices (None for free-form input)

    Returns the user's response string.
    """
    _user_input_callback.set(callback)


def set_human_prompt_handler(handler: HumanPromptHandler) -> Token[HumanPromptHandler | None]:
    """Set the handler for structured human prompts."""
    return _human_prompt_handler.set(handler)


def reset_human_prompt_handler(token: Token[HumanPromptHandler | None]) -> None:
    """Reset the structured human prompt handler."""
    _human_prompt_handler.reset(token)


def get_user_input_callback() -> t.Callable[[str, list[str] | None], t.Awaitable[str]] | None:
    """Get the current user input callback."""
    return _user_input_callback.get()


def get_human_prompt_handler() -> HumanPromptHandler | None:
    """Get the structured human prompt handler."""
    return _human_prompt_handler.get()


async def _default_input(question: str, options: list[str] | None = None) -> str:
    """Default input handler using stdin (blocking)."""

    if options:
        prompt_lines = [f"  {i}. {opt}" for i, opt in enumerate(options, 1)]
        prompt_lines.append(f"  {len(options) + 1}. Other (free text)")
        prompt_text = f"{question}\n" + "\n".join(prompt_lines) + "\nYour choice (number or text): "

        # Run blocking input in thread
        response = await asyncio.to_thread(input, prompt_text)

        # Parse response
        try:
            idx = int(response.strip()) - 1
            if 0 <= idx < len(options):
                return options[idx]
            if idx == len(options):
                return await asyncio.to_thread(input, "Enter your response: ")
        except ValueError:
            pass

        return response.strip()
    return await asyncio.to_thread(input, f"{question}\n> ")


class QuestionOption(BaseModel):
    """An option for a multiple-choice question."""

    label: str
    """Short label for the option."""
    description: str | None = None
    """Optional longer description."""


@tool(catch=True)
async def ask_user(
    question: t.Annotated[str, "The question to ask the user"],
    options: t.Annotated[
        list[str] | list[HumanPromptOption] | None,
        "Optional list of choices. If provided, user selects from these. "
        "If None, user can type free-form response.",
    ] = None,
    *,
    kind: t.Annotated[
        t.Literal["input", "choice", "approval"] | None,
        "Prompt kind (input, choice, approval). Defaults based on options.",
    ] = None,
    details: t.Annotated[str | None, "Optional supporting details."] = None,
    allow_free_text: t.Annotated[bool | None, "Allow free-form text in choice prompts."] = None,
    default_option: t.Annotated[str | None, "Default option label."] = None,
    severity: t.Annotated[str | None, "Optional severity for the prompt."] = None,
    request_id: t.Annotated[str | None, "Optional request id override."] = None,
    source_tool_name: t.Annotated[str | None, "Source tool name."] = None,
    source_tool_call_id: t.Annotated[str | None, "Source tool call id."] = None,
) -> str:
    """
    Ask the user a question and wait for their response.

    Use this tool when you need:
    - Clarification on ambiguous requirements
    - User preference between options
    - Confirmation before destructive actions
    - Additional information to proceed

    ## Best Practices
    - Ask specific, clear questions
    - Provide options when choices are limited
    - Don't ask unnecessary questions (use your judgment first)
    - Explain why you're asking if it's not obvious

    ## Examples

    Free-form question:
    ```
    ask_user("What authentication method should I use?")
    ```

    Multiple choice:
    ```
    ask_user(
        "Which database should I configure?",
        options=["PostgreSQL", "MySQL", "SQLite"]
    )
    ```

    Confirmation:
    ```
    ask_user(
        "This will delete 15 files. Proceed?",
        options=["Yes, delete them", "No, cancel"]
    )
    ```

    Args:
        question: The question to ask.
        options: Optional list of choices for the user.

    Returns:
        The user's response as a string.
    """
    prompt_handler = get_human_prompt_handler()
    resolved_options: list[HumanPromptOption] | None = None
    if options is not None:
        resolved_options = [
            opt if isinstance(opt, HumanPromptOption) else HumanPromptOption(label=str(opt))
            for opt in options
        ]

    resolved_kind = kind or ("choice" if resolved_options else "input")
    if allow_free_text is None:
        allow_free_text = resolved_kind == "input"

    prompt = HumanPrompt(
        request_id=request_id or f"req-{uuid4().hex}",
        kind=resolved_kind,
        question=question,
        details=details,
        options=resolved_options,
        allow_free_text=allow_free_text,
        default_option=default_option,
        severity=severity,
        source_tool_name=source_tool_name,
        source_tool_call_id=source_tool_call_id,
    )

    if prompt_handler is not None:
        logger.info(f"Asking user (structured): {question}")
        response = await prompt_handler(prompt)
        if response.action in {"approve", "deny", "allow_session"}:
            return response.action
        if response.selected_option:
            return response.selected_option
        if response.text:
            return response.text
        return ""

    callback = get_user_input_callback()
    if callback is None:
        logger.warning("No user input callback set, using default stdin handler")
        callback = _default_input

    logger.info(f"Asking user: {question}")
    legacy_options = [opt.label for opt in resolved_options] if resolved_options else None
    response_text = await callback(question, legacy_options)
    logger.info(f"User responded: {response_text}")
    return response_text


@tool(catch=True)
async def ask_the_user(
    question: t.Annotated[str, "The question to ask the user"],
    options: t.Annotated[
        list[str] | list[HumanPromptOption] | None,
        "Optional list of choices. If provided, user selects from these. "
        "If None, user can type free-form response.",
    ] = None,
    *,
    kind: t.Annotated[
        t.Literal["input", "choice", "approval"] | None,
        "Prompt kind (input, choice, approval). Defaults based on options.",
    ] = None,
    details: t.Annotated[str | None, "Optional supporting details."] = None,
    allow_free_text: t.Annotated[bool | None, "Allow free-form text in choice prompts."] = None,
    default_option: t.Annotated[str | None, "Default option label."] = None,
    severity: t.Annotated[str | None, "Optional severity for the prompt."] = None,
    request_id: t.Annotated[str | None, "Optional request id override."] = None,
    source_tool_name: t.Annotated[str | None, "Source tool name."] = None,
    source_tool_call_id: t.Annotated[str | None, "Source tool call id."] = None,
) -> str:
    """Backward-compatible alias for ask_user."""
    return await ask_user(
        question,
        options=options,
        kind=kind,
        details=details,
        allow_free_text=allow_free_text,
        default_option=default_option,
        severity=severity,
        request_id=request_id,
        source_tool_name=source_tool_name,
        source_tool_call_id=source_tool_call_id,
    )


@tool(catch=True)
async def confirm(
    action: t.Annotated[str, "Description of the action to confirm"],
    *,
    default_yes: t.Annotated[bool, "Whether to default to yes if unclear"] = False,
) -> bool:
    """
    Ask user to confirm an action.

    Returns True if confirmed, False if rejected.

    Args:
        action: What you're asking to confirm.
        default_yes: If True, ambiguous responses default to yes.

    Returns:
        True if user confirms, False otherwise.
    """
    response = await ask_user(f"Confirm: {action}", options=["Yes", "No"])

    response_lower = response.lower().strip()

    if response_lower in ("yes", "y", "1", "confirm", "ok", "sure"):
        return True
    if response_lower in ("no", "n", "2", "cancel", "abort"):
        return False
    return default_yes


class InteractionToolset(Toolset):
    """
    Toolset for user interaction with configurable callback.

    Use this when you need to inject a custom input handler.
    """

    input_callback: t.Callable[[str, list[str] | None], t.Awaitable[str]] | None = Config(
        default=None
    )
    """Custom callback for getting user input."""

    async def _get_input(self, question: str, options: list[str] | None = None) -> str:
        """Get input using configured callback or default."""
        if self.input_callback:
            return await self.input_callback(question, options)

        if get_human_prompt_handler() is not None:
            return await ask_user(question, options=options)

        callback = get_user_input_callback()
        if callback:
            return await callback(question, options)

        return await _default_input(question, options)

    @tool_method(catch=True)
    async def ask(
        self,
        question: t.Annotated[str, "Question to ask"],
        options: t.Annotated[list[str] | None, "Optional choices"] = None,
    ) -> str:
        """Ask user a question."""
        logger.info(f"Asking: {question}")
        response = await self._get_input(question, options)
        logger.info(f"Response: {response}")
        return response

    @tool_method(catch=True)
    async def confirm_action(
        self,
        action: t.Annotated[str, "Action to confirm"],
    ) -> bool:
        """Ask user to confirm an action."""
        response = await self._get_input(f"Confirm: {action}", options=["Yes", "No"])
        return response.lower().strip() in ("yes", "y", "1")
