"""File and directory reading tool with binary detection, pagination, and fuzzy path suggestions."""

import base64
import mimetypes
import typing as t
from pathlib import Path

import aiofiles

from dreadnode.agents.tools import tool

# --- Constants ----------------------------------------------------------------

DEFAULT_READ_LIMIT = 2000
"""Default maximum number of lines to return."""

MAX_LINE_LENGTH = 2000
"""Truncate individual lines longer than this."""

MAX_LINE_SUFFIX = f"... (line truncated to {MAX_LINE_LENGTH} chars)"

MAX_BYTES = 50 * 1024
"""Hard cap on total output size in bytes (50 KB)."""

_BINARY_SAMPLE_SIZE = 4096
"""Number of bytes to sample for binary content detection."""

_NON_PRINTABLE_THRESHOLD = 0.30
"""If more than 30% of sampled bytes are non-printable, treat as binary."""

# Extensions that are always binary — no need to sample content.
_BINARY_EXTENSIONS: frozenset[str] = frozenset(
    {
        # Archives
        ".zip",
        ".tar",
        ".gz",
        ".bz2",
        ".xz",
        ".7z",
        ".rar",
        # Executables / shared objects
        ".exe",
        ".dll",
        ".so",
        ".dylib",
        ".class",
        ".jar",
        ".war",
        ".wasm",
        # Compiled Python
        ".pyc",
        ".pyo",
        # Object files / libraries
        ".o",
        ".a",
        ".obj",
        ".lib",
        # Data / binary blobs
        ".bin",
        ".dat",
        # Office documents (binary formats)
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
        ".ppt",
        ".pptx",
        ".odt",
        ".ods",
        ".odp",
        # Media (non-image — images handled separately)
        ".mp3",
        ".mp4",
        ".avi",
        ".mov",
        ".flac",
        ".wav",
        # Databases
        ".sqlite",
        ".db",
    }
)


# --- Helpers ------------------------------------------------------------------


async def _is_binary_file(filepath: Path, file_size: int) -> bool:
    """Detect whether a file is binary.

    Uses a two-tier strategy matching opencode's ``isBinaryFile``:
    1. Extension-based check for known binary types (instant).
    2. Content sampling — read first 4096 bytes, reject on null byte
       or >30% non-printable characters.
    """
    if filepath.suffix.lower() in _BINARY_EXTENSIONS:
        return True

    if file_size == 0:
        return False

    sample_size = min(_BINARY_SAMPLE_SIZE, file_size)
    async with aiofiles.open(filepath, "rb") as f:
        sample = await f.read(sample_size)

    if not sample:
        return False

    non_printable = 0
    for byte in sample:
        # Null byte is an immediate binary indicator.
        if byte == 0:
            return True
        # Non-printable: outside tab(9), LF(10), CR(13), and printable range (32-126).
        if byte < 9 or (13 < byte < 32):
            non_printable += 1

    return non_printable / len(sample) > _NON_PRINTABLE_THRESHOLD


async def _read_directory(dirpath: Path, offset: int, limit: int) -> str:
    """List directory entries with pagination.

    Directories get a trailing ``/``. Symlinks to directories likewise.
    Entries are sorted alphabetically (case-insensitive).
    """
    entries: list[str] = []
    for child in dirpath.iterdir():
        try:
            if child.is_dir():
                entries.append(child.name + "/")
            elif child.is_symlink():
                # Resolve symlink — if target is a directory, add trailing /
                try:
                    if child.resolve().is_dir():
                        entries.append(child.name + "/")
                    else:
                        entries.append(child.name)
                except OSError:
                    entries.append(child.name)
            else:
                entries.append(child.name)
        except OSError:
            entries.append(child.name)

    entries.sort(key=str.lower)

    start = offset - 1
    sliced = entries[start : start + limit]
    truncated = start + len(sliced) < len(entries)

    lines = [str(dirpath)]
    lines.extend(sliced)

    if truncated:
        lines.append(
            f"\n(Showing {len(sliced)} of {len(entries)} entries. "
            f"Use offset={offset + len(sliced)} to see more.)"
        )
    else:
        lines.append(f"\n({len(entries)} entries)")

    return "\n".join(lines)


def _suggest_similar(filepath: Path) -> list[str]:
    """Find up to 3 similarly-named files in the parent directory."""
    parent = filepath.parent
    base = filepath.name.lower()

    if not parent.is_dir():
        return []

    suggestions: list[str] = []
    try:
        for entry in parent.iterdir():
            name = entry.name.lower()
            if base in name or name in base:
                suggestions.append(str(entry))
                if len(suggestions) >= 3:
                    break
    except OSError:
        pass

    return suggestions


# --- Tool ---------------------------------------------------------------------


@tool(catch=True)
async def read(
    file_path: t.Annotated[str, "Absolute or relative path to the file or directory to read"],
    offset: t.Annotated[int | None, "Line number to start reading from (1-indexed)"] = None,
    limit: t.Annotated[int | None, "Maximum number of lines to read (default 2000)"] = None,
) -> str:
    """
    Read a file or directory from the local filesystem.

    Contents are returned with each line prefixed by its line number as
    ``<line>: <content>``. For directories, entries are listed one per line
    with a trailing ``/`` for subdirectories. Images and PDFs are returned
    as base64-encoded data.

    - Use ``offset`` and ``limit`` to page through large files. Avoid tiny
      repeated slices (e.g. 30 lines) — read a larger window instead.
    - Use the ``grep`` tool to find specific content in large files.
    - If you are unsure of the correct file path, use ``glob`` to look up
      filenames by pattern.
    - Call this tool in parallel when you know there are multiple files to
      read.
    - Any line longer than 2000 characters is truncated.

    Args:
        file_path: Absolute or relative path to the file or directory.
        offset: Line number to start reading from (1-indexed). Default: 1.
        limit: Maximum number of lines to return. Default: 2000.

    Returns:
        File contents with line numbers, directory listing, or base64 data.
    """
    effective_offset = offset if offset is not None else 1
    effective_limit = limit if limit is not None else DEFAULT_READ_LIMIT

    if effective_offset < 1:
        raise ValueError("offset must be >= 1")

    filepath = Path(file_path)

    # --- Not found → fuzzy suggestions ---
    if not filepath.exists():
        suggestions = _suggest_similar(filepath)
        msg = f"File not found: {filepath}"
        if suggestions:
            msg += "\n\nDid you mean one of these?\n" + "\n".join(suggestions)
        raise FileNotFoundError(msg)

    # --- Directory listing ---
    if filepath.is_dir():
        return await _read_directory(filepath, effective_offset, effective_limit)

    stat = filepath.stat()

    # --- Image / PDF → base64 ---
    mime_type, _ = mimetypes.guess_type(str(filepath))
    if mime_type:
        is_image = mime_type.startswith("image/") and mime_type not in (
            "image/svg+xml",  # SVG is XML-based text
        )
        is_pdf = mime_type == "application/pdf"

        if is_image or is_pdf:
            async with aiofiles.open(filepath, "rb") as f:
                raw = await f.read()
            encoded = base64.b64encode(raw).decode("ascii")
            kind = "Image" if is_image else "PDF"
            return (
                f"{kind}: {filepath}\n"
                f"Type: {mime_type}\n"
                f"Size: {stat.st_size:,} bytes\n"
                f"Base64: {encoded}"
            )

    # --- Binary detection ---
    if await _is_binary_file(filepath, stat.st_size):
        raise ValueError(f"Cannot read binary file: {filepath}")

    # --- Text file reading with dual truncation ---
    lines_out: list[str] = []
    total_bytes = 0
    total_lines = 0
    lines_read = 0
    truncated_by_bytes = False
    has_more_lines = False
    start = effective_offset - 1

    async with aiofiles.open(filepath, errors="replace") as f:
        line_num = 0
        async for raw_line in f:
            line_num += 1
            total_lines = line_num

            # Skip lines before offset.
            if line_num <= start:
                continue

            # Already collected enough lines — just count remaining.
            if lines_read >= effective_limit:
                has_more_lines = True
                continue

            line_content = raw_line.rstrip("\n\r")

            # Per-line truncation.
            if len(line_content) > MAX_LINE_LENGTH:
                line_content = line_content[:MAX_LINE_LENGTH] + MAX_LINE_SUFFIX

            formatted = f"{line_num:>6}\u2192{line_content}"

            # Byte-level cap check.
            line_bytes = len(formatted.encode("utf-8")) + (1 if lines_out else 0)
            if total_bytes + line_bytes > MAX_BYTES:
                truncated_by_bytes = True
                has_more_lines = True
                break

            lines_out.append(formatted)
            total_bytes += line_bytes
            lines_read += 1

    # Edge case: offset beyond file length.
    if total_lines < effective_offset and not (total_lines == 0 and effective_offset == 1):
        raise ValueError(f"offset {effective_offset} is beyond end of file ({total_lines} lines)")

    # --- Build output ---
    content = "\n".join(lines_out)

    last_line = effective_offset + lines_read - 1
    next_offset = last_line + 1

    if truncated_by_bytes:
        content += (
            f"\n\n(Output capped at {MAX_BYTES // 1024} KB. "
            f"Showing lines {effective_offset}-{last_line}. "
            f"Use offset={next_offset} to continue.)"
        )
    elif has_more_lines:
        content += (
            f"\n\n(Showing lines {effective_offset}-{last_line} of {total_lines}. "
            f"Use offset={next_offset} to continue.)"
        )
    else:
        content += f"\n\n(End of file — {total_lines} lines total)"

    return content
