"""
Content search tool — find files containing a regex pattern.

Uses ripgrep (rg) when available for speed and .gitignore awareness.
Falls back to pure-Python regex search otherwise.
"""

import mimetypes
import re
import typing as t
from pathlib import Path

import aiofiles

from dreadnode.agents.tools import tool
from dreadnode.tools._ripgrep import find_rg, run_rg

MAX_RESULTS = 100
"""Hard cap on total matches returned."""

MAX_LINE_LENGTH = 2000
"""Truncate individual matching lines longer than this."""

_MAX_FILE_SIZE = 5 * 1024 * 1024
"""Skip files larger than 5 MB in the Python fallback."""

_MAX_FILES_FALLBACK = 200
"""Max files to search in the Python fallback."""

# MIME types considered searchable text.
_TEXT_MIME_PREFIXES = ("text/",)
_TEXT_MIME_EXTRAS = frozenset(
    {
        "application/json",
        "application/xml",
        "application/javascript",
        "application/x-yaml",
        "application/toml",
        "application/x-sh",
        "application/x-python",
    }
)


def _is_text_file(filepath: Path) -> bool:
    """Heuristic check for text files."""
    mime, _ = mimetypes.guess_type(str(filepath))
    if mime is None:
        return True  # Unknown = try it.
    if any(mime.startswith(p) for p in _TEXT_MIME_PREFIXES):
        return True
    return mime in _TEXT_MIME_EXTRAS


# --- Ripgrep backend ----------------------------------------------------------


async def _grep_rg(
    pattern: str,
    search_dir: str,
    *,
    include: str | None = None,
) -> tuple[list[dict[str, t.Any]], bool]:
    """Use ripgrep for content search.

    Returns (matches, has_errors) where matches is a list of dicts
    with keys: path, line_num, line_text, mtime.
    """
    args = [
        "-nH",
        "--hidden",
        "--no-messages",
        "--field-match-separator=|",
        "--regexp",
        pattern,
    ]
    if include:
        args.extend(["--glob", include])
    args.append(search_dir)

    exit_code, stdout, _ = await run_rg(args, cwd=search_dir)

    has_errors = exit_code == 2
    if exit_code == 1 or (exit_code == 2 and not stdout.strip()):
        return [], has_errors
    if exit_code not in (0, 2):
        return [], True

    matches: list[dict[str, t.Any]] = []
    for line in stdout.splitlines():
        if not line:
            continue
        parts = line.split("|", 2)
        if len(parts) < 3:
            continue

        file_path, line_num_str, line_text = parts
        try:
            line_num = int(line_num_str)
        except ValueError:
            continue

        try:
            mtime = Path(file_path).stat().st_mtime
        except OSError:
            mtime = 0.0

        matches.append(
            {
                "path": file_path,
                "line_num": line_num,
                "line_text": line_text,
                "mtime": mtime,
            }
        )

    return matches, has_errors


# --- Python fallback ----------------------------------------------------------


async def _grep_fallback(
    pattern: str,
    search_dir: str,
    *,
    include: str | None = None,
    ignore_case: bool = False,
) -> list[dict[str, t.Any]]:
    """Pure-Python regex search fallback."""
    flags = re.IGNORECASE if ignore_case else 0
    try:
        regex = re.compile(pattern, flags)
    except re.error as e:
        raise ValueError(f"Invalid regex pattern: {e}") from e

    base = Path(search_dir)
    glob_pat = include or "**/*"

    files: list[Path] = []
    for match in base.glob(glob_pat):
        if ".git" in match.parts:
            continue
        if match.is_file() and _is_text_file(match):
            try:
                if match.stat().st_size <= _MAX_FILE_SIZE:
                    files.append(match)
            except OSError:
                continue
        if len(files) >= _MAX_FILES_FALLBACK:
            break

    matches: list[dict[str, t.Any]] = []
    for filepath in files:
        try:
            async with aiofiles.open(filepath, errors="replace") as f:
                for line_num, line in enumerate(await f.readlines(), 1):
                    if regex.search(line):
                        try:
                            mtime = filepath.stat().st_mtime
                        except OSError:
                            mtime = 0.0
                        matches.append(
                            {
                                "path": str(filepath),
                                "line_num": line_num,
                                "line_text": line.rstrip("\n\r"),
                                "mtime": mtime,
                            }
                        )
                        if len(matches) >= MAX_RESULTS * 2:
                            return matches
        except (OSError, UnicodeDecodeError):
            continue

    return matches


# --- Output formatting --------------------------------------------------------


def _format_output(
    matches: list[dict[str, t.Any]],
    *,
    has_errors: bool = False,
) -> str:
    """Format matches into the agent-facing output string.

    Groups matches by file (sorted by mtime, newest first).
    """
    # Sort by mtime descending.
    matches.sort(key=lambda m: m["mtime"], reverse=True)

    total = len(matches)
    truncated = total > MAX_RESULTS
    display = matches[:MAX_RESULTS]

    if not display:
        return "No files found"

    lines: list[str] = []
    lines.append(
        f"Found {total} matches" + (f" (showing first {MAX_RESULTS})" if truncated else "")
    )

    current_file = ""
    for m in display:
        if m["path"] != current_file:
            if current_file:
                lines.append("")
            current_file = m["path"]
            lines.append(f"{m['path']}:")

        text = m["line_text"]
        if len(text) > MAX_LINE_LENGTH:
            text = text[:MAX_LINE_LENGTH] + "..."
        lines.append(f"  Line {m['line_num']}: {text}")

    if truncated:
        lines.append("")
        lines.append(
            f"(Results truncated: showing {MAX_RESULTS} of {total} matches "
            f"({total - MAX_RESULTS} hidden). Use a more specific path or pattern.)"
        )

    if has_errors:
        lines.append("")
        lines.append("(Some paths were inaccessible and skipped)")

    return "\n".join(lines)


# --- Tool ---------------------------------------------------------------------


@tool(catch=True)
async def grep(
    pattern: t.Annotated[str, "Regex pattern to search for in file contents"],
    path: t.Annotated[
        str | None, "File or directory to search in (default: working directory)"
    ] = None,
    *,
    include: t.Annotated[
        str | None,
        'File glob to filter searched files (e.g. "*.py", "*.{ts,tsx}")',
    ] = None,
    cwd: t.Annotated[str | None, "Working directory for relative paths"] = None,
) -> str:
    """
    Search file contents for a regex pattern.

    Returns matching file paths with line numbers and content, grouped by
    file and sorted by modification time (newest first). Use this tool
    when you need to find files containing specific text or patterns.

    - Supports full regex syntax (e.g. ``log.*Error``,
      ``def\\s+\\w+``).
    - Filter files with the ``include`` parameter (e.g. ``*.py``,
      ``*.{ts,tsx}``).
    - Results are capped at 100 matches; lines truncated at 2000 chars.
    - For open-ended searches requiring multiple rounds, consider using
      a sub-agent instead.

    Args:
        pattern: Regular expression to search for.
        path: Directory or file to search in. Defaults to working directory.
        include: Glob pattern to filter which files are searched.
        cwd: Working directory for resolving relative paths.

    Returns:
        Formatted match results grouped by file.
    """
    base = Path(cwd) if cwd else Path.cwd()
    search_path = str(base / path) if path and not Path(path).is_absolute() else (path or str(base))

    if not Path(search_path).exists():
        raise FileNotFoundError(f"Path not found: {search_path}")

    # Try ripgrep first, fall back to Python.
    rg = await find_rg()
    if rg is not None:
        matches, has_errors = await _grep_rg(pattern, search_path, include=include)
        return _format_output(matches, has_errors=has_errors)
    matches = await _grep_fallback(pattern, search_path, include=include, ignore_case=False)
    return _format_output(matches)
