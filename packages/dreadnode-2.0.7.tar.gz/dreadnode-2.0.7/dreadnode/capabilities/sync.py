"""Capability sync — downloads capabilities from the platform.

See docs/domains/capabilities/runtime.md (CAP-LOAD-010..013).
"""

from __future__ import annotations

import shutil
import typing as t
from dataclasses import dataclass, field

from loguru import logger

from dreadnode.capabilities.capability import (
    read_local_capability_records,
    write_local_capability_records,
)

if t.TYPE_CHECKING:
    from pathlib import Path

    from dreadnode.app.api.client import ApiClient


@dataclass
class SyncError:
    """A capability that failed to sync."""

    name: str
    error: str


@dataclass
class SyncResult:
    """Result of runtime sync operation."""

    synced: list[str] = field(default_factory=list)
    cached: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    errors: list[SyncError] = field(default_factory=list)
    bindings: list[dict[str, t.Any]] = field(default_factory=list)


@dataclass
class LocalInstallResult:
    """Result of a local registry-backed capability install."""

    installed_name: str
    source: str
    overwritten: bool = False


def encode_capability_dirname(name: str) -> str:
    """Encode a capability name for use as a directory name.

    Replaces '/' with '_' to avoid nested directories. This is bijective
    because capability name parts follow [a-z0-9][a-z0-9-]* (no underscores).
    e.g., 'acme/github' -> 'acme_github'
    """
    return name.replace("/", "_")


def decode_capability_dirname(dirname: str) -> str:
    """Decode a directory name back to a capability name.

    Replaces the first '_' with '/' (canonical names have exactly one '/').
    e.g., 'acme_github' -> 'acme/github'
    """
    return dirname.replace("_", "/", 1)


def bare_capability_name(qualified_name: str) -> str:
    """Extract the bare name from an org-qualified capability name.

    e.g., 'acme/github' -> 'github'
    If no '/' present, returns the name as-is.
    """
    if "/" in qualified_name:
        return qualified_name.split("/", 1)[1]
    return qualified_name


class CapabilitySyncClient:
    """Downloads runtime capabilities from the platform into a local cache.

    CAP-LOAD-010: sync before runtime starts.
    CAP-LOAD-012: cache is runtime-managed.
    CAP-LOAD-013: produces same directory layout the loader expects.
    """

    def __init__(
        self,
        api: ApiClient,
        org: str,
        workspace: str,
        cache_dir: Path,
        runtime_id: str,
    ) -> None:
        self._api = api
        self._org = org
        self._workspace = workspace
        self._runtime_id = runtime_id
        self._cache_dir = cache_dir

    async def sync(self) -> SyncResult:
        """Sync runtime capabilities from the platform.

        Downloads enabled capabilities into the cache directory.
        Uses digest-based caching to skip unchanged capabilities.
        """
        self._cache_dir.mkdir(parents=True, exist_ok=True)

        # 1. Fetch resolved capabilities (let exceptions propagate)
        try:
            resolved = self._api.get_runtime_capabilities_resolved(
                self._org,
                self._workspace,
                self._runtime_id,
            )
        except RuntimeError as exc:
            if self._is_not_found_error(exc):
                logger.debug(
                    "Runtime capability resolution returned 404 for '{}'; treating as empty result",
                    self._runtime_id,
                )
                return SyncResult()
            raise
        resolved_caps = resolved.get("capabilities", [])
        logger.info(
            "Resolved {} capabilities for runtime {}: {}",
            len(resolved_caps),
            self._runtime_id,
            [c["name"] for c in resolved_caps] or "(none)",
        )

        result = SyncResult()
        resolved_names: set[str] = set()

        # 2. Sync each resolved capability
        for cap_info in resolved_caps:
            name = cap_info["name"]
            resolved_names.add(name)
            encoded = encode_capability_dirname(name)
            cap_dir = self._cache_dir / encoded
            digest = cap_info.get("runtime_digest", "")

            # Check cache
            digest_file = cap_dir / ".runtime_digest"
            if digest_file.exists() and digest_file.read_text().strip() == digest:
                logger.debug("Capability '{}' unchanged (digest match), using cache", name)
                result.cached.append(name)
                continue

            # Download to temp dir, atomic rename on success
            temp_dir = self._cache_dir / f".tmp-{encoded}"
            try:
                self._download_capability(cap_info, temp_dir)

                # Write digest marker
                (temp_dir / ".runtime_digest").write_text(digest)

                # Atomic replace: remove old, rename temp
                if cap_dir.exists():
                    shutil.rmtree(cap_dir)
                temp_dir.rename(cap_dir)

                result.synced.append(name)
            except Exception as e:
                logger.warning("Failed to sync capability '{}': {}", name, e)
                result.errors.append(SyncError(name=name, error=str(e)))
                # Clean up temp dir on failure
                if temp_dir.exists():
                    shutil.rmtree(temp_dir)

        # 3. Remove stale cached capabilities
        if self._cache_dir.exists():
            for entry in self._cache_dir.iterdir():
                if not entry.is_dir() or entry.name.startswith("."):
                    continue
                decoded = decode_capability_dirname(entry.name)
                if decoded not in resolved_names:
                    shutil.rmtree(entry)
                    result.removed.append(decoded)

        # 4. Fetch full binding list (best-effort — enrichment data)
        try:
            bindings_response = self._api.list_runtime_capabilities(
                self._org,
                self._workspace,
                self._runtime_id,
            )
            result.bindings = bindings_response.get("items", [])
        except Exception:
            logger.warning("Failed to fetch runtime bindings — proceeding without binding metadata")

        return result

    @staticmethod
    def _is_not_found_error(exc: RuntimeError) -> bool:
        return str(exc).startswith("404:")

    def _download_capability(
        self,
        cap_info: dict[str, t.Any],
        target_dir: Path,
    ) -> None:
        """Download all files for a single capability into target_dir."""
        name = cap_info["name"]
        version = cap_info["version"]
        bare = bare_capability_name(name)

        # Clean target if it exists (partial previous attempt)
        if target_dir.exists():
            shutil.rmtree(target_dir)
        target_dir.mkdir(parents=True)

        # Get file manifest
        detail = self._api.get_capability(self._org, bare, version)
        file_manifest = detail.get("file_manifest", [])

        # Download each file
        for entry in file_manifest:
            file_path = entry["path"]
            content = self._api.get_capability_file(self._org, bare, version, file_path)
            dest = target_dir / file_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(content if isinstance(content, bytes) else content.encode())


class LocalInstallClient:
    """Install registry-backed capabilities into the local user store."""

    def __init__(
        self,
        api: ApiClient,
        org: str,
        local_dir: Path,
        state_path: Path,
    ) -> None:
        self._api = api
        self._org = org
        self._local_dir = local_dir
        self._state_path = state_path

    async def install(
        self,
        *,
        name: str,
        version: str,
        source: str,
        overwrite: bool,
    ) -> LocalInstallResult:
        self._local_dir.mkdir(parents=True, exist_ok=True)

        detail, fetch_file = self._resolve_detail(name=name, version=version, source=source)
        manifest = detail.get("manifest", {})
        local_name = str(manifest.get("name") or bare_capability_name(name))

        target_dir = self._local_dir / local_name
        temp_dir = self._local_dir / f".tmp-{local_name}"

        if target_dir.exists():
            if not overwrite:
                raise FileExistsError(f"Capability already exists locally: {local_name}")
            shutil.rmtree(target_dir)

        if temp_dir.exists():
            shutil.rmtree(temp_dir)
        temp_dir.mkdir(parents=True, exist_ok=True)

        try:
            for entry in detail.get("file_manifest", []):
                file_path = entry["path"]
                content = fetch_file(file_path)
                dest = temp_dir / file_path
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(content if isinstance(content, bytes) else content.encode())

            temp_dir.rename(target_dir)
        except Exception:
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
            raise

        artifact_identity = name if "/" in name else f"{self._org}/{name}"
        records = read_local_capability_records(self._state_path)
        records[local_name] = {
            "enabled": True,
            "source": source,
            "version": version,
            "artifact_identity": artifact_identity,
            "digest": detail.get("runtime_digest"),
            "artifact_sha256": detail.get("artifact_sha256"),
        }
        write_local_capability_records(self._state_path, records)

        return LocalInstallResult(
            installed_name=local_name,
            source=source,
            overwritten=overwrite,
        )

    def _resolve_detail(
        self,
        *,
        name: str,
        version: str,
        source: str,
    ) -> tuple[dict[str, t.Any], t.Callable[[str], bytes]]:
        if source == "public":
            owner, public_name = name.split("/", 1)
            detail = self._api.get_public_capability(owner, public_name, version)

            def fetch_file(file_path: str) -> bytes:
                return self._api.get_public_capability_file(owner, public_name, version, file_path)

            return detail, fetch_file

        bare = bare_capability_name(name)
        detail = self._api.get_capability(self._org, bare, version)

        def fetch_file(file_path: str) -> bytes:
            return self._api.get_capability_file(self._org, bare, version, file_path)

        return detail, fetch_file
