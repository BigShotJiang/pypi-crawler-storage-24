"""
Capability type definitions — v1 spec.

See docs/domains/capabilities/contract.md for the canonical schema.
"""

from __future__ import annotations

import typing as t
from dataclasses import dataclass, field

if t.TYPE_CHECKING:
    from pathlib import Path

    from dreadnode.capabilities.capability import Capability

# ============================================================================
# Component Definitions
# ============================================================================


@dataclass
class AgentDef:
    """Agent definition resolved from markdown frontmatter."""

    name: str
    description: str
    model: str = "inherit"
    system_prompt: str = ""
    tools: dict[str, bool] = field(default_factory=dict)
    skills: list[str] = field(default_factory=list)
    hooks: list[str] = field(default_factory=list)
    metadata: dict[str, t.Any] | None = None
    capability: str | None = None


@dataclass
class AgentLinkDef:
    """Synthetic capability link between agents."""

    kind: t.Literal["delegate", "subagent", "handoff"]
    source: str
    target: str


@dataclass
class MCPServerDef:
    """Parsed MCP server definition from a capability manifest.

    CAP-MCP-002: transport is inferred from fields (command -> stdio, url -> streamable-http).
    """

    name: str
    transport: t.Literal["stdio", "streamable-http"]
    # stdio fields
    command: str | None = None
    args: list[str] = field(default_factory=list)
    env: dict[str, str] | None = None
    cwd: str | Path | None = None
    # streamable-http fields
    url: str | None = None
    headers: dict[str, str] | None = None
    # timeout fields (capability.yaml → server config)
    timeout: float | None = None
    init_timeout: float | None = None

    def _resolve_init_timeout(self) -> dict[str, float]:
        """Resolve init_timeout: explicit init_timeout > timeout > default."""
        if self.init_timeout is not None:
            return {"init_timeout": self.init_timeout}
        if self.timeout is not None:
            return {"init_timeout": self.timeout}
        return {}

    def to_server_config(self) -> t.Any:
        """Convert to an MCPClient-compatible ServerConfig."""
        from dreadnode.agents.mcp.config import HttpServerConfig, StdioServerConfig

        timeout_kw = self._resolve_init_timeout()
        if self.transport == "stdio":
            return StdioServerConfig(
                command=self.command or "",
                args=self.args,
                env=self.env,
                cwd=self.cwd,
                **timeout_kw,
            )
        return HttpServerConfig(
            url=self.url or "",
            headers=self.headers,
            **timeout_kw,
        )


@dataclass
class LoadFailure:
    """A capability that failed to load."""

    name: str
    path: Path
    error: str


@dataclass
class LoadResult:
    """Result of loading capabilities from search paths."""

    capabilities: list[Capability] = field(default_factory=list)
    failures: list[LoadFailure] = field(default_factory=list)


@dataclass
class LoadOptions:
    """Options for loading a capability."""

    base_dir: Path | None = None
