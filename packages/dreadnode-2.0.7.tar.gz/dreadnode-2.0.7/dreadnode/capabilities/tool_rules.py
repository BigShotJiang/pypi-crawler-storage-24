"""Tool filtering rules with glob-pattern matching.

Agents declare tool access via a dict of {pattern: bool} rules.
Rules are evaluated in insertion order; last matching rule wins.
Patterns use fnmatch glob syntax (*, ?, [seq]).

Examples:
    {}                                          -> all tools allowed (default)
    {"*": True, "bash": False}                  -> everything except bash
    {"*": False, "read": True, "grep": True}    -> only read and grep
    {"mcp_*": False}                            -> block all MCP tools
    {"*": True, "mcp_*": False, "mcp_pg": True} -> allow mcp_pg, deny other mcp_*
"""

import fnmatch
import typing as t

ToolRules = dict[str, bool]


def match_pattern(name: str, pattern: str) -> bool:
    """Match a tool name against a glob pattern (*, ?, [seq]).

    Matching is case-insensitive so authors don't need to worry about
    the exact casing of tool names.
    """
    return fnmatch.fnmatchcase(name.lower(), pattern.lower())


def is_tool_allowed(name: str, rules: ToolRules) -> bool:
    """Check if a tool is allowed by evaluating rules in order.

    Last matching rule wins. If no rule matches, the tool is allowed.
    """
    result = True
    for pattern, allowed in rules.items():
        if match_pattern(name, pattern):
            result = allowed
    return result


def filter_tools(
    tools: list[t.Any],
    rules: ToolRules,
    *,
    name_fn: t.Callable[[t.Any], str] = lambda t: t.name,
) -> list[t.Any]:
    """Filter tool objects through rules. Empty rules = all tools pass."""
    if not rules:
        return list(tools)
    return [tool for tool in tools if is_tool_allowed(name_fn(tool), rules)]
