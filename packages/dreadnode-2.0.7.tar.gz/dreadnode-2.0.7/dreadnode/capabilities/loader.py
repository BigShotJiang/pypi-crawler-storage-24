"""
Capability loader — v1 spec.

Load capabilities from disk, validate against the v1 contract,
and prepare for use.

See docs/domains/capabilities/ for the canonical spec.
"""

from __future__ import annotations

import importlib.util
import os
import re
import sys
import typing as t
from pathlib import Path

import yaml
from loguru import logger
from packaging.version import InvalidVersion, Version

from dreadnode.capabilities.types import (
    AgentDef,
    LoadFailure,
    LoadOptions,
    LoadResult,
    MCPServerDef,
)
from dreadnode.packaging.manifest import CapabilityManifest
from dreadnode.storage.storage import Storage

MANIFEST_FILE = "capability.yaml"
PROJECT_CAPABILITIES_RELATIVE_DIR = Path(".dreadnode") / "capabilities"
CAPABILITY_DIRS_ENV = "DREADNODE_CAPABILITY_DIRS"
PROJECT_ROOT_ENV = "DREADNODE_PROJECT_ROOT"

# CAP-VALID-002: name pattern
_NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]*$")


# ============================================================================
# Search Path Resolution
# ============================================================================


def get_default_capabilities_dir() -> Path:
    """Get the default user capabilities directory."""
    from dreadnode.app.main import DEFAULT_INSTANCE

    if DEFAULT_INSTANCE._storage is not None:
        return DEFAULT_INSTANCE.storage.capabilities_path

    return Storage(cache=DEFAULT_INSTANCE.cache).capabilities_path


def resolve_search_paths(
    *,
    capability_dirs: list[str | Path] | None = None,
    cwd: Path | None = None,
    user_dir: str | Path | None = None,
) -> list[Path]:
    """
    Resolve capability discovery search paths (CAP-LOAD-001).

    Precedence:
    1. Project-local .dreadnode/capabilities
    2. User-local ~/.dreadnode/capabilities
    3. Explicit dirs (CLI flags)
    4. DREADNODE_CAPABILITY_DIRS env list
    """
    cwd = cwd or Path.cwd()
    project_dir = (_resolve_project_root(cwd) / PROJECT_CAPABILITIES_RELATIVE_DIR).resolve()
    user_dir = (
        Path(user_dir).resolve()
        if user_dir is not None
        else get_default_capabilities_dir().resolve()
    )
    explicit = [Path(d).resolve() for d in (capability_dirs or [])]
    env_dirs = _split_capability_dirs(os.environ.get(CAPABILITY_DIRS_ENV))

    ordered = [project_dir, user_dir, *explicit, *env_dirs]
    return _dedupe_paths(ordered)


def _resolve_project_root(cwd: Path) -> Path:
    root_from_env = os.environ.get(PROJECT_ROOT_ENV, "").strip()
    if root_from_env:
        return (cwd / root_from_env).resolve()

    git_root = _find_git_root(cwd)
    if git_root:
        return git_root

    return cwd.resolve()


def _find_git_root(start: Path) -> Path | None:
    current = start.resolve()
    while True:
        if (current / ".git").exists():
            return current
        parent = current.parent
        if parent == current:
            return None
        current = parent


def _split_capability_dirs(value: str | None) -> list[Path]:
    if not value:
        return []
    return [Path(entry.strip()).resolve() for entry in value.split(os.pathsep) if entry.strip()]


def _dedupe_paths(paths: list[Path]) -> list[Path]:
    seen: set[Path] = set()
    deduped: list[Path] = []
    for p in paths:
        if p not in seen:
            seen.add(p)
            deduped.append(p)
    return deduped


# ============================================================================
# Load Single Capability
# ============================================================================


class _CapabilityResolution(t.NamedTuple):
    path: Path
    manifest: CapabilityManifest
    agents: list[AgentDef]
    tools: list[t.Any] | None
    skills_paths: list[Path] | None
    skills_path: Path | None
    mcp_server_defs: list[MCPServerDef]
    component_health: list[dict[str, t.Any]]


async def load_capability(
    path: str | Path,
    options: LoadOptions | None = None,
    source: t.Literal["runtime", "local"] = "local",
) -> t.Any:
    """Load a capability from a directory."""
    options = options or LoadOptions()
    base = options.base_dir or Path.cwd()
    capability_path = (base / path).resolve()
    manifest_path = capability_path / MANIFEST_FILE

    if not manifest_path.exists():
        raise FileNotFoundError(f"No {MANIFEST_FILE} found in {capability_path}")

    resolved = _resolve_capability(capability_path)

    from dreadnode.capabilities.capability import Capability

    return Capability._from_resolved(
        path=resolved.path,
        manifest=resolved.manifest,
        agents=resolved.agents,
        tools=resolved.tools,
        skills_paths=resolved.skills_paths,
        skills_path=resolved.skills_path,
        mcp_server_defs=resolved.mcp_server_defs,
        source=source,
        component_health=resolved.component_health,
    )


# ============================================================================
# Load Multiple Capabilities
# ============================================================================


async def load_capabilities(
    directory: str | Path | None = None,
    options: LoadOptions | None = None,
    source: t.Literal["runtime", "local"] = "local",
) -> LoadResult:
    """Load all capabilities from a directory."""
    options = options or LoadOptions()
    cap_dir = (
        Path(directory).resolve()
        if directory is not None
        else get_default_capabilities_dir().resolve()
    )

    if not cap_dir.exists():
        return LoadResult()

    capabilities: list[t.Any] = []
    failures: list[LoadFailure] = []

    for entry in sorted(cap_dir.iterdir()):
        if not entry.is_dir():
            continue
        if not (entry / MANIFEST_FILE).exists():
            logger.debug("Skipping {} — no {}", entry.name, MANIFEST_FILE)
            continue
        try:
            cap = await load_capability(entry, options, source=source)
            capabilities.append(cap)
        except Exception as e:
            failures.append(
                LoadFailure(
                    name=entry.name,
                    path=entry,
                    error=str(e),
                )
            )

    logger.debug(
        "Scanned {} — found {} capabilities, {} failures",
        cap_dir,
        len(capabilities),
        len(failures),
    )

    return LoadResult(capabilities=capabilities, failures=failures)


async def load_capabilities_from_search_paths(
    search_paths: list[Path],
    options: LoadOptions | None = None,
    source: t.Literal["runtime", "local"] = "local",
) -> LoadResult:
    """
    Load capabilities from search paths.

    If the same capability name appears in multiple directories, the first one wins.
    """
    capabilities: list[t.Any] = []
    failures: list[LoadFailure] = []
    seen: set[str] = set()

    for path in search_paths:
        result = await load_capabilities(path, options, source=source)
        for cap in result.capabilities:
            if cap.name not in seen:
                seen.add(cap.name)
                capabilities.append(cap)
        failures.extend(result.failures)

    return LoadResult(capabilities=capabilities, failures=failures)


# ============================================================================
# Capability Discovery
# ============================================================================


async def list_capabilities(
    directory: str | Path | None = None,
) -> list[dict[str, t.Any]]:
    """List available capabilities without fully loading them."""
    cap_dir = (
        Path(directory).resolve()
        if directory is not None
        else get_default_capabilities_dir().resolve()
    )

    if not cap_dir.exists():
        return []

    results: list[dict[str, t.Any]] = []

    for entry in sorted(cap_dir.iterdir()):
        if not entry.is_dir():
            continue

        manifest_path = entry / MANIFEST_FILE
        if not manifest_path.exists():
            continue

        try:
            content = manifest_path.read_text()
            manifest = _parse_capability_file(content, manifest_path)
            results.append(
                {
                    "name": manifest.name,
                    "path": str(entry),
                    "version": manifest.version,
                    "description": manifest.description,
                }
            )
        except Exception:
            results.append({"name": entry.name, "path": str(entry)})

    return results


# ============================================================================
# Capability Resolution
# ============================================================================


def _resolve_capability(capability_path: Path) -> _CapabilityResolution:
    manifest_path = capability_path / MANIFEST_FILE
    content = manifest_path.read_text()
    manifest = _parse_capability_file(content, manifest_path)
    component_health: list[dict[str, t.Any]] = []

    agent_refs = _build_export_refs(capability_path, manifest.agents, ["agents/"], "agents")
    agents = _resolve_agent_definitions(
        capability_path, manifest.name, agent_refs, component_health
    )
    mcp_defs = parse_mcp_servers(manifest.mcp, capability_path, component_health)
    skills_paths = _resolve_skill_paths(capability_path, manifest.skills, component_health) or None
    skills_path = skills_paths[0] if skills_paths else None
    skill_count = sum(1 for h in component_health if h.get("kind") == "skill")
    exported_count = (
        len(agents)
        + skill_count
        + _count_python_tool_files(capability_path, manifest.tools)
        + len(mcp_defs)
    )
    if exported_count == 0:
        raise ValueError(
            f"Capability '{manifest.name}' must export at least one component "
            f"(agent, tool, skill, or MCP server) [CAP-VALID-008]"
        )

    return _CapabilityResolution(
        path=capability_path,
        manifest=manifest,
        agents=agents,
        tools=None,
        skills_paths=skills_paths,
        skills_path=skills_path,
        mcp_server_defs=mcp_defs,
        component_health=component_health,
    )


# ============================================================================
# Manifest Parsing & Validation
# ============================================================================


def _parse_capability_file(content: str, manifest_path: Path) -> CapabilityManifest:
    """Parse and validate a capability.yaml file against v1 spec."""
    parsed = yaml.safe_load(content)
    if not isinstance(parsed, dict):
        raise ValueError(f"Capability manifest must contain a root object: {manifest_path}")  # noqa: TRY004

    _validate_contract(parsed, manifest_path)

    return CapabilityManifest(
        schema_version=parsed["schema"],
        name=parsed["name"],
        version=str(parsed["version"]),
        description=parsed["description"],
        agents=parsed.get("agents"),  # None=omitted (auto-discover), []=disabled
        tools=parsed.get("tools"),
        skills=parsed.get("skills"),
        mcp=parsed.get("mcp"),
        author=parsed.get("author"),
        license=parsed.get("license"),
        repository=parsed.get("repository"),
        keywords=parsed.get("keywords", []),
    )


def _validate_contract(data: dict[str, t.Any], manifest_path: Path) -> None:
    """Validate a capability manifest against v1 spec rules.

    CAP-VALID-005: Unknown top-level keys are ignored.
    Only canonical v1 fields are validated.
    """

    # CAP-VALID-001: required fields
    for required in ("schema", "name", "version", "description"):
        if required not in data:
            raise ValueError(
                f"Required field '{required}' missing in {manifest_path} [CAP-VALID-001]"
            )

    # CAP-VALID-004: schema must be 1
    schema = data["schema"]
    if schema != 1:
        raise ValueError(
            f"Unsupported schema version {schema!r} in {manifest_path}; expected 1 [CAP-VALID-004]"
        )

    # CAP-VALID-002: name format
    name = data["name"]
    if not isinstance(name, str) or not _NAME_PATTERN.match(name):
        raise ValueError(
            f"Capability name {name!r} must match [a-z0-9][a-z0-9-]* "
            f"in {manifest_path} [CAP-VALID-002]"
        )

    # CAP-VALID-003: version is valid semver
    version = data["version"]
    if not isinstance(version, (str, int, float)):
        raise ValueError(f"Capability version must be a string in {manifest_path} [CAP-VALID-003]")  # noqa: TRY004
    try:
        Version(str(version))
    except InvalidVersion as exc:
        raise ValueError(
            f"Capability version {version!r} is not valid semver in {manifest_path} [CAP-VALID-003]"
        ) from exc

    # CAP-VALID-001: description must be a non-empty string
    description = data["description"]
    if not isinstance(description, str) or not description.strip():
        raise ValueError(
            f"Capability 'description' must be a non-empty string "
            f"in {manifest_path} [CAP-VALID-001]"
        )

    # CAP-VALID-006: export path arrays must contain only non-empty strings
    for field in ("agents", "tools", "skills"):
        value = data.get(field)
        if value is None:
            continue
        if not isinstance(value, list):
            raise ValueError(  # noqa: TRY004
                f"Capability field '{field}' must be an array in {manifest_path} [CAP-VALID-006]"
            )
        for item in value:
            if not isinstance(item, str) or not item:
                raise ValueError(
                    f"Capability field '{field}' must contain only non-empty strings "
                    f"in {manifest_path} [CAP-VALID-006]"
                )

    # Validate mcp if present
    mcp = data.get("mcp")
    if mcp is not None and not isinstance(mcp, dict):
        raise ValueError(f"Capability field 'mcp' must be an object in {manifest_path}")

    # Validate keywords if present
    keywords = data.get("keywords")
    if keywords is not None:
        if not isinstance(keywords, list):
            raise ValueError(f"Capability field 'keywords' must be an array in {manifest_path}")
        for item in keywords:
            if not isinstance(item, str):
                raise ValueError(  # noqa: TRY004
                    f"Capability field 'keywords' must contain strings in {manifest_path}"
                )


# ============================================================================
# Export Path Resolution
# ============================================================================


class _ExportRef(t.NamedTuple):
    path: str
    required: bool
    field: str


def _build_export_refs(
    capability_path: Path,
    configured_paths: list[str] | None,
    default_paths: list[str],
    field: str,
) -> list[_ExportRef]:
    """Build export references from configured + default paths.

    Per contract.md "Omission vs. Empty Behavior":
    - Field omitted (None): auto-discover default dirs
    - Field present with paths: auto-discover defaults PLUS listed paths
    - Field present as []: disabled — no auto-discovery
    """
    # Explicit empty list = disabled
    if configured_paths is not None and len(configured_paths) == 0:
        return []

    refs: list[_ExportRef] = []
    seen: set[Path] = set()

    # Auto-discover default directories
    for default_path in default_paths:
        normalized = default_path.strip()
        if not normalized:
            continue
        absolute = (capability_path / normalized).resolve()
        if not absolute.exists():
            continue
        if absolute in seen:
            continue
        # CAP-VALID-007: path must be within capability directory
        if not _is_contained_within(absolute, capability_path):
            continue
        seen.add(absolute)
        refs.append(_ExportRef(path=normalized, required=False, field=field))

    # Add configured paths
    for configured_path in configured_paths or []:
        normalized = configured_path.strip()
        if not normalized:
            continue
        absolute = (capability_path / normalized).resolve()
        # CAP-VALID-007: path must be within capability directory
        if not _is_contained_within(absolute, capability_path):
            raise ValueError(
                f"Export path '{configured_path}' resolves outside capability "
                f"directory in {capability_path} [CAP-VALID-007]"
            )
        if absolute in seen:
            continue
        seen.add(absolute)
        refs.append(_ExportRef(path=normalized, required=True, field=field))

    return refs


def _is_contained_within(resolved_path: Path, capability_path: Path) -> bool:
    """Check that a path is contained within the capability root (prevent traversal)."""
    try:
        real_root = capability_path.resolve()
        real_path = resolved_path.resolve()
        return real_path == real_root or str(real_path).startswith(str(real_root) + os.sep)
    except (OSError, ValueError):
        return False


def _resolve_export_path(
    capability_path: Path,
    ref: _ExportRef,
) -> Path | None:
    resolved = (capability_path / ref.path).resolve()
    if not resolved.exists():
        return None
    if not _is_contained_within(resolved, capability_path):
        return None
    return resolved


# ============================================================================
# Skill Path Resolution
# ============================================================================


def _resolve_skill_paths(
    capability_path: Path,
    configured_paths: list[str] | None,
    component_health: list[dict[str, t.Any]] | None = None,
) -> list[Path]:
    """Resolve skill export paths."""
    refs = _build_export_refs(capability_path, configured_paths, ["skills/"], "skills")
    paths: list[Path] = []
    for ref in refs:
        resolved = (capability_path / ref.path).resolve()
        if not resolved.exists():
            continue
        if not _is_contained_within(resolved, capability_path):
            continue
        # Record health for each skill subdirectory
        if component_health is not None and resolved.is_dir():
            for skill_dir in sorted(resolved.iterdir()):
                if not skill_dir.is_dir():
                    continue
                skill_md = skill_dir / "SKILL.md"
                if skill_md.exists():
                    component_health.append(
                        {
                            "kind": "skill",
                            "name": skill_dir.name,
                            "status": "ok",
                            "error": None,
                            "detail": None,
                        }
                    )
                else:
                    component_health.append(
                        {
                            "kind": "skill",
                            "name": skill_dir.name,
                            "status": "error",
                            "error": f"Missing SKILL.md in {skill_dir}",
                            "detail": "Each skill directory must contain a SKILL.md file",
                        }
                    )
        paths.append(resolved)
    return paths


# ============================================================================
# Agent Resolution
# ============================================================================


def _resolve_agent_definitions(
    capability_path: Path,
    capability_name: str,
    refs: list[_ExportRef],
    component_health: list[dict[str, t.Any]],
) -> list[AgentDef]:
    agents: list[AgentDef] = []

    for ref in refs:
        resolved = _resolve_export_path(capability_path, ref)
        if not resolved:
            continue

        files: list[Path] = []
        if resolved.is_dir():
            files = [
                f
                for f in _list_files_recursive(resolved)
                if f.suffix.lower() in (".md", ".markdown")
            ]
        elif resolved.suffix.lower() in (".md", ".markdown"):
            files = [resolved]

        for f in files:
            agent, health = _load_agent_from_markdown(f, capability_name)
            component_health.append(health)
            if agent is not None:
                agents.append(agent)

    _assert_unique_names(agents, "agent", capability_path)
    return agents


def _load_agent_from_markdown(
    file_path: Path,
    capability_name: str,
) -> tuple[AgentDef | None, dict[str, t.Any]]:
    try:
        agent = _agent_from_markdown(file_path)
        agent.capability = capability_name
    except Exception as exc:
        logger.warning(f"Failed to load agent from {file_path}: {exc}")
        return (
            None,
            {
                "kind": "agent",
                "name": file_path.stem,
                "status": "error",
                "error": str(exc),
                "detail": "Check agent markdown frontmatter format",
            },
        )
    else:
        return (
            agent,
            {
                "kind": "agent",
                "name": agent.name,
                "status": "ok",
                "error": None,
                "detail": None,
            },
        )


def _agent_from_markdown(file_path: Path) -> AgentDef:
    """Parse an agent definition from a markdown file with YAML frontmatter."""
    content = file_path.read_text()
    fallback_name = file_path.stem

    frontmatter, body = _parse_frontmatter(content)

    # Name: from frontmatter or filename stem
    name = fallback_name
    if frontmatter and isinstance(frontmatter.get("name"), str) and frontmatter["name"].strip():
        name = frontmatter["name"].strip()

    # CAP-VALID-010: agent name format
    if not _NAME_PATTERN.match(name):
        logger.warning(f"Agent name '{name}' in {file_path} does not match [a-z0-9][a-z0-9-]*")

    # CAP-VALID-011: description required
    description = f"Agent '{name}'"
    if frontmatter and isinstance(frontmatter.get("description"), str):
        description = frontmatter["description"]
    elif body.strip():
        description = _extract_markdown_summary(body) or description

    # Model
    model = "inherit"
    if frontmatter and isinstance(frontmatter.get("model"), str) and frontmatter["model"].strip():
        model = frontmatter["model"].strip()

    # Tool rules: dict[str, bool] with fnmatch patterns
    tools = _read_tools_dict(frontmatter, "tools", file_path)

    # Skills allow-list
    skills = _read_string_list(frontmatter, "skills", file_path)

    # Agent hooks
    hooks = _read_string_list(frontmatter, "hooks", file_path)

    # Metadata
    metadata = (
        frontmatter.get("metadata")
        if frontmatter and isinstance(frontmatter.get("metadata"), dict)
        else None
    )

    # CAP-VALID-011: body (system prompt) must be non-empty
    system_prompt = body.strip()
    if not system_prompt:
        logger.warning(f"Agent '{name}' in {file_path} has empty system prompt [CAP-VALID-011]")

    return AgentDef(
        name=name,
        description=description,
        model=model,
        system_prompt=system_prompt,
        tools=tools,
        skills=skills,
        hooks=hooks,
        metadata=metadata,
    )


# ============================================================================
# Python Tool Discovery
# ============================================================================


def _python_export_paths(
    capability_path: Path,
    configured_paths: list[str] | None,
    default_dir: str,
) -> list[Path]:
    if configured_paths is not None and len(configured_paths) == 0:
        return []

    seen_roots: set[Path] = set()
    roots: list[Path] = []

    for relative in [default_dir, *(configured_paths or [])]:
        resolved = (capability_path / relative).resolve()
        if not resolved.exists() or not _is_contained_within(resolved, capability_path):
            continue
        if resolved in seen_roots:
            continue
        seen_roots.add(resolved)
        roots.append(resolved)

    files: list[Path] = []
    for root in roots:
        if root.is_dir():
            files.extend(file for file in sorted(root.rglob("*.py")) if file.name != "__init__.py")
        elif root.suffix.lower() == ".py" and root.name != "__init__.py":
            files.append(root)
    return files


def _load_python_module(
    file_path: Path,
    capability_path: Path,
    capability_name: str,
    kind: str,
) -> t.Any:
    relative = file_path.resolve().relative_to(capability_path.resolve())
    module_name = (
        f"dreadnode.capabilities.{kind}."
        f"{capability_name.replace('-', '_')}."
        f"{str(relative.with_suffix('')).replace('/', '_').replace('-', '_')}"
    )
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec for {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _instantiate_toolset(toolset_cls: type[t.Any]) -> t.Any | None:
    try:
        return toolset_cls()
    except TypeError:
        return None


def _discover_python_tools(
    capability_path: Path,
    manifest: CapabilityManifest,
    component_health: list[dict[str, t.Any]],
) -> list[t.Any]:
    """Discover Python tools from @tool and Toolset classes."""
    from dreadnode.agents.tools import Tool, Toolset

    tools: list[t.Any] = []
    seen: set[str] = set()
    for file_path in _python_export_paths(capability_path, manifest.tools, "tools/"):
        try:
            module = _load_python_module(file_path, capability_path, manifest.name, "tool")
        except Exception as e:
            logger.warning(f"[{manifest.name}] Failed to import {file_path}: {e}")
            component_health.append(
                {
                    "kind": "tool",
                    "name": file_path.stem,
                    "status": "error",
                    "error": str(e),
                    "detail": "Check that all dependencies are installed in the runtime environment",
                }
            )
            continue

        for value in vars(module).values():
            if isinstance(value, Tool):
                if value.name not in seen:
                    tools.append(value)
                    seen.add(value.name)
                    component_health.append(
                        {
                            "kind": "tool",
                            "name": value.name,
                            "status": "ok",
                            "error": None,
                            "detail": None,
                        }
                    )
                continue

            if isinstance(value, Toolset):
                for tool in value.get_tools():
                    if tool.name in seen:
                        continue
                    tools.append(tool)
                    seen.add(tool.name)
                    component_health.append(
                        {
                            "kind": "tool",
                            "name": tool.name,
                            "status": "ok",
                            "error": None,
                            "detail": None,
                        }
                    )
                continue

            if isinstance(value, type) and issubclass(value, Toolset) and value is not Toolset:
                toolset = _instantiate_toolset(value)
                if toolset is None:
                    logger.warning(
                        f"[{manifest.name}] Toolset {value.__name__} requires constructor arguments "
                        "— skipping auto-instantiation"
                    )
                    component_health.append(
                        {
                            "kind": "tool",
                            "name": value.__name__,
                            "status": "error",
                            "error": f"Toolset {value.__name__} requires constructor arguments",
                            "detail": "Provide a no-arg constructor or instantiate the Toolset manually",
                        }
                    )
                    continue
                for tool in toolset.get_tools():
                    if tool.name in seen:
                        continue
                    tools.append(tool)
                    seen.add(tool.name)
                    component_health.append(
                        {
                            "kind": "tool",
                            "name": tool.name,
                            "status": "ok",
                            "error": None,
                            "detail": None,
                        }
                    )
    return tools


# ============================================================================
# Component Counting (for CAP-VALID-008)
# ============================================================================


def _count_python_tool_files(
    capability_path: Path,
    configured_paths: list[str] | None,
) -> int:
    """Count Python tool files that would be discovered."""
    refs = _build_export_refs(capability_path, configured_paths, ["tools/"], "tools")
    count = 0
    for ref in refs:
        resolved = _resolve_export_path(capability_path, ref)
        if not resolved:
            continue
        if resolved.is_dir():
            count += sum(1 for f in resolved.rglob("*.py") if f.name != "__init__.py")
        elif resolved.suffix.lower() == ".py" and resolved.name != "__init__.py":
            count += 1
    return count


def _count_mcp_servers(
    mcp: dict[str, t.Any] | None,
    capability_path: Path,
) -> int:
    """Count MCP servers from manifest definition.

    Delegates to parse_mcp_servers() for accurate counting of individual
    servers, including those defined within .mcp.json files.
    """
    return len(parse_mcp_servers(mcp, capability_path))


# ============================================================================
# MCP Server Parsing
# ============================================================================


def _interpolate_capability_root(value: str, root: str) -> str:
    """Replace ${CAPABILITY_ROOT} in a string value (CAP-MCP-003)."""
    return value.replace("${CAPABILITY_ROOT}", root)


def _interpolate_server_def(raw: dict[str, t.Any], root: str) -> dict[str, t.Any]:
    """Interpolate ${CAPABILITY_ROOT} in all string values of a server def."""
    result: dict[str, t.Any] = {}
    for key, value in raw.items():
        if isinstance(value, str):
            result[key] = _interpolate_capability_root(value, root)
        elif isinstance(value, list):
            result[key] = [
                _interpolate_capability_root(v, root) if isinstance(v, str) else v for v in value
            ]
        elif isinstance(value, dict):
            result[key] = {
                k: _interpolate_capability_root(v, root) if isinstance(v, str) else v
                for k, v in value.items()
            }
        else:
            result[key] = value
    return result


def _parse_server_entry(name: str, raw: dict[str, t.Any], capability_path: Path) -> MCPServerDef:
    """Parse a single MCP server entry into an MCPServerDef."""
    root = str(capability_path.resolve())
    interpolated = _interpolate_server_def(raw, root)

    # Optional timeout fields
    timeout_kw: dict[str, float] = {}
    if "timeout" in interpolated:
        timeout_kw["timeout"] = float(interpolated["timeout"])
    if "init_timeout" in interpolated:
        timeout_kw["init_timeout"] = float(interpolated["init_timeout"])

    # CAP-MCP-002: infer transport from fields
    if "command" in interpolated:
        return MCPServerDef(
            name=name,
            transport="stdio",
            command=interpolated["command"],
            args=interpolated.get("args", []),
            env=interpolated.get("env"),
            cwd=interpolated.get("cwd", root),  # CAP-MCP-005
            **timeout_kw,
        )
    if "url" in interpolated:
        return MCPServerDef(
            name=name,
            transport="streamable-http",
            url=interpolated["url"],
            headers=interpolated.get("headers"),
            **timeout_kw,
        )
    raise ValueError(f"MCP server '{name}' must have either 'command' (stdio) or 'url' (http)")


def _load_mcp_file(path: Path) -> dict[str, dict[str, t.Any]]:
    """Load an .mcp.json file and return its mcpServers dict."""
    import json

    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to read MCP config file {}: {}", path, e)
        return {}

    servers = data.get("mcpServers", {})
    if not isinstance(servers, dict):
        logger.warning("Invalid mcpServers in {}: expected object", path)
        return {}
    return servers


def parse_mcp_servers(
    mcp: dict[str, t.Any] | None,
    capability_path: Path,
    component_health: list[dict[str, t.Any]] | None = None,
) -> list[MCPServerDef]:
    """Parse MCP server definitions from a capability manifest.

    CAP-MCP-001: files and inline servers are merged, inline wins on name conflict.
    Returns empty list for mcp={} (explicit disable).
    Auto-discovers .mcp.json and mcp.json when mcp is None.
    """
    # mcp={} -> explicit disable
    if isinstance(mcp, dict) and not mcp:
        return []

    merged: dict[str, dict[str, t.Any]] = {}

    if mcp is None:
        # Auto-discover
        for filename in (".mcp.json", "mcp.json"):
            p = capability_path / filename
            if p.exists():
                merged.update(_load_mcp_file(p))
    else:
        # Load from files first
        files = mcp.get("files", [])
        if isinstance(files, list):
            for rel in files:
                p = capability_path / rel
                if p.exists():
                    merged.update(_load_mcp_file(p))
                else:
                    logger.warning("MCP config file not found: {}", p)

        # Inline servers override file-loaded (CAP-MCP-001)
        servers = mcp.get("servers", {})
        if isinstance(servers, dict):
            merged.update(servers)

    defs: list[MCPServerDef] = []
    for name, raw in merged.items():
        if not isinstance(raw, dict):
            logger.warning("Skipping MCP server '{}': expected object", name)
            continue
        try:
            defs.append(_parse_server_entry(name, raw, capability_path))
            if component_health is not None:
                component_health.append(
                    {
                        "kind": "mcp_server",
                        "name": name,
                        "status": "ok",
                        "error": None,
                        "detail": None,
                    }
                )
        except Exception as e:
            # CAP-MCP-007: single server failure doesn't invalidate capability
            logger.warning("Failed to parse MCP server '{}': {}", name, e)
            if component_health is not None:
                component_health.append(
                    {
                        "kind": "mcp_server",
                        "name": name,
                        "status": "error",
                        "error": str(e),
                        "detail": "Check MCP server definition — needs 'command' (stdio) or 'url' (http)",
                    }
                )

    return defs


# ============================================================================
# Merge Capabilities
# ============================================================================


def merge_capabilities(capabilities: list[t.Any]) -> MergedCapabilities:
    """Merge multiple capabilities into one."""

    agents: list[AgentDef] = []
    tools: list[t.Any] = []

    for cap in capabilities:
        agents.extend(cap.agents)
        tools.extend(cap.tools)

    return MergedCapabilities(agents=agents, tools=tools)


# ============================================================================
# Utility Types
# ============================================================================


class MergedCapabilities(t.NamedTuple):
    agents: list[AgentDef]
    tools: list[t.Any]


# ============================================================================
# Helpers
# ============================================================================


def _list_files_recursive(root: Path) -> list[Path]:
    """List all files recursively, sorted. Skips the manifest file."""
    if not root.is_dir():
        return []
    return [
        item
        for item in sorted(root.rglob("*"))
        if item.is_file() and item.name not in {MANIFEST_FILE, "__init__.py"}
    ]


def _assert_unique_names(
    defs: list[t.Any],
    kind: str,
    capability_path: Path,
) -> None:
    seen: set[str] = set()
    for d in defs:
        name = d.name if hasattr(d, "name") else d.get("name", "")
        if name in seen:
            raise ValueError(f"Duplicate {kind} name '{name}' in capability at {capability_path}")
        seen.add(name)


def _parse_frontmatter(content: str) -> tuple[dict[str, t.Any] | None, str]:
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", content, re.DOTALL)
    if not match:
        return None, content
    try:
        parsed = yaml.safe_load(match.group(1))
        return (parsed if isinstance(parsed, dict) else None), match.group(2)
    except yaml.YAMLError:
        return None, content


def _extract_markdown_summary(content: str) -> str:
    for raw_line in content.split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("#"):
            return re.sub(r"^#+\s*", "", line).strip()
        return line[:117] + "..." if len(line) > 120 else line
    return ""


def _read_string_list(
    obj: dict[str, t.Any] | None,
    field: str,
    source: Path,
) -> list[str]:
    if not obj or field not in obj or obj[field] is None:
        return []

    value = obj[field]
    if not isinstance(value, list):
        raise ValueError(f"Field '{field}' must be an array in {source}")  # noqa: TRY004

    result: list[str] = []
    for item in value:
        if not isinstance(item, str) or not item.strip():
            raise ValueError(f"Field '{field}' must contain only non-empty strings in {source}")
        result.append(item)
    return result


def _read_tools_dict(
    obj: dict[str, t.Any] | None,
    field: str,
    source: Path,
) -> dict[str, bool]:
    if not obj or field not in obj or obj[field] is None:
        return {}

    value = obj[field]
    if isinstance(value, dict):
        for k, v in value.items():
            if not isinstance(k, str) or not k.strip():
                raise ValueError(f"Field '{field}' keys must be non-empty strings in {source}")
            if not isinstance(v, bool):
                raise ValueError(f"Field '{field}' values must be booleans in {source}")  # noqa: TRY004
        return dict(value)

    raise ValueError(f"Field '{field}' must be a dict in {source}")
