import asyncio
import typing as t
from datetime import UTC, datetime
from uuid import UUID, uuid4

import typing_extensions as te
from pydantic import BaseModel, ConfigDict, Field, PrivateAttr

from dreadnode.evaluations.result import EvalResult


def _now_utc() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(tz=UTC)


CandidateT = te.TypeVar("CandidateT", default=t.Any)
TrialStatus = t.Literal["pending", "running", "finished", "failed", "pruned"]


class Trial(BaseModel, t.Generic[CandidateT]):
    """Represents a single, evaluated point in the search space.

    Attributes:
        id: Unique identifier for the trial.
        candidate: The candidate configuration being assessed.
        status: Current status of the trial.
        score: The primary, single-value fitness score for this trial.
            This is an average of all objective scores for this trial adjusted
            based on their objective directions (higher is better).

        eval_result: Complete evaluation result of the trial and associated dataset.
        pruning_reason: Reason for pruning this trial, if applicable.
        error: Any error which occurred while processing this trial.
        step: The optimization step which produced this trial.
        dataset: The specific dataset used for probing.
        created_at: The creation timestamp of the trial.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, use_attribute_docstrings=True)

    id: UUID = Field(default_factory=uuid4)
    candidate: CandidateT
    status: TrialStatus = "pending"
    score: float = -float("inf")
    scores: dict[str, float] = Field(default_factory=dict)
    directional_scores: dict[str, float] = Field(default_factory=dict)
    evaluation_result: EvalResult | None = None
    pruning_reason: str | None = None
    error: str | None = None
    step: int = Field(default=0)
    parent_id: UUID | None = None
    created_at: datetime = Field(default_factory=_now_utc)
    started_at: datetime | None = None
    finished_at: datetime | None = None

    _future: "asyncio.Future[Trial[CandidateT]]" = PrivateAttr(
        default_factory=lambda: asyncio.get_running_loop().create_future()
    )

    def __repr__(self) -> str:
        parts = [
            f"id={self.id}",
            f"status='{self.status}'",
            f"step={self.step}",
            f"score={self.score:.5f}",
            f"scores={{{', '.join(f'{k}={v:.5f}' for k, v in self.scores.items())}}}",
        ]
        return f"{self.__class__.__name__}({', '.join(parts)})"

    def __str__(self) -> str:
        return self.__repr__()

    def __await__(self) -> t.Generator[t.Any, None, "Trial[CandidateT]"]:
        """
        Await the completion of the trial.
        """
        return self._future.__await__()

    def done(self) -> bool:
        """A non-blocking check to see if the trial's evaluation is complete."""
        return self._future.done()

    @staticmethod
    async def wait_for(*trials: "Trial[CandidateT]") -> "list[Trial[CandidateT]]":
        """
        Await the completion of multiple trials.

        Args:
            *trials: The trials to wait for.

        Returns:
            A future that resolves to a list of completed trials.
        """
        return await asyncio.gather(*(trial._future for trial in trials))

    def get_directional_score(
        self, name: str | None = None, default: float = -float("inf")
    ) -> float:
        """
        Get a specific named objective score - adjusted for optimization direction (higher is better),
        or the overall score if no name is given.

        Args:
            name: The name of the objective.
            default: The value to return if the named score is not found.
        """
        if name is not None:
            return self.scores.get(name, default)
        return self.score

    @property
    def all_scores(self) -> dict[str, float]:
        """
        A dictionary of all named metric mean values from the evaluation result.

        This includes scores not directly related to the objective.
        """
        if not self.evaluation_result or not self.evaluation_result.metrics_summary:
            return {}

        return {
            name: summary.get("mean", -float("inf"))
            for name, summary in self.evaluation_result.metrics_summary.items()
        }

    @property
    def score_breakdown(self) -> dict[str, list[float]]:
        """
        Returns a breakdown of all objective scores across all samples in the evaluation result.

        Returns:
            A dictionary where keys are objective names and values are lists of scores,
            with each score corresponding to a sample from the evaluation dataset.
        """
        if not self.evaluation_result or not self.evaluation_result.samples:
            return {}

        return {k: v for k, v in self.evaluation_result.metrics.items() if k in self.scores}


@te.runtime_checkable
class TrialCollector(t.Protocol, t.Generic[CandidateT]):
    """
    Collect a list of relevant trials based on the current trial.
    """

    def __call__(
        self,
        current_trial: Trial[CandidateT],
        all_trials: list[Trial[CandidateT]],
        /,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> list[Trial[CandidateT]]: ...


@te.runtime_checkable
class TrialSampler(t.Protocol, t.Generic[CandidateT]):
    """
    Sample from a list of trials.
    """

    def __call__(
        self, trials: list[Trial[CandidateT]], /, *args: t.Any, **kwargs: t.Any
    ) -> list[Trial[CandidateT]]: ...
