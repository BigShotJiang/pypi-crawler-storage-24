import calendar
import os
import sqlite3
import sys
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Iterable

from .models import Account, Transaction

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT NOT NULL UNIQUE,
  institution TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT,
  currency TEXT NOT NULL,
  last_seen_at TEXT
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT NOT NULL,
  posted_at TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  currency TEXT NOT NULL,
  description TEXT,
  merchant TEXT,
  source_txn_id TEXT,
  fingerprint TEXT NOT NULL,
  pending INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(account_id, source_txn_id) ON CONFLICT IGNORE
);

-- Fallback uniqueness when source_txn_id is NULL:
CREATE UNIQUE INDEX IF NOT EXISTS ux_txn_fallback
ON transactions(account_id, posted_at, amount_cents, fingerprint)
WHERE source_txn_id IS NULL;

CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ran_at TEXT NOT NULL,
  lookback_days INTEGER NOT NULL,
  txns_fetched INTEGER NOT NULL,
  txns_inserted INTEGER NOT NULL,
  txns_updated INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS subscription_candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT NOT NULL,
  merchant_norm TEXT NOT NULL,
  amount_median_cents INTEGER NOT NULL,
  interval_days INTEGER NOT NULL,
  confidence REAL NOT NULL,
  last_seen_at TEXT NOT NULL,
  next_expected_at TEXT,
  monthly_cost_estimate_cents INTEGER NOT NULL,
  details_json TEXT
);

CREATE TABLE IF NOT EXISTS anomalies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  severity TEXT NOT NULL,
  details_json TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(txn_id) REFERENCES transactions(id)
);

-- Alert actions: user feedback on detected alerts
CREATE TABLE IF NOT EXISTS alert_actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  alert_key TEXT NOT NULL UNIQUE,  -- Unique identifier: "type|merchant|amount|date"
  action TEXT NOT NULL,             -- "ack", "not_suspicious", "confirmed", "canceled"
  merchant_norm TEXT,               -- For learning across similar transactions
  pattern_type TEXT,                -- "duplicate_charge", "unusual_amount", etc.
  notes TEXT,                       -- User notes
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Index for quick lookups
CREATE INDEX IF NOT EXISTS idx_alert_actions_merchant ON alert_actions(merchant_norm);
CREATE INDEX IF NOT EXISTS idx_alert_actions_key ON alert_actions(alert_key);

-- Merchant learning: remember user preferences for merchants
CREATE TABLE IF NOT EXISTS merchant_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  merchant_pattern TEXT NOT NULL,   -- Substring or exact match
  rule_type TEXT NOT NULL,          -- "trust", "suspicious", "ignore_duplicates", "income"
  created_at TEXT NOT NULL,
  UNIQUE(merchant_pattern, rule_type)
);

-- Manual type overrides for recurring charges (subscription vs bill)
CREATE TABLE IF NOT EXISTS recurring_type_overrides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  merchant_norm TEXT NOT NULL UNIQUE,  -- Normalized merchant name
  override_type TEXT NOT NULL,         -- "subscription", "bill", "auto" (auto = use ML)
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Manual category overrides for merchants
CREATE TABLE IF NOT EXISTS category_overrides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  merchant_norm TEXT NOT NULL UNIQUE,  -- Normalized merchant name
  category_id TEXT NOT NULL,           -- Category ID (e.g., "healthcare", "shopping")
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Transaction type overrides (INCOME, EXPENSE, TRANSFER, REFUND, CREDIT_OTHER)
-- Supports both fingerprint-specific and merchant pattern overrides
CREATE TABLE IF NOT EXISTS txn_type_overrides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fingerprint TEXT,                    -- Specific transaction (NULL for merchant pattern)
  merchant_pattern TEXT,               -- Merchant substring (NULL for fingerprint)
  target_type TEXT NOT NULL,           -- INCOME, EXPENSE, TRANSFER, REFUND, CREDIT_OTHER
  reason TEXT,                         -- User note explaining override
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(fingerprint),
  UNIQUE(merchant_pattern)
);

-- Index for fast fingerprint lookup
CREATE INDEX IF NOT EXISTS idx_txn_type_overrides_fp ON txn_type_overrides(fingerprint);

-- Budget targets
CREATE TABLE IF NOT EXISTS budget_targets (
    category_id TEXT NOT NULL UNIQUE,
    monthly_target_cents INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Transaction notes
CREATE TABLE IF NOT EXISTS transaction_notes (
    fingerprint TEXT NOT NULL UNIQUE,
    note TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Transaction tags
CREATE TABLE IF NOT EXISTS transaction_tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fingerprint TEXT NOT NULL,
    tag TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(fingerprint, tag)
);

CREATE INDEX IF NOT EXISTS idx_txn_tags_fp ON transaction_tags(fingerprint);
CREATE INDEX IF NOT EXISTS idx_txn_tags_tag ON transaction_tags(tag);

-- Performance indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_txn_posted_at ON transactions(posted_at);
CREATE INDEX IF NOT EXISTS idx_txn_account_posted ON transactions(account_id, posted_at);
CREATE INDEX IF NOT EXISTS idx_txn_pending ON transactions(pending) WHERE pending = 1;
CREATE INDEX IF NOT EXISTS idx_txn_amount ON transactions(amount_cents);

-- User-confirmed recurring commitments (source of truth for projections)
CREATE TABLE IF NOT EXISTS commitments (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  name           TEXT NOT NULL,
  merchant_norm  TEXT,            -- nullable; links to transaction matching
  expected_cents INTEGER,         -- nullable; use detected median if NULL
  cadence        TEXT NOT NULL DEFAULT 'monthly',
                                  -- monthly | weekly | annual | quarterly
                                  -- biweekly | one_time
  day_of_month   INTEGER,         -- expected charge day (1–31), nullable
  reference_date TEXT,            -- YYYY-MM-DD; anchor for non-monthly cadences
  confirmed      INTEGER NOT NULL DEFAULT 0,  -- 0=suggestion, 1=user-confirmed
  source         TEXT NOT NULL DEFAULT 'detected',
                                  -- detected | manual | dismissed
  direction      TEXT NOT NULL DEFAULT 'expense',
                                  -- expense | income
  created_at     TEXT NOT NULL,
  updated_at     TEXT NOT NULL
);
"""


def _utcnow_iso() -> str:
    """Return current UTC time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


def connect(db_path: str, check_same_thread: bool = True) -> sqlite3.Connection:
    """
    Connect to SQLite database.

    Args:
        db_path: Path to the database file
        check_same_thread: Set to False for multi-threaded access (e.g., FastAPI)
    """
    db = Path(db_path)
    db.parent.mkdir(parents=True, exist_ok=True)
    is_new = not db.exists()
    conn = sqlite3.connect(db_path, check_same_thread=check_same_thread)
    # Restrict file permissions to owner-only on Unix systems
    if is_new and sys.platform != "win32":
        try:
            os.chmod(db_path, 0o600)
        except OSError:
            pass
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_SQL)
    # Migration: add pending column if it doesn't exist
    try:
        conn.execute("ALTER TABLE transactions ADD COLUMN pending INTEGER NOT NULL DEFAULT 0")
        conn.commit()
    except sqlite3.OperationalError:
        pass  # Column already exists
    # Migration: add direction column to commitments if it doesn't exist
    try:
        conn.execute("ALTER TABLE commitments ADD COLUMN direction TEXT NOT NULL DEFAULT 'expense'")
        conn.commit()
    except sqlite3.OperationalError:
        pass  # Column already exists
    conn.commit()


def upsert_accounts(conn: sqlite3.Connection, accounts: Iterable[Account]) -> None:
    now = _utcnow_iso()
    for a in accounts:
        conn.execute(
            """
            INSERT INTO accounts(account_id, institution, name, type, currency, last_seen_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(account_id) DO UPDATE SET
              institution=excluded.institution,
              name=excluded.name,
              type=excluded.type,
              currency=excluded.currency,
              last_seen_at=excluded.last_seen_at
            """,
            (a.account_id, a.institution, a.name, a.type, a.currency, now),
        )
    conn.commit()


def upsert_transactions(conn: sqlite3.Connection, txns: Iterable[Transaction]) -> tuple[int, int]:
    inserted = 0
    updated = 0
    now = _utcnow_iso()

    for t in txns:
        pending_int = 1 if t.pending else 0
        if t.source_txn_id:
            # Update first - use <> instead of IS NOT for non-NULL comparisons
            cur_upd = conn.execute(
                """
                UPDATE transactions
                SET posted_at=?, amount_cents=?, currency=?, description=?, merchant=?,
                    fingerprint=?, pending=?, updated_at=?
                WHERE account_id=? AND source_txn_id=?
                AND (
                    posted_at <> ?
                    OR amount_cents <> ?
                    OR currency <> ?
                    OR COALESCE(description, '') <> COALESCE(?, '')
                    OR COALESCE(merchant, '') <> COALESCE(?, '')
                    OR fingerprint <> ?
                    OR pending <> ?
                )
                """,
                (
                    t.posted_at.isoformat(), t.amount_cents, t.currency, t.description, t.merchant,
                    t.fingerprint, pending_int, now, t.account_id, t.source_txn_id,
                    # comparison params
                    t.posted_at.isoformat(), t.amount_cents, t.currency, t.description, t.merchant, t.fingerprint, pending_int
                ),
            )
            if cur_upd.rowcount > 0:
                updated += 1
                continue

            # Insert if missing
            cur_ins = conn.execute(
                """
                INSERT OR IGNORE INTO transactions(
                  account_id, posted_at, amount_cents, currency, description, merchant,
                  source_txn_id, fingerprint, pending, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    t.account_id, t.posted_at.isoformat(), t.amount_cents, t.currency,
                    t.description, t.merchant, t.source_txn_id, t.fingerprint, pending_int, now, now
                ),
            )
            if cur_ins.rowcount == 1:
                inserted += 1
        else:
            cur_ins = conn.execute(
                """
                INSERT OR IGNORE INTO transactions(
                  account_id, posted_at, amount_cents, currency, description, merchant,
                  source_txn_id, fingerprint, pending, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)
                """,
                (
                    t.account_id, t.posted_at.isoformat(), t.amount_cents, t.currency,
                    t.description, t.merchant, t.fingerprint, pending_int, now, now
                ),
            )
            if cur_ins.rowcount == 1:
                inserted += 1

    conn.commit()
    return inserted, updated


def record_run(conn: sqlite3.Connection, lookback_days: int, fetched: int, ins: int, upd: int) -> None:
    conn.execute(
        "INSERT INTO runs(ran_at, lookback_days, txns_fetched, txns_inserted, txns_updated) VALUES (?, ?, ?, ?, ?)",
        (_utcnow_iso(), lookback_days, fetched, ins, upd),
    )
    conn.commit()


def save_alert_action(
    conn: sqlite3.Connection,
    alert_key: str,
    action: str,
    merchant_norm: str | None = None,
    pattern_type: str | None = None,
    notes: str | None = None,
) -> None:
    """Save or update an alert action."""
    now = _utcnow_iso()
    conn.execute(
        """
        INSERT INTO alert_actions(alert_key, action, merchant_norm, pattern_type, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(alert_key) DO UPDATE SET
          action=excluded.action,
          notes=excluded.notes,
          updated_at=excluded.updated_at
        """,
        (alert_key, action, merchant_norm, pattern_type, notes, now, now),
    )
    conn.commit()


def get_alert_actions(conn: sqlite3.Connection) -> dict[str, str]:
    """Get all alert actions as a dict of alert_key -> action."""
    rows = conn.execute("SELECT alert_key, action FROM alert_actions").fetchall()
    return {r["alert_key"]: r["action"] for r in rows}


def get_actioned_alert_keys(conn: sqlite3.Connection) -> set[str]:
    """Get set of alert keys that have been acknowledged (ack)."""
    rows = conn.execute(
        "SELECT alert_key FROM alert_actions WHERE action = 'ack'"
    ).fetchall()
    return {r["alert_key"] for r in rows}


def mark_income_source(conn: sqlite3.Connection, merchant_pattern: str, is_income: bool) -> None:
    """
    Mark a merchant pattern as income or not-income.

    is_income=True: This is real income (paychecks, etc.)
    is_income=False: This is NOT income (transfers, refunds, etc.) - exclude from income totals
    """
    now = _utcnow_iso()
    merchant = merchant_pattern.lower().strip()
    rule_type = "income" if is_income else "not_income"

    # Remove any existing rule for this merchant (both income and not_income)
    conn.execute(
        "DELETE FROM merchant_rules WHERE merchant_pattern = ? AND rule_type IN ('income', 'not_income')",
        (merchant,),
    )

    # Add the new rule
    conn.execute(
        """
        INSERT INTO merchant_rules(merchant_pattern, rule_type, created_at)
        VALUES (?, ?, ?)
        """,
        (merchant, rule_type, now),
    )
    conn.commit()


def get_income_rules(conn: sqlite3.Connection) -> tuple[set[str], set[str]]:
    """
    Get merchant rules for income classification.

    Returns: (income_sources, excluded_sources)
    - income_sources: merchants explicitly marked as income
    - excluded_sources: merchants explicitly marked as NOT income (transfers, refunds)
    """
    rows = conn.execute(
        "SELECT merchant_pattern, rule_type FROM merchant_rules WHERE rule_type IN ('income', 'not_income')"
    ).fetchall()

    income_sources = set()
    excluded_sources = set()

    for r in rows:
        if r["rule_type"] == "income":
            income_sources.add(r["merchant_pattern"])
        else:
            excluded_sources.add(r["merchant_pattern"])

    return income_sources, excluded_sources


def get_income_sources(conn: sqlite3.Connection) -> set[str]:
    """Get set of merchant patterns marked as income sources."""
    income, _ = get_income_rules(conn)
    return income


def learn_from_alert_action(
    conn: sqlite3.Connection,
    merchant_norm: str,
    pattern_type: str,
    action: str,
) -> None:
    """
    Learn from user's alert action.

    When user dismisses alerts multiple times, create a rule to suppress similar future alerts.
    - not_suspicious: trust this pattern for this merchant
    - confirmed: flag this merchant as suspicious
    """
    now = _utcnow_iso()

    # Count how many times user dismissed this pattern for this merchant
    count_result = conn.execute(
        """
        SELECT COUNT(*) as cnt FROM alert_actions
        WHERE merchant_norm = ? AND pattern_type = ? AND action = 'not_suspicious'
        """,
        (merchant_norm, pattern_type),
    ).fetchone()

    dismiss_count = count_result["cnt"] if count_result else 0

    # After 2+ dismissals of same pattern type for same merchant, auto-trust
    if action == "not_suspicious" and dismiss_count >= 1:
        # Create rule to suppress this pattern type for this merchant
        rule_type = f"trust_{pattern_type}"
        conn.execute(
            """
            INSERT OR REPLACE INTO merchant_rules(merchant_pattern, rule_type, created_at)
            VALUES (?, ?, ?)
            """,
            (merchant_norm, rule_type, now),
        )
        conn.commit()


def get_suppressed_patterns(conn: sqlite3.Connection) -> dict[str, set[str]]:
    """
    Get patterns to suppress per merchant.

    Returns: dict mapping merchant_norm -> set of suppressed pattern_types
    """
    rows = conn.execute(
        """
        SELECT merchant_pattern, rule_type FROM merchant_rules
        WHERE rule_type LIKE 'trust_%'
        """
    ).fetchall()

    suppressed: dict[str, set[str]] = {}
    for r in rows:
        merchant = r["merchant_pattern"]
        pattern_type = r["rule_type"].replace("trust_", "")
        if merchant not in suppressed:
            suppressed[merchant] = set()
        suppressed[merchant].add(pattern_type)

    return suppressed


def get_trusted_merchants(conn: sqlite3.Connection) -> set[str]:
    """
    Get merchants that are fully trusted (all alert types suppressed).
    """
    rows = conn.execute(
        "SELECT merchant_pattern FROM merchant_rules WHERE rule_type = 'trust'"
    ).fetchall()
    return {r["merchant_pattern"] for r in rows}


def set_recurring_type_override(
    conn: sqlite3.Connection,
    merchant_norm: str,
    override_type: str,
) -> None:
    """
    Set manual type override for a recurring charge.

    override_type:
      - "subscription": Force as subscription
      - "bill": Force as bill
      - "ignore": Dismiss from recurring lists entirely
      - "auto": Remove override, let ML decide
    """
    now = _utcnow_iso()
    merchant = merchant_norm.lower().strip()

    if override_type == "auto":
        # Remove override - let ML decide
        conn.execute(
            "DELETE FROM recurring_type_overrides WHERE merchant_norm = ?",
            (merchant,),
        )
    else:
        conn.execute(
            """
            INSERT INTO recurring_type_overrides(merchant_norm, override_type, created_at, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(merchant_norm) DO UPDATE SET
              override_type=excluded.override_type,
              updated_at=excluded.updated_at
            """,
            (merchant, override_type, now, now),
        )
    conn.commit()


def get_recurring_type_overrides(conn: sqlite3.Connection) -> dict[str, str]:
    """
    Get all manual type overrides for recurring charges.

    Returns: dict mapping merchant_norm -> override_type ("subscription" or "bill")
    """
    rows = conn.execute(
        "SELECT merchant_norm, override_type FROM recurring_type_overrides"
    ).fetchall()
    return {r["merchant_norm"]: r["override_type"] for r in rows}


def set_category_override(
    conn: sqlite3.Connection,
    merchant_norm: str,
    category_id: str,
) -> None:
    """
    Set manual category override for a merchant.

    category_id: Category ID like "healthcare", "shopping", etc. Use "auto" to remove override.
    """
    now = _utcnow_iso()
    merchant = merchant_norm.lower().strip()

    if category_id == "auto":
        # Remove override - let ML decide
        conn.execute(
            "DELETE FROM category_overrides WHERE merchant_norm = ?",
            (merchant,),
        )
    else:
        conn.execute(
            """
            INSERT INTO category_overrides(merchant_norm, category_id, created_at, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(merchant_norm) DO UPDATE SET
              category_id=excluded.category_id,
              updated_at=excluded.updated_at
            """,
            (merchant, category_id, now, now),
        )
    conn.commit()


def get_category_overrides(conn: sqlite3.Connection) -> dict[str, str]:
    """
    Get all manual category overrides.

    Returns: dict mapping merchant_norm -> category_id
    """
    rows = conn.execute(
        "SELECT merchant_norm, category_id FROM category_overrides"
    ).fetchall()
    return {r["merchant_norm"]: r["category_id"] for r in rows}


def get_budget_targets(conn: sqlite3.Connection) -> dict[str, int]:
    """Get all budget targets. Returns dict mapping category_id -> monthly_target_cents."""
    rows = conn.execute("SELECT category_id, monthly_target_cents FROM budget_targets").fetchall()
    return {r["category_id"]: r["monthly_target_cents"] for r in rows}


def set_budget_target(conn: sqlite3.Connection, category_id: str, monthly_target_cents: int) -> None:
    """Set or update a budget target for a category."""
    now = _utcnow_iso()
    conn.execute(
        """
        INSERT INTO budget_targets(category_id, monthly_target_cents, created_at, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(category_id) DO UPDATE SET
            monthly_target_cents = excluded.monthly_target_cents,
            updated_at = excluded.updated_at
        """,
        (category_id, monthly_target_cents, now, now),
    )
    conn.commit()


def delete_budget_target(conn: sqlite3.Connection, category_id: str) -> None:
    """Remove a budget target."""
    conn.execute("DELETE FROM budget_targets WHERE category_id = ?", (category_id,))
    conn.commit()


def get_transaction_note(conn: sqlite3.Connection, fingerprint: str) -> str | None:
    """Get the note for a transaction, or None if no note exists."""
    row = conn.execute(
        "SELECT note FROM transaction_notes WHERE fingerprint = ?", (fingerprint,)
    ).fetchone()
    return row["note"] if row else None


def set_transaction_note(conn: sqlite3.Connection, fingerprint: str, note: str) -> None:
    """Set or update a note on a transaction."""
    now = _utcnow_iso()
    conn.execute(
        """
        INSERT INTO transaction_notes(fingerprint, note, created_at, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(fingerprint) DO UPDATE SET
            note = excluded.note,
            updated_at = excluded.updated_at
        """,
        (fingerprint, note, now, now),
    )
    conn.commit()


def delete_transaction_note(conn: sqlite3.Connection, fingerprint: str) -> None:
    """Remove a note from a transaction."""
    conn.execute("DELETE FROM transaction_notes WHERE fingerprint = ?", (fingerprint,))
    conn.commit()


def get_transaction_tags(conn: sqlite3.Connection, fingerprint: str) -> list[str]:
    """Get all tags for a transaction."""
    rows = conn.execute(
        "SELECT tag FROM transaction_tags WHERE fingerprint = ? ORDER BY tag",
        (fingerprint,),
    ).fetchall()
    return [r["tag"] for r in rows]


def add_transaction_tag(conn: sqlite3.Connection, fingerprint: str, tag: str) -> None:
    """Add a tag to a transaction."""
    now = _utcnow_iso()
    conn.execute(
        """
        INSERT INTO transaction_tags(fingerprint, tag, created_at)
        VALUES (?, ?, ?)
        ON CONFLICT(fingerprint, tag) DO NOTHING
        """,
        (fingerprint, tag, now),
    )
    conn.commit()


def remove_transaction_tag(conn: sqlite3.Connection, fingerprint: str, tag: str) -> None:
    """Remove a tag from a transaction."""
    conn.execute(
        "DELETE FROM transaction_tags WHERE fingerprint = ? AND tag = ?",
        (fingerprint, tag),
    )
    conn.commit()


def get_all_tags(conn: sqlite3.Connection) -> list[str]:
    """Get all distinct tags used across transactions."""
    rows = conn.execute(
        "SELECT DISTINCT tag FROM transaction_tags ORDER BY tag"
    ).fetchall()
    return [r["tag"] for r in rows]


def get_notes_and_tags_bulk(
    conn: sqlite3.Connection, fingerprints: list[str]
) -> dict[str, dict]:
    """
    Bulk-load notes and tags for a list of fingerprints.
    Returns dict mapping fingerprint -> {"note": str|None, "tags": list[str]}
    """
    if not fingerprints:
        return {}

    placeholders = ",".join("?" for _ in fingerprints)

    notes = {}
    rows = conn.execute(
        f"SELECT fingerprint, note FROM transaction_notes WHERE fingerprint IN ({placeholders})",
        fingerprints,
    ).fetchall()
    for r in rows:
        notes[r["fingerprint"]] = r["note"]

    tags: dict[str, list[str]] = {}
    rows = conn.execute(
        f"SELECT fingerprint, tag FROM transaction_tags WHERE fingerprint IN ({placeholders}) ORDER BY tag",
        fingerprints,
    ).fetchall()
    for r in rows:
        tags.setdefault(r["fingerprint"], []).append(r["tag"])

    result = {}
    for fp in fingerprints:
        result[fp] = {
            "note": notes.get(fp),
            "tags": tags.get(fp, []),
        }
    return result


def dismiss_duplicate(conn: sqlite3.Connection, merchant_norm: str) -> None:
    """
    Dismiss duplicate warning for a merchant.
    """
    now = _utcnow_iso()
    merchant = merchant_norm.lower().strip()
    conn.execute(
        """
        INSERT INTO merchant_rules(merchant_pattern, rule_type, created_at)
        VALUES (?, 'ignore_duplicates', ?)
        ON CONFLICT(merchant_pattern, rule_type) DO NOTHING
        """,
        (merchant, now),
    )
    conn.commit()


def undismiss_duplicate(conn: sqlite3.Connection, merchant_norm: str) -> None:
    """
    Remove duplicate dismissal for a merchant.
    """
    merchant = merchant_norm.lower().strip()
    conn.execute(
        "DELETE FROM merchant_rules WHERE merchant_pattern = ? AND rule_type = 'ignore_duplicates'",
        (merchant,),
    )
    conn.commit()


def get_dismissed_duplicates(conn: sqlite3.Connection) -> set[str]:
    """
    Get all merchants with dismissed duplicate warnings.
    """
    rows = conn.execute(
        "SELECT merchant_pattern FROM merchant_rules WHERE rule_type = 'ignore_duplicates'"
    ).fetchall()
    return {r["merchant_pattern"] for r in rows}


# ---------------------------------------------------------------------------
# Transaction Type Overrides
# ---------------------------------------------------------------------------
# Valid transaction types (from reporting_models.TransactionType)
VALID_TXN_TYPES = frozenset(["INCOME", "EXPENSE", "TRANSFER", "REFUND", "CREDIT_OTHER"])


def set_txn_type_override_fingerprint(
    conn: sqlite3.Connection,
    fingerprint: str,
    target_type: str,
    reason: str | None = None,
    *,
    commit: bool = True,
) -> None:
    """
    Set transaction type override for a specific transaction by fingerprint.

    Args:
        fingerprint: Transaction fingerprint
        target_type: One of INCOME, EXPENSE, TRANSFER, REFUND, CREDIT_OTHER
        reason: Optional user note
        commit: Whether to commit immediately (set False for batch operations)
    """
    if target_type not in VALID_TXN_TYPES:
        raise ValueError(f"Invalid target_type: {target_type}. Must be one of {VALID_TXN_TYPES}")

    now = _utcnow_iso()
    conn.execute(
        """
        INSERT INTO txn_type_overrides(fingerprint, merchant_pattern, target_type, reason, created_at, updated_at)
        VALUES (?, NULL, ?, ?, ?, ?)
        ON CONFLICT(fingerprint) DO UPDATE SET
          target_type=excluded.target_type,
          reason=excluded.reason,
          updated_at=excluded.updated_at
        """,
        (fingerprint, target_type, reason, now, now),
    )
    if commit:
        conn.commit()


def set_txn_type_override_merchant(
    conn: sqlite3.Connection,
    merchant_pattern: str,
    target_type: str,
    reason: str | None = None,
) -> None:
    """
    Set transaction type override for all transactions matching merchant pattern.

    Args:
        merchant_pattern: Merchant substring to match
        target_type: One of INCOME, EXPENSE, TRANSFER, REFUND, CREDIT_OTHER
        reason: Optional user note
    """
    if target_type not in VALID_TXN_TYPES:
        raise ValueError(f"Invalid target_type: {target_type}. Must be one of {VALID_TXN_TYPES}")

    now = _utcnow_iso()
    pattern = merchant_pattern.lower().strip()
    conn.execute(
        """
        INSERT INTO txn_type_overrides(fingerprint, merchant_pattern, target_type, reason, created_at, updated_at)
        VALUES (NULL, ?, ?, ?, ?, ?)
        ON CONFLICT(merchant_pattern) DO UPDATE SET
          target_type=excluded.target_type,
          reason=excluded.reason,
          updated_at=excluded.updated_at
        """,
        (pattern, target_type, reason, now, now),
    )
    conn.commit()


def remove_txn_type_override(
    conn: sqlite3.Connection,
    fingerprint: str | None = None,
    merchant_pattern: str | None = None,
) -> None:
    """
    Remove a transaction type override.

    Specify either fingerprint OR merchant_pattern, not both.
    """
    if fingerprint and merchant_pattern:
        raise ValueError("Specify either fingerprint or merchant_pattern, not both")

    if fingerprint:
        conn.execute(
            "DELETE FROM txn_type_overrides WHERE fingerprint = ?",
            (fingerprint,),
        )
    elif merchant_pattern:
        pattern = merchant_pattern.lower().strip()
        conn.execute(
            "DELETE FROM txn_type_overrides WHERE merchant_pattern = ?",
            (pattern,),
        )
    conn.commit()


def get_txn_type_overrides(
    conn: sqlite3.Connection,
) -> tuple[dict[str, str], dict[str, str]]:
    """
    Get all transaction type overrides.

    Returns:
        Tuple of (fingerprint_overrides, merchant_overrides)
        Each is a dict mapping fingerprint/pattern -> target_type
    """
    rows = conn.execute(
        "SELECT fingerprint, merchant_pattern, target_type FROM txn_type_overrides"
    ).fetchall()

    fp_overrides: dict[str, str] = {}
    merchant_overrides: dict[str, str] = {}

    for row in rows:
        if row["fingerprint"]:
            fp_overrides[row["fingerprint"]] = row["target_type"]
        elif row["merchant_pattern"]:
            merchant_overrides[row["merchant_pattern"]] = row["target_type"]

    return fp_overrides, merchant_overrides


def get_txn_type_override(
    conn: sqlite3.Connection,
    fingerprint: str,
    merchant_norm: str,
) -> str | None:
    """
    Get the effective transaction type override for a transaction.

    Checks fingerprint first, then merchant patterns.

    Returns:
        Target type string, or None if no override
    """
    # Check fingerprint override first
    row = conn.execute(
        "SELECT target_type FROM txn_type_overrides WHERE fingerprint = ?",
        (fingerprint,),
    ).fetchone()
    if row:
        return row["target_type"]

    # Check merchant patterns
    rows = conn.execute(
        "SELECT merchant_pattern, target_type FROM txn_type_overrides WHERE merchant_pattern IS NOT NULL"
    ).fetchall()

    for row in rows:
        if row["merchant_pattern"] in merchant_norm:
            return row["target_type"]

    return None



# ---------------------------------------------------------------------------
# Commitments
# ---------------------------------------------------------------------------

VALID_CADENCES = frozenset({"monthly", "weekly", "annual", "quarterly", "biweekly", "one_time"})
VALID_SOURCES = frozenset({"detected", "manual", "dismissed"})
VALID_DIRECTIONS = frozenset({"expense", "income"})


def get_commitments(
    conn: sqlite3.Connection,
    confirmed_only: bool = False,
    include_dismissed: bool = False,
    direction: str | None = None,
) -> list[dict]:
    """
    Get commitments as a list of dicts.

    Args:
        conn: Database connection
        confirmed_only: If True, return only confirmed=1 rows
        include_dismissed: If True, include source='dismissed' rows. Otherwise exclude them.
        direction: If set, filter by direction (expense or income). Otherwise return all.

    Returns:
        List of commitment dicts, ordered by confirmed DESC then name ASC
    """
    clauses = []
    params = []
    if not include_dismissed:
        clauses.append("source != 'dismissed'")
    if confirmed_only:
        clauses.append("confirmed = 1")
    if direction is not None:
        clauses.append("direction = ?")
        params.append(direction)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    try:
        rows = conn.execute(
            f"SELECT * FROM commitments {where} ORDER BY confirmed DESC, name ASC",
            params
        ).fetchall()
    except Exception:
        return []
    return [dict(row) for row in rows]


def upsert_commitment(
    conn: sqlite3.Connection,
    name: str,
    cadence: str = "monthly",
    commitment_id: int | None = None,
    merchant_norm: str | None = None,
    expected_cents: int | None = None,
    day_of_month: int | None = None,
    reference_date: str | None = None,
    confirmed: int = 0,
    source: str = "detected",
    direction: str = "expense",
) -> int:
    """
    Insert or update a commitment.

    If commitment_id is provided and exists, updates that row. Otherwise inserts a new row.

    Args:
        conn: Database connection
        name: Commitment name
        cadence: Recurring frequency (monthly, weekly, annual, quarterly, biweekly, one_time)
        commitment_id: If provided, update this row. If None, insert new.
        merchant_norm: Normalized merchant name (optional)
        expected_cents: Expected amount in cents (optional)
        day_of_month: Expected day of month (optional, 1-31)
        reference_date: Anchor date as YYYY-MM-DD (optional, for non-monthly cadences)
        confirmed: 0=suggestion, 1=user-confirmed
        source: "detected", "manual", or "dismissed"
        direction: "expense" or "income"

    Returns:
        The commitment_id of the inserted or updated commitment
    """
    now = _utcnow_iso()
    if commitment_id is not None:
        cur = conn.execute(
            """
            UPDATE commitments
            SET name=?, merchant_norm=?, expected_cents=?, cadence=?,
                day_of_month=?, reference_date=?, confirmed=?, source=?,
                direction=?, updated_at=?
            WHERE id=?
            """,
            (name, merchant_norm, expected_cents, cadence,
             day_of_month, reference_date, confirmed, source, direction, now, commitment_id),
        )
        if cur.rowcount == 0:
            raise ValueError(f"Commitment id={commitment_id} not found")
        conn.commit()
        return commitment_id
    cur = conn.execute(
        """
        INSERT INTO commitments
          (name, merchant_norm, expected_cents, cadence, day_of_month,
           reference_date, confirmed, source, direction, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (name, merchant_norm, expected_cents, cadence, day_of_month,
         reference_date, confirmed, source, direction, now, now),
    )
    conn.commit()
    return cur.lastrowid


def delete_commitment(conn: sqlite3.Connection, commitment_id: int) -> None:
    """
    Hard-delete a commitment by commitment_id.

    Args:
        conn: Database connection
        commitment_id: Commitment id to delete
    """
    conn.execute("DELETE FROM commitments WHERE id=?", (commitment_id,))
    conn.commit()



def find_matching_transactions(
    conn: sqlite3.Connection,
    merchant_norm: str,
    day_of_month: int | None,
    cadence: str,  # Reserved for future cadence-dependent matching logic (e.g., weekly ±7 days)
    expected_cents: int | None,
    source: str = "detected",
    direction: str = "expense",
) -> list[dict]:
    """Find transactions matching a commitment's criteria.

    Applies matching rule:
    1. merchant_norm match (case-insensitive), sign matches direction
    2. Amount in [0.5×anchor, 1.5×anchor]
    3. ≥4 distinct calendar months (skipped for source='manual')
    4. day_of_month ±3 with month-end clamping (skipped if day_of_month is None)

    Returns empty list if any non-skipped condition fails.

    Args:
        direction: "expense" (amount_cents < 0) or "income" (amount_cents > 0)
    """

    sign_filter = "AND amount_cents < 0" if direction == "expense" else "AND amount_cents > 0"
    rows = conn.execute(
        f"""
        SELECT posted_at, amount_cents, merchant, fingerprint
        FROM transactions
        WHERE LOWER(merchant) = LOWER(?)
          {sign_filter}
        ORDER BY posted_at DESC
        """,
        (merchant_norm,),
    ).fetchall()

    if not rows:
        return []

    # Determine anchor for amount range
    if expected_cents is not None:
        anchor = expected_cents
    else:
        recent_amounts = sorted(abs(r["amount_cents"]) for r in rows[:3])
        if not recent_amounts:
            return []
        anchor = recent_amounts[len(recent_amounts) // 2]

    anchor = abs(anchor)
    lo = int(anchor * 0.5)
    hi = int(anchor * 1.5)

    amount_matches = [r for r in rows if lo <= abs(r["amount_cents"]) <= hi]
    if not amount_matches:
        return []

    # Filter by day_of_month ±3 if set
    if day_of_month is not None:
        day_matches = []
        for r in amount_matches:
            txn_date = date.fromisoformat(r["posted_at"][:10])
            _, last_day = calendar.monthrange(txn_date.year, txn_date.month)
            anchor_day = min(day_of_month, last_day)
            if abs(txn_date.day - anchor_day) <= 3:
                day_matches.append(r)
    else:
        day_matches = amount_matches

    # Check ≥4 distinct calendar months (skipped for manual)
    if source != "manual":
        months_seen = set()
        for r in day_matches:
            txn_date = date.fromisoformat(r["posted_at"][:10])
            months_seen.add((txn_date.year, txn_date.month))
        if len(months_seen) < 4:
            return []
    # distinct-month check runs on day-filtered results; months where the charge
    # landed outside the ±3-day window are not counted, by design

    return [dict(r) for r in day_matches]



def suggest_commitments_from_heuristics(conn: sqlite3.Connection) -> None:
    """Seed unconfirmed commitment suggestions from heuristic detection.

    Reads get_subscriptions() and get_bills() from legacy_classify for expenses.
    Also seeds income suggestions from merchant_rules (rule_type='income') and
    payroll keyword fallback.

    Inserts unconfirmed rows idempotently — never duplicates, never
    overwrites confirmed entries.

    Dedup key: same merchant_norm (case-insensitive), direction, and source != 'dismissed'.
    """
    from .legacy_classify import get_subscriptions, get_bills
    import statistics

    now = _utcnow_iso()

    # Process subscriptions (10-tuple)
    for sub in get_subscriptions(conn, days=400):
        merchant, monthly_cents, cadence, first_seen, last_seen, \
            is_dup, txn_type, is_known, display_name, actual_cents = sub

        name = display_name or merchant
        merchant_norm = merchant
        expected_cents = actual_cents

        _seed_commitment_if_new(
            conn, name=name, merchant_norm=merchant_norm,
            expected_cents=expected_cents, cadence=cadence, now=now,
            direction="expense",
        )

    # Process bills (6-tuple)
    for bill in get_bills(conn, days=400):
        merchant, monthly_cents, cadence, first_seen, last_seen, txn_type = bill

        _seed_commitment_if_new(
            conn, name=merchant, merchant_norm=merchant,
            expected_cents=monthly_cents, cadence=cadence, now=now,
            direction="expense",
        )

    # ── Income pass ──────────────────────────────────────────────────────────
    # Fetch all positive transactions to scan for income patterns
    all_positive = conn.execute(
        "SELECT merchant, amount_cents, posted_at FROM transactions WHERE amount_cents > 0"
    ).fetchall()

    income_merchants = get_income_sources(conn)

    # Determine which rows to consider for income seeding
    PAYROLL_KEYWORDS = {"payroll", "direct deposit", "paycheck", "salary"}

    def _is_income_candidate(merchant_lower: str) -> bool:
        if income_merchants:
            return any(pat in merchant_lower for pat in income_merchants)
        # Fallback: keyword matching when no explicit income sources configured
        return any(kw in merchant_lower for kw in PAYROLL_KEYWORDS)

    # Group positive txns by normalised merchant
    merchant_txns: dict[str, list[dict]] = {}
    for row in all_positive:
        if not row["merchant"]:
            continue
        norm = row["merchant"].lower().strip()
        if _is_income_candidate(norm):
            merchant_txns.setdefault(norm, []).append(dict(row))

    for merchant_norm, txns in merchant_txns.items():
        # Need ≥2 distinct calendar months
        months_seen = set()
        for t in txns:
            d = t["posted_at"][:7]  # YYYY-MM
            months_seen.add(d)
        if len(months_seen) < 2:
            continue

        # Infer cadence from median gap between consecutive deposits
        dates_sorted = sorted(t["posted_at"][:10] for t in txns)
        if len(dates_sorted) >= 2:
            from datetime import date as _date
            date_objs = [_date.fromisoformat(d) for d in dates_sorted]
            gaps = [(date_objs[i + 1] - date_objs[i]).days for i in range(len(date_objs) - 1)]
            median_gap = statistics.median(gaps)
            if 5 <= median_gap <= 10:
                cadence = "weekly"
            elif 11 <= median_gap <= 18:
                cadence = "biweekly"
            elif 19 <= median_gap <= 35:
                cadence = "monthly"
            elif 80 <= median_gap <= 100:
                cadence = "quarterly"
            else:
                cadence = "monthly"
        else:
            cadence = "monthly"

        # Compute median expected amount
        amounts = [t["amount_cents"] for t in txns]
        median_cents = int(statistics.median(amounts))

        _seed_commitment_if_new(
            conn,
            name=merchant_norm,
            merchant_norm=merchant_norm,
            expected_cents=median_cents,
            cadence=cadence,
            now=now,
            direction="income",
        )

    conn.commit()


def _seed_commitment_if_new(
    conn: sqlite3.Connection,
    name: str,
    merchant_norm: str,
    expected_cents: int | None,
    cadence: str,
    now: str,
    direction: str = "expense",
) -> None:
    """Insert a single unconfirmed suggestion if no non-dismissed row exists for this merchant+direction."""
    if not merchant_norm:
        return

    existing = conn.execute(
        """
        SELECT id, confirmed FROM commitments
        WHERE LOWER(merchant_norm) = LOWER(?)
          AND direction = ?
        """,
        (merchant_norm, direction),
    ).fetchone()

    if existing is not None:
        return  # Already exists (confirmed, unconfirmed, or dismissed) for this direction

    cur = conn.execute(
        """
        INSERT INTO commitments
          (name, merchant_norm, expected_cents, cadence, confirmed, source,
           direction, created_at, updated_at)
        VALUES (?, ?, ?, ?, 0, 'detected', ?, ?, ?)
        """,
        (name, merchant_norm, expected_cents, cadence, direction, now, now),
    )
    new_id = cur.lastrowid

    # Populate reference_date from most recent matching transaction
    ref_row = conn.execute(
        """
        SELECT DATE(posted_at) AS ref_date
        FROM transactions
        WHERE LOWER(merchant) = LOWER(?)
        ORDER BY posted_at DESC
        LIMIT 1
        """,
        (merchant_norm,),
    ).fetchone()

    if ref_row and ref_row["ref_date"]:
        conn.execute(
            "UPDATE commitments SET reference_date=? WHERE id=?",
            (ref_row["ref_date"], new_id),
        )
