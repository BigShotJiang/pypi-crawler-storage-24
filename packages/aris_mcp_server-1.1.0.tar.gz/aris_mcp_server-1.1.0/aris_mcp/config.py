"""Configuration for ARIS MCP Server."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Server settings loaded from environment."""

    supabase_url: str = ""
    supabase_key: str = ""
    stripe_secret_key: str = ""
    jwt_secret: str = "aris-dev-secret-change-in-prod"
    server_host: str = "0.0.0.0"
    server_port: int = 8400
    skills_dir: str = "./skills"
    debug: bool = False

    model_config = {"env_prefix": "ARIS_"}


settings = Settings()
