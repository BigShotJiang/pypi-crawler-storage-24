"""ARIS MCP License Server — serves premium skills dynamically."""
__version__ = "0.1.0"
