"""Allow running as: python -m aris_mcp.server"""
from .server import main
main()
