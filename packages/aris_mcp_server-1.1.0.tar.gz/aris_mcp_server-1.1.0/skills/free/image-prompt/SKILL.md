---
name: image-prompt
description: "Generate optimized prompts for AI image generation. Structured JSON with style, lighting, composition, and technical details."
version: 1.0.0
category: dev
tags: [image, prompt, ai-art, generation, visual]
tier: free
---

# Image Prompt Generator

Create optimized prompts for AI image generation.

## When to trigger
- User says `/image-prompt`, "generate image prompt", "create visual", "image for"

## Output Format
```json
{
  "prompt": "main description",
  "style": "photorealistic | illustration | 3d-render | pixel-art | watercolor",
  "lighting": "natural | studio | dramatic | neon | golden-hour",
  "composition": "close-up | wide-shot | overhead | isometric",
  "color_palette": ["#hex1", "#hex2", "#hex3"],
  "aspect_ratio": "1:1 | 16:9 | 9:16 | 4:3",
  "negative_prompt": "things to avoid",
  "technical": "8k, detailed, sharp focus"
}
```

## Best Practices
- Be specific about subject, environment, mood
- Include technical quality terms
- Specify what to AVOID in negative prompt
- Match style to use case (app icons = clean/flat, marketing = photorealistic)
- For consistent branding, include ARIS colors: indigo #818cf8, cyan #22d3ee
