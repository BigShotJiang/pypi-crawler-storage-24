---
name: aris-setup
description: Interactive ARIS setup wizard. Detects hardware, configures workers, generates CLAUDE.md, connects API keys.
version: 1.0.0
category: aris
tags: [setup, init, onboarding, wizard]
---

# ARIS Setup Wizard

Run this skill to configure ARIS for your environment.

## What it does

1. **Detect Hardware**: Scans your machine and any SSH-accessible workers
2. **Configure Cluster**: Sets up aris.config.yaml with your nodes
3. **Generate CLAUDE.md**: Creates an optimized CLAUDE.md for your setup
4. **Connect AI Models**: Configures API keys for Claude, GPT, Gemini, Grok
5. **Activate License**: Validates your ARIS license key (if Pro/Team)
6. **Run Health Check**: Verifies everything is working

## Instructions

When the user runs `/aris-setup` or asks to set up ARIS:

### Step 1: Detect Environment
```bash
# Check local machine
echo "OS: $(uname -s) $(uname -m)"
echo "CPU: $(nproc 2>/dev/null || sysctl -n hw.ncpu) cores"
echo "RAM: $(free -h 2>/dev/null | awk '/Mem:/{print $2}' || sysctl -n hw.memsize | awk '{print $1/1073741824 "G"}')"
echo "GPU: $(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>/dev/null || echo 'None detected')"
```

### Step 2: Check for Workers
Ask the user: "Do you have remote servers you want ARIS to use as workers?"

If yes, for each worker:
- Test SSH connectivity: `ssh -o ConnectTimeout=5 <host> 'echo ok'`
- Detect hardware on worker
- Add to aris.config.yaml

### Step 3: Generate aris.config.yaml
```yaml
# aris.config.yaml — ARIS Cluster Configuration
version: "1.0"

local:
  role: orchestrator  # or worker if powerful enough
  max_concurrent: 2

workers: []
  # - name: gpu-server
  #   ssh: user@gpu-server.local
  #   role: ai
  #   gpu: true
  #   max_concurrent: 4

models:
  claude:
    enabled: true  # Always true for Claude Code users
  gpt:
    enabled: false
    api_key_env: OPENAI_API_KEY
  gemini:
    enabled: false
    api_key_env: GEMINI_API_KEY
  grok:
    enabled: false
    api_key_env: GROK_API_KEY
  ollama:
    enabled: false
    host: ""  # e.g., http://gpu-server:11434

routing:
  strategy: auto  # auto, manual, cost-optimized, quality-first
  privacy_mode: false  # true = sensitive data only to local models

license:
  key_env: ARIS_LICENSE_KEY
```

### Step 4: Generate CLAUDE.md
Create a CLAUDE.md optimized for the user's setup with:
- Cluster info (if workers configured)
- Dispatch rules (which tasks go where)
- Active model configuration
- ARIS skill activation rules

### Step 5: Verify
Run `aris-status` to confirm everything works.

Print a summary:
```
ARIS Setup Complete!
├── Nodes: 1 local + N workers
├── Models: Claude + [others]
├── Skills: 10 free (upgrade for 66+)
├── Router: [active/inactive]
└── License: [Free/Pro/Team]
```
