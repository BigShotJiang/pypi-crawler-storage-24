---
name: xlsx-toolkit
description: "Excel/CSV automation with AI. Create, edit, analyze spreadsheets. Handle formulas, formatting, and data insights."
version: 1.0.0
category: dev
tags: [excel, csv, spreadsheet, data, analysis]
tier: free
---

# XLSX Toolkit

Complete spreadsheet automation with AI analysis.

## When to trigger
- User says `/xlsx-toolkit`, "create spreadsheet", "analyze CSV", "excel"

## Capabilities
1. **Create** — Generate xlsx/csv from data or descriptions
2. **Read** — Parse and summarize spreadsheet contents
3. **Edit** — Add columns, formulas, formatting
4. **Analyze** — Statistical analysis, trends, outliers
5. **Visualize** — Describe chart recommendations

## Instructions
- Use openpyxl (Python) or SheetJS (Node) for file operations
- Always validate data types before operations
- Handle merged cells, multi-sheet workbooks
- Preserve existing formatting when editing
- For large files (>10K rows), use streaming/chunked processing
