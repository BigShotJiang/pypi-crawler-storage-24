---
name: prd-generator
description: "Generate Product Requirement Documents from ideas. Converts rough concepts into structured, executable documentation."
version: 1.0.0
category: biz
tags: [prd, product, requirements, documentation, planning]
tier: free
---

# PRD Generator

Convert ideas into structured Product Requirement Documents.

## When to trigger
- User says `/prd-generator`, "write PRD", "product requirements", "spec this out"

## Output Structure

### 1. Overview
- Product name, one-liner, target audience
- Problem statement (what pain does this solve?)
- Success metrics (how do we know it works?)

### 2. User Stories
```
As a [role], I want to [action], so that [benefit]
```
- P0 (must have), P1 (should have), P2 (nice to have)

### 3. Functional Requirements
- Feature breakdown with acceptance criteria
- API contracts (if applicable)
- Data model (entities and relationships)

### 4. Non-Functional Requirements
- Performance targets
- Security requirements
- Scalability considerations
- Accessibility standards

### 5. Technical Architecture
- System diagram
- Tech stack recommendation
- Integration points
- Migration plan (if replacing existing system)

### 6. Timeline
- Phase breakdown with milestones
- MVP scope vs full scope
- Dependencies and risks

### 7. Open Questions
- Decisions that need stakeholder input
- Technical unknowns to investigate
