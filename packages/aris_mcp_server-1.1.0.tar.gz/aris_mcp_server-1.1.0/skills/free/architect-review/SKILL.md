---
name: architect-review
description: "Architecture stress-test and design analysis. Evaluates backend, API contracts, scalability risks, security gaps like a senior staff engineer."
version: 1.0.0
category: dev
tags: [architecture, design, scalability, security-review]
tier: free
---

# Architect Review

Stress-test system architecture as a senior staff engineer.

## When to trigger
- User says `/architect-review`, "review architecture", "stress test design"
- When designing new systems or evaluating technical proposals

## Instructions

### Step 1: Understand the System
- Read project structure, key files, config
- Identify: language, framework, database, external services
- Map the data flow: input → processing → storage → output

### Step 2: Evaluate 6 Dimensions

#### 2.1 API Design
- RESTful conventions respected?
- Consistent error responses?
- Versioning strategy?
- Rate limiting?
- Input validation at boundary?

#### 2.2 Data Architecture
- Schema normalization appropriate?
- Indexes on query patterns?
- Migration strategy safe?
- Backup/recovery plan?
- Data retention policy?

#### 2.3 Security
- Authentication mechanism solid?
- Authorization (RBAC/ABAC) in place?
- Secrets management (env vars, not hardcoded)?
- OWASP Top 10 covered?
- Audit logging?

#### 2.4 Scalability
- Horizontal scaling possible?
- Stateless services?
- Caching strategy?
- Database connection pooling?
- Async processing for heavy tasks?

#### 2.5 Reliability
- Health checks?
- Circuit breakers?
- Retry logic with backoff?
- Graceful degradation?
- Monitoring and alerting?

#### 2.6 Maintainability
- Clear separation of concerns?
- Dependency injection?
- Test coverage adequate?
- Documentation up to date?
- CI/CD pipeline?

### Step 3: Output
```
## Architecture Review

### Risk Level: [LOW|MEDIUM|HIGH|CRITICAL]

### Strengths
- ...

### Critical Risks
- [Risk]: Description + Impact + Recommendation

### Improvement Roadmap
1. Immediate (this week): ...
2. Short-term (this month): ...
3. Long-term (this quarter): ...

### Score: X/10
```
