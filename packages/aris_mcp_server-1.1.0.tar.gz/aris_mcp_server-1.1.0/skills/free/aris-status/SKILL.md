---
name: aris-status
description: ARIS health check — shows cluster status, active skills, model availability, and system health.
version: 1.0.0
category: aris
tags: [status, health, dashboard, monitoring]
---

# ARIS Status

Quick health check of your ARIS installation.

## When to trigger
- User says `/aris-status`, "aris status", "is aris working", "check aris"

## Instructions

1. Read `aris.config.yaml` from project root or `~/.config/aris/`
2. Check each component:

### Cluster Health
- For each worker: `ssh -o ConnectTimeout=3 <host> 'uptime && free -h | head -2'`
- Local: CPU/RAM usage

### Model Availability
- Claude: always available (Claude Code)
- GPT: check OPENAI_API_KEY env var
- Gemini: check GEMINI_API_KEY env var
- Grok: check GROK_API_KEY env var
- Ollama: check connectivity to configured host

### Skills Status
- Count installed skills
- Check MCP server connectivity (if Pro)
- List recently used skills

### Output Format
```
╔══════════════════════════════════════╗
║          ARIS Status v0.1.0          ║
╠══════════════════════════════════════╣
║ Cluster                              ║
║  Local:    ✓ 8 cores, 16GB RAM       ║
║  Worker1:  ✓ 16 cores, 32GB, GPU     ║
║  Worker2:  ✗ Unreachable             ║
╠══════════════════════════════════════╣
║ Models                               ║
║  Claude:   ✓ Active                  ║
║  GPT:      ✓ API key found           ║
║  Gemini:   ✗ No API key              ║
║  Grok:     ✓ API key found           ║
║  Ollama:   ✓ 3 models loaded         ║
╠══════════════════════════════════════╣
║ Skills                               ║
║  Installed: 10 free + 56 pro         ║
║  MCP Server: ✓ Connected             ║
║  Last used: code-reviewer (2h ago)   ║
╠══════════════════════════════════════╣
║ License: PRO (expires 2026-04-22)    ║
╚══════════════════════════════════════╝
```
