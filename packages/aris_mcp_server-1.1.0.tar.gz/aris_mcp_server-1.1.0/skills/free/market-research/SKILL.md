---
name: market-research
description: "McKinsey-style market analysis reports. Includes Porter's Five Forces, PESTLE, SWOT, TAM/SAM/SOM, BCG Matrix."
version: 1.0.0
category: biz
tags: [market-research, analysis, strategy, competitive-intelligence]
tier: free
---

# Market Research

Generate consulting-quality market research reports.

## When to trigger
- User says `/market-research`, "analyze market", "research industry"
- When evaluating new markets, competition, or business opportunities

## Instructions

### Step 1: Define Scope
Ask for (or infer from context):
- **Industry/Market**: What sector?
- **Geography**: Global, US, specific region?
- **Focus**: Competition, sizing, entry strategy?

### Step 2: Research (use web search)
Search for:
- Market size and growth rates
- Key players and market share
- Recent trends and disruptions
- Regulatory environment
- Technology shifts

### Step 3: Analysis Frameworks

#### Porter's Five Forces
1. Threat of new entrants
2. Bargaining power of suppliers
3. Bargaining power of buyers
4. Threat of substitutes
5. Competitive rivalry

#### PESTLE Analysis
- Political, Economic, Social, Technological, Legal, Environmental

#### SWOT (for user's position)
- Strengths, Weaknesses, Opportunities, Threats

#### TAM/SAM/SOM
- Total Addressable Market (everyone who could buy)
- Serviceable Addressable Market (your segment)
- Serviceable Obtainable Market (realistic capture)

### Step 4: Output Format
```
# Market Research Report: [Industry]

## Executive Summary
[2-3 paragraph overview with key findings]

## Market Overview
- Size: $XB (202X)
- Growth: X% CAGR
- Key trends: ...

## Competitive Landscape
| Company | Market Share | Strengths | Weaknesses |
|---------|-------------|-----------|------------|

## Porter's Five Forces
[Analysis of each force: Low/Medium/High]

## TAM/SAM/SOM
- TAM: $XB
- SAM: $XM
- SOM: $XM (X% penetration in Y years)

## Opportunities
1. ...

## Risks
1. ...

## Recommendations
1. ...
```
