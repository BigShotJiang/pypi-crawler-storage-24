---
name: excalidraw-diagrams
description: "Generate system diagrams from natural language. Creates flowcharts, architecture diagrams, mind maps, and ERDs as Excalidraw files."
version: 1.0.0
category: dev
tags: [diagrams, excalidraw, architecture, flowchart, visualization]
tier: free
---

# Excalidraw Diagrams

Generate visual diagrams from natural language descriptions.

## When to trigger
- User says `/excalidraw-diagrams`, "draw diagram", "visualize architecture", "create flowchart"

## Supported Diagram Types
1. **System Architecture** — boxes for services, arrows for data flow
2. **Flowcharts** — decision trees, process flows
3. **Mind Maps** — brainstorming, concept exploration
4. **ERD** — database entity relationships
5. **Sequence Diagrams** — service-to-service communication
6. **Network Diagrams** — infrastructure topology

## Instructions
1. Ask user what to diagram (or infer from context)
2. Generate Excalidraw JSON with proper element positioning
3. Save as .excalidraw file
4. Elements should use ARIS color palette: #818cf8, #22d3ee, #34d399, #f472b6, #fb923c

## Element Templates
- Service box: 200x80, rounded corners, colored border
- Database: cylinder shape
- Arrow: with label
- Group: dashed border for logical grouping
- Note: yellow sticky for annotations
