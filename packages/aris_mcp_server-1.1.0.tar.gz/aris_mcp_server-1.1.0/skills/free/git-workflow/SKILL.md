---
name: git-workflow
description: "Standardized git operations — commits, branches, PRs, cross-repo sync. Enforces consistent commit messages and branch naming."
version: 1.0.0
category: dev
tags: [git, workflow, commits, branches, pr]
tier: free
---

# Git Workflow

Standardized git operations with best practices.

## When to trigger
- User says `/git-workflow`, "commit", "create PR", "branch"

## Commit Message Format
```
type(scope): description

[optional body]

Co-Authored-By: ARIS <noreply@aris4u.dev>
```

Types: feat, fix, refactor, docs, test, chore, perf, ci

## Branch Naming
- feature/description
- fix/description  
- refactor/description

## PR Template
```markdown
## Summary
[1-3 bullet points]

## Changes
- File: description of change

## Test Plan
- [ ] Tests pass
- [ ] Manual verification
```
