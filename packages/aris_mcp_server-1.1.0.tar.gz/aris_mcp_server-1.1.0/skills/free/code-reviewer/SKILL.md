---
name: code-reviewer
description: "Multi-agent code review with language-specific best practices. Analyzes code quality, security, performance, and maintainability."
version: 1.0.0
category: dev
tags: [code-review, quality, security, best-practices]
tier: free
---

# Code Reviewer

Perform a comprehensive code review on changed files.

## When to trigger
- User says `/code-reviewer`, "review this code", "review my changes"
- Before commits when code quality is important

## Instructions

### Step 1: Identify Changes
```bash
git diff --name-only HEAD~1  # or staged changes
git diff --stat
```

### Step 2: Review Each File
For each changed file, analyze:

1. **Correctness**: Logic errors, edge cases, off-by-one errors
2. **Security**: SQL injection, XSS, credential exposure, input validation
3. **Performance**: N+1 queries, unnecessary loops, memory leaks
4. **Maintainability**: Naming, complexity, DRY violations, dead code
5. **Best Practices**: Language-specific patterns and conventions

### Step 3: Language-Specific Rules

**Python**: Type hints, docstrings (Google style), specific exceptions, async patterns
**JavaScript/TypeScript**: Strict types, null checks, proper error handling
**Java**: Constructor injection, DTOs, proper HTTP status codes
**Dart/Flutter**: Widget composition, state management, null safety
**SQL**: Parameterized queries, index usage, migration safety

### Step 4: Output Format
```
## Code Review Summary

### Critical (must fix)
- [file:line] Description of issue

### Important (should fix)
- [file:line] Description of issue

### Minor (nice to fix)
- [file:line] Description of suggestion

### Positive
- Good patterns observed

**Score**: X/10
```
