# ARIS MCP Server

**AI Operating System for Developers** — Multi-model routing, persistent memory, auto-evolution, cluster orchestration.

## Install

```bash
pip install aris-mcp-server
```

Then add to your Claude Code config (`~/.claude/settings.json`):

```json
{
  "mcpServers": {
    "aris": {
      "command": "aris-mcp",
      "args": []
    }
  }
}
```

Restart Claude Code. Done.

## What You Get

**23 MCP Tools** available instantly:

| Tool | What it does |
|------|-------------|
| `aris_activate` | Activate your license key |
| `aris_list_skills` | Browse 66 skills across 4 tiers |
| `aris_get_skill` | Load any skill (19 free, no license needed) |
| `aris_route_task` | Smart AI router — picks the best model per subtask |
| `aris_guardian` | Monitor cluster hardware (CPU, RAM, GPU, temp) |
| `aris_memory_save` | Save persistent memory across sessions |
| `aris_memory_recall` | Recall any saved memory |
| `aris_memory_search` | Search all memories by keyword |
| `aris_budget_set` | Set AI spending limits |
| `aris_budget_report` | View cost breakdown by model |
| `aris_forge` | Create custom skills from natural language |
| `aris_scout_report` | Discover new tools (GitHub, npm, HN) |
| `aris_analytics` | Usage stats and ROI metrics |
| `aris_orchestrate` | CEO Agent — decompose and parallelize tasks |
| `aris_add_worker` | Add any SSH machine to your cluster |
| + 8 more | Update checks, config export, changelog... |

## Tiers

| | Free | Pro ($20/mo) | Shield ($40/mo) | Ultimate ($50/mo) |
|---|---|---|---|---|
| Skills | 19 | 55 | 61 | 66 |
| AI Router | Basic | Smart (15 categories) | Smart | Smart |
| Memory | Yes | Yes | Yes | Yes |
| Guardian | No | Yes | Yes | Yes |
| Forge | No | Yes | Yes | Yes |
| Security Suite | No | No | Yes | Yes |
| Intel Analytics | No | No | No | Yes |

## Links

- Website: [aris4u.dev](https://aris4u.dev)
- GitHub: [github.com/ama2alvarez-1990/aris](https://github.com/ama2alvarez-1990/aris)
- Pricing: [aris4u.dev/#pricing](https://aris4u.dev/#pricing)
