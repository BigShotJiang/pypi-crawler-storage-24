#!/bin/bash
# ARIS MCP Server — start script
cd "$(dirname "$0")"
source .venv/bin/activate
export ARIS_DEBUG=true
export ARIS_SKILLS_DIR=./skills
export ARIS_JWT_SECRET="aris-amado-cluster-2026"
exec python3 -m aris_mcp.server
