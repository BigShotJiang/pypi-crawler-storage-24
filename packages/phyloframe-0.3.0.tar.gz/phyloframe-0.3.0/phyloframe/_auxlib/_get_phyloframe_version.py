def get_phyloframe_version() -> str:
    return "0.3.0"
