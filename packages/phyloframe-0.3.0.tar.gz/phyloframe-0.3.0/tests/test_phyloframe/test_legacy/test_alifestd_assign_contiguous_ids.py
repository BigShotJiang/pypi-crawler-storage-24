from collections import Counter
import os

import alifedata_phyloinformatics_convert as apc
import pandas as pd
from pandas import testing as pdt
import polars as pl
import pytest

from phyloframe.legacy import (
    alifestd_aggregate_phylogenies,
)
from phyloframe.legacy import (
    alifestd_assign_contiguous_ids as alifestd_assign_contiguous_ids_,
)
from phyloframe.legacy import (
    alifestd_assign_contiguous_ids_polars as alifestd_assign_contiguous_ids_polars_,
)
from phyloframe.legacy import (
    alifestd_find_leaf_ids,
    alifestd_has_contiguous_ids,
    alifestd_is_asexual,
    alifestd_make_ancestor_id_col,
    alifestd_to_working_format,
    alifestd_validate,
)

from ._impl import (
    enforce_dtype_stability_pandas,
    enforce_dtype_stability_polars,
)

alifestd_assign_contiguous_ids = enforce_dtype_stability_pandas(
    alifestd_assign_contiguous_ids_,
)
alifestd_assign_contiguous_ids_polars = enforce_dtype_stability_polars(
    alifestd_assign_contiguous_ids_polars_,
)

assets_path = os.path.join(os.path.dirname(__file__), "assets")


@pytest.mark.parametrize(
    "phylogeny_df",
    [
        pd.read_csv(
            f"{assets_path}/example-standard-toy-sexual-phylogeny.csv"
        ),
        alifestd_aggregate_phylogenies(
            [
                pd.read_csv(
                    f"{assets_path}/example-standard-toy-sexual-phylogeny.csv"
                ),
                pd.read_csv(f"{assets_path}/nk_lexicaseselection.csv"),
            ]
        ),
        pd.read_csv(
            f"{assets_path}/example-standard-toy-asexual-phylogeny.csv"
        ),
        pd.read_csv(f"{assets_path}/nk_ecoeaselection.csv"),
        pd.read_csv(f"{assets_path}/nk_lexicaseselection.csv"),
        alifestd_aggregate_phylogenies(
            [
                pd.read_csv(f"{assets_path}/nk_ecoeaselection.csv"),
                pd.read_csv(f"{assets_path}/nk_lexicaseselection.csv"),
            ]
        ),
        pd.read_csv(f"{assets_path}/nk_tournamentselection.csv"),
    ],
)
@pytest.mark.parametrize(
    "apply",
    [
        alifestd_to_working_format,
        lambda x: x,
    ],
)
def test_alifestd_assign_contiguous_ids(phylogeny_df, apply):
    phylogeny_df = apply(phylogeny_df)
    phylogeny_df_ = phylogeny_df.copy()
    reassigned_df = alifestd_assign_contiguous_ids(phylogeny_df)
    assert alifestd_validate(reassigned_df)
    # check for side effects
    assert phylogeny_df.equals(phylogeny_df_)

    assert alifestd_has_contiguous_ids(reassigned_df)

    assert len(phylogeny_df) == len(reassigned_df)
    assert len(alifestd_find_leaf_ids(phylogeny_df)) == len(
        alifestd_find_leaf_ids(reassigned_df)
    )
    if "ancestor_id" in phylogeny_df:
        assert (
            phylogeny_df["ancestor_id"]
            == alifestd_make_ancestor_id_col(
                phylogeny_df["id"],
                phylogeny_df["ancestor_list"],
            )
        ).all()
        pdt.assert_frame_equal(
            reassigned_df.drop(
                "ancestor_list", axis=1, errors="ignore"
            ).reset_index(drop=True),
            alifestd_assign_contiguous_ids_polars(
                pl.from_pandas(
                    phylogeny_df_.drop(
                        "ancestor_list", axis=1, errors="ignore"
                    )
                )
            ).to_pandas(),
            check_dtype=False,
        )

    if alifestd_is_asexual(phylogeny_df):
        phylogeny_trees = apc.alife_dataframe_to_dendropy_trees(phylogeny_df)
        reassigned_trees = apc.alife_dataframe_to_dendropy_trees(reassigned_df)

        assert Counter(
            node.level() for tree in phylogeny_trees for node in tree
        ) == Counter(
            node.level() for tree in reassigned_trees for node in tree
        )
        assert Counter(
            len(node.child_nodes())
            for tree in phylogeny_trees
            for node in tree
        ) == Counter(
            len(node.child_nodes())
            for tree in reassigned_trees
            for node in tree
        )
        assert Counter(
            (node.level(), len(node.child_nodes()))
            for tree in phylogeny_trees
            for node in tree
        ) == Counter(
            (node.level(), len(node.child_nodes()))
            for tree in reassigned_trees
            for node in tree
        )
