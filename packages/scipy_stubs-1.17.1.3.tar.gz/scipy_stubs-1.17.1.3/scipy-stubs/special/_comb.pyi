def _comb_int(N: int, k: int) -> int: ...  # undocumented
