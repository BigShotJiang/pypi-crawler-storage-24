from typing import SupportsIndex

def _nonneg_int_or_fail(n: SupportsIndex, var_name: str, strict: bool = True) -> int: ...  # undocumented
