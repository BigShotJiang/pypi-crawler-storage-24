# scipy-stubs

Reliable type annotations for <a href="https://github.com/scipy/scipy">SciPy</a>

[![GitHub License](https://img.shields.io/github/license/scipy/scipy-stubs?style=flat-square&color=121d2f&labelColor=3d444d)](https://github.com/scipy/scipy-stubs)
[![PyPI Version](https://img.shields.io/pypi/v/scipy-stubs?style=flat-square&color=121d2f&labelColor=3d444d)](https://pypi.org/project/scipy-stubs)
[![Conda Version](https://img.shields.io/conda/vn/conda-forge/scipy-stubs?style=flat-square&color=121d2f&labelColor=3d444d)](https://anaconda.org/conda-forge/scipy-stubs)
[![Python Versions](https://img.shields.io/pypi/pyversions/scipy-stubs?style=flat-square&color=121d2f&labelColor=3d444d)](https://github.com/scipy/scipy-stubs)
[![PyPI Downloads](https://img.shields.io/pypi/dm/scipy-stubs?style=flat-square&color=121d2f&labelColor=3d444d&cacheSeconds=86400)](https://pypi.org/project/scipy-stubs)

## Features

### Enhanced Development Experience

- **Better IDE support**: Get accurate autocompletion, parameter hints, and return type information
- **Catch errors early**: Type checkers can detect mistakes before runtime
- **Improved code documentation**: Type hints serve as inline documentation for function signatures

### Zero Configuration Required

- **Drop-in replacement**: Works immediately after installation, no configuration needed
- **No runtime impact**: Type stubs are only used during development and type checking
- **IDE agnostic**: Works with VSCode, PyCharm, Vim, Emacs, and any editor with Python language server support

### Precise and Complete

- **Array shape awareness**: Many functions include shape-type information for better array handling
- **Generic types**: Comprehensive generic classes for sparse arrays, distributions, linear operators, and more
- **Complete coverage**: Type annotations are provided for the entire SciPy API

### Thoroughly Tested and Reliable

- **stubtest validation**: Ensures all type annotations match the actual SciPy runtime behavior
- **Comprehensive type-tests**: Validates type checker behavior with real-world usage patterns
- **Regression testing**: Uses [mypy_primer][PRIMER] to test against popular open-source projects, preventing breaking changes

[PRIMER]: https://github.com/hauntsaninja/mypy_primer

## Examples

### Accurate type hints for shapes and dtypes

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://github.com/user-attachments/assets/c8a5d204-13ca-4fe8-8d83-95d55ca9b9df">
  <source media="(prefers-color-scheme: light)" srcset="https://github.com/user-attachments/assets/2170df07-3491-480e-985f-24494e7d5d3f">
  <img alt="precise type inference demo" src="https://github.com/user-attachments/assets/2170df07-3491-480e-985f-24494e7d5d3f">
</picture>

### Prevent mistakes with precise type hints

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://github.com/user-attachments/assets/e50eb3db-7cb5-41e7-a56b-a563e9bd28d6">
  <source media="(prefers-color-scheme: light)" srcset="https://github.com/user-attachments/assets/7905d0ea-693c-4b5f-aaf9-4af0d11a520f">
  <img alt="bug prevention demo" src="https://github.com/user-attachments/assets/7905d0ea-693c-4b5f-aaf9-4af0d11a520f">
</picture>

<!-- NOTE: SciPy permalinks to the following `#installation` anchor; don't modify it! -->

## Installation

The source code is hosted on GitHub at [github.com/scipy/scipy-stubs](https://github.com/scipy/scipy-stubs/).

Binary distributions are available on [PyPI](https://pypi.org/project/scipy-stubs/) and
[conda-forge](https://anaconda.org/conda-forge/scipy-stubs).

### Using pip (PyPI)

To install from the [PyPI](https://pypi.org/project/scipy-stubs/), run:

```bash
pip install scipy-stubs
```

In case you haven't installed `scipy` yet, both can be installed with:

```bash
pip install scipy-stubs[scipy]
```

### Using conda (conda-forge)

To install using Conda from the [conda-forge channel](https://anaconda.org/conda-forge/scipy-stubs), run:

```bash
conda install conda-forge::scipy-stubs
```

It's also possible to install both `scipy` and `scipy-stubs` together through the bundled
[`scipy-typed`](https://anaconda.org/conda-forge/scipy-typed) package:

```bash
conda install conda-forge::scipy-typed
```

## Why is scipy-stubs a separate package?

Here are some of the key reasons why `scipy-stubs` is maintained as a separate package rather than being integrated into SciPy itself.

### Separation of concerns

If `scipy-stubs` were part of SciPy, every contributor would need to be familiar with type stubs.
Some areas of `scipy-stubs` get intricate, so keeping them in good shape goes more smoothly when you’re comfortable with how the typing pieces interact ([example](https://github.com/scipy/scipy-stubs/blob/2d6cca6a5e6ee21b6be7008c6c773dd8f12723fb/scipy-stubs/sparse/_base.pyi#L322-L389)).
Requiring all SciPy developers to become typing experts would likely reduce overall willingness to contribute.
By keeping stubs separate, SciPy contributors can focus on scientific functionality while typing specialists handle the stubs, with each group reviewing changes in its domain of expertise.

### Opt-in by design

A significant portion of SciPy users don’t use type checking.
Without `scipy-stubs` installed, type checkers won’t analyze SciPy-related code.
Some patterns may be technically type-unsafe while still working fine in practice, and installing `scipy-stubs` would flag these cases.
By keeping stubs separate, users retain full control over whether to enable type checking for their SciPy code.

### Independent release cycles

The `scipy-stubs` versioning scheme uses four numbers: `{scipy_version}.{stubs_version}`.
The first three match the SciPy semver version, while the fourth is specific to stub releases.
Since stub releases occur more frequently than SciPy releases, this independence allows typing improvements and bug fixes to ship without waiting for the next SciPy version.

### CI efficiency

The SciPy CI pipeline is large and takes over 30 minutes to run.
The `scipy-stubs` CI is lightweight and finishes in under 4 minutes.
This difference has a real impact on development workflow, enabling quicker iteration and faster delivery of changes.
The speed gap exists mainly because `scipy-stubs` doesn’t require compilation - it can rely on SciPy’s pre-built wheels.

## Frequently Asked Questions

### Q: What static type-checkers are supported?

**A:** `scipy-stubs` is tested against the most recent stable versions of

- [Mypy](https://github.com/python/mypy),
- [Pyright](https://github.com/microsoft/pyright) (a.k.a. Pylance),
- [BasedPyright](https://github.com/detachhead/basedpyright), and
- [Pyrefly](https://github.com/facebook/pyrefly) (currently in beta, so it may not always work as expected).
- [ty](https://github.com/astral-sh/ty) (currently in alpha, so it may not always work as expected).

### Q: Do I need to change my existing code?

**A:** No! `scipy-stubs` works with your existing code without any modifications.
Just install it and your type checker and IDE will automatically use the type information.

### Q: How much of SciPy is covered?

**A:** All of it! If you find any missing or incorrect type annotations, please open an issue on
[GitHub](https://github.com/scipy/scipy-stubs/issues).

### Q: Can I use this with Jupyter notebooks?

**A:** Yes! Most modern Jupyter environments (JupyterLab, VSCode notebooks) support
type checking and will benefit from `scipy-stubs`.

### Q: What if I don't use type hints in my code?

**A:** You'll still benefit! Your IDE will provide better autocompletion and error detection
even without explicit type annotations in your code.

### Q: How do I know if it's working?

**A:** You should see improved autocompletion in your IDE and more precise type information.
You can also run `mypy`, `pyright` or another type checker on your code to see type checking in action.

## Versioning and requirements

The versioning scheme of `scipy-stubs` includes the compatible `scipy` version as `{scipy_version}.{stubs_version}`.
Even though `scipy-stubs` doesn't enforce an upper bound on the `scipy` version, later `scipy` versions aren't guaranteed to be
fully compatible.

There are no additional restrictions enforced by `scipy-stubs` on the `numpy` requirements.
For `scipy-stubs==1.16.*` that is `numpy >= 1.25.2`.

Currently, `scipy-stubs` has one required dependency: [`optype`](https://github.com/jorenham/optype).
This is essential for `scipy-stubs` to work properly, as it relies heavily on it for annotating (shaped) array-likes,
scalar-likes, shape-typing in general, and much more. At the moment, `scipy-stubs` requires the latest version `optype`.

The exact version requirements are specified in the [`pyproject.toml`](pyproject.toml).

## Generics

`scipy-stubs` provides many generic classes that enable precise type checking for SciPy's complex APIs.

All generic type parameters are optional and can be omitted if not needed.

Note that not all classes are subscriptable at runtime, as that requires the `__class_getitem__` method to be implemented in `scipy`.
This can be worked around with `from __future__ import annotations` or by manually stringifying the generic annotations.
We are working on improving this in future versions of SciPy.
See the `scipy` columns below for which classes are subscriptable at runtime.

### `scipy.integrate`

| generic type                  | `scipy-stubs` | `scipy`  |                                                                                               |
| ----------------------------- | ------------- | -------- | --------------------------------------------------------------------------------------------- |
| `BDF[T: f64 \| c128]`         | `>=1.14.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.BDF.html)         |
| `DOP853[T: f64 \| c128]`      | `>=1.14.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.DOP853.html)      |
| `RK23[T: f64 \| c128]`        | `>=1.14.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.RK23.html)        |
| `RK45[T: f64 \| c128]`        | `>=1.14.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.RK45.html)        |
| `OdeSolver[T: f64 \| c128]`   | `>=1.16.2.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.OdeSolver.html)   |
| `DenseOutput[T: inexact]`     | `>=1.16.2.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.DenseOutput.html) |
| `ode[T: f64 \| c128, *ArgTs]` | `>=1.16.0.3`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.ode.html)         |
| `complex_ode[*ArgTs]`         | `>=1.14.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.complex_ode.html) |

### `scipy.interpolate`

| generic type                                       | `scipy-stubs` | `scipy`  |                                                                                                                |
| -------------------------------------------------- | ------------- | -------- | -------------------------------------------------------------------------------------------------------------- |
| `AAA[T: inexact]`                                  | `>=1.15.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.AAA.html)                        |
| `BarycentricInterpolator[T: f64 \| c128]`          | `>=1.16.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.BarycentricInterpolator.html)    |
| `BPoly[T: f64 \| c128]`                            | `>=1.14.1.4`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.BPoly.html)                      |
| `BSpline[T: f64 \| c128]`                          | `>=1.14.1.6`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.BSpline.html)                    |
| `CubicHermiteSpline[T: f64 \| c128]`               | `>=1.14.1.4`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.CubicHermiteSpline.html)         |
| `CubicSpline[T: f64 \| c128]`                      | `>=1.14.1.4`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.CubicSpline.html)                |
| `FloaterHormannInterpolator[T: f64 \| c128]`       | `>=1.15.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.FloaterHormannInterpolator.html) |
| `KroghInterpolator[T: f64 \| c128, S: (int, ...)]` | `>=1.16.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.KroghInterpolator.html)          |
| `LinearNDInterpolator[T: f64 \| c128]`             | `>=1.15.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.LinearNDInterpolator.html)       |
| `NdBSpline[T: f64 \| c128]`                        | `>=1.15.2.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.NdBSpline.html)                  |
| `NdPPoly[T: f64 \| c128]`                          | `>=1.14.1.4`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.NdPPoly.html)                    |
| `NearestNDInterpolator[T: f64 \| c128]`            | `>=1.14.1.6`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.NearestNDInterpolator.html)      |
| `PPoly[T: f64 \| c128]`                            | `>=1.14.1.4`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.PPoly.html)                      |
| `RBFInterpolator[T: f64 \| c128, S: (int, ...)]`   | `>=1.16.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.RBFInterpolator.html)            |
| `RegularGridInterpolator[T: f64 \| c128]`          | `>=1.14.1.6`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.RegularGridInterpolator.html)    |

### `scipy.optimize`

| generic type                            | `scipy-stubs` | `scipy`  |                                                                                                  |
| --------------------------------------- | ------------- | -------- | ------------------------------------------------------------------------------------------------ |
| `BroydenFirst[T: inexact]`              | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.BroydenFirst.html)    |
| `InverseJacobian[T: inexact]`           | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.InverseJacobian.html) |
| `KrylovJacobian[T: inexact]`            | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.KrylovJacobian.html)  |
| `Bounds[S: (int, int, ...), T: scalar]` | `>=1.16.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.Bounds.html)          |

### `scipy.signal`

| generic type                                         | `scipy-stubs` | `scipy`  |                                                                                                 |
| ---------------------------------------------------- | ------------- | -------- | ----------------------------------------------------------------------------------------------- |
| `ShortTimeFFT[T: inexact]`                           | `>=1.16.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.ShortTimeFFT.html)     |
| `StateSpace[Z: inexact, P: floating, D: scalar]`     | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.StateSpace.html)       |
| `TransferFunction[P: floating, D: scalar]`           | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.TransferFunction.html) |
| `ZerosPolesGain[Z: inexact, P: floating, D: scalar]` | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.ZerosPolesGain.html)   |
| `lti[Z: inexact, P: floating]`                       | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.lti.html)              |
| `dlti[Z: inexact, P: floating, D: scalar]`           | `>=1.15.2.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.dlti.html)             |

### `scipy.sparse`

| generic type                                    | `scipy-stubs` | `scipy`  |                                                                                           |
| ----------------------------------------------- | ------------- | -------- | ----------------------------------------------------------------------------------------- |
| `bsr_array[T: scalar]`                          | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.bsr_array.html)  |
| `bsr_matrix[T: scalar]`                         | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.bsr_matrix.html) |
| `coo_array[T: scalar, S: (int, ...)]`           | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.coo_array.html)  |
| `coo_matrix[T: scalar]`                         | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.coo_matrix.html) |
| `csc_array[T: scalar]`                          | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csc_array.html)  |
| `csc_matrix[T: scalar]`                         | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csc_matrix.html) |
| `csr_array[T: scalar, S: (int,) \| (int, int)]` | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_array.html)  |
| `csr_matrix[T: scalar]`                         | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_matrix.html) |
| `dia_array[T: scalar]`                          | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.dia_array.html)  |
| `dia_matrix[T: scalar]`                         | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.dia_matrix.html) |
| `dok_array[T: scalar, S: (int,) \| (int, int)]` | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.dok_array.html)  |
| `dok_matrix[T: scalar]`                         | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.dok_matrix.html) |
| `lil_array[T: scalar]`                          | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.lil_array.html)  |
| `lil_matrix[T: scalar]`                         | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.lil_matrix.html) |
| `sparray[T: scalar, S: (int, ...)]`             | `>=1.15.2.0`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.sparray.html)    |
| `spmatrix[T: scalar]`                           | `>=1.14.1.6`  | `>=1.16` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.spmatrix.html)   |

#### `scipy.sparse.linalg`

| generic type                | `scipy-stubs` | `scipy`  |                                                                                                      |
| --------------------------- | ------------- | -------- | ---------------------------------------------------------------------------------------------------- |
| `LaplacianNd[T: real]`      | `>=1.14.1.6`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.LaplacianNd.html)    |
| `LinearOperator[T: scalar]` | `>=1.14.1.6`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.LinearOperator.html) |
| `SuperLU[T: inexact]`       | `>=1.16.0.1`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.SuperLU.html)        |

### `scipy.spatial.transform`

| generic type                    | `scipy-stubs` | `scipy`  |                                                                                                          |
| ------------------------------- | ------------- | -------- | -------------------------------------------------------------------------------------------------------- |
| `Rotation[S: (int, ...)]`       | `>=1.17.1.1`  | `>=1.18` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.transform.Rotation.html)       |
| `RigidTransform[S: (int, ...)]` | `>=1.17.1.1`  | `>=1.18` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.transform.RigidTransform.html) |

### `scipy.stats`

| generic type                                                                   | `scipy-stubs` | `scipy`  |                                                                                                              |
| ------------------------------------------------------------------------------ | ------------- | -------- | ------------------------------------------------------------------------------------------------------------ |
| `Covariance[T: real]`                                                          | `>=1.14.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.Covariance.html)                     |
| `Uniform[S: (int, ...), T: floating]`                                          | `>=1.15.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.Uniform.html)                        |
| `Normal[S: (int, ...), T: floating]`                                           | `>=1.15.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.Normal.html)                         |
| `Binomial[S: (int, ...), T: floating]`                                         | `>=1.16.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.Binomial.html)                       |
| `Mixture[T: floating]`                                                         | `>=1.15.0.0`  | `>=1.17` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.Mixture.html)                        |
| `rv_frozen[D: rv_generic, T: scalar or array]`                                 | `>=1.14.0.0`  | `>=1.17` |                                                                                                              |
| `multi_rv_frozen[D: rv_generic]`                                               | `>=1.14.0.0`  | `>=1.17` |                                                                                                              |
| `CensoredData[X: f64 \| c128, L: f64 \| c128, R: f64 \| c128, I: f64 \| c128]` | `>=1.17.0.2`  | `>=1.18` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.CensoredData.html)                   |
| `gaussian_kde[T: floating]`                                                    | `>=1.17.0.2`  | `>=1.18` | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.gaussian_kde.html)                   |
| `FitResult[F: (float, *) -> f64]`                                              | `>=1.15.0.0`  |          | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats._result_classes.FitResult.html)      |
| `PearsonRResult[T: floating scalar/array, P: f64 scalar/array]`                | `>=1.14.1.0`  |          | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats._result_classes.PearsonRResult.html) |
| `TtestResult[T: floating scalar/array]`                                        | `>=1.14.1.0`  |          | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats._result_classes.TtestResult.html)    |

#### `scipy.stats.contingency`

| generic type                           | `scipy-stubs` | `scipy` |                                                                                                |
| -------------------------------------- | ------------- | ------- | ---------------------------------------------------------------------------------------------- |
| `Chi2ContingencyResult[S: (int, ...)]` | `>=1.17.1.2`  | `*`     | [docs](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2_contingency.html) |

## Contributing

We welcome contributions from the community! There are many ways to help improve `scipy-stubs`:

### Ways to Contribute

- **Report issues**: Found a bug or incorrect type annotation? [Open an issue](https://github.com/scipy/scipy-stubs/issues)
- **Improve stubs**: Fix or enhance `.pyi` files (see [CONTRIBUTING.md](https://github.com/scipy/scipy-stubs/blob/master/CONTRIBUTING.md))
- **Add tests**: Help with type-testing (see [#1099](https://github.com/scipy/scipy-stubs/issues/1099) and the `README.md` in [`tests/`](https://github.com/scipy/scipy-stubs/tree/master/tests))
- **Documentation**: Write guides, examples, or improve existing documentation
- **Spread the word**: Help others discover `scipy-stubs`

### Development Setup

See the [CONTRIBUTING.md](https://github.com/scipy/scipy-stubs/blob/master/CONTRIBUTING.md) for detailed instructions.

## Who's using `scipy-stubs`?

`scipy-stubs` is used by a number of major open-source projects, including:

Apache Spark ([PySpark](https://github.com/apache/spark)) |
[Artisan](https://github.com/artisan-roaster-scope/artisan) |
[Arviz](https://github.com/arviz-devs/arviz) |
[asammdf](https://github.com/danielhrisca/asammdf) |
[Astropy](https://github.com/astropy/astropy) |
[Chemotools](https://github.com/paucablop/chemotools) |
Colour ([Colour](https://github.com/colour-science/colour),
[Checker Detection](https://github.com/colour-science/colour-checker-detection),
[Demosaicing](https://github.com/colour-science/colour-demosaicing),
[HDRI](https://github.com/colour-science/colour-hdri),
[Visuals](https://github.com/colour-science/colour-visuals)) |
[CSAPS](https://github.com/espdev/csaps) |
[cuPyNumeric](https://github.com/nv-legate/cupynumeric) |
derwen.ai ([kglab](https://github.com/DerwenAI/kglab)) |
[Dify](https://github.com/langgenius/dify) |
[Dify-Plus](https://github.com/YFGaia/dify-plus) |
[Dingo](https://github.com/dingo-gw/dingo) |
[Efax](https://github.com/NeilGirdhar/efax) |
[Fast GraphRAG](https://github.com/circlemind-ai/fast-graphrag) |
[foamlib](https://github.com/gerlero/foamlib) |
[Freqtrade](https://github.com/freqtrade/freqtrade) |
[graphix](https://github.com/TeamGraphix/graphix) |
Gurobi ([gurobi-logtools](https://github.com/Gurobi/gurobi-logtools)) |
[JAX](https://github.com/jax-ml/jax) |
[LensKit](https://github.com/lenskit/lkpy) |
[librosa](https://github.com/librosa/librosa) |
[linearmodels](https://github.com/bashtage/linearmodels) |
[Lmo](https://github.com/jorenham/Lmo) |
[Materialize](https://github.com/MaterializeInc/materialize) |
[MaxText](https://github.com/AI-Hypercomputer/maxtext) |
Metta AI ([mettagrid](https://github.com/Metta-AI/metta/tree/main/packages/mettagrid)) |
[MolPipeline](https://github.com/basf/MolPipeline) |
[MouseTracks](https://github.com/huntfx/MouseTracks) |
[movement](https://github.com/neuroinformatics-unit/movement) |
Mozilla ([mozanalysis](https://github.com/mozilla/mozanalysis)) |
[MTEB](https://github.com/embeddings-benchmark/mteb) |
[mypy_primer](https://github.com/hauntsaninja/mypy_primer) |
[Namer](https://github.com/ThePornDatabase/namer) |
[NeuroGym](https://github.com/neurogym/neurogym) |
[Optuna](https://github.com/optuna/optuna) |
[pandapower](https://github.com/e2nIEE/pandapower) |
Pandas ([pandas](https://github.com/pandas-dev/pandas),
[pandas-stubs](https://github.com/pandas-dev/pandas-stubs)) |
[Pandera](https://github.com/unionai-oss/pandera) |
[ProgressiVis](https://github.com/progressivis/progressivis) |
[ProLIF](https://github.com/chemosim-lab/ProLIF) |
[Ptera Software](https://github.com/camUrban/PteraSoftware) |
PyMC ([PyTensor](https://github.com/pymc-devs/pytensor)) |
[pysmo](https://github.com/pysmo/pysmo) |
[python-hvac](https://github.com/TomLXXVI/python-hvac) |
[radioactivedecay](https://github.com/radioactivedecay/radioactivedecay) |
[scikit-fingerprints](https://github.com/scikit-fingerprints/scikit-fingerprints) |
scverse ([PyDESeq2](https://github.com/scverse/PyDESeq2), [scanpy](https://github.com/scverse/scanpy)) |
[SeQUeNCe](https://github.com/sequence-toolbox/SeQUeNCe) |
[Skore](https://github.com/probabl-ai/skore) |
Theis Lab ([anndata2ri](https://github.com/theislab/anndata2ri)) |
[TorchFX](https://github.com/matteospanio/torchfx) |
[TQEC](https://github.com/tqec/tqec) |
[traccuracy](https://github.com/live-image-tracking-tools/traccuracy) |
[Ultralytics](https://github.com/ultralytics/ultralytics) |
Vega ([Altair](https://github.com/vega/altair)) |
[Voctomix](https://github.com/voc/voctomix) |
[xarray](https://github.com/pydata/xarray)

## License

`scipy-stubs` is licensed under the [BSD 3-Clause License](https://github.com/scipy/scipy-stubs/blob/master/LICENSE),
the same as SciPy itself.
