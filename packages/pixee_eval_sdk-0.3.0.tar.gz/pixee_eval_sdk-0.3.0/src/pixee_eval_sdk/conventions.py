"""Tagging conventions for the Benchmark Command Center + MLflow integration.

Defines tag key constants, the feature registry, and helpers for
deriving feature names from benchmark types.
"""

from __future__ import annotations


class Tags:
    """MLflow tag key constants used by the BCC convention."""

    FEATURE = "bcc.feature"
    BENCHMARK_TYPE = "bcc.benchmark_type"
    MODE = "bcc.mode"
    SUITE = "bcc.suite"
    CASE_ID = "bcc.case_id"
    RENDER_HINTS = "bcc.render_hints"
    TAG_PREFIX = "bcc.tag."


FEATURE_REGISTRY: dict[str, list[str]] = {
    "vulnerability-triage": ["triage"],
    "code-remediation": ["code_generation", "fix_quality", "fix_preferences"],
    "sca-analysis": ["sca"],
}

# Inverse lookup: benchmark_type → feature name
_TYPE_TO_FEATURE: dict[str, str] = {}
for _feature, _types in FEATURE_REGISTRY.items():
    for _bt in _types:
        _TYPE_TO_FEATURE[_bt] = _feature


def feature_for_benchmark_type(benchmark_type: str) -> str | None:
    """Return the feature name for a given benchmark_type, or None if unknown."""
    return _TYPE_TO_FEATURE.get(benchmark_type)
