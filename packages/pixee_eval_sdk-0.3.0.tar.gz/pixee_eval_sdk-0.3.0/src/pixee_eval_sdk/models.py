from __future__ import annotations

from typing import Any


def field(value: Any, render_hint: str, **metadata: Any) -> dict[str, Any]:
    result: dict[str, Any] = {"value": value, "render_hint": render_hint}
    if metadata:
        result["metadata"] = metadata
    return result


def code_field(value: str, language: str = "python") -> dict[str, Any]:
    return field(value, "code", language=language)


def diff_field(value: str) -> dict[str, Any]:
    return field(value, "diff")


def markdown_field(value: str) -> dict[str, Any]:
    return field(value, "markdown")


def key_value_field(value: dict[str, Any]) -> dict[str, Any]:
    return field(value, "key_value")


def json_field(value: Any) -> dict[str, Any]:
    return field(value, "json")


def text_field(value: str) -> dict[str, Any]:
    return field(value, "text")


def badge_field(value: str, color: str = "gray") -> dict[str, Any]:
    return field(value, "badge", color=color)
