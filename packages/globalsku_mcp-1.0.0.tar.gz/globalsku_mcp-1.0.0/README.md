# GlobalSKU MCP Server

A Model Context Protocol (MCP) server that wraps the GlobalSKU product data management API. It lets AI assistants (Claude Desktop, Claude Code, etc.) submit products for market analysis, get pricing data, manage listings across marketplaces, and more -- all through natural conversation.

## Installation

```bash
# From the mcp-server directory
pip install .

# Or install directly from the package name (if published)
pip install globalsku-mcp
```

## Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `GLOBALSKU_API_URL` | Yes | Base URL of your GlobalSKU instance (e.g. `https://app.globalsku.com`) |
| `GLOBALSKU_API_TOKEN` | Yes | Laravel Sanctum API bearer token |

Generate a Sanctum token from your GlobalSKU account under Settings > API Tokens.

### Claude Desktop

Add to your Claude Desktop config file (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS or `%APPDATA%\Claude\claude_desktop_config.json` on Windows):

```json
{
  "mcpServers": {
    "globalsku": {
      "command": "globalsku-mcp",
      "env": {
        "GLOBALSKU_API_URL": "https://app.globalsku.com",
        "GLOBALSKU_API_TOKEN": "your-sanctum-token-here"
      }
    }
  }
}
```

### Claude Code

Add to your Claude Code MCP config (`.claude/mcp.json` in your project or `~/.claude/mcp.json` globally):

```json
{
  "mcpServers": {
    "globalsku": {
      "command": "globalsku-mcp",
      "env": {
        "GLOBALSKU_API_URL": "https://app.globalsku.com",
        "GLOBALSKU_API_TOKEN": "your-sanctum-token-here"
      }
    }
  }
}
```

## Available Tools

| Tool | Description |
|------|-------------|
| `process_search` | Submit a product for AI-powered market analysis |
| `get_quick_results` | Get fast ballpark pricing (30s-2min) |
| `get_full_results` | Get complete market analysis with eBay data (2-10min) |
| `list_item` | List a product on marketplaces (eBay, Walmart, Amazon, Shopify, Meta, Temu) |
| `delist_item` | Remove a product listing from marketplaces |
| `update_listing_data` | Update listing attributes (title, description, price, etc.) |
| `update_quantity` | Update inventory quantity (syncs to all active listings) |
| `update_search_data` | Update search record attributes |
| `update_ebay_order` | Add tracking information to an eBay order |
| `suggest_additional_photos` | AI suggests additional photo angles for better listings |
| `identify_missing_attributes` | AI identifies attributes that need manual verification |

## Available Prompts

| Prompt | Description |
|--------|-------------|
| `product_enrichment` | Step-by-step guide through the full workflow: search, analyze, update, and list |
| `bulk_processing` | Guide for processing multiple products efficiently |

## Quick Example

Once configured, you can ask Claude:

> "I have a Nike Air Max 90 in size 10, white colorway. Can you look up the market price and list it on eBay?"

Claude will:
1. Call `process_search` with the title, brand, size, and color
2. Wait and then call `get_quick_results` for initial pricing
3. Call `get_full_results` for complete eBay comparable data
4. Present the analysis and suggested price
5. Call `list_item` to post it on eBay (after your confirmation)

## Development

```bash
# Install in editable mode
pip install -e .

# Run directly
GLOBALSKU_API_URL=https://app.globalsku.com GLOBALSKU_API_TOKEN=your-token globalsku-mcp
```
