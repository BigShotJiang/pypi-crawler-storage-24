"""GlobalSKU MCP Server - MCP server for the GlobalSKU product data management API."""

__version__ = "1.0.0"
