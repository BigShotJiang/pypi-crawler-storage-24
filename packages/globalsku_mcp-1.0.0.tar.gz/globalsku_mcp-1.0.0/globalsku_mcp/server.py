# ABOUTME: Main MCP server for GlobalSKU. Wraps the GlobalSKU REST API as MCP tools
# ABOUTME: so AI assistants can process products, get pricing, manage listings, and more.

import os
import sys
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("globalsku")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def _get_config() -> tuple[str, str]:
    """Return (api_url, api_token) from environment variables."""
    api_url = os.environ.get("GLOBALSKU_API_URL", "").rstrip("/")
    api_token = os.environ.get("GLOBALSKU_API_TOKEN", "")
    if not api_url:
        raise RuntimeError(
            "GLOBALSKU_API_URL environment variable is required "
            "(e.g. https://app.globalsku.com)"
        )
    if not api_token:
        raise RuntimeError(
            "GLOBALSKU_API_TOKEN environment variable is required "
            "(Laravel Sanctum bearer token)"
        )
    return api_url, api_token


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

async def _request(
    method: str,
    path: str,
    *,
    params: dict | None = None,
    json_body: dict | None = None,
) -> dict:
    """Make an authenticated request to the GlobalSKU API.

    Returns the parsed JSON response, or an error dict on failure.
    """
    api_url, api_token = _get_config()
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    url = f"{api_url}{path}"

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.request(
                method,
                url,
                headers=headers,
                params=params,
                json=json_body,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        try:
            error_body = exc.response.json()
        except Exception:
            error_body = exc.response.text
        return {
            "error": True,
            "status_code": exc.response.status_code,
            "detail": error_body,
        }
    except httpx.RequestError as exc:
        return {
            "error": True,
            "detail": f"Request failed: {exc}",
        }


def _clean(payload: dict) -> dict:
    """Remove keys whose values are None."""
    return {k: v for k, v in payload.items() if v is not None}


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def process_search(
    title: str | None = None,
    barcode: str | None = None,
    images: list[str] | None = None,
    brand: str | None = None,
    price: float | None = None,
    quantity: int | None = None,
    condition: str | None = None,
    color: str | None = None,
    size: str | None = None,
    sku: str | None = None,
    manifest_id: int | None = None,
    manifest_name: str | None = None,
) -> dict:
    """Submit a product for AI-powered market analysis.

    Requires at least one of: title, barcode, or images.
    Returns search_id for tracking.
    Results available via get_quick_results (30s-2min) and get_full_results (2-10min).
    """
    if not any([title, barcode, images]):
        return {"error": True, "detail": "At least one of title, barcode, or images is required."}

    payload = _clean({
        "title": title,
        "barcode": barcode,
        "images": images,
        "brand": brand,
        "price": price,
        "quantity": quantity,
        "condition": condition,
        "color": color,
        "size": size,
        "sku": sku,
        "manifest_id": manifest_id,
        "manifest_name": manifest_name,
    })
    return await _request("POST", "/api/process-search", json_body=payload)


@mcp.tool()
async def get_quick_results(
    search_id: int | None = None,
    sku: str | None = None,
) -> dict:
    """Get fast ballpark pricing from Google search data.

    Available 30s-2min after process_search.
    Provide either search_id or sku to look up results.
    """
    if not search_id and not sku:
        return {"error": True, "detail": "Either search_id or sku is required."}

    if search_id:
        return await _request("GET", f"/api/quick-results/{search_id}")
    return await _request("GET", "/api/quick-results", params={"sku": sku})


@mcp.tool()
async def get_full_results(
    search_id: int | None = None,
    sku: str | None = None,
) -> dict:
    """Get complete market analysis with eBay pricing, AI-generated listing data, and product attributes.

    Available 2-10min after process_search.
    Provide either search_id or sku to look up results.
    """
    if not search_id and not sku:
        return {"error": True, "detail": "Either search_id or sku is required."}

    if search_id:
        return await _request("GET", f"/api/full-results/{search_id}")
    return await _request("GET", "/api/full-results", params={"sku": sku})


@mcp.tool()
async def list_item(
    sku: str | None = None,
    listing_data_id: int | None = None,
    manifest_item_id: int | None = None,
    marketplaces: list[str] | None = None,
    quantity: int | None = None,
    condition: str | None = None,
) -> dict:
    """List a product on one or more marketplaces.

    Supported marketplaces: ebay, walmart, amazon, shopify, meta, temu.
    Use ['all'] to list on all marketplaces.
    At least one identifier (sku, listing_data_id, or manifest_item_id) is required.
    """
    if not any([sku, listing_data_id, manifest_item_id]):
        return {"error": True, "detail": "At least one of sku, listing_data_id, or manifest_item_id is required."}

    payload = _clean({
        "sku": sku,
        "listing_data_id": listing_data_id,
        "manifest_item_id": manifest_item_id,
        "marketplaces": marketplaces if marketplaces is not None else ["ebay"],
        "quantity": quantity,
        "condition": condition,
    })
    return await _request("POST", "/api/list-item", json_body=payload)


@mcp.tool()
async def delist_item(
    sku: str | None = None,
    listing_data_id: int | None = None,
    manifest_item_id: int | None = None,
    marketplaces: list[str] | None = None,
) -> dict:
    """Remove a product listing from one or more marketplaces.

    At least one identifier (sku, listing_data_id, or manifest_item_id) is required.
    Defaults to removing from all marketplaces.
    """
    if not any([sku, listing_data_id, manifest_item_id]):
        return {"error": True, "detail": "At least one of sku, listing_data_id, or manifest_item_id is required."}

    payload = _clean({
        "sku": sku,
        "listing_data_id": listing_data_id,
        "manifest_item_id": manifest_item_id,
        "marketplaces": marketplaces if marketplaces is not None else ["all"],
    })
    return await _request("POST", "/api/delist-item", json_body=payload)


@mcp.tool()
async def update_listing_data(
    sku: str | None = None,
    listing_data_id: int | None = None,
    manifest_item_id: int | None = None,
    title: str | None = None,
    description: str | None = None,
    condition: str | None = None,
    brand: str | None = None,
    color: str | None = None,
    size: str | None = None,
    price: float | None = None,
    quantity: int | None = None,
    notes: str | None = None,
    reprocess_ai: bool | None = None,
) -> dict:
    """Update listing attributes for a product.

    Set reprocess_ai=true to regenerate title/description with AI.
    At least one identifier (sku, listing_data_id, or manifest_item_id) is required.
    """
    if not any([sku, listing_data_id, manifest_item_id]):
        return {"error": True, "detail": "At least one of sku, listing_data_id, or manifest_item_id is required."}

    payload = _clean({
        "sku": sku,
        "listing_data_id": listing_data_id,
        "manifest_item_id": manifest_item_id,
        "title": title,
        "description": description,
        "condition": condition,
        "brand": brand,
        "color": color,
        "size": size,
        "price": price,
        "quantity": quantity,
        "notes": notes,
        "reprocess_ai": reprocess_ai,
    })
    return await _request("POST", "/api/update-listing-data", json_body=payload)


@mcp.tool()
async def update_quantity(
    quantity: int,
    sku: str | None = None,
    listing_data_id: int | None = None,
    manifest_item_id: int | None = None,
) -> dict:
    """Update inventory quantity for a product.

    Automatically syncs to all active marketplace listings (eBay, Walmart, Amazon, Shopify, Meta).
    At least one identifier (sku, listing_data_id, or manifest_item_id) is required.
    """
    if not any([sku, listing_data_id, manifest_item_id]):
        return {"error": True, "detail": "At least one of sku, listing_data_id, or manifest_item_id is required."}

    payload = _clean({
        "sku": sku,
        "listing_data_id": listing_data_id,
        "manifest_item_id": manifest_item_id,
        "quantity": quantity,
    })
    return await _request("POST", "/api/update-quantity", json_body=payload)


@mcp.tool()
async def update_search_data(
    search_id: int | None = None,
    manifest_item_id: int | None = None,
    sku: str | None = None,
    basic_title: str | None = None,
    brand: str | None = None,
    color: str | None = None,
    size: str | None = None,
    images: list[str] | None = None,
) -> dict:
    """Update search record attributes.

    If brand is changed, AI may regenerate the title.
    At least one identifier (search_id, manifest_item_id, or sku) is required.
    """
    if not any([search_id, manifest_item_id, sku]):
        return {"error": True, "detail": "At least one of search_id, manifest_item_id, or sku is required."}

    payload = _clean({
        "search_id": search_id,
        "manifest_item_id": manifest_item_id,
        "sku": sku,
        "basic_title": basic_title,
        "brand": brand,
        "color": color,
        "size": size,
        "images": images,
    })
    return await _request("POST", "/api/update-search-data", json_body=payload)


@mcp.tool()
async def update_ebay_order(
    tracking_number: str,
    carrier_code: str,
    ebay_order_id: str,
) -> dict:
    """Add tracking information to an eBay order.

    Carrier 'stamps_com' maps to USPS, others to FedEx.
    """
    payload = {
        "tracking_number": tracking_number,
        "carrier_code": carrier_code,
        "ebay_order_id": ebay_order_id,
    }
    return await _request("POST", "/api/update-ebay-order", json_body=payload)


@mcp.tool()
async def suggest_additional_photos(
    image_url: str,
    max_photos: int | None = None,
) -> dict:
    """AI suggests additional product photo angles to improve listings.

    Returns ranked suggestions optimized for warehouse workflow.
    """
    payload = _clean({
        "image_url": image_url,
        "max_photos": max_photos if max_photos is not None else 4,
    })
    return await _request("POST", "/api/suggest-additional-photos", json_body=payload)


@mcp.tool()
async def identify_missing_attributes(
    image_url: str,
    product_type: str | None = None,
    existing_photos: list[str] | None = None,
) -> dict:
    """AI identifies product attributes that can't be determined from photos alone.

    Detects missing info like size, compatibility, specs that need manual verification.
    """
    payload = _clean({
        "image_url": image_url,
        "product_type": product_type,
        "existing_photos": existing_photos,
    })
    return await _request("POST", "/api/identify-missing-attributes", json_body=payload)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

@mcp.prompt()
def product_enrichment() -> str:
    """Guide through the full product enrichment workflow: search, analyze, update, and list."""
    return """You are helping the user enrich a product and list it on marketplaces using GlobalSKU.

Follow this workflow:

## Step 1: Submit the product
Ask the user for product information (title, barcode, images, brand, etc.).
Call `process_search` with whatever they provide. Note the returned `search_id`.

## Step 2: Get quick pricing
Wait about 30-60 seconds, then call `get_quick_results` with the search_id.
Share the ballpark pricing with the user. If the status shows processing is still in progress, wait and retry.

## Step 3: Get full results
Wait 2-5 minutes after the initial search, then call `get_full_results` with the search_id.
Present the complete market analysis:
- AI-generated title and description
- eBay comparable pricing (sold items)
- Product attributes (brand, color, size, condition)
- Suggested listing price

## Step 4: Review and refine
Ask the user if they want to adjust anything:
- Update the listing title or description (`update_listing_data`)
- Fix product attributes (`update_search_data`)
- Set reprocess_ai=true to regenerate AI content
- Suggest additional photos (`suggest_additional_photos`)
- Check for missing attributes (`identify_missing_attributes`)

## Step 5: List the product
Once the user is satisfied, ask which marketplaces to target.
Call `list_item` with the chosen marketplaces. Supported: ebay, walmart, amazon, shopify, meta, temu.

## Tips
- If the user provides a barcode/UPC, that usually gives the best results.
- Images of the actual product improve AI analysis significantly.
- Always confirm pricing with the user before listing.
- Use `update_quantity` if the user has multiple units.
"""


@mcp.prompt()
def bulk_processing() -> str:
    """Guide for processing multiple products efficiently."""
    return """You are helping the user process multiple products through GlobalSKU in bulk.

## Preparation
Ask the user how they want to provide products:
1. **One at a time** - they'll give you details for each product sequentially
2. **List of titles/barcodes** - they have a list ready to go
3. **CSV manifest** - they've already uploaded a manifest (get the manifest_id)

## Bulk Workflow

### For sequential processing:
1. Collect product info for each item
2. Call `process_search` for each product - note all search_ids
3. After submitting all products, go back and collect results:
   - First pass: `get_quick_results` for each (after ~1 min)
   - Second pass: `get_full_results` for each (after ~5 min)
4. Present a summary table of all products with pricing
5. Ask the user which ones to list and on which marketplaces
6. Call `list_item` for each approved product

### For manifest-based processing:
1. Get the manifest_id from the user
2. Products are already submitted - check results with SKUs
3. Call `get_full_results` for each SKU
4. Present summary and proceed to listing

## Efficiency Tips
- Submit all `process_search` calls before waiting for results
- Check quick results first to identify any products that need attention
- Use full results to make final listing decisions
- Batch `list_item` calls for products going to the same marketplace
- Track search_ids so you can reference them throughout the session

## Status Tracking
Keep a running list:
| # | Product | Search ID | Quick Results | Full Results | Listed |
|---|---------|-----------|---------------|--------------|--------|

Update this table as you progress through the workflow.
"""


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    """Run the GlobalSKU MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
