#!/usr/bin/env python3
"""Mesh Optimizer agent CLI.

Usage:
    mesh-optimizer start [--config FILE] [--port PORT]
    mesh-optimizer stop
    mesh-optimizer status
    mesh-optimizer --config FILE          # (no subcommand = start)
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import signal
import subprocess
import sys
from pathlib import Path

import uvicorn


def _default_config() -> str:
    """Find config in standard locations."""
    candidates = [
        Path.home() / ".mesh-optimizer" / "mesh_config.yaml",
        Path("mesh/mesh_config.yaml"),
        Path("mesh_config.yaml"),
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    return str(candidates[0])


def _pid_file() -> Path:
    return Path.home() / ".mesh-optimizer" / "mesh-optimizer.pid"


def _is_running() -> tuple[bool, int | None]:
    """Check if agent is running. Returns (running, pid)."""
    pf = _pid_file()
    if not pf.exists():
        return False, None
    try:
        pid = int(pf.read_text().strip())
        os.kill(pid, 0)  # signal 0 = check existence
        return True, pid
    except (ValueError, ProcessLookupError, PermissionError):
        pf.unlink(missing_ok=True)
        return False, None


def _agent_port(config_path: str) -> int:
    """Read agent port from config."""
    try:
        import yaml
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
        return cfg.get("node", {}).get("agent_port", 8400)
    except Exception:
        return 8400


def cmd_start(args):
    """Start the mesh agent."""
    running, pid = _is_running()
    if running:
        print(f"Agent already running (PID {pid})")
        sys.exit(0)

    project_root = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(project_root))

    from mesh.config import MeshConfig
    from mesh.agent.node_agent import NodeAgent
    from mesh.api.agent_api import app, wire_agent

    config = MeshConfig.from_yaml(args.config)
    if args.port:
        config.node.agent_port = args.port
    if args.log_level:
        config.log_level = args.log_level

    logging.basicConfig(
        level=getattr(logging, config.log_level.upper()),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    logger = logging.getLogger("mesh.agent")
    logger.info("Starting agent on port %d", config.node.agent_port)

    # Write PID file
    pf = _pid_file()
    pf.parent.mkdir(parents=True, exist_ok=True)
    pf.write_text(str(os.getpid()))

    def _cleanup(*_a):
        pf.unlink(missing_ok=True)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _cleanup)
    signal.signal(signal.SIGINT, _cleanup)

    try:
        agent = NodeAgent(config)
        wire_agent(node_agent=agent)
        uvicorn.run(app, host=config.node.host, port=config.node.agent_port,
                    log_level=config.log_level.lower())
    finally:
        pf.unlink(missing_ok=True)


def cmd_stop(args):
    """Stop the mesh agent."""
    running, pid = _is_running()
    if not running:
        print("Agent is not running.")
        sys.exit(0)

    print(f"Stopping agent (PID {pid})...")
    try:
        os.kill(pid, signal.SIGTERM)
        print("Agent stopped.")
    except ProcessLookupError:
        print("Agent already stopped.")
    _pid_file().unlink(missing_ok=True)


def cmd_status(args):
    """Show agent status."""
    running, pid = _is_running()
    config_path = args.config

    print(f"Mesh Optimizer Agent")
    print(f"{'─' * 40}")

    if running:
        print(f"  Status:   \033[32mrunning\033[0m (PID {pid})")
    else:
        print(f"  Status:   \033[31mstopped\033[0m")

    cfg_path = Path(config_path)
    print(f"  Config:   {cfg_path}")
    print(f"  PID file: {_pid_file()}")

    if cfg_path.exists():
        try:
            import yaml
            with open(cfg_path) as f:
                cfg = yaml.safe_load(f)
            port = cfg.get("node", {}).get("agent_port", 8400)
            ctrl = cfg.get("controller", {}).get("url", "not set")
            nat = cfg.get("controller", {}).get("nat_mode", False)
            cluster = cfg.get("cluster_name", "default")
            print(f"  Port:     {port}")
            print(f"  Cluster:  {cluster}")
            print(f"  Controller: {ctrl}")
            print(f"  NAT mode: {nat}")
        except Exception:
            pass

    # If running, try to hit the local health endpoint
    if running:
        try:
            import urllib.request
            port = _agent_port(config_path)
            resp = urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=2)
            data = json.loads(resp.read())
            print(f"  Health:   {data.get('status', 'unknown')}")
        except Exception:
            print(f"  Health:   unreachable")

    log_dir = Path.home() / ".mesh-optimizer" / "logs"
    if log_dir.exists():
        logs = sorted(log_dir.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
        if logs:
            print(f"  Logs:     {logs[0]}")


def main():
    parser = argparse.ArgumentParser(
        prog="mesh-optimizer",
        description="Mesh Optimizer — distributed hardware optimization agent",
    )
    parser.add_argument("--config", default=_default_config(), help="Config file path")
    parser.add_argument("--port", type=int, default=None, help="Override agent port")
    parser.add_argument("--log-level", default=None, help="Log level")

    sub = parser.add_subparsers(dest="command")

    sub.add_parser("start", help="Start the agent")
    sub.add_parser("stop", help="Stop the agent")
    sub.add_parser("status", help="Show agent status")

    args = parser.parse_args()

    # Default to start if no subcommand given
    if args.command is None or args.command == "start":
        cmd_start(args)
    elif args.command == "stop":
        cmd_stop(args)
    elif args.command == "status":
        cmd_status(args)


if __name__ == "__main__":
    main()
