"""RDNA3 Discovery Mesh — Distributed profiling and job routing."""
__version__ = "0.1.0"
