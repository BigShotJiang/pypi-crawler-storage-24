"""
BeeQ CLI — beeq <command>

Commands:
  start     Start the hive (Queen + workers + dashboard)
  stop      Stop the hive
  mission   Give a mission
  status    Hive status + audit chain
  log       Show audit chain
  verify    Verify an action hash
  workers   List workers
  revoke    Revoke a worker
  connect   Configure LLM provider
  memory    Manage sovereign memory
  version   Show version
"""

import asyncio
import click
from rich.console import Console
from rich.table   import Table
from rich         import box

console = Console()


def header():
    console.print()
    console.print("  [bold yellow]BeeQ[/bold yellow] [dim]— The First AI Hive[/dim]")
    console.print("  [dim]Every action signed. You remain sovereign.[/dim]")
    console.print()


@click.group()
def cli():
    """BeeQ — The First AI Hive."""
    pass


@cli.command()
@click.option("--port", default=7935, help="Dashboard port")
@click.option("--provider", default=None, help="LLM provider (claude/openai/ollama)")
def start(port, provider):
    """Start the BeeQ hive + dashboard."""
    header()
    console.print(f"  [dim]Starting hive...[/dim]")

    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        workers = list(hive.governance.workers.keys())
        console.print(f"  [green]✓[/green] Queen ready")
        console.print(f"  [green]✓[/green] {len(workers)} workers: {', '.join(workers)}")
        console.print()
        console.print(f"  Dashboard: [bold yellow]http://localhost:{port}[/bold yellow]")
        console.print(f"  Verify:    [bold]https://beeq.run/verify/<hash>[/bold]")
        console.print()
        console.print("  [dim]Press Ctrl+C to stop.[/dim]")
        console.print()

        from beeq.dashboard.server import create_app
        app, uvicorn = create_app(hive)
        config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="error")
        server = uvicorn.Server(config)
        await server.serve()

    asyncio.run(_run())


@cli.command()
@click.argument("text", nargs=-1)
@click.option("--provider", default=None)
def mission(text, provider):
    """Give a mission to the hive."""
    if not text:
        console.print("[red]Error:[/red] Please provide a mission.")
        return

    mission_text = " ".join(text)
    header()
    console.print(f"  [bold]Mission:[/bold] {mission_text}")
    console.print()

    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        with console.status("[yellow]Queen orchestrating...[/yellow]"):
            # Sign intention first
            from beeq.dashboard.server import _sign_intention
            intention = await _sign_intention(hive, mission_text)

        console.print("  [bold yellow]⚡ Intention Signed (BEFORE acting):[/bold yellow]")
        console.print(f"  [dim]{intention[:200]}...[/dim]" if len(intention) > 200 else f"  [dim]{intention}[/dim]")
        console.print()

        with console.status("[yellow]Workers executing...[/yellow]"):
            m = await hive.execute(mission_text)

        for r in m.results:
            icon = "✅" if r.success else "❌"
            console.print(f"  {icon} [{r.worker}]")
            console.print(f"  [dim]{r.output[:500]}[/dim]")
            console.print()

        audit = hive.audit()
        chain = "INTACT" if audit["valid"] else "ERROR"
        color = "green" if audit["valid"] else "red"
        console.print(f"  [{color}]Chain: {chain}[/{color}] · {audit['actions']} action(s) signed")
        console.print()

    asyncio.run(_run())


@cli.command()
@click.option("--provider", default=None)
def status(provider):
    """Show hive status + audit chain."""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)
        audit = hive.audit()
        header()

        t = Table(box=box.SIMPLE, show_header=False, padding=(0,1))
        t.add_column("K", style="dim", width=12)
        t.add_column("V")
        t.add_row("Workers", str(len(audit["workers"])))
        t.add_row("Actions", str(audit["actions"]))
        t.add_row("Chain", "[green]INTACT[/green]" if audit["valid"] else "[red]ERROR[/red]")
        console.print(t)

    asyncio.run(_run())


@cli.command()
@click.argument("hash_id")
@click.option("--provider", default=None)
def verify(hash_id, provider):
    """Verify an action hash from the audit chain."""
    async def _run():
        from beeq.core import BeeQ
        import hashlib
        hive = BeeQ()
        await hive.setup(provider=provider)

        for e in hive.governance.audit_entries:
            ts = e.timestamp.isoformat() if hasattr(e.timestamp, "isoformat") else str(e.timestamp)
            h = hashlib.sha256(f"{e.agent_id}{e.action}{ts}".encode()).hexdigest()
            if h.startswith(hash_id) or h == hash_id:
                worker = (e.agent_id or "").split("/")[-1].split("@")[0]
                console.print(f"\n  [green]✅ Valid[/green]")
                console.print(f"  Worker:    {worker}")
                console.print(f"  Action:    {e.action}")
                console.print(f"  Result:    {e.result}")
                console.print(f"  Timestamp: {ts}")
                console.print(f"  Hash:      {h}")
                return

        console.print(f"\n  [yellow]Hash not found in current session.[/yellow]")
        console.print(f"  [dim]Start the same hive instance to verify historical actions.[/dim]")

    asyncio.run(_run())


@cli.command()
@click.option("--last", default=20, help="Number of entries")
@click.option("--provider", default=None)
def log(last, provider):
    """Show audit chain."""
    async def _run():
        import hashlib
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        entries = list(hive.governance.audit_entries)[-last:]
        if not entries:
            console.print("  [dim]No actions yet.[/dim]")
            return

        t = Table(box=box.SIMPLE, padding=(0,1))
        t.add_column("Worker", style="yellow", width=10)
        t.add_column("Action", style="cyan", width=16)
        t.add_column("Result", width=8)
        t.add_column("Hash", style="dim", width=18)

        for e in reversed(entries):
            ts = e.timestamp.isoformat() if hasattr(e.timestamp, "isoformat") else str(e.timestamp)
            h  = hashlib.sha256(f"{e.agent_id}{e.action}{ts}".encode()).hexdigest()[:16]
            worker = (e.agent_id or "").split("/")[-1].split("@")[0]
            color  = "green" if e.result == "success" else "red"
            t.add_row(worker, e.action, f"[{color}]{e.result}[/{color}]", h + "...")
        console.print(t)

    asyncio.run(_run())


@cli.command()
@click.option("--provider", default=None)
def workers(provider):
    """List active workers + their scopes."""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)
        header()
        for name, w in hive.governance.workers.items():
            status = "[red]REVOKED[/red]" if not w.authorization.is_valid() else "[green]active[/green]"
            scope  = ", ".join(w.identity.scope)
            console.print(f"  {name:12} {status}  [dim]{scope}[/dim]")
        console.print()

    asyncio.run(_run())


@cli.command()
@click.argument("worker_name")
@click.option("--provider", default=None)
def revoke(worker_name, provider):
    """Revoke a worker (LEX §5)."""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)
        hive.governance.revoke_worker(worker_name)
        console.print(f"  [red]✗[/red] Worker '{worker_name}' revoked. LEX §5 applied.")

    asyncio.run(_run())


@cli.command()
@click.argument("text", nargs=-1)
@click.option("--provider", default=None)
def memory(text, provider):
    """Manage sovereign memory. Usage: beeq memory [search query]"""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        if text:
            query   = " ".join(text)
            results = await hive.recall(query)
            if results:
                for r in results:
                    console.print(f"  [{r['id'][:8]}] [dim]{r['content'][:100]}[/dim]")
            else:
                console.print("  [dim]Nothing found.[/dim]")
        else:
            if hive.memory:
                console.print(f"  [dim]{hive.memory.summary()}[/dim]")

    asyncio.run(_run())


@cli.command()
@click.argument("provider_name")
@click.option("--key", default=None, help="API key")
@click.option("--model", default=None, help="Model name")
def connect(provider_name, key, model):
    """Configure LLM provider."""
    import json
    from pathlib import Path

    cfg_path = Path.home() / ".beeq" / "config.json"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(cfg_path.read_text()) if cfg_path.exists() else {}

    cfg["default_provider"] = provider_name
    if "providers" not in cfg:
        cfg["providers"] = {}
    if provider_name not in cfg["providers"]:
        cfg["providers"][provider_name] = {}
    if key:
        cfg["providers"][provider_name]["api_key"] = key
    if model:
        cfg["providers"][provider_name]["model"] = model

    cfg_path.write_text(json.dumps(cfg, indent=2))
    console.print(f"  [green]✓[/green] Provider '{provider_name}' configured.")


@cli.command()
def version():
    """Show BeeQ version."""
    from beeq import __version__
    console.print(f"\n  [bold yellow]BeeQ[/bold yellow] v{__version__}")
    console.print(f"  [dim]https://beeq.run[/dim]\n")


if __name__ == "__main__":
    cli()
