from _typeshed import Incomplete
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DEFAULT_REDIS_FILTER_QUERY_NUM_RESULTS as DEFAULT_REDIS_FILTER_QUERY_NUM_RESULTS, DefaultBatchSize as DefaultBatchSize, FIELD_CONFIG_NAME as FIELD_CONFIG_NAME, FIELD_CONFIG_TYPE as FIELD_CONFIG_TYPE
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.vector_capability import BaseVectorCapability as BaseVectorCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.redis.query import build_filter_expression as build_filter_expression, check_index_exists as check_index_exists, fetch_hash_data_batch as fetch_hash_data_batch, get_filterable_fields_from_index as get_filterable_fields_from_index, infer_filterable_fields_from_chunks as infer_filterable_fields_from_chunks, normalize_field_name_for_schema as normalize_field_name_for_schema, parse_redisvl_result_to_chunks as parse_redisvl_result_to_chunks, prepare_chunk_document as prepare_chunk_document, process_update_batch as process_update_batch, strip_index_prefix as strip_index_prefix, validate_chunk_content as validate_chunk_content, validate_metadata_fields as validate_metadata_fields
from gllm_datastore.data_store.redis.query_translator import RedisQueryTranslator as RedisQueryTranslator
from gllm_datastore.utils.converter import cosine_distance_to_similarity_score as cosine_distance_to_similarity_score
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from redis.asyncio.client import Redis
from typing import Any

class RedisVectorCapability(BaseVectorCapability):
    """Redis implementation of VectorCapability protocol.

    This class provides vector similarity search operations using RedisVL
    AsyncSearchIndex for vector storage and retrieval.

    Attributes:
        index_name (str): Name of the Redis index.
        client (Redis): Redis async client instance.
        em_invoker (BaseEMInvoker): Embedding model for vectorization.
        index (Any): RedisVL AsyncSearchIndex instance.
    """
    index_name: Incomplete
    client: Incomplete
    index: AsyncSearchIndex
    def __init__(self, index_name: str, client: Redis, em_invoker: BaseEMInvoker, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the Redis vector capability.

        Schema will be automatically inferred from chunks when creating a new index,
        or auto-detected from an existing index when performing operations.

        Args:
            index_name (str): Name of the Redis index.
            client (Redis): Redis async client instance.
            em_invoker (BaseEMInvoker): Embedding model for vectorization.
            encryption (EncryptionCapability | None, optional): Encryption capability for field-level
                encryption. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for create/update. Defaults to None.
        """
    async def ensure_index(self, filterable_fields: list[dict[str, Any]] | None = None, **kwargs: Any) -> None:
        '''Ensure Redis vector index exists, creating it if necessary.

        This method is idempotent - if the index already exists, it will skip creation
        and return early.

        Args:
            filterable_fields (list[dict[str, Any]] | None, optional): List of filterable field
                configurations to use when creating a new index. Each field should be a dictionary
                with "name" and "type" keys. For example:
                [{"name": "metadata.category", "type": "tag"}, {"name": "metadata.score", "type": "numeric"}]
                If not provided and index doesn\'t exist, a default schema will be created with
                only basic fields (id, content, metadata, vector). Defaults to None.
            **kwargs (Any): Additional keyword arguments (e.g. from base capability interface);
                Unused in this implementation.

        Raises:
            RuntimeError: If index creation fails.
        '''
