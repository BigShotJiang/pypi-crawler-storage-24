from _typeshed import Incomplete
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DefaultBatchSize as DefaultBatchSize, FIELD_CONFIG_NAME as FIELD_CONFIG_NAME, FIELD_CONFIG_TYPE as FIELD_CONFIG_TYPE, FieldType as FieldType
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.fulltext_capability import BaseFulltextCapability as BaseFulltextCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.redis.query import apply_query_options as apply_query_options, check_index_exists as check_index_exists, delete_keys_batched as delete_keys_batched, execute_query as execute_query, get_doc_ids_for_deletion as get_doc_ids_for_deletion, get_filterable_fields_from_index as get_filterable_fields_from_index, infer_filterable_fields_from_chunks as infer_filterable_fields_from_chunks, normalize_field_name_for_schema as normalize_field_name_for_schema, parse_redis_documents as parse_redis_documents, prepare_chunk_document as prepare_chunk_document, process_update_batch as process_update_batch, sanitize_key as sanitize_key, strip_index_prefix as strip_index_prefix, validate_chunk_content as validate_chunk_content, validate_metadata_fields as validate_metadata_fields
from gllm_datastore.data_store.redis.query_translator import RedisQueryTranslator as RedisQueryTranslator
from redis.asyncio.client import Redis

FUZZY_MATCH_MAX_DISTANCE: int

class RedisFulltextCapability(BaseFulltextCapability):
    """Redis implementation of FulltextCapability protocol.

    Attributes:
        index_name (str): Name of the Redis index.
        client (Redis): Redis client instance.
    """
    index_name: Incomplete
    client: Incomplete
    def __init__(self, index_name: str, client: Redis, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the Redis fulltext capability.

        Schema will be automatically inferred from chunks when creating a new index,
        or auto-detected from an existing index when performing operations.

        Args:
            index_name (str): Name of the Redis index.
            client (Redis): Redis client instance.
            encryption (EncryptionCapability | None, optional): Encryption capability for field-level
                encryption. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for create/update/delete.
                Defaults to None.
        """
