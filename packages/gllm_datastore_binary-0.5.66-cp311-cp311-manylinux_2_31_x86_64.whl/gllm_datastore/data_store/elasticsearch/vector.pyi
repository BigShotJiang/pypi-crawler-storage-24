from _typeshed import Incomplete
from elasticsearch import AsyncElasticsearch
from gllm_core.schema import Chunk as Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DEFAULT_FETCH_K as DEFAULT_FETCH_K, DEFAULT_TOP_K as DEFAULT_TOP_K
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.vector_capability import BaseVectorCapability as BaseVectorCapability
from gllm_datastore.core.filters.schema import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store._elastic_core.elastic_like_core import ElasticLikeCore as ElasticLikeCore
from gllm_datastore.data_store.elasticsearch.query import delete_by_id as delete_by_id, delete_by_query as delete_by_query, translate_filter as translate_filter
from gllm_datastore.data_store.elasticsearch.query_translator import ElasticsearchQueryTranslator as ElasticsearchQueryTranslator
from gllm_datastore.utils.converter import from_langchain as from_langchain
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from langchain_elasticsearch.vectorstores import AsyncRetrievalStrategy
from typing import Any

class ElasticsearchVectorCapability(BaseVectorCapability, ElasticLikeCore):
    """Elasticsearch implementation of VectorCapability protocol.

    This class provides document CRUD operations and vector search using Elasticsearch.

    Attributes:
        index_name (str): The name of the Elasticsearch index.
        vector_store (AsyncElasticsearchStore): The vector store instance.
        em_invoker (BaseEMInvoker): The embedding model to perform vectorization.
    """
    vector_store: Incomplete
    def __init__(self, index_name: str, client: AsyncElasticsearch, em_invoker: BaseEMInvoker, query_field: str = 'text', vector_query_field: str = 'vector', retrieval_strategy: AsyncRetrievalStrategy | None = None, distance_strategy: str | None = None, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        '''Initialize the Elasticsearch vector capability.

        Args:
            index_name (str): The name of the Elasticsearch index.
            client (AsyncElasticsearch): The Elasticsearch client.
            em_invoker (BaseEMInvoker): The embedding model to perform vectorization.
            query_field (str, optional): The field name for text queries. Defaults to "text".
            vector_query_field (str, optional): The field name for vector queries. Defaults to "vector".
            retrieval_strategy (AsyncRetrievalStrategy | None, optional): The retrieval strategy for retrieval.
                Defaults to None, in which case DenseVectorStrategy() is used.
            distance_strategy (str | None, optional): The distance strategy for retrieval. Defaults to None.
            encryption (EncryptionCapability | None, optional): Encryption capability for field-level
                encryption. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for operations. Defaults to None.
        '''
    async def ensure_index(self, mapping: dict[str, Any] | None = None, index_settings: dict[str, Any] | None = None, dimension: int | None = None, distance_strategy: str | None = None, **kwargs: Any) -> None:
        '''Ensure Elasticsearch index exists, creating it if necessary.

        This method is idempotent - if the index already exists, it will skip creation
        and return early.

        Args:
            mapping (dict[str, Any] | None, optional): Custom mapping dictionary to use
                for index creation. If provided, this mapping will be used directly.
                The mapping should follow Elasticsearch mapping format. Defaults to None,
                in which default mapping will be used.
            index_settings (dict[str, Any] | None, optional): Custom index settings.
                These settings will be merged with any default settings. Defaults to None.
            dimension (int | None, optional): Vector dimension. If not provided and mapping
                is not provided, will be inferred from em_invoker by generating a test embedding.
            distance_strategy (str | None, optional): Distance strategy for vector similarity.
                Supported values: "cosine", "l2_norm", "dot_product", etc.
                Only used when building default mapping. Defaults to "cosine" if not specified.
            **kwargs (Any): Additional arguments.

        Raises:
            ValueError: If mapping is invalid or required parameters are missing.
            RuntimeError: If index creation fails due to backend errors.
        '''
    async def delete_by_id(self, id_: str | list[str], **kwargs: Any) -> None:
        """Deletes records from the data store based on IDs.

        Args:
            id_ (str | list[str]): ID or list of IDs to delete.
            **kwargs (Any): Additional arguments.
        """
