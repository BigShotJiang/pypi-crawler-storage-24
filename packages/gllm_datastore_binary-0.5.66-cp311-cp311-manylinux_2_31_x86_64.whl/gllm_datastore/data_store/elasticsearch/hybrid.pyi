from elasticsearch import AsyncElasticsearch
from gllm_core.schema import Chunk as Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DEFAULT_TOP_K as DEFAULT_TOP_K, METADATA_KEYS as METADATA_KEYS
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.hybrid_capability import BaseHybridCapability as BaseHybridCapability, HybridSearchType as HybridSearchType, SearchConfig as SearchConfig
from gllm_datastore.core.filters.schema import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store._elastic_core.elastic_like_core import ElasticLikeCore as ElasticLikeCore
from gllm_datastore.data_store.elasticsearch.query import apply_filters_and_options as apply_filters_and_options, delete_by_query as delete_by_query, translate_filter as translate_filter
from gllm_datastore.data_store.elasticsearch.query_translator import ElasticsearchQueryTranslator as ElasticsearchQueryTranslator
from gllm_inference.schema import Vector as Vector
from opensearchpy import AsyncOpenSearch
from typing import Any

KNN_NUM_CANDIDATES_MULTIPLIER: int

class ElasticsearchHybridCapability(ElasticLikeCore, BaseHybridCapability):
    """Elasticsearch implementation of HybridCapability using weighted score boosting.

    Combines fulltext (BM25) and vector (dense) retrieval in a single query.
    Final score = sum(weight_i * score_i) for each configured search type.
    """
    backend_package: str
    backend_extra: str
    query_translator_cls = ElasticsearchQueryTranslator
    client: AsyncElasticsearch | AsyncOpenSearch
    def __init__(self, index_name: str, client: AsyncElasticsearch | AsyncOpenSearch, config: list[SearchConfig], encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        '''Initialize the Elasticsearch hybrid capability.

        Examples:
            ```python
            from gllm_datastore.data_store.elasticsearch.hybrid import ElasticsearchHybridCapability
            from gllm_datastore.core.capabilities.hybrid_capability import HybridSearchType, SearchConfig

            config = [
                SearchConfig(HybridSearchType.FULLTEXT, field="text", weight=0.3),
                SearchConfig(HybridSearchType.VECTOR, field="embedding", weight=0.7, em_invoker=em_invoker),
            ]
            capability = ElasticsearchHybridCapability(
                index_name="my_index",
                client=es_client,
                config=config,
            )
            ```

        Args:
            index_name (str): The name of the Elasticsearch index.
            client (AsyncElasticsearch | AsyncOpenSearch): Elastic-like async client used by
                inherited hybrid operations.
            config (list[SearchConfig]): List of search configurations (FULLTEXT and/or VECTOR).
            encryption (EncryptionCapability | None, optional): Encryption capability.
                Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.
        '''
    @property
    def fulltext_configs(self) -> list[SearchConfig]:
        """Return configs for FULLTEXT search type."""
    @property
    def vector_configs(self) -> list[SearchConfig]:
        """Return configs for VECTOR search type."""
    async def create(self, chunks: list[Chunk], batch_size: int | None = None, **kwargs: Any) -> None:
        """Create chunks with automatic generation of all configured search fields.

        Overrides BaseHybridCapability.create to perform enrichment (embedding generation)
        before encryption and storage.

        Args:
            chunks (list[Chunk]): List of chunks to create and index.
            batch_size (int | None, optional): Batch size for creation. Defaults to None.
            **kwargs (Any): Extra arguments passed through to the Elasticsearch bulk API.
        """
    async def update(self, update_values: dict[str, Any], filters: FilterClause | QueryFilter | None = None, batch_size: int | None = None, **kwargs: Any) -> None:
        '''Update existing records in the datastore.

        1. Vector configs: For each VECTOR config whose field is being updated, generate
            embeddings from the **plaintext** source (content/text/fulltext field). Embeddings
            must be produced before encryption so the model sees plaintext.
        2. Encryption: Encrypt all update values (content and metadata) using the
            encryption config. Vector fields are not encrypted; only content and metadata
            are. This step runs after enrichment so we never embed from encrypted text.


        Examples:
            ```python
            from gllm_datastore.core.filters import filter as F

            await hybrid_capability.update(
                update_values={"text": "Updated content"},
                filters=F.eq("metadata.source", "doc1"),
            )
            await hybrid_capability.update(
                update_values={"metadata": {"status": "published"}},
                filters=F.eq("id", "chunk_1"),
            )
            ```

        Args:
            update_values (dict[str, Any]): Fields to update (e.g. text, content,
                metadata). When text or content is present, vector fields from
                the hybrid config are re-embedded and included automatically.
            filters (FilterClause | QueryFilter | None, optional): Filter to
                select which records to update. No filter means no documents
                match. Defaults to None.
            batch_size (int | None, optional): Batch size for update operations. Defaults to None.
            **kwargs (Any): Extra arguments passed through to the Elasticsearch
                update_by_query API (e.g. refresh, timeout). No default.
        '''
