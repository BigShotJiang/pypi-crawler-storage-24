from elasticsearch import AsyncElasticsearch
from elasticsearch.dsl import AsyncSearch
from elasticsearch.dsl.query import Query
from gllm_datastore.core.filters.schema import QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.elasticsearch.query_translator import ElasticsearchQueryTranslator as ElasticsearchQueryTranslator

def apply_filters_and_options(search: AsyncSearch, filters: QueryFilter | None = None, options: QueryOptions | None = None) -> AsyncSearch:
    """Apply filters and options to an Elasticsearch search object.

    Args:
        search (AsyncSearch): Elasticsearch search object.
        filters (QueryFilter | None, optional): New QueryFilter with filters and condition.
        options (QueryOptions | None, optional): Query options (limit, sort, fields).

    Returns:
        AsyncSearch: Elasticsearch search object.
    """
def translate_filter(filters: QueryFilter | None) -> Query | None:
    """Translate a structured QueryFilter into an Elasticsearch DSL Query.

    The translation supports comparison operators (EQ, NE, GT, LT, GTE, LTE),
    array operators (IN, NIN, ARRAY_CONTAINS, ANY, ALL), text operators (TEXT_CONTAINS),
    and logical conditions (AND, OR, NOT), including nested filters.

    Args:
        filters (QueryFilter | None): Structured QueryFilter. If None, returns None.

    Returns:
        Query | None: An Elasticsearch Query object or None if no filters are provided.

    Raises:
        ValueError: When the filter structure is invalid.
        TypeError: When an operator-value type combination is invalid.
    """
async def delete_by_query(client: AsyncElasticsearch, index_name: str, filters: QueryFilter | None = None) -> None:
    """Delete records from Elasticsearch using delete_by_query.

    Args:
        client (AsyncElasticsearch): Elasticsearch client instance.
        index_name (str): The name of the Elasticsearch index.
        filters (QueryFilter | None, optional): New QueryFilter to select records for deletion.
            Defaults to None, in which case no operation will be performed.
    """
async def delete_by_id(client: AsyncElasticsearch, index_name: str, ids: str | list[str]) -> None:
    """Delete records from Elasticsearch by IDs using Search.delete().

    Args:
        client (AsyncElasticsearch): Elasticsearch client instance.
        index_name (str): The name of the Elasticsearch index.
        ids (str | list[str]): ID or list of IDs to delete.
    """
def create_search_with_filters(client: AsyncElasticsearch, index_name: str, filters: QueryFilter | None = None, exclude_fields: list[str] | None = None) -> AsyncSearch:
    """Create an AsyncSearch object with optional filters and field exclusions.

    Args:
        client (AsyncElasticsearch): Elasticsearch client instance.
        index_name (str): The name of the Elasticsearch index.
        filters (QueryFilter | None, optional): New QueryFilter to apply. Defaults to None.
        exclude_fields (list[str] | None, optional): Fields to exclude from source. Defaults to None.

    Returns:
        AsyncSearch: Configured AsyncSearch object.
    """
def apply_filter_query_to_search(search: AsyncSearch, main_query: Query, filters: QueryFilter | None = None) -> AsyncSearch:
    """Apply filter query to a search with a main query.

    Args:
        search (AsyncSearch): Elasticsearch search object.
        main_query (Query): The main query to apply.
        filters (QueryFilter | None, optional): Query filters to apply. Defaults to None.

    Returns:
        AsyncSearch: Search object with applied queries.
    """
