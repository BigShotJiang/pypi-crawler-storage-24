from _typeshed import Incomplete
from chromadb import ClientAPI
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, METADATA_KEYS as METADATA_KEYS
from gllm_datastore.core.capabilities import DataStoreCapability as DataStoreCapability
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.fulltext_capability import BaseFulltextCapability as BaseFulltextCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.chroma._chroma_import import safe_import_chromadb as safe_import_chromadb
from gllm_datastore.data_store.chroma.query import ChromaCollectionKeys as ChromaCollectionKeys, DEFAULT_NUM_CANDIDATES as DEFAULT_NUM_CANDIDATES, build_chroma_delete_kwargs as build_chroma_delete_kwargs, build_chroma_get_kwargs as build_chroma_get_kwargs, sanitize_metadata as sanitize_metadata
from gllm_datastore.data_store.chroma.query_translator import ChromaQueryTranslator as ChromaQueryTranslator

chromadb: Incomplete

class ChromaFulltextCapability(BaseFulltextCapability):
    """ChromaDB implementation of FulltextCapability protocol.

    This class provides document CRUD operations and text search using ChromaDB.

    Attributes:
        collection_name (str): The name of the ChromaDB collection.
        client (ClientAPI): ChromaDB client instance.
        collection: ChromaDB collection instance.
        num_candidates (int): Maximum number of candidates to consider during search.
    """
    collection_name: Incomplete
    client: Incomplete
    collection: Incomplete
    num_candidates: Incomplete
    def __init__(self, collection_name: str, client: ClientAPI, num_candidates: int = ..., encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the ChromaDB fulltext capability.

        Args:
            collection_name (str): The name of the ChromaDB collection.
            client (ClientAPI): ChromaDB client instance.
            num_candidates (int, optional): Maximum number of candidates to consider during search.
                Defaults to DEFAULT_NUM_CANDIDATES.
            encryption (EncryptionCapability | None, optional): Encryption capability for field-level
                encryption. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for batching operations.
                Defaults to None.
        """
    def get_size(self) -> int:
        """Returns the total number of documents in the collection.

        Returns:
            int: The total number of documents.
        """
