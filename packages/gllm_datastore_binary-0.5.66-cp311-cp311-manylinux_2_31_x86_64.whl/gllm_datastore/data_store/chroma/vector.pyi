from _typeshed import Incomplete
from chromadb import ClientAPI
from gllm_core.schema import Chunk as Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DEFAULT_TOP_K as DEFAULT_TOP_K, METADATA_KEYS as METADATA_KEYS
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.vector_capability import BaseVectorCapability as BaseVectorCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.chroma._chroma_import import safe_import_chromadb as safe_import_chromadb
from gllm_datastore.data_store.chroma.query import ChromaCollectionKeys as ChromaCollectionKeys, DEFAULT_NUM_CANDIDATES as DEFAULT_NUM_CANDIDATES, build_chroma_delete_kwargs as build_chroma_delete_kwargs, build_chroma_get_kwargs as build_chroma_get_kwargs, sanitize_metadata as sanitize_metadata
from gllm_datastore.data_store.chroma.query_translator import ChromaQueryTranslator as ChromaQueryTranslator
from gllm_datastore.utils.converter import from_langchain as from_langchain, l2_distance_to_similarity_score as l2_distance_to_similarity_score
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from typing import Any

chromadb: Incomplete

class ChromaVectorCapability(BaseVectorCapability):
    """ChromaDB implementation of VectorCapability protocol.

    This class provides document CRUD operations and vector search using ChromaDB.

    Attributes:
        collection_name (str): The name of the ChromaDB collection.
        collection (Collection): The ChromaDB collection instance.
        vector_store (Chroma): The langchain Chroma vector store instance.
        num_candidates (int): The maximum number of candidates to consider during search.
    """
    collection_name: Incomplete
    client: Incomplete
    collection: Incomplete
    num_candidates: Incomplete
    vector_store: Incomplete
    def __init__(self, collection_name: str, em_invoker: BaseEMInvoker, client: ClientAPI, num_candidates: int = ..., encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the ChromaDB vector capability.

        Args:
            collection_name (str): The name of the ChromaDB collection.
            em_invoker (BaseEMInvoker): The embedding model to perform vectorization.
            client (ClientAPI): The ChromaDB client instance.
            num_candidates (int, optional): Maximum number of candidates to consider during search.
                Defaults to 50.
            encryption (EncryptionCapability | None, optional): Encryption capability for field-level
                encryption. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for batching operations.
                Defaults to None.
        """
    async def ensure_index(self, **kwargs: Any) -> None:
        """Ensure ChromaDB collection exists, creating it if necessary.

        This method is idempotent - if the collection already exists, it will return
        the existing collection. The collection is automatically created during initialization,
        but this method can be called explicitly to ensure it exists.

        Args:
            **kwargs (Any): Unused; for interface compatibility.

        Raises:
            RuntimeError: If collection creation fails.
        """
