from _typeshed import Incomplete
from gllm_core.schema.chunk import Chunk as Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.vector_capability import BaseVectorCapability as BaseVectorCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.postgresql.query_translator import PostgreSQLQueryTranslator as PostgreSQLQueryTranslator
from gllm_datastore.data_store.postgresql.utils import validate_sql_identifier as validate_sql_identifier, vector_to_pg_text as vector_to_pg_text
from gllm_datastore.data_store.sql.constants import SQL_COLUMNS as SQL_COLUMNS
from gllm_datastore.data_store.sql.query import execute_update_with_filters as execute_update_with_filters, row_to_chunk as row_to_chunk
from gllm_datastore.utils.converter import cosine_distance_to_similarity_score as cosine_distance_to_similarity_score
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from sqlalchemy.ext.asyncio import AsyncEngine
from typing import Any

DEFAULT_VECTOR_TOP_K: int

class PostgreSQLVectorCapability(BaseVectorCapability):
    """PostgreSQL implementation of VectorCapability protocol using pgvector.

    This capability uses async SQLAlchemy with the pgvector extension for
    vector storage and cosine-distance similarity search. It operates on the
    same table as the fulltext capability (id, content, metadata) plus an
    embedding column of type vector(embedding_dimension).

    Attributes:
        engine (AsyncEngine): SQLAlchemy async engine instance.
        table_name (str): Name of the table this capability operates on.
        embedding_column (str): Name of the vector column.
        embedding_dimension (int): Dimension of the embedding vectors.
        session_factory (async_sessionmaker): Async session factory.
    """
    engine: Incomplete
    table_name: Incomplete
    embedding_column: Incomplete
    embedding_dimension: Incomplete
    session_factory: Incomplete
    def __init__(self, engine: AsyncEngine, table_name: str, embedding_column: str, embedding_dimension: int, em_invoker: BaseEMInvoker, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the PostgreSQL vector capability.

        Args:
            engine (AsyncEngine): SQLAlchemy async engine instance.
            table_name (str): Name of the table this capability operates on.
            embedding_column (str): Name of the embedding column for vector operations.
            embedding_dimension (int): Dimension of the embedding vectors.
            em_invoker (BaseEMInvoker): Embedding model for vectorization.
            encryption (EncryptionCapability | None, optional): Encryption capability.
                Defaults to None.
            default_batch_size (int | None, optional): Default batch size for create/update.
                Defaults to None.
        """
    async def ensure_index(self, **kwargs: Any) -> None:
        """Ensure pgvector extension and embedding column exist.

        Creates the vector extension if not present and adds the embedding
        column to the table if it does not exist. Idempotent.

        Args:
            **kwargs (Any): Datastore-specific parameters (unused, kept for compatibility
                with base class interface).
        """
