from _typeshed import Incomplete
from gllm_datastore.data_store.base import CapabilityType as CapabilityType
from gllm_datastore.data_store.postgresql.fulltext import PostgreSQLFulltextCapability as PostgreSQLFulltextCapability
from gllm_datastore.data_store.postgresql.query_translator import PostgreSQLQueryTranslator as PostgreSQLQueryTranslator
from gllm_datastore.data_store.postgresql.vector import PostgreSQLVectorCapability as PostgreSQLVectorCapability
from gllm_datastore.data_store.sql.data_store import SQLDataStore as SQLDataStore
from gllm_datastore.encryptor.encryptor import BaseEncryptor as BaseEncryptor
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from sqlalchemy import URL
from sqlalchemy.ext.asyncio import AsyncEngine
from typing import Any

class PostgreSQLDataStore(SQLDataStore):
    """PostgreSQL datastore with fulltext and vector capabilities.

    This data store extends SQLDataStore to provide PostgreSQL-specific features
    including pgvector support for vector operations. It follows the same architecture
    as SQLDataStore with PostgreSQL-specific optimizations. get_size and
    translate_query_filter use PostgreSQLQueryTranslator for JSONB-aware filter handling.

    Attributes:
        engine (AsyncEngine): SQLAlchemy async engine instance. Can be shared across
            multiple PostgreSQLDataStore instances for different tables with single connection pool.
        table_name (str): Name of the table this instance operates on. This is immutable
            after construction and defines the scope of all operations.
        embedding_column (str): Name of the embedding column for vector operations.
        embedding_dimension (int): Dimension of the embedding vectors.
    """
    query_translator_class = PostgreSQLQueryTranslator
    embedding_column: Incomplete
    embedding_dimension: Incomplete
    def __init__(self, engine_or_url: AsyncEngine | str | URL, pool_size: int = 10, max_overflow: int = 10, table_name: str = 'chunks', embedding_column: str = 'embedding', embedding_dimension: int = 1536, **engine_kwargs: Any) -> None:
        '''Initialize PostgreSQLDataStore with async engine and pgvector setup.

        Args:
            engine_or_url (AsyncEngine | str | URL): AsyncEngine instance, database URL string, or URL object.
                For async support, async drivers are automatically added if not specified.
                PostgreSQL: "postgresql://..." -> "postgresql+asyncpg://..."
            pool_size (int, optional): The size of the database connection pool. Defaults to 10.
                Only used when creating a new engine from a URL. Ignored if AsyncEngine is provided.
            max_overflow (int, optional): The maximum overflow size of the pool. Defaults to 10.
                Only used when creating a new engine from a URL. Ignored if AsyncEngine is provided.
            table_name (str, optional): Name of the table this instance will operate on. Defaults to "chunks".
                This defines the scope of all operations for this instance and cannot be changed after construction.
            embedding_column (str, optional): Name of the embedding column for vector operations.
                Defaults to "embedding".
            embedding_dimension (int, optional): Dimension of the embedding vectors. Defaults to 1536.
            **engine_kwargs (Any, optional): Additional keyword arguments for create_async_engine.
                Only used when creating a new engine from a URL.

        Raises:
            ValueError: If the database engine initialization fails or if engine_kwargs
                contains pool-related parameters that conflict with pool_size/max_overflow.
        '''
    @property
    def supported_capabilities(self) -> list[CapabilityType]:
        """Return list of currently supported capabilities.

        Returns:
            list[CapabilityType]: List of capability names that are supported.
        """
    @property
    def fulltext(self) -> PostgreSQLFulltextCapability:
        """Access fulltext capability if registered.

        This method overrides the parent class to return PostgreSQLFulltextCapability for better type hinting.

        Returns:
            PostgreSQLFulltextCapability: Fulltext capability handler.

        Raises:
            NotRegisteredException: If fulltext capability is not registered.
        """
    @property
    def vector(self) -> PostgreSQLVectorCapability:
        """Access vector capability if registered.

        This method overrides the parent class to return PostgreSQLVectorCapability for better type hinting.

        Returns:
            PostgreSQLVectorCapability: Vector capability handler.

        Raises:
            NotRegisteredException: If vector capability is not registered.
        """
    def with_fulltext(self) -> PostgreSQLDataStore:
        '''Configure fulltext capability and return datastore instance.

        Examples:
            ```python
            # Enable fulltext
            datastore.with_fulltext()

            # For multiple tables with shared engine
            engine = create_async_engine("postgresql+asyncpg://...")
            chunks_store = PostgreSQLDataStore(engine, table_name="chunks")
            users_store = PostgreSQLDataStore(engine, table_name="users")
            chunks_store.with_fulltext()
            users_store.with_fulltext()
            ```

        Returns:
            PostgreSQLDataStore: Self for method chaining.
        '''
    def with_encryption(self, encryptor: BaseEncryptor, fields: set[str] | list[str]) -> PostgreSQLDataStore:
        """Enable encryption for specified fields.

        Note:
            Encrypted fields (content and metadata fields specified in encryption configuration)
            must be serializable to strings. Non-string values will be converted to strings
            before encryption.

        Warning:
            When encryption is enabled for fields, some search and filter operations may be
            limited or broken. Encrypted fields cannot be used in filters for update or delete
            operations. Use non-encrypted fields (like 'id') for filtering when working with
            encrypted data.

        Args:
            encryptor (BaseEncryptor): The encryptor instance to use. Must not be None.
            fields (set[str] | list[str]): Set or list of field names to encrypt. Must not be empty.

        Returns:
            PostgreSQLDataStore: Self instance for method chaining.

        Raises:
            ValueError: If encryptor is None or fields is empty.
        """
    def with_vector(self, em_invoker: BaseEMInvoker, **kwargs: Any) -> PostgreSQLDataStore:
        """Configure vector capability and return datastore instance.

        Args:
            em_invoker (BaseEMInvoker): Embedding model invoker (required).
            **kwargs: Vector capability configuration parameters.

        Returns:
            PostgreSQLDataStore: Self for method chaining.
        """
