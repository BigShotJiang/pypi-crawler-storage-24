from gllm_datastore.core.filters import FilterClause as FilterClause, FilterOperator as FilterOperator
from gllm_datastore.data_store.sql.query_translator import SQLQueryTranslator as SQLQueryTranslator

class PostgreSQLQueryTranslator(SQLQueryTranslator):
    """PostgreSQL-specific query translator extending SQLQueryTranslator.

    This translator provides PostgreSQL-specific features such as JSONB operators
    and PostgreSQL-specific filter handling while maintaining compatibility with
    the base SQLQueryTranslator.
    """
