from _typeshed import Incomplete
from gllm_inference.schema import Vector

VALID_SQL_IDENTIFIER: Incomplete

def vector_to_pg_text(vector: Vector | list[float]) -> str:
    """Format a vector as pgvector text literal so asyncpg accepts it without type codec.

    Args:
        vector (Vector | list[float]): Embedding vector.

    Returns:
        str: String in form '[1.0,2.0,...]' that PostgreSQL casts to vector.
    """
def validate_sql_identifier(name: str, kind: str) -> None:
    """Ensure a string is a safe SQL identifier to prevent injection.

    Args:
        name (str): Identifier value (e.g. table or column name).
        kind (str): Label for error message (e.g. 'table_name').

    Raises:
        ValueError: If name is empty or contains disallowed characters.
    """
