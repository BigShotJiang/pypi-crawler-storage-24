from _typeshed import Incomplete
from elasticsearch import AsyncElasticsearch
from elasticsearch.dsl import AsyncSearch, AttrDict as ESAttrDict
from gllm_core.schema import Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS
from gllm_datastore.core import QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store._elastic_core.constants import ELASTIC_RESPONSE_KEYS as ELASTIC_RESPONSE_KEYS, VALID_FIELD_PATH as VALID_FIELD_PATH
from gllm_datastore.data_store._elastic_core.query_translator import ElasticLikeQueryTranslator as ElasticLikeQueryTranslator
from gllm_datastore.utils import flatten_dict as flatten_dict
from opensearchpy import AsyncOpenSearch
from opensearchpy.helpers.utils import AttrDict as OSAttrDict
from typing import Any

AttrDict = ESAttrDict | OSAttrDict

class ElasticLikeCore:
    """Shared core implementation for Elasticsearch-like datastores.

    This class contains the common logic shared between Elasticsearch and OpenSearch.
    Product-specific datastores delegate to this core and override methods where needed.

    Attributes:
        index_name (str): The name of the index used for all operations.
        client (AsyncElasticsearch | AsyncOpenSearch): The Elasticsearch or OpenSearch client.
            Used for all index and document operations.
    """
    index_name: Incomplete
    client: Incomplete
    def __init__(self, index_name: str, client: AsyncElasticsearch | AsyncOpenSearch) -> None:
        """Initialize the shared core.

        Args:
            index_name (str): The name of the index to use for operations.
                This index name will be used for all queries and operations.
            client (AsyncElasticsearch | AsyncOpenSearch): The Elasticsearch or OpenSearch client.
                Must be a properly configured async client instance.
        """
    async def check_index_exists(self) -> bool:
        """Check if index exists.

        Returns:
            bool: True if the index exists, False otherwise.
        """
    async def get_index_count(self) -> int:
        """Get document count for the index.

        Returns:
            int: The total number of documents in the index.
        """
    async def get_index_count_with_filters(self, query: dict[str, Any] | None = None) -> int:
        """Get document count for the index with optional query filters.

        Args:
            query (dict[str, Any] | None, optional): Elasticsearch/OpenSearch query DSL.
                If None, returns total count. Defaults to None.

        Returns:
            int: The total number of documents matching the query.
        """
    def create_chunks_from_hits(self, hits: list[AttrDict], query_field: str = ...) -> list[Chunk]:
        """Create Chunk objects from Elasticsearch/OpenSearch hits.

        This method processes hits from Elasticsearch/OpenSearch DSL responses where hits are AttrDict
        objects (from elasticsearch.dsl or opensearchpy.helpers.utils). The _source field is accessed via
        attribute access and is always an AttrDict (nested dicts are automatically wrapped by _wrap function).

        Args:
            hits (list[AttrDict]): List of Elasticsearch/OpenSearch hits as AttrDict objects.
            query_field (str, optional): The field name to use for text content. Defaults to CHUNK_KEYS.TEXT.

        Returns:
            list[Chunk]: List of Chunk objects.
        """
    @staticmethod
    def extract_response_suggestions(response: dict[str, Any], suggestion_key: str) -> list[str]:
        """Extract suggestions from Elasticsearch/OpenSearch autocomplete response.

        Args:
            response (dict[str, Any]): Elasticsearch/OpenSearch response.
            suggestion_key (str): The suggestion key in the response.

        Returns:
            list[str]: List of suggestions.
        """
    @staticmethod
    def extract_aggregation_buckets(response: dict[str, Any], aggregation_name: str) -> list[str]:
        """Extract bucket keys from Elasticsearch/OpenSearch aggregation response.

        Args:
            response (dict[str, Any]): Elasticsearch/OpenSearch response.
            aggregation_name (str): The aggregation name in the response.

        Returns:
            list[str]: List of bucket keys.
        """
    @staticmethod
    def extract_highlighted_text(response: dict[str, Any], field: str) -> list[str]:
        """Extract highlighted text from Elasticsearch/OpenSearch response.

        Args:
            response (dict[str, Any]): Elasticsearch/OpenSearch response.
            field (str): The field name to extract highlights from.

        Returns:
            list[str]: List of unique highlighted text snippets.
        """
    def validate_bm25_parameters(self, k1: float | None, b: float | None) -> bool:
        """Validate BM25 parameters.

        Args:
            k1 (float | None): BM25 parameter controlling term frequency saturation.
            b (float | None): BM25 parameter controlling document length normalization.

        Returns:
            bool: True if parameters are valid, False otherwise.
        """
    def prepare_update_values(self, update_values: dict[str, Any], query_field: str) -> dict[str, Any]:
        """Prepare update values by handling field swapping.

        Args:
            update_values (dict[str, Any]): Dictionary of values to update.
            query_field (str): The field name used for text queries.

        Returns:
            dict[str, Any]: The prepared update values.
        """
    def validate_query_length(self, query: str, min_length: int = 0, max_length: int | None = None) -> bool:
        """Validate query length against minimum and maximum constraints.

        Args:
            query (str): The query string to validate.
            min_length (int, optional): Minimum required length. Defaults to 0.
            max_length (int | None, optional): Maximum allowed length. Defaults to None.

        Returns:
            bool: True if query is valid, False otherwise.
        """
    async def safe_execute(self, search: AsyncSearch) -> Any | None:
        """Execute an Elasticsearch/OpenSearch DSL search with unified error handling.

        Args:
            search: Elasticsearch/OpenSearch DSL AsyncSearch object.

        Returns:
            The response on success, otherwise None.
        """
