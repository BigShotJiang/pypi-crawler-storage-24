from gllm_datastore.core.filters.schema import QueryFilter as QueryFilter
from gllm_datastore.data_store.opensearch.query_translator import OpenSearchQueryTranslator as OpenSearchQueryTranslator
from opensearchpy import AsyncOpenSearch
from opensearchpy._async.helpers.search import AsyncSearch
from opensearchpy.helpers.query import Query
from typing import Any

async def delete_by_query(client: AsyncOpenSearch, index_name: str, filters: QueryFilter | None = None, **kwargs: Any) -> None:
    """Delete records from OpenSearch using delete_by_query.

    Args:
        client (AsyncOpenSearch): OpenSearch client instance.
        index_name (str): The name of the OpenSearch index.
        filters (QueryFilter | None, optional): QueryFilter to select records for deletion.
            Defaults to None, in which case no operation will be performed.
        **kwargs (Any): Additional arguments passed to client.delete_by_query.
    """
async def delete_by_id(client: AsyncOpenSearch, index_name: str, ids: str | list[str]) -> None:
    """Delete records from OpenSearch by IDs using Search.delete().

    Args:
        client (AsyncOpenSearch): OpenSearch client instance.
        index_name (str): The name of the OpenSearch index.
        ids (str | list[str]): ID or list of IDs to delete.
    """
def create_search_with_filters(client: AsyncOpenSearch, index_name: str, filters: QueryFilter | None = None, exclude_fields: list[str] | None = None) -> AsyncSearch:
    """Create an AsyncSearch object with optional filters and field exclusions.

    Args:
        client (AsyncOpenSearch): OpenSearch client instance.
        index_name (str): The name of the OpenSearch index.
        filters (QueryFilter | None, optional): QueryFilter to apply. Defaults to None.
        exclude_fields (list[str] | None, optional): Fields to exclude from source. Defaults to None.

    Returns:
        AsyncSearch: Configured AsyncSearch object.
    """
def apply_filter_query_to_search(search: AsyncSearch, main_query: Query, filters: QueryFilter | None = None) -> AsyncSearch:
    """Apply filter query to a search with a main query.

    Args:
        search (AsyncSearch): OpenSearch search object.
        main_query (Query): The main query to apply.
        filters (QueryFilter | None, optional): Query filters to apply. Defaults to None.

    Returns:
        AsyncSearch: Search object with applied queries.
    """
