from _typeshed import Incomplete
from enum import StrEnum
from gllm_core.schema import Chunk as Chunk
from gllm_datastore.constants import METADATA_KEYS as METADATA_KEYS
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.fulltext_capability import BaseFulltextCapability as BaseFulltextCapability
from gllm_datastore.core.filters.schema import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store._elastic_core.constants import ELASTIC_RESPONSE_KEYS as ELASTIC_RESPONSE_KEYS
from gllm_datastore.data_store._elastic_core.elastic_like_core import ElasticLikeCore as ElasticLikeCore
from gllm_datastore.data_store.opensearch.query import apply_filter_query_to_search as apply_filter_query_to_search, create_search_with_filters as create_search_with_filters, delete_by_id as delete_by_id, delete_by_query as delete_by_query
from gllm_datastore.data_store.opensearch.query_translator import OpenSearchQueryTranslator as OpenSearchQueryTranslator
from opensearchpy import AsyncOpenSearch
from typing import Any, Literal, overload

class SupportedQueryMethods(StrEnum):
    """Supported query methods for OpenSearch fulltext capability."""
    AUTOCOMPLETE: str
    AUTOSUGGEST: str
    BM25: str
    BY_FIELD: str
    SHINGLES: str

QUERY_REQUIRED_STRATEGIES: Incomplete

class OpenSearchFulltextCapability(ElasticLikeCore, BaseFulltextCapability):
    """OpenSearch implementation of FulltextCapability protocol.

    This class provides document CRUD operations and flexible querying using OpenSearch.

    Attributes:
        index_name (str): The name of the OpenSearch index.
        client (AsyncOpenSearch): AsyncOpenSearch client.
        query_field (str): The field name to use for text content.
    """
    client: AsyncOpenSearch
    def __init__(self, index_name: str, client: AsyncOpenSearch, query_field: str = 'text', encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        '''Initialize the OpenSearch fulltext capability.

        Args:
            index_name (str): The name of the OpenSearch index.
            client (AsyncOpenSearch): The OpenSearch client.
            query_field (str, optional): The field name to use for text content. Defaults to "text".
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.
        '''
    async def get_size(self) -> int:
        """Returns the total number of documents in the index.

        Returns:
            int: The total number of documents in the index.
        """
    @overload
    async def retrieve(self, strategy: Literal[SupportedQueryMethods.BY_FIELD] | None = ..., query: str | None = None, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, **kwargs: Any) -> list[Chunk]: ...
    @overload
    async def retrieve(self, strategy: Literal[SupportedQueryMethods.BM25], query: str, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, k1: float | None = None, b: float | None = None, **kwargs: Any) -> list[Chunk]: ...
    @overload
    async def retrieve(self, strategy: Literal[SupportedQueryMethods.AUTOCOMPLETE], query: str, field: str, size: int = 20, fuzzy_tolerance: int = 1, min_prefix_length: int = 3, filter_query: dict[str, Any] | None = None, **kwargs: Any) -> list[str]: ...
    @overload
    async def retrieve(self, strategy: Literal[SupportedQueryMethods.AUTOSUGGEST], query: str, search_fields: list[str], autocomplete_field: str, size: int = 20, min_length: int = 3, filter_query: dict[str, Any] | None = None, **kwargs: Any) -> list[str]: ...
    @overload
    async def retrieve(self, strategy: Literal[SupportedQueryMethods.SHINGLES], query: str, field: str, size: int = 20, min_length: int = 3, max_length: int = 30, filter_query: dict[str, Any] | None = None, **kwargs: Any) -> list[str]: ...
    async def delete_by_id(self, id_: str | list[str], **kwargs: Any) -> None:
        """Deletes records from the data store based on IDs.

        Args:
            id_ (str | list[str]): The ID or list of IDs to delete.
            **kwargs (Any): Additional arguments.
        """
