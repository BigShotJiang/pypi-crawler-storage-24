from _typeshed import Incomplete
from gllm_core.schema import Chunk as Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DEFAULT_FETCH_K as DEFAULT_FETCH_K, DEFAULT_TOP_K as DEFAULT_TOP_K
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.vector_capability import BaseVectorCapability as BaseVectorCapability
from gllm_datastore.core.filters.schema import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store._elastic_core.elastic_like_core import ElasticLikeCore as ElasticLikeCore
from gllm_datastore.data_store.opensearch.query import delete_by_id as delete_by_id, delete_by_query as delete_by_query
from gllm_datastore.data_store.opensearch.query_translator import OpenSearchQueryTranslator as OpenSearchQueryTranslator
from gllm_datastore.utils.converter import from_langchain as from_langchain
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from opensearchpy import AsyncOpenSearch
from typing import Any

class OpenSearchVectorCapability(BaseVectorCapability, ElasticLikeCore):
    """OpenSearch implementation of VectorCapability protocol.

    This class provides document CRUD operations and vector search using OpenSearch.
    Uses LangChain's OpenSearchVectorSearch for create and retrieve operations,
    and direct OpenSearch client for update and delete operations.

    Attributes:
        index_name (str): The name of the OpenSearch index.
        vector_store (OpenSearchVectorSearch): The vector store instance.
        client (AsyncOpenSearch): AsyncOpenSearch client for direct operations.
        em_invoker (BaseEMInvoker): The embedding model to perform vectorization.
    """
    index_name: Incomplete
    client: Incomplete
    vector_store: Incomplete
    def __init__(self, index_name: str, em_invoker: BaseEMInvoker, client: AsyncOpenSearch, opensearch_url: str | None = None, query_field: str = 'text', vector_query_field: str = 'vector', retrieval_strategy: Any = None, distance_strategy: str | None = None, connection_params: dict[str, Any] | None = None, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        '''Initialize the OpenSearch vector capability.

        OpenSearchVectorSearch creates its own sync and async clients internally
        based on the provided connection parameters. The async client is used
        for operations like update, delete, and clear.

        Args:
            index_name (str): The name of the OpenSearch index.
            em_invoker (BaseEMInvoker): The embedding model to perform vectorization.
            client (AsyncOpenSearch): The OpenSearch client for direct operations.
            opensearch_url (str | None, optional): The URL of the OpenSearch server.
                Used for LangChain\'s OpenSearchVectorSearch initialization.
                If None, will be extracted from client connection info. Defaults to None.
            query_field (str, optional): The field name for text queries. Defaults to "text".
            vector_query_field (str, optional): The field name for vector queries. Defaults to "vector".
            retrieval_strategy: Not used with OpenSearchVectorSearch (kept for API compatibility).
            distance_strategy (str | None, optional): The distance strategy for retrieval.
                For example, "l2" for Euclidean distance, "l2squared" for squared Euclidean distance,
                "cosine" for cosine similarity, etc. Defaults to None.
            connection_params (dict[str, Any] | None, optional): Additional connection parameters
                to override defaults. These will be merged with automatically detected parameters
                (authentication, SSL settings). User-provided params take precedence. Defaults to None.
                Available parameters include:
                1. http_auth (tuple[str, str] | None): HTTP authentication tuple (username, password).
                2. use_ssl (bool): Whether to use SSL/TLS. Defaults to True for HTTPS URLs.
                3. verify_certs (bool): Whether to verify SSL certificates. Defaults to True for HTTPS URLs.
                4. ssl_show_warn (bool): Whether to show SSL warnings. Defaults to True for HTTPS URLs.
                5. ssl_assert_hostname (str | None): SSL hostname assertion. Defaults to None.
                6. max_retries (int): Maximum number of retries for requests. Defaults to 3.
                7. retry_on_timeout (bool): Whether to retry on timeouts. Defaults to True.
                8. client_cert (str | None): Path to the client certificate file. Defaults to None.
                9. client_key (str | None): Path to the client private key file. Defaults to None.
                10. root_cert (str | None): Path to the root certificate file. Defaults to None.
                11. Additional kwargs: Any other parameters accepted by OpenSearch client constructor.
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.
        '''
    async def ensure_index(self, mapping: dict[str, Any] | None = None, index_settings: dict[str, Any] | None = None, dimension: int | None = None, distance_strategy: str | None = None, **kwargs: Any) -> None:
        '''Ensure OpenSearch index exists, creating it if necessary.

        This method is idempotent - if the index already exists, it will skip creation
        and return early.

        Args:
            mapping (dict[str, Any] | None, optional): Custom mapping dictionary to use
                for index creation. If provided, this mapping will be used directly.
                The mapping should follow OpenSearch mapping format. Defaults to None,
                in which default mapping will be used.
            index_settings (dict[str, Any] | None, optional): Custom index settings.
                These settings will be merged with any default settings. Defaults to None.
            dimension (int | None, optional): Vector dimension. If not provided and mapping
                is not provided, will be inferred from em_invoker by generating a test embedding.
            distance_strategy (str | None, optional): Distance strategy for vector similarity.
                Supported values: "l2", "l2squared", "cosine", "innerproduct", etc.
                Only used when building default mapping. Defaults to "l2" if not specified.
            **kwargs (Any): Additional arguments.

        Raises:
            ValueError: If mapping is invalid or required parameters are missing.
            RuntimeError: If index creation fails due to backend errors.
        '''
    async def delete_by_id(self, id: str | list[str], **kwargs: Any) -> None:
        """Delete records from the data store based on IDs.

        Args:
            id (str | list[str]): ID or list of IDs to delete.
            **kwargs: Additional arguments passed to the delete operation.
        """
