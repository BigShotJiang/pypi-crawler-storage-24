from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.hybrid_capability import SearchConfig as SearchConfig
from gllm_datastore.core.filters.schema import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.elasticsearch.hybrid import ElasticsearchHybridCapability as ElasticsearchHybridCapability
from gllm_datastore.data_store.opensearch.query import delete_by_query as delete_by_query
from gllm_datastore.data_store.opensearch.query_translator import OpenSearchQueryTranslator as OpenSearchQueryTranslator
from opensearchpy import AsyncOpenSearch

class OpenSearchHybridCapability(ElasticsearchHybridCapability):
    """OpenSearch hybrid capability backed by BM25 and k-NN search."""
    backend_package: str
    backend_extra: str
    query_translator_cls = OpenSearchQueryTranslator
    def __init__(self, index_name: str, client: AsyncOpenSearch, config: list[SearchConfig], encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the OpenSearch hybrid capability.

        Args:
            index_name (str): The name of the OpenSearch index.
            client (AsyncOpenSearch): The OpenSearch client.
            config (list[SearchConfig]): List of search configurations.
            encryption (EncryptionCapability | None, optional): Encryption capability.
                Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.

        Raises:
            ValueError: If no hybrid search configuration is provided.
        """
