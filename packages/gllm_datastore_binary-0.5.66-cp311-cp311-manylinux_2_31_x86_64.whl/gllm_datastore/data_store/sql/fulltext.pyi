from _typeshed import Incomplete
from gllm_core.schema.chunk import Chunk
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.fulltext_capability import BaseFulltextCapability as BaseFulltextCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.sql.query import execute_delete as execute_delete, execute_delete_with_filters as execute_delete_with_filters, execute_update_with_filters as execute_update_with_filters, row_to_chunk as row_to_chunk
from gllm_datastore.data_store.sql.query_translator import SQLQueryTranslator as SQLQueryTranslator
from gllm_datastore.data_store.sql.schema import ChunkModel as ChunkModel
from sqlalchemy.engine import Row as Row
from sqlalchemy.ext.asyncio import AsyncEngine
from sqlalchemy.orm import DeclarativeBase
from typing import Any

class SQLFulltextCapability(BaseFulltextCapability):
    """SQL implementation of FulltextCapability protocol using async SQLAlchemy.

    This capability creates its own session factory from the engine, making it
    self-contained and independent of the data store's session configuration.
    Subclasses (e.g. PostgreSQLFulltextCapability) may set query_translator_class
    to use a dialect-specific translator for retrieve, update, and delete.

    Attributes:
        engine (AsyncEngine): SQLAlchemy async engine instance.
        session_factory (async_sessionmaker): Async session factory created from engine.
        table_name (str): Name of the table this capability operates on. This is immutable
            and defines the scope of all operations.
    """
    query_translator_class = SQLQueryTranslator
    engine: Incomplete
    table_name: Incomplete
    session_factory: Incomplete
    def __init__(self, engine: AsyncEngine, table_name: str, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the SQL fulltext capability with async support.

        Args:
            engine (AsyncEngine): SQLAlchemy async engine instance.
            table_name (str): Name of the table this capability will operate on.
                This defines the scope of all operations and cannot be changed after initialization.
            encryption (EncryptionCapability | None, optional): Encryption capability for field-level
                encryption. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for create/update/delete.
                Defaults to None.
        """
    async def create(self, data: Chunk | list[Chunk] | DeclarativeBase | list[DeclarativeBase], batch_size: int | None = None, **kwargs: Any) -> None:
        '''Create new records in the datastore.

        This method accepts both Chunk and DeclarativeBase instances.
        1. If data is a Chunk, it will be converted to a ChunkModel instance with flattened metadata.
           Encryption and batching are handled by the base class.
        2. If data is a DeclarativeBase, it will be added directly to the database.

        Note:
            DeclarativeBase instances must map to this capability\'s table. The model\'s
            __tablename__ must equal the table_name passed when constructing this
            capability. Passing a model whose __tablename__ differs from this capability\'s
            table_name will raise ValueError, since records would be inserted into a
            different table than this capability operates on.

        Examples:
            1. Create a single record using a Chunk.
            ```python
            # Create a single chunk
            chunk = Chunk(id="1", content="Test content", metadata={"source": "test"})
            await datastore.fulltext.create(chunk)

            # Bulk create
            chunks = [
                Chunk(id=str(i), content=f"Test content {i}", metadata={"source": "test"})
                for i in range(10)
            ]
            await datastore.fulltext.create(chunks)
            ```

            2. Create a single record using a declarative base model.
            ```python
            # Create a single user
            user = UserModel(id="1", name="John", email="john@example.com")
            await datastore.fulltext.create(user)

            # Bulk create
            users = [UserModel(id=str(i), name=f"User{i}") for i in range(10)]
            await datastore.fulltext.create(users)
            ```

        Args:
            data (Chunk | list[Chunk] | DeclarativeBase | list[DeclarativeBase]):
                Data to create (single item or collection). Chunk instances will be converted
                to ChunkModel. DeclarativeBase instances will be added directly to the database.
            batch_size (int | None, optional): Override batch size for this call. Defaults to None.
            **kwargs (Any): Passed to _create.

        Raises:
            ValueError: If a DeclarativeBase model\'s __tablename__ does not match this
                capability\'s table_name.
            RuntimeError: If the creation fails.
        '''
