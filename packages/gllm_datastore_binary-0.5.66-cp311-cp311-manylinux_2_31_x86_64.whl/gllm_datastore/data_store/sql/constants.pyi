class SQL_COLUMNS:
    """Namespace for SQL chunk table column name constants.

    Use this class to reference column names (e.g., SQL_COLUMNS.ID) instead of
    string literals.
    """
    ID: str
    CONTENT: str
    METADATA: str
