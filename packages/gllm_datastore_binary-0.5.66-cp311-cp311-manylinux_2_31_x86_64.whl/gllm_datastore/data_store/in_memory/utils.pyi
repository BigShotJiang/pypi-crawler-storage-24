from gllm_core.schema.chunk import Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS
from typing import Any

def validate_cache_key(key: str) -> None:
    """Validate cache key format and content.

    Args:
        key (str): Cache key to validate.

    Raises:
        TypeError: If key is not a string.
        ValueError: If key is empty or whitespace-only.
    """
def create_updated_chunk(existing_chunk: Chunk, update_values: dict[str, Any]) -> Chunk:
    """Create an updated chunk with new values.

    Args:
        existing_chunk (Chunk): The existing chunk to update.
        update_values (dict[str, Any]): Values to update.

    Returns:
        Chunk: Updated chunk with new values.
    """
