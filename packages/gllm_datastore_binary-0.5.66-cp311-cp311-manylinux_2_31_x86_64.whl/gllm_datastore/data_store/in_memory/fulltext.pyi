from gllm_core.schema.chunk import Chunk as Chunk
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.fulltext_capability import BaseFulltextCapability as BaseFulltextCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.in_memory.query import delete_chunks_by_filters as delete_chunks_by_filters, get_chunks_from_store as get_chunks_from_store
from gllm_datastore.data_store.in_memory.utils import create_updated_chunk as create_updated_chunk
from typing import Any

class InMemoryFulltextCapability(BaseFulltextCapability):
    """In-memory implementation of FulltextCapability protocol.

    This class provides document CRUD operations and flexible querying using pure
    Python data structures optimized for development and testing.

    Attributes:
        store (dict[str, Chunk]): Dictionary storing Chunk objects with their IDs as keys.
    """
    store: dict[str, Chunk]
    def __init__(self, store: dict[str, Any] | None = None, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the in-memory fulltext capability.

        Args:
            store (dict[str, Any] | None, optional): Dictionary storing Chunk objects with their IDs as keys.
                Defaults to None.
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.
        """
