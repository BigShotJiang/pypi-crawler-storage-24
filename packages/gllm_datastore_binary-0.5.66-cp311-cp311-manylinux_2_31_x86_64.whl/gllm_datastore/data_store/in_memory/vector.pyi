from gllm_core.schema.chunk import Chunk as Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.vector_capability import BaseVectorCapability as BaseVectorCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.in_memory.query import delete_chunks_by_filters as delete_chunks_by_filters, get_chunks_from_store as get_chunks_from_store, similarity_search as similarity_search
from gllm_datastore.data_store.in_memory.utils import create_updated_chunk as create_updated_chunk
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from typing import Any

class InMemoryVectorCapability(BaseVectorCapability):
    """In-memory implementation of VectorCapability protocol.

    This class provides vector similarity search operations using pure Python
    data structures optimized for development and testing.

    Attributes:
        store (dict[str, Chunk]): Dictionary storing Chunk objects with their IDs as keys.
    """
    store: dict[str, Chunk]
    def __init__(self, em_invoker: BaseEMInvoker, store: dict[str, Any] | None = None, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the in-memory vector capability.

        Args:
            em_invoker (BaseEMInvoker): Embedding model invoker for text-to-vector conversion.
            store (dict[str, Any] | None, optional): Dictionary storing Chunk objects. Defaults to None.
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.
        """
    async def ensure_index(self, **kwargs: Any) -> None:
        """Ensure in-memory vector store exists, initializing if necessary.

        Idempotent; no-op if store already exists.

        Args:
            **kwargs (Any): Unused; for interface compatibility.
        """
