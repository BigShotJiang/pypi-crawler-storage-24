from _typeshed import Incomplete
from gllm_core.schema import Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DEFAULT_TOP_K as DEFAULT_TOP_K
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.hybrid_capability import BaseHybridCapability as BaseHybridCapability, HybridSearchType as HybridSearchType, SearchConfig as SearchConfig
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.milvus.query import apply_query_options as apply_query_options, clear_collection as clear_collection, delete_by_filter as delete_by_filter, delete_with_options as delete_with_options, prepare_update_entities as prepare_update_entities, query_update_records as query_update_records
from gllm_datastore.data_store.milvus.query_translator import MilvusQueryTranslator as MilvusQueryTranslator
from gllm_datastore.data_store.milvus.utils import extract_entity_field as extract_entity_field, prepare_metadata_updates as prepare_metadata_updates
from pymilvus import AsyncMilvusClient
from typing import Any

DEFAULT_FULLTEXT_SUFFIX: str
DEFAULT_INDEX_TYPE: str
DEFAULT_DISTANCE_METRIC: str
INDEX_PARAMS_MAP: dict[str, dict[str, Any]]
DEFAULT_OUTPUT_FIELDS: Incomplete

class MilvusHybridCapability(BaseHybridCapability):
    """Milvus hybrid capability backed by BM25 sparse search and dense vector search.

    Attributes:
        collection_name (str): Name of the target Milvus collection.
        client (AsyncMilvusClient): Async Milvus client used for collection operations.
    """
    collection_name: Incomplete
    client: Incomplete
    def __init__(self, collection_name: str, client: AsyncMilvusClient, uri: str, config: list[SearchConfig], query_field: str = ..., index_type: str = ..., index_params: dict[str, Any] | None = None, default_index_params_map: dict[str, dict[str, Any]] | None = None, distance_metric: str = ..., id_max_length: int = 100, content_max_length: int = 65535, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        '''Initialize the Milvus hybrid capability.

        Args:
            collection_name (str): Name of the Milvus collection.
            client (AsyncMilvusClient): Async Milvus client instance.
            uri (str): Milvus URI used to create the sync client for index params.
            config (list[SearchConfig]): Hybrid search configuration entries.
            query_field (str, optional): Field used to store chunk content. Defaults to `content`.
            index_type (str, optional): Dense index type for vector fields. Defaults to "IVF_FLAT".
            index_params (dict[str, Any] | None, optional): Dense index-specific parameters.
                Defaults to None.
            default_index_params_map (dict[str, dict[str, Any]] | None, optional): Default index
                parameters keyed by Milvus index type when `index_params` is not provided.
                Defaults to None.
            distance_metric (str, optional): Dense vector metric type. Defaults to "IP".
            id_max_length (int, optional): Maximum length for chunk IDs. Defaults to 100.
            content_max_length (int, optional): Maximum length for content fields. Defaults to 65535.
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for batched operations.
                Defaults to None.

        Raises:
            ValueError: If no search configuration is provided.
        '''
    @property
    def fulltext_configs(self) -> list[SearchConfig]:
        """Return configured fulltext searches.

        Returns:
            list[SearchConfig]: Fulltext search configurations.
        """
    @property
    def vector_configs(self) -> list[SearchConfig]:
        """Return configured dense vector searches.

        Returns:
            list[SearchConfig]: Dense vector search configurations.
        """
    async def ensure_index(self) -> None:
        """Ensure the hybrid collection exists with BM25 and dense indexes.

        Raises:
            ValueError: If a required vector dimension cannot be inferred.
        """
    async def create(self, chunks: list[Chunk], batch_size: int | None = None, **kwargs: Any) -> None:
        """Create chunks, enriching them with dense vectors before persistence.

        Args:
            chunks (list[Chunk]): Chunks to persist.
            batch_size (int | None, optional): Batch size override. Defaults to None.
            **kwargs (Any): Backend-specific arguments forwarded to upsert.
        """
    async def update(self, update_values: dict[str, Any], filters: FilterClause | QueryFilter | None = None, batch_size: int | None = None, **kwargs: Any) -> None:
        """Update chunks and regenerate dense vectors when text changes.

        Args:
            update_values (dict[str, Any]): Values to update.
            filters (FilterClause | QueryFilter | None, optional): Filters selecting the target rows.
                Defaults to None.
            batch_size (int | None, optional): Batch size override. Defaults to None.
            **kwargs (Any): Backend-specific arguments forwarded to upsert.
        """
