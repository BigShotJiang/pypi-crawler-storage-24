from _typeshed import Incomplete
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, WORD_EXTRACTION_PATTERN as WORD_EXTRACTION_PATTERN
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.fulltext_capability import BaseFulltextCapability as BaseFulltextCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.milvus.query import clear_collection as clear_collection, delete_by_filter as delete_by_filter, delete_with_options as delete_with_options, execute_query as execute_query
from gllm_datastore.data_store.milvus.query_translator import MilvusQueryTranslator as MilvusQueryTranslator
from gllm_datastore.utils.fuzzy import compute_sliding_window_levenshtein_distance as compute_sliding_window_levenshtein_distance
from pymilvus import AsyncMilvusClient

class MilvusFulltextCapability(BaseFulltextCapability):
    """Milvus implementation of FulltextCapability protocol.

    This class provides document CRUD operations and filtering using Milvus.
    Encryption and batching are handled by the base class.

    Attributes:
        collection_name (str): The name of the Milvus collection.
        client (AsyncMilvusClient): Async Milvus client instance.
        query_field (str): The field name to use for text content.
    """
    collection_name: Incomplete
    client: Incomplete
    id_max_length: Incomplete
    content_max_length: Incomplete
    def __init__(self, collection_name: str, client: AsyncMilvusClient, uri: str, query_field: str = 'content', id_max_length: int = 100, content_max_length: int = 65535, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        '''Initialize the Milvus fulltext capability.

        Args:
            collection_name (str): The name of the Milvus collection.
            client (AsyncMilvusClient): The async Milvus client instance.
            uri (str): Milvus URI for creating sync client to prepare index params.
            query_field (str, optional): The field name to use for text content. Defaults to "content".
            id_max_length (int, optional): Maximum length for ID field. Defaults to 100.
            content_max_length (int, optional): Maximum length for content field. Defaults to 65535.
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for create/update/delete. Defaults to None.
        '''
    async def ensure_index(self) -> None:
        """Ensure collection exists with proper schema for fulltext capability.

        This method is idempotent - if the collection already exists, it will skip
        creation and return early.

        Raises:
            RuntimeError: If collection creation fails.
        """
