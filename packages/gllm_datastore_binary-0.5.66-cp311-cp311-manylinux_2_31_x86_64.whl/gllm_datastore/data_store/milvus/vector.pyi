from _typeshed import Incomplete
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DEFAULT_TOP_K as DEFAULT_TOP_K
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.capabilities.vector_capability import BaseVectorCapability as BaseVectorCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.data_store.milvus.query import apply_query_options as apply_query_options, clear_collection as clear_collection, delete_by_filter as delete_by_filter, delete_with_options as delete_with_options, prepare_update_entities as prepare_update_entities, query_update_records as query_update_records
from gllm_datastore.data_store.milvus.query_translator import MilvusQueryTranslator as MilvusQueryTranslator
from gllm_datastore.data_store.milvus.utils import create_base_schema as create_base_schema, extract_entity_field as extract_entity_field
from gllm_datastore.utils.converter import cosine_distance_to_similarity_score as cosine_distance_to_similarity_score, l2_distance_to_similarity_score as l2_distance_to_similarity_score
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from pymilvus import AsyncMilvusClient
from typing import Any

INDEX_PARAMS_MAP: dict[str, dict[str, Any]]
DISTANCE_METRIC_CONFIG: dict[str, dict[str, Any]]

class MilvusVectorCapability(BaseVectorCapability):
    '''Milvus implementation of VectorCapability protocol.

    This class provides vector similarity search operations using Milvus.
    Encryption and batching are handled by the base class.

    Attributes:
        collection_name (str): The name of the Milvus collection.
        client (AsyncMilvusClient): Async Milvus client instance.
        dimension (int): Vector dimension.
        distance_metric (str): Distance metric ("L2", "IP", "COSINE").
        vector_field (str): Field name for dense vectors.
        id_max_length (int): Maximum length for ID field.
        content_max_length (int): Maximum length for content field.
    '''
    collection_name: Incomplete
    client: Incomplete
    dimension: Incomplete
    distance_metric: Incomplete
    vector_field: Incomplete
    id_max_length: Incomplete
    content_max_length: Incomplete
    def __init__(self, collection_name: str, client: AsyncMilvusClient, uri: str, em_invoker: BaseEMInvoker, dimension: int, distance_metric: str = 'L2', vector_field: str = 'dense_vector', id_max_length: int = 100, content_max_length: int = 65535, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        '''Initialize the Milvus vector capability.

        Args:
            collection_name (str): The name of the Milvus collection.
            client (AsyncMilvusClient): The async Milvus client instance.
            uri (str): Milvus URI for creating sync client to prepare index params.
            em_invoker (BaseEMInvoker): The embedding model invoker.
            dimension (int): Vector dimension.
            distance_metric (str, optional): Distance metric. Defaults to "L2".
                Supported: "L2", "IP", "COSINE".
            vector_field (str, optional): Field name for dense vectors. Defaults to "dense_vector".
            id_max_length (int, optional): Maximum length for ID field. Defaults to 100.
            content_max_length (int, optional): Maximum length for content field. Defaults to 65535.
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size for create/update. Defaults to None.
        '''
    async def ensure_index(self, index_type: str = 'IVF_FLAT', index_params: dict[str, Any] | None = None, query_field: str = 'content', **kwargs: Any) -> None:
        '''Ensure collection and vector index exist, creating them if necessary.

        This method is idempotent - if the collection and index already exist, it will skip
        creation and return early. Uses a lock to prevent race conditions when called
        concurrently from multiple coroutines.

        Args:
            index_type (str, optional): Index type. Defaults to "IVF_FLAT".
                Supported: "IVF_FLAT", "HNSW".
            index_params (dict[str, Any] | None, optional): Index-specific parameters.
                Defaults to None, in which case default parameters are used.
            query_field (str, optional): Field name for text content. Defaults to "content".
            **kwargs (Any): Additional parameters (e.g. from base capability interface); ignored.

        Raises:
            RuntimeError: If collection or index creation fails.
        '''
