from _typeshed import Incomplete
from abc import abstractmethod
from collections.abc import Awaitable as Awaitable
from gllm_core.schema.chunk import Chunk
from gllm_datastore.constants import CHUNK_KEYS as CHUNK_KEYS, DefaultBatchSize as DefaultBatchSize
from gllm_datastore.core.capabilities.data_store_capability import DataStoreCapability as DataStoreCapability
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_inference.schema import Vector
from typing import Any

DEFAULT_RETRY_MAX_RETRIES: int
DEFAULT_RETRY_BASE_DELAY: float
DEFAULT_RETRY_MAX_DELAY: float
DEFAULT_RETRY_EXCEPTIONS: Incomplete

class BaseVectorCapability(DataStoreCapability):
    """Base class for vector capability implementations.

    Provides default batching/encryption flows for create, create_from_vector,
    retrieve, retrieve_by_vector, update, delete, and clear.
    """
    def __init__(self, em_invoker: BaseEMInvoker, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the base vector capability.

        Args:
            em_invoker (BaseEMInvoker): Embedding model invoker (required).
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.
        """
    @property
    def em_invoker(self) -> BaseEMInvoker:
        """Return the embedding model invoker.

        Returns:
            BaseEMInvoker: The EM invoker instance.
        """
    @abstractmethod
    async def ensure_index(self, **kwargs: Any) -> None:
        """Ensure vector index exists.

        Args:
            **kwargs (Any): Datastore-specific parameters.

        Raises:
            NotImplementedError: This method is not implemented in the subclass.
        """
    async def create(self, data: Chunk | list[Chunk], batch_size: int | None = None, **kwargs: Any) -> None:
        """Create records with automatic encryption and batching.

        Args:
            data (Chunk | list[Chunk]): Single chunk or list of chunks.
            batch_size (int | None, optional): Override batch size. Defaults to None.
            **kwargs (Any): Passed to subclass.
        """
    async def create_from_vector(self, chunk_vectors: list[tuple[Chunk, Vector]], batch_size: int | None = None, **kwargs: Any) -> None:
        """Create from pre-computed vectors with encryption and batching.

        Args:
            chunk_vectors (list[tuple[Chunk, Vector]]): Chunks and their vectors.
            batch_size (int | None, optional): Override batch size. Defaults to None.
            **kwargs (Any): Passed to subclass.
        """
    async def retrieve_by_vector(self, vector: Vector, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, **kwargs: Any) -> list[Chunk]:
        """Retrieve by vector with automatic decryption.

        Args:
            vector (Vector): Query vector.
            filters (FilterClause | QueryFilter | None, optional): Filters. Defaults to None.
            options (QueryOptions | None, optional): Query options. Defaults to None.
            **kwargs (Any): Passed to _retrieve_by_vector.

        Returns:
            list[Chunk]: Decrypted chunks.
        """
    async def update(self, update_values: dict[str, Any], filters: FilterClause | QueryFilter | None = None, batch_size: int | None = None, **kwargs: Any) -> None:
        """Update records with centralized encryption and content embedding refresh.

        Args:
            update_values (dict[str, Any]): Fields to update.
            filters (FilterClause | QueryFilter | None, optional): Filters. Defaults to None.
            batch_size (int | None, optional): Optional batch size override.
                Defaults to DefaultBatchSize.UPDATE when not configured at request/capability level.
            **kwargs (Any): Passed to backend-specific _update implementation.
        """
