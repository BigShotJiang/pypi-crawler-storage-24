from abc import ABC
from collections.abc import Awaitable as Awaitable
from gllm_core.schema.chunk import Chunk as Chunk
from gllm_datastore.constants import DefaultBatchSize as DefaultBatchSize
from gllm_datastore.core.capabilities.encryption_capability import EncryptionCapability as EncryptionCapability, decrypt_chunks_if_enabled as decrypt_chunks_if_enabled, encrypt_chunks_if_enabled as encrypt_chunks_if_enabled, encrypt_update_values_if_enabled as encrypt_update_values_if_enabled
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_datastore.utils.batching import batching_context as batching_context, validate_batch_size as validate_batch_size
from typing import Any, TypeVar

T = TypeVar('T')

class DataStoreCapability(ABC):
    """Base class for capability implementations that share encryption and batching.

    Holds common state (encryption, default_batch_size) and helpers used by
    BaseFulltextCapability, BaseVectorCapability, and BaseHybridCapability.
    Subclasses should not inherit from this directly; use the specific base
    (BaseFulltextCapability, etc.) instead.
    """
    def __init__(self, encryption: EncryptionCapability | None = None, default_batch_size: int | None = None) -> None:
        """Initialize the data store capability.

        Args:
            encryption (EncryptionCapability | None, optional): Encryption capability. Defaults to None.
            default_batch_size (int | None, optional): Default batch size. Defaults to None.
        """
    async def retrieve(self, *args: Any, **kwargs: Any) -> list[Chunk]:
        """Retrieve records with automatic decryption. Delegates to _retrieve then decrypts.

        Args:
            *args (Any): Passed to _retrieve (signature is capability-specific).
            **kwargs (Any): Passed to _retrieve.

        Returns:
            list[Chunk]: Decrypted chunks.
        """
    async def update(self, update_values: dict[str, Any], filters: FilterClause | QueryFilter | None = None, batch_size: int | None = None, **kwargs: Any) -> None:
        """Update records with automatic encryption of update_values.

        Args:
            update_values (dict[str, Any]): Fields to update.
            filters (FilterClause | QueryFilter | None, optional): Filters. Defaults to None.
            batch_size (int | None, optional): Optional batch size override.
                Defaults to DefaultBatchSize.UPDATE when not configured at request/capability level.
            **kwargs (Any): Passed to _update.
        """
    async def delete(self, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, **kwargs: Any) -> None:
        """Delete records that match the given filter. Delegates to subclass _delete.

        Args:
            filters (FilterClause | QueryFilter | None, optional): Deletion criteria; only records
                matching this filter are removed. Passed to _delete. Defaults to None.
            options (QueryOptions | None, optional): Query options (e.g. ordering/limit for
                eviction-style deletes). Passed to _delete. Defaults to None.
            **kwargs (Any): Passed to _delete.
        """
    async def clear(self, **kwargs: Any) -> None:
        """Clear all records. Delegates to subclass _clear.

        Args:
            **kwargs (Any): Passed to _clear.
        """
    def update_encryption(self, encryption: EncryptionCapability) -> None:
        """Update the encryption capability.

        Args:
            encryption (EncryptionCapability): New encryption capability.

        Raises:
            TypeError: If the provided encryption is not an instance of EncryptionCapability.
        """
