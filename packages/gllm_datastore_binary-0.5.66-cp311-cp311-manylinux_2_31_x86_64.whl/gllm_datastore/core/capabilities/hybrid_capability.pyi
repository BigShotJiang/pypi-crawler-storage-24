from _typeshed import Incomplete
from enum import StrEnum
from gllm_core.schema.chunk import Chunk as Chunk
from gllm_datastore.core.capabilities.data_store_capability import DataStoreCapability as DataStoreCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_inference.schema import Vector as Vector
from pydantic import BaseModel
from typing import Any

class HybridSearchType(StrEnum):
    """Types of searches that can be combined in hybrid search."""
    FULLTEXT: str
    VECTOR: str

class SearchConfig(BaseModel):
    '''Configuration for a single search component in hybrid search.

    Examples:
        FULLTEXT search configuration:
            ```python
            config = SearchConfig(
                search_type=HybridSearchType.FULLTEXT,
                field="text",
                weight=0.3
            )
            ```

        VECTOR search configuration:
            ```python
            config = SearchConfig(
                search_type=HybridSearchType.VECTOR,
                field="embedding",
                em_invoker=em_invoker,
                weight=0.5
            )
            ```

    Attributes:
        search_type (HybridSearchType): Type of search (FULLTEXT or VECTOR).
        field (str): Field name in the index (e.g., "text", "embedding").
        weight (float): Weight for this search in hybrid search. Defaults to 1.0.
        em_invoker (BaseEMInvoker | None): Embedding model invoker required for VECTOR type.
            Defaults to None.
        top_k (int | None): Per-search top_k limit (optional). Defaults to None.
        extra_kwargs (dict[str, Any]): Additional search-specific parameters.
            Defaults to empty dict.
    '''
    search_type: HybridSearchType
    field: str
    weight: float
    em_invoker: BaseEMInvoker | None
    top_k: int | None
    extra_kwargs: dict[str, Any]
    @classmethod
    def validate_top_k(cls, v: int | None) -> int | None:
        """Validate that top_k is positive if provided.

        Args:
            v (int | None): top_k value.

        Returns:
            int | None: Validated top_k value.

        Raises:
            ValueError: If top_k is provided but not positive.
        """
    @classmethod
    def validate_field_not_empty(cls, v: str) -> str:
        """Validate that field name is not empty.

        Args:
            v (str): Field name value.

        Returns:
            str: Validated field name.

        Raises:
            ValueError: If field name is empty.
        """
    model_config: Incomplete
    def validate_search_requirements(self) -> SearchConfig:
        """Validate configuration based on search type.

        Returns:
            SearchConfig: Validated configuration instance.

        Raises:
            ValueError: If required fields are missing for the search type.
        """

class BaseHybridCapability(DataStoreCapability):
    """Base class for hybrid capability implementations."""
    async def create(self, chunks: list[Chunk], batch_size: int | None = None, **kwargs: Any) -> None:
        """Create chunks with automatic encryption and batching.

        Args:
            chunks (list[Chunk]): Chunks to create and index.
            batch_size (int | None, optional): Override batch size. Defaults to None.
            **kwargs (Any): Passed to subclass _create.
        """
    async def create_from_vector(self, chunks: list[Chunk], dense_vectors: dict[str, list[tuple[Chunk, Vector]]] | None = None, batch_size: int | None = None, **kwargs: Any) -> None:
        """Create from pre-computed vectors with encryption and batching.

        Args:
            chunks (list[Chunk]): Chunks to index.
            dense_vectors (dict[str, list[tuple[Chunk, Vector]]] | None, optional): Per-field vectors. Defaults to None.
            batch_size (int | None, optional): Override batch size; controls actual batching. Defaults to None.
            **kwargs (Any): Passed to subclass.
        """
    async def retrieve(self, query: str, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, **kwargs: Any) -> list[Chunk]:
        """Retrieve using hybrid search with automatic decryption.

        Args:
            query (str): Query text to search with.
            filters (FilterClause | QueryFilter | None, optional): Query filters to apply. Defaults to None.
            options (QueryOptions | None, optional): Query options like limit and sorting. Defaults to None.
            **kwargs (Any): Additional arguments passed to _retrieve.

        Returns:
            list[Chunk]: Decrypted query results.
        """
    async def retrieve_by_vector(self, query: str | None = None, dense_vectors: dict[str, Vector] | None = None, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, **kwargs: Any) -> list[Chunk]:
        """Retrieve by pre-computed vectors with automatic decryption.

        Args:
            query (str | None, optional): Optional query text. Defaults to None.
            dense_vectors (dict[str, Vector] | None, optional): Field name to query vector. Defaults to None.
            filters (FilterClause | QueryFilter | None, optional): Filters. Defaults to None.
            options (QueryOptions | None, optional): Query options. Defaults to None.
            **kwargs (Any): Passed to _retrieve_by_vector.

        Returns:
            list[Chunk]: Decrypted chunks.
        """
