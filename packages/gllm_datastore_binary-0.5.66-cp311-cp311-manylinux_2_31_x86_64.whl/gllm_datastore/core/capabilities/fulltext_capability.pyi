from gllm_core.schema.chunk import Chunk
from gllm_datastore.core.capabilities.data_store_capability import DataStoreCapability as DataStoreCapability
from gllm_datastore.core.filters import FilterClause as FilterClause, QueryFilter as QueryFilter, QueryOptions as QueryOptions
from typing import Any

class BaseFulltextCapability(DataStoreCapability):
    """Base class for fulltext capability implementations.

    Handles encryption and batching transparently. Subclasses implement
    internal CRUD methods that operate on plaintext data (or receive
    already-encrypted data when encryption is enabled).
    """
    async def create(self, data: Chunk | list[Chunk], batch_size: int | None = None, **kwargs: Any) -> None:
        """Create records with automatic encryption and batching.

        Args:
            data (Chunk | list[Chunk]): Single chunk or list of chunks to create.
            batch_size (int | None, optional): Override batch size for this call. Defaults to None.
            **kwargs (Any): Passed to subclass _create.
        """
    async def retrieve_fuzzy(self, query: str, max_distance: int = 2, filters: FilterClause | QueryFilter | None = None, options: QueryOptions | None = None, **kwargs: Any) -> list[Chunk]:
        """Find records that fuzzy match the query within distance threshold, with automatic decryption.

        Args:
            query (str): Text to fuzzy match against.
            max_distance (int, optional): Maximum edit distance for matches (e.g. Levenshtein). Defaults to 2.
            filters (FilterClause | QueryFilter | None, optional): Optional metadata filters. Defaults to None.
            options (QueryOptions | None, optional): Query options (limit, etc.). Defaults to None.
            **kwargs (Any): Passed to subclass _retrieve_fuzzy.

        Returns:
            list[Chunk]: Matched chunks ordered by relevance/distance, decrypted when encryption is enabled.
        """
