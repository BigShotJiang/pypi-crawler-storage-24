from abc import ABC, abstractmethod
from gllm_core.schema.graph import Edge, Node
from typing import Any

class BaseGraphDataStore(ABC):
    '''Abstract base class for an async graph data store interface.

    This class defines the asynchronous interface for all graph data store implementations.
    It provides methods for creating, updating, and querying graph data.

    The upsert methods accept two calling conventions:

    **New-style (preferred)** – pass a ``Node`` or ``Edge`` object directly:

    .. code-block:: python

        node = Node(type="Person", metadata={"name": "Alice", "age": 30})
        await store.upsert_node(node=node)

        edge = Edge(type="KNOWS", source_id="Alice", target_id="Bob",
                    metadata={"since": 2020})
        await store.upsert_relationship(edge=edge)

    **Old-style (deprecated)** – pass individual string/dict arguments.  These
    still work but emit a ``DeprecationWarning`` at call time:

    .. code-block:: python

        await store.upsert_node("Person", "name", "Alice", {"age": 30})
        await store.upsert_relationship("name", "Alice", "KNOWS", "name", "Bob")
    '''
    @abstractmethod
    async def upsert_node(self, label: str | None = None, identifier_key: str | None = None, identifier_value: str | None = None, properties: dict[str, Any] | None = None, *, node: Node | None = None) -> Node | None:
        '''Upsert a node in the graph.

        **Preferred** – pass a ``Node`` instance:

        .. code-block:: python

            node = Node(type="Person", metadata={"name": "Alice", "age": 30})
            result = await store.upsert_node(node=node)

        **Deprecated** – pass raw string/dict parameters (still supported):

        .. code-block:: python

            result = await store.upsert_node("Person", "name", "Alice", {"age": 30})

        Args:
            label (str | None, optional): The label of the node.
                *Deprecated* – use ``node`` instead. Defaults to None.
            identifier_key (str | None, optional): The key of the identifier.
                *Deprecated* – use ``node`` instead. Defaults to None.
            identifier_value (str | None, optional): The value of the identifier.
                *Deprecated* – use ``node`` instead. Defaults to None.
            properties (dict[str, Any] | None, optional): Extra node properties.
                *Deprecated* – use ``node`` instead. Defaults to None.
            node (Node | None): A ``Node`` object.  When provided, the positional
                arguments are ignored and a deprecation warning is **not** emitted.

        Returns:
            Node | None: The upserted node, or ``None`` if the node could not be
                confirmed in the database. When called with a ``Node`` object, the
                same object is returned. When called with legacy parameters, a new
                ``Node`` is constructed from the resolved arguments if available.
        '''
    @abstractmethod
    async def upsert_relationship(self, node_source_key: str | None = None, node_source_value: str | None = None, relation: str | None = None, node_target_key: str | None = None, node_target_value: str | None = None, properties: dict[str, Any] | None = None, *, edge: Edge | None = None) -> Edge | None:
        '''Upsert a relationship between two nodes in the graph.

        **Preferred** – pass an ``Edge`` instance:

        .. code-block:: python

            edge = Edge(type="KNOWS", source_id="alice-id", target_id="bob-id",
                        metadata={"since": 2020})
            result = await store.upsert_relationship(edge=edge)

        **Deprecated** – pass raw string/dict parameters (still supported):

        .. code-block:: python

            result = await store.upsert_relationship(
                "name", "Alice", "KNOWS", "name", "Bob", {"since": 2020}
            )

        Args:
            node_source_key (str | None, optional): The key of the source node.
                *Deprecated* – use ``edge`` instead. Defaults to None.
            node_source_value (str | None, optional): The value of the source node.
                *Deprecated* – use ``edge`` instead. Defaults to None.
            relation (str | None, optional): The type of the relationship.
                *Deprecated* – use ``edge`` instead. Defaults to None.
            node_target_key (str | None, optional): The key of the target node.
                *Deprecated* – use ``edge`` instead. Defaults to None.
            node_target_value (str | None, optional): The value of the target node.
                *Deprecated* – use ``edge`` instead. Defaults to None.
            properties (dict[str, Any] | None, optional): Extra relationship properties.
                *Deprecated* – use ``edge`` instead. Defaults to None.
            edge (Edge | None): An ``Edge`` object.  When provided, the positional
                arguments are ignored and a deprecation warning is **not** emitted.

        Returns:
            Edge | None: The upserted edge, or ``None`` if the relationship could not
                be confirmed in the database. When called with an ``Edge`` object, the
                same object is returned. When called with legacy parameters, a new
                ``Edge`` is constructed from the resolved arguments if available.
        '''
    @abstractmethod
    async def delete_node(self, label: str, identifier_key: str, identifier_value: str) -> bool:
        """Delete a node from the graph.

        Args:
            label (str): The label of the node.
            identifier_key (str): The key of the identifier.
            identifier_value (str): The identifier of the node.

        Returns:
            bool: ``True`` if the deletion completed successfully.
        """
    @abstractmethod
    async def delete_relationship(self, node_source_key: str, node_source_value: str, relation: str, node_target_key: str, node_target_value: str) -> bool:
        """Delete a relationship between two nodes in the graph.

        Args:
            node_source_key (str): The key of the source node.
            node_source_value (str): The identifier of the source node.
            relation (str): The type of the relationship.
            node_target_key (str): The key of the target node.
            node_target_value (str): The identifier of the target node.

        Returns:
            bool: ``True`` if the deletion completed successfully.
        """
    @abstractmethod
    async def query(self, query: str, parameters: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Query the graph data store.

        Args:
            query (str): The query to be executed.
            parameters (dict[str, Any] | None, optional): The parameters of the query. Defaults to None.

        Returns:
            list[dict[str, Any]]: The result of the query as a list of dictionaries.
        """
    @abstractmethod
    async def traverse_graph(self, node_properties: dict[str, Any], extracted_node_properties: list[str] | None = None, extracted_relationship_properties: list[str] | None = None, depth: int = 3) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        '''Traverse graph from a node with specified properties, ignoring relationship\'s direction, up to a given depth.

        Example:
            ```python
            nodes, relationships = await graph_data_store.traverse_graph(
                node_properties={"name": "John Doe"},
                extracted_node_properties=["name", "age"],
                extracted_relationship_properties=["since"],
                depth=1
            )
            ```
            Means starting from the node with property `name` equal to "John Doe", traverse
            the graph up to depth 1, extracting the `name` and `age` properties from nodes
            and the `since` property from relationships.

            ```python
            nodes, relationships = await graph_data_store.traverse_graph(
                node_properties={"name": "John Doe"},
                depth=2
            )
            ```
            Means starting from the node with property `name` equal to "John Doe", traverse
            the graph up to depth 2, extracting all properties from nodes and relationships.

        Args:
            node_properties (dict[str, Any]): The properties of the starting node.
            extracted_node_properties (list[str] | None, optional): The properties to extract from nodes during
                traversal. If None or empty list, all node properties will be returned. Defaults to None.
            extracted_relationship_properties (list[str] | None, optional): The properties to extract from relationships
                during traversal. If None or empty list, all relationship properties will be returned. Defaults to None.
            depth (int, optional): The depth of traversal. Defaults to 3.

        Returns:
            tuple[list[dict[str, Any]], list[dict[str, Any]]]: A tuple containing two lists:
                - List of nodes with their extracted properties (including the source node).
                - List of relationships with their extracted properties.

            Example return value:
            nodes = [
                {
                    "id": 1001,
                    "labels": ["Person"],
                    "properties": {
                        "name": "John Doe",
                        "age": 30,
                        "occupation": "Engineer"
                    }
                },
                {
                    "id": 2001,
                    "labels": ["Company"],
                    "properties": {
                        "name": "TechCorp",
                        "industry": "Technology",
                        "employees": 500
                    }
                }
            ]

            relationships = [
                {
                    "id": 5002,
                    "type": "FRIEND_OF",
                    "start_node": 1001,
                    "end_node": 1002,
                    "properties": {
                        "since": "2018-05-20",
                        "closeness": 8
                    }
                }
            ]

        Raises:
            ValueError: If node_properties is empty or depth is less than 1.
        '''
    @abstractmethod
    async def close(self) -> None:
        """Close the graph data store."""
