from abc import ABC, abstractmethod
from collections.abc import Iterable
from dataclasses import dataclass

@dataclass(frozen=True)
class Metadata:
    """Metadata for a secret.

    Attributes:
        version (int): The version of the secret.
        created_time (str | None): The time the secret was created.
        deletion_time (str | None): The time the secret was deleted.
        destroyed (bool): Whether the secret has been destroyed.
        custom_metadata (dict[str, str] | None): Custom metadata for the secret.
    """
    version: int
    created_time: str | None = ...
    deletion_time: str | None = ...
    destroyed: bool = ...
    custom_metadata: dict[str, str] | None = ...

@dataclass(frozen=True)
class Secret:
    """Secret data.

    Attributes:
        data (dict[str, str]): The secret data.
        metadata (Metadata): The metadata for the secret.
    """
    data: dict[str, str]
    metadata: Metadata

@dataclass(frozen=True)
class ReadOption:
    """Read options.

    Attributes:
        version (int | None): The version to read.
    """
    version: int | None = ...

@dataclass(frozen=True)
class WriteOption:
    """Write options.

    Attributes:
        cas (int | None): The version to write.
            Check the version available before writing.
    """
    cas: int | None = ...

class BaseKeyValueStore(ABC):
    """Abstract base class for Key Value (KV) implementations.

    This interface defines the contract for KV implementations that handle
    key-value storage operations.
    """
    @abstractmethod
    def read(self, path: str, *, options: ReadOption | None = None) -> Secret:
        """Read a secret.

        Args:
            path (str): The path to the secret.
            options (ReadOption | None, optional): Read options including version. Defaults to None.

        Returns:
            Secret: The secret data and metadata.

        Raises:
            requests.RequestException: If the secret cannot be read.
        """
    @abstractmethod
    def write(self, path: str, data: dict[str, str], *, options: WriteOption | None = None) -> None:
        """Write a full secret snapshot.

        This ALWAYS creates a new version.
        Partial updates must use patch().

        Args:
            path (str): The path to the secret.
            data (dict[str, str]): The secret data to write.
            options (WriteOption | None, optional): Write options including CAS. Defaults to None.

        Returns:
            None

        Raises:
            requests.RequestException: If the secret cannot be written.
        """
    @abstractmethod
    def delete(self, path: str, *, versions: Iterable[int]) -> None:
        """Soft-delete secret versions.

        Args:
            path (str): The path to the secret.
            versions (Iterable[int]): The versions to soft-delete.

        Returns:
            None
        """
    @abstractmethod
    def undelete(self, path: str, *, versions: Iterable[int]) -> None:
        """Restore soft-deleted versions.

        Args:
            path (str): The path to the secret.
            versions (Iterable[int]): The versions to restore.

        Returns:
            None
        """
    @abstractmethod
    def destroy(self, path: str, *, versions: Iterable[int]) -> None:
        """Permanently destroy secret versions.

        Args:
            path (str): The path to the secret.
            versions (Iterable[int]): The versions to permanently destroy.

        Returns:
            None
        """
    @abstractmethod
    def list(self, path: str) -> list[str]:
        """List child keys at a path.

        Args:
            path (str): The path to list keys from.

        Returns:
            list[str]: List of key names at the given path.
        """
    def patch(self, path: str, data: dict[str, str], *, cas: int | None = None) -> None:
        """Merge keys into an existing secret and write a new version.

        Args:
            path (str): The path to the secret.
            data (dict[str, str]): The data to merge into the existing secret.
            cas (int | None, optional): The version to write.
                Check the version available before writing.

        Raises:
            requests.RequestException: If the secret cannot be patched.
        """
