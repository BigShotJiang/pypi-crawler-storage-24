from _typeshed import Incomplete
from collections.abc import Iterable
from gllm_datastore.key_value_store.key_value_store import BaseKeyValueStore as BaseKeyValueStore, Metadata as Metadata, ReadOption as ReadOption, Secret as Secret, WriteOption as WriteOption

class OpenBaoKeyValueStore(BaseKeyValueStore):
    """OpenBao implementation of Key-Value storage.

    This class provides KV v2 functionality using OpenBao's KV secrets engine
    for versioned key-value storage operations.

    Attributes:
        base_url (str): The OpenBao server base URL.
        token (str): The authentication token for OpenBao.
        mount_point (str): The mount point for the KV v2 secrets engine.
        namespace (str | None): The OpenBao namespace.
        session (requests.Session): The HTTP session for API calls.
    """
    base_url: Incomplete
    token: Incomplete
    mount_point: Incomplete
    namespace: Incomplete
    timeout: Incomplete
    session: Incomplete
    def __init__(self, base_url: str, token: str, mount_point: str, namespace: str | None = None, timeout: int = 30) -> None:
        """Initialize the OpenBao KV client.

        Args:
            base_url (str): The OpenBao server base URL.
            token (str): The authentication token for OpenBao.
            mount_point (str): The mount point for KV v2 en`gine.
            namespace (str | None, optional): The OpenBao namespace. Defaults to None.
            timeout (int, optional): The timeout for API calls. Defaults to 30 seconds.
        """
    def read(self, path: str, *, options: ReadOption | None = None) -> Secret:
        """Read a secret from OpenBao KV v2.

        Retrieves the full secret at a given version (or latest if not specified).

        Args:
            path (str): The path to the secret.
            options (ReadOptions | None, optional): Read options including version. Defaults to None.

        Returns:
            Secret: The secret data and metadata.

        Raises:
            requests.RequestException: If the secret cannot be read.
        """
    def write(self, path: str, data: dict[str, str], *, options: WriteOption | None = None) -> None:
        """Write a full secret snapshot to OpenBao KV v2.

        This ALWAYS creates a new version. For partial updates, use `patch()`.

        Args:
            path (str): The path to the secret.
            data (dict[str, str]): The secret data to write.
            options (WriteOptions | None, optional): Write options including CAS. Defaults to None.

        Returns:
            None

        Raises:
            requests.RequestException: If the secret cannot be written.
        """
    def delete(self, path: str, *, versions: Iterable[int]) -> None:
        """Soft-delete secret versions in OpenBao KV v2.

        The versions can be undeleted later using undelete().

        Args:
            path (str): The path to the secret.
            versions (Iterable[int]): The versions to soft-delete.

        Returns:
            None

        Raises:
            requests.RequestException: If the versions cannot be deleted.
        """
    def undelete(self, path: str, *, versions: Iterable[int]) -> None:
        """Restore soft-deleted versions in OpenBao KV v2.

        Args:
            path (str): The path to the secret.
            versions (Iterable[int]): The versions to restore.

        Returns:
            None

        Raises:
            requests.RequestException: If the versions cannot be undeleted.
        """
    def destroy(self, path: str, *, versions: Iterable[int]) -> None:
        """Permanently destroy secret versions in OpenBao KV v2.

        This operation is irreversible.

        Args:
            path (str): The path to the secret.
            versions (Iterable[int]): The versions to permanently destroy.

        Returns:
            None

        Raises:
            requests.RequestException: If the versions cannot be destroyed.
        """
    def list(self, path: str) -> list[str]:
        """List child keys at a path in OpenBao KV v2.

        Args:
            path (str): The path to list keys from.

        Returns:
            list[str]: List of key names at the given path.

        Raises:
            requests.RequestException: If the keys cannot be listed.
        """
    def patch(self, path: str, data: dict[str, str], *, options: WriteOption | None = None) -> None:
        """Merge keys into an existing secret and write a new version.

        Args:
            path (str): The path to the secret.
            data (dict[str, str]): The data to merge into the existing secret.
            options (WriteOptions | None, optional): Write options including CAS. Defaults to None.

        Raises:
            requests.RequestException: If the secret cannot be patched.
        """
