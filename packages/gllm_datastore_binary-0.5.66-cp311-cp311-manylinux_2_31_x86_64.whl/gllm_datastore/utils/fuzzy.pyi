from gllm_datastore.constants import WORD_EXTRACTION_PATTERN as WORD_EXTRACTION_PATTERN

def compute_sliding_window_levenshtein_distance(query: str, content: str, query_words: list[str] | None = None) -> float:
    """Compute minimum Levenshtein distance using sliding-window approach.

    This function uses a sliding-window technique to find the best match between
    a query string and content string. It extracts words from both strings,
    then slides a window of query_words length over the content_words to find
    the candidate phrase with the minimum Levenshtein distance.

    Args:
        query (str): The query string to match against.
        content (str): The content string to search within.
        query_words (list[str] | None, optional): Pre-extracted query words.
            If None, words will be extracted from query. Defaults to None.

    Returns:
        float: The minimum Levenshtein distance found, or float('inf') if
            content has fewer words than query.
    """
