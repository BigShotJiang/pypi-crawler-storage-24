from _typeshed import Incomplete
from collections.abc import AsyncIterator, Callable, Coroutine
from contextlib import asynccontextmanager
from enum import Enum
from typing import Any, Generic, TypeVar

T = TypeVar('T')
AsyncBatchFn = Callable[[list[T]], Coroutine[Any, Any, None]]

class ErrorStrategy(Enum):
    """Strategy for handling errors during batch processing.

    Attributes:
        FAIL_FAST: Stop immediately on the first error and raise it.
        BEST_EFFORT: Continue processing remaining batches and report all errors at the end.
    """
    FAIL_FAST: Incomplete
    BEST_EFFORT: Incomplete

class BatchingError(Exception):
    """Exception raised when errors occur during batch processing."""
    errors: Incomplete
    def __init__(self, errors: list[Exception]) -> None:
        """Initialize BatchingError.

        Args:
            errors (list[Exception]): List of exceptions encountered during batch processing.
        """

def validate_batch_size(batch_size: int | None) -> None:
    """Validate batch size.

    Args:
        batch_size (int | None): The batch size to validate.

    Raises:
        ValueError: If batch_size is not None and is not positive.
    """

class BatchingContextImpl(Generic[T]):
    """Concrete batching context yielded by batching_context."""
    def __init__(self, per_batch: AsyncBatchFn[T], batch_size: int | None, error_strategy: ErrorStrategy, on_progress: Callable[[int, int], None] | None) -> None:
        """Initialize BatchingContextImpl.

        Args:
            per_batch (AsyncBatchFn[T]): Async callable that accepts a list of items and returns None.
            batch_size (int | None): Maximum items per batch. None means process all items in one call.
            error_strategy (ErrorStrategy): Strategy for handling errors (FAIL_FAST or BEST_EFFORT).
            on_progress (Callable[[int, int], None] | None): Optional callback for progress tracking.
                Receives (processed_count, total_count).
        """
    async def process_all(self, items: list[T]) -> None:
        """Process all items in batches.

        Args:
            items (list[T]): List of items to process.

        Raises:
            BatchingError: If errors occurred and error_strategy is BEST_EFFORT and at least one error.
            Exception: First exception raised by per_batch if error_strategy is FAIL_FAST.
        """

@asynccontextmanager
async def batching_context(per_batch: AsyncBatchFn[T], batch_size: int | None = None, error_strategy: ErrorStrategy = ..., on_progress: Callable[[int, int], None] | None = None) -> AsyncIterator[BatchingContextImpl[T]]:
    """Async context manager for batch processing.

    Yields a BatchingContextImpl that can process items in batches via process_all().

    Args:
        per_batch (AsyncBatchFn[T]): Async callable that accepts a list of items and returns None.
        batch_size (int | None, optional): Maximum items per batch. None means process all in one call.
            Defaults to None.
        error_strategy (ErrorStrategy, optional): How to handle errors. Defaults to FAIL_FAST.
        on_progress (Callable[[int, int], None] | None, optional): Progress callback (processed, total).
            Defaults to None.

    Yields:
        BatchingContextImpl[T]: Context instance with process_all() method.

    Example:
        >>> async with batching_context(my_async_fn, batch_size=10) as ctx:
        ...     await ctx.process_all(items)
    """
