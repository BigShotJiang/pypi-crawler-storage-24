# Moveable version tags

While controversial, [several platforms](https://github.com/actions/toolkit/blob/master/docs/action-versioning.md) recommend providing moving "release bindings."
These release bindings are tags that represent the latest revision of a version component.
For example, a tag of `v1` is similar to specifying a dependency of `>=1.0.0 <2.0.0`.
A tag of `v1.1` is similar to specifying a dependency of `>=1.1.0 <1.2.0`.

Bump My Version's stance is to provide unique, immutable release tags when tagging is enabled as its default behavior.
"Moving" tags are an optional choice and will work in addition to the default behavior.

## How they work

- The `moveable_tags` configuration is a list of serialization strings.
- All strings are serialized
- Each string is forcibly tagged locally (as a lightweight, non-annotated tag), deleted on origin, and then pushed to origin without force.

## Configuration

```toml
moveable_tags = [
    "latest",
    "v{new_major}.{new_minor}",
    "v{new_major}"
]
```

## Example

![Movable Tags Diagram](../assets/moving-tags.svg)
