"""
DataCore Library - A comprehensive standard-library-only utility package.
Version: 1.0.0
Author: AI Assistant
"""

import os
import sys
import json
import time
import socket
import logging
import hashlib
import datetime
import threading
import queue
import typing as t
import functools
import inspect
import traceback
import contextlib
import dataclasses
import collections
import itertools
import random
import string
import re
import uuid
import base64
import tempfile
import shutil
import pathlib
import warnings
import enum
import abc

class LogLevel(enum.Enum):
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50

@dataclasses.dataclass
class LibConfig:
    """Configuration container for the library."""
    app_name: str = "DataCore"
    version: str = "1.0.0"
    log_level: LogLevel = LogLevel.INFO
    debug_mode: bool = False
    max_retries: int = 3
    timeout: float = 5.0
    
    def to_dict(self) -> dict:
        return {
            "app_name": self.app_name,
            "version": self.version,
            "log_level": self.log_level.name,
            "debug_mode": self.debug_mode
        }

# Global configuration instance
_global_config = LibConfig()

def get_config() -> LibConfig:
    return _global_config

def configure(**kwargs) -> None:
    """Update global configuration."""
    for key, value in kwargs.items():
        if hasattr(_global_config, key):
            setattr(_global_config, key, value)
        else:
            warnings.warn(f"Unknown configuration key: {key}")


class CoreLogger:
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)

    def debug(self, msg: str): self.logger.debug(msg)
    def info(self, msg: str): self.logger.info(msg)
    def warning(self, msg: str): self.logger.warning(msg)
    def error(self, msg: str): self.logger.error(msg)
    def critical(self, msg: str): self.logger.critical(msg)

logger = CoreLogger("DataCore")


def retry(attempts: int = 3, delay: float = 1.0, exceptions: t.Tuple = (Exception,)):
    """Decorator to retry a function on failure."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc = None
            for i in range(attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exc = e
                    logger.warning(f"Attempt {i+1}/{attempts} failed: {e}")
                    if i < attempts - 1:
                        time.sleep(delay)
            raise last_exc
        return wrapper
    return decorator

def timing(func):
    """Decorator to measure execution time."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        logger.debug(f"{func.__name__} executed in {end - start:.4f}s")
        return result
    return wrapper

def deprecated(reason: str):
    """Decorator to mark functions as deprecated."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            warnings.warn(f"{func.__name__} is deprecated: {reason}", DeprecationWarning, stacklevel=2)
            return func(*args, **kwargs)
        return wrapper
    return decorator

T = t.TypeVar('T')

class Node(t.Generic[T]):
    def __init__(self, value: T, next_node: 'Node[T]' = None):
        self.value = value
        self.next = next_node

class LinkedList(t.Generic[T]):
    """A simple generic Linked List implementation."""
    def __init__(self):
        self.head = None
        self.size = 0

    def append(self, value: T) -> None:
        new_node = Node(value)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
        self.size += 1

    def prepend(self, value: T) -> None:
        new_node = Node(value, self.head)
        self.head = new_node
        self.size += 1

    def remove(self, value: T) -> bool:
        current = self.head
        previous = None
        while current:
            if current.value == value:
                if previous:
                    previous.next = current.next
                else:
                    self.head = current.next
                self.size -= 1
                return True
            previous = current
            current = current.next
        return False

    def to_list(self) -> t.List[T]:
        result = []
        current = self.head
        while current:
            result.append(current.value)
            current = current.next
        return result

    def __len__(self):
        return self.size

    def __iter__(self):
        current = self.head
        while current:
            yield current.value
            current = current.next

class PriorityQueue(t.Generic[T]):
    """Thread-safe Priority Queue using standard library queue."""
    def __init__(self):
        self._queue = queue.PriorityQueue()
        self._counter = itertools.count()

    def put(self, item: T, priority: int = 0) -> None:
        count = next(self._counter)
        self._queue.put((priority, count, item))

    def get(self, block: bool = True, timeout: float = None) -> T:
        try:
            _, _, item = self._queue.get(block=block, timeout=timeout)
            return item
        except queue.Empty:
            raise

    def empty(self) -> bool:
        return self._queue.empty()


class CryptoUtils:
    @staticmethod
    def hash_string(data: str, algorithm: str = 'sha256') -> str:
        h = hashlib.new(algorithm)
        h.update(data.encode('utf-8'))
        return h.hexdigest()

    @staticmethod
    def generate_salt(length: int = 16) -> str:
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    @staticmethod
    def simple_encrypt(text: str, key: str) -> str:
        # Simple XOR encryption for demonstration (NOT for production security)
        key_bytes = key.encode()
        text_bytes = text.encode()
        encrypted = []
        for i, b in enumerate(text_bytes):
            encrypted.append(b ^ key_bytes[i % len(key_bytes)])
        return base64.b64encode(bytes(encrypted)).decode()

    @staticmethod
    def simple_decrypt(encrypted_text: str, key: str) -> str:
        try:
            data = base64.b64decode(encrypted_text)
            key_bytes = key.encode()
            decrypted = []
            for i, b in enumerate(data):
                decrypted.append(b ^ key_bytes[i % len(key_bytes)])
            return bytes(decrypted).decode()
        except Exception:
            return ""


class NetworkUtils:
    @staticmethod
    @retry(attempts=3, delay=0.5)
    def check_port(host: str, port: int, timeout: float = 2.0) -> bool:
        """Check if a TCP port is open on a host."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        try:
            sock.connect((host, port))
            sock.shutdown(socket.SHUT_RDWR)
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False
        finally:
            sock.close()

    @staticmethod
    def get_local_ip() -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"


class FileUtils:
    @staticmethod
    def ensure_dir(path: str) -> None:
        pathlib.Path(path).mkdir(parents=True, exist_ok=True)

    @staticmethod
    def read_json(path: str) -> dict:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)

    @staticmethod
    def write_json(path: str, data: dict, indent: int = 4) -> None:
        FileUtils.ensure_dir(os.path.dirname(path))
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)

    @staticmethod
    def safe_remove(path: str) -> bool:
        try:
            if os.path.isfile(path):
                os.remove(path)
            elif os.path.isdir(path):
                shutil.rmtree(path)
            return True
        except Exception as e:
            logger.error(f"Failed to remove {path}: {e}")
            return False

class Validator:
    EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    
    @staticmethod
    def is_email(text: str) -> bool:
        return bool(Validator.EMAIL_REGEX.match(text))

    @staticmethod
    def is_strong_password(text: str, min_len: int = 8) -> bool:
        if len(text) < min_len:
            return False
        has_upper = any(c.isupper() for c in text)
        has_lower = any(c.islower() for c in text)
        has_digit = any(c.isdigit() for c in text)
        return has_upper and has_lower and has_digit

    @staticmethod
    def sanitize_filename(filename: str) -> str:
        # Remove unsafe characters
        return re.sub(r'[^\w\-_\. ]', '_', filename)


def _initialize_library():
    """Internal initialization routine called on import."""
    logger.info(f"Initializing {get_config().app_name} v{get_config().version}")
    logger.debug(f"Python Version: {sys.version}")
    logger.debug(f"Platform: {sys.platform}")
    
    # Perform sanity checks
    if not os.path.exists(tempfile.gettempdir()):
        logger.critical("Temp directory missing!")


def bootstrap():
    """Public API to start the library context."""
    configure(debug_mode=True)
    _initialize_library()
    logger.info("Library bootstrapped successfully.")

# Call initialization immediately upon import if needed, 
# but usually better to let user call bootstrap()
# _initialize_library() 

# Expose main classes and functions for easy import
__all__ = [
    'LibConfig', 'get_config', 'configure', 'logger',
    'retry', 'timing', 'deprecated',
    'LinkedList', 'PriorityQueue',
    'CryptoUtils', 'NetworkUtils', 'FileUtils', 'Validator',
    'bootstrap', 'self_init'
]