"""Command-line interface for Agent Berlin SDK.

This module provides CLI commands for downloading workflows and uploading reports.
"""

import json
from pathlib import Path
from typing import Optional

import click
import requests

from . import __version__
from .config import DEFAULT_BASE_URL
from .session import configure_session as _configure_session, load_session_config


@click.group()
@click.version_option(version=__version__, prog_name="agentberlin")
def main() -> None:
    """Agent Berlin CLI - Download and manage workflows."""
    pass


@main.command()
@click.option("--token", "-t", required=True, help="Authentication token from get_auth_token MCP tool")
@click.option("--domain", "-d", required=True, help="Project domain (e.g., example.com)")
@click.option("--config-path", help="Custom config file path")
def configure(token: str, domain: str, config_path: Optional[str]) -> None:
    """Configure session credentials for Agent Berlin."""
    _configure_session(token, domain, config_path)
    click.echo(f"Session configured for domain: {domain}")


@main.command()
@click.argument("workflow_id")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--output", "-o", type=click.Path(), help="Output directory")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def download_workflow(
    workflow_id: str,
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a workflow to local files.

    WORKFLOW_ID is the workflow identifier.

    This downloads the workflow definition to local files that can be read
    by an LLM to understand and execute the workflow locally.
    """
    # Resolve token (same as SDK)
    if not token:
        config = load_session_config()
        token = config.get("token")

    if not token:
        raise click.ClickException(
            "No API token found. Set AGENTBERLIN_TOKEN or configure session first."
        )

    # Fetch workflow from API
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{base_url}/workflows/{workflow_id}/download"

    try:
        resp = requests.get(url, headers=headers, timeout=30)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found or access denied.")
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    data = resp.json()

    # Determine output directory
    if output:
        out_dir = Path(output)
    else:
        out_dir = Path.cwd() / ".agentberlin" / "workflows" / workflow_id

    out_dir.mkdir(parents=True, exist_ok=True)
    scripts_dir = out_dir / "scripts"
    scripts_dir.mkdir(exist_ok=True)
    subagents_dir = out_dir / "subagents"
    subagents_dir.mkdir(exist_ok=True)

    # Write scripts as individual .py files
    script_files: list[str] = []
    for script in data.get("scripts", []):
        name = script["name"].replace(" ", "_").lower()
        filename = f"{name}.py"
        script_files.append(filename)

        # Add header comment to script
        deps = ", ".join(script.get("dependencies", []))
        header = f'''# Script: {script["name"]}
# Description: {script.get("description", "")}
# Dependencies: {deps}

'''
        # Add INPUT preamble for external LLM execution
        # This allows LLMs to pass inputs via stdin when INPUT is not injected by executor
        input_preamble = '''# INPUT handling: reads from stdin if INPUT not injected by executor
import sys as _sys, json as _json
if 'INPUT' not in dir():
    INPUT = _json.loads(_sys.stdin.read()) if not _sys.stdin.isatty() else None

'''
        (scripts_dir / filename).write_text(header + input_preamble + script.get("script", ""))

    # Write sub-agents as individual .md files
    subagent_files: list[str] = []
    for subagent in data.get("subagents", []):
        name = subagent["name"].replace(" ", "_").lower()
        filename = f"{name}.md"
        subagent_files.append(filename)

        header = f"# {subagent['name']}\n\n"
        (subagents_dir / filename).write_text(header + subagent.get("processing_guide", ""))

    # Generate README.md with all workflow content
    readme = _generate_readme(data, script_files, subagent_files)
    (out_dir / "README.md").write_text(readme)

    # Print confirmation
    click.echo(f"Downloaded workflow: {data.get('name', workflow_id)}")
    click.echo(f"Location: {out_dir}")
    click.echo("Files:")
    click.echo("  - README.md")
    for sf in script_files:
        click.echo(f"  - scripts/{sf}")
    for sf in subagent_files:
        click.echo(f"  - subagents/{sf}")


@main.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--description", "-d", required=True, help="Report description")
@click.option("--project-domain", help="Project domain (reads from config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def save_report(
    file_path: str,
    description: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Upload a file as a report to Agent Berlin.

    FILE_PATH is the path to the file to upload.

    This uploads the file to Agent Berlin's storage and registers it
    so users can download it from the Agent Berlin UI.
    """
    # Resolve token and project_domain from config
    config = load_session_config()

    if not token:
        token = config.get("token")

    if not token:
        raise click.ClickException(
            "No API token found. Set AGENTBERLIN_TOKEN or configure session first."
        )

    if not project_domain:
        project_domain = config.get("project_domain")

    if not project_domain:
        raise click.ClickException(
            "No project domain found. Use --project-domain or configure session first."
        )

    source = Path(file_path)
    if not source.exists():
        raise click.ClickException(f"File not found: {file_path}")

    # Upload file to backend API
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{base_url}/reports/upload"

    try:
        with open(source, "rb") as f:
            files = {"file": (source.name, f)}
            form_data = {"description": description, "project_domain": project_domain}
            resp = requests.post(
                url, headers=headers, files=files, data=form_data, timeout=120
            )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_msg = resp.json().get("error", "Bad request")
        raise click.ClickException(f"Upload failed: {error_msg}")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    result = resp.json()
    click.echo(f"Report uploaded: {source.name}")
    click.echo(f"Description: {description}")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


CREATE_WORKFLOW_HELP = """Create a new workflow from local files.

MANIFEST FILE FORMAT
====================

The manifest is a JSON file that defines your workflow structure:

\b
{
  "instruction_file": "path/to/instructions.md",
  "scripts": [...],
  "subagents": [...],
  "built_in_tools": [...],
  "inputs": [...]
}

INSTRUCTION FILE
================
The instruction file (markdown) is the system prompt for the orchestrator LLM
that executes the workflow. It should describe:
- The workflow's goal
- The process/steps to follow
- Data flow between components
- Error handling behavior

Do NOT include tool documentation - it's auto-injected at runtime.

SCRIPTS (TOOLS)
===============
Python scripts that the orchestrator can call. Each script:
- Receives input via a global INPUT variable (dict or None)
- Should write large outputs to files, not stdout
- Must print a JSON control envelope with metadata

Required fields per script:
  name         - Tool name the orchestrator will use
  description  - What the tool does (shown to orchestrator)
  file_path    - Path to the Python file

\b
Script structure:
  import json
  from agentberlin import AgentBerlin

  sdk = AgentBerlin()

  def main():
      param = INPUT.get("param") if INPUT else None
      # ... implementation ...
      print(json.dumps({"output_file": "results.json", "count": 100}))

  if __name__ == "__main__":
      main()

SUBAGENTS
=========
LLM sub-agents for tasks requiring semantic understanding (classification,
summarization, content generation). Use when deterministic Python isn't enough.

Required fields per subagent:
  name                  - Subagent identifier
  processing_guide_file - Path to markdown file with instructions

The processing guide should describe the TASK and OUTPUT format, not
orchestration mechanics (batching is automatic).

BUILT-IN TOOLS
==============
Optional. Defaults to ["save_report"]. Valid options:
  save_report - Saves files from session directory as downloadable reports

INPUTS
======
Optional configurable parameters that make workflows reusable. Users provide
values when running the workflow.

\b
Fields per input:
  key          - Unique identifier (snake_case)
  label        - Human-readable name for UI
  description  - Help text
  type         - "text" or "file"
  default_value - Pre-filled value (optional, not for file type)
  required     - Whether parameter must be provided
  placeholder  - Input hint (optional)

EXAMPLE
=======

\b
# Create manifest
cat > workflow.json << 'EOF'
{
  "instruction_file": "./instructions.md",
  "scripts": [
    {"name": "analyze", "description": "Analyzes page data", "file_path": "./analyze.py"}
  ],
  "inputs": [
    {"key": "url", "label": "URL", "description": "Target URL", "type": "text", "required": true}
  ]
}
EOF

\b
# Create workflow
agentberlin create-workflow --name "My Workflow" --manifest workflow.json
"""


@main.command()
@click.option("--name", "-n", required=True, help="Workflow name")
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--description", "-d", help="Workflow description")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def create_workflow(
    name: str,
    manifest: str,
    description: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Create a new workflow from local files.

    Use --help for detailed documentation on the manifest file format.
    """
    # Resolve token from config
    config = load_session_config()

    if not token:
        token = config.get("token")

    if not token:
        raise click.ClickException(
            "No API token found. Set AGENTBERLIN_TOKEN or configure session first."
        )

    # Load and validate manifest
    manifest_path = Path(manifest)
    try:
        manifest_data = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid manifest JSON: {e}")

    manifest_dir = manifest_path.parent

    # Read instruction file
    instruction_file = manifest_data.get("instruction_file")
    if not instruction_file:
        raise click.ClickException("manifest must include 'instruction_file'")

    instruction_path = manifest_dir / instruction_file
    if not instruction_path.exists():
        raise click.ClickException(f"Instruction file not found: {instruction_path}")

    instruction_content = instruction_path.read_text()

    # Read script files
    scripts = []
    for script in manifest_data.get("scripts", []):
        if "name" not in script or "description" not in script or "file_path" not in script:
            raise click.ClickException(
                "Each script must have 'name', 'description', and 'file_path'"
            )

        script_path = manifest_dir / script["file_path"]
        if not script_path.exists():
            raise click.ClickException(f"Script file not found: {script_path}")

        scripts.append(
            {
                "name": script["name"],
                "description": script["description"],
                "script": script_path.read_text(),
            }
        )

    # Read subagent files
    subagents = []
    for sa in manifest_data.get("subagents", []):
        if "name" not in sa or "processing_guide_file" not in sa:
            raise click.ClickException(
                "Each subagent must have 'name' and 'processing_guide_file'"
            )

        guide_path = manifest_dir / sa["processing_guide_file"]
        if not guide_path.exists():
            raise click.ClickException(f"Processing guide not found: {guide_path}")

        subagents.append(
            {"name": sa["name"], "processing_guide": guide_path.read_text()}
        )

    # Build request payload
    payload: dict = {
        "name": name,
        "instruction": instruction_content,
        "scripts": scripts,
        "subagents": subagents,
        "built_in_tools": manifest_data.get("built_in_tools", ["save_report"]),
        "inputs": manifest_data.get("inputs", []),
    }
    if description:
        payload["description"] = description

    # POST to API
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    url = f"{base_url}/workflows/create"

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_msg = resp.json().get("error", "Bad request")
        raise click.ClickException(f"Workflow creation failed: {error_msg}")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    result = resp.json()
    click.echo(f"Workflow created: {result.get('name', name)}")
    click.echo(f"Workflow ID: {result.get('workflow_id')}")
    click.echo(f"Version ID: {result.get('version_id')}")


# Override the help text for create_workflow to include full documentation
create_workflow.help = CREATE_WORKFLOW_HELP


def _generate_readme(data: dict, script_files: list[str], subagent_files: list[str]) -> str:
    """Generate README.md with workflow instruction, sub-agents, and config."""
    lines = [
        f"# {data.get('name', 'Workflow')}",
        "",
        "## Main Agent Instruction",
        "",
        data.get("instruction", ""),
        "",
    ]

    # Sub-agents section (reference files instead of inline content)
    subagents = data.get("subagents", [])
    if subagents:
        lines.append("## Sub-Agents")
        lines.append("")
        lines.append(
            "Sub-agents are separate instruction sets that help manage complex workflows. "
            "While the main agent can write and process data with Python scripts, "
            "sub-agents isolate specific tasks to prevent context pollution in the main process. "
            "Delegate work to sub-agents when their instructions apply."
        )
        lines.append("")
        for sa in subagents:
            name = sa["name"].replace(" ", "_").lower()
            lines.append(f"- **{sa['name']}** (`subagents/{name}.md`)")
        lines.append("")

    # Scripts section (just list them, code is in separate files)
    if script_files:
        lines.append("## Scripts")
        lines.append("")
        for script in data.get("scripts", []):
            name = script["name"].replace(" ", "_").lower()
            desc = script.get("description", "")
            lines.append(f"- **{script['name']}** (`scripts/{name}.py`): {desc}")
        lines.append("")

    # Configuration section
    config: dict = {}
    inputs = data.get("inputs", [])
    if inputs:
        config["inputs"] = inputs

    built_in_tools = data.get("built_in_tools", [])
    if built_in_tools:
        config["built_in_tools"] = built_in_tools

    if config:
        lines.append("## Configuration")
        lines.append("")
        lines.append("```json")
        lines.append(json.dumps(config, indent=2))
        lines.append("```")

    return "\n".join(lines)


if __name__ == "__main__":
    main()
