"""Presenter for template update output."""

from cli.commands.templates.get.presenter import present_template_details
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.templates import (
    GetTemplateResponse,
    UpdateTemplateResponse,
)


def present_template_update_success(response: UpdateTemplateResponse) -> None:
    """Present successful template update.

    Args:
        response: Template update response from server
    """
    output = OutputService.get()

    output.result(
        action="update",
        resource="template",
        identifier=str(response.template.id),
        name=response.template.name,
    )
    present_template_details(
        GetTemplateResponse(
            template=response.template,
            versions=[response.version],
            dependencies=response.dependencies,
        )
    )
