from typing import Any, cast

from pydantic import BaseModel

from cli.infrastructure.output import OutputFormat, OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.generation import GenerateTextResponse


class GeneratedTextOutput(BaseModel):
    output_text: str


def _format_optional_text(value: str | None) -> Any:
    if value is None:
        return cast(str, None)
    return value


def _format_tags(value: list[str]) -> Any:
    if not value:
        return cast(str, None)
    return ", ".join(value)


def _format_total_tokens(response: GenerateTextResponse) -> str:
    return str(response.usage.input_tokens + response.usage.output_tokens)


class GenerateTextPresenter:
    def __init__(self, output: OutputService):
        self.output = output

    def present_result(
        self,
        response: GenerateTextResponse,
        show_metadata: bool = True,
        *,
        metadata_title: str = "Generation Result",
        output_title: str = "Generated Text",
    ) -> None:
        if getattr(self.output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
            self.output.raw(response)
            return

        if show_metadata:
            self.output.entity(
                response,
                metadata_title,
                [
                    FieldConfig("execution_id", "Execution ID", str),
                    FieldConfig("chat_session_id", "Session ID", str),
                    FieldConfig("content_part_id", "Content Part ID", str),
                    FieldConfig("provider_key", "Provider"),
                    FieldConfig("provider_model_name", "Model"),
                    FieldConfig("finish_reason", "Finish Reason"),
                    FieldConfig(
                        "usage", "Input Tokens", lambda usage: str(usage.input_tokens)
                    ),
                    FieldConfig(
                        "usage", "Output Tokens", lambda usage: str(usage.output_tokens)
                    ),
                    FieldConfig(
                        "usage",
                        "Total Tokens",
                        lambda _: _format_total_tokens(response),
                    ),
                    FieldConfig(
                        "cost", "Input Cost", lambda cost: f"${cost.input_cost_usd:.6f}"
                    ),
                    FieldConfig(
                        "cost",
                        "Output Cost",
                        lambda cost: f"${cost.output_cost_usd:.6f}",
                    ),
                    FieldConfig(
                        "cost", "Total Cost", lambda cost: f"${cost.total_cost_usd:.6f}"
                    ),
                    FieldConfig("tags", "Tags", _format_tags),
                    FieldConfig("external_id", "External ID", _format_optional_text),
                    FieldConfig("used_fallback", "Used Fallback"),
                    FieldConfig(
                        "actual_provider_key", "Actual Provider", _format_optional_text
                    ),
                    FieldConfig(
                        "actual_provider_model_name",
                        "Actual Model",
                        _format_optional_text,
                    ),
                ],
                raw_payload=response,
            )

        self.present_text_output(response.output_text, title=output_title)

    def present_multiple_results(
        self, responses: list[GenerateTextResponse], show_metadata: bool = True
    ) -> None:
        if getattr(self.output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
            self.output.raw(responses)
            return

        total = len(responses)
        for index, response in enumerate(responses, start=1):
            suffix = f"{index}/{total}"
            self.present_result(
                response,
                show_metadata=show_metadata,
                metadata_title=f"Generation Result {suffix}",
                output_title=f"Generated Text {suffix}",
            )

    def present_text_output(
        self, content: str, *, title: str = "Generated Text"
    ) -> None:
        output = GeneratedTextOutput(output_text=content)
        self.output.entity(
            output,
            title,
            [FieldConfig("output_text", "Output")],
            raw_payload=output,
        )
