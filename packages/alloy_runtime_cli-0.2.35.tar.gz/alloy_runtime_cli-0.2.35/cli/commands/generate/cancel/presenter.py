"""Presenter for async generation cancel command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.generation import AsyncGenerationCancelResponse


def present_generation_cancel(response: AsyncGenerationCancelResponse) -> None:
    """Present async generation cancel result."""
    output = OutputService.get()
    output.result(
        action="cancel",
        resource="text_generation",
        status=response.status,
        identifier=str(response.execution_id),
        name=None,
        extra_fields={
            "Was Running": response.was_running,
            "Message": response.message,
        },
    )
