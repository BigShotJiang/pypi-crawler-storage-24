"""Presenter for organizations create command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.organizations import OrganizationResponse


def present_create_result(response: OrganizationResponse) -> None:
    output = OutputService.get()
    output.result(
        action="create",
        resource="organization",
        identifier=str(response.id),
        name=response.name,
    )
