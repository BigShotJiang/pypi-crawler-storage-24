"""Billing project get command implementation."""

import typer

from cli.commands.billing.projects.get.presenter import present_billing_project
from cli.infrastructure.command import async_command, authenticated_client


def billing_projects_get_command(
    project_id: str = typer.Argument(
        ...,
        help="Billing project name or UUID",
    ),
) -> None:
    """Get details of a billing project.

    Examples:
        alloy billing projects get 123e4567-89ab-cdef-0123-456789abcdef
    """
    _execute_get(project_id=project_id)


@async_command
async def _execute_get(project_id: str) -> None:
    """Execute get billing project operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_billing_project(project_id)

    present_billing_project(response)
