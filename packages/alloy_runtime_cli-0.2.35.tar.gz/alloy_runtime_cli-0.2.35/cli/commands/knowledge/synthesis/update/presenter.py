"""Presenter for knowledge synthesis update command output."""

from cli.infrastructure.formatting.fields import format_datetime, format_uuid
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.knowledge import UpdateSynthesisResponse


def present_synthesis_update_result(
    response: UpdateSynthesisResponse,
) -> None:
    """Present synthesis update result.

    Args:
        response: UpdateSynthesisResponse from server
    """
    output = OutputService.get()
    output.result(
        action="update",
        resource="synthesis",
        identifier=format_uuid(response.id, short=False),
        name=response.title,
    )
    output.entity(
        response,
        "Synthesis Updated",
        [
            FieldConfig("id", "ID", lambda v: format_uuid(v, short=False)),
            FieldConfig("title", "Title"),
            FieldConfig("topic", "Topic"),
            FieldConfig("status", "Status"),
            FieldConfig("is_stale", "Stale"),
            FieldConfig("staleness_reason", "Staleness Reason"),
            FieldConfig("source_chunk_count", "Source Chunks", str),
            FieldConfig("updated_at", "Updated At", format_datetime),
        ],
        raw_payload=response,
    )
