"""Presenter for synthesis creation output."""

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import CreateSynthesisResponse


def present_synthesis_create_success(response: CreateSynthesisResponse) -> None:
    """Present successful synthesis creation.

    Args:
        response: Synthesis creation response from server
    """
    output = OutputService.get()
    output.result(
        action="create",
        resource="synthesis",
        status=response.status,
        identifier=format_uuid(response.synthesis_id, short=False),
        name=None,
        extra_fields={
            "Message": response.message,
            "Next Step": f"alloy knowledge synthesis get {response.synthesis_id}",
        },
    )
