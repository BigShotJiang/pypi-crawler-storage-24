"""Presenter for knowledge collection cluster command output."""

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.knowledge import (
    GetCollectionClusteringStatusResponse,
    TriggerCollectionClusteringResponse,
)


def present_cluster_triggered(response: TriggerCollectionClusteringResponse) -> None:
    """Present clustering trigger result.

    Args:
        response: TriggerCollectionClusteringResponse from server
    """
    output = OutputService.get()
    output.result(
        action="cluster",
        resource="knowledge_collection",
        status=response.status,
        identifier=str(response.collection_id),
        name=None,
        extra_fields={
            "Task ID": response.task_id,
            "Message": response.message,
        },
    )


def present_cluster_status(
    response: GetCollectionClusteringStatusResponse,
) -> None:
    """Present clustering status details.

    Args:
        response: GetCollectionClusteringStatusResponse from server
    """
    output = OutputService.get()

    output.entity(
        response,
        "Clustering Status",
        [
            FieldConfig(
                "collection_id", "Collection ID", lambda v: format_uuid(v, short=False)
            ),
            FieldConfig("status", "Status"),
            FieldConfig("cluster_count", "Cluster Count", str),
            FieldConfig("total_chunks", "Total Chunks", str),
            FieldConfig("clustered_chunks", "Clustered Chunks", str),
            FieldConfig("noise_chunks", "Noise Chunks", str),
            FieldConfig("unclustered_chunks", "Unclustered Chunks", str),
            FieldConfig("message", "Message", format_optional),
            FieldConfig("error_message", "Error", format_optional),
            FieldConfig("last_cluster_run_at", "Last Cluster Run", format_datetime),
        ],
        raw_payload=response,
    )
