"""Presenter for collection creation output."""

from cli.infrastructure.formatting.fields import (
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.knowledge import CreateCollectionResponse


def present_collection_create_success(response: CreateCollectionResponse) -> None:
    """Present successful collection creation.

    Args:
        response: Collection creation response from server
    """
    output = OutputService.get()
    output.result(
        action="create",
        resource="knowledge_collection",
        identifier=str(response.id),
        name=response.name,
    )
    output.entity(
        response,
        f"Collection: {response.name}",
        [
            FieldConfig("id", "ID", lambda v: format_uuid(v, short=False)),
            FieldConfig("name", "Name"),
            FieldConfig("description", "Description", format_optional),
            FieldConfig("embedding_model", "Embedding Model"),
            FieldConfig("chunk_size_tokens", "Chunk Size", lambda v: f"{v} tokens"),
            FieldConfig(
                "chunk_overlap_tokens", "Chunk Overlap", lambda v: f"{v} tokens"
            ),
            FieldConfig("section_strategy", "Section Strategy"),
        ],
        raw_payload=response,
    )
