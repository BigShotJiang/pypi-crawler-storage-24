"""Presenter for document ingest output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import IngestDocumentResponse


def present_ingest_success(response: IngestDocumentResponse) -> None:
    """Present successful document ingestion (queued for processing).

    Args:
        response: Document ingestion response from server
    """
    output = OutputService.get()
    extra_fields: dict[str, object] = {}
    if response.document_id is not None:
        extra_fields["Next Step"] = (
            f"alloy knowledge documents get {response.document_id}"
        )
    output.result(
        action="ingest",
        resource="knowledge_document",
        status=response.status,
        identifier=(
            str(response.document_id) if response.document_id is not None else None
        ),
        name=response.title,
        extra_fields=extra_fields or None,
    )
