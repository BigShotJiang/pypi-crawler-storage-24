"""Presenter for sync command output."""

from pydantic import BaseModel

from alloy_runtime_types.dtos.admin import SyncModelsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


class SyncSourceRow(BaseModel):
    source: str
    models: int
    providers: int
    status: str


def present_sync_models_success(response: SyncModelsResponse) -> None:
    output = OutputService.get()
    output.result(
        action="sync",
        resource="models",
        identifier=None,
        name=None,
        extra_fields={
            "Models Synced": response.total_models_synced,
            "Providers Synced": response.total_providers_synced,
        },
    )

    if response.by_source:
        output.table(
            items=[
                SyncSourceRow(
                    source=source_name,
                    models=result.models_synced,
                    providers=result.providers_synced,
                    status=result.error or "success",
                )
                for source_name, result in response.by_source.items()
            ],
            title=f"Sync Results by Source ({len(response.by_source)})",
            columns=[
                ColumnConfig("source", "Source"),
                ColumnConfig("models", "Models", str),
                ColumnConfig("providers", "Providers", str),
                ColumnConfig("status", "Status"),
            ],
            total_count=len(response.by_source),
        )
