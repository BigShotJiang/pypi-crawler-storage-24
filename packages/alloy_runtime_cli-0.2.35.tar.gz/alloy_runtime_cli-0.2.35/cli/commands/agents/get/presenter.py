"""Presenter for agents get command output."""

from alloy_runtime_types.dtos.agents import GetAgentResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def _format_configured_count(values: list[object]) -> str:
    return f"{len(values)} configured"


def _format_tags(response: GetAgentResponse) -> str:
    if not response.tags:
        return "[]"
    return ", ".join(tag.tag_path for tag in response.tags)


def present_agent_details(response: GetAgentResponse) -> None:
    output = OutputService.get()
    fields = [
        FieldConfig("id", "ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description"),
        FieldConfig("models", "Models", _format_configured_count),
        FieldConfig("tools", "Tools", _format_configured_count),
        FieldConfig("id", "Tags", lambda _: _format_tags(response)),
    ]

    output.entity(
        response,
        f"Agent: {response.name}",
        fields,
        raw_payload=response,
    )
