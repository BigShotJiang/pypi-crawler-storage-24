"""Presenter for agent delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.agents import DeleteAgentResponse


def present_delete_result(response: DeleteAgentResponse) -> None:
    """Present agent deletion result.

    Args:
        response: DeleteAgentResponse from server
    """
    output = OutputService.get()
    deleted = response.deleted_agent

    output.result(
        action="delete",
        resource="agent",
        identifier=str(deleted.id),
        name=deleted.name,
    )
