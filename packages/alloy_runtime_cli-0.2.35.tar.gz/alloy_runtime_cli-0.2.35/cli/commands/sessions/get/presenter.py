"""Presenter for session get command output."""

from alloy_runtime_types.dtos.sessions import SessionDetailResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _truncate(text: str | None, max_len: int = 200) -> str:
    """Truncate text for display."""
    if not text:
        return "-"
    _ = max_len
    return text


def present_session(response: SessionDetailResponse) -> None:
    output = OutputService.get()

    output.entity(
        response,
        f"Session: {response.name or str(response.id)}",
        [
            FieldConfig("id", "ID", str),
            FieldConfig("name", "Name", lambda value: value or "(unnamed)"),
            FieldConfig("total_messages", "Message Count", str),
            FieldConfig(
                "created_at",
                "Created",
                lambda value: value.strftime("%Y-%m-%d %H:%M:%S"),
            ),
        ],
        raw_payload=response,
    )

    if response.messages:
        output.table(
            items=response.messages,  # type: ignore[arg-type]
            title=f"Recent Messages ({len(response.messages)})",
            columns=[
                ColumnConfig("sequence_number", "Seq"),
                ColumnConfig("role", "Role"),
                ColumnConfig(
                    "content_parts",
                    "Content",
                    lambda parts: (
                        _truncate(parts[0].content_text, 100)
                        if parts and parts[0].content_text
                        else "-"
                    ),
                ),
            ],
        )
