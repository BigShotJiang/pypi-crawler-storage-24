"""Presenter for session messages command output."""

from typing import Any

from alloy_runtime_types.dtos.sessions import (
    ListSessionMessagesResponse,
)

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_content_parts(parts: list[Any]) -> str:
    if not parts:
        return "-"
    first_part: Any = parts[0]
    return getattr(first_part, "content_text", None) or "-"


def present_messages_list(response: ListSessionMessagesResponse) -> None:
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="sequence_number",
            header_label="#",
            align="right",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="role",
            header_label="Role",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="created_at",
            header_label="Time",
            formatter=lambda x: x.strftime("%H:%M:%S") if x else "-",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="content_parts",
            header_label="Content",
            formatter=_format_content_parts,
            compact_line=3,
            compact_style="dim",
        ),
    ]

    output.table(
        items=response.messages,  # type: ignore[arg-type]
        title=f"Messages ({response.total})",
        columns=columns,
        raw_payload=response,
        total_count=response.total,
    )
