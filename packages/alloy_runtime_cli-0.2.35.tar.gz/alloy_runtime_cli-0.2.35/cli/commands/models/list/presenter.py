"""Presenter for models list command output."""

from typing import TYPE_CHECKING

from pydantic import BaseModel

from alloy_runtime_types.dtos.models import ListModelsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig

if TYPE_CHECKING:
    from cli.commands.models.list.command import DisplayColumn


class ModelListRow(BaseModel):
    provider: str
    model: str
    context_window: str | None = None
    max_output: str | None = None
    input_modalities: str = "[]"
    output_modalities: str = "[]"


def _format_int(value: int | None) -> str | None:
    if value is None:
        return None
    return f"{value:,}"


def _format_modalities(values: list[str]) -> str:
    if not values:
        return "[]"
    return ", ".join(sorted(values))


def _build_rows(response: ListModelsResponse) -> list[BaseModel]:
    return [
        ModelListRow(
            provider=model.provider_key,
            model=model.provider_model_name,
            context_window=_format_int(model.context_window),
            max_output=_format_int(model.max_output_tokens),
            input_modalities=_format_modalities(model.input_modalities),
            output_modalities=_format_modalities(model.output_modalities),
        )
        for model in response.models
    ]


def present_models_list(
    response: ListModelsResponse,
    *,
    display_column: "DisplayColumn | None" = None,
    extra_fields: bool = False,
) -> None:
    from cli.commands.models.list.command import DisplayColumn

    output = OutputService.get()
    rows = _build_rows(response)

    if display_column == DisplayColumn.PROVIDER:
        columns = [
            ColumnConfig(
                source_field="provider",
                header_label="Provider",
            ),
        ]
    elif display_column == DisplayColumn.MODEL:
        columns = [
            ColumnConfig(
                source_field="model",
                header_label="Model",
            ),
        ]
    elif extra_fields:
        columns = [
            ColumnConfig(
                source_field="provider",
                header_label="Provider",
            ),
            ColumnConfig(
                source_field="model",
                header_label="Model",
            ),
            ColumnConfig(
                source_field="context_window",
                header_label="Context Window",
            ),
            ColumnConfig(
                source_field="max_output",
                header_label="Max Output",
            ),
            ColumnConfig(
                source_field="input_modalities",
                header_label="Input Modalities",
            ),
            ColumnConfig(
                source_field="output_modalities",
                header_label="Output Modalities",
            ),
        ]
    else:
        columns = [
            ColumnConfig(source_field="provider", header_label="Provider"),
            ColumnConfig(source_field="model", header_label="Model"),
        ]

    output.table(
        items=rows,
        title="Models",
        columns=columns,
        raw_payload=response,
    )
