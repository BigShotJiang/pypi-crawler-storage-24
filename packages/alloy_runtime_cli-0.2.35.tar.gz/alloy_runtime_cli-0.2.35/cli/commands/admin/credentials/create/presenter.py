"""Presenter for admin credentials create command output."""

from cli.commands.credentials.update.fields import CREDENTIAL_FIELDS
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.credentials import SystemCredentialResponse


def present_credential_create_success(credential: SystemCredentialResponse) -> None:
    """Present a successful credential creation with Rich formatting.

    Args:
        credential: Created credential data from server
    """
    output = OutputService.get()
    output.result(
        action="create",
        resource="system_credential",
        identifier=str(credential.id),
        name=credential.name,
    )
    output.entity(
        credential,
        "System Credential Details",
        CREDENTIAL_FIELDS,
        raw_payload=credential,
    )
