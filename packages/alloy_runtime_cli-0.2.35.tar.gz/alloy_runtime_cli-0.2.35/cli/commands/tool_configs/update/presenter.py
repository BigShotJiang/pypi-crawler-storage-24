"""Presenter for tool config update command output."""

from cli.commands.tool_configs.get.presenter import present_tool_config_details
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tool_configs import UpdateToolConfigResponse


def present_tool_config_update_success(response: UpdateToolConfigResponse) -> None:
    """Present successful tool config update.

    Args:
        response: Tool config update response from server
    """
    output = OutputService.get()

    output.result(
        action="update",
        resource="tool_config",
        identifier=str(response.id),
        name=response.name,
    )
    present_tool_config_details(response)
