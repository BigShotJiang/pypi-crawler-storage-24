"""Tool config delete command implementation."""

import typer

from cli.commands.tool_configs.delete.presenter import present_tool_config_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def tool_configs_delete_command(
    identifier: str = typer.Argument(
        ...,
        help="Tool config UUID or slug",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a tool config.

    Deletion fails if the tool config is currently referenced by any agent.

    Examples:
        alloy tool-configs delete my-config
        alloy tool-configs delete 550e8400-e29b-41d4-a716-446655440000 -y
        alloy tool-configs delete my-config -y
    """
    _execute_delete(identifier=identifier, skip_confirm=yes)


@async_command
async def _execute_delete(identifier: str, skip_confirm: bool) -> None:
    """Execute delete tool config operation."""
    if not skip_confirm:
        confirmed = Confirm.ask(
            f"Delete tool config '{identifier}'? This cannot be undone"
        )
        if not confirmed:
            raise typer.Abort()

    async with authenticated_client() as (_config, client):
        response = await client.delete_tool_config(identifier)

    present_tool_config_delete_result(response)
