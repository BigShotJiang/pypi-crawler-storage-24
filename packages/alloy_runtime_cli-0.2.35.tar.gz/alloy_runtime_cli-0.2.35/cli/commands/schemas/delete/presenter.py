"""Presenter for schemas delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.schemas import DeleteSchemaResponse


def present_delete_result(response: DeleteSchemaResponse) -> None:
    output = OutputService.get()
    output.result(
        action="delete",
        resource="schema",
        identifier=str(response.deleted_schema.id),
        name=response.deleted_schema.schema_name,
    )
