from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.api_keys import CreateApiKeyResponse


def present_api_key_create_success(response: CreateApiKeyResponse) -> None:
    output = OutputService.get()
    output.result(
        action="create",
        resource="api_key",
        identifier=str(response.id),
        name=response.prefix,
        extra_fields={
            "Note": "Save the plaintext key now; it will not be shown again.",
        },
    )

    fields = [
        FieldConfig("id", "ID", lambda v: format_uuid(v, short=False)),
        FieldConfig("key", "Plaintext Key"),
        FieldConfig("prefix", "Prefix"),
        FieldConfig("description", "Description", format_optional),
        FieldConfig(
            "scopes",
            "Scopes",
            lambda values: ", ".join(scope.value for scope in values),
        ),
        FieldConfig("created_at", "Created At", format_datetime),
        FieldConfig("expires_at", "Expires At", format_datetime),
    ]

    output.entity(response, "API Key", fields, raw_payload=response)
