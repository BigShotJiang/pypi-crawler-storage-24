"""Presenter for content delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.content import DeleteContentPartResponse


def present_delete_result(response: DeleteContentPartResponse) -> None:
    """Present content part deletion result.

    Args:
        response: DeleteContentPartResponse from server
    """
    output = OutputService.get()
    deleted = response.deleted_content_part

    output.result(
        action="delete",
        resource="content_part",
        identifier=str(deleted.id),
        name=None,
    )
