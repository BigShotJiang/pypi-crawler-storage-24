"""Presenter for credentials create command output."""

from cli.commands.credentials.create.fields import ORG_CREDENTIAL_FIELDS
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.organization_credentials import (
    OrganizationCredentialResponse,
)


def present_org_credential_create_success(
    credential: OrganizationCredentialResponse,
) -> None:
    """Present a successful organization credential creation with Rich formatting.

    Args:
        credential: Created organization credential data from server
    """
    output = OutputService.get()
    output.result(
        action="create",
        resource="organization_credential",
        identifier=str(credential.id),
        name=credential.name,
    )
    output.entity(
        credential,
        "Organization Credential Details",
        ORG_CREDENTIAL_FIELDS,
        raw_payload=credential,
    )
