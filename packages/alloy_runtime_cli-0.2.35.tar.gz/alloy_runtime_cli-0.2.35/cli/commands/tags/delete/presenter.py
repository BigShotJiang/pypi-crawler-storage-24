"""Presenter for tag delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tags import DeleteTagResponse


def present_delete_result(response: DeleteTagResponse) -> None:
    """Present tag deletion result."""
    output = OutputService.get()
    output.result(
        action="delete",
        resource="tag",
        identifier=response.deleted_tag.id,
        name=response.deleted_tag.tag_path,
    )
