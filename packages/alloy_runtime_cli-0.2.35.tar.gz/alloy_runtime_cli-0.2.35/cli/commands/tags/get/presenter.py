"""Presenter for tags get command output."""

from typing import Any, cast

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.tags import GetTagResponse


def _format_optional_text(value: str | None) -> Any:
    if value is None:
        return cast(str, None)
    return value


def present_tag_details(response: GetTagResponse) -> None:
    output = OutputService.get()
    output.entity(
        response.tag,
        f"Tag: {response.tag.tag_path}",
        [
            FieldConfig("id", "ID", str),
            FieldConfig("tag_path", "Tag Path"),
            FieldConfig("display_name", "Display Name", _format_optional_text),
            FieldConfig("description", "Description", _format_optional_text),
        ],
        raw_payload=response,
    )
