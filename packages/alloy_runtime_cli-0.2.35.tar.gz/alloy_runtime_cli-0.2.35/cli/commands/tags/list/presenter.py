"""Presenter for tags list command output."""

from alloy_runtime_types.dtos.tags import ListTagsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def present_tags_list(response: ListTagsResponse) -> None:
    """Present list of tags with Rich table formatting."""
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="tag_path",
            header_label="Path",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="display_name",
            header_label="Display Name",
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=lambda x: x or "-",
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=response.tags,  # type: ignore[arg-type]
        title=f"Tags ({response.total})",
        columns=columns,
        raw_payload=response,
        total_count=response.total,
    )
