"""Presenter for pipeline execution update command output."""

from pydantic import BaseModel

from alloy_runtime_types.dtos.pipeline import UpdatePipelineExecutionResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


class ExecutionUpdateDetails(BaseModel):
    tags: str
    metadata: str | None = None


def present_execution_update(response: UpdatePipelineExecutionResponse) -> None:
    output = OutputService.get()
    execution = response.execution

    fields = [
        FieldConfig("id", "Execution ID", str),
        FieldConfig("pipeline_definition_id", "Pipeline ID", str),
        FieldConfig("status", "Status"),
    ]

    output.entity(execution, "Execution Updated", fields, raw_payload=response)

    output.entity(
        ExecutionUpdateDetails(
            tags=", ".join(t.tag_path for t in execution.tags)
            if execution.tags
            else "(none)",
            metadata=str(execution.metadata) if execution.metadata else None,
        ),
        "Execution Update Details",
        [
            FieldConfig("tags", "Tags"),
            FieldConfig("metadata", "Metadata"),
        ],
    )
