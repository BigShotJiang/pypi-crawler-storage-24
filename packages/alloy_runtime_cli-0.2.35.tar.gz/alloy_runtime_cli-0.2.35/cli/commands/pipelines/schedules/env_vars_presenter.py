from pydantic import BaseModel

from alloy_runtime_types.dtos.schedule import SetScheduleEnvVarsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


class ScheduleEnvVarsOutput(BaseModel):
    masked_values: str


def present_set_env_vars_result(response: SetScheduleEnvVarsResponse) -> None:
    output = OutputService.get()

    if not response.env_var_keys:
        output.result(
            action="clear",
            resource="schedule_env_vars",
            identifier=str(response.schedule_id),
            name=None,
        )
        return

    output.result(
        action="set",
        resource="schedule_env_vars",
        identifier=str(response.schedule_id),
        name=None,
        extra_fields={"Count": len(response.env_var_keys)},
    )
    output.entity(
        ScheduleEnvVarsOutput(
            masked_values="\n".join(
                f"{key}: {response.masked_values.get(key, '***')}"
                for key in response.env_var_keys
            )
        ),
        "Schedule Env Vars",
        [FieldConfig("masked_values", "Masked Values")],
    )
