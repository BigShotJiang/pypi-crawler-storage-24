"""Presenter for pipeline get command output."""

import json

from pydantic import BaseModel

from alloy_runtime_types.dtos.pipeline import (
    GetPipelineResponse,
    UpdatePipelineResponse,
)

from cli.infrastructure.formatting.fields import format_datetime, format_optional
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


class PipelineBodyOutput(BaseModel):
    content: str


def present_pipeline(response: GetPipelineResponse | UpdatePipelineResponse) -> None:
    """Present pipeline details with Rich formatting."""
    output = OutputService.get()

    fields = [
        FieldConfig("id", "ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description", format_optional),
        FieldConfig("is_public", "Public", lambda v: "Yes" if v else "No"),
        FieldConfig("created_at", "Created", format_datetime),
        FieldConfig("updated_at", "Updated", format_datetime),
    ]

    if isinstance(response, GetPipelineResponse):
        fields.insert(3, FieldConfig("source_hash", "Source Hash", format_optional))

    output.entity(response, f"Pipeline: {response.name}", fields, raw_payload=response)

    if response.input_schema:
        output.entity(
            PipelineBodyOutput(content=json.dumps(response.input_schema, indent=2)),
            "Input Schema",
            [FieldConfig("content", "Input Schema")],
        )

    if response.module_content:
        output.entity(
            PipelineBodyOutput(content=response.module_content),
            "Module Content",
            [FieldConfig("content", "Module Content")],
        )
