"""Common formatting utilities for CLI display."""

from alloy_runtime_types.enums.ownership_scope import OwnershipScope
from textual.widgets import RadioSet


def format_scope_label(
    organization_id: str | None,
    user_id: str | None,
) -> str:
    """Format ownership scope as human-readable label.

    Args:
        organization_id: Organization UUID if org-owned
        user_id: User UUID if user-owned

    Returns:
        Scope string: "User", "Org", or "Global"
    """
    if user_id:
        return "User"
    elif organization_id:
        return "Org"
    return "Global"


def get_scope_from_radioset(
    radioset: RadioSet,
    user_id: str = "scope-user",
    org_id: str = "scope-org",
) -> OwnershipScope:
    """Extract OwnershipScope from a RadioSet widget.

    Args:
        radioset: The RadioSet containing scope radio buttons
        user_id: ID of the user scope radio button
        org_id: ID of the org scope radio button

    Returns:
        OwnershipScope enum value
    """
    pressed = radioset.pressed_button
    if pressed is None or pressed.id == org_id:
        return OwnershipScope.ORGANIZATION
    elif pressed.id == user_id:
        return OwnershipScope.USER
    return OwnershipScope.GLOBAL
