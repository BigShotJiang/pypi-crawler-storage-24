"""Web routes — page rendering + htmx fragment endpoints."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import shutil
import tempfile
import time
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse

from dlightrag.citations import (
    CitationProcessor,
    extract_highlights_for_sources,
)
from dlightrag.citations.source_builder import build_sources
from dlightrag.config import get_config

from .deps import get_manager, get_workspace, templates
from .markdown import render_markdown

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/web", tags=["web"])


# ---------------------------------------------------------------------------
# Helpers — data preparation (no HTML)
# ---------------------------------------------------------------------------


def _render_partial(name: str, **ctx: Any) -> str:
    """Render a Jinja2 partial template to string."""
    return templates.env.get_template(name).render(**ctx)


# ---------------------------------------------------------------------------
# Page routes
# ---------------------------------------------------------------------------


@router.get("/", response_class=HTMLResponse)
async def index(request: Request, workspace: str = Depends(get_workspace)):
    """Main page."""
    return templates.TemplateResponse(
        request,
        "index.html",
        {"workspace": workspace},
    )


# ---------------------------------------------------------------------------
# Answer streaming (SSE)
# ---------------------------------------------------------------------------


@router.post("/answer")
async def answer_stream(
    request: Request,
    workspace: str = Depends(get_workspace),
):
    """Stream answer via SSE, then swap in enriched citations."""
    body = await request.json()
    query = str(body.get("query", ""))
    if not query:
        return HTMLResponse("<span>Please enter a question.</span>")

    conversation_history: list[dict[str, str]] | None = body.get("conversation_history")

    cfg = get_config()

    # Extract images (base64 from frontend)
    images_b64: list[str] = body.get("images", [])
    multimodal_content: list[dict[str, Any]] | None = None
    tmp_paths: list[str] = []
    if images_b64:
        multimodal_content = []
        for b64 in images_b64[:3]:  # enforce 3-image limit
            try:
                img_bytes = base64.b64decode(b64)
                if len(img_bytes) > 10 * 1024 * 1024:  # 10MB server-side limit
                    logger.warning("Skipping oversized image (%d bytes)", len(img_bytes))
                    continue
                tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
                tmp.write(img_bytes)
                tmp.close()
                tmp_paths.append(tmp.name)
                multimodal_content.append({"type": "image", "img_path": tmp.name})
            except Exception:
                logger.warning("Failed to decode uploaded image", exc_info=True)
        if not multimodal_content:
            multimodal_content = None

    # Extract workspaces (multi-select from frontend)
    workspaces: list[str] | None = body.get("workspaces")

    manager = get_manager(request)

    async def event_generator() -> AsyncIterator[str]:
        full_answer = ""
        try:
            # Tell frontend how many history messages are in context
            history_kept = len(conversation_history) if conversation_history else 0
            yield f"event: meta\ndata: {json.dumps({'history_kept': history_kept})}\n\n"

            t0 = time.monotonic()
            logger.info("[SSE] query received: %s", query[:80])

            # --- Phase 1: Query planning ---
            yield f"event: progress\ndata: {json.dumps({'phase': 'planning'})}\n\n"

            ws_list = workspaces or [workspace or manager._config.workspace]
            planner = manager._get_query_planner()
            plan = await planner.plan(
                query,
                conversation_history=conversation_history,
                max_turns=manager._config.max_conversation_turns,
                max_tokens=manager._config.max_conversation_tokens,
            )
            t1 = time.monotonic()
            logger.info(
                "[SSE] planning done (%.1fs): original=%r, standalone=%r",
                t1 - t0,
                plan.original_query[:60],
                plan.standalone_query[:60],
            )

            # --- Phase 2: Retrieval ---
            yield f"event: progress\ndata: {json.dumps({'phase': 'searching'})}\n\n"

            retrieval = await manager.aretrieve(
                query,
                plan=plan,
                workspaces=ws_list,
                multimodal_content=multimodal_content,
            )
            t2 = time.monotonic()
            logger.info("[SSE] retrieval done (%.1fs)", t2 - t1)

            # --- Phase 3: Answer generation (streaming) ---
            yield f"event: progress\ndata: {json.dumps({'phase': 'generating'})}\n\n"

            engine = manager._get_answer_engine()
            contexts, token_iter = await engine.generate_stream(
                plan.standalone_query,
                retrieval.contexts,
            )
            logger.info("[SSE] stream started (%.1fs since retrieval)", time.monotonic() - t2)

            # token_iter may be an AsyncIterator, a plain str, or None
            # depending on the RAG mode and provider capabilities.
            accumulated_text = ""
            last_preview_ts = 0.0
            last_preview_len = 0

            if token_iter is None:
                pass
            elif isinstance(token_iter, str):
                full_answer = token_iter
                accumulated_text = token_iter
                yield f"event: token\ndata: {json.dumps(token_iter)}\n\n"
            else:
                async for chunk in token_iter:
                    full_answer += chunk
                    accumulated_text += chunk
                    yield f"event: token\ndata: {json.dumps(chunk)}\n\n"
                    now = time.monotonic()
                    new_chars = len(accumulated_text) - last_preview_len
                    if now - last_preview_ts > 0.3 and new_chars > 20:
                        preview_html = render_markdown(accumulated_text)
                        yield f"event: preview\ndata: {json.dumps(preview_html)}\n\n"
                        last_preview_ts = now
                        last_preview_len = len(accumulated_text)

            # AnswerStream cleans invalid citations; use its answer if available
            clean_answer = getattr(token_iter, "answer", None) or full_answer

            # Build cited-only sources
            flat_contexts = []
            for items in contexts.values():
                if isinstance(items, list):
                    flat_contexts.extend(items)

            sources = build_sources(contexts)

            processor = CitationProcessor(
                contexts=flat_contexts,
                available_sources=sources,
            )
            result = processor.process(clean_answer)

            # Rebuild references section from cited-only sources
            if result.sources:
                ref_lines = [f"[{s.id}] {s.title}" for s in result.sources]
                result.answer += "\n\n### References\n" + "\n".join(ref_lines)

            # Send done event immediately (sources without highlights)
            done_html = _render_partial(
                "partials/answer_done.html",
                answer=result.answer,
                sources=result.sources,
            )
            yield f"event: done\ndata: {json.dumps(done_html)}\n\n"

            # Highlight extraction (best-effort, short timeout since done is sent)
            has_text_chunks = any(
                chunk.content for src in result.sources if src.chunks for chunk in src.chunks
            )
            if has_text_chunks:
                try:
                    from dlightrag.models.llm import get_chat_model_func

                    llm_func = get_chat_model_func(cfg)
                    highlighted_sources = await asyncio.wait_for(
                        extract_highlights_for_sources(
                            sources=result.sources,
                            answer_text=result.answer,
                            llm_func=llm_func,
                        ),
                        timeout=5.0,
                    )
                    highlights_html = _render_partial(
                        "partials/source_panel.html",
                        sources=highlighted_sources,
                    )
                    yield f"event: highlights\ndata: {json.dumps(highlights_html)}\n\n"
                except TimeoutError:
                    logger.warning("Highlight extraction timed out (5s), skipping")
                except Exception:
                    logger.warning("Highlight extraction failed", exc_info=True)

        except Exception:
            logger.exception("Answer streaming failed")
            yield "event: error\ndata: Service error. Please try again.\n\n"
        finally:
            # Clean up temp image files
            for p in tmp_paths:
                Path(p).unlink(missing_ok=True)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# File management
# ---------------------------------------------------------------------------


@router.get("/files", response_class=HTMLResponse)
async def file_list(request: Request, workspace: str = Depends(get_workspace)):
    """Return file list HTML fragment for panel."""
    manager = get_manager(request)
    try:
        files = await manager.list_ingested_files(workspace)
    except Exception:
        files = []

    return templates.TemplateResponse(
        request,
        "partials/file_list.html",
        {"files": files, "workspace": workspace},
    )


@router.post("/files/upload", response_class=HTMLResponse)
async def upload_files(
    request: Request,
    files: list[UploadFile] = File(...),
    workspace: str = Depends(get_workspace),
):
    """Upload and ingest files."""
    manager = get_manager(request)

    tmp_dir = Path(tempfile.mkdtemp(prefix="dlightrag_upload_"))
    try:
        for f in files:
            if not f.filename:
                continue
            dest = tmp_dir / f.filename
            with open(dest, "wb") as out:
                shutil.copyfileobj(f.file, out)

        await manager.aingest(
            workspace=workspace,
            source_type="local",
            path=str(tmp_dir),
        )
    except Exception as e:
        logger.exception("Upload/ingestion failed")
        return HTMLResponse(_render_partial("partials/error.html", message=f"Upload failed: {e}"))

    return await file_list(request, workspace)


@router.delete("/files", response_class=HTMLResponse)
async def delete_files(
    request: Request,
    workspace: str = Depends(get_workspace),
):
    """Delete files from workspace."""
    # htmx sends hx-vals as query params for DELETE requests
    file_path = request.query_params.get("file_path", "")
    file_paths = [file_path] if file_path else []
    manager = get_manager(request)

    try:
        await manager.delete_files(workspace, file_paths=file_paths)
    except Exception as e:
        logger.exception("Delete failed")
        return HTMLResponse(_render_partial("partials/error.html", message=f"Delete failed: {e}"))

    return await file_list(request, workspace)


# ---------------------------------------------------------------------------
# Ingestion progress (SSE)
# ---------------------------------------------------------------------------


@router.get("/ingest/progress")
async def ingest_progress(request: Request):
    """SSE endpoint for ingestion progress -- pushes task event dicts.

    Event types sent to the client:
    - ``snapshot``: all current tasks (initial state)
    - ``task_created``: new task submitted
    - ``progress``: task updated (status/step/progress changed)
    - ``done``: task completed successfully
    - ``failed``: task failed with error
    """
    ingest_mgr = getattr(request.app.state, "ingest_task_manager", None)
    if ingest_mgr is None:

        async def _no_mgr() -> AsyncIterator[str]:
            yield f"event: error\ndata: {json.dumps({'detail': 'Ingest task manager not available'})}\n\n"

        return StreamingResponse(
            _no_mgr(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    # Map internal event types to client SSE event names
    _EVENT_MAP = {
        "snapshot": "snapshot",
        "task_created": "task_created",
        "task_updated": "progress",
        "task_progress": "progress",
        "task_done": "done",
        "task_failed": "failed",
    }

    async def stream() -> AsyncIterator[str]:
        async for event in ingest_mgr.subscribe():
            if await request.is_disconnected():
                break

            etype = event.get("type", "")
            sse_name = _EVENT_MAP.get(etype)
            if not sse_name:
                continue

            # Encode the event payload as JSON
            if sse_name == "snapshot":
                tasks = event.get("tasks", [])
                yield f"event: snapshot\ndata: {json.dumps(tasks)}\n\n"
            else:
                task = event.get("task", {})
                yield f"event: {sse_name}\ndata: {json.dumps(task)}\n\n"

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------


@router.get("/workspaces", response_class=HTMLResponse)
async def workspace_list(request: Request, workspace: str = Depends(get_workspace)):
    """Return workspace list fragment."""
    manager = get_manager(request)
    try:
        workspaces = await manager.list_workspaces()
    except Exception:
        workspaces = ["default"]

    return templates.TemplateResponse(
        request,
        "partials/workspace_list.html",
        {"workspaces": workspaces, "current_workspace": workspace},
    )


@router.post("/workspaces/switch")
async def switch_workspace(request: Request):
    """Switch workspace via cookie."""
    form = await request.form()
    workspace = str(form.get("workspace", "default"))
    response = RedirectResponse(url="/web/", status_code=303)
    response.set_cookie("dlightrag_workspace", workspace, httponly=True)
    return response


_WS_FORBIDDEN_RE = re.compile(r'[/\\<>"\']')


@router.post("/workspaces/create", response_class=HTMLResponse)
async def create_workspace(
    request: Request,
    workspace_name: str = Form(default=""),
    workspace: str = Depends(get_workspace),
):
    """Create a new workspace and return updated workspace list."""
    from dlightrag.utils import normalize_workspace

    manager = get_manager(request)
    name = workspace_name.strip()

    # Validation
    if not name:
        return HTMLResponse("Workspace name cannot be empty", status_code=400)
    if len(name) > 64:
        return HTMLResponse("Workspace name too long (max 64 characters)", status_code=400)
    if _WS_FORBIDDEN_RE.search(name):
        return HTMLResponse("Workspace name contains forbidden characters", status_code=400)

    ws = normalize_workspace(name)

    # Duplicate check
    existing = await manager.list_workspaces()
    if ws in existing:
        return HTMLResponse(f"Workspace '{name}' already exists", status_code=409)

    # Initialize workspace (creates the RAGService)
    try:
        await manager._get_service(ws)
    except Exception as e:
        logger.exception("Workspace creation failed")
        return HTMLResponse(f"Failed to create workspace: {e}", status_code=500)

    # Return updated workspace list
    workspaces = await manager.list_workspaces()
    html = _render_partial(
        "partials/workspace_list.html",
        workspaces=workspaces,
        current_workspace=workspace,
    )
    return HTMLResponse(
        html,
        headers={"HX-Trigger": json.dumps({"workspaceCreated": {"workspace": ws}})},
    )


@router.post("/workspaces/delete", response_class=HTMLResponse)
async def delete_workspace(
    request: Request,
    workspace_name: str = Form(default=""),
    confirm_name: str = Form(default=""),
):
    """Delete a workspace after type-to-confirm verification."""
    from dlightrag.utils import normalize_workspace

    manager = get_manager(request)
    name = workspace_name.strip()
    confirm = confirm_name.strip()

    if not name:
        return HTMLResponse("Workspace name cannot be empty", status_code=400)
    if normalize_workspace(name) != normalize_workspace(confirm):
        return HTMLResponse("Confirmation name does not match", status_code=400)

    ws = normalize_workspace(name)

    try:
        await manager.areset(workspace=ws)
    except Exception as e:
        logger.exception("Workspace deletion failed")
        return HTMLResponse(f"Failed to delete workspace: {e}", status_code=500)

    # Return updated workspace list, falling back to first available
    workspaces = await manager.list_workspaces()
    fallback = workspaces[0] if workspaces else "default"

    # Switch cookie to fallback workspace
    html = _render_partial(
        "partials/workspace_list.html",
        workspaces=workspaces,
        current_workspace=fallback,
    )
    return HTMLResponse(
        html,
        headers={"HX-Trigger": json.dumps({"workspaceDeleted": {"workspace": ws}})},
    )
