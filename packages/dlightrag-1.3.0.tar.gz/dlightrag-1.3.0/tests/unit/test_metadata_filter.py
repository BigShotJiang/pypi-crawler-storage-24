# Copyright 2025-2026 Hanlian Lu. SPDX-License-Identifier: Apache-2.0
"""Tests for MetadataFilter and RetrievalPlan data models."""

from __future__ import annotations

from datetime import datetime

from dlightrag.core.retrieval.models import MetadataFilter, RetrievalPlan


class TestMetadataFilter:
    def test_empty_filter(self) -> None:
        f = MetadataFilter()
        assert f.is_empty()

    def test_filename_makes_non_empty(self) -> None:
        f = MetadataFilter(filename="test.pdf")
        assert not f.is_empty()

    def test_custom_metadata_makes_non_empty(self) -> None:
        f = MetadataFilter(custom={"department": "finance"})
        assert not f.is_empty()

    def test_file_extension_makes_non_empty(self) -> None:
        f = MetadataFilter(file_extension=".png")
        assert not f.is_empty()

    def test_date_range_makes_non_empty(self) -> None:
        f = MetadataFilter(date_from=datetime(2024, 1, 1))
        assert not f.is_empty()

    def test_all_none_is_empty(self) -> None:
        f = MetadataFilter(
            filename=None,
            filename_pattern=None,
            file_extension=None,
            doc_title=None,
            doc_author=None,
            date_from=None,
            date_to=None,
            rag_mode=None,
            custom=None,
        )
        assert f.is_empty()


class TestRetrievalPlan:
    def test_default_paths(self) -> None:
        plan = RetrievalPlan(query="test", metadata_filters=None)
        assert plan.paths == ["kgvector"]

    def test_with_filters(self) -> None:
        f = MetadataFilter(filename="test.pdf")
        plan = RetrievalPlan(
            query="test",
            metadata_filters=f,
            paths=["metafilters", "kgvector"],
        )
        assert "metafilters" in plan.paths
        assert "kgvector" in plan.paths

    def test_query_preserved_unchanged(self) -> None:
        """Query is always stored unchanged (no rewriting by analyzer)."""
        plan = RetrievalPlan(
            query="original query with file.pdf",
            metadata_filters=None,
        )
        assert plan.query == "original query with file.pdf"


class TestRrfKConfig:
    def test_rrf_k_default(self) -> None:
        from dlightrag.config import DlightragConfig, EmbeddingConfig, ModelConfig

        config = DlightragConfig(  # type: ignore[call-arg]
            chat=ModelConfig(model="gpt-4.1-mini", api_key="test-key"),
            embedding=EmbeddingConfig(api_key="test-key"),
        )
        assert config.rrf_k == 60

    def test_rrf_k_custom(self) -> None:
        from dlightrag.config import DlightragConfig, EmbeddingConfig, ModelConfig

        config = DlightragConfig(  # type: ignore[call-arg]
            chat=ModelConfig(model="gpt-4.1-mini", api_key="test-key"),
            embedding=EmbeddingConfig(api_key="test-key"),
            rrf_k=100,
        )
        assert config.rrf_k == 100
