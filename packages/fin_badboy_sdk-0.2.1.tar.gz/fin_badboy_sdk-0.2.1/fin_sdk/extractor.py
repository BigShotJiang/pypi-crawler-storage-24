"""Extractor registry — derives usage and model from raw provider responses."""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger("fin_sdk")


def _extract_openai(response: Any) -> Optional[Dict]:
    """OpenAI, Groq, Azure OpenAI — response.usage.prompt_tokens etc."""
    u = getattr(response, "usage", None)
    model = getattr(response, "model", None) or ""

    if u is None:
        return {"usage": {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0}, "model": model}

    return {
        "usage": {
            "inputTokens": getattr(u, "prompt_tokens", 0) or 0,
            "outputTokens": getattr(u, "completion_tokens", 0) or 0,
            "totalTokens": getattr(u, "total_tokens", 0) or 0,
        },
        "model": model,
    }


def _extract_anthropic(response: Any) -> Optional[Dict]:
    """Anthropic — response.usage.input_tokens etc.; derives totalTokens."""
    u = getattr(response, "usage", None)
    model = getattr(response, "model", None) or ""

    if u is None:
        return {"usage": {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0}, "model": model}

    input_tokens = getattr(u, "input_tokens", 0) or 0
    output_tokens = getattr(u, "output_tokens", 0) or 0

    return {
        "usage": {
            "inputTokens": input_tokens,
            "outputTokens": output_tokens,
            "totalTokens": input_tokens + output_tokens,
        },
        "model": model,
    }


def _google_count(usage_meta: Any, camel: str, snake: str) -> int:
    v = getattr(usage_meta, camel, None)
    if v is None:
        v = getattr(usage_meta, snake, None)
    if v is None:
        return 0
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _extract_google(response: Any) -> Optional[Dict]:
    """Google Gemini — usageMetadata / usage_metadata token counts (Vertex / google-generative-ai)."""
    um = getattr(response, "usageMetadata", None) or getattr(response, "usage_metadata", None)
    raw_model = (
        getattr(response, "model", None)
        or getattr(response, "modelVersion", None)
        or getattr(response, "model_version", None)
    )
    model = "" if raw_model is None else str(raw_model)

    if um is None:
        return {"usage": {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0}, "model": model}

    input_tokens = _google_count(um, "promptTokenCount", "prompt_token_count")
    output_tokens = _google_count(um, "candidatesTokenCount", "candidates_token_count")
    total_tokens = _google_count(um, "totalTokenCount", "total_token_count")
    if not total_tokens:
        total_tokens = input_tokens + output_tokens

    return {
        "usage": {
            "inputTokens": input_tokens,
            "outputTokens": output_tokens,
            "totalTokens": total_tokens,
        },
        "model": model,
    }


EXTRACTORS: Dict[str, Callable[[Any], Optional[Dict]]] = {
    "openai": _extract_openai,
    "groq": _extract_openai,
    "azure_openai": _extract_openai,
    "anthropic": _extract_anthropic,
    "google": _extract_google,
    "mistral": _extract_openai,
}


def extract(response: Any, provider: str) -> Optional[Dict]:
    """
    Extract usage and model from a raw provider response.

    Looks up the provider in the extractor registry and calls the matching extractor.
    Returns None for unknown providers or on extractor failure.
    """
    extractor = EXTRACTORS.get(provider)
    if extractor is None:
        return None
    try:
        return extractor(response)
    except Exception as exc:
        logger.warning("[fin-sdk] extractor failed for provider %r: %s", provider, exc)
        return None
