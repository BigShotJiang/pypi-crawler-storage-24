"""FinClient — convenience class wrapping track_response, track, and resolve_model."""
from __future__ import annotations

import logging
import os
import random
import time
from typing import Any, Dict, Optional, Tuple, TypedDict

import requests as _requests

from .track import track_response as _track_response_impl, track as _track_impl

logger = logging.getLogger("fin_sdk")


class ResolvedModel(TypedDict):
    model: str
    provider: str
    experiment_id: str


class ResolveConfig(TypedDict):
    experimentId: str
    variants: list


class FinClient:
    """
    Client for the fin ingest API with optional A/B experiment resolution.

    Usage::

        fin = FinClient(
            ingest_url="https://events.badboy.dev",
            api_key="sk-...",
            api_url="https://api.badboy.dev",
            experiments_enabled=True,
        )

        # Resolve which model variant to use for a feature
        resolved = fin.resolve_model("chat", user_id="user-42")
        if resolved:
            model = resolved["model"]
            provider = resolved["provider"]

        # Track a response and associate it with the experiment
        fin.track_response(
            response=llm_response,
            provider=provider,
            feature_id="chat",
            experiment_id=resolved["experiment_id"] if resolved else None,
        )
    """

    def __init__(
        self,
        ingest_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        api_url: Optional[str] = None,
        experiments_enabled: bool = False,
        experiments_ttl: int = 60,
    ) -> None:
        self.ingest_url = (ingest_url or os.environ.get("FIN_INGEST_URL", "")).rstrip("/")
        self.api_key = api_key or os.environ.get("FIN_API_KEY", "")
        self.api_url = (api_url or os.environ.get("FIN_API_URL", "")).rstrip("/")
        self.experiments_enabled = experiments_enabled
        self.experiments_ttl = experiments_ttl
        # Cache: featureId → (resolve-config, expiry_monotonic)
        self._cache: Dict[str, Tuple[Optional[ResolveConfig], float]] = {}

    # -------------------------------------------------------------------------
    # Tracking methods
    # -------------------------------------------------------------------------

    def track_response(
        self,
        response: Any = None,
        *,
        provider: str,
        feature_id: str,
        latency_ms: Optional[float] = None,
        error: bool = False,
        model: Optional[str] = None,
        tenant_id: Optional[str] = None,
        plan_tier: Optional[str] = None,
        outcome: Optional[str] = None,
        cost: Optional[float] = None,
        usage: Optional[Dict[str, int]] = None,
        idempotency_key: Optional[str] = None,
        experiment_id: Optional[str] = None,
    ) -> None:
        """Build and POST a usage event from a provider response (or error context)."""
        _track_response_impl(
            ingest_url=self.ingest_url,
            api_key=self.api_key,
            response=response,
            provider=provider,
            feature_id=feature_id,
            latency_ms=latency_ms,
            error=error,
            model=model,
            tenant_id=tenant_id,
            plan_tier=plan_tier,
            outcome=outcome,
            cost=cost,
            usage=usage,
            idempotency_key=idempotency_key,
            experiment_id=experiment_id,
        )

    def track(self, payload: dict, *, idempotency_key: Optional[str] = None) -> None:
        """Post a pre-built camelCase event dict directly."""
        _track_impl(
            ingest_url=self.ingest_url,
            api_key=self.api_key,
            payload=payload,
            idempotency_key=idempotency_key,
        )

    # -------------------------------------------------------------------------
    # Experiment resolution
    # -------------------------------------------------------------------------

    def resolve_model(
        self,
        feature_id: str,
        *,
        user_id: Optional[str] = None,
    ) -> Optional[ResolvedModel]:
        """
        Resolve which model variant to use for a given feature based on the active A/B experiment.

        Returns None when:
        - experiments_enabled is False or api_url is not configured
        - no active experiment for the feature_id
        - network or HTTP error (logged, never raised)

        When user_id is provided, assignment is deterministic: same user always gets same variant.
        Otherwise, assignment is random weighted.

        Caches experiment config per feature_id for experiments_ttl seconds (default 60).
        """
        if not self.experiments_enabled or not self.api_url:
            return None

        config: Optional[ResolveConfig]
        cache_hit = False
        entry = self._cache.get(feature_id)
        if entry is not None:
            cached_config, expiry = entry
            if time.monotonic() < expiry:
                config = cached_config
                cache_hit = True
            else:
                config = None
        else:
            config = None

        if not cache_hit:
            config = self._fetch_resolve_config(feature_id)
            self._cache[feature_id] = (config, time.monotonic() + self.experiments_ttl)

        if not config:
            return None

        try:
            return self._select_variant(
                config["variants"],
                user_id=user_id,
                experiment_id=config["experimentId"],
            )
        except Exception as exc:  # noqa: BLE001
            logger.error("[fin-sdk] resolve failed: %s", exc)
            return None

    def experiment(
        self,
        feature_id: str,
        *,
        user_id: Optional[str] = None,
    ) -> Optional[ResolvedModel]:
        """
        Alias for resolve_model(). Returns the assigned variant for this feature/user.
        Use this name in application code; resolve_model() remains for backward compatibility.
        """
        return self.resolve_model(feature_id, user_id=user_id)

    def _fetch_resolve_config(self, feature_id: str) -> Optional[ResolveConfig]:
        """Fetch experiment config from api-nest. Returns None on any error or no active experiment."""
        url = f"{self.api_url}/experiments/resolve"
        headers = {"x-api-key": self.api_key}
        try:
            response = _requests.get(
                url,
                params={"featureId": feature_id},
                headers=headers,
                timeout=10,
            )
            if not response.ok:
                logger.error("[fin-sdk] resolve failed: %s", response.status_code)
                return None
            body = response.json()
            if not isinstance(body, dict):
                return None
            if body.get("experiment") is None:
                return None

            experiment_id = body.get("experimentId")
            variants = body.get("variants")
            if not isinstance(experiment_id, str) or not experiment_id:
                return None
            if not isinstance(variants, list):
                return None

            normalized_variants = []
            for v in variants:
                if not isinstance(v, dict):
                    continue
                model = v.get("model")
                provider = v.get("provider")
                weight = v.get("weight")
                if not isinstance(model, str) or not isinstance(provider, str):
                    continue
                if not isinstance(weight, (int, float)):
                    continue
                normalized_variants.append(
                    {"model": model, "provider": provider, "weight": weight}
                )

            return ResolveConfig(experimentId=experiment_id, variants=normalized_variants)
        except Exception as exc:  # noqa: BLE001
            logger.error("[fin-sdk] resolve failed: %s", exc)
            return None

    def _select_variant(
        self,
        variants: list,
        *,
        experiment_id: str,
        user_id: Optional[str] = None,
    ) -> Optional[ResolvedModel]:
        """Select a variant using weighted random or deterministic hash assignment."""
        if not variants:
            return None

        total_weight = sum(v.get("weight", 0) for v in variants)
        if total_weight <= 0:
            return None

        if user_id and experiment_id:
            bucket = self._stable_hash(f"{experiment_id}:{user_id}") % total_weight
        else:
            bucket = random.randrange(total_weight)

        cumulative = 0
        for v in variants:
            cumulative += v.get("weight", 0)
            if bucket < cumulative:
                return ResolvedModel(
                    model=v["model"],
                    provider=v["provider"],
                    experiment_id=experiment_id,
                )

        # Fallback — should not be reached with valid weights
        last = variants[-1]
        return ResolvedModel(
            model=last["model"],
            provider=last["provider"],
            experiment_id=experiment_id,
        )

    @staticmethod
    def _stable_hash(s: str) -> int:
        """djb2 hash — matches the TypeScript implementation for cross-language consistency."""
        h = 5381
        for c in s:
            h = ((h << 5) + h + ord(c)) & 0xFFFFFFFF
        return h
