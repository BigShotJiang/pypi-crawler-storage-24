"""HTTP client — POST events to the ingest API."""
from __future__ import annotations

import json
import logging
from typing import Optional

import requests

logger = logging.getLogger("fin_sdk")


def post_event(
    *,
    ingest_url: str,
    api_key: str,
    event: dict,
    idempotency_key: Optional[str] = None,
) -> None:
    """
    POST a canonical event to {ingest_url}/usage/ingest.

    Headers:
      x-api-key: {api_key}          (primary auth header)
      idempotency-key: {key}        (optional deduplication)

    Never raises — errors are logged and swallowed.
    """
    url = ingest_url.rstrip("/") + "/usage/ingest"
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key,
    }
    if idempotency_key:
        headers["idempotency-key"] = idempotency_key

    try:
        response = requests.post(url, data=json.dumps(event), headers=headers, timeout=10)
        if not response.ok:
            logger.error("[fin-sdk] ingest failed: %s %s", response.status_code, response.text)
    except requests.RequestException as exc:
        logger.error("[fin-sdk] ingest failed: %s", exc)
