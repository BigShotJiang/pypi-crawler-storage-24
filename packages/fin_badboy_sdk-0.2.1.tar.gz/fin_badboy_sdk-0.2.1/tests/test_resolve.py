"""Tests for FinClient.resolve_model — experiment resolution, caching, and variant selection."""
import time
from unittest.mock import MagicMock, patch

from fin_sdk.client import FinClient


INGEST_URL = "http://localhost:3001"
API_URL = "http://api.localhost:3000"
API_KEY = "test-key"

ACTIVE_CONFIG = {
    "experimentId": "exp-abc-123",
    "featureId": "chat",
    "variants": [
        {"model": "gpt-4o", "provider": "openai", "weight": 60},
        {"model": "claude-3-5-sonnet", "provider": "anthropic", "weight": 40},
    ],
}


def make_client(**kwargs) -> FinClient:
    return FinClient(
        ingest_url=INGEST_URL,
        api_key=API_KEY,
        api_url=kwargs.pop("api_url", API_URL),
        experiments_enabled=kwargs.pop("experiments_enabled", True),
        experiments_ttl=kwargs.pop("experiments_ttl", 60),
        **kwargs,
    )


class TestResolveModelGuards:
    def test_returns_none_when_experiments_disabled(self):
        fin = make_client(experiments_enabled=False)
        with patch.object(fin, "_fetch_resolve_config") as mock_fetch:
            result = fin.resolve_model("chat")
        assert result is None
        mock_fetch.assert_not_called()

    def test_returns_none_when_api_url_not_configured(self):
        fin = make_client(api_url="")
        with patch.object(fin, "_fetch_resolve_config") as mock_fetch:
            result = fin.resolve_model("chat")
        assert result is None
        mock_fetch.assert_not_called()

    def test_returns_none_when_no_active_experiment(self):
        fin = make_client()
        with patch.object(fin, "_fetch_resolve_config", return_value=None):
            result = fin.resolve_model("chat")
        assert result is None


class TestResolveModelCache:
    def test_cache_hit_fetch_called_only_once(self):
        fin = make_client(experiments_ttl=60)
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG) as mock_fetch:
            fin.resolve_model("chat")
            fin.resolve_model("chat")
        mock_fetch.assert_called_once()

    def test_cache_miss_after_ttl_expiry(self):
        fin = make_client(experiments_ttl=0)
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG) as mock_fetch:
            fin.resolve_model("chat")
            time.sleep(0.01)  # ensure monotonic clock advances
            fin.resolve_model("chat")
        assert mock_fetch.call_count == 2

    def test_cache_is_per_feature_id(self):
        fin = make_client(experiments_ttl=60)
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG) as mock_fetch:
            fin.resolve_model("chat")
            fin.resolve_model("summarize")
        assert mock_fetch.call_count == 2

    def test_null_result_is_also_cached(self):
        fin = make_client(experiments_ttl=60)
        with patch.object(fin, "_fetch_resolve_config", return_value=None) as mock_fetch:
            fin.resolve_model("chat")
            fin.resolve_model("chat")
        mock_fetch.assert_called_once()

    def test_cache_stores_config_not_resolved_variant(self):
        fin = make_client(experiments_ttl=60)
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG) as mock_fetch:
            models = {
                fin.resolve_model("chat", user_id=f"user-{i}")["model"]
                for i in range(100)
            }
        mock_fetch.assert_called_once()
        assert "gpt-4o" in models
        assert "claude-3-5-sonnet" in models


class TestResolveModelFallback:
    def test_fallback_on_exception_in_fetch(self):
        fin = make_client()
        with patch("fin_sdk.client._requests.get", side_effect=ConnectionError("ECONNREFUSED")):
            assert fin.resolve_model("chat") is None

    def test_fallback_on_http_error(self):
        fin = make_client()
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = 503
        with patch("fin_sdk.client._requests.get", return_value=mock_response):
            result = fin.resolve_model("chat")
        assert result is None

    def test_returns_none_for_experiment_null_response(self):
        fin = make_client()
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"experiment": None}
        with patch("fin_sdk.client._requests.get", return_value=mock_response):
            result = fin.resolve_model("chat")
        assert result is None

    def test_returns_none_for_malformed_success_response(self):
        fin = make_client()
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"experimentId": "exp-abc-123"}  # missing variants
        with patch("fin_sdk.client._requests.get", return_value=mock_response):
            result = fin.resolve_model("chat")
        assert result is None


class TestWeightDistribution:
    def test_random_selection_matches_weights_over_1000_calls(self):
        fin = make_client(experiments_ttl=0)
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG):
            count_a = sum(
                1
                for _ in range(1000)
                if (fin.resolve_model("chat") or {}).get("model") == "gpt-4o"
            )
        # 60% expected, ±5% absolute tolerance → [550, 650]
        assert 550 <= count_a <= 650, f"Expected 550–650 gpt-4o selections, got {count_a}"


class TestDeterministicAssignment:
    def test_same_user_id_always_returns_same_model(self):
        fin = make_client(experiments_ttl=0)
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG):
            models = {
                fin.resolve_model("chat", user_id="user-sticky-42")["model"]
                for _ in range(20)
            }
        assert len(models) == 1, f"Expected one unique model for same user, got {models}"

    def test_different_user_ids_reach_both_variants(self):
        fin = make_client(experiments_ttl=0)
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG):
            models = {
                fin.resolve_model("chat", user_id=f"user-{i}")["model"]
                for i in range(100)
            }
        assert "gpt-4o" in models
        assert "claude-3-5-sonnet" in models

    def test_deterministic_hash_cross_language_consistency(self):
        """Verify djb2 hash matches TypeScript implementation for key inputs."""
        # Python: FinClient._stable_hash("exp-abc-123:user-42")
        # TypeScript: stableHash("exp-abc-123:user-42")
        # Both must produce the same non-negative integer so cross-language parity is maintained.
        fin = make_client()
        h = fin._stable_hash("exp-abc-123:user-42")
        assert isinstance(h, int)
        assert h >= 0
        # Deterministic — calling twice yields same result
        assert fin._stable_hash("exp-abc-123:user-42") == h


class TestResolvedModelShape:
    def test_resolved_model_has_correct_keys(self):
        fin = make_client()
        with patch.object(fin, "_fetch_resolve_config", return_value=ACTIVE_CONFIG):
            result = fin.resolve_model("chat")
        assert result is not None
        assert "model" in result
        assert "provider" in result
        assert "experiment_id" in result
        assert result["experiment_id"] == "exp-abc-123"
        assert result["model"] in ("gpt-4o", "claude-3-5-sonnet")

    def test_returns_none_for_variants_with_zero_total_weight(self):
        fin = make_client()
        config = {
            "experimentId": "exp-zero",
            "variants": [
                {"model": "gpt-4o", "provider": "openai", "weight": 0},
            ],
        }
        with patch.object(fin, "_fetch_resolve_config", return_value=config):
            result = fin.resolve_model("chat")
        assert result is None

    def test_returns_none_for_empty_variants(self):
        fin = make_client()
        config = {"experimentId": "exp-empty", "variants": []}
        with patch.object(fin, "_fetch_resolve_config", return_value=config):
            result = fin.resolve_model("chat")
        assert result is None


class TestFetchResolveConfig:
    def test_calls_correct_url_with_api_key_header(self):
        fin = make_client()
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = ACTIVE_CONFIG
        with patch("fin_sdk.client._requests.get", return_value=mock_response) as mock_get:
            fin._fetch_resolve_config("chat")
        mock_get.assert_called_once()
        call_args = mock_get.call_args
        assert call_args[0][0] == f"{API_URL}/experiments/resolve"
        assert call_args[1]["params"] == {"featureId": "chat"}
        assert call_args[1]["headers"]["x-api-key"] == API_KEY
        assert call_args[1]["timeout"] == 10
