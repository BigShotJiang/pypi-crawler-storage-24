"""Tests for extractor registry — OpenAI, Anthropic, Google, Mistral, unknown, and failure cases."""
import logging
from types import SimpleNamespace

from fin_sdk.extractor import extract


# ---------------------------------------------------------------------------
# Mock response objects (no dependency on openai/anthropic packages)
# ---------------------------------------------------------------------------

class _OpenAIUsage:
    def __init__(self, prompt=10, completion=20, total=30):
        self.prompt_tokens = prompt
        self.completion_tokens = completion
        self.total_tokens = total


class _OpenAIResponse:
    def __init__(self, model="gpt-4o-mini", usage=None):
        self.model = model
        self.usage = usage if usage is not None else _OpenAIUsage()


class _AnthropicUsage:
    def __init__(self, inp=12, out=8):
        self.input_tokens = inp
        self.output_tokens = out


class _AnthropicResponse:
    def __init__(self, model="claude-sonnet-4-5-20250929", usage=None):
        self.model = model
        self.usage = usage if usage is not None else _AnthropicUsage()


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------

class TestExtractOpenAI:
    def test_success(self):
        result = extract(_OpenAIResponse(), "openai")
        assert result == {
            "usage": {"inputTokens": 10, "outputTokens": 20, "totalTokens": 30},
            "model": "gpt-4o-mini",
        }

    def test_missing_usage(self):
        resp = _OpenAIResponse(model="gpt-4o")
        resp.usage = None
        result = extract(resp, "openai")
        assert result == {
            "usage": {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0},
            "model": "gpt-4o",
        }

    def test_missing_model(self):
        resp = _OpenAIResponse()
        resp.model = None
        result = extract(resp, "openai")
        assert result["model"] == ""

    def test_null_token_values(self):
        usage = _OpenAIUsage()
        usage.prompt_tokens = None
        usage.completion_tokens = None
        usage.total_tokens = None
        result = extract(_OpenAIResponse(usage=usage), "openai")
        assert result["usage"] == {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0}


# ---------------------------------------------------------------------------
# Groq / Azure (same extractor as OpenAI)
# ---------------------------------------------------------------------------

class TestExtractGroqAzure:
    def test_groq(self):
        resp = _OpenAIResponse(model="llama-3.3-70b-versatile", usage=_OpenAIUsage(15, 25, 40))
        result = extract(resp, "groq")
        assert result == {
            "usage": {"inputTokens": 15, "outputTokens": 25, "totalTokens": 40},
            "model": "llama-3.3-70b-versatile",
        }

    def test_azure_openai(self):
        result = extract(_OpenAIResponse(model="gpt-4o"), "azure_openai")
        assert result["model"] == "gpt-4o"
        assert result["usage"]["inputTokens"] == 10


# ---------------------------------------------------------------------------
# Anthropic
# ---------------------------------------------------------------------------

class TestExtractAnthropic:
    def test_success_derives_total(self):
        result = extract(_AnthropicResponse(), "anthropic")
        assert result == {
            "usage": {"inputTokens": 12, "outputTokens": 8, "totalTokens": 20},
            "model": "claude-sonnet-4-5-20250929",
        }

    def test_missing_usage(self):
        resp = _AnthropicResponse(model="claude-3-5-haiku")
        resp.usage = None
        result = extract(resp, "anthropic")
        assert result == {
            "usage": {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0},
            "model": "claude-3-5-haiku",
        }


# ---------------------------------------------------------------------------
# Google (Gemini)
# ---------------------------------------------------------------------------

class TestExtractGoogle:
    def test_usage_metadata_camelcase(self):
        um = SimpleNamespace(
            promptTokenCount=5,
            candidatesTokenCount=12,
            totalTokenCount=17,
        )
        resp = SimpleNamespace(modelVersion="models/gemini-2.0-flash", usageMetadata=um)
        result = extract(resp, "google")
        assert result == {
            "usage": {"inputTokens": 5, "outputTokens": 12, "totalTokens": 17},
            "model": "models/gemini-2.0-flash",
        }

    def test_usage_metadata_snake_case(self):
        um = SimpleNamespace(
            prompt_token_count=1,
            candidates_token_count=2,
            total_token_count=0,
        )
        resp = SimpleNamespace(model="gemini-1.5-flash", usage_metadata=um)
        result = extract(resp, "google")
        assert result == {
            "usage": {"inputTokens": 1, "outputTokens": 2, "totalTokens": 3},
            "model": "gemini-1.5-flash",
        }

    def test_prefers_model_over_model_version(self):
        um = SimpleNamespace(promptTokenCount=1, candidatesTokenCount=1, totalTokenCount=2)
        resp = SimpleNamespace(
            model="gemini-1.5-pro",
            modelVersion="ignored",
            usageMetadata=um,
        )
        assert extract(resp, "google")["model"] == "gemini-1.5-pro"


# ---------------------------------------------------------------------------
# Mistral (OpenAI-compatible)
# ---------------------------------------------------------------------------

class TestExtractMistral:
    def test_openai_shaped_usage(self):
        resp = _OpenAIResponse(
            model="mistral-small-latest",
            usage=_OpenAIUsage(4, 6, 10),
        )
        assert extract(resp, "mistral") == {
            "usage": {"inputTokens": 4, "outputTokens": 6, "totalTokens": 10},
            "model": "mistral-small-latest",
        }


# ---------------------------------------------------------------------------
# Unknown provider
# ---------------------------------------------------------------------------

class TestExtractUnknown:
    def test_returns_none(self):
        assert extract(_OpenAIResponse(), "cohere") is None

    def test_empty_provider(self):
        assert extract(_OpenAIResponse(), "") is None


# ---------------------------------------------------------------------------
# Malformed response (extractor throws)
# ---------------------------------------------------------------------------

class TestExtractMalformed:
    def test_returns_none_and_logs_warning(self, caplog):
        class _BrokenResponse:
            model = "gpt-4o"

            @property
            def usage(self):
                raise RuntimeError("boom")

        with caplog.at_level(logging.WARNING, logger="fin_sdk"):
            result = extract(_BrokenResponse(), "openai")

        assert result is None
        assert "[fin-sdk] extractor failed for provider" in caplog.text
        assert "openai" in caplog.text
