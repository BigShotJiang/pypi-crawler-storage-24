"""Vibe Package Manager - A package manager for AI coding assistants."""

__version__ = "1.0.0"
__all__ = ["main"]

from .cli import main
