"""Setup script for Vibe Package Manager."""

from setuptools import setup, find_packages

setup(
    name="vibe-package-manager",
    version="1.0.0",
    description="A package manager for managing SKILLs, SubAgents, and MCPs",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Vibe Package Manager Team",
    author_email="maintainer@example.com",
    url="https://github.com/YOUR_USERNAME/vibe_package_manager",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.7",
    install_requires=[
        "PyYAML>=6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "vibe-pm=main:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
        "Topic :: System :: Software Distribution",
    ],
    keywords="package-manager skills agents mcp claude iflow",
    project_urls={
        "Homepage": "https://github.com/YOUR_USERNAME/vibe_package_manager",
        "Documentation": "https://github.com/YOUR_USERNAME/vibe_package_manager#readme",
        "Repository": "https://github.com/YOUR_USERNAME/vibe_package_manager.git",
        "Issues": "https://github.com/YOUR_USERNAME/vibe_package_manager/issues",
    },
)