"""Tests for version utilities."""

import pytest
from src.version_utils import (
    parse_version,
    compare_versions,
    check_version_requirement,
    validate_support_agents
)


class TestParseVersion:
    """Test version parsing."""
    
    def test_simple_version(self):
        """Test parsing simple version."""
        assert parse_version("1.2.3") == (1, 2, 3)
    
    def test_two_part_version(self):
        """Test parsing two-part version."""
        assert parse_version("1.2") == (1, 2)
    
    def test_single_part_version(self):
        """Test parsing single-part version."""
        assert parse_version("1") == (1,)
    
    def test_version_with_v_prefix(self):
        """Test parsing version with v prefix."""
        assert parse_version("v1.2.3") == (1, 2, 3)
        assert parse_version("V1.2.3") == (1, 2, 3)
    
    def test_version_with_extra_parts(self):
        """Test parsing version with extra non-numeric parts."""
        assert parse_version("1.2.3-alpha") == (1, 2, 3)
        assert parse_version("1.2.3-beta.1") == (1, 2, 3)
    
    def test_version_with_date_suffix(self):
        """Test parsing version with date suffix like Claude Code."""
        assert parse_version("2.1.79-20260319.1") == (2, 1, 79)
        assert parse_version("2.1.0-20260319") == (2, 1, 0)
        assert parse_version("1.0.0-20250101") == (1, 0, 0)


class TestCompareVersions:
    """Test version comparison."""
    
    def test_equal_versions(self):
        """Test comparing equal versions."""
        assert compare_versions((1, 2, 3), (1, 2, 3)) == 0
    
    def test_first_greater(self):
        """Test when first version is greater."""
        assert compare_versions((2, 0, 0), (1, 2, 3)) == 1
    
    def test_second_greater(self):
        """Test when second version is greater."""
        assert compare_versions((1, 2, 3), (2, 0, 0)) == -1
    
    def test_different_lengths(self):
        """Test comparing versions with different lengths."""
        assert compare_versions((1, 2), (1, 2, 0)) == 0
        assert compare_versions((1, 2, 0), (1, 2)) == 0
        assert compare_versions((1, 2, 1), (1, 2)) == 1
        assert compare_versions((1, 2), (1, 2, 1)) == -1


class TestCheckVersionRequirement:
    """Test version requirement checking."""
    
    def test_exact_version_match(self):
        """Test exact version match."""
        assert check_version_requirement("1.2.3", "1.2.3") is True
        assert check_version_requirement("1.2.4", "1.2.3") is True
        assert check_version_requirement("1.2.2", "1.2.3") is False
    
    def test_caret_notation(self):
        """Test caret notation."""
        assert check_version_requirement("1.2.3", "^1.2.3") is True
        assert check_version_requirement("1.3.0", "^1.2.3") is True
        assert check_version_requirement("1.2.4", "^1.2.3") is True
        assert check_version_requirement("2.0.0", "^1.2.3") is False
        assert check_version_requirement("0.9.0", "^1.2.3") is False
    
    def test_caret_notation_major_zero(self):
        """Test caret notation with major version zero."""
        assert check_version_requirement("0.2.3", "^0.2.3") is True
        assert check_version_requirement("0.3.0", "^0.2.3") is False
        assert check_version_requirement("0.2.4", "^0.2.3") is True
        assert check_version_requirement("1.0.0", "^0.2.3") is False
    
    def test_version_with_date_suffix_matching(self):
        """Test version matching with date suffix."""
        # Claude Code style version with date suffix
        assert check_version_requirement("2.1.79-20260319.1", "^2.1.0") is True
        assert check_version_requirement("2.1.79-20260319.1", "^2.1.70") is True
        assert check_version_requirement("2.1.79-20260319.1", "^2.0.0") is True
        assert check_version_requirement("2.1.79-20260319.1", "^3.0.0") is False


class TestValidateSupportAgents:
    """Test support_agents validation."""
    
    def test_valid_support(self):
        """Test valid support configuration."""
        support_agents = {
            "iflow": "1.0.0",
            "claude": "^2.0.0"
        }
        target_agents = ["iflow", "claude"]
        current_versions = {
            "iflow": "1.0.0",
            "claude": "2.1.0"
        }
        warnings = validate_support_agents(support_agents, target_agents, current_versions)
        assert len(warnings) == 0
    
    def test_missing_agent(self):
        """Test when agent is missing from support_agents."""
        support_agents = {
            "claude": "^2.0.0"
        }
        target_agents = ["iflow", "claude"]
        current_versions = {
            "iflow": "1.0.0",
            "claude": "2.1.0"
        }
        warnings = validate_support_agents(support_agents, target_agents, current_versions)
        assert len(warnings) == 1
        assert "iflow" in warnings[0]
    
    def test_version_mismatch(self):
        """Test when current version doesn't meet requirement."""
        support_agents = {
            "claude": "^3.0.0"
        }
        target_agents = ["claude"]
        current_versions = {
            "claude": "2.1.0"
        }
        warnings = validate_support_agents(support_agents, target_agents, current_versions)
        assert len(warnings) == 1
        assert "version" in warnings[0].lower()
    
    def test_missing_current_version(self):
        """Test when current version is not provided."""
        support_agents = {
            "claude": "^2.0.0"
        }
        target_agents = ["claude"]
        current_versions = {}
        warnings = validate_support_agents(support_agents, target_agents, current_versions)
        assert len(warnings) == 1
        assert "version" in warnings[0].lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])