# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime

import httpx

from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.cloud.quotas import notification_threshold_update_params
from ....types.cloud.quotas.notification_threshold import NotificationThreshold

__all__ = ["NotificationThresholdResource", "AsyncNotificationThresholdResource"]


class NotificationThresholdResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> NotificationThresholdResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return NotificationThresholdResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> NotificationThresholdResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return NotificationThresholdResourceWithStreamingResponse(self)

    def update(
        self,
        client_id: int,
        *,
        threshold: int,
        last_message: Optional[notification_threshold_update_params.LastMessage] | Omit = omit,
        last_sending: Union[str, datetime, None] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationThreshold:
        """Update or create a client's quota notification threshold.

        This threshold is used
        to send warning notifications to the client when their quota usage reaches the
        specified percentage. Defaults to 80%.

        Args:
          client_id: Client ID

          threshold: Quota notification threshold in percentage

          last_message: A message data

          last_sending: Time of last successful email sending

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._put(
            path_template("/cloud/v2/client_quotas/{client_id}/notification_threshold", client_id=client_id),
            body=maybe_transform(
                {
                    "threshold": threshold,
                    "last_message": last_message,
                    "last_sending": last_sending,
                },
                notification_threshold_update_params.NotificationThresholdUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NotificationThreshold,
        )

    def delete(
        self,
        client_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Delete a client's quota notification threshold.

        After deletion, the default
        threshold of 80% will be used.

        Args:
          client_id: Client ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/cloud/v2/client_quotas/{client_id}/notification_threshold", client_id=client_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get(
        self,
        client_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationThreshold:
        """Get a client's quota notification threshold.

        This threshold is used to send
        warning notifications to the client when their quota usage reaches the specified
        percentage. Defaults to 80% if not set.

        Args:
          client_id: Client ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            path_template("/cloud/v2/client_quotas/{client_id}/notification_threshold", client_id=client_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NotificationThreshold,
        )


class AsyncNotificationThresholdResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncNotificationThresholdResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return AsyncNotificationThresholdResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncNotificationThresholdResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return AsyncNotificationThresholdResourceWithStreamingResponse(self)

    async def update(
        self,
        client_id: int,
        *,
        threshold: int,
        last_message: Optional[notification_threshold_update_params.LastMessage] | Omit = omit,
        last_sending: Union[str, datetime, None] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationThreshold:
        """Update or create a client's quota notification threshold.

        This threshold is used
        to send warning notifications to the client when their quota usage reaches the
        specified percentage. Defaults to 80%.

        Args:
          client_id: Client ID

          threshold: Quota notification threshold in percentage

          last_message: A message data

          last_sending: Time of last successful email sending

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._put(
            path_template("/cloud/v2/client_quotas/{client_id}/notification_threshold", client_id=client_id),
            body=await async_maybe_transform(
                {
                    "threshold": threshold,
                    "last_message": last_message,
                    "last_sending": last_sending,
                },
                notification_threshold_update_params.NotificationThresholdUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NotificationThreshold,
        )

    async def delete(
        self,
        client_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Delete a client's quota notification threshold.

        After deletion, the default
        threshold of 80% will be used.

        Args:
          client_id: Client ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/cloud/v2/client_quotas/{client_id}/notification_threshold", client_id=client_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get(
        self,
        client_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationThreshold:
        """Get a client's quota notification threshold.

        This threshold is used to send
        warning notifications to the client when their quota usage reaches the specified
        percentage. Defaults to 80% if not set.

        Args:
          client_id: Client ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            path_template("/cloud/v2/client_quotas/{client_id}/notification_threshold", client_id=client_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NotificationThreshold,
        )


class NotificationThresholdResourceWithRawResponse:
    def __init__(self, notification_threshold: NotificationThresholdResource) -> None:
        self._notification_threshold = notification_threshold

        self.update = to_raw_response_wrapper(
            notification_threshold.update,
        )
        self.delete = to_raw_response_wrapper(
            notification_threshold.delete,
        )
        self.get = to_raw_response_wrapper(
            notification_threshold.get,
        )


class AsyncNotificationThresholdResourceWithRawResponse:
    def __init__(self, notification_threshold: AsyncNotificationThresholdResource) -> None:
        self._notification_threshold = notification_threshold

        self.update = async_to_raw_response_wrapper(
            notification_threshold.update,
        )
        self.delete = async_to_raw_response_wrapper(
            notification_threshold.delete,
        )
        self.get = async_to_raw_response_wrapper(
            notification_threshold.get,
        )


class NotificationThresholdResourceWithStreamingResponse:
    def __init__(self, notification_threshold: NotificationThresholdResource) -> None:
        self._notification_threshold = notification_threshold

        self.update = to_streamed_response_wrapper(
            notification_threshold.update,
        )
        self.delete = to_streamed_response_wrapper(
            notification_threshold.delete,
        )
        self.get = to_streamed_response_wrapper(
            notification_threshold.get,
        )


class AsyncNotificationThresholdResourceWithStreamingResponse:
    def __init__(self, notification_threshold: AsyncNotificationThresholdResource) -> None:
        self._notification_threshold = notification_threshold

        self.update = async_to_streamed_response_wrapper(
            notification_threshold.update,
        )
        self.delete = async_to_streamed_response_wrapper(
            notification_threshold.delete,
        )
        self.get = async_to_streamed_response_wrapper(
            notification_threshold.get,
        )
