from __future__ import annotations

from io import BytesIO
from pathlib import Path
from uuid import uuid4

import openpyxl
import pytest

from flowbook import (
    Engine,
    InMemoryArtifactsStore,
    InMemoryConfigStore,
    Registry,
    register_steps,
)
from flowbook.core.configs.spec_types import (
    EntityPlanMap,
    InputProfile,
    Mapping,
    Plan,
)

pytestmark = pytest.mark.e2e


def _resolve_plan_name(config_store: InMemoryConfigStore, detected_kind: str | None) -> str:
    epm = config_store.get_spec(EntityPlanMap, "default")
    map_obj = epm.get("map") or {}
    plan_name = (
        map_obj.get(detected_kind, epm.get("default"))
        if detected_kind is not None
        else epm.get("default")
    )
    if plan_name is None:
        raise RuntimeError(f"plan_name is None for detected_kind={detected_kind}")
    return plan_name


def test_excel_bytes_inspect_route_plan_execute_e2e() -> None:
    artifacts_store = InMemoryArtifactsStore()
    config_store = InMemoryConfigStore()

    registry = Registry()
    register_steps(registry)

    # ---- Configs ----
    input_profile_spec = {
        "kind_rules": [
            {"pattern": r"^fileA_.*\.xlsx$", "kind": "fileA"},
            {"pattern": r"^fileB_.*\.xlsx$", "kind": "fileB"},
        ],
        "date_rule": {"sheet": "meta", "cell": "B2"},
        "inspect_step_name": "inspect_excel_bytes_v2",
    }
    config_store.put_spec(
        InputProfile,
        "demo_excel_inspect",
        input_profile_spec,
        config_id=str(uuid4()),
    )

    entity_plan_map_spec = {"map": {"fileA": "plan_fileA"}, "default": None}
    config_store.put_spec(
        EntityPlanMap,
        "default",
        entity_plan_map_spec,
        config_id=str(uuid4()),
    )

    mapping_spec = {
        "ops": [
            {"op": "select_cols", "cols": ["a", "b"]},
            {"op": "rename", "map": {"a": "A"}},
            {"op": "filter_rows", "expr": "A > 0"},
        ]
    }
    config_store.put_spec(
        Mapping,
        "mvp_map",
        mapping_spec,
        config_id=str(uuid4()),
    )

    plan_spec = {
        "plan": {
            "name": "excel_e2e",
            "steps": [
                {
                    "name": "read",
                    "op": "read_excel_bytes",
                    "inputs": {
                        "src_excel_bytes": "@src_excel_bytes",
                        "sheet": "@sheet_name",
                        "header": "@header_row",
                    },
                },
                {
                    "name": "map",
                    "op": "apply_mapping",
                    "inputs": {
                        "df": "@read/df",
                        "mapping_name": "@mapping_name_val",
                    },
                },
                {
                    "name": "write",
                    "op": "write_excel",
                    "inputs": {"df": "@map/df"},
                },
            ],
        }
    }
    config_store.put_spec(
        Plan,
        "plan_fileA",
        plan_spec,
        config_id=str(uuid4()),
    )

    engine = Engine(
        store=artifacts_store,
        registry=registry,
        config_store=config_store,
        meta={"env": "test"},
    )

    src_bytes = Path("tests/fixtures/excel/real_input.xlsx").read_bytes()
    bytes_artifact_key = "artifact/bytes/src_excel"

    # ---- Inspect (bytes + filename) ----
    with engine.create_run() as inspect_run:
        inspect_run.store.put_bytes(bytes_artifact_key, src_bytes)
        inspect_run.bind("src_excel_bytes", bytes_artifact_key)
        inspect_run.put_input("src_excel_filename", "fileA_real_input.xlsx")
        inspect_run.put_input("input_profile_name", "demo_excel_inspect")

        inspect_config = {
            "steps": [
                {
                    "name": "inspect",
                    "op": "inspect_excel_bytes_v2",
                    "inputs": {
                        "input_profile_name": "@input_profile_name",
                        "src_excel_bytes": "@src_excel_bytes",
                        "src_excel_filename": "@src_excel_filename",
                    },
                }
            ]
        }

        inspect_info = inspect_run.exec_plan(plan_config=inspect_config)
        assert inspect_info.status == "succeeded", f"inspect failed: {inspect_info.errors}"

        result_key = inspect_info.steps[0].outputs["result"]
        result = inspect_run.get_dict(result_key)
        assert result["detected_kind"] == "fileA"
        assert result["effective_date"] == "2026-02-10"

    plan_name = _resolve_plan_name(config_store, result["detected_kind"])

    # ---- Plan + Execute ----
    with engine.create_run() as run:
        run.store.put_bytes(bytes_artifact_key, src_bytes)
        run.bind("src_excel_bytes", bytes_artifact_key)
        run.put_input("sheet_name", "data")
        run.put_input("header_row", 0)
        run.put_input("mapping_name_val", "mvp_map")
        run.put_input("plan_name", plan_name)

        planner_config = {
            "steps": [
                {
                    "name": "planner",
                    "op": "load_plan",
                    "inputs": {"plan_name": "@plan_name"},
                }
            ]
        }

        info1, info2 = run.exec_with_planner_once(planner_config=planner_config)

        assert info1.status == "succeeded", f"planner failed: {info1.errors}"
        assert info2.status == "succeeded", f"plan execution failed: {info2.errors}"

        write_step = info2.steps[-1]
        assert "bytes" in write_step.outputs

        out_bytes_key = write_step.outputs["bytes"]
        out_bytes = run.get_bytes(out_bytes_key)
        assert len(out_bytes) > 0

        wb = openpyxl.load_workbook(BytesIO(out_bytes), data_only=True)
        assert wb.sheetnames
        assert "out" in wb.sheetnames
