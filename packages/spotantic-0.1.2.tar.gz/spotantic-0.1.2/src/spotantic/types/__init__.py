from __future__ import annotations

from typing import Annotated
from typing import Optional
from typing import Union

from pydantic import StringConstraints

from ._spotify_types import AlbumTypes
from ._spotify_types import AuthScope
from ._spotify_types import RepeatMode
from ._spotify_types import SpotifyItemType

type RawAPIResponse = Optional[bytes]
"""Raw API response type. bytes or ``None``."""

type JsonAPIResponse = Union[None, int, str, bool, list[JsonAPIResponse], dict[str, JsonAPIResponse]]
"""JSON API response type."""

type APIResponse = Union[RawAPIResponse, JsonAPIResponse]
"""API response type."""

type SpotifyMarketID = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        to_upper=True,
        pattern=r"^[A-Za-z]{2}$",
    ),
]
"""An ISO 3166-1 alpha-2 country code."""

type SpotifyLocaleID = Annotated[
    str,
    StringConstraints(strip_whitespace=True, pattern=r"^[A-Za-z]{2}_[A-Za-z]{2}$"),
]
"""An ISO 639-1 language code and an ISO 3166-1 alpha-2 country code, joined by an underscore."""

type SpotifyItemID = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=r"^[A-Za-z0-9]{22}$",
    ),
]
"""The base-62 identifier found at the end of the `SpotifyItemURI`."""

type SpotifyAlbumURI = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=rf"^spotify:{SpotifyItemType.ALBUM.value}:[A-Za-z0-9]{{22}}$",
    ),
]
"""The resource identifier of an album."""

type SpotifyArtistURI = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=rf"^spotify:{SpotifyItemType.ARTIST.value}:[A-Za-z0-9]{{22}}$",
    ),
]
"""The resource identifier of an artist."""

type SpotifyEpisodeURI = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=rf"^spotify:{SpotifyItemType.EPISODE.value}:[A-Za-z0-9]{{22}}$",
    ),
]
"""The resource identifier of an episode."""

type SpotifyPlaylistURI = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=rf"^spotify:{SpotifyItemType.PLAYLIST.value}:[A-Za-z0-9]{{22}}$",
    ),
]
"""The resource identifier of a playlist."""

type SpotifyShowURI = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=rf"^spotify:{SpotifyItemType.SHOW.value}:[A-Za-z0-9]{{22}}$",
    ),
]
"""The resource identifier of a show."""

type SpotifyTrackURI = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=rf"^spotify:{SpotifyItemType.TRACK.value}:[A-Za-z0-9]{{22}}$",
    ),
]
"""The resource identifier of a track."""

type SpotifyUserURI = Annotated[
    str,
    StringConstraints(
        strip_whitespace=True,
        pattern=rf"^spotify:{SpotifyItemType.USER.value}:[A-Za-z0-9]*$",
    ),
]
"""The resource identifier of an user."""

type SpotifyItemURI = Union[
    SpotifyAlbumURI,
    SpotifyArtistURI,
    SpotifyEpisodeURI,
    SpotifyPlaylistURI,
    SpotifyShowURI,
    SpotifyTrackURI,
    SpotifyUserURI,
]
"""The resource identifier of an item."""


__all__ = [
    "APIResponse",
    "AlbumTypes",
    "AuthScope",
    "JsonAPIResponse",
    "RawAPIResponse",
    "RepeatMode",
    "SpotifyAlbumURI",
    "SpotifyArtistURI",
    "SpotifyEpisodeURI",
    "SpotifyItemID",
    "SpotifyItemType",
    "SpotifyItemURI",
    "SpotifyLocaleID",
    "SpotifyMarketID",
    "SpotifyPlaylistURI",
    "SpotifyShowURI",
    "SpotifyTrackURI",
    "SpotifyUserURI",
]
