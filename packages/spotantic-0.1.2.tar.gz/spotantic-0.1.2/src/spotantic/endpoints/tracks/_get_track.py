from typing import Optional

from spotantic.client import SpotanticClient
from spotantic.models import APICallModel
from spotantic.models.spotify import TrackModel
from spotantic.models.tracks.requests import GetTrackRequest
from spotantic.types import JsonAPIResponse
from spotantic.types import SpotifyItemID
from spotantic.types import SpotifyMarketID


async def get_track(
    client: SpotanticClient, *, track_id: SpotifyItemID, market: Optional[SpotifyMarketID] = None
) -> APICallModel[GetTrackRequest, JsonAPIResponse, TrackModel]:
    """Get Spotify catalog information for a single track identified by its unique Spotify ID.

    Args:
        client: :class:`~spotantic.client.SpotanticClient` instance.
        track_id: The Spotify ID for the track.
        market: An ISO 3166-1 alpha-2 country code.

    Returns:
        An object containing the request used to obtain the response, the retrieved data and
        parsed data as model.
    """
    request = GetTrackRequest.build(track_id=track_id, market=market)
    response = await client.request_json(request)
    data = TrackModel.model_validate(response)

    return APICallModel(request=request, response=response, data=data)
