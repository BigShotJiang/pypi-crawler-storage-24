from typing import Optional

from typing_extensions import deprecated

from spotantic.client import SpotanticClient
from spotantic.models import APICallModel
from spotantic.models.artists.requests import GetArtistTopTracksRequest
from spotantic.models.artists.responses import GetArtistTopTracksResponse
from spotantic.models.spotify import TrackModel
from spotantic.types import JsonAPIResponse
from spotantic.types import SpotifyItemID
from spotantic.types import SpotifyMarketID


@deprecated("This endpoint is deprecated since 11 February 2026 for new users.")
async def get_artist_top_tracks(
    client: SpotanticClient, *, artist_id: SpotifyItemID, market: Optional[SpotifyMarketID] = None
) -> APICallModel[GetArtistTopTracksRequest, JsonAPIResponse, list[TrackModel]]:
    """Get Spotify catalog information about an artist's top tracks by country.

    .. version-deprecated:: 0.1.0
       This endpoint is deprecated since 11 February 2026 for new users. Existing users may be able to
       continue using it. More information on the deprecation can be found in the Spotify API documentation:
       `Update on Developer Access and Platform Security
       <https://developer.spotify.com/blog/2026-02-06-update-on-developer-access-and-platform-security>`_.

    Args:
        client: :class:`~spotantic.client.SpotanticClient` instance.
        artist_id: The Spotify ID for the artist.
        market: An ISO 3166-1 alpha-2 country code.

    Returns:
        An object containing the request used to obtain the response, the retrieved data and
        parsed data as model.
    """
    request = GetArtistTopTracksRequest.build(artist_id=artist_id, market=market)
    response = await client.request_json(request)
    data = GetArtistTopTracksResponse.model_validate(response)

    return APICallModel(request=request, response=response, data=data.tracks)
