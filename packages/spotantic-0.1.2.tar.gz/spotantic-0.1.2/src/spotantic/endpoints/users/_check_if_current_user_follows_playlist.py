from typing_extensions import deprecated

from spotantic._utils.models._type_validation import validate_is_instance_of
from spotantic.client import SpotanticClient
from spotantic.models import APICallModel
from spotantic.models.users.requests import CheckIfCurrentUserFollowsPlaylistRequest
from spotantic.types import JsonAPIResponse
from spotantic.types import SpotifyItemID


@deprecated("This endpoint is deprecated. Use Check User's Saved Items instead.")
async def check_if_current_user_follows_playlist(
    client: SpotanticClient,
    *,
    playlist_id: SpotifyItemID,
) -> APICallModel[CheckIfCurrentUserFollowsPlaylistRequest, JsonAPIResponse, bool]:
    """Check to see if the current user is following a specified playlist.

    .. version-deprecated:: 0.1.0
       This endpoint is deprecated since 11 February 2026 for new users. Existing users may be able to
       continue using it. More information on the deprecation can be found in the Spotify API documentation:
       `Update on Developer Access and Platform Security
       <https://developer.spotify.com/blog/2026-02-06-update-on-developer-access-and-platform-security>`_.
       This endpoint is deprecated. Use *Check User's Saved Items* instead.

    Args:
        client: :class:`~spotantic.client.SpotanticClient` instance.
        playlist_id: The Spotify ID for the playlist.

    Returns:
        An object containing the request used to obtain the response, the retrieved data and
        parsed data as model.
    """
    request = CheckIfCurrentUserFollowsPlaylistRequest.build(
        playlist_id=playlist_id,
    )
    response = await client.request_json(request)
    validated_response = validate_is_instance_of(response, list[bool])
    data = validated_response[0]

    return APICallModel(request=request, response=response, data=data)
