"""Compatibility wrapper re-exporting ``from_dta`` from LigonLibrary."""

from ligonlibrary.dataframes import from_dta

__all__ = ["from_dta"]
