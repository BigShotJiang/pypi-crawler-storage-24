from importlib.metadata import PackageNotFoundError, version

from . import tools
from . dta_concordance import dta_concordance
from . from_dta import from_dta

try:
    __version__ = version("lsms")
except PackageNotFoundError:
    __version__ = "0.0.0"
