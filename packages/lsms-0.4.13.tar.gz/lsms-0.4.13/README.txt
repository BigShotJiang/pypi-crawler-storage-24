Python tools for working with LSMS datasets.

Build and packaging are managed with Poetry. Typical workflow:

- `make tangle` to regenerate the Python sources from `MANIFEST.org`.
- `poetry install` (or `make devinstall`) to create a virtual environment with dependencies.
- `make test` to run the project's pytest suite inside Poetry's environment.
- `make build` (or `poetry build`) to produce distributions in `dist/`.
- `make upload` uses `poetry publish --build` to push the built artifacts.
- The `ligonlibrary` helper package is vendored as a Poetry path dependency; adjust the relative path if your checkout lives elsewhere.
