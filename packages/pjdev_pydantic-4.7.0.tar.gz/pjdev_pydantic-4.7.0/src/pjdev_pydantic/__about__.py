# SPDX-FileCopyrightText: 2024-present Purple Jay LLC <it@purplejay.io>
#
# SPDX-License-Identifier: MIT
__version__ = "4.7.0"
