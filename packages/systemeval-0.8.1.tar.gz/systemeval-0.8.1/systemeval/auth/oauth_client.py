"""OAuth 2.0 client implementations for systemeval.

Supports:
- Device Authorization Flow (RFC 8628) - primary for CLI/headless
- Authorization Code + PKCE (RFC 7636) - for local dev with browser
- Client Credentials (RFC 6749 section 4.4) - for CI/CD service accounts
"""

import base64
import hashlib
import http.server
import json
import os
import secrets
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from typing import Optional

from systemeval.auth.token_storage import TokenData, TokenStorage
from systemeval.config.e2e import OAuthConfig
from systemeval.utils.logging import get_logger

logger = get_logger(__name__)


class OAuthError(Exception):
    """Base exception for OAuth errors."""

    def __init__(self, error: str, description: str = "") -> None:
        self.error = error
        self.description = description
        super().__init__(f"{error}: {description}" if description else error)


class BaseOAuthClient:
    """Shared OAuth 2.0 client logic: HTTP, caching, refresh, logout.

    Args:
        oauth_config: OAuthConfig with client_id and endpoints.
        storage: TokenStorage for persisting tokens.
        provider_key: Key to store tokens under. Default "debuggai".
    """

    def __init__(
        self,
        oauth_config: OAuthConfig,
        storage: Optional[TokenStorage] = None,
        provider_key: str = "debuggai",
    ) -> None:
        self._config = oauth_config
        self._storage = storage or TokenStorage()
        self._provider_key = provider_key

    def get_cached_token(self) -> Optional[TokenData]:
        """Get a valid cached token, refreshing if needed.

        Returns:
            TokenData if a valid (non-expired) token is available, None otherwise.
        """
        token = self._storage.load(self._provider_key)
        if token is None:
            return None

        if not token.is_expired():
            return token

        if token.has_refresh_token():
            try:
                refreshed = self._refresh_token(token.refresh_token)
                self._storage.save(self._provider_key, refreshed)
                return refreshed
            except OAuthError:
                logger.debug("Token refresh failed, re-authentication required")
                return None

        return None

    def logout(self) -> bool:
        """Remove stored tokens.

        Returns:
            True if tokens were removed, False if none existed.
        """
        return self._storage.delete(self._provider_key)

    def _refresh_token(self, refresh_token: str) -> TokenData:
        """Refresh an access token using a refresh token.

        Args:
            refresh_token: The refresh token to use.

        Returns:
            New TokenData with refreshed access token.

        Raises:
            OAuthError: If refresh fails.
        """
        data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": self._config.client_id,
        }

        response = self._post(self._config.token_endpoint, data)
        token = TokenData.from_token_response(response)
        # Preserve refresh token if server doesn't return a new one
        if not token.refresh_token:
            token.refresh_token = refresh_token
        return token

    def _post(self, url: str, data: dict) -> dict:
        """Make a POST request to an OAuth endpoint.

        Args:
            url: Endpoint URL.
            data: Form-encoded body parameters.

        Returns:
            Parsed JSON response.

        Raises:
            OAuthError: If the response indicates an error.
        """
        encoded = urllib.parse.urlencode(data).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=encoded,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
        )

        try:
            with urllib.request.urlopen(request, timeout=30) as resp:
                body = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                body = json.loads(e.read().decode("utf-8"))
            except (json.JSONDecodeError, AttributeError):
                raise OAuthError("http_error", f"HTTP {e.code}: {e.reason}")

            error = body.get("error", "unknown_error")
            description = body.get("error_description", "")
            raise OAuthError(error, description)
        except urllib.error.URLError as e:
            raise OAuthError("connection_error", str(e.reason))

        if "error" in body:
            raise OAuthError(body["error"], body.get("error_description", ""))

        return body


class DeviceAuthorizationResponse:
    """Response from the device authorization endpoint (RFC 8628 section 3.2)."""

    def __init__(self, data: dict) -> None:
        self.device_code: str = data["device_code"]
        self.user_code: str = data["user_code"]
        self.verification_uri: str = data["verification_uri"]
        self.verification_uri_complete: Optional[str] = data.get("verification_uri_complete")
        self.expires_in: int = data.get("expires_in", 600)
        self.interval: int = data.get("interval", 5)


class DeviceFlowClient(BaseOAuthClient):
    """OAuth 2.0 Device Authorization Flow (RFC 8628).

    Used for CLI environments where a browser may not be available.
    The user authenticates via a separate device (phone, other computer).

    Flow:
    1. Request device code from authorization server
    2. Display user_code and verification_uri to user
    3. Poll token endpoint until user completes auth
    4. Store tokens via TokenStorage
    """

    def request_device_code(self) -> DeviceAuthorizationResponse:
        """Request a device code from the authorization server.

        Returns:
            DeviceAuthorizationResponse with user_code and verification_uri.

        Raises:
            OAuthError: If the request fails.
        """
        endpoint = self._config.device_authorization_endpoint
        if not endpoint:
            raise OAuthError("configuration_error", "device_authorization_endpoint not configured")

        data = {
            "client_id": self._config.client_id,
            "scope": " ".join(self._config.scopes),
        }

        response = self._post(endpoint, data)
        return DeviceAuthorizationResponse(response)

    def poll_for_token(
        self,
        device_code: str,
        interval: int = 5,
        timeout: int = 600,
    ) -> TokenData:
        """Poll the token endpoint until the user completes authentication.

        Args:
            device_code: Device code from request_device_code().
            interval: Seconds between polls. Default 5.
            timeout: Maximum seconds to wait. Default 600.

        Returns:
            TokenData with the access token.

        Raises:
            OAuthError: If polling fails or times out.
        """
        data = {
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "device_code": device_code,
            "client_id": self._config.client_id,
        }

        start = time.time()
        while time.time() - start < timeout:
            try:
                response = self._post(self._config.token_endpoint, data)
                token = TokenData.from_token_response(response)
                self._storage.save(self._provider_key, token)
                return token
            except OAuthError as e:
                if e.error == "authorization_pending":
                    time.sleep(interval)
                elif e.error == "slow_down":
                    interval = min(interval + 5, 30)
                    time.sleep(interval)
                elif e.error == "expired_token":
                    raise OAuthError("expired_token", "Device code expired. Please restart authentication.")
                elif e.error == "access_denied":
                    raise OAuthError("access_denied", "User denied the authorization request.")
                else:
                    raise

        raise OAuthError("timeout", f"Authentication timed out after {timeout}s")


class ClientCredentialsClient(BaseOAuthClient):
    """OAuth 2.0 Client Credentials Flow (RFC 6749 section 4.4).

    Used for CI/CD service accounts where no user interaction is possible.
    Authenticates using client_id and client_secret directly.

    Flow:
    1. POST client_id + client_secret to token endpoint
    2. Receive access token (typically no refresh token)
    3. Cache token until expiry, then re-authenticate
    """

    def authenticate(self) -> TokenData:
        """Authenticate using client credentials.

        Returns:
            TokenData with the access token.

        Raises:
            OAuthError: If client_secret is missing or the request fails.
        """
        if not self._config.client_secret:
            raise OAuthError(
                "configuration_error",
                "client_secret is required for client_credentials flow",
            )

        data = {
            "grant_type": "client_credentials",
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
        }

        if self._config.scopes:
            data["scope"] = " ".join(self._config.scopes)

        response = self._post(self._config.token_endpoint, data)
        token = TokenData.from_token_response(response)
        self._storage.save(self._provider_key, token)
        return token

    def get_token(self) -> TokenData:
        """Get a valid token, authenticating if needed.

        Tries cached token first, then re-authenticates.

        Returns:
            TokenData with a valid access token.

        Raises:
            OAuthError: If authentication fails.
        """
        cached = self.get_cached_token()
        if cached is not None:
            return cached

        return self.authenticate()


def _generate_code_verifier(length: int = 64) -> str:
    """Generate a PKCE code verifier (RFC 7636 section 4.1)."""
    return secrets.token_urlsafe(length)[:length]


def _generate_code_challenge(verifier: str) -> str:
    """Generate a PKCE code challenge from a verifier (RFC 7636 section 4.2)."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """HTTP handler that captures the OAuth callback code."""

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        if "error" in params:
            self.server.oauth_error = params["error"][0]  # type: ignore[attr-defined]
            self.server.oauth_error_description = params.get(  # type: ignore[attr-defined]
                "error_description", [""]
            )[0]
            self.server.oauth_code = None  # type: ignore[attr-defined]
        else:
            self.server.oauth_code = params.get("code", [None])[0]  # type: ignore[attr-defined]
            self.server.oauth_state = params.get("state", [None])[0]  # type: ignore[attr-defined]
            self.server.oauth_error = None  # type: ignore[attr-defined]

        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(
            b"<html><body><h1>Authentication complete</h1>"
            b"<p>You can close this window.</p></body></html>"
        )

    def log_message(self, format, *args) -> None:
        pass  # Suppress request logs


class AuthorizationCodeClient(BaseOAuthClient):
    """OAuth 2.0 Authorization Code + PKCE Flow (RFC 7636).

    Used for local development where a browser is available.

    Flow:
    1. Generate PKCE code_verifier and code_challenge
    2. Open browser to authorization endpoint
    3. Start local HTTP server to receive callback
    4. Exchange authorization code for tokens
    """

    def __init__(
        self,
        oauth_config: OAuthConfig,
        storage: Optional[TokenStorage] = None,
        provider_key: str = "debuggai",
        redirect_port: int = 8484,
    ) -> None:
        super().__init__(oauth_config, storage, provider_key)
        self._redirect_port = redirect_port

    @property
    def redirect_uri(self) -> str:
        return f"http://localhost:{self._redirect_port}/callback"

    def build_authorization_url(
        self, code_challenge: str, state: str
    ) -> str:
        """Build the authorization URL with PKCE parameters.

        Args:
            code_challenge: PKCE code challenge.
            state: Random state for CSRF protection.

        Returns:
            Full authorization URL string.

        Raises:
            OAuthError: If authorization_endpoint is not configured.
        """
        endpoint = self._config.authorization_endpoint
        if not endpoint:
            raise OAuthError(
                "configuration_error",
                "authorization_endpoint not configured",
            )

        params = {
            "response_type": "code",
            "client_id": self._config.client_id,
            "redirect_uri": self.redirect_uri,
            "scope": " ".join(self._config.scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }

        return f"{endpoint}?{urllib.parse.urlencode(params)}"

    def exchange_code(self, code: str, code_verifier: str) -> TokenData:
        """Exchange an authorization code for tokens.

        Args:
            code: Authorization code from the callback.
            code_verifier: PKCE code verifier used to generate the challenge.

        Returns:
            TokenData with access token.

        Raises:
            OAuthError: If the exchange fails.
        """
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self.redirect_uri,
            "client_id": self._config.client_id,
            "code_verifier": code_verifier,
        }

        response = self._post(self._config.token_endpoint, data)
        token = TokenData.from_token_response(response)
        self._storage.save(self._provider_key, token)
        return token

    def authenticate(self, timeout: int = 120, open_browser: bool = True) -> TokenData:
        """Run the full authorization code + PKCE flow.

        Opens a browser, waits for the callback, then exchanges the code.

        Args:
            timeout: Seconds to wait for user to complete auth. Default 120.
            open_browser: Whether to auto-open the browser. Default True.

        Returns:
            TokenData with access token.

        Raises:
            OAuthError: If auth fails, times out, or state mismatch.
        """
        code_verifier = _generate_code_verifier()
        code_challenge = _generate_code_challenge(code_verifier)
        state = secrets.token_urlsafe(32)

        auth_url = self.build_authorization_url(code_challenge, state)

        server = http.server.HTTPServer(
            ("127.0.0.1", self._redirect_port), _CallbackHandler
        )
        server.timeout = timeout
        server.oauth_code = None  # type: ignore[attr-defined]
        server.oauth_state = None  # type: ignore[attr-defined]
        server.oauth_error = None  # type: ignore[attr-defined]
        server.oauth_error_description = ""  # type: ignore[attr-defined]

        if open_browser:
            webbrowser.open(auth_url)

        server.handle_request()
        server.server_close()

        if server.oauth_error:  # type: ignore[attr-defined]
            raise OAuthError(
                server.oauth_error,  # type: ignore[attr-defined]
                server.oauth_error_description,  # type: ignore[attr-defined]
            )

        code = server.oauth_code  # type: ignore[attr-defined]
        if not code:
            raise OAuthError("timeout", f"No authorization code received within {timeout}s")

        returned_state = server.oauth_state  # type: ignore[attr-defined]
        if returned_state != state:
            raise OAuthError("state_mismatch", "CSRF state parameter does not match")

        return self.exchange_code(code, code_verifier)

    def get_token(self, timeout: int = 120, open_browser: bool = True) -> TokenData:
        """Get a valid token, authenticating via browser if needed.

        Args:
            timeout: Seconds to wait for auth. Default 120.
            open_browser: Whether to auto-open browser. Default True.

        Returns:
            TokenData with a valid access token.

        Raises:
            OAuthError: If authentication fails.
        """
        cached = self.get_cached_token()
        if cached is not None:
            return cached

        return self.authenticate(timeout=timeout, open_browser=open_browser)
