"""Authenticated HTTP session with automatic token refresh and 401 retry.

Wraps an OAuth client to provide transparent token management for API calls.
On 401, attempts to refresh the token and retry the request once.
"""

import json
import urllib.parse
import urllib.request
from typing import Any, Callable, Dict, Optional

from systemeval.auth.oauth_client import BaseOAuthClient, OAuthError
from systemeval.auth.token_storage import TokenData
from systemeval.utils.logging import get_logger

logger = get_logger(__name__)


class AuthenticatedSession:
    """HTTP session that automatically manages OAuth tokens.

    Wraps API requests with Bearer token authentication. On a 401 response,
    the session invalidates the cached token, re-authenticates, and retries
    the request once.

    Args:
        oauth_client: Any BaseOAuthClient subclass (Device, AuthCode, ClientCredentials).
        re_authenticate: Callable that performs fresh authentication when refresh fails.
                        Should return a TokenData. If None, 401 after refresh failure
                        raises OAuthError.
        timeout: HTTP request timeout in seconds.
    """

    def __init__(
        self,
        oauth_client: BaseOAuthClient,
        re_authenticate: Optional[Callable[[], TokenData]] = None,
        timeout: int = 30,
    ) -> None:
        self._client = oauth_client
        self._re_authenticate = re_authenticate
        self._timeout = timeout
        self._current_token: Optional[TokenData] = None

    @property
    def access_token(self) -> Optional[str]:
        """Current access token, if available."""
        if self._current_token and not self._current_token.is_expired():
            return self._current_token.access_token
        return None

    def get_token(self) -> TokenData:
        """Get a valid token, refreshing or re-authenticating as needed.

        Returns:
            TokenData with a valid access token.

        Raises:
            OAuthError: If no valid token can be obtained.
        """
        # Try cached token first (includes auto-refresh)
        token = self._client.get_cached_token()
        if token is not None:
            self._current_token = token
            return token

        # No valid cached token — re-authenticate
        if self._re_authenticate is not None:
            token = self._re_authenticate()
            self._current_token = token
            return token

        raise OAuthError("no_token", "No valid token available and no re-authentication method configured")

    def request(
        self,
        method: str,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Make an authenticated HTTP request with automatic 401 retry.

        Args:
            method: HTTP method (GET, POST, etc.).
            url: Full URL to request.
            data: JSON body (for POST/PUT/PATCH).
            params: Query parameters.
            headers: Additional headers (Authorization is added automatically).

        Returns:
            Parsed JSON response.

        Raises:
            OAuthError: If authentication fails after retry.
            urllib.error.HTTPError: For non-401 HTTP errors.
        """
        token = self.get_token()
        try:
            return self._do_request(method, url, token.access_token, data, params, headers)
        except urllib.error.HTTPError as e:
            if e.code != 401:
                raise

            logger.debug("Got 401, attempting re-authentication and retry")
            self._current_token = None
            # Invalidate the stored token since the server rejected it
            self._client.logout()
            token = self._force_re_authenticate()
            return self._do_request(method, url, token.access_token, data, params, headers)

    def _force_re_authenticate(self) -> TokenData:
        """Force re-authentication after a 401.

        Returns:
            Fresh TokenData.

        Raises:
            OAuthError: If re-authentication is not available.
        """
        if self._re_authenticate is not None:
            token = self._re_authenticate()
            self._current_token = token
            return token

        raise OAuthError("authentication_required", "Token expired and re-authentication is required")

    def _do_request(
        self,
        method: str,
        url: str,
        access_token: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Execute an HTTP request with the given access token.

        Args:
            method: HTTP method.
            url: Full URL.
            access_token: Bearer token.
            data: JSON body.
            params: Query parameters.
            extra_headers: Additional headers.

        Returns:
            Parsed JSON response.

        Raises:
            urllib.error.HTTPError: On HTTP errors.
            OAuthError: On connection errors.
        """
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"

        body = json.dumps(data).encode("utf-8") if data else None

        req = urllib.request.Request(url, data=body, method=method)
        req.add_header("Authorization", f"Bearer {access_token}")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")

        if extra_headers:
            for key, value in extra_headers.items():
                req.add_header(key, value)

        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as e:
            if isinstance(e, urllib.error.HTTPError):
                raise  # Re-raise HTTP errors for 401 handling
            raise OAuthError("connection_error", str(e.reason))
