"""Secure token storage for OAuth 2.0 tokens.

Stores tokens in a JSON file with restricted permissions (0600).
Supports token refresh tracking and expiry detection.
"""

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from systemeval.utils.logging import get_logger

logger = get_logger(__name__)

DEFAULT_TOKEN_PATH = Path.home() / ".systemeval" / "oauth_tokens.json"


@dataclass
class TokenData:
    """OAuth token data with expiry tracking.

    Attributes:
        access_token: The OAuth access token.
        token_type: Token type (typically "Bearer").
        expires_at: Unix timestamp when the access token expires.
        refresh_token: Optional refresh token for automatic renewal.
        scope: Space-separated list of granted scopes.
    """
    access_token: str
    token_type: str = "Bearer"
    expires_at: Optional[float] = None
    refresh_token: Optional[str] = None
    scope: Optional[str] = None

    @classmethod
    def from_token_response(cls, response: dict) -> "TokenData":
        """Create TokenData from an OAuth token endpoint response.

        Args:
            response: Dictionary from the token endpoint containing
                      access_token, token_type, expires_in, etc.

        Returns:
            TokenData instance with computed expires_at.
        """
        expires_in = response.get("expires_in")
        expires_at = time.time() + expires_in if expires_in else None

        return cls(
            access_token=response["access_token"],
            token_type=response.get("token_type", "Bearer"),
            expires_at=expires_at,
            refresh_token=response.get("refresh_token"),
            scope=response.get("scope"),
        )

    def is_expired(self, buffer_seconds: int = 60) -> bool:
        """Check if the access token is expired or about to expire.

        Args:
            buffer_seconds: Consider the token expired this many seconds
                           before the actual expiry time. Default 60.

        Returns:
            True if expired or no expiry info available.
        """
        if self.expires_at is None:
            return True
        return time.time() >= (self.expires_at - buffer_seconds)

    def has_refresh_token(self) -> bool:
        """Check if a refresh token is available."""
        return self.refresh_token is not None and len(self.refresh_token) > 0


class TokenStorage:
    """Secure file-based token storage.

    Stores OAuth tokens in a JSON file with 0600 permissions.
    Tokens are keyed by a provider identifier to support multiple providers.

    Args:
        path: Path to the token storage file. Defaults to
              ~/.systemeval/oauth_tokens.json
    """

    def __init__(self, path: Optional[Path] = None) -> None:
        self._path = path or DEFAULT_TOKEN_PATH

    @property
    def path(self) -> Path:
        """Get the storage file path."""
        return self._path

    def load(self, provider_key: str) -> Optional[TokenData]:
        """Load token data for a provider.

        Args:
            provider_key: Provider identifier (e.g., "debuggai").

        Returns:
            TokenData if found and valid, None otherwise.
        """
        data = self._read_store()
        if provider_key not in data:
            return None

        entry = data[provider_key]
        try:
            return TokenData(
                access_token=entry["access_token"],
                token_type=entry.get("token_type", "Bearer"),
                expires_at=entry.get("expires_at"),
                refresh_token=entry.get("refresh_token"),
                scope=entry.get("scope"),
            )
        except (KeyError, TypeError) as e:
            logger.warning(f"Corrupt token entry for '{provider_key}': {e}")
            return None

    def save(self, provider_key: str, token: TokenData) -> None:
        """Save token data for a provider.

        Args:
            provider_key: Provider identifier (e.g., "debuggai").
            token: TokenData to persist.
        """
        data = self._read_store()
        data[provider_key] = asdict(token)
        self._write_store(data)

    def delete(self, provider_key: str) -> bool:
        """Delete token data for a provider.

        Args:
            provider_key: Provider identifier to remove.

        Returns:
            True if the provider was found and removed, False otherwise.
        """
        data = self._read_store()
        if provider_key not in data:
            return False

        del data[provider_key]
        self._write_store(data)
        return True

    def clear(self) -> None:
        """Remove all stored tokens."""
        self._write_store({})

    def list_providers(self) -> list:
        """List all provider keys with stored tokens.

        Returns:
            List of provider key strings.
        """
        return list(self._read_store().keys())

    def _read_store(self) -> dict:
        """Read the token store file.

        Returns:
            Dictionary of stored data, empty dict if file doesn't exist.
        """
        if not self._path.exists():
            return {}

        try:
            content = self._path.read_text(encoding="utf-8")
            return json.loads(content) if content.strip() else {}
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to read token store at {self._path}: {e}")
            return {}

    def _write_store(self, data: dict) -> None:
        """Write data to the token store file with secure permissions.

        Creates parent directories if needed. Sets file permissions to 0600.

        Args:
            data: Dictionary to persist as JSON.
        """
        self._path.parent.mkdir(parents=True, exist_ok=True)

        content = json.dumps(data, indent=2, sort_keys=True)
        self._path.write_text(content, encoding="utf-8")

        try:
            os.chmod(self._path, 0o600)
        except OSError:
            pass  # Best-effort on systems that don't support chmod
