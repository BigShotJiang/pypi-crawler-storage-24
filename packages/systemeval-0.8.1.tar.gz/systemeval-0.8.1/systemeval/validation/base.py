"""Base validator with rule-based validation pattern.

Validators collect named rules and run them all against a target,
producing a single merged ValidationResult. Rules can be added
declaratively or via subclass methods.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, List, Optional

from systemeval.validation.result import ValidationResult


@dataclass
class Rule:
    """A named validation rule.

    Attributes:
        name: Short identifier (e.g., "required_fields", "timeout_bounds").
        check: Callable that accepts a target and returns a ValidationResult.
        description: Human-readable description of what this rule validates.
    """

    name: str
    check: Callable[[Any], ValidationResult]
    description: str = ""


class BaseValidator(ABC):
    """Base class for validators that check a target using a set of rules.

    Subclasses implement ``get_rules()`` to define their validation checks.
    Each rule receives the target object and returns a ``ValidationResult``.
    The validator runs all rules and merges results.

    Args:
        strict_mode: If True, warnings are promoted to errors.

    Example::

        class ConfigValidator(BaseValidator):
            def get_rules(self) -> list[Rule]:
                return [
                    Rule("version", self._check_version, "Validate config version"),
                    Rule("adapters", self._check_adapters, "Validate adapter names"),
                ]

            def _check_version(self, config) -> ValidationResult:
                if config.version not in ("1.0", "2.0"):
                    return ValidationResult.error(f"Bad version: {config.version}")
                return ValidationResult.ok()
    """

    def __init__(self, strict_mode: bool = False) -> None:
        self._strict_mode = strict_mode

    @abstractmethod
    def get_rules(self) -> List[Rule]:
        """Return the list of validation rules.

        Returns:
            List of Rule objects to run against the target.
        """
        ...

    def validate(self, target: Any) -> ValidationResult:
        """Run all rules against the target and return a merged result.

        Args:
            target: The object to validate.

        Returns:
            Merged ValidationResult from all rules.
        """
        merged = ValidationResult.ok()

        for rule in self.get_rules():
            result = rule.check(target)
            merged.merge(result)

        if self._strict_mode and merged.warnings:
            merged.errors.extend(merged.warnings)
            merged.warnings = []
            merged.valid = len(merged.errors) == 0

        return merged

    def validate_one(self, rule_name: str, target: Any) -> ValidationResult:
        """Run a single rule by name.

        Args:
            rule_name: Name of the rule to run.
            target: The object to validate.

        Returns:
            ValidationResult from the named rule.

        Raises:
            KeyError: If no rule with the given name exists.
        """
        for rule in self.get_rules():
            if rule.name == rule_name:
                return rule.check(target)
        raise KeyError(f"No rule named '{rule_name}'")

    def list_rules(self) -> List[str]:
        """Return names of all registered rules."""
        return [r.name for r in self.get_rules()]
