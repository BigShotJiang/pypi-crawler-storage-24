"""Validation result type shared across all systemeval validators."""

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class ValidationResult:
    """Result of a validation operation.

    Collects errors (blocking) and warnings (non-blocking) from one or more
    validation checks. A result is valid only when it has zero errors.

    Attributes:
        valid: True if no errors were found.
        errors: Blocking validation failures.
        warnings: Non-blocking issues or suggestions.
        metadata: Extra context for programmatic consumers.
    """

    valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def merge(self, other: "ValidationResult") -> "ValidationResult":
        """Merge another result into this one, combining errors and warnings.

        Args:
            other: Another ValidationResult to merge.

        Returns:
            Self, for chaining.
        """
        self.errors.extend(other.errors)
        self.warnings.extend(other.warnings)
        self.metadata.update(other.metadata)
        self.valid = len(self.errors) == 0
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a serializable dictionary."""
        return {
            "valid": self.valid,
            "errors": self.errors,
            "warnings": self.warnings,
            "metadata": self.metadata,
        }

    @staticmethod
    def ok() -> "ValidationResult":
        """Create a passing result with no errors or warnings."""
        return ValidationResult(valid=True)

    @staticmethod
    def error(message: str) -> "ValidationResult":
        """Create a failing result with a single error."""
        return ValidationResult(valid=False, errors=[message])

    @staticmethod
    def warning(message: str) -> "ValidationResult":
        """Create a passing result with a single warning."""
        return ValidationResult(valid=True, warnings=[message])
