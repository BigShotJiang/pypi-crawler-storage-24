"""Adapter validation using the shared validation framework.

Wraps the boolean ``validate_environment()`` calls from each adapter
into structured ``ValidationResult`` objects with actionable messages.

Usage::

    from systemeval.validation import AdapterValidator

    validator = AdapterValidator(adapter)
    result = validator.validate(adapter)
    if not result.valid:
        for err in result.errors:
            click.echo(f"  {err}", err=True)
"""

from pathlib import Path
from typing import Any, List

from systemeval.validation.base import BaseValidator, Rule
from systemeval.validation.result import ValidationResult


class AdapterValidator(BaseValidator):
    """Validates an adapter instance is ready to run tests.

    Rules check that the underlying framework is installed, config
    files exist, and the project root is valid.  Uses the adapter's
    own ``validate_environment()`` as a fallback but provides richer
    diagnostics where possible.
    """

    def __init__(self, *, strict_mode: bool = False, check_paths: bool = True) -> None:
        super().__init__(strict_mode=strict_mode)
        self._check_paths = check_paths

    def get_rules(self) -> List[Rule]:
        rules = [
            Rule(
                "adapter_type",
                self._check_adapter_type,
                "Adapter must be a recognized adapter instance",
            ),
            Rule(
                "project_root",
                self._check_project_root,
                "Project root must be set and valid",
            ),
            Rule(
                "environment_ready",
                self._check_environment_ready,
                "Framework environment must pass adapter self-check",
            ),
        ]
        if self._check_paths:
            rules.append(
                Rule(
                    "test_directory",
                    self._check_test_directory,
                    "Test directory should exist",
                )
            )
        return rules

    # ------------------------------------------------------------------
    # Rule implementations
    # ------------------------------------------------------------------

    def _check_adapter_type(self, adapter: Any) -> ValidationResult:
        if not hasattr(adapter, "validate_environment"):
            return ValidationResult.error(
                f"Object {type(adapter).__name__} is not a valid adapter "
                f"(missing validate_environment method)"
            )
        if not hasattr(adapter, "discover"):
            return ValidationResult.error(
                f"Object {type(adapter).__name__} is not a valid adapter "
                f"(missing discover method)"
            )
        return ValidationResult.ok()

    def _check_project_root(self, adapter: Any) -> ValidationResult:
        root = getattr(adapter, "project_root", None)
        if root is None:
            return ValidationResult.error("Adapter has no project_root set")

        root = Path(root)
        if self._check_paths and not root.exists():
            return ValidationResult.error(
                f"Adapter project_root does not exist: {root}"
            )
        if self._check_paths and not root.is_dir():
            return ValidationResult.error(
                f"Adapter project_root is not a directory: {root}"
            )
        return ValidationResult.ok()

    def _check_environment_ready(self, adapter: Any) -> ValidationResult:
        if not hasattr(adapter, "validate_environment"):
            return ValidationResult.ok()  # Already caught by adapter_type rule

        try:
            is_valid = adapter.validate_environment()
        except Exception as exc:
            return ValidationResult.error(
                f"Adapter validate_environment() raised {type(exc).__name__}: {exc}"
            )

        if not is_valid:
            adapter_name = getattr(adapter, "name", type(adapter).__name__)
            return ValidationResult.error(
                f"Adapter '{adapter_name}' environment validation failed. "
                f"Check that the test framework is installed and properly configured."
            )
        return ValidationResult.ok()

    def _check_test_directory(self, adapter: Any) -> ValidationResult:
        root = getattr(adapter, "project_root", None)
        test_dir = getattr(adapter, "test_directory", None)

        if root is None or test_dir is None:
            return ValidationResult.ok()

        full_path = Path(root) / test_dir
        if not full_path.exists():
            return ValidationResult.warning(
                f"Test directory '{test_dir}' not found at {full_path}. "
                f"Tests may fail to discover."
            )
        return ValidationResult.ok()
