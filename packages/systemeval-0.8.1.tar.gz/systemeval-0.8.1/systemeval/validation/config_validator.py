"""Config validator using the shared validation framework.

Provides post-construction validation for SystemEvalConfig that collects
all errors and warnings rather than failing on the first issue. This
complements the Pydantic field/model validators which run at construction
time and raise immediately.

Usage::

    from systemeval.validation import ConfigValidator

    validator = ConfigValidator()
    result = validator.validate(config)
    if not result.valid:
        for err in result.errors:
            click.echo(f"ERROR: {err}", err=True)
"""

from pathlib import Path
from typing import List

from systemeval.validation.base import BaseValidator, Rule
from systemeval.validation.result import ValidationResult


class ConfigValidator(BaseValidator):
    """Validates a fully-constructed SystemEvalConfig.

    Rules check cross-field consistency, file-system references,
    and runtime constraints that Pydantic validators cannot cover
    (or that benefit from collecting all issues rather than failing fast).
    """

    def __init__(self, *, strict_mode: bool = False, check_paths: bool = False) -> None:
        super().__init__(strict_mode=strict_mode)
        self._check_paths = check_paths

    def get_rules(self) -> List[Rule]:
        rules = [
            Rule(
                "composite_env_deps",
                self._check_composite_env_deps,
                "Composite environments must reference defined environments",
            ),
            Rule(
                "unique_subproject_names",
                self._check_unique_subproject_names,
                "Subproject names must be unique",
            ),
            Rule(
                "v2_needs_subprojects",
                self._check_v2_subprojects,
                "v2.0 config should define subprojects",
            ),
            Rule(
                "e2e_api_key",
                self._check_e2e_api_key,
                "DebuggAI E2E provider requires an API key or OAuth config",
            ),
            Rule(
                "subproject_adapters",
                self._check_subproject_adapters,
                "Subproject adapters should be known",
            ),
            Rule(
                "timeout_consistency",
                self._check_timeout_consistency,
                "Subproject timeouts should not exceed default max",
            ),
        ]
        if self._check_paths:
            rules.append(
                Rule(
                    "subproject_paths_exist",
                    self._check_subproject_paths,
                    "Subproject paths should exist on disk",
                )
            )
        return rules

    # ------------------------------------------------------------------
    # Rule implementations
    # ------------------------------------------------------------------

    def _check_composite_env_deps(self, config) -> ValidationResult:
        from systemeval.config.environments import CompositeEnvConfig

        result = ValidationResult.ok()
        for name, env_config in config.environments.items():
            if env_config.type == "composite" and isinstance(env_config, CompositeEnvConfig):
                for dep in env_config.depends_on:
                    if dep not in config.environments:
                        result.merge(
                            ValidationResult.error(
                                f"Environment '{name}' depends on '{dep}' which is not defined"
                            )
                        )
        return result

    def _check_unique_subproject_names(self, config) -> ValidationResult:
        if not config.subprojects:
            return ValidationResult.ok()
        names = [sp.name for sp in config.subprojects]
        seen = set()
        dupes = set()
        for n in names:
            if n in seen:
                dupes.add(n)
            seen.add(n)
        if dupes:
            return ValidationResult.error(
                f"Duplicate subproject names: {', '.join(sorted(dupes))}"
            )
        return ValidationResult.ok()

    def _check_v2_subprojects(self, config) -> ValidationResult:
        if config.version == "2.0" and not config.subprojects:
            return ValidationResult.warning(
                "Config version is 2.0 but no subprojects defined. "
                "Consider using version 1.0 or adding subprojects."
            )
        return ValidationResult.ok()

    def _check_e2e_api_key(self, config) -> ValidationResult:
        if config.e2e is None or not config.e2e.enabled:
            return ValidationResult.ok()

        provider = config.e2e.provider
        if provider.provider != "debuggai":
            return ValidationResult.ok()

        from systemeval.config.e2e import AuthType

        if provider.auth_type == AuthType.API_KEY and not provider.api_key:
            return ValidationResult.warning(
                "DebuggAI provider uses api_key auth but no api_key set in config. "
                "Pass --api-key via CLI or set e2e.provider.api_key."
            )
        return ValidationResult.ok()

    def _check_subproject_adapters(self, config) -> ValidationResult:
        if not config.subprojects:
            return ValidationResult.ok()

        known = {"pytest", "pytest-django", "vitest", "jest", "playwright", "pipeline", "surfer"}
        result = ValidationResult.ok()
        for sp in config.subprojects:
            if sp.adapter not in known:
                result.merge(
                    ValidationResult.warning(
                        f"Subproject '{sp.name}' uses unknown adapter '{sp.adapter}'. "
                        f"Known: {', '.join(sorted(known))}"
                    )
                )
        return result

    def _check_timeout_consistency(self, config) -> ValidationResult:
        if not config.subprojects:
            return ValidationResult.ok()

        max_reasonable = 3600  # 1 hour
        result = ValidationResult.ok()
        for sp in config.subprojects:
            if sp.timeout is not None and sp.timeout > max_reasonable:
                result.merge(
                    ValidationResult.warning(
                        f"Subproject '{sp.name}' timeout ({sp.timeout}s) exceeds "
                        f"1 hour. This may indicate a misconfiguration."
                    )
                )
        return result

    def _check_subproject_paths(self, config) -> ValidationResult:
        if not config.subprojects:
            return ValidationResult.ok()

        result = ValidationResult.ok()
        root = Path(config.project_root)
        for sp in config.subprojects:
            sp_path = root / sp.path
            if not sp_path.exists():
                result.merge(
                    ValidationResult.error(
                        f"Subproject '{sp.name}' path '{sp_path}' does not exist"
                    )
                )
        return result
