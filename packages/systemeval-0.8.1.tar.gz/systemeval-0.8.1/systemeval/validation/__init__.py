"""Validation framework for systemeval.

Provides a common validation pattern used across config, adapters, and E2E modules.
"""

from systemeval.validation.result import ValidationResult
from systemeval.validation.base import BaseValidator, Rule
from systemeval.validation.adapter_validator import AdapterValidator
from systemeval.validation.config_validator import ConfigValidator

__all__ = [
    "AdapterValidator",
    "BaseValidator",
    "ConfigValidator",
    "Rule",
    "ValidationResult",
]
