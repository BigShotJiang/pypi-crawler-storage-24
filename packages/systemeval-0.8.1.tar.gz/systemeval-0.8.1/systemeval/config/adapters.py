"""
Adapter configuration models for systemeval.

This module contains Pydantic models for test adapter configurations:
- TestCategory: Test categorization (unit, integration, api, browser, pipeline)
- PytestConfig: Pytest adapter specific configuration
- PipelineConfig: Pipeline adapter specific configuration
- PlaywrightConfig: Playwright adapter configuration
- SurferConfig: DebuggAI Surfer adapter configuration
- CriterionConfig: YAML-parseable pipeline criterion configuration
"""
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from systemeval.types.criteria import Criterion, CriterionOp


class TestCategory(BaseModel):
    """Test category configuration."""
    description: Optional[str] = None
    markers: List[str] = Field(default_factory=list)
    test_match: List[str] = Field(default_factory=list)
    paths: List[str] = Field(default_factory=list)
    requires: List[str] = Field(default_factory=list)
    environment: Optional[str] = Field(
        default=None,
        description="Docker environment to use for this category (e.g., 'docker', 'docker-full'). If not set, tests run directly without Docker."
    )


class PytestConfig(BaseModel):
    """Pytest adapter specific configuration."""
    config_file: Optional[str] = None
    base_path: str = "."
    default_category: str = "unit"


class CriterionConfig(BaseModel):
    """YAML-parseable pipeline criterion configuration.

    Example YAML:
        criteria:
          - metric: build_status
            op: equals
            expected: succeeded
            failure_message: "Build failed: {value}"
    """
    metric: str = Field(..., description="Metrics dict key to evaluate")
    op: str = Field(..., description="Comparison operator: equals, is_true, gt, gte, lt, lte")
    expected: Any = Field(default=None, description="Expected value (unused for is_true)")
    failure_message: str = Field(default="", description="Failure template with {value}/{expected} placeholders")

    def to_criterion(self) -> Criterion:
        """Convert to a Criterion dataclass instance."""
        return Criterion(
            metric=self.metric,
            op=CriterionOp(self.op),
            expected=self.expected,
            failure_template=self.failure_message,
        )


class PipelineConfig(BaseModel):
    """Pipeline adapter specific configuration."""
    projects: List[str] = Field(default_factory=lambda: ["crochet-patterns"])
    timeout: int = Field(default=600, description="Max time to wait per project (seconds)")
    poll_interval: int = Field(default=15, description="Seconds between status checks")
    sync_mode: bool = Field(default=False, description="Run webhooks synchronously")
    skip_build: bool = Field(default=False, description="Skip build, use existing containers")
    criteria: Optional[List[CriterionConfig]] = Field(
        default=None,
        description="Custom pass/fail criteria. If omitted, uses DEFAULT_PIPELINE_CRITERIA.",
    )

    def get_criteria(self) -> Optional[List[Criterion]]:
        """Convert criteria configs to Criterion instances, or None for defaults."""
        if self.criteria is None:
            return None
        return [c.to_criterion() for c in self.criteria]


class PlaywrightConfig(BaseModel):
    """Playwright adapter configuration."""
    config_file: str = Field(default="playwright.config.ts", description="Playwright config file")
    project: Optional[str] = Field(default=None, description="Playwright project (chromium, firefox, webkit)")
    headed: bool = Field(default=False, description="Run in headed mode")
    timeout: int = Field(default=30000, description="Test timeout in milliseconds")


class SurferConfig(BaseModel):
    """DebuggAI Surfer adapter configuration."""
    project_slug: str = Field(..., description="DebuggAI project slug")
    api_key: Optional[str] = Field(default=None, description="DebuggAI API key (or use DEBUGGAI_API_KEY env var)")
    api_base_url: str = Field(default="https://api.debugg.ai", description="DebuggAI API base URL")
    poll_interval: int = Field(default=5, description="Seconds between status checks")
    timeout: int = Field(default=600, description="Max time to wait for test completion")
