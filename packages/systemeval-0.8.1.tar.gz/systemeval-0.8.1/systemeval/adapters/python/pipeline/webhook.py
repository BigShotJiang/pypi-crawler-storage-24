"""Webhook triggering for pipeline evaluation.

Handles constructing and dispatching GitHub push webhook payloads
to trigger pipeline runs for project evaluation.
"""

import hashlib
import json
import secrets
from typing import Any, Dict, Optional

from systemeval.adapters.repositories import ProjectRepository
from systemeval.utils.logging import get_logger
from systemeval.utils.retry import RetryConfig, retry_with_backoff

logger = get_logger(__name__)


def trigger_webhook(
    repository: Optional[ProjectRepository],
    retry_config: RetryConfig,
    project: Any,
    sync_mode: bool = False,
    verbose: bool = False,
) -> bool:
    """Trigger GitHub push webhook for a project.

    Uses retry logic to handle transient failures in webhook triggering,
    such as temporary network issues or service unavailability.

    Args:
        repository: Project repository for installation lookup.
        retry_config: Retry configuration for transient failures.
        project: Project instance (Django model).
        sync_mode: Run synchronously (blocking) if True.
        verbose: Print verbose output.

    Returns:
        True if webhook was triggered successfully.
    """

    @retry_with_backoff(
        max_attempts=retry_config.max_attempts,
        initial_delay=retry_config.initial_delay,
        max_delay=retry_config.max_delay,
        exponential_base=retry_config.exponential_base,
        exceptions=(ConnectionError, TimeoutError, OSError),
        logger_instance=logger,
    )
    def _trigger_with_retry():
        from backend.repos.tasks import process_push_webhook

        repo = project.repo
        if not repo:
            if verbose:
                logger.warning("  No repository associated with project")
            return False

        if repository:
            installation_data = repository.get_repository_installation(repo.id)
        else:
            installation_data = None

        if not installation_data:
            if verbose:
                logger.warning("  No GitHub installation found")
            return False

        repo_install = installation_data.get("_instance")
        if not repo_install:
            if verbose:
                logger.warning("  Repository installation not available")
            return False

        # Get latest commit SHA from existing execution
        if repository:
            latest_exec_data = repository.get_latest_pipeline_execution(
                str(project.id)
            )
            commit_sha = (
                latest_exec_data.get("metadata", {}).get("commit_sha")
                if latest_exec_data
                else secrets.token_hex(20)
            )
        else:
            commit_sha = secrets.token_hex(20)

        # Build webhook payload
        if "/" in repo.name:
            owner, repo_name = repo.name.split("/", 1)
        else:
            url_parts = repo.url.rstrip("/").split("/")
            owner = url_parts[-2]
            repo_name = url_parts[-1].replace(".git", "")

        payload = {
            "ref": "refs/heads/main",
            "before": "0" * 40,
            "after": commit_sha,
            "repository": {
                "id": repo_install.github_repo_id or 0,
                "name": repo_name,
                "full_name": f"{owner}/{repo_name}",
                "html_url": repo.url,
            },
            "pusher": {"name": "systemeval", "email": "eval@debugg.ai"},
            "sender": {"login": "systemeval", "id": 0},
            "commits": [
                {
                    "id": commit_sha,
                    "message": "System eval",
                    "modified": ["README.md"],
                }
            ],
            "head_commit": {"id": commit_sha, "message": "System eval"},
        }

        payload_str = (
            json.dumps(payload, sort_keys=True) + f"_eval_{secrets.token_hex(4)}"
        )
        payload_hash = hashlib.sha256(payload_str.encode()).hexdigest()

        if sync_mode:
            process_push_webhook(payload_hash, payload, repo.id)
        else:
            task = process_push_webhook.delay(payload_hash, payload, repo.id)
            if verbose:
                logger.debug(f"  Task queued: {task.id}")

        return True

    try:
        return _trigger_with_retry()
    except Exception as e:
        logger.exception(
            f"Failed to trigger webhook for {project.name} after retries"
        )
        if verbose:
            logger.error(f"  Webhook trigger failed after retries: {e}")
        return False
