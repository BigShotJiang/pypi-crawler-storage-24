"""Pipeline adapter implementation for Django pipeline evaluation."""

import time
from typing import Any, Dict, List, Optional

from systemeval.adapters.base import AdapterConfig, BaseAdapter, TestFailure, TestItem, TestResult
from systemeval.adapters.repositories import DjangoProjectRepository, ProjectRepository
from systemeval.core.evaluation import EvaluationResult
from systemeval.types.criteria import (
    Criterion,
    DEFAULT_PIPELINE_CRITERIA,
    check_criteria,
    get_failure_messages,
)
from systemeval.utils.django import setup_django
from systemeval.utils.logging import get_logger
from systemeval.utils.retry import RetryConfig

from .evaluation import create_pipeline_evaluation
from .metrics import collect_all_metrics
from .polling import poll_for_completion
from .webhook import trigger_webhook

logger = get_logger(__name__)


class PipelineAdapter(BaseAdapter):
    """Adapter for Django pipeline evaluation.

    Example:
        config = AdapterConfig(
            project_root="/path/to/project",
            timeout=600,
            extra={
                "repository": my_repository,
                "retry_config": RetryConfig(...),
                "criteria": [Criterion(...)],
            }
        )
        adapter = PipelineAdapter(config)
    """

    def __init__(self, config: AdapterConfig) -> None:
        """Initialize pipeline adapter with configuration.

        Args:
            config: AdapterConfig with project root and pipeline settings.
                    Supported extra keys: repository, retry_config, criteria.
        """
        super().__init__(config)

        self._repository = self.config.get("repository")
        retry_cfg = self.config.get("retry_config")
        config_criteria = self.config.get("criteria")

        self.criteria = (
            config_criteria if config_criteria is not None
            else list(DEFAULT_PIPELINE_CRITERIA)
        )

        # Setup retry configuration with sensible defaults
        self._retry_config = retry_cfg or RetryConfig(
            max_attempts=3,
            initial_delay=1.0,
            max_delay=30.0,
            exponential_base=2.0,
            exceptions=(Exception,),
        )

        # Only setup Django if no repository is provided
        if self._repository is None:
            self._setup_django()
            try:
                self._repository = DjangoProjectRepository()
            except (ImportError, RuntimeError) as e:
                logger.warning(
                    f"Failed to create Django repository: {e}. "
                    "Adapter will not be functional without a repository."
                )

    def _setup_django(self) -> None:
        """Ensure Django is configured."""
        setup_django(self.project_root)

    def validate_environment(self) -> bool:
        """Validate that the repository is available."""
        if self._repository is None:
            logger.error("No repository configured")
            return False

        try:
            self._repository.get_all_projects()
            return True
        except Exception as e:
            logger.error(f"Repository validation failed: {e}")
            return False

    def discover(
        self,
        category: Optional[str] = None,
        app: Optional[str] = None,
        file: Optional[str] = None,
    ) -> List[TestItem]:
        """Discover projects to test."""
        if self._repository is None:
            logger.error("No repository configured for discovery")
            return []

        try:
            projects = self._repository.get_all_projects()

            test_items = []
            for project in projects:
                test_items.append(
                    TestItem(
                        id=project["id"],
                        name=project["name"],
                        path=project["slug"],
                        markers=["pipeline", "build", "health", "crawl", "e2e"],
                        metadata={
                            "project_id": project["id"],
                            "project_slug": project["slug"],
                            "repo_url": project.get("repo_url"),
                        },
                    )
                )

            return test_items

        except Exception as e:
            logger.error(f"Project discovery failed: {e}")
            return []

    def execute(
        self,
        tests: Optional[List[TestItem]] = None,
        parallel: bool = False,
        coverage: bool = False,
        failfast: bool = False,
        verbose: bool = False,
        timeout: Optional[int] = None,
        # Pipeline-specific options
        projects: Optional[List[str]] = None,
        poll_interval: Optional[int] = None,
        sync_mode: bool = False,
        skip_build: bool = False,
    ) -> TestResult:
        """Execute pipeline tests and return results."""
        if self._repository is None:
            return TestResult(
                passed=0,
                failed=0,
                errors=1,
                skipped=0,
                duration=0.0,
                failures=[
                    TestFailure(
                        test_id="config",
                        test_name="config",
                        message="No repository configured",
                    )
                ],
                exit_code=2,
            )

        timeout = timeout or 600
        poll_interval = poll_interval or 15

        if tests is None:
            tests = self.discover()

        if projects:
            tests = [
                t for t in tests
                if t.metadata.get("project_slug") in projects
                or t.name.lower() in [p.lower() for p in projects]
                or any(p.lower() in t.name.lower() for p in projects)
            ]

        if not tests:
            return TestResult(
                passed=0,
                failed=0,
                errors=1,
                skipped=0,
                duration=0.0,
                failures=[
                    TestFailure(
                        test_id="discovery",
                        test_name="discovery",
                        message="No projects found to test",
                    )
                ],
                exit_code=2,
            )

        start_time = time.time()
        passed = 0
        failed = 0
        errors = 0
        failures = []
        results_by_project = {}

        for test in tests:
            if verbose:
                logger.info(f"\n--- Evaluating: {test.name} ---")

            try:
                project_data = self._repository.get_project_by_id(test.id)
                if not project_data:
                    raise ValueError(f"Project {test.id} not found")

                project = project_data.get("_instance")
                if project is None:
                    raise ValueError(
                        "Mock repository does not support full pipeline execution. "
                        "Use DjangoProjectRepository for actual pipeline tests."
                    )

                session_start = time.time()
                metrics = self._evaluate_project(
                    project=project,
                    timeout=timeout,
                    poll_interval=poll_interval,
                    sync_mode=sync_mode,
                    skip_build=skip_build,
                    verbose=verbose,
                )
                session_duration = time.time() - session_start

                results_by_project[test.id] = metrics

                if self._metrics_pass(metrics):
                    passed += 1
                    if verbose:
                        logger.info(f"  -> PASS ({session_duration:.1f}s)")
                else:
                    failed += 1
                    failure_msg = self._get_failure_message(metrics)
                    failures.append(
                        TestFailure(
                            test_id=test.id,
                            test_name=test.name,
                            message=failure_msg,
                            duration=session_duration,
                            metadata=metrics,
                        )
                    )
                    if verbose:
                        logger.info(f"  -> FAIL: {failure_msg}")

                    if failfast:
                        break

            except Exception as e:
                errors += 1
                failures.append(
                    TestFailure(
                        test_id=test.id,
                        test_name=test.name,
                        message=f"Evaluation error: {str(e)}",
                        metadata={
                            "build_status": "error",
                            "container_healthy": False,
                            "kg_pages": 0,
                            "e2e_passed": 0,
                            "e2e_failed": 0,
                            "e2e_error": 0,
                        },
                    )
                )
                logger.exception(f"Evaluation failed for {test.name}")

                if failfast:
                    break

        duration = time.time() - start_time

        result = TestResult(
            passed=passed,
            failed=failed,
            errors=errors,
            skipped=0,
            duration=duration,
            failures=failures,
            exit_code=0 if errors == 0 and failed == 0 else 1,
            pipeline_tests=tests,
            pipeline_metrics=results_by_project,
            pipeline_adapter=self,
        )

        return result

    def get_available_markers(self) -> List[str]:
        """Return available test markers/categories."""
        return ["pipeline", "build", "health", "crawl", "e2e"]

    # =========================================================================
    # Helper Methods (delegate to extracted modules)
    # =========================================================================

    def _find_project(self, slug: str):
        """Find a project by slug or name."""
        if self._repository is None:
            return None

        project_data = self._repository.find_project(slug)
        if project_data:
            return project_data.get("_instance")
        return None

    def _trigger_webhook(
        self, project, sync_mode: bool = False, verbose: bool = False
    ) -> bool:
        """Trigger GitHub push webhook for a project."""
        return trigger_webhook(
            self._repository, self._retry_config, project, sync_mode, verbose
        )

    def _poll_for_completion(
        self,
        project,
        timeout: int,
        poll_interval: int,
        session_start: float,
        skip_build: bool,
        verbose: bool,
    ) -> Dict[str, Any]:
        """Poll for pipeline completion and collect metrics."""
        return poll_for_completion(
            project, timeout, poll_interval, session_start,
            skip_build, verbose, self._retry_config,
        )

    def _collect_metrics(
        self, project, session_start: float, verbose: bool = False
    ) -> Dict[str, Any]:
        """Collect comprehensive metrics for a project."""
        return collect_all_metrics(
            project, session_start, verbose, self._retry_config,
        )

    def _metrics_pass(self, metrics: Dict[str, Any]) -> bool:
        """Check if metrics pass all criteria."""
        return check_criteria(metrics, self.criteria)

    def _get_failure_message(self, metrics: Dict[str, Any]) -> str:
        """Generate failure message from metrics."""
        failures = get_failure_messages(metrics, self.criteria)
        return "; ".join(failures) if failures else "Unknown failure"

    def _evaluate_project(
        self,
        project,
        timeout: int,
        poll_interval: int,
        sync_mode: bool,
        skip_build: bool,
        verbose: bool,
    ) -> Dict[str, Any]:
        """Evaluate a single project through the full pipeline."""
        session_start = time.time()

        if not skip_build:
            triggered = self._trigger_webhook(
                project, sync_mode=sync_mode, verbose=verbose
            )
            if not triggered:
                return {
                    "build_status": "not_triggered",
                    "container_healthy": False,
                    "kg_exists": False,
                    "kg_pages": 0,
                    "e2e_error_rate": 0.0,
                }

        self._poll_for_completion(
            project=project,
            timeout=timeout,
            poll_interval=poll_interval,
            session_start=session_start,
            skip_build=skip_build,
            verbose=verbose,
        )

        metrics = self._collect_metrics(
            project=project,
            session_start=session_start,
            verbose=verbose,
        )

        return metrics

    def create_evaluation_result(
        self,
        tests: List[TestItem],
        results_by_project: Dict[str, Dict[str, Any]],
        duration: float,
    ) -> EvaluationResult:
        """Create a detailed EvaluationResult from pipeline metrics."""
        return create_pipeline_evaluation(tests, results_by_project, duration)
