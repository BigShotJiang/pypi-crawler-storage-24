"""Polling logic for pipeline evaluation.

Handles the polling loop that waits for pipeline completion and checks
run status via database queries.
"""

import time
from typing import Any, Dict, List

from systemeval.utils.logging import get_logger
from systemeval.utils.retry import RetryConfig, retry_with_backoff

logger = get_logger(__name__)


def check_run_status(project: Any, session_start_dt: Any) -> Dict[str, Any]:
    """Check pipeline run status via database queries.

    Fetches current status of build, container, pipeline execution,
    knowledge graph, and E2E runs for the given project.

    Args:
        project: Project instance (Django model).
        session_start_dt: Session start datetime (timezone-aware).

    Returns:
        Dictionary of current metrics with internal tracking data.
    """
    from django.db.models import Avg, Q
    from backend.builds.models import Build
    from backend.containers.models import Container
    from backend.e2es.models import E2eRun, E2eRunMetrics
    from backend.graphs.models import GraphPage, KnowledgeGraph
    from backend.pipelines.models import PipelineExecution

    current_metrics: Dict[str, Any] = {}

    # Check pipeline execution
    pe = (
        PipelineExecution.objects.filter(
            project=project, timestamp__gte=session_start_dt
        )
        .order_by("-timestamp")
        .first()
    )

    if pe:
        current_metrics["pipeline_status"] = pe.status
        current_metrics["_pe_obj"] = pe
        current_metrics["_pe_id"] = str(pe.id)
    else:
        current_metrics["_pe_obj"] = None
        current_metrics["_pe_id"] = None

    # Check build
    build = (
        Build.objects.filter(project=project, timestamp__gte=session_start_dt)
        .order_by("-timestamp")
        .first()
    )
    if build:
        current_metrics["build_status"] = build.status
        current_metrics["_build_id"] = str(build.id)
        if build.completed_at and build.timestamp:
            current_metrics["build_duration_seconds"] = (
                build.completed_at - build.timestamp
            ).total_seconds()

    # Check container
    container = (
        Container.objects.filter(project=project, timestamp__gte=session_start_dt)
        .order_by("-timestamp")
        .first()
    )
    if container:
        current_metrics["container_healthy"] = container.is_healthy
        current_metrics["health_checks_passed"] = container.health_checks_passed
        current_metrics["_container_id"] = str(container.id)

    # Check knowledge graph
    if container and hasattr(container, "environment"):
        kg = KnowledgeGraph.objects.filter(
            environment=container.environment
        ).first()
    else:
        kg = KnowledgeGraph.objects.filter(
            environment__project=project
        ).first()

    if kg:
        current_metrics["kg_exists"] = True
        current_metrics["kg_pages"] = GraphPage.objects.filter(graph=kg).count()
        current_metrics["_kg_id"] = str(kg.id)
    else:
        current_metrics["kg_exists"] = False
        current_metrics["kg_pages"] = 0
        current_metrics["_kg_id"] = None

    # Check E2E metrics
    pe = current_metrics.get("_pe_obj")
    if pe:
        session_runs = E2eRun.objects.filter(
            Q(pipeline_execution=pe)
            | Q(project=project, timestamp__gte=session_start_dt)
        ).distinct()
    else:
        session_runs = E2eRun.objects.filter(
            project=project, timestamp__gte=session_start_dt
        )

    current_metrics["e2e_runs"] = session_runs.count()
    current_metrics["e2e_passed"] = session_runs.filter(outcome="pass").count()
    current_metrics["e2e_failed"] = session_runs.filter(outcome="fail").count()
    current_metrics["e2e_error"] = session_runs.filter(outcome="error").count()

    if current_metrics["e2e_runs"] > 0:
        current_metrics["e2e_error_rate"] = (
            current_metrics["e2e_error"] / current_metrics["e2e_runs"]
        ) * 100
    else:
        current_metrics["e2e_error_rate"] = 0.0

    # Get average actions from E2eRunMetrics
    session_run_ids = list(session_runs.values_list("id", flat=True))
    avg_result = E2eRunMetrics.objects.filter(
        run_id__in=session_run_ids
    ).aggregate(avg_steps=Avg("num_steps"))
    current_metrics["e2e_avg_actions"] = avg_result["avg_steps"] or 0.0

    # Count completed E2E runs
    current_metrics["_completed_runs"] = session_runs.filter(
        status__in=["completed", "error"]
    ).count()
    current_metrics["_pending_runs"] = session_runs.filter(
        status__in=["pending", "running"]
    ).count()

    return current_metrics


def handle_completion(metrics: Dict[str, Any], skip_build: bool) -> bool:
    """Check if pipeline run is complete based on metrics.

    Args:
        metrics: Current metrics dictionary.
        skip_build: Whether build phase was skipped.

    Returns:
        True if polling should stop (completion detected), False otherwise.
    """
    pending_runs = metrics.get("_pending_runs", 0)
    e2e_runs = metrics.get("e2e_runs", 0)

    if metrics.get("build_status") == "succeeded" and metrics.get(
        "container_healthy"
    ):
        if skip_build:
            return True
        elif metrics.get("pipeline_status") in ["completed", "failed"]:
            if pending_runs == 0 or e2e_runs == 0:
                return True
        elif e2e_runs > 0 and pending_runs == 0:
            return True

    return False


def calculate_backoff(attempt: int, base_interval: int) -> float:
    """Calculate polling interval.

    Args:
        attempt: Current polling attempt number (0-indexed).
        base_interval: Base polling interval in seconds.

    Returns:
        Sleep duration in seconds.
    """
    return float(base_interval)


def log_polling_progress(metrics: Dict[str, Any], start_wait: float) -> None:
    """Log polling progress for verbose output.

    Args:
        metrics: Current metrics dictionary.
        start_wait: Timestamp when polling started.
    """
    elapsed = int(time.time() - start_wait)
    build_status = metrics.get("build_status", "none")
    container_status = (
        "healthy" if metrics.get("container_healthy") else "pending"
    )
    completed_runs = metrics.get("_completed_runs", 0)
    pending_runs = metrics.get("_pending_runs", 0)
    e2e_runs = metrics.get("e2e_runs", 0)
    pe_id = metrics.get("_pe_id")
    exec_info = f"pe={pe_id[:8] if pe_id else 'none'}" if pe_id else ""

    logger.debug(
        f"  [+{elapsed}s] "
        f"build={build_status} "
        f"container={container_status} "
        f"e2e={completed_runs}/{e2e_runs} (pending={pending_runs}) "
        f"{exec_info}"
    )


def cleanup_internal_metadata(metrics: Dict[str, Any]) -> Dict[str, Any]:
    """Remove internal tracking metadata from metrics.

    Args:
        metrics: Metrics dictionary with internal keys.

    Returns:
        Cleaned metrics dictionary.
    """
    internal_keys = [
        "_pe_id",
        "_build_id",
        "_container_id",
        "_kg_id",
        "_pe_obj",
        "_completed_runs",
        "_pending_runs",
    ]
    for key in internal_keys:
        metrics.pop(key, None)
    return metrics


def poll_for_completion(
    project: Any,
    timeout: int,
    poll_interval: int,
    session_start: float,
    skip_build: bool,
    verbose: bool,
    retry_config: RetryConfig,
) -> Dict[str, Any]:
    """Poll for pipeline completion and collect metrics.

    Orchestrates the polling loop by delegating to focused helper functions.

    Args:
        project: Project instance (Django model).
        timeout: Max time to wait in seconds.
        poll_interval: Seconds between status checks.
        session_start: Start time of this session (Unix timestamp).
        skip_build: Skip build phase if True.
        verbose: Print verbose output.
        retry_config: Retry configuration for transient failures.

    Returns:
        Dictionary of collected metrics.
    """
    from datetime import datetime, timezone as dt_timezone
    from django.db import OperationalError

    metrics: Dict[str, Any] = {}
    start_wait = time.time()
    session_start_dt = datetime.fromtimestamp(session_start, tz=dt_timezone.utc)

    metrics["_session_start"] = session_start

    @retry_with_backoff(
        max_attempts=retry_config.max_attempts,
        initial_delay=retry_config.initial_delay,
        max_delay=retry_config.max_delay,
        exponential_base=retry_config.exponential_base,
        exceptions=(OperationalError, ConnectionError, TimeoutError),
        logger_instance=logger,
    )
    def _fetch_metrics_with_retry():
        return check_run_status(project, session_start_dt)

    attempt = 0
    while time.time() - start_wait < timeout:
        try:
            current_metrics = _fetch_metrics_with_retry()
            metrics.update(current_metrics)

            if verbose:
                log_polling_progress(metrics, start_wait)

            if handle_completion(metrics, skip_build):
                break

        except Exception as e:
            logger.warning(
                f"Failed to fetch metrics during polling (will retry): {e}"
            )

        sleep_duration = calculate_backoff(attempt, poll_interval)
        time.sleep(sleep_duration)
        attempt += 1

    return cleanup_internal_metadata(metrics)
