"""Metrics collection for pipeline evaluation.

Collects comprehensive metrics from Django database models including
build status, container health, knowledge graph, surfers, and E2E tests.
"""

from typing import Any, Dict, List, Optional

from systemeval.utils.logging import get_logger
from systemeval.utils.retry import RetryConfig, retry_with_backoff

logger = get_logger(__name__)


def collect_build_metrics(
    project: Any, session_start_dt: Any, diagnostics: List[str]
) -> Dict[str, Any]:
    """Collect build-related metrics.

    Args:
        project: Project instance (Django model).
        session_start_dt: Session start as datetime (UTC).
        diagnostics: List to append diagnostic messages to.

    Returns:
        Dictionary of build metrics.
    """
    from backend.builds.models import Build

    metrics: Dict[str, Any] = {}
    build = (
        Build.objects.filter(project=project, timestamp__gte=session_start_dt)
        .order_by("-timestamp")
        .first()
    )
    if build:
        metrics["build_status"] = build.status
        metrics["build_id"] = str(build.id)
        if build.completed_at and build.timestamp:
            metrics["build_duration"] = (
                build.completed_at - build.timestamp
            ).total_seconds()
        else:
            metrics["build_duration"] = None
        if build.status != "succeeded":
            diagnostics.append(f"Build {build.status}: check CodeBuild logs")
    else:
        metrics["build_status"] = "not_triggered"
        metrics["build_id"] = None
        metrics["build_duration"] = None
        diagnostics.append("No build found for project")

    return metrics


def collect_container_metrics(
    project: Any, session_start_dt: Any, diagnostics: List[str]
) -> Dict[str, Any]:
    """Collect container-related metrics.

    Args:
        project: Project instance (Django model).
        session_start_dt: Session start as datetime (UTC).
        diagnostics: List to append diagnostic messages to.

    Returns:
        Dictionary of container metrics. Includes '_container' key with instance.
    """
    from backend.containers.models import Container

    metrics: Dict[str, Any] = {}
    container = (
        Container.objects.filter(
            project=project, timestamp__gte=session_start_dt
        )
        .order_by("-timestamp")
        .first()
    )
    if container:
        metrics["container_healthy"] = container.is_healthy
        metrics["health_checks_passed"] = container.health_checks_passed
        metrics["container_id"] = str(container.id)
        if container.started_at and container.timestamp:
            metrics["container_startup_time"] = (
                container.started_at - container.timestamp
            ).total_seconds()
        else:
            metrics["container_startup_time"] = None
        if not container.is_healthy:
            diagnostics.append(
                f"Container unhealthy: {container.health_checks_passed} checks passed"
            )
    else:
        metrics["container_healthy"] = False
        metrics["health_checks_passed"] = 0
        metrics["container_id"] = None
        metrics["container_startup_time"] = None
        diagnostics.append("No container found for project")

    metrics["_container"] = container
    return metrics


def collect_pipeline_metrics(
    project: Any, session_start_dt: Any, diagnostics: List[str]
) -> Dict[str, Any]:
    """Collect pipeline execution metrics.

    Args:
        project: Project instance (Django model).
        session_start_dt: Session start as datetime (UTC).
        diagnostics: List to append diagnostic messages to.

    Returns:
        Dictionary of pipeline metrics. Includes '_pe' key with instance.
    """
    from backend.pipelines.models import PipelineExecution, StageExecution

    metrics: Dict[str, Any] = {}
    pe = (
        PipelineExecution.objects.filter(
            project=project, timestamp__gte=session_start_dt
        )
        .order_by("-timestamp")
        .first()
    )
    if pe:
        metrics["pipeline_status"] = pe.status
        metrics["pipeline_id"] = str(pe.id)
        metrics["pipeline_name"] = pe.pipeline.name if pe.pipeline else None
        if pe.error_message:
            diagnostics.append(f"Pipeline error: {pe.error_message[:100]}")

        stages = StageExecution.objects.filter(
            pipeline_execution=pe
        ).order_by("order")
        stage_details = []
        for stage in stages:
            stage_info = {
                "name": stage.stage_name,
                "status": stage.status,
                "order": stage.order,
            }
            if stage.started_at and stage.completed_at:
                stage_info["duration"] = (
                    stage.completed_at - stage.started_at
                ).total_seconds()
            else:
                stage_info["duration"] = None
            if stage.error_message:
                stage_info["error"] = stage.error_message[:100]
                diagnostics.append(
                    f"Stage '{stage.stage_name}' failed: {stage.error_message[:50]}"
                )
            stage_details.append(stage_info)
        metrics["pipeline_stages"] = stage_details
    else:
        metrics["pipeline_status"] = None
        metrics["pipeline_id"] = None
        metrics["pipeline_name"] = None
        metrics["pipeline_stages"] = []

    metrics["_pe"] = pe
    return metrics


def collect_kg_metrics(
    project: Any, container: Optional[Any], diagnostics: List[str]
) -> Dict[str, Any]:
    """Collect knowledge graph metrics.

    Args:
        project: Project instance (Django model).
        container: Container instance (may be None).
        diagnostics: List to append diagnostic messages to.

    Returns:
        Dictionary of knowledge graph metrics.
    """
    from backend.graphs.models import GraphPage, KnowledgeGraph

    metrics: Dict[str, Any] = {}
    if container and hasattr(container, "environment"):
        kg = KnowledgeGraph.objects.filter(
            environment=container.environment
        ).first()
    else:
        kg = KnowledgeGraph.objects.filter(
            environment__project=project
        ).first()

    if kg:
        metrics["kg_exists"] = True
        metrics["kg_id"] = str(kg.id)
        metrics["kg_pages"] = GraphPage.objects.filter(graph=kg).count()
        if metrics["kg_pages"] == 0:
            diagnostics.append(
                "Knowledge graph exists but has 0 pages - crawl failed"
            )
    else:
        metrics["kg_exists"] = False
        metrics["kg_id"] = None
        metrics["kg_pages"] = 0
        diagnostics.append("No knowledge graph found")

    return metrics


def collect_surfer_metrics(
    project: Any, session_start_dt: Any, diagnostics: List[str]
) -> Dict[str, Any]:
    """Collect surfer/crawler metrics.

    Args:
        project: Project instance (Django model).
        session_start_dt: Session start as datetime (UTC).
        diagnostics: List to append diagnostic messages to.

    Returns:
        Dictionary containing surfer summary under 'surfers' key.
    """
    from backend.surfers.models import Surfer

    session_surfers = Surfer.objects.filter(
        project=project, timestamp__gte=session_start_dt
    ).order_by("-timestamp")

    surfer_summary: Dict[str, Any] = {
        "total": session_surfers.count(),
        "completed": 0,
        "failed": 0,
        "running": 0,
        "errors": [],
    }

    for surfer in session_surfers[:10]:
        goal_status = surfer.goal_status
        if goal_status == "DONE":
            surfer_summary["completed"] += 1
        elif goal_status == "FAILED":
            surfer_summary["failed"] += 1
            if surfer.metadata and surfer.metadata.get("error"):
                error_msg = surfer.metadata["error"][:100]
                if error_msg not in surfer_summary["errors"]:
                    surfer_summary["errors"].append(error_msg)
                    diagnostics.append(f"Surfer error: {error_msg[:60]}")
        elif goal_status is None:
            surfer_summary["running"] += 1

    if surfer_summary["failed"] > 0 and surfer_summary["completed"] == 0:
        diagnostics.append(
            f"All {surfer_summary['failed']} surfers failed - browser issues likely"
        )

    return {"surfers": surfer_summary}


def collect_e2e_metrics(
    project: Any,
    session_start_dt: Any,
    pe: Optional[Any],
    diagnostics: List[str],
) -> Dict[str, Any]:
    """Collect E2E test metrics.

    Args:
        project: Project instance (Django model).
        session_start_dt: Session start as datetime (UTC).
        pe: Pipeline execution instance (may be None).
        diagnostics: List to append diagnostic messages to.

    Returns:
        Dictionary of E2E metrics.
    """
    from django.db.models import Avg, Q
    from backend.e2es.models import E2eRun, E2eRunMetrics

    metrics: Dict[str, Any] = {}

    if pe:
        session_runs = E2eRun.objects.filter(
            Q(pipeline_execution=pe)
            | Q(project=project, timestamp__gte=session_start_dt)
        ).distinct()
    else:
        session_runs = E2eRun.objects.filter(
            project=project, timestamp__gte=session_start_dt
        )

    metrics["e2e_runs"] = session_runs.count()
    metrics["e2e_passed"] = session_runs.filter(outcome="pass").count()
    metrics["e2e_failed"] = session_runs.filter(outcome="fail").count()
    metrics["e2e_error"] = session_runs.filter(outcome="error").count()
    metrics["e2e_pending"] = session_runs.filter(
        status__in=["pending", "running"]
    ).count()

    if metrics["e2e_runs"] > 0:
        metrics["e2e_error_rate"] = round(
            (metrics["e2e_error"] / metrics["e2e_runs"]) * 100, 1
        )
        metrics["e2e_pass_rate"] = round(
            (metrics["e2e_passed"] / metrics["e2e_runs"]) * 100, 1
        )
    else:
        metrics["e2e_error_rate"] = 0.0
        metrics["e2e_pass_rate"] = 0.0

    session_run_ids = list(session_runs.values_list("id", flat=True))
    if session_run_ids:
        avg_result = E2eRunMetrics.objects.filter(
            run_id__in=session_run_ids
        ).aggregate(avg_steps=Avg("num_steps"))
        metrics["e2e_avg_steps"] = round(avg_result["avg_steps"] or 0, 1)
    else:
        metrics["e2e_avg_steps"] = 0.0

    if metrics["e2e_error"] > 0:
        diagnostics.append(
            f"{metrics['e2e_error']} E2E runs errored - this is a system bug!"
        )

    return metrics


def collect_all_metrics(
    project: Any,
    session_start: float,
    verbose: bool,
    retry_config: RetryConfig,
) -> Dict[str, Any]:
    """Collect comprehensive metrics for a project.

    Orchestrates collection from all focused metric functions.

    Args:
        project: Project instance (Django model).
        session_start: Start time of this session (Unix timestamp).
        verbose: Print verbose output.
        retry_config: Retry configuration for transient failures.

    Returns:
        Dictionary of metrics including diagnostics.
    """
    from datetime import datetime, timezone as dt_timezone
    from django.db import OperationalError

    @retry_with_backoff(
        max_attempts=retry_config.max_attempts,
        initial_delay=retry_config.initial_delay,
        max_delay=retry_config.max_delay,
        exponential_base=retry_config.exponential_base,
        exceptions=(OperationalError, ConnectionError, TimeoutError),
        logger_instance=logger,
    )
    def _collect_with_retry():
        session_start_dt = datetime.fromtimestamp(
            session_start, tz=dt_timezone.utc
        )

        metrics: Dict[str, Any] = {}
        diagnostics: List[str] = []

        metrics["_session_start"] = session_start

        build_metrics = collect_build_metrics(
            project, session_start_dt, diagnostics
        )
        metrics.update(build_metrics)

        container_metrics = collect_container_metrics(
            project, session_start_dt, diagnostics
        )
        container = container_metrics.pop("_container")
        metrics.update(container_metrics)

        pipeline_metrics = collect_pipeline_metrics(
            project, session_start_dt, diagnostics
        )
        pe = pipeline_metrics.pop("_pe")
        metrics.update(pipeline_metrics)

        kg_metrics = collect_kg_metrics(project, container, diagnostics)
        metrics.update(kg_metrics)

        surfer_metrics = collect_surfer_metrics(
            project, session_start_dt, diagnostics
        )
        metrics.update(surfer_metrics)

        e2e_metrics = collect_e2e_metrics(
            project, session_start_dt, pe, diagnostics
        )
        metrics.update(e2e_metrics)

        metrics["diagnostics"] = diagnostics
        metrics["diagnostic_count"] = len(diagnostics)

        return metrics

    return _collect_with_retry()
