"""Pytest adapter implementation for test discovery and execution."""

import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import pytest
    from _pytest.config import Config
    from _pytest.main import Session
    from _pytest.nodes import Item
    from _pytest.python import Function

    PYTEST_AVAILABLE = True
except ImportError:
    PYTEST_AVAILABLE = False

from systemeval.adapters.base import AdapterConfig, BaseAdapter, TestFailure, TestItem, TestResult
from systemeval.utils import working_directory
from systemeval.utils.django import detect_django_settings
from systemeval.utils.logging import get_logger

logger = get_logger(__name__)


class PytestCollectPlugin:
    """Plugin to collect test items during pytest collection phase."""

    def __init__(self) -> None:
        self.items: List[Item] = []

    def pytest_collection_finish(self, session: Session) -> None:
        """Called after collection has been performed."""
        self.items = session.items


class PytestResultPlugin:
    """Plugin to capture test results during pytest execution."""

    def __init__(self) -> None:
        self.passed = 0
        self.failed = 0
        self.errors = 0
        self.skipped = 0
        self.failures: List[TestFailure] = []
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None

    def pytest_sessionstart(self, session: Session) -> None:
        """Called at the start of the test session."""
        import time

        self.start_time = time.time()

    def pytest_sessionfinish(self, session: Session) -> None:
        """Called at the end of the test session."""
        import time

        self.end_time = time.time()

    def pytest_runtest_logreport(self, report: Any) -> None:
        """Called for each test run phase (setup, call, teardown)."""
        # Only process the 'call' phase
        if report.when != "call":
            return

        if report.passed:
            self.passed += 1
        elif report.failed:
            self.failed += 1
            self.failures.append(
                TestFailure(
                    test_id=report.nodeid,
                    test_name=report.nodeid.split("::")[-1],
                    message=str(report.longrepr) if hasattr(report, "longrepr") else "",
                    traceback=str(report.longrepr) if hasattr(report, "longrepr") else None,
                    duration=report.duration if hasattr(report, "duration") else 0.0,
                )
            )
        elif report.skipped:
            self.skipped += 1

    def pytest_internalerror(self, excrepr: Any) -> None:
        """Called for internal errors."""
        self.errors += 1

    def get_result(self, exit_code: int) -> TestResult:
        """Build TestResult from collected data.

        Args:
            exit_code: Pytest exit code

        Returns:
            TestResult object
        """
        duration = 0.0
        if self.start_time and self.end_time:
            duration = self.end_time - self.start_time

        return TestResult(
            passed=self.passed,
            failed=self.failed,
            errors=self.errors,
            skipped=self.skipped,
            duration=duration,
            failures=self.failures,
            exit_code=exit_code,
        )


class PytestAdapter(BaseAdapter):
    """Pytest framework adapter.

    Example:
        config = AdapterConfig(
            project_root="/path/to/project",
            test_directory="tests",
            markers=["unit"],
            parallel=True,
        )
        adapter = PytestAdapter(config)
    """

    def __init__(self, config: AdapterConfig) -> None:
        """Initialize pytest adapter.

        Args:
            config: AdapterConfig with project root and test settings.
        """
        if not PYTEST_AVAILABLE:
            raise ImportError(
                "pytest is not installed. Install with: pip install systemeval[pytest]"
            )
        super().__init__(config)
        self._detect_django()

    def _detect_django(self) -> None:
        """Detect if this is a Django project and set DJANGO_SETTINGS_MODULE."""
        detect_django_settings(self.project_root, require_manage_py=True)

    def validate_environment(self) -> bool:
        """Validate that pytest is properly configured.

        Returns:
            True if environment is valid, False otherwise
        """
        if not PYTEST_AVAILABLE:
            return False

        # Check if pytest.ini or pyproject.toml exists
        pytest_ini = Path(self.project_root) / "pytest.ini"
        pyproject_toml = Path(self.project_root) / "pyproject.toml"
        setup_cfg = Path(self.project_root) / "setup.cfg"

        return any([pytest_ini.exists(), pyproject_toml.exists(), setup_cfg.exists()])

    def discover(
        self,
        category: Optional[str] = None,
        app: Optional[str] = None,
        file: Optional[str] = None,
        timeout: int = 60,
    ) -> List[TestItem]:
        """Discover tests matching criteria.

        Uses subprocess to run pytest --collect-only, avoiding in-process
        side effects (e.g. duplicate pytest.main() calls corrupting state).

        Args:
            category: Test marker to filter by (e.g., 'unit', 'integration')
            app: Application/module path to filter by
            file: Specific test file path to filter by
            timeout: Maximum seconds to wait for collection (default 60)

        Returns:
            List of discovered test items
        """
        cmd = [sys.executable, "-m", "pytest", "--collect-only", "-q"]

        # Build pytest arguments based on filters
        if category:
            cmd.extend(["-m", category])

        if file:
            test_path = Path(self.project_root) / file
            if test_path.exists():
                cmd.append(str(test_path))
        elif app:
            app_path = Path(self.project_root) / app
            if app_path.exists():
                cmd.append(str(app_path))
        else:
            # Default to project root
            cmd.append(self.project_root)

        # Run pytest collection as subprocess with timeout
        try:
            result = subprocess.run(
                cmd,
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            logger.error(
                f"Test discovery timed out after {timeout}s. "
                f"Command: {' '.join(cmd)}"
            )
            return []

        # Check exit code for collection errors
        # pytest exit codes: 0=tests collected, 1=tests failed (still collected),
        # 2=interrupted, 3=internal error, 4=usage error, 5=no tests found
        if result.returncode == 5:
            logger.info("No tests found matching the given criteria")
            return []
        elif result.returncode in (2, 3, 4):
            error_detail = result.stderr.strip() or result.stdout.strip()
            logger.error(
                f"pytest collection failed (exit code {result.returncode}): "
                f"{error_detail[:500]}"
            )
            raise RuntimeError(
                f"pytest collection failed (exit code {result.returncode}): "
                f"{error_detail[:500]}"
            )

        # Parse output lines -- test node IDs contain '::'
        test_items = []
        for line in result.stdout.splitlines():
            line = line.strip()
            if "::" in line and not line.startswith(("=", "-", "ERRORS", "ERROR")):
                # Node ID format: path/to/test.py::TestClass::test_method
                # or path/to/test.py::test_function
                node_id = line.split()[0] if line else ""
                if not node_id or "::" not in node_id:
                    continue

                parts = node_id.split("::")
                test_path = parts[0]
                test_name = parts[-1]

                # Extract class name if present
                class_name = parts[1] if len(parts) > 2 else None
                # Derive module name from path
                module_name = test_path.replace("/", ".").replace(".py", "")

                test_items.append(
                    TestItem(
                        id=node_id,
                        name=test_name,
                        path=test_path,
                        markers=[],
                        metadata={
                            "module": module_name,
                            "class": class_name,
                        },
                    )
                )

        return test_items

    def execute(
        self,
        tests: Optional[List[TestItem]] = None,
        parallel: bool = False,
        coverage: bool = False,
        failfast: bool = False,
        verbose: bool = False,
        timeout: Optional[int] = None,
    ) -> TestResult:
        """Execute tests and return results.

        Args:
            tests: Specific test items to run (None = run all)
            parallel: Enable parallel test execution (requires pytest-xdist)
            coverage: Enable coverage reporting (requires pytest-cov)
            failfast: Stop on first failure
            verbose: Verbose output
            timeout: Timeout in seconds for entire test run

        Returns:
            Test execution results
        """
        args = []

        # Verbosity
        if verbose:
            args.append("-vv")
        else:
            args.append("-v")

        # Fail fast
        if failfast:
            args.append("-x")

        # Parallel execution
        if parallel:
            try:
                import xdist  # noqa: F401

                args.extend(["-n", "auto"])
            except ImportError:
                logger.warning("pytest-xdist not installed, running serially")

        # Coverage
        if coverage:
            try:
                import pytest_cov  # noqa: F401

                args.extend(["--cov", self.project_root, "--cov-report", "term-missing"])
            except ImportError:
                logger.warning("pytest-cov not installed, skipping coverage")

        # Timeout
        if timeout:
            args.append(f"--timeout={timeout}")

        # Use custom plugin to capture results
        result_plugin = PytestResultPlugin()

        # Specific tests or full suite
        if tests:
            for test in tests:
                args.append(f"{test.path}::{test.name}")
        else:
            args.append(self.project_root)

        # Execute pytest
        with working_directory(self.project_root):
            exit_code = pytest.main(args, plugins=[result_plugin])

        # Build result from collected data
        return result_plugin.get_result(exit_code)

    def get_command(
        self,
        tests: Optional[List[TestItem]] = None,
        parallel: bool = False,
        coverage: bool = False,
        failfast: bool = False,
        verbose: bool = False,
        timeout: Optional[int] = None,
    ) -> List[str]:
        """Get the pytest command that would be used to run tests.

        Args:
            tests: Specific test items to run (None = run all)
            parallel: Enable parallel test execution
            coverage: Enable coverage reporting
            failfast: Stop on first failure
            verbose: Verbose output
            timeout: Timeout in seconds

        Returns:
            List of command arguments (e.g., ['pytest', '-v', 'tests/'])
        """
        args = ["pytest"]

        # Verbosity
        if verbose:
            args.append("-vv")
        else:
            args.append("-v")

        # Fail fast
        if failfast:
            args.append("-x")

        # Parallel execution
        if parallel:
            args.extend(["-n", "auto"])

        # Coverage
        if coverage:
            args.extend(["--cov", self.project_root, "--cov-report", "term-missing"])

        # Timeout
        if timeout:
            args.append(f"--timeout={timeout}")

        # Specific tests or full suite
        if tests:
            for test in tests:
                args.append(f"{test.path}::{test.name}")
        else:
            args.append(self.project_root)

        return args

    def get_available_markers(self) -> List[str]:
        """Return available test markers/categories.

        Returns:
            List of marker names
        """
        args = ["--markers"]

        # Capture markers from pytest
        markers = []
        with working_directory(self.project_root):
            # Run pytest --markers and capture output
            import io
            import contextlib

            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                pytest.main(args)

            output_text = output.getvalue()

            # Parse markers from output
            # Format is typically: @pytest.mark.markername: description
            for line in output_text.split("\n"):
                if line.strip().startswith("@pytest.mark."):
                    marker_name = line.split("@pytest.mark.")[1].split(":")[0].strip()
                    if marker_name and marker_name not in ["parametrize", "skip", "skipif"]:
                        markers.append(marker_name)

        return sorted(set(markers))
