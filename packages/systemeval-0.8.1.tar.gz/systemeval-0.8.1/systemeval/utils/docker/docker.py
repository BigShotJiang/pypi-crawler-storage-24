"""
Docker environment detection and availability checks.
"""
import os
import subprocess
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Optional


def is_docker_environment() -> bool:
    """
    Detect if running inside Docker container.

    Checks multiple indicators:
    - Presence of /.dockerenv file
    - DOCKER_CONTAINER environment variable
    - Container-specific cgroup entries
    """
    # Check for /.dockerenv file (most reliable)
    if Path("/.dockerenv").exists():
        return True

    # Check for DOCKER_CONTAINER env var
    if os.environ.get("DOCKER_CONTAINER"):
        return True

    # Check cgroup for docker/containerd entries
    try:
        with open("/proc/1/cgroup", "r") as f:
            cgroup_content = f.read()
            if "docker" in cgroup_content or "containerd" in cgroup_content:
                return True
    except (FileNotFoundError, PermissionError):
        # /proc/1/cgroup might not exist on non-Linux systems
        pass

    return False


def get_environment_type() -> str:
    """
    Return 'docker' or 'local' based on environment detection.

    Returns:
        str: 'docker' if running in a container, 'local' otherwise
    """
    return "docker" if is_docker_environment() else "local"


def get_docker_compose_service() -> Optional[str]:
    """
    Get the Docker Compose service name if running in Docker Compose.

    Returns:
        Optional[str]: Service name from COMPOSE_SERVICE env var, or None
    """
    return os.environ.get("COMPOSE_SERVICE")


def get_container_id() -> Optional[str]:
    """
    Get the container ID if running in Docker.

    Returns:
        Optional[str]: Container ID from hostname, or None
    """
    if not is_docker_environment():
        return None

    # In Docker, hostname is typically the container ID
    return os.environ.get("HOSTNAME")


def check_docker_available() -> bool:
    """
    Check if Docker is installed and the daemon is running.

    Returns:
        bool: True if docker binary exists and daemon is responsive
    """
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


class DockerMode(Enum):
    """Result of Docker auto-detection."""
    INSIDE_CONTAINER = "inside_container"  # We're running inside Docker
    ATTACH = "attach"                      # Containers running, attach to them
    START = "start"                        # Containers exist but stopped, start them
    BUILD_AND_START = "build_and_start"    # Need full build + start lifecycle
    LOCAL_ONLY = "local_only"              # No Docker available, run locally


@dataclass
class DockerDetectionResult:
    """Result of Docker environment auto-detection."""
    mode: DockerMode
    compose_file: Optional[Path] = None
    reason: str = ""

    @property
    def needs_docker(self) -> bool:
        return self.mode not in (DockerMode.INSIDE_CONTAINER, DockerMode.LOCAL_ONLY)

    @property
    def can_use_docker(self) -> bool:
        return self.mode != DockerMode.LOCAL_ONLY


def _check_containers_running(compose_file: Path, project_dir: Path) -> Optional[str]:
    """Check if containers are running for a compose file.

    Returns:
        'running' if test-relevant containers are up,
        'stopped' if they exist but are stopped,
        None if no containers found.
    """
    try:
        result = subprocess.run(
            ["docker", "compose", "-f", str(compose_file), "ps", "--format", "json"],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=str(project_dir),
        )
        if result.returncode != 0:
            return None

        output = result.stdout.strip()
        if not output:
            return None

        # docker compose ps --format json may return:
        # - one JSON object per line (older versions)
        # - a single JSON array on one line (newer versions)
        import json
        containers = []
        for line in output.splitlines():
            line = line.strip()
            if line:
                try:
                    parsed = json.loads(line)
                    if isinstance(parsed, list):
                        containers.extend(parsed)
                    else:
                        containers.append(parsed)
                except json.JSONDecodeError:
                    continue

        if not containers:
            return None

        running = any(
            c.get("State") == "running" or c.get("Status", "").startswith("Up")
            for c in containers
        )
        return "running" if running else "stopped"

    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def auto_detect_docker(project_dir: Path) -> DockerDetectionResult:
    """Auto-detect the best Docker execution mode for a project.

    Decision tree:
    1. Inside a container already? → INSIDE_CONTAINER
    2. Docker unavailable? → LOCAL_ONLY
    3. No compose file found? → LOCAL_ONLY
    4. Containers already running? → ATTACH
    5. Containers stopped? → START
    6. No containers? → BUILD_AND_START

    Args:
        project_dir: Project root directory.

    Returns:
        DockerDetectionResult with the recommended mode.
    """
    # 1. Are we inside a container?
    if is_docker_environment():
        return DockerDetectionResult(
            mode=DockerMode.INSIDE_CONTAINER,
            reason="Running inside Docker container",
        )

    # 2. Is Docker available?
    if not check_docker_available():
        return DockerDetectionResult(
            mode=DockerMode.LOCAL_ONLY,
            reason="Docker not available (binary missing or daemon not running)",
        )

    # 3. Find compose file
    from systemeval.utils.docker.discovery import find_compose_file
    compose_file = find_compose_file(project_dir)
    if not compose_file:
        return DockerDetectionResult(
            mode=DockerMode.LOCAL_ONLY,
            reason="No docker-compose file found",
        )

    # 4-6. Check container state
    container_state = _check_containers_running(compose_file, project_dir)

    if container_state == "running":
        return DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=compose_file,
            reason=f"Containers already running ({compose_file.name})",
        )
    elif container_state == "stopped":
        return DockerDetectionResult(
            mode=DockerMode.START,
            compose_file=compose_file,
            reason=f"Containers stopped, will restart ({compose_file.name})",
        )
    else:
        return DockerDetectionResult(
            mode=DockerMode.BUILD_AND_START,
            compose_file=compose_file,
            reason=f"No containers found, full build needed ({compose_file.name})",
        )
