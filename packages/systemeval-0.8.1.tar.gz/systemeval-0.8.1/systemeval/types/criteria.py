"""Pipeline evaluation criteria types.

Defines the Criterion model for configurable pass/fail evaluation of pipeline
metrics. Replaces the hardcoded CRITERIA dict in PipelineAdapter with a
structured, serializable model.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, List, Optional


class CriterionOp(str, Enum):
    """Comparison operators for criterion evaluation."""

    EQUALS = "equals"
    IS_TRUE = "is_true"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"


@dataclass
class Criterion:
    """A single pass/fail criterion for pipeline evaluation.

    Attributes:
        metric: The key in the metrics dictionary to evaluate.
        op: The comparison operator.
        expected: The expected value (unused for IS_TRUE).
        failure_template: Format string for failure messages.
            Supports {value} and {expected} placeholders.
    """

    metric: str
    op: CriterionOp
    expected: Any = None
    failure_template: str = ""

    def evaluate(self, value: Any) -> bool:
        """Evaluate a metric value against this criterion.

        Args:
            value: The actual metric value from the metrics dict.

        Returns:
            True if the value satisfies the criterion.
        """
        if self.op == CriterionOp.EQUALS:
            return value == self.expected
        elif self.op == CriterionOp.IS_TRUE:
            return value is True
        elif self.op == CriterionOp.GT:
            return value is not None and value > self.expected
        elif self.op == CriterionOp.GTE:
            return value is not None and value >= self.expected
        elif self.op == CriterionOp.LT:
            return value is not None and value < self.expected
        elif self.op == CriterionOp.LTE:
            return value is not None and value <= self.expected
        return False

    def format_failure(self, value: Any) -> str:
        """Format a failure message for the given value.

        Args:
            value: The actual metric value that failed.

        Returns:
            Human-readable failure message.
        """
        if self.failure_template:
            try:
                return self.failure_template.format(
                    value=value, expected=self.expected
                )
            except (KeyError, ValueError, TypeError):
                pass
        return f"{self.metric}: got {value}, expected {self.op.value} {self.expected}"


def check_criteria(
    metrics: dict, criteria: List["Criterion"]
) -> bool:
    """Check if metrics pass all criteria.

    Args:
        metrics: Dictionary of collected metrics.
        criteria: List of Criterion to evaluate.

    Returns:
        True if all criteria pass.
    """
    for criterion in criteria:
        value = metrics.get(criterion.metric)
        if not criterion.evaluate(value):
            return False
    return True


def get_failure_messages(
    metrics: dict, criteria: List["Criterion"]
) -> List[str]:
    """Collect failure messages for all failing criteria.

    Args:
        metrics: Dictionary of collected metrics.
        criteria: List of Criterion to evaluate.

    Returns:
        List of human-readable failure messages.
    """
    failures = []
    for criterion in criteria:
        value = metrics.get(criterion.metric)
        if not criterion.evaluate(value):
            failures.append(criterion.format_failure(value))
    return failures


# Default pipeline criteria matching the original hardcoded CRITERIA dict.
DEFAULT_PIPELINE_CRITERIA: List[Criterion] = [
    Criterion(
        metric="build_status",
        op=CriterionOp.EQUALS,
        expected="succeeded",
        failure_template="Build failed: {value}",
    ),
    Criterion(
        metric="container_healthy",
        op=CriterionOp.IS_TRUE,
        failure_template="Container not healthy",
    ),
    Criterion(
        metric="kg_exists",
        op=CriterionOp.IS_TRUE,
        failure_template="Knowledge graph does not exist",
    ),
    Criterion(
        metric="kg_pages",
        op=CriterionOp.GT,
        expected=0,
        failure_template="Knowledge graph has {value} pages (required: > 0)",
    ),
    Criterion(
        metric="e2e_error_rate",
        op=CriterionOp.EQUALS,
        expected=0,
        failure_template="E2E error rate: {value}% (required: 0%)",
    ),
]
