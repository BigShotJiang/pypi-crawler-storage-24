"""AI Help commands for SystemEval CLI.

This module provides structured, machine-parseable documentation
designed specifically for AI agents to quickly understand SystemEval.
"""
import json
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from systemeval.config import load_config, find_config_file

console = Console()


@click.command('ai-help')
@click.option('--format', type=click.Choice(['json', 'text']), default='json',
              help='Output format (json for agents, text for humans)')
@click.option('--config', type=click.Path(exists=True), help='Path to config file')
def ai_help(format: str, config: Optional[str]) -> None:
        """AI-friendly system overview with structured data.

        Provides complete SystemEval documentation in machine-parseable format.
        Designed for AI agents to quickly build understanding of:
        - Core concepts and architecture
        - Available commands and options
        - Configuration structure
        - Workflow patterns
        - Exit codes and verdicts
        """
        try:
            # Load project config if available
            config_path = Path(config) if config else find_config_file()
            project_config = None
            if config_path:
                try:
                    project_config = load_config(config_path)
                except Exception:
                    pass  # Config optional for overview

            help_data = {
                "systemeval_version": "0.7.1",
                "purpose": "Unified test runner with deterministic verdicts",
                "core_concepts": {
                    "adapter": "Framework-agnostic test execution (pytest, jest, playwright)",
                    "environment": "Execution context (docker-compose, standalone, remote)",
                    "category": "Logical test grouping with markers (unit, integration, e2e)",
                    "verdict": "Deterministic result (PASS/FAIL/ERROR - not fungible)",
                    "exit_codes": {
                        "0": "PASS - all tests passed, all criteria met",
                        "1": "FAIL - one or more tests failed",
                        "2": "ERROR - configuration, collection, or execution error",
                        "5": "ERROR - no tests collected (when tests expected)"
                    }
                },
                "critical_rules": {
                    "mandatory_for_agents": "AI agents MUST use systemeval, never raw test frameworks",
                    "structured_output": "Always use --json or --template for machine-parseable results",
                    "no_interpretation": "Rely on verdict, don't parse raw test output",
                    "traceability": "Every result has UUID, timestamp, full context"
                },
                "common_commands": {
                    "test_by_category": {
                        "command": "systemeval test -c <category>",
                        "example": "systemeval test -c unit --json",
                        "description": "Run tests by category (unit, integration, api, etc.)"
                    },
                    "test_by_app": {
                        "command": "systemeval test --app <app_name>",
                        "example": "systemeval test --app agents --json",
                        "description": "Run tests for specific Django app"
                    },
                    "test_specific_file": {
                        "command": "systemeval test --file <path>",
                        "example": "systemeval test --file backend/tests/test_workflow.py",
                        "description": "Run specific test file"
                    },
                    "test_with_environment": {
                        "command": "systemeval test --env <env_name>",
                        "example": "systemeval test --env docker -c integration",
                        "description": "Run tests in specific environment"
                    },
                    "pipeline_evaluation": {
                        "command": "systemeval test --projects <project>",
                        "example": "systemeval test --projects crochet-patterns --timeout 600",
                        "description": "Full pipeline: build → deploy → crawl → E2E"
                    }
                },
                "discovery_commands": {
                    "list_categories": "systemeval list categories",
                    "list_environments": "systemeval list environments",
                    "list_templates": "systemeval list templates",
                    "list_adapters": "systemeval list adapters"
                },
                "workflow_for_agents": {
                    "step_1": "Run: systemeval test --json",
                    "step_2": "Parse JSON: extract verdict, failures, errors",
                    "step_3": {
                        "if_PASS": "Done - tests passed",
                        "if_FAIL": "Read failure details, fix code, goto step_1",
                        "if_ERROR": "Fix config/setup, goto step_1"
                    },
                    "step_4": "NEVER parse raw pytest/jest output - use systemeval verdict"
                },
                "output_formats": {
                    "json": {
                        "flag": "--json",
                        "use": "Machine-parseable, complete metadata",
                        "fields": ["verdict", "exit_code", "total", "passed", "failed", "errors", "duration", "timestamp"]
                    },
                    "template": {
                        "flag": "--template <name>",
                        "use": "Formatted output (markdown, github, summary)",
                        "available": ["summary", "markdown", "github", "json", "ci"]
                    }
                },
                "configuration": {
                    "file": "systemeval.yaml",
                    "location": "project root or specified via --config",
                    "required_sections": ["adapter", "project"],
                    "optional_sections": ["categories", "environments", "pytest", "suites"],
                    "example_minimal": {
                        "adapter": "pytest",
                        "project": {
                            "name": "my-project",
                            "type": "django"
                        }
                    }
                }
            }

            # Add project-specific data if available
            if project_config:
                project_info = getattr(project_config, 'project', None)
                project_name = project_info.name if project_info and hasattr(project_info, 'name') else "unknown"

                help_data["project_config"] = {
                    "name": project_name,
                    "adapter": getattr(project_config, 'adapter', 'unknown'),
                    "categories": list(project_config.categories.keys()) if hasattr(project_config, 'categories') and project_config.categories else [],
                    "environments": list(project_config.environments.keys()) if hasattr(project_config, 'environments') and project_config.environments else []
                }

            if format == 'json':
                print(json.dumps(help_data, indent=2))
            else:
                # Text format for human readability
                console.print("\n[bold cyan]SystemEval AI Help[/bold cyan]\n")
                console.print(f"[dim]Version:[/dim] {help_data['systemeval_version']}")
                console.print(f"[dim]Purpose:[/dim] {help_data['purpose']}\n")

                console.print("[bold]Core Concepts:[/bold]")
                for key, value in help_data['core_concepts'].items():
                    if key != 'exit_codes':
                        console.print(f"  • {key}: {value}")

                console.print("\n[bold]Critical Rules:[/bold]")
                for key, value in help_data['critical_rules'].items():
                    console.print(f"  • {value}")

                console.print("\n[bold]Common Commands:[/bold]")
                for name, cmd_info in help_data['common_commands'].items():
                    console.print(f"  [cyan]{cmd_info['command']}[/cyan]")
                    console.print(f"    {cmd_info['description']}")
                    console.print(f"    Example: [dim]{cmd_info['example']}[/dim]\n")

                console.print("[dim]For complete JSON output: systemeval ai-help --format json[/dim]")

        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(2)
