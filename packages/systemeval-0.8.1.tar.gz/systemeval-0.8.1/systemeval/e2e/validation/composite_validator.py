"""Composite E2E configuration validator.

Migrated to use the shared ``systemeval.validation`` framework.
Each validation concern is a named Rule so callers can run individual
checks via ``validate_one()`` or list available rules via ``list_rules()``.
"""

from typing import List

from systemeval.validation.base import BaseValidator, Rule
from systemeval.validation.result import ValidationResult

from ..core.types import E2EConfig
from .base import BaseE2EValidator, PROVIDERS_REQUIRING_API_KEY
from .debuggai_validator import DebuggAIValidator


class E2EConfigValidator(BaseValidator):
    """Validates E2E configurations comprehensively.

    Checks:
    - Required fields (provider_name, project_root)
    - Provider-specific requirements (api_key for debuggai)
    - Path validation (project_root exists, output_directory writable)
    - URL validation (api_base_url, project_url formats)
    - Timeout bounds (reasonable ranges)
    - Test framework compatibility

    Usage::

        validator = E2EConfigValidator()
        result = validator.validate(config)
        if not result.valid:
            for error in result.errors:
                print(f"ERROR: {error}")
    """

    def __init__(
        self,
        strict_mode: bool = False,
        check_paths: bool = True,
        check_connectivity: bool = False,
    ) -> None:
        super().__init__(strict_mode=strict_mode)
        self._check_paths = check_paths
        self._check_connectivity = check_connectivity
        self._base_validator = BaseE2EValidator(strict_mode=False, check_paths=check_paths)
        self._debuggai_validator = DebuggAIValidator()

    def get_rules(self) -> List[Rule]:
        return [
            Rule("required_fields", self._rule_required_fields, "Required fields present"),
            Rule("provider_config", self._rule_provider_config, "Provider-specific config"),
            Rule("paths", self._rule_paths, "Path existence and writability"),
            Rule("urls", self._rule_urls, "URL format validation"),
            Rule("timeouts", self._rule_timeouts, "Timeout bounds"),
            Rule("test_framework", self._rule_test_framework, "Framework/language compatibility"),
        ]

    def validate(self, target: E2EConfig) -> ValidationResult:
        """Run all rules and attach metadata to the result."""
        result = super().validate(target)
        result.metadata.update({
            "strict_mode": self._strict_mode,
            "check_paths": self._check_paths,
            "check_connectivity": self._check_connectivity,
        })
        return result

    # ------------------------------------------------------------------
    # Rule wrappers — delegate to the existing BaseE2EValidator methods
    # ------------------------------------------------------------------

    def _rule_required_fields(self, config: E2EConfig) -> ValidationResult:
        return self._base_validator.validate_required_fields(config)

    def _rule_provider_config(self, config: E2EConfig) -> ValidationResult:
        return self.validate_provider_config(config)

    def _rule_paths(self, config: E2EConfig) -> ValidationResult:
        return self._base_validator.validate_paths(config)

    def _rule_urls(self, config: E2EConfig) -> ValidationResult:
        return self._base_validator.validate_urls(config)

    def _rule_timeouts(self, config: E2EConfig) -> ValidationResult:
        return self._base_validator.validate_timeouts(config)

    def _rule_test_framework(self, config: E2EConfig) -> ValidationResult:
        return self._base_validator.validate_test_framework(config)

    # ------------------------------------------------------------------
    # Provider-specific validation (unchanged logic)
    # ------------------------------------------------------------------

    def validate_provider_config(self, config: E2EConfig) -> ValidationResult:
        """Validate provider-specific configuration requirements."""
        errors: List[str] = []
        warnings: List[str] = []

        provider = config.provider_name.lower() if config.provider_name else ""

        if provider in PROVIDERS_REQUIRING_API_KEY:
            if not config.api_key:
                errors.append(
                    f"api_key is required for provider '{config.provider_name}'"
                )
            elif not config.api_key.strip():
                errors.append("api_key cannot be whitespace only")

        if provider == "debuggai":
            result = self._debuggai_validator.validate(config)
            errors.extend(result.errors)
            warnings.extend(result.warnings)
        elif provider == "surfer":
            result = self._validate_surfer_config(config)
            errors.extend(result.errors)
            warnings.extend(result.warnings)

        return ValidationResult(
            valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
        )

    def _validate_surfer_config(self, config: E2EConfig) -> ValidationResult:
        if not config.api_base_url:
            return ValidationResult.error("api_base_url is required for Surfer provider")
        return ValidationResult.ok()

    # ------------------------------------------------------------------
    # Backward compatibility delegation methods
    # ------------------------------------------------------------------

    def validate_required_fields(self, config: E2EConfig) -> ValidationResult:
        """Delegate to base validator (backward compatibility)."""
        return self._base_validator.validate_required_fields(config)

    def validate_paths(self, config: E2EConfig) -> ValidationResult:
        """Delegate to base validator (backward compatibility)."""
        return self._base_validator.validate_paths(config)

    def validate_urls(self, config: E2EConfig) -> ValidationResult:
        """Delegate to base validator (backward compatibility)."""
        return self._base_validator.validate_urls(config)

    def validate_timeouts(self, config: E2EConfig) -> ValidationResult:
        """Delegate to base validator (backward compatibility)."""
        return self._base_validator.validate_timeouts(config)

    def validate_test_framework(self, config: E2EConfig) -> ValidationResult:
        """Delegate to base validator (backward compatibility)."""
        return self._base_validator.validate_test_framework(config)


__all__ = ["E2EConfigValidator"]
