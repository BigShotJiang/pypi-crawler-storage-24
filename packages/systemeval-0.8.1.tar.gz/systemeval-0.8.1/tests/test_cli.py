"""Tests for CLI functionality."""

import json
import pytest
from click.testing import CliRunner
from unittest.mock import patch, MagicMock

from systemeval.cli_main import main
from systemeval.cli.formatting import display_results as _display_results
from systemeval.adapters import TestResult, Verdict
from systemeval.core.evaluation import SCHEMA_VERSION


class TestDisplayResults:
    """Tests for _display_results function."""

    def test_display_passing_results(self, passing_test_result, capsys):
        """Test display of passing results."""
        _display_results(passing_test_result)
        # Just verify it doesn't crash
        # Rich output is hard to test directly

    def test_display_failing_results(self, failing_test_result, capsys):
        """Test display of failing results."""
        _display_results(failing_test_result)

    def test_display_error_results(self, error_test_result, capsys):
        """Test display of error results."""
        _display_results(error_test_result)


class TestCLIHelp:
    """Tests for CLI help and basic commands."""

    def test_help(self):
        """Test --help flag."""
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])

        assert result.exit_code == 0
        assert "SystemEval" in result.output

    def test_version(self):
        """Test --version flag."""
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])

        assert result.exit_code == 0

    def test_test_help(self):
        """Test 'test --help' command."""
        runner = CliRunner()
        result = runner.invoke(main, ["test", "--help"])

        assert result.exit_code == 0
        assert "--category" in result.output
        assert "--json" in result.output
        assert "--env" in result.output


class TestCLIListCommands:
    """Tests for CLI list subcommands."""

    def test_list_adapters(self):
        """Test 'list adapters' command."""
        runner = CliRunner()
        result = runner.invoke(main, ["list", "adapters"])

        assert result.exit_code == 0
        assert "pytest" in result.output.lower()

    def test_list_templates(self):
        """Test 'list templates' command."""
        runner = CliRunner()
        result = runner.invoke(main, ["list", "templates"])

        assert result.exit_code == 0
        assert "summary" in result.output.lower() or "template" in result.output.lower()

    def test_list_subprojects_v2_config(self, tmp_path):
        """Test 'list subprojects' with a v2.0 config."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text(
            "version: '2.0'\n"
            "subprojects:\n"
            "  - name: backend\n"
            "    path: backend\n"
            "    adapter: pytest\n"
            "    tags: [unit, python]\n"
            "  - name: frontend\n"
            "    path: frontend\n"
            "    adapter: vitest\n"
            "    tags: [unit, typescript]\n"
            "  - name: legacy\n"
            "    path: legacy\n"
            "    adapter: pytest\n"
            "    enabled: false\n"
        )

        runner = CliRunner()
        result = runner.invoke(main, ["list", "subprojects", "--config", str(config_file)])

        assert result.exit_code == 0
        assert "backend" in result.output
        assert "frontend" in result.output
        assert "legacy" in result.output
        assert "Enabled" in result.output
        assert "Disabled" in result.output

    def test_list_subprojects_not_multiproject(self, tmp_path):
        """Test 'list subprojects' with v1.0 config shows warning."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\ntest_directory: tests\n")

        runner = CliRunner()
        result = runner.invoke(main, ["list", "subprojects", "--config", str(config_file)])

        assert result.exit_code == 0
        assert "Not a multi-project" in result.output


class TestJSONOutput:
    """Tests for JSON output format."""

    def test_json_output_schema(self, passing_test_result):
        """Test that JSON output conforms to EvaluationResult schema."""
        eval_result = passing_test_result.to_evaluation(
            adapter_type="pytest",
            project_name="test-project",
        )
        eval_result.finalize()

        json_str = eval_result.to_json()
        data = json.loads(json_str)

        # Check required fields
        assert "verdict" in data
        assert "exit_code" in data
        assert "metadata" in data
        assert "sessions" in data
        assert "summary" in data

        # Check metadata
        metadata = data["metadata"]
        assert "evaluation_id" in metadata
        assert "timestamp_utc" in metadata
        assert "schema_version" in metadata
        assert metadata["schema_version"] == SCHEMA_VERSION

        # Check verdict values
        assert data["verdict"] in ["PASS", "FAIL", "ERROR"]
        assert data["exit_code"] in [0, 1, 2]

    def test_json_output_pass(self, passing_test_result):
        """Test JSON output for passing tests."""
        eval_result = passing_test_result.to_evaluation(adapter_type="pytest")
        eval_result.finalize()

        data = json.loads(eval_result.to_json())

        assert data["verdict"] == "PASS"
        assert data["exit_code"] == 0

    def test_json_output_fail(self, failing_test_result):
        """Test JSON output for failing tests."""
        eval_result = failing_test_result.to_evaluation(adapter_type="pytest")
        eval_result.finalize()

        data = json.loads(eval_result.to_json())

        assert data["verdict"] == "FAIL"
        assert data["exit_code"] == 1

    def test_json_output_error(self, error_test_result):
        """Test JSON output for error results."""
        eval_result = error_test_result.to_evaluation(adapter_type="pytest")
        eval_result.finalize()

        data = json.loads(eval_result.to_json())

        # Error results produce FAIL verdict (errors > 0)
        assert data["exit_code"] in [1, 2]

    def test_json_sessions_contain_metrics(self, passing_test_result):
        """Test that sessions contain metrics."""
        eval_result = passing_test_result.to_evaluation(adapter_type="pytest")
        eval_result.finalize()

        data = json.loads(eval_result.to_json())

        assert len(data["sessions"]) > 0
        session = data["sessions"][0]
        assert "metrics" in session
        assert len(session["metrics"]) > 0

    def test_json_metrics_structure(self, passing_test_result):
        """Test metric structure in JSON output."""
        eval_result = passing_test_result.to_evaluation(adapter_type="pytest")
        eval_result.finalize()

        data = json.loads(eval_result.to_json())
        session = data["sessions"][0]
        metric = session["metrics"][0]

        assert "name" in metric
        assert "value" in metric
        assert "expected" in metric
        assert "passed" in metric

    def test_json_summary_statistics(self, passing_test_result):
        """Test summary statistics in JSON output."""
        eval_result = passing_test_result.to_evaluation(adapter_type="pytest")
        eval_result.finalize()

        data = json.loads(eval_result.to_json())
        summary = data["summary"]

        assert "total_sessions" in summary
        assert "passed_sessions" in summary
        assert "failed_sessions" in summary
        assert "total_metrics" in summary
        assert "passed_metrics" in summary
        assert "failed_metrics" in summary
        assert "total_duration_seconds" in summary


class TestCLIValidate:
    """Tests for validate command."""

    def test_validate_no_config(self):
        """Test validate with no config file."""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["validate"])
            assert result.exit_code == 2
            assert "no systemeval.yaml" in result.output.lower() or "error" in result.output.lower()


class TestCLIInit:
    """Tests for init command."""

    def test_init_creates_config(self):
        """Test that init creates a config file."""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["init"])

            assert result.exit_code == 0
            import os
            assert os.path.exists("systemeval.yaml")

    def test_init_no_overwrite_without_force(self):
        """Test that init doesn't overwrite existing config without --force."""
        runner = CliRunner()
        with runner.isolated_filesystem():
            # Create existing config
            with open("systemeval.yaml", "w") as f:
                f.write("existing: config\n")

            result = runner.invoke(main, ["init"])

            assert result.exit_code == 1
            assert "already exists" in result.output.lower() or "force" in result.output.lower()

    def test_init_force_overwrites(self):
        """Test that init --force overwrites existing config."""
        runner = CliRunner()
        with runner.isolated_filesystem():
            # Create existing config
            with open("systemeval.yaml", "w") as f:
                f.write("existing: config\n")

            result = runner.invoke(main, ["init", "--force"])

            assert result.exit_code == 0

            with open("systemeval.yaml") as f:
                content = f.read()
            assert "adapter" in content  # new config should have adapter


class TestCLITestCommand:
    """Tests for test command (mocked)."""

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    def test_test_no_config(self, mock_find):
        """Test test command with no config."""
        mock_find.return_value = None

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        assert result.exit_code == 2
        assert "no systemeval.yaml" in result.output.lower() or "error" in result.output.lower()

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    def test_test_with_json_output(self, mock_get_adapter, mock_load, mock_find, tmp_path):
        """Test test command with --json flag."""
        # Setup mocks
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        mock_config = MagicMock()
        mock_config.adapter = "pytest"
        mock_config.project_root = tmp_path
        mock_config.environments = None
        mock_config.is_multi_project = False  # Ensure v1.0 single-project mode
        mock_load.return_value = mock_config

        mock_adapter = MagicMock()
        mock_adapter.validate_environment.return_value = True
        mock_adapter.execute.return_value = TestResult(
            passed=5,
            failed=0,
            errors=0,
            skipped=0,
            duration=1.0,
        )
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(main, ["test", "--json"])

        # Should output valid JSON
        if result.exit_code == 0:
            data = json.loads(result.output)
            assert "verdict" in data
            assert "metadata" in data


class TestMultiProjectOptions:
    """Tests for multi-project CLI options (v2.0)."""

    def test_project_option_in_help(self):
        """Test that --project option is documented in help."""
        runner = CliRunner()
        result = runner.invoke(main, ["test", "--help"])

        assert result.exit_code == 0
        assert "--project" in result.output
        assert "subproject" in result.output.lower()

    def test_tags_option_in_help(self):
        """Test that --tags option is documented in help."""
        runner = CliRunner()
        result = runner.invoke(main, ["test", "--help"])

        assert result.exit_code == 0
        assert "--tags" in result.output

    def test_exclude_tags_option_in_help(self):
        """Test that --exclude-tags option is documented in help."""
        runner = CliRunner()
        result = runner.invoke(main, ["test", "--help"])

        assert result.exit_code == 0
        assert "--exclude-tags" in result.output


class TestEnvModeOption:
    """Tests for --env-mode option (replacing --docker/--no-docker)."""

    def test_env_mode_help_text(self):
        """Test that --env-mode is documented in help."""
        runner = CliRunner()
        result = runner.invoke(main, ["test", "--help"])

        assert result.exit_code == 0
        assert "--env-mode" in result.output

    def test_env_mode_accepts_auto(self):
        """Test that --env-mode accepts 'auto' value."""
        runner = CliRunner()
        # Using --help to avoid needing a real config
        result = runner.invoke(main, ["test", "--help"])
        assert result.exit_code == 0

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    def test_env_mode_auto_calls_auto_detect(self, mock_get_adapter, mock_detect, mock_load, mock_find, tmp_path):
        """Test that --env-mode auto (default) calls auto_detect_docker."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        mock_config = MagicMock()
        mock_config.adapter = "pytest"
        mock_config.project_root = tmp_path
        mock_config.environments = {}
        mock_config.is_multi_project = False
        mock_config.categories = {}
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.LOCAL_ONLY,
            reason="No Docker available",
        )

        mock_adapter = MagicMock()
        mock_adapter.validate_environment.return_value = True
        mock_adapter.execute.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        # auto_detect_docker should have been called (default 'auto' mode)
        mock_detect.assert_called_once()

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    def test_env_mode_docker_skips_detection(self, mock_get_adapter, mock_detect, mock_load, mock_find, tmp_path):
        """Test that --env-mode docker doesn't call auto_detect_docker."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        mock_config = MagicMock()
        mock_config.adapter = "pytest"
        mock_config.project_root = tmp_path
        mock_config.environments = {}
        mock_config.is_multi_project = False
        mock_config.categories = {}
        mock_load.return_value = mock_config

        mock_adapter = MagicMock()
        mock_adapter.validate_environment.return_value = True
        mock_adapter.execute.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(main, ["test", "--env-mode", "docker"])

        # auto_detect_docker should NOT have been called
        mock_detect.assert_not_called()

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    def test_env_mode_local_skips_detection(self, mock_get_adapter, mock_detect, mock_load, mock_find, tmp_path):
        """Test that --env-mode local doesn't call auto_detect_docker."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        mock_config = MagicMock()
        mock_config.adapter = "pytest"
        mock_config.project_root = tmp_path
        mock_config.environments = {}
        mock_config.is_multi_project = False
        mock_config.categories = {}
        mock_load.return_value = mock_config

        mock_adapter = MagicMock()
        mock_adapter.validate_environment.return_value = True
        mock_adapter.execute.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(main, ["test", "--env-mode", "local"])

        # auto_detect_docker should NOT have been called
        mock_detect.assert_not_called()

    def test_env_mode_invalid_value_rejected(self):
        """Test that invalid --env-mode values are rejected."""
        runner = CliRunner()
        result = runner.invoke(main, ["test", "--env-mode", "invalid"])

        assert result.exit_code != 0
        assert "Invalid value" in result.output or "invalid choice" in result.output.lower()


class TestFindDockerEnvironment:
    """Tests for _find_docker_environment helper."""

    def test_finds_docker_compose_env(self):
        """Test finding a docker-compose environment in config."""
        from systemeval.cli.commands.test_commands import _find_docker_environment

        mock_config = MagicMock()
        env_backend = MagicMock()
        env_backend.type = "docker-compose"
        env_frontend = MagicMock()
        env_frontend.type = "standalone"
        mock_config.environments = {"backend": env_backend, "frontend": env_frontend}

        result = _find_docker_environment(mock_config)
        assert result == "backend"

    def test_returns_none_when_no_docker_env(self):
        """Test returns None when no docker-compose environments exist."""
        from systemeval.cli.commands.test_commands import _find_docker_environment

        mock_config = MagicMock()
        env_standalone = MagicMock()
        env_standalone.type = "standalone"
        mock_config.environments = {"local": env_standalone}

        result = _find_docker_environment(mock_config)
        assert result is None

    def test_returns_none_when_empty_environments(self):
        """Test returns None when environments dict is empty."""
        from systemeval.cli.commands.test_commands import _find_docker_environment

        mock_config = MagicMock()
        mock_config.environments = {}

        result = _find_docker_environment(mock_config)
        assert result is None

    def test_returns_first_docker_env_when_multiple(self):
        """Test returns first docker-compose env when multiple exist."""
        from systemeval.cli.commands.test_commands import _find_docker_environment
        from collections import OrderedDict

        mock_config = MagicMock()
        env_a = MagicMock()
        env_a.type = "docker-compose"
        env_b = MagicMock()
        env_b.type = "docker-compose"
        # Use OrderedDict to ensure consistent ordering
        mock_config.environments = OrderedDict([("alpha", env_a), ("beta", env_b)])

        result = _find_docker_environment(mock_config)
        assert result == "alpha"


class TestInjectAutoDockerEnvironment:
    """Tests for _inject_auto_docker_environment helper."""

    def test_injects_docker_compose_env(self):
        """Test that it injects a docker-compose environment entry."""
        from systemeval.cli.commands.test_commands import _inject_auto_docker_environment
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        mock_config = MagicMock()
        mock_config.environments = {}

        detection = DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=Path("/project/docker-compose.yml"),
            reason="test",
        )
        _inject_auto_docker_environment(mock_config, detection)

        assert "docker" in mock_config.environments
        env = mock_config.environments["docker"]
        assert env.type == "docker-compose"
        assert env.compose_file == "docker-compose.yml"
        assert env.default is True
        assert env.auto_discover is True

    def test_injects_with_no_compose_file(self):
        """Test injection when detection has no compose_file."""
        from systemeval.cli.commands.test_commands import _inject_auto_docker_environment
        from systemeval.utils.docker import DockerDetectionResult, DockerMode

        mock_config = MagicMock()
        mock_config.environments = {}

        detection = DockerDetectionResult(
            mode=DockerMode.BUILD_AND_START,
            compose_file=None,
            reason="test",
        )
        _inject_auto_docker_environment(mock_config, detection)

        assert "docker" in mock_config.environments
        env = mock_config.environments["docker"]
        assert env.compose_file is None

    def test_uses_compose_file_name_only(self):
        """Test that only the filename (not full path) is used."""
        from systemeval.cli.commands.test_commands import _inject_auto_docker_environment
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        mock_config = MagicMock()
        mock_config.environments = {}

        detection = DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=Path("/some/deep/path/local.yml"),
            reason="test",
        )
        _inject_auto_docker_environment(mock_config, detection)

        env = mock_config.environments["docker"]
        assert env.compose_file == "local.yml"


class TestDockerAutoDetectIntegration:
    """Tests for Docker auto-detection integration in _execute_test_command."""

    def _make_mock_config(self, tmp_path, environments=None, categories=None):
        """Create a standard mock config for tests."""
        mock_config = MagicMock()
        mock_config.adapter = "pytest"
        mock_config.project_root = tmp_path
        mock_config.environments = environments or {}
        mock_config.is_multi_project = False
        mock_config.categories = categories or {}
        return mock_config

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    def test_attach_mode_sets_attach_flag(self, mock_get_adapter, mock_detect, mock_load, mock_find, tmp_path):
        """Test that ATTACH detection sets opts.environment.attach = True."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        mock_config = self._make_mock_config(tmp_path)
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=Path("docker-compose.yml"),
            reason="Containers already running",
        )

        mock_adapter = MagicMock()
        mock_adapter.validate_environment.return_value = True
        mock_adapter.execute.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        # Run test - it will use legacy adapter path since no docker env in config
        result = runner.invoke(main, ["test"])

        # Verify auto_detect_docker was called
        mock_detect.assert_called_once()

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands._run_with_environment")
    def test_attach_mode_auto_selects_docker_env(self, mock_run_env, mock_detect, mock_load, mock_find, tmp_path):
        """Test ATTACH mode auto-selects a docker-compose env from config."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        env_backend = MagicMock()
        env_backend.type = "docker-compose"
        mock_config = self._make_mock_config(tmp_path, environments={"backend": env_backend})
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=Path("docker-compose.yml"),
            reason="Containers already running",
        )

        mock_run_env.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        # Should have called _run_with_environment (Docker path)
        mock_run_env.assert_called_once()
        # Check that opts.environment.attach was set
        call_opts = mock_run_env.call_args[1]["opts"]
        assert call_opts.environment.attach is True
        assert call_opts.environment.env_name == "backend"

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands._run_with_environment")
    def test_start_mode_sets_skip_build(self, mock_run_env, mock_detect, mock_load, mock_find, tmp_path):
        """Test START mode sets skip_build and auto-selects Docker env."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        env_backend = MagicMock()
        env_backend.type = "docker-compose"
        mock_config = self._make_mock_config(tmp_path, environments={"backend": env_backend})
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.START,
            compose_file=Path("docker-compose.yml"),
            reason="Containers stopped, will restart",
        )

        mock_run_env.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        mock_run_env.assert_called_once()
        call_opts = mock_run_env.call_args[1]["opts"]
        assert call_opts.pipeline.skip_build is True
        assert call_opts.environment.env_name == "backend"

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands._run_with_environment")
    def test_build_and_start_full_lifecycle(self, mock_run_env, mock_detect, mock_load, mock_find, tmp_path):
        """Test BUILD_AND_START mode triggers full Docker lifecycle."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        env_backend = MagicMock()
        env_backend.type = "docker-compose"
        mock_config = self._make_mock_config(tmp_path, environments={"backend": env_backend})
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.BUILD_AND_START,
            compose_file=Path("docker-compose.yml"),
            reason="No containers found, full build needed",
        )

        mock_run_env.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        mock_run_env.assert_called_once()
        call_opts = mock_run_env.call_args[1]["opts"]
        # Neither attach nor skip_build should be set for full lifecycle
        assert call_opts.environment.attach is False
        assert call_opts.pipeline.skip_build is False
        assert call_opts.environment.env_name == "backend"

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    def test_local_only_uses_adapter_path(self, mock_get_adapter, mock_detect, mock_load, mock_find, tmp_path):
        """Test LOCAL_ONLY mode falls back to legacy adapter path."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        env_backend = MagicMock()
        env_backend.type = "docker-compose"
        mock_config = self._make_mock_config(tmp_path, environments={"backend": env_backend})
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.LOCAL_ONLY,
            reason="Docker not available",
        )

        mock_adapter = MagicMock()
        mock_adapter.validate_environment.return_value = True
        mock_adapter.execute.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        # Should use adapter path, not environment path
        mock_get_adapter.assert_called_once()

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    def test_inside_container_uses_adapter_path(self, mock_get_adapter, mock_detect, mock_load, mock_find, tmp_path):
        """Test INSIDE_CONTAINER mode runs tests locally (already in Docker)."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        mock_config = self._make_mock_config(tmp_path)
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.INSIDE_CONTAINER,
            reason="Running inside Docker container",
        )

        mock_adapter = MagicMock()
        mock_adapter.validate_environment.return_value = True
        mock_adapter.execute.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        # INSIDE_CONTAINER: can_use_docker is False, should use adapter
        mock_get_adapter.assert_called_once()

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands._run_with_environment")
    def test_explicit_env_name_not_overridden(self, mock_run_env, mock_detect, mock_load, mock_find, tmp_path):
        """Test that explicit --env flag is not overridden by auto-detection."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        env_backend = MagicMock()
        env_backend.type = "docker-compose"
        env_frontend = MagicMock()
        env_frontend.type = "standalone"
        mock_config = self._make_mock_config(
            tmp_path,
            environments={"backend": env_backend, "frontend": env_frontend},
        )
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=Path("docker-compose.yml"),
            reason="Containers running",
        )

        mock_run_env.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )

        runner = CliRunner()
        result = runner.invoke(main, ["test", "--env", "frontend"])

        # Explicit --env should be preserved, not overridden to "backend"
        mock_run_env.assert_called_once()
        call_opts = mock_run_env.call_args[1]["opts"]
        assert call_opts.environment.env_name == "frontend"

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands._run_with_environment")
    def test_zero_config_injects_docker_env(self, mock_run_env, mock_detect, mock_load, mock_find, tmp_path):
        """Test zero-config: Docker detected + no docker-compose env → injects one."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        # Only standalone envs, no docker-compose
        env_local = MagicMock()
        env_local.type = "standalone"
        mock_config = self._make_mock_config(tmp_path, environments={"local": env_local})
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=Path("docker-compose.yml"),
            reason="Containers running",
        )

        mock_run_env.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        # Zero-config should inject a docker env and route to Docker path
        mock_run_env.assert_called_once()
        call_opts = mock_run_env.call_args[1]["opts"]
        assert call_opts.environment.env_name == "docker"
        assert call_opts.environment.attach is True
        # Verify env was injected into config
        assert "docker" in mock_config.environments

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands._run_with_environment")
    def test_zero_config_no_envs_at_all(self, mock_run_env, mock_detect, mock_load, mock_find, tmp_path):
        """Test zero-config: Docker detected + empty environments → injects one."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        # No environments at all
        mock_config = self._make_mock_config(tmp_path, environments={})
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.BUILD_AND_START,
            compose_file=Path("local.yml"),
            reason="No containers found",
        )

        mock_run_env.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        # Should inject a docker env
        mock_run_env.assert_called_once()
        call_opts = mock_run_env.call_args[1]["opts"]
        assert call_opts.environment.env_name == "docker"
        assert "docker" in mock_config.environments
        # Verify the injected env has the compose file from detection
        injected = mock_config.environments["docker"]
        assert injected.compose_file == "local.yml"

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    @patch("systemeval.cli.commands.test_commands._run_with_environment")
    def test_zero_config_preserves_existing_docker_env(self, mock_run_env, mock_detect, mock_load, mock_find, tmp_path):
        """Test that zero-config doesn't override an existing docker-compose env."""
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        from pathlib import Path

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        # Has an existing docker-compose env
        env_backend = MagicMock()
        env_backend.type = "docker-compose"
        mock_config = self._make_mock_config(tmp_path, environments={"backend": env_backend})
        mock_load.return_value = mock_config

        mock_detect.return_value = DockerDetectionResult(
            mode=DockerMode.ATTACH,
            compose_file=Path("docker-compose.yml"),
            reason="Containers running",
        )

        mock_run_env.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.1
        )

        runner = CliRunner()
        result = runner.invoke(main, ["test"])

        # Should pick the existing env, NOT inject a new one
        mock_run_env.assert_called_once()
        call_opts = mock_run_env.call_args[1]["opts"]
        assert call_opts.environment.env_name == "backend"
        assert "docker" not in mock_config.environments  # No injection
