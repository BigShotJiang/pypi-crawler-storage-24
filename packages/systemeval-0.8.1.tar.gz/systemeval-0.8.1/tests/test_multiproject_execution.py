"""Tests for multi-project execution, filtering, pre_commands, and aggregated reporting.

Covers beads: systemeval-gq7, systemeval-xza, systemeval-8sq, systemeval-92k, systemeval-ef9
"""
import json
import os
import subprocess
from pathlib import Path
from textwrap import dedent
from unittest.mock import patch, MagicMock, call

import pytest

from systemeval.config import (
    SystemEvalConfig,
    SubprojectConfig,
    SubprojectResult,
    MultiProjectResult,
    load_config,
)
from systemeval.config.multiproject import DefaultsConfig
from systemeval.types.options import (
    TestCommandOptions,
    TestSelectionOptions,
    ExecutionOptions,
    OutputOptions,
    EnvironmentOptions,
    PipelineOptions,
    BrowserOptions,
    MultiProjectOptions,
)


# ── Fixtures (systemeval-92k) ──────────────────────────────────────────


@pytest.fixture
def base_opts():
    """Default TestCommandOptions for multi-project tests."""
    return TestCommandOptions(
        selection=TestSelectionOptions(),
        execution=ExecutionOptions(),
        output=OutputOptions(),
        environment=EnvironmentOptions(),
        pipeline=PipelineOptions(),
        browser_opts=BrowserOptions(),
        multi_project=MultiProjectOptions(),
    )


@pytest.fixture
def sp_backend():
    """Backend subproject using pytest."""
    return SubprojectConfig(
        name="backend",
        path="backend",
        adapter="pytest",
        tags=["unit", "python"],
        env={"DJANGO_SETTINGS_MODULE": "config.settings.test"},
    )


@pytest.fixture
def sp_frontend():
    """Frontend subproject using vitest."""
    return SubprojectConfig(
        name="frontend",
        path="frontend",
        adapter="vitest",
        tags=["unit", "typescript"],
        pre_commands=["npm install"],
    )


@pytest.fixture
def sp_e2e():
    """E2E subproject using playwright."""
    return SubprojectConfig(
        name="e2e",
        path="e2e-tests",
        adapter="playwright",
        tags=["e2e", "browser"],
    )


@pytest.fixture
def sp_disabled():
    """Disabled subproject."""
    return SubprojectConfig(
        name="legacy",
        path="legacy",
        adapter="pytest",
        tags=["deprecated"],
        enabled=False,
    )


@pytest.fixture
def multi_project_config(tmp_path, sp_backend, sp_frontend, sp_e2e, sp_disabled):
    """Create a multi-project SystemEvalConfig."""
    config_file = tmp_path / "systemeval.yaml"
    config_file.write_text(dedent("""
        version: "2.0"

        defaults:
          timeout: 300
          parallel: false

        subprojects:
          - name: backend
            path: backend
            adapter: pytest
            tags: [unit, python]
            env:
              DJANGO_SETTINGS_MODULE: config.settings.test
          - name: frontend
            path: frontend
            adapter: vitest
            tags: [unit, typescript]
            pre_commands:
              - npm install
          - name: e2e
            path: e2e-tests
            adapter: playwright
            tags: [e2e, browser]
          - name: legacy
            path: legacy
            adapter: pytest
            tags: [deprecated]
            enabled: false
    """).strip())

    config = load_config(config_file)
    return config


@pytest.fixture
def passing_sp_result():
    """A passing SubprojectResult."""
    return SubprojectResult(
        name="backend",
        adapter="pytest",
        passed=42,
        failed=0,
        errors=0,
        skipped=3,
        status="PASS",
        duration=5.2,
    )


@pytest.fixture
def failing_sp_result():
    """A failing SubprojectResult."""
    return SubprojectResult(
        name="frontend",
        adapter="vitest",
        passed=18,
        failed=2,
        errors=0,
        skipped=1,
        status="FAIL",
        duration=3.1,
        failures=[
            {"test": "LoginForm.test.ts::renders", "name": "renders", "message": "Expected true"},
        ],
    )


@pytest.fixture
def error_sp_result():
    """An error SubprojectResult."""
    return SubprojectResult(
        name="e2e",
        adapter="playwright",
        status="ERROR",
        error_message="Playwright not installed",
    )


# ── MultiProjectResult aggregation tests (systemeval-8sq) ─────────────


class TestMultiProjectResultAggregation:
    """Test MultiProjectResult.calculate_totals and verdict logic."""

    def test_all_pass_verdict(self, passing_sp_result):
        """All subprojects passing → PASS verdict."""
        result = MultiProjectResult()
        result.subprojects = [
            passing_sp_result,
            SubprojectResult(name="frontend", adapter="vitest", passed=10, status="PASS", duration=2.0),
        ]
        result.calculate_totals()

        assert result.verdict == "PASS"
        assert result.total_passed == 52
        assert result.total_failed == 0

    def test_any_fail_verdict(self, passing_sp_result, failing_sp_result):
        """Any subproject failing → FAIL verdict."""
        result = MultiProjectResult()
        result.subprojects = [passing_sp_result, failing_sp_result]
        result.calculate_totals()

        assert result.verdict == "FAIL"
        assert result.total_passed == 60
        assert result.total_failed == 2

    def test_error_overrides_fail(self, passing_sp_result, failing_sp_result, error_sp_result):
        """ERROR takes priority over FAIL."""
        result = MultiProjectResult()
        result.subprojects = [passing_sp_result, failing_sp_result, error_sp_result]
        result.calculate_totals()

        assert result.verdict == "ERROR"

    def test_duration_summed(self, passing_sp_result, failing_sp_result):
        """Total duration is sum of subproject durations."""
        result = MultiProjectResult()
        result.subprojects = [passing_sp_result, failing_sp_result]
        result.calculate_totals()

        assert result.total_duration == pytest.approx(8.3, abs=0.01)

    def test_empty_subprojects_pass(self):
        """No subprojects → PASS verdict."""
        result = MultiProjectResult()
        result.calculate_totals()

        assert result.verdict == "PASS"
        assert result.total_passed == 0

    def test_skipped_counted(self, passing_sp_result, failing_sp_result):
        """Skipped tests are aggregated."""
        result = MultiProjectResult()
        result.subprojects = [passing_sp_result, failing_sp_result]
        result.calculate_totals()

        assert result.total_skipped == 4  # 3 + 1


class TestMultiProjectResultJson:
    """Test JSON output for CI integration."""

    def test_to_json_dict_structure(self, passing_sp_result, failing_sp_result):
        """JSON output has the expected structure."""
        result = MultiProjectResult()
        result.subprojects = [passing_sp_result, failing_sp_result]
        result.calculate_totals()

        data = result.to_json_dict()

        assert data["verdict"] == "FAIL"
        assert data["total_passed"] == 60
        assert data["total_failed"] == 2
        assert len(data["subprojects"]) == 2
        assert data["subprojects"][0]["name"] == "backend"
        assert data["subprojects"][1]["name"] == "frontend"

    def test_json_serializable(self, passing_sp_result):
        """Result can be serialized to valid JSON."""
        result = MultiProjectResult()
        result.subprojects = [passing_sp_result]
        result.calculate_totals()

        json_str = json.dumps(result.to_json_dict())
        parsed = json.loads(json_str)

        assert parsed["verdict"] == "PASS"

    def test_failure_details_in_json(self, failing_sp_result):
        """Failure details are preserved in JSON output."""
        result = MultiProjectResult()
        result.subprojects = [failing_sp_result]
        result.calculate_totals()

        data = result.to_json_dict()
        sp_data = data["subprojects"][0]

        assert sp_data["failures"] is not None
        assert len(sp_data["failures"]) == 1
        assert "LoginForm" in sp_data["failures"][0]["test"]

    def test_error_message_in_json(self, error_sp_result):
        """Error message is preserved in JSON output."""
        result = MultiProjectResult()
        result.subprojects = [error_sp_result]
        result.calculate_totals()

        data = result.to_json_dict()
        assert data["subprojects"][0]["error_message"] == "Playwright not installed"


# ── Subproject filtering tests (systemeval-gq7) ───────────────────────


class TestSubprojectFiltering:
    """Test --project, --tags, --exclude-tags filtering."""

    def test_get_enabled_excludes_disabled(self, multi_project_config):
        """Disabled subprojects are excluded."""
        enabled = multi_project_config.get_enabled_subprojects()

        names = [sp.name for sp in enabled]
        assert "legacy" not in names
        assert len(enabled) == 3

    def test_filter_by_name(self, multi_project_config):
        """--project flag filters to specific subprojects."""
        result = multi_project_config.get_enabled_subprojects(names=["backend"])

        assert len(result) == 1
        assert result[0].name == "backend"

    def test_filter_by_multiple_names(self, multi_project_config):
        """Multiple --project flags work."""
        result = multi_project_config.get_enabled_subprojects(names=["backend", "e2e"])

        assert len(result) == 2
        names = {sp.name for sp in result}
        assert names == {"backend", "e2e"}

    def test_filter_by_tag(self, multi_project_config):
        """--tags flag filters by tag."""
        result = multi_project_config.get_enabled_subprojects(tags=["unit"])

        assert len(result) == 2
        names = {sp.name for sp in result}
        assert names == {"backend", "frontend"}

    def test_filter_by_tag_e2e(self, multi_project_config):
        """--tags e2e returns only browser tests."""
        result = multi_project_config.get_enabled_subprojects(tags=["e2e"])

        assert len(result) == 1
        assert result[0].name == "e2e"

    def test_filter_by_nonexistent_name(self, multi_project_config):
        """Unknown project name returns empty list."""
        result = multi_project_config.get_enabled_subprojects(names=["nonexistent"])

        assert len(result) == 0

    def test_filter_by_nonexistent_tag(self, multi_project_config):
        """Unknown tag returns empty list."""
        result = multi_project_config.get_enabled_subprojects(tags=["nonexistent"])

        assert len(result) == 0

    def test_disabled_excluded_even_with_matching_name(self, multi_project_config):
        """Disabled subprojects are excluded even if name matches."""
        result = multi_project_config.get_enabled_subprojects(names=["legacy"])

        assert len(result) == 0


class TestExcludeTagsFiltering:
    """Test --exclude-tags filtering (applied in run_multi_project_tests)."""

    def test_exclude_tags_removes_matching(self, multi_project_config):
        """Exclude tags removes subprojects with matching tags."""
        enabled = multi_project_config.get_enabled_subprojects()
        exclude_tags = ["e2e"]
        filtered = [sp for sp in enabled if not any(tag in sp.tags for tag in exclude_tags)]

        names = {sp.name for sp in filtered}
        assert "e2e" not in names
        assert len(filtered) == 2

    def test_exclude_tags_multiple(self, multi_project_config):
        """Multiple exclude tags remove all matching subprojects."""
        enabled = multi_project_config.get_enabled_subprojects()
        exclude_tags = ["e2e", "python"]
        filtered = [sp for sp in enabled if not any(tag in sp.tags for tag in exclude_tags)]

        names = {sp.name for sp in filtered}
        assert names == {"frontend"}


# ── Pre-commands execution tests (systemeval-xza) ─────────────────────


class TestPreCommandsExecution:
    """Test that pre_commands run before subproject tests."""

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    @patch("systemeval.cli.execution.multiproject.subprocess.run")
    def test_pre_commands_run_before_tests(self, mock_subprocess, mock_get_adapter, tmp_path, base_opts):
        """pre_commands execute before adapter.execute()."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "frontend"
        sp_path.mkdir()

        mock_adapter = MagicMock()
        from systemeval.adapters import TestResult
        mock_adapter.execute.return_value = TestResult(passed=5, failed=0, errors=0, skipped=0, duration=1.0)
        mock_get_adapter.return_value = mock_adapter

        sp = SubprojectConfig(
            name="frontend",
            path="frontend",
            adapter="vitest",
            pre_commands=["npm install", "npm run build"],
        )

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        # Patch get_subproject_absolute_path to return sp_path
        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            result = run_single_subproject(root_config, sp, base_opts)

        # pre_commands should run in order
        assert mock_subprocess.call_count == 2
        assert mock_subprocess.call_args_list[0][0] == ("npm install",)
        assert mock_subprocess.call_args_list[1][0] == ("npm run build",)

        # Tests should also run
        mock_adapter.execute.assert_called_once()
        assert result.status == "PASS"

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    @patch("systemeval.cli.execution.multiproject.subprocess.run")
    def test_pre_command_failure_returns_error(self, mock_subprocess, mock_get_adapter, tmp_path, base_opts):
        """Failed pre_command returns ERROR status without running tests."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "frontend"
        sp_path.mkdir()

        mock_subprocess.side_effect = subprocess.CalledProcessError(1, "npm install")

        sp = SubprojectConfig(
            name="frontend",
            path="frontend",
            adapter="vitest",
            pre_commands=["npm install"],
        )

        root_config = MagicMock()
        root_config.project_root = tmp_path

        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            result = run_single_subproject(root_config, sp, base_opts)

        assert result.status == "ERROR"
        assert "Pre-command failed" in result.error_message
        # Adapter should NOT be called if pre_command fails
        mock_get_adapter.assert_not_called()

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    @patch("systemeval.cli.execution.multiproject.subprocess.run")
    def test_pre_commands_run_in_subproject_dir(self, mock_subprocess, mock_get_adapter, tmp_path, base_opts):
        """pre_commands run in the subproject directory."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "backend"
        sp_path.mkdir()

        mock_adapter = MagicMock()
        from systemeval.adapters import TestResult
        mock_adapter.execute.return_value = TestResult(passed=1, failed=0, errors=0, skipped=0, duration=0.1)
        mock_get_adapter.return_value = mock_adapter

        sp = SubprojectConfig(
            name="backend",
            path="backend",
            adapter="pytest",
            pre_commands=["pip install -e ."],
        )

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            run_single_subproject(root_config, sp, base_opts)

        # cwd should be subproject path
        call_kwargs = mock_subprocess.call_args_list[0][1]
        assert call_kwargs["cwd"] == str(sp_path)

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    @patch("systemeval.cli.execution.multiproject.subprocess.run")
    def test_pre_commands_env_vars_passed(self, mock_subprocess, mock_get_adapter, tmp_path, base_opts):
        """pre_commands receive subproject env vars."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "backend"
        sp_path.mkdir()

        mock_adapter = MagicMock()
        from systemeval.adapters import TestResult
        mock_adapter.execute.return_value = TestResult(passed=1, failed=0, errors=0, skipped=0, duration=0.1)
        mock_get_adapter.return_value = mock_adapter

        sp = SubprojectConfig(
            name="backend",
            path="backend",
            adapter="pytest",
            pre_commands=["echo test"],
            env={"MY_VAR": "my_value"},
        )

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            run_single_subproject(root_config, sp, base_opts)

        call_kwargs = mock_subprocess.call_args_list[0][1]
        assert call_kwargs["env"]["MY_VAR"] == "my_value"

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    def test_no_pre_commands_skips_subprocess(self, mock_get_adapter, tmp_path, base_opts):
        """When no pre_commands, subprocess.run is not called."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "backend"
        sp_path.mkdir()

        mock_adapter = MagicMock()
        from systemeval.adapters import TestResult
        mock_adapter.execute.return_value = TestResult(passed=1, failed=0, errors=0, skipped=0, duration=0.1)
        mock_get_adapter.return_value = mock_adapter

        sp = SubprojectConfig(
            name="backend",
            path="backend",
            adapter="pytest",
        )

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            with patch("systemeval.cli.execution.multiproject.subprocess.run") as mock_sub:
                run_single_subproject(root_config, sp, base_opts)
                mock_sub.assert_not_called()


# ── run_single_subproject integration tests (systemeval-ef9) ──────────


class TestRunSingleSubproject:
    """Test run_single_subproject handles various scenarios."""

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    def test_missing_path_returns_error(self, mock_get_adapter, tmp_path, base_opts):
        """Nonexistent subproject path returns ERROR."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp = SubprojectConfig(name="missing", path="nonexistent", adapter="pytest")

        root_config = MagicMock()
        root_config.project_root = tmp_path

        with patch(
            "systemeval.cli.execution.multiproject.get_subproject_absolute_path",
            return_value=tmp_path / "nonexistent",
        ):
            result = run_single_subproject(root_config, sp, base_opts)

        assert result.status == "ERROR"
        assert "not found" in result.error_message
        mock_get_adapter.assert_not_called()

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    def test_adapter_error_returns_error(self, mock_get_adapter, tmp_path, base_opts):
        """Adapter instantiation failure returns ERROR."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "backend"
        sp_path.mkdir()

        mock_get_adapter.side_effect = KeyError("Unknown adapter: custom")

        sp = SubprojectConfig(name="backend", path="backend", adapter="custom")

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            result = run_single_subproject(root_config, sp, base_opts)

        assert result.status == "ERROR"
        assert "Adapter error" in result.error_message

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    def test_test_execution_exception_returns_error(self, mock_get_adapter, tmp_path, base_opts):
        """Runtime exception during test execution returns ERROR."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "backend"
        sp_path.mkdir()

        mock_adapter = MagicMock()
        mock_adapter.execute.side_effect = RuntimeError("Container crashed")
        mock_get_adapter.return_value = mock_adapter

        sp = SubprojectConfig(name="backend", path="backend", adapter="pytest")

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            result = run_single_subproject(root_config, sp, base_opts)

        assert result.status == "ERROR"
        assert "Container crashed" in result.error_message

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    def test_env_vars_set_and_restored(self, mock_get_adapter, tmp_path, base_opts):
        """Environment variables are set during tests and restored after."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "backend"
        sp_path.mkdir()

        # Track env state during test execution
        captured_env = {}

        def capture_env(*args, **kwargs):
            captured_env["DJANGO_SETTINGS_MODULE"] = os.environ.get("DJANGO_SETTINGS_MODULE")
            from systemeval.adapters import TestResult
            return TestResult(passed=1, failed=0, errors=0, skipped=0, duration=0.1)

        mock_adapter = MagicMock()
        mock_adapter.execute.side_effect = capture_env
        mock_get_adapter.return_value = mock_adapter

        sp = SubprojectConfig(
            name="backend",
            path="backend",
            adapter="pytest",
            env={"DJANGO_SETTINGS_MODULE": "config.settings.test"},
        )

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        # Ensure env var doesn't exist before
        original = os.environ.pop("DJANGO_SETTINGS_MODULE", None)

        try:
            with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
                run_single_subproject(root_config, sp, base_opts)

            # During execution, env var should have been set
            assert captured_env["DJANGO_SETTINGS_MODULE"] == "config.settings.test"

            # After execution, env var should be cleaned up
            assert os.environ.get("DJANGO_SETTINGS_MODULE") is None
        finally:
            if original is not None:
                os.environ["DJANGO_SETTINGS_MODULE"] = original

    @patch("systemeval.cli.execution.multiproject.get_adapter")
    def test_passing_test_result_converted(self, mock_get_adapter, tmp_path, base_opts):
        """Passing TestResult is correctly converted to SubprojectResult."""
        from systemeval.cli.execution.multiproject import run_single_subproject

        sp_path = tmp_path / "backend"
        sp_path.mkdir()

        from systemeval.adapters import TestResult
        mock_adapter = MagicMock()
        mock_adapter.execute.return_value = TestResult(
            passed=10, failed=0, errors=0, skipped=2, duration=3.5
        )
        mock_get_adapter.return_value = mock_adapter

        sp = SubprojectConfig(name="backend", path="backend", adapter="pytest")

        root_config = MagicMock()
        root_config.project_root = tmp_path
        root_config.get_effective_timeout.return_value = 300

        with patch("systemeval.cli.execution.multiproject.get_subproject_absolute_path", return_value=sp_path):
            result = run_single_subproject(root_config, sp, base_opts)

        assert result.name == "backend"
        assert result.adapter == "pytest"
        assert result.passed == 10
        assert result.skipped == 2
        assert result.status == "PASS"


# ── run_multi_project_tests integration tests (systemeval-ef9) ────────


class TestRunMultiProjectTests:
    """Test the top-level run_multi_project_tests orchestrator."""

    @patch("systemeval.cli.execution.multiproject.run_single_subproject")
    def test_runs_all_enabled_subprojects(self, mock_run_single, multi_project_config, base_opts):
        """All enabled subprojects are executed."""
        from systemeval.cli_helpers import run_multi_project_tests

        mock_run_single.return_value = SubprojectResult(
            name="test", adapter="pytest", passed=5, status="PASS", duration=1.0,
        )

        result = run_multi_project_tests(multi_project_config, base_opts)

        # 3 enabled subprojects (legacy is disabled)
        assert mock_run_single.call_count == 3
        assert len(result.subprojects) == 3

    @patch("systemeval.cli.execution.multiproject.run_single_subproject")
    def test_project_filter(self, mock_run_single, multi_project_config, base_opts):
        """--project flag filters to specific subprojects."""
        from systemeval.cli_helpers import run_multi_project_tests

        base_opts.multi_project = MultiProjectOptions(subprojects=("backend",))
        mock_run_single.return_value = SubprojectResult(
            name="backend", adapter="pytest", passed=5, status="PASS", duration=1.0,
        )

        result = run_multi_project_tests(multi_project_config, base_opts)

        assert mock_run_single.call_count == 1
        assert len(result.subprojects) == 1

    @patch("systemeval.cli.execution.multiproject.run_single_subproject")
    def test_tags_filter(self, mock_run_single, multi_project_config, base_opts):
        """--tags flag filters to subprojects with matching tags."""
        from systemeval.cli_helpers import run_multi_project_tests

        base_opts.multi_project = MultiProjectOptions(tags=("unit",))
        mock_run_single.return_value = SubprojectResult(
            name="test", adapter="pytest", passed=5, status="PASS", duration=1.0,
        )

        result = run_multi_project_tests(multi_project_config, base_opts)

        # backend and frontend have "unit" tag
        assert mock_run_single.call_count == 2

    @patch("systemeval.cli.execution.multiproject.run_single_subproject")
    def test_exclude_tags_filter(self, mock_run_single, multi_project_config, base_opts):
        """--exclude-tags flag removes matching subprojects."""
        from systemeval.cli_helpers import run_multi_project_tests

        base_opts.multi_project = MultiProjectOptions(exclude_tags=("e2e",))
        mock_run_single.return_value = SubprojectResult(
            name="test", adapter="pytest", passed=5, status="PASS", duration=1.0,
        )

        result = run_multi_project_tests(multi_project_config, base_opts)

        # e2e subproject is excluded, 2 remain
        assert mock_run_single.call_count == 2

    @patch("systemeval.cli.execution.multiproject.run_single_subproject")
    def test_no_matching_subprojects_returns_pass(self, mock_run_single, multi_project_config, base_opts):
        """No matching subprojects returns PASS with empty results."""
        from systemeval.cli_helpers import run_multi_project_tests

        base_opts.multi_project = MultiProjectOptions(subprojects=("nonexistent",))

        result = run_multi_project_tests(multi_project_config, base_opts)

        mock_run_single.assert_not_called()
        assert result.verdict == "PASS"
        assert len(result.subprojects) == 0

    @patch("systemeval.cli.execution.multiproject.run_single_subproject")
    def test_totals_calculated(self, mock_run_single, multi_project_config, base_opts):
        """calculate_totals is called after all subprojects run."""
        from systemeval.cli_helpers import run_multi_project_tests

        mock_run_single.side_effect = [
            SubprojectResult(name="backend", adapter="pytest", passed=10, failed=1, status="FAIL", duration=2.0),
            SubprojectResult(name="frontend", adapter="vitest", passed=5, failed=0, status="PASS", duration=1.0),
            SubprojectResult(name="e2e", adapter="playwright", passed=3, failed=0, status="PASS", duration=4.0),
        ]

        result = run_multi_project_tests(multi_project_config, base_opts)

        assert result.total_passed == 18
        assert result.total_failed == 1
        assert result.verdict == "FAIL"
        assert result.total_duration == pytest.approx(7.0, abs=0.01)


# ── CLI integration tests for multi-project flags (systemeval-gq7) ────


class TestMultiProjectCLIFlags:
    """Test that --project, --tags, --exclude-tags CLI flags reach the executor."""

    @patch("systemeval.cli.commands.test_commands.run_multi_project_tests")
    @patch("systemeval.cli.commands.test_commands.output_multi_project_results")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.find_config_file")
    def test_project_flag_passes_to_opts(
        self, mock_find, mock_load, mock_output, mock_run, tmp_path
    ):
        """--project flag is captured and passed to run_multi_project_tests."""
        from click.testing import CliRunner
        from systemeval.cli.commands.test_commands import test as test_cmd

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("version: '2.0'\nsubprojects: []")
        mock_find.return_value = config_file

        mock_config = MagicMock()
        mock_config.is_multi_project = True
        mock_load.return_value = mock_config

        mock_result = MagicMock()
        mock_result.verdict = "PASS"
        mock_run.return_value = mock_result

        runner = CliRunner()
        result = runner.invoke(test_cmd, ["--project", "backend", "--project", "frontend"])

        # Verify opts.multi_project.subprojects was set
        call_args = mock_run.call_args
        opts = call_args[1]["opts"] if "opts" in call_args[1] else call_args[0][1]
        assert "backend" in opts.multi_project.subprojects
        assert "frontend" in opts.multi_project.subprojects

    @patch("systemeval.cli.commands.test_commands.run_multi_project_tests")
    @patch("systemeval.cli.commands.test_commands.output_multi_project_results")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.find_config_file")
    def test_tags_flag_passes_to_opts(
        self, mock_find, mock_load, mock_output, mock_run, tmp_path
    ):
        """--tags flag is captured and passed to run_multi_project_tests."""
        from click.testing import CliRunner
        from systemeval.cli.commands.test_commands import test as test_cmd

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("version: '2.0'\nsubprojects: []")
        mock_find.return_value = config_file

        mock_config = MagicMock()
        mock_config.is_multi_project = True
        mock_load.return_value = mock_config

        mock_result = MagicMock()
        mock_result.verdict = "PASS"
        mock_run.return_value = mock_result

        runner = CliRunner()
        result = runner.invoke(test_cmd, ["--tags", "unit"])

        call_args = mock_run.call_args
        opts = call_args[1]["opts"] if "opts" in call_args[1] else call_args[0][1]
        assert "unit" in opts.multi_project.tags

    @patch("systemeval.cli.commands.test_commands.run_multi_project_tests")
    @patch("systemeval.cli.commands.test_commands.output_multi_project_results")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.find_config_file")
    def test_exclude_tags_flag_passes_to_opts(
        self, mock_find, mock_load, mock_output, mock_run, tmp_path
    ):
        """--exclude-tags flag is captured and passed to run_multi_project_tests."""
        from click.testing import CliRunner
        from systemeval.cli.commands.test_commands import test as test_cmd

        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("version: '2.0'\nsubprojects: []")
        mock_find.return_value = config_file

        mock_config = MagicMock()
        mock_config.is_multi_project = True
        mock_load.return_value = mock_config

        mock_result = MagicMock()
        mock_result.verdict = "PASS"
        mock_run.return_value = mock_result

        runner = CliRunner()
        result = runner.invoke(test_cmd, ["--exclude-tags", "e2e"])

        call_args = mock_run.call_args
        opts = call_args[1]["opts"] if "opts" in call_args[1] else call_args[0][1]
        assert "e2e" in opts.multi_project.exclude_tags


# ── Aggregated reporting output tests (systemeval-8sq) ────────────────


class TestAggregatedReportingOutput:
    """Test that multi-project results render correctly."""

    def test_display_multi_project_table(self, passing_sp_result, failing_sp_result, capsys):
        """display_multi_project_table renders without error."""
        from systemeval.cli.execution.multiproject import display_multi_project_table

        result = MultiProjectResult()
        result.subprojects = [passing_sp_result, failing_sp_result]
        result.calculate_totals()

        # Should not raise
        display_multi_project_table(result)

    def test_json_output_mode(self, passing_sp_result, base_opts, capsys):
        """JSON output mode renders valid JSON."""
        from systemeval.cli.execution.multiproject import output_multi_project_results

        base_opts.output.json_output = True

        result = MultiProjectResult()
        result.subprojects = [passing_sp_result]
        result.calculate_totals()

        # Should not raise
        output_multi_project_results(result, base_opts)
