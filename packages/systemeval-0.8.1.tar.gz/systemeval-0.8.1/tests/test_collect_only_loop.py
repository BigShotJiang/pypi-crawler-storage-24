"""
Tests for the infinite pytest --collect-only loop bug (sentinal-62nbm).

Root Cause Analysis:
====================
When 'systemeval test -c browser' is run, the following chain of events can
lead to repeated 'pytest --collect-only' invocations inside Docker:

1. PytestAdapter.discover() calls pytest.main(["--collect-only", ...]) with
   NO timeout or termination guard. If the Django project requires database
   access during collection (e.g. via conftest fixtures, model imports, or
   the --create-db flag in addopts), and the database isn't available or is
   slow, pytest.main() can hang indefinitely.

2. The _run_legacy_adapter_tests path in test_commands.py calls discover()
   first, then execute(). If discover() returns an empty list (due to
   collection errors), execute() falls through to running ALL tests
   (ignoring the category filter) because empty list is falsy.

3. There is an environment selection mismatch: auto_detect_docker() sets
   opts.environment.env_name='docker' when it finds running containers.
   This prevents the category-specific environment (e.g., 'docker-browser')
   from being applied at line 355. The result is that the wrong Docker
   environment may be used, or in edge cases, the legacy adapter path
   can be triggered.

4. PytestAdapter.discover() calls pytest.main() in-process, which
   conflicts with pytest's global state. Calling pytest.main() multiple
   times (once for discover, once for execute) can cause unstable behavior
   including plugins being re-registered, conftest hooks firing multiple
   times, or Django.setup() being called twice.

The test file below validates these specific failure modes.
"""

import os
import tempfile
import threading
import time
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from systemeval.adapters import PytestAdapter
from systemeval.adapters.python.pytest_adapter import PytestCollectPlugin
from systemeval.types.adapters import AdapterConfig
from systemeval.adapters.base import TestItem, TestResult


@pytest.fixture(autouse=True)
def preserve_cwd():
    """Preserve the current working directory across all tests.

    PytestAdapter.discover() and execute() change the working directory
    via working_directory() context manager. If a test uses a temp dir
    that gets deleted before the cwd is restored, subsequent tests fail
    with 'No such file or directory' from os.getcwd().
    """
    original = os.getcwd()
    yield
    try:
        os.getcwd()
    except (FileNotFoundError, OSError):
        os.chdir(original)


# =============================================================================
# Test: discover() has no timeout guard
# =============================================================================


class TestDiscoverNoTimeout:
    """Prove that PytestAdapter.discover() can hang indefinitely.

    The bug: discover() calls pytest.main() with no timeout. If pytest
    collection hangs (e.g., waiting for database), the process blocks
    forever, leading to accumulated zombie processes.
    """

    def test_discover_has_no_timeout_parameter(self):
        """Verify that discover() accepts no timeout argument.

        This proves the API has no mechanism to limit collection time.
        A well-behaved discover() should accept a timeout parameter.
        """
        import inspect
        sig = inspect.signature(PytestAdapter.discover)
        param_names = list(sig.parameters.keys())

        # discover() should have a timeout parameter but doesn't
        assert "timeout" not in param_names, (
            "discover() now has a timeout parameter - the bug may be fixed. "
            "Update this test."
        )

    def test_discover_blocks_on_slow_collection(self):
        """Prove that discover() blocks when collection is slow.

        Simulates a project where conftest.py sleeps during collection,
        mimicking a Django project waiting for database connection.
        The discover() call should time out, but it doesn't have a timeout.

        This test uses a thread with a hard time limit to avoid actually
        blocking the test suite.
        """
        unique_id = uuid.uuid4().hex[:8]

        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            (project_path / "pyproject.toml").write_text(
                '[tool.pytest.ini_options]\ntestpaths = ["tests"]\n'
            )
            tests_dir = project_path / "tests"
            tests_dir.mkdir()

            # conftest that sleeps for 10 seconds during import
            # This simulates Django DB connection timeout or import hang
            (tests_dir / "conftest.py").write_text(
                "import time\n"
                "time.sleep(10)  # Simulate slow Django setup\n"
            )

            (tests_dir / f"test_basic_{unique_id}.py").write_text(
                "def test_pass(): assert True\n"
            )

            adapter = PytestAdapter(
                AdapterConfig(project_root=str(project_path))
            )

            # Run discover() in a thread with a strict 3-second deadline
            result_holder = {"completed": False, "tests": None}

            def run_discover():
                try:
                    tests = adapter.discover()
                    result_holder["completed"] = True
                    result_holder["tests"] = tests
                except Exception:
                    result_holder["completed"] = True

            thread = threading.Thread(target=run_discover, daemon=True)
            thread.start()
            thread.join(timeout=3.0)

            # The discover() call should NOT have completed in 3 seconds
            # because the conftest sleeps for 10 seconds, and discover()
            # has no timeout mechanism to abort early.
            if not result_holder["completed"]:
                # This is the bug: discover() is still blocked
                assert True, (
                    "CONFIRMED: discover() blocked for >3s with no timeout. "
                    "This is the root cause of zombie process accumulation."
                )
            else:
                # If it completed, the sleep was somehow skipped
                pytest.skip(
                    "discover() completed quickly - conftest may not be "
                    "loaded during --collect-only in this pytest version"
                )


# =============================================================================
# Test: discover() returns empty list silently on collection failure
# =============================================================================


class TestDiscoverSilentFailure:
    """Prove that discover() silently returns empty on collection errors.

    When pytest collection fails (import errors, missing deps), discover()
    returns an empty list instead of raising. This causes execute() to
    ignore the category filter and run ALL tests.
    """

    def test_discover_returns_empty_on_import_error(self):
        """Verify discover() returns [] when test files have import errors."""
        unique_id = uuid.uuid4().hex[:8]

        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            (project_path / "pyproject.toml").write_text(
                '[tool.pytest.ini_options]\ntestpaths = ["tests"]\n'
            )
            tests_dir = project_path / "tests"
            tests_dir.mkdir()
            (tests_dir / "conftest.py").write_text("")

            # Test file with import that will fail
            (tests_dir / f"test_broken_{unique_id}.py").write_text(
                "import this_module_does_not_exist_at_all\n"
                "\n"
                "def test_browser_thing(): pass\n"
            )

            adapter = PytestAdapter(
                AdapterConfig(project_root=str(project_path))
            )

            # discover() should return empty list or raise - not silently succeed
            tests = adapter.discover(category="browser")

            # Bug: returns empty list, no error raised
            assert tests == [], (
                "discover() returned tests despite import errors"
            )
            # The problem: empty list means execute() will ignore the
            # category filter and run everything

    def test_empty_discover_causes_execute_to_ignore_category(self):
        """Prove that when discover() returns [], execute() runs ALL tests.

        This is the mechanism by which the wrong tests get executed:
        1. discover(category='browser') returns [] due to collection error
        2. execute(tests=[]) sees falsy value
        3. execute() falls through to 'else: args.append(self.project_root)'
        4. ALL tests are executed, ignoring the category filter
        """
        unique_id = uuid.uuid4().hex[:8]

        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            (project_path / "pyproject.toml").write_text(
                '[tool.pytest.ini_options]\n'
                'testpaths = ["tests"]\n'
                'markers = [\n'
                '    "browser: browser tests",\n'
                '    "unit: unit tests",\n'
                ']\n'
            )
            tests_dir = project_path / "tests"
            tests_dir.mkdir()
            (tests_dir / "conftest.py").write_text("")

            # Unit test (should NOT run when category='browser')
            (tests_dir / f"test_unit_{unique_id}.py").write_text(
                "import pytest\n"
                "\n"
                "@pytest.mark.unit\n"
                "def test_unit_thing(): assert True\n"
            )

            # Browser test
            (tests_dir / f"test_browser_{unique_id}.py").write_text(
                "import pytest\n"
                "\n"
                "@pytest.mark.browser\n"
                "def test_browser_thing(): assert True\n"
            )

            adapter = PytestAdapter(
                AdapterConfig(project_root=str(project_path))
            )

            # Simulate the legacy adapter path:
            # 1. discover returns empty (simulating collection error)
            tests_to_run = []  # Empty list from failed discover()

            # 2. execute with empty tests list
            result = adapter.execute(tests=tests_to_run)

            # Bug: empty list is falsy, so execute() runs ALL tests
            # instead of just browser-marked tests
            assert result.passed >= 2, (
                f"Expected 2+ tests to run (both unit AND browser), "
                f"got {result.passed} passed. "
                "This proves empty discover causes execute to ignore category."
            )


# =============================================================================
# Test: Environment mismatch in auto-detect Docker flow
# =============================================================================


class TestEnvironmentMismatch:
    """Prove the environment selection bug that can cause wrong code path.

    When auto_detect_docker() finds running containers, it sets
    opts.environment.env_name='docker' (the first docker-compose env).
    This prevents the category-specific environment (e.g., 'docker-browser')
    from being applied, because the check at line 355:
        if category_needs_docker and not opts.environment.env_name
    evaluates to False when env_name is already set.
    """

    def test_auto_detect_overrides_category_environment(self):
        """Prove auto-detect sets env_name before category check can run."""
        from systemeval.config.adapters import TestCategory

        # Simulate the config with environments
        categories = {
            "browser": TestCategory(
                markers=["browser"],
                description="Browser tests",
                environment="docker-browser",
            ),
        }

        # Simulate auto-detect setting env_name
        env_name = "docker"  # Set by auto_detect_docker (line 312-316)
        category = "browser"

        # This is the check from test_commands.py line 340-345
        category_needs_docker = False
        category_env_name = None

        cat_config = categories.get(category)
        if cat_config and cat_config.environment:
            category_needs_docker = True
            category_env_name = cat_config.environment

        assert category_needs_docker is True
        assert category_env_name == "docker-browser"

        # This is the check from test_commands.py line 355
        # The bug: env_name was already set by auto-detect,
        # so this condition is False
        should_use_category_env = category_needs_docker and not env_name

        assert should_use_category_env is False, (
            "Expected False because env_name is already set by auto-detect"
        )

        # Result: 'docker' environment is used instead of 'docker-browser'
        effective_env = env_name
        assert effective_env == "docker"
        assert effective_env != category_env_name, (
            "Environment mismatch: category wants 'docker-browser' "
            f"but auto-detect forced '{effective_env}'"
        )


# =============================================================================
# Test: Multiple pytest.main() calls cause state pollution
# =============================================================================


class TestPytestMainStatePollution:
    """Prove that calling pytest.main() twice causes issues.

    The legacy adapter path calls:
    1. adapter.discover() -> pytest.main(["--collect-only", ...])
    2. adapter.execute()  -> pytest.main(["-v", ...])

    Calling pytest.main() multiple times in the same process is
    documented as potentially unstable due to global state pollution.
    """

    def test_discover_then_execute_invokes_pytest_main_twice(self):
        """Verify that discover+execute makes two pytest.main calls."""
        unique_id = uuid.uuid4().hex[:8]

        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            (project_path / "pyproject.toml").write_text(
                '[tool.pytest.ini_options]\n'
                'testpaths = ["tests"]\n'
                'markers = ["unit: unit tests"]\n'
            )
            tests_dir = project_path / "tests"
            tests_dir.mkdir()
            (tests_dir / "conftest.py").write_text("")
            (tests_dir / f"test_simple_{unique_id}.py").write_text(
                "import pytest\n"
                "@pytest.mark.unit\n"
                "def test_pass(): assert True\n"
            )

            adapter = PytestAdapter(
                AdapterConfig(project_root=str(project_path))
            )

            # Call 1: discover (runs pytest.main with --collect-only)
            tests = adapter.discover(category="unit")

            # Call 2: execute (runs pytest.main with -v)
            result = adapter.execute(tests=tests)

            # Both calls succeeded, proving pytest.main is called twice
            assert result.passed >= 1, (
                "Execute should work after discover"
            )
            # The risk: in Django projects, conftest hooks fire twice,
            # Django.setup() may be called twice, and plugin state can leak

    def test_discover_does_not_check_pytest_exit_code(self):
        """Prove that discover() ignores pytest.main() return value.

        If pytest.main() returns a non-zero exit code (collection error),
        discover() still processes the (empty) items list without error.
        """
        unique_id = uuid.uuid4().hex[:8]

        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            (project_path / "pyproject.toml").write_text(
                '[tool.pytest.ini_options]\ntestpaths = ["tests"]\n'
            )
            tests_dir = project_path / "tests"
            tests_dir.mkdir()
            (tests_dir / "conftest.py").write_text("")

            # Create a test file that will cause collection error
            (tests_dir / f"test_error_{unique_id}.py").write_text(
                "raise RuntimeError('Collection bomb')\n"
            )

            adapter = PytestAdapter(
                AdapterConfig(project_root=str(project_path))
            )

            # discover() should handle the error but doesn't check exit code
            tests = adapter.discover()

            # Bug: returns empty list with no indication of error
            assert isinstance(tests, list)
            # There's no way for the caller to know collection failed


# =============================================================================
# Test: build_test_command produces correct command for Docker path
# =============================================================================


class TestBuildTestCommand:
    """Verify the Docker path builds correct commands."""

    def test_build_test_command_no_collect_only(self):
        """Verify build_test_command never produces --collect-only."""
        from systemeval.utils.commands import build_test_command

        test_cases = [
            ("pytest", None, "browser", False),
            ("pytest", None, "unit", True),
            ("pytest", "e2e", None, False),
            ("pytest", None, None, False),
        ]

        for base_cmd, suite, category, verbose in test_cases:
            cmd = build_test_command(base_cmd, suite, category, verbose)
            assert "--collect-only" not in cmd, (
                f"build_test_command({base_cmd}, {suite}, {category}, "
                f"{verbose}) produced --collect-only: {cmd}"
            )

    def test_build_test_command_applies_category_marker(self):
        """Verify category is applied as -m flag."""
        from systemeval.utils.commands import build_test_command

        cmd = build_test_command("pytest", None, "browser", False)

        assert "-m browser" in cmd
        assert "browser" in cmd


# =============================================================================
# Test: Docker executor sends single command (no collect-only)
# =============================================================================


class TestDockerExecutorNoCollectLoop:
    """Verify the Docker path sends exactly one command."""

    def test_docker_run_tests_single_execution(self):
        """Verify run_tests makes exactly one executor.execute call."""
        from systemeval.environments.implementations.docker_compose import (
            DockerComposeEnvironment,
        )

        config = {
            "type": "docker-compose",
            "compose_file": "local.yml",
            "test_service": "django",
            "test_command": "pytest",
            "working_dir": "/app",
            "auto_discover": False,
        }

        env = DockerComposeEnvironment("test", config)
        env._is_up = True

        mock_result = MagicMock()
        mock_result.stdout = "1 passed in 0.5s"
        mock_result.exit_code = 0

        with patch(
            "systemeval.environments.implementations.docker_compose.DockerExecutor"
        ) as MockExecutor:
            mock_executor = MagicMock()
            mock_executor.execute.return_value = mock_result
            mock_executor.parse_test_results.return_value = TestResult(
                passed=1, failed=0, errors=0, skipped=0,
                duration=0.5, exit_code=0,
            )
            MockExecutor.return_value = mock_executor

            env.run_tests(category="browser")

            # Should have exactly ONE execute call
            assert mock_executor.execute.call_count == 1, (
                f"Expected 1 execute call, got "
                f"{mock_executor.execute.call_count}. "
                "Multiple calls would indicate a loop."
            )

            # The command should NOT contain --collect-only
            execute_args = mock_executor.execute.call_args
            command = execute_args[1].get("command", "")
            assert "--collect-only" not in str(command), (
                f"Docker path should NOT use --collect-only: {command}"
            )

    def test_docker_run_tests_no_retry_on_failure(self):
        """Verify run_tests does NOT retry on test failure."""
        from systemeval.environments.implementations.docker_compose import (
            DockerComposeEnvironment,
        )

        config = {
            "type": "docker-compose",
            "compose_file": "local.yml",
            "test_service": "django",
            "test_command": "pytest",
            "working_dir": "/app",
            "auto_discover": False,
        }

        env = DockerComposeEnvironment("test", config)
        env._is_up = True

        mock_result = MagicMock()
        mock_result.stdout = "ERRORS during collection"
        mock_result.exit_code = 2

        with patch(
            "systemeval.environments.implementations.docker_compose.DockerExecutor"
        ) as MockExecutor:
            mock_executor = MagicMock()
            mock_executor.execute.return_value = mock_result
            mock_executor.parse_test_results.return_value = TestResult(
                passed=0, failed=0, errors=1, skipped=0,
                duration=0.0, exit_code=2,
            )
            MockExecutor.return_value = mock_executor

            result = env.run_tests(category="browser")

            # Should still be exactly ONE execute call (no retry)
            assert mock_executor.execute.call_count == 1, (
                f"Expected 1 execute call even on failure, got "
                f"{mock_executor.execute.call_count}"
            )

            assert result.errors >= 1 or result.exit_code != 0


# =============================================================================
# Test: Legacy adapter path discover+execute interaction
# =============================================================================


class TestLegacyAdapterPathInteraction:
    """Reproduce the exact flow of _run_legacy_adapter_tests."""

    def test_legacy_path_discover_then_execute(self):
        """Simulate _run_legacy_adapter_tests flow end-to-end."""
        unique_id = uuid.uuid4().hex[:8]

        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            (project_path / "pyproject.toml").write_text(
                '[tool.pytest.ini_options]\n'
                'testpaths = ["tests"]\n'
                'markers = [\n'
                '    "unit: unit tests",\n'
                '    "browser: browser tests",\n'
                ']\n'
            )
            tests_dir = project_path / "tests"
            tests_dir.mkdir()
            (tests_dir / "conftest.py").write_text("")

            (tests_dir / f"test_unit_{unique_id}.py").write_text(
                "import pytest\n"
                "@pytest.mark.unit\n"
                "def test_unit(): assert True\n"
            )
            (tests_dir / f"test_browser_{unique_id}.py").write_text(
                "import pytest\n"
                "@pytest.mark.browser\n"
                "def test_browser(): assert True\n"
            )

            adapter = PytestAdapter(
                AdapterConfig(project_root=str(project_path))
            )

            # Simulate _run_legacy_adapter_tests:
            category = "browser"
            tests_to_run = None

            if category:
                tests_to_run = adapter.discover(category=category)

            # Execute with discovered tests
            result = adapter.execute(
                tests=tests_to_run,
                parallel=False,
                coverage=False,
                failfast=False,
                verbose=False,
            )

            if tests_to_run:
                # If discover found tests, execute should run only browser tests
                assert result.passed == 1, (
                    f"Expected 1 browser test, got {result.passed}"
                )
            else:
                # Bug: if discover returned empty, ALL tests run
                assert result.passed >= 2, (
                    "Empty discover caused all tests to run"
                )
