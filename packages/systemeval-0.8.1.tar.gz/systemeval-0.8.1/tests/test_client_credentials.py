"""Tests for OAuth 2.0 Client Credentials Flow client."""

import time
from unittest.mock import patch

import pytest

from systemeval.auth.oauth_client import ClientCredentialsClient, OAuthError
from systemeval.auth.token_storage import TokenData, TokenStorage
from systemeval.config.e2e import OAuthConfig


@pytest.fixture
def oauth_config():
    """OAuthConfig with client_secret for client_credentials flow."""
    return OAuthConfig(
        client_id="ci-client-id",
        client_secret="ci-client-secret",
        token_endpoint="https://auth.example.com/oauth/token",
        scopes=["e2e:read", "e2e:write"],
    )


@pytest.fixture
def oauth_config_no_secret():
    """OAuthConfig without client_secret."""
    return OAuthConfig(
        client_id="ci-client-id",
        token_endpoint="https://auth.example.com/oauth/token",
    )


@pytest.fixture
def storage(tmp_path):
    return TokenStorage(path=tmp_path / "tokens.json")


@pytest.fixture
def client(oauth_config, storage):
    return ClientCredentialsClient(oauth_config, storage=storage, provider_key="test_cc")


# =============================================================================
# ClientCredentialsClient.authenticate Tests
# =============================================================================


class TestAuthenticate:

    def test_authenticate_success(self, client, storage):
        token_response = {
            "access_token": "cc_access_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", return_value=token_response) as mock_post:
            token = client.authenticate()

        assert token.access_token == "cc_access_tok"
        assert token.expires_at is not None

        mock_post.assert_called_once_with(
            "https://auth.example.com/oauth/token",
            {
                "grant_type": "client_credentials",
                "client_id": "ci-client-id",
                "client_secret": "ci-client-secret",
                "scope": "e2e:read e2e:write",
            },
        )

        # Token should be saved
        saved = storage.load("test_cc")
        assert saved.access_token == "cc_access_tok"

    def test_authenticate_no_scopes(self, storage):
        config = OAuthConfig(
            client_id="ci-client-id",
            client_secret="ci-client-secret",
            token_endpoint="https://auth.example.com/oauth/token",
            scopes=[],
        )
        client = ClientCredentialsClient(config, storage=storage, provider_key="test_cc")

        token_response = {
            "access_token": "tok_no_scope",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", return_value=token_response) as mock_post:
            token = client.authenticate()

        assert token.access_token == "tok_no_scope"
        # scope should NOT be in the request data
        call_data = mock_post.call_args[0][1]
        assert "scope" not in call_data

    def test_authenticate_no_secret_raises(self, oauth_config_no_secret, storage):
        client = ClientCredentialsClient(
            oauth_config_no_secret, storage=storage, provider_key="test_cc"
        )

        with pytest.raises(OAuthError, match="client_secret"):
            client.authenticate()

    def test_authenticate_server_error_raises(self, client):
        with patch.object(client, "_post", side_effect=OAuthError("invalid_client", "Bad creds")):
            with pytest.raises(OAuthError, match="invalid_client"):
                client.authenticate()


# =============================================================================
# ClientCredentialsClient.get_token Tests
# =============================================================================


class TestGetToken:

    def test_get_token_returns_cached(self, client, storage):
        token = TokenData(
            access_token="cached_cc",
            expires_at=time.time() + 3600,
        )
        storage.save("test_cc", token)

        result = client.get_token()
        assert result.access_token == "cached_cc"

    def test_get_token_authenticates_when_no_cache(self, client):
        token_response = {
            "access_token": "fresh_cc",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", return_value=token_response):
            result = client.get_token()

        assert result.access_token == "fresh_cc"

    def test_get_token_authenticates_when_expired(self, client, storage):
        expired = TokenData(
            access_token="old_cc",
            expires_at=time.time() - 100,
        )
        storage.save("test_cc", expired)

        token_response = {
            "access_token": "new_cc",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", return_value=token_response):
            result = client.get_token()

        assert result.access_token == "new_cc"


# =============================================================================
# Inherited BaseOAuthClient behavior
# =============================================================================


class TestInheritedBehavior:

    def test_logout(self, client, storage):
        storage.save("test_cc", TokenData(access_token="tok"))
        assert client.logout() is True
        assert storage.load("test_cc") is None

    def test_logout_no_token(self, client):
        assert client.logout() is False

    def test_get_cached_token_refreshes(self, client, storage):
        old = TokenData(
            access_token="old",
            expires_at=time.time() - 100,
            refresh_token="ref_tok",
        )
        storage.save("test_cc", old)

        refreshed = {
            "access_token": "refreshed",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "new_ref",
        }

        with patch.object(client, "_post", return_value=refreshed):
            result = client.get_cached_token()

        assert result.access_token == "refreshed"

    def test_default_provider_key(self, oauth_config, storage):
        client = ClientCredentialsClient(oauth_config, storage=storage)
        assert client._provider_key == "debuggai"
