"""Tests for ConfigValidator (post-construction config validation)."""

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from systemeval.validation import ConfigValidator


# =============================================================================
# Helpers to build minimal config-like objects
# =============================================================================


def _make_config(**overrides):
    """Build a minimal config mock with sensible defaults."""
    cfg = MagicMock()
    cfg.version = overrides.get("version", "1.0")
    cfg.environments = overrides.get("environments", {})
    cfg.subprojects = overrides.get("subprojects", [])
    cfg.e2e = overrides.get("e2e", None)
    cfg.project_root = overrides.get("project_root", Path("."))
    return cfg


def _make_subproject(name="backend", adapter="pytest", path="backend",
                     timeout=None, enabled=True, tags=None):
    sp = MagicMock()
    sp.name = name
    sp.adapter = adapter
    sp.path = path
    sp.timeout = timeout
    sp.enabled = enabled
    sp.tags = tags or []
    return sp


def _make_composite_env(depends_on):
    env = MagicMock()
    env.type = "composite"
    env.depends_on = depends_on
    # Make isinstance check work for CompositeEnvConfig
    from systemeval.config.environments import CompositeEnvConfig
    env.__class__ = CompositeEnvConfig
    return env


def _make_e2e(provider="debuggai", api_key=None, auth_type=None, enabled=True):
    from systemeval.config.e2e import AuthType

    e2e = MagicMock()
    e2e.enabled = enabled
    e2e.provider = MagicMock()
    e2e.provider.provider = provider
    e2e.provider.api_key = api_key
    e2e.provider.auth_type = auth_type or AuthType.API_KEY
    return e2e


# =============================================================================
# composite_env_deps rule
# =============================================================================


class TestCompositeEnvDeps:

    def test_no_environments_passes(self):
        v = ConfigValidator()
        r = v.validate_one("composite_env_deps", _make_config())
        assert r.valid is True

    def test_non_composite_passes(self):
        env = MagicMock()
        env.type = "standalone"
        cfg = _make_config(environments={"web": env})
        r = ConfigValidator().validate_one("composite_env_deps", cfg)
        assert r.valid is True

    def test_composite_with_valid_deps_passes(self):
        standalone = MagicMock()
        standalone.type = "standalone"
        composite = _make_composite_env(depends_on=["web"])
        cfg = _make_config(environments={"web": standalone, "full": composite})
        r = ConfigValidator().validate_one("composite_env_deps", cfg)
        assert r.valid is True

    def test_composite_missing_dep_fails(self):
        composite = _make_composite_env(depends_on=["missing_env"])
        cfg = _make_config(environments={"full": composite})
        r = ConfigValidator().validate_one("composite_env_deps", cfg)
        assert r.valid is False
        assert "missing_env" in r.errors[0]

    def test_composite_multiple_missing_deps(self):
        composite = _make_composite_env(depends_on=["a", "b"])
        cfg = _make_config(environments={"full": composite})
        r = ConfigValidator().validate_one("composite_env_deps", cfg)
        assert r.valid is False
        assert len(r.errors) == 2


# =============================================================================
# unique_subproject_names rule
# =============================================================================


class TestUniqueSubprojectNames:

    def test_no_subprojects_passes(self):
        r = ConfigValidator().validate_one("unique_subproject_names", _make_config())
        assert r.valid is True

    def test_unique_names_passes(self):
        sps = [_make_subproject("a"), _make_subproject("b")]
        r = ConfigValidator().validate_one(
            "unique_subproject_names", _make_config(subprojects=sps)
        )
        assert r.valid is True

    def test_duplicate_names_fails(self):
        sps = [_make_subproject("api"), _make_subproject("api")]
        r = ConfigValidator().validate_one(
            "unique_subproject_names", _make_config(subprojects=sps)
        )
        assert r.valid is False
        assert "api" in r.errors[0]


# =============================================================================
# v2_needs_subprojects rule
# =============================================================================


class TestV2NeedsSubprojects:

    def test_v1_no_subprojects_ok(self):
        r = ConfigValidator().validate_one(
            "v2_needs_subprojects", _make_config(version="1.0")
        )
        assert r.valid is True
        assert r.warnings == []

    def test_v2_with_subprojects_ok(self):
        sps = [_make_subproject("x")]
        r = ConfigValidator().validate_one(
            "v2_needs_subprojects", _make_config(version="2.0", subprojects=sps)
        )
        assert r.valid is True
        assert r.warnings == []

    def test_v2_no_subprojects_warns(self):
        r = ConfigValidator().validate_one(
            "v2_needs_subprojects", _make_config(version="2.0")
        )
        assert r.valid is True
        assert len(r.warnings) == 1
        assert "2.0" in r.warnings[0]

    def test_v2_no_subprojects_strict_fails(self):
        cfg = _make_config(version="2.0")
        r = ConfigValidator(strict_mode=True).validate(cfg)
        assert r.valid is False
        assert any("2.0" in e for e in r.errors)


# =============================================================================
# e2e_api_key rule
# =============================================================================


class TestE2eApiKey:

    def test_no_e2e_passes(self):
        r = ConfigValidator().validate_one("e2e_api_key", _make_config())
        assert r.valid is True

    def test_e2e_disabled_passes(self):
        e2e = _make_e2e(enabled=False)
        r = ConfigValidator().validate_one("e2e_api_key", _make_config(e2e=e2e))
        assert r.valid is True

    def test_non_debuggai_passes(self):
        e2e = _make_e2e(provider="mock")
        r = ConfigValidator().validate_one("e2e_api_key", _make_config(e2e=e2e))
        assert r.valid is True

    def test_debuggai_with_key_passes(self):
        e2e = _make_e2e(api_key="sk_test")
        r = ConfigValidator().validate_one("e2e_api_key", _make_config(e2e=e2e))
        assert r.valid is True

    def test_debuggai_no_key_warns(self):
        e2e = _make_e2e(api_key=None)
        r = ConfigValidator().validate_one("e2e_api_key", _make_config(e2e=e2e))
        assert r.valid is True
        assert len(r.warnings) == 1
        assert "api_key" in r.warnings[0]

    def test_debuggai_oauth_no_key_passes(self):
        from systemeval.config.e2e import AuthType
        e2e = _make_e2e(api_key=None, auth_type=AuthType.OAUTH_DEVICE)
        r = ConfigValidator().validate_one("e2e_api_key", _make_config(e2e=e2e))
        assert r.valid is True
        assert r.warnings == []


# =============================================================================
# subproject_adapters rule
# =============================================================================


class TestSubprojectAdapters:

    def test_no_subprojects_passes(self):
        r = ConfigValidator().validate_one("subproject_adapters", _make_config())
        assert r.valid is True

    def test_known_adapters_pass(self):
        sps = [_make_subproject("a", adapter="pytest"), _make_subproject("b", adapter="jest")]
        r = ConfigValidator().validate_one(
            "subproject_adapters", _make_config(subprojects=sps)
        )
        assert r.valid is True
        assert r.warnings == []

    def test_unknown_adapter_warns(self):
        sps = [_make_subproject("x", adapter="karma")]
        r = ConfigValidator().validate_one(
            "subproject_adapters", _make_config(subprojects=sps)
        )
        assert r.valid is True
        assert len(r.warnings) == 1
        assert "karma" in r.warnings[0]


# =============================================================================
# timeout_consistency rule
# =============================================================================


class TestTimeoutConsistency:

    def test_no_subprojects_passes(self):
        r = ConfigValidator().validate_one("timeout_consistency", _make_config())
        assert r.valid is True

    def test_reasonable_timeout_passes(self):
        sps = [_make_subproject("a", timeout=300)]
        r = ConfigValidator().validate_one(
            "timeout_consistency", _make_config(subprojects=sps)
        )
        assert r.valid is True

    def test_no_timeout_override_passes(self):
        sps = [_make_subproject("a", timeout=None)]
        r = ConfigValidator().validate_one(
            "timeout_consistency", _make_config(subprojects=sps)
        )
        assert r.valid is True

    def test_excessive_timeout_warns(self):
        sps = [_make_subproject("a", timeout=7200)]
        r = ConfigValidator().validate_one(
            "timeout_consistency", _make_config(subprojects=sps)
        )
        assert r.valid is True
        assert len(r.warnings) == 1
        assert "7200" in r.warnings[0]


# =============================================================================
# subproject_paths_exist rule (opt-in)
# =============================================================================


class TestSubprojectPathsExist:

    def test_not_included_by_default(self):
        v = ConfigValidator()
        assert "subproject_paths_exist" not in v.list_rules()

    def test_included_when_check_paths_true(self):
        v = ConfigValidator(check_paths=True)
        assert "subproject_paths_exist" in v.list_rules()

    def test_existing_path_passes(self, tmp_path):
        sp_dir = tmp_path / "backend"
        sp_dir.mkdir()
        sps = [_make_subproject("backend", path="backend")]
        cfg = _make_config(subprojects=sps, project_root=tmp_path)
        r = ConfigValidator(check_paths=True).validate_one(
            "subproject_paths_exist", cfg
        )
        assert r.valid is True

    def test_missing_path_fails(self, tmp_path):
        sps = [_make_subproject("backend", path="nonexistent")]
        cfg = _make_config(subprojects=sps, project_root=tmp_path)
        r = ConfigValidator(check_paths=True).validate_one(
            "subproject_paths_exist", cfg
        )
        assert r.valid is False
        assert "nonexistent" in r.errors[0]


# =============================================================================
# Full validation flow
# =============================================================================


class TestFullValidation:

    def test_valid_v1_config_passes(self):
        cfg = _make_config()
        r = ConfigValidator().validate(cfg)
        assert r.valid is True
        assert r.errors == []

    def test_multiple_issues_collected(self):
        composite = _make_composite_env(depends_on=["missing"])
        sps = [_make_subproject("x"), _make_subproject("x")]
        cfg = _make_config(
            environments={"full": composite},
            subprojects=sps,
        )
        r = ConfigValidator().validate(cfg)
        assert r.valid is False
        assert len(r.errors) >= 2  # composite dep + duplicate names

    def test_strict_promotes_all_warnings(self):
        sps = [_make_subproject("a", adapter="karma", timeout=7200)]
        cfg = _make_config(version="2.0", subprojects=sps)
        r = ConfigValidator(strict_mode=True).validate(cfg)
        assert r.valid is False
        # unknown adapter + excessive timeout both promoted
        assert len(r.errors) >= 2
        assert r.warnings == []

    def test_list_rules_default(self):
        v = ConfigValidator()
        names = v.list_rules()
        assert "composite_env_deps" in names
        assert "unique_subproject_names" in names
        assert "subproject_paths_exist" not in names

    def test_list_rules_with_paths(self):
        v = ConfigValidator(check_paths=True)
        assert "subproject_paths_exist" in v.list_rules()
