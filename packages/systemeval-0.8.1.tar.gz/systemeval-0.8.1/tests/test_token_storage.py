"""Tests for OAuth token storage."""

import json
import os
import time
from pathlib import Path

import pytest

from systemeval.auth.token_storage import TokenData, TokenStorage


# =============================================================================
# TokenData Tests
# =============================================================================


class TestTokenData:
    """Tests for TokenData dataclass."""

    def test_minimal_token_data(self):
        token = TokenData(access_token="abc123")
        assert token.access_token == "abc123"
        assert token.token_type == "Bearer"
        assert token.expires_at is None
        assert token.refresh_token is None
        assert token.scope is None

    def test_full_token_data(self):
        token = TokenData(
            access_token="abc123",
            token_type="Bearer",
            expires_at=1700000000.0,
            refresh_token="refresh_xyz",
            scope="read write",
        )
        assert token.refresh_token == "refresh_xyz"
        assert token.scope == "read write"

    def test_from_token_response(self):
        response = {
            "access_token": "tok_123",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "ref_456",
            "scope": "e2e:read e2e:write",
        }
        token = TokenData.from_token_response(response)
        assert token.access_token == "tok_123"
        assert token.refresh_token == "ref_456"
        assert token.scope == "e2e:read e2e:write"
        assert token.expires_at is not None
        assert token.expires_at > time.time()

    def test_from_token_response_minimal(self):
        response = {"access_token": "tok_123"}
        token = TokenData.from_token_response(response)
        assert token.access_token == "tok_123"
        assert token.expires_at is None
        assert token.refresh_token is None

    def test_is_expired_no_expiry(self):
        token = TokenData(access_token="abc")
        assert token.is_expired() is True

    def test_is_expired_future(self):
        token = TokenData(access_token="abc", expires_at=time.time() + 3600)
        assert token.is_expired() is False

    def test_is_expired_past(self):
        token = TokenData(access_token="abc", expires_at=time.time() - 10)
        assert token.is_expired() is True

    def test_is_expired_within_buffer(self):
        token = TokenData(access_token="abc", expires_at=time.time() + 30)
        assert token.is_expired(buffer_seconds=60) is True

    def test_is_expired_outside_buffer(self):
        token = TokenData(access_token="abc", expires_at=time.time() + 120)
        assert token.is_expired(buffer_seconds=60) is False

    def test_has_refresh_token_true(self):
        token = TokenData(access_token="abc", refresh_token="ref")
        assert token.has_refresh_token() is True

    def test_has_refresh_token_false_none(self):
        token = TokenData(access_token="abc")
        assert token.has_refresh_token() is False

    def test_has_refresh_token_false_empty(self):
        token = TokenData(access_token="abc", refresh_token="")
        assert token.has_refresh_token() is False


# =============================================================================
# TokenStorage Tests
# =============================================================================


class TestTokenStorage:
    """Tests for TokenStorage file operations."""

    def test_default_path(self):
        storage = TokenStorage()
        assert storage.path.name == "oauth_tokens.json"
        assert ".systemeval" in str(storage.path)

    def test_custom_path(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)
        assert storage.path == path

    def test_save_and_load(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        token = TokenData(
            access_token="access_123",
            refresh_token="refresh_456",
            expires_at=1700000000.0,
        )
        storage.save("debuggai", token)

        loaded = storage.load("debuggai")
        assert loaded is not None
        assert loaded.access_token == "access_123"
        assert loaded.refresh_token == "refresh_456"
        assert loaded.expires_at == 1700000000.0

    def test_load_nonexistent_provider(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)
        assert storage.load("nonexistent") is None

    def test_load_nonexistent_file(self, tmp_path):
        path = tmp_path / "no_such_file.json"
        storage = TokenStorage(path=path)
        assert storage.load("anything") is None

    def test_delete_existing(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("provider1", TokenData(access_token="tok1"))
        storage.save("provider2", TokenData(access_token="tok2"))

        assert storage.delete("provider1") is True
        assert storage.load("provider1") is None
        assert storage.load("provider2") is not None

    def test_delete_nonexistent(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)
        assert storage.delete("nonexistent") is False

    def test_clear(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("a", TokenData(access_token="tok_a"))
        storage.save("b", TokenData(access_token="tok_b"))

        storage.clear()

        assert storage.load("a") is None
        assert storage.load("b") is None
        assert storage.list_providers() == []

    def test_list_providers(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("alpha", TokenData(access_token="tok1"))
        storage.save("beta", TokenData(access_token="tok2"))

        providers = storage.list_providers()
        assert sorted(providers) == ["alpha", "beta"]

    def test_list_providers_empty(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)
        assert storage.list_providers() == []

    def test_file_permissions(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("test", TokenData(access_token="tok"))

        mode = os.stat(path).st_mode & 0o777
        assert mode == 0o600

    def test_creates_parent_directories(self, tmp_path):
        path = tmp_path / "deep" / "nested" / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("test", TokenData(access_token="tok"))

        assert path.exists()
        loaded = storage.load("test")
        assert loaded.access_token == "tok"

    def test_overwrite_existing_provider(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("p", TokenData(access_token="old"))
        storage.save("p", TokenData(access_token="new"))

        loaded = storage.load("p")
        assert loaded.access_token == "new"

    def test_corrupt_file_returns_none(self, tmp_path):
        path = tmp_path / "tokens.json"
        path.write_text("not valid json{{{")

        storage = TokenStorage(path=path)
        assert storage.load("anything") is None

    def test_corrupt_entry_returns_none(self, tmp_path):
        path = tmp_path / "tokens.json"
        path.write_text(json.dumps({"bad": {"not_a_token": True}}))

        storage = TokenStorage(path=path)
        assert storage.load("bad") is None

    def test_multiple_providers_isolated(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("debuggai", TokenData(access_token="da_tok"))
        storage.save("other", TokenData(access_token="ot_tok"))

        da = storage.load("debuggai")
        ot = storage.load("other")

        assert da.access_token == "da_tok"
        assert ot.access_token == "ot_tok"

    def test_json_format_readable(self, tmp_path):
        path = tmp_path / "tokens.json"
        storage = TokenStorage(path=path)

        storage.save("test", TokenData(access_token="tok", scope="read"))

        content = path.read_text()
        data = json.loads(content)
        assert "test" in data
        assert data["test"]["access_token"] == "tok"
