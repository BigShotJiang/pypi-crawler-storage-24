"""Tests for OAuth 2.0 Authorization Code + PKCE Flow client."""

import time
import urllib.parse
from unittest.mock import MagicMock, patch

import pytest

from systemeval.auth.oauth_client import (
    AuthorizationCodeClient,
    OAuthError,
    _generate_code_challenge,
    _generate_code_verifier,
)
from systemeval.auth.token_storage import TokenData, TokenStorage
from systemeval.config.e2e import OAuthConfig


@pytest.fixture
def oauth_config():
    return OAuthConfig(
        client_id="browser-client-id",
        token_endpoint="https://auth.example.com/oauth/token",
        authorization_endpoint="https://auth.example.com/oauth/authorize",
        scopes=["e2e:read", "e2e:write"],
    )


@pytest.fixture
def oauth_config_no_authz():
    return OAuthConfig(
        client_id="browser-client-id",
        token_endpoint="https://auth.example.com/oauth/token",
    )


@pytest.fixture
def storage(tmp_path):
    return TokenStorage(path=tmp_path / "tokens.json")


@pytest.fixture
def client(oauth_config, storage):
    return AuthorizationCodeClient(
        oauth_config, storage=storage, provider_key="test_ac", redirect_port=9876
    )


# =============================================================================
# PKCE Helper Tests
# =============================================================================


class TestPKCEHelpers:

    def test_code_verifier_length(self):
        verifier = _generate_code_verifier(64)
        assert len(verifier) == 64

    def test_code_verifier_url_safe(self):
        verifier = _generate_code_verifier()
        # URL-safe base64 chars only
        allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")
        assert all(c in allowed for c in verifier)

    def test_code_verifier_unique(self):
        a = _generate_code_verifier()
        b = _generate_code_verifier()
        assert a != b

    def test_code_challenge_deterministic(self):
        verifier = "test_verifier_string"
        c1 = _generate_code_challenge(verifier)
        c2 = _generate_code_challenge(verifier)
        assert c1 == c2

    def test_code_challenge_no_padding(self):
        verifier = _generate_code_verifier()
        challenge = _generate_code_challenge(verifier)
        assert "=" not in challenge

    def test_code_challenge_differs_from_verifier(self):
        verifier = _generate_code_verifier()
        challenge = _generate_code_challenge(verifier)
        assert challenge != verifier


# =============================================================================
# AuthorizationCodeClient.build_authorization_url Tests
# =============================================================================


class TestBuildAuthorizationUrl:

    def test_builds_correct_url(self, client):
        url = client.build_authorization_url("challenge123", "state456")
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.netloc == "auth.example.com"
        assert parsed.path == "/oauth/authorize"

        assert params["response_type"] == ["code"]
        assert params["client_id"] == ["browser-client-id"]
        assert params["redirect_uri"] == ["http://localhost:9876/callback"]
        assert params["scope"] == ["e2e:read e2e:write"]
        assert params["state"] == ["state456"]
        assert params["code_challenge"] == ["challenge123"]
        assert params["code_challenge_method"] == ["S256"]

    def test_no_endpoint_raises(self, oauth_config_no_authz, storage):
        client = AuthorizationCodeClient(
            oauth_config_no_authz, storage=storage, provider_key="test_ac"
        )
        with pytest.raises(OAuthError, match="authorization_endpoint"):
            client.build_authorization_url("challenge", "state")


# =============================================================================
# AuthorizationCodeClient.redirect_uri Tests
# =============================================================================


class TestRedirectUri:

    def test_default_port(self, oauth_config, storage):
        client = AuthorizationCodeClient(oauth_config, storage=storage)
        assert client.redirect_uri == "http://localhost:8484/callback"

    def test_custom_port(self, client):
        assert client.redirect_uri == "http://localhost:9876/callback"


# =============================================================================
# AuthorizationCodeClient.exchange_code Tests
# =============================================================================


class TestExchangeCode:

    def test_exchange_success(self, client, storage):
        token_response = {
            "access_token": "ac_tok_123",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "ac_ref_456",
        }

        with patch.object(client, "_post", return_value=token_response) as mock_post:
            token = client.exchange_code("auth_code_abc", "verifier_xyz")

        assert token.access_token == "ac_tok_123"
        assert token.refresh_token == "ac_ref_456"

        mock_post.assert_called_once_with(
            "https://auth.example.com/oauth/token",
            {
                "grant_type": "authorization_code",
                "code": "auth_code_abc",
                "redirect_uri": "http://localhost:9876/callback",
                "client_id": "browser-client-id",
                "code_verifier": "verifier_xyz",
            },
        )

        saved = storage.load("test_ac")
        assert saved.access_token == "ac_tok_123"

    def test_exchange_error_raises(self, client):
        with patch.object(client, "_post", side_effect=OAuthError("invalid_grant")):
            with pytest.raises(OAuthError, match="invalid_grant"):
                client.exchange_code("bad_code", "verifier")


# =============================================================================
# AuthorizationCodeClient.authenticate Tests
# =============================================================================


class TestAuthenticate:

    def _simulate_callback(self, server, code="auth_code_ok", state=None, error=None):
        """Simulate what the callback handler sets on the server."""
        server.oauth_code = code
        server.oauth_state = state
        server.oauth_error = error
        server.oauth_error_description = ""

    def test_authenticate_success(self, client, storage):
        token_response = {
            "access_token": "full_flow_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        def fake_handle_request(server_self):
            server_self.oauth_code = "auth_code"
            # We need to match the state. Patch secrets to control it.

        with patch("secrets.token_urlsafe", return_value="fixed_state"):
            with patch("webbrowser.open") as mock_browser:
                with patch("http.server.HTTPServer") as MockServer:
                    mock_server = MagicMock()
                    MockServer.return_value = mock_server
                    mock_server.oauth_code = None
                    mock_server.oauth_state = None
                    mock_server.oauth_error = None
                    mock_server.oauth_error_description = ""

                    def set_callback_result():
                        mock_server.oauth_code = "auth_code_xyz"
                        mock_server.oauth_state = "fixed_state"
                        mock_server.oauth_error = None

                    mock_server.handle_request.side_effect = lambda: set_callback_result()

                    with patch.object(client, "exchange_code", return_value=TokenData(
                        access_token="full_flow_tok", expires_at=time.time() + 3600
                    )) as mock_exchange:
                        token = client.authenticate(timeout=10, open_browser=True)

                    mock_browser.assert_called_once()
                    mock_exchange.assert_called_once()
                    # Verify code_verifier was passed
                    call_args = mock_exchange.call_args
                    assert call_args[0][0] == "auth_code_xyz"
                    assert len(call_args[0][1]) > 0  # code_verifier is non-empty

        assert token.access_token == "full_flow_tok"

    def test_authenticate_no_browser(self, client):
        with patch("secrets.token_urlsafe", return_value="fixed_state"):
            with patch("webbrowser.open") as mock_browser:
                with patch("http.server.HTTPServer") as MockServer:
                    mock_server = MagicMock()
                    MockServer.return_value = mock_server

                    def set_callback_result():
                        mock_server.oauth_code = "code"
                        mock_server.oauth_state = "fixed_state"
                        mock_server.oauth_error = None

                    mock_server.handle_request.side_effect = lambda: set_callback_result()

                    with patch.object(client, "exchange_code", return_value=TokenData(
                        access_token="tok"
                    )):
                        client.authenticate(open_browser=False)

                    mock_browser.assert_not_called()

    def test_authenticate_error_callback(self, client):
        with patch("http.server.HTTPServer") as MockServer:
            mock_server = MagicMock()
            MockServer.return_value = mock_server

            def set_error():
                mock_server.oauth_code = None
                mock_server.oauth_error = "access_denied"
                mock_server.oauth_error_description = "User denied"

            mock_server.handle_request.side_effect = lambda: set_error()

            with patch("webbrowser.open"):
                with pytest.raises(OAuthError, match="access_denied"):
                    client.authenticate()

    def test_authenticate_no_code_timeout(self, client):
        with patch("http.server.HTTPServer") as MockServer:
            mock_server = MagicMock()
            MockServer.return_value = mock_server
            mock_server.oauth_code = None
            mock_server.oauth_error = None
            mock_server.handle_request.return_value = None

            with patch("webbrowser.open"):
                with pytest.raises(OAuthError, match="timeout"):
                    client.authenticate(timeout=1)

    def test_authenticate_state_mismatch(self, client):
        with patch("secrets.token_urlsafe", return_value="expected_state"):
            with patch("http.server.HTTPServer") as MockServer:
                mock_server = MagicMock()
                MockServer.return_value = mock_server

                def set_mismatched_state():
                    mock_server.oauth_code = "some_code"
                    mock_server.oauth_state = "wrong_state"
                    mock_server.oauth_error = None

                mock_server.handle_request.side_effect = lambda: set_mismatched_state()

                with patch("webbrowser.open"):
                    with pytest.raises(OAuthError, match="state_mismatch"):
                        client.authenticate()


# =============================================================================
# AuthorizationCodeClient.get_token Tests
# =============================================================================


class TestGetToken:

    def test_returns_cached(self, client, storage):
        storage.save("test_ac", TokenData(
            access_token="cached_ac", expires_at=time.time() + 3600
        ))
        result = client.get_token(open_browser=False)
        assert result.access_token == "cached_ac"

    def test_authenticates_when_no_cache(self, client):
        with patch.object(client, "authenticate", return_value=TokenData(
            access_token="fresh_ac"
        )) as mock_auth:
            result = client.get_token(timeout=10, open_browser=False)

        assert result.access_token == "fresh_ac"
        mock_auth.assert_called_once_with(timeout=10, open_browser=False)


# =============================================================================
# Inherited BaseOAuthClient behavior
# =============================================================================


class TestInheritedBehavior:

    def test_logout(self, client, storage):
        storage.save("test_ac", TokenData(access_token="tok"))
        assert client.logout() is True
        assert storage.load("test_ac") is None

    def test_default_provider_key(self, oauth_config, storage):
        client = AuthorizationCodeClient(oauth_config, storage=storage)
        assert client._provider_key == "debuggai"
