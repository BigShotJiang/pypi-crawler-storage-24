"""Tests for AdapterValidator (shared adapter validation rules)."""

from pathlib import Path
from unittest.mock import MagicMock, PropertyMock

import pytest

from systemeval.validation import AdapterValidator


# =============================================================================
# Helpers
# =============================================================================


def _make_adapter(
    project_root=None,
    test_directory=None,
    validate_env_return=True,
    validate_env_raises=None,
    name="pytest",
):
    adapter = MagicMock()
    adapter.name = name
    adapter.project_root = project_root
    adapter.test_directory = test_directory

    if validate_env_raises:
        adapter.validate_environment.side_effect = validate_env_raises
    else:
        adapter.validate_environment.return_value = validate_env_return

    return adapter


# =============================================================================
# adapter_type rule
# =============================================================================


class TestAdapterType:

    def test_valid_adapter_passes(self):
        adapter = _make_adapter()
        r = AdapterValidator(check_paths=False).validate_one("adapter_type", adapter)
        assert r.valid is True

    def test_missing_validate_environment_fails(self):
        obj = MagicMock(spec=[])  # no attributes
        r = AdapterValidator(check_paths=False).validate_one("adapter_type", obj)
        assert r.valid is False
        assert "validate_environment" in r.errors[0]

    def test_missing_discover_fails(self):
        obj = MagicMock(spec=["validate_environment"])
        r = AdapterValidator(check_paths=False).validate_one("adapter_type", obj)
        assert r.valid is False
        assert "discover" in r.errors[0]


# =============================================================================
# project_root rule
# =============================================================================


class TestProjectRoot:

    def test_no_project_root_fails(self):
        adapter = _make_adapter(project_root=None)
        r = AdapterValidator(check_paths=False).validate_one("project_root", adapter)
        assert r.valid is False

    def test_with_project_root_no_path_check(self):
        adapter = _make_adapter(project_root="/fake/path")
        r = AdapterValidator(check_paths=False).validate_one("project_root", adapter)
        assert r.valid is True

    def test_existing_project_root_passes(self, tmp_path):
        adapter = _make_adapter(project_root=str(tmp_path))
        r = AdapterValidator(check_paths=True).validate_one("project_root", adapter)
        assert r.valid is True

    def test_nonexistent_project_root_fails(self):
        adapter = _make_adapter(project_root="/nonexistent/xyz")
        r = AdapterValidator(check_paths=True).validate_one("project_root", adapter)
        assert r.valid is False
        assert "does not exist" in r.errors[0]

    def test_file_as_root_fails(self, tmp_path):
        f = tmp_path / "file.txt"
        f.write_text("x")
        adapter = _make_adapter(project_root=str(f))
        r = AdapterValidator(check_paths=True).validate_one("project_root", adapter)
        assert r.valid is False
        assert "not a directory" in r.errors[0]


# =============================================================================
# environment_ready rule
# =============================================================================


class TestEnvironmentReady:

    def test_valid_environment_passes(self):
        adapter = _make_adapter(validate_env_return=True)
        r = AdapterValidator(check_paths=False).validate_one("environment_ready", adapter)
        assert r.valid is True

    def test_invalid_environment_fails(self):
        adapter = _make_adapter(validate_env_return=False)
        r = AdapterValidator(check_paths=False).validate_one("environment_ready", adapter)
        assert r.valid is False
        assert "environment validation failed" in r.errors[0]

    def test_environment_exception_fails(self):
        adapter = _make_adapter(validate_env_raises=RuntimeError("npx not found"))
        r = AdapterValidator(check_paths=False).validate_one("environment_ready", adapter)
        assert r.valid is False
        assert "RuntimeError" in r.errors[0]
        assert "npx not found" in r.errors[0]


# =============================================================================
# test_directory rule (opt-in via check_paths)
# =============================================================================


class TestTestDirectory:

    def test_not_included_when_paths_disabled(self):
        v = AdapterValidator(check_paths=False)
        assert "test_directory" not in v.list_rules()

    def test_included_when_paths_enabled(self):
        v = AdapterValidator(check_paths=True)
        assert "test_directory" in v.list_rules()

    def test_existing_test_dir_passes(self, tmp_path):
        test_dir = tmp_path / "tests"
        test_dir.mkdir()
        adapter = _make_adapter(project_root=str(tmp_path), test_directory="tests")
        r = AdapterValidator(check_paths=True).validate_one("test_directory", adapter)
        assert r.valid is True

    def test_missing_test_dir_warns(self, tmp_path):
        adapter = _make_adapter(project_root=str(tmp_path), test_directory="nonexistent")
        r = AdapterValidator(check_paths=True).validate_one("test_directory", adapter)
        assert r.valid is True  # warning, not error
        assert len(r.warnings) == 1
        assert "nonexistent" in r.warnings[0]

    def test_no_test_directory_set_ok(self, tmp_path):
        adapter = _make_adapter(project_root=str(tmp_path), test_directory=None)
        r = AdapterValidator(check_paths=True).validate_one("test_directory", adapter)
        assert r.valid is True


# =============================================================================
# Full validation
# =============================================================================


class TestFullValidation:

    def test_valid_adapter_passes(self, tmp_path):
        test_dir = tmp_path / "tests"
        test_dir.mkdir()
        adapter = _make_adapter(
            project_root=str(tmp_path),
            test_directory="tests",
            validate_env_return=True,
        )
        r = AdapterValidator(check_paths=True).validate(adapter)
        assert r.valid is True
        assert r.errors == []

    def test_multiple_failures_collected(self):
        adapter = _make_adapter(
            project_root=None,
            validate_env_return=False,
        )
        r = AdapterValidator(check_paths=False).validate(adapter)
        assert r.valid is False
        assert len(r.errors) >= 2  # project_root + environment_ready

    def test_strict_mode_promotes_warnings(self, tmp_path):
        adapter = _make_adapter(
            project_root=str(tmp_path),
            test_directory="nonexistent",
            validate_env_return=True,
        )
        r = AdapterValidator(strict_mode=True, check_paths=True).validate(adapter)
        assert r.valid is False
        assert any("nonexistent" in e for e in r.errors)
        assert r.warnings == []

    def test_list_rules_without_paths(self):
        v = AdapterValidator(check_paths=False)
        names = v.list_rules()
        assert "adapter_type" in names
        assert "project_root" in names
        assert "environment_ready" in names
        assert "test_directory" not in names

    def test_list_rules_with_paths(self):
        v = AdapterValidator(check_paths=True)
        assert "test_directory" in v.list_rules()
