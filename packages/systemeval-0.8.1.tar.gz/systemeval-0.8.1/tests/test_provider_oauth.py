"""Tests for DebuggAIProvider OAuth session integration."""

import json
import time
from unittest.mock import MagicMock, patch

import pytest

from systemeval.auth.token_storage import TokenData
from systemeval.e2e.providers.debuggai.provider import DebuggAIProvider


@pytest.fixture
def mock_session():
    """Create a mock AuthenticatedSession."""
    session = MagicMock()
    session.get_token.return_value = TokenData(
        access_token="oauth_tok", expires_at=time.time() + 3600
    )
    return session


# =============================================================================
# Construction Tests
# =============================================================================


class TestConstruction:

    def test_from_oauth_session(self, mock_session):
        provider = DebuggAIProvider.from_oauth_session(mock_session)
        assert provider._auth_session is mock_session
        assert provider._config.api_key == "oauth-session"
        assert provider._config.api_base_url == "https://api.debugg.ai"

    def test_from_oauth_session_custom_url(self, mock_session):
        provider = DebuggAIProvider.from_oauth_session(
            mock_session, api_base_url="https://staging.debugg.ai"
        )
        assert provider.api_base_url == "https://staging.debugg.ai"

    def test_auth_session_kwarg(self, mock_session):
        provider = DebuggAIProvider(auth_session=mock_session)
        assert provider._auth_session is mock_session

    def test_no_auth_method_raises(self):
        with pytest.raises(ValueError, match="Either 'client', 'api_key', or 'auth_session'"):
            DebuggAIProvider()


# =============================================================================
# _api_request with OAuth session
# =============================================================================


class TestApiRequestOAuth:

    def test_uses_session_for_get(self, mock_session):
        provider = DebuggAIProvider(auth_session=mock_session)
        mock_session.request.return_value = {"status": "ok"}

        result = provider._api_request("GET", "/health")

        mock_session.request.assert_called_once_with(
            "GET", "https://api.debugg.ai/health", data=None, params=None
        )
        assert result == {"status": "ok"}

    def test_uses_session_for_post(self, mock_session):
        provider = DebuggAIProvider(auth_session=mock_session)
        mock_session.request.return_value = {"created": True}

        result = provider._api_request("POST", "/cli/e2e/suites", data={"name": "test"})

        mock_session.request.assert_called_once_with(
            "POST", "https://api.debugg.ai/cli/e2e/suites",
            data={"name": "test"}, params=None,
        )
        assert result == {"created": True}

    def test_uses_session_with_params(self, mock_session):
        provider = DebuggAIProvider(auth_session=mock_session)
        mock_session.request.return_value = {"results": []}

        provider._api_request("GET", "/suites", params={"status": "completed"})

        mock_session.request.assert_called_once_with(
            "GET", "https://api.debugg.ai/suites",
            data=None, params={"status": "completed"},
        )


# =============================================================================
# _download_file with OAuth session
# =============================================================================


class TestDownloadFileOAuth:

    def test_download_uses_session_token(self, mock_session, tmp_path):
        provider = DebuggAIProvider(auth_session=mock_session)
        out_file = tmp_path / "test.js"

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = b"console.log('test');"
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = provider._download_file("https://cdn.example.com/test.js", out_file)

        assert result is True
        assert out_file.read_bytes() == b"console.log('test');"
        mock_session.get_token.assert_called_once()

        req = mock_urlopen.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer oauth_tok"

    def test_download_failure_returns_false(self, mock_session, tmp_path):
        provider = DebuggAIProvider(auth_session=mock_session)
        out_file = tmp_path / "test.js"

        with patch("urllib.request.urlopen", side_effect=Exception("network error")):
            result = provider._download_file("https://cdn.example.com/test.js", out_file)

        assert result is False


# =============================================================================
# Backward compatibility
# =============================================================================


class TestBackwardCompatibility:

    def test_api_key_still_works(self):
        provider = DebuggAIProvider(api_key="sk_test_123")
        assert provider._auth_session is None
        assert provider.api_key == "sk_test_123"

    def test_api_key_request_no_session(self):
        provider = DebuggAIProvider(api_key="sk_test_123")

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = b'{"ok": true}'
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = provider._api_request("GET", "/health")

        assert result == {"ok": True}
        req = mock_urlopen.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer sk_test_123"
