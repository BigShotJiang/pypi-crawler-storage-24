"""Tests for the systemeval validation framework."""

from dataclasses import dataclass

import pytest

from systemeval.validation import BaseValidator, Rule, ValidationResult


# =============================================================================
# ValidationResult Tests
# =============================================================================


class TestValidationResult:

    def test_ok_result(self):
        r = ValidationResult.ok()
        assert r.valid is True
        assert r.errors == []
        assert r.warnings == []

    def test_error_result(self):
        r = ValidationResult.error("something broke")
        assert r.valid is False
        assert r.errors == ["something broke"]
        assert r.warnings == []

    def test_warning_result(self):
        r = ValidationResult.warning("watch out")
        assert r.valid is True
        assert r.errors == []
        assert r.warnings == ["watch out"]

    def test_merge_two_ok(self):
        a = ValidationResult.ok()
        b = ValidationResult.ok()
        a.merge(b)
        assert a.valid is True
        assert a.errors == []

    def test_merge_ok_with_error(self):
        a = ValidationResult.ok()
        b = ValidationResult.error("bad")
        a.merge(b)
        assert a.valid is False
        assert a.errors == ["bad"]

    def test_merge_error_with_ok(self):
        a = ValidationResult.error("first")
        b = ValidationResult.ok()
        a.merge(b)
        assert a.valid is False
        assert a.errors == ["first"]

    def test_merge_accumulates_errors(self):
        a = ValidationResult.error("e1")
        b = ValidationResult.error("e2")
        a.merge(b)
        assert a.errors == ["e1", "e2"]

    def test_merge_accumulates_warnings(self):
        a = ValidationResult.warning("w1")
        b = ValidationResult.warning("w2")
        a.merge(b)
        assert a.warnings == ["w1", "w2"]
        assert a.valid is True

    def test_merge_combines_metadata(self):
        a = ValidationResult(valid=True, metadata={"a": 1})
        b = ValidationResult(valid=True, metadata={"b": 2})
        a.merge(b)
        assert a.metadata == {"a": 1, "b": 2}

    def test_merge_returns_self(self):
        a = ValidationResult.ok()
        b = ValidationResult.ok()
        result = a.merge(b)
        assert result is a

    def test_to_dict(self):
        r = ValidationResult(
            valid=False,
            errors=["e1"],
            warnings=["w1"],
            metadata={"k": "v"},
        )
        d = r.to_dict()
        assert d == {
            "valid": False,
            "errors": ["e1"],
            "warnings": ["w1"],
            "metadata": {"k": "v"},
        }

    def test_custom_construction(self):
        r = ValidationResult(
            valid=True,
            errors=[],
            warnings=["minor"],
            metadata={"checked_at": "2026-01-01"},
        )
        assert r.valid is True
        assert r.warnings == ["minor"]


# =============================================================================
# Rule Tests
# =============================================================================


class TestRule:

    def test_rule_creation(self):
        rule = Rule(
            name="test_rule",
            check=lambda t: ValidationResult.ok(),
            description="A test rule",
        )
        assert rule.name == "test_rule"
        assert rule.description == "A test rule"

    def test_rule_check_callable(self):
        rule = Rule(
            name="always_fail",
            check=lambda t: ValidationResult.error(f"failed for {t}"),
        )
        result = rule.check("myobj")
        assert result.valid is False
        assert "myobj" in result.errors[0]

    def test_rule_default_description(self):
        rule = Rule(name="x", check=lambda t: ValidationResult.ok())
        assert rule.description == ""


# =============================================================================
# BaseValidator Tests (via concrete subclass)
# =============================================================================


@dataclass
class SampleConfig:
    """Test target for validation."""
    name: str = ""
    count: int = 0
    url: str = ""


class SampleValidator(BaseValidator):
    """Concrete validator for testing."""

    def get_rules(self):
        return [
            Rule("name_required", self._check_name, "Name must be non-empty"),
            Rule("count_positive", self._check_count, "Count must be positive"),
        ]

    def _check_name(self, config: SampleConfig) -> ValidationResult:
        if not config.name:
            return ValidationResult.error("name is required")
        return ValidationResult.ok()

    def _check_count(self, config: SampleConfig) -> ValidationResult:
        if config.count < 0:
            return ValidationResult.error(f"count must be >= 0, got {config.count}")
        if config.count == 0:
            return ValidationResult.warning("count is zero")
        return ValidationResult.ok()


class TestBaseValidator:

    def test_validate_all_pass(self):
        v = SampleValidator()
        result = v.validate(SampleConfig(name="test", count=5))
        assert result.valid is True
        assert result.errors == []

    def test_validate_single_error(self):
        v = SampleValidator()
        result = v.validate(SampleConfig(name="", count=5))
        assert result.valid is False
        assert len(result.errors) == 1
        assert "name is required" in result.errors[0]

    def test_validate_multiple_errors(self):
        v = SampleValidator()
        result = v.validate(SampleConfig(name="", count=-1))
        assert result.valid is False
        assert len(result.errors) == 2

    def test_validate_warning(self):
        v = SampleValidator()
        result = v.validate(SampleConfig(name="ok", count=0))
        assert result.valid is True
        assert len(result.warnings) == 1
        assert "count is zero" in result.warnings[0]

    def test_strict_mode_promotes_warnings(self):
        v = SampleValidator(strict_mode=True)
        result = v.validate(SampleConfig(name="ok", count=0))
        assert result.valid is False
        assert len(result.errors) == 1
        assert "count is zero" in result.errors[0]
        assert result.warnings == []

    def test_strict_mode_no_warnings_ok(self):
        v = SampleValidator(strict_mode=True)
        result = v.validate(SampleConfig(name="ok", count=5))
        assert result.valid is True

    def test_validate_one_by_name(self):
        v = SampleValidator()
        result = v.validate_one("name_required", SampleConfig(name="test"))
        assert result.valid is True

    def test_validate_one_error(self):
        v = SampleValidator()
        result = v.validate_one("name_required", SampleConfig(name=""))
        assert result.valid is False

    def test_validate_one_unknown_raises(self):
        v = SampleValidator()
        with pytest.raises(KeyError, match="no_such_rule"):
            v.validate_one("no_such_rule", SampleConfig())

    def test_list_rules(self):
        v = SampleValidator()
        names = v.list_rules()
        assert names == ["name_required", "count_positive"]


# =============================================================================
# Empty validator
# =============================================================================


class EmptyValidator(BaseValidator):
    def get_rules(self):
        return []


class TestEmptyValidator:

    def test_no_rules_passes(self):
        v = EmptyValidator()
        result = v.validate("anything")
        assert result.valid is True

    def test_no_rules_strict_passes(self):
        v = EmptyValidator(strict_mode=True)
        result = v.validate("anything")
        assert result.valid is True

    def test_list_rules_empty(self):
        v = EmptyValidator()
        assert v.list_rules() == []


# =============================================================================
# Chaining merge
# =============================================================================


class TestMergeChaining:

    def test_chain_three_results(self):
        r = (
            ValidationResult.ok()
            .merge(ValidationResult.warning("w1"))
            .merge(ValidationResult.error("e1"))
            .merge(ValidationResult.warning("w2"))
        )
        assert r.valid is False
        assert r.errors == ["e1"]
        assert r.warnings == ["w1", "w2"]
