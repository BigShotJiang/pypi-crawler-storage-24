"""Tests for OAuth 2.0 Device Authorization Flow client."""

import json
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from systemeval.auth.oauth_client import (
    DeviceAuthorizationResponse,
    DeviceFlowClient,
    OAuthError,
)
from systemeval.auth.token_storage import TokenData, TokenStorage
from systemeval.config.e2e import OAuthConfig


@pytest.fixture
def oauth_config():
    """Create a test OAuthConfig for device flow."""
    return OAuthConfig(
        client_id="test-client-id",
        token_endpoint="https://auth.example.com/oauth/token",
        device_authorization_endpoint="https://auth.example.com/oauth/device/code",
        scopes=["e2e:read", "e2e:write"],
    )


@pytest.fixture
def storage(tmp_path):
    """Create a test TokenStorage."""
    return TokenStorage(path=tmp_path / "tokens.json")


@pytest.fixture
def client(oauth_config, storage):
    """Create a DeviceFlowClient with test config."""
    return DeviceFlowClient(oauth_config, storage=storage, provider_key="test")


# =============================================================================
# OAuthError Tests
# =============================================================================


class TestOAuthError:

    def test_error_with_description(self):
        err = OAuthError("invalid_grant", "Token expired")
        assert err.error == "invalid_grant"
        assert err.description == "Token expired"
        assert "invalid_grant" in str(err)
        assert "Token expired" in str(err)

    def test_error_without_description(self):
        err = OAuthError("server_error")
        assert err.error == "server_error"
        assert str(err) == "server_error"


# =============================================================================
# DeviceAuthorizationResponse Tests
# =============================================================================


class TestDeviceAuthorizationResponse:

    def test_minimal_response(self):
        resp = DeviceAuthorizationResponse({
            "device_code": "dev123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://auth.example.com/device",
        })
        assert resp.device_code == "dev123"
        assert resp.user_code == "ABCD-1234"
        assert resp.verification_uri == "https://auth.example.com/device"
        assert resp.verification_uri_complete is None
        assert resp.expires_in == 600
        assert resp.interval == 5

    def test_full_response(self):
        resp = DeviceAuthorizationResponse({
            "device_code": "dev123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://auth.example.com/device",
            "verification_uri_complete": "https://auth.example.com/device?code=ABCD-1234",
            "expires_in": 300,
            "interval": 10,
        })
        assert resp.verification_uri_complete == "https://auth.example.com/device?code=ABCD-1234"
        assert resp.expires_in == 300
        assert resp.interval == 10


# =============================================================================
# DeviceFlowClient.get_cached_token Tests
# =============================================================================


class TestGetCachedToken:

    def test_returns_none_when_no_token(self, client):
        assert client.get_cached_token() is None

    def test_returns_valid_cached_token(self, client, storage):
        token = TokenData(
            access_token="valid_tok",
            expires_at=time.time() + 3600,
        )
        storage.save("test", token)

        cached = client.get_cached_token()
        assert cached is not None
        assert cached.access_token == "valid_tok"

    def test_returns_none_for_expired_no_refresh(self, client, storage):
        token = TokenData(
            access_token="expired_tok",
            expires_at=time.time() - 100,
        )
        storage.save("test", token)

        assert client.get_cached_token() is None

    def test_refreshes_expired_token(self, client, storage):
        old_token = TokenData(
            access_token="old_tok",
            expires_at=time.time() - 100,
            refresh_token="ref_tok",
        )
        storage.save("test", old_token)

        refreshed_response = {
            "access_token": "new_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "new_ref",
        }

        with patch.object(client, "_post", return_value=refreshed_response):
            cached = client.get_cached_token()

        assert cached is not None
        assert cached.access_token == "new_tok"

    def test_returns_none_if_refresh_fails(self, client, storage):
        old_token = TokenData(
            access_token="old_tok",
            expires_at=time.time() - 100,
            refresh_token="bad_ref",
        )
        storage.save("test", old_token)

        with patch.object(client, "_post", side_effect=OAuthError("invalid_grant")):
            assert client.get_cached_token() is None


# =============================================================================
# DeviceFlowClient.request_device_code Tests
# =============================================================================


class TestRequestDeviceCode:

    def test_request_device_code(self, client):
        mock_response = {
            "device_code": "dev_abc",
            "user_code": "WXYZ-1234",
            "verification_uri": "https://auth.example.com/device",
            "expires_in": 900,
            "interval": 5,
        }

        with patch.object(client, "_post", return_value=mock_response) as mock_post:
            resp = client.request_device_code()

        assert resp.device_code == "dev_abc"
        assert resp.user_code == "WXYZ-1234"

        mock_post.assert_called_once_with(
            "https://auth.example.com/oauth/device/code",
            {
                "client_id": "test-client-id",
                "scope": "e2e:read e2e:write",
            },
        )

    def test_request_device_code_no_endpoint(self, storage):
        config = OAuthConfig(
            client_id="test",
            token_endpoint="https://auth.example.com/token",
        )
        client = DeviceFlowClient(config, storage=storage)

        with pytest.raises(OAuthError, match="device_authorization_endpoint"):
            client.request_device_code()


# =============================================================================
# DeviceFlowClient.poll_for_token Tests
# =============================================================================


class TestPollForToken:

    def test_poll_immediate_success(self, client, storage):
        token_response = {
            "access_token": "final_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "ref_final",
        }

        with patch.object(client, "_post", return_value=token_response):
            token = client.poll_for_token("dev_code", interval=0, timeout=10)

        assert token.access_token == "final_tok"
        # Token should be saved
        saved = storage.load("test")
        assert saved.access_token == "final_tok"

    def test_poll_authorization_pending_then_success(self, client):
        pending = OAuthError("authorization_pending", "Waiting for user")
        success = {
            "access_token": "tok_after_wait",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", side_effect=[pending, success]):
            with patch("time.sleep"):
                token = client.poll_for_token("dev_code", interval=0, timeout=30)

        assert token.access_token == "tok_after_wait"

    def test_poll_slow_down_increases_interval(self, client):
        slow_down = OAuthError("slow_down", "Too fast")
        success = {
            "access_token": "tok",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        sleep_calls = []

        def track_sleep(seconds):
            sleep_calls.append(seconds)

        with patch.object(client, "_post", side_effect=[slow_down, success]):
            with patch("time.sleep", side_effect=track_sleep):
                client.poll_for_token("dev_code", interval=5, timeout=30)

        # After slow_down, interval should increase by 5
        assert sleep_calls[0] == 10

    def test_poll_expired_token_raises(self, client):
        expired = OAuthError("expired_token", "Code expired")

        with patch.object(client, "_post", side_effect=expired):
            with pytest.raises(OAuthError, match="expired"):
                client.poll_for_token("dev_code", interval=0, timeout=10)

    def test_poll_access_denied_raises(self, client):
        denied = OAuthError("access_denied", "User denied")

        with patch.object(client, "_post", side_effect=denied):
            with pytest.raises(OAuthError, match="denied"):
                client.poll_for_token("dev_code", interval=0, timeout=10)

    def test_poll_timeout(self, client):
        pending = OAuthError("authorization_pending", "Still waiting")

        with patch.object(client, "_post", side_effect=pending):
            with patch("time.sleep"):
                with patch("time.time", side_effect=[0, 0, 100]):
                    with pytest.raises(OAuthError, match="timeout"):
                        client.poll_for_token("dev_code", interval=0, timeout=1)


# =============================================================================
# DeviceFlowClient.logout Tests
# =============================================================================


class TestLogout:

    def test_logout_removes_token(self, client, storage):
        storage.save("test", TokenData(access_token="tok"))
        assert client.logout() is True
        assert storage.load("test") is None

    def test_logout_no_token(self, client):
        assert client.logout() is False


# =============================================================================
# DeviceFlowClient._refresh_token Tests
# =============================================================================


class TestRefreshToken:

    def test_refresh_preserves_old_refresh_token(self, client):
        response = {
            "access_token": "new_access",
            "token_type": "Bearer",
            "expires_in": 3600,
            # No refresh_token in response
        }

        with patch.object(client, "_post", return_value=response):
            token = client._refresh_token("old_refresh")

        assert token.access_token == "new_access"
        assert token.refresh_token == "old_refresh"  # Preserved

    def test_refresh_uses_new_refresh_token(self, client):
        response = {
            "access_token": "new_access",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "new_refresh",
        }

        with patch.object(client, "_post", return_value=response):
            token = client._refresh_token("old_refresh")

        assert token.refresh_token == "new_refresh"

    def test_refresh_sends_correct_params(self, client):
        response = {
            "access_token": "tok",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", return_value=response) as mock_post:
            client._refresh_token("my_refresh_tok")

        mock_post.assert_called_once_with(
            "https://auth.example.com/oauth/token",
            {
                "grant_type": "refresh_token",
                "refresh_token": "my_refresh_tok",
                "client_id": "test-client-id",
            },
        )
