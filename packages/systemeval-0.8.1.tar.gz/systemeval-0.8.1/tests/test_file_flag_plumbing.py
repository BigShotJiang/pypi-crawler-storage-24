"""Tests proving -f/--file flag is broken across all execution paths.

These tests verify that passing -f/--file to `systemeval test` actually
reaches the adapter layer. Currently all tests FAIL because file_path
is captured by Click but never plumbed through to any execution path.

Related beads: systemeval-ax4, systemeval-9cc, systemeval-anq, systemeval-x02, systemeval-79f
"""

import pytest
from click.testing import CliRunner
from unittest.mock import patch, MagicMock, call

from systemeval.cli.commands.test_commands import test as test_command
from systemeval.adapters import TestResult


def _make_mock_config(tmp_path, adapter="pytest", environments=None, categories=None):
    """Create a mock SystemEvalConfig."""
    mock_config = MagicMock()
    mock_config.adapter = adapter
    mock_config.project_root = tmp_path
    mock_config.environments = environments
    mock_config.is_multi_project = False
    mock_config.categories = categories or {}
    mock_config.playwright_config = None
    mock_config.surfer_config = None
    return mock_config


def _make_mock_adapter(tests_to_discover=None):
    """Create a mock adapter with discover/execute methods."""
    mock_adapter = MagicMock()
    mock_adapter.validate_environment.return_value = True
    mock_adapter.discover.return_value = tests_to_discover or []
    mock_adapter.execute.return_value = TestResult(
        passed=1, failed=0, errors=0, skipped=0, duration=0.5
    )
    return mock_adapter


class TestFilePathLegacyAdapter:
    """Test -f flag plumbing through the legacy adapter path."""

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    def test_file_flag_reaches_adapter_discover(
        self, mock_detect, mock_get_adapter, mock_load, mock_find, tmp_path
    ):
        """Passing -f should cause adapter.discover(file='test_foo.py') to be called."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file
        mock_load.return_value = _make_mock_config(tmp_path)
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        mock_detect.return_value = DockerDetectionResult(mode=DockerMode.LOCAL_ONLY, reason="test")

        mock_adapter = _make_mock_adapter()
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(test_command, ["-f", "test_specific.py"])

        # The adapter's discover() should be called with file='test_specific.py'
        mock_adapter.discover.assert_called_once()
        discover_call = mock_adapter.discover.call_args
        assert discover_call.kwargs.get("file") == "test_specific.py" or \
            (len(discover_call.args) >= 3 and discover_call.args[2] == "test_specific.py"), \
            f"adapter.discover() was not called with file='test_specific.py'. Call was: {discover_call}"

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    def test_file_flag_reaches_adapter_execute(
        self, mock_detect, mock_get_adapter, mock_load, mock_find, tmp_path
    ):
        """Passing -f should pass discovered tests to adapter.execute(tests=...)."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file
        mock_load.return_value = _make_mock_config(tmp_path)
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        mock_detect.return_value = DockerDetectionResult(mode=DockerMode.LOCAL_ONLY, reason="test")

        mock_test_item = MagicMock()
        mock_test_item.path = "test_specific.py"
        mock_adapter = _make_mock_adapter(tests_to_discover=[mock_test_item])
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(test_command, ["-f", "test_specific.py"])

        # The adapter's execute() should receive the discovered tests, not None
        mock_adapter.execute.assert_called_once()
        execute_call = mock_adapter.execute.call_args
        tests_arg = execute_call.kwargs.get("tests") or (execute_call.args[0] if execute_call.args else None)
        assert tests_arg is not None, \
            f"adapter.execute() was called with tests=None. -f flag was ignored. Call: {execute_call}"
        assert tests_arg == [mock_test_item], \
            f"adapter.execute() got wrong tests: {tests_arg}"


class TestAppFlagLegacyAdapter:
    """Test --app flag plumbing through the legacy adapter path."""

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    def test_app_flag_reaches_adapter_discover(
        self, mock_detect, mock_get_adapter, mock_load, mock_find, tmp_path
    ):
        """Passing --app should cause adapter.discover(app='myapp') to be called."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file
        mock_load.return_value = _make_mock_config(tmp_path)
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        mock_detect.return_value = DockerDetectionResult(mode=DockerMode.LOCAL_ONLY, reason="test")

        mock_adapter = _make_mock_adapter()
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(test_command, ["--app", "myapp"])

        mock_adapter.discover.assert_called_once()
        discover_call = mock_adapter.discover.call_args
        assert discover_call.kwargs.get("app") == "myapp" or \
            (len(discover_call.args) >= 2 and discover_call.args[1] == "myapp"), \
            f"adapter.discover() was not called with app='myapp'. Call was: {discover_call}"


class TestFilePathBrowserPath:
    """Test -f flag plumbing through the browser test path."""

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.run_browser_tests")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    def test_file_flag_reaches_browser_env(
        self, mock_detect, mock_run_browser, mock_load, mock_find, tmp_path
    ):
        """Passing -f with --browser should pass file_path through to browser tests."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file

        mock_config = _make_mock_config(tmp_path)
        mock_config.playwright_config = MagicMock()
        mock_config.playwright_config.config_file = "playwright.config.ts"
        mock_config.playwright_config.project = None
        mock_config.playwright_config.headed = False
        mock_config.playwright_config.timeout = 30000
        mock_load.return_value = mock_config
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        mock_detect.return_value = DockerDetectionResult(mode=DockerMode.LOCAL_ONLY, reason="test")

        mock_run_browser.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=1.0
        )

        runner = CliRunner()
        result = runner.invoke(test_command, ["--browser", "-f", "test_e2e_login.py"])

        # run_browser_tests receives opts - check that opts.selection.file_path is set
        mock_run_browser.assert_called_once()
        call_kwargs = mock_run_browser.call_args
        opts = call_kwargs.kwargs.get("opts") or call_kwargs.args[1]
        assert opts.selection.file_path == "test_e2e_login.py", \
            f"Browser tests didn't receive file_path. Got: {opts.selection.file_path}"

    @patch("systemeval.cli_helpers.BrowserEnvironment")
    def test_browser_env_run_tests_passes_file_path(self, MockBrowserEnv):
        """BrowserEnvironment.run_tests should accept and use file_path."""
        from systemeval.cli_helpers import run_browser_tests
        from systemeval.types import TestCommandOptions

        mock_env = MagicMock()
        mock_env.tunnel_url = None
        mock_env.server_url = None
        mock_env.timings = MagicMock()
        mock_env.run_tests.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.5
        )
        MockBrowserEnv.return_value = mock_env

        mock_config = MagicMock()
        mock_config.project_root = MagicMock()
        mock_config.project_root.absolute.return_value = "/tmp/test"
        mock_config.playwright_config = MagicMock()
        mock_config.playwright_config.config_file = "playwright.config.ts"
        mock_config.playwright_config.project = None
        mock_config.playwright_config.headed = False
        mock_config.playwright_config.timeout = 30000
        mock_config.surfer_config = None

        opts = TestCommandOptions.from_cli_args(
            browser=True,
            file_path="test_e2e_login.py",
            category="e2e",
        )

        result = run_browser_tests(test_config=mock_config, opts=opts)

        # run_tests should be called with file_path
        mock_env.run_tests.assert_called_once()
        run_call = mock_env.run_tests.call_args
        # Check that file_path was passed (currently it won't be)
        assert "file_path" in run_call.kwargs or \
            (len(run_call.args) >= 4), \
            f"BrowserEnvironment.run_tests() not called with file_path. Call: {run_call}"


class TestFilePathDockerComposePath:
    """Test -f flag plumbing through Docker Compose environment path."""

    def test_build_test_command_accepts_file_path(self):
        """build_test_command() should accept and append file_path to pytest commands."""
        from systemeval.utils.commands import build_test_command

        # This should add the file path to the pytest command
        result = build_test_command("pytest", file_path="tests/test_specific.py")
        assert "tests/test_specific.py" in result, \
            f"build_test_command() didn't include file_path. Got: {result}"

    def test_build_test_command_with_category_and_file(self):
        """build_test_command() should support both category and file_path."""
        from systemeval.utils.commands import build_test_command

        result = build_test_command(
            "pytest", category="unit", file_path="tests/test_auth.py"
        )
        assert "tests/test_auth.py" in result, \
            f"build_test_command() didn't include file_path. Got: {result}"
        assert "-m unit" in result, \
            f"build_test_command() didn't include category. Got: {result}"

    def test_docker_compose_run_tests_accepts_file_path(self):
        """DockerComposeEnvironment.run_tests() should accept file_path parameter."""
        from systemeval.environments.implementations.docker_compose import DockerComposeEnvironment
        import inspect

        sig = inspect.signature(DockerComposeEnvironment.run_tests)
        params = list(sig.parameters.keys())
        assert "file_path" in params, \
            f"DockerComposeEnvironment.run_tests() missing file_path param. Has: {params}"

    def test_environment_base_run_tests_accepts_file_path(self):
        """Environment base class run_tests() should accept file_path parameter."""
        from systemeval.environments.base import Environment
        import inspect

        sig = inspect.signature(Environment.run_tests)
        params = list(sig.parameters.keys())
        assert "file_path" in params, \
            f"Environment.run_tests() missing file_path param. Has: {params}"


class TestFilePathEnvironmentPath:
    """Test -f flag plumbing through _run_with_environment path."""

    @patch("systemeval.environments.EnvironmentResolver")
    def test_file_flag_reaches_environment_run_tests(self, MockResolver, tmp_path):
        """Passing -f with --env should pass file_path to env.run_tests()."""
        from systemeval.types.options import TestCommandOptions
        from systemeval.cli.commands.test_commands import _run_with_environment

        mock_env = MagicMock()
        mock_env.env_type = MagicMock()
        mock_env.env_type.value = "docker-compose"
        mock_env.setup.return_value = MagicMock(success=True, duration=1.0)
        mock_env.wait_ready.return_value = True
        mock_env.timings = MagicMock()
        mock_env.timings.health_check = 1.0
        mock_env.timings.cleanup = 0.5
        mock_env.run_tests.return_value = TestResult(
            passed=1, failed=0, errors=0, skipped=0, duration=0.5
        )

        mock_resolver = MagicMock()
        mock_resolver.get_default_environment.return_value = "backend"
        mock_resolver.resolve.return_value = mock_env
        MockResolver.return_value = mock_resolver

        mock_config = _make_mock_config(
            tmp_path,
            environments={"backend": {"type": "docker-compose"}},
        )

        opts = TestCommandOptions.from_cli_args(
            env_name="backend",
            file_path="test_specific.py",
        )

        result = _run_with_environment(mock_config, opts)

        # env.run_tests should be called with file_path
        mock_env.run_tests.assert_called_once()
        run_call = mock_env.run_tests.call_args
        file_path_passed = run_call.kwargs.get("file_path")
        assert file_path_passed == "test_specific.py", \
            f"env.run_tests() not called with file_path='test_specific.py'. Call: {run_call}"


class TestCombinedFilters:
    """Test that -f combined with -c and -a all work together."""

    @patch("systemeval.cli.commands.test_commands.find_config_file")
    @patch("systemeval.cli.commands.test_commands.load_config")
    @patch("systemeval.cli.commands.test_commands.get_adapter")
    @patch("systemeval.cli.commands.test_commands.auto_detect_docker")
    def test_category_app_file_all_reach_discover(
        self, mock_detect, mock_get_adapter, mock_load, mock_find, tmp_path
    ):
        """Using -c unit -a auth -f test_login.py should pass all three to discover()."""
        config_file = tmp_path / "systemeval.yaml"
        config_file.write_text("adapter: pytest\nproject_root: .")
        mock_find.return_value = config_file
        mock_load.return_value = _make_mock_config(tmp_path)
        from systemeval.utils.docker import DockerDetectionResult, DockerMode
        mock_detect.return_value = DockerDetectionResult(mode=DockerMode.LOCAL_ONLY, reason="test")

        mock_adapter = _make_mock_adapter()
        mock_get_adapter.return_value = mock_adapter

        runner = CliRunner()
        result = runner.invoke(test_command, ["-c", "unit", "-a", "auth", "-f", "test_login.py"])

        mock_adapter.discover.assert_called_once()
        discover_call = mock_adapter.discover.call_args
        assert discover_call.kwargs.get("category") == "unit", \
            f"discover() didn't get category='unit'. Call: {discover_call}"
        assert discover_call.kwargs.get("app") == "auth", \
            f"discover() didn't get app='auth'. Call: {discover_call}"
        assert discover_call.kwargs.get("file") == "test_login.py", \
            f"discover() didn't get file='test_login.py'. Call: {discover_call}"
