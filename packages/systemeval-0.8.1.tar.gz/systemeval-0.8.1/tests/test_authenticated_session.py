"""Tests for AuthenticatedSession with auto-refresh and 401 retry."""

import json
import time
import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from systemeval.auth.oauth_client import BaseOAuthClient, OAuthError
from systemeval.auth.session import AuthenticatedSession
from systemeval.auth.token_storage import TokenData, TokenStorage
from systemeval.config.e2e import OAuthConfig


@pytest.fixture
def oauth_config():
    return OAuthConfig(
        client_id="test-client",
        token_endpoint="https://auth.example.com/oauth/token",
    )


@pytest.fixture
def storage(tmp_path):
    return TokenStorage(path=tmp_path / "tokens.json")


@pytest.fixture
def oauth_client(oauth_config, storage):
    return BaseOAuthClient(oauth_config, storage=storage, provider_key="test")


@pytest.fixture
def valid_token():
    return TokenData(access_token="valid_tok", expires_at=time.time() + 3600)


@pytest.fixture
def expired_token():
    return TokenData(access_token="expired_tok", expires_at=time.time() - 100)


# =============================================================================
# AuthenticatedSession.get_token Tests
# =============================================================================


class TestGetToken:

    def test_returns_cached_token(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)
        token = session.get_token()
        assert token.access_token == "valid_tok"

    def test_re_authenticates_when_no_cache(self, oauth_client):
        fresh = TokenData(access_token="fresh_tok", expires_at=time.time() + 3600)
        re_auth = MagicMock(return_value=fresh)
        session = AuthenticatedSession(oauth_client, re_authenticate=re_auth)

        token = session.get_token()
        assert token.access_token == "fresh_tok"
        re_auth.assert_called_once()

    def test_raises_when_no_token_and_no_re_auth(self, oauth_client):
        session = AuthenticatedSession(oauth_client)
        with pytest.raises(OAuthError, match="no_token"):
            session.get_token()

    def test_refreshes_expired_token(self, oauth_client, storage):
        expired = TokenData(
            access_token="old", expires_at=time.time() - 100, refresh_token="ref"
        )
        storage.save("test", expired)

        refreshed = {
            "access_token": "refreshed_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(oauth_client, "_post", return_value=refreshed):
            session = AuthenticatedSession(oauth_client)
            token = session.get_token()

        assert token.access_token == "refreshed_tok"


# =============================================================================
# AuthenticatedSession.access_token property
# =============================================================================


class TestAccessToken:

    def test_returns_none_when_no_token(self, oauth_client):
        session = AuthenticatedSession(oauth_client)
        assert session.access_token is None

    def test_returns_token_after_get(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)
        session.get_token()
        assert session.access_token == "valid_tok"


# =============================================================================
# AuthenticatedSession.request Tests
# =============================================================================


class TestRequest:

    def test_successful_request(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        response_data = {"result": "ok"}

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = json.dumps(response_data).encode()
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = session.request("GET", "https://api.example.com/test")

        assert result == {"result": "ok"}

    def test_request_adds_authorization_header(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = b'{"ok": true}'
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            session.request("GET", "https://api.example.com/test")

        req = mock_urlopen.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer valid_tok"

    def test_request_with_params(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = b'{"ok": true}'
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            session.request("GET", "https://api.example.com/test", params={"page": "1"})

        req = mock_urlopen.call_args[0][0]
        assert "page=1" in req.full_url

    def test_request_with_json_body(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = b'{"created": true}'
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            session.request("POST", "https://api.example.com/data", data={"name": "test"})

        req = mock_urlopen.call_args[0][0]
        assert req.data == json.dumps({"name": "test"}).encode("utf-8")

    def test_retries_on_401(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        re_auth = MagicMock(return_value=TokenData(
            access_token="new_tok", expires_at=time.time() + 3600
        ))
        session = AuthenticatedSession(oauth_client, re_authenticate=re_auth)

        # First call gets 401, retry succeeds
        http_401 = urllib.error.HTTPError(
            "https://api.example.com/test", 401, "Unauthorized", {}, None
        )

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise http_401
            mock_resp = MagicMock()
            mock_resp.read.return_value = b'{"retried": true}'
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=side_effect):
            result = session.request("GET", "https://api.example.com/test")

        assert result == {"retried": True}
        assert call_count == 2
        re_auth.assert_called_once()

    def test_non_401_error_not_retried(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        http_500 = urllib.error.HTTPError(
            "https://api.example.com/test", 500, "Server Error", {}, None
        )

        with patch("urllib.request.urlopen", side_effect=http_500):
            with pytest.raises(urllib.error.HTTPError) as exc_info:
                session.request("GET", "https://api.example.com/test")
            assert exc_info.value.code == 500

    def test_connection_error_raises(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("Connection refused")):
            with pytest.raises(OAuthError, match="connection_error"):
                session.request("GET", "https://api.example.com/test")

    def test_401_with_no_re_auth_raises(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        http_401 = urllib.error.HTTPError(
            "https://api.example.com/test", 401, "Unauthorized", {}, None
        )

        with patch("urllib.request.urlopen", side_effect=http_401):
            with pytest.raises(OAuthError, match="authentication_required"):
                session.request("GET", "https://api.example.com/test")


# =============================================================================
# AuthenticatedSession with extra headers
# =============================================================================


class TestExtraHeaders:

    def test_custom_headers_added(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client)

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = b'{"ok": true}'
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            session.request(
                "GET", "https://api.example.com/test",
                headers={"X-Custom": "value"},
            )

        req = mock_urlopen.call_args[0][0]
        assert req.get_header("X-custom") == "value"


# =============================================================================
# AuthenticatedSession timeout
# =============================================================================


class TestTimeout:

    def test_custom_timeout(self, oauth_client, storage, valid_token):
        storage.save("test", valid_token)
        session = AuthenticatedSession(oauth_client, timeout=60)

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = MagicMock()
            mock_resp.read.return_value = b'{"ok": true}'
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            session.request("GET", "https://api.example.com/test")

        _, kwargs = mock_urlopen.call_args
        assert kwargs["timeout"] == 60
