"""Tests for E2E OAuth CLI flags and auth subcommands."""

import time
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

from systemeval.cli.commands.e2e_commands import e2e

# Patch target for TokenStorage — where it's imported from in the helper functions
_TS_PATCH = "systemeval.auth.token_storage.TokenStorage"


@pytest.fixture
def runner():
    return CliRunner()


def _make_storage(tmp_path):
    """Create a real TokenStorage pointing to tmp_path."""
    from systemeval.auth.token_storage import TokenStorage
    return TokenStorage(path=tmp_path / "tokens.json")


# =============================================================================
# --oauth-logout flag on e2e run
# =============================================================================


class TestOAuthLogoutFlag:

    def test_logout_clears_tokens(self, runner, tmp_path):
        from systemeval.auth.token_storage import TokenData

        storage = _make_storage(tmp_path)
        storage.save("debuggai", TokenData(access_token="tok"))

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["run", "--oauth-logout"])

        assert result.exit_code == 0
        assert "Removed" in result.output
        assert storage.list_providers() == []

    def test_logout_no_tokens(self, runner, tmp_path):
        storage = _make_storage(tmp_path)

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["run", "--oauth-logout"])

        assert result.exit_code == 0
        assert "No OAuth tokens" in result.output


# =============================================================================
# Mutual exclusivity of OAuth flags
# =============================================================================


class TestOAuthFlagExclusivity:

    def test_multiple_oauth_flags_rejected(self, runner):
        result = runner.invoke(e2e, ["run", "--oauth", "--oauth-browser"])
        assert result.exit_code == 2
        assert "Only one OAuth method" in result.output

    def test_oauth_and_client_creds_rejected(self, runner):
        result = runner.invoke(e2e, ["run", "--oauth", "--oauth-client-credentials"])
        assert result.exit_code == 2
        assert "Only one OAuth method" in result.output


# =============================================================================
# --oauth flag (device flow)
# =============================================================================


class TestOAuthDeviceFlag:

    def test_device_flow_no_config_errors(self, runner):
        with patch(
            "systemeval.cli.commands.e2e_commands._load_oauth_config",
            return_value=None,
        ):
            result = runner.invoke(e2e, ["run", "--oauth"])

        assert result.exit_code == 2
        assert "No OAuth configuration" in result.output

    def test_device_flow_uses_cached_token(self, runner, tmp_path):
        from systemeval.auth.token_storage import TokenData
        from systemeval.config.e2e import OAuthConfig

        oauth_config = OAuthConfig(
            client_id="test",
            token_endpoint="https://auth.example.com/token",
            device_authorization_endpoint="https://auth.example.com/device/code",
        )
        storage = _make_storage(tmp_path)
        storage.save("debuggai", TokenData(
            access_token="cached_device_tok", expires_at=time.time() + 3600
        ))

        with patch(
            "systemeval.cli.commands.e2e_commands._load_oauth_config",
            return_value=oauth_config,
        ):
            with patch(_TS_PATCH, return_value=storage):
                # Will get past auth and fail at config loading
                result = runner.invoke(e2e, ["run", "--oauth"])

        # Exit code 2 = got past OAuth auth, failed at config loading
        assert result.exit_code == 2
        assert "No OAuth configuration" not in result.output


# =============================================================================
# e2e auth login
# =============================================================================


class TestAuthLogin:

    def test_login_device_with_cached_token(self, runner, tmp_path):
        from systemeval.auth.token_storage import TokenData
        from systemeval.config.e2e import OAuthConfig

        oauth_config = OAuthConfig(
            client_id="test",
            token_endpoint="https://auth.example.com/token",
            device_authorization_endpoint="https://auth.example.com/device/code",
        )
        storage = _make_storage(tmp_path)
        storage.save("debuggai", TokenData(
            access_token="cached_tok", expires_at=time.time() + 3600
        ))

        with patch(
            "systemeval.cli.commands.e2e_commands._load_oauth_config",
            return_value=oauth_config,
        ):
            with patch(_TS_PATCH, return_value=storage):
                result = runner.invoke(e2e, ["auth", "login", "--method", "device"])

        assert result.exit_code == 0
        assert "Logged in" in result.output

    def test_login_no_oauth_config(self, runner):
        with patch(
            "systemeval.cli.commands.e2e_commands._load_oauth_config",
            return_value=None,
        ):
            result = runner.invoke(e2e, ["auth", "login"])

        assert result.exit_code == 2
        assert "No OAuth configuration" in result.output


# =============================================================================
# e2e auth logout
# =============================================================================


class TestAuthLogout:

    def test_auth_logout_clears_tokens(self, runner, tmp_path):
        from systemeval.auth.token_storage import TokenData

        storage = _make_storage(tmp_path)
        storage.save("debuggai", TokenData(access_token="tok"))

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["auth", "logout"])

        assert result.exit_code == 0
        assert "Removed" in result.output

    def test_auth_logout_no_tokens(self, runner, tmp_path):
        storage = _make_storage(tmp_path)

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["auth", "logout"])

        assert result.exit_code == 0
        assert "No OAuth tokens" in result.output


# =============================================================================
# e2e auth status
# =============================================================================


class TestAuthStatus:

    def test_status_no_tokens(self, runner, tmp_path):
        storage = _make_storage(tmp_path)

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["auth", "status"])

        assert result.exit_code == 0
        assert "Not authenticated" in result.output

    def test_status_valid_token(self, runner, tmp_path):
        from systemeval.auth.token_storage import TokenData

        storage = _make_storage(tmp_path)
        storage.save("debuggai", TokenData(
            access_token="valid", expires_at=time.time() + 3600
        ))

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["auth", "status"])

        assert result.exit_code == 0
        assert "authenticated" in result.output

    def test_status_expired_token(self, runner, tmp_path):
        from systemeval.auth.token_storage import TokenData

        storage = _make_storage(tmp_path)
        storage.save("debuggai", TokenData(
            access_token="expired", expires_at=time.time() - 100
        ))

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["auth", "status"])

        assert result.exit_code == 0
        assert "expired" in result.output

    def test_status_expired_with_refresh(self, runner, tmp_path):
        from systemeval.auth.token_storage import TokenData

        storage = _make_storage(tmp_path)
        storage.save("debuggai", TokenData(
            access_token="expired",
            expires_at=time.time() - 100,
            refresh_token="ref_tok",
        ))

        with patch(_TS_PATCH, return_value=storage):
            result = runner.invoke(e2e, ["auth", "status"])

        assert result.exit_code == 0
        assert "has refresh token" in result.output
