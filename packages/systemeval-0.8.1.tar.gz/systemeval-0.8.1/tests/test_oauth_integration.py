"""Integration tests for OAuth 2.0 full flow: config → client → session → provider.

Tests that the complete OAuth pipeline works end-to-end with mocked HTTP.
"""

import json
import time
from unittest.mock import MagicMock, patch

import pytest

from systemeval.auth.oauth_client import (
    AuthorizationCodeClient,
    ClientCredentialsClient,
    DeviceFlowClient,
    OAuthError,
)
from systemeval.auth.session import AuthenticatedSession
from systemeval.auth.token_storage import TokenData, TokenStorage
from systemeval.config.e2e import AuthType, E2EProviderConfig, OAuthConfig


@pytest.fixture
def tmp_storage(tmp_path):
    return TokenStorage(path=tmp_path / "tokens.json")


@pytest.fixture
def oauth_config():
    return OAuthConfig(
        client_id="test-client",
        client_secret="test-secret",
        token_endpoint="https://auth.example.com/oauth/token",
        device_authorization_endpoint="https://auth.example.com/oauth/device/code",
        authorization_endpoint="https://auth.example.com/oauth/authorize",
        scopes=["e2e:read", "e2e:write"],
    )


# =============================================================================
# E2EProviderConfig → OAuthConfig validation integration
# =============================================================================


class TestConfigIntegration:

    def test_api_key_auth_type_backward_compat(self):
        config = E2EProviderConfig(
            provider="debuggai",
            api_key="sk_test_123",
            auth_type=AuthType.API_KEY,
        )
        assert config.api_key == "sk_test_123"
        assert config.oauth is None

    def test_oauth_device_requires_oauth_config(self):
        with pytest.raises(Exception):
            E2EProviderConfig(
                provider="debuggai",
                auth_type=AuthType.OAUTH_DEVICE,
                # Missing oauth config
            )

    def test_oauth_device_with_valid_config(self, oauth_config):
        config = E2EProviderConfig(
            provider="debuggai",
            auth_type=AuthType.OAUTH_DEVICE,
            oauth=oauth_config,
        )
        assert config.oauth.client_id == "test-client"
        assert config.oauth.device_authorization_endpoint is not None

    def test_oauth_client_credentials_with_config(self, oauth_config):
        config = E2EProviderConfig(
            provider="debuggai",
            auth_type=AuthType.OAUTH_CLIENT_CREDENTIALS,
            oauth=oauth_config,
        )
        assert config.oauth.client_secret == "test-secret"


# =============================================================================
# Device Flow → TokenStorage → Session pipeline
# =============================================================================


class TestDeviceFlowPipeline:

    def test_device_flow_stores_and_session_retrieves(self, oauth_config, tmp_storage):
        """Full pipeline: device flow → storage → session → API call."""
        client = DeviceFlowClient(oauth_config, storage=tmp_storage, provider_key="debuggai")

        # Simulate successful device flow authentication
        token_response = {
            "access_token": "device_access_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "device_refresh_tok",
        }

        with patch.object(client, "_post", return_value=token_response):
            token = client.poll_for_token("dev_code", interval=0, timeout=10)

        assert token.access_token == "device_access_tok"

        # Verify token is stored
        stored = tmp_storage.load("debuggai")
        assert stored.access_token == "device_access_tok"

        # Create session from same client — should use cached token
        session = AuthenticatedSession(client)
        cached = session.get_token()
        assert cached.access_token == "device_access_tok"

    def test_device_flow_refresh_cycle(self, oauth_config, tmp_storage):
        """Token expires → refresh → session gets refreshed token."""
        client = DeviceFlowClient(oauth_config, storage=tmp_storage, provider_key="debuggai")

        # Store an expired token with refresh token
        expired = TokenData(
            access_token="expired_tok",
            expires_at=time.time() - 100,
            refresh_token="ref_tok",
        )
        tmp_storage.save("debuggai", expired)

        refreshed = {
            "access_token": "refreshed_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
            "refresh_token": "new_ref_tok",
        }

        with patch.object(client, "_post", return_value=refreshed):
            session = AuthenticatedSession(client)
            token = session.get_token()

        assert token.access_token == "refreshed_tok"

        # Verify new token is stored
        stored = tmp_storage.load("debuggai")
        assert stored.access_token == "refreshed_tok"
        assert stored.refresh_token == "new_ref_tok"


# =============================================================================
# Client Credentials → Session → Provider pipeline
# =============================================================================


class TestClientCredentialsPipeline:

    def test_client_creds_full_pipeline(self, oauth_config, tmp_storage):
        """Client creds → token → session → provider API call."""
        client = ClientCredentialsClient(
            oauth_config, storage=tmp_storage, provider_key="debuggai"
        )

        token_response = {
            "access_token": "cc_tok_123",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", return_value=token_response):
            session = AuthenticatedSession(
                client, re_authenticate=client.authenticate
            )
            token = session.get_token()

        assert token.access_token == "cc_tok_123"

        # Verify provider can use the session
        from systemeval.e2e.providers.debuggai.provider import DebuggAIProvider

        provider = DebuggAIProvider.from_oauth_session(session)
        assert provider._auth_session is session

    def test_client_creds_auto_reauth(self, oauth_config, tmp_storage):
        """Expired token with no refresh → re-authenticate via client creds."""
        client = ClientCredentialsClient(
            oauth_config, storage=tmp_storage, provider_key="debuggai"
        )

        # Store an expired token with no refresh token
        expired = TokenData(access_token="old", expires_at=time.time() - 100)
        tmp_storage.save("debuggai", expired)

        fresh = {
            "access_token": "fresh_cc",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(client, "_post", return_value=fresh):
            session = AuthenticatedSession(
                client, re_authenticate=client.authenticate
            )
            token = session.get_token()

        assert token.access_token == "fresh_cc"


# =============================================================================
# Token isolation between providers
# =============================================================================


class TestProviderIsolation:

    def test_different_provider_keys_isolated(self, oauth_config, tmp_storage):
        """Tokens stored under different keys don't interfere."""
        device_client = DeviceFlowClient(
            oauth_config, storage=tmp_storage, provider_key="device_provider"
        )
        cc_client = ClientCredentialsClient(
            oauth_config, storage=tmp_storage, provider_key="cc_provider"
        )

        device_resp = {
            "access_token": "device_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
        }
        cc_resp = {
            "access_token": "cc_tok",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.object(device_client, "_post", return_value=device_resp):
            device_client.poll_for_token("dev_code", interval=0, timeout=10)

        with patch.object(cc_client, "_post", return_value=cc_resp):
            cc_client.authenticate()

        # Each has its own token
        assert tmp_storage.load("device_provider").access_token == "device_tok"
        assert tmp_storage.load("cc_provider").access_token == "cc_tok"

        # Logout one doesn't affect the other
        device_client.logout()
        assert tmp_storage.load("device_provider") is None
        assert tmp_storage.load("cc_provider").access_token == "cc_tok"


# =============================================================================
# Backward compatibility: API key auth still works
# =============================================================================


class TestBackwardCompatibility:

    def test_api_key_provider_no_oauth(self):
        """Provider with API key doesn't use any OAuth machinery."""
        from systemeval.e2e.providers.debuggai.provider import DebuggAIProvider

        provider = DebuggAIProvider(api_key="sk_test_legacy")
        assert provider._auth_session is None
        assert provider.api_key == "sk_test_legacy"

    def test_api_key_and_oauth_config_coexist(self):
        """Config can have both api_key and oauth, using api_key by default."""
        config = E2EProviderConfig(
            provider="debuggai",
            api_key="sk_test",
            auth_type=AuthType.API_KEY,
        )
        assert config.api_key == "sk_test"
        assert config.oauth is None


# =============================================================================
# Error handling across pipeline
# =============================================================================


class TestErrorPropagation:

    def test_expired_refresh_falls_through(self, oauth_config, tmp_storage):
        """Expired token + failed refresh → re-auth or error."""
        client = DeviceFlowClient(
            oauth_config, storage=tmp_storage, provider_key="debuggai"
        )

        expired = TokenData(
            access_token="old",
            expires_at=time.time() - 100,
            refresh_token="bad_ref",
        )
        tmp_storage.save("debuggai", expired)

        with patch.object(client, "_post", side_effect=OAuthError("invalid_grant")):
            session = AuthenticatedSession(client)
            with pytest.raises(OAuthError, match="no_token"):
                session.get_token()

    def test_expired_refresh_falls_to_reauth(self, oauth_config, tmp_storage):
        """Expired token + failed refresh → re-authenticate succeeds."""
        client = DeviceFlowClient(
            oauth_config, storage=tmp_storage, provider_key="debuggai"
        )

        expired = TokenData(
            access_token="old",
            expires_at=time.time() - 100,
            refresh_token="bad_ref",
        )
        tmp_storage.save("debuggai", expired)

        re_auth_token = TokenData(
            access_token="reauthed", expires_at=time.time() + 3600
        )

        with patch.object(client, "_post", side_effect=OAuthError("invalid_grant")):
            session = AuthenticatedSession(
                client, re_authenticate=lambda: re_auth_token
            )
            token = session.get_token()

        assert token.access_token == "reauthed"
