"""Safe arithmetic expression parser for the 'compute' operation.

Only allows: column references, numeric literals, and basic arithmetic (+, -, *, /, //, %, **).
No function calls, no attribute access, no imports, no string operations.
"""

from __future__ import annotations

import ast
import re
from typing import Any

import numpy as np
import pandas as pd

# Allowed AST node types for safe expressions
ALLOWED_NODES = (
    ast.Expression,
    ast.BinOp,
    ast.UnaryOp,
    ast.Constant,  # numeric literals
    ast.Name,  # column references
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.FloorDiv,
    ast.Mod,
    ast.Pow,
    ast.USub,  # unary minus
    ast.UAdd,  # unary plus
    ast.Load,  # variable loading context (required by ast.Name)
)

# Patterns that should never appear in expressions
FORBIDDEN_PATTERNS = re.compile(
    r"(__|import|exec|eval|open|getattr|setattr|delattr|globals|locals|compile|"
    r"breakpoint|exit|quit|input|print|type|super|classmethod|staticmethod)",
    re.IGNORECASE,
)


def validate_expression(expression: str, available_columns: list[str]) -> list[str]:
    """Validate an arithmetic expression. Returns list of errors (empty = valid)."""
    errors: list[str] = []

    if not expression or not expression.strip():
        return ["Expression is empty"]

    # Check for forbidden patterns
    if FORBIDDEN_PATTERNS.search(expression):
        return [f"Expression contains forbidden pattern: {expression}"]

    # Parse AST
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as e:
        return [f"Syntax error in expression: {e}"]

    # Walk the AST and check all nodes are allowed
    for node in ast.walk(tree):
        if not isinstance(node, ALLOWED_NODES):
            errors.append(
                f"Disallowed operation in expression: {type(node).__name__}. "
                f"Only arithmetic (+, -, *, /, //, %, **) and column references are allowed."
            )
            return errors

    # Check that all Name references are valid columns
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            if node.id not in available_columns:
                errors.append(f"Unknown column '{node.id}' in expression. Available: {available_columns}")

    return errors


def evaluate_expression(expression: str, df: pd.DataFrame) -> pd.Series:
    """Evaluate a validated arithmetic expression against a DataFrame.

    Column names in the expression map to DataFrame columns.
    Returns a pandas Series with the computed result.
    """
    # Build a namespace with only column Series
    namespace: dict[str, Any] = {}
    for col in df.columns:
        namespace[col] = df[col]

    # Parse and validate AST before eval
    tree = ast.parse(expression, mode="eval")

    # Reject any Name node that is not a valid column name
    col_set = set(df.columns)
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and node.id not in col_set:
            raise ValueError(
                f"Unknown name '{node.id}' in expression. Only column names are allowed."
            )

    # Compile with restricted builtins (no numpy or other libraries)
    code = compile(tree, "<expression>", "eval")
    result = eval(code, {"__builtins__": {}}, namespace)

    if isinstance(result, pd.Series):
        return result
    elif isinstance(result, (int, float, np.integer, np.floating)):
        return pd.Series([result] * len(df), index=df.index)
    else:
        raise ValueError(f"Expression returned unexpected type: {type(result)}")
