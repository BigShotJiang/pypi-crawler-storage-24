"""Generate Python/pandas code from a validated pipeline.

Produces a markdown-formatted code block that reproduces the pipeline execution.
"""

from __future__ import annotations

import re

from pandaspipe.models import PipelineStep


def generate_code(pipeline: list[PipelineStep]) -> str:
    """Generate Python code that reproduces a pipeline.

    Returns a markdown-formatted string with a Python code block.
    """
    lines: list[str] = [
        "import pandas as pd",
        "",
        "# df = pd.read_csv('your_data.csv')  # load your DataFrame",
        "",
    ]

    for step in pipeline:
        input_var = _input_var(step, pipeline)
        output_var = f"df_{step.id}"
        p = step.params
        comment = f"# Step: {step.id} ({step.op})"
        lines.append(comment)

        if step.op == "filter":
            if "logic" in p and "conditions" in p:
                conds = []
                for c in p["conditions"]:
                    conds.append(_filter_expr(c, input_var))
                joiner = " & " if p["logic"] == "and" else " | "
                lines.append(f"{output_var} = {input_var}[{joiner.join(conds)}]")
            else:
                expr = _filter_expr(p, input_var)
                lines.append(f"{output_var} = {input_var}[{expr}]")

        elif step.op == "select":
            cols = p.get("columns", [])
            lines.append(f"{output_var} = {input_var}[{repr(cols)}]")

        elif step.op == "drop":
            cols = p.get("columns", [])
            lines.append(f"{output_var} = {input_var}.drop(columns={repr(cols)})")

        elif step.op == "rename":
            mapping = p.get("mapping", {})
            lines.append(f"{output_var} = {input_var}.rename(columns={repr(mapping)})")

        elif step.op == "sort":
            by = p.get("by", "")
            asc = p.get("ascending", True)
            lines.append(f"{output_var} = {input_var}.sort_values(by={repr(by)}, ascending={repr(asc)})")

        elif step.op in ("limit", "head"):
            n = p.get("n", 5)
            lines.append(f"{output_var} = {input_var}.head({n})")

        elif step.op == "tail":
            n = p.get("n", 5)
            lines.append(f"{output_var} = {input_var}.tail({n})")

        elif step.op == "groupby":
            # Language spec: by (str|list), agg (dict)
            by = p.get("by", [])
            agg = p.get("agg", {})
            lines.append(
                f"{output_var} = {input_var}.groupby({repr(by)}, as_index=False)"
                f".agg({repr(agg)})"
            )

        elif step.op == "agg":
            # Language spec: agg (dict)
            agg = p.get("agg", {})
            lines.append(f"{output_var} = {input_var}.agg({repr(agg)})")

        elif step.op == "pivot_table":
            idx = p.get("index", [])
            col = p.get("columns")
            vals = p.get("values", [])
            agg = p.get("aggfunc", "mean")
            fill_value = p.get("fill_value")
            parts = [f"index={repr(idx)}", f"values={repr(vals)}", f"aggfunc={repr(agg)}"]
            if col:
                parts.insert(1, f"columns={repr(col)}")
            if fill_value is not None:
                parts.append(f"fill_value={repr(fill_value)}")
            lines.append(f"{output_var} = pd.pivot_table({input_var}, {', '.join(parts)})")

        elif step.op == "pivot":
            idx = p.get("index", "")
            col = p.get("columns", "")
            val = p.get("values", "")
            lines.append(
                f"{output_var} = {input_var}.pivot("
                f"index={repr(idx)}, columns={repr(col)}, values={repr(val)})"
            )

        elif step.op == "melt":
            id_vars = p.get("id_vars", [])
            val_vars = p.get("value_vars", [])
            var_name = p.get("var_name", "variable")
            val_name = p.get("value_name", "value")
            lines.append(
                f"{output_var} = {input_var}.melt("
                f"id_vars={repr(id_vars)}, value_vars={repr(val_vars)}, "
                f"var_name={repr(var_name)}, value_name={repr(val_name)})"
            )

        elif step.op == "value_counts":
            col = p.get("column", "")
            normalize = p.get("normalize", False)
            top_n = p.get("top_n", 20)
            lines.append(
                f"{output_var} = {input_var}[{repr(col)}].value_counts("
                f"normalize={normalize}).head({top_n}).reset_index()"
            )

        elif step.op == "describe":
            cols = p.get("columns")
            percentiles = p.get("percentiles")
            kwargs_parts = []
            if percentiles is not None:
                kwargs_parts.append(f"percentiles={repr(percentiles)}")
            kwargs_str = ", ".join(kwargs_parts)
            if cols:
                lines.append(f"{output_var} = {input_var}[{repr(cols)}].describe({kwargs_str})")
            else:
                lines.append(f"{output_var} = {input_var}.describe({kwargs_str})")

        elif step.op == "correlation":
            cols = p.get("columns")
            method = p.get("method", "pearson")
            if cols:
                lines.append(f"{output_var} = {input_var}[{repr(cols)}].corr(method={repr(method)})")
            else:
                lines.append(f"{output_var} = {input_var}.corr(method={repr(method)})")

        elif step.op == "compute":
            # Language spec: target (new col name), expression
            target = p.get("target", "new_col")
            expr = p.get("expression", "")
            # Transform bare column names to df['col'] syntax
            transformed_expr = _transform_expression(expr, input_var)
            lines.append(f"{output_var} = {input_var}.copy()")
            lines.append(f"{output_var}[{repr(target)}] = {transformed_expr}")

        elif step.op == "fillna":
            col = p.get("column")
            val = p.get("value")
            method = p.get("method")
            if method in ("mean", "median"):
                lines.append(f"{output_var} = {input_var}.copy()")
                if col:
                    lines.append(
                        f"{output_var}[{repr(col)}] = "
                        f"{output_var}[{repr(col)}].fillna({output_var}[{repr(col)}].{method}())"
                    )
                else:
                    lines.append(f"# Fill numeric columns with {method}")
                    lines.append(
                        f"for _col in {output_var}.select_dtypes(include='number').columns:\n"
                        f"    {output_var}[_col] = {output_var}[_col].fillna({output_var}[_col].{method}())"
                    )
            elif method == "ffill":
                if col:
                    lines.append(f"{output_var} = {input_var}.copy()")
                    lines.append(f"{output_var}[{repr(col)}] = {output_var}[{repr(col)}].ffill()")
                else:
                    lines.append(f"{output_var} = {input_var}.ffill()")
            elif method == "bfill":
                if col:
                    lines.append(f"{output_var} = {input_var}.copy()")
                    lines.append(f"{output_var}[{repr(col)}] = {output_var}[{repr(col)}].bfill()")
                else:
                    lines.append(f"{output_var} = {input_var}.bfill()")
            elif col and val is not None:
                lines.append(f"{output_var} = {input_var}.copy()")
                lines.append(f"{output_var}[{repr(col)}] = {output_var}[{repr(col)}].fillna({repr(val)})")
            elif val is not None:
                lines.append(f"{output_var} = {input_var}.fillna({repr(val)})")
            else:
                # No value and no method; default to ffill
                if col:
                    lines.append(f"{output_var} = {input_var}.copy()")
                    lines.append(f"{output_var}[{repr(col)}] = {output_var}[{repr(col)}].ffill()")
                else:
                    lines.append(f"{output_var} = {input_var}.ffill()")

        elif step.op == "drop_duplicates":
            # Language spec: subset (list), keep
            subset = p.get("subset")
            keep = p.get("keep", "first")
            # Handle keep=False as boolean, not string
            if keep is False or keep == "False":
                keep_repr = "False"
            else:
                keep_repr = repr(keep)
            if subset:
                lines.append(f"{output_var} = {input_var}.drop_duplicates(subset={repr(subset)}, keep={keep_repr})")
            else:
                lines.append(f"{output_var} = {input_var}.drop_duplicates(keep={keep_repr})")

        elif step.op == "concat":
            inputs = p.get("inputs", [])
            input_vars = [f"df_{ref}" if ref != "source" else "df" for ref in inputs]
            axis = p.get("axis", 0)
            ignore_index = p.get("ignore_index", True)
            lines.append(
                f"{output_var} = pd.concat([{', '.join(input_vars)}], "
                f"axis={axis}, ignore_index={ignore_index})"
            )

        elif step.op == "merge":
            # Language spec: right (step ID)
            right_ref = p.get("right", "source")
            right_var = f"df_{right_ref}" if right_ref != "source" else "df"
            on = p.get("on")
            left_on = p.get("left_on")
            right_on = p.get("right_on")
            how = p.get("how", "inner")
            if on:
                lines.append(f"{output_var} = {input_var}.merge({right_var}, on={repr(on)}, how={repr(how)})")
            else:
                lines.append(
                    f"{output_var} = {input_var}.merge({right_var}, "
                    f"left_on={repr(left_on)}, right_on={repr(right_on)}, how={repr(how)})"
                )

        elif step.op == "sample":
            n = p.get("n")
            frac = p.get("frac")
            seed = p.get("random_state", 42)
            if n:
                lines.append(f"{output_var} = {input_var}.sample(n={n}, random_state={seed})")
            else:
                lines.append(f"{output_var} = {input_var}.sample(frac={frac}, random_state={seed})")

        elif step.op == "assign":
            # Language spec: columns (dict)
            cols_dict = p.get("columns", {})
            lines.append(f"{output_var} = {input_var}.assign(**{repr(cols_dict)})")

        elif step.op == "astype":
            # Language spec: mapping (dict of col -> dtype)
            mapping = p.get("mapping", {})
            lines.append(f"{output_var} = {input_var}.astype({repr(mapping)})")

        elif step.op == "reset_index":
            drop = p.get("drop", True)
            lines.append(f"{output_var} = {input_var}.reset_index(drop={drop})")

        else:
            lines.append(f"# {output_var} = ... (unsupported op: {step.op})")

        lines.append("")

    # Final result reference
    if pipeline:
        last_var = f"df_{pipeline[-1].id}"
        lines.append(f"result = {last_var}")

    code = "\n".join(lines)
    return f"```python\n{code}\n```"


def _input_var(step: PipelineStep, pipeline: list[PipelineStep]) -> str:
    """Determine the input variable name for a step."""
    if step.input == "source" or step.input is None and pipeline.index(step) == 0:
        return "df"
    if step.input:
        return f"df_{step.input}"
    # Default: previous step
    idx = next(i for i, s in enumerate(pipeline) if s.id == step.id)
    if idx > 0:
        return f"df_{pipeline[idx - 1].id}"
    return "df"


def _filter_expr(cond: dict, var: str) -> str:
    """Build a filter expression string for a single condition."""
    col = cond.get("column", "")
    op = cond.get("operator", "==")
    val = cond.get("value")

    if op in ("==", "!=", ">", "<", ">=", "<="):
        return f"({var}[{repr(col)}] {op} {repr(val)})"
    elif op == "in":
        return f"({var}[{repr(col)}].isin({repr(val)}))"
    elif op == "not_in":
        return f"(~{var}[{repr(col)}].isin({repr(val)}))"
    elif op == "contains":
        return f"({var}[{repr(col)}].str.contains({repr(val)}, case=False, na=False, regex=False))"
    elif op == "startswith":
        return f"({var}[{repr(col)}].str.startswith({repr(val)}, na=False))"
    elif op == "endswith":
        return f"({var}[{repr(col)}].str.endswith({repr(val)}, na=False))"
    elif op == "isnull":
        return f"({var}[{repr(col)}].isna())"
    elif op == "notnull":
        return f"({var}[{repr(col)}].notna())"
    elif op == "between":
        return f"({var}[{repr(col)}].between({val[0]}, {val[1]}))"
    else:
        return f"({var}[{repr(col)}] {op} {repr(val)})"


def _transform_expression(expression: str, var: str) -> str:
    """Transform bare column names in an expression to df['column_name'] syntax.

    E.g. 'revenue / quantity' -> "df_s1['revenue'] / df_s1['quantity']"
    """
    import ast as _ast

    try:
        tree = _ast.parse(expression, mode="eval")
    except SyntaxError:
        return expression

    # Collect all Name nodes with their positions (right to left for safe replacement)
    replacements = []
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Name):
            replacements.append(node)

    if not replacements:
        return expression

    # Sort by position in reverse order (right to left) so offsets don't shift
    replacements.sort(key=lambda n: n.col_offset, reverse=True)

    result = expression
    for node in replacements:
        start = node.col_offset
        end = start + len(node.id)
        result = result[:start] + f"{var}[{repr(node.id)}]" + result[end:]

    return result
