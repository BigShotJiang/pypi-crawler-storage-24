"""Pydantic models for pandaspipe."""

from __future__ import annotations

from typing import Any

import pandas as pd
from pydantic import BaseModel, Field


class ColumnSchema(BaseModel):
    """Schema for a single DataFrame column."""

    name: str
    dtype: str
    nullable: bool = False
    null_count: int = 0
    null_pct: float = 0.0
    cardinality: int = 0
    is_numeric: bool = False
    is_categorical: bool = False
    is_datetime: bool = False
    is_boolean: bool = False
    sample_values: list[Any] = Field(default_factory=list)
    min_value: Any = None
    max_value: Any = None


class DataFrameSchema(BaseModel):
    """Full schema for a DataFrame."""

    row_count: int
    column_count: int
    columns: list[ColumnSchema] = Field(default_factory=list)
    memory_usage_mb: float = 0.0

    def column_names(self) -> list[str]:
        return [c.name for c in self.columns]

    def numeric_columns(self) -> list[str]:
        return [c.name for c in self.columns if c.is_numeric]

    def categorical_columns(self) -> list[str]:
        return [c.name for c in self.columns if c.is_categorical]


class PipelineStep(BaseModel):
    """A single step in a pipeline."""

    id: str
    op: str
    input: str | None = None  # step ID or "source"; None = previous step
    # All other params are stored as extra fields
    params: dict[str, Any] = Field(default_factory=dict)


class PipelineValidationError(BaseModel):
    """A single validation error."""

    step_id: str | None = None
    field: str | None = None
    message: str


class ValidationResult(BaseModel):
    """Result of pipeline validation."""

    is_valid: bool
    errors: list[PipelineValidationError] = Field(default_factory=list)
    pipeline: list[PipelineStep] = Field(default_factory=list)


class StepLog(BaseModel):
    """Execution log for a single step."""

    step_id: str
    op: str
    rows_in: int
    rows_out: int
    columns_out: list[str] = Field(default_factory=list)


class PipelineResult(BaseModel):
    """Result of pipeline execution."""

    class Config:
        arbitrary_types_allowed = True

    result_df: Any = None  # pd.DataFrame (arbitrary_types_allowed)
    code_markdown: str = ""
    steps_log: list[StepLog] = Field(default_factory=list)
    success: bool = True
    error: str | None = None
