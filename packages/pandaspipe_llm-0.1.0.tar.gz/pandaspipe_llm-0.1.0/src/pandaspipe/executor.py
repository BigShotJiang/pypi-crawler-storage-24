"""Core execution engine for pandaspipe.

Takes a validated pipeline (list of PipelineStep) and a DataFrame,
executes each step respecting the DAG dependencies, and returns a PipelineResult.
"""

from __future__ import annotations

import logging
from typing import Any

import pandas as pd

from pandaspipe.expressions import evaluate_expression
from pandaspipe.models import PipelineResult, PipelineStep, StepLog

logger = logging.getLogger(__name__)

_HEAD_LIMIT_CAP = 10_000


# ---------------------------------------------------------------------------
# Filter operator mapping
# ---------------------------------------------------------------------------

def _apply_filter_condition(series: pd.Series, operator: str, value: Any) -> pd.Series:
    """Apply a single filter condition and return a boolean mask."""
    op_map = {
        "==": lambda s, v: s == v,
        "!=": lambda s, v: s != v,
        ">": lambda s, v: s > v,
        "<": lambda s, v: s < v,
        ">=": lambda s, v: s >= v,
        "<=": lambda s, v: s <= v,
        "in": lambda s, v: s.isin(v),
        "not_in": lambda s, v: ~s.isin(v),
        "contains": lambda s, v: s.str.contains(v, case=False, na=False, regex=False),
        "startswith": lambda s, v: s.str.startswith(v, na=False),
        "endswith": lambda s, v: s.str.endswith(v, na=False),
        "isnull": lambda s, v: s.isna(),
        "notnull": lambda s, v: s.notna(),
        "between": lambda s, v: s.between(v[0], v[1]),
    }
    func = op_map.get(operator)
    if func is None:
        raise ValueError(f"Unknown filter operator: {operator}")
    return func(series, value)


# ---------------------------------------------------------------------------
# Operation implementations
# ---------------------------------------------------------------------------

def _exec_filter(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Filter rows by one or more conditions."""
    df = df.copy()

    # Compound filter: logic + conditions list
    if "conditions" in params:
        logic = params.get("logic", "and")
        conditions = params["conditions"]
        masks = [
            _apply_filter_condition(
                df[c["column"]], c["operator"], c.get("value")
            )
            for c in conditions
        ]
        if logic == "or":
            combined = masks[0]
            for m in masks[1:]:
                combined = combined | m
        else:
            combined = masks[0]
            for m in masks[1:]:
                combined = combined & m
        return df.loc[combined].reset_index(drop=True)

    # Single condition
    column = params["column"]
    operator = params["operator"]
    value = params.get("value")
    mask = _apply_filter_condition(df[column], operator, value)
    return df.loc[mask].reset_index(drop=True)


def _exec_select(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Select specific columns."""
    return df[params["columns"]].copy()


def _exec_drop(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Drop specific columns."""
    return df.drop(columns=params["columns"]).copy()


def _exec_rename(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Rename columns using a mapping."""
    return df.rename(columns=params["mapping"]).copy()


def _exec_sort(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Sort by one or more columns."""
    by = params["by"]
    ascending = params.get("ascending", True)
    return df.sort_values(by=by, ascending=ascending).reset_index(drop=True)


def _exec_limit(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Return first n rows (capped at 10000)."""
    n = min(params["n"], _HEAD_LIMIT_CAP)
    return df.head(n).copy()


def _exec_head(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Return first n rows (capped at 10000)."""
    n = min(params.get("n", 5), _HEAD_LIMIT_CAP)
    return df.head(n).copy()


def _exec_tail(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Return last n rows (capped at 10000)."""
    n = min(params.get("n", 5), _HEAD_LIMIT_CAP)
    return df.tail(n).copy().reset_index(drop=True)


def _exec_groupby(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Group by columns and aggregate.

    Language spec params: by (str|list), agg (dict of col->func/funcs)
    """
    by = params["by"]
    agg = params["agg"]
    result = df.groupby(by, as_index=False).agg(agg)
    # Flatten MultiIndex columns if present (e.g. when agg has lists)
    if isinstance(result.columns, pd.MultiIndex):
        result.columns = ["_".join(str(c) for c in col).rstrip("_") for col in result.columns]
    return result


def _exec_agg(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Aggregate columns with specified functions.

    Language spec params: agg (dict of col->func/funcs)
    """
    agg = params["agg"]
    result = df.agg(agg)
    if isinstance(result, pd.Series):
        result = result.to_frame().T
    return result.reset_index(drop=True)


def _exec_pivot_table(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Create a pivot table."""
    index = params["index"]
    columns = params.get("columns")
    values = params["values"]
    aggfunc = params.get("aggfunc", "mean")
    fill_value = params.get("fill_value")

    kwargs: dict[str, Any] = {
        "index": index,
        "columns": columns,
        "values": values,
        "aggfunc": aggfunc,
    }
    if fill_value is not None:
        kwargs["fill_value"] = fill_value

    result = pd.pivot_table(df, **kwargs)
    # Flatten multi-level column index if present
    if isinstance(result.columns, pd.MultiIndex):
        result.columns = ["_".join(str(c) for c in col).rstrip("_") for col in result.columns]
    return result.reset_index()


def _exec_pivot(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Reshape using pivot (no aggregation)."""
    result = df.pivot(
        index=params["index"],
        columns=params["columns"],
        values=params["values"],
    )
    result.columns = [str(c) for c in result.columns]
    return result.reset_index()


def _exec_melt(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Unpivot from wide to long format."""
    return pd.melt(
        df,
        id_vars=params.get("id_vars"),
        value_vars=params.get("value_vars"),
        var_name=params.get("var_name", "variable"),
        value_name=params.get("value_name", "value"),
    )


def _exec_value_counts(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Count unique values in a column."""
    column = params["column"]
    normalize = params.get("normalize", False)
    top_n = params.get("top_n", 20)
    counts = df[column].value_counts(normalize=normalize).head(top_n).reset_index()
    count_col = "proportion" if normalize else "count"
    counts.columns = [column, count_col]
    return counts


def _exec_describe(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Descriptive statistics."""
    columns = params.get("columns")
    percentiles = params.get("percentiles")
    kwargs: dict[str, Any] = {}
    if percentiles is not None:
        kwargs["percentiles"] = percentiles
    if columns:
        result = df[columns].describe(**kwargs)
    else:
        result = df.describe(**kwargs)
    return result.reset_index().rename(columns={"index": "statistic"})


def _exec_correlation(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Compute correlation matrix."""
    columns = params.get("columns")
    method = params.get("method", "pearson")
    subset = df[columns] if columns else df.select_dtypes(include="number")
    corr = subset.corr(method=method)
    return corr.reset_index().rename(columns={"index": "column"})


def _exec_compute(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Create a new column from an arithmetic expression.

    Language spec params: target (new col name), expression
    """
    df = df.copy()
    target = params["target"]
    expression = params["expression"]
    df[target] = evaluate_expression(expression, df)
    return df


def _exec_fillna(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Fill missing values.

    Language spec: column is optional. If omitted, fill all columns.
    """
    df = df.copy()
    column = params.get("column")

    if "value" in params:
        if column:
            df[column] = df[column].fillna(params["value"])
        else:
            df = df.fillna(params["value"])
    else:
        method = params.get("method", "ffill")
        if method == "mean":
            if column:
                df[column] = df[column].fillna(df[column].mean())
            else:
                for col in df.select_dtypes(include="number").columns:
                    df[col] = df[col].fillna(df[col].mean())
        elif method == "median":
            if column:
                df[column] = df[column].fillna(df[column].median())
            else:
                for col in df.select_dtypes(include="number").columns:
                    df[col] = df[col].fillna(df[col].median())
        elif method == "ffill":
            if column:
                df[column] = df[column].ffill()
            else:
                df = df.ffill()
        elif method == "bfill":
            if column:
                df[column] = df[column].bfill()
            else:
                df = df.bfill()
        else:
            raise ValueError(f"Unknown fillna method: {method}")
    return df


def _exec_drop_duplicates(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Drop duplicate rows.

    Language spec params: subset (list), keep
    """
    subset = params.get("subset")
    keep = params.get("keep", "first")
    # keep can be "first", "last", or False (drop all duplicates)
    if keep == "False" or keep is False:
        keep = False
    return df.drop_duplicates(subset=subset, keep=keep).reset_index(drop=True)


def _exec_concat(dfs: list[pd.DataFrame], params: dict[str, Any]) -> pd.DataFrame:
    """Concatenate multiple DataFrames."""
    axis = params.get("axis", 0)
    ignore_index = params.get("ignore_index", True)
    return pd.concat(dfs, axis=axis, ignore_index=ignore_index)


def _exec_merge(
    df: pd.DataFrame, right_df: pd.DataFrame, params: dict[str, Any]
) -> pd.DataFrame:
    """Merge two DataFrames."""
    how = params.get("how", "inner")
    on = params.get("on")
    left_on = params.get("left_on")
    right_on = params.get("right_on")

    kwargs: dict[str, Any] = {"how": how}
    if on:
        kwargs["on"] = on
    else:
        if left_on:
            kwargs["left_on"] = left_on
        if right_on:
            kwargs["right_on"] = right_on

    return df.merge(right_df, **kwargs)


def _exec_sample(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Random sample of rows."""
    random_state = params.get("random_state", 42)
    if "n" in params:
        n = min(params["n"], len(df))
        return df.sample(n=n, random_state=random_state).reset_index(drop=True)
    elif "frac" in params:
        frac = max(0.0, min(1.0, params["frac"]))
        return df.sample(frac=frac, random_state=random_state).reset_index(drop=True)
    else:
        raise ValueError("sample requires either 'n' or 'frac' parameter")


def _exec_assign(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Assign constant values to columns.

    Language spec params: columns (dict of col_name -> value)
    """
    df = df.copy()
    cols = params["columns"]
    for col_name, value in cols.items():
        df[col_name] = value
    return df


def _exec_astype(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Cast columns to different dtypes.

    Language spec params: mapping (dict of col -> dtype)
    """
    df = df.copy()
    mapping = params["mapping"]
    for col, dtype in mapping.items():
        df[col] = df[col].astype(dtype)
    return df


def _exec_reset_index(df: pd.DataFrame, params: dict[str, Any]) -> pd.DataFrame:
    """Reset the DataFrame index."""
    drop = params.get("drop", True)
    return df.reset_index(drop=drop)


# ---------------------------------------------------------------------------
# Operation dispatch table
# ---------------------------------------------------------------------------

_STANDARD_OPS: dict[str, Any] = {
    "filter": _exec_filter,
    "select": _exec_select,
    "drop": _exec_drop,
    "rename": _exec_rename,
    "sort": _exec_sort,
    "limit": _exec_limit,
    "head": _exec_head,
    "tail": _exec_tail,
    "groupby": _exec_groupby,
    "agg": _exec_agg,
    "pivot_table": _exec_pivot_table,
    "pivot": _exec_pivot,
    "melt": _exec_melt,
    "value_counts": _exec_value_counts,
    "describe": _exec_describe,
    "correlation": _exec_correlation,
    "compute": _exec_compute,
    "fillna": _exec_fillna,
    "drop_duplicates": _exec_drop_duplicates,
    "sample": _exec_sample,
    "assign": _exec_assign,
    "astype": _exec_astype,
    "reset_index": _exec_reset_index,
}


# ---------------------------------------------------------------------------
# Input resolution helpers
# ---------------------------------------------------------------------------

def _resolve_input(
    step: PipelineStep,
    results: dict[str, pd.DataFrame],
    prev_step_id: str | None,
) -> pd.DataFrame:
    """Resolve the input DataFrame for a standard (single-input) step."""
    if step.input is not None:
        source_id = step.input
    elif prev_step_id is not None:
        source_id = prev_step_id
    else:
        source_id = "source"

    if source_id not in results:
        raise ValueError(
            f"Step '{step.id}' references input '{source_id}' which has not been computed yet"
        )
    return results[source_id]


def _resolve_multi_inputs(
    step: PipelineStep,
    results: dict[str, pd.DataFrame],
) -> list[pd.DataFrame]:
    """Resolve multiple input DataFrames for concat operations."""
    input_ids: list[str] = step.params.get("inputs", [])
    if not input_ids:
        raise ValueError(f"Step '{step.id}' ({step.op}) requires 'inputs' in params")
    dfs: list[pd.DataFrame] = []
    for sid in input_ids:
        if sid not in results:
            raise ValueError(
                f"Step '{step.id}' references input '{sid}' which has not been computed yet"
            )
        dfs.append(results[sid])
    return dfs


# ---------------------------------------------------------------------------
# Main execution function
# ---------------------------------------------------------------------------

def execute_pipeline(
    df: pd.DataFrame,
    pipeline: list[PipelineStep],
    generate_code: bool = True,
) -> PipelineResult:
    """Execute a validated pipeline against a DataFrame.

    Args:
        df: The source DataFrame.
        pipeline: Ordered list of PipelineStep objects.
        generate_code: If True, also generate the equivalent pandas code.

    Returns:
        PipelineResult with the final DataFrame, step logs, and optional code.
    """
    results: dict[str, pd.DataFrame] = {"source": df.copy()}
    steps_log: list[StepLog] = []
    prev_step_id: str | None = None

    for step in pipeline:
        try:
            op = step.op
            params = step.params
            rows_in: int

            if op == "concat":
                input_dfs = _resolve_multi_inputs(step, results)
                rows_in = sum(len(d) for d in input_dfs)
                result_df = _exec_concat(input_dfs, params)

            elif op == "merge":
                # Language spec: left from step.input, right from params["right"]
                left_df = _resolve_input(step, results, prev_step_id)
                right_id = params.get("right")
                if right_id not in results:
                    raise ValueError(
                        f"Step '{step.id}' (merge) references right '{right_id}' "
                        f"which has not been computed yet"
                    )
                right_df = results[right_id]
                rows_in = len(left_df)
                result_df = _exec_merge(left_df, right_df, params)

            elif op in _STANDARD_OPS:
                input_df = _resolve_input(step, results, prev_step_id)
                rows_in = len(input_df)
                result_df = _STANDARD_OPS[op](input_df, params)

            else:
                raise ValueError(f"Unknown operation: {op}")

            results[step.id] = result_df
            rows_out = len(result_df)

            steps_log.append(
                StepLog(
                    step_id=step.id,
                    op=op,
                    rows_in=rows_in,
                    rows_out=rows_out,
                    columns_out=[str(c) for c in result_df.columns],
                )
            )
            logger.debug(
                "Step '%s' (%s): %d rows in -> %d rows out",
                step.id, op, rows_in, rows_out,
            )
            prev_step_id = step.id

        except Exception as exc:
            logger.error("Step '%s' (%s) failed: %s", step.id, step.op, exc)
            # Return partial result up to the last successful step
            last_df = results.get(prev_step_id, results["source"])
            code_md = ""
            if generate_code:
                code_md = _safe_generate_code(pipeline)
            return PipelineResult(
                result_df=last_df,
                code_markdown=code_md,
                steps_log=steps_log,
                success=False,
                error=f"Step '{step.id}' ({step.op}) failed: {exc}",
            )

    # Determine final DataFrame: output of last step, or source if pipeline is empty
    if pipeline:
        final_df = results[pipeline[-1].id]
    else:
        final_df = results["source"]

    code_md = ""
    if generate_code:
        code_md = _safe_generate_code(pipeline)

    return PipelineResult(
        result_df=final_df,
        code_markdown=code_md,
        steps_log=steps_log,
        success=True,
        error=None,
    )


def _safe_generate_code(pipeline: list[PipelineStep]) -> str:
    """Attempt code generation; return empty string on failure."""
    try:
        from pandaspipe.codegen import generate_code  # noqa: WPS433

        return generate_code(pipeline)
    except Exception as exc:
        logger.warning("Code generation failed: %s", exc)
        return ""
