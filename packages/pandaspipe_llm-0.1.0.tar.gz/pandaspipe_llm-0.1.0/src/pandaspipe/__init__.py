"""pandaspipe: Safe DataFrame query pipeline for LLM agents."""

from pandaspipe.executor import execute_pipeline
from pandaspipe.models import PipelineResult, PipelineStep, PipelineValidationError, ValidationResult
from pandaspipe.prompt import generate_prompt
from pandaspipe.validator import validate_pipeline

__version__ = "0.1.0"
__all__ = [
    "generate_prompt",
    "validate_pipeline",
    "execute_pipeline",
    "run",
    "PipelineResult",
    "PipelineStep",
    "PipelineValidationError",
    "ValidationResult",
]


def run(
    df: "pd.DataFrame",
    pipeline_json: str | dict | list,
    generate_code: bool = True,
) -> PipelineResult:
    """Convenience: validate + execute in one call.

    Args:
        df: The DataFrame to operate on.
        pipeline_json: JSON pipeline (string, dict, or list).
        generate_code: Whether to generate Python code markdown.

    Returns:
        PipelineResult with result_df, code_markdown, and steps_log.

    Raises:
        ValueError: If the pipeline is invalid.
    """
    result = validate_pipeline(pipeline_json, df)
    if not result.is_valid:
        error_msgs = "; ".join(e.message for e in result.errors)
        raise ValueError(f"Invalid pipeline: {error_msgs}")
    return execute_pipeline(df, result.pipeline, generate_code=generate_code)
