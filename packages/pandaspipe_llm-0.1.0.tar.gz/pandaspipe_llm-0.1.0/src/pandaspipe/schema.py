"""Extract DataFrame schema for LLM context."""

from __future__ import annotations

import numpy as np
import pandas as pd

from pandaspipe.models import ColumnSchema, DataFrameSchema


def extract_schema(df: pd.DataFrame, sample_values: int = 5) -> DataFrameSchema:
    """Extract a complete schema from a DataFrame.

    The schema includes column names, types, cardinality, null info,
    and sample values -- everything an LLM needs to write valid pipelines.
    """
    columns: list[ColumnSchema] = []

    for col_name in df.columns:
        series = df[col_name]
        non_null = series.dropna()
        null_count = int(series.isna().sum())
        n = len(series)

        is_numeric = pd.api.types.is_numeric_dtype(series)
        is_datetime = pd.api.types.is_datetime64_any_dtype(series)
        is_boolean = pd.api.types.is_bool_dtype(series) or (
            series.dtype == object
            and non_null.nunique() <= 3
            and set(str(v).lower() for v in non_null.unique()).issubset(
                {"true", "false", "yes", "no", "0", "1"}
            )
        )
        is_categorical = (
            not is_numeric
            and not is_datetime
            and not is_boolean
            and series.dtype == object
            and non_null.nunique() <= 50
        )

        # Sample values
        samples: list = []
        if len(non_null) > 0:
            sample_s = non_null.sample(n=min(sample_values, len(non_null)), random_state=42)
            for v in sample_s:
                if isinstance(v, (np.integer,)):
                    samples.append(int(v))
                elif isinstance(v, (np.floating,)):
                    samples.append(round(float(v), 4))
                elif isinstance(v, pd.Timestamp):
                    samples.append(str(v.date()))
                else:
                    samples.append(str(v))

        # Min/max for numeric and datetime
        min_val = None
        max_val = None
        if is_numeric and len(non_null) > 0:
            min_val = round(float(non_null.min()), 4)
            max_val = round(float(non_null.max()), 4)
        elif is_datetime and len(non_null) > 0:
            min_val = str(non_null.min())
            max_val = str(non_null.max())

        columns.append(ColumnSchema(
            name=col_name,
            dtype=str(series.dtype),
            nullable=null_count > 0,
            null_count=null_count,
            null_pct=round(null_count / n * 100, 2) if n > 0 else 0.0,
            cardinality=int(non_null.nunique()),
            is_numeric=is_numeric,
            is_categorical=is_categorical,
            is_datetime=is_datetime,
            is_boolean=is_boolean,
            sample_values=samples,
            min_value=min_val,
            max_value=max_val,
        ))

    return DataFrameSchema(
        row_count=len(df),
        column_count=len(df.columns),
        columns=columns,
        memory_usage_mb=round(df.memory_usage(deep=True).sum() / (1024 * 1024), 2),
    )


def schema_to_text(schema: DataFrameSchema) -> str:
    """Format schema as readable text for LLM context."""
    lines = [
        f"Dataset: {schema.row_count:,} rows x {schema.column_count} columns ({schema.memory_usage_mb} MB)",
        "",
        "Columns:",
    ]

    for col in schema.columns:
        type_tags = []
        if col.is_numeric:
            type_tags.append("numeric")
        if col.is_categorical:
            type_tags.append("categorical")
        if col.is_datetime:
            type_tags.append("datetime")
        if col.is_boolean:
            type_tags.append("boolean")
        if not type_tags:
            type_tags.append(col.dtype)

        tags = ", ".join(type_tags)
        line = f"  {col.name} ({tags}): {col.cardinality} unique"

        if col.nullable:
            line += f", {col.null_pct}% null"

        if col.min_value is not None:
            line += f", range=[{col.min_value}, {col.max_value}]"

        if col.sample_values:
            samples_str = ", ".join(str(v) for v in col.sample_values[:3])
            line += f", examples: [{samples_str}]"

        lines.append(line)

    return "\n".join(lines)
