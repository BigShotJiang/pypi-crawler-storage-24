"""Query language specification for pandaspipe pipelines.

Defines every supported operation, its parameters, and constraints.
Used by prompt.py to generate LLM instructions and by validator.py
to validate pipelines.
"""

from __future__ import annotations

from typing import Any


FILTER_OPERATORS = [
    "==", "!=", ">", "<", ">=", "<=",
    "in", "not_in",
    "contains", "startswith", "endswith",
    "isnull", "notnull",
    "between",
]

AGG_FUNCTIONS = [
    "sum", "mean", "median", "min", "max",
    "count", "nunique", "std", "var",
    "first", "last",
]

ALLOWED_DTYPES = [
    "int", "int32", "int64",
    "float", "float32", "float64",
    "str", "string",
    "bool",
    "datetime64[ns]",
    "category",
]


OPERATIONS: dict[str, dict[str, Any]] = {
    "filter": {
        "description": "Subset rows based on a condition",
        "params": {
            "column": {
                "type": "string",
                "required": False,
                "description": "Column name to filter on (required for simple form)",
            },
            "operator": {
                "type": "string",
                "required": False,
                "enum": FILTER_OPERATORS,
                "description": "Comparison operator (required for simple form)",
            },
            "value": {
                "type": "any",
                "required": False,
                "description": (
                    "Value to compare against. Not needed for isnull/notnull. "
                    "For 'in'/'not_in' pass a list. For 'between' pass [low, high]."
                ),
            },
            "logic": {
                "type": "string",
                "required": False,
                "enum": ["and", "or"],
                "description": "Logic connector for compound filters (use with 'conditions')",
            },
            "conditions": {
                "type": "list[dict]",
                "required": False,
                "description": (
                    "List of {column, operator, value} dicts for compound filters. "
                    "Use together with 'logic'."
                ),
            },
        },
        "accepts_compound": True,
        "example": '{"id": "s1", "op": "filter", "column": "region", "operator": "==", "value": "South"}',
        "example_compound": (
            '{"id": "s1", "op": "filter", "logic": "and", "conditions": ['
            '{"column": "age", "operator": ">=", "value": 18}, '
            '{"column": "status", "operator": "==", "value": "active"}]}'
        ),
    },

    "select": {
        "description": "Keep only the specified columns",
        "params": {
            "columns": {
                "type": "list[string]",
                "required": True,
                "description": "List of column names to keep",
            },
        },
        "example": '{"id": "s1", "op": "select", "columns": ["name", "age", "city"]}',
    },

    "drop": {
        "description": "Remove specified columns",
        "params": {
            "columns": {
                "type": "list[string]",
                "required": True,
                "description": "List of column names to drop",
            },
        },
        "example": '{"id": "s1", "op": "drop", "columns": ["temp_col", "internal_id"]}',
    },

    "rename": {
        "description": "Rename one or more columns",
        "params": {
            "mapping": {
                "type": "dict[string, string]",
                "required": True,
                "description": "Mapping of old column names to new column names",
            },
        },
        "example": '{"id": "s1", "op": "rename", "mapping": {"old_name": "new_name"}}',
    },

    "sort": {
        "description": "Sort rows by one or more columns",
        "params": {
            "by": {
                "type": "string | list[string]",
                "required": True,
                "description": "Column name or list of column names to sort by",
            },
            "ascending": {
                "type": "bool | list[bool]",
                "required": False,
                "description": "Sort direction. Default true. Pass a list to match 'by'.",
            },
        },
        "example": '{"id": "s1", "op": "sort", "by": "revenue", "ascending": false}',
    },

    "limit": {
        "description": "Keep only the first N rows (alias for head)",
        "params": {
            "n": {
                "type": "int",
                "required": True,
                "description": "Number of rows to keep",
            },
        },
        "example": '{"id": "s1", "op": "limit", "n": 100}',
    },

    "head": {
        "description": "Keep the first N rows",
        "params": {
            "n": {
                "type": "int",
                "required": False,
                "description": "Number of rows. Default 5.",
            },
        },
        "example": '{"id": "s1", "op": "head", "n": 10}',
    },

    "tail": {
        "description": "Keep the last N rows",
        "params": {
            "n": {
                "type": "int",
                "required": False,
                "description": "Number of rows. Default 5.",
            },
        },
        "example": '{"id": "s1", "op": "tail", "n": 10}',
    },

    "groupby": {
        "description": "Group rows by columns and aggregate. Always used together with 'agg'.",
        "params": {
            "by": {
                "type": "string | list[string]",
                "required": True,
                "description": "Column name or list of column names to group by",
            },
            "agg": {
                "type": "dict[string, string | list[string]]",
                "required": True,
                "description": (
                    "Mapping of column names to aggregation functions. "
                    f"Allowed functions: {', '.join(AGG_FUNCTIONS)}"
                ),
            },
        },
        "example": (
            '{"id": "s1", "op": "groupby", "by": "region", '
            '"agg": {"revenue": "sum", "orders": ["sum", "mean"]}}'
        ),
    },

    "agg": {
        "description": "Aggregate the entire DataFrame (no grouping). Returns a single row.",
        "params": {
            "agg": {
                "type": "dict[string, string | list[string]]",
                "required": True,
                "description": (
                    "Mapping of column names to aggregation functions. "
                    f"Allowed functions: {', '.join(AGG_FUNCTIONS)}"
                ),
            },
        },
        "example": '{"id": "s1", "op": "agg", "agg": {"price": ["mean", "max"], "quantity": "sum"}}',
    },

    "pivot_table": {
        "description": "Create a pivot table",
        "params": {
            "index": {
                "type": "string | list[string]",
                "required": True,
                "description": "Column(s) to use as row index",
            },
            "columns": {
                "type": "string",
                "required": True,
                "description": "Column whose unique values become new columns",
            },
            "values": {
                "type": "string | list[string]",
                "required": True,
                "description": "Column(s) to aggregate",
            },
            "aggfunc": {
                "type": "string",
                "required": False,
                "description": "Aggregation function. Default 'mean'.",
            },
            "fill_value": {
                "type": "any",
                "required": False,
                "description": "Value to fill missing cells. Default null.",
            },
        },
        "example": (
            '{"id": "s1", "op": "pivot_table", "index": "region", '
            '"columns": "quarter", "values": "revenue", "aggfunc": "sum"}'
        ),
    },

    "pivot": {
        "description": "Reshape from long to wide (no aggregation, values must be unique)",
        "params": {
            "index": {
                "type": "string | list[string]",
                "required": True,
                "description": "Column(s) for row index",
            },
            "columns": {
                "type": "string",
                "required": True,
                "description": "Column whose unique values become new columns",
            },
            "values": {
                "type": "string | list[string]",
                "required": True,
                "description": "Column(s) to populate the cells",
            },
        },
        "example": (
            '{"id": "s1", "op": "pivot", "index": "date", '
            '"columns": "metric", "values": "value"}'
        ),
    },

    "melt": {
        "description": "Reshape from wide to long (unpivot)",
        "params": {
            "id_vars": {
                "type": "list[string]",
                "required": True,
                "description": "Columns to keep as identifiers",
            },
            "value_vars": {
                "type": "list[string]",
                "required": False,
                "description": "Columns to unpivot. Defaults to all columns not in id_vars.",
            },
            "var_name": {
                "type": "string",
                "required": False,
                "description": "Name for the variable column. Default 'variable'.",
            },
            "value_name": {
                "type": "string",
                "required": False,
                "description": "Name for the value column. Default 'value'.",
            },
        },
        "example": (
            '{"id": "s1", "op": "melt", "id_vars": ["region"], '
            '"value_vars": ["q1", "q2", "q3", "q4"], "var_name": "quarter", "value_name": "revenue"}'
        ),
    },

    "value_counts": {
        "description": "Count occurrences of each unique value in a column",
        "params": {
            "column": {
                "type": "string",
                "required": True,
                "description": "Column to count values for",
            },
            "normalize": {
                "type": "bool",
                "required": False,
                "description": "If true, return proportions instead of counts. Default false.",
            },
            "top_n": {
                "type": "int",
                "required": False,
                "description": "Return only the top N values. Default all.",
            },
        },
        "example": '{"id": "s1", "op": "value_counts", "column": "category", "top_n": 10}',
    },

    "describe": {
        "description": "Compute summary statistics for numeric columns",
        "params": {
            "columns": {
                "type": "list[string]",
                "required": False,
                "description": "Columns to describe. Default all numeric columns.",
            },
            "percentiles": {
                "type": "list[float]",
                "required": False,
                "description": "Percentiles to include, e.g. [0.25, 0.5, 0.75].",
            },
        },
        "example": '{"id": "s1", "op": "describe", "columns": ["price", "quantity"]}',
    },

    "correlation": {
        "description": "Compute pairwise correlation between numeric columns",
        "params": {
            "columns": {
                "type": "list[string]",
                "required": False,
                "description": "Columns to correlate. Default all numeric columns.",
            },
            "method": {
                "type": "string",
                "required": False,
                "enum": ["pearson", "kendall", "spearman"],
                "description": "Correlation method. Default 'pearson'.",
            },
        },
        "example": '{"id": "s1", "op": "correlation", "columns": ["height", "weight", "age"]}',
    },

    "compute": {
        "description": "Create a new column from an arithmetic expression on existing columns",
        "params": {
            "target": {
                "type": "string",
                "required": True,
                "description": "Name of the new column to create",
            },
            "expression": {
                "type": "string",
                "required": True,
                "description": (
                    "Arithmetic expression using column names and operators (+, -, *, /, //, %, **). "
                    "Example: 'revenue / quantity'"
                ),
            },
        },
        "example": '{"id": "s1", "op": "compute", "target": "unit_price", "expression": "revenue / quantity"}',
    },

    "fillna": {
        "description": "Fill missing values in one or more columns",
        "params": {
            "column": {
                "type": "string",
                "required": False,
                "description": "Single column to fill. Omit to fill all columns.",
            },
            "value": {
                "type": "any",
                "required": False,
                "description": "Value to fill with. Use this or 'method', not both.",
            },
            "method": {
                "type": "string",
                "required": False,
                "enum": ["ffill", "bfill"],
                "description": "Fill method: forward fill or backward fill.",
            },
        },
        "example": '{"id": "s1", "op": "fillna", "column": "score", "value": 0}',
    },

    "drop_duplicates": {
        "description": "Remove duplicate rows",
        "params": {
            "subset": {
                "type": "list[string]",
                "required": False,
                "description": "Columns to consider for identifying duplicates. Default all columns.",
            },
            "keep": {
                "type": "string",
                "required": False,
                "enum": ["first", "last", False],
                "description": "Which duplicate to keep. Default 'first'. Use false to drop all.",
            },
        },
        "example": '{"id": "s1", "op": "drop_duplicates", "subset": ["email"]}',
    },

    "concat": {
        "description": "Concatenate results from two pipeline branches (vertical stack)",
        "params": {
            "inputs": {
                "type": "list[string]",
                "required": True,
                "description": "List of step IDs whose results to concatenate",
            },
            "axis": {
                "type": "int",
                "required": False,
                "enum": [0, 1],
                "description": "0 for row-wise (stack), 1 for column-wise (side by side). Default 0.",
            },
            "ignore_index": {
                "type": "bool",
                "required": False,
                "description": "Reset index after concatenation. Default true.",
            },
        },
        "example": (
            '{"id": "s3", "op": "concat", "inputs": ["s1", "s2"], "ignore_index": true}'
        ),
    },

    "merge": {
        "description": "Join two pipeline branches on common columns",
        "params": {
            "right": {
                "type": "string",
                "required": True,
                "description": "Step ID of the right DataFrame to merge with",
            },
            "on": {
                "type": "string | list[string]",
                "required": False,
                "description": "Column(s) to join on (if same name in both DataFrames)",
            },
            "left_on": {
                "type": "string | list[string]",
                "required": False,
                "description": "Column(s) from the left DataFrame to join on",
            },
            "right_on": {
                "type": "string | list[string]",
                "required": False,
                "description": "Column(s) from the right DataFrame to join on",
            },
            "how": {
                "type": "string",
                "required": False,
                "enum": ["inner", "left", "right", "outer"],
                "description": "Type of join. Default 'inner'.",
            },
        },
        "example": (
            '{"id": "s3", "op": "merge", "input": "s1", "right": "s2", '
            '"on": "customer_id", "how": "left"}'
        ),
    },

    "sample": {
        "description": "Randomly sample rows from the DataFrame",
        "params": {
            "n": {
                "type": "int",
                "required": False,
                "description": "Number of rows to sample. Use this or 'frac', not both.",
            },
            "frac": {
                "type": "float",
                "required": False,
                "description": "Fraction of rows to sample (0.0 to 1.0).",
            },
            "random_state": {
                "type": "int",
                "required": False,
                "description": "Seed for reproducibility.",
            },
        },
        "example": '{"id": "s1", "op": "sample", "n": 50, "random_state": 42}',
    },

    "assign": {
        "description": "Add or overwrite columns with constant values or simple mappings",
        "params": {
            "columns": {
                "type": "dict[string, any]",
                "required": True,
                "description": "Mapping of column names to constant values",
            },
        },
        "example": '{"id": "s1", "op": "assign", "columns": {"source": "survey", "year": 2024}}',
    },

    "astype": {
        "description": "Cast columns to different data types",
        "params": {
            "mapping": {
                "type": "dict[string, string]",
                "required": True,
                "description": (
                    "Mapping of column names to target types. "
                    f"Allowed types: {', '.join(ALLOWED_DTYPES)}"
                ),
            },
        },
        "example": '{"id": "s1", "op": "astype", "mapping": {"price": "float64", "zip_code": "str"}}',
    },

    "reset_index": {
        "description": "Reset the DataFrame index, moving it into columns",
        "params": {
            "drop": {
                "type": "bool",
                "required": False,
                "description": "If true, discard the old index instead of adding it as a column. Default false.",
            },
        },
        "example": '{"id": "s1", "op": "reset_index", "drop": true}',
    },
}


def language_spec_to_text() -> str:
    """Format the full language spec as readable text for an LLM prompt.

    Returns a structured description of all operations, their parameters,
    constraints, and examples. Designed to be comprehensive but scannable.
    """
    lines: list[str] = []

    lines.append("=" * 60)
    lines.append("PIPELINE QUERY LANGUAGE REFERENCE")
    lines.append("=" * 60)
    lines.append("")
    lines.append("Each pipeline is a JSON list of step objects.")
    lines.append("Every step MUST have: \"id\" (unique string like \"s1\"), \"op\" (operation name).")
    lines.append(
        "Steps run in sequence by default. Use \"input\" to reference a specific "
        "prior step (for branching pipelines)."
    )
    lines.append("")

    # Group operations by category for readability
    categories = {
        "Row Selection": ["filter", "limit", "head", "tail", "sample", "drop_duplicates"],
        "Column Operations": ["select", "drop", "rename", "compute", "assign", "astype"],
        "Sorting": ["sort"],
        "Aggregation": ["groupby", "agg", "value_counts"],
        "Reshaping": ["pivot_table", "pivot", "melt"],
        "Statistics": ["describe", "correlation"],
        "Combining": ["concat", "merge"],
        "Missing Data": ["fillna"],
        "Utility": ["reset_index"],
    }

    for category, op_names in categories.items():
        lines.append("-" * 40)
        lines.append(f"  {category}")
        lines.append("-" * 40)

        for op_name in op_names:
            spec = OPERATIONS[op_name]
            lines.append("")
            lines.append(f"  {op_name}: {spec['description']}")

            # Parameters
            if spec.get("params"):
                lines.append("    Parameters:")
                for param_name, param_spec in spec["params"].items():
                    req = "REQUIRED" if param_spec.get("required") else "optional"
                    ptype = param_spec["type"]
                    desc = param_spec["description"]
                    line = f"      - {param_name} ({ptype}, {req}): {desc}"
                    if "enum" in param_spec:
                        enum_vals = param_spec["enum"]
                        line += f" Options: {enum_vals}"
                    lines.append(line)

            # Example
            if "example" in spec:
                lines.append(f"    Example: {spec['example']}")
            if "example_compound" in spec:
                lines.append(f"    Compound: {spec['example_compound']}")

        lines.append("")

    # Additional constraints
    lines.append("=" * 60)
    lines.append("FILTER OPERATORS")
    lines.append("=" * 60)
    for fop in FILTER_OPERATORS:
        notes = {
            "==": "equal",
            "!=": "not equal",
            ">": "greater than",
            "<": "less than",
            ">=": "greater than or equal",
            "<=": "less than or equal",
            "in": "value is in a list",
            "not_in": "value is not in a list",
            "contains": "string contains substring",
            "startswith": "string starts with prefix",
            "endswith": "string ends with suffix",
            "isnull": "value is null (no 'value' param needed)",
            "notnull": "value is not null (no 'value' param needed)",
            "between": "value is between [low, high] (pass list of two)",
        }
        lines.append(f"  {fop:12s} -- {notes.get(fop, '')}")

    lines.append("")
    lines.append("=" * 60)
    lines.append("AGGREGATION FUNCTIONS")
    lines.append("=" * 60)
    lines.append(f"  {', '.join(AGG_FUNCTIONS)}")

    lines.append("")
    lines.append("=" * 60)
    lines.append("ALLOWED CAST TYPES (astype)")
    lines.append("=" * 60)
    lines.append(f"  {', '.join(ALLOWED_DTYPES)}")

    return "\n".join(lines)
