"""LLM prompt generation for pandaspipe pipeline building.

Assembles a complete prompt that instructs an LLM to produce a valid
JSON pipeline from natural-language instructions (questions or transforms)
and a DataFrame schema.
"""

from __future__ import annotations

import pandas as pd

from pandaspipe.language import language_spec_to_text
from pandaspipe.schema import extract_schema, schema_to_text


def generate_prompt(
    df: pd.DataFrame,
    instructions: str,
    include_examples: bool = True,
) -> str:
    """Generate a complete LLM prompt for pipeline construction.

    Args:
        df: The DataFrame the pipeline will run against.
        instructions: Natural-language instructions. Can be a question
            ("What is the total revenue by region?") or a transform
            ("Add a margin column, rename qty to quantity, sort by revenue").
        include_examples: Whether to include worked examples in the prompt.

    Returns:
        A prompt string ready to send to any capable LLM.
    """
    schema = extract_schema(df)
    schema_text = schema_to_text(schema)
    language_text = language_spec_to_text()
    column_names = schema.column_names()

    sections: list[str] = []

    # ── ROLE ──────────────────────────────────────────────────
    sections.append(_section("ROLE", (
        "You are a data pipeline builder. Given a dataset schema and instructions, "
        "you produce a JSON pipeline that fulfills the request. "
        "Instructions can be analytical questions (e.g., 'What is the total revenue by region?') "
        "or data transformations (e.g., 'Add a margin column, rename qty to quantity, pivot by region'). "
        "The pipeline is a list of step objects, each performing one data operation. "
        "You MUST respond with ONLY valid JSON (no explanation, no markdown fences, no commentary)."
    )))

    # ── DATASET SCHEMA ────────────────────────────────────────
    sections.append(_section("DATASET SCHEMA", schema_text))

    # ── QUERY LANGUAGE ────────────────────────────────────────
    sections.append(_section("QUERY LANGUAGE", language_text))

    # ── RULES ─────────────────────────────────────────────────
    rules = _build_rules(column_names)
    sections.append(_section("RULES", rules))

    # ── EXAMPLES ──────────────────────────────────────────────
    if include_examples:
        examples = _build_examples()
        sections.append(_section("EXAMPLES", examples))

    # ── INSTRUCTIONS ──────────────────────────────────────────
    sections.append(_section("INSTRUCTIONS", instructions))

    # ── OUTPUT FORMAT ─────────────────────────────────────────
    sections.append(_section("OUTPUT FORMAT", (
        "Respond with ONLY a JSON array of step objects. No text before or after.\n"
        "The output must be parseable by json.loads() with no modifications.\n"
        "Do NOT wrap the JSON in markdown code fences.\n"
        "Do NOT include any explanation, commentary, or notes."
    )))

    return "\n\n".join(sections)


# ── Internal helpers ──────────────────────────────────────────


def _section(title: str, body: str) -> str:
    """Format a named section of the prompt."""
    border = "=" * len(title)
    return f"[{title}]\n{border}\n{body}"


def _build_rules(column_names: list[str]) -> str:
    """Build the rules section with dataset-specific constraints."""
    cols_str = ", ".join(f'"{c}"' for c in column_names)

    rules = [
        f"1. ONLY reference columns that exist in the dataset: [{cols_str}]. "
        "Do not invent column names.",

        "2. Every step MUST have a unique \"id\" field (e.g., \"s1\", \"s2\", \"s3\").",

        "3. Steps execute sequentially by default. Each step receives the output "
        "of the previous step. To create branches, set \"input\" to a specific step ID.",

        "4. For \"concat\" and \"merge\", you may reference multiple prior step IDs "
        "to combine branching pipelines.",

        "5. Keep pipelines as short as possible. Do not add unnecessary steps.",

        "6. When using \"groupby\", always include the \"agg\" parameter in the same step.",

        "7. For \"compute\" expressions, only use arithmetic operators (+, -, *, /, //, %, **) "
        "and column names. No function calls.",

        "8. If the instructions ask for \"top N\", use a \"sort\" step followed by a \"head\" step.",

        "9. Use \"limit\" or \"head\" to cap results at a reasonable size "
        "(max 1000 rows) unless the instructions explicitly ask for all data.",

        "10. If the instructions are ambiguous, choose the most common interpretation "
        "and produce a valid pipeline rather than refusing.",

        "13. Instructions can be questions OR transformations. For transforms, "
        "apply operations in order and return the transformed DataFrame. "
        "For questions, produce the pipeline that answers the question.",

        "14. For complex transforms that require splitting a DataFrame, applying "
        "different operations to each part, and recombining, use branching with "
        "\"input\": \"source\" and \"concat\" to merge the results.",

        "11. Column names in all steps must match EXACTLY (case-sensitive) the names "
        "in the dataset schema.",

        "12. For filter operations with string operators (contains, startswith, endswith), "
        "the column must be a string/object type.",
    ]

    return "\n".join(rules)


def _build_examples() -> str:
    """Build worked examples showing simple, branching, and complex pipelines."""
    examples: list[str] = []

    # Example 1: Simple filtering and selection
    examples.append(
        "Example 1: Simple filter and select\n"
        'Question: "Show me the name and revenue of companies in the South region"\n'
        "Pipeline:\n"
        "[\n"
        '  {"id": "s1", "op": "filter", "column": "region", "operator": "==", "value": "South"},\n'
        '  {"id": "s2", "op": "select", "columns": ["name", "revenue"]}\n'
        "]"
    )

    # Example 2: Aggregation with sorting
    examples.append(
        "Example 2: Group, aggregate, and sort\n"
        'Question: "What is the total revenue by region, sorted highest to lowest?"\n'
        "Pipeline:\n"
        "[\n"
        '  {"id": "s1", "op": "groupby", "by": "region", "agg": {"revenue": "sum"}},\n'
        '  {"id": "s2", "op": "sort", "by": "revenue", "ascending": false}\n'
        "]"
    )

    # Example 3: Branching pipeline with concat
    examples.append(
        "Example 3: Branching pipeline (compare two segments)\n"
        'Question: "Compare total revenue for the North and South regions side by side"\n'
        "Pipeline:\n"
        "[\n"
        '  {"id": "s1", "op": "filter", "column": "region", "operator": "==", "value": "North"},\n'
        '  {"id": "s2", "op": "groupby", "by": "region", "agg": {"revenue": "sum"}, "input": "s1"},\n'
        '  {"id": "s3", "op": "filter", "column": "region", "operator": "==", "value": "South", "input": "source"},\n'
        '  {"id": "s4", "op": "groupby", "by": "region", "agg": {"revenue": "sum"}, "input": "s3"},\n'
        '  {"id": "s5", "op": "concat", "inputs": ["s2", "s4"]}\n'
        "]"
    )

    # Example 4: Computed column + compound filter + top N
    examples.append(
        "Example 4: Compute, compound filter, and top N\n"
        'Question: "Show the top 5 products by profit margin where quantity > 10 and price > 50"\n'
        "Pipeline:\n"
        "[\n"
        '  {"id": "s1", "op": "compute", "target": "profit_margin", "expression": "(revenue - cost) / revenue"},\n'
        '  {"id": "s2", "op": "filter", "logic": "and", "conditions": [\n'
        '    {"column": "quantity", "operator": ">", "value": 10},\n'
        '    {"column": "price", "operator": ">", "value": 50}\n'
        "  ]},\n"
        '  {"id": "s3", "op": "sort", "by": "profit_margin", "ascending": false},\n'
        '  {"id": "s4", "op": "head", "n": 5}\n'
        "]"
    )

    # Example 5: Transform - add columns, rename, clean
    examples.append(
        "Example 5: Data transformation (add column, fill nulls, rename)\n"
        'Instructions: "Add a margin column (revenue minus cost), fill null discounts with 0, rename qty to quantity"\n'
        "Pipeline:\n"
        "[\n"
        '  {"id": "s1", "op": "compute", "target": "margin", "expression": "revenue - cost"},\n'
        '  {"id": "s2", "op": "fillna", "column": "discount", "value": 0},\n'
        '  {"id": "s3", "op": "rename", "mapping": {"qty": "quantity"}}\n'
        "]"
    )

    # Example 6: Transform - pivot/reshape
    examples.append(
        "Example 6: Reshape (pivot table)\n"
        'Instructions: "Create a cross-table with regions as rows, categories as columns, showing sum of revenue. Fill missing with 0."\n'
        "Pipeline:\n"
        "[\n"
        '  {"id": "s1", "op": "pivot_table", "index": ["region"], "columns": "category", "values": ["revenue"], "aggfunc": "sum", "fill_value": 0}\n'
        "]"
    )

    # Example 7: Transform - split, process differently, recombine
    examples.append(
        "Example 7: Split-transform-recombine\n"
        'Instructions: "For VIP customers, double the revenue. For non-VIP, keep as is. Combine into one table."\n'
        "Pipeline:\n"
        "[\n"
        '  {"id": "vip", "op": "filter", "input": "source", "column": "segment", "operator": "==", "value": "VIP"},\n'
        '  {"id": "vip_boost", "op": "compute", "input": "vip", "target": "revenue", "expression": "revenue * 2"},\n'
        '  {"id": "non_vip", "op": "filter", "input": "source", "column": "segment", "operator": "!=", "value": "VIP"},\n'
        '  {"id": "combined", "op": "concat", "inputs": ["vip_boost", "non_vip"]},\n'
        '  {"id": "final", "op": "sort", "input": "combined", "by": "revenue", "ascending": false}\n'
        "]"
    )

    return "\n\n".join(examples)
