"""Validate JSON pipelines against the query language spec."""

from __future__ import annotations

import json
from typing import Any

import pandas as pd

from pandaspipe.expressions import validate_expression
from pandaspipe.language import AGG_FUNCTIONS, ALLOWED_DTYPES, FILTER_OPERATORS, OPERATIONS
from pandaspipe.models import DataFrameSchema, PipelineStep, PipelineValidationError, ValidationResult
from pandaspipe.schema import extract_schema


def validate_pipeline(
    pipeline_json: str | dict | list,
    df: pd.DataFrame,
) -> ValidationResult:
    """Validate a JSON pipeline against the DataFrame schema.

    Args:
        pipeline_json: JSON string, dict with "pipeline" key, or list of step dicts.
        df: The DataFrame this pipeline will run against.

    Returns:
        ValidationResult with is_valid, errors, and parsed pipeline steps.
    """
    errors: list[PipelineValidationError] = []

    # 1. Parse JSON
    raw_steps = _parse_json(pipeline_json, errors)
    if errors:
        return ValidationResult(is_valid=False, errors=errors)

    # 2. Extract schema for column validation
    schema = extract_schema(df, sample_values=0)
    column_names = set(schema.column_names())
    numeric_columns = set(schema.numeric_columns())

    # 3. Parse into PipelineStep models
    steps: list[PipelineStep] = []
    step_ids: set[str] = {"source"}

    for i, raw in enumerate(raw_steps):
        if not isinstance(raw, dict):
            errors.append(PipelineValidationError(
                step_id=f"step_{i}",
                message=f"Step {i} is not a dict: {type(raw).__name__}",
            ))
            continue

        step_id = raw.get("id", f"auto_{i}")
        op = raw.get("op")

        if not op:
            errors.append(PipelineValidationError(step_id=step_id, field="op", message="Missing 'op' field"))
            continue

        if op not in OPERATIONS:
            errors.append(PipelineValidationError(
                step_id=step_id, field="op",
                message=f"Unknown operation '{op}'. Valid: {', '.join(sorted(OPERATIONS.keys()))}",
            ))
            continue

        # Check for duplicate IDs
        if step_id in step_ids and step_id != f"auto_{i}":
            errors.append(PipelineValidationError(
                step_id=step_id, field="id",
                message=f"Duplicate step ID '{step_id}'",
            ))

        step_ids.add(step_id)

        # Extract input reference
        input_ref = raw.get("input")
        if input_ref and input_ref not in step_ids:
            errors.append(PipelineValidationError(
                step_id=step_id, field="input",
                message=f"Input '{input_ref}' references unknown step. Available: {sorted(step_ids)}",
            ))

        # Extract params (everything except id, op, input)
        params = {k: v for k, v in raw.items() if k not in ("id", "op", "input")}

        # Validate operation-specific params
        _validate_op_params(step_id, op, params, column_names, numeric_columns, step_ids, errors)

        # Track columns created by compute/assign/rename steps
        # Use language spec param names: compute uses "target", assign uses "columns" (dict)
        if op == "compute" and "target" in params:
            column_names.add(params["target"])
            numeric_columns.add(params["target"])  # computed columns are numeric
        elif op == "assign" and "columns" in params:
            for col_name in params["columns"]:
                column_names.add(col_name)
        elif op == "rename" and "mapping" in params:
            for old, new in params["mapping"].items():
                if old in column_names:
                    column_names.discard(old)
                    column_names.add(new)
                if old in numeric_columns:
                    numeric_columns.discard(old)
                    numeric_columns.add(new)

        steps.append(PipelineStep(id=step_id, op=op, input=input_ref, params=params))

    if not steps and not errors:
        errors.append(PipelineValidationError(message="Pipeline is empty"))

    return ValidationResult(
        is_valid=len(errors) == 0,
        errors=errors,
        pipeline=steps,
    )


def _parse_json(
    pipeline_json: str | dict | list,
    errors: list[PipelineValidationError],
) -> list[dict]:
    """Parse the raw JSON input into a list of step dicts."""
    if isinstance(pipeline_json, str):
        # Strip markdown code fences if present
        text = pipeline_json.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            text = "\n".join(lines[1:])
            if text.rstrip().endswith("```"):
                text = text.rstrip()[:-3]
            text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            # Try to find JSON object in the text
            start = text.find("{")
            end = text.rfind("}") + 1
            if start >= 0 and end > start:
                try:
                    data = json.loads(text[start:end])
                except json.JSONDecodeError:
                    errors.append(PipelineValidationError(message=f"Invalid JSON: {e}"))
                    return []
            else:
                errors.append(PipelineValidationError(message=f"Invalid JSON: {e}"))
                return []
    elif isinstance(pipeline_json, (dict, list)):
        data = pipeline_json
    else:
        errors.append(PipelineValidationError(message=f"Expected str, dict, or list, got {type(pipeline_json).__name__}"))
        return []

    # Extract the pipeline list
    if isinstance(data, dict):
        if "pipeline" in data:
            steps = data["pipeline"]
        else:
            errors.append(PipelineValidationError(message="JSON object missing 'pipeline' key"))
            return []
    elif isinstance(data, list):
        steps = data
    else:
        errors.append(PipelineValidationError(message=f"Expected dict or list at top level, got {type(data).__name__}"))
        return []

    if not isinstance(steps, list):
        errors.append(PipelineValidationError(message=f"'pipeline' must be a list, got {type(steps).__name__}"))
        return []

    return steps


def _validate_op_params(
    step_id: str,
    op: str,
    params: dict[str, Any],
    columns: set[str],
    numeric_columns: set[str],
    step_ids: set[str],
    errors: list[PipelineValidationError],
) -> None:
    """Validate operation-specific parameters."""

    def _check_column(col_name: str, field: str = "column"):
        if col_name not in columns:
            errors.append(PipelineValidationError(
                step_id=step_id, field=field,
                message=f"Column '{col_name}' not found. Available: {sorted(columns)}",
            ))

    def _check_columns(col_list: list, field: str = "columns"):
        if not isinstance(col_list, list):
            errors.append(PipelineValidationError(
                step_id=step_id, field=field,
                message=f"'{field}' must be a list",
            ))
            return
        for c in col_list:
            _check_column(c, field)

    if op == "filter":
        # Compound filter
        if "logic" in params and "conditions" in params:
            if params["logic"] not in ("and", "or"):
                errors.append(PipelineValidationError(
                    step_id=step_id, field="logic",
                    message=f"Logic must be 'and' or 'or', got '{params['logic']}'",
                ))
            conditions = params.get("conditions", [])
            if not isinstance(conditions, list) or len(conditions) == 0:
                errors.append(PipelineValidationError(
                    step_id=step_id, field="conditions",
                    message="Compound filter must have a non-empty 'conditions' list",
                ))
            for cond in conditions:
                if isinstance(cond, dict):
                    if "column" in cond:
                        _check_column(cond["column"])
                    if "operator" in cond and cond["operator"] not in FILTER_OPERATORS:
                        errors.append(PipelineValidationError(
                            step_id=step_id, field="operator",
                            message=f"Unknown filter operator '{cond['operator']}'",
                        ))
        # Single filter
        elif "column" in params:
            _check_column(params["column"])
            operator = params.get("operator")
            if operator and operator not in FILTER_OPERATORS:
                errors.append(PipelineValidationError(
                    step_id=step_id, field="operator",
                    message=f"Unknown filter operator '{operator}'. Valid: {FILTER_OPERATORS}",
                ))

    elif op in ("select", "drop"):
        _check_columns(params.get("columns", []))

    elif op == "rename":
        mapping = params.get("mapping", {})
        for old_name in mapping:
            _check_column(old_name, "mapping")

    elif op == "sort":
        by = params.get("by")
        if isinstance(by, str):
            _check_column(by, "by")
        elif isinstance(by, list):
            _check_columns(by, "by")

    elif op in ("limit", "head", "tail"):
        n = params.get("n")
        if n is not None and (not isinstance(n, int) or n < 1):
            errors.append(PipelineValidationError(
                step_id=step_id, field="n",
                message=f"'n' must be a positive integer, got {n}",
            ))

    elif op == "groupby":
        # Language spec uses "by" (string or list) and "agg" (dict)
        by = params.get("by")
        if by is not None:
            if isinstance(by, str):
                _check_column(by, "by")
            elif isinstance(by, list):
                _check_columns(by, "by")
        agg = params.get("agg", {})
        if isinstance(agg, dict):
            for col in agg:
                _check_column(col, "agg")
            for col, funcs in agg.items():
                if isinstance(funcs, str):
                    if funcs not in AGG_FUNCTIONS:
                        errors.append(PipelineValidationError(
                            step_id=step_id, field="agg",
                            message=f"Unknown aggregation '{funcs}' for column '{col}'. Valid: {AGG_FUNCTIONS}",
                        ))
                elif isinstance(funcs, list):
                    for f in funcs:
                        if f not in AGG_FUNCTIONS:
                            errors.append(PipelineValidationError(
                                step_id=step_id, field="agg",
                                message=f"Unknown aggregation '{f}' for column '{col}'. Valid: {AGG_FUNCTIONS}",
                            ))

    elif op == "agg":
        # Language spec uses "agg" (dict)
        agg = params.get("agg", {})
        if isinstance(agg, dict):
            for col, funcs in agg.items():
                _check_column(col, "agg")
                if isinstance(funcs, list):
                    for f in funcs:
                        if f not in AGG_FUNCTIONS:
                            errors.append(PipelineValidationError(
                                step_id=step_id, field="agg",
                                message=f"Unknown aggregation '{f}' for column '{col}'",
                            ))
                elif isinstance(funcs, str):
                    if funcs not in AGG_FUNCTIONS:
                        errors.append(PipelineValidationError(
                            step_id=step_id, field="agg",
                            message=f"Unknown aggregation '{funcs}' for column '{col}'",
                        ))

    elif op == "pivot_table":
        # Language spec: index can be string or list
        idx = params.get("index", [])
        if isinstance(idx, str):
            idx = [idx]
        _check_columns(idx, "index")
        if "columns" in params and params["columns"]:
            _check_column(params["columns"], "columns")
        vals = params.get("values", [])
        if isinstance(vals, str):
            vals = [vals]
        _check_columns(vals, "values")

    elif op == "compute":
        expression = params.get("expression", "")
        if expression:
            expr_errors = validate_expression(expression, list(columns))
            for e in expr_errors:
                errors.append(PipelineValidationError(step_id=step_id, field="expression", message=e))

    elif op == "fillna":
        if "column" in params:
            _check_column(params["column"])
        method = params.get("method")
        if method and method not in ("ffill", "bfill", "mean", "median"):
            errors.append(PipelineValidationError(
                step_id=step_id, field="method",
                message=f"Unknown fillna method '{method}'. Valid: ffill, bfill, mean, median",
            ))

    elif op == "drop_duplicates":
        # Language spec uses "subset"
        subset = params.get("subset")
        if subset:
            _check_columns(subset, "subset")

    elif op == "concat":
        inputs = params.get("inputs", [])
        if not isinstance(inputs, list) or len(inputs) < 2:
            errors.append(PipelineValidationError(
                step_id=step_id, field="inputs",
                message="concat requires 'inputs' list with at least 2 step IDs",
            ))
        for ref in inputs:
            if ref not in step_ids:
                errors.append(PipelineValidationError(
                    step_id=step_id, field="inputs",
                    message=f"concat input '{ref}' references unknown step",
                ))

    elif op == "merge":
        # Language spec uses "right" (step ID)
        right = params.get("right")
        if not right:
            errors.append(PipelineValidationError(
                step_id=step_id, field="right",
                message="merge requires 'right' (step ID for right DataFrame)",
            ))
        elif right not in step_ids:
            errors.append(PipelineValidationError(
                step_id=step_id, field="right",
                message=f"merge right '{right}' references unknown step",
            ))
        how = params.get("how", "inner")
        if how not in ("inner", "left", "right", "outer"):
            errors.append(PipelineValidationError(
                step_id=step_id, field="how",
                message=f"merge 'how' must be inner/left/right/outer, got '{how}'",
            ))

    elif op == "astype":
        # Language spec uses "mapping" (dict of col -> dtype)
        mapping = params.get("mapping", {})
        if isinstance(mapping, dict):
            for col, dtype in mapping.items():
                _check_column(col, "mapping")
                if dtype not in ALLOWED_DTYPES:
                    errors.append(PipelineValidationError(
                        step_id=step_id, field="mapping",
                        message=f"Unknown dtype '{dtype}' for column '{col}'. Valid: {ALLOWED_DTYPES}",
                    ))

    elif op == "assign":
        # Language spec uses "columns" (dict)
        cols_dict = params.get("columns", {})
        # No column existence check needed since assign creates/overwrites columns

    elif op == "value_counts":
        if "column" in params:
            _check_column(params["column"])

    elif op == "correlation":
        if "columns" in params:
            _check_columns(params["columns"])

    elif op == "describe":
        if "columns" in params and params["columns"]:
            _check_columns(params["columns"])
