"""Comprehensive test suite for pandaspipe."""

import json

import numpy as np
import pandas as pd
import pytest

import pandaspipe as pp
from pandaspipe.expressions import evaluate_expression, validate_expression
from pandaspipe.schema import extract_schema, schema_to_text


@pytest.fixture
def sample_df():
    np.random.seed(42)
    return pd.DataFrame({
        "region": np.random.choice(["North", "South", "East", "West"], 500),
        "category": np.random.choice(["Electronics", "Clothing", "Food"], 500),
        "segment": np.random.choice(["VIP", "New", "Returning"], 500),
        "revenue": np.random.lognormal(5, 1, 500).round(2),
        "quantity": np.random.randint(1, 20, 500),
        "discount": np.random.uniform(0, 30, 500).round(2),
        "notes": np.random.choice(["good", "ok", "bad", None], 500),
    })


# ============================================================
# Schema
# ============================================================

class TestSchema:
    def test_extract_schema(self, sample_df):
        schema = extract_schema(sample_df)
        assert schema.row_count == 500
        assert schema.column_count == 7
        assert len(schema.columns) == 7

    def test_numeric_detection(self, sample_df):
        schema = extract_schema(sample_df)
        numeric = schema.numeric_columns()
        assert "revenue" in numeric
        assert "quantity" in numeric
        assert "region" not in numeric

    def test_categorical_detection(self, sample_df):
        schema = extract_schema(sample_df)
        cat = schema.categorical_columns()
        assert "region" in cat
        assert "category" in cat

    def test_schema_to_text(self, sample_df):
        schema = extract_schema(sample_df)
        text = schema_to_text(schema)
        assert "500 rows" in text
        assert "region" in text
        assert "revenue" in text


# ============================================================
# Prompt
# ============================================================

class TestPrompt:
    def test_generate_prompt(self, sample_df):
        prompt = pp.generate_prompt(sample_df, instructions="Sum revenue by region")
        assert "region" in prompt
        assert "revenue" in prompt
        assert "Sum revenue" in prompt
        assert "pipeline" in prompt.lower()
        assert len(prompt) > 1000

    def test_prompt_contains_language_spec(self, sample_df):
        prompt = pp.generate_prompt(sample_df, instructions="test")
        assert "groupby" in prompt
        assert "filter" in prompt
        assert "concat" in prompt


# ============================================================
# Expressions
# ============================================================

class TestExpressions:
    def test_valid_expression(self):
        errors = validate_expression("revenue * quantity", ["revenue", "quantity"])
        assert errors == []

    def test_valid_arithmetic(self):
        errors = validate_expression("(revenue + 10) / quantity", ["revenue", "quantity"])
        assert errors == []

    def test_invalid_column(self):
        errors = validate_expression("profit * 2", ["revenue", "quantity"])
        assert len(errors) > 0
        assert "profit" in errors[0]

    def test_forbidden_patterns(self):
        errors = validate_expression("__import__('os')", ["revenue"])
        assert len(errors) > 0

    def test_function_calls_rejected(self):
        errors = validate_expression("len(revenue)", ["revenue"])
        assert len(errors) > 0

    def test_evaluate(self, sample_df):
        result = evaluate_expression("revenue * quantity", sample_df)
        expected = sample_df["revenue"] * sample_df["quantity"]
        assert result.equals(expected)

    def test_no_numpy_access(self):
        errors = validate_expression("np.os.system('ls')", ["revenue"])
        assert len(errors) > 0


# ============================================================
# Validation
# ============================================================

class TestValidation:
    def test_valid_pipeline(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "filter", "column": "segment", "operator": "==", "value": "VIP"},
            {"id": "s2", "op": "groupby", "by": ["category"], "agg": {"revenue": "sum"}},
        ]}
        result = pp.validate_pipeline(pipeline, sample_df)
        assert result.is_valid
        assert len(result.pipeline) == 2

    def test_invalid_column(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "filter", "column": "nonexistent", "operator": "==", "value": 1},
        ]}
        result = pp.validate_pipeline(pipeline, sample_df)
        assert not result.is_valid
        assert "nonexistent" in result.errors[0].message

    def test_unknown_operation(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "bogus"},
        ]}
        result = pp.validate_pipeline(pipeline, sample_df)
        assert not result.is_valid

    def test_duplicate_step_ids(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "head", "n": 10},
            {"id": "s1", "op": "tail", "n": 5},
        ]}
        result = pp.validate_pipeline(pipeline, sample_df)
        assert not result.is_valid

    def test_invalid_json_string(self, sample_df):
        result = pp.validate_pipeline("not valid json", sample_df)
        assert not result.is_valid

    def test_json_string_with_code_fences(self, sample_df):
        json_str = '```json\n{"pipeline": [{"id": "s1", "op": "head", "n": 5}]}\n```'
        result = pp.validate_pipeline(json_str, sample_df)
        assert result.is_valid

    def test_compute_tracks_new_column(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "c1", "op": "compute", "target": "total", "expression": "revenue * quantity"},
            {"id": "f1", "op": "filter", "column": "total", "operator": ">", "value": 100},
        ]}
        result = pp.validate_pipeline(pipeline, sample_df)
        assert result.is_valid

    def test_invalid_filter_operator(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "filter", "column": "revenue", "operator": "LIKE", "value": "test"},
        ]}
        result = pp.validate_pipeline(pipeline, sample_df)
        assert not result.is_valid

    def test_concat_needs_two_inputs(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "concat", "inputs": ["source"]},
        ]}
        result = pp.validate_pipeline(pipeline, sample_df)
        assert not result.is_valid


# ============================================================
# Execution
# ============================================================

class TestExecution:
    def test_simple_filter(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "filter", "column": "segment", "operator": "==", "value": "VIP"},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) < len(sample_df)
        assert all(result.result_df["segment"] == "VIP")

    def test_compound_filter(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "filter", "logic": "and", "conditions": [
                {"column": "segment", "operator": "==", "value": "VIP"},
                {"column": "revenue", "operator": ">", "value": 100},
            ]},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert all(result.result_df["segment"] == "VIP")
        assert all(result.result_df["revenue"] > 100)

    def test_filter_in(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "filter", "column": "region", "operator": "in", "value": ["North", "South"]},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert set(result.result_df["region"].unique()).issubset({"North", "South"})

    def test_groupby(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "groupby", "by": ["region"], "agg": {"revenue": "sum"}},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) == sample_df["region"].nunique()

    def test_sort(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "groupby", "by": ["region"], "agg": {"revenue": "sum"}},
            {"id": "s2", "op": "sort", "by": "revenue", "ascending": False},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        values = result.result_df["revenue"].tolist()
        assert values == sorted(values, reverse=True)

    def test_compute(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "compute", "target": "total", "expression": "revenue * quantity"},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert "total" in result.result_df.columns
        expected = sample_df["revenue"] * sample_df["quantity"]
        assert result.result_df["total"].equals(expected)

    def test_limit(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "limit", "n": 10},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) == 10

    def test_select(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "select", "columns": ["region", "revenue"]},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert list(result.result_df.columns) == ["region", "revenue"]

    def test_rename(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "rename", "mapping": {"revenue": "sales"}},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert "sales" in result.result_df.columns
        assert "revenue" not in result.result_df.columns

    def test_drop(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "drop", "columns": ["notes", "discount"]},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert "notes" not in result.result_df.columns

    def test_value_counts(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "value_counts", "column": "region"},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) == sample_df["region"].nunique()

    def test_describe(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "describe", "columns": ["revenue", "quantity"]},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success

    def test_correlation(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "correlation", "columns": ["revenue", "quantity", "discount"]},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success

    def test_pivot_table(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "pivot_table", "index": ["region"], "columns": "category",
             "values": ["revenue"], "aggfunc": "mean", "fill_value": 0},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) == sample_df["region"].nunique()

    def test_drop_duplicates(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "select", "columns": ["region", "category"]},
            {"id": "s2", "op": "drop_duplicates"},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) <= len(sample_df)

    def test_assign(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "assign", "columns": {"source": "test", "year": 2024}},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert "source" in result.result_df.columns
        assert all(result.result_df["source"] == "test")


# ============================================================
# Branching (DAG)
# ============================================================

class TestBranching:
    def test_concat_branches(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "vip", "op": "filter", "input": "source", "column": "segment", "operator": "==", "value": "VIP"},
            {"id": "vip_agg", "op": "groupby", "input": "vip", "by": ["category"], "agg": {"revenue": "sum"}},
            {"id": "new", "op": "filter", "input": "source", "column": "segment", "operator": "==", "value": "New"},
            {"id": "new_agg", "op": "groupby", "input": "new", "by": ["category"], "agg": {"revenue": "sum"}},
            {"id": "combined", "op": "concat", "inputs": ["vip_agg", "new_agg"]},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) == 6  # 3 categories x 2 segments

    def test_source_reference(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "head", "input": "source", "n": 10},
            {"id": "s2", "op": "tail", "input": "source", "n": 10},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) == 10  # last step wins


# ============================================================
# Codegen
# ============================================================

class TestCodegen:
    def test_code_generated(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "s1", "op": "filter", "column": "segment", "operator": "==", "value": "VIP"},
            {"id": "s2", "op": "groupby", "by": ["category"], "agg": {"revenue": "sum"}},
        ]}
        result = pp.run(sample_df, pipeline)
        assert result.code_markdown
        assert "```python" in result.code_markdown
        assert "groupby" in result.code_markdown

    def test_compute_codegen_uses_subscript(self, sample_df):
        pipeline = {"pipeline": [
            {"id": "c1", "op": "compute", "target": "total", "expression": "revenue * quantity"},
        ]}
        result = pp.run(sample_df, pipeline)
        # Should use df['revenue'] * df['quantity'] not bare names
        assert "['revenue']" in result.code_markdown
        assert "['quantity']" in result.code_markdown


# ============================================================
# Convenience
# ============================================================

class TestConvenience:
    def test_run_validates_and_executes(self, sample_df):
        pipeline = {"pipeline": [{"id": "s1", "op": "head", "n": 5}]}
        result = pp.run(sample_df, pipeline)
        assert result.success
        assert len(result.result_df) == 5

    def test_run_raises_on_invalid(self, sample_df):
        pipeline = {"pipeline": [{"id": "s1", "op": "filter", "column": "FAKE", "operator": "==", "value": 1}]}
        with pytest.raises(ValueError, match="Invalid pipeline"):
            pp.run(sample_df, pipeline)
