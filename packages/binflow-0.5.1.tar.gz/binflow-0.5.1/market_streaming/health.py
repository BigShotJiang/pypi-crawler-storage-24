"""Monitor de salud para los streams de mercado.

Componente interno usado por el Manager. El usuario accede al
diagnostico via ``manager.get_health()``, ``manager.is_healthy()``
y ``manager.get_stats()``.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from .models import StreamState, StreamStatus, SystemHealth

if TYPE_CHECKING:
    from .config import Config


class HealthMonitor:
    """Evalua la salud de los streams y del sistema global.

    Detecta streams stale (conectados pero sin datos recientes, segun
    ``stale_threshold_s``) y genera un ``SystemHealth`` consolidado.
    """

    def __init__(self, config: Config) -> None:
        self._config = config

    def evaluate_stream(self, status: StreamStatus) -> StreamState:
        """Evalúa si un stream debe marcarse como stale.

        Solo modifica streams en estado RUNNING cuyo último mensaje
        supera el umbral configurado.
        """
        if status.state != StreamState.RUNNING:
            return status.state

        if status.last_message_at is None:
            return status.state

        age = time.time() - status.last_message_at
        if age > self._config.stale_threshold_s:
            return StreamState.STALE

        return StreamState.RUNNING

    def evaluate_system(
        self,
        streams: dict[str, StreamStatus],
        started_at: float,
    ) -> SystemHealth:
        """Genera un diagnóstico completo del sistema."""
        now = time.time()
        total = len(streams)
        running = 0
        stale = 0
        reconnecting = 0
        stopped = 0
        total_messages = 0

        for status in streams.values():
            total_messages += status.message_count
            evaluated = self.evaluate_stream(status)

            if evaluated == StreamState.RUNNING:
                running += 1
            elif evaluated == StreamState.STALE:
                stale += 1
            elif evaluated == StreamState.RECONNECTING:
                reconnecting += 1
            elif evaluated in (StreamState.STOPPED, StreamState.FAILED):
                stopped += 1

        is_healthy = total > 0 and stale == 0 and stopped == 0

        return SystemHealth(
            is_healthy=is_healthy,
            total_streams=total,
            running_streams=running,
            stale_streams=stale,
            reconnecting_streams=reconnecting,
            stopped_streams=stopped,
            uptime_s=now - started_at,
            total_messages=total_messages,
            stream_details=dict(streams),
        )
