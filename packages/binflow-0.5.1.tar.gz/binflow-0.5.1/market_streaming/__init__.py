"""Motor de WebSockets persistente para datos de mercado de Binance.

Proporciona streaming en tiempo real de trades, order book, klines,
tickers y mas, con reconexion automatica, cache en memoria thread-safe
y observabilidad integrada. Soporta Spot, USD-M Futures y COIN-M Futures.

Cada ``Manager`` opera sobre un mercado y tipo de stream. Los datos se
consultan con ``.get()`` (ultimo dato) y ``.get_recent()`` (historial).

Uso basico::

    from market_streaming import Manager, Config

    config = Config(
        stream_type="trade",
        symbols=["BTCUSDT", "ETHUSDT"],
        max_history=500,
    )

    with Manager(config) as mgr:
        # Ultimo trade de un simbolo
        trade = mgr.get("BTCUSDT")

        # Todos los simbolos
        all_trades = mgr.get()

        # Historial reciente
        recent = mgr.get_recent("BTCUSDT", limit=50)
"""

from .cache import MarketDataCache
from .config import MARKET_DEPTH_PATHS, MARKET_REST_URLS, MARKET_URLS, Market, Config
from .exceptions import (
    FatalStreamError,
    ManagerNotRunningError,
    MarketStreamError,
    StreamAlreadyExistsError,
    StreamNotFoundError,
)
from .health import HealthMonitor
from .logging_config import setup_logging, teardown_logging
from .manager import Manager
from .models import (
    AggTrade,
    BookTicker,
    Kline,
    Liquidation,
    MiniTicker,
    OrderBookLevel,
    OrderBookSnapshot,
    StreamState,
    StreamStatus,
    StreamType,
    SystemHealth,
    Ticker,
    Trade,
)
from .worker import Worker

__all__ = [
    "Manager",
    "Config",
    "Worker",
    "MarketDataCache",
    "Market",
    "MARKET_URLS",
    "MARKET_REST_URLS",
    "MARKET_DEPTH_PATHS",
    "HealthMonitor",
    "Trade",
    "AggTrade",
    "Kline",
    "Liquidation",
    "Ticker",
    "MiniTicker",
    "BookTicker",
    "OrderBookLevel",
    "OrderBookSnapshot",
    "StreamState",
    "StreamStatus",
    "StreamType",
    "SystemHealth",
    "MarketStreamError",
    "StreamAlreadyExistsError",
    "StreamNotFoundError",
    "ManagerNotRunningError",
    "FatalStreamError",
    "setup_logging",
    "teardown_logging",
]
