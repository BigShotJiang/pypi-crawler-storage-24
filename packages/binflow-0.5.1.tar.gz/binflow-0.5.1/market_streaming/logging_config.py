"""Configuracion de logging con rotacion y persistencia en disco.

Configura el logger raiz del paquete ``market_streaming`` con:
- salida a consola (nivel configurable)
- archivo rotado por tamano (RotatingFileHandler)
- archivo separado solo para errores

La rotacion evita que los logs llenen el disco del servidor.
"""

from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import Config

PACKAGE_LOGGER_NAME = "market_streaming"

# Formato detallado para archivos (incluye timestamp, nivel, modulo y linea)
FILE_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s"

# Formato mas compacto para consola
CONSOLE_FORMAT = "%(asctime)s | %(levelname)-8s | %(message)s"

DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logging(config: Config) -> logging.Logger:
    """Configura el sistema de logging del paquete.

    Crea el directorio de logs si no existe y configura tres handlers:

    1. **Consola** -- nivel configurable, formato compacto.
    2. **Archivo general** (``binflow.log``) -- todo desde DEBUG, rotado por tamano.
    3. **Archivo de errores** (``binflow.error.log``) -- solo WARNING+, rotado.

    Parameters
    ----------
    config : Config
        Configuracion con parametros de logging.

    Returns
    -------
    logging.Logger
        Logger raiz del paquete, ya configurado.
    """
    logger = logging.getLogger(PACKAGE_LOGGER_NAME)

    # Evitar configurar dos veces si se llama start() multiples veces
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    # No propagar al root logger para evitar duplicados
    logger.propagate = False

    # --- Consola ---
    console_handler = logging.StreamHandler()
    console_handler.setLevel(config.log_level)
    console_handler.setFormatter(logging.Formatter(CONSOLE_FORMAT, DATE_FORMAT))
    logger.addHandler(console_handler)

    # --- Archivos (solo si hay directorio configurado) ---
    if config.log_dir:
        log_path = Path(config.log_dir)
        log_path.mkdir(parents=True, exist_ok=True)

        # Archivo general: todo desde DEBUG
        general_handler = RotatingFileHandler(
            filename=log_path / "binflow.log",
            maxBytes=config.log_max_bytes,
            backupCount=config.log_backup_count,
            encoding="utf-8",
        )
        general_handler.setLevel(logging.DEBUG)
        general_handler.setFormatter(logging.Formatter(FILE_FORMAT, DATE_FORMAT))
        logger.addHandler(general_handler)

        # Archivo de errores: solo WARNING+
        error_handler = RotatingFileHandler(
            filename=log_path / "binflow.error.log",
            maxBytes=config.log_max_bytes,
            backupCount=config.log_backup_count,
            encoding="utf-8",
        )
        error_handler.setLevel(logging.WARNING)
        error_handler.setFormatter(logging.Formatter(FILE_FORMAT, DATE_FORMAT))
        logger.addHandler(error_handler)

        logger.debug(
            "Logging inicializado: dir=%s, max_bytes=%d, backups=%d",
            log_path,
            config.log_max_bytes,
            config.log_backup_count,
        )

    return logger


def teardown_logging() -> None:
    """Cierra y elimina todos los handlers del logger del paquete.

    Llamar al detener el manager para liberar file handles.
    """
    logger = logging.getLogger(PACKAGE_LOGGER_NAME)
    for handler in logger.handlers[:]:
        handler.close()
        logger.removeHandler(handler)
