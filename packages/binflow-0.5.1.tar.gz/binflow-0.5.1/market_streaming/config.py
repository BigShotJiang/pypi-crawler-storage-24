"""Configuracion centralizada del sistema de streaming de mercado.

``Config`` es el unico objeto de configuracion. Todos los campos tipo
enum (``market``, ``stream_type``, ``log_level``) aceptan strings
case-insensitive. ``symbols`` se normaliza a mayusculas automaticamente.
"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass, field

from .models import StreamType


class Market(str, enum.Enum):
    """Mercados soportados de Binance.

    Se pasa como string en ``Config(market="spot")``.
    """

    SPOT = "spot"
    FUTURES_USD = "futures_usd"   # USD-M Futures
    FUTURES_COIN = "futures_coin"  # COIN-M Futures


MARKET_URLS: dict[Market, str] = {
    Market.SPOT: "wss://stream.binance.com:9443/ws",
    Market.FUTURES_USD: "wss://fstream.binance.com/ws",
    Market.FUTURES_COIN: "wss://dstream.binance.com/ws",
}

MARKET_REST_URLS: dict[Market, str] = {
    Market.SPOT: "https://api.binance.com",
    Market.FUTURES_USD: "https://fapi.binance.com",
    Market.FUTURES_COIN: "https://dapi.binance.com",
}

MARKET_DEPTH_PATHS: dict[Market, str] = {
    Market.SPOT: "/api/v3/depth",
    Market.FUTURES_USD: "/fapi/v1/depth",
    Market.FUTURES_COIN: "/dapi/v1/depth",
}


@dataclass(slots=True)
class Config:
    """Configuracion completa del motor de WebSockets.

    Centraliza todos los parametros operativos. Cada ``Manager`` opera
    sobre un unico mercado y tipo de stream, definidos aqui. Los campos
    ``market``, ``stream_type`` y ``log_level`` aceptan strings
    case-insensitive para evitar imports innecesarios.

    Campos obligatorios segun ``stream_type``
    ------------------------------------------
    - ``"trade"`` / ``"agg_trade"``: requiere ``max_history > 0``
      (cuantos trades recientes mantener en cache).
    - ``"depth"``: requiere ``depth > 0``
      (niveles por lado: ``depth=20`` mantiene 20 bids + 20 asks).
    - ``"kline"``: usa ``interval`` (default ``"1m"``).
    - ``"ticker"`` / ``"mini_ticker"`` / ``"book_ticker"``: sin campos
      adicionales obligatorios.

    Ejemplos::

        # Stream de trades
        Config(
            market="spot",
            stream_type="trade",
            symbols=["BTCUSDT", "ETHUSDT"],
            max_history=500,
        )

        # Order book
        Config(
            market="futures_usd",
            stream_type="depth",
            symbols=["BTCUSDT"],
            depth=20,
        )

        # Klines de 5 minutos
        Config(
            stream_type="kline",
            symbols=["BTCUSDT"],
            interval="5m",
        )

    Valores validos para ``market``: ``"spot"``, ``"futures_usd"``,
    ``"futures_coin"``.

    Valores validos para ``stream_type``: ``"trade"``, ``"depth"``
    (alias ``"order_book"``), ``"agg_trade"``, ``"kline"``, ``"ticker"``,
    ``"mini_ticker"``, ``"book_ticker"``.

    Valores validos para ``log_level``: ``"debug"``, ``"info"``,
    ``"warning"``, ``"error"``, ``"critical"``.

    Los ``symbols`` son case-insensitive y se normalizan a mayusculas.

    Se puede forzar una URL personalizada con ``base_url``,
    que tiene prioridad sobre ``market``.
    """

    # --- Mercado y stream ---
    market: Market | str = Market.SPOT
    stream_type: StreamType | str = StreamType.TRADE
    symbols: list[str] = field(default_factory=list)
    interval: str = "1m"
    base_url: str = ""
    ping_interval_s: float = 20.0
    ping_timeout_s: float = 10.0

    # --- Cache ---
    max_history: int = 0
    depth: int = 0

    # --- Reconexión ---
    reconnect_base_delay_s: float = 1.0
    reconnect_max_delay_s: float = 60.0
    reconnect_jitter_factor: float = 0.2
    max_reconnect_attempts: int = 0  # 0 = sin límite

    # --- Health ---
    stale_threshold_s: float = 30.0
    health_check_interval_s: float = 5.0

    # --- Logging ---
    log_level: int | str = field(default=logging.INFO)
    log_dir: str = "logs"
    log_max_bytes: int = 10 * 1024 * 1024  # 10 MB por archivo
    log_backup_count: int = 5               # maximo 5 archivos rotados

    def __post_init__(self) -> None:
        if isinstance(self.market, str) and not isinstance(self.market, Market):
            try:
                self.market = Market(self.market.lower())
            except ValueError:
                valid = ", ".join(m.value for m in Market)
                raise ValueError(
                    f"Mercado no reconocido: {self.market!r}. "
                    f"Valores validos: {valid}"
                ) from None

        if isinstance(self.stream_type, str) and not isinstance(self.stream_type, StreamType):
            _aliases: dict[str, StreamType] = {
                "trade": StreamType.TRADE,
                "trades": StreamType.TRADE,
                "depth": StreamType.DEPTH,
                "order_book": StreamType.DEPTH,
                "orderbook": StreamType.DEPTH,
                "agg_trade": StreamType.AGG_TRADE,
                "aggtrade": StreamType.AGG_TRADE,
                "kline": StreamType.KLINE,
                "klines": StreamType.KLINE,
                "ticker": StreamType.TICKER,
                "mini_ticker": StreamType.MINI_TICKER,
                "miniticker": StreamType.MINI_TICKER,
                "book_ticker": StreamType.BOOK_TICKER,
                "bookticker": StreamType.BOOK_TICKER,
                "force_order": StreamType.FORCE_ORDER,
                "forceorder": StreamType.FORCE_ORDER,
                "liquidation": StreamType.FORCE_ORDER,
                "liquidations": StreamType.FORCE_ORDER,
            }
            key = self.stream_type.lower().strip()
            resolved_st = _aliases.get(key)
            if resolved_st is None:
                valid = ", ".join(sorted(_aliases))
                raise ValueError(
                    f"Tipo de stream no reconocido: {self.stream_type!r}. "
                    f"Valores validos: {valid}"
                )
            self.stream_type = resolved_st

        self.symbols = [s.upper() for s in self.symbols]

        # Validar campos obligatorios segun tipo de stream
        if self.stream_type in (StreamType.TRADE, StreamType.AGG_TRADE, StreamType.FORCE_ORDER):
            if self.max_history <= 0:
                raise ValueError(
                    f"max_history debe ser > 0 para stream_type={self.stream_type.value!r}. "
                    f"Indica cuantos elementos recientes quieres mantener en cache."
                )
        if self.stream_type == StreamType.FORCE_ORDER:
            if self.market == Market.SPOT:
                raise ValueError(
                    "stream_type='force_order' solo esta disponible en futuros "
                    "(market='futures_usd' o market='futures_coin')."
                )
        if self.stream_type == StreamType.DEPTH:
            if self.depth <= 0:
                raise ValueError(
                    "depth debe ser > 0 para stream_type='depth'. "
                    "Indica la profundidad del order book a mantener."
                )

        if not self.base_url:
            self.base_url = MARKET_URLS[self.market]

        if isinstance(self.log_level, str):
            resolved = logging.getLevelName(self.log_level.upper())
            if not isinstance(resolved, int):
                raise ValueError(
                    f"Nivel de log no reconocido: {self.log_level!r}. "
                    f"Valores validos: debug, info, warning, error, critical"
                )
            self.log_level = resolved

    def rest_depth_url(self, symbol: str, limit: int = 1000) -> str:
        """URL para GET depth snapshot de un simbolo."""
        base = MARKET_REST_URLS[self.market]
        path = MARKET_DEPTH_PATHS[self.market]
        return f"{base}{path}?symbol={symbol}&limit={limit}"
