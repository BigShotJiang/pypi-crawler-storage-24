"""Modelos de datos de mercado y estado de streams.

Todos los modelos de datos (Trade, OrderBookSnapshot, Kline, etc.) son
dataclasses inmutables (frozen=True) que se obtienen via ``Manager.get()``
y ``Manager.get_recent()``. Cada modelo incluye tanto valores numericos
(float) como cadenas originales de precision (_str) de Binance, y un
metodo ``to_rest_format()`` para compatibilidad con la REST API.
"""

from __future__ import annotations

import enum
import time
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Datos de mercado
# ---------------------------------------------------------------------------

@dataclass(slots=True, frozen=True)
class Trade:
    """Un trade individual ejecutado en Binance.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"trade"``, o como lista con ``manager.get_recent("BTCUSDT")``.

    ``buyer_maker=True`` indica que el comprador era el maker (la orden
    limit estaba en el book), lo que equivale a un trade de venta
    (el vendedor es el taker que cruzo la orden).

    Cada campo numerico tiene su equivalente ``_str`` con la cadena
    original de Binance para preservar la precision decimal completa.

    Incluye ``to_rest_format()`` que devuelve un dict compatible con
    GET /api/v3/trades.
    """

    symbol: str
    trade_id: int
    price: float
    quantity: float
    quote_quantity: float
    buyer_maker: bool
    timestamp_ms: int
    price_str: str = ""
    quantity_str: str = ""
    quote_quantity_str: str = ""
    is_best_match: bool = True
    event_time_ms: int = 0

    def to_rest_format(self) -> dict:
        """Devuelve un dict con los mismos campos que GET /api/v3/trades."""
        return {
            "id": self.trade_id,
            "price": self.price_str or f"{self.price:.8f}",
            "qty": self.quantity_str or f"{self.quantity:.8f}",
            "quoteQty": self.quote_quantity_str or f"{self.quote_quantity:.8f}",
            "time": self.timestamp_ms,
            "isBuyerMaker": self.buyer_maker,
            "isBestMatch": self.is_best_match,
        }


@dataclass(slots=True, frozen=True)
class OrderBookLevel:
    """Un nivel de precio en el order book (un par precio/cantidad).

    Los bids estan ordenados de mayor a menor precio (mejor bid primero).
    Los asks estan ordenados de menor a mayor precio (mejor ask primero).
    """

    price: float
    quantity: float
    price_str: str = ""
    quantity_str: str = ""

    def to_rest_format(self) -> list[str]:
        """Devuelve [price, qty] como cadenas, igual que la REST API."""
        return [
            self.price_str or f"{self.price:.8f}",
            self.quantity_str or f"{self.quantity:.8f}",
        ]


@dataclass(slots=True)
class OrderBookSnapshot:
    """Snapshot actual del order book para un simbolo.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"depth"``. El snapshot se actualiza continuamente con diffs
    del WebSocket. No es frozen porque se muta in-place en el cache.

    ``is_synced=True`` indica que el book paso por la sincronizacion
    REST (snapshot + diffs), garantizando integridad. Un book con
    ``is_synced=False`` solo contiene diffs parciales y puede estar
    incompleto.

    La profundidad (numero de niveles por lado) se configura con
    ``Config(depth=N)``. Por ejemplo, ``depth=20`` mantiene 20 bids
    y 20 asks.

    Incluye ``to_rest_format()`` compatible con GET /api/v3/depth.
    """

    symbol: str
    bids: list[OrderBookLevel] = field(default_factory=list)
    asks: list[OrderBookLevel] = field(default_factory=list)
    last_update_id: int = 0
    timestamp: float = field(default_factory=time.time)
    event_time_ms: int = 0
    transaction_time_ms: int = 0
    is_synced: bool = False

    def to_rest_format(self) -> dict:
        """Devuelve un dict con los mismos campos que GET /api/v3/depth."""
        return {
            "lastUpdateId": self.last_update_id,
            "bids": [level.to_rest_format() for level in self.bids],
            "asks": [level.to_rest_format() for level in self.asks],
        }


@dataclass(slots=True, frozen=True)
class AggTrade:
    """Un trade agregado de Binance.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"agg_trade"``, o como lista con ``manager.get_recent("BTCUSDT")``.

    Agrupa uno o mas trades individuales ejecutados al mismo precio
    y en la misma orden (``first_trade_id`` a ``last_trade_id``).
    Produce menos mensajes que el stream de trades individuales.

    Incluye ``to_rest_format()`` compatible con GET /api/v3/aggTrades.
    """

    symbol: str
    agg_trade_id: int
    price: float
    quantity: float
    first_trade_id: int
    last_trade_id: int
    timestamp_ms: int
    buyer_maker: bool
    price_str: str = ""
    quantity_str: str = ""
    event_time_ms: int = 0

    def to_rest_format(self) -> dict:
        """Devuelve un dict compatible con GET /api/v3/aggTrades."""
        return {
            "a": self.agg_trade_id,
            "p": self.price_str or f"{self.price:.8f}",
            "q": self.quantity_str or f"{self.quantity:.8f}",
            "f": self.first_trade_id,
            "l": self.last_trade_id,
            "T": self.timestamp_ms,
            "m": self.buyer_maker,
            "M": True,
        }


@dataclass(slots=True, frozen=True)
class Kline:
    """Una vela (candlestick) de Binance.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"kline"``. El intervalo se configura con ``Config(interval="5m")``.

    Mientras la vela esta abierta, se actualiza en tiempo real con cada
    tick. Cuando ``is_closed=True``, la vela es definitiva y no cambiara.

    Incluye ``to_rest_format()`` compatible con GET /api/v3/klines.
    """

    symbol: str
    interval: str
    open_time_ms: int
    close_time_ms: int
    open: float
    close: float
    high: float
    low: float
    volume: float
    quote_volume: float
    trades: int
    taker_buy_volume: float
    taker_buy_quote_volume: float
    is_closed: bool
    open_str: str = ""
    close_str: str = ""
    high_str: str = ""
    low_str: str = ""
    volume_str: str = ""
    quote_volume_str: str = ""
    taker_buy_volume_str: str = ""
    taker_buy_quote_volume_str: str = ""
    event_time_ms: int = 0

    def to_rest_format(self) -> list:
        """Devuelve un array compatible con GET /api/v3/klines."""
        return [
            self.open_time_ms,
            self.open_str or f"{self.open:.8f}",
            self.high_str or f"{self.high:.8f}",
            self.low_str or f"{self.low:.8f}",
            self.close_str or f"{self.close:.8f}",
            self.volume_str or f"{self.volume:.8f}",
            self.close_time_ms,
            self.quote_volume_str or f"{self.quote_volume:.8f}",
            self.trades,
            self.taker_buy_volume_str or f"{self.taker_buy_volume:.8f}",
            self.taker_buy_quote_volume_str or f"{self.taker_buy_quote_volume:.8f}",
            "0",
        ]


@dataclass(slots=True, frozen=True)
class Ticker:
    """Estadisticas rolling de 24 horas de Binance.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"ticker"``. Incluye OHLC, volumen, mejor bid/ask, cambio de
    precio, y conteo de trades. Se actualiza cada segundo aprox.

    Incluye ``to_rest_format()`` compatible con GET /api/v3/ticker/24hr.
    """

    symbol: str
    price_change: float
    price_change_pct: float
    weighted_avg_price: float
    prev_close_price: float
    last_price: float
    last_quantity: float
    best_bid_price: float
    best_bid_quantity: float
    best_ask_price: float
    best_ask_quantity: float
    open_price: float
    high_price: float
    low_price: float
    volume: float
    quote_volume: float
    open_time_ms: int
    close_time_ms: int
    first_trade_id: int
    last_trade_id: int
    trade_count: int
    event_time_ms: int = 0
    price_change_str: str = ""
    price_change_pct_str: str = ""
    weighted_avg_price_str: str = ""
    prev_close_price_str: str = ""
    last_price_str: str = ""
    last_quantity_str: str = ""
    best_bid_price_str: str = ""
    best_bid_quantity_str: str = ""
    best_ask_price_str: str = ""
    best_ask_quantity_str: str = ""
    open_price_str: str = ""
    high_price_str: str = ""
    low_price_str: str = ""
    volume_str: str = ""
    quote_volume_str: str = ""

    def to_rest_format(self) -> dict:
        """Devuelve un dict compatible con GET /api/v3/ticker/24hr."""
        return {
            "symbol": self.symbol,
            "priceChange": self.price_change_str or f"{self.price_change:.8f}",
            "priceChangePercent": self.price_change_pct_str or f"{self.price_change_pct:.3f}",
            "weightedAvgPrice": self.weighted_avg_price_str or f"{self.weighted_avg_price:.8f}",
            "prevClosePrice": self.prev_close_price_str or f"{self.prev_close_price:.8f}",
            "lastPrice": self.last_price_str or f"{self.last_price:.8f}",
            "lastQty": self.last_quantity_str or f"{self.last_quantity:.8f}",
            "bidPrice": self.best_bid_price_str or f"{self.best_bid_price:.8f}",
            "bidQty": self.best_bid_quantity_str or f"{self.best_bid_quantity:.8f}",
            "askPrice": self.best_ask_price_str or f"{self.best_ask_price:.8f}",
            "askQty": self.best_ask_quantity_str or f"{self.best_ask_quantity:.8f}",
            "openPrice": self.open_price_str or f"{self.open_price:.8f}",
            "highPrice": self.high_price_str or f"{self.high_price:.8f}",
            "lowPrice": self.low_price_str or f"{self.low_price:.8f}",
            "volume": self.volume_str or f"{self.volume:.8f}",
            "quoteVolume": self.quote_volume_str or f"{self.quote_volume:.8f}",
            "openTime": self.open_time_ms,
            "closeTime": self.close_time_ms,
            "firstId": self.first_trade_id,
            "lastId": self.last_trade_id,
            "count": self.trade_count,
        }


@dataclass(slots=True, frozen=True)
class MiniTicker:
    """Estadisticas 24h reducidas de Binance.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"mini_ticker"``. Version ligera de ``Ticker`` con solo OHLC
    y volumen. Util cuando no necesitas bid/ask ni conteo de trades.
    """

    symbol: str
    close_price: float
    open_price: float
    high_price: float
    low_price: float
    volume: float
    quote_volume: float
    event_time_ms: int = 0
    close_price_str: str = ""
    open_price_str: str = ""
    high_price_str: str = ""
    low_price_str: str = ""
    volume_str: str = ""
    quote_volume_str: str = ""

    def to_rest_format(self) -> dict:
        """Devuelve un dict con campos basicos del ticker."""
        return {
            "symbol": self.symbol,
            "closePrice": self.close_price_str or f"{self.close_price:.8f}",
            "openPrice": self.open_price_str or f"{self.open_price:.8f}",
            "highPrice": self.high_price_str or f"{self.high_price:.8f}",
            "lowPrice": self.low_price_str or f"{self.low_price:.8f}",
            "volume": self.volume_str or f"{self.volume:.8f}",
            "quoteVolume": self.quote_volume_str or f"{self.quote_volume:.8f}",
        }


@dataclass(slots=True, frozen=True)
class BookTicker:
    """Mejor bid/ask en tiempo real de Binance.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"book_ticker"``. Es el stream mas rapido para monitorizar spread.
    Se actualiza con cada cambio en el mejor bid o ask.

    Incluye ``to_rest_format()`` compatible con
    GET /api/v3/ticker/bookTicker.
    """

    symbol: str
    update_id: int
    best_bid_price: float
    best_bid_quantity: float
    best_ask_price: float
    best_ask_quantity: float
    best_bid_price_str: str = ""
    best_bid_quantity_str: str = ""
    best_ask_price_str: str = ""
    best_ask_quantity_str: str = ""

    def to_rest_format(self) -> dict:
        """Devuelve un dict compatible con GET /api/v3/ticker/bookTicker."""
        return {
            "symbol": self.symbol,
            "bidPrice": self.best_bid_price_str or f"{self.best_bid_price:.8f}",
            "bidQty": self.best_bid_quantity_str or f"{self.best_bid_quantity:.8f}",
            "askPrice": self.best_ask_price_str or f"{self.best_ask_price:.8f}",
            "askQty": self.best_ask_quantity_str or f"{self.best_ask_quantity:.8f}",
        }


@dataclass(slots=True, frozen=True)
class Liquidation:
    """Una orden de liquidacion forzada en Binance Futures.

    Se obtiene con ``manager.get("BTCUSDT")`` en un manager de tipo
    ``"force_order"``, o como lista con ``manager.get_recent("BTCUSDT")``.

    Solo disponible en mercados de futuros (USD-M y COIN-M). El campo
    ``side="SELL"`` indica liquidacion de posicion larga; ``"BUY"``
    indica liquidacion de posicion corta.

    Incluye ``to_rest_format()`` compatible con GET /fapi/v1/forceOrders.
    """

    symbol: str
    side: str
    order_type: str
    time_in_force: str
    original_qty: float
    price: float
    average_price: float
    status: str
    last_filled_qty: float
    filled_qty: float
    trade_time_ms: int
    event_time_ms: int = 0
    original_qty_str: str = ""
    price_str: str = ""
    average_price_str: str = ""
    last_filled_qty_str: str = ""
    filled_qty_str: str = ""

    def to_rest_format(self) -> dict:
        """Devuelve un dict compatible con GET /fapi/v1/forceOrders."""
        return {
            "symbol": self.symbol,
            "price": self.price_str or f"{self.price:.8f}",
            "origQty": self.original_qty_str or f"{self.original_qty:.8f}",
            "executedQty": self.filled_qty_str or f"{self.filled_qty:.8f}",
            "averagePrice": self.average_price_str or f"{self.average_price:.8f}",
            "status": self.status,
            "timeInForce": self.time_in_force,
            "type": self.order_type,
            "side": self.side,
            "time": self.trade_time_ms,
        }


# ---------------------------------------------------------------------------
# Estado de streams
# ---------------------------------------------------------------------------

class StreamState(str, enum.Enum):
    """Estado del ciclo de vida de un stream WebSocket.

    Se consulta via ``manager.get_health()`` o
    ``manager.get_stream_status(stream_id)``.
    """

    STARTING = "starting"        # Iniciando conexion
    RUNNING = "running"          # Conectado y recibiendo datos
    RECONNECTING = "reconnecting"  # Reconectando tras error
    STALE = "stale"              # Conectado pero sin datos recientes
    STOPPED = "stopped"          # Detenido de forma limpia
    FAILED = "failed"            # Error fatal, no reconectable


class StreamType(str, enum.Enum):
    """Tipos de stream soportados por Binance.

    Se pasa como string en ``Config(stream_type="trade")``.
    Acepta aliases: ``"order_book"`` -> ``"depth"``,
    ``"trades"`` -> ``"trade"``, etc.
    """

    TRADE = "trade"
    DEPTH = "depth"
    AGG_TRADE = "aggTrade"
    KLINE = "kline"
    TICKER = "ticker"
    MINI_TICKER = "miniTicker"
    BOOK_TICKER = "bookTicker"
    FORCE_ORDER = "forceOrder"


@dataclass(slots=True)
class StreamStatus:
    """Estado operativo de un stream individual (un Worker).

    Se consulta via ``manager.get_all_streams_status()`` o
    ``manager.get_stream_status(stream_id)``.
    """

    stream_id: str
    stream_type: StreamType
    symbol: str
    state: StreamState = StreamState.STARTING
    connected_at: float | None = None
    last_message_at: float | None = None
    reconnect_count: int = 0
    message_count: int = 0
    error_count: int = 0


@dataclass(slots=True)
class SystemHealth:
    """Diagnostico de salud global del sistema.

    Se obtiene con ``manager.get_health()``. El campo ``is_healthy``
    es ``True`` cuando todos los streams estan en estado ``running``
    (ninguno stale, failed ni stopped).
    """

    is_healthy: bool
    total_streams: int
    running_streams: int
    stale_streams: int
    reconnecting_streams: int
    stopped_streams: int
    uptime_s: float
    total_messages: int
    stream_details: dict[str, StreamStatus] = field(default_factory=dict)
