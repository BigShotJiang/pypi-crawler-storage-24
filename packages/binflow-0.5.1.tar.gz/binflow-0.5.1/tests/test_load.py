"""Test de carga: todos los pares USDT+USDC de Binance durante 60 segundos.

Levanta streams de trades contra Binance Spot real usando conexiones
combinadas (multiplexadas), acumula datos durante 60 segundos y verifica
continuidad, unicidad y orden de los trades recibidos para cada simbolo.
"""

import json
import time
import urllib.request

import pytest

from market_streaming import Manager, Config

ACCUMULATION_SECONDS = 60
MAX_RECENT = 200_000
BATCH_SIZE = 200


def _fetch_all_usdt_usdc_symbols() -> list[str]:
    """Obtiene todos los pares USDT y USDC activos de Binance."""
    url = "https://api.binance.com/api/v3/exchangeInfo"
    data = json.loads(urllib.request.urlopen(url, timeout=15).read())
    symbols = sorted([
        s["symbol"] for s in data["symbols"]
        if s["status"] == "TRADING"
        and (s["symbol"].endswith("USDT") or s["symbol"].endswith("USDC"))
        and s["symbol"].isascii()
    ])
    return symbols


@pytest.fixture(scope="module")
def load_results() -> dict[str, list]:
    """Levanta combined streams para todos los USDT+USDC, acumula 60s."""
    symbols = _fetch_all_usdt_usdc_symbols()
    stream_count = len(symbols)
    n_connections = (stream_count + BATCH_SIZE - 1) // BATCH_SIZE
    print(f"\nSymbols obtenidos de Binance: {stream_count}")
    print(f"Conexiones combinadas necesarias: {n_connections}")

    config = Config(
        stream_type="trade",
        max_history=MAX_RECENT,
        log_level="error",
        log_dir="",
    )

    manager = Manager(config)
    manager.start()
    try:
        manager.add_symbols(symbols, batch_size=BATCH_SIZE)
        print(f"Workers creados: {len(manager._workers)}")
        print(f"Acumulando datos durante {ACCUMULATION_SECONDS}s...")

        # Esperar conexion inicial + acumulacion
        time.sleep(5 + ACCUMULATION_SECONDS)

        results = {}
        stats = manager.get_stats()
        for symbol in symbols:
            trades = manager.get_recent(symbol, limit=MAX_RECENT)
            if trades:
                results[symbol] = trades

        results["__stats__"] = stats
        results["__health__"] = manager.get_health()
        results["__stream_count__"] = stream_count
        results["__n_workers__"] = len(manager._workers)
    finally:
        manager.stop()

    return results


class TestLoadStreams:
    """Verifica que cientos de streams simultaneos mantienen datos integros."""

    def _stream_count(self, load_results: dict) -> int:
        return load_results["__stream_count__"]

    def test_sufficient_symbols_received_data(self, load_results: dict) -> None:
        data_symbols = {k for k in load_results if not k.startswith("__")}
        total = len(data_symbols)
        stream_count = self._stream_count(load_results)
        print(f"\nSymbols con datos: {total}/{stream_count}")
        # Con 60s de acumulacion, al menos 15% deberian tener trades
        min_expected = stream_count * 0.15
        assert total >= min_expected, (
            f"Solo {total} symbols recibieron datos, esperado >= {min_expected:.0f}"
        )

    def test_continuity_all_symbols(self, load_results: dict) -> None:
        """Verifica que los trade IDs son consecutivos sin huecos."""
        failures = []
        for symbol, trades in load_results.items():
            if symbol.startswith("__"):
                continue
            ids = [t.trade_id for t in trades]
            if len(ids) < 2:
                continue
            gaps = []
            for i in range(len(ids) - 1):
                diff = ids[i + 1] - ids[i]
                if diff != 1:
                    gaps.append((ids[i], ids[i + 1], diff - 1))
            if gaps:
                total_missing = sum(g[2] for g in gaps)
                failures.append(
                    f"{symbol}: {total_missing} trades perdidos en {len(gaps)} huecos "
                    f"(de {len(ids)} recibidos)"
                )
        if failures:
            report = "\n  ".join(failures)
            pytest.fail(
                f"CONTINUIDAD ROTA en {len(failures)} symbols:\n  {report}"
            )

    def test_uniqueness_all_symbols(self, load_results: dict) -> None:
        failures = []
        for symbol, trades in load_results.items():
            if symbol.startswith("__"):
                continue
            ids = [t.trade_id for t in trades]
            dupes = len(ids) - len(set(ids))
            if dupes > 0:
                failures.append(f"{symbol}: {dupes} duplicados de {len(ids)}")
        assert not failures, f"DUPLICADOS:\n  " + "\n  ".join(failures)

    def test_order_all_symbols(self, load_results: dict) -> None:
        failures = []
        for symbol, trades in load_results.items():
            if symbol.startswith("__"):
                continue
            ids = [t.trade_id for t in trades]
            if len(ids) < 2:
                continue
            for i in range(len(ids) - 1):
                if ids[i] >= ids[i + 1]:
                    failures.append(
                        f"{symbol}: ID {ids[i]} >= {ids[i + 1]} en posicion {i}"
                    )
                    break
        assert not failures, f"ORDEN ROTO:\n  " + "\n  ".join(failures)

    def test_timestamps_non_decreasing(self, load_results: dict) -> None:
        failures = []
        for symbol, trades in load_results.items():
            if symbol.startswith("__"):
                continue
            ts = [t.timestamp_ms for t in trades]
            if len(ts) < 2:
                continue
            for i in range(len(ts) - 1):
                if ts[i] > ts[i + 1]:
                    failures.append(
                        f"{symbol}: ts {ts[i]} > {ts[i + 1]} en posicion {i}"
                    )
                    break
        assert not failures, f"TIMESTAMPS DESORDENADOS:\n  " + "\n  ".join(failures)

    def test_workers_healthy(self, load_results: dict) -> None:
        """Verifica que los workers funcionaron correctamente."""
        health = load_results["__health__"]
        n_workers = load_results["__n_workers__"]
        print(f"\nWorkers: {n_workers}")
        print(f"Running: {health.running_streams}")
        print(f"Stale: {health.stale_streams}")
        print(f"Reconnecting: {health.reconnecting_streams}")
        print(f"Total mensajes: {health.total_messages:,}")
        assert health.running_streams >= n_workers * 0.8, (
            f"Solo {health.running_streams}/{n_workers} workers running"
        )

    def test_total_messages_reasonable(self, load_results: dict) -> None:
        stats = load_results["__stats__"]
        total = stats["total_messages"]
        print(f"\nTotal mensajes procesados: {total:,}")
        # Con 700+ symbols en 60s deberiamos recibir miles
        assert total > 500, f"Solo {total} mensajes en {ACCUMULATION_SECONDS}s"

    def test_load_summary(self, load_results: dict) -> None:
        """Resumen final: no es un assert, es para visibilidad."""
        stream_count = self._stream_count(load_results)
        n_workers = load_results["__n_workers__"]
        data_symbols = {k: v for k, v in load_results.items() if not k.startswith("__")}
        total_trades = sum(len(v) for v in data_symbols.values())
        trade_counts = sorted(
            [(s, len(t)) for s, t in data_symbols.items()],
            key=lambda x: -x[1],
        )
        print(f"\n{'='*60}")
        print(f"  RESUMEN PRUEBA DE CARGA")
        print(f"{'='*60}")
        print(f"  Symbols:         {stream_count}")
        print(f"  Conexiones WS:   {n_workers}")
        print(f"  Duracion:        {ACCUMULATION_SECONDS}s")
        print(f"  Symbols activos: {len(data_symbols)}")
        print(f"  Total trades:    {total_trades:,}")
        if trade_counts:
            print(f"\n  Top 10 symbols por volumen:")
            for symbol, count in trade_counts[:10]:
                print(f"    {symbol:<14} {count:>8,} trades")
            print(f"\n  Bottom 5:")
            for symbol, count in trade_counts[-5:]:
                print(f"    {symbol:<14} {count:>8,} trades")
        print(f"{'='*60}")
