"""Tests unitarios para Worker de streaming."""

import asyncio
import json

import pytest

from market_streaming.cache import MarketDataCache
from market_streaming.config import Market, Config
from market_streaming.exceptions import FatalStreamError
from market_streaming.models import StreamState, StreamType
from market_streaming.worker import (
    Worker,
    _build_agg_trade,
    _build_book_ticker,
    _build_kline,
    _build_liquidation,
    _build_mini_ticker,
    _build_ticker,
    _build_trade,
    _filter_sync_diffs,
    _parse_book_levels,
)


@pytest.fixture
def trade_config() -> Config:
    return Config(stream_type="trade", max_history=100, depth=5)


@pytest.fixture
def depth_config() -> Config:
    return Config(stream_type="depth", max_history=100, depth=5)


@pytest.fixture
def ticker_config() -> Config:
    """Config generico para tests que no requieren validacion de stream_type."""
    return Config(stream_type="ticker")


@pytest.fixture
def trade_cache(trade_config: Config) -> MarketDataCache:
    return MarketDataCache(trade_config)


@pytest.fixture
def depth_cache(depth_config: Config) -> MarketDataCache:
    return MarketDataCache(depth_config)


@pytest.fixture
def trade_worker(trade_config: Config, trade_cache: MarketDataCache) -> Worker:
    return Worker(
        worker_id="trade_0",
        stream_type=StreamType.TRADE,
        symbols=["BTCUSDT"],
        config=trade_config,
        cache=trade_cache,
    )


@pytest.fixture
def depth_worker(depth_config: Config, depth_cache: MarketDataCache) -> Worker:
    return Worker(
        worker_id="depth_0",
        stream_type=StreamType.DEPTH,
        symbols=["BTCUSDT"],
        config=depth_config,
        cache=depth_cache,
        depth=5,
    )


class TestWorkerInit:
    def test_initial_state(self, trade_worker: Worker) -> None:
        assert trade_worker.status.state == StreamState.STARTING
        assert trade_worker.status.message_count == 0
        assert trade_worker.stream_id == "trade_0"

    def test_url_trade(self, trade_worker: Worker) -> None:
        url = trade_worker._build_url()
        assert "btcusdt@trade" in url

    def test_url_depth(self, depth_worker: Worker) -> None:
        url = depth_worker._build_url()
        assert "btcusdt@depth5" in url

    def test_url_spot_default(self, trade_worker: Worker) -> None:
        url = trade_worker._build_url()
        assert "stream.binance.com" in url

    def test_url_futures_usd(self, trade_cache: MarketDataCache) -> None:
        cfg = Config(market=Market.FUTURES_USD, stream_type="trade", max_history=100)
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=trade_cache,
        )
        url = worker._build_url()
        assert "fstream.binance.com" in url

    def test_url_futures_coin(self, trade_cache: MarketDataCache) -> None:
        cfg = Config(market=Market.FUTURES_COIN, stream_type="trade", max_history=100)
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSD_PERP"],
            config=cfg,
            cache=trade_cache,
        )
        url = worker._build_url()
        assert "dstream.binance.com" in url

    def test_url_custom_base_url(self, trade_cache: MarketDataCache) -> None:
        cfg = Config(
            base_url="wss://custom.example.com/ws",
            stream_type="trade",
            max_history=100,
        )
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=trade_cache,
        )
        url = worker._build_url()
        assert "custom.example.com" in url


class TestWorkerMessageProcessing:
    def test_process_trade_message(
        self, trade_worker: Worker, trade_cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "stream": "btcusdt@trade",
            "data": {
                "e": "trade",
                "E": 1234567890,
                "s": "BTCUSDT",
                "t": 100,
                "p": "50000.00",
                "q": "0.50000000",
                "T": 1234567890,
                "m": False,
                "M": True,
            },
        })
        trade_worker._process_message(msg)

        assert trade_worker.status.message_count == 1
        assert trade_worker.status.last_message_at is not None

        last = trade_cache.get_last_trade("BTCUSDT")
        assert last is not None
        assert last.price == 50000.0
        assert last.quantity == 0.5
        assert last.quote_quantity == 25000.0
        assert last.price_str == "50000.00"
        assert last.quantity_str == "0.50000000"
        assert last.is_best_match is True
        assert last.event_time_ms == 1234567890

    def test_trade_to_rest_format(
        self, trade_worker: Worker, trade_cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "stream": "btcusdt@trade",
            "data": {
                "e": "trade",
                "E": 1234567890,
                "s": "BTCUSDT",
                "t": 42,
                "p": "68332.01000000",
                "q": "0.00016000",
                "T": 1499865549590,
                "m": False,
                "M": True,
            },
        })
        trade_worker._process_message(msg)
        last = trade_cache.get_last_trade("BTCUSDT")
        rest = last.to_rest_format()
        assert rest["id"] == 42
        assert rest["price"] == "68332.01000000"
        assert rest["qty"] == "0.00016000"
        assert "quoteQty" in rest
        assert rest["time"] == 1499865549590
        assert rest["isBuyerMaker"] is False
        assert rest["isBestMatch"] is True

    def test_process_depth_update(
        self, depth_worker: Worker, depth_cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "stream": "btcusdt@depth5",
            "data": {
                "e": "depthUpdate",
                "E": 1234567890,
                "T": 1234567891,
                "s": "BTCUSDT",
                "U": 1,
                "u": 5,
                "b": [["50000.00000000", "1.00000000"], ["49999.00000000", "2.00000000"]],
                "a": [["50001.00000000", "0.50000000"]],
            },
        })
        depth_worker._process_message(msg)

        book = depth_cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 2
        assert len(book.asks) == 1
        assert book.bids[0].price_str == "50000.00000000"
        assert book.bids[0].quantity_str == "1.00000000"
        assert book.event_time_ms == 1234567890
        assert book.transaction_time_ms == 1234567891

    def test_process_depth_snapshot(
        self, depth_worker: Worker, depth_cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "stream": "btcusdt@depth5",
            "data": {
                "lastUpdateId": 100,
                "bids": [["50000.00000000", "1.00000000"]],
                "asks": [["50001.00000000", "0.50000000"]],
            },
        })
        depth_worker._process_message(msg)

        book = depth_cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.last_update_id == 100
        assert book.bids[0].price_str == "50000.00000000"

    def test_depth_to_rest_format(
        self, depth_worker: Worker, depth_cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "stream": "btcusdt@depth5",
            "data": {
                "lastUpdateId": 200,
                "bids": [["50000.00000000", "1.00000000"]],
                "asks": [["50001.00000000", "0.50000000"]],
            },
        })
        depth_worker._process_message(msg)
        book = depth_cache.get_order_book("BTCUSDT")
        rest = book.to_rest_format()
        assert rest["lastUpdateId"] == 200
        assert rest["bids"] == [["50000.00000000", "1.00000000"]]
        assert rest["asks"] == [["50001.00000000", "0.50000000"]]

    def test_invalid_json(self, trade_worker: Worker) -> None:
        trade_worker._process_message("not json at all")
        assert trade_worker.status.error_count == 1
        assert trade_worker.status.message_count == 1


class TestWorkerBackoff:
    def test_backoff_increases(self, trade_worker: Worker) -> None:
        d1 = trade_worker._calculate_backoff(1)
        d2 = trade_worker._calculate_backoff(3)
        assert d1 > 0
        assert d2 > 0

    def test_backoff_capped(self, trade_worker: Worker) -> None:
        delay = trade_worker._calculate_backoff(100)
        max_with_jitter = (
            trade_worker._config.reconnect_max_delay_s * 1.3
        )
        assert delay <= max_with_jitter


class TestModuleFunctions:
    """Tests para funciones de modulo extraidas del refactor."""

    def test_parse_book_levels(self) -> None:
        raw = [["50000.00", "1.00"], ["49999.00", "2.00"]]
        levels = _parse_book_levels(raw)
        assert len(levels) == 2
        assert levels[0].price == 50000.0
        assert levels[0].price_str == "50000.00"
        assert levels[1].quantity == 2.0

    def test_parse_book_levels_empty(self) -> None:
        assert _parse_book_levels([]) == []

    def test_build_trade(self) -> None:
        data = {
            "t": 100, "p": "50000.00", "q": "0.50000000",
            "T": 1234567890, "m": False, "M": True, "E": 9999,
        }
        trade = _build_trade(data, "BTCUSDT")
        assert trade.symbol == "BTCUSDT"
        assert trade.trade_id == 100
        assert trade.price == 50000.0
        assert trade.quantity == 0.5
        assert trade.quote_quantity == 25000.0
        assert trade.price_str == "50000.00"
        assert trade.buyer_maker is False
        assert trade.is_best_match is True
        assert trade.event_time_ms == 9999

class TestFilterSyncDiffs:
    """Tests para _filter_sync_diffs (validacion de continuidad)."""

    def test_spot_drops_stale_diffs(self) -> None:
        buffer = [
            {"U": 1, "u": 5},   # stale (u <= 10)
            {"U": 6, "u": 10},  # stale (u <= 10)
            {"U": 11, "u": 15}, # valid (u > 10)
        ]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.SPOT)
        assert len(result) == 1
        assert result[0]["U"] == 11

    def test_futures_drops_stale_diffs(self) -> None:
        buffer = [
            {"U": 1, "u": 5},   # stale (u < 10)
            {"U": 6, "u": 9},   # stale (u < 10)
            {"U": 8, "u": 10},  # valid (u >= 10)
            {"U": 11, "u": 15}, # valid (u >= 10)
        ]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.FUTURES_USD)
        assert len(result) == 2
        assert result[0]["U"] == 8

    def test_empty_buffer(self) -> None:
        result = _filter_sync_diffs([], snapshot_update_id=10, market=Market.SPOT)
        assert result == []

    def test_all_stale(self) -> None:
        buffer = [{"U": 1, "u": 3}, {"U": 4, "u": 8}]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.SPOT)
        assert result == []

    def test_sorted_by_first_update_id(self) -> None:
        buffer = [
            {"U": 20, "u": 25},
            {"U": 11, "u": 15},
            {"U": 16, "u": 19},
        ]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.SPOT)
        assert [d["U"] for d in result] == [11, 16, 20]


class TestWorkerCombined:
    """Tests para Worker con multiples simbolos (combined streams)."""

    def test_initial_state(self, trade_config: Config, trade_cache: MarketDataCache) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        assert worker.status.state == StreamState.STARTING
        assert worker.status.symbol == "COMBINED(2)"
        assert worker.stream_id == "trade_0"

    def test_combined_url_trades(self, trade_config: Config, trade_cache: MarketDataCache) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        url = worker._build_url()
        assert "stream?streams=" in url
        assert "btcusdt@trade" in url
        assert "ethusdt@trade" in url

    def test_combined_url_depth(self, depth_config: Config, depth_cache: MarketDataCache) -> None:
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=depth_config,
            cache=depth_cache,
            depth=5,
        )
        url = worker._build_url()
        assert "btcusdt@depth5" in url

    def test_combined_process_trade(self, trade_config: Config, trade_cache: MarketDataCache) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@trade",
            "data": {
                "e": "trade", "E": 1234567890, "s": "BTCUSDT",
                "t": 42, "p": "60000.00", "q": "1.00000000",
                "T": 1234567890, "m": True, "M": True,
            },
        })
        worker._process_message(msg)
        assert worker.status.message_count == 1
        last = trade_cache.get_last_trade("BTCUSDT")
        assert last is not None
        assert last.price == 60000.0
        assert last.trade_id == 42

    def test_combined_process_depth_update(
        self, depth_config: Config, depth_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=depth_config,
            cache=depth_cache,
            depth=5,
        )
        msg = json.dumps({
            "stream": "btcusdt@depth5",
            "data": {
                "e": "depthUpdate", "E": 1234567890, "T": 1234567891,
                "s": "BTCUSDT", "U": 1, "u": 5,
                "b": [["50000.00", "1.00"]],
                "a": [["50001.00", "0.50"]],
            },
        })
        worker._process_message(msg)
        book = depth_cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 1

    def test_combined_invalid_json(
        self, trade_config: Config, trade_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        worker._process_message("not json")
        assert worker.status.error_count == 1


class TestWorkerSyncState:
    """Tests para el estado de sincronizacion de workers."""

    def test_worker_needs_sync_for_deep_depth(
        self, depth_config: Config, depth_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=depth_config,
            cache=depth_cache,
            depth=200,
        )
        assert worker._needs_sync is True
        assert worker._synced_symbols == set()

    def test_worker_no_sync_for_partial_depth(
        self, depth_config: Config, depth_cache: MarketDataCache,
    ) -> None:
        for depth in [5, 10, 20]:
            worker = Worker(
                worker_id="depth_0",
                stream_type=StreamType.DEPTH,
                symbols=["BTCUSDT"],
                config=depth_config,
                cache=depth_cache,
                depth=depth,
            )
            assert worker._needs_sync is False

    def test_trade_worker_no_sync(
        self, trade_config: Config, trade_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        assert worker._needs_sync is False

    def test_worker_needs_sync_multi_symbol(
        self, depth_config: Config, depth_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=depth_config,
            cache=depth_cache,
            depth=200,
        )
        assert worker._needs_sync is True
        assert worker._synced_symbols == set()

    def test_worker_no_sync_for_trades(
        self, trade_config: Config, trade_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        assert worker._needs_sync is False

    def test_diff_buffer_initialized_empty(
        self, depth_config: Config, depth_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=depth_config,
            cache=depth_cache,
            depth=200,
        )
        assert worker._diff_buffer == {}


class TestDiffBuffering:
    """Tests para el buffering de diffs antes del sync REST."""

    def test_diffs_buffered_before_sync(self) -> None:
        """Los diffs se bufferean (no se aplican al cache) antes del sync."""
        cfg = Config(stream_type="depth", depth=200)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=200,
        )
        msg = json.dumps({
            "stream": "btcusdt@depth",
            "data": {
                "e": "depthUpdate", "E": 100, "T": 100,
                "s": "BTCUSDT", "U": 1, "u": 5,
                "b": [["50000.00", "1.00"]],
                "a": [["50001.00", "0.50"]],
            },
        })
        worker._process_message(msg)

        # El diff debe estar en el buffer, NO en el cache
        assert len(worker._diff_buffer.get("BTCUSDT", [])) == 1
        book = cache.get_order_book("BTCUSDT")
        assert book is None

    def test_diffs_applied_after_sync(self) -> None:
        """Tras marcar synced, los diffs se aplican directamente al cache."""
        cfg = Config(stream_type="depth", depth=200)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=200,
        )
        # Simular que el sync ya se completo
        worker._synced_symbols.add("BTCUSDT")

        msg = json.dumps({
            "stream": "btcusdt@depth",
            "data": {
                "e": "depthUpdate", "E": 100, "T": 100,
                "s": "BTCUSDT", "U": 1, "u": 5,
                "b": [["50000.00", "1.00"]],
                "a": [["50001.00", "0.50"]],
            },
        })
        worker._process_message(msg)

        # No debe bufferear, debe ir al cache
        assert worker._diff_buffer.get("BTCUSDT") is None
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.is_synced is True

    def test_partial_depth_no_buffering(self) -> None:
        """Los streams parciales (5, 10, 20) no bufferean."""
        cfg = Config(stream_type="depth", depth=5)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=5,
        )
        msg = json.dumps({
            "stream": "btcusdt@depth5",
            "data": {
                "e": "depthUpdate", "E": 100, "T": 100,
                "s": "BTCUSDT", "U": 1, "u": 5,
                "b": [["50000.00", "1.00"]],
                "a": [["50001.00", "0.50"]],
            },
        })
        worker._process_message(msg)

        # Sin buffering: va directo al cache
        assert worker._diff_buffer == {}
        book = cache.get_order_book("BTCUSDT")
        assert book is not None

    def test_multiple_diffs_buffered(self) -> None:
        """Se acumulan multiples diffs en el buffer."""
        cfg = Config(stream_type="depth", depth=200)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=200,
        )
        for i in range(5):
            msg = json.dumps({
                "stream": "btcusdt@depth",
                "data": {
                    "e": "depthUpdate", "E": 100 + i, "T": 100 + i,
                    "s": "BTCUSDT", "U": i * 5 + 1, "u": (i + 1) * 5,
                    "b": [["50000.00", "1.00"]],
                    "a": [["50001.00", "0.50"]],
                },
            })
            worker._process_message(msg)

        assert len(worker._diff_buffer["BTCUSDT"]) == 5
        assert cache.get_order_book("BTCUSDT") is None


class TestDepthStreamSpeed:
    """Tests para la velocidad de actualizacion del stream de depth."""

    def test_partial_depth_uses_100ms(self) -> None:
        cfg = Config(stream_type="depth", depth=5)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=5,
        )
        url = worker._build_url()
        assert "btcusdt@depth5@100ms" in url

    def test_diff_depth_uses_100ms(self) -> None:
        cfg = Config(stream_type="depth", depth=200)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=200,
        )
        url = worker._build_url()
        assert "btcusdt@depth@100ms" in url


class TestRunPreservesFailed:
    """Verifica que _run() no sobreescribe StreamState.FAILED con STOPPED."""

    def test_fatal_error_preserves_failed(
        self, trade_config: Config, trade_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        async def _raise_fatal() -> None:
            raise FatalStreamError("test fatal")

        worker._connect_and_consume = _raise_fatal  # type: ignore[assignment]
        asyncio.run(worker._run())
        assert worker.status.state == StreamState.FAILED

    def test_max_reconnect_preserves_failed(
        self, trade_cache: MarketDataCache,
    ) -> None:
        cfg = Config(
            stream_type="trade",
            max_history=100,
            max_reconnect_attempts=1,
            reconnect_base_delay_s=0.01,
            reconnect_max_delay_s=0.01,
        )
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=trade_cache,
        )
        async def _raise_generic() -> None:
            raise ConnectionError("test reconnect")

        worker._connect_and_consume = _raise_generic  # type: ignore[assignment]
        asyncio.run(worker._run())
        assert worker.status.state == StreamState.FAILED

    def test_normal_stop_sets_stopped(
        self, trade_config: Config, trade_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="trade_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        async def _stop_immediately() -> None:
            worker._stop_event.set()

        worker._connect_and_consume = _stop_immediately  # type: ignore[assignment]
        asyncio.run(worker._run())
        assert worker.status.state == StreamState.STOPPED


class TestNewBuilderFunctions:
    """Tests para funciones builder de los nuevos tipos de stream."""

    def test_build_agg_trade(self) -> None:
        data = {
            "e": "aggTrade", "E": 1672515782136, "s": "BTCUSDT",
            "a": 12345, "p": "50000.00", "q": "0.001",
            "f": 100, "l": 105, "T": 1672515782136,
            "m": False, "M": True,
        }
        agg = _build_agg_trade(data, "BTCUSDT")
        assert agg.symbol == "BTCUSDT"
        assert agg.agg_trade_id == 12345
        assert agg.price == 50000.0
        assert agg.quantity == 0.001
        assert agg.first_trade_id == 100
        assert agg.last_trade_id == 105
        assert agg.timestamp_ms == 1672515782136
        assert agg.buyer_maker is False
        assert agg.price_str == "50000.00"
        assert agg.quantity_str == "0.001"
        assert agg.event_time_ms == 1672515782136

    def test_build_kline(self) -> None:
        data = {
            "e": "kline", "E": 1672515782136, "s": "BTCUSDT",
            "k": {
                "t": 1672515780000, "T": 1672515839999, "s": "BTCUSDT",
                "i": "1m", "f": 100, "L": 200,
                "o": "50000.00", "c": "50100.00", "h": "50200.00",
                "l": "49900.00", "v": "100.00", "n": 150,
                "x": False, "q": "5000000.00", "V": "60.00",
                "Q": "3000000.00", "B": "0",
            },
        }
        kline = _build_kline(data, "BTCUSDT")
        assert kline.symbol == "BTCUSDT"
        assert kline.interval == "1m"
        assert kline.open == 50000.0
        assert kline.close == 50100.0
        assert kline.high == 50200.0
        assert kline.low == 49900.0
        assert kline.volume == 100.0
        assert kline.trades == 150
        assert kline.is_closed is False
        assert kline.open_str == "50000.00"
        assert kline.event_time_ms == 1672515782136

    def test_build_ticker(self) -> None:
        data = {
            "e": "24hrTicker", "E": 1672515782136, "s": "BTCUSDT",
            "p": "500.00", "P": "1.00", "w": "50000.00",
            "x": "49500.00", "c": "50000.00", "Q": "0.1",
            "b": "49999.00", "B": "1.0", "a": "50001.00", "A": "0.5",
            "o": "49500.00", "h": "50500.00", "l": "49000.00",
            "v": "1000.00", "q": "50000000.00",
            "O": 0, "C": 86400000, "F": 1, "L": 18150, "n": 18151,
        }
        ticker = _build_ticker(data, "BTCUSDT")
        assert ticker.symbol == "BTCUSDT"
        assert ticker.price_change == 500.0
        assert ticker.last_price == 50000.0
        assert ticker.best_bid_price == 49999.0
        assert ticker.best_ask_price == 50001.0
        assert ticker.trade_count == 18151
        assert ticker.event_time_ms == 1672515782136

    def test_build_mini_ticker(self) -> None:
        data = {
            "e": "24hrMiniTicker", "E": 1672515782136, "s": "BTCUSDT",
            "c": "50000.00", "o": "49500.00", "h": "50500.00",
            "l": "49000.00", "v": "1000.00", "q": "50000000.00",
        }
        mt = _build_mini_ticker(data, "BTCUSDT")
        assert mt.symbol == "BTCUSDT"
        assert mt.close_price == 50000.0
        assert mt.open_price == 49500.0
        assert mt.high_price == 50500.0
        assert mt.low_price == 49000.0
        assert mt.volume == 1000.0
        assert mt.quote_volume == 50000000.0
        assert mt.event_time_ms == 1672515782136

    def test_build_book_ticker(self) -> None:
        data = {
            "u": 400900217, "s": "BTCUSDT",
            "b": "49999.00", "B": "1.0",
            "a": "50001.00", "A": "0.5",
        }
        bt = _build_book_ticker(data, "BTCUSDT")
        assert bt.symbol == "BTCUSDT"
        assert bt.update_id == 400900217
        assert bt.best_bid_price == 49999.0
        assert bt.best_bid_quantity == 1.0
        assert bt.best_ask_price == 50001.0
        assert bt.best_ask_quantity == 0.5
        assert bt.best_bid_price_str == "49999.00"
        assert bt.best_ask_price_str == "50001.00"

    def test_build_liquidation(self) -> None:
        data = {
            "e": "forceOrder",
            "E": 1568014460893,
            "o": {
                "s": "BTCUSDT",
                "S": "SELL",
                "o": "LIMIT",
                "f": "IOC",
                "q": "0.014",
                "p": "9910",
                "ap": "9910",
                "X": "FILLED",
                "l": "0.014",
                "z": "0.014",
                "T": 1568014460893,
            },
        }
        liq = _build_liquidation(data)
        assert liq.symbol == "BTCUSDT"
        assert liq.side == "SELL"
        assert liq.order_type == "LIMIT"
        assert liq.time_in_force == "IOC"
        assert liq.original_qty == 0.014
        assert liq.price == 9910.0
        assert liq.average_price == 9910.0
        assert liq.status == "FILLED"
        assert liq.last_filled_qty == 0.014
        assert liq.filled_qty == 0.014
        assert liq.trade_time_ms == 1568014460893
        assert liq.event_time_ms == 1568014460893
        assert liq.original_qty_str == "0.014"
        assert liq.price_str == "9910"
        assert liq.average_price_str == "9910"


class TestNewStreamURLs:
    """Tests para URLs de los nuevos tipos de stream."""

    def test_url_agg_trade(self, trade_config: Config, trade_cache: MarketDataCache) -> None:
        worker = Worker(
            worker_id="agg_trade_0",
            stream_type=StreamType.AGG_TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        url = worker._build_url()
        assert "btcusdt@aggTrade" in url

    def test_url_kline(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="kline_0",
            stream_type=StreamType.KLINE,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
            interval="5m",
        )
        url = worker._build_url()
        assert "btcusdt@kline_5m" in url

    def test_url_ticker(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="ticker_0",
            stream_type=StreamType.TICKER,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@ticker" in url

    def test_url_mini_ticker(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="mini_ticker_0",
            stream_type=StreamType.MINI_TICKER,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@miniTicker" in url

    def test_url_book_ticker(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="book_ticker_0",
            stream_type=StreamType.BOOK_TICKER,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@bookTicker" in url

    def test_url_force_order(self) -> None:
        cfg = Config(market="futures_usd", stream_type="force_order", max_history=100)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="force_order_0",
            stream_type=StreamType.FORCE_ORDER,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@forceOrder" in url
        assert "fstream.binance.com" in url

    def test_combined_url_force_order(self) -> None:
        cfg = Config(market="futures_usd", stream_type="force_order", max_history=100)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="force_order_0",
            stream_type=StreamType.FORCE_ORDER,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "stream?streams=" in url
        assert "btcusdt@forceOrder" in url
        assert "ethusdt@forceOrder" in url

    def test_combined_url_agg_trades(
        self, trade_config: Config, trade_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="agg_trade_0",
            stream_type=StreamType.AGG_TRADE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        url = worker._build_url()
        assert "stream?streams=" in url
        assert "btcusdt@aggTrade" in url
        assert "ethusdt@aggTrade" in url

    def test_combined_url_klines(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="kline_0",
            stream_type=StreamType.KLINE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=ticker_config,
            cache=cache,
            interval="15m",
        )
        url = worker._build_url()
        assert "stream?streams=" in url
        assert "btcusdt@kline_15m" in url
        assert "ethusdt@kline_15m" in url


class TestNewMessageProcessing:
    """Tests para procesamiento de mensajes de los nuevos tipos de stream."""

    def test_process_agg_trade_message(
        self, trade_config: Config, trade_cache: MarketDataCache,
    ) -> None:
        worker = Worker(
            worker_id="agg_trade_0",
            stream_type=StreamType.AGG_TRADE,
            symbols=["BTCUSDT"],
            config=trade_config,
            cache=trade_cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@aggTrade",
            "data": {
                "e": "aggTrade", "E": 1672515782136, "s": "BTCUSDT",
                "a": 12345, "p": "50000.00", "q": "0.001",
                "f": 100, "l": 105, "T": 1672515782136,
                "m": False, "M": True,
            },
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        last = trade_cache.get_last_agg_trade("BTCUSDT")
        assert last is not None
        assert last.agg_trade_id == 12345
        assert last.price == 50000.0
        assert last.quantity == 0.001

    def test_process_kline_message(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="kline_0",
            stream_type=StreamType.KLINE,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@kline_1m",
            "data": {
                "e": "kline", "E": 1672515782136, "s": "BTCUSDT",
                "k": {
                    "t": 1672515780000, "T": 1672515839999, "s": "BTCUSDT",
                    "i": "1m", "f": 100, "L": 200,
                    "o": "50000.00", "c": "50100.00", "h": "50200.00",
                    "l": "49900.00", "v": "100.00", "n": 150,
                    "x": False, "q": "5000000.00", "V": "60.00",
                    "Q": "3000000.00", "B": "0",
                },
            },
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        kline = cache.get_kline("BTCUSDT", "1m")
        assert kline is not None
        assert kline.open == 50000.0
        assert kline.close == 50100.0
        assert kline.interval == "1m"

    def test_process_ticker_message(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="ticker_0",
            stream_type=StreamType.TICKER,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@ticker",
            "data": {
                "e": "24hrTicker", "E": 1672515782136, "s": "BTCUSDT",
                "p": "500.00", "P": "1.00", "w": "50000.00",
                "x": "49500.00", "c": "50000.00", "Q": "0.1",
                "b": "49999.00", "B": "1.0", "a": "50001.00", "A": "0.5",
                "o": "49500.00", "h": "50500.00", "l": "49000.00",
                "v": "1000.00", "q": "50000000.00",
                "O": 0, "C": 86400000, "F": 1, "L": 18150, "n": 18151,
            },
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        ticker = cache.get_ticker("BTCUSDT")
        assert ticker is not None
        assert ticker.last_price == 50000.0
        assert ticker.trade_count == 18151

    def test_process_mini_ticker_message(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="mini_ticker_0",
            stream_type=StreamType.MINI_TICKER,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@miniTicker",
            "data": {
                "e": "24hrMiniTicker", "E": 1672515782136, "s": "BTCUSDT",
                "c": "50000.00", "o": "49500.00", "h": "50500.00",
                "l": "49000.00", "v": "1000.00", "q": "50000000.00",
            },
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        mt = cache.get_mini_ticker("BTCUSDT")
        assert mt is not None
        assert mt.close_price == 50000.0
        assert mt.open_price == 49500.0

    def test_process_book_ticker_message(self, ticker_config: Config) -> None:
        cache = MarketDataCache(ticker_config)
        worker = Worker(
            worker_id="book_ticker_0",
            stream_type=StreamType.BOOK_TICKER,
            symbols=["BTCUSDT"],
            config=ticker_config,
            cache=cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@bookTicker",
            "data": {
                "u": 400900217, "s": "BTCUSDT",
                "b": "49999.00", "B": "1.0",
                "a": "50001.00", "A": "0.5",
            },
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        bt = cache.get_book_ticker("BTCUSDT")
        assert bt is not None
        assert bt.best_bid_price == 49999.0
        assert bt.best_ask_price == 50001.0
        assert bt.update_id == 400900217

    def test_process_force_order_message(self) -> None:
        cfg = Config(market="futures_usd", stream_type="force_order", max_history=100)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="force_order_0",
            stream_type=StreamType.FORCE_ORDER,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@forceOrder",
            "data": {
                "e": "forceOrder",
                "E": 1568014460893,
                "o": {
                    "s": "BTCUSDT",
                    "S": "SELL",
                    "o": "LIMIT",
                    "f": "IOC",
                    "q": "0.014",
                    "p": "9910",
                    "ap": "9910",
                    "X": "FILLED",
                    "l": "0.014",
                    "z": "0.014",
                    "T": 1568014460893,
                },
            },
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        liq = cache.get_last_liquidation("BTCUSDT")
        assert liq is not None
        assert liq.symbol == "BTCUSDT"
        assert liq.side == "SELL"
        assert liq.price == 9910.0
        assert liq.original_qty == 0.014
        assert liq.status == "FILLED"
        assert liq.trade_time_ms == 1568014460893
