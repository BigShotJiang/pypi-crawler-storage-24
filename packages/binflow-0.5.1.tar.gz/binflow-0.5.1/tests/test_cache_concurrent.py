"""Tests de lectura concurrente del cache mientras se actualiza.

Verifica que el cache no se corrompe cuando multiples threads escriben
(simulando workers) mientras el thread principal lee continuamente.
"""

import threading
import time

from market_streaming.cache import MarketDataCache
from market_streaming.config import Config
from market_streaming.models import OrderBookLevel, OrderBookSnapshot, Trade


DURATION_S = 2.0
NUM_SYMBOLS = 50
DEPTH = 200
NUM_WRITERS = 4


def _make_trade(symbol: str, tid: int, price: float) -> Trade:
    qty = 0.1
    return Trade(
        symbol=symbol,
        trade_id=tid,
        price=price,
        quantity=qty,
        quote_quantity=price * qty,
        buyer_maker=False,
        timestamp_ms=int(time.time() * 1000),
    )


def _make_levels(count: int, base_price: float, ascending: bool = True) -> list[OrderBookLevel]:
    levels = []
    for i in range(count):
        p = base_price + i * 0.01 if ascending else base_price - i * 0.01
        levels.append(OrderBookLevel(price=p, quantity=1.0 + i * 0.1))
    return levels


class TestConcurrentReadWrite:
    """Verifica integridad del cache bajo lectura y escritura concurrentes."""

    def test_order_books_not_corrupted_during_updates(self) -> None:
        """Lee order books continuamente mientras writers los actualizan."""
        config = Config(
            stream_type="ticker",
            max_history=100,
            depth=DEPTH,
        )
        cache = MarketDataCache(config)
        symbols = [f"SYM{i}USDT" for i in range(NUM_SYMBOLS)]
        stop = threading.Event()
        errors: list[str] = []
        write_counts = [0] * NUM_WRITERS
        read_count = [0]

        # Inicializar books
        for symbol in symbols:
            snapshot = OrderBookSnapshot(
                symbol=symbol,
                bids=_make_levels(DEPTH, 50000.0, ascending=False),
                asks=_make_levels(DEPTH, 50001.0, ascending=True),
                last_update_id=1,
                is_synced=True,
            )
            cache.update_order_book(snapshot)

        def writer(worker_idx: int) -> None:
            """Escribe actualizaciones incrementales a subconjuntos de symbols."""
            my_symbols = symbols[worker_idx::NUM_WRITERS]
            update_id = 100
            while not stop.is_set():
                for symbol in my_symbols:
                    if stop.is_set():
                        break
                    # Actualizar unos niveles
                    bids = [OrderBookLevel(price=50000.0 - update_id * 0.001, quantity=2.0)]
                    asks = [OrderBookLevel(price=50001.0 + update_id * 0.001, quantity=2.0)]
                    cache.apply_depth_update(
                        symbol, bids, asks, update_id,
                        max_depth=DEPTH,
                        is_synced=True,
                    )
                    update_id += 1
                    write_counts[worker_idx] += 1

        def reader() -> None:
            """Lee todos los books continuamente y verifica integridad."""
            while not stop.is_set():
                for symbol in symbols:
                    if stop.is_set():
                        break
                    book = cache.get_order_book(symbol)
                    if book is None:
                        errors.append(f"{symbol}: book es None")
                        continue

                    read_count[0] += 1

                    # Verificar que no hay None en niveles
                    for i, bid in enumerate(book.bids):
                        if bid is None:
                            errors.append(f"{symbol}: bid[{i}] es None")
                        elif bid.price <= 0 or bid.quantity <= 0:
                            errors.append(
                                f"{symbol}: bid[{i}] invalido "
                                f"price={bid.price} qty={bid.quantity}"
                            )
                    for i, ask in enumerate(book.asks):
                        if ask is None:
                            errors.append(f"{symbol}: ask[{i}] es None")
                        elif ask.price <= 0 or ask.quantity <= 0:
                            errors.append(
                                f"{symbol}: ask[{i}] invalido "
                                f"price={ask.price} qty={ask.quantity}"
                            )

                    # Verificar orden
                    for i in range(len(book.bids) - 1):
                        if book.bids[i].price < book.bids[i + 1].price:
                            errors.append(
                                f"{symbol}: bids desordenados en [{i}]"
                            )
                            break
                    for i in range(len(book.asks) - 1):
                        if book.asks[i].price > book.asks[i + 1].price:
                            errors.append(
                                f"{symbol}: asks desordenados en [{i}]"
                            )
                            break

                    # Verificar depth no excedido
                    if len(book.bids) > DEPTH:
                        errors.append(
                            f"{symbol}: {len(book.bids)} bids > {DEPTH}"
                        )
                    if len(book.asks) > DEPTH:
                        errors.append(
                            f"{symbol}: {len(book.asks)} asks > {DEPTH}"
                        )

                    # Verificar is_synced preservado
                    if not book.is_synced:
                        errors.append(f"{symbol}: is_synced perdido")

                    if errors:
                        stop.set()
                        return

        # Lanzar threads
        writer_threads = [
            threading.Thread(target=writer, args=(i,), name=f"writer-{i}")
            for i in range(NUM_WRITERS)
        ]
        reader_thread = threading.Thread(target=reader, name="reader")

        for t in writer_threads:
            t.start()
        reader_thread.start()

        time.sleep(DURATION_S)
        stop.set()

        for t in writer_threads:
            t.join(timeout=2.0)
        reader_thread.join(timeout=2.0)

        total_writes = sum(write_counts)
        print(f"\n  Writes: {total_writes:,}, Reads: {read_count[0]:,}")
        print(f"  Symbols: {NUM_SYMBOLS}, Depth: {DEPTH}, Duration: {DURATION_S}s")

        assert not errors, (
            f"{len(errors)} errores de integridad:\n  "
            + "\n  ".join(errors[:20])
        )
        assert read_count[0] > 0, "No se realizaron lecturas"
        assert total_writes > 0, "No se realizaron escrituras"

    def test_trades_not_corrupted_during_updates(self) -> None:
        """Lee trades continuamente mientras writers los actualizan."""
        config = Config(stream_type="trade", max_history=500)
        cache = MarketDataCache(config)
        symbols = [f"SYM{i}USDT" for i in range(NUM_SYMBOLS)]
        stop = threading.Event()
        errors: list[str] = []
        write_count = [0]
        read_count = [0]

        def writer() -> None:
            tid = 1
            while not stop.is_set():
                for symbol in symbols:
                    if stop.is_set():
                        break
                    trade = _make_trade(symbol, tid, 50000.0 + tid * 0.01)
                    cache.update_trade(trade)
                    tid += 1
                    write_count[0] += 1

        def reader() -> None:
            while not stop.is_set():
                for symbol in symbols:
                    if stop.is_set():
                        break

                    # Leer last trade
                    last = cache.get_last_trade(symbol)
                    if last is not None:
                        if last.price <= 0:
                            errors.append(f"{symbol}: last trade price={last.price}")
                        if last.symbol.upper() != symbol:
                            errors.append(
                                f"{symbol}: last trade symbol={last.symbol}"
                            )

                    # Leer recent trades
                    recent = cache.get_recent_trades(symbol, limit=100)
                    read_count[0] += 1
                    for t in recent:
                        if t is None:
                            errors.append(f"{symbol}: trade None en recent")
                        elif t.price <= 0:
                            errors.append(f"{symbol}: trade price={t.price}")

                    # Verificar que no excede maxlen
                    if len(recent) > config.max_history:
                        errors.append(
                            f"{symbol}: {len(recent)} > maxlen {config.max_history}"
                        )

                    if errors:
                        stop.set()
                        return

        writer_thread = threading.Thread(target=writer, name="trade-writer")
        reader_thread = threading.Thread(target=reader, name="trade-reader")

        writer_thread.start()
        reader_thread.start()

        time.sleep(DURATION_S)
        stop.set()

        writer_thread.join(timeout=2.0)
        reader_thread.join(timeout=2.0)

        print(f"\n  Writes: {write_count[0]:,}, Reads: {read_count[0]:,}")

        assert not errors, (
            f"{len(errors)} errores de integridad:\n  "
            + "\n  ".join(errors[:20])
        )
        assert read_count[0] > 0
        assert write_count[0] > 0

    def test_mixed_order_book_operations(self) -> None:
        """Mezcla update_order_book y apply_depth_update concurrentemente."""
        config = Config(stream_type="ticker", depth=DEPTH)
        cache = MarketDataCache(config)
        symbol = "BTCUSDT"
        stop = threading.Event()
        errors: list[str] = []

        def snapshot_writer() -> None:
            """Escribe snapshots completos periodicamente (simula REST sync)."""
            uid = 1000000
            while not stop.is_set():
                snapshot = OrderBookSnapshot(
                    symbol=symbol,
                    bids=_make_levels(DEPTH, 50000.0, ascending=False),
                    asks=_make_levels(DEPTH, 50001.0, ascending=True),
                    last_update_id=uid,
                    is_synced=True,
                )
                cache.update_order_book(snapshot)
                uid += 1000
                time.sleep(0.01)

        def diff_writer() -> None:
            """Escribe diffs incrementales continuamente."""
            uid = 1
            while not stop.is_set():
                bids = [OrderBookLevel(price=49999.0 + uid * 0.0001, quantity=1.5)]
                asks = [OrderBookLevel(price=50002.0 + uid * 0.0001, quantity=1.5)]
                cache.apply_depth_update(
                    symbol, bids, asks, uid, max_depth=DEPTH, is_synced=True,
                )
                uid += 1

        def reader() -> None:
            while not stop.is_set():
                book = cache.get_order_book(symbol)
                if book is None:
                    continue
                # Verificar que la copia devuelta es consistente
                if book.bids:
                    for bid in book.bids:
                        if bid is None or bid.price <= 0:
                            errors.append(f"bid corrupto: {bid}")
                if book.asks:
                    for ask in book.asks:
                        if ask is None or ask.price <= 0:
                            errors.append(f"ask corrupto: {ask}")
                if errors:
                    stop.set()
                    return

        threads = [
            threading.Thread(target=snapshot_writer, name="snapshot-writer"),
            threading.Thread(target=diff_writer, name="diff-writer"),
            threading.Thread(target=reader, name="reader"),
        ]
        for t in threads:
            t.start()

        time.sleep(DURATION_S)
        stop.set()

        for t in threads:
            t.join(timeout=2.0)

        assert not errors, (
            f"{len(errors)} errores:\n  " + "\n  ".join(errors[:20])
        )
