"""Tests para reconfiguracion en caliente de Manager."""

import json
from collections import deque

import pytest

from market_streaming.cache import MarketDataCache
from market_streaming.config import Config, Market
from market_streaming.models import (
    OrderBookLevel,
    OrderBookSnapshot,
    StreamType,
    Trade,
)
from market_streaming.worker import Worker, _PARTIAL_DEPTH_LEVELS


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def trade_config() -> Config:
    return Config(stream_type="trade", max_history=100)


@pytest.fixture
def depth_config() -> Config:
    return Config(stream_type="depth", depth=200)


@pytest.fixture
def kline_config() -> Config:
    return Config(stream_type="kline", interval="1m")


# ------------------------------------------------------------------
# Validacion de parametros
# ------------------------------------------------------------------

class TestReconfigureValidation:
    """Tests de validacion de parametros en reconfigure()."""

    def test_reject_market(self, trade_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(trade_config)
        with pytest.raises(ValueError, match="market"):
            mgr.reconfigure(market="futures_usd")

    def test_reject_stream_type(self, trade_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(trade_config)
        with pytest.raises(ValueError, match="stream_type"):
            mgr.reconfigure(stream_type="depth")

    def test_reject_symbols(self, trade_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(trade_config)
        with pytest.raises(ValueError, match="symbols"):
            mgr.reconfigure(symbols=["BTCUSDT"])

    def test_reject_depth_on_trade(self, trade_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(trade_config)
        with pytest.raises(ValueError, match="depth.*no es valido"):
            mgr.reconfigure(depth=100)

    def test_reject_max_history_on_depth(self, depth_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(depth_config)
        with pytest.raises(ValueError, match="max_history.*no es valido"):
            mgr.reconfigure(max_history=500)

    def test_reject_interval_on_trade(self, trade_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(trade_config)
        with pytest.raises(ValueError, match="interval.*no es valido"):
            mgr.reconfigure(interval="5m")

    def test_reject_invalid_max_history(self, trade_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(trade_config)
        with pytest.raises(ValueError, match="max_history"):
            mgr.reconfigure(max_history=0)

    def test_reject_invalid_depth(self, depth_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(depth_config)
        with pytest.raises(ValueError, match="depth"):
            mgr.reconfigure(depth=-1)

    def test_noop_empty_kwargs(self, trade_config: Config) -> None:
        from market_streaming.manager import Manager
        mgr = Manager(trade_config)
        mgr.reconfigure()  # no error


# ------------------------------------------------------------------
# Cache: max_history
# ------------------------------------------------------------------

class TestReconfigureMaxHistory:
    """Tests de reconfiguracion de max_history en cache."""

    def test_increase_max_history(self) -> None:
        cfg = Config(stream_type="trade", max_history=5)
        cache = MarketDataCache(cfg)
        # Llenar 5 trades
        for i in range(5):
            cache.update_trade(Trade(
                symbol="BTCUSDT", trade_id=i, price=100.0,
                quantity=1.0, quote_quantity=100.0, buyer_maker=False,
                timestamp_ms=i,
            ))
        assert len(cache.get_recent_trades("BTCUSDT")) == 5

        cache.reconfigure_max_history(10)
        # Los 5 trades siguen ahi
        assert len(cache.get_recent_trades("BTCUSDT")) == 5
        # Ahora caben 10
        for i in range(5, 10):
            cache.update_trade(Trade(
                symbol="BTCUSDT", trade_id=i, price=100.0,
                quantity=1.0, quote_quantity=100.0, buyer_maker=False,
                timestamp_ms=i,
            ))
        assert len(cache.get_recent_trades("BTCUSDT")) == 10

    def test_decrease_max_history(self) -> None:
        cfg = Config(stream_type="trade", max_history=10)
        cache = MarketDataCache(cfg)
        for i in range(10):
            cache.update_trade(Trade(
                symbol="BTCUSDT", trade_id=i, price=100.0,
                quantity=1.0, quote_quantity=100.0, buyer_maker=False,
                timestamp_ms=i,
            ))
        assert len(cache.get_recent_trades("BTCUSDT")) == 10

        cache.reconfigure_max_history(3)
        # Solo quedan los 3 mas recientes
        recent = cache.get_recent_trades("BTCUSDT")
        assert len(recent) == 3
        assert recent[0].trade_id == 7


# ------------------------------------------------------------------
# Cache: depth
# ------------------------------------------------------------------

class TestReconfigureDepthCache:
    """Tests de reconfiguracion de depth en cache."""

    def _make_book(self, symbol: str, n_levels: int) -> OrderBookSnapshot:
        bids = [
            OrderBookLevel(price=100.0 - i, quantity=1.0)
            for i in range(n_levels)
        ]
        asks = [
            OrderBookLevel(price=100.0 + i + 1, quantity=1.0)
            for i in range(n_levels)
        ]
        return OrderBookSnapshot(
            symbol=symbol, bids=bids, asks=asks,
            last_update_id=1, is_synced=True,
        )

    def test_decrease_depth_truncates(self) -> None:
        cfg = Config(stream_type="depth", depth=50)
        cache = MarketDataCache(cfg)
        cache.update_order_book(self._make_book("BTCUSDT", 50))

        cache.reconfigure_depth(20)
        book = cache.get_order_book("BTCUSDT")
        assert len(book.bids) == 20
        assert len(book.asks) == 20

    def test_increase_depth_marks_unsynced(self) -> None:
        cfg = Config(stream_type="depth", depth=50)
        cache = MarketDataCache(cfg)
        cache.update_order_book(self._make_book("BTCUSDT", 50))

        book = cache.get_order_book("BTCUSDT")
        assert book.is_synced is True

        cache.reconfigure_depth(200)
        book = cache.get_order_book("BTCUSDT")
        # Sigue teniendo 50 niveles, pero marcado como no synced
        assert len(book.bids) == 50
        assert book.is_synced is False

    def test_same_depth_no_change(self) -> None:
        cfg = Config(stream_type="depth", depth=50)
        cache = MarketDataCache(cfg)
        cache.update_order_book(self._make_book("BTCUSDT", 50))

        cache.reconfigure_depth(50)
        book = cache.get_order_book("BTCUSDT")
        assert len(book.bids) == 50
        assert book.is_synced is True


# ------------------------------------------------------------------
# Worker: depth reconfiguration
# ------------------------------------------------------------------

class TestReconfigureDepthWorker:
    """Tests de reconfiguracion de depth en Worker (sin WS real)."""

    def test_diff_to_diff_increase_resets_sync(self) -> None:
        cfg = Config(stream_type="depth", depth=50)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=50,
        )
        worker._synced_symbols.add("BTCUSDT")
        assert worker._needs_sync is True

        # Sin WS conectado, reconfigure solo cambia estado interno
        # (no puede enviar mensajes WS)
        worker._depth = 200
        worker._synced_symbols.clear()
        worker._diff_buffer.clear()
        assert worker._depth == 200
        assert worker._synced_symbols == set()

    def test_partial_no_sync(self) -> None:
        cfg = Config(stream_type="depth", depth=5)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=5,
        )
        assert worker._needs_sync is False

    def test_worker_depth_change_offline(self) -> None:
        """Cambio de depth sin WS: solo actualiza estado."""
        cfg = Config(stream_type="depth", depth=50)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=50,
        )
        # Simular reconfigure offline (sin event loop)
        worker._depth = 200
        worker._needs_sync = 200 not in _PARTIAL_DEPTH_LEVELS
        assert worker._depth == 200
        assert worker._needs_sync is True

    def test_worker_depth_to_partial_offline(self) -> None:
        cfg = Config(stream_type="depth", depth=200)
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            depth=200,
        )
        assert worker._needs_sync is True

        worker._depth = 20
        worker._needs_sync = 20 not in _PARTIAL_DEPTH_LEVELS
        assert worker._depth == 20
        assert worker._needs_sync is False


# ------------------------------------------------------------------
# Worker: interval reconfiguration
# ------------------------------------------------------------------

class TestReconfigureIntervalWorker:
    """Tests de reconfiguracion de interval en Worker."""

    def test_interval_change_offline(self) -> None:
        cfg = Config(stream_type="kline", interval="1m")
        cache = MarketDataCache(cfg)
        worker = Worker(
            worker_id="kline_0",
            stream_type=StreamType.KLINE,
            symbols=["BTCUSDT"],
            config=cfg,
            cache=cache,
            interval="1m",
        )
        assert worker._interval == "1m"
        worker._interval = "5m"
        assert worker._interval == "5m"


# ------------------------------------------------------------------
# Manager: reconfigure() end-to-end (offline)
# ------------------------------------------------------------------

class TestReconfigureManagerOffline:
    """Tests de reconfigure() en Manager sin conexion."""

    def test_reconfigure_max_history(self) -> None:
        from market_streaming.manager import Manager
        cfg = Config(stream_type="trade", symbols=["BTCUSDT"], max_history=100)
        mgr = Manager(cfg)
        assert mgr._config.max_history == 100

        mgr.reconfigure(max_history=500)
        assert mgr._config.max_history == 500

    def test_reconfigure_depth(self) -> None:
        from market_streaming.manager import Manager
        cfg = Config(stream_type="depth", symbols=["BTCUSDT"], depth=50)
        mgr = Manager(cfg)
        assert mgr._config.depth == 50

        mgr.reconfigure(depth=200)
        assert mgr._config.depth == 200
        # Workers actualizados offline
        for w in mgr._workers.values():
            assert w._depth == 200

    def test_reconfigure_depth_to_partial(self) -> None:
        from market_streaming.manager import Manager
        cfg = Config(stream_type="depth", symbols=["BTCUSDT"], depth=200)
        mgr = Manager(cfg)
        mgr.reconfigure(depth=20)
        assert mgr._config.depth == 20
        for w in mgr._workers.values():
            assert w._depth == 20
            assert w._needs_sync is False

    def test_reconfigure_interval(self) -> None:
        from market_streaming.manager import Manager
        cfg = Config(stream_type="kline", symbols=["BTCUSDT"], interval="1m")
        mgr = Manager(cfg)
        assert mgr._config.interval == "1m"

        mgr.reconfigure(interval="5m")
        assert mgr._config.interval == "5m"
        for w in mgr._workers.values():
            assert w._interval == "5m"

    def test_reconfigure_repr_updated(self) -> None:
        from market_streaming.manager import Manager
        cfg = Config(stream_type="depth", symbols=["BTCUSDT"], depth=50)
        mgr = Manager(cfg)
        assert "depth=50" in repr(mgr)

        mgr.reconfigure(depth=200)
        assert "depth=200" in repr(mgr)
