"""Tests unitarios para el monitor de salud."""

import time

from market_streaming.config import Config
from market_streaming.health import HealthMonitor
from market_streaming.models import StreamState, StreamStatus, StreamType


def _make_status(
    stream_id: str = "test_stream",
    state: StreamState = StreamState.RUNNING,
    last_message_at: float | None = None,
    message_count: int = 10,
) -> StreamStatus:
    return StreamStatus(
        stream_id=stream_id,
        stream_type=StreamType.TRADE,
        symbol="BTCUSDT",
        state=state,
        last_message_at=last_message_at,
        message_count=message_count,
    )


class TestHealthMonitor:
    def test_healthy_stream(self) -> None:
        config = Config(stream_type="ticker", stale_threshold_s=30.0)
        monitor = HealthMonitor(config)
        status = _make_status(last_message_at=time.time())
        assert monitor.evaluate_stream(status) == StreamState.RUNNING

    def test_stale_stream(self) -> None:
        config = Config(stream_type="ticker", stale_threshold_s=5.0)
        monitor = HealthMonitor(config)
        status = _make_status(last_message_at=time.time() - 10.0)
        assert monitor.evaluate_stream(status) == StreamState.STALE

    def test_non_running_stream_not_evaluated(self) -> None:
        config = Config(stream_type="ticker")
        monitor = HealthMonitor(config)
        status = _make_status(state=StreamState.RECONNECTING)
        assert monitor.evaluate_stream(status) == StreamState.RECONNECTING

    def test_no_last_message_not_stale(self) -> None:
        config = Config(stream_type="ticker")
        monitor = HealthMonitor(config)
        status = _make_status(last_message_at=None)
        assert monitor.evaluate_stream(status) == StreamState.RUNNING

    def test_system_healthy(self) -> None:
        config = Config(stream_type="ticker", stale_threshold_s=30.0)
        monitor = HealthMonitor(config)
        streams = {
            "s1": _make_status("s1", last_message_at=time.time()),
            "s2": _make_status("s2", last_message_at=time.time()),
        }
        health = monitor.evaluate_system(streams, started_at=time.time() - 60)
        assert health.is_healthy is True
        assert health.running_streams == 2
        assert health.total_messages == 20

    def test_system_unhealthy_with_stale(self) -> None:
        config = Config(stream_type="ticker", stale_threshold_s=5.0)
        monitor = HealthMonitor(config)
        streams = {
            "s1": _make_status("s1", last_message_at=time.time()),
            "s2": _make_status("s2", last_message_at=time.time() - 60),
        }
        health = monitor.evaluate_system(streams, started_at=time.time() - 60)
        assert health.is_healthy is False
        assert health.stale_streams == 1

    def test_system_unhealthy_when_empty(self) -> None:
        config = Config(stream_type="ticker")
        monitor = HealthMonitor(config)
        health = monitor.evaluate_system({}, started_at=time.time())
        assert health.is_healthy is False
        assert health.total_streams == 0

    def test_system_with_stopped_stream(self) -> None:
        config = Config(stream_type="ticker")
        monitor = HealthMonitor(config)
        streams = {
            "s1": _make_status("s1", state=StreamState.STOPPED),
        }
        health = monitor.evaluate_system(streams, started_at=time.time())
        assert health.is_healthy is False
        assert health.stopped_streams == 1
