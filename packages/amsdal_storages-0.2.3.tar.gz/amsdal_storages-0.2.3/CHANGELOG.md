# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.3] - 2026-03-13

### Added

- Added upload_extra_args

## [0.2.2] - 2026-02-16

### Changed

- Upgrade amsdal dependency to v0.7.0 and amsdal_models to v0.6.2

## [0.2.1] - 2026-02-06

### Added

- AMSDAL EULA license
- CHANGELOG.md in Keep a Changelog format
- Consolidated CI/CD workflows

## [0.2.0] - 2026-02-06

### Changed

- Upgrade deps to amsdal v0.6.0

## [0.1.1] - 2025-09-22

### Fixed

- Fixed amsdal dependency version constraints

## [0.1.0] - 2025-09-22

### Added

- S3 storage implementation

