"""Extract changelog section for a specific version from CHANGELOG.md."""

import re
import sys


def extract_changelog(version: str) -> str:
    """Extract the changelog section for the given version tag (e.g., v0.1.0)."""
    # Strip leading 'v' if present
    version = version.lstrip('v')

    with open('CHANGELOG.md') as f:
        content = f.read()

    # Match the section for this version until the next version header or end of file
    pattern = rf'## \[{re.escape(version)}\].*?\n(.*?)(?=\n## \[|\Z)'
    match = re.search(pattern, content, re.DOTALL)

    if match:
        return match.group(1).strip()

    return f'Release {version}'


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: extract_changelog.py <version-tag>')
        sys.exit(1)

    print(extract_changelog(sys.argv[1]))
