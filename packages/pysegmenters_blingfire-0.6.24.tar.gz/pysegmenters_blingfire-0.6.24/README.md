# pysegmenters_blingfire

[![license](https://img.shields.io/github/license/oterrier/pysegmenters_blingfire)](https://github.com/oterrier/pysegmenters_blingfire/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pysegmenters_blingfire/workflows/tests/badge.svg)](https://github.com/oterrier/pysegmenters_blingfire/actions?query=workflow%3Atests)
[![docs](https://img.shields.io/readthedocs/pysegmenters_blingfire)](https://pysegmenters_blingfire.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pysegmenters_blingfire)](https://pypi.org/project/pysegmenters_blingfire/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pysegmenters_blingfire)](https://pypi.org/project/pysegmenters_blingfire/)

Rule based segmenter based on [BlingFire](https://github.com/microsoft/BlingFire)

## Installation

You can simply `pip install pysegmenters_blingfire`.

## Developing

### Pre-requisites

You will need to install `uv` (for managing the package and running tests):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pysegmenters_blingfire
```

Install the package in development mode with test dependencies:

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.
