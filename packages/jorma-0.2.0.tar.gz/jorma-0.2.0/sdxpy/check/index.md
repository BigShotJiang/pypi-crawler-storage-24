# check
| Scope          | Variable | Role        | Location |
| :--------------| :--------| :-----------| :--------|
| module         | text     | fixed value | line 10  |
| module         | doc      | fixed value | line 20  |
| module.display | node     | fixed value | line 2   |
| module.display | child    | stepper     | line 5   |
| Scope          | Variable | Role        | Location |
| :--------------| :--------| :-----------| :--------|
| module         | text     | fixed value | line 13  |
| module         | doc      | fixed value | line 24  |
| module.display | node     | fixed value | line 2   |
| module.display | child    | stepper     | line 8   |
| Scope                     | Variable | Role        | Location |
| :-------------------------| :--------| :-----------| :--------|
| module.Visitor._tag_enter | node     | fixed value | line 14  |
| module.Visitor._tag_enter | self     | fixed value | line 14  |
| module.Visitor._tag_exit  | node     | fixed value | line 16  |
| module.Visitor._tag_exit  | self     | fixed value | line 16  |
| module.Visitor._text      | node     | fixed value | line 18  |
| module.Visitor._text      | self     | fixed value | line 18  |
| module.Visitor.visit      | node     | fixed value | line 5   |
| module.Visitor.visit      | self     | fixed value | line 5   |
| module.Visitor.visit      | child    | stepper     | line 10  |
