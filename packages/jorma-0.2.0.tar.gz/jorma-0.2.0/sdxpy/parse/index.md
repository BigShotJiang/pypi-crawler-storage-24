# parse
| Scope                                  | Variable | Role        | Location |
| :--------------------------------------| :--------| :-----------| :--------|
| module.BetterParser._parse_EitherStart | back     | stepper     | line 7   |
| module.BetterParser._parse_EitherStart | rest     | fixed value | line 7   |
| module.BetterParser._parse_EitherStart | self     | fixed value | line 7   |
| module.BetterParser._parse_EitherStart | children | log         | line 8   |
| Scope                  | Variable | Role        | Location |
| :----------------------| :--------| :-----------| :--------|
| module.Any.__init__    | rest     | fixed value | line 24  |
| module.Any.__init__    | self     | fixed value | line 24  |
| module.Either.__eq__   | other    | fixed value | line 33  |
| module.Either.__eq__   | self     | fixed value | line 33  |
| module.Either.__init__ | children | fixed value | line 29  |
| module.Either.__init__ | rest     | fixed value | line 29  |
| module.Either.__init__ | self     | fixed value | line 29  |
| module.Lit.__eq__      | other    | fixed value | line 16  |
| module.Lit.__eq__      | self     | fixed value | line 16  |
| module.Lit.__init__    | chars    | fixed value | line 12  |
| module.Lit.__init__    | rest     | fixed value | line 12  |
| module.Lit.__init__    | self     | fixed value | line 12  |
| module.Match.__eq__    | other    | fixed value | line 6   |
| module.Match.__eq__    | self     | fixed value | line 6   |
| module.Match.__init__  | rest     | fixed value | line 3   |
| module.Match.__init__  | self     | fixed value | line 3   |
| module.Null.__init__   | self     | fixed value | line 40  |
| Scope                            | Variable | Role        | Location |
| :--------------------------------| :--------| :-----------| :--------|
| module.Parser._parse             | self     | fixed value | line 20  |
| module.Parser._parse             | tokens   | fixed value | line 20  |
| module.Parser._parse             | back     | fixed value | line 24  |
| module.Parser._parse             | front    | fixed value | line 24  |
| module.Parser._parse             | handler  | fixed value | line 25  |
| module.Parser._parse_Any         | back     | fixed value | line 12  |
| module.Parser._parse_Any         | rest     | fixed value | line 12  |
| module.Parser._parse_Any         | self     | fixed value | line 12  |
| module.Parser._parse_EitherStart | back     | fixed value | line 35  |
| module.Parser._parse_EitherStart | rest     | fixed value | line 35  |
| module.Parser._parse_EitherStart | self     | fixed value | line 35  |
| module.Parser._parse_EitherStart | left     | fixed value | line 43  |
| module.Parser._parse_EitherStart | right    | fixed value | line 44  |
| module.Parser._parse_Lit         | back     | fixed value | line 15  |
| module.Parser._parse_Lit         | rest     | fixed value | line 15  |
| module.Parser._parse_Lit         | self     | fixed value | line 15  |
| module.Parser.parse              | self     | fixed value | line 6   |
| module.Parser.parse              | text     | fixed value | line 6   |
| module.Parser.parse              | tokens   | fixed value | line 7   |
| Scope                     | Variable | Role        | Location |
| :-------------------------| :--------| :-----------| :--------|
| module                    | CHARS    | fixed value | line 4   |
| module.Tokenizer.__init__ | self     | fixed value | line 7   |
| module.Tokenizer._add     | self     | fixed value | line 36  |
| module.Tokenizer._add     | thing    | fixed value | line 36  |
| module.Tokenizer._setup   | self     | fixed value | line 10  |
| module.Tokenizer.tok      | self     | fixed value | line 16  |
| module.Tokenizer.tok      | text     | fixed value | line 16  |
| module.Tokenizer.tok      | ch       | stepper     | line 18  |
