# docgen
| Scope         | Variable | Role        | Location |
| :-------------| :--------| :-----------| :--------|
| module.add    | left     | fixed value | line 1   |
| module.add    | right    | fixed value | line 1   |
| module.double | x        | fixed value | line 4   |
| Scope                            | Variable    | Role               | Location |
| :--------------------------------| :-----------| :------------------| :--------|
| module                           | results     | fixed value        | line 61  |
| module                           | key         | stepper            | line 62  |
| module                           | value       | stepper            | line 62  |
| module.Extract.__init__          | self        | fixed value        | line 27  |
| module.Extract.extract           | filenames   | fixed value        | line 13  |
| module.Extract.extract           | extracter   | fixed value        | line 15  |
| module.Extract.extract           | filename    | stepper            | line 16  |
| module.Extract.extract           | reader      | fixed value        | line 17  |
| module.Extract.extract           | source      | most-recent holder | line 18  |
| module.Extract.extract           | tree        | most-recent holder | line 19  |
| module.Extract.extract           | module_name | most-recent holder | line 20  |
| module.Extract.extract_from      | module_name | fixed value        | line 39  |
| module.Extract.extract_from      | self        | fixed value        | line 39  |
| module.Extract.extract_from      | tree        | fixed value        | line 39  |
| module.Extract.save              | kind        | fixed value        | line 45  |
| module.Extract.save              | name        | fixed value        | line 45  |
| module.Extract.save              | node        | fixed value        | line 45  |
| module.Extract.save              | self        | fixed value        | line 45  |
| module.Extract.save              | docstring   | fixed value        | line 48  |
| module.Extract.visit_ClassDef    | node        | fixed value        | line 33  |
| module.Extract.visit_ClassDef    | self        | fixed value        | line 33  |
| module.Extract.visit_FunctionDef | node        | fixed value        | line 53  |
| module.Extract.visit_FunctionDef | self        | fixed value        | line 53  |
| Scope               | Variable   | Role        | Location |
| :-------------------| :----------| :-----------| :--------|
| module              | HEADING    | fixed value | line 9   |
| module              | MISSING    | fixed value | line 11  |
| module.format       | docstrings | fixed value | line 14  |
| module.format       | result     | log         | line 16  |
| module.format       | docstring  | stepper     | line 17  |
| module.format       | key        | stepper     | line 17  |
| module.format       | kind       | stepper     | line 17  |
| module.format_key   | key        | fixed value | line 24  |
| module.main         | filenames  | fixed value | line 35  |
| module.main         | docstrings | fixed value | line 36  |
| module.main         | page       | fixed value | line 37  |
| module.make_heading | key        | fixed value | line 28  |
| module.make_heading | kind       | fixed value | line 28  |
| Scope                  | Variable | Role        | Location |
| :----------------------| :--------| :-----------| :--------|
| module.Sample.__init__ | name     | fixed value | line 15  |
| module.Sample.__init__ | self     | fixed value | line 15  |
| module.Sample.rename   | new_name | fixed value | line 19  |
| module.Sample.rename   | self     | fixed value | line 19  |
| module.function        | param    | fixed value | line 4   |
| module.undocumented    | param    | fixed value | line 8   |
| Scope         | Variable | Role        | Location |
| :-------------| :--------| :-----------| :--------|
| module.double | x        | fixed value | line 1   |
