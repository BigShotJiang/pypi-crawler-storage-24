print(type(3))
