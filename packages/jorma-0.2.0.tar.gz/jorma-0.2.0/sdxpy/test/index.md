# test
| Scope  | Variable | Role    | Location |
| :------| :--------| :-------| :--------|
| module | name     | stepper | line 1   |
| Scope             | Variable | Role        | Location |
| :-----------------| :--------| :-----------| :--------|
| module.find_tests | prefix   | fixed value | line 20  |
| module.find_tests | func     | stepper     | line 21  |
| module.find_tests | name     | stepper     | line 21  |
| module.sign       | value    | fixed value | line 1   |
| Scope  | Variable   | Role        | Location |
| :------| :----------| :-----------| :--------|
| module | everything | fixed value | line 10  |
| module | func       | stepper     | line 11  |
| Scope  | Variable    | Role        | Location |
| :------| :-----------| :-----------| :--------|
| module | my_variable | fixed value | line 2   |
| Scope              | Variable | Role        | Location |
| :------------------| :--------| :-----------| :--------|
| module.show_locals | high     | fixed value | line 1   |
| module.show_locals | low      | fixed value | line 1   |
| module.show_locals | i        | stepper     | line 3   |
| Scope            | Variable  | Role        | Location |
| :----------------| :---------| :-----------| :--------|
| module           | TESTS     | fixed value | line 40  |
| module.run_tests | all_tests | fixed value | line 24  |
| module.run_tests | results   | fixed value | line 25  |
| module.run_tests | test      | stepper     | line 26  |
| module.sign      | value     | fixed value | line 2   |
| Scope            | Variable | Role        | Location |
| :----------------| :--------| :-----------| :--------|
| module.run_tests | results  | fixed value | line 21  |
| module.run_tests | name     | stepper     | line 22  |
| module.run_tests | test     | stepper     | line 22  |
| module.sign      | value    | fixed value | line 1   |
