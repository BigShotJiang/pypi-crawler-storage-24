from pydantic import BaseModel
from typing import Optional, List, Any
from datetime import datetime

class TestOptions(BaseModel):
    cache: Optional[bool] = True

class Metric(BaseModel):
    id: Optional[int] = None
    name: str
    description: Optional[str] = ''
    module: Optional[str] = "scdata.device.process"
    function: str
    unit: Optional[str] = ''
    post: Optional[bool] = False
    args: Optional[dict] = None
    kwargs: Optional[dict] = None
    depends_on: List[str] = []

class Sensor(BaseModel):
    id: int
    name: str
    description: str
    unit: Optional[str] = None

class Source(BaseModel):
    type: str = 'api'
    module: str = 'smartcitizen_connector'
    handler: str = 'SCDevice'

class APIParams(BaseModel):
    id: Any

class FileParams(BaseModel):
    id: Any # To be compatible with API id
    path: str

class CSVParams(FileParams):
    header_skip: Optional[List[int]] = [1,2,3]
    index: Optional[str] = 'TIME'
    separator: Optional[str] = ','
    tzaware: Optional[bool] = True
    timezone: Optional[str] = "UTC"
    date_format: Optional[str] = None

class DeviceOptions(BaseModel):
    clean_na: Optional[bool] = None
    frequency: Optional[str] = '1Min'
    resample: Optional[bool] = False
    min_date: Optional[str] = None
    max_date: Optional[str] = None
    limit: Optional[int] = None
    channels: Optional[List[str]] = []
    convert_units: Optional[bool] = True
    convert_names: Optional[bool] = True
    dateformat: Optional[str] = None

class Blueprint(BaseModel):
    meta: dict = dict()
    metrics: List[Metric] = []

class Name(BaseModel):
    id: int
    name: str
    description: str
    unit: str
