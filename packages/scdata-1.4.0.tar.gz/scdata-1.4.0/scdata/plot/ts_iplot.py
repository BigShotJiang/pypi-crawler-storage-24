# Plotly
import plotly.tools as tls
from plotly.io import renderers
# import plotly.graph_objs as go
from plotly.offline import iplot
from plotly.subplots import make_subplots

from scdata._config import config
from scdata.plot.tools import prepare_test_data, prepare_device_data
from scdata.tools.custom_logger import logger
from scdata.tools.dictmerge import dict_fmerge


def ts_iplot(self, **kwargs):
    """
    Plots timeseries in plotly interactive plot
    Parameters
    ----------
        traces: dict
            Data for the plot, with the format:
            "traces":  {"1": {"devices": ['8019043', '8019044', '8019004'],
                             "channel" : "PM_10",
                             "subplot": 1,
                             "extras": ['max', 'min', 'avg']},
                        "2": {"devices": "all",
                             "channel" : "TEMP",
                             "subplot": 2}
                        }
        options: dict
            Options including data processing prior to plot. Defaults in config._plot_def_opt
        formatting: dict
            Name of auxiliary electrode found in dataframe. Defaults in config._ts_plot_def_fmt
    Returns
    -------
        Plotly figure
    """

    from scdata.test.test import Test
    from scdata.device.device import Device

    if config.framework == 'jupyterlab': renderers.default = config.framework

    if 'traces' not in kwargs:
        logger.error('No traces defined')
        return None
    else:
        traces = kwargs['traces']

    if 'options' not in kwargs:
        logger.warning('Using default options')
        options = config._plot_def_opt
    else:
        options = dict_fmerge(config._plot_def_opt, kwargs['options'])

    if 'formatting' not in kwargs:
        logger.warning('Using default formatting')
        formatting = config._ts_plot_def_fmt['plotly']
    else:
        formatting = dict_fmerge(config._ts_plot_def_fmt['plotly'], kwargs['formatting'])

    # Get dataframe
    if isinstance(self, Test):
        df, subplots, sides = prepare_test_data(self, traces, options)
    elif isinstance(self, Device):
        df, subplots, sides = prepare_device_data(self, traces, options)

    # If empty, nothing to do here
    if df is None:
        return None

    n_subplots = len(subplots)

    # Size sanity check
    if formatting['width'] < 100:
        logger.info('Setting width to 800')
        formatting['width'] = 800
    if formatting['height'] < 100:
        logger.info('Reducing height to 600')
        formatting['height'] = 600

    figure = make_subplots(rows = n_subplots, cols=1,
                           shared_xaxes = formatting['sharex'])

    # Add traces
    for isbplt in range(n_subplots):

        for trace in subplots[isbplt]:

            figure.append_trace({'x': df.index,
                                 'y': df[trace],
                                 'type': 'scatter',
                                 'mode': 'lines+markers',
                                 'name': trace},
                                isbplt + 1, 1)

        # Name the axis
        if formatting['ylabel'] is not None:
            figure['layout']['yaxis' + str(isbplt+1)]['title']['text'] = formatting['ylabel'][isbplt+1]

        if formatting['yrange'] is not None:
            figure['layout']['yaxis' + str(isbplt+1)]['range'] = formatting['yrange'][isbplt+1]

    # Add axis labels
    if formatting['xlabel'] is not None:
        figure['layout']['xaxis' + str(n_subplots)]['title']['text'] = formatting['xlabel']

    # Add layout
    figure['layout'].update(width = formatting['width'],
                            height = formatting['height'],
                            # legend = dict(
                            #             traceorder='normal',
                            #             font = dict(family='sans-serif',
                            #                         size=10,
                            #                         color='#000'),
                            #             xanchor = 'center',
                            #             orientation = 'h',
                            #             itemsizing = 'trace',
                            #             yanchor = 'bottom',
                            #             bgcolor ='rgba(0,0,0,0)',
                            #             bordercolor = 'rgba(0,0,0,0)',
                            #             borderwidth = 0),
                            title=dict(text=formatting['title'])
                           )

    if options['show']: figure.show()

    return figure
