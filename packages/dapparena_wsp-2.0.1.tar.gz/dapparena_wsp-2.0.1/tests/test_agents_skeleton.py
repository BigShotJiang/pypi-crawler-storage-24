"""에이전트 스켈레톤 테스트 — import 및 구조 검증 (UT-S1-07)"""

import pytest
import sys
import os

# 에이전트 코드가 sdk를 임포트할 수 있도록 경로 추가
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestBaseAgentV2:
    """BaseAgent 추상 클래스 검증"""

    def test_abstract_class_cannot_instantiate(self):
        """BaseAgentV2를 직접 인스턴스화하면 TypeError"""
        from dapparena_wsp.base_agent import BaseAgentV2

        with pytest.raises(TypeError):
            BaseAgentV2(name="raw")  # type: ignore

    def test_concrete_agent_works(self):
        """BaseAgentV2를 상속하고 handle_task 구현 시 정상 동작"""
        from dapparena_wsp.a2a.models import Task
        from dapparena_wsp.base_agent import BaseAgentV2

        class ConcreteAgent(BaseAgentV2):
            async def handle_task(self, task: Task) -> Task:
                return task

        agent = ConcreteAgent(name="concrete", port=9999)
        assert agent.name == "concrete"
        assert agent.port == 9999

    def test_agent_card_generation(self):
        """get_agent_card()가 올바른 AgentCard를 반환"""
        from dapparena_wsp.a2a.models import Task
        from dapparena_wsp.base_agent import BaseAgentV2

        class TestAgent(BaseAgentV2):
            async def handle_task(self, task: Task) -> Task:
                return task

        agent = TestAgent(
            name="test_agent",
            description="테스트 설명",
            port=8080,
            skills=["skill1", "skill2"],
        )
        card = agent.get_agent_card()
        assert card.name == "test_agent"
        assert card.description == "테스트 설명"
        assert "skill1" in card.skills
        assert "8080" in card.url


class TestAgentImports:
    """에이전트 모듈 임포트 검증"""

    def test_can_import_sdk_package(self):
        import dapparena_wsp
        assert dapparena_wsp.__version__ == "1.2.0"

    def test_can_import_a2a_models(self):
        from dapparena_wsp.a2a.models import Task, Artifact, AgentCard, TaskState
        assert TaskState.SUBMITTED.value == "submitted"

    def test_can_import_a2a_client(self):
        from dapparena_wsp.a2a.client import A2AClientV2
        client = A2AClientV2()
        assert client._timeout == 120.0

    def test_can_import_orchestrator(self):
        from dapparena_wsp.orchestrator.engine import OrchestratorEngine
        engine = OrchestratorEngine()
        assert engine is not None

    def test_can_import_workflow(self):
        from dapparena_wsp.orchestrator.workflow import WorkflowStep, load_workflow
        step = WorkflowStep(agent="test", url="http://localhost:8000")
        assert step.agent == "test"
