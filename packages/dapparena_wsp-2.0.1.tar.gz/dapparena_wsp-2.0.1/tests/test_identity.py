"""Identity 모듈 단위 테스트 — DIDManager, DIDResolver (S3-01, S3-02)"""

import json

import pytest

from dapparena_wsp.identity.did_manager import DIDManager, DIDDocument


class TestDIDManager:
    """DIDManager 단위 테스트."""

    def test_did_string_format(self):
        """DID 문자열이 did:worldland:agent:{name} 형식인지 확인."""
        mgr = DIDManager("cheolsu", agent_id=1)
        assert mgr.did_string == "did:worldland:agent:cheolsu"

    def test_did_string_different_names(self):
        """다양한 에이전트 이름으로 DID 생성."""
        for name in ["younghee", "mansu", "test_agent"]:
            mgr = DIDManager(name)
            assert mgr.did_string == f"did:worldland:agent:{name}"

    def test_public_key_hex(self):
        """공개키가 hex 문자열인지 확인."""
        mgr = DIDManager("test")
        assert len(mgr.public_key_hex) == 64  # 32 bytes = 64 hex chars

    def test_public_key_multibase(self):
        """공개키 multibase가 z 접두사를 가지는지 확인."""
        mgr = DIDManager("test")
        assert mgr.public_key_multibase.startswith("z")

    def test_did_document_creation(self):
        """DID Document 생성 및 JSON-LD 구조 검증."""
        mgr = DIDManager("cheolsu", agent_id=1)
        doc = mgr.create_did_document(endpoint="http://localhost:8101")

        assert doc.id == "did:worldland:agent:cheolsu"
        assert doc.agent_id == 1
        assert len(doc.verification_method) == 1
        assert doc.verification_method[0]["type"] == "Ed25519VerificationKey2020"
        assert len(doc.authentication) == 1

        # 서비스 엔드포인트 확인
        assert len(doc.service) == 1
        assert doc.service[0]["type"] == "A2AEndpoint"
        assert doc.service[0]["serviceEndpoint"] == "http://localhost:8101"

    def test_did_document_without_endpoint(self):
        """엔드포인트 없이 DID Document 생성."""
        mgr = DIDManager("test")
        doc = mgr.create_did_document()
        assert len(doc.service) == 0

    def test_did_document_json_ld(self):
        """DID Document가 유효한 JSON-LD 구조인지 확인."""
        mgr = DIDManager("cheolsu", agent_id=1)
        doc = mgr.create_did_document()
        d = doc.to_dict()

        assert "@context" in d
        assert "https://www.w3.org/ns/did/v1" in d["@context"]
        assert d["id"] == "did:worldland:agent:cheolsu"

    def test_did_document_to_json(self):
        """DID Document JSON 직렬화."""
        mgr = DIDManager("test")
        doc = mgr.create_did_document()
        j = doc.to_json()
        parsed = json.loads(j)
        assert parsed["id"] == "did:worldland:agent:test"

    def test_sign_verify_roundtrip(self):
        """서명→검증 라운드트립."""
        mgr = DIDManager("test")
        message = b"Hello, World!"

        signature = mgr.sign(message)
        assert isinstance(signature, bytes)
        assert len(signature) > 0
        assert mgr.verify(message, signature)

    def test_verify_wrong_message(self):
        """잘못된 메시지로 검증 실패."""
        mgr = DIDManager("test")
        signature = mgr.sign(b"correct message")
        assert not mgr.verify(b"wrong message", signature)

    def test_verify_wrong_signature(self):
        """잘못된 서명으로 검증 실패."""
        mgr = DIDManager("test")
        mgr.sign(b"test")
        assert not mgr.verify(b"test", b"wrong_sig" * 8)

    def test_different_keys_per_instance(self):
        """인스턴스마다 다른 키가 생성되는지 확인."""
        mgr1 = DIDManager("test")
        mgr2 = DIDManager("test")
        assert mgr1.public_key_hex != mgr2.public_key_hex


class TestDIDDocument:
    """DIDDocument 데이터 클래스 테스트."""

    def test_default_values(self):
        doc = DIDDocument(id="did:worldland:agent:test")
        assert doc.agent_id == 0
        assert doc.controller == ""
        assert doc.verification_method == []
        assert doc.authentication == []
        assert doc.service == []

    def test_to_dict_structure(self):
        doc = DIDDocument(
            id="did:worldland:agent:test",
            agent_id=1,
            controller="did:worldland:agent:test",
        )
        d = doc.to_dict()
        assert isinstance(d, dict)
        assert "@context" in d
        assert "id" in d
        assert "controller" in d
