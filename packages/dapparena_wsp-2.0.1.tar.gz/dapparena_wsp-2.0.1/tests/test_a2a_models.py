"""단위 테스트 — A2A v2 데이터 모델 (UT-S1-01, UT-S1-02)"""

import json
import pytest

from dapparena_wsp.a2a.models import Artifact, AgentCard, Task, TaskState


class TestTaskState:
    """UT-S1-01: Task 생성 시 UUID 자동 할당, 상태 초기값 SUBMITTED"""

    def test_task_has_uuid_on_creation(self):
        task = Task(message="테스트 메시지")
        assert task.id is not None
        assert len(task.id) == 36  # UUID4 형식

    def test_task_initial_state_submitted(self):
        task = Task(message="테스트")
        assert task.state == TaskState.SUBMITTED

    def test_task_state_transition(self):
        task = Task(message="test")
        task.state = TaskState.WORKING
        assert task.state == TaskState.WORKING
        task.state = TaskState.COMPLETED
        assert task.state == TaskState.COMPLETED

    def test_task_state_enum_values(self):
        assert TaskState.SUBMITTED.value == "submitted"
        assert TaskState.WORKING.value == "working"
        assert TaskState.INPUT_REQUIRED.value == "input-required"
        assert TaskState.COMPLETED.value == "completed"
        assert TaskState.FAILED.value == "failed"


class TestArtifact:
    """UT-S1-02: Artifact JSON 직렬화/역직렬화"""

    def test_artifact_creation(self):
        artifact = Artifact(
            name="research_summary",
            mime_type="application/json",
            data='{"key": "value"}',
        )
        assert artifact.name == "research_summary"
        assert artifact.mime_type == "application/json"

    def test_artifact_json_roundtrip(self):
        original = Artifact(
            name="test",
            mime_type="application/json",
            data=json.dumps({"papers": [1, 2, 3]}),
        )
        d = original.to_dict()
        restored = Artifact.from_dict(d)
        assert restored.name == original.name
        assert restored.mime_type == original.mime_type
        assert restored.data == original.data

    def test_artifact_default_values(self):
        artifact = Artifact(name="simple")
        assert artifact.mime_type == "text/plain"
        assert artifact.data == ""


class TestTask:
    """Task 직렬화/역직렬화 및 속성"""

    def test_task_with_artifacts(self):
        task = Task(
            message="교재 만들어",
            artifacts=[
                Artifact(name="a1", data="data1"),
                Artifact(name="a2", data="data2"),
            ],
        )
        assert len(task.artifacts) == 2

    def test_task_json_roundtrip(self):
        original = Task(
            message="Blockchain 교재",
            artifacts=[Artifact(name="summary", data="내용")],
            metadata={"step": 1},
        )
        d = original.to_dict()
        restored = Task.from_dict(d)
        assert restored.id == original.id
        assert restored.message == original.message
        assert restored.state == original.state
        assert len(restored.artifacts) == 1
        assert restored.artifacts[0].name == "summary"
        assert restored.metadata["step"] == 1

    def test_task_from_dict_defaults(self):
        task = Task.from_dict({"message": "test"})
        assert task.state == TaskState.SUBMITTED
        assert task.artifacts == []
        assert task.metadata == {}

    def test_task_unique_ids(self):
        t1 = Task(message="a")
        t2 = Task(message="b")
        assert t1.id != t2.id


class TestAgentCard:
    """AgentCard 직렬화"""

    def test_agent_card_creation(self):
        card = AgentCard(
            name="cheolsu",
            description="연구 조교",
            url="http://localhost:8101",
            skills=["paper_search", "summarization"],
        )
        assert card.name == "cheolsu"
        assert len(card.skills) == 2

    def test_agent_card_roundtrip(self):
        original = AgentCard(
            name="younghee",
            description="편찬 조교",
            url="http://localhost:8102",
            skills=["writing"],
            auth={"type": "api_key"},
        )
        d = original.to_dict()
        restored = AgentCard.from_dict(d)
        assert restored.name == original.name
        assert restored.auth == {"type": "api_key"}
