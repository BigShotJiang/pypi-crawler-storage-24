"""RAG (VectorStore, Chunker) 테스트 — S2-06"""

import pytest

from dapparena_wsp.rag.vectorstore import VectorStore
from dapparena_wsp.rag.chunker import Chunker, Chunk


class TestVectorStore:
    """VectorStore 테스트."""

    def test_create_store(self):
        store = VectorStore(collection_name="test_store")
        assert store.count() == 0

    def test_index_and_count(self):
        store = VectorStore(collection_name="test_index")
        count = store.index([
            {"text": "블록체인은 분산 원장 기술입니다", "metadata": {"source": "doc1"}},
            {"text": "스마트 계약은 자동 실행됩니다", "metadata": {"source": "doc2"}},
        ])
        assert count == 2
        assert store.count() == 2

    def test_search(self):
        store = VectorStore(collection_name="test_search")
        store.index([
            {"text": "블록체인 합의 알고리즘 PoW PoS", "metadata": {"topic": "consensus"}},
            {"text": "스마트 계약 Solidity 배포", "metadata": {"topic": "smart_contracts"}},
            {"text": "영지식 증명 ZKP 프라이버시", "metadata": {"topic": "zkp"}},
        ])

        results = store.search("블록체인 합의", top_k=2)
        assert len(results) <= 2
        assert all(hasattr(r, "score") for r in results)

    def test_delete(self):
        store = VectorStore(collection_name="test_delete")
        store.index([
            {"text": "문서 A", "metadata": {}},
            {"text": "문서 B", "metadata": {}},
        ])
        # 인메모리 모드에서는 ID 기반 삭제
        assert store.count() == 2

    def test_clear(self):
        store = VectorStore(collection_name="test_clear")
        store.index([{"text": "테스트", "metadata": {}}])
        store.clear()
        assert store.count() == 0

    def test_empty_search(self):
        store = VectorStore(collection_name="test_empty_search")
        results = store.search("쿼리", top_k=5)
        assert len(results) == 0


class TestChunker:
    """Chunker 테스트."""

    def test_short_text(self):
        chunker = Chunker(max_tokens=512)
        chunks = chunker.split("짧은 텍스트입니다.")
        assert len(chunks) == 1
        assert chunks[0].text == "짧은 텍스트입니다."

    def test_markdown_headings(self):
        text = """# 제목

## 섹션 1
섹션 1 내용입니다.

## 섹션 2
섹션 2 내용입니다.
"""
        chunker = Chunker(max_tokens=512)
        chunks = chunker.split(text)
        assert len(chunks) >= 2
        sections = [c.metadata.get("section", "") for c in chunks]
        assert "섹션 1" in sections or "제목" in sections

    def test_long_text_splitting(self):
        # 1000단어 문서 생성
        text = " ".join(f"단어{i}" for i in range(1000))
        chunker = Chunker(max_tokens=100, overlap=20)
        chunks = chunker.split(text)
        assert len(chunks) > 1
        # 각 청크가 max_tokens 이하인지 확인
        for chunk in chunks:
            words = chunk.text.split()
            assert len(words) <= 120  # overlap 여유

    def test_metadata_propagation(self):
        chunker = Chunker(max_tokens=512)
        chunks = chunker.split("테스트 문서", metadata={"source": "unit_test"})
        assert chunks[0].metadata["source"] == "unit_test"

    def test_estimate_tokens(self):
        english = "This is a test sentence with several words."
        tokens = Chunker.estimate_tokens(english)
        assert tokens > 0

        korean = "블록체인 기술의 핵심 개념을 설명합니다."
        tokens_kr = Chunker.estimate_tokens(korean)
        assert tokens_kr > 0

    def test_reconstruct(self):
        chunker = Chunker(max_tokens=512)
        original = "섹션 1 내용입니다.\n\n섹션 2 내용입니다."
        chunks = chunker.split(original)
        reconstructed = chunker.reconstruct(chunks)
        assert len(reconstructed) > 0
