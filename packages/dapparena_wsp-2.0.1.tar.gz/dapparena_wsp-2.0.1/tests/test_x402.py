"""x402 모듈 단위 테스트 — X402PaymentHandler, SpendingGuardClient (S3-06, S3-07)"""

import json

import httpx
import pytest

from dapparena_wsp.x402.payment_handler import (
    X402PaymentHandler,
    PaymentRequirement,
    PaymentResult,
)
from dapparena_wsp.x402.spending_guard import SpendingGuardClient, SpendingStatus


class TestX402PaymentHandler:
    """X402PaymentHandler 단위 테스트."""

    @pytest.fixture
    def handler(self):
        return X402PaymentHandler(
            payer_tba="0xPayer",
            agent_id=1,
            x402_contract="0xX402Contract",
        )

    def test_is_payment_required_402(self, handler):
        """402 응답 감지."""
        request = httpx.Request("GET", "http://example.com")
        response = httpx.Response(status_code=402, request=request)
        assert handler.is_payment_required(response)

    def test_is_payment_required_200(self, handler):
        """200 응답은 결제 불필요."""
        request = httpx.Request("GET", "http://example.com")
        response = httpx.Response(status_code=200, request=request)
        assert not handler.is_payment_required(response)

    def test_parse_www_authenticate_header(self, handler):
        """WWW-Authenticate 헤더 파싱."""
        request = httpx.Request("GET", "http://example.com")
        response = httpx.Response(
            status_code=402,
            headers={
                "www-authenticate": (
                    'X402 amount=1000000000000000000,'
                    'recipient=0xRecipient,'
                    'contract=0xContract,'
                    'description="service fee"'
                ),
            },
            request=request,
        )
        req = handler.parse_402(response)
        assert req is not None
        assert req.amount_wei == 1000000000000000000
        assert req.amount_wlc == 1.0
        assert req.recipient == "0xRecipient"
        assert req.payment_contract == "0xContract"

    def test_parse_json_body(self, handler):
        """바디에서 결제 정보 파싱."""
        body = {
            "x402": {
                "amount": "500000000000000000",
                "recipient": "0xRecipient",
                "description": "쿼리 비용",
            }
        }
        request = httpx.Request("GET", "http://example.com")
        response = httpx.Response(
            status_code=402,
            json=body,
            request=request,
        )
        req = handler.parse_402(response)
        assert req is not None
        assert req.amount_wei == 500000000000000000
        assert req.amount_wlc == 0.5

    def test_parse_no_payment_info(self, handler):
        """결제 정보가 없는 402 응답."""
        request = httpx.Request("GET", "http://example.com")
        response = httpx.Response(status_code=402, text="Payment Required", request=request)
        req = handler.parse_402(response)
        assert req is None

    def test_build_payment_tx(self, handler):
        """결제 트랜잭션 빌드."""
        req = PaymentRequirement(
            amount_wei=1000000000000000000,
            recipient="0xRecipient",
            payment_contract="0xContract",
        )
        result = handler.build_payment_tx(req)
        assert result.success
        assert result.payment_id != ""
        assert result.tx_data is not None
        assert result.tx_data["to"] == "0xContract"
        assert result.amount_wei == 1000000000000000000
        assert result.amount_wlc == 1.0


class TestPaymentRequirement:
    """PaymentRequirement 데이터 테스트."""

    def test_amount_wlc(self):
        req = PaymentRequirement(
            amount_wei=2500000000000000000,
            recipient="0x123",
            payment_contract="0x456",
        )
        assert req.amount_wlc == 2.5


class TestPaymentResult:
    """PaymentResult 데이터 테스트."""

    def test_success_result(self):
        result = PaymentResult(
            success=True,
            payment_id="abc123",
            amount_wei=1e18,
        )
        assert result.success
        assert result.amount_wlc == 1.0

    def test_failure_result(self):
        result = PaymentResult(success=False, error="timeout")
        assert not result.success
        assert result.error == "timeout"


class TestSpendingGuardClient:
    """SpendingGuardClient 단위 테스트."""

    def test_build_set_limit_tx(self):
        """한도 설정 트랜잭션 빌드."""
        guard = SpendingGuardClient(contract_address="0xGuard")
        tx = guard.build_set_limit_tx(
            agent_id=1,
            limit_wei=10000000000000000000,  # 10 WLC
        )
        assert tx["to"] == "0xGuard"
        assert tx["data"].startswith("0x")

    def test_build_remove_limit_tx(self):
        """한도 제거 트랜잭션 빌드."""
        guard = SpendingGuardClient(contract_address="0xGuard")
        tx = guard.build_remove_limit_tx(agent_id=1)
        assert tx["to"] == "0xGuard"

    @pytest.mark.asyncio
    async def test_check_allowance_no_contract(self):
        """컨트랙트 미설정 시 무제한 허용."""
        guard = SpendingGuardClient(contract_address="")
        result = await guard.check_allowance(agent_id=1, amount_wei=999)
        assert result is True


class TestSpendingStatus:
    """SpendingStatus 데이터 테스트."""

    def test_conversions(self):
        status = SpendingStatus(
            agent_id=1,
            daily_limit_wei=10000000000000000000,
            spent_today_wei=3000000000000000000,
            remaining_wei=7000000000000000000,
            active=True,
        )
        assert status.daily_limit_wlc == 10.0
        assert status.spent_today_wlc == 3.0
        assert status.remaining_wlc == 7.0
