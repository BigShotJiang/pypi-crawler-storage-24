"""RAG E2E 통합 테스트 — scholar_workflow의 _enrich_topic_with_rag 검증

사용자 지식베이스 폴더가 주어졌을 때:
1. 파일을 읽어 벡터 색인하고
2. 주제 관련 검색하여
3. enriched_topic에 RAG 마커 문자열이 포함되는지 확인

테스트 실행:
    cd sdk/wsp && python -m pytest tests/test_rag_e2e.py -v
"""

import os
import tempfile
from pathlib import Path

import pytest


class TestEnrichTopicWithRAG:
    """_enrich_topic_with_rag() 공통 함수 테스트."""

    @pytest.fixture
    def knowledge_base_dir(self, tmp_path):
        """테스트용 지식베이스 폴더 생성."""
        # 블록체인 관련 텍스트 파일
        doc1 = tmp_path / "blockchain_basics.txt"
        doc1.write_text(
            "블록체인은 분산 원장 기술입니다. 각 블록은 이전 블록의 해시를 포함하며, "
            "이를 통해 데이터의 무결성을 보장합니다. PoW(작업증명)와 PoS(지분증명)는 "
            "대표적인 합의 알고리즘입니다. 비트코인은 PoW를, 이더리움 2.0은 PoS를 사용합니다.",
            encoding="utf-8",
        )

        # 마크다운 파일
        doc2 = tmp_path / "smart_contracts.md"
        doc2.write_text(
            "# 스마트 계약\n\n"
            "스마트 계약은 블록체인 상에서 자동으로 실행되는 프로그램입니다.\n"
            "Solidity는 이더리움 스마트 계약을 작성하는 데 가장 널리 사용되는 언어입니다.\n"
            "스마트 계약은 중개자 없이 신뢰할 수 있는 거래를 가능하게 합니다.\n",
            encoding="utf-8",
        )

        # 너무 짧은 파일 (50자 미만 → 무시되어야 함)
        doc3 = tmp_path / "short.txt"
        doc3.write_text("짧은 내용", encoding="utf-8")

        # 지원하지 않는 확장자 (무시되어야 함)
        doc4 = tmp_path / "image.png"
        doc4.write_bytes(b"\x89PNG\r\n")

        return tmp_path

    @pytest.mark.asyncio
    async def test_enrich_with_rag_context(self, knowledge_base_dir):
        """RAG 지식베이스가 있을 때 enriched_topic에 마커가 포함되는지 확인."""
        # scholar_workflow의 _enrich_topic_with_rag를 직접 임포트
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from scholar_workflow import _enrich_topic_with_rag, ChatRequest

        request = ChatRequest(
            message="블록체인 합의 알고리즘 교재 만들어",
            context={
                "knowledge_base": str(knowledge_base_dir),
                "style": "academic",
                "lang": "ko",
            },
            session_id="test_session_001",
        )

        enriched_topic, rag_summary = await _enrich_topic_with_rag(request)

        # ① RAG 마커 문자열 존재
        assert "사용자 제공 참고 자료 (RAG 지식베이스)" in enriched_topic

        # ② RAG 요약이 비어있지 않음
        assert len(rag_summary) > 0

        # ③ 원본 메시지가 포함됨
        assert "블록체인 합의 알고리즘 교재 만들어" in enriched_topic

        # ④ 스타일/언어 힌트가 포함됨
        assert "[스타일:academic]" in enriched_topic
        assert "[언어:ko]" in enriched_topic

    @pytest.mark.asyncio
    async def test_enrich_without_rag(self):
        """RAG 지식베이스가 없을 때 enriched_topic이 원본 그대로인지 확인."""
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from scholar_workflow import _enrich_topic_with_rag, ChatRequest

        request = ChatRequest(
            message="AI 기초 교재 만들어",
            context=None,
            session_id="test_no_rag",
        )

        enriched_topic, rag_summary = await _enrich_topic_with_rag(request)

        # RAG 없으면 원본과 동일
        assert enriched_topic == "AI 기초 교재 만들어"
        assert rag_summary == ""

    @pytest.mark.asyncio
    async def test_enrich_with_style_only(self):
        """스타일/언어만 있고 지식베이스 없을 때."""
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from scholar_workflow import _enrich_topic_with_rag, ChatRequest

        request = ChatRequest(
            message="딥러닝 교재 만들어",
            context={"style": "practical", "lang": "en"},
        )

        enriched_topic, rag_summary = await _enrich_topic_with_rag(request)

        assert "사용자 제공 참고 자료" not in enriched_topic
        assert "[스타일:practical]" in enriched_topic
        assert "[언어:en]" in enriched_topic
        assert rag_summary == ""

    @pytest.mark.asyncio
    async def test_enrich_nonexistent_path(self, tmp_path):
        """존재하지 않는 경로가 주어지면 RAG가 적용되지 않음."""
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from scholar_workflow import _enrich_topic_with_rag, ChatRequest

        request = ChatRequest(
            message="테스트 주제",
            context={"knowledge_base": str(tmp_path / "nonexistent_folder")},
        )

        enriched_topic, rag_summary = await _enrich_topic_with_rag(request)

        assert "사용자 제공 참고 자료" not in enriched_topic
        assert rag_summary == ""


class TestRAGMarkerPropagation:
    """RAG 마커가 에이전트 메시지에서 감지 가능한지 검증."""

    RAG_MARKER = "사용자 제공 참고 자료 (RAG 지식베이스)"

    def test_marker_detection_present(self):
        """RAG 마커가 포함된 메시지 감지."""
        message = f"주제\n\n---\n{self.RAG_MARKER}:\n[참고:doc.txt] 내용\n---"
        assert self.RAG_MARKER in message
        rag_start = message.index(self.RAG_MARKER)
        assert rag_start > 0

    def test_marker_detection_absent(self):
        """RAG 마커가 없는 메시지."""
        message = "일반 주제 메시지"
        assert self.RAG_MARKER not in message
