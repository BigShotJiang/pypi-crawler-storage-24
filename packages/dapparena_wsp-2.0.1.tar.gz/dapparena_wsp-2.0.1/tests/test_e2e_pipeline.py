"""E2E 파이프라인 테스트 — 3에이전트 순차 협업 (S1-12)

⚠️ 이 테스트는 3개 에이전트 서버가 실행 중일 때만 동작합니다.
   Ollama가 없으면 fallback 응답으로 테스트됩니다.

실행 방법:
    # 1. 에이전트 서버 시작 (각각 별도 터미널에서)
    cd agents/wsp && python -m cheolsu.agent
    cd agents/wsp && python -m younghee.agent
    cd agents/wsp && python -m mansu.agent

    # 2. E2E 테스트 실행
    cd sdk/wsp && pytest tests/test_e2e_pipeline.py -v
"""

import os

import pytest

from dapparena_wsp.a2a.client import A2AClientV2
from dapparena_wsp.a2a.models import Task, TaskState
from dapparena_wsp.orchestrator.engine import OrchestratorEngine
from dapparena_wsp.orchestrator.workflow import Workflow, WorkflowStep


# E2E 테스트는 에이전트 서버가 실행 중이어야 함
E2E_ENABLED = os.getenv("WSP_E2E_TEST", "false").lower() == "true"


@pytest.mark.skipif(not E2E_ENABLED, reason="WSP_E2E_TEST=true 필요")
class TestE2EPipeline:
    """E2E: 3에이전트 순차 협업 파이프라인"""

    @pytest.fixture
    def workflow(self):
        return Workflow(
            name="e2e_test_pipeline",
            description="E2E 테스트용 파이프라인",
            steps=[
                WorkflowStep(agent="cheolsu", url="http://localhost:8101", role="researcher"),
                WorkflowStep(agent="younghee", url="http://localhost:8102", role="editor"),
                WorkflowStep(agent="mansu", url="http://localhost:8103", role="evaluator"),
            ],
        )

    @pytest.mark.asyncio
    async def test_health_check(self):
        """① 3개 에이전트 모두 health 응답"""
        client = A2AClientV2()
        for port in [8101, 8102, 8103]:
            result = await client.health(f"http://localhost:{port}")
            assert result["status"] == "online"

    @pytest.mark.asyncio
    async def test_full_pipeline(self, workflow):
        """② 전체 파이프라인 실행 — 3에이전트 순차 협업"""
        engine = OrchestratorEngine()
        result = await engine.execute_workflow(
            workflow,
            "Blockchain 기초 교재 만들어",
        )

        # ① 최종 상태 completed
        assert result.state == TaskState.COMPLETED

        # ② 모든 artifacts 확인
        artifact_names = [a.name for a in result.artifacts]
        assert "research_summary" in artifact_names
        assert "chapter_draft" in artifact_names
        assert "exercises" in artifact_names
        assert "final_textbook" in artifact_names

        # ③ workflow_id 메타데이터 존재
        assert "workflow_id" in result.metadata

    @pytest.mark.asyncio
    async def test_individual_agents(self):
        """③ 개별 에이전트 직접 호출"""
        client = A2AClientV2()

        # 철수 테스트
        task = Task(message="ZKP 논문 검색")
        result = await client.send_task("http://localhost:8101", task)
        assert result.state == TaskState.COMPLETED
        assert any(a.name == "research_summary" for a in result.artifacts)


class TestE2EWithMocks:
    """E2E Mock 테스트 — 서버 없이 동작하는 구조 검증"""

    def test_workflow_creation(self):
        """워크플로 YAML 없이 직접 Workflow 객체 생성"""
        workflow = Workflow(
            name="mock_pipeline",
            steps=[
                WorkflowStep(agent="a", url="http://localhost:9001"),
                WorkflowStep(agent="b", url="http://localhost:9002"),
                WorkflowStep(agent="c", url="http://localhost:9003"),
            ],
        )
        assert len(workflow.steps) == 3
        assert workflow.steps[0].agent == "a"
        assert workflow.steps[2].agent == "c"

    def test_engine_creation(self):
        """OrchestratorEngine 인스턴스 생성"""
        engine = OrchestratorEngine()
        assert engine is not None
        assert engine._client is not None
