"""LLM 커넥터 — Ollama / 외부 API 통합 인터페이스 (S2-07)"""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod

logger = logging.getLogger("dapparena_wsp.llm.connector")


class LLMConnector(ABC):
    """LLM 커넥터 추상 인터페이스."""

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.4,
    ) -> str:
        """텍스트를 생성합니다."""
        ...

    @abstractmethod
    async def is_available(self) -> bool:
        """LLM이 사용 가능한지 확인합니다."""
        ...


class OllamaConnector(LLMConnector):
    """Ollama 로컬 LLM 커넥터.

    Example:
        connector = OllamaConnector(model="gemma3:12b")
        response = await connector.generate("블록체인 설명")
    """

    def __init__(
        self,
        model: str = "",
        host: str = "",
    ):
        self.model = model or os.getenv("OLLAMA_MODEL", "gemma3:12b")
        self.host = host or os.getenv("OLLAMA_HOST", "http://localhost:11434")

    async def generate(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.4,
    ) -> str:
        """Ollama를 통해 텍스트를 생성합니다."""
        try:
            import ollama

            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})

            response = ollama.chat(
                model=self.model,
                messages=messages,
                options={
                    "temperature": temperature,
                    "num_predict": 8192,   # 긴 문서 생성 지원 (gemma3:12b)
                    "num_ctx": 32768,      # 32K 컨텍스트 윈도우 (gemma3:12b 최대 128K)
                },
            )
            return response["message"]["content"]

        except Exception as e:
            logger.warning(f"Ollama 생성 실패: {e}")
            return f"[LLM 오류] Ollama 호출 실패: {e}"

    async def is_available(self) -> bool:
        """Ollama 서버가 실행 중인지 확인합니다."""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(self.host)
                return resp.status_code == 200
        except Exception:
            return False
