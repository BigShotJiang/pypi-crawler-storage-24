"""Agent Card — /.well-known/agent.json 엔드포인트 생성 (S1-04)"""

from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import APIRouter
from fastapi.responses import JSONResponse

if TYPE_CHECKING:
    from ..base_agent import BaseAgentV2

agent_card_router = APIRouter(tags=["Agent Card"])

_agent_instance: BaseAgentV2 | None = None


def register_agent_card(agent: BaseAgentV2) -> None:
    """Agent Card 라우터에 에이전트 인스턴스를 등록합니다."""
    global _agent_instance
    _agent_instance = agent


@agent_card_router.get("/.well-known/agent.json")
async def get_agent_card() -> JSONResponse:
    """에이전트 능력 명세를 JSON으로 반환합니다.

    GET /.well-known/agent.json
    """
    if _agent_instance is None:
        return JSONResponse(
            content={"error": "Agent not registered"},
            status_code=503,
        )
    card = _agent_instance.get_agent_card()
    return JSONResponse(content=card.to_dict())
