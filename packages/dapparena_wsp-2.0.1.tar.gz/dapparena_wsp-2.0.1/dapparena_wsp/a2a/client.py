"""A2A v2 Client — 다른 에이전트에 Task를 전송하고 결과를 수신 (S1-02, S4 업데이트)

Slice 4 (FR-OC-02.2): 지수 백오프 자동 재연결 + 영속 큐 지원.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

from .models import Task, TaskState

logger = logging.getLogger("dapparena_wsp.a2a.client")


class AgentUnavailableError(Exception):
    """에이전트 연결 실패 (모든 재시도 소진)."""
    pass


class A2AClientV2:
    """A2A v2 클라이언트 — Task 기반 에이전트 간 통신.

    Slice 4: 지수 백오프 자동 재연결 지원.

    Example:
        client = A2AClientV2()
        task = Task(message="논문 검색해줘")
        result = await client.send_task("http://localhost:8101", task)
        print(result.state, result.artifacts)
    """

    def __init__(
        self,
        timeout: float = 120.0,
        api_key: str = "",
        max_retries: int = 5,
        initial_backoff: float = 2.0,
        max_backoff: float = 64.0,
    ):
        self._timeout = timeout
        self._api_key = api_key
        # Slice 4: ACP 바인딩 설정
        self._max_retries = max_retries
        self._initial_backoff = initial_backoff
        self._max_backoff = max_backoff

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["X-API-Key"] = self._api_key
        return headers

    async def send_task(self, agent_url: str, task: Task) -> Task:
        """에이전트에 Task를 전송하고 완료된 Task를 수신합니다.

        Args:
            agent_url: 대상 에이전트 base URL (예: "http://localhost:8101")
            task: 전송할 Task 객체

        Returns:
            처리 완료된 Task (state, artifacts 포함)
        """
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{agent_url}/a2a/tasks/send",
                json=task.to_dict(),
                headers=self._headers(),
            )
            resp.raise_for_status()
            return Task.from_dict(resp.json())

    async def send_task_with_retry(
        self,
        agent_url: str,
        task: Task,
        max_retries: int | None = None,
    ) -> Task:
        """ACP 바인딩: 지수 백오프 자동 재연결 (FR-OC-02.2).

        에이전트가 다운된 경우 지수 백오프로 자동 재연결을 시도합니다.

        Args:
            agent_url: 대상 에이전트 URL
            task: 전송할 Task
            max_retries: 최대 재시도 횟수 (None이면 기본값)

        Returns:
            처리 완료된 Task

        Raises:
            AgentUnavailableError: 모든 재시도 소진
        """
        retries = max_retries if max_retries is not None else self._max_retries
        last_error: Exception | None = None

        for attempt in range(retries):
            try:
                result = await self.send_task(agent_url, task)
                if attempt > 0:
                    logger.info(
                        f"✅ {agent_url} 재연결 성공 (시도 {attempt + 1})"
                    )
                return result

            except (httpx.ConnectError, httpx.TimeoutException, ConnectionError, OSError) as e:
                last_error = e
                delay = min(
                    self._initial_backoff * (2 ** attempt),
                    self._max_backoff,
                )
                logger.warning(
                    f"⚠️ {agent_url} 연결 실패 — "
                    f"재시도 {attempt + 1}/{retries} ({delay:.0f}초 후): {e}"
                )
                await asyncio.sleep(delay)

            except httpx.HTTPStatusError as e:
                # 서버 에러(5xx)는 재시도, 클라이언트 에러(4xx)는 즉시 실패
                if e.response.status_code >= 500:
                    last_error = e
                    delay = min(
                        self._initial_backoff * (2 ** attempt),
                        self._max_backoff,
                    )
                    logger.warning(
                        f"⚠️ {agent_url} 서버 에러 {e.response.status_code} — "
                        f"재시도 {attempt + 1}/{retries} ({delay:.0f}초 후)"
                    )
                    await asyncio.sleep(delay)
                else:
                    raise

        raise AgentUnavailableError(
            f"❌ {agent_url} {retries}회 재시도 실패: {last_error}"
        )

    async def get_task(self, agent_url: str, task_id: str) -> Task:
        """Task ID로 상태를 조회합니다."""
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{agent_url}/a2a/tasks/{task_id}",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return Task.from_dict(resp.json())

    async def cancel_task(self, agent_url: str, task_id: str) -> Task:
        """실행 중인 Task를 취소합니다."""
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{agent_url}/a2a/tasks/{task_id}/cancel",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return Task.from_dict(resp.json())

    async def health(self, agent_url: str) -> dict:
        """에이전트 헬스체크."""
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{agent_url}/health",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return resp.json()

    async def is_available(self, agent_url: str) -> bool:
        """에이전트 가용성 확인 (예외 없이 bool 반환).

        Returns:
            True if the agent is online and responding
        """
        try:
            await self.health(agent_url)
            return True
        except Exception:
            return False
