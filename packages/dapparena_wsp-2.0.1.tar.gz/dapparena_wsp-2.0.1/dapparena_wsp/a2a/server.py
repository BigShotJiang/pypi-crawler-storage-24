"""A2A v2 Server — FastAPI 라우터로 Task를 수신하고 처리 (S1-03)"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from .models import Task, TaskState

if TYPE_CHECKING:
    from ..base_agent import BaseAgentV2

logger = logging.getLogger("dapparena_wsp.a2a.server")

router = APIRouter(prefix="/a2a", tags=["A2A v2"])

# 에이전트 인스턴스는 서버 시작 시 등록됩니다
_agent_instance: BaseAgentV2 | None = None
_task_store: dict[str, Task] = {}


def register_agent(agent: BaseAgentV2) -> None:
    """A2A 서버에 에이전트 인스턴스를 등록합니다."""
    global _agent_instance
    _agent_instance = agent


def _get_agent() -> BaseAgentV2:
    if _agent_instance is None:
        raise HTTPException(status_code=503, detail="Agent not registered")
    return _agent_instance


@router.post("/tasks/send")
async def send_task(request: Request) -> JSONResponse:
    """Task를 수신하여 에이전트에 위임하고 결과를 반환합니다.

    POST /a2a/tasks/send
    Body: Task JSON
    """
    agent = _get_agent()
    body = await request.json()
    task = Task.from_dict(body)

    logger.info(f"[A2A] Task 수신: id={task.id}, message={task.message[:50]}...")

    # 상태를 working으로 변경
    task.state = TaskState.WORKING
    _task_store[task.id] = task

    try:
        # LLM 설정: task.metadata에서 llm_provider/gemini_api_key 읽어 에이전트 LLMRouter 설정
        _llm_provider = task.metadata.get("llm_provider", "")
        _gemini_key = task.metadata.get("gemini_api_key", "")
        if hasattr(agent, 'llm') and _llm_provider:
            if _llm_provider == "gemini" and _gemini_key:
                agent.llm.prefer_local = False
                agent.llm.gemini_api_key = _gemini_key
                agent.llm.gemini_model = "gemini-3-flash-preview"
                logger.info(f"[A2A] LLM: gemini-3-flash-preview")
            else:
                agent.llm.prefer_local = True
                logger.info(f"[A2A] LLM: Ollama (local)")

        result = await agent.handle_task(task)
        result.state = TaskState.COMPLETED

        # 실제 사용된 LLM 정보를 metadata에 기록
        if hasattr(agent, 'llm') and agent.llm.last_used_model:
            result.metadata["actual_llm"] = agent.llm.last_used_model

        _task_store[result.id] = result
        logger.info(f"[A2A] Task 완료: id={result.id}, artifacts={len(result.artifacts)}")
        return JSONResponse(content=result.to_dict())
    except Exception as e:
        task.state = TaskState.FAILED
        task.metadata["error"] = str(e)
        _task_store[task.id] = task
        logger.error(f"[A2A] Task 실패: id={task.id}, error={e}")
        return JSONResponse(content=task.to_dict(), status_code=500)


@router.get("/tasks/{task_id}")
async def get_task(task_id: str) -> JSONResponse:
    """Task ID로 상태를 조회합니다.

    GET /a2a/tasks/{task_id}
    """
    task = _task_store.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return JSONResponse(content=task.to_dict())


@router.post("/tasks/{task_id}/cancel")
async def cancel_task(task_id: str) -> JSONResponse:
    """실행 중인 Task를 취소합니다.

    POST /a2a/tasks/{task_id}/cancel
    """
    task = _task_store.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    task.state = TaskState.FAILED
    task.metadata["cancelled"] = True
    _task_store[task_id] = task
    return JSONResponse(content=task.to_dict())
