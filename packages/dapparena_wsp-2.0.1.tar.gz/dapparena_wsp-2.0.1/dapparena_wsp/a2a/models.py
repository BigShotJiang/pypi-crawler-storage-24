"""A2A v2 데이터 모델 — Task, Artifact, AgentCard (S1-01)

Google A2A 표준에 맞춰 에이전트 간 구조화된 데이터 교환을 지원합니다.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TaskState(str, Enum):
    """Task 생명 주기 상태."""
    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Artifact:
    """에이전트가 생성하거나 전달하는 산출물.

    Attributes:
        name: 산출물 이름 (예: "research_summary")
        mime_type: MIME 타입 (예: "application/json", "text/markdown")
        data: 실제 데이터 (인라인 텍스트 또는 base64 바이너리)
    """
    name: str
    mime_type: str = "text/plain"
    data: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "mime_type": self.mime_type, "data": self.data}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Artifact:
        return cls(
            name=d["name"],
            mime_type=d.get("mime_type", "text/plain"),
            data=d.get("data", ""),
        )


@dataclass
class Task:
    """에이전트 간 주고받는 작업 단위.

    Attributes:
        id: 고유 식별자 (UUID)
        state: 현재 상태 (submitted → working → completed/failed)
        message: 사용자/에이전트의 요청 텍스트
        artifacts: 첨부된 산출물 목록
        metadata: 추가 메타데이터 (자유 형식)
    """
    message: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    state: TaskState = TaskState.SUBMITTED
    artifacts: list[Artifact] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "state": self.state.value,
            "message": self.message,
            "artifacts": [a.to_dict() for a in self.artifacts],
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Task:
        return cls(
            id=d.get("id", str(uuid.uuid4())),
            state=TaskState(d.get("state", "submitted")),
            message=d.get("message", ""),
            artifacts=[Artifact.from_dict(a) for a in d.get("artifacts", [])],
            metadata=d.get("metadata", {}),
        )


@dataclass
class AgentCard:
    """에이전트 능력 명세 — /.well-known/agent.json으로 노출.

    Attributes:
        name: 에이전트 이름 (예: "cheolsu")
        description: 역할 설명
        url: 에이전트 엔드포인트 URL
        skills: 보유 스킬 목록
        auth: 인증 방식 (예: {"type": "api_key"})
        version: SDK 버전
        protocol: 통신 프로토콜
        did: DID 문자열 (Slice 3)
        tba_address: Token Bound Account 주소 (Slice 3)
        trusted: TrustRegistry 공인 여부 (Slice 3)
        pricing: 요금 정보 (Slice 3)
        endpoints: 엔드포인트 경로 목록 (Slice 3)
    """
    name: str
    description: str = ""
    url: str = ""
    skills: list[str] = field(default_factory=list)
    auth: dict[str, str] = field(default_factory=lambda: {"type": "none"})
    version: str = "1.2.0"
    protocol: str = "a2a-v2"
    did: str = ""
    tba_address: str = ""
    trusted: bool = False
    pricing: dict[str, str] = field(default_factory=dict)
    endpoints: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "url": self.url,
            "version": self.version,
            "protocol": self.protocol,
            "skills": self.skills,
        }
        if self.did:
            result["did"] = self.did
        if self.tba_address:
            result["tba_address"] = self.tba_address
        if self.did:
            result["trusted"] = self.trusted
        if self.pricing:
            result["pricing"] = self.pricing
        if self.endpoints:
            result["endpoints"] = self.endpoints
        result["auth"] = self.auth
        return result

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AgentCard:
        return cls(
            name=d["name"],
            description=d.get("description", ""),
            url=d.get("url", ""),
            skills=d.get("skills", []),
            auth=d.get("auth", {"type": "none"}),
            version=d.get("version", "1.2.0"),
            protocol=d.get("protocol", "a2a-v2"),
            did=d.get("did", ""),
            tba_address=d.get("tba_address", ""),
            trusted=d.get("trusted", False),
            pricing=d.get("pricing", {}),
            endpoints=d.get("endpoints", {}),
        )
