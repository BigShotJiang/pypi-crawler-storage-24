"""heungno.net MCP Server — 강의 스케줄/자료 스크래핑 (S2-04)

heungno.net에서 강의 스케줄과 강의 노트를 가져옵니다.
접속 불가 시 Mock 데이터로 동작합니다.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from ..server import MCPServer

logger = logging.getLogger("dapparena_wsp.mcp.heungno")

HEUNGNO_URL = os.getenv("HEUNGNO_URL", "http://heungno.net")

heungno_server = MCPServer("heungno", port=9003)

# Mock 데이터
MOCK_SCHEDULE = [
    {
        "week": 1,
        "topic": "블록체인 개요 및 분산 시스템 기초",
        "date": "2026-03-03",
        "reading": "Chapter 1: Introduction to Blockchain",
        "assignment": "Lab 1: 비트코인 네트워크 분석",
    },
    {
        "week": 2,
        "topic": "합의 알고리즘 (PoW, PoS, PBFT)",
        "date": "2026-03-10",
        "reading": "Chapter 2: Consensus Mechanisms",
        "assignment": "Lab 2: 합의 알고리즘 시뮬레이션",
    },
    {
        "week": 3,
        "topic": "스마트 계약 — Solidity 기초",
        "date": "2026-03-17",
        "reading": "Chapter 3: Smart Contracts",
        "assignment": "Lab 3: 첫 번째 스마트 계약 배포",
    },
    {
        "week": 4,
        "topic": "DeFi 프로토콜 분석",
        "date": "2026-03-24",
        "reading": "Chapter 4: Decentralized Finance",
        "assignment": "Lab 4: DEX 프로토콜 구현",
    },
    {
        "week": 5,
        "topic": "ZKP(영지식 증명) 이론 및 응용",
        "date": "2026-03-31",
        "reading": "Chapter 5: Zero-Knowledge Proofs",
        "assignment": "Lab 5: zk-SNARK 회로 작성",
    },
]

MOCK_LECTURE_NOTES = {
    1: {
        "week": 1,
        "title": "블록체인 개요",
        "content": (
            "# 블록체인 개요\n\n"
            "## 1. 분산 시스템 기초\n"
            "- 분산 원장 기술(DLT)의 정의\n"
            "- 비잔틴 장군 문제와 합의\n"
            "- 해시 함수와 머클 트리\n\n"
            "## 2. 블록체인 구조\n"
            "- 블록: 헤더 + 트랜잭션 목록\n"
            "- 체이닝: 이전 블록 해시 참조\n"
            "- 불변성(immutability) 원리\n\n"
            "## 3. 주요 플랫폼\n"
            "- Bitcoin: 첫 번째 퍼블릭 블록체인\n"
            "- Ethereum: 튜링 완전 스마트 계약\n"
            "- WorldLand: 친환경 합의 기반 L1\n"
        ),
    },
    5: {
        "week": 5,
        "title": "ZKP 이론 및 응용",
        "content": (
            "# ZKP(영지식 증명)\n\n"
            "## 1. 이론적 배경\n"
            "- 완전성(Completeness), 건전성(Soundness), 영지식성(Zero-knowledge)\n"
            "- 대화형 증명 vs 비대화형 증명\n\n"
            "## 2. 주요 ZKP 시스템\n"
            "- zk-SNARKs: Succinct Non-interactive Arguments of Knowledge\n"
            "- zk-STARKs: Scalable Transparent Arguments of Knowledge\n"
            "- Bulletproofs: Short Non-interactive Zero-Knowledge Proofs\n\n"
            "## 3. 응용 분야\n"
            "- 프라이버시 보장 트랜잭션 (Zcash)\n"
            "- 롤업 스케일링 (zkSync, StarkNet)\n"
            "- 탈중앙 신원 인증\n"
        ),
    },
}


@heungno_server.tool("get_schedule", "강의 스케줄 조회")
async def get_schedule() -> list[dict[str, Any]]:
    """heungno.net에서 강의 스케줄을 가져옵니다."""
    # TODO: 실제 스크래핑 구현
    logger.info("📅 heungno.net 강의 스케줄 조회 (Mock)")
    return MOCK_SCHEDULE


@heungno_server.tool("get_lecture_notes", "강의 노트 조회")
async def get_lecture_notes(week: int) -> dict[str, Any]:
    """특정 주차의 강의 노트를 가져옵니다."""
    logger.info(f"📝 heungno.net 강의 노트 조회: {week}주차 (Mock)")
    note = MOCK_LECTURE_NOTES.get(week)
    if note:
        return note
    return {
        "week": week,
        "title": f"{week}주차 강의",
        "content": f"# {week}주차 강의 노트\n\n(해당 주차 강의 자료가 아직 등록되지 않았습니다.)",
    }


@heungno_server.tool("search_content", "강의 자료 검색")
async def search_content(query: str) -> list[dict[str, Any]]:
    """강의 관련 콘텐츠를 검색합니다."""
    logger.info(f"🔍 heungno.net 검색: '{query}' (Mock)")
    results = []
    query_lower = query.lower()
    for note in MOCK_LECTURE_NOTES.values():
        if query_lower in note["content"].lower() or query_lower in note["title"].lower():
            results.append({
                "week": note["week"],
                "title": note["title"],
                "snippet": note["content"][:200],
                "relevance": 0.9,
            })
    return results


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    heungno_server.run()
