"""Local Drive MCP Server — 로컬 폴더 파일 액세스 (S2-03)

로컬 파일 시스템의 지정된 폴더에서 교재·자료를 읽고 검색합니다.
Google Drive API 없이 동작하며, .env의 LOCAL_DRIVE_PATH로 폴더를 지정합니다.

지원 파일 형식:
  - 텍스트: .txt, .md, .csv, .json, .xml, .yaml, .yml, .py, .js, .html
  - 문서:  .pdf (텍스트 추출), .docx (python-docx)
  - 기타:  메타데이터만 반환
"""

from __future__ import annotations

import logging
import mimetypes
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..server import MCPServer

logger = logging.getLogger("dapparena_wsp.mcp.drive")

# ── 설정 ──
LOCAL_DRIVE_PATH = os.getenv("LOCAL_DRIVE_PATH", "")

drive_server = MCPServer("local-drive", port=9002)

# 읽을 수 있는 텍스트 확장자
TEXT_EXTENSIONS = {
    ".txt", ".md", ".csv", ".json", ".xml", ".yaml", ".yml",
    ".py", ".js", ".ts", ".html", ".css", ".log", ".ini", ".cfg", ".toml",
}


def _get_root() -> Path | None:
    """로컬 드라이브 루트 경로를 반환합니다."""
    root = LOCAL_DRIVE_PATH
    if not root:
        return None
    p = Path(root)
    if p.exists() and p.is_dir():
        return p
    logger.warning(f"LOCAL_DRIVE_PATH가 존재하지 않습니다: {root}")
    return None


def _file_info(filepath: Path, root: Path) -> dict[str, Any]:
    """파일의 메타데이터를 반환합니다."""
    stat = filepath.stat()
    rel_path = str(filepath.relative_to(root)).replace("\\", "/")
    mime, _ = mimetypes.guess_type(str(filepath))
    return {
        "id": rel_path,
        "name": filepath.name,
        "path": rel_path,
        "mime_type": mime or "application/octet-stream",
        "size": stat.st_size,
        "modified_time": datetime.fromtimestamp(
            stat.st_mtime, tz=timezone.utc
        ).isoformat(),
    }


def _read_text_file(filepath: Path) -> str:
    """텍스트 파일을 읽습니다 (여러 인코딩 시도)."""
    for encoding in ("utf-8", "cp949", "euc-kr", "latin-1"):
        try:
            return filepath.read_text(encoding=encoding)
        except (UnicodeDecodeError, UnicodeError):
            continue
    return "[인코딩 오류 — 파일을 읽을 수 없습니다]"


def _read_pdf(filepath: Path) -> str:
    """PDF에서 텍스트를 추출합니다."""
    try:
        import PyPDF2
        with open(filepath, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            pages = []
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    pages.append(text)
            return "\n\n".join(pages) if pages else "[PDF 텍스트 추출 실패]"
    except ImportError:
        return "[PyPDF2 미설치 — pip install PyPDF2]"
    except Exception as e:
        return f"[PDF 읽기 오류: {e}]"


def _read_docx(filepath: Path) -> str:
    """DOCX에서 텍스트를 추출합니다."""
    try:
        from docx import Document
        doc = Document(str(filepath))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        return "\n\n".join(paragraphs) if paragraphs else "[DOCX 내용 없음]"
    except ImportError:
        return "[python-docx 미설치 — pip install python-docx]"
    except Exception as e:
        return f"[DOCX 읽기 오류: {e}]"


# ── MCP Tools ──


@drive_server.tool("list_files", "로컬 폴더 파일 목록 조회")
async def list_files(
    folder: str = "", max_results: int = 20
) -> list[dict[str, Any]]:
    """로컬 폴더에서 파일 목록을 조회합니다.

    Args:
        folder: 하위 폴더 경로 (비어있으면 루트)
        max_results: 최대 결과 수

    Returns:
        파일 목록 (id, name, path, mime_type, size, modified_time)
    """
    root = _get_root()
    if not root:
        logger.warning("LOCAL_DRIVE_PATH가 설정되지 않았습니다")
        return [{"error": "LOCAL_DRIVE_PATH가 .env에 설정되지 않았습니다"}]

    target = root / folder if folder else root
    if not target.exists() or not target.is_dir():
        return [{"error": f"폴더를 찾을 수 없습니다: {folder}"}]

    files = []
    for item in sorted(target.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        if item.name.startswith("."):
            continue
        info = _file_info(item, root)
        info["is_dir"] = item.is_dir()
        files.append(info)
        if len(files) >= max_results:
            break

    logger.info(f"📂 로컬 폴더: {target} → {len(files)}개 항목")
    return files


@drive_server.tool("read_file", "로컬 파일 읽기")
async def read_file(file_path: str) -> dict[str, Any]:
    """로컬 파일 내용을 읽습니다.

    텍스트 파일은 내용을 반환하고, PDF/DOCX는 텍스트 추출,
    바이너리 파일은 메타데이터만 반환합니다.

    Args:
        file_path: 파일 경로 (루트 기준 상대 경로)

    Returns:
        파일 정보 + content (텍스트 내용)
    """
    root = _get_root()
    if not root:
        return {"error": "LOCAL_DRIVE_PATH가 .env에 설정되지 않았습니다"}

    filepath = root / file_path
    # 보안: 루트 디렉토리 바깥 접근 방지
    try:
        filepath.resolve().relative_to(root.resolve())
    except ValueError:
        return {"error": "접근 권한 없음 — 루트 폴더 바깥의 파일입니다"}

    if not filepath.exists():
        return {"error": f"파일을 찾을 수 없습니다: {file_path}"}

    if filepath.is_dir():
        return {"error": f"디렉토리입니다. list_files를 사용하세요: {file_path}"}

    info = _file_info(filepath, root)
    suffix = filepath.suffix.lower()

    # 텍스트 파일
    if suffix in TEXT_EXTENSIONS:
        content = _read_text_file(filepath)
        # 너무 큰 파일은 잘라서 반환
        if len(content) > 50000:
            content = content[:50000] + f"\n\n... [잘림: 전체 {len(content)} 글자 중 50,000자만 표시]"
        info["content"] = content
        info["type"] = "text"
        logger.info(f"📄 텍스트 파일 읽기: {filepath.name} ({len(content)} chars)")
        return info

    # PDF
    if suffix == ".pdf":
        info["content"] = _read_pdf(filepath)
        info["type"] = "pdf"
        logger.info(f"📄 PDF 읽기: {filepath.name}")
        return info

    # DOCX
    if suffix == ".docx":
        info["content"] = _read_docx(filepath)
        info["type"] = "docx"
        logger.info(f"📄 DOCX 읽기: {filepath.name}")
        return info

    # 바이너리
    info["content"] = f"[바이너리 파일 — {info['mime_type']}, 크기: {info['size']} bytes]"
    info["type"] = "binary"
    logger.info(f"📄 바이너리 파일 (메타데이터만): {filepath.name}")
    return info


@drive_server.tool("search_files", "로컬 파일 검색")
async def search_files(
    query: str, max_results: int = 10, include_content: bool = False
) -> list[dict[str, Any]]:
    """로컬 폴더에서 파일 이름 또는 내용으로 검색합니다.

    Args:
        query: 검색 키워드
        max_results: 최대 결과 수
        include_content: True면 텍스트 파일 내용도 검색

    Returns:
        검색 결과 파일 목록
    """
    root = _get_root()
    if not root:
        return [{"error": "LOCAL_DRIVE_PATH가 .env에 설정되지 않았습니다"}]

    query_lower = query.lower()
    results = []

    for filepath in root.rglob("*"):
        if filepath.is_dir() or filepath.name.startswith("."):
            continue

        # 파일 이름 검색
        name_match = query_lower in filepath.name.lower()

        # 내용 검색 (텍스트 파일만)
        content_match = False
        matched_snippet = ""
        if include_content and filepath.suffix.lower() in TEXT_EXTENSIONS:
            try:
                text = _read_text_file(filepath)
                if query_lower in text.lower():
                    content_match = True
                    # 매칭 위치 주변 스니펫 추출
                    idx = text.lower().find(query_lower)
                    start = max(0, idx - 80)
                    end = min(len(text), idx + len(query) + 80)
                    matched_snippet = "..." + text[start:end] + "..."
            except Exception:
                pass

        if name_match or content_match:
            info = _file_info(filepath, root)
            info["match_type"] = "name" if name_match else "content"
            if matched_snippet:
                info["snippet"] = matched_snippet
            results.append(info)
            if len(results) >= max_results:
                break

    logger.info(f"🔍 검색 '{query}' → {len(results)}개 결과")
    return results


if __name__ == "__main__":
    from pathlib import Path as _Path
    try:
        from dotenv import load_dotenv
        _env_path = _Path(__file__).resolve().parents[4] / "agents" / "wsp" / ".env"
        load_dotenv(_env_path)
        import os as _os
        globals()["LOCAL_DRIVE_PATH"] = _os.getenv("LOCAL_DRIVE_PATH", "")
    except ImportError:
        pass
    logging.basicConfig(level=logging.INFO)
    drive_server.run()
