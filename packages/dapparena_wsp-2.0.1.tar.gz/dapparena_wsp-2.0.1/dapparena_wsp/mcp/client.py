"""MCP Client — 에이전트가 MCP Server에 Tool/Resource 요청을 보내는 클라이언트 (S2-01)

에이전트(철수, 영희, 만수)가 외부 데이터 소스에 접근할 때 사용합니다.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger("dapparena_wsp.mcp.client")


class MCPClient:
    """MCP Client — 에이전트용 외부 데이터 접근 클라이언트.

    Example:
        client = MCPClient("http://localhost:9001")
        tools = await client.list_tools()
        result = await client.call_tool("search_papers", {"query": "ZKP"})
    """

    def __init__(self, server_url: str, *, timeout: float = 60.0):
        """
        Args:
            server_url: MCP Server 주소 (예: "http://localhost:9001")
            timeout: 요청 타임아웃(초)
        """
        self.server_url = server_url.rstrip("/")
        self.timeout = timeout

    async def list_tools(self) -> list[dict[str, Any]]:
        """MCP 서버에 등록된 Tool 목록을 조회합니다.

        Returns:
            Tool 목록 (name, description, parameters)
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.get(f"{self.server_url}/mcp/tools")
            resp.raise_for_status()
            return resp.json().get("tools", [])

    async def call_tool(
        self, tool_name: str, arguments: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """MCP 서버의 Tool을 호출합니다.

        Args:
            tool_name: 호출할 Tool 이름
            arguments: Tool 인수 딕셔너리

        Returns:
            Tool 실행 결과
        """
        payload = {
            "tool": tool_name,
            "arguments": arguments or {},
        }
        logger.info(f"🔧 MCP Tool 호출: {tool_name} → {self.server_url}")

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                f"{self.server_url}/mcp/tools/call",
                json=payload,
            )
            resp.raise_for_status()
            result = resp.json()

        logger.info(f"🔧 MCP Tool 결과: {tool_name} → 성공")
        return result

    async def list_resources(self) -> list[dict[str, Any]]:
        """MCP 서버에 등록된 Resource 목록을 조회합니다."""
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.get(f"{self.server_url}/mcp/resources")
            resp.raise_for_status()
            return resp.json().get("resources", [])

    async def read_resource(self, uri: str) -> dict[str, Any]:
        """MCP 서버의 Resource를 읽습니다.

        Args:
            uri: 리소스 URI

        Returns:
            리소스 데이터
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.get(
                f"{self.server_url}/mcp/resources/read",
                params={"uri": uri},
            )
            resp.raise_for_status()
            return resp.json()

    async def health(self) -> dict[str, Any]:
        """MCP 서버 헬스체크."""
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.get(f"{self.server_url}/mcp/health")
            resp.raise_for_status()
            return resp.json()
