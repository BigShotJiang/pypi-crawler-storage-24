"""Trust Registry 모듈 — ERC-8004 공인 에이전트 등록 (Slice 3: S3-08)"""

from .registry import TrustRegistry

__all__ = ["TrustRegistry"]
