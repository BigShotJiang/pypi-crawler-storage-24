"""TrustRegistry — ERC-8004 공인 에이전트 등록·조회 (S3-08)

블록체인에 등록된 공인(Trusted) 에이전트를 조회하고,
새로운 에이전트를 공인 목록에 등록합니다.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger("dapparena_wsp.trust_registry.registry")


@dataclass
class TrustedAgent:
    """공인 에이전트 정보."""

    agent_id: int
    did_string: str
    trusted: bool
    registered_at: int = 0


class TrustRegistry:
    """ERC-8004 Trust Registry 클라이언트.

    Usage::

        reg = TrustRegistry(
            rpc_url="https://rpc.worldland.foundation",
            contract_address="0x...",
        )
        is_ok = await reg.is_trusted(agent_id=1)
        tx = reg.build_register_tx(agent_id=1, did_string="did:worldland:agent:cheolsu")
    """

    def __init__(
        self,
        rpc_url: str = "https://rpc.worldland.foundation",
        contract_address: str = "",
    ):
        self.rpc_url = rpc_url
        self.contract_address = contract_address
        self._client = httpx.AsyncClient(timeout=30.0)

    # ----------------------------------------------------------
    # 조회
    # ----------------------------------------------------------

    async def is_trusted(self, agent_id: int) -> bool:
        """에이전트가 공인 목록에 있는지 확인합니다.

        Args:
            agent_id: AgentNFT 토큰 ID

        Returns:
            공인 여부
        """
        if not self.contract_address:
            logger.warning("TrustRegistry 주소 미설정")
            return False

        try:
            selector = _function_selector("isTrusted(uint256)")
            agent_hex = hex(agent_id)[2:].zfill(64)
            data = "0x" + selector + agent_hex

            payload = {
                "jsonrpc": "2.0",
                "method": "eth_call",
                "params": [
                    {"to": self.contract_address, "data": data},
                    "latest",
                ],
                "id": 1,
            }
            resp = await self._client.post(self.rpc_url, json=payload)
            resp.raise_for_status()
            result = resp.json()

            if "error" in result:
                return False
            raw = result.get("result", "0x0")
            return raw != "0x" and int(raw, 16) != 0
        except Exception as e:
            logger.error(f"Trust 확인 실패: {e}")
            return False

    # ----------------------------------------------------------
    # 등록 TX 빌드
    # ----------------------------------------------------------

    def build_register_tx(
        self, agent_id: int, did_string: str
    ) -> dict[str, Any]:
        """공인 에이전트 등록 트랜잭션을 빌드합니다.

        registerAgent(uint256 agentId, string didString)

        Args:
            agent_id: AgentNFT 토큰 ID
            did_string: DID 문자열

        Returns:
            트랜잭션 딕셔너리
        """
        selector = _function_selector("registerAgent(uint256,string)")
        agent_hex = hex(agent_id)[2:].zfill(64)

        # string은 동적 타입: offset + encoded
        # uint256(32) + string_offset(32) = 64 → offset = 0x40
        string_offset = "0000000000000000000000000000000000000000000000000000000000000040"
        encoded_string = _encode_string(did_string)

        calldata = (
            "0x" + selector + agent_hex + string_offset + encoded_string
        )

        return {
            "to": self.contract_address,
            "data": calldata,
            "value": "0x0",
        }

    def build_revoke_tx(self, agent_id: int) -> dict[str, Any]:
        """공인 에이전트 등록 해제 트랜잭션을 빌드합니다.

        revokeAgent(uint256 agentId)
        """
        selector = _function_selector("revokeAgent(uint256)")
        agent_hex = hex(agent_id)[2:].zfill(64)

        return {
            "to": self.contract_address,
            "data": "0x" + selector + agent_hex,
            "value": "0x0",
        }

    async def close(self) -> None:
        """HTTP 클라이언트를 닫습니다."""
        await self._client.aclose()


# ─────────────────────────────────────────────
# 유틸리티
# ─────────────────────────────────────────────


def _function_selector(signature: str) -> str:
    """Solidity 함수 시그니처의 4바이트 셀렉터."""
    return hashlib.sha3_256(signature.encode()).hexdigest()[:8]


def _encode_string(s: str) -> str:
    """ABI 동적 string 인코딩 (length + padded data)."""
    s_bytes = s.encode("utf-8")
    length = len(s_bytes)
    length_hex = hex(length)[2:].zfill(64)
    padded_len = ((length + 31) // 32) * 32
    data_hex = s_bytes.hex().ljust(padded_len * 2, "0")
    return length_hex + data_hex
