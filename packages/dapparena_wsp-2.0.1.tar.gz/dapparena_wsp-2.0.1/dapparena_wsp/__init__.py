"""DappArena WSP SDK v2.0.0 — WorldLand Scholar Protocol

Slice 1: A2A v2, Orchestrator, BaseAgent
Slice 2: MCP, RAG, LLM Router, Security
Slice 3: Identity (DID), Wallet (ERC-6551), x402 Payment, Trust Registry
Slice 4: Memory System, ACP Resilience (SQLite persistence, exponential backoff)
Slice 5: Parallel Execution, Scheduling/CRON
Slice 6: Multi-Channel Messaging, Browser Automation
"""

__version__ = "2.0.0"
