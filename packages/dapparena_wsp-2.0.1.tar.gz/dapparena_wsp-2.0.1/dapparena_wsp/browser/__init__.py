"""dapparena_wsp.browser — 브라우저 자동화 MCP 서버 (Slice 6, FR-OC-06)

Playwright 기반 웹 자동화 도구를 MCP 서버로 제공합니다.
Optional dependency: pip install dapparena-wsp[browser]
"""

from .automation import BrowserTools

__all__ = ["BrowserTools"]
