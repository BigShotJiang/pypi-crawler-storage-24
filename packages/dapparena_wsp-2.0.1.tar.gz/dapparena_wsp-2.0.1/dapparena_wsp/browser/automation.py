"""BrowserTools — Playwright 기반 브라우저 자동화 (FR-OC-06.1, FR-OC-06.2)

웹페이지 탐색, 스크린샷, 폼 입력, 클릭 등 자동화 도구를 제공합니다.
에이전트가 LLM 판단에 따라 자율 브라우징 루프를 실행할 수 있습니다.

Optional dependency: pip install playwright
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("dapparena_wsp.browser.automation")


class BrowserTools:
    """Playwright 기반 브라우저 자동화 도구.

    MCP 서버로 에이전트에 노출되어 @mcp_tool로 호출 가능합니다.

    Example:
        browser = BrowserTools()
        await browser.start()
        text = await browser.navigate("https://arxiv.org/abs/2401.12345")
        screenshot = await browser.screenshot()
        await browser.stop()
    """

    def __init__(self, headless: bool = True):
        self.headless = headless
        self._browser = None
        self._page = None
        self._playwright = None

    async def start(self) -> None:
        """브라우저 인스턴스 시작."""
        try:
            from playwright.async_api import async_playwright
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(headless=self.headless)
            self._page = await self._browser.new_page()
            logger.info("🌐 브라우저 시작됨 (headless={})".format(self.headless))
        except ImportError:
            raise ImportError(
                "playwright가 설치되지 않았습니다. "
                "pip install playwright && playwright install chromium"
            )

    async def stop(self) -> None:
        """브라우저 종료."""
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        self._browser = None
        self._page = None
        logger.info("🌐 브라우저 종료됨")

    async def navigate(self, url: str) -> str:
        """URL로 이동하고 페이지 텍스트를 반환합니다.

        Args:
            url: 이동할 URL

        Returns:
            페이지 텍스트 콘텐츠
        """
        if not self._page:
            raise RuntimeError("브라우저가 시작되지 않았습니다. start()를 먼저 호출하세요.")

        await self._page.goto(url, wait_until="networkidle")
        text = await self._page.inner_text("body")
        logger.info(f"🌐 탐색: {url} ({len(text)}자)")
        return text

    async def screenshot(self, path: str = "screenshot.png") -> bytes:
        """현재 페이지 스크린샷.

        Returns:
            PNG 이미지 바이트
        """
        if not self._page:
            raise RuntimeError("브라우저가 시작되지 않았습니다.")
        data = await self._page.screenshot(path=path, full_page=True)
        logger.info(f"📸 스크린샷: {path}")
        return data

    async def click(self, selector: str) -> None:
        """요소 클릭."""
        if not self._page:
            raise RuntimeError("브라우저가 시작되지 않았습니다.")
        await self._page.click(selector)
        logger.debug(f"🖱️ 클릭: {selector}")

    async def fill(self, selector: str, value: str) -> None:
        """폼 입력."""
        if not self._page:
            raise RuntimeError("브라우저가 시작되지 않았습니다.")
        await self._page.fill(selector, value)
        logger.debug(f"⌨️ 입력: {selector} = {value[:50]}...")

    async def extract_text(self, selector: str = "body") -> str:
        """요소 텍스트 추출."""
        if not self._page:
            raise RuntimeError("브라우저가 시작되지 않았습니다.")
        return await self._page.inner_text(selector)

    async def get_links(self) -> list[dict[str, str]]:
        """현재 페이지의 링크 목록 추출."""
        if not self._page:
            return []
        links = await self._page.evaluate("""
            () => Array.from(document.querySelectorAll('a[href]'))
                .map(a => ({href: a.href, text: a.innerText.trim()}))
                .filter(a => a.href.startsWith('http'))
                .slice(0, 50)
        """)
        return links

    async def autonomous_browse(
        self,
        start_url: str,
        goal: str,
        max_steps: int = 5,
        llm_callback: Any = None,
    ) -> list[dict[str, Any]]:
        """자율 브라우징 루프 (FR-OC-06.2).

        LLM 판단에 따라 자동으로 다음 페이지를 탐색합니다.

        Args:
            start_url: 시작 URL
            goal: 브라우징 목표 (에이전트에게 전달)
            max_steps: 최대 탐색 단계
            llm_callback: LLM 호출 콜백 (text -> next_action)

        Returns:
            탐색 기록 리스트
        """
        history = []
        current_url = start_url

        for step in range(max_steps):
            text = await self.navigate(current_url)
            links = await self.get_links()

            entry = {
                "step": step + 1,
                "url": current_url,
                "text_length": len(text),
                "links_count": len(links),
            }
            history.append(entry)

            logger.info(f"🤖 자율 탐색 [{step+1}/{max_steps}]: {current_url}")

            if llm_callback:
                # LLM에게 현재 페이지 정보와 목표를 주고 다음 행동 결정
                next_action = await llm_callback(
                    goal=goal,
                    current_text=text[:2000],
                    available_links=links[:20],
                    step=step + 1,
                )
                if next_action.get("action") == "done":
                    entry["result"] = next_action.get("result", "")
                    break
                elif next_action.get("action") == "navigate":
                    current_url = next_action["url"]
                else:
                    break  # 알 수 없는 행동이면 중지
            else:
                break  # LLM 콜백이 없으면 1회 탐색 후 중지

        return history
