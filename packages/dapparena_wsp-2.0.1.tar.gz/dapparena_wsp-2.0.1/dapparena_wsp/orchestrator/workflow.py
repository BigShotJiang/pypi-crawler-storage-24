"""Workflow YAML 파서 — 워크플로 정의를 로드하고 파싱 (S1-06, S4 업데이트)

Slice 4 (FR-OC-03): parallel, merge_strategy, supervisor 필드 추가.

YAML 형식 예시 (순차):
    name: textbook_pipeline
    steps:
      - agent: cheolsu
        url: http://localhost:8101
        role: researcher

YAML 형식 예시 (병렬):
    name: parallel_research
    steps:
      - name: "병렬 연구"
        parallel: true
        merge_strategy: merge
        supervisor: mansu
        agents:
          - agent: cheolsu-a
            url: http://localhost:8101
            task: "Federated Learning 연구"
          - agent: cheolsu-b
            url: http://localhost:8111
            task: "LLM 최적화 연구"
      - agent: younghee
        url: http://localhost:8102
        role: editor
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class WorkflowStep:
    """워크플로의 개별 단계.

    Attributes:
        agent: 에이전트 이름 (순차 단계용)
        url: 에이전트 서버 URL
        role: 역할 설명
        timeout: 요청 타임아웃 (초)
        on_failure: 실패 시 동작 ("retry", "skip", "abort")
        max_retries: 재시도 횟수
        parallel: 병렬 실행 여부 (Slice 4)
        agents: 병렬 실행할 에이전트 목록 (Slice 4)
        merge_strategy: 병렬 결과 병합 전략 (Slice 4)
        supervisor: 결과 평가 에이전트 (Slice 4)
        name: 단계 이름
        task: 에이전트에게 전달할 특정 지시사항
    """
    agent: str = ""
    url: str = ""
    role: str = ""
    timeout: int = 120
    on_failure: str = "abort"
    max_retries: int = 1
    # Slice 4: 병렬 실행 지원
    parallel: bool = False
    agents: list[dict[str, Any]] = field(default_factory=list)
    merge_strategy: str = "merge"  # "merge" | "select_best" | "vote"
    supervisor: str = ""
    name: str = ""
    task: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> WorkflowStep:
        return cls(
            agent=d.get("agent", ""),
            url=d.get("url", ""),
            role=d.get("role", ""),
            timeout=d.get("timeout", 120),
            on_failure=d.get("on_failure", "abort"),
            max_retries=d.get("max_retries", 1),
            parallel=d.get("parallel", False),
            agents=d.get("agents", []),
            merge_strategy=d.get("merge_strategy", "merge"),
            supervisor=d.get("supervisor", ""),
            name=d.get("name", ""),
            task=d.get("task", ""),
        )

    @property
    def is_parallel(self) -> bool:
        return self.parallel and len(self.agents) > 0


@dataclass
class Workflow:
    """워크플로 전체 정의."""
    name: str
    description: str = ""
    steps: list[WorkflowStep] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


def load_workflow(path: str | Path) -> Workflow:
    """YAML 파일에서 Workflow를 로드합니다."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"워크플로 파일을 찾을 수 없습니다: {path}")

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict):
        raise ValueError(f"유효하지 않은 워크플로 형식: {path}")

    steps = [WorkflowStep.from_dict(s) for s in data.get("steps", [])]

    return Workflow(
        name=data.get("name", path.stem),
        description=data.get("description", ""),
        steps=steps,
        metadata=data.get("metadata", {}),
    )
