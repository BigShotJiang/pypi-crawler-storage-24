"""워크플로 실행 상태 관리 (S1-07, S4 업데이트: SQLite 영속 저장)

Slice 4 (FR-OC-02.1): 인메모리 → SQLite 영속 저장으로 업그레이드.
프로세스 재시작 후에도 미완료 워크플로를 복원할 수 있습니다.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.orchestrator.state")


class WorkflowStatus(str, Enum):
    """워크플로 실행 상태."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class StepResult:
    """개별 단계의 실행 결과."""
    agent: str
    status: str  # "completed", "failed", "skipped"
    duration_seconds: float = 0.0
    task_id: str = ""
    error: str = ""


@dataclass
class WorkflowState:
    """워크플로 전체 실행 상태.

    Attributes:
        workflow_id: 워크플로 실행 고유 ID
        workflow_name: 워크플로 이름
        status: 실행 상태
        current_step: 현재 실행 중인 단계 인덱스
        total_steps: 전체 단계 수
        step_results: 각 단계별 실행 결과
        started_at: 시작 시간 (epoch)
        completed_at: 완료 시간 (epoch)
        metadata: 추가 정보
    """
    workflow_id: str
    workflow_name: str = ""
    status: WorkflowStatus = WorkflowStatus.PENDING
    current_step: int = 0
    total_steps: int = 0
    step_results: list[StepResult] = field(default_factory=list)
    started_at: float = 0.0
    completed_at: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def elapsed_seconds(self) -> float:
        end = self.completed_at or time.time()
        return round(end - self.started_at, 2) if self.started_at else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "workflow_id": self.workflow_id,
            "workflow_name": self.workflow_name,
            "status": self.status.value,
            "current_step": self.current_step,
            "total_steps": self.total_steps,
            "elapsed_seconds": self.elapsed_seconds,
            "step_results": [
                {
                    "agent": sr.agent,
                    "status": sr.status,
                    "duration_seconds": sr.duration_seconds,
                    "task_id": sr.task_id,
                    "error": sr.error,
                }
                for sr in self.step_results
            ],
        }


# ── Slice 4: SQLite 영속 저장 백엔드 ──

_db_path: str = "workflow_state.db"
_in_memory_cache: dict[str, WorkflowState] = {}


def init_state_db(db_path: str = "workflow_state.db") -> None:
    """상태 DB 초기화. 앱 시작 시 한 번 호출."""
    global _db_path
    _db_path = db_path
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS workflow_runs (
                workflow_id   TEXT PRIMARY KEY,
                workflow_name TEXT NOT NULL DEFAULT '',
                status        TEXT NOT NULL DEFAULT 'pending',
                current_step  INTEGER DEFAULT 0,
                total_steps   INTEGER DEFAULT 0,
                step_results  TEXT DEFAULT '[]',
                started_at    REAL DEFAULT 0,
                completed_at  REAL DEFAULT 0,
                metadata      TEXT DEFAULT '{}',
                created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
    logger.info(f"💾 워크플로 상태 DB 초기화: {db_path}")


def save_state(state: WorkflowState) -> None:
    """워크플로 상태를 SQLite + 인메모리 캐시에 저장."""
    _in_memory_cache[state.workflow_id] = state

    step_results_json = json.dumps([
        {
            "agent": sr.agent,
            "status": sr.status,
            "duration_seconds": sr.duration_seconds,
            "task_id": sr.task_id,
            "error": sr.error,
        }
        for sr in state.step_results
    ], ensure_ascii=False)

    metadata_json = json.dumps(state.metadata, ensure_ascii=False)

    try:
        with sqlite3.connect(_db_path) as conn:
            conn.execute(
                """INSERT INTO workflow_runs
                   (workflow_id, workflow_name, status, current_step, total_steps,
                    step_results, started_at, completed_at, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(workflow_id) DO UPDATE SET
                    status=excluded.status,
                    current_step=excluded.current_step,
                    step_results=excluded.step_results,
                    completed_at=excluded.completed_at,
                    metadata=excluded.metadata,
                    updated_at=CURRENT_TIMESTAMP""",
                (
                    state.workflow_id,
                    state.workflow_name,
                    state.status.value,
                    state.current_step,
                    state.total_steps,
                    step_results_json,
                    state.started_at,
                    state.completed_at,
                    metadata_json,
                ),
            )
    except Exception as e:
        logger.warning(f"상태 DB 저장 실패 (인메모리 캐시는 유지): {e}")


def get_state(workflow_id: str) -> WorkflowState | None:
    """워크플로 상태 조회 (캐시 우선)."""
    if workflow_id in _in_memory_cache:
        return _in_memory_cache[workflow_id]

    # DB에서 로드
    try:
        with sqlite3.connect(_db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM workflow_runs WHERE workflow_id=?",
                (workflow_id,),
            ).fetchone()

        if not row:
            return None

        state = _row_to_state(row)
        _in_memory_cache[workflow_id] = state
        return state
    except Exception:
        return None


def list_states() -> list[WorkflowState]:
    """모든 워크플로 상태 목록 (DB에서 조회)."""
    try:
        with sqlite3.connect(_db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM workflow_runs ORDER BY created_at DESC"
            ).fetchall()
        return [_row_to_state(row) for row in rows]
    except Exception:
        return list(_in_memory_cache.values())


def get_incomplete_workflows() -> list[WorkflowState]:
    """미완료 워크플로 목록 (FR-OC-02.3: 재시작 복구용).

    Returns:
        status가 'running' 또는 'pending'인 워크플로 목록
    """
    try:
        with sqlite3.connect(_db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM workflow_runs WHERE status IN ('running', 'pending') ORDER BY started_at",
            ).fetchall()
        return [_row_to_state(row) for row in rows]
    except Exception as e:
        logger.warning(f"미완료 워크플로 조회 실패: {e}")
        return [s for s in _in_memory_cache.values()
                if s.status in (WorkflowStatus.RUNNING, WorkflowStatus.PENDING)]


def _row_to_state(row) -> WorkflowState:
    """DB Row → WorkflowState 변환."""
    step_results_raw = json.loads(row["step_results"] or "[]")
    step_results = [
        StepResult(
            agent=sr["agent"],
            status=sr["status"],
            duration_seconds=sr.get("duration_seconds", 0),
            task_id=sr.get("task_id", ""),
            error=sr.get("error", ""),
        )
        for sr in step_results_raw
    ]
    metadata = json.loads(row["metadata"] or "{}")

    return WorkflowState(
        workflow_id=row["workflow_id"],
        workflow_name=row["workflow_name"],
        status=WorkflowStatus(row["status"]),
        current_step=row["current_step"],
        total_steps=row["total_steps"],
        step_results=step_results,
        started_at=row["started_at"],
        completed_at=row["completed_at"],
        metadata=metadata,
    )
