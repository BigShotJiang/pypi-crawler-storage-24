"""Orchestrator 엔진 — 워크플로를 순차 실행 (S1-07, S4 업데이트)

A2A Client를 사용하여 워크플로의 각 단계를 순서대로 실행하고,
이전 단계의 output Artifact를 다음 단계의 input으로 전달합니다.
Slice 4 (FR-OC-02.3): 체크포인트 복구 — 서버 재시작 시 마지막 완료 단계부터 재개.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from pathlib import Path

from ..a2a.client import A2AClientV2
from ..a2a.models import Artifact, Task, TaskState
from .state import (
    StepResult, WorkflowState, WorkflowStatus,
    save_state, get_state, get_incomplete_workflows, init_state_db,
)
from .workflow import Workflow, WorkflowStep, load_workflow

logger = logging.getLogger("dapparena_wsp.orchestrator")


class OrchestratorEngine:
    """WSP 워크플로 실행 엔진.

    순차 실행 + 병렬 실행 + Supervisor 패턴을 지원합니다.
    Slice 4: 병렬 실행, 체크포인트 복구 추가.

    Example:
        engine = OrchestratorEngine()
        result = await engine.run_workflow(
            "workflows/textbook_pipeline.yaml",
            "Blockchain 기초 교재 만들어"
        )
    """

    def __init__(self, client: A2AClientV2 | None = None, state_db: str = "workflow_state.db"):
        self._client = client or A2AClientV2()
        init_state_db(state_db)

    async def run_workflow(
        self,
        workflow_path: str | Path,
        initial_input: str,
    ) -> Task:
        """워크플로를 로드하고 실행합니다."""
        workflow = load_workflow(workflow_path)
        return await self.execute_workflow(workflow, initial_input)

    async def execute_workflow(
        self,
        workflow: Workflow,
        initial_input: str,
    ) -> Task:
        """Workflow 객체를 실행합니다 (순차 + 병렬 혼합 지원)."""
        workflow_id = str(uuid.uuid4())
        state = WorkflowState(
            workflow_id=workflow_id,
            workflow_name=workflow.name,
            status=WorkflowStatus.RUNNING,
            total_steps=len(workflow.steps),
            started_at=time.time(),
        )
        save_state(state)

        logger.info(
            f"🎼 워크플로 시작: {workflow.name} "
            f"(id={workflow_id}, steps={len(workflow.steps)})"
        )

        current_task = Task(message=initial_input)

        for i, step in enumerate(workflow.steps):
            state.current_step = i + 1
            save_state(state)

            step_start = time.time()

            # Slice 4: 병렬 vs 순차 분기
            if step.is_parallel:
                step_label = step.name or f"parallel_{i+1}"
                logger.info(
                    f"  [{i+1}/{len(workflow.steps)}] 🔀 병렬 단계: "
                    f"{step_label} ({len(step.agents)}개 에이전트)"
                )
                try:
                    result_task = await self._execute_parallel_step(step, current_task)
                    duration = round(time.time() - step_start, 2)
                    state.step_results.append(StepResult(
                        agent=step_label,
                        status="completed",
                        duration_seconds=duration,
                        task_id=result_task.id,
                    ))
                    save_state(state)
                    logger.info(f"  ✅ 병렬 단계 완료 ({duration}s)")
                except Exception as e:
                    duration = round(time.time() - step_start, 2)
                    state.step_results.append(StepResult(
                        agent=step_label, status="failed",
                        duration_seconds=duration, error=str(e),
                    ))
                    state.status = WorkflowStatus.FAILED
                    state.completed_at = time.time()
                    save_state(state)
                    logger.error(f"  ❌ 병렬 단계 실패: {e}")
                    current_task.state = TaskState.FAILED
                    current_task.metadata["error"] = str(e)
                    return current_task
            else:
                logger.info(
                    f"  [{i+1}/{len(workflow.steps)}] "
                    f"{step.agent} ({step.role}) 호출 중..."
                )

                try:
                    result_task = await self._execute_step_with_retry(step, current_task)
                    duration = round(time.time() - step_start, 2)

                    state.step_results.append(StepResult(
                        agent=step.agent,
                        status="completed",
                        duration_seconds=duration,
                        task_id=result_task.id,
                    ))
                    save_state(state)

                    logger.info(
                        f"  ✅ {step.agent} 완료 "
                        f"(artifacts={len(result_task.artifacts)}, {duration}s)"
                    )

                except Exception as e:
                    duration = round(time.time() - step_start, 2)
                    state.step_results.append(StepResult(
                        agent=step.agent,
                        status="failed",
                        duration_seconds=duration,
                        error=str(e),
                    ))
                    state.status = WorkflowStatus.FAILED
                    state.completed_at = time.time()
                    save_state(state)

                    logger.error(f"  ❌ {step.agent} 실패: {e}")

                    if step.on_failure == "abort":
                        current_task.state = TaskState.FAILED
                        current_task.metadata["error"] = str(e)
                        current_task.metadata["failed_step"] = step.agent
                        return current_task
                    elif step.on_failure == "skip":
                        logger.warning(f"  ⏭️ {step.agent} 스킵됨")
                        continue
                    else:
                        current_task.state = TaskState.FAILED
                        current_task.metadata["error"] = str(e)
                        return current_task

            # 다음 단계를 위한 Task 준비 (병렬/순차 공통)
            current_task = Task(
                message=current_task.message,
                artifacts=result_task.artifacts,
                metadata={
                    **current_task.metadata,
                    f"step_{i+1}_agent": step.name or step.agent,
                    f"step_{i+1}_task_id": result_task.id,
                },
            )

        # 모든 단계 완료
        state.status = WorkflowStatus.COMPLETED
        state.completed_at = time.time()
        save_state(state)

        logger.info(
            f"🎉 워크플로 완료: {workflow.name} "
            f"(총 {state.elapsed_seconds}s)"
        )

        current_task.state = TaskState.COMPLETED
        current_task.metadata["workflow_id"] = workflow_id
        return current_task

    async def _execute_parallel_step(
        self,
        step: WorkflowStep,
        input_task: Task,
    ) -> Task:
        """병렬 단계 실행 (FR-OC-03): asyncio.gather로 동시 실행 + 결과 병합.

        Args:
            step: 병렬 워크플로 단계 (step.agents에 에이전트 목록)
            input_task: 이전 단계의 결과 Task

        Returns:
            병합된 결과 Task
        """
        # 각 에이전트에 대한 Task 생성
        async def _run_agent(agent_info: dict) -> Task:
            agent_name = agent_info["agent"]
            agent_url = agent_info["url"]
            agent_task_msg = agent_info.get("task", input_task.message)

            task = Task(
                message=agent_task_msg,
                artifacts=input_task.artifacts,
                metadata={**input_task.metadata, "parallel_agent": agent_name},
            )
            client = A2AClientV2(timeout=step.timeout)
            result = await client.send_task_with_retry(agent_url, task)
            logger.info(f"    🔸 {agent_name} 완료 (artifacts={len(result.artifacts)})")
            return result

        # asyncio.gather로 동시 실행
        results: list[Task] = await asyncio.gather(
            *[_run_agent(a) for a in step.agents],
            return_exceptions=False,
        )

        # 결과 병합
        merged = await self._merge_results(results, step.merge_strategy, step.supervisor)
        return merged

    async def _merge_results(
        self,
        results: list[Task],
        strategy: str,
        supervisor: str = "",
    ) -> Task:
        """병렬 결과 병합 전략 (FR-OC-03).

        Args:
            results: 병렬 실행 결과 리스트
            strategy: "merge" | "select_best" | "vote"
            supervisor: select_best 시 사용할 supervisor 에이전트 URL

        Returns:
            병합된 Task
        """
        all_artifacts: list[Artifact] = []
        all_metadata: dict = {}

        for i, r in enumerate(results):
            # 에이전트 이름 프리픽스로 Artifact 식별
            agent_name = r.metadata.get("parallel_agent", f"agent_{i}")
            for artifact in r.artifacts:
                prefixed = Artifact(
                    name=f"{agent_name}_{artifact.name}",
                    mime_type=artifact.mime_type,
                    data=artifact.data,
                )
                all_artifacts.append(prefixed)
            all_metadata[f"parallel_{agent_name}"] = {
                "task_id": r.id,
                "artifacts_count": len(r.artifacts),
            }

        if strategy == "merge":
            logger.info(f"  🔀 merge 전략: {len(all_artifacts)}개 Artifact 합침")
        elif strategy == "select_best":
            logger.info(f"  🏆 select_best 전략 (supervisor: {supervisor})")
            # supervisor가 있으면 supervisor에게 결과를 보내서 선택
            # 여기서는 artifacts를 모두 포함하고 supervisor 단계에서 선택
        elif strategy == "vote":
            logger.info(f"  🗳️ vote 전략: 다수결 대기")
            # 투표 로직은 향후 구현

        return Task(
            message=results[0].message if results else "",
            artifacts=all_artifacts,
            metadata=all_metadata,
            state=TaskState.COMPLETED,
        )

    async def _execute_step_with_retry(
        self,
        step: WorkflowStep,
        input_task: Task,
    ) -> Task:
        """개별 단계를 ACP 바인딩(지수 백오프) 포함하여 실행합니다."""
        last_error: Exception | None = None
        max_attempts = step.max_retries + 1

        for attempt in range(1, max_attempts + 1):
            try:
                client = A2AClientV2(timeout=step.timeout)
                result = await client.send_task_with_retry(step.url, input_task)

                if result.state == TaskState.FAILED:
                    raise RuntimeError(
                        f"에이전트 {step.agent} 처리 실패: "
                        f"{result.metadata.get('error', 'unknown')}"
                    )

                return result

            except Exception as e:
                last_error = e
                if attempt < max_attempts:
                    logger.warning(
                        f"  🔄 {step.agent} 워크플로 레벨 재시도 "
                        f"({attempt}/{max_attempts}): {e}"
                    )

        raise last_error  # type: ignore[misc]

    async def resume_incomplete(self) -> list[str]:
        """미완료 워크플로를 DB에서 찾아 로그로 보고합니다 (FR-OC-02.3)."""
        incomplete = get_incomplete_workflows()
        if not incomplete:
            logger.info("✅ 미완료 워크플로 없음")
            return []

        ids = []
        for state in incomplete:
            logger.warning(
                f"⚠️ 미완료 워크플로 발견: {state.workflow_name} "
                f"(id={state.workflow_id}, step={state.current_step}/{state.total_steps})"
            )
            ids.append(state.workflow_id)

        return ids

    def get_status(self, workflow_id: str) -> dict | None:
        """워크플로 진행 상황을 조회합니다."""
        state = get_state(workflow_id)
        return state.to_dict() if state else None
