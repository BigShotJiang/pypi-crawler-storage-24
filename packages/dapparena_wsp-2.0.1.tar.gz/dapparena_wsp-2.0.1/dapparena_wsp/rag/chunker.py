"""문서 청크 분할기 (S2-06)

긴 문서를 벡터 검색에 적합한 크기의 청크로 분할합니다.
Markdown 구조를 인식하여 헤딩 경계를 유지합니다.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger("dapparena_wsp.rag.chunker")


@dataclass
class Chunk:
    """문서 청크."""
    text: str
    index: int  # 청크 순서
    metadata: dict[str, Any]


class Chunker:
    """Markdown-aware 문서 청크 분할기.

    Example:
        chunker = Chunker(max_tokens=512, overlap=128)
        chunks = chunker.split(long_document)
    """

    def __init__(
        self,
        max_tokens: int = 512,
        overlap: int = 128,
        separator: str = "\n\n",
    ):
        """
        Args:
            max_tokens: 청크 최대 토큰 수 (근사: 단어 기준)
            overlap: 인접 청크 간 겹치는 토큰 수
            separator: 기본 분할 구분자
        """
        self.max_tokens = max_tokens
        self.overlap = overlap
        self.separator = separator

    def split(
        self,
        text: str,
        metadata: dict[str, Any] | None = None,
    ) -> list[Chunk]:
        """텍스트를 청크로 분할합니다.

        Args:
            text: 분할할 텍스트
            metadata: 모든 청크에 첨부할 메타데이터

        Returns:
            Chunk 리스트
        """
        base_meta = metadata or {}

        # 1단계: Markdown 헤딩으로 섹션 분할
        sections = self._split_by_headings(text)

        # 2단계: 각 섹션을 토큰 제한에 맞게 분할
        chunks: list[Chunk] = []
        chunk_index = 0

        for section_title, section_text in sections:
            section_chunks = self._split_by_tokens(section_text)

            for chunk_text in section_chunks:
                if chunk_text.strip():
                    chunks.append(Chunk(
                        text=chunk_text.strip(),
                        index=chunk_index,
                        metadata={
                            **base_meta,
                            "section": section_title,
                            "chunk_index": chunk_index,
                        },
                    ))
                    chunk_index += 1

        logger.info(f"📄 문서 분할: {len(chunks)}개 청크 (max_tokens={self.max_tokens})")
        return chunks

    def _split_by_headings(self, text: str) -> list[tuple[str, str]]:
        """Markdown 헤딩으로 섹션을 분할합니다."""
        heading_pattern = re.compile(r"^(#{1,4})\s+(.+)$", re.MULTILINE)
        matches = list(heading_pattern.finditer(text))

        if not matches:
            return [("", text)]

        sections = []

        # 첫 번째 헤딩 이전 텍스트
        if matches[0].start() > 0:
            preamble = text[:matches[0].start()].strip()
            if preamble:
                sections.append(("서문", preamble))

        # 각 헤딩 섹션
        for i, match in enumerate(matches):
            title = match.group(2).strip()
            start = match.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            section_text = text[start:end].strip()
            if section_text:
                sections.append((title, section_text))

        return sections

    def _split_by_tokens(self, text: str) -> list[str]:
        """텍스트를 토큰 제한에 맞게 분할합니다."""
        words = text.split()

        if len(words) <= self.max_tokens:
            return [text]

        chunks = []
        start = 0

        while start < len(words):
            end = min(start + self.max_tokens, len(words))
            chunk = " ".join(words[start:end])
            chunks.append(chunk)

            # 마지막 청크면 종료
            if end >= len(words):
                break

            # overlap 적용
            next_start = end - self.overlap
            # 무한 루프 방지: start가 전진하지 않으면 강제 전진
            if next_start <= start:
                next_start = start + max(1, self.max_tokens - self.overlap)
            start = next_start

        return chunks

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """토큰 수를 추정합니다 (단어 기준 근사).

        한국어: 대략 글자 수 / 2
        영어: 대략 단어 수 * 1.3
        """
        words = text.split()
        # 한국어 비중 추정
        korean_chars = sum(1 for c in text if "\uac00" <= c <= "\ud7a3")
        total_chars = len(text.replace(" ", ""))

        if total_chars > 0 and korean_chars / total_chars > 0.3:
            return int(korean_chars / 1.5 + len(words) * 0.5)
        return int(len(words) * 1.3)

    def reconstruct(self, chunks: list[Chunk]) -> str:
        """청크를 원본 텍스트로 재조합합니다 (오버랩 제거)."""
        if not chunks:
            return ""

        sorted_chunks = sorted(chunks, key=lambda c: c.index)

        # 단순 연결 (완전 복원은 어렵지만 근사)
        return "\n\n".join(c.text for c in sorted_chunks)
