"""EmailAdapter — SMTP 이메일 어댑터 (FR-OC-05)"""

from __future__ import annotations
import logging
from typing import Any
from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.email")


class EmailAdapter(ChannelAdapter):
    """SMTP 이메일 발신 어댑터."""

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__("email", config)
        self.smtp_host = (config or {}).get("smtp_host", "smtp.gmail.com")
        self.smtp_port = (config or {}).get("smtp_port", 587)
        self.username = (config or {}).get("username", "")
        self.password = (config or {}).get("password", "")
        self.from_addr = (config or {}).get("from_addr", self.username)

    async def connect(self) -> None:
        self._connected = bool(self.username)
        if self._connected:
            logger.info("📧 Email 어댑터 연결됨")

    async def disconnect(self) -> None:
        self._connected = False

    async def receive(self) -> IncomingMessage:
        return IncomingMessage(channel="email", channel_id="", sender_id="")

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """이메일 발신. channel_id = 수신자 이메일 주소."""
        import smtplib
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from email.mime.application import MIMEApplication

        try:
            msg = MIMEMultipart()
            msg["From"] = self.from_addr
            msg["To"] = channel_id
            msg["Subject"] = message.metadata.get("subject", "🤖 WSP Agent 보고서")

            if message.format == "html":
                msg.attach(MIMEText(message.content, "html"))
            else:
                msg.attach(MIMEText(message.content, "plain"))

            for att in message.attachments:
                part = MIMEApplication(att["data"], Name=att["name"])
                part["Content-Disposition"] = f'attachment; filename="{att["name"]}"'
                msg.attach(part)

            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)

            logger.info(f"📧 이메일 전송: {channel_id}")
        except Exception as e:
            logger.error(f"이메일 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="html")
