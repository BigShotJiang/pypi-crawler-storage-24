"""MessageBus — 통합 메시지 큐 (FR-OC-05.4)

모든 채널의 메시지를 통합 큐에서 처리하여,
채널과 무관하게 동일한 에이전트 로직을 실행합니다.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.bus")


class MessageBus:
    """통합 메시지 버스.

    여러 채널 어댑터를 등록하고, 모든 채널의 메시지를 단일 큐로 통합합니다.

    Example:
        bus = MessageBus()
        bus.register(TelegramAdapter(token="..."))
        bus.register(DiscordAdapter(token="..."))

        # 모든 채널로 메시지 브로드캐스트
        await bus.broadcast("연구 결과 보고서입니다.", channels=["telegram:@user", "slack:#lab"])
    """

    def __init__(self):
        self._adapters: dict[str, ChannelAdapter] = {}
        self._queue: asyncio.Queue[IncomingMessage] = asyncio.Queue()

    def register(self, adapter: ChannelAdapter) -> None:
        """채널 어댑터 등록."""
        self._adapters[adapter.name] = adapter
        logger.info(f"📡 채널 등록: {adapter.name}")

    def unregister(self, name: str) -> None:
        """채널 어댑터 해제."""
        self._adapters.pop(name, None)

    def get_adapter(self, name: str) -> ChannelAdapter | None:
        """채널 어댑터 조회."""
        return self._adapters.get(name)

    async def connect_all(self) -> None:
        """모든 어댑터 연결."""
        for adapter in self._adapters.values():
            await adapter.connect()

    async def disconnect_all(self) -> None:
        """모든 어댑터 연결 해제."""
        for adapter in self._adapters.values():
            await adapter.disconnect()

    async def send(self, channel_spec: str, message: OutgoingMessage) -> None:
        """특정 채널로 메시지 발신.

        Args:
            channel_spec: "채널이름:채널ID" (예: "telegram:@user", "slack:#lab")
            message: 발신할 메시지
        """
        parts = channel_spec.split(":", 1)
        if len(parts) != 2:
            logger.error(f"잘못된 채널 형식: {channel_spec} (형식: channel_name:channel_id)")
            return

        adapter_name, channel_id = parts
        adapter = self._adapters.get(adapter_name)
        if not adapter:
            logger.warning(f"등록되지 않은 채널: {adapter_name}")
            return

        await adapter.send(channel_id, message)

    async def broadcast(
        self,
        text: str,
        channels: list[str],
        attachments: list[dict] | None = None,
    ) -> dict[str, str]:
        """여러 채널로 동시 발신.

        Args:
            text: 메시지 내용
            channels: 채널 목록 (예: ["telegram:@user", "slack:#lab", "email:kim@univ.ac.kr"])
            attachments: 첨부 파일

        Returns:
            {channel: "sent" | "error"} 결과
        """
        results: dict[str, str] = {}

        async def _send_one(ch: str) -> None:
            try:
                parts = ch.split(":", 1)
                adapter_name = parts[0]
                adapter = self._adapters.get(adapter_name)
                if adapter:
                    msg = adapter.format_result(text, attachments)
                    await self.send(ch, msg)
                    results[ch] = "sent"
                else:
                    results[ch] = f"adapter_not_found:{adapter_name}"
            except Exception as e:
                results[ch] = f"error:{e}"

        await asyncio.gather(*[_send_one(ch) for ch in channels])
        logger.info(f"📡 브로드캐스트 완료: {len(channels)}개 채널 → {results}")
        return results

    @property
    def registered_channels(self) -> list[str]:
        return list(self._adapters.keys())
