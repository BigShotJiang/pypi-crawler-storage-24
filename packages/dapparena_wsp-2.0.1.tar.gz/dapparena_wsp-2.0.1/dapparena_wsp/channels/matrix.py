"""MatrixAdapter — Matrix 프로토콜 어댑터 (FR-OC-05.10)

Matrix Client-Server API를 사용하여 메시지를 수신/발신합니다.
환경변수: MATRIX_HOMESERVER, MATRIX_ACCESS_TOKEN, MATRIX_USER_ID
"""

from __future__ import annotations

import logging
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.matrix")


class MatrixAdapter(ChannelAdapter):
    """Matrix 프로토콜 어댑터.

    Matrix Client-Server API (/_matrix/client/) 기반.

    Args:
        homeserver: Matrix 홈서버 URL (예: https://matrix.org)
        access_token: Matrix 액세스 토큰
        user_id: Bot 사용자 ID (예: @bot:matrix.org)
        config: 추가 설정
    """

    def __init__(
        self,
        homeserver: str = "",
        access_token: str = "",
        user_id: str = "",
        config: dict[str, Any] | None = None,
    ):
        super().__init__("matrix", config)
        cfg = config or {}
        self.homeserver = (homeserver or cfg.get("homeserver", "https://matrix.org")).rstrip("/")
        self.access_token = access_token or cfg.get("access_token", "")
        self.user_id = user_id or cfg.get("user_id", "")
        self._since: str = ""  # sync 토큰 (페이지네이션)

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.access_token}"}

    async def connect(self) -> None:
        if not self.access_token:
            logger.warning("⚠️ Matrix access_token 미설정")
            return
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    f"{self.homeserver}/_matrix/client/v3/account/whoami",
                    headers=self._headers,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    self.user_id = data.get("user_id", self.user_id)
                    self._connected = True
                    logger.info(f"📱 Matrix 어댑터 연결됨: {self.user_id} @ {self.homeserver}")
                else:
                    logger.warning(f"⚠️ Matrix 인증 실패: {resp.status_code}")
        except Exception as e:
            logger.error(f"Matrix 연결 실패: {e}")

    async def disconnect(self) -> None:
        self._connected = False
        logger.info("📱 Matrix 어댑터 연결 해제")

    async def receive(self) -> IncomingMessage:
        """Matrix /sync API로 메시지 수신."""
        try:
            import httpx
            params: dict[str, Any] = {"timeout": 10000}
            if self._since:
                params["since"] = self._since

            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.get(
                    f"{self.homeserver}/_matrix/client/v3/sync",
                    headers=self._headers,
                    params=params,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    self._since = data.get("next_batch", self._since)

                    # 조인된 방에서 메시지 탐색
                    rooms = data.get("rooms", {}).get("join", {})
                    for room_id, room_data in rooms.items():
                        timeline = room_data.get("timeline", {}).get("events", [])
                        for event in timeline:
                            if (
                                event.get("type") == "m.room.message"
                                and event.get("sender") != self.user_id
                            ):
                                content = event.get("content", {})
                                return IncomingMessage(
                                    channel="matrix",
                                    channel_id=room_id,
                                    sender_id=event.get("sender", ""),
                                    sender_name=event.get("sender", ""),
                                    content=content.get("body", ""),
                                    metadata={
                                        "event_id": event.get("event_id", ""),
                                        "msgtype": content.get("msgtype", ""),
                                    },
                                    raw=event,
                                )
        except Exception as e:
            logger.error(f"Matrix 수신 실패: {e}")
        return IncomingMessage(channel="matrix", channel_id="", sender_id="")

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """Matrix 방으로 메시지 발신."""
        try:
            import httpx
            import time

            txn_id = str(int(time.time() * 1000))

            # 포맷에 따라 msgtype 결정
            if message.format == "html":
                content = {
                    "msgtype": "m.text",
                    "body": message.content,
                    "format": "org.matrix.custom.html",
                    "formatted_body": message.content,
                }
            else:
                content = {"msgtype": "m.text", "body": message.content}

            async with httpx.AsyncClient() as client:
                await client.put(
                    f"{self.homeserver}/_matrix/client/v3/rooms/{channel_id}/send/m.room.message/{txn_id}",
                    headers=self._headers,
                    json=content,
                )
            logger.info(f"📱 Matrix 메시지 전송: room={channel_id[:20]}...")
        except Exception as e:
            logger.error(f"Matrix 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="text")
