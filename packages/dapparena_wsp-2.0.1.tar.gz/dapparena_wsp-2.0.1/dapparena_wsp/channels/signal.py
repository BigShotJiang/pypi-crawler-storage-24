"""SignalAdapter — Signal Messenger 어댑터 (FR-OC-05.7)

signal-cli REST API를 사용하여 Signal 메시지를 수신/발신합니다.
환경변수: SIGNAL_CLI_API_URL, SIGNAL_PHONE_NUMBER
"""

from __future__ import annotations

import logging
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.signal")


class SignalAdapter(ChannelAdapter):
    """Signal Messenger 어댑터.

    signal-cli-rest-api (https://github.com/bbernhard/signal-cli-rest-api) 기반.

    Args:
        api_url: signal-cli REST API URL (기본: http://localhost:8080)
        phone_number: 등록된 Signal 전화번호
        config: 추가 설정
    """

    def __init__(
        self,
        api_url: str = "",
        phone_number: str = "",
        config: dict[str, Any] | None = None,
    ):
        super().__init__("signal", config)
        cfg = config or {}
        self.api_url = (api_url or cfg.get("api_url", "http://localhost:8080")).rstrip("/")
        self.phone_number = phone_number or cfg.get("phone_number", "")

    async def connect(self) -> None:
        if not self.phone_number:
            logger.warning("⚠️ Signal phone_number 미설정")
            return
        # 연결 확인
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self.api_url}/v1/about")
                if resp.status_code == 200:
                    self._connected = True
                    logger.info(f"📱 Signal 어댑터 연결됨 (API: {self.api_url})")
                else:
                    logger.warning(f"⚠️ Signal API 응답 이상: {resp.status_code}")
        except Exception as e:
            logger.error(f"Signal 연결 실패: {e}")

    async def disconnect(self) -> None:
        self._connected = False
        logger.info("📱 Signal 어댑터 연결 해제")

    async def receive(self) -> IncomingMessage:
        """Signal 메시지 수신 (polling 기반)."""
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self.api_url}/v1/receive/{self.phone_number}")
                if resp.status_code == 200:
                    messages = resp.json()
                    for msg in messages:
                        envelope = msg.get("envelope", {})
                        data_msg = envelope.get("dataMessage", {})
                        if data_msg.get("message"):
                            return IncomingMessage(
                                channel="signal",
                                channel_id=envelope.get("source", ""),
                                sender_id=envelope.get("source", ""),
                                sender_name=envelope.get("sourceName", ""),
                                content=data_msg.get("message", ""),
                                metadata={"timestamp": envelope.get("timestamp", 0)},
                                raw=msg,
                            )
        except Exception as e:
            logger.error(f"Signal 수신 실패: {e}")
        return IncomingMessage(channel="signal", channel_id="", sender_id="")

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """Signal로 메시지 발신."""
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{self.api_url}/v2/send",
                    json={
                        "message": message.content,
                        "number": self.phone_number,
                        "recipients": [channel_id],
                    },
                )
            logger.info(f"📱 Signal 메시지 전송: to={channel_id}")
        except Exception as e:
            logger.error(f"Signal 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="text")
