"""DiscordAdapter — Discord Bot 어댑터 (FR-OC-05.3)"""

from __future__ import annotations

import logging
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.discord")


class DiscordAdapter(ChannelAdapter):
    """Discord Bot 어댑터.

    Args:
        bot_token: Discord Bot 토큰
        config: 추가 설정
    """

    def __init__(self, bot_token: str = "", config: dict[str, Any] | None = None):
        super().__init__("discord", config)
        self.bot_token = bot_token or (config or {}).get("bot_token", "")
        self._base_url = "https://discord.com/api/v10"

    async def connect(self) -> None:
        if not self.bot_token:
            logger.warning("⚠️ Discord bot_token이 설정되지 않았습니다")
            return
        self._connected = True
        logger.info("💬 Discord 어댑터 연결됨")

    async def disconnect(self) -> None:
        self._connected = False

    async def receive(self) -> IncomingMessage:
        return IncomingMessage(channel="discord", channel_id="", sender_id="")

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """Discord 채널에 임베드 메시지 발신."""
        try:
            import httpx
            headers = {"Authorization": f"Bot {self.bot_token}", "Content-Type": "application/json"}
            # 임베드 형식으로 발신
            embed = {
                "title": "🤖 WSP Agent 결과",
                "description": message.content[:4096],
                "color": 0x6366f1,  # indigo
            }
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{self._base_url}/channels/{channel_id}/messages",
                    json={"embeds": [embed]},
                    headers=headers,
                )
            logger.info(f"💬 Discord 메시지 전송: channel={channel_id}")
        except Exception as e:
            logger.error(f"Discord 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="embed")
