"""WhatsAppAdapter — WhatsApp Cloud API 어댑터 (FR-OC-05.6)

Meta Cloud API를 사용하여 WhatsApp Business 메시지를 수신/발신합니다.
환경변수: WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_VERIFY_TOKEN
"""

from __future__ import annotations

import logging
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.whatsapp")


class WhatsAppAdapter(ChannelAdapter):
    """WhatsApp Cloud API 어댑터.

    Args:
        access_token: Meta Cloud API 액세스 토큰
        phone_number_id: WhatsApp Business 전화번호 ID
        verify_token: Webhook 검증 토큰
        config: 추가 설정
    """

    API_BASE = "https://graph.facebook.com/v19.0"

    def __init__(
        self,
        access_token: str = "",
        phone_number_id: str = "",
        verify_token: str = "",
        config: dict[str, Any] | None = None,
    ):
        super().__init__("whatsapp", config)
        cfg = config or {}
        self.access_token = access_token or cfg.get("access_token", "")
        self.phone_number_id = phone_number_id or cfg.get("phone_number_id", "")
        self.verify_token = verify_token or cfg.get("verify_token", "")

    @property
    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
        }

    async def connect(self) -> None:
        if not self.access_token or not self.phone_number_id:
            logger.warning("⚠️ WhatsApp access_token 또는 phone_number_id 미설정")
            return
        self._connected = True
        logger.info("📱 WhatsApp 어댑터 연결됨")

    async def disconnect(self) -> None:
        self._connected = False
        logger.info("📱 WhatsApp 어댑터 연결 해제")

    async def receive(self) -> IncomingMessage:
        """WhatsApp webhook으로 메시지 수신 (FastAPI 라우터에서 호출)."""
        return IncomingMessage(channel="whatsapp", channel_id="", sender_id="")

    def parse_webhook(self, payload: dict[str, Any]) -> IncomingMessage | None:
        """Webhook payload를 IncomingMessage로 파싱."""
        try:
            entry = payload.get("entry", [{}])[0]
            changes = entry.get("changes", [{}])[0]
            value = changes.get("value", {})
            messages = value.get("messages", [])
            if not messages:
                return None

            msg = messages[0]
            contact = value.get("contacts", [{}])[0]

            return IncomingMessage(
                channel="whatsapp",
                channel_id=msg.get("from", ""),
                sender_id=msg.get("from", ""),
                sender_name=contact.get("profile", {}).get("name", ""),
                content=msg.get("text", {}).get("body", ""),
                metadata={"message_id": msg.get("id", ""), "timestamp": msg.get("timestamp", "")},
                raw=payload,
            )
        except (IndexError, KeyError) as e:
            logger.error(f"WhatsApp webhook 파싱 실패: {e}")
            return None

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """WhatsApp으로 메시지 발신."""
        try:
            import httpx
            url = f"{self.API_BASE}/{self.phone_number_id}/messages"

            # 텍스트 메시지 전송
            async with httpx.AsyncClient() as client:
                await client.post(
                    url,
                    headers=self._headers,
                    json={
                        "messaging_product": "whatsapp",
                        "to": channel_id,
                        "type": "text",
                        "text": {"body": message.content},
                    },
                )

                # 첨부 파일 전송 (문서)
                for att in message.attachments:
                    mime = att.get("mime_type", "application/octet-stream")
                    if mime.startswith("application/pdf"):
                        await client.post(
                            url,
                            headers=self._headers,
                            json={
                                "messaging_product": "whatsapp",
                                "to": channel_id,
                                "type": "document",
                                "document": {
                                    "link": att.get("url", ""),
                                    "caption": att.get("name", "document"),
                                },
                            },
                        )

            logger.info(f"📱 WhatsApp 메시지 전송: to={channel_id}")
        except Exception as e:
            logger.error(f"WhatsApp 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        # WhatsApp은 Markdown 일부 지원 (*bold*, _italic_)
        return OutgoingMessage(content=text, attachments=attachments or [], format="text")
