"""ChannelAdapter — 멀티채널 추상 인터페이스 (FR-OC-05.1)

모든 플랫폼별 어댑터가 동일한 인터페이스로 메시지를 수신/발신합니다.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class IncomingMessage:
    """플랫폼에서 수신된 메시지."""
    channel: str           # "telegram", "discord", "slack", "email", "dapparena"
    channel_id: str        # 채널/채팅방 ID
    sender_id: str         # 발신자 ID
    sender_name: str = ""
    content: str = ""
    attachments: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class OutgoingMessage:
    """플랫폼으로 발신할 메시지."""
    content: str = ""
    attachments: list[dict[str, Any]] = field(default_factory=list)  # [{"name":"...", "data":..., "mime_type":"..."}]
    format: str = "text"   # "text", "markdown", "html", "embed"
    metadata: dict[str, Any] = field(default_factory=dict)


class ChannelAdapter(ABC):
    """채널 어댑터 추상 기본 클래스.

    각 플랫폼별 어댑터는 이 클래스를 상속하여
    receive(), send(), format_result()를 구현합니다.
    """

    def __init__(self, name: str, config: dict[str, Any] | None = None):
        self.name = name
        self.config = config or {}
        self._connected = False

    @abstractmethod
    async def connect(self) -> None:
        """플랫폼에 연결합니다."""
        ...

    @abstractmethod
    async def disconnect(self) -> None:
        """플랫폼 연결을 해제합니다."""
        ...

    @abstractmethod
    async def receive(self) -> IncomingMessage:
        """플랫폼에서 메시지를 수신합니다."""
        ...

    @abstractmethod
    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """플랫폼으로 메시지를 발신합니다."""
        ...

    @abstractmethod
    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        """에이전트 결과를 플랫폼 형식으로 변환합니다."""
        ...

    @property
    def is_connected(self) -> bool:
        return self._connected
