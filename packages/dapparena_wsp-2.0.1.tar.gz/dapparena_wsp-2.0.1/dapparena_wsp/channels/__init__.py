"""dapparena_wsp.channels — 멀티채널 메시징 어댑터 (Slice 6, FR-OC-05)

Telegram, Discord, Slack, Email, WhatsApp, Signal, iMessage, Teams, Matrix
어댑터를 제공합니다.
"""

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage
from .telegram import TelegramAdapter
from .discord import DiscordAdapter
from .slack import SlackAdapter
from .email import EmailAdapter
from .whatsapp import WhatsAppAdapter
from .signal import SignalAdapter
from .imessage import iMessageAdapter
from .teams import TeamsAdapter
from .matrix import MatrixAdapter
from .bus import MessageBus

__all__ = [
    "ChannelAdapter", "IncomingMessage", "OutgoingMessage",
    "TelegramAdapter", "DiscordAdapter", "SlackAdapter", "EmailAdapter",
    "WhatsAppAdapter", "SignalAdapter", "iMessageAdapter", "TeamsAdapter", "MatrixAdapter",
    "MessageBus",
]

