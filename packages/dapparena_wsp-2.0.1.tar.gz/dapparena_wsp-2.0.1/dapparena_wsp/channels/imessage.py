"""iMessageAdapter — Apple iMessage 어댑터 (FR-OC-05.8)

AppleScript (macOS) 또는 Beeper/BlueBubbles REST API를 사용합니다.
macOS에서 실행 시 osascript로 iMessage를 직접 제어합니다.
환경변수: IMESSAGE_API_URL (BlueBubbles API 사용 시)
"""

from __future__ import annotations

import logging
import platform
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.imessage")


class iMessageAdapter(ChannelAdapter):
    """Apple iMessage 어댑터.

    두 가지 모드:
    1. macOS 네이티브: AppleScript로 직접 iMessage 전송
    2. BlueBubbles API: REST API를 통한 크로스플랫폼 지원

    Args:
        api_url: BlueBubbles REST API URL (macOS 네이티브 시 빈 문자열)
        api_password: BlueBubbles API 비밀번호
        config: 추가 설정
    """

    def __init__(
        self,
        api_url: str = "",
        api_password: str = "",
        config: dict[str, Any] | None = None,
    ):
        super().__init__("imessage", config)
        cfg = config or {}
        self.api_url = (api_url or cfg.get("api_url", "")).rstrip("/")
        self.api_password = api_password or cfg.get("api_password", "")
        self._use_native = not self.api_url and platform.system() == "Darwin"

    async def connect(self) -> None:
        if self._use_native:
            self._connected = True
            logger.info("📱 iMessage 어댑터 연결됨 (macOS 네이티브)")
        elif self.api_url:
            try:
                import httpx
                async with httpx.AsyncClient() as client:
                    resp = await client.get(
                        f"{self.api_url}/api/v1/server/info",
                        params={"password": self.api_password},
                    )
                    if resp.status_code == 200:
                        self._connected = True
                        logger.info(f"📱 iMessage 어댑터 연결됨 (BlueBubbles: {self.api_url})")
                    else:
                        logger.warning(f"⚠️ BlueBubbles API 응답 이상: {resp.status_code}")
            except Exception as e:
                logger.error(f"iMessage 연결 실패: {e}")
        else:
            logger.warning("⚠️ iMessage: macOS가 아니고 api_url도 미설정")

    async def disconnect(self) -> None:
        self._connected = False
        logger.info("📱 iMessage 어댑터 연결 해제")

    async def receive(self) -> IncomingMessage:
        """iMessage 수신 (BlueBubbles API polling)."""
        if self.api_url:
            try:
                import httpx
                async with httpx.AsyncClient() as client:
                    resp = await client.get(
                        f"{self.api_url}/api/v1/message",
                        params={"password": self.api_password, "limit": 1, "sort": "DESC"},
                    )
                    if resp.status_code == 200:
                        data = resp.json().get("data", [])
                        if data:
                            msg = data[0]
                            return IncomingMessage(
                                channel="imessage",
                                channel_id=msg.get("handle", {}).get("address", ""),
                                sender_id=msg.get("handle", {}).get("address", ""),
                                sender_name=msg.get("handle", {}).get("address", ""),
                                content=msg.get("text", ""),
                                metadata={"guid": msg.get("guid", "")},
                                raw=msg,
                            )
            except Exception as e:
                logger.error(f"iMessage 수신 실패: {e}")
        return IncomingMessage(channel="imessage", channel_id="", sender_id="")

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """iMessage로 메시지 발신."""
        if self._use_native:
            await self._send_native(channel_id, message.content)
        elif self.api_url:
            await self._send_bluebubbles(channel_id, message)
        else:
            logger.error("iMessage 전송 불가: 네이티브/API 모두 미설정")

    async def _send_native(self, to: str, text: str) -> None:
        """macOS AppleScript를 통한 직접 전송."""
        import asyncio
        script = (
            f'tell application "Messages"\n'
            f'  set targetBuddy to buddy "{to}" of service "iMessage"\n'
            f'  send "{text}" to targetBuddy\n'
            f'end tell'
        )
        proc = await asyncio.create_subprocess_exec(
            "osascript", "-e", script,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode == 0:
            logger.info(f"📱 iMessage 전송 (네이티브): to={to}")
        else:
            logger.error(f"iMessage 네이티브 전송 실패: {stderr.decode()}")

    async def _send_bluebubbles(self, channel_id: str, message: OutgoingMessage) -> None:
        """BlueBubbles API를 통한 전송."""
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{self.api_url}/api/v1/message/text",
                    params={"password": self.api_password},
                    json={
                        "chatGuid": f"iMessage;-;{channel_id}",
                        "message": message.content,
                    },
                )
            logger.info(f"📱 iMessage 전송 (BlueBubbles): to={channel_id}")
        except Exception as e:
            logger.error(f"iMessage BlueBubbles 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="text")
