"""TeamsAdapter — Microsoft Teams 어댑터 (FR-OC-05.9)

Microsoft Graph API / Bot Framework를 사용하여 Teams 메시지를 수신/발신합니다.
환경변수: TEAMS_BOT_ID, TEAMS_BOT_PASSWORD, TEAMS_TENANT_ID
"""

from __future__ import annotations

import logging
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.teams")


class TeamsAdapter(ChannelAdapter):
    """Microsoft Teams 어댑터.

    Bot Framework REST API 기반.

    Args:
        bot_id: Microsoft Bot ID (App ID)
        bot_password: Microsoft Bot Password (Client Secret)
        tenant_id: Azure AD Tenant ID
        config: 추가 설정
    """

    AUTH_URL = "https://login.microsoftonline.com/botframework.com/oauth2/v2.0/token"

    def __init__(
        self,
        bot_id: str = "",
        bot_password: str = "",
        tenant_id: str = "",
        config: dict[str, Any] | None = None,
    ):
        super().__init__("teams", config)
        cfg = config or {}
        self.bot_id = bot_id or cfg.get("bot_id", "")
        self.bot_password = bot_password or cfg.get("bot_password", "")
        self.tenant_id = tenant_id or cfg.get("tenant_id", "")
        self._access_token: str = ""

    async def _get_token(self) -> str:
        """OAuth2 액세스 토큰 가져오기."""
        if self._access_token:
            return self._access_token
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self.AUTH_URL,
                    data={
                        "grant_type": "client_credentials",
                        "client_id": self.bot_id,
                        "client_secret": self.bot_password,
                        "scope": "https://api.botframework.com/.default",
                    },
                )
                if resp.status_code == 200:
                    self._access_token = resp.json().get("access_token", "")
                    return self._access_token
        except Exception as e:
            logger.error(f"Teams OAuth 토큰 획득 실패: {e}")
        return ""

    async def connect(self) -> None:
        if not self.bot_id or not self.bot_password:
            logger.warning("⚠️ Teams bot_id 또는 bot_password 미설정")
            return
        token = await self._get_token()
        if token:
            self._connected = True
            logger.info("📱 Teams 어댑터 연결됨")
        else:
            logger.error("Teams 연결 실패: 토큰 획득 불가")

    async def disconnect(self) -> None:
        self._connected = False
        self._access_token = ""
        logger.info("📱 Teams 어댑터 연결 해제")

    async def receive(self) -> IncomingMessage:
        """Teams Bot Framework webhook으로 메시지 수신."""
        return IncomingMessage(channel="teams", channel_id="", sender_id="")

    def parse_activity(self, activity: dict[str, Any]) -> IncomingMessage | None:
        """Bot Framework Activity를 IncomingMessage로 파싱."""
        if activity.get("type") != "message":
            return None
        return IncomingMessage(
            channel="teams",
            channel_id=activity.get("conversation", {}).get("id", ""),
            sender_id=activity.get("from", {}).get("id", ""),
            sender_name=activity.get("from", {}).get("name", ""),
            content=activity.get("text", ""),
            metadata={
                "activity_id": activity.get("id", ""),
                "service_url": activity.get("serviceUrl", ""),
                "conversation_type": activity.get("conversation", {}).get("conversationType", ""),
            },
            raw=activity,
        )

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """Teams으로 메시지 발신."""
        try:
            import httpx
            token = await self._get_token()
            if not token:
                logger.error("Teams 전송 실패: 토큰 없음")
                return

            # Adaptive Card 형식으로 발신
            async with httpx.AsyncClient() as client:
                # 기본 서비스 URL (실제로는 activity에서 받은 serviceUrl 사용)
                service_url = message.metadata.get(
                    "service_url", "https://smba.trafficmanager.net/apac/"
                )
                await client.post(
                    f"{service_url}v3/conversations/{channel_id}/activities",
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "type": "message",
                        "text": message.content,
                        "textFormat": "markdown",
                    },
                )
            logger.info(f"📱 Teams 메시지 전송: conversation={channel_id[:20]}...")
        except Exception as e:
            logger.error(f"Teams 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="markdown")
