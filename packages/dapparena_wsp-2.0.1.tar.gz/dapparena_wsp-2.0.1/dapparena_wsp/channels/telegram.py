"""TelegramAdapter — Telegram Bot API 어댑터 (FR-OC-05.2)"""

from __future__ import annotations

import logging
from typing import Any

from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.telegram")


class TelegramAdapter(ChannelAdapter):
    """Telegram Bot 어댑터.

    Args:
        bot_token: Telegram Bot API 토큰
        config: 추가 설정
    """

    def __init__(self, bot_token: str = "", config: dict[str, Any] | None = None):
        super().__init__("telegram", config)
        self.bot_token = bot_token or (config or {}).get("bot_token", "")
        self._base_url = f"https://api.telegram.org/bot{self.bot_token}"

    async def connect(self) -> None:
        if not self.bot_token:
            logger.warning("⚠️ Telegram bot_token이 설정되지 않았습니다")
            return
        self._connected = True
        logger.info("📱 Telegram 어댑터 연결됨")

    async def disconnect(self) -> None:
        self._connected = False
        logger.info("📱 Telegram 어댑터 연결 해제")

    async def receive(self) -> IncomingMessage:
        """Telegram 메시지 수신 (poll/webhook 기반)."""
        # 실제 구현 시 python-telegram-bot 또는 aiogram 사용
        return IncomingMessage(channel="telegram", channel_id="", sender_id="")

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        """Telegram으로 메시지 발신."""
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{self._base_url}/sendMessage",
                    json={"chat_id": channel_id, "text": message.content, "parse_mode": "Markdown"},
                )
                # 첨부 파일 전송
                for att in message.attachments:
                    if att.get("mime_type", "").startswith("application/pdf"):
                        await client.post(
                            f"{self._base_url}/sendDocument",
                            data={"chat_id": channel_id},
                            files={"document": (att["name"], att["data"])},
                        )
            logger.info(f"📱 Telegram 메시지 전송: chat_id={channel_id}")
        except Exception as e:
            logger.error(f"Telegram 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="markdown")
