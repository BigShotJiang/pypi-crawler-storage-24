"""SlackAdapter — Slack App 어댑터 (FR-OC-05)"""

from __future__ import annotations
import logging
from typing import Any
from .base import ChannelAdapter, IncomingMessage, OutgoingMessage

logger = logging.getLogger("dapparena_wsp.channels.slack")


class SlackAdapter(ChannelAdapter):
    """Slack App 어댑터 (Block Kit 형식)."""

    def __init__(self, bot_token: str = "", config: dict[str, Any] | None = None):
        super().__init__("slack", config)
        self.bot_token = bot_token or (config or {}).get("bot_token", "")

    async def connect(self) -> None:
        self._connected = bool(self.bot_token)
        if self._connected:
            logger.info("💼 Slack 어댑터 연결됨")

    async def disconnect(self) -> None:
        self._connected = False

    async def receive(self) -> IncomingMessage:
        return IncomingMessage(channel="slack", channel_id="", sender_id="")

    async def send(self, channel_id: str, message: OutgoingMessage) -> None:
        try:
            import httpx
            headers = {"Authorization": f"Bearer {self.bot_token}", "Content-Type": "application/json"}
            blocks = [{"type": "section", "text": {"type": "mrkdwn", "text": message.content[:3000]}}]
            async with httpx.AsyncClient() as client:
                await client.post(
                    "https://slack.com/api/chat.postMessage",
                    json={"channel": channel_id, "blocks": blocks, "text": message.content[:200]},
                    headers=headers,
                )
            logger.info(f"💼 Slack 메시지 전송: {channel_id}")
        except Exception as e:
            logger.error(f"Slack 전송 실패: {e}")

    def format_result(self, text: str, attachments: list | None = None) -> OutgoingMessage:
        return OutgoingMessage(content=text, attachments=attachments or [], format="markdown")
