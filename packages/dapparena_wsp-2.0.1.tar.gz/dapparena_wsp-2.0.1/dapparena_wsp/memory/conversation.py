"""ConversationMemory — session_id 기반 대화 이력 관리 (FR-OC-01.1)

에이전트별 session_id 기반으로 최근 N턴의 대화 이력을 자동 저장/로드합니다.
SQLite 백엔드로 영속 저장합니다.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.memory.conversation")


class ConversationMemory:
    """세션 기반 대화 이력 저장/로드.

    Args:
        db_path: SQLite DB 파일 경로
        max_turns: 로드 시 최대 대화 턴 수 (슬라이딩 윈도우)
    """

    def __init__(self, db_path: str = "memory.db", max_turns: int = 50):
        self.db_path = db_path
        self.max_turns = max_turns
        self._ensure_db()

    def _ensure_db(self) -> None:
        """DB 및 테이블 초기화."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS conversation_turns (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id  TEXT NOT NULL,
                    role        TEXT NOT NULL,
                    content     TEXT NOT NULL,
                    metadata    TEXT DEFAULT '{}',
                    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_conv_session
                ON conversation_turns(session_id, created_at DESC)
            """)

    async def add_turn(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """대화 턴 추가.

        Args:
            session_id: 세션 식별자
            role: 'user' | 'assistant' | 'system'
            content: 메시지 내용
            metadata: 추가 메타데이터
        """
        meta_json = json.dumps(metadata or {}, ensure_ascii=False)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO conversation_turns (session_id, role, content, metadata) VALUES (?, ?, ?, ?)",
                (session_id, role, content, meta_json),
            )
        logger.debug(f"💬 대화 턴 저장: session={session_id}, role={role}")

    async def get_history(
        self,
        session_id: str,
        max_turns: int | None = None,
    ) -> list[dict[str, Any]]:
        """세션의 대화 이력 조회 (최근 N턴).

        Args:
            session_id: 세션 식별자
            max_turns: 최대 턴 수 (None이면 기본값 사용)

        Returns:
            대화 이력 리스트 [{"role": ..., "content": ..., "metadata": ...}, ...]
        """
        limit = max_turns or self.max_turns
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """SELECT role, content, metadata, created_at
                   FROM conversation_turns
                   WHERE session_id = ?
                   ORDER BY created_at DESC
                   LIMIT ?""",
                (session_id, limit),
            ).fetchall()

        # 시간순 정렬 (오래된 것 먼저)
        result = []
        for row in reversed(rows):
            entry = {
                "role": row["role"],
                "content": row["content"],
                "created_at": row["created_at"],
            }
            try:
                entry["metadata"] = json.loads(row["metadata"])
            except (json.JSONDecodeError, TypeError):
                entry["metadata"] = {}
            result.append(entry)

        return result

    async def get_summary(self, session_id: str) -> dict[str, Any]:
        """세션 요약 정보 반환."""
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """SELECT COUNT(*) as turn_count,
                          MIN(created_at) as first_at,
                          MAX(created_at) as last_at
                   FROM conversation_turns WHERE session_id = ?""",
                (session_id,),
            ).fetchone()

        return {
            "session_id": session_id,
            "turn_count": row[0] if row else 0,
            "first_at": row[1] if row else None,
            "last_at": row[2] if row else None,
        }

    async def clear(self, session_id: str) -> int:
        """세션의 대화 이력 삭제.

        Returns:
            삭제된 턴 수
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM conversation_turns WHERE session_id = ?",
                (session_id,),
            )
        deleted = cursor.rowcount
        logger.info(f"🗑️ 대화 이력 삭제: session={session_id}, {deleted}턴")
        return deleted

    async def list_sessions(self) -> list[dict[str, Any]]:
        """모든 세션 목록 조회."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT session_id, COUNT(*) as turn_count,
                          MAX(created_at) as last_at
                   FROM conversation_turns
                   GROUP BY session_id
                   ORDER BY last_at DESC"""
            ).fetchall()

        return [
            {"session_id": r[0], "turn_count": r[1], "last_at": r[2]}
            for r in rows
        ]
