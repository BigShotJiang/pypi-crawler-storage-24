"""LongTermMemory — 사용자 선호·습관·과거 결과 영구 저장 (FR-OC-01.2)

사용자의 선호도, 습관 패턴, 과거 요청 결과를 JSON/SQLite로 영구 저장하고,
LLM 프롬프트 생성 시 참조합니다.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.memory.long_term")


class LongTermMemory:
    """사용자/에이전트 장기 메모리.

    Args:
        db_path: SQLite DB 파일 경로
    """

    def __init__(self, db_path: str = "memory.db"):
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS long_term_memory (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id     TEXT NOT NULL,
                    category    TEXT NOT NULL DEFAULT 'general',
                    key         TEXT NOT NULL,
                    value       TEXT NOT NULL,
                    importance  REAL DEFAULT 1.0,
                    access_count INTEGER DEFAULT 0,
                    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, category, key)
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_ltm_user_cat
                ON long_term_memory(user_id, category)
            """)

    async def save(
        self,
        user_id: str,
        key: str,
        value: Any,
        category: str = "general",
        importance: float = 1.0,
    ) -> None:
        """장기 메모리에 값 저장 (upsert).

        Args:
            user_id: 사용자 식별자
            key: 메모리 키 (예: 'preferred_style', 'last_textbook')
            value: 저장할 값 (dict, str, list 등 — JSON 직렬화)
            category: 카테고리 (예: 'preference', 'history', 'profile')
            importance: 중요도 (0.0~10.0, 프롬프트 생성 시 정렬 기준)
        """
        val_json = json.dumps(value, ensure_ascii=False) if not isinstance(value, str) else value
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO long_term_memory (user_id, category, key, value, importance)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(user_id, category, key)
                   DO UPDATE SET value=excluded.value,
                                 importance=excluded.importance,
                                 updated_at=CURRENT_TIMESTAMP""",
                (user_id, category, key, val_json, importance),
            )
        logger.debug(f"🧠 장기 메모리 저장: user={user_id}, {category}/{key}")

    async def load(
        self,
        user_id: str,
        key: str,
        category: str = "general",
    ) -> Any | None:
        """장기 메모리에서 값 로드.

        Returns:
            저장된 값 또는 None
        """
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                """SELECT value FROM long_term_memory
                   WHERE user_id=? AND category=? AND key=?""",
                (user_id, category, key),
            ).fetchone()
            if row:
                # access_count 증가
                conn.execute(
                    """UPDATE long_term_memory SET access_count = access_count + 1
                       WHERE user_id=? AND category=? AND key=?""",
                    (user_id, category, key),
                )
        if not row:
            return None
        try:
            return json.loads(row[0])
        except (json.JSONDecodeError, TypeError):
            return row[0]

    async def search(
        self,
        user_id: str,
        query: str | None = None,
        category: str | None = None,
        top_k: int = 10,
    ) -> list[dict[str, Any]]:
        """유사도 기반 검색 (간이: LIKE 매칭 + importance 정렬).

        Args:
            user_id: 사용자 식별자
            query: 검색 쿼리 (키/값 LIKE 매칭)
            category: 카테고리 필터
            top_k: 최대 결과 수

        Returns:
            매칭된 메모리 항목 리스트
        """
        conditions = ["user_id = ?"]
        params: list[Any] = [user_id]

        if category:
            conditions.append("category = ?")
            params.append(category)

        if query:
            conditions.append("(key LIKE ? OR value LIKE ?)")
            params.extend([f"%{query}%", f"%{query}%"])

        where = " AND ".join(conditions)
        params.append(top_k)

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                f"""SELECT key, value, category, importance, access_count, updated_at
                    FROM long_term_memory
                    WHERE {where}
                    ORDER BY importance DESC, access_count DESC
                    LIMIT ?""",
                params,
            ).fetchall()

        results = []
        for row in rows:
            try:
                val = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                val = row["value"]
            results.append({
                "key": row["key"],
                "value": val,
                "category": row["category"],
                "importance": row["importance"],
                "access_count": row["access_count"],
                "updated_at": row["updated_at"],
            })
        return results

    async def get_user_profile(self, user_id: str) -> dict[str, Any]:
        """사용자의 전체 프로필 (선호도, 히스토리 등) 조회.

        Returns:
            카테고리별 그룹화된 메모리: {"preference": {...}, "history": [...], ...}
        """
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT category, key, value
                   FROM long_term_memory
                   WHERE user_id=?
                   ORDER BY category, importance DESC""",
                (user_id,),
            ).fetchall()

        profile: dict[str, dict] = {}
        for cat, key, val in rows:
            if cat not in profile:
                profile[cat] = {}
            try:
                profile[cat][key] = json.loads(val)
            except (json.JSONDecodeError, TypeError):
                profile[cat][key] = val
        return profile

    async def delete(self, user_id: str, key: str, category: str = "general") -> bool:
        """장기 메모리 삭제."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM long_term_memory WHERE user_id=? AND category=? AND key=?",
                (user_id, category, key),
            )
        return cursor.rowcount > 0
