"""SharedMemoryBoard — 파이프라인 내 에이전트 간 공유 메모리 (FR-OC-01.3)

워크플로 실행 내에서 에이전트 간 데이터 공유를 위한 공유 메모리 보드.
예: 철수가 수집한 핵심 논문 목록을 영희가 자동 참조.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.memory.shared_board")


class SharedMemoryBoard:
    """파이프라인 내 에이전트 간 공유 컨텍스트.

    workflow_id로 스코프가 격리되어 서로 다른 워크플로 실행 간 데이터가 섞이지 않습니다.

    Args:
        db_path: SQLite DB 파일 경로
    """

    def __init__(self, db_path: str = "memory.db"):
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS shared_board (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    workflow_id TEXT NOT NULL,
                    key         TEXT NOT NULL,
                    value       TEXT NOT NULL,
                    agent_name  TEXT DEFAULT '',
                    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(workflow_id, key)
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_board_workflow
                ON shared_board(workflow_id)
            """)

    async def put(
        self,
        workflow_id: str,
        key: str,
        data: Any,
        agent_name: str = "",
    ) -> None:
        """공유 보드에 데이터 저장 (upsert).

        Args:
            workflow_id: 워크플로 실행 ID
            key: 데이터 키 (예: 'paper_list', 'research_summary')
            data: 저장할 데이터 (JSON 직렬화)
            agent_name: 저장한 에이전트 이름
        """
        val_json = json.dumps(data, ensure_ascii=False) if not isinstance(data, str) else data
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO shared_board (workflow_id, key, value, agent_name)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(workflow_id, key)
                   DO UPDATE SET value=excluded.value,
                                 agent_name=excluded.agent_name,
                                 updated_at=CURRENT_TIMESTAMP""",
                (workflow_id, key, val_json, agent_name),
            )
        logger.debug(f"📋 공유 보드 저장: workflow={workflow_id}, key={key}, by={agent_name}")

    async def get(self, workflow_id: str, key: str) -> Any | None:
        """공유 보드에서 데이터 조회.

        Returns:
            저장된 데이터 또는 None
        """
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT value FROM shared_board WHERE workflow_id=? AND key=?",
                (workflow_id, key),
            ).fetchone()

        if not row:
            return None
        try:
            return json.loads(row[0])
        except (json.JSONDecodeError, TypeError):
            return row[0]

    async def list_keys(self, workflow_id: str) -> list[dict[str, Any]]:
        """워크플로의 공유 보드 키 목록 조회.

        Returns:
            [{"key": ..., "agent_name": ..., "updated_at": ...}, ...]
        """
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT key, agent_name, updated_at
                   FROM shared_board
                   WHERE workflow_id=?
                   ORDER BY updated_at DESC""",
                (workflow_id,),
            ).fetchall()

        return [
            {"key": r[0], "agent_name": r[1], "updated_at": r[2]}
            for r in rows
        ]

    async def get_all(self, workflow_id: str) -> dict[str, Any]:
        """워크플로의 공유 보드 전체 데이터 조회.

        Returns:
            {key: value, ...}
        """
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT key, value FROM shared_board WHERE workflow_id=?",
                (workflow_id,),
            ).fetchall()

        result = {}
        for key, val in rows:
            try:
                result[key] = json.loads(val)
            except (json.JSONDecodeError, TypeError):
                result[key] = val
        return result

    async def delete(self, workflow_id: str, key: str) -> bool:
        """공유 보드 데이터 삭제."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM shared_board WHERE workflow_id=? AND key=?",
                (workflow_id, key),
            )
        return cursor.rowcount > 0

    async def clear_workflow(self, workflow_id: str) -> int:
        """워크플로의 공유 보드 전체 삭제.

        Returns:
            삭제된 항목 수
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM shared_board WHERE workflow_id=?",
                (workflow_id,),
            )
        deleted = cursor.rowcount
        logger.info(f"🗑️ 공유 보드 초기화: workflow={workflow_id}, {deleted}건")
        return deleted
