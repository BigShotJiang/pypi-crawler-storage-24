"""MemoryStore — 통합 메모리 인터페이스 (FR-OC-01.4)

대화/장기/공유 메모리를 단일 API로 제공합니다.
MemoryStore.save(), .load(), .search() 인터페이스를 SDK에 제공합니다.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from .conversation import ConversationMemory
from .long_term import LongTermMemory
from .shared_board import SharedMemoryBoard

logger = logging.getLogger("dapparena_wsp.memory.store")


class MemoryStore:
    """통합 메모리 인터페이스 — 대화/장기/공유 메모리를 단일 API로 제공.

    Args:
        db_path: SQLite DB 파일 경로 (모든 메모리가 동일 DB 사용)
        max_conversation_turns: 대화 이력 슬라이딩 윈도우 크기

    Example:
        memory = MemoryStore("data/memory.db")

        # 대화 메모리
        await memory.conversation.add_turn("session_1", "user", "블록체인 교재 만들어줘")
        history = await memory.conversation.get_history("session_1")

        # 장기 메모리
        await memory.save("user_123", "preferred_style", "academic", scope="long_term")
        style = await memory.load("user_123", "preferred_style", scope="long_term")

        # 공유 보드
        await memory.shared.put("workflow_abc", "paper_list", [{"title": "..."}])
        papers = await memory.shared.get("workflow_abc", "paper_list")
    """

    def __init__(
        self,
        db_path: str = "memory.db",
        max_conversation_turns: int = 50,
    ):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)

        self.conversation = ConversationMemory(db_path, max_conversation_turns)
        self.long_term = LongTermMemory(db_path)
        self.shared = SharedMemoryBoard(db_path)

        logger.info(f"🧠 MemoryStore 초기화: {db_path}")

    async def save(
        self,
        key: str,
        data: Any,
        scope: str = "session",
        *,
        session_id: str = "",
        user_id: str = "",
        workflow_id: str = "",
        category: str = "general",
        role: str = "assistant",
        agent_name: str = "",
        importance: float = 1.0,
    ) -> None:
        """통합 저장 API.

        Args:
            key: 데이터 키
            data: 저장할 데이터
            scope: 'session' | 'long_term' | 'shared'
            session_id: (session scope) 세션 ID
            user_id: (long_term scope) 사용자 ID
            workflow_id: (shared scope) 워크플로 ID
            category: (long_term) 카테고리
            role: (session) 메시지 역할
            agent_name: (shared) 에이전트 이름
            importance: (long_term) 중요도
        """
        if scope == "session":
            content = data if isinstance(data, str) else str(data)
            await self.conversation.add_turn(session_id or key, role, content)
        elif scope == "long_term":
            await self.long_term.save(user_id or "default", key, data, category, importance)
        elif scope == "shared":
            await self.shared.put(workflow_id or "default", key, data, agent_name)
        else:
            raise ValueError(f"Unknown scope: {scope}. Use 'session', 'long_term', or 'shared'.")

    async def load(
        self,
        key: str,
        scope: str = "session",
        *,
        session_id: str = "",
        user_id: str = "",
        workflow_id: str = "",
        category: str = "general",
        max_turns: int | None = None,
    ) -> Any | None:
        """통합 로드 API.

        Returns:
            scope에 따른 데이터 또는 None
        """
        if scope == "session":
            return await self.conversation.get_history(session_id or key, max_turns)
        elif scope == "long_term":
            return await self.long_term.load(user_id or "default", key, category)
        elif scope == "shared":
            return await self.shared.get(workflow_id or "default", key)
        else:
            raise ValueError(f"Unknown scope: {scope}")

    async def search(
        self,
        query: str,
        top_k: int = 5,
        *,
        user_id: str = "",
        category: str | None = None,
    ) -> list[dict[str, Any]]:
        """장기 메모리에서 유사도 기반 검색.

        Args:
            query: 검색 쿼리
            top_k: 최대 결과 수
            user_id: 사용자 ID
            category: 카테고리 필터

        Returns:
            매칭된 메모리 항목 리스트
        """
        return await self.long_term.search(
            user_id=user_id or "default",
            query=query,
            category=category,
            top_k=top_k,
        )

    def get_prompt_context(
        self,
        session_id: str = "",
        user_id: str = "",
        workflow_id: str = "",
    ) -> dict[str, Any]:
        """LLM 프롬프트에 주입할 메모리 컨텍스트 빌더.

        동기 래퍼 — 실제 비동기 조회는 get_prompt_context_async를 사용.
        """
        return {
            "session_id": session_id,
            "user_id": user_id,
            "workflow_id": workflow_id,
            "note": "Use get_prompt_context_async() for actual data loading",
        }

    async def get_prompt_context_async(
        self,
        session_id: str = "",
        user_id: str = "",
        workflow_id: str = "",
        max_history_turns: int = 10,
    ) -> dict[str, Any]:
        """LLM 프롬프트에 주입할 메모리 컨텍스트를 비동기로 수집.

        Returns:
            {"conversation_history": [...], "user_profile": {...}, "shared_data": {...}}
        """
        context: dict[str, Any] = {}

        if session_id:
            context["conversation_history"] = await self.conversation.get_history(
                session_id, max_history_turns
            )

        if user_id:
            context["user_profile"] = await self.long_term.get_user_profile(user_id)

        if workflow_id:
            context["shared_data"] = await self.shared.get_all(workflow_id)

        return context
