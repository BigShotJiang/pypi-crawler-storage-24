"""OTAUpdater — 에이전트 무선 업데이트 (FR-OC-09.2)

버전 비교 → 다운로드 → 교체 순서로 자동 업데이트를 실행합니다.
"""

from __future__ import annotations
import json, logging, sqlite3
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.export.updater")


class OTAUpdater:
    """에이전트 OTA(Over-The-Air) 업데이트 관리자.

    Args:
        registry_url: 패키지 레지스트리 URL
        db_path: 업데이트 이력 DB
    """

    def __init__(self, registry_url: str = "", db_path: str = "updates.db"):
        self.registry_url = registry_url
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS update_history (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id    TEXT NOT NULL,
                    from_ver    TEXT NOT NULL,
                    to_ver      TEXT NOT NULL,
                    status      TEXT NOT NULL,
                    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    error       TEXT DEFAULT ''
                )
            """)

    async def check_update(self, agent_id: str, current_version: str) -> dict[str, Any]:
        """업데이트 가능 여부 확인.

        Returns:
            {"available": bool, "latest_version": str, "release_notes": str}
        """
        if not self.registry_url:
            return {"available": False, "reason": "no_registry"}

        try:
            import httpx
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(f"{self.registry_url}/agents/{agent_id}/latest")
                resp.raise_for_status()
                data = resp.json()

            latest = data.get("version", current_version)
            available = self._compare_versions(current_version, latest) < 0

            return {
                "available": available,
                "current_version": current_version,
                "latest_version": latest,
                "release_notes": data.get("release_notes", ""),
                "download_url": data.get("download_url", ""),
            }
        except Exception as e:
            return {"available": False, "error": str(e)}

    async def apply_update(
        self,
        agent_id: str,
        current_version: str,
        download_url: str,
        target_dir: str,
    ) -> dict[str, str]:
        """업데이트 적용.

        Args:
            agent_id: 에이전트 ID
            current_version: 현재 버전
            download_url: 패키지 다운로드 URL
            target_dir: 설치 대상 디렉토리

        Returns:
            {"status": ..., "version": ...}
        """
        try:
            import httpx, zipfile, io

            # 다운로드
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.get(download_url)
                resp.raise_for_status()
                pkg_data = resp.content

            # ZIP 압축 해제
            target = Path(target_dir)
            target.mkdir(parents=True, exist_ok=True)

            with zipfile.ZipFile(io.BytesIO(pkg_data)) as zf:
                # manifest에서 버전 확인
                if "manifest.json" in zf.namelist():
                    manifest = json.loads(zf.read("manifest.json"))
                    new_version = manifest.get("version", "unknown")
                else:
                    new_version = "unknown"
                zf.extractall(target)

            # 이력 기록
            self._record(agent_id, current_version, new_version, "success")
            logger.info(f"🔄 업데이트 완료: {agent_id} {current_version} → {new_version}")
            return {"status": "updated", "version": new_version}

        except Exception as e:
            self._record(agent_id, current_version, "?", "failed", str(e))
            logger.error(f"업데이트 실패: {e}")
            return {"status": "failed", "error": str(e)}

    def get_history(self, agent_id: str, limit: int = 20) -> list[dict]:
        """업데이트 이력 조회."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM update_history WHERE agent_id=? ORDER BY updated_at DESC LIMIT ?",
                (agent_id, limit),
            ).fetchall()
        return [dict(r) for r in rows]

    def _record(self, agent_id: str, from_ver: str, to_ver: str, status: str, error: str = "") -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO update_history (agent_id, from_ver, to_ver, status, error) VALUES (?,?,?,?,?)",
                (agent_id, from_ver, to_ver, status, error),
            )

    @staticmethod
    def _compare_versions(v1: str, v2: str) -> int:
        """간이 버전 비교. 0=같음, -1=v1<v2, 1=v1>v2."""
        parts1 = [int(x) for x in v1.split(".") if x.isdigit()]
        parts2 = [int(x) for x in v2.split(".") if x.isdigit()]
        for a, b in zip(parts1, parts2):
            if a < b:
                return -1
            if a > b:
                return 1
        return len(parts1) - len(parts2)
