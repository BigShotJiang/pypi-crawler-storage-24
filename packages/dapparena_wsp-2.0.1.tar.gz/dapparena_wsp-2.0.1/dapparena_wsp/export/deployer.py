"""AgentDeployer — 에이전트 배포 (FR-OC-08.2)

패키징된 에이전트를 Docker 환경 또는 원격 서버에 배포합니다.
"""

from __future__ import annotations
import asyncio, json, logging, subprocess
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.export.deployer")


class AgentDeployer:
    """에이전트 배포 관리자.

    Docker 빌드/실행 및 원격 배포를 지원합니다.
    """

    async def deploy_docker(
        self,
        dockerfile_path: str,
        context_dir: str,
        image_name: str,
        port: int = 8080,
        detach: bool = True,
    ) -> dict[str, Any]:
        """Docker 이미지 빌드 + 컨테이너 실행.

        Args:
            dockerfile_path: Dockerfile 경로
            context_dir: 빌드 컨텍스트 디렉토리
            image_name: 이미지 이름 (예: "wsp/cheolsu:1.0.0")
            port: 호스트 포트
            detach: 백그라운드 실행 여부

        Returns:
            {"status": ..., "container_id": ..., "url": ...}
        """
        try:
            # 빌드
            build_cmd = ["docker", "build", "-f", dockerfile_path, "-t", image_name, context_dir]
            proc = await asyncio.create_subprocess_exec(
                *build_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                return {"status": "build_failed", "error": stderr.decode()[:500]}

            logger.info(f"🐳 도커 빌드 완료: {image_name}")

            # 실행
            run_cmd = ["docker", "run"]
            if detach:
                run_cmd.append("-d")
            run_cmd.extend(["-p", f"{port}:8080", "--name", image_name.split("/")[-1].replace(":", "-"), image_name])

            proc = await asyncio.create_subprocess_exec(
                *run_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
            container_id = stdout.decode().strip()[:12]

            logger.info(f"🐳 컨테이너 시작: {container_id} (port={port})")
            return {
                "status": "deployed",
                "container_id": container_id,
                "url": f"http://localhost:{port}",
                "image": image_name,
            }

        except FileNotFoundError:
            return {"status": "error", "message": "Docker가 설치되지 않았습니다."}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def stop(self, container_name: str) -> dict[str, str]:
        """컨테이너 중지."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker", "stop", container_name,
                stdout=asyncio.subprocess.PIPE,
            )
            await proc.communicate()
            return {"status": "stopped", "container": container_name}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def list_running(self) -> list[dict[str, str]]:
        """실행 중인 WSP 에이전트 컨테이너 목록."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker", "ps", "--filter", "ancestor=wsp/*", "--format", "{{.ID}}\t{{.Names}}\t{{.Status}}\t{{.Ports}}",
                stdout=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            lines = stdout.decode().strip().split("\n")
            return [
                {"id": parts[0], "name": parts[1], "status": parts[2], "ports": parts[3]}
                for line in lines if line
                for parts in [line.split("\t")]
                if len(parts) >= 4
            ]
        except Exception:
            return []
