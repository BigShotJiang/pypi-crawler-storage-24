"""AgentPackager — 에이전트 패키징 (FR-OC-08.1)

에이전트 소스 코드, 설정, 의존성을 Docker 이미지 또는 ZIP으로 패키징합니다.
"""

from __future__ import annotations
import json, logging, shutil, uuid, zipfile
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.export.packager")


class AgentPackager:
    """에이전트 배포 패키지 생성.

    Example:
        packager = AgentPackager()
        pkg = packager.create_package(
            agent_dir="agents/cheolsu",
            output_dir="dist/",
            metadata={"name": "cheolsu", "version": "1.0.0"},
        )
    """

    def create_package(
        self,
        agent_dir: str,
        output_dir: str = "dist",
        metadata: dict[str, Any] | None = None,
        include_docker: bool = True,
    ) -> dict[str, str]:
        """에이전트를 ZIP + Dockerfile 로 패키징.

        Args:
            agent_dir: 에이전트 소스 디렉토리
            output_dir: 출력 디렉토리
            metadata: 에이전트 메타데이터
            include_docker: Dockerfile 포함 여부

        Returns:
            {"zip_path": ..., "dockerfile_path": ..., "manifest_path": ...}
        """
        agent_path = Path(agent_dir)
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)

        metadata = metadata or {}
        pkg_name = metadata.get("name", agent_path.name)
        pkg_version = metadata.get("version", "1.0.0")
        pkg_id = f"{pkg_name}-{pkg_version}"

        # 1. manifest.json 생성
        manifest = {
            "id": str(uuid.uuid4())[:8],
            "name": pkg_name,
            "version": pkg_version,
            "description": metadata.get("description", ""),
            "entry_point": metadata.get("entry_point", "main.py"),
            "requirements": metadata.get("requirements", "requirements.txt"),
            "sdk_version": "2.0.0",
        }
        manifest_path = out_path / f"{pkg_id}-manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

        # 2. ZIP 패키지
        zip_path = out_path / f"{pkg_id}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))
            if agent_path.exists():
                for f in agent_path.rglob("*"):
                    if f.is_file() and "__pycache__" not in str(f):
                        zf.write(f, f.relative_to(agent_path))

        # 3. Dockerfile 생성
        dockerfile_path = None
        if include_docker:
            dockerfile_content = f"""FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install --no-cache-dir -r {manifest['requirements']} 2>/dev/null || true
RUN pip install --no-cache-dir dapparena-wsp>=2.0.0 2>/dev/null || true
EXPOSE 8080
CMD ["python", "{manifest['entry_point']}"]
"""
            dockerfile_path = out_path / f"Dockerfile.{pkg_name}"
            dockerfile_path.write_text(dockerfile_content)

        result = {
            "zip_path": str(zip_path),
            "manifest_path": str(manifest_path),
        }
        if dockerfile_path:
            result["dockerfile_path"] = str(dockerfile_path)

        logger.info(f"📦 에이전트 패키지 생성: {pkg_id}")
        return result
