"""LicenseManager — 에이전트 라이선스 발급/검증 (FR-OC-09.1)"""

from __future__ import annotations
import hashlib, hmac, json, logging, sqlite3, time, uuid
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.export.license")


class LicenseManager:
    """에이전트 라이선스 관리 (발급, 검증, 취소).

    HMAC-SHA256 서명으로 라이선스 무결성을 보장합니다.
    """

    def __init__(self, db_path: str = "licenses.db", secret_key: str = "wsp-license-key"):
        self.db_path = db_path
        self._secret = secret_key.encode()
        self._ensure_db()

    def _ensure_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS licenses (
                    id          TEXT PRIMARY KEY,
                    agent_id    TEXT NOT NULL,
                    user_id     TEXT NOT NULL,
                    license_type TEXT NOT NULL DEFAULT 'trial',
                    issued_at   REAL NOT NULL,
                    expires_at  REAL,
                    signature   TEXT NOT NULL,
                    revoked     INTEGER DEFAULT 0,
                    metadata    TEXT DEFAULT '{}'
                )
            """)

    def issue(
        self,
        agent_id: str,
        user_id: str,
        license_type: str = "standard",
        duration_days: int = 365,
        metadata: dict | None = None,
    ) -> dict[str, Any]:
        """라이선스 발급.

        Args:
            agent_id: 에이전트 ID
            user_id: 사용자 ID
            license_type: "trial" | "standard" | "enterprise"
            duration_days: 유효 기간 (일)
            metadata: 추가 정보

        Returns:
            라이선스 정보 딕셔너리
        """
        lid = str(uuid.uuid4())
        issued_at = time.time()
        expires_at = issued_at + (duration_days * 86400) if duration_days > 0 else None

        # HMAC 서명
        payload = f"{lid}:{agent_id}:{user_id}:{issued_at}"
        signature = hmac.new(self._secret, payload.encode(), hashlib.sha256).hexdigest()

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO licenses (id, agent_id, user_id, license_type, issued_at, expires_at, signature, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (lid, agent_id, user_id, license_type, issued_at, expires_at, signature,
                 json.dumps(metadata or {}, ensure_ascii=False)),
            )

        logger.info(f"🔑 라이선스 발급: {lid} ({license_type}, {duration_days}일)")
        return {
            "license_id": lid,
            "agent_id": agent_id,
            "user_id": user_id,
            "type": license_type,
            "expires_at": expires_at,
            "signature": signature,
        }

    def verify(self, license_id: str) -> dict[str, Any]:
        """라이선스 유효성 검증.

        Returns:
            {"valid": bool, "reason": str, "license": ...}
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT * FROM licenses WHERE id=?", (license_id,)).fetchone()

        if not row:
            return {"valid": False, "reason": "not_found"}

        if row["revoked"]:
            return {"valid": False, "reason": "revoked"}

        if row["expires_at"] and time.time() > row["expires_at"]:
            return {"valid": False, "reason": "expired"}

        # 서명 검증
        payload = f"{row['id']}:{row['agent_id']}:{row['user_id']}:{row['issued_at']}"
        expected = hmac.new(self._secret, payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(row["signature"], expected):
            return {"valid": False, "reason": "invalid_signature"}

        return {"valid": True, "reason": "ok", "type": row["license_type"]}

    def revoke(self, license_id: str) -> bool:
        """라이선스 취소."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("UPDATE licenses SET revoked=1 WHERE id=?", (license_id,))
        return cursor.rowcount > 0
