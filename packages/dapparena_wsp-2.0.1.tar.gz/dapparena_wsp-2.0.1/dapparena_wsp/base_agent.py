"""BaseAgentV2 — WSP 에이전트 추상 기본 클래스 (S1-05, S3-13, S4 업데이트)

Task 기반 handle_task() 인터페이스를 정의합니다.
Slice 3: blockchain_config로 DID/지갑/x402 연동 지원.
Slice 4: MemoryStore 옵셔널 주입 — 대화/장기/공유 메모리.
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import Any

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .a2a.agent_card import agent_card_router, register_agent_card
from .a2a.models import AgentCard, Artifact, Task, TaskState
from .a2a.server import register_agent, router as a2a_router

logger = logging.getLogger("dapparena_wsp.base_agent")


class BaseAgentV2(ABC):
    """WSP 에이전트 기본 클래스.

    개발자는 이 클래스를 상속하고 handle_task()를 구현합니다.

    Example:
        class CheolsuAgent(BaseAgentV2):
            async def handle_task(self, task: Task) -> Task:
                # LLM으로 연구 수행
                result = await self.llm_call(task.message)
                task.artifacts.append(Artifact(
                    name="research_summary",
                    mime_type="application/json",
                    data=result,
                ))
                return task
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        port: int = 8080,
        skills: list[str] | None = None,
        host: str = "0.0.0.0",
        blockchain_config: dict[str, Any] | None = None,
        memory=None,
    ):
        self.name = name
        self.description = description
        self.port = port
        self.skills = skills or []
        self.host = host
        self._start_time = time.time()

        # Slice 4: 메모리 시스템 (옵셔널)
        self.memory = memory  # MemoryStore | None
        if self.memory:
            logger.info(f"🧠 메모리 시스템 활성화: {self.memory.db_path}")

        # Slice 3: 블록체인 설정
        self.blockchain_config = blockchain_config or {}
        self.did_manager = None
        self.tba_manager = None
        self.x402_handler = None

        if self.blockchain_config:
            self._init_blockchain()

    def _init_blockchain(self) -> None:
        """블록체인 모듈을 초기화합니다 (DID, TBA, x402)."""
        cfg = self.blockchain_config
        agent_id = cfg.get("agent_id", 0)

        try:
            from .identity import DIDManager
            self.did_manager = DIDManager(
                agent_name=self.name,
                agent_id=agent_id,
            )
            logger.info(f"🆔 DID: {self.did_manager.did_string}")
        except Exception as e:
            logger.warning(f"DID 초기화 실패: {e}")

        try:
            from .wallet import TBAManager
            self.tba_manager = TBAManager(
                rpc_url=cfg.get("rpc_url", "https://rpc.worldland.foundation"),
                registry_address=cfg.get("erc6551_registry", ""),
                implementation_address=cfg.get("tba_implementation", ""),
                nft_contract=cfg.get("nft_contract", ""),
                chain_id=cfg.get("chain_id", 103),
            )
        except Exception as e:
            logger.warning(f"TBA 초기화 실패: {e}")

        try:
            from .x402 import X402PaymentHandler
            tba_addr = ""
            if self.tba_manager and agent_id:
                tba_addr = self.tba_manager.compute_tba_address(agent_id)
            self.x402_handler = X402PaymentHandler(
                payer_tba=tba_addr,
                agent_id=agent_id,
                x402_contract=cfg.get("x402_contract", ""),
                rpc_url=cfg.get("rpc_url", "https://rpc.worldland.foundation"),
            )
        except Exception as e:
            logger.warning(f"x402 초기화 실패: {e}")

    @abstractmethod
    async def handle_task(self, task: Task) -> Task:
        """Task를 처리하고 결과 Task를 반환합니다.

        Args:
            task: 입력 Task (message + 이전 단계 artifacts)

        Returns:
            처리 완료된 Task (artifacts 추가됨)
        """
        ...

    def get_agent_card(self) -> AgentCard:
        """에이전트 능력 명세를 반환합니다 (Slice 3: 블록체인 정보 포함)."""
        cfg = self.blockchain_config
        agent_id = cfg.get("agent_id", 0)

        # DID 문자열
        did_str = ""
        if self.did_manager:
            did_str = self.did_manager.did_string

        # TBA 주소
        tba_addr = ""
        if self.tba_manager and agent_id:
            try:
                tba_addr = self.tba_manager.compute_tba_address(agent_id)
            except Exception:
                pass

        # 요금 정보
        pricing = {}
        x402 = cfg.get("x402_contract", "")
        if x402:
            pricing = {
                "model": "per_query",
                "amount_wlc": "0.01",
                "payment_contract": x402,
            }

        # 엔드포인트
        endpoints = {
            "task": "/a2a/tasks/send",
            "health": "/health",
        }
        if did_str:
            endpoints["did"] = "/did"

        return AgentCard(
            name=self.name,
            description=self.description,
            url=f"http://{self.host}:{self.port}",
            skills=self.skills,
            did=did_str,
            tba_address=tba_addr,
            trusted=bool(did_str),  # TrustRegistry 조회는 별도; DID 있으면 true 표시
            pricing=pricing,
            endpoints=endpoints,
        )

    def _create_app(self) -> FastAPI:
        """FastAPI 앱을 구성합니다."""
        app = FastAPI(title=f"WSP Agent: {self.name}", version="1.2.0")

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # 에이전트 등록
        register_agent(self)
        register_agent_card(self)

        # 라우터 포함
        app.include_router(a2a_router)
        app.include_router(agent_card_router)

        # 헬스체크
        @app.get("/health")
        async def health():
            result = {
                "status": "online",
                "agent_name": self.name,
                "uptime_seconds": round(time.time() - self._start_time, 1),
            }
            if self.did_manager:
                result["did"] = self.did_manager.did_string
            return JSONResponse(content=result)

        # DID 엔드포인트 (Slice 3)
        if self.did_manager:
            @app.get("/did")
            async def did_document():
                doc = self.did_manager.create_did_document(
                    endpoint=f"http://{self.host}:{self.port}"
                )
                return JSONResponse(content=doc.to_dict())

        # ── v1 호환 엔드포인트 (샌드박스/CLI 호환) ──

        @app.get("/a2a/capabilities")
        async def capabilities():
            """v1 호환: agent capabilities 반환."""
            card = self.get_agent_card()
            return JSONResponse(content={
                "name": self.name,
                "description": self.description,
                "skills": self.skills,
                "supportsStreaming": True,
                "category": self.blockchain_config.get("category", 0),
                "version": "1.2.0",
                "endpoints": card.endpoints if hasattr(card, "endpoints") else {},
            })

        @app.get("/a2a/info")
        async def info():
            """v1 호환: agent 상세 정보 반환."""
            return JSONResponse(content={
                "name": self.name,
                "description": self.description,
                "version": "1.2.0",
                "skills": self.skills,
                "supportsStreaming": True,
            })

        @app.post("/a2a/chat")
        async def chat(request: Request):
            """v1 호환: handle_task()를 래핑하여 {message} 형태로 응답.
            Slice 4: 메모리가 활성화된 경우 대화 이력을 자동 저장/로드.
            """
            import uuid as _uuid
            body = await request.json()
            message = body.get("message", "")
            context = body.get("context", {})
            session_id = body.get("session_id", str(_uuid.uuid4()))

            # Slice 4: 메모리에서 대화 이력 로드
            if self.memory:
                try:
                    history = await self.memory.conversation.get_history(session_id, max_turns=20)
                    context["conversation_history"] = history
                    await self.memory.conversation.add_turn(session_id, "user", message)
                except Exception as mem_err:
                    logger.warning(f"메모리 로드 실패 (무시): {mem_err}")

            task = Task(message=message, metadata={"context": context, "session_id": session_id})
            try:
                result = await self.handle_task(task)
                # artifacts에서 텍스트 추출
                response_text = ""
                if result.artifacts:
                    first = result.artifacts[0]
                    if isinstance(first.data, str):
                        response_text = first.data
                    elif isinstance(first.data, dict):
                        response_text = first.data.get("text", str(first.data))
                    else:
                        response_text = str(first.data)
                else:
                    response_text = f"[{self.name}] Task 완료 (artifacts 없음)"

                # Slice 4: 에이전트 응답도 메모리에 저장
                if self.memory:
                    try:
                        await self.memory.conversation.add_turn(session_id, "assistant", response_text)
                    except Exception as mem_err:
                        logger.warning(f"메모리 저장 실패 (무시): {mem_err}")

                return JSONResponse(content={
                    "message": response_text,
                    "session_id": session_id,
                })
            except Exception as e:
                logger.error(f"[v1 chat] 오류: {e}")
                return JSONResponse(
                    content={"message": f"오류: {str(e)}", "error": True},
                    status_code=500,
                )

        @app.post("/a2a/quote")
        async def quote(request: Request):
            """v1 호환: 견적 반환."""
            body = await request.json()
            cfg = self.blockchain_config
            amount = cfg.get("price_wl", "0.01")
            return JSONResponse(content={
                "cost": f"{amount} WL",
                "costWei": str(int(float(amount) * 10**18)),
                "duration": "~30s",
                "taskDescription": body.get("taskDescription", ""),
            })

        @app.post("/a2a/stream")
        async def stream(request: Request):
            """v1 호환: handle_task() 결과를 SSE 스트리밍으로 반환."""
            from fastapi.responses import StreamingResponse as SR
            body = await request.json()
            message = body.get("message", "")

            async def generate():
                import json as _json
                task = Task(message=message)
                try:
                    result = await self.handle_task(task)
                    if result.artifacts:
                        text = result.artifacts[0].data
                        if isinstance(text, dict):
                            text = text.get("text", str(text))
                        # S-3: json.dumps로 안전 직렬화 (특수문자 이스케이프)
                        chunk_size = 20
                        for i in range(0, len(str(text)), chunk_size):
                            chunk = str(text)[i:i + chunk_size]
                            yield f'data: {_json.dumps({"token": chunk, "done": False}, ensure_ascii=False)}\n\n'
                    yield f'data: {_json.dumps({"token": "", "done": True})}\n\n'
                except Exception as e:
                    yield f'data: {_json.dumps({"token": f"오류: {str(e)}", "done": True}, ensure_ascii=False)}\n\n'

            return SR(
                generate(),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
            )

        return app

    def run(self, host: str | None = None, port: int | None = None) -> None:
        """에이전트 서버를 시작합니다.

        Args:
            host: 바인딩 호스트 (기본: self.host)
            port: 바인딩 포트 (기본: self.port)
        """
        _host = host or self.host
        _port = port or self.port
        app = self._create_app()
        logger.info(f"🚀 {self.name} 에이전트 시작: http://{_host}:{_port}")
        uvicorn.run(app, host=_host, port=_port, log_level="info")

