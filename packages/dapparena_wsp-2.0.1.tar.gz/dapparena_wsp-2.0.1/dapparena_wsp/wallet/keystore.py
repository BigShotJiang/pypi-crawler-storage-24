"""Keystore — Private Key 암호화 저장 (S3-04)

AES-256-GCM으로 에이전트 private key를 로컬 파일에 암호화 저장합니다.
파일 권한은 600(owner-only)으로 설정합니다.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import secrets
import stat
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.wallet.keystore")

# AES-GCM은 선택적 의존성
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes

    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False
    logger.warning("cryptography 미설치 — keystore 기능 제한")


class Keystore:
    """에이전트 private key를 암호화하여 로컬에 저장합니다.

    Usage::

        ks = Keystore(key_dir=".keys")
        ks.save("cheolsu", private_key_hex, password="my-secret")
        recovered = ks.load("cheolsu", password="my-secret")
    """

    def __init__(self, key_dir: str = ".keys"):
        self.key_dir = Path(key_dir)
        self.key_dir.mkdir(parents=True, exist_ok=True)

    def _keyfile_path(self, agent_name: str) -> Path:
        """키 파일 경로."""
        return self.key_dir / f"{agent_name}.keystore.json"

    # ----------------------------------------------------------
    # 저장
    # ----------------------------------------------------------

    def save(
        self,
        agent_name: str,
        private_key_hex: str,
        password: str,
    ) -> Path:
        """Private key를 암호화하여 저장합니다.

        Args:
            agent_name: 에이전트 이름
            private_key_hex: 16진수 private key (0x 접두사 선택적)
            password: 암호화 패스워드

        Returns:
            저장된 키 파일 경로
        """
        key_hex = private_key_hex.replace("0x", "")
        key_bytes = bytes.fromhex(key_hex)

        if HAS_CRYPTO:
            encrypted_data = self._encrypt_aes(key_bytes, password)
        else:
            # 폴백: XOR + PBKDF2 시뮬레이션 (보안 수준 낮음)
            encrypted_data = self._encrypt_simple(key_bytes, password)

        keyfile_path = self._keyfile_path(agent_name)
        keyfile_path.write_text(
            json.dumps(encrypted_data, indent=2),
            encoding="utf-8",
        )

        # 파일 권한 설정 (owner-only read/write)
        self._set_permissions(keyfile_path)

        logger.info(f"🔑 키스토어 저장: {keyfile_path}")
        return keyfile_path

    # ----------------------------------------------------------
    # 로드
    # ----------------------------------------------------------

    def load(self, agent_name: str, password: str) -> str:
        """암호화된 Private key를 복호화하여 반환합니다.

        Args:
            agent_name: 에이전트 이름
            password: 복호화 패스워드

        Returns:
            복호화된 private key (hex, 0x 없음)

        Raises:
            FileNotFoundError: 키 파일 없음
            ValueError: 패스워드 불일치
        """
        keyfile_path = self._keyfile_path(agent_name)
        if not keyfile_path.exists():
            raise FileNotFoundError(f"키스토어 파일 없음: {keyfile_path}")

        data = json.loads(keyfile_path.read_text(encoding="utf-8"))

        if HAS_CRYPTO:
            key_bytes = self._decrypt_aes(data, password)
        else:
            key_bytes = self._decrypt_simple(data, password)

        return key_bytes.hex()

    def exists(self, agent_name: str) -> bool:
        """키스토어 파일 존재 여부."""
        return self._keyfile_path(agent_name).exists()

    def delete(self, agent_name: str) -> bool:
        """키스토어 파일 삭제."""
        path = self._keyfile_path(agent_name)
        if path.exists():
            path.unlink()
            logger.info(f"🔑 키스토어 삭제: {path}")
            return True
        return False

    # ----------------------------------------------------------
    # AES-256-GCM 암호화
    # ----------------------------------------------------------

    def _encrypt_aes(
        self, plaintext: bytes, password: str
    ) -> dict[str, Any]:
        """AES-256-GCM으로 암호화합니다."""
        salt = secrets.token_bytes(16)
        nonce = secrets.token_bytes(12)

        # PBKDF2로 키 파생
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,
        )
        derived_key = kdf.derive(password.encode("utf-8"))

        aesgcm = AESGCM(derived_key)
        ciphertext = aesgcm.encrypt(nonce, plaintext, None)

        return {
            "version": 1,
            "crypto": "aes-256-gcm",
            "kdf": "pbkdf2-sha256",
            "iterations": 480000,
            "salt": salt.hex(),
            "nonce": nonce.hex(),
            "ciphertext": ciphertext.hex(),
        }

    def _decrypt_aes(
        self, data: dict[str, Any], password: str
    ) -> bytes:
        """AES-256-GCM으로 복호화합니다."""
        salt = bytes.fromhex(data["salt"])
        nonce = bytes.fromhex(data["nonce"])
        ciphertext = bytes.fromhex(data["ciphertext"])
        iterations = data.get("iterations", 480000)

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=iterations,
        )
        derived_key = kdf.derive(password.encode("utf-8"))

        aesgcm = AESGCM(derived_key)
        try:
            return aesgcm.decrypt(nonce, ciphertext, None)
        except Exception as e:
            raise ValueError("패스워드 불일치 또는 데이터 손상") from e

    # ----------------------------------------------------------
    # 폴백 (cryptography 미설치 시)
    # ----------------------------------------------------------

    def _encrypt_simple(
        self, plaintext: bytes, password: str
    ) -> dict[str, Any]:
        """XOR 기반 간단 암호화 (폴백)."""
        salt = secrets.token_bytes(16)
        key = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), salt, 480000
        )
        encrypted = bytes(a ^ b for a, b in zip(plaintext, key[: len(plaintext)]))
        checksum = hashlib.sha256(plaintext).hexdigest()

        return {
            "version": 1,
            "crypto": "xor-pbkdf2",
            "salt": salt.hex(),
            "ciphertext": encrypted.hex(),
            "checksum": checksum,
        }

    def _decrypt_simple(
        self, data: dict[str, Any], password: str
    ) -> bytes:
        """XOR 기반 복호화 (폴백)."""
        salt = bytes.fromhex(data["salt"])
        ciphertext = bytes.fromhex(data["ciphertext"])
        key = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), salt, 480000
        )
        decrypted = bytes(
            a ^ b for a, b in zip(ciphertext, key[: len(ciphertext)])
        )

        if "checksum" in data:
            actual = hashlib.sha256(decrypted).hexdigest()
            if actual != data["checksum"]:
                raise ValueError("패스워드 불일치 또는 데이터 손상")

        return decrypted

    # ----------------------------------------------------------
    # 파일 권한
    # ----------------------------------------------------------

    @staticmethod
    def _set_permissions(path: Path) -> None:
        """파일 권한을 owner-only (600)로 설정합니다."""
        try:
            if os.name == "nt":
                # Windows: 읽기 전용 해제 후 다시 설정 (완전한 ACL은 미지원)
                os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
            else:
                os.chmod(path, 0o600)
        except OSError as e:
            logger.warning(f"파일 권한 설정 실패: {e}")

    @staticmethod
    def check_permissions(path: Path) -> bool:
        """파일 권한이 600 이하인지 확인합니다."""
        try:
            st = path.stat()
            mode = st.st_mode & 0o777
            if os.name == "nt":
                # Windows에서는 간소화된 확인
                return True
            return mode <= 0o600
        except OSError:
            return False
