"""ScheduleManager — 스케줄 작업 통합 관리 및 REST API (FR-OC-04.3)

예약된 작업 목록, 실행 이력, 성공/실패 통계를 조회하는 REST API를 제공합니다.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from .cron import CronScheduler

logger = logging.getLogger("dapparena_wsp.scheduler.manager")


class ScheduleManager:
    """스케줄 작업 통합 관리자.

    CronScheduler와 함께 사용하며, FastAPI 라우터를 제공합니다.

    Example:
        scheduler = CronScheduler("scheduler.db")
        manager = ScheduleManager(scheduler)
        app.include_router(manager.router, prefix="/api/scheduler")
    """

    def __init__(self, scheduler: CronScheduler):
        self.scheduler = scheduler
        self.router = APIRouter(tags=["scheduler"])
        self._register_routes()

    def _register_routes(self) -> None:
        """REST API 라우트 등록."""

        @self.router.get("/jobs")
        async def list_jobs():
            """등록된 스케줄 목록 조회."""
            jobs = self.scheduler.list_jobs()
            return JSONResponse(content={"jobs": jobs, "total": len(jobs)})

        @self.router.post("/jobs")
        async def create_job(request: Request):
            """새 스케줄 등록."""
            body = await request.json()
            cron = body.get("cron")
            workflow = body.get("workflow")
            if not cron or not workflow:
                raise HTTPException(400, "cron과 workflow는 필수입니다")

            job_id = self.scheduler.schedule(
                cron=cron,
                workflow=workflow,
                channels=body.get("channels", []),
                params=body.get("params", {}),
                job_id=body.get("id"),
            )
            return JSONResponse(content={"id": job_id, "status": "scheduled"})

        @self.router.delete("/jobs/{job_id}")
        async def delete_job(job_id: str):
            """스케줄 삭제."""
            deleted = self.scheduler.unschedule(job_id)
            if not deleted:
                raise HTTPException(404, f"Job {job_id} not found")
            return JSONResponse(content={"id": job_id, "status": "deleted"})

        @self.router.get("/jobs/{job_id}/history")
        async def job_history(job_id: str, limit: int = 20):
            """작업 실행 이력 조회."""
            history = self.scheduler.get_history(job_id, limit)
            return JSONResponse(content={"job_id": job_id, "history": history})

        @self.router.get("/stats")
        async def stats():
            """전체 스케줄 통계."""
            jobs = self.scheduler.list_jobs()
            total = len(jobs)
            active = sum(1 for j in jobs if j.get("enabled"))
            total_runs = sum(j.get("run_count", 0) for j in jobs)
            return JSONResponse(content={
                "total_jobs": total,
                "active_jobs": active,
                "total_runs": total_runs,
            })
