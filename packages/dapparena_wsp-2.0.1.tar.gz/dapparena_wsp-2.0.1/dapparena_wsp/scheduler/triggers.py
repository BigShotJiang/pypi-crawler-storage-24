"""EventTrigger — 외부 이벤트 감지 기반 워크플로 트리거 (FR-OC-04.2)

외부 이벤트(webhook, 블록체인 이벤트, 파일 변경)를 감지하여 워크플로를 시작합니다.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Callable

logger = logging.getLogger("dapparena_wsp.scheduler.triggers")


class EventTrigger(ABC):
    """이벤트 트리거 추상 기본 클래스."""

    def __init__(self, name: str, callback: Callable | None = None):
        self.name = name
        self._callback = callback
        self._active = False

    @abstractmethod
    async def start(self) -> None:
        """트리거 감시 시작."""
        ...

    @abstractmethod
    async def stop(self) -> None:
        """트리거 감시 중지."""
        ...

    async def fire(self, event_data: dict[str, Any]) -> None:
        """이벤트 발생 시 콜백 실행."""
        logger.info(f"🔥 트리거 발동: {self.name}")
        if self._callback:
            await self._callback(event_data)


class WebhookTrigger(EventTrigger):
    """Webhook 기반 트리거.

    외부 시스템에서 HTTP POST로 이벤트를 수신합니다.
    FastAPI 라우터에 등록하여 사용합니다.

    Args:
        name: 트리거 이름
        path: 웹훅 경로 (예: "/webhook/github")
        secret: 인증용 시크릿 키
        callback: 이벤트 발생 시 호출할 콜백
    """

    def __init__(
        self,
        name: str,
        path: str = "/webhook",
        secret: str = "",
        callback: Callable | None = None,
    ):
        super().__init__(name, callback)
        self.path = path
        self.secret = secret

    async def start(self) -> None:
        self._active = True
        logger.info(f"🔗 Webhook 트리거 활성화: {self.name} ({self.path})")

    async def stop(self) -> None:
        self._active = False
        logger.info(f"🔗 Webhook 트리거 비활성화: {self.name}")

    async def handle_webhook(self, payload: dict[str, Any]) -> dict[str, str]:
        """웹훅 요청 처리.

        Args:
            payload: POST 요청 바디

        Returns:
            처리 결과
        """
        if not self._active:
            return {"status": "inactive"}

        await self.fire({"type": "webhook", "path": self.path, "payload": payload})
        return {"status": "triggered", "trigger": self.name}


class FileWatchTrigger(EventTrigger):
    """파일 변경 감지 트리거.

    지정된 디렉토리의 파일 변경을 감시하고, 변경 감지 시 워크플로를 시작합니다.
    watchdog 패키지의 간이 대체 구현입니다.

    Args:
        name: 트리거 이름
        watch_path: 감시할 디렉토리 경로
        patterns: 감시할 파일 패턴 (예: ["*.pdf", "*.docx"])
        callback: 변경 감지 시 호출할 콜백
    """

    def __init__(
        self,
        name: str,
        watch_path: str = ".",
        patterns: list[str] | None = None,
        callback: Callable | None = None,
    ):
        super().__init__(name, callback)
        self.watch_path = watch_path
        self.patterns = patterns or ["*"]
        self._file_states: dict[str, float] = {}

    async def start(self) -> None:
        self._active = True
        self._scan_files()
        logger.info(
            f"📁 파일 감시 트리거 활성화: {self.name} "
            f"({self.watch_path}, patterns={self.patterns})"
        )

    async def stop(self) -> None:
        self._active = False
        logger.info(f"📁 파일 감시 트리거 비활성화: {self.name}")

    def _scan_files(self) -> None:
        """현재 파일 상태 스캔."""
        from pathlib import Path
        import fnmatch

        watch = Path(self.watch_path)
        if not watch.exists():
            return

        for pattern in self.patterns:
            for f in watch.rglob(pattern):
                if f.is_file():
                    self._file_states[str(f)] = f.stat().st_mtime

    async def check_changes(self) -> list[dict[str, Any]]:
        """파일 변경 확인 및 이벤트 발생.

        Returns:
            변경된 파일 목록
        """
        from pathlib import Path
        import fnmatch

        changes = []
        watch = Path(self.watch_path)
        if not watch.exists():
            return changes

        current_files: dict[str, float] = {}
        for pattern in self.patterns:
            for f in watch.rglob(pattern):
                if f.is_file():
                    current_files[str(f)] = f.stat().st_mtime

        # 새 파일 또는 수정된 파일 감지
        for fpath, mtime in current_files.items():
            old_mtime = self._file_states.get(fpath)
            if old_mtime is None:
                changes.append({"file": fpath, "event": "created"})
            elif mtime > old_mtime:
                changes.append({"file": fpath, "event": "modified"})

        # 삭제된 파일 감지
        for fpath in self._file_states:
            if fpath not in current_files:
                changes.append({"file": fpath, "event": "deleted"})

        self._file_states = current_files

        # 변경이 있으면 이벤트 발생
        if changes and self._active:
            await self.fire({"type": "file_change", "changes": changes})

        return changes
