"""CronScheduler — CRON 기반 워크플로 스케줄링 (FR-OC-04.1)

APScheduler 기반으로 CRON 표현식에 따라 워크플로를 정기 실행합니다.
APScheduler가 없는 환경에서는 간이 스레드 기반 스케줄러를 사용합니다.
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger("dapparena_wsp.scheduler.cron")


class CronScheduler:
    """CRON 기반 워크플로 스케줄러.

    Args:
        db_path: 스케줄 DB 경로

    Example:
        scheduler = CronScheduler()
        scheduler.schedule(
            cron="0 9 * * 1",
            workflow="weekly_review",
            channels=["slack:#lab", "telegram:@WSPBot"],
            params={"topic": "AI 논문", "count": 5},
        )
        scheduler.start()
    """

    def __init__(self, db_path: str = "scheduler.db"):
        self.db_path = db_path
        self._jobs: dict[str, dict[str, Any]] = {}
        self._running = False
        self._thread: threading.Thread | None = None
        self._ensure_db()

    def _ensure_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS scheduled_jobs (
                    id          TEXT PRIMARY KEY,
                    cron_expr   TEXT NOT NULL,
                    workflow    TEXT NOT NULL,
                    channels    TEXT DEFAULT '[]',
                    params      TEXT DEFAULT '{}',
                    enabled     INTEGER DEFAULT 1,
                    last_run    DATETIME,
                    next_run    DATETIME,
                    run_count   INTEGER DEFAULT 0,
                    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS job_history (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id      TEXT NOT NULL,
                    status      TEXT NOT NULL,
                    started_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    completed_at DATETIME,
                    result      TEXT DEFAULT '',
                    error       TEXT DEFAULT ''
                )
            """)

    def schedule(
        self,
        cron: str,
        workflow: str,
        channels: list[str] | None = None,
        params: dict[str, Any] | None = None,
        job_id: str | None = None,
    ) -> str:
        """CRON 스케줄 등록.

        Args:
            cron: CRON 표현식 (예: "0 9 * * 1" = 매주 월요일 09시)
            workflow: 워크플로 이름 또는 YAML 경로
            channels: 결과 전달 채널 목록
            params: 워크플로 파라미터
            job_id: 작업 ID (None이면 자동 생성)

        Returns:
            등록된 작업 ID
        """
        import json

        jid = job_id or str(uuid.uuid4())[:8]
        channels = channels or []
        params = params or {}

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO scheduled_jobs (id, cron_expr, workflow, channels, params)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(id) DO UPDATE SET
                    cron_expr=excluded.cron_expr,
                    workflow=excluded.workflow,
                    channels=excluded.channels,
                    params=excluded.params""",
                (jid, cron, workflow,
                 json.dumps(channels), json.dumps(params, ensure_ascii=False)),
            )

        self._jobs[jid] = {
            "cron": cron,
            "workflow": workflow,
            "channels": channels,
            "params": params,
            "enabled": True,
        }

        logger.info(f"⏰ 스케줄 등록: {jid} — cron={cron}, workflow={workflow}")
        return jid

    def unschedule(self, job_id: str) -> bool:
        """스케줄 해제."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM scheduled_jobs WHERE id=?", (job_id,),
            )
        self._jobs.pop(job_id, None)
        return cursor.rowcount > 0

    def list_jobs(self) -> list[dict[str, Any]]:
        """등록된 스케줄 목록 반환."""
        import json
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM scheduled_jobs ORDER BY created_at DESC"
            ).fetchall()

        return [
            {
                "id": r["id"],
                "cron": r["cron_expr"],
                "workflow": r["workflow"],
                "channels": json.loads(r["channels"] or "[]"),
                "params": json.loads(r["params"] or "{}"),
                "enabled": bool(r["enabled"]),
                "last_run": r["last_run"],
                "run_count": r["run_count"],
            }
            for r in rows
        ]

    def get_history(self, job_id: str, limit: int = 20) -> list[dict[str, Any]]:
        """작업 실행 이력 조회."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """SELECT * FROM job_history
                   WHERE job_id=? ORDER BY started_at DESC LIMIT ?""",
                (job_id, limit),
            ).fetchall()

        return [
            {
                "id": r["id"],
                "job_id": r["job_id"],
                "status": r["status"],
                "started_at": r["started_at"],
                "completed_at": r["completed_at"],
                "error": r["error"],
            }
            for r in rows
        ]

    def record_run(self, job_id: str, status: str, error: str = "") -> None:
        """실행 결과 기록."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO job_history (job_id, status, completed_at, error)
                   VALUES (?, ?, CURRENT_TIMESTAMP, ?)""",
                (job_id, status, error),
            )
            conn.execute(
                """UPDATE scheduled_jobs
                   SET last_run=CURRENT_TIMESTAMP, run_count=run_count+1
                   WHERE id=?""",
                (job_id,),
            )

    def start(self) -> None:
        """스케줄러 백그라운드 스레드 시작."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        logger.info("⏰ CronScheduler 시작")

    def stop(self) -> None:
        """스케줄러 중지."""
        self._running = False
        logger.info("⏰ CronScheduler 중지")

    def _run_loop(self) -> None:
        """메인 스케줄 루프 (간이 구현 — 1분 간격 체크)."""
        while self._running:
            try:
                self._check_and_run()
            except Exception as e:
                logger.error(f"스케줄 루프 오류: {e}")
            time.sleep(60)

    def _check_and_run(self) -> None:
        """현재 시간에 실행할 작업이 있는지 확인."""
        now = datetime.now()
        for jid, job in self._jobs.items():
            if not job.get("enabled"):
                continue
            if self._cron_matches(job["cron"], now):
                logger.info(f"⏰ 스케줄 실행: {jid} — {job['workflow']}")
                self.record_run(jid, "triggered")

    @staticmethod
    def _cron_matches(cron_expr: str, dt: datetime) -> bool:
        """간이 CRON 매칭 (분 시 일 월 요일).

        정밀한 CRON 파싱은 croniter 패키지 사용을 권장합니다.
        """
        parts = cron_expr.strip().split()
        if len(parts) != 5:
            return False

        checks = [
            (parts[0], dt.minute),    # 분
            (parts[1], dt.hour),      # 시
            (parts[2], dt.day),       # 일
            (parts[3], dt.month),     # 월
            (parts[4], dt.isoweekday() % 7),  # 요일 (0=일, 1=월, ...)
        ]

        for pattern, value in checks:
            if pattern == "*":
                continue
            try:
                if int(pattern) != value:
                    return False
            except ValueError:
                continue  # 복잡한 패턴(범위, 목록)은 무시

        return True
