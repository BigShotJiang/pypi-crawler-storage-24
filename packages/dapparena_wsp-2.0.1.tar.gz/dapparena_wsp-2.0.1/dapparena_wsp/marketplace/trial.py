"""TrialManager — 에이전트 무료 체험 세션 관리 (FR-OC-07.1, FR-OC-07.2)"""

from __future__ import annotations
import logging
from typing import Any

from .quota import QuotaManager

logger = logging.getLogger("dapparena_wsp.marketplace.trial")


class TrialManager:
    """에이전트 체험 세션 관리.

    QuotaManager와 연동하여 무료 체험 횟수를 관리하고,
    체험 실행 시 에이전트를 호출합니다.

    Args:
        quota: QuotaManager 인스턴스
    """

    def __init__(self, quota: QuotaManager | None = None):
        self.quota = quota or QuotaManager()

    async def start_trial(
        self,
        agent_id: str,
        agent_url: str,
        user_id: str,
        message: str,
    ) -> dict[str, Any]:
        """에이전트 무료 체험 실행.

        Args:
            agent_id: 에이전트 식별자
            agent_url: 에이전트 서버 URL
            user_id: 사용자 식별자
            message: 체험 메시지

        Returns:
            {"status": "ok" | "quota_exceeded", "response": ..., "quota": ...}
        """
        # 쿼터 확인
        quota_info = self.quota.check_quota(user_id, agent_id)
        if not quota_info["allowed"]:
            return {
                "status": "quota_exceeded",
                "message": f"일일 무료 체험 한도({quota_info['limit']}회)를 초과했습니다.",
                "quota": quota_info,
            }

        # 쿼터 소비
        self.quota.consume(user_id, agent_id)

        # 에이전트 호출
        try:
            from ..a2a.client import A2AClientV2
            from ..a2a.models import Task

            client = A2AClientV2(timeout=120)
            task = Task(message=message, metadata={"user_id": user_id, "trial": True})
            result = await client.send_task_with_retry(agent_url, task)

            response_text = ""
            if result.artifacts:
                first = result.artifacts[0]
                if isinstance(first.data, str):
                    response_text = first.data
                elif isinstance(first.data, dict):
                    response_text = first.data.get("text", str(first.data))
                else:
                    response_text = str(first.data)

            return {
                "status": "ok",
                "response": response_text,
                "artifacts_count": len(result.artifacts),
                "quota": self.quota.check_quota(user_id, agent_id),
            }

        except Exception as e:
            logger.error(f"체험 실행 실패: {e}")
            return {"status": "error", "message": str(e), "quota": quota_info}
