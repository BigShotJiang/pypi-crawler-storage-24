"""QuotaManager — 사용자별 에이전트 체험 쿼터 관리 (FR-OC-07.1)"""

from __future__ import annotations
import json, logging, sqlite3
from datetime import date
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.marketplace.quota")


class QuotaManager:
    """사용자별·에이전트별 일일 무료 체험 쿼터 관리.

    Args:
        db_path: SQLite DB 경로
        daily_limit: 에이전트당 일일 무료 체험 횟수
    """

    def __init__(self, db_path: str = "marketplace.db", daily_limit: int = 5):
        self.db_path = db_path
        self.daily_limit = daily_limit
        self._ensure_db()

    def _ensure_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS usage_quota (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id     TEXT NOT NULL,
                    agent_id    TEXT NOT NULL,
                    usage_date  TEXT NOT NULL,
                    usage_count INTEGER DEFAULT 0,
                    UNIQUE(user_id, agent_id, usage_date)
                )
            """)

    def check_quota(self, user_id: str, agent_id: str) -> dict[str, Any]:
        """남은 쿼터 확인.

        Returns:
            {"remaining": int, "used": int, "limit": int, "allowed": bool}
        """
        today = date.today().isoformat()
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT usage_count FROM usage_quota WHERE user_id=? AND agent_id=? AND usage_date=?",
                (user_id, agent_id, today),
            ).fetchone()

        used = row[0] if row else 0
        remaining = max(0, self.daily_limit - used)
        return {"remaining": remaining, "used": used, "limit": self.daily_limit, "allowed": remaining > 0}

    def consume(self, user_id: str, agent_id: str) -> bool:
        """쿼터 1회 소비. 초과 시 False 반환."""
        today = date.today().isoformat()
        quota = self.check_quota(user_id, agent_id)
        if not quota["allowed"]:
            return False

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO usage_quota (user_id, agent_id, usage_date, usage_count)
                   VALUES (?, ?, ?, 1)
                   ON CONFLICT(user_id, agent_id, usage_date)
                   DO UPDATE SET usage_count = usage_count + 1""",
                (user_id, agent_id, today),
            )
        return True
