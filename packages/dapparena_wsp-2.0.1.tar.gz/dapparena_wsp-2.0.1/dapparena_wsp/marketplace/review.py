"""ReviewManager — 에이전트 별점/리뷰 관리 (FR-OC-07.3)"""

from __future__ import annotations
import json, logging, sqlite3, uuid
from pathlib import Path
from typing import Any

logger = logging.getLogger("dapparena_wsp.marketplace.review")


class ReviewManager:
    """에이전트 별점/리뷰 CRUD + 평균 별점 계산.

    Args:
        db_path: SQLite DB 경로
    """

    def __init__(self, db_path: str = "marketplace.db"):
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    id          TEXT PRIMARY KEY,
                    agent_id    TEXT NOT NULL,
                    user_id     TEXT NOT NULL,
                    rating      INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
                    comment     TEXT DEFAULT '',
                    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(agent_id, user_id)
                )
            """)

    def create_review(self, agent_id: str, user_id: str, rating: int, comment: str = "") -> dict:
        """리뷰 작성 (upsert)."""
        rid = str(uuid.uuid4())[:8]
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO reviews (id, agent_id, user_id, rating, comment)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(agent_id, user_id)
                   DO UPDATE SET rating=excluded.rating, comment=excluded.comment, created_at=CURRENT_TIMESTAMP""",
                (rid, agent_id, user_id, rating, comment),
            )
        return {"id": rid, "agent_id": agent_id, "rating": rating}

    def get_reviews(self, agent_id: str, limit: int = 50) -> list[dict]:
        """에이전트 리뷰 목록."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM reviews WHERE agent_id=? ORDER BY created_at DESC LIMIT ?",
                (agent_id, limit),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_stats(self, agent_id: str) -> dict:
        """에이전트 리뷰 통계."""
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT COUNT(*) as cnt, AVG(rating) as avg_r FROM reviews WHERE agent_id=?",
                (agent_id,),
            ).fetchone()
        return {
            "agent_id": agent_id,
            "review_count": row[0] or 0,
            "average_rating": round(row[1], 1) if row[1] else 0.0,
        }
