"""PII 자동 감지/마스킹 모듈 (S2-08)

전화번호, 이메일, 학번 등 개인 식별 정보를 자동으로 마스킹합니다.
마스킹된 텍스트를 외부 API에 전달하고, 결과에서 원본을 복원할 수 있습니다.
"""

from __future__ import annotations

import logging
import re
import uuid
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("dapparena_wsp.security.pii_masker")


@dataclass
class MaskMapping:
    """마스킹 매핑 정보."""
    placeholder: str
    original: str
    pii_type: str


class PIIMasker:
    """PII 자동 감지/마스킹.

    Example:
        masker = PIIMasker()
        masked, mapping = masker.mask("학생 010-1234-5678의 이메일")
        # → "학생 [PHONE_MASKED_1]의 이메일"
        original = masker.unmask(masked, mapping)
        # → "학생 010-1234-5678의 이메일"
    """

    # PII 감지 패턴 (우선순위 순서)
    PATTERNS = [
        ("주민번호", re.compile(r"\b(\d{6})[-\s]?(\d{7})\b"), "RRN_MASKED"),
        ("전화번호", re.compile(r"\b(01[016789])[-\s.]?(\d{3,4})[-\s.]?(\d{4})\b"), "PHONE_MASKED"),
        ("이메일", re.compile(r"\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,})\b"), "EMAIL_MASKED"),
        ("학번", re.compile(r"\b(20\d{2})[-\s]?(\d{5,6})\b"), "STUDENT_ID_MASKED"),
        ("사업자번호", re.compile(r"\b(\d{3})[-\s]?(\d{2})[-\s]?(\d{5})\b"), "BIZ_NUM_MASKED"),
        ("IP주소", re.compile(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b"), "IP_MASKED"),
        ("카드번호", re.compile(r"\b(\d{4})[-\s]?(\d{4})[-\s]?(\d{4})[-\s]?(\d{4})\b"), "CARD_MASKED"),
    ]

    def mask(self, text: str) -> tuple[str, list[MaskMapping]]:
        """텍스트에서 PII를 감지하고 마스킹합니다.

        Args:
            text: 원본 텍스트

        Returns:
            (마스킹된 텍스트, 매핑 정보 리스트)
        """
        mappings: list[MaskMapping] = []
        masked_text = text
        counter: dict[str, int] = {}

        for pii_type, pattern, placeholder_base in self.PATTERNS:
            matches = list(pattern.finditer(masked_text))
            # 역순으로 처리하여 인덱스가 밀리지 않도록
            for match in reversed(matches):
                original = match.group(0)
                counter[placeholder_base] = counter.get(placeholder_base, 0) + 1
                placeholder = f"[{placeholder_base}_{counter[placeholder_base]}]"

                mappings.append(MaskMapping(
                    placeholder=placeholder,
                    original=original,
                    pii_type=pii_type,
                ))

                masked_text = (
                    masked_text[:match.start()]
                    + placeholder
                    + masked_text[match.end():]
                )

        if mappings:
            logger.info(f"🛡️ PII 마스킹: {len(mappings)}건 ({', '.join(m.pii_type for m in mappings)})")

        return masked_text, mappings

    def unmask(self, text: str, mappings: list[MaskMapping]) -> str:
        """마스킹된 텍스트를 원본으로 복원합니다.

        Args:
            text: 마스킹된 텍스트
            mappings: mask() 호출 시 반환된 매핑 정보

        Returns:
            원본 복원된 텍스트
        """
        result = text
        for mapping in mappings:
            result = result.replace(mapping.placeholder, mapping.original)
        return result

    def has_pii(self, text: str) -> bool:
        """텍스트에 PII가 포함되어 있는지 확인합니다."""
        for _, pattern, _ in self.PATTERNS:
            if pattern.search(text):
                return True
        return False

    def detect(self, text: str) -> list[dict[str, Any]]:
        """텍스트에서 PII를 감지하고 위치를 반환합니다."""
        found = []
        for pii_type, pattern, _ in self.PATTERNS:
            for match in pattern.finditer(text):
                found.append({
                    "type": pii_type,
                    "value": match.group(0),
                    "start": match.start(),
                    "end": match.end(),
                })
        return found
