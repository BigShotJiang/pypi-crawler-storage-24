"""Model evaluation stage."""
