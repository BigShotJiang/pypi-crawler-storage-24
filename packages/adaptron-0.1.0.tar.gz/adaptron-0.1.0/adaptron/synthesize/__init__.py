"""Synthetic dataset generation stage."""
