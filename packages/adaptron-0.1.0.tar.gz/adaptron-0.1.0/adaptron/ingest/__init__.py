"""Data ingestion stage."""
