"""Universal data connector framework."""
