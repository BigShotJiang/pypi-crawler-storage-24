"""RAG (Retrieval-Augmented Generation) module."""
