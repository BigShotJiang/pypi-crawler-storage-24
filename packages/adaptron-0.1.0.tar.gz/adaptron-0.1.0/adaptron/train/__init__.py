"""Model training stage."""
