"""AISpendGuard client — batched, threaded event transport."""

from __future__ import annotations

import atexit
import logging
import threading
from typing import Any, Dict, List, Optional, Union

import httpx

from .event import UsageEvent
from .validate import validate_event

logger = logging.getLogger("aispendguard")

DEFAULT_ENDPOINT = "https://www.aispendguard.com/api/ingest"
DEFAULT_BATCH_SIZE = 10
DEFAULT_FLUSH_INTERVAL = 5.0
DEFAULT_TIMEOUT = 10.0


class AISpendGuard:
    """Client for sending usage events to AISpendGuard.

    Events are buffered and sent in batches via a background thread.
    Call flush() before exit or use as a context manager.

    Example::

        from aispendguard import AISpendGuard, create_openai_event

        client = AISpendGuard(api_key="asg_...")

        event = create_openai_event(
            model="gpt-4o-mini",
            usage=response.usage,
            latency_ms=420,
            tags={"task_type": "classify", "feature": "triage", "route": "POST /api/classify"},
        )
        client.track(event)
    """

    def __init__(
        self,
        *,
        api_key: str,
        endpoint: str = DEFAULT_ENDPOINT,
        batch_size: int = DEFAULT_BATCH_SIZE,
        flush_interval: float = DEFAULT_FLUSH_INTERVAL,
        timeout: float = DEFAULT_TIMEOUT,
        strict: bool = False,
        default_tags: Optional[Dict[str, Any]] = None,
    ):
        if not api_key:
            raise ValueError("api_key is required")

        self._api_key = api_key
        self._endpoint = endpoint
        self._batch_size = max(1, batch_size)
        self._flush_interval = flush_interval
        self._strict = strict
        self._default_tags = default_tags or {}

        self._http = httpx.Client(
            timeout=timeout,
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
            },
        )

        self._queue: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._stop = threading.Event()

        self._thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._thread.start()

        atexit.register(self._shutdown)

    # ── Public API ────────────────────────────────────────────────────────

    def track(self, event: UsageEvent) -> None:
        """Queue an event for sending. Validates and merges default tags."""
        # Merge default tags (event tags take precedence)
        if self._default_tags:
            merged = {**self._default_tags, **event.tags}
            event.tags = merged

        errors = validate_event(event)
        if errors:
            msg = f"[aispendguard] invalid event: {'; '.join(errors)}"
            if self._strict:
                raise ValueError(msg)
            logger.warning(msg)
            return

        payload = event.to_dict()

        with self._lock:
            self._queue.append(payload)
            should_flush = len(self._queue) >= self._batch_size

        if should_flush:
            self._send_batch()

    def flush(self) -> None:
        """Send all queued events immediately."""
        self._send_batch()

    def close(self) -> None:
        """Flush remaining events and shut down the background thread."""
        self._shutdown()

    # ── Context manager ───────────────────────────────────────────────────

    def __enter__(self) -> "AISpendGuard":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Internal ──────────────────────────────────────────────────────────

    def _flush_loop(self) -> None:
        while not self._stop.wait(self._flush_interval):
            self._send_batch()

    def _send_batch(self) -> None:
        with self._lock:
            if not self._queue:
                return
            batch = self._queue[:]
            self._queue.clear()

        try:
            resp = self._http.post(self._endpoint, json={"events": batch})
            if resp.status_code >= 400:
                body = resp.text
                msg = f"[aispendguard] ingest failed ({self._endpoint}): HTTP {resp.status_code} — {body}"
                if self._strict:
                    raise RuntimeError(msg)
                logger.warning(msg)
        except httpx.HTTPError as exc:
            msg = f"[aispendguard] ingest failed ({self._endpoint}): {exc}"
            if self._strict:
                raise RuntimeError(msg) from exc
            logger.warning(msg)

    def _shutdown(self) -> None:
        self._stop.set()
        self._send_batch()
        try:
            self._http.close()
        except Exception:
            pass
