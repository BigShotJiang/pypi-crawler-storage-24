"""Usage event construction and provider helpers."""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

TagValue = Union[str, List[str]]


class UsageEvent:
    """A single AI API usage event to send to AISpendGuard."""

    def __init__(
        self,
        *,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        latency_ms: int,
        tags: Dict[str, TagValue],
        event_id: Optional[str] = None,
        resolved_model: Optional[str] = None,
        input_tokens_cached: Optional[int] = None,
        input_tokens_cache_write: Optional[int] = None,
        thinking_tokens: Optional[int] = None,
        cache_ttl: Optional[str] = None,
        web_search_count: Optional[int] = None,
        web_fetch_count: Optional[int] = None,
        is_batch_api: bool = False,
        is_fast_mode: bool = False,
        cost_usd: Optional[float] = None,
        timestamp: Optional[str] = None,
    ):
        self.event_id = event_id or f"py-{uuid.uuid4().hex[:16]}"
        self.provider = provider
        self.model = model
        self.resolved_model = resolved_model
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.input_tokens_cached = input_tokens_cached
        self.input_tokens_cache_write = input_tokens_cache_write
        self.thinking_tokens = thinking_tokens
        self.cache_ttl = cache_ttl
        self.web_search_count = web_search_count
        self.web_fetch_count = web_fetch_count
        self.is_batch_api = is_batch_api
        self.is_fast_mode = is_fast_mode
        self.latency_ms = latency_ms
        self.cost_usd = cost_usd
        self.timestamp = timestamp or datetime.now(timezone.utc).isoformat()
        self.tags = tags

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "event_id": self.event_id,
            "provider": self.provider,
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "latency_ms": self.latency_ms,
            "timestamp": self.timestamp,
            "tags": self.tags,
        }
        if self.resolved_model is not None:
            d["resolved_model"] = self.resolved_model
        if self.input_tokens_cached is not None:
            d["input_tokens_cached"] = self.input_tokens_cached
        if self.input_tokens_cache_write is not None:
            d["input_tokens_cache_write"] = self.input_tokens_cache_write
        if self.thinking_tokens is not None:
            d["thinking_tokens"] = self.thinking_tokens
        if self.cache_ttl is not None:
            d["cache_ttl"] = self.cache_ttl
        if self.web_search_count is not None:
            d["web_search_count"] = self.web_search_count
        if self.web_fetch_count is not None:
            d["web_fetch_count"] = self.web_fetch_count
        if self.is_batch_api:
            d["is_batch_api"] = True
        if self.is_fast_mode:
            d["is_fast_mode"] = True
        if self.cost_usd is not None:
            d["cost_usd"] = self.cost_usd
        return d


def create_openai_event(
    *,
    model: str,
    usage: Any,
    latency_ms: int,
    tags: Dict[str, TagValue],
    resolved_model: Optional[str] = None,
    cost_usd: Optional[float] = None,
) -> UsageEvent:
    """Create a UsageEvent from an OpenAI response's usage object.

    Works with both openai.types.CompletionUsage and response dicts.
    """
    if hasattr(usage, "prompt_tokens"):
        input_tokens = usage.prompt_tokens or 0
        output_tokens = usage.completion_tokens or 0
        cached = getattr(usage, "prompt_tokens_details", None)
        input_cached = getattr(cached, "cached_tokens", None) if cached else None
        reasoning = getattr(usage, "completion_tokens_details", None)
        thinking = getattr(reasoning, "reasoning_tokens", None) if reasoning else None
    elif isinstance(usage, dict):
        input_tokens = usage.get("prompt_tokens", 0) or 0
        output_tokens = usage.get("completion_tokens", 0) or 0
        details = usage.get("prompt_tokens_details", {}) or {}
        input_cached = details.get("cached_tokens")
        comp_details = usage.get("completion_tokens_details", {}) or {}
        thinking = comp_details.get("reasoning_tokens")
    else:
        input_tokens = 0
        output_tokens = 0
        input_cached = None
        thinking = None

    return UsageEvent(
        provider="openai",
        model=model,
        resolved_model=resolved_model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        input_tokens_cached=input_cached,
        thinking_tokens=thinking,
        latency_ms=latency_ms,
        cost_usd=cost_usd,
        tags=tags,
    )


def create_anthropic_event(
    *,
    model: str,
    usage: Any,
    latency_ms: int,
    tags: Dict[str, TagValue],
    resolved_model: Optional[str] = None,
    cost_usd: Optional[float] = None,
) -> UsageEvent:
    """Create a UsageEvent from an Anthropic message's usage object."""
    if hasattr(usage, "input_tokens"):
        input_tokens = usage.input_tokens or 0
        output_tokens = usage.output_tokens or 0
        input_cached = getattr(usage, "cache_read_input_tokens", None)
        cache_write = getattr(usage, "cache_creation_input_tokens", None)
    elif isinstance(usage, dict):
        input_tokens = usage.get("input_tokens", 0) or 0
        output_tokens = usage.get("output_tokens", 0) or 0
        input_cached = usage.get("cache_read_input_tokens")
        cache_write = usage.get("cache_creation_input_tokens")
    else:
        input_tokens = 0
        output_tokens = 0
        input_cached = None
        cache_write = None

    return UsageEvent(
        provider="anthropic",
        model=model,
        resolved_model=resolved_model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        input_tokens_cached=input_cached,
        input_tokens_cache_write=cache_write,
        latency_ms=latency_ms,
        cost_usd=cost_usd,
        tags=tags,
    )


def create_gemini_event(
    *,
    model: str,
    usage: Any,
    latency_ms: int,
    tags: Dict[str, TagValue],
    resolved_model: Optional[str] = None,
    cost_usd: Optional[float] = None,
) -> UsageEvent:
    """Create a UsageEvent from a Google Gemini usage_metadata object."""
    if hasattr(usage, "prompt_token_count"):
        input_tokens = usage.prompt_token_count or 0
        output_tokens = usage.candidates_token_count or 0
        cached = getattr(usage, "cached_content_token_count", None)
        thinking = getattr(usage, "thoughts_token_count", None)
    elif isinstance(usage, dict):
        input_tokens = usage.get("prompt_token_count", 0) or 0
        output_tokens = usage.get("candidates_token_count", 0) or 0
        cached = usage.get("cached_content_token_count")
        thinking = usage.get("thoughts_token_count")
    else:
        input_tokens = 0
        output_tokens = 0
        cached = None
        thinking = None

    return UsageEvent(
        provider="google",
        model=model,
        resolved_model=resolved_model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        input_tokens_cached=cached,
        thinking_tokens=thinking,
        latency_ms=latency_ms,
        cost_usd=cost_usd,
        tags=tags,
    )
