"""Event validation — matches the TypeScript SDK and server-side rules."""

from __future__ import annotations

from typing import List

from .event import UsageEvent

REQUIRED_TAGS = ("task_type", "feature", "route")

FORBIDDEN_KEYS = frozenset({
    "prompt", "messages", "input", "output", "completion", "content",
    "message", "response", "text", "body", "context", "system",
    "assistant", "human", "user_message", "assistant_message",
    "system_message", "chat_history", "conversation",
    "function_call", "tool_calls", "tool_results",
    "image", "audio", "file", "attachment",
})

MAX_TAGS = 24
MAX_ARRAY_VALUES = 16
MAX_VALUE_LENGTH = 120


def validate_event(event: UsageEvent) -> List[str]:
    """Validate an event and return a list of error messages (empty = valid)."""
    errors: List[str] = []

    if not event.provider:
        errors.append("provider is required")
    if not event.model:
        errors.append("model is required")
    if event.input_tokens < 0:
        errors.append("input_tokens must be >= 0")
    if event.output_tokens < 0:
        errors.append("output_tokens must be >= 0")
    if event.latency_ms < 0:
        errors.append("latency_ms must be >= 0")

    tags = event.tags
    if not isinstance(tags, dict):
        errors.append("tags must be a dict")
        return errors

    for key in REQUIRED_TAGS:
        if key not in tags or not tags[key]:
            errors.append(f"missing required tag: {key}")

    if len(tags) > MAX_TAGS:
        errors.append(f"too many tags: {len(tags)} (max {MAX_TAGS})")

    for key, value in tags.items():
        lower = key.lower()
        if lower in FORBIDDEN_KEYS:
            errors.append(f"forbidden tag key: {key}")
            continue

        if isinstance(value, str):
            if len(value) > MAX_VALUE_LENGTH:
                errors.append(f"tag '{key}' value too long: {len(value)} chars (max {MAX_VALUE_LENGTH})")
        elif isinstance(value, list):
            if len(value) > MAX_ARRAY_VALUES:
                errors.append(f"tag '{key}' array too long: {len(value)} items (max {MAX_ARRAY_VALUES})")
            for item in value:
                if not isinstance(item, str):
                    errors.append(f"tag '{key}' array items must be strings")
                    break
                if len(item) > MAX_VALUE_LENGTH:
                    errors.append(f"tag '{key}' array item too long: {len(item)} chars (max {MAX_VALUE_LENGTH})")
        else:
            errors.append(f"tag '{key}' must be str or list[str]")

    return errors
