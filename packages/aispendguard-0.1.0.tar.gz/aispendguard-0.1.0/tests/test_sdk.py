"""Tests for the AISpendGuard Python SDK."""

import json
import pytest
from aispendguard import (
    AISpendGuard,
    UsageEvent,
    create_openai_event,
    create_anthropic_event,
    create_gemini_event,
    validate_event,
)


# ── Event construction ────────────────────────────────────────────────────


class TestUsageEvent:
    def test_basic_event(self):
        event = UsageEvent(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=100,
            output_tokens=20,
            latency_ms=500,
            tags={"task_type": "classify", "feature": "triage", "route": "POST /api/classify"},
        )
        d = event.to_dict()
        assert d["provider"] == "openai"
        assert d["model"] == "gpt-4o-mini"
        assert d["input_tokens"] == 100
        assert d["output_tokens"] == 20
        assert d["latency_ms"] == 500
        assert d["tags"]["task_type"] == "classify"
        assert "event_id" in d
        assert "timestamp" in d

    def test_optional_fields_excluded_when_none(self):
        event = UsageEvent(
            provider="openai",
            model="gpt-4o",
            input_tokens=50,
            output_tokens=10,
            latency_ms=200,
            tags={"task_type": "classify", "feature": "x", "route": "GET /"},
        )
        d = event.to_dict()
        assert "resolved_model" not in d
        assert "input_tokens_cached" not in d
        assert "thinking_tokens" not in d
        assert "is_batch_api" not in d
        assert "cost_usd" not in d

    def test_optional_fields_included_when_set(self):
        event = UsageEvent(
            provider="openai",
            model="o3",
            input_tokens=100,
            output_tokens=50,
            latency_ms=1000,
            thinking_tokens=30,
            is_batch_api=True,
            cost_usd=0.05,
            tags={"task_type": "code", "feature": "review", "route": "POST /api/review"},
        )
        d = event.to_dict()
        assert d["thinking_tokens"] == 30
        assert d["is_batch_api"] is True
        assert d["cost_usd"] == 0.05


# ── Provider helpers ──────────────────────────────────────────────────────


class TestOpenAIHelper:
    def test_from_dict_usage(self):
        usage = {
            "prompt_tokens": 120,
            "completion_tokens": 30,
            "prompt_tokens_details": {"cached_tokens": 50},
            "completion_tokens_details": {"reasoning_tokens": 10},
        }
        event = create_openai_event(
            model="gpt-4o-mini",
            usage=usage,
            latency_ms=400,
            tags={"task_type": "classify", "feature": "x", "route": "POST /x"},
        )
        assert event.provider == "openai"
        assert event.input_tokens == 120
        assert event.output_tokens == 30
        assert event.input_tokens_cached == 50
        assert event.thinking_tokens == 10

    def test_from_object_usage(self):
        class Usage:
            prompt_tokens = 200
            completion_tokens = 80
            prompt_tokens_details = None

        event = create_openai_event(
            model="gpt-4o",
            usage=Usage(),
            latency_ms=600,
            tags={"task_type": "generate", "feature": "x", "route": "POST /x"},
        )
        assert event.input_tokens == 200
        assert event.output_tokens == 80
        assert event.input_tokens_cached is None


class TestAnthropicHelper:
    def test_from_dict_usage(self):
        usage = {
            "input_tokens": 150,
            "output_tokens": 60,
            "cache_read_input_tokens": 40,
            "cache_creation_input_tokens": 20,
        }
        event = create_anthropic_event(
            model="claude-sonnet-4-20250514",
            usage=usage,
            latency_ms=800,
            tags={"task_type": "summarize", "feature": "x", "route": "POST /x"},
        )
        assert event.provider == "anthropic"
        assert event.input_tokens == 150
        assert event.input_tokens_cached == 40
        assert event.input_tokens_cache_write == 20


class TestGeminiHelper:
    def test_from_dict_usage(self):
        usage = {
            "prompt_token_count": 300,
            "candidates_token_count": 100,
            "cached_content_token_count": 50,
            "thoughts_token_count": 20,
        }
        event = create_gemini_event(
            model="gemini-2.5-flash",
            usage=usage,
            latency_ms=500,
            tags={"task_type": "answer", "feature": "x", "route": "POST /x"},
        )
        assert event.provider == "google"
        assert event.input_tokens == 300
        assert event.output_tokens == 100
        assert event.input_tokens_cached == 50
        assert event.thinking_tokens == 20


# ── Validation ────────────────────────────────────────────────────────────


class TestValidation:
    def test_valid_event(self):
        event = UsageEvent(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=100,
            output_tokens=20,
            latency_ms=500,
            tags={"task_type": "classify", "feature": "triage", "route": "POST /api/classify"},
        )
        assert validate_event(event) == []

    def test_missing_required_tags(self):
        event = UsageEvent(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=100,
            output_tokens=20,
            latency_ms=500,
            tags={"task_type": "classify"},
        )
        errors = validate_event(event)
        assert any("feature" in e for e in errors)
        assert any("route" in e for e in errors)

    def test_forbidden_tag_key(self):
        event = UsageEvent(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=100,
            output_tokens=20,
            latency_ms=500,
            tags={
                "task_type": "classify",
                "feature": "x",
                "route": "POST /x",
                "prompt": "secret data",
            },
        )
        errors = validate_event(event)
        assert any("forbidden" in e for e in errors)

    def test_too_many_tags(self):
        tags = {"task_type": "classify", "feature": "x", "route": "POST /x"}
        for i in range(25):
            tags[f"custom_{i}"] = "val"
        event = UsageEvent(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=100,
            output_tokens=20,
            latency_ms=500,
            tags=tags,
        )
        errors = validate_event(event)
        assert any("too many tags" in e for e in errors)

    def test_value_too_long(self):
        event = UsageEvent(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=100,
            output_tokens=20,
            latency_ms=500,
            tags={
                "task_type": "classify",
                "feature": "x" * 200,
                "route": "POST /x",
            },
        )
        errors = validate_event(event)
        assert any("too long" in e for e in errors)


# ── Privacy guard ─────────────────────────────────────────────────────────


class TestPrivacy:
    """Ensure no prompt/content data can leak through tags."""

    FORBIDDEN = [
        "prompt", "messages", "input", "output", "completion",
        "content", "message", "response", "text", "body",
    ]

    def test_forbidden_keys_rejected(self):
        for key in self.FORBIDDEN:
            event = UsageEvent(
                provider="openai",
                model="gpt-4o-mini",
                input_tokens=10,
                output_tokens=5,
                latency_ms=100,
                tags={
                    "task_type": "classify",
                    "feature": "x",
                    "route": "POST /x",
                    key: "secret",
                },
            )
            errors = validate_event(event)
            assert any("forbidden" in e for e in errors), f"Key '{key}' should be forbidden"
