# piwebapiconnect

A professional Python library for PI Web API integration.

## Installation

```bash
pip install -e ./piwebapiconnect
```

## Usage

### Using .env file
```python
from piwebapiconnect import get_service
service = get_service()
```

### Passing credentials directly
```python
from piwebapiconnect import get_service

service = get_service(
    url="https://your-pi-server/piwebapi",
    username="domain\\user",
    password="your-password",
    server_name="PISERVER01",
    verify_ssl=False  # Optional
)

async def main():
    val = await service.get_current_value("YourTagName")
    print(val)
```
