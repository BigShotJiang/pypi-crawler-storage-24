"""
Integration tests for the Ezop SDK.

These tests use the `responses` library to intercept HTTP calls at the network
level, exercising the full stack (Agent → EzopClient → requests → HTTP parsing)
without hitting a real server.

To run against the real Ezop API, set EZOP_API_KEY and EZOP_API_URL in your
environment and run:

    pytest tests/test_integration.py -m live -v

Live tests are skipped by default unless EZOP_API_KEY is present.
"""

import pytest
import responses as responses_lib
from responses import matchers
from ezop import Agent
from ezop.config import Config


BASE_URL = Config.EZOP_API_URL


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_AGENT_DATA = {
    "id": "integ-agent-001",
    "name": "integ-bot",
    "owner": "integ-team",
    "runtime": "claude",
    "description": "Integration test agent",
    "default_permissions": ["read:logs"],
}

_VERSION_DATA = {
    "id": "integ-version-001",
    "agent_id": "integ-agent-001",
    "version": "v1.0",
    "permissions": ["read:logs", "write:reports"],
    "changelog": "Integration test version",
}

_RUN_DATA = {
    "id": "integ-run-001",
    "status": "running",
}

_END_RUN_DATA = {
    "id": "integ-run-001",
    "status": "completed",
    "total_tokens": 1200,
    "total_cost": 0.024,
    "metadata": None,
}

def _wrap(data):
    return {"success": True, "data": data, "error": None}

AGENT_PAYLOAD = _wrap(_AGENT_DATA)
VERSION_PAYLOAD = _wrap(_VERSION_DATA)
RUN_PAYLOAD = _wrap(_RUN_DATA)
END_RUN_PAYLOAD = _wrap(_END_RUN_DATA)


def register_mock_endpoints():
    """Register all mock HTTP endpoints for a complete agent lifecycle."""
    responses_lib.add(
        responses_lib.POST,
        f"{BASE_URL}/agents/register",
        json=AGENT_PAYLOAD,
        status=201,
    )
    responses_lib.add(
        responses_lib.POST,
        f"{BASE_URL}/agents/integ-agent-001/versions",
        json=VERSION_PAYLOAD,
        status=201,
    )
    responses_lib.add(
        responses_lib.POST,
        f"{BASE_URL}/agents/integ-agent-001/runs",
        json=RUN_PAYLOAD,
        status=201,
    )
    responses_lib.add(
        responses_lib.PATCH,
        f"{BASE_URL}/runs/integ-run-001",
        json=END_RUN_PAYLOAD,
        status=200,
    )


# ---------------------------------------------------------------------------
# HTTP-level integration tests (no real network — responses intercepts)
# ---------------------------------------------------------------------------

class TestAgentInitHTTP:
    """Verify Agent.init() sends correct HTTP requests and parses responses."""

    @responses_lib.activate
    def test_register_agent_url_and_method(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json=AGENT_PAYLOAD, status=201)
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/integ-agent-001/versions",
                          json=VERSION_PAYLOAD, status=201)
        Agent.init(name="integ-bot", owner="integ-team", version="v1.0", runtime="claude")
        assert responses_lib.calls[0].request.method == "POST"
        assert responses_lib.calls[0].request.url == f"{BASE_URL}/agents/register"

    @responses_lib.activate
    def test_register_agent_request_body(self):
        import json
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json=AGENT_PAYLOAD, status=201)
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/integ-agent-001/versions",
                          json=VERSION_PAYLOAD, status=201)
        Agent.init(
            name="integ-bot",
            owner="integ-team",
            version="v1.0",
            runtime="claude",
            description="Integration test agent",
            default_permissions=["read:logs"],
        )
        body = json.loads(responses_lib.calls[0].request.body)
        assert body["name"] == "integ-bot"
        assert body["owner"] == "integ-team"
        assert body["runtime"] == "claude"
        assert body["description"] == "Integration test agent"
        assert body["default_permissions"] == ["read:logs"]

    @responses_lib.activate
    def test_register_agent_auth_header(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json=AGENT_PAYLOAD, status=201)
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/integ-agent-001/versions",
                          json=VERSION_PAYLOAD, status=201)
        Agent.init(name="integ-bot", owner="integ-team", version="v1.0", runtime="claude")
        auth = responses_lib.calls[0].request.headers.get("Authorization", "")
        assert auth.startswith("Bearer ")

    @responses_lib.activate
    def test_create_version_url_uses_agent_id(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json=AGENT_PAYLOAD, status=201)
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/integ-agent-001/versions",
                          json=VERSION_PAYLOAD, status=201)
        Agent.init(name="integ-bot", owner="integ-team", version="v1.0", runtime="claude")
        assert responses_lib.calls[1].request.url == f"{BASE_URL}/agents/integ-agent-001/versions"

    @responses_lib.activate
    def test_create_version_request_body(self):
        import json
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json=AGENT_PAYLOAD, status=201)
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/integ-agent-001/versions",
                          json=VERSION_PAYLOAD, status=201)
        Agent.init(
            name="integ-bot",
            owner="integ-team",
            version="v1.0",
            runtime="claude",
            permissions=["read:logs", "write:reports"],
            changelog="Integration test version",
        )
        body = json.loads(responses_lib.calls[1].request.body)
        assert body["version"] == "v1.0"
        assert body["permissions"] == ["read:logs", "write:reports"]
        assert body["changelog"] == "Integration test version"

    @responses_lib.activate
    def test_agent_built_correctly_from_responses(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json=AGENT_PAYLOAD, status=201)
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/integ-agent-001/versions",
                          json=VERSION_PAYLOAD, status=201)
        agent = Agent.init(
            name="integ-bot",
            owner="integ-team",
            version="v1.0",
            runtime="claude",
            description="Integration test agent",
            default_permissions=["read:logs"],
            permissions=["read:logs", "write:reports"],
            changelog="Integration test version",
        )
        assert agent.model.id == "integ-agent-001"
        assert agent.model.name == "integ-bot"
        assert agent.model.runtime == "claude"
        assert agent.version.id == "integ-version-001"
        assert agent.version.version == "v1.0"
        assert agent.version.permissions == ["read:logs", "write:reports"]

    @responses_lib.activate
    def test_api_400_raises_exception(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json={"error": "invalid payload"}, status=400)
        with pytest.raises(Exception, match="Ezop API error"):
            Agent.init(name="integ-bot", owner="integ-team", version="v1.0", runtime="claude")

    @responses_lib.activate
    def test_api_401_raises_exception(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json={"error": "unauthorized"}, status=401)
        with pytest.raises(Exception, match="Ezop API error"):
            Agent.init(name="integ-bot", owner="integ-team", version="v1.0", runtime="claude")

    @responses_lib.activate
    def test_api_500_raises_exception(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json={"error": "server error"}, status=500)
        with pytest.raises(Exception, match="Ezop API error"):
            Agent.init(name="integ-bot", owner="integ-team", version="v1.0", runtime="claude")


class TestRunLifecycleHTTP:
    """Verify start_run / end_run send correct HTTP requests."""

    def _make_agent(self):
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/register",
                          json=AGENT_PAYLOAD, status=201)
        responses_lib.add(responses_lib.POST, f"{BASE_URL}/agents/integ-agent-001/versions",
                          json=VERSION_PAYLOAD, status=201)
        return Agent.init(name="integ-bot", owner="integ-team", version="v1.0", runtime="claude")

    @responses_lib.activate
    def test_start_run_url_and_method(self):
        agent = self._make_agent()
        responses_lib.add(responses_lib.POST,
                          f"{BASE_URL}/agents/integ-agent-001/runs",
                          json=RUN_PAYLOAD, status=201)
        agent.start_run()
        last_call = responses_lib.calls[-1]
        assert last_call.request.method == "POST"
        assert last_call.request.url == f"{BASE_URL}/agents/integ-agent-001/runs"

    @responses_lib.activate
    def test_start_run_request_body_contains_version_id(self):
        import json
        agent = self._make_agent()
        responses_lib.add(responses_lib.POST,
                          f"{BASE_URL}/agents/integ-agent-001/runs",
                          json=RUN_PAYLOAD, status=201)
        agent.start_run()
        body = json.loads(responses_lib.calls[-1].request.body)
        assert body["version_id"] == "integ-version-001"

    @responses_lib.activate
    def test_start_run_returns_correct_run(self):
        agent = self._make_agent()
        responses_lib.add(responses_lib.POST,
                          f"{BASE_URL}/agents/integ-agent-001/runs",
                          json=RUN_PAYLOAD, status=201)
        run = agent.start_run()
        assert run.id == "integ-run-001"
        assert run.status == "running"
        assert run.agent_id == "integ-agent-001"
        assert run.version_id == "integ-version-001"

    @responses_lib.activate
    def test_end_run_url_and_method(self):
        agent = self._make_agent()
        responses_lib.add(responses_lib.POST,
                          f"{BASE_URL}/agents/integ-agent-001/runs",
                          json=RUN_PAYLOAD, status=201)
        responses_lib.add(responses_lib.PATCH,
                          f"{BASE_URL}/runs/integ-run-001",
                          json=END_RUN_PAYLOAD, status=200)
        agent.start_run()
        agent.end_run(status="completed", total_tokens=1200, total_cost=0.024)
        last_call = responses_lib.calls[-1]
        assert last_call.request.method == "PATCH"
        assert last_call.request.url == f"{BASE_URL}/runs/integ-run-001"

    @responses_lib.activate
    def test_end_run_request_body(self):
        import json
        agent = self._make_agent()
        responses_lib.add(responses_lib.POST,
                          f"{BASE_URL}/agents/integ-agent-001/runs",
                          json=RUN_PAYLOAD, status=201)
        responses_lib.add(responses_lib.PATCH,
                          f"{BASE_URL}/runs/integ-run-001",
                          json=END_RUN_PAYLOAD, status=200)
        agent.start_run()
        agent.end_run(
            status="completed",
            total_tokens=1200,
            total_cost=0.024,
            metadata={"user_id": "u-42"},
        )
        body = json.loads(responses_lib.calls[-1].request.body)
        assert body["status"] == "completed"
        assert body["total_tokens"] == 1200
        assert body["total_cost"] == 0.024
        assert body["metadata"] == {"user_id": "u-42"}

    @responses_lib.activate
    def test_end_run_body_omits_none_fields(self):
        import json
        agent = self._make_agent()
        responses_lib.add(responses_lib.POST,
                          f"{BASE_URL}/agents/integ-agent-001/runs",
                          json=RUN_PAYLOAD, status=201)
        responses_lib.add(responses_lib.PATCH,
                          f"{BASE_URL}/runs/integ-run-001",
                          json=_wrap({"id": "integ-run-001", "status": "failed", "total_tokens": None, "total_cost": None, "metadata": None}), status=200)
        agent.start_run()
        agent.end_run(status="failed")
        body = json.loads(responses_lib.calls[-1].request.body)
        assert "total_tokens" not in body
        assert "total_cost" not in body
        assert "metadata" not in body

    @responses_lib.activate
    def test_end_run_updates_agent_state(self):
        agent = self._make_agent()
        responses_lib.add(responses_lib.POST,
                          f"{BASE_URL}/agents/integ-agent-001/runs",
                          json=RUN_PAYLOAD, status=201)
        responses_lib.add(responses_lib.PATCH,
                          f"{BASE_URL}/runs/integ-run-001",
                          json=END_RUN_PAYLOAD, status=200)
        agent.start_run()
        run = agent.end_run(status="completed", total_tokens=1200, total_cost=0.024)
        assert run.status == "completed"
        assert run.total_tokens == 1200
        assert run.total_cost == 0.024

    @responses_lib.activate
    def test_full_lifecycle(self):
        """Agent init → start_run → end_run, exactly 4 HTTP calls."""
        register_mock_endpoints()
        agent = Agent.init(
            name="integ-bot",
            owner="integ-team",
            version="v1.0",
            runtime="claude",
            description="Integration test agent",
            default_permissions=["read:logs"],
            permissions=["read:logs", "write:reports"],
            changelog="Integration test version",
        )
        run = agent.start_run()
        assert run.status == "running"
        result = agent.end_run(status="completed", total_tokens=1200, total_cost=0.024)
        assert result.status == "completed"
        assert len(responses_lib.calls) == 4
