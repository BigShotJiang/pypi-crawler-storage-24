from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime


@dataclass(frozen=True)
class AgentModel:
    id: str
    name: str
    owner: str
    runtime: Optional[str]
    description: Optional[str]
    default_permissions: list[str]


@dataclass(frozen=True)
class AgentVersion:
    id: str
    agent_id: str
    version: str
    permissions: list[str]
    changelog: Optional[str]


@dataclass
class AgentRun:
    id: str
    agent_id: str
    version_id: Optional[str]
    status: str
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    total_tokens: Optional[int] = None
    total_cost: Optional[float] = None
    metadata: Optional[dict] = None
