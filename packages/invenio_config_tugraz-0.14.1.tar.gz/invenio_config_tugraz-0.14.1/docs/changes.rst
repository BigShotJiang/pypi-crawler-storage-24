..
    Copyright (C) 2020 Mojib Wali.

    invenio-config-tugraz is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.


.. include:: ../CHANGES.rst
