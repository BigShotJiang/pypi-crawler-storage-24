..
    Copyright (C) 2020 Mojib Wali.

    invenio-config-tugraz is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.


.. include:: ../README.rst

User's Guide
------------

This part of the documentation will show you how to get started in using
invenio-config-tugraz.

.. toctree::
   :maxdepth: 2

   installation
   configuration
   usage

API Reference
-------------

If you are looking for information on a specific function, class or method,
this part of the documentation is for you.

.. toctree::
   :maxdepth: 2

   api

Additional Notes
----------------

Notes on how to contribute, legal information and changes are here for the
interested.

.. toctree::
   :maxdepth: 1

   contributing
   changes
   license
   authors
