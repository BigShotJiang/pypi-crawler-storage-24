import requests

SERVER_URL = "https://lecyborgnextgen.pythonanywhere.com"

def register_node(node_id):
    try:
        r = requests.post(f"{SERVER_URL}/register", json={"node_id": node_id}, timeout=3)
        return r.json()
    except Exception as e:
        return {"error": str(e)}

def submit_tasks_batch(node_id, tasks_list):
    try:
        r = requests.post(
            f"{SERVER_URL}/submit_tasks_batch",
            json={"node_id": node_id, "tasks": tasks_list},
            timeout=5
        )
        return r.json()
    except Exception as e:
        return [{"error": str(e)} for _ in tasks_list]

def request_tasks_batch(node_id, batch_size=25):
    try:
        r = requests.post(
            f"{SERVER_URL}/request_tasks_batch",
            json={"node_id": node_id, "batch_size": batch_size},
            timeout=5
        )
        return r.json() if r.ok else []
    except Exception:
        return []

def submit_results_batch(node_id, results):
    try:
        r = requests.post(
            f"{SERVER_URL}/submit_results_batch",
            json={"node_id": node_id, "results": results},
            timeout=5
        )
        return r.json()
    except Exception as e:
        return {"error": str(e)}

def get_results_batch(node_id, batch_size=25):
    try:
        r = requests.post(
            f"{SERVER_URL}/get_results_batch",
            json={"node_id": node_id, "batch_size": batch_size},
            timeout=5
        )
        return r.json() if r.ok else []
    except Exception:
        return []