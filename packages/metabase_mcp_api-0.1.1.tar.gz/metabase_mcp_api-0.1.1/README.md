# metabase-mcp

MCP server for [Metabase](https://www.metabase.com/) — lets an LLM create and manage questions/dashboards via the Metabase API.

## Installation

```bash
pipx install metabase-mcp
# or
pip install metabase-mcp
```

## Usage

```bash
METABASE_URL=https://metabase.example.com \
METABASE_API_KEY=your_api_key \
metabase-mcp
```

The server starts on `http://0.0.0.0:8001/mcp` by default.

### Environment variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `METABASE_URL` | ✅ | — | Base URL of your Metabase instance |
| `METABASE_API_KEY` | ✅ | — | API key (Settings → Admin → API Keys) |
| `MCP_PORT` | ❌ | `8001` | Port to listen on |
| `MCP_HOST` | ❌ | `0.0.0.0` | Host to bind to |

## Claude / VS Code configuration

```json
{
  "mcpServers": {
    "metabase": {
      "command": "uvx",
      "args": ["metabase-mcp"],
      "env": {
        "METABASE_URL": "https://metabase.example.com",
        "METABASE_API_KEY": "your_api_key"
      }
    }
  }
}
```
