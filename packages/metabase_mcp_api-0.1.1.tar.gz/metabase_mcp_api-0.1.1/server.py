"""
Metabase MCP Server
====================
Allows an LLM to create and manage Metabase questions/cards inside dashboards.

Environment variables (required):
  METABASE_URL      - Base URL of the Metabase instance (e.g. https://metabase.example.com)
  METABASE_API_KEY  - Metabase API key (Settings → Admin → API Keys)
"""

import json
import logging
import os
import re
import sys
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

import httpx
from fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("metabase_mcp")

# ---------------------------------------------------------------------------
# Configuration (from env)
# ---------------------------------------------------------------------------

METABASE_URL = os.environ.get("METABASE_URL", "").rstrip("/")
METABASE_API_KEY = os.environ.get("METABASE_API_KEY", "")

if not METABASE_URL:
    logger.warning("⚠️  METABASE_URL is not set")
if not METABASE_API_KEY:
    logger.warning("⚠️  METABASE_API_KEY is not set")

# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _headers() -> Dict[str, str]:
    return {
        "x-api-key": METABASE_API_KEY,
        "Content-Type": "application/json",
    }


def _get(path: str, params: Optional[Dict] = None) -> Any:
    url = f"{METABASE_URL}/api{path}"
    logger.info(f"GET {url} params={params}")
    r = httpx.get(url, headers=_headers(), params=params, timeout=30)
    r.raise_for_status()
    return r.json()


def _post(path: str, body: Dict) -> Any:
    url = f"{METABASE_URL}/api{path}"
    logger.info(f"POST {url}")
    r = httpx.post(url, headers=_headers(), json=body, timeout=30)
    r.raise_for_status()
    return r.json()


def _put(path: str, body: Dict) -> Any:
    url = f"{METABASE_URL}/api{path}"
    logger.info(f"PUT {url}")
    r = httpx.put(url, headers=_headers(), json=body, timeout=30)
    if r.status_code >= 400:
        logger.error(f"PUT {url} failed ({r.status_code}): {r.text[:2000]}")
    r.raise_for_status()
    return r.json()


def _delete(path: str) -> Any:
    url = f"{METABASE_URL}/api{path}"
    logger.info(f"DELETE {url}")
    r = httpx.delete(url, headers=_headers(), timeout=30)
    r.raise_for_status()
    return r.json() if r.content else {}


def _parse_json_param(value, name: str) -> Any:
    """Parse a JSON string parameter, returning None if empty.
    Also accepts already-parsed dicts/lists (MCP protocol may pre-parse JSON)."""
    if value is None:
        return None
    if isinstance(value, (dict, list)):
        return value
    if isinstance(value, str) and value.strip() == "":
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON for parameter '{name}': {e}")


# ---------------------------------------------------------------------------
# MCP server instance
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(server):
    logger.info("🚀 Starting Metabase MCP Server")
    try:
        data = _get("/user/current")
        logger.info(f"✅ Connected to Metabase as: {data.get('email', data.get('id'))}")
    except Exception as e:
        logger.error(f"❌ Could not reach Metabase API: {e}")
    yield


mcp = FastMCP(name="MetabaseMCPServer", lifespan=lifespan)

# ===========================================================================
# TOOL 1 – Parse dashboard URL
# ===========================================================================

@mcp.tool()
def parse_dashboard_url(url: str) -> Dict:
    """Extract the dashboard ID and tab ID from a Metabase dashboard URL.

    Supports URLs like:
      https://metabase.example.com/dashboard/247-my-dashboard?tab=487-my-tab

    Args:
        url: Full Metabase dashboard URL.

    Returns:
        Dict with keys:
          - dashboard_id (int)
          - tab_id (int | None)
          - dashboard_slug (str | None)
          - tab_slug (str | None)
    """
    result: Dict[str, Any] = {
        "dashboard_id": None,
        "tab_id": None,
        "dashboard_slug": None,
        "tab_slug": None,
    }

    # Dashboard id
    m = re.search(r"/dashboard/(\d+)([^?#]*)", url)
    if m:
        result["dashboard_id"] = int(m.group(1))
        result["dashboard_slug"] = m.group(2).lstrip("-") or None

    # Tab id
    m = re.search(r"[?&]tab=(\d+)([^&#]*)", url)
    if m:
        result["tab_id"] = int(m.group(1))
        result["tab_slug"] = m.group(2).lstrip("-") or None

    logger.info(f"Parsed URL → {result}")
    return result


# ===========================================================================
# TOOL 2 – List databases
# ===========================================================================

@mcp.tool()
def list_databases() -> List[Dict]:
    """List all databases connected to Metabase.

    Returns:
        List of dicts with keys: id, name, engine, features.
    """
    data = _get("/database")
    dbs = data.get("data", data) if isinstance(data, dict) else data
    return [
        {
            "id": d["id"],
            "name": d["name"],
            "engine": d.get("engine"),
        }
        for d in dbs
    ]


# ===========================================================================
# TOOL 3 – List tables in a database
# ===========================================================================

@mcp.tool()
def get_database_tables(database_id: int) -> List[Dict]:
    """List all tables available in a database.

    Args:
        database_id: The Metabase database ID (from list_databases).

    Returns:
        List of dicts with keys: id, name, schema, display_name.
    """
    data = _get(f"/database/{database_id}/metadata")
    tables = data.get("tables", [])
    return [
        {
            "id": t["id"],
            "name": t["name"],
            "schema": t.get("schema"),
            "display_name": t.get("display_name"),
        }
        for t in tables
    ]


# ===========================================================================
# TOOL 4 – Get fields for a table
# ===========================================================================

@mcp.tool()
def get_table_fields(table_id: int) -> List[Dict]:
    """Get all fields (columns) of a table with their types and IDs.

    These field IDs are required when building filters, aggregations and
    breakouts for create_question.

    Args:
        table_id: The Metabase table ID (from get_database_tables).

    Returns:
        List of dicts with keys:
          - id (int)          → use this as field_id in queries
          - name (str)        → database column name
          - display_name (str)
          - base_type (str)   → e.g. type/Text, type/Integer, type/DateTime
          - semantic_type (str | None) → e.g. type/PK, type/FK, type/Category
          - has_field_values (str | None) → "list", "search", "none"
    """
    data = _get(f"/table/{table_id}/query_metadata")
    fields = data.get("fields", [])
    return [
        {
            "id": f["id"],
            "name": f["name"],
            "display_name": f.get("display_name"),
            "base_type": f.get("base_type"),
            "semantic_type": f.get("semantic_type"),
            "has_field_values": f.get("has_field_values"),
        }
        for f in fields
    ]


# ===========================================================================
# TOOL 4b – Resolve table by name (search + fields in one call)
# ===========================================================================

@mcp.tool()
def resolve_table(database_id: int, table_name: str) -> Dict:
    """Find a table by name (partial, case-insensitive) and return its ID and fields.

    Combines get_database_tables + get_table_fields into a single call.
    If multiple tables match, returns the best match (shortest name).

    Args:
        database_id: The Metabase database ID.
        table_name:  Full or partial table name to search for (case-insensitive).

    Returns:
        Dict with keys:
          - table_id (int)
          - table_name (str)
          - schema (str)
          - fields: list of {id, name, display_name, base_type, semantic_type}
        Or an error dict if no table matches.
    """
    search_term = table_name.lower().replace(" ", "_")
    data = _get(f"/database/{database_id}/metadata")
    tables = data.get("tables", [])

    # Find matching tables (case-insensitive partial match)
    matches = [
        t for t in tables
        if search_term in t["name"].lower()
    ]

    if not matches:
        return {"error": f"No table matching '{table_name}' found in database {database_id}"}

    # Pick best match: prefer exact match, then shortest name
    best = None
    for t in matches:
        if t["name"].lower() == search_term:
            best = t
            break
    if not best:
        best = min(matches, key=lambda t: len(t["name"]))

    # Fetch fields
    field_data = _get(f"/table/{best['id']}/query_metadata")
    fields = [
        {
            "id": f["id"],
            "name": f["name"],
            "display_name": f.get("display_name"),
            "base_type": f.get("base_type"),
            "semantic_type": f.get("semantic_type"),
        }
        for f in field_data.get("fields", [])
    ]

    logger.info(f"Resolved table '{table_name}' → id={best['id']} ({best['name']}) with {len(fields)} fields")
    return {
        "table_id": best["id"],
        "table_name": best["name"],
        "schema": best.get("schema"),
        "fields": fields,
    }


# ===========================================================================
# TOOL 5 – Search / list dashboards
# ===========================================================================

@mcp.tool()
def search_dashboards(query: str = "") -> List[Dict]:
    """Search for dashboards in Metabase.

    Args:
        query: Optional search string. Leave empty to list recent dashboards.

    Returns:
        List of dicts with keys: id, name, description, collection_id.
    """
    if query:
        data = _get("/search", params={"q": query, "models": "dashboard"})
        items = data.get("data", [])
    else:
        items = _get("/dashboard")
        if isinstance(items, dict):
            items = items.get("data", [])
    return [
        {
            "id": d["id"],
            "name": d["name"],
            "description": d.get("description"),
            "collection_id": d.get("collection_id"),
        }
        for d in items
        if d.get("model", "dashboard") == "dashboard" or "model" not in d
    ]


# ===========================================================================
# TOOL 6 – Get dashboard details (including tabs)
# ===========================================================================

@mcp.tool()
def get_dashboard(dashboard_id: int) -> Dict:
    """Get full details of a dashboard, including its tabs.

    Args:
        dashboard_id: The dashboard ID (from search_dashboards or parse_dashboard_url).

    Returns:
        Dict with keys:
          - id, name, description
          - tabs: list of {id, name, position}
          - cards_count (int)
    """
    data = _get(f"/dashboard/{dashboard_id}")
    tabs = [
        {"id": t["id"], "name": t["name"], "position": t.get("position", 0)}
        for t in data.get("tabs", [])
    ]
    dashcards = data.get("dashcards", [])
    return {
        "id": data["id"],
        "name": data["name"],
        "description": data.get("description"),
        "tabs": tabs,
        "cards_count": len(dashcards),
    }


# ===========================================================================
# TOOL 7 – List collections
# ===========================================================================

@mcp.tool()
def list_collections() -> List[Dict]:
    """List all collections in Metabase where questions can be saved.

    Returns:
        List of dicts with keys: id, name, slug, location (path).
    """
    data = _get("/collection")
    items = data if isinstance(data, list) else data.get("data", [])
    return [
        {
            "id": c["id"],
            "name": c["name"],
            "slug": c.get("slug"),
            "location": c.get("location"),
        }
        for c in items
    ]


# ===========================================================================
# TOOL 8 – Create a question / card
# ===========================================================================

@mcp.tool()
def create_question(
    name: str,
    database_id: int,
    source_table_id: int,
    display: str = "bar",
    filters_json: Optional[str] = None,
    aggregations_json: Optional[str] = None,
    breakouts_json: Optional[str] = None,
    order_by_json: Optional[str] = None,
    row_limit: Optional[int] = None,
    joins_json: Optional[Any] = None,
    second_stage_json: Optional[str] = None,
    visualization_settings_json: Optional[str] = None,
    collection_id: Optional[int] = None,
    description: Optional[str] = None,
) -> Dict:
    """Create a new Metabase question (card) using the structured query builder.

    All *_json parameters accept JSON strings. Always use field IDs obtained
    from get_table_fields.

    ── Display types ──────────────────────────────────────────────────────────
    "bar", "line", "area", "pie", "row", "combo", "scatter", "table",
    "scalar", "smartscalar", "pivot", "funnel", "waterfall", "gauge", "progress"

    ── filters_json ──────────────────────────────────────────────────────────
    One filter clause or a compound clause (and/or). Examples:

      Equality:        ["=",        ["field", 42, null], "active"]
      Multiple values: ["=",        ["field", 42, null], "a", "b", "c"]
      Contains:        ["contains", ["field", 42, null], "foo"]
      Numeric range:   [">",        ["field", 99, null], 100]
      Date relative:   ["time-interval", ["field", 7, null], -30, "day"]
      Compound:        ["and", ["=", ["field", 1, null], "X"],
                                [">", ["field", 2, null], 0]]

    ── aggregations_json ─────────────────────────────────────────────────────
    List of aggregation clauses. Examples:

      Count all rows:   [["count"]]
      Sum a field:      [["sum",      ["field", 99, null]]]
      Average:          [["avg",      ["field", 99, null]]]
      Distinct count:   [["distinct", ["field", 99, null]]]
      Multiple:         [["count"], ["sum", ["field", 99, null]]]

    ── breakouts_json ────────────────────────────────────────────────────────
    List of GROUP-BY fields. Examples:

      Plain:     [["field", 42, null]]
      By week:   [["field", 7, {"temporal-unit": "week"}]]
      By month:  [["field", 7, {"temporal-unit": "month"}]]
      Multiple:  [["field", 1, null], ["field", 2, null]]

    ── order_by_json ─────────────────────────────────────────────────────────
    List of ORDER-BY clauses. Examples:

      Ascending:  [["asc",  ["field", 42, null]]]
      Descending: [["desc", ["field", 42, null]]]

    ── joins_json ────────────────────────────────────────────────────────────
    List of JOIN clauses. Each join is an object with keys:
      - source_table_id (int): ID of the table to join
      - alias (str): alias for the joined table (used in field refs)
      - condition: MBQL join condition
      - fields (optional): "all", "none", or list of field refs (default "all")

    Example — join Enterprise Edition table on instance_id:
      [{"source_table_id": 999, "alias": "EE",
        "condition": ["=",
          ["field", 42, null],
          ["field", 99, {"join-alias": "EE"}]],
        "fields": "all"}]

    To reference joined fields in filters/aggregations, use:
      ["field", field_id, {"join-alias": "EE"}]

    ── second_stage_json ─────────────────────────────────────────────────────
    Optional second aggregation stage applied on top of the first stage results.
    JSON object with keys "aggregation" and/or "breakout". This enables
    two-level aggregations like "Average of Sum of X by Month".

    Example — Average of Sum per month:
      {"aggregation": [["avg", ["field", "sum", {"base-type": "type/Float"}]]],
       "breakout": [["field", "TIMEU~1", {"temporal-unit": "month", "base-type": "type/DateTime"}]]}

    The field references in the second stage use column names from the first
    stage result (e.g. "sum" for Sum of AsInt, "count" for Count).

    ── visualization_settings_json ───────────────────────────────────────────
    Optional chart settings. Examples:

      Goal line:  {"graph.show_goal": true, "graph.goal_value": 1000}
      Axis title: {"graph.x_axis.title_text": "Date", "graph.y_axis.title_text": "Count"}
      Stacked:    {"stackable.stack_type": "stacked"}
      KPI format: {"number.compact": true, "number.decimals": 0}

    Args:
        name:                       Title of the question.
        database_id:                ID of the database (from list_databases).
        source_table_id:            ID of the source table (from get_database_tables).
        display:                    Visualization type (default: "bar").
        filters_json:               JSON filter clause (optional).
        aggregations_json:          JSON list of aggregation clauses (optional).
        breakouts_json:             JSON list of breakout (GROUP BY) fields (optional).
        order_by_json:              JSON list of ORDER BY clauses (optional).
        row_limit:                  Maximum number of rows (optional).
        joins_json:                 JSON list of join clauses (optional).
        second_stage_json:          JSON object for second aggregation stage (optional).
        visualization_settings_json: JSON object for chart display options (optional).
        collection_id:              Collection to save the question in (optional).
        description:                Optional description.

    Returns:
        Dict with keys: id, name, display, collection_id, dataset_query.
    """
    # Build inner query
    inner_query: Dict[str, Any] = {"source-table": source_table_id}

    filters = _parse_json_param(filters_json, "filters_json")
    if filters:
        inner_query["filter"] = filters

    aggregations = _parse_json_param(aggregations_json, "aggregations_json")
    if aggregations:
        inner_query["aggregation"] = aggregations

    breakouts = _parse_json_param(breakouts_json, "breakouts_json")
    if breakouts:
        inner_query["breakout"] = breakouts

    order_by = _parse_json_param(order_by_json, "order_by_json")
    if order_by:
        inner_query["order-by"] = order_by

    if row_limit is not None:
        inner_query["limit"] = row_limit

    # Support optional joins
    joins = _parse_json_param(joins_json, "joins_json")
    if joins:
        mbql_joins = []
        for j in joins:
            mbql_join: Dict[str, Any] = {
                "source-table": j["source_table_id"],
                "alias": j["alias"],
                "condition": j["condition"],
                "fields": j.get("fields", "all"),
            }
            mbql_joins.append(mbql_join)
        inner_query["joins"] = mbql_joins

    # Support optional second aggregation stage (multi-stage / two-level aggregation)
    second_stage = _parse_json_param(second_stage_json, "second_stage_json")
    if second_stage:
        second_query: Dict[str, Any] = {"source-query": inner_query}
        if "aggregation" in second_stage:
            second_query["aggregation"] = second_stage["aggregation"]
        if "breakout" in second_stage:
            second_query["breakout"] = second_stage["breakout"]
        if "filter" in second_stage:
            second_query["filter"] = second_stage["filter"]
        if "order-by" in second_stage:
            second_query["order-by"] = second_stage["order-by"]
        dataset_query = {
            "type": "query",
            "database": database_id,
            "query": second_query,
        }
    else:
        dataset_query = {
            "type": "query",
            "database": database_id,
            "query": inner_query,
        }

    viz_settings = _parse_json_param(visualization_settings_json, "visualization_settings_json") or {}

    body: Dict[str, Any] = {
        "name": name,
        "dataset_query": dataset_query,
        "display": display,
        "visualization_settings": viz_settings,
    }
    if collection_id is not None:
        body["collection_id"] = collection_id
    if description:
        body["description"] = description

    result = _post("/card", body)
    logger.info(f"Created question id={result['id']} name={result['name']}")
    return {
        "id": result["id"],
        "name": result["name"],
        "display": result["display"],
        "collection_id": result.get("collection_id"),
        "url": f"{METABASE_URL}/question/{result['id']}",
        "dataset_query": result.get("dataset_query"),
    }


# ===========================================================================
# TOOL 9 – Update an existing question
# ===========================================================================

@mcp.tool()
def update_question(
    card_id: int,
    name: Optional[str] = None,
    display: Optional[str] = None,
    filters_json: Optional[str] = None,
    aggregations_json: Optional[str] = None,
    breakouts_json: Optional[str] = None,
    order_by_json: Optional[str] = None,
    row_limit: Optional[int] = None,
    visualization_settings_json: Optional[str] = None,
    description: Optional[str] = None,
) -> Dict:
    """Update fields of an existing question/card.

    Only the parameters you provide will be changed. The query structure
    (filters, aggregations, breakouts) is replaced wholesale if provided —
    first fetch the current card with get_question to inspect it.

    Args:
        card_id:                    ID of the card to update.
        name:                       New title (optional).
        display:                    New visualization type (optional).
        filters_json:               Replace filter clause (optional).
        aggregations_json:          Replace aggregations (optional).
        breakouts_json:             Replace breakouts (optional).
        order_by_json:              Replace order-by (optional).
        row_limit:                  Replace row limit (optional).
        visualization_settings_json: Replace vis settings (optional).
        description:                New description (optional).

    Returns:
        Updated card dict: id, name, display, url.
    """
    # Fetch current state
    current = _get(f"/card/{card_id}")
    body: Dict[str, Any] = {}

    if name is not None:
        body["name"] = name
    if display is not None:
        body["display"] = display
    if description is not None:
        body["description"] = description

    viz = _parse_json_param(visualization_settings_json, "visualization_settings_json")
    if viz is not None:
        body["visualization_settings"] = viz

    # Rebuild dataset_query only if any query param is provided
    query_params = [filters_json, aggregations_json, breakouts_json, order_by_json, row_limit]
    if any(p is not None for p in query_params):
        dq = current.get("dataset_query", {})
        inner = dict(dq.get("query", {}))

        filters = _parse_json_param(filters_json, "filters_json")
        if filters is not None:
            inner["filter"] = filters

        aggregations = _parse_json_param(aggregations_json, "aggregations_json")
        if aggregations is not None:
            inner["aggregation"] = aggregations

        breakouts = _parse_json_param(breakouts_json, "breakouts_json")
        if breakouts is not None:
            inner["breakout"] = breakouts

        order_by = _parse_json_param(order_by_json, "order_by_json")
        if order_by is not None:
            inner["order-by"] = order_by

        if row_limit is not None:
            inner["limit"] = row_limit

        dq["query"] = inner
        body["dataset_query"] = dq

    result = _put(f"/card/{card_id}", body)
    return {
        "id": result["id"],
        "name": result["name"],
        "display": result["display"],
        "url": f"{METABASE_URL}/question/{result['id']}",
    }


# ===========================================================================
# TOOL 10 – Get a question's full definition
# ===========================================================================

@mcp.tool()
def get_question(card_id: int) -> Dict:
    """Retrieve the full definition of an existing question/card.

    Useful to inspect current filters/aggregations before calling update_question.

    Args:
        card_id: ID of the card.

    Returns:
        Full card object from Metabase including dataset_query, display,
        visualization_settings and collection_id.
    """
    data = _get(f"/card/{card_id}")
    return {
        "id": data["id"],
        "name": data["name"],
        "display": data["display"],
        "description": data.get("description"),
        "collection_id": data.get("collection_id"),
        "visualization_settings": data.get("visualization_settings"),
        "dataset_query": data.get("dataset_query"),
        "url": f"{METABASE_URL}/question/{data['id']}",
    }


# ===========================================================================
# TOOL 11 – Execute / preview a question
# ===========================================================================

@mcp.tool()
def execute_question(card_id: int, row_limit: int = 10) -> Dict:
    """Run a question and return a preview of its results.

    Args:
        card_id:   ID of the card to run.
        row_limit: Maximum rows to return (default 10, max 2000).

    Returns:
        Dict with keys:
          - columns: list of column names
          - rows:    list of rows (each row is a list of values)
          - row_count (int)
          - status ("completed" | "failed")
          - error (str | None)
    """
    row_limit = min(max(1, row_limit), 2000)
    try:
        data = _post(f"/card/{card_id}/query", {"parameters": []})
    except httpx.HTTPStatusError as e:
        return {"columns": [], "rows": [], "row_count": 0, "status": "failed", "error": str(e)}

    result_data = data.get("data", {})
    cols = [c.get("name") for c in result_data.get("cols", [])]
    rows = result_data.get("rows", [])[:row_limit]

    return {
        "columns": cols,
        "rows": rows,
        "row_count": result_data.get("rows_count", len(rows)),
        "status": data.get("status", "completed"),
        "error": data.get("error"),
    }


# ===========================================================================
# TOOL 12 – Add question to a dashboard (with optional tab)
# ===========================================================================

@mcp.tool()
def add_question_to_dashboard(
    dashboard_id: int,
    card_id: int,
    col: int = 0,
    row: int = 0,
    size_x: int = 12,
    size_y: int = 8,
    tab_id: Optional[int] = None,
) -> Dict:
    """Add an existing question/card to a dashboard, optionally on a specific tab.

    The grid is 24 columns wide. Typical card widths:
      - Full width:  size_x=24
      - Half width:  size_x=12
      - Third width: size_x=8

    To find the right tab_id use get_dashboard or parse_dashboard_url.

    Args:
        dashboard_id: ID of the target dashboard.
        card_id:      ID of the question/card to add.
        col:          Column position (0-based, 0–23). Default 0.
        row:          Row position (0-based). Default 0.
        size_x:       Width in grid columns (default 12).
        size_y:       Height in grid rows (default 8).
        tab_id:       Dashboard tab ID. If None, added to the default tab.

    Returns:
        Dict with keys: dashcard_id, card_id, dashboard_id, tab_id, col, row.
    """
    # Fetch current dashboard to get existing dashcards (Metabase v0.47+ requires
    # a full PUT with the complete dashcards list — POST /cards is removed)
    current = _get(f"/dashboard/{dashboard_id}")
    existing_dashcards = current.get("dashcards", [])
    existing_ids = {dc["id"] for dc in existing_dashcards}

    # Preserve existing dashcards — only keep fields that Metabase accepts on PUT
    _ALLOWED_FIELDS = {
        "id", "card_id", "col", "row", "size_x", "size_y",
        "dashboard_tab_id", "parameter_mappings", "visualization_settings",
        "series",
    }
    kept: List[Dict[str, Any]] = []
    for dc in existing_dashcards:
        entry = {k: v for k, v in dc.items() if k in _ALLOWED_FIELDS}
        # Ensure card_id is present (sometimes only the nested card object has the id)
        if not entry.get("card_id") and dc.get("card"):
            entry["card_id"] = dc["card"].get("id")
        kept.append(entry)

    # New dashcard — negative id signals a creation to Metabase
    new_dashcard: Dict[str, Any] = {
        "id": -1,
        "card_id": card_id,
        "col": col,
        "row": row,
        "size_x": size_x,
        "size_y": size_y,
        "parameter_mappings": [],
        "visualization_settings": {},
    }
    if tab_id is not None:
        new_dashcard["dashboard_tab_id"] = tab_id

    kept.append(new_dashcard)

    # Include tabs in the PUT body — Metabase recreates dashcards and needs
    # the tabs to exist for foreign key references to dashboard_tab_id.
    tabs = current.get("tabs", [])
    result = _put(f"/dashboard/{dashboard_id}", {"dashcards": kept, "tabs": tabs})

    # Find the newly-created dashcard by exclusion
    result_dashcards = result.get("dashcards", [])
    new_dc: Dict[str, Any] = {}
    for dc in result_dashcards:
        if dc.get("id") not in existing_ids:
            new_dc = dc
            break

    logger.info(f"Added card {card_id} to dashboard {dashboard_id} → dashcard_id={new_dc.get('id')}")
    return {
        "dashcard_id": new_dc.get("id"),
        "card_id": card_id,
        "dashboard_id": dashboard_id,
        "tab_id": tab_id,
        "col": col,
        "row": row,
    }


# ===========================================================================
# TOOL 13 – List cards (questions) in a collection
# ===========================================================================

@mcp.tool()
def list_questions(collection_id: Optional[int] = None, search_query: str = "") -> List[Dict]:
    """List existing questions/cards, optionally filtered by collection or text search.

    Args:
        collection_id: Filter by collection (optional). Use 0 for root.
        search_query:  Text to search across question names (optional).

    Returns:
        List of dicts with keys: id, name, display, collection_id, description.
    """
    if search_query:
        data = _get("/search", params={"q": search_query, "models": "card"})
        items = data.get("data", [])
    elif collection_id is not None:
        cid = "root" if collection_id == 0 else collection_id
        data = _get(f"/collection/{cid}/items", params={"models": "card"})
        items = [i.get("data", i) for i in data.get("data", [])]
    else:
        items = _get("/card") or []

    return [
        {
            "id": c["id"],
            "name": c["name"],
            "display": c.get("display"),
            "collection_id": c.get("collection_id"),
            "description": c.get("description"),
        }
        for c in items
        if isinstance(c, dict) and c.get("id")
    ]


# ===========================================================================
# TOOL 14 – Get cards currently on a dashboard (to find placement gaps)
# ===========================================================================

@mcp.tool()
def get_dashboard_cards(dashboard_id: int) -> List[Dict]:
    """List all cards placed on a dashboard with their positions and tab assignments.

    Useful to find free grid positions before calling add_question_to_dashboard.

    Args:
        dashboard_id: ID of the dashboard.

    Returns:
        List of dicts with keys:
          dashcard_id, card_id, card_name, tab_id, col, row, size_x, size_y.
    """
    data = _get(f"/dashboard/{dashboard_id}")
    dashcards = data.get("dashcards", [])
    if dashcards:
        logger.info(f"dashcard sample keys: {list(dashcards[0].keys())}")
    result = []
    for dc in dashcards:
        card = dc.get("card") or {}
        # Metabase uses different field names across versions
        dc_tab = dc.get("dashboard_tab_id") or dc.get("tab_id")
        result.append(
            {
                "dashcard_id": dc.get("id"),
                "card_id": card.get("id"),
                "card_name": card.get("name"),
                "tab_id": dc_tab,
                "col": dc.get("col"),
                "row": dc.get("row"),
                "size_x": dc.get("size_x"),
                "size_y": dc.get("size_y"),
            }
        )
    return result


# ===========================================================================
# Entry point
# ===========================================================================

def main():
    transport = os.environ.get("MCP_TRANSPORT", "streamable-http")
    if transport == "stdio":
        mcp.run(transport="stdio")
    else:
        port = int(os.environ.get("MCP_PORT", "8001"))
        host = os.environ.get("MCP_HOST", "0.0.0.0")
        logger.info(f"🚀 Starting Metabase MCP Server on http://{host}:{port}/mcp")
        mcp.run(
            transport="streamable-http",
            host=host,
            port=port,
            path="/mcp",
        )


if __name__ == "__main__":
    main()
