# smolagents-lats

LATS (Language Agent Tree Search) agent for [smolagents](https://github.com/huggingface/smolagents).

Instead of a linear ReAct loop, `LATSAgent` expands a search tree, scores branches with UCT, and reflects on failed paths.

Based on the paper: [arxiv.org/abs/2310.04406](https://arxiv.org/abs/2310.04406)

## Install
```bash
pip install smolagents-lats
```

## Usage
```python
from smolagents import HfApiModel
from smolagents_lats import LATSAgent

model = HfApiModel()

agent = LATSAgent(
    tools=[],
    model=model,
    n_branches=3,
    max_depth=4,
)

result = agent.run("What is the 10th Fibonacci number?")
print(result)
```

## How it works

- **Expand** — generates `n_branches` candidate actions at each step
- **Score** — asks the LLM to score each branch (0.0 → 1.0)
- **UCT select** — picks the most promising unexplored branch
- **Reflect** — on failed paths, generates a verbal self-critique fed back as context

## Parameters

| Parameter | Default | Description |
|---|---|---|
| `n_branches` | 3 | Candidate actions generated per step |
| `max_depth` | 4 | Max tree depth before forcing answer |
| `exploration_weight` | 1.4 | UCT exploration constant |

## License

MIT