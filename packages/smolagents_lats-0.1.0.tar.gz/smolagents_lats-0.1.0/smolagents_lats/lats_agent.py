import math
from dataclasses import dataclass, field
from typing import Optional
from smolagents.agents import MultiStepAgent
from smolagents.agents import ActionOutput


@dataclass
class LATSNode:
    """One node in the search tree — a (thought, action, observation) triple."""
    thought: str
    action: str
    observation: str
    parent: Optional["LATSNode"] = None
    children: list = field(default_factory=list)
    visits: int = 0
    value: float = 0.0
    reflection: str = ""
    is_terminal: bool = False
    reward: float = 0.0

    def uct_score(self, exploration_weight: float = 1.4) -> float:
        """UCT = exploitation + exploration bonus."""
        if self.visits == 0:
            return float("inf")
        exploitation = self.value / self.visits
        exploration = exploration_weight * math.sqrt(
            math.log(self.parent.visits) / self.visits
        )
        return exploitation + exploration

    def best_child(self) -> "LATSNode":
        return max(self.children, key=lambda c: c.uct_score())

    def is_leaf(self) -> bool:
        return len(self.children) == 0


class LATSAgent(MultiStepAgent):
    """
    Language Agent Tree Search (LATS) agent for smolagents.

    Instead of a linear ReAct loop, expands a search tree,
    scores branches with UCT, and reflects on failed paths.

    Based on: https://arxiv.org/abs/2310.04406

    Args:
        n_branches (int): Number of candidate actions to generate per step. Default 3.
        max_depth (int): Maximum tree depth before forcing a final answer. Default 4.
        exploration_weight (float): UCT exploration constant. Higher = more exploration. Default 1.4.

    Example:
        >>> from smolagents import HfApiModel
        >>> from smolagents_lats import LATSAgent
        >>> model = HfApiModel()
        >>> agent = LATSAgent(tools=[], model=model, n_branches=3, max_depth=4)
        >>> result = agent.run("What is the 10th Fibonacci number?")
    """

    def __init__(
        self,
        *args,
        n_branches: int = 3,
        max_depth: int = 4,
        exploration_weight: float = 1.4,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.n_branches = n_branches
        self.max_depth = max_depth
        self.exploration_weight = exploration_weight
        
    def initialize_system_prompt(self) -> str:
        return (
            "You are an agent that solves tasks step by step using tools. "
            "At each step, output your reasoning as 'Thought: ...' "
            "followed by your action as 'Action: ...'. "
            "When you have the final answer, use 'Action: final_answer(your_answer)'."
        )

    # ------------------------------------------------------------------ #
    # Core LATS loop                                                       #
    # ------------------------------------------------------------------ #

    def _run(self, task: str, **kwargs):
        root = LATSNode(thought="", action="", observation=task)
        best_answer = None

        for iteration in range(self.max_steps):
            # 1. SELECT — walk tree, pick most promising leaf
            node = self._select(root)

            # 2. EXPAND — generate n_branches candidate next steps
            candidates = self._expand(node, task)

            # 3. EVALUATE — score each candidate
            for candidate in candidates:
                reward = self._evaluate(candidate, task)
                candidate.reward = reward
                candidate.visits += 1
                candidate.value += reward
                node.children.append(candidate)

            # 4. BACKPROPAGATE — update ancestor counts
            self._backpropagate(node)

            # 5. Check for a terminal node (final answer)
            best_terminal = self._best_terminal(root)
            if best_terminal:
                best_answer = best_terminal.action
                break

        return best_answer or (self._best_terminal(root).action if self._best_terminal(root) else "No answer found.")

    # ------------------------------------------------------------------ #
    # Tree operations                                                      #
    # ------------------------------------------------------------------ #
    def _step_stream(self, memory_step):
        """
        Bridge between smolagents' step-based pipeline and the LATS tree loop.
        Runs one LATS iteration and yields the result.
        """

        task = self.task
        result = self._run(task)
        memory_step.action_output = result
        memory_step.is_final_answer = True
        yield ActionOutput(output=result, is_final_answer=True)

    def _select(self, node: LATSNode) -> LATSNode:
        """Walk down the tree using UCT until we hit a leaf."""
        depth = 0
        while not node.is_leaf() and not node.is_terminal and depth < self.max_depth:
            node = node.best_child()
            depth += 1
        return node

    def _expand(self, node: LATSNode, task: str) -> list[LATSNode]:
        """Ask the LLM to generate n_branches next steps from this node."""
        children = []
        context = self._node_to_context(node, task)

        for _ in range(self.n_branches):
            messages = self.write_memory_to_messages()
            messages.append({"role": "user", "content": context})

            response = self.model(messages)
            thought, action = self._parse_response(response)
            observation = self._execute_action(action)

            child = LATSNode(
                thought=thought,
                action=action,
                observation=observation,
                parent=node,
            )
            child.is_terminal = self._is_final_answer(action)
            children.append(child)

        return children

    def _evaluate(self, node: LATSNode, task: str) -> float:
        """
        Ask the LLM to score this node's trajectory (0.0 to 1.0).
        If it failed, also generate a reflection stored on the node.
        """
        trajectory = self._node_to_trajectory(node)
        prompt = (
            f"Task: {task}\n\n"
            f"Trajectory so far:\n{trajectory}\n\n"
            "Score how likely this trajectory leads to the correct answer. "
            "Reply with a float between 0.0 and 1.0 on the first line. "
            "Then on a new line write REFLECTION: <one sentence critique if score < 0.5, else leave empty>."
        )
        messages = [{"role": "user", "content": prompt}]
        response = self.model(messages)
        return self._parse_score_and_reflection(response, node)

    def _backpropagate(self, node: LATSNode):
        """Propagate visit counts and values up to the root."""
        while node.parent is not None:
            node.parent.visits += 1
            node.parent.value += node.reward
            node = node.parent

    def _best_terminal(self, root: LATSNode) -> Optional[LATSNode]:
        """Find the highest-reward terminal node in the whole tree."""
        terminals = self._collect_terminals(root)
        if not terminals:
            return None
        return max(terminals, key=lambda n: n.reward)

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    def _collect_terminals(self, node: LATSNode) -> list[LATSNode]:
        results = []
        if node.is_terminal:
            results.append(node)
        for child in node.children:
            results.extend(self._collect_terminals(child))
        return results

    def _node_to_context(self, node: LATSNode, task: str) -> str:
        """Build the prompt context from root → current node path."""
        path = []
        current = node
        while current.parent is not None:
            path.append(
                f"Thought: {current.thought}\n"
                f"Action: {current.action}\n"
                f"Observation: {current.observation}"
            )
            if current.reflection:
                path.append(f"Reflection: {current.reflection}")
            current = current.parent
        path.reverse()
        return (
            f"Task: {task}\n\n"
            + "\n\n".join(path)
            + "\n\nWhat should the next step be?"
        )

    def _node_to_trajectory(self, node: LATSNode) -> str:
        steps = []
        current = node
        while current.parent is not None:
            steps.append(f"- {current.thought} → {current.action}")
            current = current.parent
        steps.reverse()
        return "\n".join(steps)

    def _parse_response(self, response) -> tuple[str, str]:
        """Extract thought and action from LLM response."""
        text = (
            response.content[0].text
            if hasattr(response, "content")
            else str(response)
        )
        parts = text.split("Action:", 1)
        thought = parts[0].replace("Thought:", "").strip()
        action = parts[1].strip() if len(parts) > 1 else text.strip()
        return thought, action

    def _parse_score_and_reflection(self, response, node: LATSNode) -> float:
        """Parse the LLM's score and optional reflection from evaluation response."""
        text = (
            response.content[0].text
            if hasattr(response, "content")
            else str(response)
        )
        lines = text.strip().split("\n")
        try:
            score = float(lines[0].strip())
        except ValueError:
            score = 0.5
        for line in lines[1:]:
            if line.startswith("REFLECTION:"):
                node.reflection = line.replace("REFLECTION:", "").strip()
        return max(0.0, min(1.0, score))

    def _execute_action(self, action: str) -> str:
        """
        Execute the action and return an observation.
        Dispatches to tool calling or code execution depending on action content.
        """
        try:
            if hasattr(self, "python_executor") and self.python_executor:
                result = self.python_executor(action, self.tools)
                return str(result)
        except Exception as e:
            return f"Error during execution: {e}"
        return f"[executed: {action[:80]}...]"

    def _is_final_answer(self, action: str) -> bool:
        """Check if this action is a final answer call."""
        return "final_answer" in action.lower()