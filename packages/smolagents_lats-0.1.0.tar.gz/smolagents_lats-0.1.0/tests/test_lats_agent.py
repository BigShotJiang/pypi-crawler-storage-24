import math
import pytest
from unittest.mock import MagicMock, patch
from smolagents_lats.lats_agent import LATSAgent, LATSNode


# ------------------------------------------------------------------ #
# LATSNode tests                                                       #
# ------------------------------------------------------------------ #

def test_uct_score_unvisited_returns_inf():
    parent = LATSNode(thought="", action="", observation="")
    parent.visits = 1
    child = LATSNode(thought="", action="", observation="", parent=parent)
    assert child.uct_score() == float("inf")


def test_uct_score_visited():
    parent = LATSNode(thought="", action="", observation="")
    parent.visits = 10
    child = LATSNode(thought="", action="", observation="", parent=parent)
    child.visits = 3
    child.value = 2.1
    score = child.uct_score(exploration_weight=1.4)
    exploitation = 2.1 / 3
    exploration = 1.4 * math.sqrt(math.log(10) / 3)
    assert abs(score - (exploitation + exploration)) < 1e-6


def test_best_child_picks_highest_uct():
    parent = LATSNode(thought="", action="", observation="")
    parent.visits = 5

    child_a = LATSNode(thought="", action="a", observation="", parent=parent)
    child_a.visits = 2
    child_a.value = 0.5

    child_b = LATSNode(thought="", action="b", observation="", parent=parent)
    child_b.visits = 0  # unvisited → inf UCT

    parent.children = [child_a, child_b]
    assert parent.best_child() == child_b


def test_is_leaf_true_when_no_children():
    node = LATSNode(thought="", action="", observation="")
    assert node.is_leaf() is True


def test_is_leaf_false_when_has_children():
    node = LATSNode(thought="", action="", observation="")
    child = LATSNode(thought="", action="", observation="", parent=node)
    node.children = [child]
    assert node.is_leaf() is False


# ------------------------------------------------------------------ #
# LATSAgent helper method tests                                        #
# ------------------------------------------------------------------ #

def make_agent(**kwargs):
    """Helper to create a LATSAgent with a mock model."""
    mock_model = MagicMock()
    mock_model.return_value.content = [
        MagicMock(text="Thought: test thought\nAction: final_answer('42')")
    ]
    return LATSAgent(
        tools=[],
        model=mock_model,
        n_branches=2,
        max_depth=2,
        max_steps=3,
        **kwargs,
    )


def test_is_final_answer_true():
    agent = make_agent()
    assert agent._is_final_answer("final_answer('42')") is True


def test_is_final_answer_false():
    agent = make_agent()
    assert agent._is_final_answer("search('query')") is False


def test_parse_response_extracts_thought_and_action():
    agent = make_agent()
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text="Thought: think step\nAction: do_something()")]
    thought, action = agent._parse_response(mock_response)
    assert thought == "think step"
    assert action == "do_something()"


def test_parse_response_no_thought():
    agent = make_agent()
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text="just an action")]
    thought, action = agent._parse_response(mock_response)
    assert action == "just an action"


def test_parse_score_valid_float():
    agent = make_agent()
    node = LATSNode(thought="", action="", observation="")
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text="0.8\nREFLECTION: ")]
    score = agent._parse_score_and_reflection(mock_response, node)
    assert score == 0.8


def test_parse_score_clamps_above_1():
    agent = make_agent()
    node = LATSNode(thought="", action="", observation="")
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text="1.5")]
    score = agent._parse_score_and_reflection(mock_response, node)
    assert score == 1.0


def test_parse_score_clamps_below_0():
    agent = make_agent()
    node = LATSNode(thought="", action="", observation="")
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text="-0.3")]
    score = agent._parse_score_and_reflection(mock_response, node)
    assert score == 0.0


def test_parse_score_invalid_defaults_to_half():
    agent = make_agent()
    node = LATSNode(thought="", action="", observation="")
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text="not a number")]
    score = agent._parse_score_and_reflection(mock_response, node)
    assert score == 0.5


def test_reflection_stored_on_node():
    agent = make_agent()
    node = LATSNode(thought="", action="", observation="")
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text="0.3\nREFLECTION: wrong tool used")]
    agent._parse_score_and_reflection(mock_response, node)
    assert node.reflection == "wrong tool used"


def test_node_to_trajectory_builds_path():
    agent = make_agent()
    root = LATSNode(thought="", action="", observation="task")
    child = LATSNode(thought="think A", action="do A", observation="obs A", parent=root)
    grandchild = LATSNode(thought="think B", action="do B", observation="obs B", parent=child)
    trajectory = agent._node_to_trajectory(grandchild)
    assert "think A" in trajectory
    assert "think B" in trajectory


def test_backpropagate_updates_ancestors():
    agent = make_agent()
    root = LATSNode(thought="", action="", observation="")
    root.visits = 1
    child = LATSNode(thought="", action="", observation="", parent=root)
    child.reward = 0.8
    agent._backpropagate(child)
    assert root.visits == 2
    assert root.value == 0.8


def test_collect_terminals_finds_terminal_nodes():
    agent = make_agent()
    root = LATSNode(thought="", action="", observation="")
    child_a = LATSNode(thought="", action="", observation="", parent=root)
    child_a.is_terminal = True
    child_b = LATSNode(thought="", action="", observation="", parent=root)
    child_b.is_terminal = False
    root.children = [child_a, child_b]
    terminals = agent._collect_terminals(root)
    assert len(terminals) == 1
    assert terminals[0] == child_a


# ------------------------------------------------------------------ #
# LATSAgent smoke test                                                 #
# ------------------------------------------------------------------ #

def test_agent_run_returns_something():
    """Smoke test — verify the core LATS loop runs without crashing."""
    mock_model = MagicMock()
    mock_model.side_effect = [
        MagicMock(content=[MagicMock(text="Thought: solving\nAction: final_answer('42')")]),
        MagicMock(content=[MagicMock(text="0.9\nREFLECTION: ")]),
        MagicMock(content=[MagicMock(text="Thought: solving\nAction: final_answer('42')")]),
        MagicMock(content=[MagicMock(text="0.9\nREFLECTION: ")]),
    ]

    agent = LATSAgent(
        tools=[],
        model=mock_model,
        n_branches=2,
        max_depth=2,
        max_steps=3,
    )

    # Test the LATS core loop directly
    result = agent._run("What is 6 x 7?")
    assert result is not None