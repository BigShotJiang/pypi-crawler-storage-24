# Reading Machine
A Machine that reads texts analytically and syntopically.
```bash
  cat Aristotle-complete_works.txt \
    | uvx reading-machine \
        --provider-api-key=sk-ant-api... \
        --github-token=ghp_... 
```
Or:
```bash
  pip install reading-machine
```
Then:
```Python
  # Python
  import reading_machine
```
