### Seally
Seally is a planning library that I build to prototype planning algorithms. It currently supports static grid based enviroments.

#### Todo
- [ ] Create better visualization tools
- [ ] Add enviroment builder
- [ ] Add performance logging
- [ ] Add Configuration space enviroments
- [ ] Find a better map file format
- [ ] Allow for growing regions

####
1. Start with a map
2. Grag start and goal positions
3. Left-click to place obstacles
4. Right-click to delete obstacles
5. Robot should simulate SLAM
