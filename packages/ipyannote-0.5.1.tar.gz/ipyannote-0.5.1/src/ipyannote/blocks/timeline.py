import anywidget
from pathlib import Path
from traitlets import Float, Integer


class Timeline(anywidget.AnyWidget):
    """Timeline widget

    Parameters
    ----------
    duration : float
        Duration of the timeline (in seconds)
    primary_tick_interval : float, optional
        Time interval between two consecutive primary labeled ticks (in seconds).
        Defaults to 10.0.
    secondary_tick_interval : float, optional
        Time interval between two consecutive secondary labeled ticks (in seconds).
        Defaults to 5.0.
    height : int, optional
        Height of the timeline (in pixels).
        Defaults to 20.
    offset : float, optional
        Time offset of the timeline (in seconds).
        Defaults to 0.0.
    """

    _esm = Path(__file__).parent.parent / "static" / "timeline.js"
    _css = Path(__file__).parent.parent / "static" / "timeline.css"

    # duration of the timeline (in seconds)
    duration = Float(0.0).tag(sync=True)

    # time interval between two consecutive labeled ticks (in seconds)
    primary_tick_interval = Float().tag(sync=True)
    secondary_tick_interval = Float().tag(sync=True)
    # height of the timeline (in pixels)
    height = Integer().tag(sync=True)
    offset = Float().tag(sync=True)

    scroll_time = Float(0.0).tag(sync=True)
    current_time = Float(0.0).tag(sync=True)
    zoom = Float().tag(sync=True)

    def __init__(
        self,
        duration: float,
        primary_tick_interval: float = 10.0,
        secondary_tick_interval: float = 5.0,
        height: int = 20,
        offset: float = 0.0,
        **kwargs,
    ):
        super().__init__(**kwargs)

        self.duration = duration

        self.primary_tick_interval = primary_tick_interval
        self.secondary_tick_interval = secondary_tick_interval
        self.height = height
        self.offset = offset
