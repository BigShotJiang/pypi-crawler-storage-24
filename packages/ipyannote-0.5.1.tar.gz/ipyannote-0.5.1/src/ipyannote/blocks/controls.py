from pathlib import Path

import anywidget
from traitlets import Bool, Float, List, TraitError, validate


class Controls(anywidget.AnyWidget):
    _esm = Path(__file__).parent.parent / "static" / "controls.js"
    _css = Path(__file__).parent.parent / "static" / "controls.css"

    current_time = Float(0.0).tag(sync=True)
    playing = Bool(False).tag(sync=True)

    # manage allowed audio speed rates
    allowed_speed_rates = List(Float()).tag(sync=True)
    # manage current audio speed rate
    playback_rate = Float(1.0).tag(sync=True)

    def __init__(
        self, allowed_speed_rates: list[float] = [0.25, 0.5, 1.0, 1.5, 2.0], **kwargs
    ):
        super().__init__(**kwargs)

        self.allowed_speed_rates = allowed_speed_rates

    @validate("allowed_speed_rates")
    def _validate_allowed_speed_rates(self, proposal):
        if any(rate <= 0 for rate in proposal["value"]):
            raise TraitError("allowed_speed_rates must only contain positive values.")
        return proposal["value"]

    @validate("playback_rate")
    def _validate_playback_rate(self, proposal):
        allowed = self.allowed_speed_rates
        value = proposal["value"]
        if value not in allowed:
            raise TraitError(
                f"Invalid playback rate: {value}. Allowed values are: {allowed}."
            )
        return value
