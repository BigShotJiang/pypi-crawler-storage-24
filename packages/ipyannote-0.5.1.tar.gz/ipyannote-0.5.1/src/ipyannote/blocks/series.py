from pathlib import Path
from typing import Optional

import numpy as np
from anywidget import AnyWidget
from ipywidgets import VBox
from pyannote.core import SlidingWindow, SlidingWindowFeature
from traitlets import Bool, Dict, Float, Integer, List, Unicode

from ..utils.sync import js_sync
from .labels import Labels


class TimeSeries(AnyWidget):
    """Display time series data

    Parameters
    ----------
    duration : float, optional
        Duration of the audio the time series is associated with (in seconds).
        Required if `series` is not provided.
    labels: Labels, optional
        Labels with which to associate time series names.
        If not provided, a new Labels instance is created.
    height : int, optional
        Height of a plot (in pixels).
        Defaults to container height.
    overlay: bool, optional
        Whether to overlay plots or stack them vertically.
        Default is False (stacked).
    fill: bool, optional
        Whether to fill the area under the plot.
        Defaults to False (not filling).
    **kwargs : dict[str, list[float | int]]
        Time series data to display. Each keyword argument corresponds to a
        different time series, where the key is the name of the series and the
        value is a list of values between 0 and 1.
    """

    _esm = Path(__file__).parent.parent / "static" / "series.js"
    _css = Path(__file__).parent.parent / "static" / "series.css"

    # used to display time series
    duration = Float().tag(sync=True)
    time_series = Dict(key_trait=Unicode(), value_trait=List(Float())).tag(sync=True)

    # used to synchronize with a player
    current_time = Float(0.0).tag(sync=True)
    scroll_time = Float(0.0).tag(sync=True)
    zoom = Float().tag(sync=True)

    # height of a plot (in pixels)
    height = Integer(allow_none=True).tag(sync=True)
    # whether to overlay plots or stack them vertically
    overlay = Bool(False).tag(sync=True)
    # whether to fill the area under the plot
    fill = Bool(False).tag(sync=True)

    offset = Float(0.0).tag(sync=True)

    # used to synchronize pool of labels
    labels = Dict(key_trait=Unicode(), value_trait=Unicode()).tag(sync=True)

    def __init__(
        self,
        duration: Optional[float] = None,
        labels: Optional[Labels] = None,
        height: Optional[int] = None,
        overlay: bool = False,
        fill: bool = False,
        **kwargs: list[float | int],
    ):
        super().__init__()

        self._labels = labels or Labels()
        js_sync(self._labels, self, ["labels"])

        if self.duration is None:
            raise ValueError("`duration` must be provided")

        self.duration = duration
        self.time_series = {k: v[:] for k, v in kwargs.items()}

        for label in self.time_series:
            _ = self._labels[label]

        self.height = height
        self.overlay = overlay
        self.fill = fill

    def __setitem__(self, name: str, values: list[float | int]):
        """Set time series data for a given name.

        Parameters
        ----------
        name : str
            Name of the time series.
        values : list of float or int
            Time series data to set.
        """
        time_series = {k: v[:] for k, v in self.time_series.items()}

        time_series[name] = values[:]

        _ = self._labels[name]
        # trigger traitlets sync
        self.time_series = time_series

    def __getitem__(self, name: str) -> list[float | int]:
        """Get time series data for a given name.
        Parameters
        ----------
        name : str
            Name of the time series.

        Returns
        -------
        time_series: list of float or int
            Time series data associated with the given name.
        """
        return self.time_series[name]


class Features(TimeSeries):
    """Display features

    Parameters
    ----------
    features : SlidingWindowFeature
        Features (num_frames, num_series)
    labels: Labels, optional
        Labels with which to associate series names.
        If not provided, a new Labels instance is created.
    height : int, optional
        Height of each row (in pixels). Defaults to 50 pixels.
    overlay: bool, optional
        Whether to overlay plots or stack them vertically.
        Default is True (overlay).
    fill: bool, optional
        Whether to fill the area under the plot.
        Defaults to True (filling).
    """

    def __init__(
        self,
        features: SlidingWindowFeature,
        labels: Labels | None = None,
        height: int | None = None,
        overlay: bool = True,
        fill: bool = True,
    ):

        duration = features.sliding_window.step * features.data.shape[0]
        _, num_series = features.data.shape
        features_labels = getattr(features, "labels") or [
            f"#{i}" for i in range(num_series)
        ]

        time_series = {
            label: features.data[:, i].tolist()
            for i, label in enumerate(features_labels)
        }

        super().__init__(
            duration=duration,
            height=height,
            overlay=overlay,
            fill=fill,
            labels=labels,
            **time_series,
        )

        self.offset = features.sliding_window.start


class ChunkedFeatures(VBox):
    """Display chunked features

    Parameters
    ----------
    chunks : SlidingWindowFeature
        Chunks features (num_chunks, num_frames, num_series)
    frames : SlidingWindow,
        Feature fsrames.
    labels: Labels, optional
        Labels with which to associate series names.
        If not provided, a new Labels instance is created.
    height : int, optional
        Height of each row (in pixels). Defaults to 50 pixels.
    overlay: bool, optional
        Whether to overlay plots or stack them vertically.
        Default is True (overlay).
    fill: bool, optional
        Whether to fill the area under the plot.
        Defaults to True (filling).
    """

    # used to synchronize with a player
    current_time = Float(0.0).tag(sync=True)
    scroll_time = Float(0.0).tag(sync=True)
    zoom = Float().tag(sync=True)

    def __init__(
        self,
        chunks: SlidingWindowFeature,
        frames: SlidingWindow,
        labels: Labels | None = None,
        height: int = 50,
        overlay: bool = True,
        fill: bool = True,
    ):

        assert chunks.data.ndim == 3, (
            "Expected 3D time series data (num_chunks, num_frames, num_dimension)"
        )

        num_steps_per_chunk = round(
            chunks.sliding_window.duration / chunks.sliding_window.step
        )
        organized = self._organize(chunks.data, num_steps_per_chunk)

        rows = []
        for r, _reshaped in enumerate(organized):
            features = Features(
                SlidingWindowFeature(_reshaped, frames, labels=chunks.labels),
                labels=labels,
                height=height,
                overlay=overlay,
                fill=fill,
            )

            rows.append(features)

        super().__init__(rows)

        for features in rows:
            js_sync(self, features, ["current_time", "zoom", "scroll_time"])

    def _organize(self, data, num_steps_per_chunk):
        """Organize chunked features so they do not overlap when plotted.

        Parameters
        ----------
        data : np.ndarray
            Chunked features of shape (num_chunks, num_frames, num_dimension).
        num_steps_per_chunk : int
            Number of steps per chunk, computed as chunk duration divided by step size.

        Returns
        -------
        reshaped : np.ndarray
            Reshaped features of shape (num_rows, total_num_frames, num_dimension),
            where chunked are spread using round-robin scheduling across rows.
        """

        try:
            import torch
            import torch.nn.functional as F
            from einops import rearrange
        except ImportError:
            raise ImportError("torch and einops are required to use ChunkedFeatures.")

        if isinstance(data, np.ndarray):
            data = torch.from_numpy(data)

        num_rows = num_steps_per_chunk + 1
        num_chunks, num_frames, num_classes = data.shape
        n_indices = np.arange(num_rows)[:, np.newaxis]
        chunk_indices = np.arange(num_chunks)[np.newaxis]
        mask = chunk_indices % num_rows == n_indices
        mask_4d = mask[:, :, np.newaxis, np.newaxis]
        stacked = data[np.newaxis] * mask_4d
        folded = F.fold(
            rearrange(stacked, "n c f k -> (k n f) c"),
            (
                1,
                num_frames + (num_chunks - 1) * num_frames // num_steps_per_chunk,
            ),
            (1, num_frames),
            stride=(1, num_frames // num_steps_per_chunk),
        )

        return rearrange(folded, "(k n) 1 t -> n t k", k=num_classes, n=num_rows)
