## Requirements

- Python 3.12+
- uv for package management
- Pydantic for the data parts.

## Installation
```
pip install uv
uv sync
```

## Running tests
```
uv run pytest
```

## Linting
```
uv run ruff check .
uv run ruff format --check .
```

## Publish the Python Package to PyPI
```
uv build
uv publish
```

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
