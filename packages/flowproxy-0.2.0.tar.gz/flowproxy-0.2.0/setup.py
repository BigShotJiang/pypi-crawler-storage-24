from setuptools import setup, find_packages

setup(
    name="flowproxy",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[
        "PyYAML>=6.0",
        "pydantic>=2.0",
        "typer[all]",
        "uvicorn",
        "fastapi",
        "httpx"
    ],
    entry_points={
        "console_scripts": [
            "flowproxy=cli.main:app",  # CLI command globally available
        ],
    },
    python_requires=">=3.10",
    author="Daksh Tiwari",
    description="FlowProxy: Config-driven proxy and orchestrator starter package",
    url="https://github.com/daksh2916/flowproxy",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)