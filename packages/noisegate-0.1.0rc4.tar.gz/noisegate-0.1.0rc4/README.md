# NoiseGate

**Filter the noise from bug bounty reports.**

A program-aware AI triage assistant that evaluates report quality, scope alignment, and impact — so researchers submit better reports and triagers focus on real vulnerabilities.

<!-- screenshot or demo gif here -->

## Quickstart

```bash
pip install noisegate
```

**1. Configure your LLM provider:**
```bash
noisegate llm
```

**2. Import a bug bounty program:**
```bash
noisegate program add acme --url https://hackerone.com/acme
```

**3. Triage a report:**
```bash
noisegate triage report.md
```

Each report gets a three-verdict result:

| Verdict | Meaning | Action |
|---------|---------|--------|
| **PASS** | In scope, real impact, clear writeup | Submit / triage it |
| **WARN** | Real finding, incomplete writeup | Improve the report |
| **FAIL** | Out of scope or ineligible | Don't submit |

## Usage

```bash
noisegate triage report.md                          # default program
noisegate triage report.md --program acme           # specific program
noisegate triage report.md --json                   # machine-readable output
noisegate triage report.md --model openai:gpt-4o    # override model
```

Exit codes: `0` PASS, `1` WARN, `2` FAIL, `3` error.

```bash
noisegate program add acme --url https://hackerone.com/acme
noisegate program add acme --file ./policy.html
noisegate program list
noisegate program show acme
noisegate program use acme
noisegate program remove acme
```

Supports Anthropic (default), OpenAI, Gemini, and Ollama. Pass `--model <provider>:<model-id>` to switch.

## Documentation

See the [full docs](https://sgmurphy.github.io/NoiseGate) for configuration, custom check plugins, and evals.

## Development

```bash
pip install -e ".[dev]"
playwright install chromium
python -m pytest
```

## License

MIT
