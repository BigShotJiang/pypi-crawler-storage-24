# Report Format

NoiseGate accepts bug bounty reports in any plain text or markdown format. A well-structured
report produces more accurate triage results.

## Recommended Structure

```markdown
# Vulnerability Title

## Summary
One paragraph describing the vulnerability and its impact.

## Affected Asset
The specific domain, endpoint, or component affected.

## Steps to Reproduce
Numbered steps a triager can follow to reproduce the finding.

## Proof of Concept
- Code, payload, or screenshot demonstrating exploitability
- HTTP request/response if applicable

## Impact
What can an attacker do with this vulnerability? Be specific:
- What data is exposed?
- What actions can be performed?
- What is the CVSS score and rationale?

## Remediation (optional)
Suggested fix.
```

## How Reports Are Evaluated

NoiseGate runs five checks against each report:

| Check | PASS | WARN / FAIL |
|-------|------|-------------|
| Asset in scope | Target matches an in-scope asset | Target is out-of-scope or unidentifiable |
| Eligible finding | Finding type is not on the ineligible list | Finding matches an ineligible type |
| Required sections present | All program-required sections are included | One or more required sections are absent |
| Reproduction quality | Steps are present and specific enough to reproduce | Steps are missing, vague, or lack a required PoC |
| Impact quality | Real, concrete security impact is described | Impact is absent, speculative, or not a security concern |

The first two checks are `hard_fail` by default — a failure produces a **FAIL** verdict immediately. The remaining three produce **WARN** on failure, indicating a real finding that needs a stronger writeup.

## Tips

- **Be specific about the affected asset.** "app.example.com/api/v1/users" is better than
  "the API".
- **Include a working PoC.** Error messages alone (e.g., a 500 response) are not enough.
- **State the impact explicitly.** Don't make the triager infer it.
- **Reference the policy.** If you know the finding is in scope, say so and cite the relevant
  policy section.
