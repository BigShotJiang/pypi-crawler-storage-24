# Programs and Policy

NoiseGate uses two configuration files for triage:

- **Program files** — define what a bug bounty program accepts: scope, ineligible findings, required report sections, and notes. Stored at `~/.config/noisegate/programs/<name>.yaml`.
- **Policy file** — defines which checks to run and how to weight them. Stored at `~/.config/noisegate/policy.yaml`.

---

## Program Files

Programs are YAML files that capture the rules of a specific bug bounty program.

```yaml
name: Acme Bug Bounty Program
platform: HackerOne
source: https://hackerone.com/acme
assets:
  include:
    - "*.acme.com"
    - "api.acme.com"
  exclude:
    - "community.acme.com"
ineligible_findings:
  - Self-XSS requiring significant user interaction
  - Clickjacking on pages without sensitive actions
  - Missing HTTP security headers without demonstrated impact
required_report_sections:
  - Steps to reproduce
  - Impact statement
  - Proof of concept
notes:
  - Rewards are determined at Acme's discretion
  - Public disclosure requires prior written approval
```

### Fields

| Field | Required | Description |
|-------|----------|-------------|
| `name` | yes | Official program name |
| `platform` | yes | Hosting platform (e.g. HackerOne, Bugcrowd) |
| `source` | yes | Canonical URL for the program page |
| `assets.include` | no | In-scope domains, subdomains, IPs. Use wildcards (e.g. `*.example.com`) where applicable |
| `assets.exclude` | no | Explicitly out-of-scope assets |
| `ineligible_findings` | no | Finding types the program won't reward |
| `required_report_sections` | no | Sections a valid report must include |
| `notes` | no | Rules relevant to triage: safe harbour, disclosure timelines, scope edge cases, reward constraints |

### Managing programs

```bash
# Import from a URL (crawled with Playwright + LLM extraction)
noisegate program add acme --url https://hackerone.com/acme

# Import from a local file (HTML, PDF, or plain text)
noisegate program add acme --file ./acme-policy.html

# Set the default program for triage
noisegate program use acme

# List all saved programs
noisegate program list

# View a program
noisegate program show acme

# Delete a program
noisegate program remove acme
```

Programs are stored at `~/.config/noisegate/programs/`. You can edit them directly with any text editor.

---

## Policy File

`~/.config/noisegate/policy.yaml` controls which checks run during triage and how failures are weighted. NoiseGate seeds this file with defaults on first run.

```yaml
checks:
  - id: asset_in_scope
    hard_fail: true
  - id: finding_ineligible
    hard_fail: true
  - id: required_sections_present
  - id: reproduction_quality
  - id: impact_quality
```

### Fields

| Field | Description |
|-------|-------------|
| `id` | Check identifier. Built-in IDs are listed below; custom check IDs can be any string |
| `hard_fail` | If `true`, a failed check produces a `FAIL` verdict regardless of other results (default: `false`) |
| `config` | Optional key/value dict passed to the check handler — used to parameterize custom checks |

### Built-in check IDs

| ID | What it evaluates |
|----|-------------------|
| `asset_in_scope` | Is the reported target within the program's in-scope assets? |
| `finding_ineligible` | Does this finding match any ineligible finding types? |
| `required_sections_present` | Are all sections required by the program present? |
| `reproduction_quality` | Are reproduction steps present and clear enough to reproduce? |
| `impact_quality` | Does the report clearly explain the security impact? |

### Verdict logic

- Any `hard_fail` check that fails → **FAIL**
- Any non-hard-fail check that fails → **WARN**
- All checks pass → **PASS**

To add custom checks, see [checks.md](checks.md).

---

## Size Limits

- URL-fetched content (program import): 40,000 characters per page, 10 pages max
- Local files (program import): 100,000 characters
- Reports (`noisegate triage`): 100,000 characters
