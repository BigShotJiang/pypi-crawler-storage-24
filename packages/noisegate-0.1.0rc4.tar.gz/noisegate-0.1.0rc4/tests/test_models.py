"""Tests for Pydantic models."""

from noisegate.models import Verdict


def test_verdict_values() -> None:
    assert Verdict.PASS.value == "PASS"
    assert Verdict.WARN.value == "WARN"
    assert Verdict.FAIL.value == "FAIL"
