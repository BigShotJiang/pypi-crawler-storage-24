"""Shared fixtures and mock helpers."""

from noisegate.models import CheckResult, ChecksResult, Verdict

_CHECK_IDS = [
    "asset_in_scope",
    "finding_ineligible",
    "impact_quality",
    "reproduction_quality",
    "required_sections_present",
]


def make_checks_result(verdict: Verdict = Verdict.PASS) -> ChecksResult:
    """Build a ChecksResult fixture for a given verdict."""
    checks = []
    for cid in _CHECK_IDS:
        if verdict == Verdict.FAIL and cid == "asset_in_scope":
            checks.append(CheckResult(check_id=cid, passed=False, reason="Out of scope."))
        elif verdict == Verdict.WARN and cid == "reproduction_quality":
            checks.append(CheckResult(check_id=cid, passed=False, reason="No steps provided."))
        else:
            checks.append(CheckResult(check_id=cid, passed=True, reason="Passed."))
    summary = "All checks passed." if verdict == Verdict.PASS else "Some checks failed."
    return ChecksResult(
        checks=checks,
        summary=summary,
        verdict=verdict,
        model_used="anthropic:claude-sonnet-4-6",
        prompt_tokens=500,
        completion_tokens=200,
    )
