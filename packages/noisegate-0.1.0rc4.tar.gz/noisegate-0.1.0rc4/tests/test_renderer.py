"""Tests for output rendering (renderer.py)."""

import io
import json

from rich.console import Console

from noisegate.models import Verdict
from noisegate.renderer import render_human, render_json
from tests.conftest import make_checks_result


def test_render_json_is_valid_json() -> None:
    result = make_checks_result(Verdict.PASS)
    parsed = json.loads(render_json(result))
    assert parsed["verdict"] == "PASS"
    assert "checks" in parsed
    assert "summary" in parsed
    assert "model_used" in parsed


def test_render_json_all_verdicts() -> None:
    for verdict in Verdict:
        result = make_checks_result(verdict)
        parsed = json.loads(render_json(result))
        assert parsed["verdict"] == verdict.value


def test_render_human_pass() -> None:
    result = make_checks_result(Verdict.PASS)
    console = Console(file=open("/dev/null", "w"))
    render_human(result, console=console)  # just ensure no exception


def test_render_human_outputs_verdict() -> None:
    result = make_checks_result(Verdict.FAIL)
    buf = io.StringIO()
    console = Console(file=buf, highlight=False, markup=False)
    render_human(result, console=console)
    assert "FAIL" in buf.getvalue()


def test_render_human_shows_check_labels() -> None:
    result = make_checks_result(Verdict.FAIL)
    buf = io.StringIO()
    console = Console(file=buf, highlight=False, markup=False)
    render_human(result, console=console)
    output = buf.getvalue()
    assert "Asset not in scope" in output   # hard_fail check that failed
    assert "Reproduction steps" in output   # check that passed


def test_render_human_shows_summary() -> None:
    result = make_checks_result(Verdict.WARN)
    buf = io.StringIO()
    console = Console(file=buf, highlight=False, markup=False)
    render_human(result, console=console)
    assert result.summary in buf.getvalue()
