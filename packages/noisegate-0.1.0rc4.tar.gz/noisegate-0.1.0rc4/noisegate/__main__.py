"""Allow `python -m noisegate` invocation."""

from noisegate.cli import cli

if __name__ == "__main__":
    cli()
