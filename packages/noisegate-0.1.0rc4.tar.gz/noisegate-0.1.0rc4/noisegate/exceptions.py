"""Custom exceptions for NoiseGate."""

from __future__ import annotations

from pathlib import Path


class NoiseGateError(Exception):
    """Base exception for all NoiseGate errors."""


class NoDefaultProgramError(NoiseGateError):
    """Raised when no default program is configured."""

    def __init__(self) -> None:
        super().__init__(
            "No default program set. Run: noisegate program use <name>"
        )


class LLMError(NoiseGateError):
    """Raised when the LLM call fails."""


class ProgramNotFoundError(NoiseGateError):
    def __init__(self, name: str) -> None:
        super().__init__(f"Program '{name}' not found at ~/.config/noisegate/programs/{name}.yaml")


class ProgramParseError(NoiseGateError):
    def __init__(self, path: Path, reason: str) -> None:
        super().__init__(f"Failed to parse program file {path}: {reason}")


class ProgramImportError(NoiseGateError):
    def __init__(self, reason: str) -> None:
        super().__init__(f"Program import failed: {reason}")


class PolicyParseError(NoiseGateError):
    def __init__(self, path: Path, reason: str) -> None:
        super().__init__(f"Failed to parse policy file {path}: {reason}")
