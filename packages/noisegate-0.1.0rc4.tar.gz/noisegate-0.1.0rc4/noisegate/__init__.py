"""NoiseGate — AI-powered bug bounty report triage tool."""

from importlib.metadata import version

__version__ = version("noisegate")
