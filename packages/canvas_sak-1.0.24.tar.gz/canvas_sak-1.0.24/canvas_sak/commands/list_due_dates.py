from canvas_sak.core import *


def format_date(dt_str):
    """Convert ISO date string to YYYY-MM-DD-hh:mm format in local timezone"""
    if not dt_str:
        return None
    dt = datetime.datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
    local_dt = dt.astimezone()
    return local_dt.strftime('%Y-%m-%d-%H:%M')


def build_date_entries(unlock_at, due_at, lock_at):
    """Build comma-separated date entries string"""
    entries = []
    if unlock_at:
        formatted = format_date(unlock_at)
        if formatted:
            entries.append(f"available={formatted}")
    if due_at:
        formatted = format_date(due_at)
        if formatted:
            entries.append(f"due={formatted}")
    if lock_at:
        formatted = format_date(lock_at)
        if formatted:
            entries.append(f"until={formatted}")
    return ','.join(entries)


@canvas_sak.command()
@click.argument('course_name', metavar='course')
@click.option('--active/--inactive', default=True, help="show only active courses")
def list_due_dates(course_name, active):
    """List due dates for all assignments in dates file format.

    Output format: assignment name TAB comma-separated dates

    Each date is type=YYYY-MM-DD-hh:mm where type is available, due, or until.

    Assignments with section overrides show the base dates first, then each
    override on a separate line with the section name in brackets.

    Example:
        Homework 1\tavailable=2024-01-15-09:00,due=2024-01-22-23:59
        Quiz 1\tdue=2024-01-20-23:59
        Quiz 1 [Section A]\tdue=2024-01-22-23:59
    """
    canvas = get_canvas_object()
    course = get_course(canvas, course_name, active)

    for assignment in course.get_assignments(include=['overrides']):
        # Output base assignment dates
        date_entries = build_date_entries(
            assignment.unlock_at,
            assignment.due_at,
            assignment.lock_at
        )
        output(f"{assignment.name}\t{date_entries}")

        # Output any override dates
        overrides = getattr(assignment, 'overrides', None) or []
        for override in overrides:
            # Handle both dict and object access patterns
            if isinstance(override, dict):
                override_title = override.get('title', 'Override')
                unlock_at = override.get('unlock_at')
                due_at = override.get('due_at')
                lock_at = override.get('lock_at')
            else:
                override_title = getattr(override, 'title', 'Override')
                unlock_at = getattr(override, 'unlock_at', None)
                due_at = getattr(override, 'due_at', None)
                lock_at = getattr(override, 'lock_at', None)
            override_dates = build_date_entries(unlock_at, due_at, lock_at)
            if override_dates:
                output(f"{assignment.name} [{override_title}]\t{override_dates}")
