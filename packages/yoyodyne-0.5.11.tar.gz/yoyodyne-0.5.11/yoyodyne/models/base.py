"""Base model class, with PL integration."""

import abc
import logging
from typing import Callable, Optional, Tuple, Union

import lightning
import torch
from lightning.pytorch import cli
from torch import nn, optim

from .. import data, defaults, metrics, special
from . import modules


class ConfigurationError(ValueError):
    pass


class BaseModel(abc.ABC, lightning.LightningModule):
    """Abstract base class for models handling Lightning integration.

    The following are defaults, but can be overriden by individual models:

    * The forward method returns a tensor of shape B x target_vocab_size x
      seq_len for compatibility with loss and evaluation functions unless
      beam search is enabled.
    * Cross-entropy loss is the loss function.
    * One or more predictions tensor(s) are returned by predict_step.
    * Loss is returned by training_step.
    * Evaluation metrics are tracked by test_step; nothing is returned.
    * Validation loss and evaluation metrics are tracked by validation_step;
      nothing is returned.

    The source_encoder argument uses a two-way sentinel system: None means
    no source_encoder is used; a BaseEncoder instance is used as a source
    encoder.

    The features_encoder argument uses a three-way sentinel system: False
    means no features encoder; True indicates that the source encoder is reused
    as the features encoder; a BaseEncoder instance is used as a separate
    features encoder.

    Derived classes should call the superclass init and then issue:

        self.decoder = self.get_decoder()
        self._log_model()
        self.save_hyperparameters(
            ignore=[
                ...
                # Modules.
                "decoder",
                "embeddings",
                "features_encoder",
                "source_encoder",
                ...,
                # Options that can change between training and prediction.
                "beam_width",
                ...,
            ]
        )

    Args:
        *args: ignored.
        beam_width (int,  optional): width of beam for decoding.
        compute_accuracy (bool, optional): compute accuracy?
        compute_ser (bool, optional): compute SER?
        decoder_hidden_size (int, optional): dimensionality of decoder layers.
        decoder_layers (int, optional): number of decoder layers.
        decoder_dropout (float, optional): dropout probability.
        embedding_size (int, optional): dimensionality of embedding.
        features_encoder (modules.BaseModule, optional).
        label_smoothing (float, optional): label smoothing coefficient.
        max_target_length (int, optional): maximum target length.
        source_encoder (modules.BaseModule, optional).
        **kwargs: ignored.
    """

    decoder_layers: int
    decoder_hidden_size: int
    decoder_dropout: float
    label_smoothing: float
    max_source_length: int
    max_features_length: int
    max_target_length: int

    source_encoder: Optional[modules.BaseEncoder]
    features_encoder: Optional[modules.BaseEncoder]
    decoder: modules.BaseModule
    embedding: nn.Embedding

    optimizer: optim.Optimizer
    scheduler: optim.lr_scheduler.LRScheduler

    beam_width: int
    accuracy: Optional[metrics.Accuracy]
    ser: Optional[metrics.SER]
    loss_func: Optional[Callable[[torch.Tensor, torch.Tensor], torch.Tensor]]

    def __init__(
        self,
        *args,  # Ignored here.
        beam_width: int = defaults.BEAM_WIDTH,
        compute_accuracy: bool = True,
        compute_ser: bool = False,
        decoder_hidden_size: int = defaults.HIDDEN_SIZE,
        decoder_layers: int = defaults.LAYERS,
        decoder_dropout: float = defaults.DROPOUT,
        embedding_size: int = defaults.EMBEDDING_SIZE,
        features_encoder: Union[modules.BaseEncoder, bool] = False,
        label_smoothing: float = defaults.LABEL_SMOOTHING,
        max_source_length: int = defaults.MAX_LENGTH,
        max_features_length: int = defaults.MAX_LENGTH,
        max_target_length: int = defaults.MAX_LENGTH,
        optimizer: cli.OptimizerCallable = defaults.OPTIMIZER,
        scheduler: cli.LRSchedulerCallable = defaults.SCHEDULER,
        source_encoder: Optional[modules.BaseEncoder] = None,
        target_vocab_size: int = -1,  # Dummy value filled in via link.
        vocab_size: int = -1,  # Dummy value filled in via link.
        **kwargs,  # Ignored here.
    ):
        super().__init__()
        self.beam_width = beam_width
        self.decoder_hidden_size = decoder_hidden_size
        self.decoder_layers = decoder_layers
        self.decoder_dropout = decoder_dropout
        self.embedding_size = embedding_size
        self.label_smoothing = label_smoothing
        self.max_source_length = max_source_length
        self.max_features_length = max_features_length
        self.max_target_length = max_target_length
        self.num_embeddings = vocab_size
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.target_vocab_size = target_vocab_size
        self.accuracy = (
            metrics.Accuracy(self.target_vocab_size)
            if compute_accuracy
            else None
        )
        self.ser = metrics.SER() if compute_ser else None
        self.loss_func = self._get_loss_func()
        self.embeddings = self.init_embeddings(
            self.num_embeddings, self.embedding_size
        )
        if source_encoder is not None:
            if source_encoder.embedding_size != self.embedding_size:
                raise ConfigurationError(
                    "Source embedding size "
                    f"({source_encoder.embedding_size}) != "
                    f"model embedding size ({self.embedding_size})"
                )
        self.source_encoder = source_encoder
        if features_encoder is False:
            # No features encoder.
            if self.source_encoder is not None:
                self.source_encoder.set_max_length(self.max_source_length + 2)
            self.features_encoder = None
            self.has_features_encoder = False
        elif features_encoder is True:
            # Shared features encoder.
            if self.source_encoder is not None:
                self.source_encoder.set_max_length(
                    max(self.max_source_length + 2, self.max_features_length)
                )
            self.features_encoder = self.source_encoder
            self.has_features_encoder = True
        else:
            # Separate features encoder.
            if features_encoder.embedding_size != self.embedding_size:
                raise ConfigurationError(
                    "Features embedding size "
                    f"({features_encoder.embedding_size}) != "
                    f"model embedding size ({self.embedding_size})"
                )
            if self.source_encoder is not None:
                self.source_encoder.set_max_length(self.max_source_length + 2)
            self.features_encoder = features_encoder
            self.features_encoder.set_max_length(self.max_features_length)
            self.has_features_encoder = True

    def _get_loss_func(
        self,
    ) -> Optional[Callable[[torch.Tensor, torch.Tensor], torch.Tensor]]:
        """Returns the actual function used to compute loss.

        This is overridden by certain classes which compute loss as a side
        effect of training and/or inference.

        Returns:
            Callable[[torch.Tensor, torch.Tensor], torch.Tensor]: configured
                loss function.
        """
        return nn.CrossEntropyLoss(
            ignore_index=special.PAD_IDX,
            label_smoothing=self.label_smoothing,
        )

    def _log_model(self) -> None:
        logging.info("Model: %s", self.name)
        if self.has_features_encoder:
            if self.source_encoder == self.features_encoder:
                logging.info(
                    "Source/features encoder: %s", self.source_encoder.name
                )
            elif self.source_encoder:
                logging.info("Source encoder: %s", self.source_encoder.name)
                logging.info(
                    "Features encoder: %s", self.features_encoder.name
                )
        elif self.source_encoder:
            logging.info("Encoder: %s", self.source_encoder.name)
        logging.info("Decoder: %s", self.decoder.name)

    def configure_optimizers(
        self,
    ) -> tuple[list[optim.Optimizer], list[optim.lr_scheduler.LRScheduler]]:
        optimizer = self.optimizer(self.parameters())
        scheduler = self.scheduler(optimizer)
        return [optimizer], [scheduler]

    @abc.abstractmethod
    def get_decoder(self) -> modules.BaseModule: ...

    @staticmethod
    @abc.abstractmethod
    def init_embeddings(
        num_embeddings: int, embedding_size: int
    ) -> nn.Embedding: ...

    # TODO: update with new metrics as they become available.

    @property
    def has_accuracy(self) -> bool:
        return self.accuracy is not None

    @property
    def has_ser(self) -> bool:
        return self.ser is not None

    @property
    def validating(self) -> bool:
        # Parallel to the built-in self.training.
        return self.trainer and (
            self.trainer.validating or self.trainer.sanity_checking
        )

    def start_symbol(self, batch_size: int) -> torch.Tensor:
        """Generates a tensor of start symbols for the batch."""
        return torch.tensor([special.START_IDX], device=self.device).repeat(
            batch_size, 1
        )

    def _align(
        self, predictions: torch.Tensor, target: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Pads predictions and target tensors along sequence dimension.

        This is useful for methods (e.g., student forcing training, or
        prediction/testing) that require matched lengths.

        Args:
            predictions (torch.Tensor): B x C x L logits or B x L indices.
            target (torch.Tensor): B X L indices.

        Returns:
            Tuple[torch.Tensor, torch.Tensor].
        """
        # Identifies which dimension represents the sequence length, and
        # returns early if they're already aligned.
        p_seq_dim = 2 if predictions.ndim == 3 else 1
        p_len = predictions.size(p_seq_dim)
        t_len = target.size(1)
        if p_len == t_len:
            return predictions, target
        max_len = max(p_len, t_len)
        # Pad predictions along the sequence dimension.
        if p_len < max_len:
            # For logits, padding with 0 is neutral; for indices use PAD_IDX.
            pad_val = 0 if predictions.ndim == 3 else special.PAD_IDX
            predictions = nn.functional.pad(
                predictions, (0, max_len - p_len), value=pad_val
            )
        # Pads target along the sequence dimension.
        elif t_len < max_len:
            target = nn.functional.pad(
                target, (0, max_len - t_len), value=special.PAD_IDX
            )
        return predictions, target

    def on_fit_start(self):
        # Rather than crashing, we simply warn about lack of deterministic
        # algorithms.
        if torch.are_deterministic_algorithms_enabled():
            logging.info("(Only) warning about non-deterministic algorithms")
            torch.use_deterministic_algorithms(True, warn_only=True)

    def predict_step(
        self,
        batch: data.Batch,
        batch_idx: int,
    ) -> Union[Tuple[torch.Tensor, torch.Tensor], torch.Tensor]:
        """Runs one predict step.

        If beam_width > 1 this invokes the forward method directly and returns
        the predictions and scores; otherwise it returns the predictions.

        No metrics are tracked.

        Args:
            batch (data.Batch).
            batch_idx (int).

        Returns:
            Union[Tuple[torch.Tensor, torch.Tensor], torch.Tensor].
        """
        if self.beam_width > 1:
            return self(batch)
        else:
            return torch.argmax(self(batch), dim=1)

    def training_step(self, batch: data.Batch, batch_idx: int) -> torch.Tensor:
        """Runs one step of training.

        Training loss is tracked.

        Args:
            batch (data.Batch)
            batch_idx (int).

        Returns:
            torch.Tensor: training loss.
        """
        predictions = self(batch)
        predictions, target = self._align(predictions, batch.target.tensor)
        loss = self.loss_func(predictions, target)
        self.log(
            "train_loss",
            loss,
            batch_size=len(batch),
            logger=True,
            on_epoch=True,
            on_step=False,
            prog_bar=True,
        )
        return loss

    def on_test_epoch_start(self) -> None:
        self._reset_metrics()

    def test_step(self, batch: data.Batch, batch_idx: int) -> None:
        """Runs one test step.

        Evaluation metrics are tracked.

        Args:
            batch (data.Batch).
            batch_idx (int).
        """
        if self.beam_width > 1:
            # TODO: make this workable with `yoyodyne test`.
            predictions, _ = self(batch)
        else:
            predictions = torch.argmax(self(batch), dim=1)
        predictions, target = self._align(predictions, batch.target.tensor)
        self._update_metrics(predictions, target)

    def on_test_epoch_end(self) -> None:
        self._log_metrics_on_epoch_end("test")

    def on_validation_epoch_start(self) -> None:
        self._reset_metrics()

    def validation_step(
        self,
        batch: data.Batch,
        batch_idx: int,
    ) -> None:
        """Runs one validation step.

        Validation loss and evaluation metrics are tracked.

        Args:
            batch (data.Batch).
            batch_idx (int).
        """
        predictions = self(batch)
        predictions, target = self._align(predictions, batch.target.tensor)
        loss = self.loss_func(predictions, target)
        self.log(
            "val_loss",
            loss,
            batch_size=len(batch),
            logger=True,
            on_epoch=True,
            prog_bar=True,
        )
        self._update_metrics(predictions, target)

    def on_validation_epoch_end(self) -> None:
        self._log_metrics_on_epoch_end("val")

    # Helpers to make it run.

    def _reset_metrics(self) -> None:
        # TODO: update with new metrics as they become available.
        if self.has_accuracy:
            self.accuracy.reset()
        if self.has_ser:
            self.ser.reset()

    def _update_metrics(
        self, predictions: torch.Tensor, target: torch.Tensor
    ) -> None:
        # TODO: update with new metrics as they become available.
        if self.has_accuracy:
            self.accuracy.update(predictions, target)
        if self.has_ser:
            self.ser.update(predictions, target)

    def _log_metrics_on_epoch_end(self, subset: str) -> None:
        # TODO: update with new metrics as they become available.
        if self.has_accuracy:
            self.log(
                f"{subset}_accuracy",
                self.accuracy.compute(),
                logger=True,
                on_epoch=True,
                prog_bar=True,
            )
        if self.has_ser:
            self.log(
                f"{subset}_ser",
                self.ser.compute(),
                logger=True,
                on_epoch=True,
                prog_bar=True,
            )
