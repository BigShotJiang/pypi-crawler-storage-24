# Reportify CLI Commands Reference

Use `reportify-cli <module> --help` to see all commands, or `reportify-cli <module> <command> --help` for parameter details.

## Search Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `all` | Search all document types | `query` |
| `news` | Search news articles | `query` |
| `reports` | Search research reports | `query` |
| `filings` | Search company filings | `query`, `symbols` |
| `conference_calls` | Search earnings conference call transcripts | `symbols` |
| `earnings_pack` | Search earnings-related exchange filings | `symbols` |
| `minutes` | Search conference calls and IR meetings | `query` |
| `socials` | Search social media posts | `query` |
| `webpages` | Search web pages | `query` |
| `crawl` | Crawl web content from URLs | `urls` |

> `conference_calls` and `earnings_pack`: `query` is optional. Without it, returns reverse-chronological results; with it, sorts by relevance.

## Docs Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `get` | Get document details | `doc_id` |
| `summary` | Get document summary | `doc_id` |
| `raw_content` | Get document raw content | `doc_id` |
| `list_by_symbols` | List documents by stock symbol | `symbol` |
| `list` | List documents with filters | (optional) |
| `search` | Search documents (v1) | (optional) |
| `search_chunks` | Search document chunks (semantic) | `query` |
| `create_folder` | Create folder | `name` |
| `delete_folder` | Delete folder and all its files | `folder_id` |
| `upload` | Upload documents | `docs` |
| `upload_async` | Upload documents asynchronously | `docs` |
| `get_upload_status` | Get document upload status | `doc_id` |
| `delete` | Delete documents | `doc_ids` |

## Stock Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `overview` | Company overview | `symbols` or `names` |
| `shareholders` | Shareholder information | `symbol` |
| `income_statement` | Income statement | `symbol` |
| `balance_sheet` | Balance sheet | `symbol` |
| `cashflow_statement` | Cash flow statement | `symbol` |
| `revenue_breakdown` | Revenue breakdown | `symbol` |
| `quote` | Stock quote (price, PE, PB, etc.) | `symbol` |
| `index_quote` | Index quote data | `symbol` |
| `index_constituents` | Index constituents | `symbol` |
| `index_tracking_funds` | Index tracking funds (ETFs) | `symbol` |
| `industry_constituents` | Industry constituents | `market`, `name` |
| `earnings_calendar` | Earnings calendar | `market` |
| `ipo_calendar_hk` | Hong Kong IPO calendar | (optional) |

## Quant Module

### Real-time / Intraday Data

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `kline_1m` | 1-minute kline (single stock) | `symbol`, `start_datetime`, `end_datetime` |
| `kline_1m_batch` | 1-minute kline (multiple stocks) | `symbols`, `start_datetime`, `end_datetime` |
| `minute` | Minute data (single stock) | `symbol`, `start_datetime`, `end_datetime` |
| `minute_batch` | Minute data (multiple stocks) | `symbols`, `start_datetime`, `end_datetime` |

### Historical Data

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `ohlcv` | Daily OHLCV (single stock) | `symbol` |
| `ohlcv_batch` | Daily OHLCV (multiple stocks) | `symbols` |

### Analysis & Screening

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `indicators` | List available technical indicators | (none) |
| `indicators_compute` | Compute technical indicators | `symbols`, `formula` |
| `factors` | List available factors | (none) |
| `factors_compute` | Compute factor values | `symbols`, `formula` |
| `factors_screen` | Stock screening | `formula` |
| `backtest` | Strategy backtesting | `symbol`, `start_date`, `end_date`, `entry_formula` |

## Macro Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `commodities` | Commodity prices (oil, gold, gas, silver, platinum) | `type`, `start_date`, `end_date` |

## Timeline Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `companies` | Updates from followed companies | (optional) |
| `topics` | Updates from followed topics | (optional) |
| `institutes` | Updates from followed institutions | (optional) |
| `public_media` | Updates from followed public media | (optional) |
| `social_media` | Updates from followed social media | (optional) |

## Channels Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `search` | Search channels | `query` |
| `followings` | List followed channels | (optional) |
| `follow` | Follow a channel | `channel_id` |
| `unfollow` | Unfollow a channel | `channel_id` |
| `get_docs` | Get documents from followed channels | (optional) |

## KB Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `search` | Search knowledge base | `query` |

## User Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `followed_companies` | Get followed companies | (none) |
| `follow_company` | Follow a company | `symbol` (Market:Code) |
| `unfollow_company` | Unfollow a company | `symbol` (Market:Code) |

## Concepts Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `latest` | Latest concept dynamics | (optional) |
| `today` | Today's concept dynamics | (none) |

## Agent Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `create_conversation` | Create a new conversation | _(none, agent_id optional)_ |
| `get_conversation` | Get conversation details | `conversation_id` |
| `chat` | Chat with agent | `conversation_id`, `message` |
| `list_messages` | List conversation messages | `conversation_id` |
| `get_message_events` | Get assistant message events | `conversation_id`, `assistant_message_id` |
| `cancel_execution` | Cancel agent execution | `conversation_id`, `assistant_message_id` |
| `get_file` | Get agent generated file | `file_id` |

## Following Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `create_follow_group` | Create a follow group | `name`, `follow_values` |
| `get_follow_groups` | Get all follow groups | (none) |
| `get_follow_group` | Get a follow group by ID | `group_id` |
| `update_follow_group` | Update a follow group | `group_id`, `name` |
| `delete_follow_group` | Delete a follow group | `group_id` |
| `add_follows_to_group` | Add follows to a group | `group_id`, `follow_values` |
| `remove_follows_from_group` | Remove follows from a group | `group_id`, `follow_values` |
| `set_group_follows` | Set follows for a group (replace all) | `group_id`, `follow_values` |
| `get_follow_group_docs` | Get docs for a follow group | `group_id` |
