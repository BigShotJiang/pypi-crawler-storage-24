"""Agent module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="Agent conversations", rich_markup_mode="rich")


@app.command(
    name="create_conversation",
    epilog=generate_epilog(
        params.AGENT_CREATE_CONVERSATION_PARAMS,
        [
            'reportify-cli agent create_conversation --input \'{"conversation_type": "bot_chat"}\'',
            'reportify-cli agent create_conversation --input \'{"agent_id": 11887655289749510, "title": "NVIDIA analysis", "conversation_type": "agent_chat"}\'',
        ],
    ),
)
def create_conversation(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Create a new agent conversation"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.agent.create_conversation(
            agent_id=params_dict.get("agent_id"),
            title=params_dict.get("title"),
            conversation_type=params_dict.get("conversation_type"),
            meta=params_dict.get("meta"),
        )
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_conversation",
    epilog=generate_epilog(
        params.AGENT_GET_CONVERSATION_PARAMS,
        [
            'reportify-cli agent get_conversation --input \'{"conversation_id": 123456}\'',
        ],
    ),
)
def get_conversation(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get agent conversation details"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        conversation_id = params_dict.get("conversation_id")
        if not conversation_id:
            raise ValueError("conversation_id is required")
        result = client.agent.get_conversation(conversation_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="chat",
    epilog=generate_epilog(
        params.AGENT_CHAT_PARAMS,
        [
            'reportify-cli agent chat --input \'{"conversation_id": 123456, "message": "Analyze NVIDIA"}\'',
            'reportify-cli agent chat --input \'{"conversation_id": 123456, "message": "Run analysis", "background": true}\'',
            'reportify-cli agent chat --input \'{"conversation_id": 123456, "message": "Hello", "stream": false}\'',
        ],
    ),
)
def chat(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Chat with agent (streaming or non-streaming)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        conversation_id = params_dict.get("conversation_id")
        message = params_dict.get("message")
        if not conversation_id:
            raise ValueError("conversation_id is required")
        if not message:
            raise ValueError("message is required")
        result = client.agent.chat(
            conversation_id=conversation_id,
            message=message,
            documents=params_dict.get("documents"),
            stream=params_dict.get("stream", True),
            background=params_dict.get("background", False),
        )
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="list_messages",
    epilog=generate_epilog(
        params.AGENT_LIST_MESSAGES_PARAMS,
        [
            'reportify-cli agent list_messages --input \'{"conversation_id": 123456}\'',
            'reportify-cli agent list_messages --input \'{"conversation_id": 123456, "limit": 20}\'',
        ],
    ),
)
def list_messages(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """List agent conversation messages"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        conversation_id = params_dict.get("conversation_id")
        if not conversation_id:
            raise ValueError("conversation_id is required")
        result = client.agent.list_messages(
            conversation_id=conversation_id,
            limit=params_dict.get("limit", 10),
            before_message_id=params_dict.get("before_message_id"),
        )
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_message_events",
    epilog=generate_epilog(
        params.AGENT_GET_MESSAGE_EVENTS_PARAMS,
        [
            'reportify-cli agent get_message_events --input \'{"conversation_id": 123456, "assistant_message_id": "msg_abc123"}\'',
        ],
    ),
)
def get_message_events(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get assistant message events"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        conversation_id = params_dict.get("conversation_id")
        assistant_message_id = params_dict.get("assistant_message_id")
        if not conversation_id:
            raise ValueError("conversation_id is required")
        if not assistant_message_id:
            raise ValueError("assistant_message_id is required")
        result = client.agent.get_message_events(
            conversation_id=conversation_id,
            assistant_message_id=assistant_message_id,
            stream=params_dict.get("stream", True),
            timeout=params_dict.get("timeout", 1800),
            from_offset=params_dict.get("from_offset", 0),
        )
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="cancel_execution",
    epilog=generate_epilog(
        params.AGENT_CANCEL_EXECUTION_PARAMS,
        [
            'reportify-cli agent cancel_execution --input \'{"conversation_id": 123456, "assistant_message_id": "msg_abc123"}\'',
        ],
    ),
)
def cancel_execution(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Cancel agent execution"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        conversation_id = params_dict.get("conversation_id")
        assistant_message_id = params_dict.get("assistant_message_id")
        if not conversation_id:
            raise ValueError("conversation_id is required")
        if not assistant_message_id:
            raise ValueError("assistant_message_id is required")
        result = client.agent.cancel_execution(
            conversation_id=conversation_id,
            assistant_message_id=assistant_message_id,
        )
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_file",
    epilog=generate_epilog(
        params.AGENT_GET_FILE_PARAMS,
        [
            'reportify-cli agent get_file --input \'{"file_id": "file_abc123"}\'',
        ],
    ),
)
def get_file(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get agent generated file"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        file_id = params_dict.get("file_id")
        if not file_id:
            raise ValueError("file_id is required")
        result = client.agent.get_file(file_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
