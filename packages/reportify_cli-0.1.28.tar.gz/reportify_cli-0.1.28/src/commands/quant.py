"""Quant module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="Quantitative analysis", rich_markup_mode="rich")


@app.command(
    name="indicators",
    epilog=generate_epilog(params.QUANT_LIST_INDICATORS_PARAMS, ["reportify-cli quant indicators"]),
)
def indicators(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """List available technical indicators"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.indicators(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="indicators_compute",
    epilog=generate_epilog(
        params.QUANT_COMPUTE_INDICATORS_PARAMS,
        [
            'reportify-cli quant indicators_compute --input \'{"symbols": ["000001"], "formula": "MA(CLOSE, 5)"}\'',
        ],
    ),
)
def indicators_compute(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Compute technical indicators"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.indicators_compute(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="factors",
    epilog=generate_epilog(params.QUANT_LIST_FACTORS_PARAMS, ["reportify-cli quant factors"]),
)
def factors(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """List available factors"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.factors(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="factors_compute",
    epilog=generate_epilog(
        params.QUANT_COMPUTE_FACTORS_PARAMS,
        [
            'reportify-cli quant factors_compute --input \'{"symbols": ["000001"], "formula": "PE_TTM()"}\'',
        ],
    ),
)
def factors_compute(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Compute factor values"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.factors_compute(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.QUANT_SCREEN_PARAMS,
        [
            'reportify-cli quant factors_screen --input \'{"formula": "(PE_TTM() < 20) & (ROE() > 0.15)"}\'',
        ],
    )
)
def factors_screen(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Screen stocks with factor formula"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.factors_screen(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.QUANT_OHLCV_PARAMS,
        [
            'reportify-cli quant ohlcv --input \'{"symbol": "000001", "start_date": "2024-01-01"}\'',
        ],
    )
)
def ohlcv(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get OHLCV data for a single stock"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.ohlcv(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="ohlcv_batch",
    epilog=generate_epilog(
        params.QUANT_OHLCV_BATCH_PARAMS,
        [
            'reportify-cli quant ohlcv_batch --input \'{"symbols": ["000001", "000002"], "start_date": "2024-01-01"}\'',
        ],
    ),
)
def ohlcv_batch(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get OHLCV data for multiple stocks"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.ohlcv_batch(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.QUANT_BACKTEST_PARAMS,
        [
            'reportify-cli quant backtest --input \'{"symbols": ["000001"], "start_date": "2023-01-01", "end_date": "2024-01-01", "entry_formula": "MA(CLOSE, 5) > MA(CLOSE, 20)"}\'',
        ],
    )
)
def backtest(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Run strategy backtest"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.backtest(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="kline_1m",
    epilog=generate_epilog(
        params.QUANT_KLINE_1M_PARAMS,
        [
            'reportify-cli quant kline_1m --input \'{"symbol": "000001", "start_datetime": "2024-01-01 09:30:00", "end_datetime": "2024-01-01 15:00:00"}\'',
        ],
    ),
)
def kline_1m(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get 1-minute kline data for a single stock"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.kline_1m(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="kline_1m_batch",
    epilog=generate_epilog(
        params.QUANT_KLINE_1M_BATCH_PARAMS,
        [
            'reportify-cli quant kline_1m_batch --input \'{"symbols": ["000001", "600519"], "start_datetime": "2024-01-01 09:30:00", "end_datetime": "2024-01-01 15:00:00"}\'',
        ],
    ),
)
def kline_1m_batch(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get 1-minute kline data for multiple stocks"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.kline_1m_batch(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="minute",
    epilog=generate_epilog(
        params.QUANT_MINUTE_PARAMS,
        [
            'reportify-cli quant minute --input \'{"symbol": "000001", "start_datetime": "2024-01-01 09:30:00", "end_datetime": "2024-01-01 15:00:00"}\'',
        ],
    ),
)
def minute(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get minute data for a single stock"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.minute(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="minute_batch",
    epilog=generate_epilog(
        params.QUANT_MINUTE_BATCH_PARAMS,
        [
            'reportify-cli quant minute_batch --input \'{"symbols": ["000001", "600519"], "start_datetime": "2024-01-01 09:30:00", "end_datetime": "2024-01-01 15:00:00"}\'',
        ],
    ),
)
def minute_batch(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get minute data for multiple stocks"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.quant.minute_batch(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
