#!/usr/bin/env bash

# 改为非严格模式，手动控制错误退出，便于调试
set -eo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 错误处理函数
error_exit() {
    echo -e "${RED}❌ $1${NC}"
    exit 1
}

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR/" || error_exit "Failed to enter project directory: $PROJECT_DIR"

echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo -e "${BLUE}   Reportify CLI - Version Bump Script${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ]; then
    error_exit "pyproject.toml not found. Are you in the right directory?"
fi

# Extract current version from pyproject.toml
CURRENT_VERSION=$(grep '^version = ' pyproject.toml | sed 's/version = "\(.*\)"/\1/')
if [ -z "$CURRENT_VERSION" ]; then
    error_exit "Failed to extract current version from pyproject.toml"
fi
echo -e "${YELLOW}Current version: ${CURRENT_VERSION}${NC}"
echo ""

# Parse version components
IFS='.' read -ra VERSION_PARTS <<< "$CURRENT_VERSION"
if [ "${#VERSION_PARTS[@]}" -ne 3 ]; then
    error_exit "Invalid version format: $CURRENT_VERSION (expected MAJOR.MINOR.PATCH)"
fi
MAJOR="${VERSION_PARTS[0]}"
MINOR="${VERSION_PARTS[1]}"
PATCH="${VERSION_PARTS[2]}"

# Determine bump type
BUMP_TYPE="${1:-patch}"
case "$BUMP_TYPE" in
    major)
        MAJOR=$((MAJOR + 1))
        MINOR=0
        PATCH=0
        ;;
    minor)
        MINOR=$((MINOR + 1))
        PATCH=0
        ;;
    patch)
        PATCH=$((PATCH + 1))
        ;;
    *)
        error_exit "Invalid bump type. Use 'major', 'minor', or 'patch'\nUsage: $0 [major|minor|patch]"
        ;;
esac

NEW_VERSION="${MAJOR}.${MINOR}.${PATCH}"
echo -e "${GREEN}New version: ${NEW_VERSION}${NC}"
echo ""

# ===================== 核心修复：先处理分支，再修改版本号 =====================
# 仅在CI环境下执行分支切换（避免本地运行时干扰）
if [ -n "${CI_COMMIT_REF_NAME}" ]; then
    echo -e "${YELLOW}CI环境：先切换到目标分支并同步远程代码${NC}"

    # 暂存当前所有修改（解决checkout时的文件覆盖问题）
    git stash push -u -m "temp stash for version bump" || true

    # 切换到目标分支
    git checkout "${CI_COMMIT_REF_NAME}" || error_exit "Failed to checkout branch ${CI_COMMIT_REF_NAME}"

    # 拉取远程最新版本（确保分支是最新的）
    git fetch origin "${CI_COMMIT_REF_NAME}" || error_exit "Failed to fetch remote branch"
    git reset --hard "origin/${CI_COMMIT_REF_NAME}" || error_exit "Failed to reset branch to remote latest"

    # 恢复暂存的修改（但此时暂存的是旧版本的修改，后续会重新更新版本号）
    git stash pop || true
fi

# ===================== 再更新版本号 =====================
# Update version in pyproject.toml
echo -e "${BLUE}Updating pyproject.toml...${NC}"
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS (sed requires empty -i flag)
    sed -i '' "s/^version = \".*\"/version = \"${NEW_VERSION}\"/" pyproject.toml || error_exit "Failed to update pyproject.toml (macOS)"
else
    # Linux
    sed -i "s/^version = \".*\"/version = \"${NEW_VERSION}\"/" pyproject.toml || error_exit "Failed to update pyproject.toml (Linux)"
fi
echo -e "${GREEN}✓ Updated pyproject.toml${NC}"
echo ""

# Show the diff
echo -e "${BLUE}Changes:${NC}"
git diff pyproject.toml || true
echo ""

# 仅当 pyproject.toml 有变更时，执行提交推送逻辑
if [ -n "$(git status --porcelain pyproject.toml)" ]; then
    echo -e "${YELLOW}Starting version commit & push...${NC}"

    # 配置git信息（仅本地生效，避免污染全局）
    git config --local user.name "GitLab Runner Bot"
    git config --local user.email "gitlab-runner-arm@xiaobangtouzi.com"

    # 更新远程仓库地址（带CI token认证）
    if [ -n "${GITLAB_PUSHER_TOKEN}" ] && [ -n "${CI_SERVER_HOST}" ] && [ -n "${CI_PROJECT_PATH}" ]; then
        git remote set-url origin "https://gitlab-ci-token:${GITLAB_PUSHER_TOKEN}@${CI_SERVER_HOST}/${CI_PROJECT_PATH}.git" || error_exit "Failed to set remote URL"
    fi

    # 同步远程代码（处理冲突）
    echo -e "${YELLOW}Syncing remote code...${NC}"
    git fetch origin "${CI_COMMIT_REF_NAME}" || error_exit "Failed to fetch remote branch"
    if ! git merge "origin/${CI_COMMIT_REF_NAME}" --no-edit; then
        echo -e "${RED}Merge conflict detected! Aborting...${NC}"
        git merge --abort
        error_exit "Please resolve conflicts manually and retry"
    fi

    # 仅添加版本文件，避免误提交其他变更
    git add pyproject.toml || error_exit "Failed to add pyproject.toml"

    # 检查是否有可提交的变更（避免无变更时commit失败）
    if git diff --cached --quiet; then
        echo -e "${YELLOW}⚠️ No changes to commit (pyproject.toml unchanged)${NC}"
        exit 0
    fi

    # 提交变更（仅提交版本文件，不带-a避免误提交）
    git commit -m "chore: bump version to ${NEW_VERSION} [ci skip]" || error_exit "Failed to commit changes"
    echo -e "${GREEN}✓ Changes committed${NC}"
    echo ""

    # 推送变更（CI环境带ci.skip避免循环触发）
    if [ -n "${CI_COMMIT_REF_NAME}" ]; then
        git push origin -o ci.skip "${CI_COMMIT_REF_NAME}" || error_exit "Failed to push changes to remote"
        echo -e "${GREEN}✓ Changes pushed to remote: ${CI_COMMIT_REF_NAME}${NC}"
    else
        # 非CI环境，提示手动推送
        echo -e "${YELLOW}⚠️ Not in CI environment, skip push. Please push manually.${NC}"
    fi
else
    echo -e "${YELLOW}⚠️ No changes to pyproject.toml, skip commit & push${NC}"
fi

# 最终状态检查（友好提示，不强制退出）
if [ -n "$(git status --porcelain)" ]; then
    echo -e "${YELLOW}⚠️ There are uncommitted changes (non-version files), please check${NC}"
    git status --short
else
    echo -e "${GREEN}✓ Working directory clean${NC}"
fi

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo -e "${GREEN}   ✓ Version Bumped Successfully!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo ""
echo -e "Old version: ${YELLOW}${CURRENT_VERSION}${NC}"
echo -e "New version: ${GREEN}${NEW_VERSION}${NC}"
echo ""
echo -e "Next steps:"
echo -e "  1. Run tests: ${YELLOW}make test${NC}"
echo -e "  2. Publish to test PyPI: ${YELLOW}./scripts/publish.sh test${NC}"
echo -e "  3. Publish to prod PyPI: ${YELLOW}./scripts/publish.sh prod${NC}"
echo ""