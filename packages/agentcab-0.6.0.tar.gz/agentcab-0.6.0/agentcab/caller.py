"""AgentCab Caller SDK"""

import time
import logging
from typing import Optional, Dict, Any, List

from .client import BaseClient
from .types import Skill, Call
from .exceptions import AgentCabError, TimeoutError as SDKTimeoutError


logger = logging.getLogger(__name__)


class CallerClient(BaseClient):
    """Client for Caller operations (call APIs, check status, etc.)"""

    def list_apis(
        self,
        query: Optional[str] = None,
        category: Optional[str] = None,
        status: str = "active",
        sort_by: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        List available APIs

        Args:
            query: Search query for API name/description
            category: Filter by category
            status: Filter by status (default: "active")
            sort_by: Sort order - "popular", "newest", "price_low", "price_high", "rating"
            page: Page number (default: 1)
            page_size: Items per page (default: 20)

        Returns:
            {
                "items": [...],
                "page": 1,
                "page_size": 20,
                "total": 100
            }
        """
        params = {
            "q": query,
            "category": category,
            "status_filter": status,
            "sort_by": sort_by,
            "page": page,
            "page_size": page_size,
        }
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        return self.get("/skills", params=params)

    def get_api(self, api_id: str) -> Skill:
        """Get API details"""
        return self.get(f"/skills/{api_id}")

    def call_api(
        self,
        api_id: str,
        input: Dict[str, Any],
        max_cost: Optional[int] = None,
        wait: bool = False,
        wait_timeout: int = 60,
        poll_interval: int = 2,
    ) -> Call:
        """
        Call an API

        Args:
            api_id: API ID to call
            input: Input data for the API
            max_cost: Maximum credits willing to pay (optional)
            wait: Whether to wait for result (default: False)
            wait_timeout: Maximum seconds to wait for result (default: 60)
            poll_interval: Seconds between status checks (default: 2)

        Returns:
            Call object with status and output (if wait=True and completed)
        """
        payload = {"input": input}
        if max_cost is not None:
            payload["max_cost"] = max_cost

        result = self.post(f"/skills/{api_id}/call", json=payload)

        if not wait:
            return result

        # Wait for result
        call_id = result["call_id"]
        start_time = time.time()

        while time.time() - start_time < wait_timeout:
            call = self.get_call(call_id)

            if call["status"] in ["success", "failed", "timeout"]:
                return call

            time.sleep(poll_interval)

        raise SDKTimeoutError(f"Call {call_id} did not complete within {wait_timeout}s")

    def call_api_sync(
        self,
        api_id: str,
        input: Dict[str, Any],
        max_cost: Optional[int] = None,
        timeout: int = 60,
        poll_interval: int = 2,
    ) -> Call:
        """
        Call an API and wait for result (synchronous)

        This is a convenience method that calls call_api with wait=True.

        Args:
            api_id: API ID to call
            input: Input data for the API
            max_cost: Maximum credits willing to pay (optional)
            timeout: Maximum seconds to wait for result (default: 60)
            poll_interval: Seconds between status checks (default: 2)

        Returns:
            Call object with status and output
        """
        return self.call_api(
            api_id=api_id,
            input=input,
            max_cost=max_cost,
            wait=True,
            wait_timeout=timeout,
            poll_interval=poll_interval,
        )

    def get_call(self, call_id: str) -> Call:
        """Get call status and result"""
        return self.get(f"/calls/{call_id}")

    def list_my_calls(
        self,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        List my calls

        Returns:
            {
                "items": [...],
                "page": 1,
                "page_size": 20,
                "total": 100
            }
        """
        params = {"page": page, "page_size": page_size}
        return self.get("/calls", params=params)

    def get_wallet(self) -> Dict[str, Any]:
        """Get wallet balance"""
        return self.get("/wallet")

    def list_transactions(
        self,
        page: int = 1,
        page_size: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        List wallet transactions

        Returns:
            List of transaction objects
        """
        return self.get("/wallet/transactions", params={"page": page, "page_size": page_size})

    def upload_file(self, file_path: str, call_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Upload a file (costs 50 credits).

        Args:
            file_path: Path to the file to upload
            call_id: Optional call ID to associate the file with

        Returns:
            Dict with file_id, filename, file_size, mime_type, url, expires_at
        """
        params = {"call_id": call_id} if call_id else None
        return super().upload_file("/files/upload", file_path, params=params)

    def download_file(self, file_id: str, save_path: str) -> str:
        """
        Download a file by ID.

        Args:
            file_id: The file ID to download
            save_path: Path to save the downloaded file

        Returns:
            Path to the saved file
        """
        return super().download_file(f"/files/{file_id}", save_path)

    def list_files(
        self,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        List your uploaded files.

        Returns:
            {
                "items": [...],
                "page": 1,
                "page_size": 20,
                "total": 100
            }
        """
        params = {"page": page, "page_size": page_size}
        return self.get("/files", params=params)

    def delete_file(self, file_id: str) -> Dict[str, Any]:
        """
        Delete a file by ID.

        Args:
            file_id: The file ID to delete

        Returns:
            {"deleted": True}
        """
        return self.delete(f"/files/{file_id}")

    def create_review(
        self,
        api_id: str,
        rating: int,
        comment: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a review for an API.

        You must have called this API at least once before reviewing.
        Each user can only review each API once.

        Args:
            api_id: API ID to review
            rating: Rating from 1 to 5
            comment: Optional review comment

        Returns:
            Review object with id, rating, comment, created_at
        """
        payload = {"rating": rating}
        if comment:
            payload["comment"] = comment
        return self.post(f"/skills/{api_id}/reviews", json=payload)

    def update_review(
        self,
        api_id: str,
        rating: Optional[int] = None,
        comment: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Update your existing review for an API.

        Args:
            api_id: API ID
            rating: New rating (1-5, optional)
            comment: New comment (optional)

        Returns:
            Updated review object
        """
        payload = {}
        if rating is not None:
            payload["rating"] = rating
        if comment is not None:
            payload["comment"] = comment
        return self.put(f"/skills/{api_id}/reviews", json=payload)

    def get_reviews(
        self,
        api_id: str,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        Get reviews for an API.

        Args:
            api_id: API ID
            page: Page number (default: 1)
            page_size: Items per page (default: 20)

        Returns:
            {
                "items": [...],
                "page": 1,
                "page_size": 20,
                "total": 100
            }
        """
        params = {"page": page, "page_size": page_size}
        return self.get(f"/skills/{api_id}/reviews", params=params)

    def delete_review(self, api_id: str) -> Dict[str, Any]:
        """
        Delete your review for an API.

        Args:
            api_id: API ID

        Returns:
            {"deleted": True}
        """
        return self.delete(f"/skills/{api_id}/reviews")

    @classmethod
    def from_credentials(
        cls,
        email: str,
        password: str,
        base_url: str = "https://www.agentcab.ai/v1",
    ) -> "CallerClient":
        """
        Create client from email/password credentials

        This will login and retrieve the API key.
        Note: Using API key directly is recommended for security.
        """
        import requests

        # Login to get token
        response = requests.post(
            f"{base_url}/auth/login",
            json={"email": email, "password": password}
        )
        response.raise_for_status()
        token = response.json()["data"]["access_token"]

        # Get user info to retrieve API key
        response = requests.get(
            f"{base_url}/auth/me",
            headers={"Authorization": f"Bearer {token}"}
        )
        response.raise_for_status()
        user_data = response.json()["data"]

        # Use API key if available, otherwise use token
        api_key = user_data.get("api_key_hash") or token

        return cls(api_key=api_key, base_url=base_url)
