"""Wallet commands"""

import click
from agentcab import CallerClient
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.group(invoke_without_command=True)
@click.pass_context
@require_auth
def wallet(ctx):
    """Show wallet balance and manage transactions"""
    # If no subcommand is provided, show balance and recent transactions (default behavior)
    if ctx.invoked_subcommand is None:
        show_wallet_summary()


def show_wallet_summary():
    """Show wallet balance and recent transactions (default command)"""
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        # Get wallet balance
        wallet_info = client.get_wallet()

        click.echo(click.style("\n💰 Wallet Balance", fg="cyan", bold=True))
        click.echo(f"  Available: {wallet_info['credits']} credits (${wallet_info['credits'] / 100:.2f} USD)")
        click.echo(f"  Frozen: {wallet_info.get('frozen_credits', 0)} credits")

        # Get recent transactions
        result = client.list_transactions(page=1, page_size=10)
        transactions = result if isinstance(result, list) else result.get("items", [])

        if transactions:
            click.echo(click.style("\n📊 Recent Transactions", fg="cyan", bold=True))
            click.echo(f"\n{'Type':<15} {'Amount':<12} {'Status':<10} {'Created At'}")
            click.echo("-" * 70)

            for tx in transactions[:10]:  # Show last 10 transactions
                amount = tx.get('credits', 0)
                tx_type = tx.get('tx_type', 'unknown')
                status = tx.get('status', 'unknown')
                created_at = tx.get('created_at', '')[:19]  # Trim to datetime

                # Color code by type
                if tx_type in ['earn', 'recharge']:
                    amount_str = click.style(f"+{amount}", fg="green")
                elif tx_type in ['consume', 'withdraw', 'platform_fee']:
                    amount_str = click.style(f"-{amount}", fg="red")
                else:
                    amount_str = str(amount)

                click.echo(
                    f"{tx_type:<15} "
                    f"{amount_str:<12} "
                    f"{status:<10} "
                    f"{created_at}"
                )

            click.echo(f"\nView more: agentcab wallet transactions")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@wallet.command()
@click.option("--page", type=int, default=1, help="Page number")
@click.option("--page-size", type=int, default=20, help="Items per page")
@require_auth
def transactions(page, page_size):
    """View transaction history with pagination

    Examples:
        # View recent transactions
        agentcab wallet transactions

        # View specific page
        agentcab wallet transactions --page 2 --page-size 50
    """
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        # Get wallet balance first
        wallet_info = client.get_wallet()
        click.echo(click.style("\n💰 Wallet Balance", fg="cyan", bold=True))
        click.echo(f"  Available: {wallet_info['credits']} credits (${wallet_info['credits'] / 100:.2f} USD)")

        # Get transactions
        result = client.list_transactions(page=page, page_size=page_size)
        transactions_list = result if isinstance(result, list) else result.get("items", [])
        total = result.get("total", len(transactions_list)) if isinstance(result, dict) else len(transactions_list)

        if not transactions_list:
            click.echo("\nNo transactions found.")
            return

        click.echo(click.style("\n📊 Transaction History", fg="cyan", bold=True))
        click.echo(f"\n{'Type':<15} {'Amount':<12} {'Status':<10} {'Created At':<20} {'ID'}")
        click.echo("-" * 90)

        for tx in transactions_list:
            amount = tx.get('credits', 0)
            tx_type = tx.get('tx_type', 'unknown')
            status = tx.get('status', 'unknown')
            created_at = tx.get('created_at', '')[:19]
            tx_id = tx.get('id', 'N/A')[:20] + ".." if len(tx.get('id', '')) > 22 else tx.get('id', 'N/A')

            # Color code by type
            if tx_type in ['earn', 'recharge']:
                amount_str = click.style(f"+{amount}", fg="green")
            elif tx_type in ['consume', 'withdraw', 'platform_fee']:
                amount_str = click.style(f"-{amount}", fg="red")
            else:
                amount_str = str(amount)

            click.echo(
                f"{tx_type:<15} "
                f"{amount_str:<12} "
                f"{status:<10} "
                f"{created_at:<20} "
                f"{tx_id}"
            )

        if isinstance(result, dict):
            click.echo(f"\nShowing {len(transactions_list)} of {total} transaction(s) (Page {page}/{(total + page_size - 1) // page_size})")
        else:
            click.echo(f"\nTotal: {len(transactions_list)} transaction(s)")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()
