"""AgentCab Provider SDK"""

import time
import signal
import logging
import subprocess
from typing import Optional, Callable, Dict, Any, List
from multiprocessing import Process, Queue

import requests

from .client import BaseClient
from .types import Skill, Job, Wallet, Transaction, Withdrawal
from .exceptions import AgentCabError


logger = logging.getLogger(__name__)


class ProviderClient(BaseClient):
    """Client for Provider operations (API management, wallet, etc.)"""

    def create_api(
        self,
        name: str,
        description: str,
        input_schema: dict,
        output_schema: dict,
        price_credits: int,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        max_concurrent_jobs: int = 5,
    ) -> Skill:
        """Create a new API"""
        data = {
            "name": name,
            "description": description,
            "input_schema": input_schema,
            "output_schema": output_schema,
            "price_credits": price_credits,
            "category": category,
            "tags": tags,
            "max_concurrent_jobs": max_concurrent_jobs,
            "callback_url": "pull://",
        }
        return self.post("/skills", json=data)

    def update_api(self, api_id: str, **kwargs) -> Skill:
        """Update API information"""
        return self.put(f"/skills/{api_id}", json=kwargs)

    def delete_api(self, api_id: str) -> bool:
        """Delete an API"""
        result = self.delete(f"/skills/{api_id}")
        return result.get("deleted", False)

    def list_my_apis(self) -> List[Skill]:
        """List my APIs"""
        result = self.get("/skills/my")
        return result if isinstance(result, list) else result.get("items", [])

    def get_api(self, api_id: str) -> Skill:
        """Get API details"""
        return self.get(f"/skills/{api_id}")

    def get_wallet(self) -> Wallet:
        """Get wallet balance"""
        return self.get("/wallet")

    def list_transactions(self) -> List[Transaction]:
        """List transactions"""
        result = self.get("/wallet/transactions")
        return result if isinstance(result, list) else result.get("items", [])

    def create_withdrawal(self, amount_credits: int) -> Withdrawal:
        """Create withdrawal request"""
        return self.post("/withdrawals", json={"amount_credits": amount_credits})

    def list_withdrawals(
        self,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        List withdrawal history

        Returns:
            {
                "items": [...],
                "page": 1,
                "page_size": 20,
                "total": 100
            }
        """
        params = {"page": page, "page_size": page_size}
        return self.get("/withdrawals", params=params)

    def upload_result_file(self, call_id: str, file_path: str) -> Dict[str, Any]:
        """
        Upload a result file for a call (free for providers).

        Args:
            call_id: The call ID to associate the file with
            file_path: Path to the file to upload

        Returns:
            Dict with file_id, filename, file_size, mime_type, url, expires_at
        """
        return self.upload_file("/files/upload-result", file_path, params={"call_id": call_id})

    def download_file(self, file_id: str, save_path: str) -> str:
        """
        Download a file by ID.

        Args:
            file_id: The file ID to download
            save_path: Path to save the downloaded file

        Returns:
            Path to the saved file
        """
        return super().download_file(f"/files/{file_id}", save_path)


class ProviderWorker:
    """Worker for processing jobs from AgentCab platform"""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://www.agentcab.ai/v1",
        process_fn: Optional[Callable[[Dict], Dict]] = None,
        agent_url: Optional[str] = None,
        command: Optional[str] = None,
        poll_interval: int = 5,
        max_workers: int = 1,
        timeout: int = 30,
        use_batch_mode: bool = True,
    ):
        """
        Initialize Provider Worker

        Args:
            api_key: AgentCab API key
            base_url: API base URL
            process_fn: Python function to process jobs (input_data -> output_data)
            agent_url: HTTP URL to forward jobs to
            command: Shell command to execute for each job
            poll_interval: Seconds between polling for new jobs
            max_workers: Number of concurrent workers
            timeout: Request timeout in seconds
            use_batch_mode: If True, use batch mode to pull jobs (recommended for multiple skills)
        """
        if not any([process_fn, agent_url, command]):
            raise ValueError("Must provide one of: process_fn, agent_url, command")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.process_fn = process_fn
        self.agent_url = agent_url
        self.command = command
        self.poll_interval = poll_interval
        self.max_workers = max_workers
        self.timeout = timeout
        self.use_batch_mode = use_batch_mode
        self.running = True

        # Job queue for batch mode (shared between processes)
        self.job_queue = Queue(maxsize=max_workers * 2) if use_batch_mode else None

        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

        self.client = BaseClient(api_key, base_url, timeout)

    def _shutdown(self, signum, frame):
        """Handle shutdown signals"""
        logger.info("Shutting down gracefully...")
        self.running = False

    def get_next_job(self, recovery: bool = False) -> Optional[Job]:
        """Poll for next available job (legacy single-job mode)"""
        try:
            params = {"recovery": "true"} if recovery else {}
            result = self.client.get("/provider/jobs/next", params=params)
            return result if result else None
        except AgentCabError as e:
            logger.error(f"Error getting next job: {e}")
            return None

    def get_next_jobs_batch(self, recovery: bool = False, skill_ids: Optional[List[str]] = None) -> List[Job]:
        """Poll for next available jobs in batch mode"""
        try:
            params = {}
            if recovery:
                params["recovery"] = "true"
            if skill_ids:
                params["skill_ids"] = ",".join(skill_ids)

            result = self.client.get("/provider/jobs/next-batch", params=params)
            return result if isinstance(result, list) else []
        except AgentCabError as e:
            logger.error(f"Error getting next jobs batch: {e}")
            return []

    def submit_result(
        self,
        call_id: str,
        output: Optional[Dict] = None,
        output_ref: Optional[str] = None,
        error_message: Optional[str] = None,
    ):
        """Submit job result"""
        payload = {}
        if output:
            payload["output"] = output
        if output_ref:
            payload["output_ref"] = output_ref
        if error_message:
            payload["error_message"] = error_message

        try:
            self.client.post(f"/provider/jobs/{call_id}/result", json=payload)
            logger.info(f"✓ Job {call_id} completed")
        except AgentCabError as e:
            logger.error(f"✗ Failed to submit result for {call_id}: {e}")

    def process_job(self, job: Job) -> Dict:
        """Process a job using configured method"""
        input_data = job["input"]

        if self.process_fn:
            # Python function mode - always pass full job object
            return self.process_fn(job)

        elif self.agent_url:
            # HTTP proxy mode
            response = requests.post(
                self.agent_url,
                json=input_data,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()

        elif self.command:
            # Command line mode
            import json
            process = subprocess.Popen(
                self.command,
                shell=True,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            stdout, stderr = process.communicate(
                input=json.dumps(job).encode(),
                timeout=self.timeout
            )
            if process.returncode != 0:
                raise Exception(f"Command failed: {stderr.decode()}")
            return json.loads(stdout.decode())

    def _job_puller_loop(self):
        """Job puller loop for batch mode - continuously pulls jobs and adds to queue"""
        logger.info("Job puller started")

        # First poll with recovery=True to pick up any stuck processing jobs
        first_poll = True

        while self.running:
            try:
                # Pull batch of jobs
                jobs = self.get_next_jobs_batch(recovery=first_poll)
                first_poll = False  # Only use recovery mode on first poll

                if jobs:
                    logger.info(f"Pulled {len(jobs)} job(s) from platform")
                    for job in jobs:
                        # Add to queue (blocks if queue is full)
                        self.job_queue.put(job)
                        logger.debug(f"Added job {job['call_id']} to queue")

                # Sleep before next poll
                time.sleep(self.poll_interval)

            except KeyboardInterrupt:
                break
            except Exception as e:
                logger.error(f"Job puller error: {e}")
                time.sleep(10)

        logger.info("Job puller stopped")

    def _worker_loop(self, worker_id: int):
        """Main worker loop"""
        logger.info(f"Worker {worker_id} started")

        if self.use_batch_mode:
            # Batch mode: consume jobs from queue
            while self.running:
                try:
                    # Get job from queue (blocks with timeout)
                    try:
                        job = self.job_queue.get(timeout=1)
                    except:
                        # Queue empty or timeout, continue
                        continue

                    call_id = job["call_id"]
                    logger.info(f"Worker {worker_id} processing job {call_id}")

                    try:
                        # Process job
                        output = self.process_job(job)

                        # Submit success result
                        self.submit_result(call_id, output=output)

                    except Exception as e:
                        # Submit error result
                        logger.error(f"Worker {worker_id} job {call_id} failed: {e}")
                        self.submit_result(call_id, error_message=str(e))

                except KeyboardInterrupt:
                    break
                except Exception as e:
                    logger.error(f"Worker {worker_id} error: {e}")
                    time.sleep(10)
        else:
            # Legacy mode: each worker independently polls
            # First poll with recovery=True to pick up any stuck processing jobs
            first_poll = True

            while self.running:
                try:
                    # Poll for next job
                    job = self.get_next_job(recovery=first_poll)
                    first_poll = False  # Only use recovery mode on first poll

                    if not job:
                        # No jobs available, wait and retry
                        time.sleep(self.poll_interval)
                        continue

                    call_id = job["call_id"]
                    logger.info(f"Worker {worker_id} processing job {call_id}")

                    try:
                        # Process job
                        output = self.process_job(job)

                        # Submit success result
                        self.submit_result(call_id, output=output)

                    except Exception as e:
                        # Submit error result
                        logger.error(f"Worker {worker_id} job {call_id} failed: {e}")
                        self.submit_result(call_id, error_message=str(e))

                except KeyboardInterrupt:
                    break
                except Exception as e:
                    logger.error(f"Worker {worker_id} error: {e}")
                    time.sleep(10)

        logger.info(f"Worker {worker_id} stopped")

    def run(self):
        """Start worker(s)"""
        if self.use_batch_mode:
            logger.info(f"Starting in batch mode with {self.max_workers} worker(s)...")

            # Start job puller process
            puller = Process(target=self._job_puller_loop)
            puller.start()

            # Start worker processes
            workers = []
            for i in range(self.max_workers):
                p = Process(target=self._worker_loop, args=(i,))
                p.start()
                workers.append(p)

            # Wait for all processes
            try:
                for p in workers:
                    p.join()
            finally:
                # Cleanup: terminate puller if still running
                if puller.is_alive():
                    puller.terminate()
                    puller.join()

        else:
            logger.info(f"Starting in legacy mode with {self.max_workers} worker(s)...")

            if self.max_workers == 1:
                # Single worker mode (no multiprocessing)
                self._worker_loop(0)
            else:
                # Multi-worker mode
                workers = []
                for i in range(self.max_workers):
                    p = Process(target=self._worker_loop, args=(i,))
                    p.start()
                    workers.append(p)

                # Wait for all workers
                for p in workers:
                    p.join()

        logger.info("All workers stopped")
