
from romayneutils.conversions_util import bytes_to_str, str_to_bytes

import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

def generate_deterministic_key(password:str) -> str:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b'',
        iterations=1_200_200,
    )
    key = base64.urlsafe_b64encode(kdf.derive(str_to_bytes(password)))
    return bytes_to_str(key)

def encrypt_password(PasswordConverter:Fernet, password:str) -> str:
    return bytes_to_str(PasswordConverter.encrypt(str_to_bytes(password)))

def decrypt_password(PasswordConverter:Fernet, password:str) -> str:
    return bytes_to_str(PasswordConverter.decrypt(str_to_bytes(password)))