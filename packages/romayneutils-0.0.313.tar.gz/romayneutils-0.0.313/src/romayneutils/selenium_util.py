
from selenium import webdriver
from selenium.webdriver import Chrome

# A simple set of configuration options to use for creating a chrome webdriver.
def get_driver() -> Chrome:
    print("Loading webdriver...")
    options = webdriver.ChromeOptions()
    options.add_argument(rf"--user-data-dir=C:\Users\Romayne\AppData\Local\Google\Chrome\User Data")
    options.add_argument(rf'--profile-directory=Profile 1')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.binary_location = rf'C:\Program Files\Google\Chrome\Application\chrome.exe'
    driver = webdriver.Chrome(options)
    driver.implicitly_wait(5)
    return driver
