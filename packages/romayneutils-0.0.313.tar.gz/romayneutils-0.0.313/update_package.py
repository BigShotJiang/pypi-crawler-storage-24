
import os, time, subprocess
from colorama import Fore
from importlib.metadata import version
import pyperclip as pc

"""
Flavor
"""
print_important = f"{Fore.RED}HEY: {Fore.RESET}"

"""
Update pip & our local package while we're here, before anything else
"""
subprocess.call("py -m pip install --upgrade pip")
subprocess.call("py -m pip install romayneutils --upgrade")

"""
Update version number automagically if not manually set
"""
current_version = version("RomayneUtils")
new_version = None
version_number_index = 0
pyproject_toml_file_dir = "C:\\Users\\Romayne\\Coding\\utilities\\pyproject.toml"
pyproject_toml_file_lines = open(pyproject_toml_file_dir, "r").readlines()
for line in pyproject_toml_file_lines:
    if line.startswith("version"):
        start = line.index("\"") + 1
        end = line[start::].index("\"") + start
        new_version = line[start:end]
        break
    version_number_index += 1

if (current_version == new_version):
    new_version = f"{new_version[:-1]}{int(new_version[-1:])+1}"
    new_version_formatted = f"version = \"{new_version}\"\n"
    pyproject_toml_file_lines[version_number_index] = new_version_formatted

open(pyproject_toml_file_dir, "w").writelines(pyproject_toml_file_lines)

"""
Remove old distribution files
"""
dist = "C:\\Users\\Romayne\\Coding\\utilities\\dist"
filelist = [f for f in os.listdir(dist)]
for f in filelist:
    os.remove(os.path.join(dist, f))

"""
Grab API key to keyboard for user to paste
"""
os.chdir("C:/Users/Romayne/Coding/utilities")
subprocess.call("py -m build")
local_api_key = open("A:/backups/pypi_api_key.txt", "r").read()
previous_clipboard_contents = pc.paste()
# its a pain to paste the api key into the actual field automatically so yeah thisll do for a script
pc.copy(local_api_key)
# i forget because adhd or smth
print(f"{print_important}I copied the API key to the keyboard and saved your previous clipboard contents. Don't forget to paste it when it asks!")
subprocess.call("py -m twine upload dist/* --verbose")
pc.copy(previous_clipboard_contents)

"""
Wait for update to reflect on pypi and upgrade local version of package
"""
initial_delay_seconds = 5
refresh_delay_seconds = 1
max_update_attempts = 60
update_attempts = 0

print(f"{print_important}Trying to upgrade the package. Don't quit this script!")
time.sleep(initial_delay_seconds)
while ((current_version != new_version) and (max_update_attempts > update_attempts)):
    update_attempts += 1
    print(f"{print_important} Initiating package update attempt #{update_attempts}.")
    subprocess.call("py -m pip install romayneutils --upgrade")
    time.sleep(refresh_delay_seconds)
    current_version = version("RomayneUtils")

print(f"{print_important}Script completed :)")