"""Utility helpers for mailagent."""
