# Instructions

L'élève propose *la requête SQL* suivante :

{{sec_start}}
```sql
{{requete}}
```
{{sec_end}}

Indique de manière synthétique l'objectif fonctionnel de cette requête. 
