"""
crunch
~~~~~~
The crunch package - a Python cli used to submit
your work to the crunch hub easily!
"""

import crunch.api as api
import crunch.store as store
from crunch.inline import load as load_notebook
from crunch.runner import is_inside as is_inside_runner
