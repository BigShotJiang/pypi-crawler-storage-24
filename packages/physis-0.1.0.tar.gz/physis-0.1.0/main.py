def main():
    print("Hello from physis!")


if __name__ == "__main__":
    main()
