"""CertiSigma Census — Cryptographic file inventory and exfiltration detection."""

__version__ = "1.8.0"
