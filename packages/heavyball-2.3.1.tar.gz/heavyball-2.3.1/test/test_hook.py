import os

os.environ["TORCH_LOGS"] = "+recompiles"

import pytest
import torch
from torch import nn
from torch._dynamo import config
from utils import REPRESENTATIVE_OPTS

import heavyball
from heavyball.utils import clean, hook_optimizer_into_model, set_torch

heavyball.utils.compile_mode = None
config.cache_size_limit = 128


@pytest.mark.parametrize("opt", REPRESENTATIVE_OPTS)
def test_foreach(opt, size: int = 128, depth: int = 1, iterations: int = 32, outer_iterations: int = 1):
    set_torch()
    opt = getattr(heavyball, opt)

    losses = []

    for use_hook in [False, True]:
        torch.manual_seed(0x2131290)
        losses.append([])

        for i in range(outer_iterations):
            model = nn.Sequential(*[nn.Linear(size, size) for _ in range(depth)]).cuda()

            if use_hook:
                hook_optimizer_into_model(model, opt, lr=1e-3, weight_decay=1e-4, warmup_steps=16)
            else:
                o = opt(model.parameters(), lr=1e-3, weight_decay=1e-4, warmup_steps=16)
            for _ in range(iterations):
                loss = model(torch.randn((1024, size), device="cuda")).square().mean()
                loss.backward()
                if not use_hook:
                    o.step()
                    o.zero_grad()
                losses[-1].append(loss.detach())

            clean()

    for i, (l0, l1) in enumerate(zip(*losses)):
        print(i, l0.item(), l1.item())
        assert torch.allclose(l0.float(), l1.float(), rtol=0.05)
