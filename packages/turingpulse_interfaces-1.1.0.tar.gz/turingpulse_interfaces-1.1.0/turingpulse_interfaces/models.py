"""Pydantic models shared across TuringPulse services."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class NodeType(str, Enum):
    """Canonical classification of span/node operations across the platform.

    Every span in a trace is assigned a node_type that determines which KPI
    rules apply, how it renders in the Portal, and what metrics are extracted.
    This enum is the single source of truth — SDKs, backend services, Flink
    pipeline, and the Portal all import from here.
    """

    LLM = "llm"
    TOOL = "tool"
    RETRIEVER = "retriever"
    AGENT = "agent"
    WORKFLOW = "workflow"
    FUNCTION = "function"
    PROCESSOR = "processor"
    EVALUATOR = "evaluator"
    DECISION = "decision"
    TRANSFORM = "transform"
    VALIDATOR = "validator"
    AGGREGATOR = "aggregator"
    ROUTER = "router"
    HUMAN = "human"
    EXTERNAL_API = "external_api"
    DATABASE = "database"
    CACHE = "cache"
    EMBEDDER = "embedder"
    CUSTOM = "custom"


# Subset of NodeType values that produce measurable telemetry metrics.
# Used by observability queries and Flink operators to filter spans
# for KPI computation, drift detection, and anomaly analysis.
METRIC_NODE_TYPES: frozenset[str] = frozenset({
    NodeType.LLM,
    NodeType.TOOL,
    NodeType.RETRIEVER,
    NodeType.FUNCTION,
    NodeType.PROCESSOR,
    NodeType.EMBEDDER,
    NodeType.EVALUATOR,
    NodeType.DATABASE,
    NodeType.EXTERNAL_API,
    NodeType.CACHE,
})


class AgenticPattern(str, Enum):
    """Classification of agentic execution patterns.

    Used to tag traces/runs so users can compare performance across
    different architectural patterns (e.g., ReAct vs Plan-and-Execute).
    SDKs auto-detect the pattern from the span tree structure when
    framework integrations provide hints; users can also set it manually.
    """

    REACT = "react"
    PLAN_AND_EXECUTE = "plan_and_execute"
    REFLEXION = "reflexion"
    MULTI_AGENT = "multi_agent"
    TOOL_USE = "tool_use"
    RAG = "rag"
    CHAIN_OF_THOUGHT = "chain_of_thought"
    CUSTOM = "custom"


class AgentEventType(str, Enum):
    SPAN = "span"
    METRIC = "metric"
    STATE = "state"
    AGENT_STEP = "agent_step"  # Used by TuringPulse SDK for workflow node spans


class TokenBreakdown(BaseModel):
    prompt: int = 0
    completion: int = 0


class ToolCallInfo(BaseModel):
    """Information about a tool call made by an agent."""
    tool_name: str
    tool_args: Dict[str, Any] = Field(default_factory=dict)
    tool_result: Optional[str] = None
    tool_id: Optional[str] = None
    success: bool = True
    error_message: Optional[str] = None


class AgentEventPayload(BaseModel):
    name: str
    duration_ms: Optional[int] = None
    tokens: Optional[TokenBreakdown] = None
    cost_usd: Optional[float] = None
    status: Optional[str] = None
    reasoning: Optional[str] = None
    # Changed from Dict[str, str] to Dict[str, Any] to support numeric metadata values
    metadata: Dict[str, Any] = Field(default_factory=dict)
    # Tool calls made by the agent
    tool_calls: Optional[List[ToolCallInfo]] = None


class AgentEvent(BaseModel):
    run_id: str
    agent_id: str
    timestamp: datetime
    type: AgentEventType
    payload: AgentEventPayload
    workflow_name: Optional[str] = None


class AgentNode(BaseModel):
    node_id: str
    name: str
    runtime_ms: int
    status: str
    parent_node_id: Optional[str] = None


class AgentRunMetrics(BaseModel):
    latency_ms: int
    cost_usd: float
    tokens_total: int


class AgentRun(BaseModel):
    run_id: str
    agent_id: str
    tenant_id: Optional[str] = None  # Tenant isolation
    project_id: Optional[str] = None  # Project isolation (UUID)
    workflow_id: Optional[str] = None  # Workflow ID for strict filtering
    workflow_name: Optional[str] = None  # Workflow display name
    workflow_run_id: Optional[str] = None  # Workflow run ID
    started_at: datetime
    completed_at: Optional[datetime]
    status: str
    metrics: Optional[AgentRunMetrics]
    nodes: List[AgentNode] = Field(default_factory=list)


class TaskStatus(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    NEEDS_HUMAN = "needs_human"
    COMPLETED = "completed"


class HITLAction(BaseModel):
    reviewer: str
    comment: str
    created_at: datetime
    resolution: Optional[str]


class AgentTask(BaseModel):
    task_id: str
    title: str
    status: TaskStatus = TaskStatus.TODO
    assignee: Optional[str]
    agent_run_id: Optional[str]
    hitl_required: bool = False
    metadata: Dict[str, str] = Field(default_factory=dict)
    hitl_actions: List[HITLAction] = Field(default_factory=list)


class AttachmentDirection(str, Enum):
    INPUT = "input"
    OUTPUT = "output"


class AttachmentMetadata(BaseModel):
    """Metadata for a document attached to a span."""

    attachment_id: str
    filename: str
    mime_type: str
    size_bytes: int
    compressed_size_bytes: Optional[int] = None
    direction: AttachmentDirection
    storage_path: str
    extracted_text_length: Optional[int] = None
    extraction_method: Optional[str] = None
    checksum_sha256: Optional[str] = None


class AttachmentUploadResponse(BaseModel):
    """Response from the attachment upload endpoint."""

    attachment_id: str
    filename: str
    mime_type: str
    size_bytes: int
    extracted_text: Optional[str] = None
    storage_path: str
    deduplicated: bool = False
