"""Shared LLM provider configuration model."""

from __future__ import annotations

from typing import Dict

from pydantic import BaseModel, Field


class LLMProvider(BaseModel):
    name: str
    provider: str
    model: str
    framework: str
    max_context_tokens: int | None = None
    temperature: float | None = None
    metadata: Dict[str, str] = Field(default_factory=dict)
