"""
Time-series granularity definitions — Single Source of Truth.

This module defines the canonical resolution types, the mapping from time
range duration to recommended resolution, and helpers consumed by both
Python backends and (via the mirrored TypeScript module) the portal.

Only trace-metric time-series endpoints use these resolutions.  Pre-computed
KPI values, drift/anomaly events, and dimensional list endpoints are *not*
affected by resolution.
"""

from __future__ import annotations

from datetime import timedelta
from enum import Enum
from typing import Dict, List, Set, Tuple


class Resolution(str, Enum):
    """Supported time-series bucket widths."""

    ONE_MINUTE = "1m"
    FIVE_MINUTES = "5m"
    FIFTEEN_MINUTES = "15m"
    ONE_HOUR = "1h"
    SIX_HOURS = "6h"
    ONE_DAY = "1d"


RESOLUTION_DELTAS: Dict[Resolution, timedelta] = {
    Resolution.ONE_MINUTE: timedelta(minutes=1),
    Resolution.FIVE_MINUTES: timedelta(minutes=5),
    Resolution.FIFTEEN_MINUTES: timedelta(minutes=15),
    Resolution.ONE_HOUR: timedelta(hours=1),
    Resolution.SIX_HOURS: timedelta(hours=6),
    Resolution.ONE_DAY: timedelta(days=1),
}

RESOLUTION_CH_INTERVAL: Dict[Resolution, str] = {
    Resolution.ONE_MINUTE: "1 MINUTE",
    Resolution.FIVE_MINUTES: "5 MINUTE",
    Resolution.FIFTEEN_MINUTES: "15 MINUTE",
    Resolution.ONE_HOUR: "1 HOUR",
    Resolution.SIX_HOURS: "6 HOUR",
    Resolution.ONE_DAY: "1 DAY",
}

# Ordered list of (max_hours_inclusive, resolution).
# The first entry whose threshold >= the requested duration wins.
RANGE_TO_RESOLUTION: List[Tuple[float, Resolution]] = [
    (1, Resolution.ONE_MINUTE),
    (6, Resolution.FIVE_MINUTES),
    (24, Resolution.FIFTEEN_MINUTES),
    (72, Resolution.ONE_HOUR),
    (336, Resolution.SIX_HOURS),
    (float("inf"), Resolution.ONE_DAY),
]

VALID_RESOLUTIONS: Set[str] = {r.value for r in Resolution}

# Legacy values accepted by earlier API versions.
LEGACY_RESOLUTION_MAP: Dict[str, Resolution] = {
    "minute": Resolution.ONE_MINUTE,
    "hour": Resolution.ONE_HOUR,
    "day": Resolution.ONE_DAY,
}


def resolve_granularity(duration_hours: float) -> Resolution:
    """Return the recommended resolution for a given time-range duration."""
    for threshold_hours, resolution in RANGE_TO_RESOLUTION:
        if duration_hours <= threshold_hours:
            return resolution
    return Resolution.ONE_DAY


def normalize_resolution(value: str) -> Resolution:
    """Accept both new (``"5m"``) and legacy (``"minute"``) resolution strings.

    Raises ``ValueError`` when *value* is not recognised.
    """
    if value in LEGACY_RESOLUTION_MAP:
        return LEGACY_RESOLUTION_MAP[value]
    return Resolution(value)
