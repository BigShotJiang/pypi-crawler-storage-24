# CodedThemes CLI

CodedThemes CLI is a powerful command-line tool designed to integrate your local development environment with the CodedThemes MCP Server. It allows you to automate UI/UX modifications, refactor themes, and apply stylistic changes across your entire repository using AI-driven insights.

## Features

- **Automated Theming**: Apply complex theme changes (e.g., branding updates) with simple natural language queries.
- **Local-to-Cloud Sync**: Securely sync your repository state to the CodedThemes engine for deep analysis.
- **Seamless Integration**: Automatically patches local files with surgical precision.
- **Sync Management**: Tracks local changes to ensure your manual edits are never overwritten.

## Installation

Install the CLI directly from PyPI:

```bash
pip install codedthemes-cli
```

## Usage

### 1. Authentication

Authenticate with your CodedThemes account to enable secure communication with the MCP server.

```bash
codedthemes login
```
*Enter your registered email and license key when prompted.*

### 2. Logout

Log out from the current device to free up a license slot on the server.

```bash
codedthemes logout
```

### 3. Initialization (Optional)

Initialize your repository to establish a baseline for synchronization. This is recommended for first-time use in a project.

```bash
codedthemes init
```

### 3. Applying Changes

Describe the changes you want to make in natural language. The CLI will analyze your repository, plan the changes, and ask for your approval before patching.

```bash
codedthemes apply "Update the theme branding from Mantis to Berry"
```

## Integration Report

After every successful `apply`, a granular report is generated showing exactly which files were modified, created, or deleted.

## Support

For issues or feature requests, please contact the CodedThemes support team.
