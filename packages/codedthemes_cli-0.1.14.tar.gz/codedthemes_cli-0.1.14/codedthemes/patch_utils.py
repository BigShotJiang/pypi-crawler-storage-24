import subprocess


def apply_patch(patch_text: str):
    # Using 'git apply -' to apply from stdin
    process = subprocess.Popen(
        ["git", "apply", "-"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    stdout, stderr = process.communicate(input=patch_text)

    if process.returncode != 0:
        raise Exception(f"Patch failed to apply.\nStdout: {stdout}\nStderr: {stderr}")

    print("✔ Patch applied successfully.")
