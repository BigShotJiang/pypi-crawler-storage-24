"""
Dokodemo AI - Run trillion-parameter models on consumer GPUs.

Adaptive hierarchical offloading with expert-aware scheduling,
model-agnostic graph compilation, and dynamic precision allocation.
"""

__version__ = "0.1.0"

from dokodemo_ai.auto_model import AutoModel

__all__ = ["AutoModel", "__version__"]
