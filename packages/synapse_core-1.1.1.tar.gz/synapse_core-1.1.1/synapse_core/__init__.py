__version__ = "1.1.1"

from .ai import DEFAULT_MODELS, PROVIDERS, detect_provider, generate_answer
from .config import load_config, save_config
from .exceptions import CollectionNotFoundError, SourceNotFoundError, SynapseError, TableNotFoundError
from .extractors import SUPPORTED_EXTENSIONS, is_supported
from .logger import setup_logging
from .models import CollectionStats, IngestProgress, IngestResult, PurgeResult, QueryResult
from .pipeline import (
    collection_stats,
    delete_source,
    ingest,
    ingest_async,
    ingest_many,
    list_collections,
    purge,
    query,
    query_async,
    reset,
    sources,
)
from .sqlite_ingester import ingest_sqlite

__all__ = [
    "__version__",
    # core API
    "collection_stats",
    "delete_source",
    "ingest",
    "ingest_async",
    "ingest_many",
    "ingest_sqlite",
    "list_collections",
    "purge",
    "query",
    "query_async",
    "reset",
    "setup_logging",
    "sources",
    # config
    "load_config",
    "save_config",
    # AI
    "DEFAULT_MODELS",
    "PROVIDERS",
    "detect_provider",
    "generate_answer",
    # formats
    "SUPPORTED_EXTENSIONS",
    "is_supported",
    # models
    "CollectionStats",
    "IngestProgress",
    "IngestResult",
    "PurgeResult",
    "QueryResult",
    # exceptions
    "CollectionNotFoundError",
    "SourceNotFoundError",
    "SynapseError",
    "TableNotFoundError",
]
