from __future__ import annotations

import streamlit as st

from recursivecharactertextsplitter.core import (
    build_output_zip_bytes,
    split_markdown_zip_bytes,
    summarize_results,
)


st.set_page_config(
    page_title="RecursiveCharacterTextSplitter",
    page_icon="✂️",
    layout="wide",
)

st.title("RecursiveCharacterTextSplitter")
st.caption("Take a .zip of Markdown chunks and split them again into smaller recursive character chunks.")

with st.sidebar:
    st.header("Settings")
    chunk_size = st.number_input("Chunk size (characters)", min_value=50, max_value=50000, value=1200, step=50)
    chunk_overlap = st.number_input("Chunk overlap (characters)", min_value=0, max_value=10000, value=150, step=25)
    separators_text = st.text_area(
        "Separators in order (one per line)",
        value="\\n\\n\n\\n\n. \n ",
        height=120,
        help="The splitter tries these separators from top to bottom before falling back to raw character windows.",
    )

uploaded = st.file_uploader("Drag the output .zip from MarkdownHeaderTextSplitter here", type=["zip"])

if uploaded is None:
    st.info("Upload a .zip file that contains .md chunks to preview and export recursively split chunks.")
    st.stop()

zip_bytes = uploaded.read()
separator_lines = []
for raw_line in separators_text.splitlines():
    line = raw_line.strip()
    if not line:
        continue
    line = line.replace("\\n", "\n").replace("\\t", "\t")
    separator_lines.append(line)

try:
    manifest, output_files = split_markdown_zip_bytes(
        zip_bytes,
        chunk_size=int(chunk_size),
        chunk_overlap=int(chunk_overlap),
        separators=separator_lines,
    )
except Exception as exc:
    st.error(str(exc))
    st.stop()

summary = summarize_results(manifest, output_files)
export_bytes = build_output_zip_bytes(manifest, output_files, uploaded.name)

col1, col2 = st.columns([1, 2])
with col1:
    st.metric("Input markdown files", summary["input_markdown_files"])
    st.metric("Output chunks", summary["output_chunks"])
    st.metric("Total output characters", summary["total_output_characters"])
    st.download_button(
        label="Download recursive split .zip",
        data=export_bytes,
        file_name=f"{uploaded.name.rsplit('.', 1)[0]}_recursive_chunks.zip",
        mime="application/zip",
    )

with col2:
    st.subheader("Chunk manifest")
    st.dataframe(manifest, use_container_width=True)

st.subheader("Chunk preview")
for item in manifest:
    chunk_text = output_files[item["output_file"]]
    with st.expander(f"{item['output_file']} — from {item['source_file']} — {item['char_count']} chars"):
        st.code(chunk_text, language="markdown")
