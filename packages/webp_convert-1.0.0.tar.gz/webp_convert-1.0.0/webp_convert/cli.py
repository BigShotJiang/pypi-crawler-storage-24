"""
webp_convert.cli
Click-based CLI entry point.

Usage:
    webp-convert [INPUT_DIR] [options]
"""

import sys
import time
import click
from pathlib import Path
from .converter import ConvertConfig, SizeSpec, convert
from .watcher import watch as do_watch


def _parse_sizes(sizes_str: str):
    """Parse '1200,800,400' → list of SizeSpec."""
    specs = []
    for part in sizes_str.split(","):
        w = int(part.strip())
        specs.append(SizeSpec(width=w, suffix="" if w == 0 else f"-{w}"))
    return specs


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("input_dir", default="assets/images", metavar="[INPUT_DIR]")
@click.option("-o", "--output",    default=None,  help="Output directory (default: same as source)")
@click.option("-q", "--quality",   default=80,    show_default=True, help="WebP quality 0-100")
@click.option("--lossless",        is_flag=True,  help="Lossless encoding")
@click.option(
    "--sizes", "sizes_str",
    default=None,
    metavar="W,W,...",
    help="Responsive widths e.g. 1200,800,400 (0=full). Default: 0,800,400",
)
@click.option("--no-full",         is_flag=True,  help="Skip full-size, only responsive variants")
@click.option("-r", "--recursive", is_flag=True,  help="Recurse into subdirectories")
@click.option("--no-overwrite",    is_flag=True,  help="Skip files that already have a .webp")
@click.option("-w", "--watch",     "watch_mode",  is_flag=True, help="Watch mode")
@click.option("--silent",          is_flag=True,  help="Suppress all output")
def main(input_dir, output, quality, lossless, sizes_str, no_full, recursive,
         no_overwrite, watch_mode, silent):
    """
    Convert PNG/JPG images to WebP with responsive size variants.

    \b
    Examples:
      webp-convert
      webp-convert src/img -q 90 -o dist/img
      webp-convert src/img --sizes 1200,800,400
      webp-convert src/img --watch
    """

    # Build sizes list
    if sizes_str:
        sizes = _parse_sizes(sizes_str)
        if not no_full and not any(s.width == 0 for s in sizes):
            sizes.insert(0, SizeSpec(width=0, suffix=""))
    else:
        sizes = [SizeSpec(0, ""), SizeSpec(800, "-800"), SizeSpec(400, "-400")]
        if no_full:
            sizes = [s for s in sizes if s.width != 0]

    cfg = ConvertConfig(
        input=input_dir,
        output=output,
        quality=quality,
        lossless=lossless,
        sizes=sizes,
        overwrite=not no_overwrite,
        recursive=recursive,
        silent=silent,
    )

    if watch_mode:
        watcher = do_watch(cfg).start()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            click.echo("\n stopping watcher...")
            watcher.stop()
    else:
        convert(cfg)


if __name__ == "__main__":
    main()
