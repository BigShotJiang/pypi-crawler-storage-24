"""
webp_convert.converter
Core image conversion logic using Pillow.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional, Union

from PIL import Image

# ─── Config ───────────────────────────────────────────────────────────────────

@dataclass
class SizeSpec:
    width: int          # 0 = full size (no resize)
    suffix: str         # e.g. "-800", "" for full-size


DEFAULT_SIZES = [
    SizeSpec(width=0,   suffix=""),
    SizeSpec(width=800, suffix="-800"),
    SizeSpec(width=400, suffix="-400"),
]

DEFAULT_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".tiff", ".bmp", ".webp"}

@dataclass
class ConvertConfig:
    input: Union[str, List[str]] = "assets/images"
    output: Optional[str] = None          # None = same folder as source
    quality: int = 80
    lossless: bool = False
    sizes: List[SizeSpec] = field(default_factory=lambda: list(DEFAULT_SIZES))
    keep_originals: bool = True
    overwrite: bool = True
    recursive: bool = False
    extensions: set = field(default_factory=lambda: set(DEFAULT_EXTENSIONS))
    on_file: Optional[Callable] = None    # called with ConvertResult per output
    on_done: Optional[Callable] = None    # called with list[ConvertResult] when batch finishes
    silent: bool = False


DEFAULT_CONFIG = ConvertConfig()


# ─── Result ───────────────────────────────────────────────────────────────────

@dataclass
class ConvertResult:
    src: Path
    dest: Path
    width: Union[int, str]   # int or "original"
    size_bytes: int


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _get_output_path(src: Path, suffix: str, cfg: ConvertConfig) -> Path:
    if cfg.output:
        base_dir = Path(cfg.output)
    else:
        base_dir = src.parent
    return base_dir / f"{src.stem}{suffix}.webp"


def _log(cfg: ConvertConfig, *args):
    if not cfg.silent:
        print(*args)


# ─── Single-file conversion ───────────────────────────────────────────────────

def convert_file(src: Union[str, Path], cfg: Optional[ConvertConfig] = None) -> List[ConvertResult]:
    """
    Convert a single image file to all configured WebP sizes.
    Returns a list of ConvertResult objects.

    Example::

        from webp_convert import convert_file, ConvertConfig
        results = convert_file("hero.jpg", ConvertConfig(quality=90))
    """
    cfg = cfg or ConvertConfig()
    src = Path(src)
    results = []

    if cfg.output:
        Path(cfg.output).mkdir(parents=True, exist_ok=True)

    with Image.open(src) as img:
        # Ensure RGB(A) for proper WebP encoding
        if img.mode not in ("RGB", "RGBA"):
            img = img.convert("RGBA" if img.mode == "P" and "transparency" in img.info else "RGB")

        for spec in cfg.sizes:
            dest = _get_output_path(src, spec.suffix, cfg)

            if not cfg.overwrite and dest.exists():
                _log(cfg, f"  skip  {dest} (exists)")
                continue

            if spec.width > 0:
                ratio = spec.width / img.width
                # Don't enlarge
                if ratio < 1.0:
                    new_h = int(img.height * ratio)
                    resized = img.resize((spec.width, new_h), Image.LANCZOS)
                else:
                    resized = img
            else:
                resized = img

            save_kwargs = {"format": "WEBP", "quality": cfg.quality}
            if cfg.lossless:
                save_kwargs["lossless"] = True

            resized.save(dest, **save_kwargs)
            size_bytes = dest.stat().st_size
            result = ConvertResult(
                src=src,
                dest=dest,
                width=spec.width if spec.width > 0 else "original",
                size_bytes=size_bytes,
            )

            _log(cfg, f"  → {dest}  ({size_bytes / 1024:.1f} KB)")

            if cfg.on_file:
                cfg.on_file(result)

            results.append(result)

    return results


# ─── Directory conversion ─────────────────────────────────────────────────────

def convert_dir(input_dir: Union[str, Path], cfg: Optional[ConvertConfig] = None) -> List[ConvertResult]:
    """
    Convert all matching images in a directory.
    """
    cfg = cfg or ConvertConfig()
    input_dir = Path(input_dir)
    all_results: List[ConvertResult] = []

    pattern = "**/*" if cfg.recursive else "*"
    for path in input_dir.glob(pattern):
        if not path.is_file():
            continue
        if path.suffix.lower() not in cfg.extensions:
            continue
        if path.suffix.lower() == ".webp":
            continue

        _log(cfg, f"processing {path}")
        try:
            results = convert_file(path, cfg)
            all_results.extend(results)
        except Exception as exc:
            print(f"  error: {path}: {exc}")

    return all_results


# ─── Batch (multi-dir) ────────────────────────────────────────────────────────

def convert(cfg: Optional[ConvertConfig] = None, **kwargs) -> List[ConvertResult]:
    """
    Main entry point. Convert all images in one or more input directories.

    Can be called with a ConvertConfig object or keyword arguments::

        # Using a config object
        from webp_convert import convert, ConvertConfig
        results = convert(ConvertConfig(input="src/images", quality=85))

        # Using keyword args (creates a ConvertConfig internally)
        results = convert(input="src/images", quality=85)
    """
    if cfg is None:
        cfg = ConvertConfig(**kwargs)
    elif kwargs:
        # Merge kwargs into a copy of cfg
        cfg_dict = cfg.__dict__.copy()
        cfg_dict.update(kwargs)
        cfg = ConvertConfig(**cfg_dict)

    inputs = cfg.input if isinstance(cfg.input, list) else [cfg.input]
    all_results: List[ConvertResult] = []

    _log(cfg, "\n webp-convert — starting...\n")

    for d in inputs:
        results = convert_dir(d, cfg)
        all_results.extend(results)

    _log(cfg, f"\n ✓ done — converted {len(all_results)} file(s)")

    if cfg.on_done:
        cfg.on_done(all_results)

    return all_results
