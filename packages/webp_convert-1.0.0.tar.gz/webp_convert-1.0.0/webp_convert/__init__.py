"""
webp-convert — Python package
Convert PNG/JPG/GIF/TIFF images to WebP with responsive size variants.
"""

from .converter import convert, convert_file, convert_dir, DEFAULT_CONFIG
from .watcher import watch

__all__ = ["convert", "convert_file", "convert_dir", "watch", "DEFAULT_CONFIG"]
__version__ = "1.0.0"
