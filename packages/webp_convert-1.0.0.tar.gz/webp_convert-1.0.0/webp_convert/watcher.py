"""
webp_convert.watcher
File watching support using watchdog.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Optional, Union, List

from watchdog.events import FileSystemEventHandler, FileCreatedEvent, FileModifiedEvent
from watchdog.observers import Observer

from .converter import ConvertConfig, convert_file


class _ImageEventHandler(FileSystemEventHandler):
    def __init__(self, cfg: ConvertConfig):
        self.cfg = cfg

    def _handle(self, src_path: str):
        path = Path(src_path)
        if path.suffix.lower() not in self.cfg.extensions:
            return
        if path.suffix.lower() == ".webp":
            return
        if not self.cfg.silent:
            print(f"\n changed: {path}")
        try:
            convert_file(path, self.cfg)
        except Exception as exc:
            print(f"  error: {exc}")

    def on_created(self, event):
        if not event.is_directory:
            self._handle(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._handle(event.src_path)


class Watcher:
    """
    Wraps a watchdog Observer. Call .start() to begin watching, .stop() to end.
    The context manager interface handles start/stop automatically.
    """

    def __init__(self, cfg: ConvertConfig):
        self.cfg = cfg
        self._observer = Observer()
        inputs = cfg.input if isinstance(cfg.input, list) else [cfg.input]
        handler = _ImageEventHandler(cfg)
        for d in inputs:
            self._observer.schedule(handler, str(d), recursive=cfg.recursive)

    def start(self):
        self._observer.start()
        if not self.cfg.silent:
            inputs = self.cfg.input if isinstance(self.cfg.input, list) else [self.cfg.input]
            print("\n webp-convert — watching...")
            for d in inputs:
                print(f"  watching: {d}")
        return self

    def stop(self):
        self._observer.stop()
        self._observer.join()

    def __enter__(self):
        return self.start()

    def __exit__(self, *_):
        self.stop()


def watch(cfg: Optional[ConvertConfig] = None, **kwargs) -> Watcher:
    """
    Watch input directories and auto-convert images on change.
    Returns a Watcher instance. Call .start() to begin (or use as context manager).

    Example::

        from webp_convert import watch, ConvertConfig

        # Context manager (blocks until Ctrl-C)
        with watch(ConvertConfig(input="src/images")).start():
            try:
                while True:
                    import time; time.sleep(1)
            except KeyboardInterrupt:
                pass

        # Manual control
        watcher = watch(input="src/images").start()
        # ... later:
        watcher.stop()
    """
    if cfg is None:
        cfg = ConvertConfig(**kwargs)
    return Watcher(cfg)
