# -*- coding: utf-8 -*-

#################################################################
# File        : channel.py
# Author      : sebi06
#
#################################################################

from typing import Union, List, Dict
from dataclasses import dataclass, field
from box import Box, BoxList
import os
from czitools.utils import logging_tools, pixels
from czitools.utils.box import get_czimd_box
from pylibCZIrw import czi as pyczi
import numpy as np

logger = logging_tools.set_logging()


@dataclass
class CziChannelInfo:
    """
    Small helper class that extracts and normalizes channel-related
    metadata from a CZI (as a `Box` or file path). The object collects
    channel names, dyes, display colors, intensity limits and builds
    pylibCZIrw-compatible display settings.

    Attributes (selected):
      - `czisource`: CZI filepath or metadata `Box`.
      - `names`, `dyes`, `colors`, `clims`, `gamma`: per-channel lists.
      - `pixeltypes`, `isRGB`: maps channel index -> pixel type / RGB flag.
      - `czi_disp_settings`: mapping channel index -> pylibCZIrw display settings.

    The class focuses on data normalization and does not open large image
    pixel arrays — it only reads lightweight metadata from the CZI.
    """

    czisource: Union[str, os.PathLike[str], Box]
    names: List[str] = field(init=False, default_factory=lambda: [])
    dyes: List[str] = field(init=False, default_factory=lambda: [])
    dyes_short: List[str] = field(init=False, default_factory=lambda: [])
    channel_descriptions: List[str] = field(init=False, default_factory=lambda: [])
    colors: List[str] = field(init=False, default_factory=lambda: [])
    clims: List[List[float]] = field(init=False, default_factory=lambda: [])
    gamma: List[float] = field(init=False, default_factory=lambda: [])
    pixeltypes: Dict[int, str] = field(init=False, default_factory=lambda: {})
    isRGB: Dict[int, bool] = field(init=False, default_factory=lambda: {})
    consistent_pixeltypes: bool = field(init=False, default=None)
    czi_disp_settings: Dict[int, pyczi.ChannelDisplaySettingsDataClass] = field(init=False, default_factory=lambda: {})
    verbose: bool = False

    def __post_init__(self):
        if self.verbose:
            logger.info("Reading Channel Information from CZI image data.")

        if isinstance(self.czisource, Box):
            czi_box = self.czisource
        else:
            czi_box = get_czimd_box(self.czisource)

        # get channels part of metadata
        if czi_box.has_channels:
            try:
                # extract the relevant dimension metadata_tools
                channels = czi_box.ImageDocument.Metadata.Information.Image.Dimensions.Channels.Channel
                if isinstance(channels, Box):
                    # get the data in case of only one channel
                    (self.names.append("CH1") if channels.Name is None else self.names.append(channels.Name))
                elif isinstance(channels, BoxList):
                    # get the data in case multiple channels
                    for ch in range(len(channels)):
                        (
                            self.names.append("CH1")
                            if channels[ch].Name is None
                            else self.names.append(channels[ch].Name)
                        )

                # get the pixel types for all channels
                with pyczi.open_czi(str(czi_box.filepath), czi_box.czi_open_arg) as czidoc:

                    # get the pixel types for all channels
                    self.pixeltypes = czidoc.pixel_types
                    self.isRGB, self.consistent_pixeltypes = pixels.check_if_rgb(self.pixeltypes)

            except AttributeError:
                channels = None
        elif not czi_box.has_channels:
            logger.warning("Channel(s) information not found. Using Default Channel Names.")
            self.names.append("CH1")

        if czi_box.has_disp:
            try:
                # extract the relevant dimension metadata_tools
                disp = czi_box.ImageDocument.Metadata.DisplaySetting.Channels.Channel
                if isinstance(disp, Box):
                    self._get_channel_info(disp)
                elif isinstance(disp, BoxList):
                    for ch in range(len(disp)):
                        self._get_channel_info(disp[ch])
            except AttributeError:
                disp = None

            # calculate the ChannelDisplaySetting
            self.czi_disp_settings = self._calculate_display_settings()

        elif not czi_box.has_disp:
            if self.verbose:
                logger.info("DisplaySetting(s) not inside CZI metadata.")

    def _get_channel_info(self, display: Box):
        """Extract channel display info from a display `Box` and append to lists.

        Args:
            display: A `Box` representing a single channel's DisplaySetting
                     metadata (may be None).
        """

        if display is None:
            # Append safe defaults when no display metadata is present.
            self.dyes.append("Dye-CH1")
            self.colors.append("#80808000")
            self.clims.append([0.0, 0.5])
            self.gamma.append(0.85)
            return

        # Name fields: fall back to sensible defaults when missing
        self.dyes.append("Dye-CH1" if display.Name is None else display.Name)
        self.dyes_short.append("Dye-CH1" if display.ShortName is None else display.ShortName)
        (
            self.channel_descriptions.append("")
            if display.Description is None
            else self.channel_descriptions.append(display.Description)
        )

        # Color: keep CZI-provided hex string or fallback to a neutral gray
        self.colors.append("#80808000" if display.Color is None else display.Color)

        # Display limits: low/high with safe defaults
        low = 0.0 if display.Low is None else float(display.Low)
        high = 0.5 if display.High is None else float(display.High)
        self.clims.append([low, high])

        # Gamma: fallback to 0.85 if not provided
        self.gamma.append(0.85 if display.Gamma is None else float(display.Gamma))

    def _calculate_display_settings(self) -> Dict:
        """Construct pylibCZIrw channel display settings for each channel.

        The function maps per-channel metadata (color, display limits, and
        whether the channel is stored as RGB) to a
        `pylibCZIrw.czi.ChannelDisplaySettingsDataClass` instance. The
        returned dictionary uses the channel index as key.

        Behavior summary:
        - Colors in the CZI DisplaySetting are stored as hex strings in the
        form `#AARRGGBB`. We slice off the leading alpha bytes and convert
        the `RRGGBB` hex to integer RGB triplet via `hex_to_rgb`.
        - If the channel is flagged as an RGB channel (pixel type: RGB), we
        choose `TintingMode.none` and fixed black/white points so the
        reader displays raw RGB values. For grayscale channels we use
        `TintingMode.Color` and apply the provided `clims` (low/high).
        - If no display settings are present, sensible defaults are used.

        Returns:
            Dict[int, pyczi.ChannelDisplaySettingsDataClass]: Mapping from
            channel index to the pylibCZIrw display settings dataclass.
        """

        # number of channels known from metadata
        num_channels = len(self.names)

        # initialize the display settings mapping
        display_settings_dict: Dict[int, pyczi.ChannelDisplaySettingsDataClass] = {}

        for channel_index in range(num_channels):

            # Colors in CZI are often stored as #AARRGGBB (alpha + RGB). The
            # display metadata in `self.colors` contains this value; we strip
            # the alpha bytes (first two hex chars) and convert the remaining
            # RRGGBB hex string to integer RGB values.
            r, g, b = hex_to_rgb(self.colors[channel_index][3:])

            # If there is no channel-specific RGB information available,
            # ensure `self.isRGB` contains a boolean entry for this channel.
            if self.isRGB == {}:
                self.isRGB[channel_index] = False

            # Choose tinting mode and display limits depending on whether the
            # channel is RGB or an intensity channel.
            if self.isRGB[channel_index]:
                # For true RGB channels we don't apply color tinting and use
                # a full-range black/white point so RGB values are shown
                # directly.
                tinting_mode = pyczi.TintingMode.none
                black_point = 0.0
                white_point = 1.0
            else:
                # For intensity (grayscale) channels we use the configured
                # color tinting and the low/high values (clims) from the
                # metadata as black/white points.
                tinting_mode = pyczi.TintingMode.Color
                black_point = self.clims[channel_index][0]
                white_point = self.clims[channel_index][1]

            # Build the pylibCZIrw ChannelDisplaySettingsDataClass instance.
            # Note: pylibCZIrw expects 8-bit RGB values for the tinting color
            # (hence the np.uint8 casts).
            display_settings_dict[channel_index] = pyczi.ChannelDisplaySettingsDataClass(
                is_enabled=True,
                tinting_mode=tinting_mode,
                tinting_color=pyczi.Rgb8Color(np.uint8(r), np.uint8(g), np.uint8(b)),
                black_point=black_point,  # minimum value for histogram display
                white_point=white_point,  # maximum value for histogram display
            )

        return display_settings_dict


def hex_to_rgb(hex_string: str) -> tuple[int, int, int]:
    """
    Convert a hexadecimal color string to an RGB tuple.
    Args:
        hex_string (str): A string representing a color in hexadecimal format (e.g., '#RRGGBB').
    Returns:
        tuple: A tuple containing the RGB values (r, g, b) as integers.
    """

    # Remove the '#' characters
    hex_string = hex_string.replace("#", "")

    # check the length of the string
    if len(hex_string) != 6:
        # remove alpha values
        hex_string = hex_string[2:]

    try:
        # Convert hex string to integer values
        r = int(hex_string[0:2], 16)
        g = int(hex_string[2:4], 16)
        b = int(hex_string[4:6], 16)

    except ValueError:

        # Set RGB values to 128 if conversion fails
        r = 128
        g = 128
        b = 128

        logger.error(
            f"Invalid RGB values detected. Conversion of hex string {hex_string} to RGB failed. Setting RGB values to 128."
        )

    return r, g, b
