import warnings

import numpy as np
from typing import Literal

from spikeinterface.core.core_tools import define_function_handling_dict_from_class
from .filter import highpass_filter
from spikeinterface.core import get_random_data_chunks, order_channels_by_depth, BaseRecording
from spikeinterface.core.channelslice import ChannelSliceRecording

from inspect import signature

_bad_channel_detection_kwargs_doc = """Different methods are implemented:

* std : threhshold on channel standard deviations
    If the standard deviation of a channel is greater than `std_mad_threshold` times the median of all
    channels standard deviations, the channel is flagged as noisy
* mad : same as std, but using median absolute deviations instead
* coeherence+psd : method developed by the International Brain Laboratory that detects bad channels of three types:
    * Dead channels are those with low similarity to the surrounding channels (n=`n_neighbors` median)
    * Noise channels are those with power at >80% Nyquist above the psd_hf_threshold (default 0.02 uV^2 / Hz)
        and a high coherence with "far away" channels"
    * Out of brain channels are contigious regions of channels dissimilar to the median of all channels
        at the top end of the probe (i.e. large channel number)
* neighborhood_r2
    A method tuned for LFP use-cases, where channels should be highly correlated with their spatial
    neighbors. This method estimates the correlation of each channel with the median of its spatial
    neighbors, and considers channels bad when this correlation is too small.

Parameters
----------
recording : BaseRecording
    The recording for which bad channels are detected
method : "coeherence+psd" | "std" | "mad" | "neighborhood_r2", default: "coeherence+psd"
        The method to be used for bad channel detection
std_mad_threshold : float, default: 5
    The standard deviation/mad multiplier threshold
psd_hf_threshold : float, default: 0.02
    For coherence+psd - an absolute threshold (uV^2/Hz) used as a cutoff for noise channels.
    Channels with average power at >80% Nyquist larger than this threshold will be labeled as noise.
    IBL suggests 0.02 for AP data and 1.4 for LFP data.
dead_channel_threshold : float, default: -0.5
    For coherence+psd - threshold for channel coherence below which channels are labeled as dead
noisy_channel_threshold : float, default: 1
    Threshold for channel coherence above which channels are labeled as noisy (together with psd condition)
outside_channel_threshold : float, default: -0.75
    For coherence+psd - threshold for channel coherence above which channels at the edge of the recording are marked as outside
    of the brain
outside_channels_location : "top" | "bottom" | "both", default: "top"
    For coherence+psd - location of the outside channels. If "top", only the channels at the top of the probe can be
    marked as outside channels. If "bottom", only the channels at the bottom of the probe can be
    marked as outside channels. If "both", both the channels at the top and bottom of the probe can be
    marked as outside channels
n_neighbors : int, default: 11
    For coeherence+psd - number of channel neighbors to compute median filter (needs to be odd)
nyquist_threshold : float, default: 0.8
    For coherence+psd - frequency with respect to Nyquist (Fn=1) above which the mean of the PSD is calculated and compared
    with psd_hf_threshold
direction : "x" | "y" | "z", default: "y"
    For coherence+psd - the depth dimension
highpass_filter_cutoff : float, default: 300
    If the recording is not filtered, the cutoff frequency of the highpass filter
chunk_duration_s : float, default: 0.5
    Duration of each chunk
num_random_chunks : int, default: 100
    Number of random chunks
    Having many chunks is important for reproducibility.
welch_window_ms : float, default: 10
    Window size for the scipy.signal.welch that will be converted to nperseg
neighborhood_r2_threshold : float, default: 0.9
    R^2 threshold for the neighborhood_r2 method.
neighborhood_r2_radius_um : float, default: 30
    Spatial radius below which two channels are considered neighbors in the neighborhood_r2 method.
seed : int | None, default: None
    The random seed to extract chunks
channel_filters : set | None, default: None
    For coherence+psd - only return `bad_channel_ids` whose labels are in the set `channel_filter`.
"""


class DetectAndRemoveBadChannelsRecording(ChannelSliceRecording):
    """
    Detects and removes bad channels. If `bad_channel_ids` are given,
    the detection is skipped and uses these instead.

    {}
    bad_channel_ids : np.ndarray | list | None, default: None
        If given, these are used rather than being detected.
    channel_labels : np.ndarray | list | None, default: None
        If given, these are labels given to the channels by the
        detection process. Only intended for use when loading.

    Returns
    -------
    removed_bad_channels_recording : DetectAndRemoveBadChannelsRecording
        The recording with bad channels removed
    """

    _precomputable_kwarg_names = ["bad_channel_ids", "channel_labels"]

    def __init__(
        self,
        parent_recording: BaseRecording,
        bad_channel_ids=None,
        channel_labels=None,
        **detect_bad_channels_kwargs,
    ):

        if bad_channel_ids is None:
            bad_channel_ids, channel_labels = detect_bad_channels(
                recording=parent_recording, **detect_bad_channels_kwargs
            )
        else:
            channel_labels = None

        self._main_ids = parent_recording.get_channel_ids()
        new_channel_ids = self.channel_ids[~np.isin(self.channel_ids, bad_channel_ids)]

        ChannelSliceRecording.__init__(
            self,
            parent_recording=parent_recording,
            channel_ids=new_channel_ids,
        )

        # Do not want these, since they are not _kwargs of `DetectAndRemoveBadChannelsRecording`
        self._kwargs.pop("channel_ids")
        self._kwargs.pop("renamed_channel_ids")

        self._kwargs.update({"bad_channel_ids": bad_channel_ids})
        if channel_labels is not None:
            self._kwargs.update({"channel_labels": channel_labels})

        all_bad_channels_kwargs = _get_all_detect_bad_channel_kwargs(detect_bad_channels_kwargs)
        self._kwargs.update(all_bad_channels_kwargs)


DetectAndRemoveBadChannelsRecording.__doc__ = DetectAndRemoveBadChannelsRecording.__doc__.format(
    _bad_channel_detection_kwargs_doc
)
detect_and_remove_bad_channels = define_function_handling_dict_from_class(
    source_class=DetectAndRemoveBadChannelsRecording, name="detect_and_remove_bad_channels"
)


def _get_all_detect_bad_channel_kwargs(detect_bad_channels_kwargs):
    """Get the default parameters from `detect_bad_channels`, and update with any user-specified parameters."""

    sig = signature(detect_bad_channels)
    all_detect_bad_channels_kwargs = {
        k: v.default for k, v in sig.parameters.items() if k not in ["recording", "parent_recording"]
    }
    all_detect_bad_channels_kwargs.update(detect_bad_channels_kwargs)
    return all_detect_bad_channels_kwargs


def detect_bad_channels(
    recording: BaseRecording,
    method: str = "coherence+psd",
    std_mad_threshold: float = 5,
    psd_hf_threshold: float = 0.02,
    dead_channel_threshold: float = -0.5,
    noisy_channel_threshold: float = 1.0,
    outside_channel_threshold: float = -0.75,
    outside_channels_location: Literal["top", "bottom", "both"] = "top",
    n_neighbors: int = 11,
    nyquist_threshold: float = 0.8,
    direction: Literal["x", "y", "z"] = "y",
    chunk_duration_s: float = 0.3,
    num_random_chunks: int = 100,
    welch_window_ms: float = 10.0,
    highpass_filter_cutoff: float = 300,
    neighborhood_r2_threshold: float = 0.9,
    neighborhood_r2_radius_um: float = 30.0,
    seed: int | None = None,
    channel_filters: set | None = None,
):
    """
    Perform bad channel detection.
    The recording is assumed to be filtered. If not, a highpass filter is applied on the fly.

    {}

    Returns
    -------
    bad_channel_ids : np.array
        The identified bad channel ids
    channel_labels : np.array of str
        Channels labels depending on the method:
          * (coeherence+psd) good/dead/noise/out
          * (std, mad) good/noise

    Examples
    --------

    >>> import spikeinterface.preprocessing as spre
    >>> bad_channel_ids, channel_labels = spre.detect_bad_channels(recording, method="coherence+psd")
    >>> # remove bad channels
    >>> recording_clean = recording.remove_channels(bad_channel_ids)

    Notes
    -----
    For details refer to:
    International Brain Laboratory et al. (2022). Spike sorting pipeline for the International Brain Laboratory.
    https://www.internationalbrainlab.com/repro-ephys
    """
    import scipy.stats

    method_list = ("std", "mad", "coherence+psd", "neighborhood_r2")
    assert method in method_list, f"{method} is not a valid method. Available methods are {method_list}"

    # Get random subset of data to estimate from
    random_chunk_kwargs = dict(
        num_chunks_per_segment=num_random_chunks,
        chunk_size=int(chunk_duration_s * recording.sampling_frequency),
        seed=seed,
    )

    # If recording is not filtered, apply a highpass filter
    if not recording.is_filtered():
        recording_hp = highpass_filter(recording, freq_min=highpass_filter_cutoff)
    else:
        recording_hp = recording

    # Adjust random chunk kwargs based on method
    if method in ("std", "mad"):
        random_chunk_kwargs["return_in_uV"] = False
        random_chunk_kwargs["concatenated"] = True
    elif method == "coherence+psd":
        random_chunk_kwargs["return_in_uV"] = True
        random_chunk_kwargs["concatenated"] = False
    elif method == "neighborhood_r2":
        random_chunk_kwargs["return_in_uV"] = False
        random_chunk_kwargs["concatenated"] = False

    random_data = get_random_data_chunks(recording_hp, **random_chunk_kwargs)

    channel_labels = np.zeros(recording.get_num_channels(), dtype="U5")
    channel_labels[:] = "good"

    if method in ("std", "mad"):
        if method == "std":
            deviations = np.std(random_data, axis=0)
        else:
            deviations = scipy.stats.median_abs_deviation(random_data, axis=0)
        thresh = std_mad_threshold * np.median(deviations)
        mask = deviations > thresh
        bad_channel_ids = recording.channel_ids[mask]
        channel_labels[mask] = "noise"

    elif method == "coherence+psd":
        # some checks
        assert recording.has_scaleable_traces(), (
            "The 'coherence+psd' method uses thresholds assuming the traces are in uV, "
            "but the recording does not have scaled traces. If the recording is already scaled, "
            "you need to set gains and offsets: "
            ">>> recording.set_channel_gains(1); recording.set_channel_offsets(0)"
        )
        assert 0 < nyquist_threshold < 1, "nyquist_threshold must be between 0 and 1"

        # If location are not sorted, estimate forward and reverse sorting
        channel_locations = recording.get_channel_locations()
        dim = ["x", "y", "z"].index(direction)
        assert dim < channel_locations.shape[1], f"Direction {direction} is wrong"
        order_f, order_r = order_channels_by_depth(recording=recording, dimensions=("x", "y"))
        if np.all(np.diff(order_f) == 1):
            # already ordered
            order_f = None
            order_r = None

        # Create empty channel labels and fill with bad-channel detection estimate for each chunk
        chunk_channel_labels = np.zeros((recording.get_num_channels(), len(random_data)), dtype=np.int8)

        for i, random_chunk in enumerate(random_data):
            random_chunk_sorted = random_chunk[:, order_f] if order_f is not None else random_chunk
            chunk_labels = detect_bad_channels_ibl(
                raw=random_chunk_sorted,
                fs=recording.sampling_frequency,
                psd_hf_threshold=psd_hf_threshold,
                dead_channel_thr=dead_channel_threshold,
                noisy_channel_thr=noisy_channel_threshold,
                outside_channel_thr=outside_channel_threshold,
                n_neighbors=n_neighbors,
                nyquist_threshold=nyquist_threshold,
                welch_window_ms=welch_window_ms,
                outside_channels_location=outside_channels_location,
            )
            chunk_channel_labels[:, i] = chunk_labels[order_r] if order_r is not None else chunk_labels

        # Take the mode of the chunk estimates as final result. Convert to binary good / bad channel output.
        mode_channel_labels, _ = scipy.stats.mode(chunk_channel_labels, axis=1, keepdims=False)

        (bad_inds,) = np.where(mode_channel_labels != 0)
        bad_channel_ids = recording.channel_ids[bad_inds]

        channel_labels[mode_channel_labels == 1] = "dead"
        channel_labels[mode_channel_labels == 2] = "noise"
        channel_labels[mode_channel_labels == 3] = "out"

        if bad_channel_ids.size > recording.get_num_channels() / 3:
            warnings.warn(
                "Over 1/3 of channels are detected as bad. In the presence of a high"
                "number of dead / noisy channels, bad channel detection may fail "
                "(good channels may be erroneously labeled as dead)."
            )

        allowed_filters = {"dead", "noise", "out"}

        if channel_filters is None:
            channel_filters = allowed_filters

        if not isinstance(channel_filters, set):
            raise ValueError(f"channel_filters must be None or a set of the following values : {allowed_filters} ")

        if not channel_filters.issubset(allowed_filters):
            raise ValueError(
                f"{channel_filters.difference(allowed_filters)} is not a valid argument of channel_filters. Please use one of the following instead {allowed_filters}."
            )

        filtered_bad_channel_mask = np.isin(channel_labels, list(channel_filters))
        bad_channel_ids = recording.channel_ids[filtered_bad_channel_mask]

    elif method == "neighborhood_r2":
        # make neighboring channels structure. this should probably be a function in core.
        geom = recording.get_channel_locations()
        num_channels = recording.get_num_channels()
        chan_distances = np.linalg.norm(geom[:, None, :] - geom[None, :, :], axis=2)
        np.fill_diagonal(chan_distances, neighborhood_r2_radius_um + 1)
        neighbors_mask = chan_distances < neighborhood_r2_radius_um
        if neighbors_mask.sum(axis=1).min() < 1:
            warnings.warn(
                f"neighborhood_r2_radius_um={neighborhood_r2_radius_um} led "
                "to channels with no neighbors for this geometry, which has "
                f"minimal channel distance {chan_distances.min()}um. These "
                "channels will not be marked as bad, but you might want to "
                "check them."
            )
        max_neighbors = neighbors_mask.sum(axis=1).max()
        channel_index = np.full((num_channels, max_neighbors), num_channels)
        for c in range(num_channels):
            my_neighbors = np.flatnonzero(neighbors_mask[c])
            channel_index[c, : my_neighbors.size] = my_neighbors

        # get the correlation of each channel with its neighbors' median inside each chunk
        # note that we did not concatenate the chunks here
        correlations = []
        for chunk in random_data:
            chunk = chunk.astype(np.float32, copy=False)
            chunk = chunk - np.median(chunk, axis=0, keepdims=True)
            padded_chunk = np.pad(chunk, [(0, 0), (0, 1)], constant_values=np.nan)
            # channels with no neighbors will get a pure-nan median trace here
            neighbmeans = np.nanmedian(
                padded_chunk[:, channel_index],
                axis=2,
            )
            denom = np.sqrt(np.nanmean(np.square(chunk), axis=0) * np.nanmean(np.square(neighbmeans), axis=0))
            denom[denom == 0] = 1
            # channels with no neighbors will get a nan here
            chunk_correlations = np.nanmean(chunk * neighbmeans, axis=0) / denom
            correlations.append(chunk_correlations)

        # now take the median over chunks and threshold to finish
        median_correlations = np.nanmedian(correlations, 0)
        r2s = median_correlations**2
        # channels with no neighbors will have r2==nan, and nan<x==False always
        bad_channel_mask = r2s < neighborhood_r2_threshold
        bad_channel_ids = recording.channel_ids[bad_channel_mask]
        channel_labels[bad_channel_mask] = "noise"

    return bad_channel_ids, channel_labels


detect_bad_channels.__doc__ = detect_bad_channels.__doc__.format(_bad_channel_detection_kwargs_doc)


# ----------------------------------------------------------------------------------------------
# IBL Detect Bad Channels
# ----------------------------------------------------------------------------------------------


def detect_bad_channels_ibl(
    raw,
    fs,
    psd_hf_threshold,
    dead_channel_thr=-0.5,
    noisy_channel_thr=1.0,
    outside_channel_thr=-0.75,
    n_neighbors=11,
    nyquist_threshold=0.8,
    welch_window_ms=10.0,
    outside_channels_location="top",
):
    """
    Bad channels detection for Neuropixel probes developed by IBL.

    `xcorr` is the dot product of each channel with the reference (median of all channels) normalized
    by the energy of the reference, which is a "correlation-like" measure that captures similarity
    of each channel to the rest of the probe. Values near 1 indicate good channels.

    A `trend` is estimated by median filtering `xcorr`: this smoothed signal captures the difference
    in similarities across depths. `n_neighbors` is the size of this median filter (larger values
    capture broader trends, smaller values are more local but less robust to bad channels). This is
    also expected to be values near 1 for good (i.e., most) channels.

    Outside channels are defined as contiguous channels on the 'top', 'bottom' or either ('both')
    side of the probe where trend < (outside_channel_thr + 1). outside_channel_thr = -0.75 by
    default so this essentially flags channnels at the top or bottom where
    corr(channel, reference) < 0.25.

    The trend is subtracted from the xcorr to get `xcorr_neighbors`. Outliers on this zero-centered
    signal are labelled as dead or noisy channels:
        a) dead if xcorr_neighbors < dead_channel_thr (-0.5 by default, essentially corr(chanel, reference) < 0.5)
        b) noisy if xcorr_neighbors > noisy_channel_thr (1.0 by default)

    Spectral analysis is also used to label noisy channels. `psd` is computed using welch method:
    split the signal into overlapping windows of size `welch_window_ms`, compute the psd in each
    window, and average over windows. `psd_hf` is the mean power of frequencies above
    `nyquist_threshold` * Nyquist frequency. If `psd_hf` > `psd_hf_threshold`, the channel is
    labelled as noisy.

    When a channel is bad in more than one way, the following priority is applied to the labeling:
    outside > noisy > dead. This means that if a channel is both outside and noisy, it will be
    labeled as outside. If it is both noisy and dead, it will be labeled as noisy.

    Parameters
    ----------
    raw : traces
        (num_samples, n_channels) raw traces
    fs : float
        sampling frequency
    psd_hf_threshold : float
        Threshold for high frequency PSD. If mean PSD above `nyquist_threshold` * fn is greater than this
        value, channels are flagged as noisy (together with channel coherence condition).
    dead_channel_thr : float, default: -0.5
        Threshold for channel coherence below which channels are labeled as dead
    noisy_channel_thr : float, default: 1
        Threshold for channel coherence above which channels are labeled as noisy (together with psd condition)
    outside_channel_thr : float, default: -0.75
        Threshold for channel coherence above which channels
    n_neighbors : int, default: 11
        Number of neighbors to compute median filter
    nyquist_threshold : float, default: 0.8
        Threshold on Nyquist frequency to calculate HF noise band
    welch_window_ms : float, default: 0.3
        Window size for the scipy.signal.welch that will be converted to nperseg
    outside_channels_location : "top" | "bottom" | "both", default: "top"
        Location of the outside channels. If "top", only the channels at the top of the probe can be
        marked as outside channels. If "bottom", only the channels at the bottom of the probe can be
        marked as outside channels. If "both", both the channels at the top and bottom of the probe can be
        marked as outside channels

    Returns
    -------
    1d array
        Channels labels: 0: good,  1: dead low coherence / amplitude, 2: noisy, 3: outside of the brain
    """
    import scipy

    # Compute PSD
    raw = raw - np.mean(raw, axis=0, keepdims=True)
    nperseg = int(welch_window_ms * fs / 1000)
    fscale, psd = scipy.signal.welch(raw, fs=fs, axis=0, window="hann", nperseg=nperseg)
    psd_hf = np.mean(psd[fscale > (fs / 2 * nyquist_threshold)], axis=0)

    # Compute similarities
    ref = np.median(raw, axis=1)
    ref = ref - np.mean(ref)
    xcorr = raw.T @ ref / np.sum(ref**2)

    # Compute coherence
    trend = shrinking_median_filter(xcorr, n_neighbors)
    xcorr_neighbors = xcorr - trend

    # Find dead, noisy and outside channels
    num_channels = raw.shape[1]
    ichannels = np.zeros(num_channels, dtype=int)

    idead = xcorr_neighbors < dead_channel_thr
    ichannels[idead] = 1

    inoisy = np.logical_or(psd_hf > psd_hf_threshold, xcorr_neighbors > noisy_channel_thr)
    ichannels[inoisy] = 2

    # Channels outside the brain are contiguous channels at the extreme of the probe below the
    # threshold on the trend coherency
    below_threshold = trend < (outside_channel_thr + 1)
    if np.any(below_threshold):
        # Find contiguous blocks of dead channels
        (ibelow,) = np.where(below_threshold)
        breaks = np.where(np.diff(ibelow) > 1)[0] + 1
        contiguous_blocks = np.split(ibelow, breaks)

        # Mark blocks at the edges of the probe
        if outside_channels_location in ("top", "both"):
            # channels are sorted bottom to top, so the last channel needs to be (num_channels - 1)
            top_block = contiguous_blocks[-1]
            if top_block[-1] == num_channels - 1:
                ichannels[top_block] = 3
        if outside_channels_location in ("bottom", "both"):
            # outside channels are at the bottom of the probe, so the first channel needs to be 0
            bottom_block = contiguous_blocks[0]
            if bottom_block[0] == 0:
                ichannels[bottom_block] = 3

    return ichannels


def shrinking_median_filter(s, size=11):
    """Compute median filter but reducing the filter size near edges to avoid padding.

    Parameters
    ----------
    s : 1d array
        The signal to be filtered.
    size : int, default: 11
            The size of the median filter.
    """
    half = size // 2

    filtered = np.empty_like(s)
    for i in range(len(s)):
        lo = max(0, i - half)
        hi = i + half + 1  # upper bound > len(s) is auto-clipped by numpy
        filtered[i] = np.median(s[lo:hi])

    return filtered
