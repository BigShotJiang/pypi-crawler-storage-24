#
# Copyright (c) 2025 TUM Department of Electrical and Computer Engineering.
#
# This file is part of ISAAC Toolkit.
# See https://github.com/tum-ei-eda/isaac-toolkit.git for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
riscv_branch_instrs = [
    "j",  # pseudo
    "jr",  # pseudo
    "call",  # pseudo
    "tail",  # pseudo
    "jal",
    "beq",
    "beqz",  # pseudo
    "bne",
    "blt",
    "bltz",  # pseudo
    "bgt",  # pseudo
    "bgtz",  # pseudo
    "bge",  # pseudo
    "bgez",  # pseudo
    "ble",
    "blez",  # new?
    "bltu",
    "bgtu",  # pseudo
    "bgtu",  # pseudo
    "bgeu",  # pseudo
    "bleu",
    "ecall",
    "bnez",  # bseudo
    "cbnez",
    "c.bnez",
    "cj",  # pseudo
    "cbeqz",
    "cjal",
    "c.j",
    "c.j",
    "c.beqz",
    "c.jal",
    # "ret",  # pseudo
    # "mret",  # pseudo
    # "sret",  # pseudo
    # "uret",  # pseudo
    # "jalr"  # return if rd=x0, rs1=x1
    # "c.jr",  # return if rs1=x1
    # "c.jalr",  # return if  rs1=x1
]
riscv_return_instrs = ["jalr", "cjalr", "cjr", "c.jr", "c.jalr", "ret", "mret", "sret", "uret"]  # TODO
