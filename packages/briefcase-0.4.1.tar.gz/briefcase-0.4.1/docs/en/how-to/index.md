# How-to guides  { #how-to }

How-to guides are recipes that take the user through steps in key subjects. They are more advanced than tutorials and assume a lot more about what the user already knows than tutorials do, and unlike documents in the tutorial they can stand alone.

## Obtaining a Code Signing identity { #obtain-code-signing-identity }

* [Android](code-signing/android.md) - One way to sign your app where the Google Play Store maintains the authoritative key for your app.
* [macOS](code-signing/macOS.md) - How to generate a macOS code signing identity, which is required to distribute your application.
* [Windows](code-signing/windows.md) - Obtaining a codes signing certificate from a Certificate Authority and installing it in a Windows certificate store.

## Building different types of apps

* [Building your app in CI with GitHub Action](building/ci.md) - This GitHub Actions workflow provides the basic framework necessary to test, build, and package a Briefcase project in CI for Windows, Linux, macOS, iOS, and Android.
* [Building your Console app with Briefcase](building/cli-apps.md) - The key differences when creating a console application using Briefcase, as opposed to a GUI-based app.
* [Packaging external apps](building/external-apps.md) - Learn how Briefcase can be used to package an application that has been constructed using another tool.

## Debugging apps

* [Debugging apps with PDB](debugging/pdb.md) - How to debug an app using Python's built-in `pdb` debugger.
* [Debugging apps with Visual Studio Code](debugging/vscode.md) - How to debug an app using the debugger built into Visual Studio Code.

## Testing apps

* [Testing Linux Apps with Docker](testing/x11passthrough.md) - Configure your system to use Docker to build apps for Linux distributions other than the distribution you're currently using.

## Publishing your app

* [Android](publishing/android.md) - Distribute a BeeWare app on the Google Play Store.
* [iOS](publishing/iOS.md) - Publish an iOS app to the Apple App Store.
* [macOS](publishing/macOS.md) - Publish a macOS app to the Apple App Store.

## [Contributing to Briefcase](contribute/index.md)

* [Contributing to Briefcase](contribute/index.md) - The many ways you can contribute to Briefcase, including what you can do and how to do it.

## Internal How-to guides

* [How to cut a Briefcase release](internal/release.md) - The procedure for cutting a new release of Briefcase.

## Upgrading from previous versions

* [Upgrading from Briefcase v0.2](upgrading/upgrade-from-v0.2.md) - The changes to configuration and processes needed to upgrade from v0.2 to v0.3.
