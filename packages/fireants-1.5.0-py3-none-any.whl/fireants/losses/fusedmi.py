# Copyright (c) 2026 Rohit Jena. All rights reserved.
#
# This file is part of FireANTs, distributed under the terms of
# the FireANTs License version 1.0. A copy of the license can be found
# in the LICENSE file at the root of this repository.
#
# IMPORTANT: This code is part of FireANTs and its use, reproduction, or
# distribution must comply with the full license terms, including:
# - Maintaining all copyright notices and bibliography references
# - Using only approved (re)-distribution channels
# - Proper attribution in derivative works
#
# For full license details, see: https://github.com/rohitrango/FireANTs/blob/main/LICENSE


from __future__ import annotations

from time import time, sleep
import torch
import torch.nn as nn
from torch.nn import functional as F
from typing import Optional
import os
import fireants_fused_ops as ffo
from fireants.losses.mi import allgather_mi
import logging
logger = logging.getLogger(__name__)
from fireants.registration.distributed import parallel_state
from fireants.losses.cc import separable_filtering, gaussian_1d
from fireants.losses.maskedutils import POSSIBLE_MASKED_MODES, DEFAULT_MASK_MODE, get_tensors_and_mask, mask_loss_function

kernel_type_dict = {
    "gaussian": ffo.KernelType.GAUSSIAN,
    "b-spline": ffo.KernelType.BSPLINE,
    "b_spline": ffo.KernelType.BSPLINE,
    "delta": ffo.KernelType.DELTA,
}

def smooth_kernel(pab: torch.Tensor, pa: torch.Tensor, pb: torch.Tensor, gaussian: torch.Tensor) -> torch.Tensor:
    '''
    helper function to smooth kernel
    '''
    pab = separable_filtering(pab, gaussian)
    pab /= pab.sum(dim=(-1, -2), keepdim=True)
    pa = separable_filtering(pa, gaussian)
    pa /= pa.sum(dim=(-1), keepdim=True)
    pb = separable_filtering(pb, gaussian)
    pb /= pb.sum(dim=(-1), keepdim=True)
    return pab, pa, pb

smooth_kernel_compile = torch.compile(smooth_kernel)

class MI_histogram_kernel(torch.autograd.Function):
    ''' custom op to compute kernel without creating parzen window table '''
    @staticmethod
    def forward(ctx, input_img, target_img, num_bins, kernel_type, minval, maxval, sigma_ratio, approximate_reduction, torch_compile):
        # compute histograms
        pab, pa, pb = ffo.mutual_information_histogram_fwd(input_img, target_img, num_bins, kernel_type, minval, maxval, sigma_ratio, approximate_reduction)
        # smooth kernel
        if approximate_reduction:
            sigma_ratio_tensor = torch.tensor(sigma_ratio/2.0, device=input_img.device, dtype=input_img.dtype)
            gaussian = gaussian_1d(sigma_ratio_tensor)
            pab, pa, pb = smooth_kernel_compile(pab, pa, pb, gaussian) if torch_compile else smooth_kernel(pab, pa, pb, gaussian)
            # pab = separable_filtering(pab, gaussian_1d(sigma_ratio_tensor))
            # pab /= pab.sum(dim=(-1, -2), keepdim=True)
            # pa = separable_filtering(pa, gaussian_1d(sigma_ratio_tensor))
            # pa /= pa.sum(dim=(-1, -2), keepdim=True)
            # pb = separable_filtering(pb, gaussian_1d(sigma_ratio_tensor))
            # pb /= pb.sum(dim=(-1, -2), keepdim=True)

        ctx.num_bins = num_bins
        ctx.kernel_type = kernel_type
        # save
        ctx.save_for_backward(input_img, target_img)
        ctx.minval = minval
        ctx.maxval = maxval
        ctx.sigma_ratio = sigma_ratio
        return pab, pa, pb

    @staticmethod
    def backward(ctx, grad_pab, grad_pa, grad_pb):
        input_img, target_img = ctx.saved_tensors  #
        num_bins = ctx.num_bins
        kernel_type = ctx.kernel_type
        grad_input = None
        grad_target = None
        minval = ctx.minval
        maxval = ctx.maxval
        sigma_ratio = ctx.sigma_ratio

        if input_img.requires_grad:
            grad_input = torch.zeros_like(input_img)
        if target_img.requires_grad:
            grad_target = torch.zeros_like(target_img)
        ffo.mutual_information_histogram_bwd(input_img, target_img, grad_pab, grad_pa, grad_pb, num_bins, grad_input, grad_target, kernel_type, minval, maxval, sigma_ratio)
        # sample_size = input_img.flatten(2).shape[2]
        # if grad_input is not None:
        #     grad_input.mul_(sample_size)
        # if grad_target is not None:
        #     grad_target.mul_(sample_size)
        return grad_input, grad_target, None, None, None, None, None, None, None


class FusedGlobalMutualInformationLoss(nn.Module):
    """
    Differentiable global mutual information loss via Parzen windowing method.
    Reference:
        https://dspace.mit.edu/handle/1721.1/123142, Section 3.1, equation 3.1-3.5, Algorithm 1
    """
    def __init__(
        self,
        kernel_type: str = "gaussian",
        num_bins: int = 32,
        reduction: str = "mean",
        normalize_image_if_required: bool = True,
        smooth_nr: float = 1e-5,
        smooth_dr: float = 1e-5,
        sigma_ratio: float = 1.0,
        approximate_reduction: bool = True,
        torch_compile: bool = False,
        # mask parameters
        masked: bool = False,
        mask_mode: str = DEFAULT_MASK_MODE,
        suppress_logging: bool = False,
    ) -> None:
        """
        Args:
            kernel_type: {``"gaussian"``, ``"b-spline"``, ``"delta"``}
                - custom implementation
            num_bins: number of bins for intensity
            sigma_ratio: a hyper param for gaussian function
            reduction: {``"none"``, ``"mean"``, ``"sum"``}
                Specifies the reduction to apply to the output. Defaults to ``"mean"``.
                - ``"none"``: no reduction will be applied.
                - ``"mean"``: the sum of the output will be divided by the number of elements in the output.
                - ``"sum"``: the output will be summed.
            smooth_nr: a small constant added to the numerator to avoid nan.
            smooth_dr: a small constant added to the denominator to avoid nan.
        """
        super().__init__()
        self.suppress_logging = suppress_logging
        if not suppress_logging:
            logger.info(f"Initializing FusedGlobalMutualInformationLoss with kernel_type={kernel_type}, num_bins={num_bins}, reduction={reduction}, normalize_image_if_required={normalize_image_if_required}, smooth_nr={smooth_nr}, smooth_dr={smooth_dr}, sigma_ratio={sigma_ratio}, approximate_reduction={approximate_reduction}, torch_compile={torch_compile}")
        if num_bins <= 0:
            raise ValueError("num_bins must > 0, got {num_bins}")
        self.kernel_type = kernel_type_dict[kernel_type]
        self.num_bins = num_bins
        self.smooth_nr = float(smooth_nr)
        self.smooth_dr = float(smooth_dr)
        self.reduction = reduction
        self.normalize_image_if_required = normalize_image_if_required
        self.warned = False
        self.sigma_ratio = sigma_ratio
        self.approximate_reduction = approximate_reduction
        self.torch_compile = torch_compile
        if self.torch_compile:
            self.get_mi_from_dist = torch.compile(self.get_mi_from_dist)
        # masked
        self.masked = masked
        self.mask_mode = mask_mode
        self.masked_reduction = reduction
        assert mask_mode in POSSIBLE_MASKED_MODES

    def get_image_padding(self) -> int:
        return 0

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        wrapper around masked versions
        """
        if not self.masked:
            return self.forward_util(pred, target)
        # masked mode
        pred, target, mask = get_tensors_and_mask(pred, target, self.mask_mode)
        # since different batches can have different number of samples, we have to run this batchwise :(
        batch_size = pred.shape[0]
        mivals = []
        for i in range(batch_size):
            p = pred[i:i+1].flatten(2)  # (1, c, n)
            t = target[i:i+1].flatten(2) # (1, c, n)
            m = mask[i:i+1].reshape(-1)  # (n)
            coords = torch.nonzero(m >= 0.5, as_tuple=True)[0]
            if coords.nelement() <= 0:
                raise ValueError("encountered zero mask, cannot compute mutual information")
            # sample positive examples
            p = p[:, :, coords].contiguous()
            t = t[:, :, coords].contiguous()  # need contiguity for fused kernel
            mival = self.forward_util(p, t)
            mivals.append(mival)
        # each item is either (1, c, bin, bin) or (1)
        mivals = torch.stack(mivals, dim=0)
        if self.reduction == "mean":
            return torch.mean(mivals)
        if self.reduction == "sum":
            return torch.sum(mivals)
        return mivals

    def forward_util(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        Args:
            pred: the shape should be B[NDHW].
            target: the shape should be same as the pred shape.
        Raises:
            ValueError: When ``self.reduction`` is not one of ["mean", "sum", "none"].
        """
        minval = min(pred.min(), target.min()).detach().item()
        maxval = max(pred.max(), target.max()).detach().item()
        normalize = False
        if maxval > 1:
            if not self.warned and not self.suppress_logging:
                logger.warning("Image values are expected to be in the range [0, 1] - normalizing the images")
                self.warned = True
            normalize = True
        if minval < 0:
            if not self.warned and not self.suppress_logging:
                logger.warning("Image values are expected to be in the range [0, 1] - normalizing the images")
                self.warned = True
            normalize = True
        # check if we should normalize
        if normalize:
            if self.normalize_image_if_required:
                # pred = (pred - minval) / (maxval - minval)
                # target = (target - minval) / (maxval - minval)
                pass  # we will pass these values in the kernel
            else:
                raise ValueError("Image values are expected to be in the range [0, 1] - please set normalize_image_if_required to True or scale the images to [0, 1] before feeding them to the loss")
        else:
            minval, maxval = 0.0, 1.0 # no need to normalize

        # check if shapes are same
        if target.shape != pred.shape:
            raise ValueError(f"ground truth has differing shape ({target.shape}) from pred ({pred.shape})")

        # flip order
        if not pred.requires_grad and target.requires_grad:
            pred, target = target, pred

        num_samples = pred.flatten(2).shape[2]
        # get histograms
        pab, pa, pb = MI_histogram_kernel.apply(pred, target, self.num_bins, self.kernel_type, minval, maxval, self.sigma_ratio, self.approximate_reduction, self.torch_compile)
        return self.get_mi_from_dist(pab, pa, pb, num_samples)

    def get_mi_from_dist(self, pab: torch.Tensor, pa: torch.Tensor, pb: torch.Tensor, num_samples: int) -> torch.Tensor:
        '''
        helper function to get mi from distributed histograms (this is the op we want to compile)
        '''
        if parallel_state.is_initialized() and parallel_state.get_grid_parallel_size() > 1:
            pab, pa, pb = allgather_mi.apply(pab, pa, pb, num_samples)
            #papb = torch.bmm(pa.permute(0, 2, 1), pb.to(pa))
            #papb = torch.bmm(pa[..., None].permute(0, 1, 3, 2), pb[..., None])  # (b, c, n, n)
        else:
            pass
        papb = torch.matmul(pa[..., None], pb[..., None].permute(0, 1, 3, 2).to(pa))  # (b, c, n, n)
        assert pab.shape == papb.shape

        mi = torch.sum(
            pab * torch.log((pab + self.smooth_nr) / (papb + self.smooth_dr) + self.smooth_dr), dim=(-1, -2)
        )  # (batch, channel)

        if self.reduction == 'sum':
            return torch.sum(mi).neg()  # sum over the batch and channel ndims
        if self.reduction == 'none':
            return mi.neg()
        if self.reduction == 'mean':
            return torch.mean(mi).neg()  # average over the batch and channel ndims

        raise ValueError(f'Unsupported reduction: {self.reduction}, available options are ["mean", "sum", "none"].')


if __name__ == '__main__':
    N = 256
    img1 = torch.rand(1, 3, N, N, N).cuda()
    img2 = torch.rand(1, 3, N, N, N).cuda()
    #loss = FusedGlobalMutualInformationLoss('b-spline').cuda()
    loss = FusedGlobalMutualInformationLoss('gaussian', sigma_ratio=2.0).cuda()
    total = 0
    a = time()
    for i in range(10):
        out = loss(img1, img2)
        total += out.item()
    print(time() - a)
