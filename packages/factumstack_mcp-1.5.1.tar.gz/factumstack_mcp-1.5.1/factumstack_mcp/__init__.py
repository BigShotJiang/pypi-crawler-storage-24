# factumstack_mcp/__init__.py
# Empty file to make this directory a valid Python package
