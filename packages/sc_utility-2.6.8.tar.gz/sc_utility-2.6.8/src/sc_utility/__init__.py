"""
sc_utility package.

This package provides utility functions and classes for the SC project.
"""
from importlib import import_module
from typing import TYPE_CHECKING

from .sc_common import SCCommon
from .sc_config_mgr import SCConfigManager
from .sc_csv_reader import CSVReader
from .sc_date_helper import DateHelper
from .sc_excel_reader import ExcelReader
from .sc_json_encoder import JSONEncoder
from .sc_logging import SCLogger
from .sc_shelly_control import ShellyControl
from .validation_schema import yaml_config_validation
from .webhook_server import _ShellyWebhookHandler

if TYPE_CHECKING:
    from weather_client import WeatherClient

__all__ = ["CSVReader", "DateHelper", "ExcelReader", "JSONEncoder", "SCCommon", "SCConfigManager", "SCLogger", "ShellyControl", "WeatherClient", "_ShellyWebhookHandler", "yaml_config_validation"]


def __getattr__(name: str):
    if name == "WeatherClient":
        return import_module("weather_client").WeatherClient

    error_msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(error_msg)
