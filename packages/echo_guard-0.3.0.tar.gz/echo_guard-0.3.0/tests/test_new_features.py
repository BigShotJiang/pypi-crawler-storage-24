"""Tests for scope-aware comparison, cross-language reuse, health score, and incremental indexing."""

import pytest
from echo_guard.languages import extract_functions_universal
from echo_guard.similarity import (
    SimilarityEngine,
    classify_reuse,
    get_reuse_guidance,
    scope_penalty,
)
from echo_guard.health import compute_health_score

# ── Visibility detection tests ────────────────────────────────────────────

def test_python_private_visibility():
    code = '''
def public_func():
    return 1

def _private_func():
    return 2

def __mangled_func():
    return 3

def __dunder__():
    return 4
'''
    funcs = extract_functions_universal("mod.py", code, "python")
    by_name = {f.name: f for f in funcs}
    assert by_name["public_func"].visibility == "public"
    assert by_name["_private_func"].visibility == "private"
    assert by_name["__mangled_func"].visibility == "private"
    assert by_name["__dunder__"].visibility == "public"  # Dunder = public

def test_go_exported_unexported():
    code = '''
package auth

func ExportedFunc() int {
    return 1
}

func unexportedFunc() int {
    return 2
}
'''
    funcs = extract_functions_universal("auth.go", code, "go")
    by_name = {f.name: f for f in funcs}
    assert by_name["ExportedFunc"].visibility == "public"
    assert by_name["unexportedFunc"].visibility == "internal"

def test_rust_pub_visibility():
    code = '''
pub fn public_func() -> i32 {
    1
}

fn private_func() -> i32 {
    2
}
'''
    funcs = extract_functions_universal("lib.rs", code, "rust")
    by_name = {f.name: f for f in funcs}
    assert by_name["public_func"].visibility == "public"
    assert by_name["private_func"].visibility == "private"

# ── Cross-language reuse classification tests ─────────────────────────────

def test_same_language_reuse():
    assert classify_reuse("python", "python") == "direct_import"
    assert classify_reuse("go", "go") == "direct_import"

def test_compatible_runtime_reuse():
    assert classify_reuse("javascript", "typescript") == "compatible_import"
    assert classify_reuse("typescript", "javascript") == "compatible_import"
    assert classify_reuse("c", "cpp") == "compatible_import"

def test_cross_language_reference_only():
    assert classify_reuse("python", "go") == "reference_only"
    assert classify_reuse("python", "javascript") == "reference_only"
    assert classify_reuse("go", "rust") == "reference_only"
    assert classify_reuse("java", "python") == "reference_only"

def test_reuse_guidance_contains_language_names():
    guidance = get_reuse_guidance("reference_only", "python", "go")
    assert "go" in guidance.lower()
    assert "python" in guidance.lower()
    assert "cannot" in guidance.lower()

# ── Scope penalty tests ──────────────────────────────────────────────────

def _make_func(name, filepath, lang="python", visibility="public"):
    from echo_guard.languages import ExtractedFunction
    return ExtractedFunction(
        name=name, filepath=filepath, language=lang,
        lineno=1, end_lineno=5, source=f"def {name}(): pass",
        visibility=visibility,
    )

def test_scope_penalty_public():
    src = _make_func("new_func", "a.py")
    existing = _make_func("old_func", "b.py", visibility="public")
    assert scope_penalty(src, existing) == 1.0

def test_scope_penalty_private():
    src = _make_func("new_func", "a.py")
    existing = _make_func("_old_func", "b.py", visibility="private")
    assert scope_penalty(src, existing) == 0.6

def test_scope_penalty_internal_same_package():
    src = _make_func("new_func", "pkg/a.py")
    existing = _make_func("old_func", "pkg/b.py", visibility="internal")
    assert scope_penalty(src, existing) == 0.9

def test_scope_penalty_internal_different_package():
    src = _make_func("new_func", "pkg_a/a.py")
    existing = _make_func("old_func", "pkg_b/b.py", visibility="internal")
    assert scope_penalty(src, existing) == 0.7

# ── Similarity engine with cross-language reuse ──────────────────────────

def test_similarity_match_includes_reuse_type():
    """Matches should include reuse classification (direct_import for same language)."""
    code_a = '''
def hash_password(password, salt=None):
    if salt is None:
        salt = generate_salt()
    return do_hash(password, salt), salt
'''
    code_b = '''
def create_password_hash(pwd, salt_val=None):
    if salt_val is None:
        salt_val = generate_salt()
    return do_hash(pwd, salt_val), salt_val
'''
    engine = SimilarityEngine(similarity_threshold=0.3)
    funcs_a = extract_functions_universal("auth.py", code_a, "python")
    funcs_b = extract_functions_universal("crypto.py", code_b, "python")

    for f in funcs_a + funcs_b:
        engine.add_function(f)

    matches = engine.find_similar(funcs_b[0], threshold=0.3)
    assert len(matches) >= 1
    match = matches[0]
    assert match.reuse_type == "direct_import"
    assert match.clone_type == "type1_type2"

def test_same_language_match_reuse_type():
    code_a = '''
def validate_email(email):
    import re
    return bool(re.match(r"^[\\w.]+@[\\w.]+$", email))
'''
    code_b = '''
def is_valid_email(addr):
    import re
    return bool(re.match(r"^[\\w.]+@[\\w.]+$", addr))
'''
    engine = SimilarityEngine(similarity_threshold=0.3)
    funcs_a = extract_functions_universal("a.py", code_a, "python")
    funcs_b = extract_functions_universal("b.py", code_b, "python")
    for f in funcs_a + funcs_b:
        engine.add_function(f)

    matches = engine.find_similar(funcs_b[0], threshold=0.3)
    assert len(matches) >= 1
    assert matches[0].reuse_type == "direct_import"

# ── Health score tests ────────────────────────────────────────────────────

def test_health_score_perfect():
    """No redundancies = score 100."""
    result = compute_health_score([], total_functions=50)
    assert result["score"] == 100
    assert result["grade"] == "A"

def test_health_score_empty():
    result = compute_health_score([], total_functions=0)
    assert result["score"] == 100

def test_health_score_with_matches():
    """Health score decreases with matches."""
    from echo_guard.similarity import SimilarityMatch

    src = _make_func("func_a", "a.py")
    ext = _make_func("func_b", "b.py")

    matches = [
        SimilarityMatch(source_func=src, existing_func=ext,
                       match_type="exact_structure", similarity_score=1.0,
                       reuse_type="direct_import", reuse_guidance=""),
    ]
    result = compute_health_score(matches, total_functions=50)
    assert result["score"] < 100
    # Pairwise matches (2 copies) are MEDIUM in the DRY-based severity model
    assert result["breakdown"]["medium"] == 1
    assert result["breakdown"]["total_redundancies"] == 1

def test_health_score_grades():
    """Many matches should produce a low score/grade."""
    from echo_guard.similarity import SimilarityMatch

    matches = []
    for i in range(20):
        src = _make_func(f"func_{i}", f"a{i}.py")
        ext = _make_func(f"dup_{i}", f"b{i}.py")
        matches.append(SimilarityMatch(
            source_func=src, existing_func=ext,
            match_type="exact_structure", similarity_score=1.0,
            reuse_type="direct_import", reuse_guidance="",
        ))

    result = compute_health_score(matches, total_functions=50)
    # 20 pairwise matches (MEDIUM severity) should still produce a poor score
    assert result["score"] < 80
    assert result["grade"] in ("C", "D", "F")

# ── Constructor exclusion tests ─────────────────────────────────────────

def test_constructor_match_different_classes_excluded():
    """__init__ across different classes should be excluded."""
    from echo_guard.similarity import _is_constructor_match
    a = _make_func("__init__", "a.py")
    a.class_name = "UserService"
    b = _make_func("__init__", "b.py")
    b.class_name = "PaymentService"
    assert _is_constructor_match(a, b) is True

def test_constructor_match_same_class_allowed():
    """__init__ on same-named classes should NOT be excluded (class-level duplication)."""
    from echo_guard.similarity import _is_constructor_match
    a = _make_func("__init__", "a.py")
    a.class_name = "UserService"
    b = _make_func("__init__", "b.py")
    b.class_name = "UserService"
    assert _is_constructor_match(a, b) is False

def test_non_constructor_not_excluded():
    """Regular functions should not be affected by constructor exclusion."""
    from echo_guard.similarity import _is_constructor_match
    a = _make_func("validate_email", "a.py")
    b = _make_func("validate_email", "b.py")
    assert _is_constructor_match(a, b) is False

# ── Observer pattern exclusion tests ─────────────────────────────────────

def test_observer_pattern_protocol_and_impl():
    """Protocol method + concrete implementation = observer pattern, not duplication."""
    from echo_guard.similarity import _is_observer_pattern
    a = _make_func("on_tool_call", "observers.py")
    a.class_name = "ObserverProtocol"
    a.class_type = "protocol"
    b = _make_func("on_tool_call", "observers.py")
    b.class_name = "LoggingObserver"
    b.class_type = "class"
    assert _is_observer_pattern(a, b) is True

def test_observer_pattern_same_class_not_excluded():
    """Same-class methods should not be excluded by observer pattern check."""
    from echo_guard.similarity import _is_observer_pattern
    a = _make_func("process", "a.py")
    a.class_name = "Handler"
    a.class_type = "class"
    b = _make_func("process", "a.py")
    b.class_name = "Handler"
    b.class_type = "class"
    assert _is_observer_pattern(a, b) is False

def test_observer_pattern_different_names_not_excluded():
    """Different method names across classes should not trigger observer exclusion."""
    from echo_guard.similarity import _is_observer_pattern
    a = _make_func("process", "a.py")
    a.class_name = "Handler"
    a.class_type = "class"
    b = _make_func("handle", "a.py")
    b.class_name = "Worker"
    b.class_type = "class"
    assert _is_observer_pattern(a, b) is False

# ── Service boundary detection tests ─────────────────────────────────────

def test_service_boundary_path_normalization():
    """Service boundary detection should handle ./ prefix and path normalization."""
    from echo_guard.similarity import _get_service
    boundaries = ["services/worker", "services/dashboard"]
    assert _get_service("services/worker/app/main.py", boundaries) == "services/worker"
    assert _get_service("./services/worker/app/main.py", boundaries) == "services/worker"
    assert _get_service("services/dashboard/views.py", boundaries) == "services/dashboard"
    assert _get_service("lib/utils.py", boundaries) is None

# ── Finding deduplication tests ──────────────────────────────────────────

def test_finding_deduplication_suppresses_subsets():
    """Subset findings should be suppressed."""
    from echo_guard.similarity import _deduplicate_findings, FindingGroup, SimilarityMatch

    a = _make_func("timeAgo", "a.py")
    b = _make_func("timeAgo", "b.py")
    c = _make_func("timeAgo", "c.py")

    match_ab = SimilarityMatch(
        source_func=a, existing_func=b,
        match_type="exact_structure", similarity_score=1.0,
        reuse_type="direct_import", reuse_guidance="",
    )
    # Group with 3 functions (superset of the pair)
    group_abc = FindingGroup(
        functions=[a, b, c],
        representative_match=match_ab,
        match_count=3,
        pattern_description="3 implementations of timeAgo()",
        reuse_type="direct_import",
        reuse_guidance="",
    )

    results = _deduplicate_findings([match_ab, group_abc])
    # The individual match_ab should be suppressed because {a, b} ⊂ {a, b, c}
    assert len(results) == 1
    assert isinstance(results[0], FindingGroup)

# ── Same-file threshold escalation tests ──────────────────────────────

def test_same_file_below_95_suppressed():
    """Same-file matches below 95% similarity should be suppressed."""
    engine = SimilarityEngine(similarity_threshold=0.50)

    # Two functions in the same file with similar but not identical code
    code_a = '''
def list_automations(db):
    rows = db.execute("SELECT * FROM automations")
    return [Automation(**r) for r in rows]
'''
    code_b = '''
def list_triggers(db):
    rows = db.execute("SELECT * FROM triggers")
    return [Trigger(**r) for r in rows]
'''
    from echo_guard.languages import ExtractedFunction
    func_a = ExtractedFunction(
        name="list_automations", filepath="repo.py", language="python",
        lineno=1, end_lineno=4, source=code_a, visibility="public",
    )
    func_b = ExtractedFunction(
        name="list_triggers", filepath="repo.py", language="python",
        lineno=5, end_lineno=8, source=code_b, visibility="public",
    )
    engine.add_function(func_a)
    engine.add_function(func_b)
    matches = engine.find_all_matches(threshold=0.50)
    # Should be suppressed: same file and similarity < 0.95
    assert len(matches) == 0

def test_same_file_above_95_kept():
    """Same-file matches at or above 95% should be kept."""
    from echo_guard.languages import extract_functions_universal

    engine = SimilarityEngine(similarity_threshold=0.50)

    # Two identical functions in the same file — extract with tree-sitter
    # to get proper AST hashes. Must be >25 lines to not be filtered by
    # the structural pattern rule (verb+noun suppression exempts long functions).
    code = '''
def compute_hash(data):
    if not data:
        raise ValueError("data required")
    if not isinstance(data, bytes):
        data = data.encode("utf-8")
    result = hashlib.sha256(data)
    formatted = result.hexdigest()
    prefix = formatted[:8]
    middle = formatted[8:16]
    suffix = formatted[16:24]
    tail = formatted[24:]
    combined = f"{prefix}-{middle}-{suffix}-{tail}"
    cleaned = combined.replace("--", "-")
    upper = cleaned.upper()
    validated = _validate(upper)
    if not validated:
        raise ValueError("validation failed")
    trimmed = validated.strip()
    encoded = base64.b64encode(trimmed.encode()).decode()
    cache[data] = encoded
    logger.info("computed hash: %s", encoded)
    stats.increment("hash_computed")
    metrics.record("hash_size", len(encoded))
    audit.log("hash", data, encoded)
    history.append(encoded)
    return encoded

def compute_digest(val):
    if not val:
        raise ValueError("val required")
    if not isinstance(val, bytes):
        val = val.encode("utf-8")
    output = hashlib.sha256(val)
    formatted = output.hexdigest()
    prefix = formatted[:8]
    middle = formatted[8:16]
    suffix = formatted[16:24]
    tail = formatted[24:]
    combined = f"{prefix}-{middle}-{suffix}-{tail}"
    cleaned = combined.replace("--", "-")
    upper = cleaned.upper()
    validated = _validate(upper)
    if not validated:
        raise ValueError("validation failed")
    trimmed = validated.strip()
    encoded = base64.b64encode(trimmed.encode()).decode()
    cache[val] = encoded
    logger.info("computed digest: %s", encoded)
    stats.increment("digest_computed")
    metrics.record("digest_size", len(encoded))
    audit.log("digest", val, encoded)
    history.append(encoded)
    return encoded
'''
    funcs = extract_functions_universal("utils.py", code, "python")
    assert len(funcs) == 2
    for f in funcs:
        engine.add_function(f)

    matches = engine.find_all_matches(threshold=0.50)
    # Same AST hash → score 1.0, same file, >25 lines → kept
    assert len(matches) >= 1

# ── Overlap deduplication tests ──────────────────────────────────────

def test_finding_deduplication_high_overlap():
    """Findings with ≥70% Jaccard overlap should be merged."""
    from echo_guard.similarity import _deduplicate_findings, FindingGroup, SimilarityMatch

    a = _make_func("schemaTypes", "a.py")
    b = _make_func("schemaTypes", "b.py")
    c = _make_func("extractEnumValues", "a.py")
    d = _make_func("extractEnumValues", "b.py")
    e = _make_func("parseLiteral", "a.py")

    match_ab = SimilarityMatch(
        source_func=a, existing_func=b,
        match_type="exact_structure", similarity_score=0.95,
        reuse_type="direct_import", reuse_guidance="",
    )

    # Group 1: {a, b, c, d}
    group1 = FindingGroup(
        functions=[a, b, c, d],
        representative_match=match_ab,
        match_count=4,
        pattern_description="4 functions",
        reuse_type="direct_import",
        reuse_guidance="",
    )
    # Group 2: {a, b, c, e} — shares 3 of 4 functions with group1 (Jaccard = 3/5 = 0.6)
    group2 = FindingGroup(
        functions=[a, b, c, e],
        representative_match=SimilarityMatch(
            source_func=a, existing_func=c,
            match_type="exact_structure", similarity_score=0.90,
            reuse_type="direct_import", reuse_guidance="",
        ),
        match_count=3,
        pattern_description="4 functions",
        reuse_type="direct_import",
        reuse_guidance="",
    )
    # Group 3: {a, b, c} — shares 3 of 4 with group1 (Jaccard = 3/4 = 0.75 ≥ 0.70)
    group3 = FindingGroup(
        functions=[a, b, c],
        representative_match=SimilarityMatch(
            source_func=a, existing_func=b,
            match_type="exact_structure", similarity_score=0.85,
            reuse_type="direct_import", reuse_guidance="",
        ),
        match_count=2,
        pattern_description="3 functions",
        reuse_type="direct_import",
        reuse_guidance="",
    )

    results = _deduplicate_findings([group1, group2, group3])
    # group3 is strict subset of group1 → suppressed
    # group2 overlaps 60% with group1 → merged (group-vs-group threshold is 0.60)
    # So we expect only group1
    assert len(results) == 1

# ── Cross-service import suggestion tests ────────────────────────────

def test_cross_service_import_suggestion_no_import_code():
    """Cross-service findings should NOT show import code."""
    from echo_guard.similarity import _generate_import_suggestion
    func = _make_func("insert_notification_log", "services/worker/notifications.py")
    suggestion = _generate_import_suggestion(func, "cross_service_reference")
    assert "import" not in suggestion.lower() or "NOT possible" in suggestion
    assert "shared library" in suggestion.lower() or "service boundary" in suggestion.lower()

# ── Parser keyword filtering tests ───────────────────────────────────

def test_async_keyword_not_extracted_as_function():
    """The keyword 'async' should not be extracted as a function name."""
    code = '''
const handler = async () => {
    const data = await fetchData();
    return data.map(item => item.value);
};
'''
    funcs = extract_functions_universal("test.ts", source=code, language="typescript")
    names = [f.name for f in funcs]
    assert "async" not in names

def test_if_keyword_not_extracted_as_function():
    """The keyword 'if' should not be extracted as a function name."""
    code = '''
function doSomething() {
    if (condition) {
        return true;
    }
    return false;
}
'''
    funcs = extract_functions_universal("test.ts", source=code, language="typescript")
    names = [f.name for f in funcs]
    assert "if" not in names
    assert "doSomething" in names

def test_arrow_function_gets_variable_name():
    """Arrow functions assigned to variables should use the variable name."""
    code = '''
const fetchData = async () => {
    const response = await fetch(url);
    return response.json();
};
'''
    funcs = extract_functions_universal("test.ts", source=code, language="typescript")
    names = [f.name for f in funcs]
    assert "fetchData" in names
    assert "async" not in names

# ── v6: Antonym camelCase normalization tests ────────────────────────

# ── v6: Constructor one-sided exclusion tests ────────────────────────

def test_constructor_one_sided_excluded():
    """A constructor matching a non-constructor should be suppressed."""
    from echo_guard.similarity import _is_constructor_match
    from echo_guard.languages import ExtractedFunction
    a = ExtractedFunction(
        name="_error_payload", filepath="a.py", language="python",
        lineno=1, end_lineno=5, source="def _error_payload(): pass",
        visibility="private",
    )
    b = ExtractedFunction(
        name="__init__", filepath="b.py", language="python",
        lineno=1, end_lineno=5, source="def __init__(self): pass",
        visibility="public", class_name="HttpRunnerError",
    )
    assert _is_constructor_match(a, b) is True

# ── v6: Cross-language threshold tests ───────────────────────────────

def test_cross_language_below_80_suppressed():
    """Cross-language matches below 80% should be suppressed."""
    engine = SimilarityEngine(similarity_threshold=0.50)

    from echo_guard.languages import ExtractedFunction
    func_a = ExtractedFunction(
        name="_row_to_config", filepath="model_config.py", language="python",
        lineno=1, end_lineno=10,
        source="def _row_to_config(row):\n    return {'name': row['name'], 'value': row['val']}",
        visibility="private",
    )
    func_b = ExtractedFunction(
        name="makeConfigForm", filepath="ModelConfigWizard.tsx", language="typescript",
        lineno=1, end_lineno=10,
        source="function makeConfigForm(row) {\n    return { name: row.name, value: row.val };\n}",
        visibility="public",
    )
    engine.add_function(func_a)
    engine.add_function(func_b)
    matches = engine.find_all_matches(threshold=0.50)
    # Cross-language, low similarity → suppressed
    for m in matches:
        assert m.similarity_score >= 0.80

# ── v6: UI wrapper component tests ───────────────────────────────────

# ── v6: Same-name score boost test ───────────────────────────────────

# ── v7: UI wrapper same-name exemption ───────────────────────────────

# ── v7: Per-service boilerplate exclusion ────────────────────────────

def test_per_service_health_excluded():
    """health() endpoints across services should be suppressed."""
    from echo_guard.similarity import _is_per_service_boilerplate
    a = _make_func("health", "services/worker/main.py")
    b = _make_func("health", "services/gateway/main.py")
    boundaries = ["services/worker", "services/gateway"]
    assert _is_per_service_boilerplate(a, b, boundaries) is True

def test_per_service_health_same_service_not_excluded():
    """health() in the same service should not be suppressed."""
    from echo_guard.similarity import _is_per_service_boilerplate
    a = _make_func("health", "services/worker/main.py")
    b = _make_func("health", "services/worker/routes.py")
    boundaries = ["services/worker"]
    assert _is_per_service_boilerplate(a, b, boundaries) is False

# ── v7: LOW filtering in output ──────────────────────────────────────

def test_all_findings_are_high_or_medium():
    """All findings should be HIGH or MEDIUM severity (no LOW)."""
    from echo_guard.output import group_matches
    from echo_guard.similarity import SimilarityMatch

    a = _make_func("fetchJson", "a.ts")
    b = _make_func("fetchJson", "b.ts")
    c = _make_func("helper", "c.ts")
    d = _make_func("other", "d.ts")

    match_high = SimilarityMatch(
        source_func=a, existing_func=b,
        match_type="exact_structure", similarity_score=1.0,
        reuse_type="direct_import", reuse_guidance="",
    )
    match_medium = SimilarityMatch(
        source_func=c, existing_func=d,
        match_type="embedding_semantic", similarity_score=0.85,
        reuse_type="direct_import", reuse_guidance="",
    )

    grouped = group_matches([match_high, match_medium])

    # All findings should exist
    assert len(grouped) >= 1
    # All findings should be high, medium, or low severity
    for item in grouped:
        assert item.severity in ("high", "medium", "low")
