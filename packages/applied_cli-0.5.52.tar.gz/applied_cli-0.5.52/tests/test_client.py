import json

import pytest

from applied_cli.client import AppliedClient


@pytest.mark.asyncio
async def test_ensure_test_conversation_creates_contact_backed_conversation(
    monkeypatch,
):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_get_or_create_contact(email=None, name=None, phone=None):
        seen["contact"] = {
            "email": email,
            "name": name,
            "phone": phone,
        }
        return {"id": "contact-1"}

    async def fake_create_conversation(
        agent_id,
        is_test=True,
        metadata=None,
        conversation_type=None,
        contact_id=None,
    ):
        seen["conversation"] = {
            "agent_id": agent_id,
            "is_test": is_test,
            "metadata": metadata,
            "conversation_type": conversation_type,
            "contact_id": contact_id,
        }
        return {"id": "conv-1"}

    monkeypatch.setattr(client, "get_or_create_contact", fake_get_or_create_contact)
    monkeypatch.setattr(client, "create_conversation", fake_create_conversation)

    conversation = await client.ensure_test_conversation(
        agent_id="agent-1",
        contact_email="customer@example.com",
        contact_name="Customer Example",
        metadata={"order_id": "123"},
        conversation_type="email",
    )

    assert conversation == {"id": "conv-1"}
    assert seen["contact"] == {
        "email": "customer@example.com",
        "name": "Customer Example",
        "phone": None,
    }
    assert seen["conversation"] == {
        "agent_id": "agent-1",
        "is_test": True,
        "metadata": {
            "order_id": "123",
            "context": {
                "email": "customer@example.com",
                "name": "Customer Example",
            },
        },
        "conversation_type": "email",
        "contact_id": "contact-1",
    }


@pytest.mark.asyncio
async def test_ensure_test_conversation_returns_existing_id_without_creating_new_one(
    monkeypatch,
):
    client = AppliedClient(token="test-token")

    async def fail_get_or_create_contact(**kwargs):
        raise AssertionError("should not create or lookup a contact")

    async def fail_create_conversation(**kwargs):
        raise AssertionError("should not create a conversation")

    monkeypatch.setattr(client, "get_or_create_contact", fail_get_or_create_contact)
    monkeypatch.setattr(client, "create_conversation", fail_create_conversation)

    conversation = await client.ensure_test_conversation(
        agent_id="agent-1",
        conversation_id="conv-existing",
        contact_email="ignored@example.com",
    )

    assert conversation == {"id": "conv-existing"}


@pytest.mark.asyncio
async def test_query_conversations_serializes_metric_event_filter_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["params"] = params
        return []

    monkeypatch.setattr(client, "_request", fake_request)

    await client.query_conversations(
        filters={
            "created_at": {
                "gte": "2026-03-22T16:50:00Z",
                "lte": "2026-03-22T19:00:00Z",
            },
            "runs__emitted_metric_events__contains": {
                "tool.run": {
                    "tool_name": ["Escalate Conversation"],
                    "success": ["False"],
                }
            },
        }
    )

    assert seen["method"] == "GET"
    assert seen["path"] == "/v1/conversations/"
    assert seen["params"]["created_at__gte"] == "2026-03-22T16:50:00Z"
    assert seen["params"]["created_at__lte"] == "2026-03-22T19:00:00Z"
    assert seen["params"]["runs__emitted_metric_events__contains"] == json.dumps(
        {
            "tool.run": {
                "tool_name": ["Escalate Conversation"],
                "success": ["False"],
            }
        },
        separators=(",", ":"),
        ensure_ascii=True,
    )


@pytest.mark.asyncio
async def test_analytics_report_posts_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"ok": True}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.analytics_report(
        {
            "view": "dashboard_rate_metrics",
            "model": "conversation",
            "group_by": "agent_revision_version",
        }
    )

    assert result == {"ok": True}
    assert seen == {
        "method": "POST",
        "path": "/v2/analytics/",
        "body": {
            "view": "dashboard_rate_metrics",
            "model": "conversation",
            "group_by": "agent_revision_version",
        },
    }


@pytest.mark.asyncio
async def test_analytics_sql_posts_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"rows": []}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.analytics_sql(
        sql="SELECT count() AS total FROM conversation_latest_state",
        parameters={"resolution": "escalated"},
        max_rows=25,
    )

    assert result == {"rows": []}
    assert seen == {
        "method": "POST",
        "path": "/v2/agents/analytics/query/",
        "body": {
            "mode": "sql",
            "sql": "SELECT count() AS total FROM conversation_latest_state",
            "parameters": {"resolution": "escalated"},
            "max_rows": 25,
        },
    }


@pytest.mark.asyncio
async def test_analytics_query_builds_legacy_sql(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_analytics_sql(*, sql, parameters=None, max_rows=None):
        seen["sql"] = sql
        seen["parameters"] = parameters
        seen["max_rows"] = max_rows
        return {
            "columns": ["resolution", "count"],
            "rows": [{"resolution": "escalated", "count": 4}],
        }

    monkeypatch.setattr(client, "analytics_sql", fake_analytics_sql)

    result = await client.analytics_query(
        group_by=["resolution"],
        metrics=["count"],
        filters=["agent_id=agent-1", "score=2"],
        start="2026-03-01",
        end="2026-03-31",
        limit=100,
    )

    assert result["rows"] == [{"resolution": "escalated", "count": 4}]
    assert result["dimensions"] == ["resolution"]
    assert result["metrics"] == ["count"]
    assert "SELECT resolution AS resolution, count() AS count" in seen["sql"]
    assert "FROM conversation_latest_state" in seen["sql"]
    assert "agent_id = 'agent-1'" in seen["sql"]
    assert "score = 2" in seen["sql"]
    assert "created_at >= '2026-03-01'" in seen["sql"]
    assert "created_at <= '2026-03-31'" in seen["sql"]
    assert "LIMIT 100" in seen["sql"]
    assert seen["parameters"] is None
    assert seen["max_rows"] == 100


@pytest.mark.asyncio
async def test_list_audit_batches_queries_new_batch_endpoint(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["params"] = params
        return {"results": [{"id": "audit-batch-1"}]}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.list_audit_batches(
        target_type="conversation",
        status="in_progress",
        period_end_gte="2026-03-16",
        period_start_lte="2026-03-22",
    )

    assert result == [{"id": "audit-batch-1"}]
    assert seen == {
        "method": "GET",
        "path": "/v1/audit-batches/",
        "params": {
            "limit": 100,
            "target_type": "conversation",
            "status": "in_progress",
            "period_end__gte": "2026-03-16",
            "period_start__lte": "2026-03-22",
        },
    }


@pytest.mark.asyncio
async def test_update_audit_rating_patches_notes(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"id": "audit-rating-1", "notes": body["notes"]}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.update_audit_rating(
        "audit-rating-1",
        notes="Root cause is missing payout tooling.",
        quality_score=2.0,
    )

    assert result == {
        "id": "audit-rating-1",
        "notes": "Root cause is missing payout tooling.",
    }
    assert seen == {
        "method": "PATCH",
        "path": "/v1/audit-ratings/audit-rating-1/",
        "body": {
            "notes": "Root cause is missing payout tooling.",
            "quality_score": 2.0,
        },
    }


@pytest.mark.asyncio
async def test_set_audit_rating_value_posts_metric_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"ok": True}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.set_audit_rating_value(
        "audit-rating-1",
        metric_field_id="field-1",
        value={"choice": "Needs action"},
    )

    assert result == {"ok": True}
    assert seen == {
        "method": "POST",
        "path": "/v1/audit-ratings/audit-rating-1/set-value/",
        "body": {
            "metric_field_id": "field-1",
            "value": {"choice": "Needs action"},
        },
    }
