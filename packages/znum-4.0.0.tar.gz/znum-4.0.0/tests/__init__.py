# znum test suite
