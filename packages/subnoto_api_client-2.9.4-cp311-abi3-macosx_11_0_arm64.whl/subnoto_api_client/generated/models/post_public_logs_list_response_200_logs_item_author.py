from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PostPublicLogsListResponse200LogsItemAuthor")



@_attrs_define
class PostPublicLogsListResponse200LogsItemAuthor:
    """ 
        Attributes:
            id (float): The author ID (0 for System user).
            email (str): The author email address.
            name (str): The author display name.
     """

    id: float
    email: str
    name: str





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        email = self.email

        name = self.name


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "id": id,
            "email": email,
            "name": name,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        email = d.pop("email")

        name = d.pop("name")

        post_public_logs_list_response_200_logs_item_author = cls(
            id=id,
            email=email,
            name=name,
        )

        return post_public_logs_list_response_200_logs_item_author

