from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_logs_list_body_category import PostPublicLogsListBodyCategory
from ..models.post_public_logs_list_body_event_types_item_type_0 import PostPublicLogsListBodyEventTypesItemType0
from ..models.post_public_logs_list_body_event_types_item_type_1 import PostPublicLogsListBodyEventTypesItemType1
from ..models.post_public_logs_list_body_sort_by import PostPublicLogsListBodySortBy
from ..models.post_public_logs_list_body_sort_order import PostPublicLogsListBodySortOrder
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PostPublicLogsListBody")



@_attrs_define
class PostPublicLogsListBody:
    """ 
        Attributes:
            category (PostPublicLogsListBodyCategory): The log category to list.
            workspace_uuid (str | Unset): Filter by workspace UUID (envelope category only).
            envelope_uuid (str | Unset): Filter by envelope UUID (envelope category only).
            event_types (list[PostPublicLogsListBodyEventTypesItemType0 | PostPublicLogsListBodyEventTypesItemType1] |
                Unset): Filter by event types. For envelope category use envelope event types; for team category use team event
                types. When empty or omitted, all event types are returned.
            page (int | Unset): The page number (1-indexed). Defaults to 1. Default: 1.
            limit (int | Unset): The number of results per page. Defaults to 50, maximum is 50. Default: 50.
            sort_by (PostPublicLogsListBodySortBy | Unset): The field to sort by. Defaults to 'timestamp'. Default:
                PostPublicLogsListBodySortBy.TIMESTAMP.
            sort_order (PostPublicLogsListBodySortOrder | Unset): The sort order. Defaults to 'desc'. Default:
                PostPublicLogsListBodySortOrder.DESC.
     """

    category: PostPublicLogsListBodyCategory
    workspace_uuid: str | Unset = UNSET
    envelope_uuid: str | Unset = UNSET
    event_types: list[PostPublicLogsListBodyEventTypesItemType0 | PostPublicLogsListBodyEventTypesItemType1] | Unset = UNSET
    page: int | Unset = 1
    limit: int | Unset = 50
    sort_by: PostPublicLogsListBodySortBy | Unset = PostPublicLogsListBodySortBy.TIMESTAMP
    sort_order: PostPublicLogsListBodySortOrder | Unset = PostPublicLogsListBodySortOrder.DESC
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        category = self.category.value

        workspace_uuid = self.workspace_uuid

        envelope_uuid = self.envelope_uuid

        event_types: list[str] | Unset = UNSET
        if not isinstance(self.event_types, Unset):
            event_types = []
            for event_types_item_data in self.event_types:
                event_types_item: str
                if isinstance(event_types_item_data, PostPublicLogsListBodyEventTypesItemType0):
                    event_types_item = event_types_item_data.value
                else:
                    event_types_item = event_types_item_data.value

                event_types.append(event_types_item)



        page = self.page

        limit = self.limit

        sort_by: str | Unset = UNSET
        if not isinstance(self.sort_by, Unset):
            sort_by = self.sort_by.value


        sort_order: str | Unset = UNSET
        if not isinstance(self.sort_order, Unset):
            sort_order = self.sort_order.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "category": category,
        })
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid
        if envelope_uuid is not UNSET:
            field_dict["envelopeUuid"] = envelope_uuid
        if event_types is not UNSET:
            field_dict["eventTypes"] = event_types
        if page is not UNSET:
            field_dict["page"] = page
        if limit is not UNSET:
            field_dict["limit"] = limit
        if sort_by is not UNSET:
            field_dict["sortBy"] = sort_by
        if sort_order is not UNSET:
            field_dict["sortOrder"] = sort_order

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        category = PostPublicLogsListBodyCategory(d.pop("category"))




        workspace_uuid = d.pop("workspaceUuid", UNSET)

        envelope_uuid = d.pop("envelopeUuid", UNSET)

        _event_types = d.pop("eventTypes", UNSET)
        event_types: list[PostPublicLogsListBodyEventTypesItemType0 | PostPublicLogsListBodyEventTypesItemType1] | Unset = UNSET
        if _event_types is not UNSET:
            event_types = []
            for event_types_item_data in _event_types:
                def _parse_event_types_item(data: object) -> PostPublicLogsListBodyEventTypesItemType0 | PostPublicLogsListBodyEventTypesItemType1:
                    try:
                        if not isinstance(data, str):
                            raise TypeError()
                        event_types_item_type_0 = PostPublicLogsListBodyEventTypesItemType0(data)



                        return event_types_item_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, str):
                        raise TypeError()
                    event_types_item_type_1 = PostPublicLogsListBodyEventTypesItemType1(data)



                    return event_types_item_type_1

                event_types_item = _parse_event_types_item(event_types_item_data)

                event_types.append(event_types_item)


        page = d.pop("page", UNSET)

        limit = d.pop("limit", UNSET)

        _sort_by = d.pop("sortBy", UNSET)
        sort_by: PostPublicLogsListBodySortBy | Unset
        if isinstance(_sort_by,  Unset):
            sort_by = UNSET
        else:
            sort_by = PostPublicLogsListBodySortBy(_sort_by)




        _sort_order = d.pop("sortOrder", UNSET)
        sort_order: PostPublicLogsListBodySortOrder | Unset
        if isinstance(_sort_order,  Unset):
            sort_order = UNSET
        else:
            sort_order = PostPublicLogsListBodySortOrder(_sort_order)




        post_public_logs_list_body = cls(
            category=category,
            workspace_uuid=workspace_uuid,
            envelope_uuid=envelope_uuid,
            event_types=event_types,
            page=page,
            limit=limit,
            sort_by=sort_by,
            sort_order=sort_order,
        )


        post_public_logs_list_body.additional_properties = d
        return post_public_logs_list_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
