from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_logs_list_response_200_logs_item_category import PostPublicLogsListResponse200LogsItemCategory
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_logs_list_response_200_logs_item_event_data import PostPublicLogsListResponse200LogsItemEventData
  from ..models.post_public_logs_list_response_200_logs_item_author import PostPublicLogsListResponse200LogsItemAuthor





T = TypeVar("T", bound="PostPublicLogsListResponse200LogsItem")



@_attrs_define
class PostPublicLogsListResponse200LogsItem:
    """ 
        Attributes:
            category (PostPublicLogsListResponse200LogsItemCategory): The log category.
            event_type (str): The type of event.
            event_data (PostPublicLogsListResponse200LogsItemEventData): Event-specific data.
            timestamp (float): The timestamp of when this event occurred (unix timestamp).
            author (PostPublicLogsListResponse200LogsItemAuthor):
            envelope_uuid (str | Unset): The envelope UUID (envelope category only).
            workspace_uuid (str | Unset): The workspace UUID (envelope category only).
     """

    category: PostPublicLogsListResponse200LogsItemCategory
    event_type: str
    event_data: PostPublicLogsListResponse200LogsItemEventData
    timestamp: float
    author: PostPublicLogsListResponse200LogsItemAuthor
    envelope_uuid: str | Unset = UNSET
    workspace_uuid: str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_logs_list_response_200_logs_item_event_data import PostPublicLogsListResponse200LogsItemEventData
        from ..models.post_public_logs_list_response_200_logs_item_author import PostPublicLogsListResponse200LogsItemAuthor
        category = self.category.value

        event_type = self.event_type

        event_data = self.event_data.to_dict()

        timestamp = self.timestamp

        author = self.author.to_dict()

        envelope_uuid = self.envelope_uuid

        workspace_uuid = self.workspace_uuid


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "category": category,
            "eventType": event_type,
            "eventData": event_data,
            "timestamp": timestamp,
            "author": author,
        })
        if envelope_uuid is not UNSET:
            field_dict["envelopeUuid"] = envelope_uuid
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_logs_list_response_200_logs_item_event_data import PostPublicLogsListResponse200LogsItemEventData
        from ..models.post_public_logs_list_response_200_logs_item_author import PostPublicLogsListResponse200LogsItemAuthor
        d = dict(src_dict)
        category = PostPublicLogsListResponse200LogsItemCategory(d.pop("category"))




        event_type = d.pop("eventType")

        event_data = PostPublicLogsListResponse200LogsItemEventData.from_dict(d.pop("eventData"))




        timestamp = d.pop("timestamp")

        author = PostPublicLogsListResponse200LogsItemAuthor.from_dict(d.pop("author"))




        envelope_uuid = d.pop("envelopeUuid", UNSET)

        workspace_uuid = d.pop("workspaceUuid", UNSET)

        post_public_logs_list_response_200_logs_item = cls(
            category=category,
            event_type=event_type,
            event_data=event_data,
            timestamp=timestamp,
            author=author,
            envelope_uuid=envelope_uuid,
            workspace_uuid=workspace_uuid,
        )

        return post_public_logs_list_response_200_logs_item

