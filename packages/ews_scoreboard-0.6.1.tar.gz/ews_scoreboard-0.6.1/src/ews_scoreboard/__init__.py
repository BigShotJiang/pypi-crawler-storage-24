"""EWS Scoreboard Pipeline."""
__version__ = "0.6.1"
