"""
Marts: silver → mart tables (scoreboard, trending lists).
"""

import json
import csv
import duckdb
from pathlib import Path


def _build_scoreboard(con) -> dict:
    """Build scoreboard mart and return as dict for JSON export."""
    donemler = [r[0] for r in con.execute(
        "SELECT DISTINCT donem FROM fact_periodic ORDER BY donem"
    ).fetchall()]

    if not donemler:
        print("    [WARN] No periods in fact_periodic")
        return {"meta": {}, "rows": []}

    son_donem = donemler[-1]

    risk_donemler = [r[0] for r in con.execute(
        "SELECT DISTINCT donem FROM fact_periodic WHERE kombine_risk IS NOT NULL ORDER BY donem"
    ).fetchall()]

    base_df = con.execute("""
        WITH risk_filter AS (
            SELECT DISTINCT entity_id FROM fact_periodic
            WHERE ABS(COALESCE(kombine_risk, 0)) > 1
        ),
        yi_transition AS (
            SELECT DISTINCT entity_id FROM fact_periodic WHERE ews_skor = 'YI'
            INTERSECT
            SELECT DISTINCT entity_id FROM fact_periodic WHERE ews_skor IS NOT NULL AND ews_skor != 'YI'
        )
        SELECT entity_id FROM risk_filter
        UNION
        SELECT entity_id FROM yi_transition
    """).fetchdf()

    entity_ids = base_df["entity_id"].tolist()
    if not entity_ids:
        return {"meta": {"donemler": donemler, "son_donem": son_donem, "n_muta": 0}, "rows": []}

    rows_data = con.execute("""
        SELECT
            de.entity_id,
            mi.unvan,
            de.segment,
            de.sube_kodu,
            sb.sube_adi,
            de.bolge_kodu,
            sb2.bolge_adi
        FROM dim_entity de
        LEFT JOIN map_identity mi ON de.entity_id = mi.entity_id
        LEFT JOIN ref_sube_bolge sb ON de.sube_kodu = sb.sube_kodu
        LEFT JOIN (
            SELECT DISTINCT ON (bolge_kodu) bolge_kodu, bolge_adi
            FROM ref_sube_bolge ORDER BY bolge_kodu
        ) sb2 ON de.bolge_kodu = sb2.bolge_kodu
        WHERE de.entity_id = ANY($1)
    """, [entity_ids]).fetchdf()

    period_data = con.execute("""
        SELECT entity_id, donem, ews_skor, kombine_risk, risk_degisim, tfrs_rating, rating_tarihi
        FROM fact_periodic
        WHERE entity_id = ANY($1)
    """, [entity_ids]).fetchdf()

    period_lookup = {}
    for _, r in period_data.iterrows():
        eid = r["entity_id"]
        d = r["donem"]
        if eid not in period_lookup:
            period_lookup[eid] = {}
        period_lookup[eid][d] = r

    son_risk_map = {}
    for _, r in period_data[period_data["donem"] == son_donem].iterrows():
        son_risk_map[r["entity_id"]] = _safe_int(r["kombine_risk"]) or 0

    rows = []
    for _, static in rows_data.iterrows():
        eid = static["entity_id"]
        row = {
            "muta": eid,
            "unvan": static["unvan"] if static["unvan"] and str(static["unvan"]) not in ("None", "<NA>", "nan") else None,
            "segment": static["segment"] if static["segment"] and str(static["segment"]) not in ("None", "<NA>", "nan") else None,
            "son_risk": son_risk_map.get(eid, 0),
            "sube_kodu": int(static["sube_kodu"]) if static["sube_kodu"] is not None and str(static["sube_kodu"]) not in ("None", "<NA>", "nan") else None,
            "sube_adi": static["sube_adi"] if static["sube_adi"] and str(static["sube_adi"]) not in ("None", "<NA>", "nan") else None,
            "bolge_kodu": int(static["bolge_kodu"]) if static["bolge_kodu"] is not None and str(static["bolge_kodu"]) not in ("None", "<NA>", "nan") else None,
            "bolge_adi": static["bolge_adi"] if static["bolge_adi"] and str(static["bolge_adi"]) not in ("None", "<NA>", "nan") else None,
        }

        periods = period_lookup.get(eid, {})
        for d in donemler:
            pr = periods.get(d)
            if pr is not None:
                ews_val = pr["ews_skor"]
                if ews_val is not None and str(ews_val) not in ("None", "<NA>", "nan"):
                    row[f"ews{d}"] = str(ews_val) if ews_val == "YI" else _safe_int(ews_val)
                else:
                    row[f"ews{d}"] = None

                row[f"r{d}"] = _safe_int(pr["kombine_risk"])
                row[f"rd{d}"] = _safe_int(pr["risk_degisim"])
                row[f"df{d}"] = row["son_risk"] - (row[f"r{d}"] or 0) if row[f"r{d}"] is not None else None

                tfrs = pr["tfrs_rating"]
                row[f"tfrs_{d}"] = str(tfrs) if tfrs is not None and str(tfrs) not in ("None", "<NA>", "nan") else None
                rtar = pr["rating_tarihi"]
                row[f"rtar_{d}"] = str(rtar) if rtar is not None and str(rtar) not in ("None", "<NA>", "nan") else None
            else:
                for prefix in ["ews", "r", "rd", "df"]:
                    row[f"{prefix}{d}"] = None
                row[f"tfrs_{d}"] = None
                row[f"rtar_{d}"] = None

        rows.append(row)

    rows.sort(key=lambda r: r.get("son_risk", 0) or 0, reverse=True)

    bolge_list = sorted(set(r["bolge_adi"] for r in rows if r.get("bolge_adi")))
    sube_list = sorted(set(r["sube_adi"] for r in rows if r.get("sube_adi")))

    meta = {
        "donemler": donemler,
        "risk_donemler": risk_donemler,
        "son_donem": son_donem,
        "n_muta": len(rows),
        "bolge_listesi": bolge_list,
        "sube_listesi": sube_list,
        "pipeline_ts": "dummy_run",
        "notebook": "pipeline_runner",
    }

    return {"meta": meta, "rows": rows}


def _safe_int(val):
    if val is None or str(val) in ("None", "<NA>", "nan", ""):
        return None
    try:
        return int(float(str(val)))
    except (ValueError, TypeError):
        return None


def _build_trending_lists(con, scoreboard: dict) -> dict:
    """Build trending lists from scoreboard data."""
    rows = scoreboard.get("rows", [])
    donemler = scoreboard.get("meta", {}).get("donemler", [])

    empty = {"fastest_rising": [], "regime_change": [], "persistent_high": [],
             "low_but_rising": [], "caught_yi": [], "missed_yi": []}
    if len(donemler) < 2:
        return empty

    son = donemler[-1]
    son_1 = donemler[-2] if len(donemler) >= 2 else None
    son_3 = donemler[-4] if len(donemler) >= 4 else donemler[0]

    def _ews_num(row, d):
        v = row.get(f"ews{d}")
        if v is None:
            return None
        if v == "YI" or v == -1:
            return 1000
        try:
            return int(v)
        except (ValueError, TypeError):
            return None

    enriched = []
    for r in rows:
        s_last = _ews_num(r, son)
        s_prev1 = _ews_num(r, son_1) if son_1 else None
        s_prev3 = _ews_num(r, son_3)

        delta_1 = (s_last - s_prev1) if s_last is not None and s_prev1 is not None else None
        delta_3 = (s_last - s_prev3) if s_last is not None and s_prev3 is not None else None

        consec = 0
        for i in range(len(donemler) - 1, 0, -1):
            curr = _ews_num(r, donemler[i])
            prev = _ews_num(r, donemler[i - 1])
            if curr is not None and prev is not None and curr > prev:
                consec += 1
            else:
                break

        enriched.append({
            **r,
            "_score_last": s_last,
            "_delta_1": delta_1,
            "_delta_3": delta_3,
            "_consec": consec,
        })

    # ── Helper: is row YI in given period? ──
    def _is_yi(row, d):
        v = row.get(f"ews{d}")
        return v == "YI" or v == -1

    # ── Helper: was firm YI in ALL available periods? ──
    def _always_yi(row):
        return all(_is_yi(row, d) for d in donemler)

    # ── Identify current-period YI firms ──
    yi_mutas = set()
    for e in enriched:
        if _is_yi(e, son):
            yi_mutas.add(e["muta"])

    # ── NEW YI this period: YI in son BUT NOT YI in son-1 ──
    new_yi = [e for e in enriched
              if e["muta"] in yi_mutas and not _always_yi(e) and not _is_yi(e, son_1)]

    # ── Caught YI ──
    # Criteria: new YI + (prev score >= 825 OR rapid rise pattern: was <200 then jumped to ~500+)
    caught_yi = []
    missed_yi = []
    for e in new_yi:
        s_prev = _ews_num(e, son_1) if son_1 else None
        # Check for rapid rise: look 2+ periods back for low scores then jump
        rapid_rise = False
        if len(donemler) >= 3:
            s_prev2 = _ews_num(e, donemler[-3]) if not _is_yi(e, donemler[-3]) else None
            if (s_prev2 is not None and s_prev2 < 200
                    and s_prev is not None and s_prev >= 500):
                rapid_rise = True

        prev_high_score = (s_prev is not None and s_prev >= 825)

        if prev_high_score or rapid_rise:
            reason_parts = []
            if prev_high_score:
                reason_parts.append(f"Önceki dönem skor: {s_prev}")
            if rapid_rise:
                reason_parts.append(f"Hızlı yükseliş: {s_prev2}→{s_prev}")
            caught_yi.append({
                "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
                "score_last": e["_score_last"],
                "reason": "Yakalandı: " + ", ".join(reason_parts),
            })
        else:
            prev_str = str(s_prev) if s_prev is not None else "?"
            missed_yi.append({
                "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
                "score_last": e["_score_last"],
                "reason": f"Kaçırıldı: Önceki dönem skor {prev_str} (<825)",
            })
    caught_yi.sort(key=lambda x: x.get("son_risk", 0) or 0, reverse=True)
    missed_yi.sort(key=lambda x: x.get("son_risk", 0) or 0, reverse=True)

    # ── Other trending lists (exclude current YI) ──
    non_yi = [e for e in enriched if e["muta"] not in yi_mutas]

    # ── Hızlı Yükselenler: current score >= 500, rising, meaningful delta ──
    fastest = [e for e in non_yi
               if e["_score_last"] is not None and e["_score_last"] >= 500
               and e["_delta_3"] is not None and e["_delta_3"] > 0
               and e.get("_delta_1", 0) and e["_delta_1"] > 0]
    fastest.sort(key=lambda x: x["_delta_3"], reverse=True)
    fastest_out = [{
        "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
        "score_last": e["_score_last"], "delta_3": e["_delta_3"],
        "reason": f"Son 3 dönemde +{e['_delta_3']} puan artış (şu an {e['_score_last']})"
    } for e in fastest[:50]]

    # ── Band Geçişi: önceden EUS bandındayken (325+ vermişiz) şimdi YIS bandına (500+) geçmiş ──
    # Ek koşul: önceki dönem(ler)de <500 olmalı (gerçek geçiş)
    regime = []
    for e in non_yi:
        s_curr = e["_score_last"]
        if s_curr is None or s_curr < 500:
            continue
        # Önceki dönem 500 altı olmalı (gerçek band geçişi)
        s_prev = _ews_num(e, son_1) if son_1 else None
        if s_prev is None or s_prev >= 500:
            continue
        # Daha önceki dönemlerde 325+ veriyor olmalıyız (erken sinyal vermiştik)
        had_early_signal = False
        signal_score = None
        for d in donemler[:-1]:
            s = _ews_num(e, d)
            if s is not None and 325 <= s < 500:
                had_early_signal = True
                signal_score = s
                break
        # OR: rapid jump from <100 to ~325+ then 500+
        rapid_jump = False
        if len(donemler) >= 3:
            for i in range(len(donemler) - 2):
                s_early = _ews_num(e, donemler[i])
                s_mid = _ews_num(e, donemler[i + 1])
                if (s_early is not None and s_early < 100
                        and s_mid is not None and s_mid >= 325):
                    rapid_jump = True
                    signal_score = s_mid
                    break
        if had_early_signal or rapid_jump:
            reason = "Band geçişi: "
            if had_early_signal:
                reason += f"Önceden {signal_score} skor verilmişti, şimdi {s_curr}"
            elif rapid_jump:
                reason += f"Hızlı sıçrama ({signal_score}), şimdi {s_curr}"
            regime.append({
                "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
                "score_last": s_curr, "reason": reason,
            })
    regime.sort(key=lambda x: x.get("score_last", 0), reverse=True)

    # ── Potansiyel YI: çoğu dönemde 825+ (en az %75) ──
    persistent = []
    n_check = min(6, len(donemler))
    check_periods = donemler[-n_check:]
    min_high_count = max(2, int(n_check * 0.75))  # en az %75'i 825+
    for e in non_yi:
        high_count = sum(1 for d in check_periods
                         if (_ews_num(e, d) or 0) >= 825)
        if high_count >= min_high_count and e["son_risk"] and e["son_risk"] > 0:
            persistent.append({
                "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
                "score_last": e["_score_last"],
                "reason": f"Son {n_check} dönemin {high_count} tanesinde skor >= 825"
            })
    persistent.sort(key=lambda x: x.get("son_risk", 0), reverse=True)

    # ── Erken Sinyal: score >= 325, yükseliyor, önceki dönem YI değil ──
    low_rising = []
    for e in non_yi:
        s = e["_score_last"]
        d3 = e["_delta_3"]
        if s is None or s < 325 or s >= 825:
            continue
        if d3 is None or d3 < 100:
            continue
        # Önceki dönem YI'dan çıkmış olmamalı
        if _is_yi(e, son_1):
            continue
        # Yükseliş trendi: son dönem > önceki dönem
        if e["_delta_1"] is None or e["_delta_1"] <= 0:
            continue
        low_rising.append(e)
    low_rising.sort(key=lambda x: x["_delta_3"], reverse=True)
    low_rising_out = [{
        "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
        "score_last": e["_score_last"], "delta_3": e["_delta_3"],
        "reason": f"Erken sinyal: {e['_score_last']} skor, +{e['_delta_3']} artış"
    } for e in low_rising[:50]]

    return {
        "fastest_rising": fastest_out,
        "regime_change": regime,
        "persistent_high": persistent,
        "low_but_rising": low_rising_out,
        "caught_yi": caught_yi,
        "missed_yi": missed_yi,
    }


def _export_sube_bolge_ref(con, output_dir: Path):
    """Export ref_sube_bolge as CSV for HTML pipeline adaptor."""
    ref_path = output_dir / "sube_bolge_ref.csv"
    rows = con.execute("""
        SELECT sube_kodu, sube_adi, bolge_kodu, bolge_adi
        FROM ref_sube_bolge
        ORDER BY bolge_kodu, sube_kodu
    """).fetchall()
    with open(ref_path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["sube_kodu", "sube_adi", "bolge_kodu", "bolge_adi"])
        w.writerows(rows)
    print(f"    sube_bolge_ref.csv: {len(rows)} rows → {ref_path}")


def run_marts(db_path: Path, output_dir: Path = None):
    """Run all mart builds."""
    con = duckdb.connect(str(db_path))

    if output_dir is None:
        output_dir = Path(db_path).parent.parent / "outputs" / "json"
    output_dir.mkdir(parents=True, exist_ok=True)

    print("  Building scoreboard mart...")
    scoreboard = _build_scoreboard(con)
    n_rows = len(scoreboard.get("rows", []))
    n_periods = len(scoreboard.get("meta", {}).get("donemler", []))
    print(f"    scoreboard: {n_rows} entities, {n_periods} periods")

    scoreboard_path = output_dir / "sample_scoreboard.json"
    with open(scoreboard_path, "w", encoding="utf-8") as f:
        json.dump(scoreboard, f, ensure_ascii=False, indent=2, default=str)
    print(f"    → {scoreboard_path}")

    print("  Exporting sube_bolge_ref.csv...")
    _export_sube_bolge_ref(con, output_dir)

    print("  Building trending lists...")
    trending = _build_trending_lists(con, scoreboard)
    for k, v in trending.items():
        print(f"    {k}: {len(v)} entities")

    trending_path = output_dir / "sample_trending_lists.json"
    with open(trending_path, "w", encoding="utf-8") as f:
        json.dump(trending, f, ensure_ascii=False, indent=2, default=str)
    print(f"    → {trending_path}")

    con.close()

    # Enrich scoreboard rows with trending flags + reasons
    _enrich_with_trending(scoreboard, trending)

    # ML predictions (if model exists)
    try:
        from ews_scoreboard.ml.predict import run_predictions
        print("  Running ML predictions...")
        scoreboard = run_predictions(db_path, scoreboard)
    except ImportError as e:
        print(f"  [ML] Skipping: {e}")
    except Exception as e:
        print(f"  [ML] Error: {e}")

    with open(scoreboard_path, "w", encoding="utf-8") as f:
        json.dump(scoreboard, f, ensure_ascii=False, indent=2, default=str)

    print("  Rendering HTML dashboard...")
    from ews_scoreboard.pipeline.html_render import render_html
    ref_csv = output_dir / "sube_bolge_ref.csv"
    html_out = output_dir / "ews_dashboard.html"
    render_html(scoreboard_path, html_out, ref_csv)

    return scoreboard, trending


def _enrich_with_trending(scoreboard: dict, trending: dict):
    """Add trending flags and reason text to scoreboard rows."""
    flag_map = {
        "fastest_rising": "_hizli_yukselen",
        "regime_change": "_rejim_degisimi",
        "persistent_high": "_potansiyel_yi",
        "low_but_rising": "_erken_sinyal",
        "caught_yi": "_yakalanan",
        "missed_yi": "_kacirilan",
    }
    # Build muta → reasons mapping
    muta_flags = {}  # muta → {flag: True, ...}
    muta_reasons = {}  # muta → [reason1, reason2, ...]

    for list_key, flag_name in flag_map.items():
        for item in trending.get(list_key, []):
            m = str(item.get("muta", ""))
            if m not in muta_flags:
                muta_flags[m] = {}
                muta_reasons[m] = []
            muta_flags[m][flag_name] = 1
            reason = item.get("reason", "")
            if reason:
                muta_reasons[m].append(reason)

    # Apply to scoreboard rows
    for row in scoreboard.get("rows", []):
        m = str(row.get("muta", ""))
        flags = muta_flags.get(m, {})
        row["_hizli_yukselen"] = flags.get("_hizli_yukselen", 0)
        row["_rejim_degisimi"] = flags.get("_rejim_degisimi", 0)
        row["_potansiyel_yi"] = flags.get("_potansiyel_yi", 0)
        row["_erken_sinyal"] = flags.get("_erken_sinyal", 0)
        row["_yakalanan"] = flags.get("_yakalanan", 0)
        row["_kacirilan"] = flags.get("_kacirilan", 0)
        row["_ews_neden"] = " | ".join(muta_reasons.get(m, [])) if m in muta_reasons else ""

    # Stats
    n = sum(1 for r in scoreboard["rows"] if any(r.get(f, 0) for f in flag_map.values()))
    print(f"    trending flags: {n} entities enriched")
