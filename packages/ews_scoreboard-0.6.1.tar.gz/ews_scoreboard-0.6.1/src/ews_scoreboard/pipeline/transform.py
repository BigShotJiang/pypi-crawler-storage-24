"""
Transform: bronze → silver tables (dim_entity, fact_periodic, map_identity, ref_sube_bolge).
"""

import duckdb
from pathlib import Path


def run_transforms(db_path: Path):
    """Run all silver transforms."""
    con = duckdb.connect(str(db_path))

    # 1. ref_sube_bolge
    print("  Building ref_sube_bolge...")
    con.execute("DELETE FROM ref_sube_bolge")
    con.execute("""
        INSERT INTO ref_sube_bolge
        SELECT DISTINCT ON (sube_kodu)
            sube_kodu,
            sube_adi,
            COALESCE(bolge_kodu, 0) AS bolge_kodu,
            COALESCE(bolge_adi, 'Bölge Dışı') AS bolge_adi
        FROM brz_statik
        WHERE sube_kodu IS NOT NULL
        ORDER BY sube_kodu
    """)
    cnt = con.execute("SELECT COUNT(*) FROM ref_sube_bolge").fetchone()[0]
    print(f"    ref_sube_bolge: {cnt} rows")

    # 2. dim_entity
    print("  Building dim_entity...")
    con.execute("DELETE FROM dim_entity")
    con.execute("""
        INSERT OR REPLACE INTO dim_entity
        SELECT
            s.muta AS entity_id,
            tf.segment,
            COALESCE(s.bolge_kodu, 0) AS bolge_kodu,
            s.sube_kodu,
            s.must_tip_kodu,
            s.grup_kodu,
            s.grup_tanimi,
            s.firma_otorize_kodu,
            s.aksiyon_sahibi,
            s.kri_bolum
        FROM (
            SELECT DISTINCT ON (muta) *
            FROM brz_statik
            ORDER BY muta
        ) s
        LEFT JOIN (
            SELECT DISTINCT ON (muta) muta, segment
            FROM brz_train_features
            ORDER BY muta, donem DESC
        ) tf ON s.muta = tf.muta
    """)
    con.execute("""
        INSERT OR IGNORE INTO dim_entity (entity_id)
        SELECT DISTINCT muta FROM brz_yis_tahmin
        WHERE muta NOT IN (SELECT entity_id FROM dim_entity)
    """)
    con.execute("""
        INSERT OR IGNORE INTO dim_entity (entity_id)
        SELECT DISTINCT muta FROM brz_eus_tahmin
        WHERE muta NOT IN (SELECT entity_id FROM dim_entity)
    """)
    cnt = con.execute("SELECT COUNT(*) FROM dim_entity").fetchone()[0]
    print(f"    dim_entity: {cnt} rows")

    # 3. map_identity
    print("  Building map_identity...")
    con.execute("DELETE FROM map_identity")
    con.execute("""
        INSERT OR REPLACE INTO map_identity
        SELECT
            de.entity_id,
            de.entity_id AS muta,
            u.unvan
        FROM dim_entity de
        LEFT JOIN (
            SELECT DISTINCT ON (muta) muta, unvan
            FROM brz_kik_izleme
            WHERE unvan IS NOT NULL AND TRIM(unvan) != '' AND unvan != 'None'
            ORDER BY muta, donem DESC
        ) u ON de.entity_id = u.muta
    """)
    cnt = con.execute("SELECT COUNT(*) FROM map_identity").fetchone()[0]
    print(f"    map_identity: {cnt} rows")

    # 4. fact_periodic
    print("  Building fact_periodic...")
    con.execute("DELETE FROM fact_periodic")

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _all_ed AS
        SELECT DISTINCT muta AS entity_id, donem FROM brz_yis_tahmin
        UNION
        SELECT DISTINCT muta, donem FROM brz_eus_tahmin
        UNION
        SELECT DISTINCT muta, donem FROM brz_kredi_risk
        UNION
        SELECT DISTINCT muta, donem FROM brz_kik_izleme
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _yis AS
        SELECT DISTINCT ON (muta, donem)
            muta, donem, yis_skor, yis_ihtimal, yis_label
        FROM brz_yis_tahmin ORDER BY muta, donem
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _eus AS
        SELECT DISTINCT ON (muta, donem)
            muta, donem, eus_skor, eus_ihtimal,
            CASE WHEN eus_skor >= 650 THEN 1 ELSE 0 END AS eus_tahmin_label
        FROM brz_eus_tahmin ORDER BY muta, donem
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _eus_kapsam AS
        SELECT DISTINCT muta, donem, 1 AS eus_kapsam FROM brz_eus_kapsam
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _eus_hedef AS
        SELECT DISTINCT muta, donem, 1 AS eus_hedef FROM brz_eus_hedef
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _risk AS
        WITH risk_raw AS (
            SELECT
                COALESCE(kr.muta, ki.muta) AS muta,
                COALESCE(kr.donem, ki.donem) AS donem,
                kr.kredi_risk,
                ki.kik_risk,
                COALESCE(kr.kredi_risk, ki.kik_risk) AS kombine_risk
            FROM (SELECT DISTINCT ON (muta, donem) * FROM brz_kredi_risk ORDER BY muta, donem) kr
            FULL OUTER JOIN (
                SELECT DISTINCT ON (muta, donem) muta, donem, kik_risk
                FROM brz_kik_izleme WHERE kik_risk IS NOT NULL
                ORDER BY muta, donem
            ) ki ON kr.muta = ki.muta AND kr.donem = ki.donem
        ),
        risk_with_lag AS (
            SELECT *,
                LAG(kombine_risk) OVER (PARTITION BY muta ORDER BY donem) AS _prev
            FROM risk_raw
        )
        SELECT muta, donem, kredi_risk, kik_risk, kombine_risk,
               CAST(kombine_risk - _prev AS BIGINT) AS risk_degisim
        FROM risk_with_lag
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _yi AS
        SELECT DISTINCT ON (muta, donem)
            muta, donem,
            CAST(CASE WHEN ykn_izl_flag IN ('1','1.0','True','true') THEN 1 ELSE 0 END AS INTEGER) AS ykn_izl_flag
        FROM brz_kik_izleme ORDER BY muta, donem
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _rating AS
        SELECT DISTINCT ON (muta, donem)
            muta, donem, tfrs_rating, rating_tarihi
        FROM brz_kik_izleme
        WHERE tfrs_rating IS NOT NULL AND TRIM(tfrs_rating) != '' AND tfrs_rating != 'None'
        ORDER BY muta, donem, rating_tarihi DESC
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _ews AS
        SELECT
            ad.entity_id, ad.donem,
            CASE
                WHEN COALESCE(y.yis_label, 0) = 1 OR COALESCE(yi.ykn_izl_flag, 0) = 1
                    THEN 'YI'
                WHEN e.eus_skor IS NOT NULL
                    THEN CAST(CAST(ROUND(e.eus_skor / 2) AS INTEGER) AS VARCHAR)
                WHEN y.yis_skor IS NOT NULL
                    THEN CAST(CAST(ROUND(CAST(y.yis_skor AS DOUBLE) / 2) + 500 AS INTEGER) AS VARCHAR)
                ELSE NULL
            END AS ews_skor,
            CASE
                WHEN COALESCE(y.yis_label, 0) = 1 OR COALESCE(yi.ykn_izl_flag, 0) = 1 THEN 'yi'
                WHEN e.eus_skor IS NOT NULL THEN 'eus'
                WHEN y.yis_skor IS NOT NULL THEN 'yis'
                ELSE NULL
            END AS ews_kaynak
        FROM _all_ed ad
        LEFT JOIN _yis y ON ad.entity_id = y.muta AND ad.donem = y.donem
        LEFT JOIN _yi yi ON ad.entity_id = yi.muta AND ad.donem = yi.donem
        LEFT JOIN _eus e ON ad.entity_id = e.muta AND ad.donem = e.donem
    """)

    con.execute("""
        INSERT INTO fact_periodic
        SELECT
            ad.entity_id, ad.donem,
            y.yis_skor, y.yis_ihtimal, y.yis_label,
            e.eus_skor, e.eus_ihtimal, e.eus_tahmin_label,
            COALESCE(ek.eus_kapsam, 0),
            COALESCE(eh.eus_hedef, 0),
            ews.ews_skor, ews.ews_kaynak,
            COALESCE(yi.ykn_izl_flag, 0),
            r.kombine_risk, r.kredi_risk, r.kik_risk, r.risk_degisim,
            rt.tfrs_rating, rt.rating_tarihi
        FROM _all_ed ad
        LEFT JOIN _yis y ON ad.entity_id = y.muta AND ad.donem = y.donem
        LEFT JOIN _eus e ON ad.entity_id = e.muta AND ad.donem = e.donem
        LEFT JOIN _eus_kapsam ek ON ad.entity_id = ek.muta AND ad.donem = ek.donem
        LEFT JOIN _eus_hedef eh ON ad.entity_id = eh.muta AND ad.donem = eh.donem
        LEFT JOIN _risk r ON ad.entity_id = r.muta AND ad.donem = r.donem
        LEFT JOIN _yi yi ON ad.entity_id = yi.muta AND ad.donem = yi.donem
        LEFT JOIN _rating rt ON ad.entity_id = rt.muta AND ad.donem = rt.donem
        LEFT JOIN _ews ews ON ad.entity_id = ews.entity_id AND ad.donem = ews.donem
    """)

    cnt = con.execute("SELECT COUNT(*) FROM fact_periodic").fetchone()[0]
    n_ent = con.execute("SELECT COUNT(DISTINCT entity_id) FROM fact_periodic").fetchone()[0]
    n_per = con.execute("SELECT COUNT(DISTINCT donem) FROM fact_periodic").fetchone()[0]
    print(f"    fact_periodic: {cnt} rows ({n_ent} entities × {n_per} periods)")

    for t in ["_all_ed", "_yis", "_eus", "_eus_kapsam", "_eus_hedef", "_risk", "_yi", "_rating", "_ews"]:
        con.execute(f"DROP TABLE IF EXISTS {t}")

    con.close()
