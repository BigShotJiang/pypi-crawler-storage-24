"""
Ingest: source files → DuckDB bronze tables.

Handles cp1254 decoding, dynamic column matching, MUTA normalization.
"""

import re
from pathlib import Path

import duckdb
import pandas as pd
import numpy as np

from ews_scoreboard.paths import get_ddl_path


def _normalize_muta(series: pd.Series) -> pd.Series:
    """MUTA normalize: str → numeric → int → str, drop NaN."""
    cleaned = series.astype(str).str.strip()
    cleaned = cleaned.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "NaN": pd.NA, "<NA>": pd.NA})
    s = pd.to_numeric(cleaned, errors="coerce")
    return s.dropna().astype(int).astype(str)


def _clean_str_col(series: pd.Series) -> pd.Series:
    """Clean string column: strip whitespace, convert empty/nan/None → proper NaN."""
    s = series.astype(str).str.strip()
    s = s.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "NaN": pd.NA, "<NA>": pd.NA, "NaT": pd.NA})
    return s


def _find_skor_col(columns, prefix=""):
    """Find score column dynamically (may be 'skor', 'yis_skor', 'eus_skor', etc)."""
    for c in columns:
        if "skor" in c.lower():
            return c
    return None


def _find_ihtimal_col(columns):
    for c in columns:
        if "ihtimal" in c.lower():
            return c
    return None


def _execute_sql_file(con, sql_path: Path):
    """Execute a SQL file, splitting on semicolons and stripping comments."""
    text = sql_path.read_text(encoding="utf-8")
    lines = [l for l in text.split("\n") if not l.strip().startswith("--")]
    clean = "\n".join(lines)
    for stmt in clean.split(";"):
        stmt = stmt.strip()
        if stmt:
            try:
                con.execute(stmt)
            except Exception:
                pass  # table/index already exists


def _create_bronze_tables(con):
    """Create all tables from DDL files."""
    ddl_dir = get_ddl_path()
    for sql_file in sorted(ddl_dir.glob("*.sql")):
        _execute_sql_file(con, sql_file)


def _ingest_kik_izleme(con, kik_dir: Path):
    """Ingest KIK İzleme Kriterleri CSV files → brz_kik_izleme."""
    if not kik_dir.exists():
        print("  [SKIP] kik_data_ham_csv not found")
        return

    unvan_candidates = ["Must Ad", "Cari Hesap Adı", "Cari Hesap Adi", "UNVAN", "Unvan"]
    total = 0

    for fpath in sorted(kik_dir.glob("*.csv")):
        fname = fpath.name
        if "Kurumsal" not in fname:
            continue

        m = re.search(r"20(\d{4})02", fname)
        if not m:
            continue
        donem = m.group(1)

        try:
            df = pd.read_csv(fpath, sep=";", encoding="cp1254", dtype=str)
        except Exception:
            df = pd.read_csv(fpath, sep=None, engine="python", encoding="cp1254", dtype=str)

        if "Must No" not in df.columns:
            continue

        df["muta"] = _normalize_muta(df["Must No"])
        df = df[df["muta"].notna()].copy()
        df["donem"] = donem

        unvan_col = None
        for uc in unvan_candidates:
            if uc in df.columns:
                unvan_col = uc
                break
        df["unvan"] = _clean_str_col(df[unvan_col]) if unvan_col else None

        df["ykn_izl_flag"] = _clean_str_col(df.get("Ykn Izl Flag", pd.Series(dtype=str)))
        df["tfrs_rating"] = _clean_str_col(df.get("Rtng Kod", pd.Series(dtype=str)))
        df["rating_tarihi"] = _clean_str_col(df.get("Rating Tar", pd.Series(dtype=str)))

        risk_raw = df.get("Risk Bky Tl", pd.Series(dtype=str))
        if risk_raw is not None and len(risk_raw) > 0:
            risk_clean = risk_raw.astype(str).str.replace(".", "", regex=False).str.replace(",", ".", regex=False)
            df["kik_risk"] = pd.to_numeric(risk_clean, errors="coerce").round(0).astype("Int64")
        else:
            df["kik_risk"] = pd.array([pd.NA] * len(df), dtype="Int64")

        out = df[["muta", "donem", "ykn_izl_flag", "tfrs_rating", "rating_tarihi", "kik_risk", "unvan"]].copy()
        con.execute("INSERT INTO brz_kik_izleme SELECT * FROM out")
        total += len(out)

    print(f"  brz_kik_izleme: {total} rows")


def _ingest_kredi_risk(con, kredi_dir: Path):
    """Ingest kredi risk parquet → brz_kredi_risk."""
    if not kredi_dir.exists():
        print("  [SKIP] kredi_db not found")
        return

    total = 0
    for fpath in sorted(kredi_dir.glob("kurumsal_risk_*.parquet")):
        donem = fpath.stem.replace("kurumsal_risk_", "")
        df = pd.read_parquet(fpath)
        df["muta"] = _normalize_muta(df["MUTA"])
        df = df[df["muta"].notna()].copy()
        df["donem"] = donem
        df["kredi_risk"] = pd.to_numeric(df["Risk_Bky_Tl"], errors="coerce")
        df["kredi_risk"] = df["kredi_risk"].where(df["kredi_risk"].notna()).round(0).astype("Int64")
        out = df[["muta", "donem", "kredi_risk"]].copy()
        con.execute("INSERT INTO brz_kredi_risk SELECT * FROM out")
        total += len(out)

    print(f"  brz_kredi_risk: {total} rows")


def _ingest_yis_tahmin(con, yis_dir: Path):
    """Ingest YIS prediction CSV → brz_yis_tahmin."""
    if not yis_dir.exists():
        print("  [SKIP] yis_tahmin_data not found")
        return

    total = 0
    for fpath in sorted(yis_dir.glob("*_pred_n_scor.csv")):
        parts = fpath.stem.split("_")
        donem = parts[0][2:] + parts[1]

        df = pd.read_csv(fpath, dtype={"MUTA": str})
        df["muta"] = df["MUTA"].astype(str).str.strip()
        df["donem"] = donem

        skor_col = _find_skor_col(df.columns)
        if skor_col:
            df["yis_skor"] = pd.to_numeric(df[skor_col], errors="coerce").round(0).astype("Int64")
        else:
            df["yis_skor"] = pd.array([pd.NA] * len(df), dtype="Int64")

        ihtimal_col = _find_ihtimal_col(df.columns)
        df["yis_ihtimal"] = pd.to_numeric(df[ihtimal_col], errors="coerce") if ihtimal_col else np.nan

        label_raw = df.get("label", pd.Series([0] * len(df)))
        df["yis_label"] = pd.to_numeric(label_raw, errors="coerce").fillna(0).astype(int)

        out = df[["muta", "donem", "yis_skor", "yis_ihtimal", "yis_label"]].copy()
        con.execute("INSERT INTO brz_yis_tahmin SELECT * FROM out")
        total += len(out)

    print(f"  brz_yis_tahmin: {total} rows")


def _ingest_eus_tahmin(con, eus_dir: Path):
    """Ingest EUS prediction CSV → brz_eus_tahmin."""
    if not eus_dir.exists():
        print("  [SKIP] eus_tahmin_data not found")
        return

    total = 0
    for fpath in sorted(eus_dir.glob("*_pred_n_scor.csv")):
        parts = fpath.stem.split("_")
        donem = parts[0][2:] + parts[1]

        df = pd.read_csv(fpath, dtype={"MUTA": str})
        df["muta"] = df["MUTA"].astype(str).str.strip()
        df["donem"] = donem

        skor_col = _find_skor_col(df.columns)
        df["eus_skor"] = pd.to_numeric(df[skor_col], errors="coerce").round(2) if skor_col else np.nan

        ihtimal_col = _find_ihtimal_col(df.columns)
        df["eus_ihtimal"] = pd.to_numeric(df[ihtimal_col], errors="coerce") if ihtimal_col else np.nan

        out = df[["muta", "donem", "eus_skor", "eus_ihtimal"]].copy()
        con.execute("INSERT INTO brz_eus_tahmin SELECT * FROM out")
        total += len(out)

    print(f"  brz_eus_tahmin: {total} rows")


def _ingest_eus_hedef(con, hedef_dir: Path):
    """Ingest EUS hedef MUTA lists → brz_eus_hedef."""
    if not hedef_dir.exists():
        print("  [SKIP] eus_hedef_muta not found")
        return

    total = 0
    for fpath in sorted(hedef_dir.glob("eus_hedef_MUTA_*.csv")):
        m = re.search(r"(\d{4})\.csv$", fpath.name)
        if not m:
            continue
        donem = m.group(1)

        df = pd.read_csv(fpath, dtype=str, header=0)
        if df.empty:
            continue
        col = df.columns[0]
        df["muta"] = df[col].astype(str).str.strip()
        df["donem"] = donem
        df = df[df["muta"].notna() & (df["muta"] != "") & (df["muta"] != "nan")]
        out = df[["muta", "donem"]].copy()
        if not out.empty:
            con.execute("INSERT INTO brz_eus_hedef SELECT * FROM out")
            total += len(out)

    print(f"  brz_eus_hedef: {total} rows")


def _ingest_eus_kapsam(con, kapsam_dir: Path):
    """Ingest EUS kapsam MUTA lists → brz_eus_kapsam."""
    if not kapsam_dir.exists():
        print("  [SKIP] eus_sql_kapsam_muta not found")
        return

    total = 0
    for fpath in sorted(kapsam_dir.glob("eus_kapsam_MUTA_*.csv")):
        m = re.search(r"(\d{4})\.csv$", fpath.name)
        if not m:
            continue
        donem = m.group(1)

        df = pd.read_csv(fpath, dtype=str, header=0)
        if df.empty:
            continue
        col = df.columns[0]
        df["muta"] = df[col].astype(str).str.strip()
        df["donem"] = donem
        df = df[df["muta"].notna() & (df["muta"] != "") & (df["muta"] != "nan")]
        out = df[["muta", "donem"]].copy()
        if not out.empty:
            con.execute("INSERT INTO brz_eus_kapsam SELECT * FROM out")
            total += len(out)

    print(f"  brz_eus_kapsam: {total} rows")


def _ingest_statik(con, statik_dir: Path):
    """Ingest statik bilgiler → brz_statik."""
    if not statik_dir.exists():
        print("  [SKIP] statik_db not found")
        return

    for fpath in sorted(statik_dir.glob("statik_bilgiler_*.txt")):
        df = pd.read_csv(fpath, sep=";", encoding="cp1254", dtype=str, header=0)

        cols = df.columns.tolist()
        rename_map = {}
        pos_names = ["muta", "bolge_kodu", "bolge_adi", "sube_kodu", "sube_adi",
                      "must_tip_kodu", "grup_kodu", "grup_tanimi",
                      "firma_otorize_kodu", "aksiyon_sahibi", "kri_bolum"]
        for i, name in enumerate(pos_names):
            if i < len(cols):
                rename_map[cols[i]] = name
        df = df.rename(columns=rename_map)

        df["muta"] = _normalize_muta(df["muta"])
        df = df[df["muta"].notna()].copy()
        df = df.drop_duplicates(subset=["muta"])

        if "bolge_kodu" in df.columns:
            df["bolge_kodu"] = df["bolge_kodu"].astype(str).str.split(",").str[0]
            df["bolge_kodu"] = pd.to_numeric(df["bolge_kodu"], errors="coerce").astype("Int64")
        if "sube_kodu" in df.columns:
            df["sube_kodu"] = pd.to_numeric(df["sube_kodu"], errors="coerce").astype("Int64")

        out = df[pos_names].copy()
        con.execute("INSERT INTO brz_statik SELECT * FROM out")
        print(f"  brz_statik: {len(out)} rows")
        return


def _ingest_train_features(con, train_dir: Path):
    """Ingest training parquet → brz_train_features (segment extraction)."""
    if not train_dir.exists():
        print("  [SKIP] yis_train_data not found")
        return

    SGMNT_MAP = {
        "Sgmnt_Kod_ESKK": "ESKK",
        "Sgmnt_Kod_KOBI": "KOBI",
        "Sgmnt_Kod_KUR-TIC": "KUR-TIC",
        "Sgmnt_Kod_MIKRO": "MIKRO",
    }

    files = sorted(train_dir.glob("yis_21_v21_*.parquet"))
    if not files:
        print("  [SKIP] no training parquets")
        return

    last_file = files[-1]
    m = re.search(r"_(\d{4})\.parquet$", last_file.name)
    donem = m.group(1) if m else "0000"

    df = pd.read_parquet(last_file)
    df["muta"] = df["MUTA"].astype(str).str.strip()

    sgmnt_cols = [c for c in df.columns if c.startswith("Sgmnt_Kod_")]

    def get_segment(row):
        for col in sgmnt_cols:
            val = row.get(col)
            if val in (True, 1, "True", "1", "1.0"):
                return SGMNT_MAP.get(col, col)
        return None

    df["segment"] = df.apply(get_segment, axis=1) if sgmnt_cols else None
    df["donem"] = donem

    out = df[["muta", "donem", "segment"]].copy()
    con.execute("INSERT INTO brz_train_features SELECT * FROM out")
    print(f"  brz_train_features: {len(out)} rows (from {last_file.name})")


def _resolve_dir(source_dir: Path, subdir: str, data_paths: dict) -> Path:
    """Resolve a data directory: use data_paths override if present, else source_dir/subdir."""
    if subdir in data_paths:
        return Path(data_paths[subdir])
    return source_dir / subdir


def run_ingest(source_dir: Path, db_path: Path, data_paths: dict = None):
    """Run full ingest pipeline.

    Args:
        source_dir: Default base directory for data subdirs.
        db_path: Path to DuckDB database file.
        data_paths: Optional dict mapping subdir names to actual paths,
                    e.g. {"kredi_db": "/mnt/z/ai/kredi", "statik_db": "/mnt/z/statik"}.
                    Keys not present fall back to source_dir/subdir.
    """
    if data_paths is None:
        data_paths = {}

    if db_path.exists():
        db_path.unlink()

    con = duckdb.connect(str(db_path))
    _create_bronze_tables(con)

    dp = data_paths
    sd = source_dir
    _ingest_kik_izleme(con,      _resolve_dir(sd, "kik_data_ham_csv", dp))
    _ingest_kredi_risk(con,      _resolve_dir(sd, "kredi_db", dp))
    _ingest_yis_tahmin(con,      _resolve_dir(sd, "yis_tahmin_data", dp))
    _ingest_eus_tahmin(con,      _resolve_dir(sd, "eus_tahmin_data", dp))
    _ingest_eus_hedef(con,       _resolve_dir(sd, "eus_hedef_muta", dp))
    _ingest_eus_kapsam(con,      _resolve_dir(sd, "eus_sql_kapsam_muta", dp))
    _ingest_statik(con,          _resolve_dir(sd, "statik_db", dp))
    _ingest_train_features(con,  _resolve_dir(sd, "yis_train_data", dp))

    tables = con.execute("SHOW TABLES").fetchall()
    print(f"\n  Bronze tables: {len(tables)}")
    for (t,) in tables:
        cnt = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        if cnt > 0:
            print(f"    {t}: {cnt}")

    con.close()
