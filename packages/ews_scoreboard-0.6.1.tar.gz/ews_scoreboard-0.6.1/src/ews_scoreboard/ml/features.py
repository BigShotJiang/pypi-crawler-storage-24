"""
Feature engineering for YI prediction model.

Input: fact_periodic table (entity_id × donem)
Output: feature matrix with rolling EWS stats, risk deltas, flag history.

Features (per entity×donem):
  - ews_score: current EWS numeric (YI→1000, null→NaN)
  - ews_lag_{1,2,3}: previous period scores
  - ews_delta_1: score change vs 1 period ago
  - ews_delta_3: score change vs 3 periods ago
  - ews_max_3: max score in last 3 periods
  - ews_mean_3: mean score in last 3 periods
  - ews_std_3: std of scores in last 3 periods
  - ews_consec_rise: consecutive rising periods
  - ews_above_825_count: how many of last 4 periods >= 825
  - ews_above_500_count: how many of last 4 periods >= 500
  - ews_band: 0=EUS(<500), 1=YIS(500-824), 2=HIGH(825+), 3=YI
  - risk_current: kombine_risk (TL)
  - risk_delta_1: risk change vs 1 period ago
  - risk_delta_pct: risk change % vs 1 period ago
  - risk_mio: risk in milyon TL
  - yi_flag_current: ykn_izl_flag this period
  - yi_flag_prev: ykn_izl_flag previous period
  - yi_flag_count_4: number of YI flags in last 4 periods
  - was_yi_prev: was ews_skor='YI' previous period
  - segment_*: one-hot encoded segment (ESKK, KOBI, KUR-TIC, MIKRO)
  - bolge_kodu: numeric bölge code
"""

import duckdb
import pandas as pd
import numpy as np
from pathlib import Path


def _ews_numeric(val):
    """Convert ews_skor to numeric. YI→1000, null/nan→NaN."""
    if val is None or str(val) in ("None", "<NA>", "nan", ""):
        return np.nan
    if str(val) == "YI":
        return 1000.0
    try:
        return float(val)
    except (ValueError, TypeError):
        return np.nan


def build_features(db_path: Path, target_horizon: int = 3) -> pd.DataFrame:
    """Build feature matrix from fact_periodic.

    Args:
        db_path: Path to DuckDB file.
        target_horizon: Number of future periods to check for YI (default 3).

    Returns:
        DataFrame with features + label column.
        Each row = one (entity_id, donem) observation.
    """
    con = duckdb.connect(str(db_path), read_only=True)

    # Load fact_periodic
    fp = con.execute("""
        SELECT
            fp.entity_id, fp.donem,
            fp.ews_skor, fp.ews_kaynak,
            fp.kombine_risk, fp.risk_degisim,
            fp.ykn_izl_flag,
            de.segment, de.bolge_kodu
        FROM fact_periodic fp
        LEFT JOIN dim_entity de ON fp.entity_id = de.entity_id
        ORDER BY fp.entity_id, fp.donem
    """).fetchdf()
    con.close()

    if fp.empty:
        return pd.DataFrame()

    # Convert ews_skor to numeric
    fp["ews_num"] = fp["ews_skor"].apply(_ews_numeric)

    # Sort
    fp = fp.sort_values(["entity_id", "donem"]).reset_index(drop=True)

    # Get sorted unique periods
    all_donemler = sorted(fp["donem"].unique())
    donem_rank = {d: i for i, d in enumerate(all_donemler)}
    fp["donem_rank"] = fp["donem"].map(donem_rank)

    # Group by entity
    rows = []
    for eid, grp in fp.groupby("entity_id"):
        grp = grp.sort_values("donem_rank").reset_index(drop=True)
        scores = grp["ews_num"].values
        risks = grp["kombine_risk"].values.astype(float)
        yi_flags = grp["ykn_izl_flag"].values
        donem_ranks = grp["donem_rank"].values

        for idx in range(len(grp)):
            r = grp.iloc[idx]
            s = scores[idx]

            # Lags
            s_lag1 = scores[idx - 1] if idx >= 1 else np.nan
            s_lag2 = scores[idx - 2] if idx >= 2 else np.nan
            s_lag3 = scores[idx - 3] if idx >= 3 else np.nan

            # Deltas
            delta_1 = s - s_lag1 if not (np.isnan(s) or np.isnan(s_lag1)) else np.nan
            delta_3 = s - s_lag3 if not (np.isnan(s) or np.isnan(s_lag3)) else np.nan

            # Rolling stats (last 3 incl current)
            window = scores[max(0, idx - 2):idx + 1]
            valid = window[~np.isnan(window)]
            ews_max_3 = float(np.max(valid)) if len(valid) > 0 else np.nan
            ews_mean_3 = float(np.mean(valid)) if len(valid) > 0 else np.nan
            ews_std_3 = float(np.std(valid)) if len(valid) > 1 else 0.0

            # Consecutive rise
            consec = 0
            for j in range(idx, 0, -1):
                if not np.isnan(scores[j]) and not np.isnan(scores[j - 1]) and scores[j] > scores[j - 1]:
                    consec += 1
                else:
                    break

            # Count thresholds in last 4
            window4 = scores[max(0, idx - 3):idx + 1]
            valid4 = window4[~np.isnan(window4)]
            above_825 = int(np.sum(valid4 >= 825))
            above_500 = int(np.sum(valid4 >= 500))

            # Band
            if np.isnan(s):
                band = -1
            elif s >= 1000:
                band = 3  # YI
            elif s >= 825:
                band = 2  # HIGH
            elif s >= 500:
                band = 1  # YIS
            else:
                band = 0  # EUS

            # Risk
            risk_cur = risks[idx] if not np.isnan(risks[idx]) else 0.0
            risk_prev = risks[idx - 1] if idx >= 1 and not np.isnan(risks[idx - 1]) else risk_cur
            risk_delta = risk_cur - risk_prev
            risk_delta_pct = (risk_delta / risk_prev) if risk_prev != 0 else 0.0

            # YI flags
            yi_cur = int(yi_flags[idx]) if str(yi_flags[idx]) in ("1", "1.0") else 0
            yi_prev = int(yi_flags[idx - 1]) if idx >= 1 and str(yi_flags[idx - 1]) in ("1", "1.0") else 0
            yi_count = sum(1 for j in range(max(0, idx - 3), idx + 1)
                          if str(yi_flags[j]) in ("1", "1.0"))

            was_yi_prev = 1 if idx >= 1 and str(grp.iloc[idx - 1]["ews_skor"]) == "YI" else 0

            # Segment one-hot
            seg = r["segment"] if r["segment"] and str(r["segment"]) not in ("None", "<NA>", "nan") else None

            # ── Label: YI in next 1..target_horizon periods ──
            label = 0
            current_rank = donem_ranks[idx]
            future_mask = (grp["donem_rank"] > current_rank) & (grp["donem_rank"] <= current_rank + target_horizon)
            future = grp[future_mask]
            if not future.empty:
                if (future["ews_skor"] == "YI").any():
                    label = 1
            else:
                label = np.nan  # no future data → can't label

            rows.append({
                "entity_id": eid,
                "donem": r["donem"],
                "ews_score": s,
                "ews_lag_1": s_lag1,
                "ews_lag_2": s_lag2,
                "ews_lag_3": s_lag3,
                "ews_delta_1": delta_1,
                "ews_delta_3": delta_3,
                "ews_max_3": ews_max_3,
                "ews_mean_3": ews_mean_3,
                "ews_std_3": ews_std_3,
                "ews_consec_rise": consec,
                "ews_above_825_count": above_825,
                "ews_above_500_count": above_500,
                "ews_band": band,
                "risk_current": risk_cur,
                "risk_delta_1": risk_delta,
                "risk_delta_pct": risk_delta_pct,
                "risk_mio": risk_cur / 1_000_000,
                "yi_flag_current": yi_cur,
                "yi_flag_prev": yi_prev,
                "yi_flag_count_4": yi_count,
                "was_yi_prev": was_yi_prev,
                "seg_ESKK": 1 if seg == "ESKK" else 0,
                "seg_KOBI": 1 if seg == "KOBI" else 0,
                "seg_KUR_TIC": 1 if seg == "KUR-TIC" else 0,
                "seg_MIKRO": 1 if seg == "MIKRO" else 0,
                "bolge_kodu": int(r["bolge_kodu"]) if r["bolge_kodu"] and str(r["bolge_kodu"]) not in ("None", "<NA>", "nan") else 0,
                "label": label,
            })

    df = pd.DataFrame(rows)
    print(f"  Features: {len(df)} rows, {df['entity_id'].nunique()} entities, "
          f"{df['donem'].nunique()} periods")
    if "label" in df.columns:
        labeled = df.dropna(subset=["label"])
        print(f"  Labeled: {len(labeled)} rows (YI={int(labeled['label'].sum())}, "
              f"non-YI={int((labeled['label'] == 0).sum())})")
    return df


# Feature columns used by the model (excludes entity_id, donem, label)
FEATURE_COLS = [
    "ews_score", "ews_lag_1", "ews_lag_2", "ews_lag_3",
    "ews_delta_1", "ews_delta_3",
    "ews_max_3", "ews_mean_3", "ews_std_3",
    "ews_consec_rise", "ews_above_825_count", "ews_above_500_count", "ews_band",
    "risk_current", "risk_delta_1", "risk_delta_pct", "risk_mio",
    "yi_flag_current", "yi_flag_prev", "yi_flag_count_4", "was_yi_prev",
    "seg_ESKK", "seg_KOBI", "seg_KUR_TIC", "seg_MIKRO",
    "bolge_kodu",
]

# Human-readable feature names for SHAP explanations
FEATURE_LABELS = {
    "ews_score": "Mevcut EWS skoru",
    "ews_lag_1": "Önceki dönem skoru",
    "ews_lag_2": "2 dönem önceki skor",
    "ews_lag_3": "3 dönem önceki skor",
    "ews_delta_1": "Son dönem skor değişimi",
    "ews_delta_3": "Son 3 dönem skor değişimi",
    "ews_max_3": "Son 3 dönem maks skor",
    "ews_mean_3": "Son 3 dönem ort skor",
    "ews_std_3": "Son 3 dönem skor dalgalanması",
    "ews_consec_rise": "Ardışık yükseliş dönem sayısı",
    "ews_above_825_count": "Son 4 dönemde 825+ olan dönem sayısı",
    "ews_above_500_count": "Son 4 dönemde 500+ olan dönem sayısı",
    "ews_band": "EWS bandı",
    "risk_current": "Mevcut risk (TL)",
    "risk_delta_1": "Risk değişimi (TL)",
    "risk_delta_pct": "Risk değişimi (%)",
    "risk_mio": "Risk (milyon TL)",
    "yi_flag_current": "Mevcut YI flag",
    "yi_flag_prev": "Önceki dönem YI flag",
    "yi_flag_count_4": "Son 4 dönemde YI flag sayısı",
    "was_yi_prev": "Önceki dönem YI miydi",
    "seg_ESKK": "Segment: ESKK",
    "seg_KOBI": "Segment: KOBİ",
    "seg_KUR_TIC": "Segment: Kurumsal-Ticari",
    "seg_MIKRO": "Segment: Mikro",
    "bolge_kodu": "Bölge kodu",
}
