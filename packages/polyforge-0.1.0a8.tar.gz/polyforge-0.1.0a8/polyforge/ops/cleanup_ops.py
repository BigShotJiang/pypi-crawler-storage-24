from __future__ import annotations

from dataclasses import dataclass

from shapely.geometry import MultiPolygon, Polygon
from shapely.geometry.base import BaseGeometry

from ..core.geometry_utils import hole_shape_metrics, remove_holes


@dataclass
class CleanupConfig:
    """Describes which cleanup operations should run."""

    min_zero_area: float = 1e-10
    hole_area_threshold: float | None = None
    hole_aspect_ratio: float | None = None
    hole_min_width: float | None = None
    preserve_holes: bool = True


def remove_small_holes(
    geometry: Polygon | MultiPolygon,
    min_area: float,
) -> Polygon | MultiPolygon:
    """Remove holes whose area is below the threshold."""
    if not isinstance(geometry, (Polygon, MultiPolygon)):
        raise TypeError("Input geometry must be a Polygon or MultiPolygon.")
    if isinstance(geometry, Polygon):
        return _strip_holes_from_polygon(geometry, min_area)
    if isinstance(geometry, MultiPolygon):
        return MultiPolygon(
            [_strip_holes_from_polygon(poly, min_area) for poly in geometry.geoms]
        )
    return geometry


def remove_narrow_holes(
    geometry: Polygon | MultiPolygon,
    max_aspect_ratio: float = 50.0,
    min_width: float | None = None,
) -> Polygon | MultiPolygon:
    """Remove holes that exceed aspect-ratio or width constraints."""
    if not isinstance(geometry, (Polygon, MultiPolygon)):
        raise TypeError("Input geometry must be a Polygon or MultiPolygon.")
    if isinstance(geometry, Polygon):
        return _filter_holes_by_shape(geometry, max_aspect_ratio, min_width)
    if isinstance(geometry, MultiPolygon):
        return MultiPolygon(
            [
                _filter_holes_by_shape(poly, max_aspect_ratio, min_width)
                for poly in geometry.geoms
            ]
        )
    return geometry


def cleanup_polygon(
    geometry: Polygon | MultiPolygon,
    config: CleanupConfig,
) -> Polygon | MultiPolygon:
    """Apply the requested cleanup operations to the geometry."""
    result: Polygon | MultiPolygon = geometry
    result = remove_small_holes(result, min_area=config.min_zero_area)

    if config.hole_area_threshold and config.hole_area_threshold > 0:
        result = remove_small_holes(result, min_area=config.hole_area_threshold)

    if config.hole_aspect_ratio or (
        config.hole_min_width is not None and config.hole_min_width > 0
    ):
        result = remove_narrow_holes(
            result,
            max_aspect_ratio=config.hole_aspect_ratio or 50.0,
            min_width=config.hole_min_width,
        )

    if not config.preserve_holes:
        result = remove_holes(result, preserve_holes=False)

    return result


def _strip_holes_from_polygon(polygon: Polygon, min_area: float) -> Polygon:
    if min_area <= 0:
        return polygon
    valid_holes = [hole for hole in polygon.interiors if Polygon(hole).area >= min_area]
    return Polygon(polygon.exterior, holes=[list(h.coords) for h in valid_holes])


def _filter_holes_by_shape(
    polygon: Polygon,
    max_aspect_ratio: float,
    min_width: float | None,
) -> Polygon:
    holes = []
    for interior in polygon.interiors:
        hole_poly = Polygon(interior)
        try:
            aspect, width = hole_shape_metrics(hole_poly)
        except Exception:
            continue
        if aspect > max_aspect_ratio:
            continue
        if min_width is not None and width < min_width:
            continue
        holes.append(list(interior.coords))
    return Polygon(polygon.exterior, holes=holes)


__all__ = [
    "CleanupConfig",
    "cleanup_polygon",
    "remove_small_holes",
    "remove_narrow_holes",
]
