---
layout: default
title: Overview
nav_order: 1
---

# rimpack

`rimpack` is a CLI-first RimWorld modpack tool built around plain files instead of opaque app
state.

## What It Does

`rimpack` helps you:

- create a modpack project directory
- keep authored mod intent in ordered `.list` files
- validate resolution, activation, dependencies, incompatibilities, and ordering
- build a launchable runtime tree without rewriting the real RimWorld install
- manage Steam Workshop subscriptions for the mods your pack needs

## Core Model

The project is organized around a few small file types:

- `pack.toml`: root manifest for the pack
- `mods/*.list`: authored mod references in pack order
- `rules/ordering/*.toml`: optional load-order constraints
- `rules/activation/*.toml`: optional activation conditions
- `generated/*`: diagnostics and resolved outputs that can be regenerated

This is the intended pipeline:

1. Read `pack.toml`.
2. Load `.list` files in `layout.mod_files` order.
3. Resolve enabled entries to canonical mods.
4. Evaluate activation rules.
5. Apply ordering rules.
6. Write generated outputs.
7. Launch RimWorld from a symlinked runtime tree.

## Current CLI Surface

The current command set includes:

- `rimpack init`
- `rimpack load-mods`
- `rimpack add`
- `rimpack add-ordering-rule`
- `rimpack validate`
- `rimpack launch`
- `rimpack subscribe`
- `rimpack unsubscribe`
- `rimpack resolve steam`

Activation rules are part of the supported project format, but they are authored directly in TOML
today rather than through a dedicated CLI command.

## Start Here

- [Getting Started](./getting-started)
- [CLI Reference](./cli)
- [Modpack Format](./modpack-format)
- [Configuration](./configuration)
