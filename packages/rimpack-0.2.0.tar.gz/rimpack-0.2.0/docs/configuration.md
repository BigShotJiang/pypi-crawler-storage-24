---
layout: default
title: Configuration
nav_order: 5
---

# Configuration

## User-Local Config

`rimpack` stores machine-local defaults outside the modpack project using a TOML config file.

Current keys:

```toml
rimworld_folder = "D:/SteamLibrary/steamapps/common/RimWorld"
steam_workshop_folder = "D:/SteamLibrary/steamapps/workshop/content/294100"
```

These are absolute paths and should not be committed into a modpack repository.

## What Belongs There

Use the user-local config for:

- the RimWorld install directory
- the Steam Workshop content directory

Do not use it for:

- pack-authored project state
- runtime tree locations committed with the pack
- generated diagnostics
- UI state

## Environment Variables

Environment variables can override automatic discovery when the config file is missing or
incomplete.

Current environment variable names:

- `RIMWORLD_FOLDER`
- `STEAM_WORKSHOP_FOLDER`

## Runtime Model

Launching does not mutate the real RimWorld install in place.

Instead, `rimpack` builds a machine-local runtime view that:

- starts from the real RimWorld install
- replaces the runtime `Mods/` tree with symlinks for the active load order
- uses a pack-specific machine-local save/config root
- regenerates `ModsConfig.xml` for that runtime

That runtime state is outside the pack project by default.
