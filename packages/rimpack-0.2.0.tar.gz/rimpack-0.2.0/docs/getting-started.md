---
layout: default
title: Getting Started
nav_order: 2
---

# Getting Started

## Requirements

- Python 3.12 or newer
- [`uv`](https://docs.astral.sh/uv/)
- RimWorld installed locally
- Steam installed locally if you want Workshop resolution and subscription features

## Install The Project

From the repository root:

```powershell
uv sync --dev
uv run rimpack --help
```

## First-Run Configuration

Running `rimpack` with no command prompts to create a user-local config file. That file stores
machine-specific absolute paths and is not part of a modpack project.

The current config fields are:

- `rimworld_folder`
- `steam_workshop_folder`

You can also supply those paths through environment variables:

- `RIMWORLD_FOLDER`
- `STEAM_WORKSHOP_FOLDER`

## Create A New Pack

```powershell
uv run rimpack init .\MyPack
```

That creates a project with this initial shape:

```text
MyPack/
  pack.toml
  README.md
  mods/
    00_core.list
    10_libraries.list
    20_ui.list
    30_gameplay.list
    40_qol.list
    50_overhaul.list
    60_factions.list
    70_combat.list
    80_graphics.list
    90_textures.list
    99_patch.list
  config/
    Mod_Configs/
  generated/
  local/
    mods/
```

The default `00_core.list` contains the core game package ID and any detected official DLC
package IDs from the local RimWorld install.

## Add Mods

Add a Workshop mod to a declared alias:

```powershell
uv run rimpack add @libraries steam:2009463077
```

You can also target a concrete list path:

```powershell
uv run rimpack add mods/20_ui.list packageid:brrainz.harmony
```

Supported add references:

- `steam:<workshop_id>`
- a Steam Workshop `sharedfiles` URL
- `packageid:<package_id>`
- `local:<folder_name>`

If the target alias or list path does not exist yet, `rimpack add` creates and registers it.

## Validate Before Launch

```powershell
uv run rimpack validate
```

Validation reports:

- unresolved entries
- missing dependencies
- incompatible active mods
- activation-rule issues
- load-order cycles

## Launch The Pack

```powershell
uv run rimpack launch
```

Launching:

1. resolves the current pack
2. subscribes required Workshop items
3. builds a symlinked runtime tree
4. generates `ModsConfig.xml` for the pack-specific runtime config
5. starts RimWorld against that machine-local runtime view

Use `--no-clean` if you do not want post-run unsubscribe cleanup for undeclared Workshop items.
