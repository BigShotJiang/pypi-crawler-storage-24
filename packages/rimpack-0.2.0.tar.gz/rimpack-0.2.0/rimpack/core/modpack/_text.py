from __future__ import annotations


def split_lines_with_endings(text: str) -> tuple[tuple[str, str], ...]:
    lines: list[tuple[str, str]] = []
    for line in text.splitlines(keepends=True):
        if line.endswith("\r\n"):
            lines.append((line[:-2], "\r\n"))
        elif line.endswith("\n") or line.endswith("\r"):
            lines.append((line[:-1], line[-1]))
        else:
            lines.append((line, ""))
    if text == "":
        return ()
    if not lines and text:
        return ((text, ""),)
    return tuple(lines)
