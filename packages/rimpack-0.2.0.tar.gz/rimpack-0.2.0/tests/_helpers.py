from __future__ import annotations

from pathlib import Path


def write_about_xml(
    mod_path: Path,
    package_id: str,
    name: str,
    *,
    extra_xml: str = "",
) -> None:
    about_path = mod_path / "About" / "About.xml"
    about_path.parent.mkdir(parents=True, exist_ok=True)
    _ = about_path.write_text(
        f"""\
<ModMetaData>
  <packageId>{package_id}</packageId>
  <name>{name}</name>
  <author>Author</author>
  <description>Description</description>
  <supportedVersions>
    <li>1.6</li>
  </supportedVersions>
{extra_xml}
</ModMetaData>
""",
        encoding="utf-8",
    )
