# Tool Config Spec

## Purpose

`rimpack` stores user-local tool configuration outside modpack projects.

This config is for machine-specific defaults such as install locations. It is not part of a
pack, should not be committed with a pack, and should not affect authored pack file formats.

---

## Location

The tool config directory must be resolved with `platformdirs`.

The config file path is:

```text
<platformdirs user config dir>/config.toml
```

Example on Windows:

```text
C:/Users/<user>/AppData/Local/rimpack/config.toml
```

---

## Format

The config file must be TOML.

The current schema uses root-level keys:

```toml
rimworld_folder = "D:/SteamLibrary/steamapps/common/RimWorld"
steam_workshop_folder = "D:/SteamLibrary/steamapps/workshop/content/294100"
```

Paths should be stored as absolute paths.

Unknown keys should be ignored for now.

---

## Fields

### `rimworld_folder`

Optional.

Absolute path to the RimWorld installation directory.

The tool derives the local mod root from this path as:

```text
<rimworld_folder>/Mods
```

---

### `steam_workshop_folder`

Optional.

Absolute path to the Steam Workshop content directory for RimWorld.

Expected shape:

```text
<Steam library>/steamapps/workshop/content/294100
```

---

## Creation behavior

When the user runs `rimpack` with no command and no usable config file exists, the tool should:

1. ask whether to create the config file
2. try to locate `rimworld_folder`
3. try to locate `steam_workshop_folder`
4. ask for confirmation before writing each detected path
5. write a deterministic TOML config file

If a path cannot be detected, the config may omit that field.

---

## Fallback behavior

If no config file exists or no config can be loaded, the tool may still operate by using:

1. environment variables
2. automatic discovery

Environment variables override automatic discovery.

Current environment variable names:

- `RIMWORLD_FOLDER`
- `STEAM_WORKSHOP_FOLDER`

---

## Non-goals

This file should not store:

- modpack project state
- generated lock data
- UI state
- caches
- per-pack authored paths
- per-pack runtime roots
- per-pack save-data or config roots

The tool config is strictly user-local machine configuration.

Per-pack runtime and save-data/config roots are still machine-local, but they should be derived
deterministically from the modpack root rather than stored in this global config file.
