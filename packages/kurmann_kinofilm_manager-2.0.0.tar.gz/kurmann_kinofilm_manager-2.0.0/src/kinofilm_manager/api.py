"""
api.py – Request/Result Fassade für die DTS→AC3 Konvertierung.

Orchestriert den Workflow: Analyse → FFmpeg-Befehl → Ausführung.
Keine print()-Aufrufe, keine sys.exit()-Aufrufe.
Fehler werden als ConvertResult(success=False, ...) zurückgegeben.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from kinofilm_manager.core import (
    analyze_streams,
    build_ac3_language_map,
    build_ffmpeg_command,
    get_tag,
    is_dts,
    run_ffprobe,
    should_skip_dts,
)


@dataclass
class ConvertRequest:
    """Eingabeparameter für die DTS→AC3 Konvertierung."""

    input_path: Path
    output_path: Path | None = None
    bitrate: str | None = None
    dry_run: bool = False


@dataclass
class StreamInfo:
    """Informationen über einen analysierten Stream für die CLI-Ausgabe."""

    index: int
    codec_type: str  # "video", "audio", "subtitle"
    codec_name: str
    profile: str
    language: str
    title: str
    channels: int
    action: str  # "", "convert", "skip", "downmix", "skip_subtitle"


@dataclass
class ConvertResult:
    """Ergebnis der DTS→AC3 Konvertierung."""

    success: bool
    output_path: Path | None = None
    streams: list[StreamInfo] = field(default_factory=list)
    converted_count: int = 0
    skipped_count: int = 0
    skipped_subtitle_streams: list[StreamInfo] = field(default_factory=list)
    ffmpeg_command: list[str] | None = None
    output_size_mb: float | None = None
    error_message: str | None = None


def _build_stream_info(
    stream: dict,
    codec_type: str,
    action: str = "",
) -> StreamInfo:
    """Erstellt ein StreamInfo-Objekt aus einem ffprobe-Stream."""
    from kinofilm_manager.core import get_channels, get_tag

    return StreamInfo(
        index=stream.get("index", 0),
        codec_type=codec_type,
        codec_name=stream.get("codec_name", ""),
        profile=stream.get("profile", ""),
        language=get_tag(stream, "language", ""),
        title=get_tag(stream, "title", ""),
        channels=get_channels(stream) if codec_type == "audio" else 0,
        action=action,
    )


def convert(request: ConvertRequest) -> ConvertResult:
    """
    Orchestriert die DTS→AC3 Konvertierung.

    1. Eingabe validieren
    2. Streams mit ffprobe analysieren
    3. FFmpeg-Befehl aufbauen
    4. Konvertierung ausführen (oder Dry-Run)
    """
    input_path = request.input_path.resolve()
    if not input_path.exists():
        return ConvertResult(
            success=False,
            error_message=f"Datei nicht gefunden: {input_path}",
        )

    output_path = request.output_path
    if output_path is None:
        output_path = input_path.parent / (input_path.stem + "_ac3.mkv")

    # ── Analyse ──────────────────────────────────────────────
    try:
        probe_data = run_ffprobe(input_path)
    except RuntimeError as e:
        return ConvertResult(
            success=False,
            error_message=str(e),
        )

    video, audio, subtitle, skipped_subs = analyze_streams(probe_data)
    ac3_language_map = build_ac3_language_map(audio)

    # ── Stream-Infos für CLI aufbereiten ─────────────────────
    stream_infos: list[StreamInfo] = []

    for s in video:
        stream_infos.append(_build_stream_info(s, "video"))

    for s in audio:
        if is_dts(s):
            if should_skip_dts(s, ac3_language_map):
                action = "skip"
            elif int(s.get("channels", 2) or 2) >= 8:
                action = "downmix"
            else:
                action = "convert"
        else:
            action = ""
        stream_infos.append(_build_stream_info(s, "audio", action))

    for s in subtitle:
        stream_infos.append(_build_stream_info(s, "subtitle"))

    skipped_subtitle_infos: list[StreamInfo] = []
    for s in skipped_subs:
        info = _build_stream_info(s, "subtitle", "skip_subtitle")
        skipped_subtitle_infos.append(info)

    # ── Prüfen ob DTS vorhanden ──────────────────────────────
    dts_tracks = [s for s in audio if is_dts(s)]
    if not dts_tracks:
        return ConvertResult(
            success=True,
            output_path=None,
            streams=stream_infos,
            converted_count=0,
            skipped_count=0,
            skipped_subtitle_streams=skipped_subtitle_infos,
            error_message="Keine DTS-Spuren gefunden. Nichts zu konvertieren.",
        )

    to_convert = [s for s in dts_tracks if not should_skip_dts(s, ac3_language_map)]
    skipped = [s for s in dts_tracks if should_skip_dts(s, ac3_language_map)]

    if not to_convert:
        return ConvertResult(
            success=True,
            output_path=None,
            streams=stream_infos,
            converted_count=0,
            skipped_count=len(skipped),
            skipped_subtitle_streams=skipped_subtitle_infos,
            error_message="Alle DTS-Spuren haben bereits eine AC3-Entsprechung. Nichts zu tun.",
        )

    # ── FFmpeg-Befehl aufbauen ───────────────────────────────
    cmd = build_ffmpeg_command(
        input_path,
        output_path,
        video,
        audio,
        subtitle,
        ac3_language_map=ac3_language_map,
        bitrate_override=request.bitrate,
    )

    if request.dry_run:
        return ConvertResult(
            success=True,
            output_path=output_path,
            streams=stream_infos,
            converted_count=len(to_convert),
            skipped_count=len(skipped),
            skipped_subtitle_streams=skipped_subtitle_infos,
            ffmpeg_command=cmd,
        )

    # ── Ausführen ────────────────────────────────────────────
    result = subprocess.run(cmd)

    if result.returncode != 0:
        return ConvertResult(
            success=False,
            output_path=output_path,
            streams=stream_infos,
            converted_count=len(to_convert),
            skipped_count=len(skipped),
            skipped_subtitle_streams=skipped_subtitle_infos,
            ffmpeg_command=cmd,
            error_message=f"FFmpeg beendet mit Code {result.returncode}",
        )

    size_mb = output_path.stat().st_size / (1024 * 1024)

    return ConvertResult(
        success=True,
        output_path=output_path,
        streams=stream_infos,
        converted_count=len(to_convert),
        skipped_count=len(skipped),
        skipped_subtitle_streams=skipped_subtitle_infos,
        ffmpeg_command=cmd,
        output_size_mb=size_mb,
    )
