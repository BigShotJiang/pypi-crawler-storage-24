"""
cli.py – typer-basierte CLI für kinofilm-manager.

Gemäss Architekturprinzip v1.1.0:
- Ergebnisse auf stdout (pipeline-freundlich)
- Rich-Ausgaben (Stream-Analyse, Fortschritt) auf stderr
- --verbose für zusätzliche Diagnoseinfos (FFmpeg-Befehl) auf stderr
"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from kinofilm_manager.api import ConvertRequest, ConvertResult, StreamInfo, convert

app = typer.Typer(
    name="kinofilm-manager",
    no_args_is_help=True,
)


@app.callback()
def main() -> None:
    """CLI-Tool zur Konvertierung von DTS/DTS-HD Audiospuren in MKV-Dateien zu AC3."""

# Alle Rich-Ausgaben auf stderr (Diagnose/Status)
stderr_console = Console(stderr=True)


def _format_stream_line(info: StreamInfo, ac3_language_map: dict[str, int]) -> str:
    """Formatiert eine Stream-Zeile für die Analyse-Ausgabe."""
    codec = info.codec_name.upper()
    profile_str = f" / {info.profile}" if info.profile else ""
    lang = info.language or "?"
    title_str = f" / {info.title}" if info.title else ""

    if info.codec_type == "video":
        return f"  Video    #{info.index}: {codec}"

    if info.codec_type == "audio":
        channels_str = f" | {info.channels}ch"

        if info.action == "skip":
            ac3_ch = ac3_language_map.get(lang.lower(), 0)
            ac3_label = f"{ac3_ch - 1}.1" if ac3_ch > 2 else f"{ac3_ch}.0"
            action_str = f" → ÜBERSPRUNGEN (AC3 {ac3_label} gleicher Sprache vorhanden)"
        elif info.action == "downmix":
            action_str = " → AC3 5.1 (7.1 Downmix via pan-Filter)"
        elif info.action == "convert":
            action_str = " → wird zu AC3 konvertiert"
        else:
            action_str = ""

        return f"  Audio    #{info.index}: {codec}{profile_str} | {lang}{title_str}{channels_str}{action_str}"

    if info.codec_type == "subtitle":
        if info.action == "skip_subtitle":
            return f"  Subtitle #{info.index}: {codec} | {lang}{title_str} → ÜBERSPRUNGEN (nicht MKV-kompatibel)"
        return f"  Subtitle #{info.index}: {codec} | {lang}{title_str}"

    return f"  #{info.index}: {codec}"


def _print_stream_analysis(result: ConvertResult) -> None:
    """Gibt die Stream-Analyse auf stderr aus."""
    # AC3-Language-Map rekonstruieren aus den Stream-Infos für die Anzeige
    ac3_map: dict[str, int] = {}
    for s in result.streams:
        if s.codec_type == "audio" and s.codec_name.lower() in {"ac3", "eac3", "a52"}:
            lang = s.language.lower()
            if lang and lang != "und":
                ac3_map[lang] = max(ac3_map.get(lang, 0), s.channels)

    stderr_console.print("\n── Stream-Analyse ──────────────────────────────────")
    for info in result.streams:
        stderr_console.print(_format_stream_line(info, ac3_map))
    for info in result.skipped_subtitle_streams:
        stderr_console.print(_format_stream_line(info, ac3_map))
    stderr_console.print("────────────────────────────────────────────────────\n")


@app.command("convert")
def convert_cmd(
    input_file: Path = typer.Argument(
        ...,
        help="Eingabe MKV-Datei",
        exists=True,
        readable=True,
    ),
    output: Path | None = typer.Option(
        None,
        "--output", "-o",
        help="Ausgabe MKV-Datei (Standard: <input>_ac3.mkv)",
    ),
    bitrate: str | None = typer.Option(
        None,
        "--bitrate", "-b",
        help="AC3-Bitrate für alle konvertierten Spuren (z.B. 448k, 640k)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Zeigt Analyse und FFmpeg-Befehl, erstellt keine Datei",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose", "-v",
        help="Zusätzliche Diagnoseinformationen auf stderr",
    ),
) -> None:
    """Konvertiert DTS/DTS-HD Audiospuren in MKV-Dateien zu AC3."""
    request = ConvertRequest(
        input_path=input_file,
        output_path=output,
        bitrate=bitrate,
        dry_run=dry_run,
    )

    stderr_console.print(f"\nEingabe:  {input_file.resolve()}")
    if output:
        stderr_console.print(f"Ausgabe:  {output}")

    # convert() führt Analyse + Konvertierung in einem Schritt durch.
    # FFmpeg-Output erscheint während der Ausführung direkt auf stderr.
    result = convert(request)

    # Stream-Analyse immer auf stderr ausgeben
    _print_stream_analysis(result)

    # ── Fehler ───────────────────────────────────────────────
    if not result.success:
        stderr_console.print(f"[bold red]\\[FEHLER][/bold red] {result.error_message}")
        raise typer.Exit(code=1)

    # ── Keine DTS-Spuren ─────────────────────────────────────
    if result.converted_count == 0:
        stderr_console.print(f"\\[INFO] {result.error_message}")
        raise typer.Exit(code=0)

    # ── Status ───────────────────────────────────────────────
    if result.skipped_count > 0:
        stderr_console.print(
            f"\\[INFO] {result.skipped_count} DTS-Spur(en) übersprungen "
            "(AC3 mit gleicher Kanalanzahl bereits vorhanden)"
        )

    stderr_console.print(
        f"\\[INFO] {result.converted_count} DTS-Spur(en) "
        f"{'würden' if dry_run else 'wurden'} zu AC3 konvertiert."
    )

    # ── Verbose: FFmpeg-Befehl ───────────────────────────────
    if (verbose or dry_run) and result.ffmpeg_command:
        stderr_console.print("\nFFmpeg-Befehl:")
        stderr_console.print("  " + " \\\n    ".join(result.ffmpeg_command))

    # ── Dry-Run ──────────────────────────────────────────────
    if dry_run:
        stderr_console.print("\n\\[DRY-RUN] Keine Datei wurde erstellt.")
        raise typer.Exit(code=0)

    # ── Ergebnis ─────────────────────────────────────────────
    if result.output_path and result.output_size_mb is not None:
        stderr_console.print(
            f"\n✓ Fertig: {result.output_path} ({result.output_size_mb:.1f} MB)"
        )
        # Ergebnis-Pfad auf stdout (pipeline-freundlich)
        print(str(result.output_path))

    # ── Warnung: übersprungene Untertitel ─────────────────────
    if result.skipped_subtitle_streams:
        stderr_console.print(
            f"\n⚠️  {len(result.skipped_subtitle_streams)} Untertitel-Spur(en) "
            "wurden weggelassen (nicht MKV-kompatibel):"
        )
        for s in result.skipped_subtitle_streams:
            title_str = f" / {s.title}" if s.title else ""
            stderr_console.print(
                f"   #{s.index}: {s.codec_name.upper()} | {s.language or '?'}{title_str}"
            )
        stderr_console.print(
            "   → DVD-Untertitel (dvd_subtitle) können nur aus VOB/MKV "
            "in Subler als Bitmaps importiert werden."
        )


if __name__ == "__main__":
    app()
