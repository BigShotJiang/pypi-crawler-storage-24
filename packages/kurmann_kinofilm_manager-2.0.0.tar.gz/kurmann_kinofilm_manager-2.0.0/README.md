# kinofilm-manager

Python-CLI-Tool zur Konvertierung von DTS/DTS-HD Audiospuren in MKV-Dateien zu Dolby Digital AC3. Das Ergebnis ist eine neue MKV-Datei, die direkt in **Subler** importiert und zu M4V/MP4 für Apple TV und Infuse weiterverarbeitet werden kann.

---

## Hintergrund und Motivation

### Das Container-Problem

Der **MP4/M4V-Container** – der native Container für Apple TV, iTunes und Infuse – unterstützt **DTS und DTS-HD nicht**. Dies ist eine Einschränkung des Container-Standards: DTS ist im MP4-Standard nicht als zulässiger Audio-Codec spezifiziert.

Wer eine Archivierungs-Pipeline aufbaut, die auf folgenden Komponenten basiert:

```
MKV (Quellformat) → Subler (Muxing/Metadaten) → M4V (Apple TV / Infuse)
```

steht vor dem Problem, dass Subler DTS-Spuren aus einem MKV **nicht direkt in einen M4V-Container übernehmen** kann. Der Workaround wäre ein manuelles Transcodieren in Subler – was aber keine Batch-Fähigkeit bietet und keinen kontrollierten Workflow erlaubt.

### Die Lösung: Zweistufiger Workflow

Der Workflow wird sauber in zwei unabhängige Schritte getrennt:

```
Schritt 1: kinofilm-manager convert
MKV (mit DTS) → MKV (mit AC3)

Schritt 2: Subler (manuell oder via SublerCLI)
MKV (mit AC3) → M4V (für Apple TV / Infuse)
```

Dadurch bleibt Subler ein reines **Muxing- und Metadaten-Tool** und kinofilm-manager übernimmt die Audiokonvertierung deterministisch und reproduzierbar.

---

## Unterstützte Audio-Codecs im M4V-Container

Zur Übersicht welche Audioformate im MP4/M4V-Container zulässig sind:

| Codec | M4V-kompatibel | Bemerkung |
|---|---|---|
| AAC | ✅ | Nativ |
| AC3 (Dolby Digital) | ✅ | Von Apple für M4V zugelassen |
| E-AC3 (Dolby Digital Plus) | ✅ | Inkl. Atmos-Metadata |
| DTS | ❌ | Nicht im MP4-Standard |
| DTS-HD HRA / MA | ❌ | Nicht im MP4-Standard |
| TrueHD | ❌ | Nicht im MP4-Standard |

---

## Voraussetzungen

- Python 3.11 oder neuer
- `ffmpeg` und `ffprobe` im PATH

**Installation ffmpeg auf macOS:**

```bash
brew install ffmpeg
```

> **Hinweis:** HandBrake nicht via Homebrew installieren – es überschreibt shared Libraries (z.B. `libvpx`) und kann zu `dyld: Library not loaded`-Fehlern bei ffmpeg führen. HandBrake stattdessen als `.app` via DMG installieren.

---

## Installation

```bash
# Via pip
pip install kurmann-kinofilm-manager

# Via uv
uv pip install kurmann-kinofilm-manager

# Für Entwicklung (lokal)
git clone https://github.com/kurmann/kinofilm-manager.git
cd kinofilm-manager
pip install -e ".[dev]"
```

---

## Verwendung

```bash
kinofilm-manager convert <input.mkv> [Optionen]
```

### Parameter

| Argument | Kurz | Standard | Beschreibung |
|---|---|---|---|
| `INPUT_FILE` | – | – | Pfad zur Eingabe-MKV (Pflichtfeld) |
| `--output` | `-o` | `<input>_ac3.mkv` | Pfad zur Ausgabe-MKV |
| `--bitrate` | `-b` | automatisch | AC3-Bitrate für alle konvertierten Spuren |
| `--dry-run` | – | – | Zeigt Analyse und FFmpeg-Befehl, erstellt keine Datei |
| `--verbose` | `-v` | – | Zusätzliche Diagnoseinformationen auf stderr |

### Beispiele

```bash
# Einfachster Aufruf – Ausgabe landet neben der Quelldatei
kinofilm-manager convert "Film (2024).mkv"

# Ausgabepfad selbst bestimmen
kinofilm-manager convert "Film (2024).mkv" -o "Film (2024)_subler.mkv"

# Erst prüfen was passieren würde (empfohlen beim ersten Test)
kinofilm-manager convert "Film (2024).mkv" --dry-run

# Eigene Bitrate (kleinere Datei, geringfügig weniger Qualität)
kinofilm-manager convert "Film (2024).mkv" --bitrate 448k

# Pipeline: Ergebnis-Pfad auf stdout, Diagnose auf stderr
output=$(kinofilm-manager convert "Film (2024).mkv")
echo "Konvertierte Datei: $output"
```

### Ausgabekonvention

Gemäss den Architekturprinzipien gilt:
- **stdout**: Ergebnis-Pfad der konvertierten Datei (pipeline-freundlich)
- **stderr**: Stream-Analyse, Fortschritt, Warnungen (Rich-formatiert)
- `--verbose`: Zusätzliche Diagnoseinformationen (FFmpeg-Befehl) auf stderr

---

## API-Nutzung

kinofilm-manager kann auch als Python-Bibliothek verwendet werden:

```python
from pathlib import Path
from kinofilm_manager.api import convert, ConvertRequest

request = ConvertRequest(
    input_path=Path("Film.mkv"),
    dry_run=True,
)
result = convert(request)

if result.success:
    print(f"Konvertiert: {result.converted_count} Spuren")
    for stream in result.streams:
        print(f"  #{stream.index}: {stream.codec_name} → {stream.action}")
```

---

## Fachlogik

### 1. DTS-Erkennung

DTS-Spuren werden über `codec_name` und `profile` aus den ffprobe-Metadaten erkannt:

- `dts` (DTS Core)
- `dts-hd` / `dtshd`
- Profile wie `DTS-HD HRA`, `DTS-HD MA`

### 2. Duplikat-Erkennung: DTS überspringen wenn AC3 mit gleicher Kanalanzahl vorhanden

Viele MKV-Dateien enthalten bereits mehrere Audiospuren pro Sprache. Eine DTS-Spur wird nur dann **übersprungen**, wenn bereits eine **AC3-Spur gleicher Sprache und mindestens gleicher Kanalanzahl** vorhanden ist.

Eine vorhandene AC3 **Stereo** (2.0) Spur ist **kein** Ersatz für eine DTS **5.1** Spur – der Mehrkanal-Surround-Ton würde verloren gehen.

### 3. Kanalanzahl und Bitrate

AC3 (Dolby Digital) unterstützt maximal **5.1 (6 Kanäle)**. Die Bitrate wird automatisch je nach Kanalanzahl gewählt:

| Kanäle | Automatische Bitrate |
|---|---|
| Mono / Stereo | 192k |
| 5.1 | 640k |
| 7.1 (vor Downmix) | 640k |

### 4. 7.1 → 5.1 Downmix via pan-Filter

DTS-HD 7.1 wird via FFmpeg `pan`-Filter auf 5.1 downgemischt. Seitenkanäle (SL/SR) werden auf die Rear-Kanäle (BL/BR) überlagert mit Faktor 0.7 zur Clipping-Vermeidung. Frontkanäle bleiben unverändert.

### 5. Tonversatz (Audio Delay)

MKV-Dateien können pro Spur einen `start_time`-Wert enthalten. FFmpeg erhält `-avoid_negative_ts make_zero` für korrekte Übertragung.

### 6. Stream-Metadaten

Alle Stream-Metadaten (Sprache, Titel) werden explizit pro Stream übertragen. Für konvertierte DTS-Spuren wird der Titel automatisch neu generiert.

### 7. Untertitel-Kompatibilität

Inkompatible Untertitel-Streams (z.B. `dvd_subtitle`) werden erkannt und weggelassen. MKV-kompatible Formate (SRT, ASS, PGS, etc.) werden unverändert kopiert.

**PGS-Untertitel und OCR:** Blu-ray PGS-Untertitel werden als Bitmap ins MKV kopiert. Eine integrierte OCR-Lösung wurde evaluiert, wird aber bewusst nicht umgesetzt. Das Tool bleibt im Scope der **Audio-Konvertierung**. Subler übernimmt im nachgelagerten Schritt die OCR-Konvertierung der PGS-Untertitel beim Muxing zu M4V – mit guter Qualität.

---

## Bekannte Einschränkungen

- **DVD-Untertitel** werden weggelassen. Workaround: In Subler als Bitmap importieren.
- **AC3-Maximum ist 5.1** – 7.1-Material wird immer auf 5.1 downgemischt.
- **Qualitätsverlust** – DTS→AC3 ist verlustbehaftet. Für audiophile Ansprüche bleibt MKV mit DTS-HD das bessere Archivformat.

---

## Weiterführender Workflow

Nach der Konvertierung empfiehlt sich folgender Workflow in **Subler**:

1. Konvertierte MKV in Subler öffnen
2. Gewünschte Spuren auswählen (typisch: eine Audiospur pro Sprache)
3. PGS-Untertitel via Sublers integrierte OCR zu Text konvertieren (falls vorhanden)
4. Metadaten ergänzen (Titel, Jahr, Beschreibung, Artwork)
5. Als M4V exportieren

---

## Änderungsverlauf

### [2.0.0] – 2026-03-12
- ⚠️ Breaking Change: Neuer CLI-Aufruf `kinofilm-manager convert` statt `python3 mkv_dts_to_ac3.py`
- Restrukturierung als PyPI-Paket `kurmann-kinofilm-manager`
- CLI mit typer und rich, Ergebnisse auf stdout, Diagnose auf stderr
- Request/Result-API für programmatische Nutzung

### [1.0.0] – 2026-03-12
- Erstveröffentlichung als einzelnes Script

Vollständiger Änderungsverlauf: [CHANGELOG.md](CHANGELOG.md)

---

## Lizenz

MIT
