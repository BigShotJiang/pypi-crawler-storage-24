"""Adam MCP Server - Expose Adam vault memory as MCP tools for Claude Desktop and any MCP client."""
__version__ = "1.0.1"
