from __future__ import annotations

import flask
from flask_restx import Api, Resource, fields
from flask_restx.api import HTTPStatus
from typing import TYPE_CHECKING, cast, Any
from PyQt6.QtCore import (
    QObject,
    QThread,
    Qt,
    QMetaObject,
    Q_RETURN_ARG,
    Q_ARG,
    pyqtSlot,
    QVariant,
)
import io
from PIL.Image import Image
import numpy
from ..lsapi.lsapi import LSAPI
from ..utils.yaml_types import Config

if TYPE_CHECKING:
    from ..laserstudio import LaserStudio


class RestProxy(QObject):
    """
    Class to execute the requests from REST object lying the RestThread, in the same thread that
    laser studio.
    """

    def __init__(self, laser_studio: LaserStudio, config: Config):
        super().__init__()
        self.laser_studio: LaserStudio = laser_studio
        self.rest_object = RestServer(self)
        self._thread = RestThread(config)
        self.rest_object.moveToThread(self._thread)
        self._thread.start()

    @pyqtSlot(result="QVariant")
    def handle_go_next(self):
        response = {}
        if self.laser_studio.scanning_enabled:
            response = self.laser_studio.handle_go_next()
        return QVariant(response)

    @pyqtSlot(QVariant, result="QVariant")
    def handle_magicfocus(self, parameters: dict[str, Any] | None):
        if (f := self.laser_studio.instruments.focus_helper) is None:
            return QVariant({"error": "No focus helper available"})
        if parameters is None:
            return QVariant(f.magic_focus_state())
        f.magic_focus(parameters=parameters).start()
        return QVariant(f.magic_focus_state())

    @pyqtSlot(QVariant, result="QVariant")
    def handle_autofocus(self, do_register: QVariant):
        if self.laser_studio.instruments.focus_helper is None:
            return QVariant({"error": "No focus helper available"})
        return self.laser_studio.instruments.focus_helper.autofocus()

        # if type((d := do_register)) is bool and d is True:
        #     # Register current position
        #     self.laser_studio.instruments.focus_helper.register()
        #     return QVariant(
        #         self.laser_studio.instruments.focus_helper.autofocus_helper.registered_points
        #     )
        # elif type(d) is dict:
        #     # Register given position
        #     self.laser_studio.instruments.focus_helper.register(d.get("new_point"))
        #     return QVariant(
        #         self.laser_studio.instruments.focus_helper.autofocus_helper.registered_points
        #     )
        # elif d is None:
        #     # Get registered points
        #     return QVariant(
        #         self.laser_studio.instruments.focus_helper.autofocus_helper.registered_points
        #     )
        # else:
        #     # Perform autofocus

    @pyqtSlot(int, result="QVariant")
    def handle_go_to_memory_point(self, index: int):
        return QVariant(self.laser_studio.handle_go_to_memory_point(index))

    @pyqtSlot(QVariant, QVariant, QVariant, QVariant, result="QVariant")
    def handle_add_markers(
        self,
        pos: list[list[float]] | None,
        color: list[float] | None,
        label: str | None,
        visible: bool | None,
    ):
        return QVariant(
            self.laser_studio.handle_add_markers(pos, color, label, visible)
        )

    @pyqtSlot(result="QVariant")
    def handle_markers(self):
        return QVariant(self.laser_studio.handle_markers())

    @pyqtSlot(QVariant, result="QVariant")
    def handle_position(self, pos: list[float] | None):
        return QVariant(self.laser_studio.handle_position(pos))

    @pyqtSlot(QVariant, result="QVariant")
    def handle_camera(self, path: str | None):
        return QVariant(self.laser_studio.handle_camera(path))

    @pyqtSlot(QVariant, result="QVariant")
    def handle_camera_accumulator(self, path: str | None):
        return QVariant(self.laser_studio.handle_camera_accumulator(path))

    @pyqtSlot(QVariant, result="QVariant")
    def handle_camera_average(self, reset: bool) -> QVariant:
        return QVariant(self.laser_studio.handle_camera_average(reset))

    @pyqtSlot(QVariant, QVariant, result="QVariant")
    def handle_camera_reference(
        self, dotake: bool | None = None, refname: str | None = None
    ):
        return QVariant(self.laser_studio.handle_camera_reference(dotake, refname))

    @pyqtSlot(QVariant, result="QVariant")
    def handle_screenshot(self, path: str | None):
        return QVariant(self.laser_studio.handle_screenshot(path))

    @pyqtSlot(QVariant, QVariant, QVariant, QVariant, result="QVariant")
    def handle_laser(
        self,
        num: int,
        active: bool | None,
        power: float | None,
        offset_current: float | None,
    ):
        return QVariant({"error": "Not implemented"})
        return QVariant(
            self.laser_studio.handle_laser(num, active, power, offset_current)
        )

    @pyqtSlot(QVariant, QVariant, result="QVariant")
    def handle_instrument_settings(self, label: str, conf: dict[str, Any] | None):
        return QVariant(self.laser_studio.handle_instrument_settings(label, conf))


class RestThread(QThread):
    """
    Subclass of QThread where to launch the Rest server.
    """

    def __init__(self, config: dict[str, Any], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.host = config.get("host", "localhost")
        self.port = config.get("port", LSAPI.PORT)

    def run(self):
        RestServer.serve(self.host, self.port)
        super(RestThread, self).run()


class RestServer(QObject):
    """
    Object that is moved in the REST-dedicated thread.
    Follows the singleton pattern
    """

    _shared: "RestServer"

    @staticmethod
    def shared(proxy: RestProxy | None = None) -> "RestServer":
        # if RestServer._shared is None:
        #     RestServer._shared = RestServer(proxy)
        return RestServer._shared

    def __init__(self, proxy: RestProxy | None, parent: QObject | None = None):
        super(RestServer, self).__init__(parent)
        self.proxy = proxy
        RestServer._shared = self

    @staticmethod
    def serve(host: str, port: int):
        """
        Launch flask's REST server on the given port

        :param port: The HTTP port to listen
        """
        flask_app.run(host=host, port=port)

    @staticmethod
    def invoke(member: str, *args) -> QVariant:
        """
        Invoke a given method name to the Proxy, with given arguments.
        The Proxy lies in the same thread that the main application.
        The method call is blocking until execution is done.

        :param member: The string value of the method to call
        :param args: The list of arguments to pass to the method invoked.
        :return: a QVariant (which can be None) returned by the invoked method.
        """
        proxy = RestServer.shared().proxy
        assert proxy is not None
        l_args = [Q_ARG(type(arg), arg) for arg in args]
        retval = cast(
            QVariant,
            QMetaObject.invokeMethod(
                proxy,
                member,
                Qt.ConnectionType.BlockingQueuedConnection,
                Q_RETURN_ARG(QVariant),
                *l_args,
            ),
        )
        return retval


flask_app = flask.Flask(__name__)
flask_api = Api(flask_app, version="1.2", title="LaserStudio REST API")

image = flask_api.namespace("images", description="Get some images")
path_png = image.model("Image Path", {"path": fields.String(example="/tmp/image.png")})
path_file = image.model("File Path", {"path": fields.String(example="/tmp/file.bin")})


@image.route("/screenshot")
class Screenshot(Resource):
    @image.produces(["image/png"])
    def get(self):
        im = cast(Image, RestServer.invoke("handle_screenshot", QVariant(None)))
        buffer = io.BytesIO()
        im.save(buffer, format="PNG")
        buffer.seek(0)
        return flask.send_file(buffer, mimetype="image/png")

    @image.expect(path_png)
    def post(self):
        if not flask.request.is_json:
            return "Given value is not a JSON", 415
        json = flask.request.json
        if not isinstance(json, dict):
            return "Given value is not a dictionary", 415
        path = json.get("path")
        RestServer.invoke("handle_screenshot", QVariant(path))
        return ""


@image.route("/camera")
class Camera(Resource):
    @image.produces(["image/png"])
    @image.response(
        HTTPStatus.NOT_FOUND, "No image can be produced (there may be no camera)"
    )
    def get(self):
        im = cast(Image | None, RestServer.invoke("handle_camera", QVariant(None)))
        if im is None:
            flask_api.abort(
                HTTPStatus.NOT_FOUND,
                "No image can be produced (there may be no camera)",
            )
            return
        buffer = io.BytesIO()
        im.save(buffer, format="PNG")
        buffer.seek(0)
        return flask.send_file(buffer, mimetype="image/png")

    @image.expect(path_png)
    def post(self):
        if not flask.request.is_json:
            return "Given value is not a JSON", 415
        json = flask.request.json
        if not isinstance(json, dict):
            return "Given value is not a dictionary", 415
        path = json.get("path")
        RestServer.invoke("handle_camera", QVariant(path))
        return ""


@image.route("/camera/accumulator")
class CameraAccumulator(Resource):
    @image.response(
        HTTPStatus.NOT_FOUND, "No data can be produced (there may be no camera)"
    )
    def get(self):
        content = cast(
            QVariant,
            RestServer.invoke("handle_camera_accumulator", QVariant(None)),
        )
        frame = cast(numpy.ndarray, content.value())
        if frame is None:
            flask_api.abort(
                HTTPStatus.NOT_FOUND,
                "No data can be produced (there may be no camera)",
            )
            return
        buffer = io.BytesIO()
        numpy.save(buffer, frame)
        buffer.seek(0)
        return flask.send_file(
            buffer, mimetype="application/octet-stream", download_name="accumulator.npy"
        )

    @image.expect(path_file)
    def post(self):
        if not flask.request.is_json:
            return "Given value is not a JSON", 415
        json = flask.request.json
        if not isinstance(json, dict):
            return "Given value is not a dictionary", 415
        path = json.get("path")
        RestServer.invoke("handle_camera_accumulator", QVariant(path))
        return path


count = image.model("Average Count", {"count": fields.Integer(example="50")})


@image.route("/camera/averaging")
class CameraAveraging(Resource):
    @image.response(200, "Get the current number of averaged images")
    def get(self):
        return RestServer.invoke("handle_camera_average", QVariant(False))

    @image.response(200, "Clear the current average")
    def delete(self):
        return RestServer.invoke("handle_camera_average", QVariant(True))


@image.route("/camera/reference/")
@image.route("/camera/reference/<refname>")
class CameraReference(Resource):
    @image.response(200, "Select the reference image")
    def get(self, refname: str | None = None):
        return RestServer.invoke(
            "handle_camera_reference", QVariant(None), QVariant(refname)
        )

    @image.response(200, "Set the reference image")
    def post(self, refname: str | None = None):
        return RestServer.invoke(
            "handle_camera_reference", QVariant(True), QVariant(refname)
        )

    @image.response(200, "Unset the reference image")
    def delete(self, refname: str | None = None):
        return RestServer.invoke(
            "handle_camera_reference", QVariant(False), QVariant(refname)
        )


motion = flask_api.namespace("motion", description="Control stage position")

viewer_pos = fields.List(fields.Float, example=[42.5, 44.1])
stage_pos = fields.List(fields.Float, example=[42.5, 44.1, -10.22])
laser_gonext = motion.model(
    "Laser GoNext parameters", {"current_percentage": fields.Float}
)
lasers_gonext = motion.model(
    "Lasers GoNext parameters",
    {
        "lasers": fields.List(fields.Nested(laser_gonext)),
    },
)
gonext_response = motion.model(
    "Go Next Response",
    {
        "next_point_geometry": stage_pos,
        "lasers": fields.List(fields.Nested(laser_gonext)),
        "next_point_applied": viewer_pos,
    },
)


@motion.route("/go_next")
class GoNext(Resource):
    # @motion.marshal_with(gonext_response)
    def post(self):
        return RestServer.invoke("handle_go_next")


@motion.route("/autofocus")
class Autofocus(Resource):
    @motion.response(200, "Autofocus is done")
    def post(self):
        """Perform autofocus"""
        return RestServer.invoke("handle_autofocus", QVariant(False))

    def put(self):
        """Register current position for autofocus"""
        return RestServer.invoke("handle_autofocus", QVariant(True))

    def get(self):
        """Get current registered points for autofocus"""
        return RestServer.invoke("handle_autofocus", QVariant(None))


@motion.route("/magicfocus")
class MagicFocus(Resource):
    @motion.response(200, "Get status of magicfocus")
    def get(self):
        return RestServer.invoke("handle_magicfocus", QVariant(None))

    def post(self):
        """Perform magicfocus with given parameters"""
        if not flask.request.is_json:
            return "Given value is not a JSON", 415
        json = flask.request.json
        if not isinstance(json, dict):
            return "Given value is not a dictionary", 415
        r = RestServer.invoke("handle_magicfocus", QVariant(json))
        return {"OK": True}


@motion.route("/go_to_memory_point/<int:index>")
class GoToMemoryPoint(Resource):
    @motion.response(200, "Go to memory point is done", stage_pos)
    def put(self, index):
        return RestServer.invoke("handle_go_to_memory_point", index)


position_move = motion.model("Stage State", {"pos": stage_pos})


@motion.route("/position")
class Position(Resource):
    @motion.expect(motion.model("Stage Position", {"pos": stage_pos}))
    @motion.response(200, "Go to position is done", position_move)
    def put(self):
        if not flask.request.is_json:
            return "Given value is not a JSON", 415
        json = flask.request.json
        if not isinstance(json, dict):
            return "Given value is not a dictionary", 415
        pos = json.get("pos")
        response = cast(dict, RestServer.invoke("handle_position", QVariant(pos)))
        if "error" in response:
            return response, HTTPStatus.BAD_REQUEST
        return response

    @motion.response(200, "Stage position and moving state", position_move)
    def get(self):
        return RestServer.invoke("handle_position", QVariant(None))


annotations = flask_api.namespace("annotation", description="Manage annotations")

marker = flask_api.model(
    "Marker",
    {
        "pos": fields.List(viewer_pos),
        "color": fields.List(fields.Float, example=[0.0, 1.0, 0.0, 0.5]),
        "visible": fields.Boolean(
            description="If False, marker(s) are created but not displayed."
        ),
    },
)


@annotations.route("/add_markers")
@annotations.route("/add_marker", doc={"description": "Alias for /add_markers"})
@annotations.route("/add_measurement", doc={"description": "Alias for /add_markers"})
class AddMarker(Resource):
    @annotations.expect(marker)
    def put(self):
        if not flask.request.is_json:
            return "Given value is not a JSON", 415
        json = flask.request.json
        if not isinstance(json, dict):
            return "Given value is not a dictionary", 415
        positions = json.get("pos")
        color = json.get("color")
        label = json.get("label")
        visible = json.get("visible", True)
        qvar = RestServer.invoke(
            "handle_add_markers",
            QVariant(positions),
            QVariant(color),
            QVariant(label),
            QVariant(visible),
        )
        return cast(dict, qvar)


@annotations.route("/markers")
class Markers(Resource):
    def get(self):
        qvar = RestServer.invoke("handle_markers")
        return cast(list[dict[str, Any]], qvar)


instruments = flask_api.namespace("instruments", description="Control instruments")

instrument = instruments.model(
    "Instrument",
    {
        "settings": fields.Raw(description="The settings of the instrument"),
    },
)


@instruments.route("/<label>/settings")
@instruments.param("label", "Label of the instrument.")
class Instrument(Resource):
    @instruments.doc("get_instrument_settings")
    def get(self, label: str):
        qvar = RestServer.invoke(
            "handle_instrument_settings",
            QVariant(label),
            QVariant(None),
        )
        return cast(dict, qvar)

    @instruments.doc("put_instrument_settings")
    @instruments.expect(instrument)
    @instruments.marshal_with(instrument)
    def put(self, label: str):
        if not flask.request.is_json:
            return "Given value is not a JSON", 415
        json = flask.request.json
        if not isinstance(json, dict):
            return "Given value is not a dictionary", 415
        qvar = RestServer.invoke(
            "handle_instrument_settings",
            QVariant(label),
            QVariant(json["settings"]),
        )
        return cast(dict, qvar)
