"""
BADAS Validation Module
========================

Clean evaluation pipeline for BADAS collision prediction models.

Quick Start
-----------

.. code-block:: python

    from badas.validation import Evaluator, EvaluatorConfig

    config = EvaluatorConfig(
        checkpoint_path="model.ckpt",
        labels_csv="test.csv",
        videos_dir="/path/to/videos",
    )

    evaluator = Evaluator(config)
    evaluator.run()  # Runs inference, metrics, and visualization

    # Or run steps individually:
    evaluator.run_inference()
    evaluator.compute_metrics()
    evaluator.generate_visualizations()

    # Skip inference if predictions already exist:
    evaluator.run(skip_inference=True)

Module Structure
----------------

- **evaluator**: Main evaluation pipeline (Evaluator class)
- **visualization**: Plotting functions for predictions and comparisons
"""

# Main evaluation pipeline
from .evaluator import (
    Evaluator,
    EvaluatorConfig,
)

# Metrics API
from .metrics import (
    MetricScope,
    ClassificationMetric,
    TemporalMetric,
    ClassificationMetrics,
    TimeToAlertMetric,
    BrierScoreMetric,
    SignalNoiseMetric,
    default_classification_metrics,
    default_temporal_metrics,
    compute_classification_metrics,
    run_temporal_metrics,
)

# Comparison figures
from .comparison import (
    discover_models,
    generate_comparison_report,
    plot_auc_by_group,
    plot_f1_mtta,
    plot_comparison_table,
    plot_f1_dumbbell,
    plot_kaggle,
    plot_recall_fpr,
    plot_overview,
)

# Visualization functions
from .visualization import (
    # Core plotting
    plot_prediction_timeseries,
    plot_prediction_from_inference,
    # Multi-panel figures
    plot_validation_results,
    plot_model_comparison,
    # Curve plots
    plot_pr_curve,
    plot_roc_curve,
    # Constants
    COLORS,
    RISK_CMAP,
    VIDEO_FPS_DEFAULT,
    DEFAULT_CAUTION_THRESHOLD,
    DEFAULT_DANGER_THRESHOLD,
)

__all__ = [
    # Evaluator
    'Evaluator',
    'EvaluatorConfig',
    # Metrics API
    'MetricScope',
    'ClassificationMetric',
    'TemporalMetric',
    'ClassificationMetrics',
    'TimeToAlertMetric',
    'BrierScoreMetric',
    'SignalNoiseMetric',
    'default_classification_metrics',
    'default_temporal_metrics',
    'compute_classification_metrics',
    'run_temporal_metrics',
    # Visualization
    'plot_prediction_timeseries',
    'plot_prediction_from_inference',
    'plot_validation_results',
    'plot_model_comparison',
    'plot_pr_curve',
    'plot_roc_curve',
    'COLORS',
    'RISK_CMAP',
    'VIDEO_FPS_DEFAULT',
    'DEFAULT_CAUTION_THRESHOLD',
    'DEFAULT_DANGER_THRESHOLD',
    # Comparison
    'discover_models',
    'generate_comparison_report',
    'plot_auc_by_group',
    'plot_f1_mtta',
    'plot_comparison_table',
    'plot_f1_dumbbell',
    'plot_kaggle',
    'plot_recall_fpr',
    'plot_overview',
]
