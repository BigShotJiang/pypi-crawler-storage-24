# badas/inference/__init__.py
"""Production inference module for video collision anticipation."""

# Configuration
from badas.inference.config import (
    Config,
    ModelConfig,
    DataConfig,
    TrainingConfig,
    SystemConfig,
    LoggingConfig,
    BADASConfig,
)

# Backends
from badas.inference.backends import (
    InferenceBackend,
    PyTorchBackend,
    ONNXBackend,
    TensorRTBackend,
    CosmosVLMBackend,
    ONNX_AVAILABLE,
    TRT_AVAILABLE,
)

# Smoothing
from badas.inference.smoothing import (
    SmoothingConfig,
    PostProcessSmoothingConfig,
    TemporalSmoother,
    apply_smoothing_offline,
    compare_smoothing_configs,
)

# Preprocessors
# NOTE: ZeroCopyTensorRTEngine is DEPRECATED. Use TensorRTBackend instead.
# It is kept here only for backwards compatibility and emits DeprecationWarning
# on instantiation. See ZeroCopyTensorRTEngine docstring for migration guide.
from badas.inference.preprocessors import (
    ZeroCopyTensorRTEngine,
)

# Debug utilities
from badas.inference.debug import (
    DebugConfig,
    DebugWindowSaver,
)

# Risk assessment
from badas.inference.risk import (
    RiskConfig,
    create_risk_assessment,
    analyze_prediction_statistics,
)

# Checkpoint loading
from badas.inference.checkpoint import (
    load_model_from_checkpoint,
)

# Frame sampling
from badas.inference.frame_sampling import (
    get_frame_interval,
    calculate_frame_indices,
    calculate_timestamp,
    expected_sampled_frames,
    get_video_info,
    iter_sampled_frames,
    iter_sampled_frames_sequential,
    FrameSampler,
    # Decord-based functions (with OpenCV fallback)
    iter_sampled_frames_decord,
    read_sampled_frames_batch,
    iter_sliding_windows_decord,
)

# Core imports (re-exported for convenience)
from badas.core import (
    VideoClassifierBase,
    VJEPA2Classifier,
    VideoMAEv2Classifier,
    create_model,
    detect_model_type,
    # Shared preprocessing
    VideoPreprocessor,
    sample_frames_uniform,
    IMAGENET_MEAN,
    IMAGENET_STD,
)

# Prediction enrichment callbacks
from badas.inference.callbacks import (
    PredictionCallback,
    TTSCallback,
)

# Main inference class and convenience functions
from badas.inference.inference import (
    BADAS,
    quick_predict,
    GPUPreprocessor,  # Backwards compatibility alias
)

# LED and Audio controllers
from badas.inference.led import (
    BaseLEDController,
    LEDController,
    DummyLEDController,
    create_led_controller,
    LED_COLORS_BGR,
    LED_COLORS_RGB,
    BaseAudioAlert,
    AudioAlert,
    DummyAudioAlert,
    create_audio_alert,
)

# Video overlay — see badas.visualization for the full public API

# Streaming sessions (HTTP API)
from badas.inference.streaming_session import (
    SessionConfig,
    SessionStats,
    StreamingSession,
    StreamingSessionManager,
    get_session_manager,
    init_session_manager,
)

# Real-time video player
from badas.inference.realtime import (
    RealtimeVideoPlayer,
)

# Visualization — see badas.visualization for the full public API

__all__ = [
    # Main inference class
    "BADAS",
    "BADASConfig",
    # Configuration
    "Config",
    "ModelConfig",
    "DataConfig",
    "TrainingConfig",
    "SystemConfig",
    "LoggingConfig",
    "DebugConfig",
    "SmoothingConfig",
    "PostProcessSmoothingConfig",
    # Models
    "VideoClassifierBase",
    "VJEPA2Classifier",
    "VideoMAEv2Classifier",
    "create_model",
    "detect_model_type",
    # Backends
    "InferenceBackend",
    "PyTorchBackend",
    "ONNXBackend",
    "TensorRTBackend",
    "CosmosVLMBackend",
    "ONNX_AVAILABLE",
    "TRT_AVAILABLE",
    # Smoothing
    "TemporalSmoother",
    "apply_smoothing_offline",
    "compare_smoothing_configs",
    # Preprocessors
    "GPUPreprocessor",
    "VideoPreprocessor",
    "ZeroCopyTensorRTEngine",
    # Debug
    "DebugWindowSaver",
    # Risk assessment
    "RiskConfig",
    "create_risk_assessment",
    "analyze_prediction_statistics",
    # Utilities
    "load_model_from_checkpoint",
    "quick_predict",
    # Callbacks
    "PredictionCallback",
    "TTSCallback",
    # Frame sampling
    "get_frame_interval",
    "calculate_frame_indices",
    "calculate_timestamp",
    "expected_sampled_frames",
    "get_video_info",
    "iter_sampled_frames",
    "iter_sampled_frames_sequential",
    "FrameSampler",
    # Decord-based (with OpenCV fallback)
    "iter_sampled_frames_decord",
    "read_sampled_frames_batch",
    "iter_sliding_windows_decord",
    # Preprocessing constants
    "sample_frames_uniform",
    "IMAGENET_MEAN",
    "IMAGENET_STD",
    # LED and Audio controllers
    "BaseLEDController",
    "LEDController",
    "DummyLEDController",
    "create_led_controller",
    "LED_COLORS_BGR",
    "LED_COLORS_RGB",
    "BaseAudioAlert",
    "AudioAlert",
    "DummyAudioAlert",
    "create_audio_alert",
    # Streaming sessions (HTTP API)
    "SessionConfig",
    "SessionStats",
    "StreamingSession",
    "StreamingSessionManager",
    "get_session_manager",
    "init_session_manager",
    # Real-time video player
    "RealtimeVideoPlayer",
]
