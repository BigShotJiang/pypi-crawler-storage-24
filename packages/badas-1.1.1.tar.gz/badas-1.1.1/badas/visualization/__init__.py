"""
Visualization utilities for BADAS.

Provides runtime prediction visualization (timelines, heatmaps, video overlays)
and analysis/validation plots (PR curves, ROC curves, model comparisons).

Usage::

    from badas.visualization import (
        visualize_predictions,
        plot_attribution_events,
        generate_overlay_video,
        display_video,
        plot_prediction_timeseries,
        plot_pr_curve,
    )
"""

# Runtime visualization (prediction timelines, heatmaps, video overlays).
# This package is the single public API — callers should import from here.

# Matplotlib-based prediction charts (timelines, attribution event plots).
from badas.visualization.charts import (
    VisualizationConfig,
    visualize_predictions,
    plot_attribution_events,
)

# Progress bars and risk display helpers — canonical implementations.
from badas.visualization.display_utils import (
    is_notebook,
    get_progress_bar,
    get_risk_color,
    get_risk_level,
    format_risk_level,
    get_risk_emoji,
    print_prediction,
)

# Video generation utilities (inference/visualization.py re-exports display_utils
# for backwards compatibility; import video functions from there directly).
from badas.inference.visualization import (
    generate_overlay_video,
    generate_heatmap_video,
    display_video,
    display_video_comparison,
)

# Video overlay rendering
from badas.visualization.overlay import (
    OverlayRenderer,
    VideoOverlayProcessor,
    create_overlay_video,
)

# Base processor and heatmap video rendering
from badas.visualization.video_base import BaseVideoProcessor
from badas.visualization.heatmap import HeatmapVideoProcessor

# TTS providers (core lives in badas.analysis.tts; re-exported here for convenience)
from badas.analysis.tts import TTSProvider, EdgeTTSProvider, FasterQwen3TTSProvider

# Multi-class overlay rendering
from badas.visualization.multiclass_overlay import (
    create_multiclass_overlay_video,
)

# Analysis / validation plots — per-video timeseries, PR/ROC curves
from badas.validation.visualization import (
    plot_prediction_timeseries,
    plot_prediction_from_inference,
    plot_validation_results,
    plot_model_comparison,
    plot_pr_curve,
    plot_roc_curve,
)

# Multi-model comparison / reporting figures
from badas.validation.comparison import (
    discover_models,
    plot_comparison_table,
    plot_f1_dumbbell,
    plot_kaggle,
    plot_recall_fpr,
    plot_overview,
    generate_comparison_report,
)

__all__ = [
    # Runtime visualization
    "is_notebook",
    "get_progress_bar",
    "VisualizationConfig",
    "get_risk_color",
    "get_risk_level",
    "format_risk_level",
    "get_risk_emoji",
    "print_prediction",
    "visualize_predictions",
    "plot_attribution_events",
    "generate_overlay_video",
    "generate_heatmap_video",
    "HeatmapVideoProcessor",
    "display_video",
    "display_video_comparison",
    # Video overlay rendering
    "OverlayRenderer",
    "VideoOverlayProcessor",
    "BaseVideoProcessor",
    "create_overlay_video",
    "create_multiclass_overlay_video",
    # TTS providers
    "TTSProvider",
    "EdgeTTSProvider",
    "FasterQwen3TTSProvider",
    # Per-video timeseries / curve plots
    "plot_prediction_timeseries",
    "plot_prediction_from_inference",
    "plot_validation_results",
    "plot_model_comparison",
    "plot_pr_curve",
    "plot_roc_curve",
    # Multi-model comparison / reporting
    "discover_models",
    "plot_comparison_table",
    "plot_f1_dumbbell",
    "plot_kaggle",
    "plot_recall_fpr",
    "plot_overview",
    "generate_comparison_report",
]
