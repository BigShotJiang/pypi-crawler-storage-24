# BADAS - Video Collision Anticipation Framework
"""
BADAS provides training, inference, and validation for video collision anticipation.

Quick start:
    # Inference
    from badas.inference import BADAS, BADASConfig
    predictor = BADAS("model.ckpt")
    results = predictor.predict_video("video.mp4")

    # Validation
    from badas.validation import Evaluator, EvaluatorConfig
    config = EvaluatorConfig(
        checkpoint_path="model.ckpt",
        labels_csv="test.csv",
        videos_dir="/path/to/videos",
    )
    evaluator = Evaluator(config)
    evaluator.run()

    # Training
    python -m badas.training.lightning_training --config configs/exp_combined_1to1.yml
"""

# Re-export core components for convenience
from badas.core import (
    VideoClassifierBase,
    VJEPA2Classifier,
    VideoMAEv2Classifier,
    create_model,
    detect_model_type,
)

# Re-export validation components
from badas.validation import (
    Evaluator,
    EvaluatorConfig,
)

__version__ = "1.0.0"

# API client
from badas.client import BADASClient, BADASError
