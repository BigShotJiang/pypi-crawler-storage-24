"""
BADAS Model Export Module.

Provides functionality to export BADAS models to ONNX and TensorRT formats
for deployment on edge devices and production environments, and to upload
slim inference checkpoints to HuggingFace Hub.

Example:
    >>> from badas.export import export_to_onnx, convert_to_tensorrt
    >>>
    >>> # Export checkpoint to ONNX
    >>> result = export_to_onnx("model.ckpt", "model.onnx")
    >>> print(f"ONNX: {result.onnx_path} ({result.file_size_mb:.1f} MB)")
    >>>
    >>> # Convert to TensorRT
    >>> result = convert_to_tensorrt("model.onnx", "model.trt")
    >>> print(f"TensorRT: {result.engine_path} ({result.file_size_mb:.1f} MB)")
    >>>
    >>> # Upload to HuggingFace Hub
    >>> from badas.export import upload_to_huggingface
    >>> result = upload_to_huggingface(
    ...     checkpoint_path="model.ckpt",
    ...     hf_repo="nexar-ai/badas-1.5-flash-lite",
    ...     backbone_name="nexar-ai/vjepa2-vits-fpc16-256-nexar",
    ...     model_type="vjepa2",
    ...     display_name="BADAS-1.5-Flash-Lite",
    ...     params="22M",
    ...     arch="ViT-S (SSL)",
    ...     description="Edge model, 5.9ms on Jetson Thor.",
    ... )
"""

# ONNX export
from badas.export.onnx import (
    ONNXExportConfig,
    ONNXExportResult,
    export_to_onnx,
    export_model_to_onnx,
)

# TensorRT conversion
from badas.export.tensorrt import (
    TensorRTConfig,
    TensorRTResult,
    find_trtexec,
    convert_to_tensorrt,
    convert_to_tensorrt_python,
)

# Export wrappers
from badas.export.wrappers import (
    ExportWrapper,
    ExportWrapperWithPredictor,
    create_export_wrapper,
)

# Utilities
from badas.export.utils import (
    patch_vjepa2_rope,
    embed_onnx_weights,
    validate_onnx,
    get_trtexec_command,
)

# HuggingFace upload
from badas.export.huggingface import (
    slim_checkpoint,
    ModelCardConfig,
    make_model_card,
    HFUploadResult,
    upload_to_huggingface,
)


__all__ = [
    # ONNX
    'ONNXExportConfig',
    'ONNXExportResult',
    'export_to_onnx',
    'export_model_to_onnx',
    # TensorRT
    'TensorRTConfig',
    'TensorRTResult',
    'find_trtexec',
    'convert_to_tensorrt',
    'convert_to_tensorrt_python',
    # Wrappers
    'ExportWrapper',
    'ExportWrapperWithPredictor',
    'create_export_wrapper',
    # Utils
    'patch_vjepa2_rope',
    'embed_onnx_weights',
    'validate_onnx',
    'get_trtexec_command',
    # HuggingFace
    'slim_checkpoint',
    'ModelCardConfig',
    'make_model_card',
    'HFUploadResult',
    'upload_to_huggingface',
]
