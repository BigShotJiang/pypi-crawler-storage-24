package main

import (
	"fmt"
	"os"
	"strings"

	"sandbox-engine/internal/detector"
	python "sandbox-engine/internal/runtime/python"
	"sandbox-engine/internal/scanner"
)

func main() {

	if len(os.Args) < 2 {
		printUsage()
		return
	}

	command := os.Args[1]

	switch command {

	case "scan":

		result, err := scanner.ScanRepo(".")
		if err != nil {
			fmt.Println("Scan failed:", err)
			return
		}

		fmt.Println("=== Scan Results ===")
		fmt.Println("Python files:", len(result.PythonFiles))
		fmt.Println("Entrypoints:", result.Entrypoints)
		fmt.Println("Dependency files:", result.DependencyFiles)

		if result.HasVenv {
			fmt.Println("Virtual env: found at", result.VenvPath)
		} else {
			fmt.Println("Virtual env: not found")
		}

	case "detect":

		result, err := scanner.ScanRepo(".")
		if err != nil {
			fmt.Println("Scan failed:", err)
			return
		}

		project, err := detector.DetectFramework(result)
		if err != nil {
			fmt.Println("Detection failed:", err)
			return
		}

		fmt.Println("=== Detection Results ===")
		fmt.Println("Framework:", project.Framework)
		fmt.Println("Entrypoint:", project.Entrypoint)
		fmt.Println("Port:", project.Port)

		if len(project.Dependencies) > 0 {
			fmt.Println("Detected imports:", strings.Join(project.Dependencies, ", "))
		} else {
			fmt.Println("Detected imports: none")
		}

	case "run":

		// Parse --isolated flag
		isolated := false
		for _, arg := range os.Args[2:] {
			if arg == "--isolated" {
				isolated = true
			}
		}

		result, err := scanner.ScanRepo(".")
		if err != nil {
			fmt.Println("Scan failed:", err)
			return
		}

		project, err := detector.DetectFramework(result)
		if err != nil {
			fmt.Println("Detection failed:", err)
			return
		}

		if isolated {
			fmt.Println("=== Running in Isolated Sandbox ===")
		} else {
			fmt.Println("=== Running Application ===")
		}

		err = python.Run(project, result, isolated)
		if err != nil {
			fmt.Println("Run failed:", err)
			return
		}

	default:
		fmt.Println("Unknown command:", command)
		printUsage()
	}

}

func printUsage() {
	fmt.Println("Usage: sandbox-engine <command>")
	fmt.Println()
	fmt.Println("Commands:")
	fmt.Println("  scan              Scan project for Python files, entrypoints, and dependencies")
	fmt.Println("  detect            Detect framework, imports, and configuration")
	fmt.Println("  run               Run application with managed venv and dependencies")
	fmt.Println("  run --isolated    Run in an isolated sandbox (destroyed on exit)")
}