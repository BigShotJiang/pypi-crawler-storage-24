"""Sherpa sentence chunking processor"""

__version__ = "0.6.12"
