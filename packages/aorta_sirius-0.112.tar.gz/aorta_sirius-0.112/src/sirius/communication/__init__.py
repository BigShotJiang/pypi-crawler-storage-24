from typing import Dict, Any

from sentry_sdk import logger as sentry_logger

from sirius import common
from sirius.common import DataClass


class Logger(DataClass):
    module_name: str

    def _set_data(self, data: Dict[Any, Any] | None = None) -> None:
        data = data if data else {}
        data.update(self.model_dump())
        data["application_name"] = common.get_application_name()

    def trace(self, message: str, data: Dict[Any, Any] | None = None) -> None:
        self._set_data(data)
        sentry_logger.trace(message, attributes=data)

    def debug(self, message: str, data: Dict[Any, Any] | None = None) -> None:
        self._set_data(data)
        sentry_logger.debug(message, attributes=data)

    def info(self, message: str, data: Dict[Any, Any] | None = None) -> None:
        self._set_data(data)
        sentry_logger.info(message, attributes=data)

    def warning(self, message: str, data: Dict[Any, Any] | None = None) -> None:
        self._set_data(data)
        sentry_logger.warning(message, attributes=data)

    def error(self, message: str, data: Dict[Any, Any] | None = None) -> None:
        self._set_data(data)
        sentry_logger.error(message, attributes=data)

    def fatal(self, message: str, data: Dict[Any, Any] | None = None) -> None:
        self._set_data(data)
        sentry_logger.fatal(message, attributes=data)
