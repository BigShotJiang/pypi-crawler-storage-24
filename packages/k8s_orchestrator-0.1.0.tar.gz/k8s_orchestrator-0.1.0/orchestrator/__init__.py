"""
Service Orchestration Framework for infra-client.

A framework for building scheduled tasks and stream processors with built-in
lifecycle management, metrics, and monitoring.

Quick Start:
    from orchestrator import ProcessManager, Service, ScheduledService

    # 1. Define your service names
    class MyServiceName(StrEnum):
        DATA_FETCHER = "my_data_fetcher"

    # 2. Define your business services (system services auto-included)
    SERVICES = (
        Service.Identity(
            service_name=MyServiceName.DATA_FETCHER,
            service_category=Service.Enums.Category.BUSINESS,
            execution_type=Service.Enums.ExecutionType.SCHEDULED,
            description="Fetches data from external API",
            cron_schedule="0 */6 * * *",
            module_path="my_project.services.data_fetcher",
        ),
    )

    # 3. Implement your service (with entry point)
    class DataFetcher(ScheduledService):
        def __init__(self):
            super().__init__(MyServiceName.DATA_FETCHER)

        def execute(self):
            # Your business logic
            pass

    if __name__ == "__main__":
        import json, sys
        DataFetcher.start(json.loads(sys.argv[1]))

    # 4. Run the orchestrator
    ProcessManager(
        env="dev",
        project_name="my_project",
        business_services=SERVICES,
    ).run()  # Blocks until interrupted

For more details, see the individual module docstrings.
"""

# =============================================================================
# Public API
# =============================================================================

# Configuration & startup
from .config import OrchestratorConfig, get_project_config
from .manager import ProcessManager
from .cli import ProjectCLI, cron_to_expected_hours

# The Service namespace (access all types via Service.*)
from .services import Service

# Service base classes
from .base import InvalidTaskError
from .scheduled import ScheduledService
from .stream import StreamService
from .table_output import TableOutputMixin, get_db_with_schema

# =============================================================================
# Extended API - For testing and advanced use cases
# =============================================================================

# Database models
from .models import Base

# Registry (pre-defined service identities via Service.Registry)
from .services import SystemRegistry

# Kafka buses and messages
from .kafka import command_bus
from .messages import Message

# Structured log events
from .events import Event

# Logging with composable contexts
from .loggers import (
    log,
    LogContext,
    ServiceContext,
    StageContext,
    BatchContext,
    TaskContext,
    get_context,
)

# System services
from .system_services.scheduler import Scheduler

# Failure reasons (for error handling)
from .constants import FailureReason

# =============================================================================
# Public API
# =============================================================================
__all__ = [
    # --- Core ---
    "OrchestratorConfig",
    "get_project_config",
    "ProcessManager",
    "ProjectCLI",
    "cron_to_expected_hours",
    "Service",
    "ScheduledService",
    "StreamService",
    "TableOutputMixin",
    "get_db_with_schema",
    # --- Logging ---
    "log",
    "LogContext",
    "ServiceContext",
    "StageContext",
    "BatchContext",
    "TaskContext",
    "get_context",
    # --- Extended ---
    "Base",
    "command_bus",
    "Event",
    "FailureReason",
    "Message",
    "Scheduler",
    "SystemRegistry",
]
