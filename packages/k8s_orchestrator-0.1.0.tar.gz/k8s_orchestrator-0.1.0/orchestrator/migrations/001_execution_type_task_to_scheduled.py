"""
Migration: Rename execution_type from 'task' to 'scheduled'.

This migration updates existing database records to use the new
'scheduled' value instead of the deprecated 'task' value.

Run manually:
    python -m orchestrator.migrations.001_execution_type_task_to_scheduled

Or import and call:
    from orchestrator.migrations.001_execution_type_task_to_scheduled import migrate
    migrate()
"""

from ..models import get_db_session


def migrate() -> int:
    """
    Update execution_type='task' to 'scheduled' in services table.

    Returns:
        Number of rows updated
    """
    with get_db_session() as db:
        result = db.execute(
            """
            UPDATE services
            SET execution_type = 'scheduled'
            WHERE execution_type = 'task'
            """
        )
        count = result.rowcount
        print(f"Updated {count} rows: execution_type 'task' -> 'scheduled'")
        return count


def check() -> int:
    """Check how many rows have the old 'task' value."""
    with get_db_session() as db:
        result = db.execute(
            "SELECT COUNT(*) FROM services WHERE execution_type = 'task'"
        )
        count = result.scalar()
        print(f"Found {count} rows with execution_type='task'")
        return count


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        check()
    else:
        migrate()
