"""
Process Manager - Orchestrates service processes.

The main entry point for running an orchestrator project. Handles all setup
(environment, logging, database, registry) and spawns services as subprocesses.

Usage:
    from orchestrator import ProcessManager

    ProcessManager(
        env="dev",
        project_name="my_project",
        business_services=SERVICES,
        infra_services=("postgresql", "redis", "kafka"),
    ).run()
"""

import json
import os
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Dict, Optional, Tuple, Literal

from .loggers import log as _log

Env = Literal["dev", "test", "prod"]

from .events import Event
from .kafka import clear_topics as clear_kafka_topics

# Bind logger name for API compatibility
log = _log.bind()

if TYPE_CHECKING:
    from .services import Service


@dataclass
class ProcessInfo:
    """Information about a managed process."""

    name: str
    module_path: str
    process: Optional[subprocess.Popen] = None
    started_at: Optional[datetime] = None
    exit_code: Optional[int] = None


class ProcessManager:
    """
    Orchestrates service processes for a project.

    Spawns services as independent subprocesses and handles graceful shutdown.
    Does NOT handle respawning - in production, use Kubernetes or similar for that.

    Services self-register via Service.Table.bootstrap() in their __init__.
    InfraMonitor receives infrastructure component names as command line args.

    Args:
        env: Environment (dev, test, prod). Required.
        project_name: Project identifier (e.g., "my_project"). Also used as
                     the PostgreSQL database name.
        business_services: Tuple of Service.Identity for business services
        infra_services: Tuple of component names to monitor (e.g., "postgresql", "kafka").
                       Must be valid names from InfraServiceName.

    Example:
        ProcessManager(
            env="dev",
            project_name="my_project",
            business_services=SERVICES,
            infra_services=("postgresql", "redis", "kafka"),
        ).run()
    """

    def __init__(
        self,
        project_name: str,
        business_services: Tuple["Service.Identity", ...],
        infra_services: Tuple[str, ...] = (),
        env: Optional[Env] = None,
    ) -> None:
        self._project_name = project_name
        self._business_services = business_services
        self._infra_services = infra_services
        self._env = env

        self._processes: Dict[str, ProcessInfo] = {}
        self._running = False
        self._shutdown_requested = False

        # Generate shared session_id for all processes
        import uuid
        ts = datetime.now().strftime("%y%m%d-%H%M%S")
        self._session_id = f"{ts}-{str(uuid.uuid4())[:4]}"

        # Configure orchestrator (logging, database, Kafka topics)
        from .config import OrchestratorConfig
        OrchestratorConfig(project_name=project_name, env=env, session_id=self._session_id)

        clear_kafka_topics()

        # Initialize database schema and tables
        from .services import Service
        Service.Table.init_db()

    def run(self) -> None:
        """
        Run the orchestrator. Spawns services with module_path and monitors them.
        Services self-register via their __init__. Blocks until SIGTERM/SIGINT.
        """
        from .services import Service

        # Collect all services with module_path (system + business)
        all_identities = (*Service.Registry.System.all(), *self._business_services)
        for identity in all_identities:
            if identity.module_path:
                name = str(identity.service_name)
                self._processes[name] = ProcessInfo(
                    name=name,
                    module_path=identity.module_path,
                )

        if not self._processes:
            event = Event.Status.run_skipped(reason="no_services")
            log.warning(event.name, **event.fields())
            return

        # Set up signal handlers and start monitoring loop
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

        self._running = True
        event = Event.Service.manager_started(self._project_name, list(self._processes.keys()))
        log.info(event.name, **event.fields())

        try:
            # Spawn all services
            for info in self._processes.values():
                self._spawn_service(info)
                time.sleep(0.5)  # Stagger spawns to avoid OOM

            while self._running and not self._shutdown_requested:
                self._check_processes()
                time.sleep(1.0)

        finally:
            self._shutdown()

    def _spawn_service(self, info: ProcessInfo) -> bool:
        """Spawn a single service process."""
        try:
            # Build config dict for subprocess (includes shared session_id)
            config = {
                "env": self._env,
                "project_name": self._project_name,
                "session_id": self._session_id,
            }

            # For InfraMonitor, include infrastructure service names
            if info.name == "infra_monitor" and self._infra_services:
                config["infra_services"] = list(self._infra_services)

            cmd = [sys.executable, "-u", "-m", info.module_path, json.dumps(config)]

            # Temporarily capture output for debugging
            log_file = open(f"/tmp/orch_svc_{info.name}.log", "w")
            proc = subprocess.Popen(
                cmd,
                stdout=log_file,
                stderr=log_file,
                env={**os.environ, "PYTHONUNBUFFERED": "1"},
            )
            info.process = proc
            info.started_at = datetime.now()
            event = Event.Service.spawned(info.name, proc.pid)
            log.info(event.name, **event.fields())
            return True
        except Exception as e:
            event = Event.Error.spawn_failed(info.name, str(e))
            log.error(event.name, **event.fields())
            return False

    def _check_processes(self) -> None:
        """Check for exited processes and log them."""
        for name, info in self._processes.items():
            if info.process is None:
                continue

            exit_code = info.process.poll()
            if exit_code is None:
                continue

            # Process has exited
            info.exit_code = exit_code
            info.process = None

            event = Event.Service.exited(name, exit_code)
            if exit_code == 0:
                log.info(event.name, **event.fields())
            else:
                # Service crashed - the service itself logs the traceback via log.exception()
                log.error(event.name, **event.fields())

    def _handle_signal(self, signum: int, _frame) -> None:
        """Handle shutdown signals."""
        sig_name = signal.Signals(signum).name
        event = Event.Shutdown.signal_received(sig_name)
        log.info(event.name, **event.fields())
        self._shutdown_requested = True
        self._running = False

    def _shutdown(self) -> None:
        """Gracefully shutdown all services via KILL commands, then terminate processes."""
        from .constants import FailureReason
        from .system_services.scheduler import Scheduler

        event = Event.Shutdown.services_stopping(len(self._processes))
        log.info(event.name, **event.fields())

        # Step 1: Send KILL commands to all services via Kafka
        # This triggers graceful shutdown - services set stop_requested=True
        kill_count = Scheduler.kill_all_services(reason=FailureReason.MANUAL)
        if kill_count > 0:
            event = Event.Command.sent("KILL", count=kill_count)
            log.debug(event.name, **event.fields())

        # Step 2: Wait for LifecycleManager to process the graceful shutdowns
        # LifecycleManager will set status to IDLE for services with stop_requested=True
        time.sleep(2)

        # Step 3: Terminate all subprocesses (they should have exited already)
        for name, info in self._processes.items():
            if info.process and info.process.poll() is None:
                event = Event.Service.terminating(name, info.process.pid)
                log.debug(event.name, **event.fields())
                info.process.terminate()

        # Step 4: Wait for processes to exit, force kill if needed
        for name, info in self._processes.items():
            if info.process:
                try:
                    info.process.wait(timeout=5)
                    event = Event.Service.terminated(name)
                    log.debug(event.name, **event.fields())
                except subprocess.TimeoutExpired:
                    event = Event.Service.terminated(name, force=True)
                    log.warning(event.name, **event.fields())
                    info.process.kill()
                    info.process.wait()

        event = Event.Shutdown.all_stopped()
        log.info(event.name, **event.fields())

    @property
    def services(self) -> list[str]:
        """Get list of managed service names."""
        return list(self._processes.keys())
