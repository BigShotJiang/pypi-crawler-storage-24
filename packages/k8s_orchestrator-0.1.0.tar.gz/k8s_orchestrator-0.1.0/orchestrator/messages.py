"""
Messages - Kafka message contracts for cross-service communication.

This module provides Pydantic models for messages sent over Kafka:
- Heartbeat: Service status updates
- StaleDetected: Service went stale (no heartbeat)
- CrashDetected: Service crashed repeatedly
- ServiceDeletion: Request to delete services

Usage:
    from orchestrator import Message

    # Create messages
    heartbeat = Message.Heartbeat(service_id=..., status=...)
    stale = Message.StaleDetected(service_id=..., reason=...)

    # Deserialize from Kafka
    msg = Message.deserialize(kafka_message)

CONTRACTS: Changes to message schemas may break Kafka consumers.
"""

from datetime import datetime, timezone
from enum import StrEnum
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, computed_field, field_serializer, field_validator

from .services import Service


# =============================================================================
# Message Type Enum
# =============================================================================


class MessageType(StrEnum):
    """All Kafka message types."""

    HEARTBEAT = "heartbeat"
    STALE_DETECTED = "stale_detected"
    CRASH_DETECTED = "crash_detected"
    SERVICE_DELETION = "service_deletion"


# =============================================================================
# Message Classes
# =============================================================================


class BaseMessage(BaseModel):
    """Base class for all Kafka messages."""

    model_config = ConfigDict(populate_by_name=True)

    message_type: MessageType
    service_id: str  # Required - UUID of the service
    trace_id: str = ""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Unique message ID for record_task compatibility
    id: str = Field(default_factory=lambda: str(uuid4()))

    # Alias for backwards compatibility during migration
    @property
    def event_type(self) -> MessageType:
        return self.message_type

    @computed_field
    @property
    def description(self) -> str:
        """Task description for record_task compatibility. Uses message_type."""
        return f"processing message of type {self.message_type.value}"


class HeartbeatMessage(BaseMessage):
    """Service heartbeat with operational status and optional payload."""

    message_type: MessageType = MessageType.HEARTBEAT
    status: Optional[Service.Enums.Status] = None
    payload: Optional[Dict[str, Any]] = None  # Optional metadata (metrics, errors, etc.)

    @field_serializer("status")
    def serialize_status(self, v: Optional[Service.Enums.Status]) -> Optional[str]:
        """Serialize Service.Enums.Status to string for JSON."""
        if v is None:
            return None
        return v.value if isinstance(v, Service.Enums.Status) else str(v)

    @field_validator("status", mode="before")
    @classmethod
    def parse_status(cls, v: Any) -> Optional[Service.Enums.Status]:
        """Parse status from string to Service.Enums.Status enum."""
        if v is None:
            return None
        if isinstance(v, Service.Enums.Status):
            return v
        if isinstance(v, str):
            # Try member name first (IDLE), then value (idle)
            if v.upper() in Service.Enums.Status.__members__:
                return Service.Enums.Status[v.upper()]
            return Service.Enums.Status(v)
        raise ValueError(f"Invalid status type: {type(v)}")

    @field_validator("payload", mode="before")
    @classmethod
    def validate_payload(cls, v: Any) -> Optional[Dict[str, Any]]:
        """Validate payload structure if provided."""
        if v is None:
            return v
        return v


class StaleDetectedMessage(BaseMessage):
    """Service went stale (no heartbeat). Ready for restart."""

    message_type: MessageType = MessageType.STALE_DETECTED
    reason: str = ""


class CrashDetectedMessage(BaseMessage):
    """Service crashed repeatedly. Terminal state requiring intervention."""

    message_type: MessageType = MessageType.CRASH_DETECTED
    reason: str = ""


class ServiceDeletionMessage(BaseModel):
    """Request to delete services and deregister their metrics.

    Emitted by pruner, handled by LifecycleManager which:
    1. Sets service_registered=0 for each ID (pushed to Mimir)
    2. Deletes the services from DB
    """

    model_config = ConfigDict(populate_by_name=True)

    message_type: MessageType = MessageType.SERVICE_DELETION
    service_ids: List[str]  # List of service UUIDs to delete
    reason: str = ""  # "test" or "stale"

    # Alias for backwards compatibility
    @property
    def event_type(self) -> MessageType:
        return self.message_type


# =============================================================================
# Type Aliases
# =============================================================================

KafkaMessage = Union[
    HeartbeatMessage,
    StaleDetectedMessage,
    CrashDetectedMessage,
    ServiceDeletionMessage,
]


# =============================================================================
# Deserialization
# =============================================================================

_MESSAGE_TYPE_MAP: Dict[MessageType, type] = {
    MessageType.HEARTBEAT: HeartbeatMessage,
    MessageType.STALE_DETECTED: StaleDetectedMessage,
    MessageType.CRASH_DETECTED: CrashDetectedMessage,
    MessageType.SERVICE_DELETION: ServiceDeletionMessage,
}


def deserialize_message(data: Dict[str, Any]) -> KafkaMessage:
    """Deserialize a Kafka message dict into a typed message.
    
    Supports both 'message_type' and legacy 'event_type' field names.
    """
    # Support both new 'message_type' and legacy 'event_type'
    msg_type_str = data.get("message_type") or data.get("event_type")
    if msg_type_str not in _MESSAGE_TYPE_MAP:
        raise ValueError(f"Unknown message_type: {msg_type_str}")
    return _MESSAGE_TYPE_MAP[msg_type_str].model_validate(data)


# =============================================================================
# Message Namespace
# =============================================================================


class Message:
    """
    Namespace for Kafka messages (cross-service communication).

    Usage:
        from orchestrator import Message

        # Create messages
        heartbeat = Message.Heartbeat(service_id=..., status=...)
        stale = Message.StaleDetected(service_id=..., reason=...)
        
        # Deserialize from Kafka
        msg = Message.deserialize(kafka_data)

    For logging events, use the events module:
        from orchestrator.events import ServiceEvent, TaskEvent
    """

    # Message type enum
    Type = MessageType

    # Message classes
    Heartbeat = HeartbeatMessage
    StaleDetected = StaleDetectedMessage
    CrashDetected = CrashDetectedMessage
    ServiceDeletion = ServiceDeletionMessage

    # Type alias for all messages
    Any = KafkaMessage

    # Utilities
    deserialize = staticmethod(deserialize_message)
