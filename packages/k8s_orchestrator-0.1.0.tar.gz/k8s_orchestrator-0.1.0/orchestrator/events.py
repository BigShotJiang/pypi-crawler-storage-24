"""
Events - Structured log events for local observability.

This module provides dataclass-based events for structured logging.
Events define the event name and expected fields, caller decides log level.

Usage:
    from orchestrator.events import ServiceEvent, TaskEvent, BatchEvent

    # Create event, log with decoupled logger
    event = ServiceEvent.started(execution_type="scheduled")
    self._logger.info(event.name, **event.fields())

    # Task processing (works for both scheduled and stream)
    event = TaskEvent(name="task_processed", task_id="123", result=Result.ok("Fetch data: completed"))
    level = "info" if event.is_success else "warning"
    getattr(self._logger, level)(event.name, **event.fields())

For Kafka messages (cross-service communication), use:
    from orchestrator import Message
    Message.Heartbeat, Message.StaleDetected, etc.
"""

from dataclasses import dataclass, asdict
from typing import Any, ClassVar, Dict, List, Optional


# =============================================================================
# Base
# =============================================================================


@dataclass
class BaseEvent:
    """Base class for all log events."""

    # Class variable: event category for Loki filtering
    event_type: ClassVar[str] = "unknown"

    name: str

    def fields(self) -> Dict[str, Any]:
        """Return fields for logging (excludes 'name', excludes None values)."""
        result = {k: v for k, v in asdict(self).items()
                  if k != "name" and v is not None}
        result["event_type"] = self.__class__.event_type
        return result


# =============================================================================
# Result Type
# =============================================================================


@dataclass(frozen=True, slots=True)
class Result:
    """Unified result type for task, batch, and service operations.

    Provides a consistent way to return success/failure status with context.

    Usage:
        def on_step(self, task: dict) -> Result:
            try:
                process(task)
                return Result.ok()
            except TimeoutError as e:
                return Result.fail(f"Timeout processing {task['id']}: {e}")

        # Check result
        result = service.on_step(task)
        if result:  # Works due to __bool__
            print("Success:", result.message)
        else:
            print("Failed:", result.message)
    """

    success: bool
    message: str = ""

    @classmethod
    def ok(cls, message: str = "") -> "Result":
        """Create a successful result."""
        return cls(success=True, message=message)

    @classmethod
    def fail(cls, message: str) -> "Result":
        """Create a failed result with a reason."""
        return cls(success=False, message=message)

    def __bool__(self) -> bool:
        """Allow using result in boolean context."""
        return self.success

    def __repr__(self) -> str:
        status = "ok" if self.success else "fail"
        if self.message:
            return f"Result.{status}({self.message!r})"
        return f"Result.{status}()"


# =============================================================================
# Service Lifecycle Events
# =============================================================================


@dataclass
class ServiceEvent(BaseEvent):
    """Service lifecycle events."""

    event_type: ClassVar[str] = "service"

    message: str = ""
    duration_ms: Optional[float] = None
    execution_type: Optional[str] = None
    error: Optional[str] = None
    service_name: Optional[str] = None
    pid: Optional[int] = None
    exit_code: Optional[int] = None
    project: Optional[str] = None
    services: Optional[List[str]] = None

    @classmethod
    def started(cls, execution_type: str, message: str = "") -> "ServiceEvent":
        msg = message or f"Starting {execution_type} service"
        return cls(name="service_started", message=msg, execution_type=execution_type)

    @classmethod
    def completed(cls, duration_ms: float, message: str = "") -> "ServiceEvent":
        msg = message or "Service completed successfully"
        return cls(name="service_completed", message=msg,
                   duration_ms=round(duration_ms, 1))

    @classmethod
    def failed(cls, error: str, duration_ms: float = None,
               message: str = "") -> "ServiceEvent":
        msg = message or error
        return cls(name="service_failed", message=msg, error=error,
                   duration_ms=round(duration_ms, 1) if duration_ms else None)

    @classmethod
    def stopped(cls, message: str = "") -> "ServiceEvent":
        return cls(name="service_stopped", message=message or "Service stopped")

    @classmethod
    def spawned(cls, service_name: str, pid: int) -> "ServiceEvent":
        return cls(name="service_spawned", service_name=service_name, pid=pid,
                   message=f"Spawned {service_name} (pid={pid})")

    @classmethod
    def exited(cls, service_name: str, exit_code: int = None, error: str = None) -> "ServiceEvent":
        if exit_code == 0 or exit_code is None:
            return cls(name="service_exited", service_name=service_name,
                       message=f"{service_name} exited cleanly")
        return cls(name="service_crashed", service_name=service_name, exit_code=exit_code,
                   error=error, message=f"{service_name} crashed with code {exit_code}")

    @classmethod
    def terminating(cls, service_name: str, pid: int) -> "ServiceEvent":
        return cls(name="service_terminating", service_name=service_name, pid=pid,
                   message=f"Terminating {service_name} (pid={pid})")

    @classmethod
    def terminated(cls, service_name: str, force: bool = False) -> "ServiceEvent":
        if force:
            return cls(name="service_killed", service_name=service_name,
                       message=f"{service_name} required SIGKILL")
        return cls(name="service_terminated", service_name=service_name,
                   message=f"{service_name} terminated gracefully")

    @classmethod
    def manager_started(cls, project: str, services: List[str]) -> "ServiceEvent":
        return cls(name="process_manager_starting", project=project, services=services,
                   message=f"Starting {len(services)} services")


# =============================================================================
# Batch Events
# =============================================================================


@dataclass
class BatchEvent(BaseEvent):
    """Batch processing events."""

    event_type: ClassVar[str] = "batch"

    message: str = ""
    task_count: Optional[int] = None
    task_success: Optional[int] = None
    task_failed: Optional[int] = None
    duration_ms: Optional[float] = None
    wait_ms: Optional[float] = None
    result: Optional[str] = None  # "success" | "failure"
    current: Optional[int] = None  # for interrupted
    total: Optional[int] = None  # for interrupted

    @classmethod
    def started(cls, task_count: int, wait_ms: float = None) -> "BatchEvent":
        return cls(
            name="batch_started",
            message=f"Starting batch with {task_count} tasks",
            task_count=task_count,
            wait_ms=wait_ms,
        )

    @classmethod
    def completed(cls, *, duration_ms: float, task_count: int,
                  task_success: int, task_failed: int, success: bool) -> "BatchEvent":
        result = "success" if success else "failure"
        msg = "Batch completed successfully" if success else "Batch failed"
        return cls(
            name="batch_completed",
            message=msg,
            result=result,
            duration_ms=round(duration_ms, 1),
            task_count=task_count,
            task_success=task_success,
            task_failed=task_failed,
        )

    @classmethod
    def interrupted(cls, current: int, total: int) -> "BatchEvent":
        return cls(
            name="batch_interrupted",
            message=f"Stop requested at task {current}/{total}",
            current=current,
            total=total,
        )

    @property
    def is_success(self) -> bool:
        return self.result == "success"


# =============================================================================
# Task Events
# =============================================================================


@dataclass
class TaskEvent(BaseEvent):
    """Individual task events - shared by scheduled and stream services.

    The result field contains a Result object with:
    - success: bool indicating pass/fail
    - message: combined task description and outcome (e.g., "Fetch users: completed")
    """

    event_type: ClassVar[str] = "task"

    task_id: str = ""
    result: Optional[Result] = None
    idx: Optional[int] = None  # 1-based task index within batch

    def fields(self) -> Dict[str, Any]:
        """Return fields for logging, serializing Result properly."""
        data = {"task_id": self.task_id, "event_type": self.__class__.event_type}
        if self.result is not None:
            data["success"] = self.result.success
            data["message"] = self.result.message
        if self.idx is not None:
            data["idx"] = self.idx
        return data

    @property
    def is_success(self) -> bool:
        return self.result.success if self.result else False


# =============================================================================
# Command Events
# =============================================================================


@dataclass
class CommandEvent(BaseEvent):
    """Command bus events."""

    event_type: ClassVar[str] = "command"

    command: Optional[str] = None
    service_id: Optional[str] = None
    trace_id: Optional[str] = None
    trigger: Optional[str] = None  # "kill", "signal", "keyboard"
    reason: Optional[str] = None
    signal: Optional[str] = None
    count: Optional[int] = None

    @classmethod
    def received(cls, command: str) -> "CommandEvent":
        return cls(name="command_received", command=command)

    @classmethod
    def sent(cls, command: str, service_id: str = None, trace_id: str = None,
             count: int = None) -> "CommandEvent":
        return cls(name="command_sent", command=command,
                   service_id=service_id, trace_id=trace_id, count=count)

    @classmethod
    def unknown(cls, command: str) -> "CommandEvent":
        return cls(name="command_unknown", command=command)

    @classmethod
    def listener_started(cls) -> "CommandEvent":
        return cls(name="command_listener_started")


# =============================================================================
# Shutdown Events
# =============================================================================


@dataclass
class ShutdownEvent(BaseEvent):
    """Shutdown-related events."""

    event_type: ClassVar[str] = "shutdown"

    message: str = ""
    trigger: Optional[str] = None  # "kill", "signal", "keyboard"
    reason: Optional[str] = None
    signal: Optional[str] = None
    graceful: Optional[bool] = None
    count: Optional[int] = None

    @classmethod
    def requested(cls, trigger: str, reason: str = None,
                  signal: str = None) -> "ShutdownEvent":
        return cls(name="shutdown_requested", trigger=trigger,
                   reason=reason, signal=signal)

    @classmethod
    def started(cls, graceful: bool) -> "ShutdownEvent":
        return cls(name="shutdown_started", graceful=graceful)

    @classmethod
    def timeout(cls, message: str) -> "ShutdownEvent":
        return cls(name="shutdown_timeout", message=message)

    @classmethod
    def signal_received(cls, signal: str) -> "ShutdownEvent":
        return cls(name="shutdown_signal_received", signal=signal)

    @classmethod
    def services_stopping(cls, count: int) -> "ShutdownEvent":
        return cls(name="shutting_down_services", count=count)

    @classmethod
    def all_stopped(cls) -> "ShutdownEvent":
        return cls(name="all_services_stopped")


# =============================================================================
# Error Events
# =============================================================================


@dataclass
class ErrorEvent(BaseEvent):
    """Error events."""

    event_type: ClassVar[str] = "error"

    message: str = ""
    error: Optional[str] = None
    service_name: Optional[str] = None
    failed_dependency: Optional[str] = None

    @classmethod
    def spawn_failed(cls, service_name: str, error: str) -> "ErrorEvent":
        return cls(name="spawn_failed", service_name=service_name, error=error)

    @classmethod
    def consumer_failed(cls, topic: str, error: str) -> "ErrorEvent":
        return cls(name="consumer_failed", message=f"Failed to create consumer for {topic}",
                   error=error)

    @classmethod
    def heartbeat_error(cls, error: str) -> "ErrorEvent":
        return cls(name="heartbeat_error", error=error)

    @classmethod
    def kafka_error(cls, error: str) -> "ErrorEvent":
        return cls(name="kafka_error", error=error)

    @classmethod
    def dependency_failed(cls, failed_dependency: str) -> "ErrorEvent":
        return cls(name="dependency_failed", failed_dependency=failed_dependency)

    @classmethod
    def on_batch_end_error(cls, error: str) -> "ErrorEvent":
        return cls(name="on_batch_end_error", error=error)


# =============================================================================
# Status Events
# =============================================================================


@dataclass
class StatusEvent(BaseEvent):
    """Status change events."""

    event_type: ClassVar[str] = "status"

    from_status: Optional[str] = None
    to_status: Optional[str] = None
    status: Optional[str] = None
    reason: Optional[str] = None

    @classmethod
    def changed(cls, from_status: str, to_status: str) -> "StatusEvent":
        return cls(name="status_changed", from_status=from_status, to_status=to_status)

    @classmethod
    def run_skipped(cls, reason: str, **extra) -> "StatusEvent":
        event = cls(name="run_skipped", reason=reason)
        # Store extra fields for logging
        event._extra = extra
        return event

    @classmethod
    def stale_override(cls, status: str, reason: str) -> "StatusEvent":
        return cls(name="overriding_stale_status", status=status, reason=reason)

    def fields(self) -> Dict[str, Any]:
        """Return fields including any extra fields."""
        result = super().fields()
        if hasattr(self, "_extra"):
            result.update(self._extra)
        return result


# =============================================================================
# Event Namespace
# =============================================================================


class Event:
    """
    Namespace for structured log events.

    Usage:
        from orchestrator.events import Event

        # Create event, log with decoupled logger
        event = Event.Service.started(execution_type="scheduled")
        self._logger.info(event.name, **event.fields())

        # Task processing
        event = Event.Task.processed(task_id="123", message="...", success=True)
        level = "info" if event.is_success else "warning"
        getattr(self._logger, level)(event.name, **event.fields())

    For Kafka messages, use Message namespace:
        from orchestrator import Message
        Message.Heartbeat, Message.StaleDetected, etc.
    """

    Service = ServiceEvent
    Batch = BatchEvent
    Task = TaskEvent
    Command = CommandEvent
    Shutdown = ShutdownEvent
    Error = ErrorEvent
    Status = StatusEvent
