"""
Structured logging with contextual dimensions.

This module provides:
1. log - Global logger (from the logger module)
2. Specialized contexts that auto-bind relevant fields:
   - ServiceContext: service_id, service_name, service_category, logger
   - StageContext: stage
   - BatchContext: batch_id
   - TaskContext: task_id, task_idx

Contexts are composable - nest them to merge fields:

    with ServiceContext(identity):
        # All logs have service_id, service_name, service_category, logger
        with StageContext(Stage.RUN):
            # + stage
            with BatchContext(batch_id):
                # + batch_id
                with TaskContext(task_id, idx=0):
                    # + task_id, task_idx
                    log.info("processing")

Environment variables:
    LOG_FILTER="stage=run,service_name=scheduler"  # Include only matching
    LOG_EXCLUDE="service_name=noisy_service"  # Exclude matching
"""

from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

from .logger import log as _log, add_processor, get_context as _base_get_context

from .services import Service

# =============================================================================
# Re-exports from the logger module
# =============================================================================

# Logger (module-level singleton from the logger module)
log = _log

# Trace ID functions (for command correlation)
set_trace_id = _log.set_trace_id
clear_trace_id = _log.clear_trace_id

# Testing utility
LogCapture = _log.capture


# =============================================================================
# Orchestrator Log Processor - Ensures required fields
# =============================================================================


def _orchestrator_processor(logger, _method_name, event_dict):
    """
    Ensures required 'logger' field is present.

    Only uses context-bound 'logger' value, defaults to 'orchestrator'.
    Does NOT use event data fields like 'service_name' to avoid confusion
    when ProcessManager logs events about other services.
    """
    if "logger" not in event_dict:
        event_dict["logger"] = "orchestrator"
    return event_dict


add_processor(_orchestrator_processor)


# =============================================================================
# Composable Log Contexts
# =============================================================================


@contextmanager
def LogContext(**dims: Any) -> Generator[None, None, None]:
    """
    Generic context for binding arbitrary dimensions.

    Prefer specialized contexts (ServiceContext, StageContext, etc.) when applicable.
    """
    with _log.context(**dims):
        yield


@contextmanager
def ServiceContext(identity: Service.Identity) -> Generator[None, None, None]:
    """
    Bind service identity fields to all logs in scope.

    Adds: service_id, service_name, service_category
    Also includes any config keys listed in config["log_context"] list.
    """
    # Base context fields
    context_fields = {
        "service_id": str(identity.id),
        "service_name": identity.service_name,
        "service_category": str(identity.service_category),
    }

    # Add config fields specified in log_context list
    config = identity.config or {}
    log_context_keys = config.get("log_context", [])
    for key in log_context_keys:
        if key in config:
            context_fields[key] = config[key]

    with _log.context(**context_fields):
        yield


@contextmanager
def StageContext(stage: str) -> Generator[None, None, None]:
    """
    Bind execution stage to all logs in scope.

    Adds: stage
    """
    with _log.context(stage=stage):
        yield


@contextmanager
def BatchContext(batch_id: str) -> Generator[None, None, None]:
    """
    Bind batch identifier to all logs in scope.

    Adds: batch_id
    """
    with _log.context(batch_id=batch_id):
        yield


@contextmanager
def TaskContext(
    task_id: str,
    idx: Optional[int] = None,
) -> Generator[None, None, None]:
    """
    Bind task identifier to all logs in scope.

    Adds: task_id, task_idx (if provided)
    """
    dims = {"task_id": task_id}
    if idx is not None:
        dims["task_idx"] = idx
    with _log.context(**dims):
        yield


@contextmanager
def get_context(
    identity: Optional[Service.Identity] = None,
    stage: Optional[str] = None,
    batch_id: Optional[str] = None,
    task_id: Optional[str] = None,
    task_idx: Optional[int] = None,
    **extra,
) -> Generator[None, None, None]:
    """
    Create a merged context with multiple dimensions.

    Combines ServiceContext, StageContext, BatchContext, TaskContext as needed.
    More convenient than nesting multiple context managers.

    Uses the logger module.s get_context under the hood for None-filtering.

    Args:
        identity: Service identity (adds service_id, service_name, service_category, logger)
        stage: Execution stage (adds stage)
        batch_id: Batch identifier (adds batch_id)
        task_id: Task identifier (adds task_id)
        task_idx: Task index (adds task_idx)
        **extra: Additional dimensions to include

    Example:
        with get_context(identity=self._identity, stage=Stage.RUN, task_id="abc"):
            log.info("processing")  # Has all service + stage + task fields
    """
    # Build identity-derived fields
    identity_dims = {}
    if identity:
        identity_dims.update(
            service_id=str(identity.id),
            service_name=identity.service_name,
            service_category=str(identity.service_category),
        )

    # Use the logger module.s get_context for None-filtering
    with _base_get_context(
        **identity_dims,
        stage=stage,
        batch_id=batch_id,
        task_id=task_id,
        task_idx=task_idx,
        **extra,
    ):
        yield


def get_context_dims() -> Dict[str, Any]:
    """Get current context dimensions."""
    from .logger import get_log_context
    return get_log_context()
