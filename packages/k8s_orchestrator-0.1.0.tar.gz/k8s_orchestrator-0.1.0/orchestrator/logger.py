"""
Structured JSON logging with context binding and validation.

Log Flow:
    App -> stdout (JSON) + optional API push -> per-env API -> Alloy -> Loki

Usage:
    from orchestrator.logger import log, configure_logging

    configure_logging(app_name="my_service")

    # Basic logging with dimensions
    log.info("processing", phase="startup", items=10)

    # Context binding (auto-includes dimensions in all logs within scope)
    with log.context(stage="execute", service="scheduler"):
        log.info("step")  # Has stage + service
        with log.context(batch_id="abc123"):
            log.info("detail")  # Has stage + service + batch_id

    # Scoped validation (require dimensions exist)
    with log.require("task_id", "message"):
        log.info("step", task_id=123, message="foo")  # OK
        log.info("step")  # Raises RuntimeError - missing required dims

    # Global validation (applies everywhere)
    log.require_dimensions(["stage"])

    # Trace context (correlation IDs)
    with log.trace_context(service="my_service"):
        log.info("start")  # Has service + trace_id

    # Log capture for testing
    with log.capture() as logs:
        log.info("test", key="value")
    assert logs[0]["event"] == "test"

Field Filtering:
    add_filter("logger", ["run", "state"])
    add_exclude("logger", ["kafka"])
    clear_filters()

    # Or via env vars
    LOG_FILTER="logger=run,service=scheduler"
    LOG_EXCLUDE="logger=kafka"

Environment Variables:
    LOG_LEVEL: DEBUG, INFO, WARNING, ERROR (default: INFO)
    LOG_FILTER: Comma-separated field=value filters
    LOG_EXCLUDE: Comma-separated field=value exclusions
    LOG_API_URL: API endpoint for log pushes (optional, enables APIPushHandler)
"""

import logging
import os
import sys
import threading
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Callable, Dict, List, Optional, Set, Union

import structlog
from dotenv import load_dotenv

load_dotenv()

# =============================================================================
# Configuration
# =============================================================================

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_API_URL = os.getenv("LOG_API_URL", os.getenv("ENV_API_URL", ""))


# =============================================================================
# Session ID (unique per configure_logging call)
# =============================================================================

_session_id: Optional[str] = None


def get_session_id() -> Optional[str]:
    """Get the current session_id (set during configure_logging)."""
    return _session_id


# =============================================================================
# Trace Context (using contextvars for async/thread safety)
# =============================================================================

_trace_id_var: ContextVar[Optional[str]] = ContextVar("trace_id", default=None)
_service_var: ContextVar[Optional[str]] = ContextVar("service", default=None)


def get_trace_id() -> Optional[str]:
    """Get the current trace_id from context."""
    return _trace_id_var.get()


def set_trace_id(trace_id: str) -> None:
    """Set trace_id in context."""
    _trace_id_var.set(trace_id)


def clear_trace_id() -> None:
    """Clear trace_id from context."""
    _trace_id_var.set(None)


def get_service() -> Optional[str]:
    """Get the current service name from context."""
    return _service_var.get()


def set_service(service: str) -> None:
    """Set service name in context."""
    _service_var.set(service)


def clear_service() -> None:
    """Clear service name from context."""
    _service_var.set(None)


@contextmanager
def trace_context(
    service: str = None,
    trace_id: str = None,
):
    """
    Context manager for binding service and trace_id to all logs in scope.

    Args:
        service: Service name to bind to logs
        trace_id: Trace ID for correlation (auto-generated if not provided)

    Yields:
        The trace_id being used

    Example:
        with trace_context(service="my_service") as trace_id:
            log.info("start", logger="run")    # Has service + trace_id
            log.info("change", logger="state") # Has service + trace_id
    """
    if trace_id is None:
        trace_id = str(uuid.uuid4())[:8]

    old_trace_id = _trace_id_var.get()
    old_service = _service_var.get()

    _trace_id_var.set(trace_id)
    if service:
        _service_var.set(service)

    try:
        yield trace_id
    finally:
        _trace_id_var.set(old_trace_id)
        _service_var.set(old_service)


# =============================================================================
# Log Context - Dimension Binding and Validation
# =============================================================================

_log_context_dims: ContextVar[Dict[str, Any]] = ContextVar("log_context_dims", default={})
_required_dims: ContextVar[Set[str]] = ContextVar("required_dims", default=set())
_global_required_dims: Set[str] = set()


def get_log_context() -> Dict[str, Any]:
    """Get current log context dimensions."""
    return _log_context_dims.get().copy()


def get_required_dims() -> Set[str]:
    """Get current required dimensions (scoped + global)."""
    return _required_dims.get() | _global_required_dims


@contextmanager
def log_context(**dims: Any):
    """
    Context manager for binding dimensions to all logs in scope.

    Dimensions are inherited by nested contexts and merged (inner overrides outer).

    Args:
        **dims: Key-value pairs to bind to logs

    Example:
        with log_context(stage="execute", service="scheduler"):
            log.info("processing")  # Has stage + service
            with log_context(batch_id="abc123"):
                log.info("step")  # Has stage + service + batch_id
    """
    old_dims = _log_context_dims.get()
    new_dims = {**old_dims, **dims}

    token = _log_context_dims.set(new_dims)
    try:
        yield
    finally:
        _log_context_dims.reset(token)


@contextmanager
def get_context(**dims: Any):
    """
    Create a merged context with only non-None dimensions.

    Unlike log_context(), this filters out None values, making it convenient
    when building contexts from optional parameters.

    Args:
        **dims: Key-value pairs to bind (None values are filtered out)

    Example:
        # These are equivalent:
        with get_context(service="my_service", stage=stage, batch_id=None):
            log.info("event")  # Has service + stage (batch_id filtered out)

        # Convenient when combining optional parameters:
        def process(task_id=None, batch_id=None):
            with get_context(task_id=task_id, batch_id=batch_id):
                log.info("processing")  # Only includes non-None values
    """
    filtered = {k: v for k, v in dims.items() if v is not None}
    with log_context(**filtered):
        yield


@contextmanager
def require_context(*keys: str):
    """
    Context manager for requiring dimensions in all logs within scope.

    Requirements are inherited by nested contexts and merged.
    Logs missing required dimensions will raise RuntimeError.

    Args:
        *keys: Dimension names that must be present in logs

    Example:
        with require_context("id", "message"):
            log.info("step", id=123, message="foo")  # OK
            log.info("step", id=123)  # Raises RuntimeError - missing "message"
    """
    old_required = _required_dims.get()
    new_required = old_required | set(keys)

    token = _required_dims.set(new_required)
    try:
        yield
    finally:
        _required_dims.reset(token)


def require_dimensions(keys: List[str]) -> None:
    """
    Set global required dimensions (applies to all logs).

    Args:
        keys: Dimension names that must be present in all logs

    Example:
        require_dimensions(["stage"])  # All logs must have "stage"
    """
    global _global_required_dims
    _global_required_dims = set(keys)


def clear_required_dimensions() -> None:
    """Clear global required dimensions."""
    global _global_required_dims
    _global_required_dims = set()


def _validate_required_dims(event_dict: Dict[str, Any]) -> None:
    """
    Validate that all required dimensions are present.

    Raises RuntimeError if any required dimension is missing.
    """
    required = get_required_dims()
    if not required:
        return

    missing = required - set(event_dict.keys())
    if missing:
        event = event_dict.get("event", "unknown")
        raise RuntimeError(
            f"Log missing required dimensions: {missing}. "
            f"Event: '{event}', got: {set(event_dict.keys())}"
        )


# =============================================================================
# Custom Processors - Extensibility Interface
# =============================================================================

_custom_processors: List[callable] = []


def add_processor(processor: callable) -> None:
    """
    Register a custom processor to run on all log entries.

    Processors are functions with signature:
        def my_processor(logger, method_name, event_dict) -> dict

    They are called after built-in processors (session_id, trace_context)
    but before rendering. Use to add project-specific fields.

    Args:
        processor: A structlog-compatible processor function

    Example:
        def add_service_info(logger, method_name, event_dict):
            event_dict.setdefault("logger", "myapp")
            event_dict.setdefault("service", get_current_service())
            return event_dict

        add_processor(add_service_info)
    """
    if processor not in _custom_processors:
        _custom_processors.append(processor)


def remove_processor(processor: callable) -> None:
    """Remove a previously registered custom processor."""
    if processor in _custom_processors:
        _custom_processors.remove(processor)


def clear_processors() -> None:
    """Clear all custom processors."""
    _custom_processors.clear()


def _apply_custom_processors(logger, method_name, event_dict):
    """Apply all registered custom processors."""
    for processor in _custom_processors:
        event_dict = processor(logger, method_name, event_dict)
    return event_dict


# =============================================================================
# Log Capture (Testing Utility)
# =============================================================================

_log_capture: ContextVar[Optional[List[Dict[str, Any]]]] = ContextVar(
    "log_capture", default=None
)
_global_log_capture: Optional[List[Dict[str, Any]]] = None
_global_capture_lock = threading.Lock()


@contextmanager
def log_capture(global_mode: bool = False):
    """
    Context manager for capturing logs during testing.

    Captures all logs emitted within the context scope.

    Args:
        global_mode: If True, use global capture (works across threads).
                     If False (default), use thread-local contextvar.

    Example:
        with log_capture() as logs:
            log.info("test", key="value")
        assert logs[0]["event"] == "test"
        assert logs[0]["key"] == "value"
    """
    global _global_log_capture

    if global_mode:
        captured: List[Dict[str, Any]] = []
        with _global_capture_lock:
            _global_log_capture = captured
        try:
            yield captured
        finally:
            with _global_capture_lock:
                _global_log_capture = None
    else:
        captured = []
        token = _log_capture.set(captured)
        try:
            yield captured
        finally:
            _log_capture.reset(token)


def _capture_log(level: str, event: str, **kwargs) -> None:
    """Capture log to active capture contexts."""
    global _global_log_capture

    entry = {"level": level, "event": event, **kwargs}

    # Thread-local capture
    capture = _log_capture.get()
    if capture is not None:
        capture.append(entry)

    # Global capture
    if _global_log_capture is not None:
        with _global_capture_lock:
            if _global_log_capture is not None:
                _global_log_capture.append(entry)


# =============================================================================
# Field-Based Filtering
# =============================================================================

_filters: Dict[str, Set[str]] = {}
_excludes: Dict[str, Set[str]] = {}


def _parse_filter_string(filter_str: str) -> Dict[str, Set[str]]:
    """
    Parse a filter string like "field1=val1,field1=val2,field2=val3".

    Returns dict mapping field -> set of values.
    """
    result: Dict[str, Set[str]] = {}
    if not filter_str:
        return result

    for part in filter_str.split(","):
        part = part.strip()
        if "=" not in part:
            continue
        field, value = part.split("=", 1)
        field = field.strip()
        value = value.strip()
        if field and value:
            if field not in result:
                result[field] = set()
            result[field].add(value)

    return result


def add_filter(field: str, values: Union[str, List[str], Set[str], None]) -> None:
    """
    Add a filter for a specific log field.

    Only logs where the field value is in the allowed set will be emitted.
    Multiple filters are AND-ed together.

    Args:
        field: Log field name (e.g., "logger", "service", "phase")
        values: Allowed values (string, list, set) or None to clear this filter

    Examples:
        add_filter("logger", ["run", "state"])
        add_filter("service", ["scheduler"])
        add_filter("logger", None)  # Clear
    """
    if values is None:
        _filters.pop(field, None)
        return

    if isinstance(values, str):
        if "," in values:
            values = {v.strip() for v in values.split(",") if v.strip()}
        else:
            values = {values}
    else:
        values = set(values)

    _filters[field] = values


def add_exclude(field: str, values: Union[str, List[str], Set[str], None]) -> None:
    """
    Add an exclusion for a specific log field.

    Logs where the field value is in the excluded set will be dropped.

    Args:
        field: Log field name
        values: Values to exclude, or None to clear

    Examples:
        add_exclude("logger", ["kafka", "urllib3"])
    """
    if values is None:
        _excludes.pop(field, None)
        return

    if isinstance(values, str):
        if "," in values:
            values = {v.strip() for v in values.split(",") if v.strip()}
        else:
            values = {values}
    else:
        values = set(values)

    _excludes[field] = values


def clear_filter(field: str) -> None:
    """Clear filter for a specific field."""
    _filters.pop(field, None)


def clear_exclude(field: str) -> None:
    """Clear exclusion for a specific field."""
    _excludes.pop(field, None)


def clear_filters() -> None:
    """Clear all filters and exclusions."""
    _filters.clear()
    _excludes.clear()


def get_filters() -> Dict[str, Set[str]]:
    """Get current active filters."""
    return {k: v.copy() for k, v in _filters.items()}


def get_excludes() -> Dict[str, Set[str]]:
    """Get current active exclusions."""
    return {k: v.copy() for k, v in _excludes.items()}


# =============================================================================
# Validation Hook
# =============================================================================

# Validation hook that projects can register
# Signature: (event_dict: dict) -> dict
# Can raise RuntimeError to block logging
_validation_hook: Optional[callable] = None


def set_validation_hook(hook: Optional[callable]) -> None:
    """
    Register a validation hook that's called before each log.

    The hook receives the event dict and can:
    - Return it unchanged (allow logging)
    - Modify and return it (add/change fields)
    - Raise RuntimeError to block logging

    Args:
        hook: Callable that takes event_dict and returns event_dict,
              or None to clear the hook

    Example:
        def require_path(event_dict):
            if "path" not in event_dict:
                raise RuntimeError("Logging without path context")
            return event_dict

        set_validation_hook(require_path)
    """
    global _validation_hook
    _validation_hook = hook


def get_validation_hook() -> Optional[callable]:
    """Get the current validation hook (for testing)."""
    return _validation_hook


# =============================================================================
# Structlog Processors
# =============================================================================


def _apply_validation_hook(logger, method_name, event_dict):
    """Apply validation hook if registered."""
    if _validation_hook is not None:
        return _validation_hook(event_dict)
    return event_dict


def _add_session_id(logger, method_name, event_dict):
    """Add session_id to all logs."""
    if _session_id:
        event_dict["session_id"] = _session_id
    return event_dict


def _add_trace_context(logger, method_name, event_dict):
    """Add trace_id and service from context to logs."""
    trace_id = _trace_id_var.get()
    if trace_id:
        event_dict["trace_id"] = trace_id

    service = _service_var.get()
    if service:
        event_dict.setdefault("service", service)

    return event_dict


def _add_log_id(logger, method_name, event_dict):
    """Add unique log_id to each log entry for debugging."""
    event_dict["log_id"] = str(uuid.uuid4())[:8]
    return event_dict


def _apply_filters(logger, method_name, event_dict):
    """
    Drop logs that don't match active filters or match exclusions.

    Filter logic: log must match ALL active filters (AND).
    Exclude logic: log is dropped if it matches ANY exclusion (OR).
    """
    # Check exclusions first (faster rejection)
    for field, excluded_values in _excludes.items():
        value = event_dict.get(field)
        if value is not None and value in excluded_values:
            raise structlog.DropEvent

    # Check filters (must match all)
    for field, allowed_values in _filters.items():
        value = event_dict.get(field)
        if value is not None and value not in allowed_values:
            raise structlog.DropEvent

    return event_dict


# =============================================================================
# Public Configuration API
# =============================================================================

_configured = False


class LoggingAlreadyConfiguredError(Exception):
    """Raised when configure_logging is called more than once."""

    pass


def configure_logging(
    app_name: str,
    level: str = None,
    json_output: bool = True,
    filters: Dict[str, Union[List[str], Set[str], str]] = None,
    session_id: str = None,
) -> None:
    """
    Configure structured logging.

    Can only be called once per process.

    Args:
        app_name: Application name (used for API log routing)
        level: Log level override (default: LOG_LEVEL env var)
        json_output: JSON output (True) or pretty console (False)
        filters: Initial filters as dict, e.g., {"logger": ["run", "state"]}
        session_id: Optional session ID to use (for shared session across processes).
                   If not provided, a unique session_id is generated.
        Environment variables (parsed at startup):
        LOG_FILTER: "field=value,field=value" - include only matching logs
        LOG_EXCLUDE: "field=value,field=value" - exclude matching logs
        LOG_API_URL: API endpoint for log pushes (enables APIPushHandler)
        ENV_API_URL: Legacy alias for LOG_API_URL

    Raises:
        LoggingAlreadyConfiguredError: If already configured
    """
    global _configured, _session_id

    if _configured:
        raise LoggingAlreadyConfiguredError(
            "configure_logging() can only be called once per process."
        )

    # Use provided session_id if given
    if session_id:
        _session_id = session_id

    log_level = (level or LOG_LEVEL).upper()

    # Parse env var filters
    env_filter = os.getenv("LOG_FILTER", "")
    env_exclude = os.getenv("LOG_EXCLUDE", "")

    for field, values in _parse_filter_string(env_filter).items():
        add_filter(field, values)

    for field, values in _parse_filter_string(env_exclude).items():
        add_exclude(field, values)

    # Apply programmatic filters (override env vars)
    if filters:
        for field, values in filters.items():
            add_filter(field, values)

    # Generate unique session_id
    if _session_id is None:
        from datetime import datetime

        ts = datetime.now().strftime("%y%m%d-%H%M%S")
        _session_id = f"{ts}-{str(uuid.uuid4())[:4]}"

    processors = [
        structlog.stdlib.filter_by_level,
        _apply_filters,
        _apply_validation_hook,  # Apply validation after filters, before rendering
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        _add_session_id,
        _add_trace_context,
        _add_log_id,
        structlog.processors.CallsiteParameterAdder(
            parameters=[structlog.processors.CallsiteParameter.MODULE],
            additional_ignores=["orchestrator.logger"],
        ),
        _apply_custom_processors,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        (
            structlog.processors.JSONRenderer()
            if json_output
            else structlog.dev.ConsoleRenderer(pad_event_to=0)
        ),
    ]

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Configure root logger
    root = logging.getLogger()
    root.setLevel(getattr(logging, log_level))
    root.handlers = []

    # Stdout handler
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(getattr(logging, log_level))
    root.addHandler(stdout_handler)

    # Suppress noisy loggers
    for name in ["kafka", "urllib3", "requests"]:
        logging.getLogger(name).setLevel(logging.WARNING)

    _configured = True

    # Log session start
    _log_session_start()


def _log_session_start() -> None:
    """Log session start message."""
    saved_filters = _filters.copy()
    saved_excludes = _excludes.copy()
    clear_filters()

    logger = structlog.get_logger()
    logger.info(
        "session_start",
        logger="session",
        session_id=_session_id,
        filters=list(saved_filters.keys()) if saved_filters else None,
        excludes=list(saved_excludes.keys()) if saved_excludes else None,
    )

    # Restore filters
    for field, values in saved_filters.items():
        add_filter(field, values)
    for field, values in saved_excludes.items():
        add_exclude(field, values)


def is_configured() -> bool:
    """Check if logging has been configured."""
    return _configured


# =============================================================================
# Logger Wrapper with Context Integration
# =============================================================================


class Logger:
    """
    Structured logger with context integration.

    Automatically merges log_context dimensions into every log call.
    Validates required dimensions before logging.
    Supports log capture for testing.

    Usage:
        log.info("event", key="value")

        with log_context(stage="execute", service="scheduler"):
            log.info("processing")  # Auto-includes stage + service

        with require_context("task_id"):
            log.info("step", task_id=123)  # OK
            log.info("step")  # Raises RuntimeError
    """

    def __init__(self):
        # Bound context stored here, applied in _log
        self._bound_context: Dict[str, Any] = {}

    # -------------------------------------------------------------------------
    # Internal: Log with context merging, validation, and capture
    # -------------------------------------------------------------------------

    def _log(self, level: str, event: str, **kwargs) -> None:
        """Log with context dimensions, validation, and capture."""
        # Merge contexts: bound -> log_context -> explicit kwargs (later overrides)
        ctx_dims = get_log_context()
        merged = {**self._bound_context, **ctx_dims, **kwargs}

        # Validate required dimensions
        _validate_required_dims({"event": event, **merged})

        # Capture for testing
        _capture_log(level, event, **merged)

        # Get logger lazily to pick up configuration set after module load
        logger = structlog.get_logger()
        getattr(logger, level)(event, **merged)

    # -------------------------------------------------------------------------
    # Context Methods
    # -------------------------------------------------------------------------

    @property
    def context(self):
        """Get the log_context context manager."""
        return log_context


    @property
    def get_context(self):
        """Get the get_context context manager (filters None values)."""
        return get_context

    @property
    def require(self):
        """Get the require_context context manager."""
        return require_context

    def require_dimensions(self, keys: List[str]) -> None:
        """Set global required dimensions."""
        require_dimensions(keys)

    def clear_required_dimensions(self) -> None:
        """Clear global required dimensions."""
        clear_required_dimensions()

    # -------------------------------------------------------------------------
    # Trace Context Methods (for correlation IDs)
    # -------------------------------------------------------------------------

    def set_trace_id(self, trace_id: str) -> None:
        """Set trace_id in context."""
        set_trace_id(trace_id)

    def clear_trace_id(self) -> None:
        """Clear trace_id from context."""
        clear_trace_id()

    def get_trace_id(self) -> Optional[str]:
        """Get current trace_id from context."""
        return get_trace_id()

    @property
    def trace_context(self):
        """Get the trace_context context manager."""
        return trace_context

    def set_validation_hook(self, hook: Optional[Callable]) -> None:
        """Register a validation hook for logging."""
        set_validation_hook(hook)

    # -------------------------------------------------------------------------
    # Logging Methods
    # -------------------------------------------------------------------------

    def bind(self, **kwargs):
        """Return a new logger with bound context."""
        new_logger = Logger()
        new_logger._bound_context = {**self._bound_context, **kwargs}
        return new_logger

    def unbind(self, *keys):
        """Return a new logger without specified keys."""
        new_logger = Logger()
        new_logger._bound_context = {
            k: v for k, v in self._bound_context.items() if k not in keys
        }
        return new_logger

    def debug(self, event: str, **kwargs) -> None:
        """Log debug message."""
        self._log("debug", event, **kwargs)

    def info(self, event: str, **kwargs) -> None:
        """Log info message."""
        self._log("info", event, **kwargs)

    def warning(self, event: str, **kwargs) -> None:
        """Log warning message."""
        self._log("warning", event, **kwargs)

    def error(self, event: str, **kwargs) -> None:
        """Log error message."""
        self._log("error", event, **kwargs)

    def exception(self, event: str, **kwargs) -> None:
        """Log exception with traceback."""
        self._log("exception", event, **kwargs)

    def critical(self, event: str, **kwargs) -> None:
        """Log critical message."""
        self._log("critical", event, **kwargs)

    # Aliases
    warn = warning
    fatal = critical

    # -------------------------------------------------------------------------
    # Capture (for testing)
    # -------------------------------------------------------------------------

    @property
    def capture(self):
        """Get the log_capture context manager for testing."""
        return log_capture


# Single logger instance - use this everywhere
# log.info("event", logger="run", service="scheduler", phase="startup")
log = Logger()
