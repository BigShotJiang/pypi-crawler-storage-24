"""
ScheduledService - Service that runs scheduled tasks to completion.

Implement:
- get_tasks(): Return list of tasks to process
- on_step(task): Process one task

Optional hooks (inherited from ServiceBase):
- on_batch_start(): Called when batch starts
- on_batch_end(): Called when batch ends (always called, even on error)
"""

import time
from typing import Iterable

from .base import ServiceBase
from .constants import Constants
from .events import Result
from .services import Service

# Stage shortcut
Stage = Constants.Stage


class ScheduledService(ServiceBase):
    """
    Service that runs scheduled tasks to completion.

    Basic usage:

        class MyService(ScheduledService):
            def get_tasks(self):
                # Each task MUST have 'id' and 'description' fields
                return [
                    {"id": f"user-{u.id}", "description": f"Sync user {u.name}", "user": u}
                    for u in User.query.all()
                ]

            def on_step(self, task):
                sync_user_to_external(task["user"])

    With batch hooks:

        class UserSyncService(ScheduledService):
            def get_tasks(self):
                return [{"id": "1", "description": "sync"}]

            def on_step(self, task):
                self.conn.send(task)

            def on_batch_start(self):
                self.conn = create_connection()

            def on_batch_end(self):
                self.conn.close()

    Failure threshold:

        class StrictService(ScheduledService):
            max_failure_ratio = 0.1  # Fail batch if >10% of tasks fail

            def on_step(self, task):
                # Return False to mark as failed (or raise exception)
                if not process(task):
                    return False
                return True
    """

    # Maximum allowed failure ratio (0.0 to 1.0). Batch fails immediately when exceeded.
    # Default 1.0 means batch never fails due to task failures (only exceptions fail it).
    max_failure_ratio: float = 1.0

    def __init__(self, identity: Service.Identity) -> None:
        """Initialize the task service."""
        super().__init__(identity)

    # =========================================================================
    # User API - Override these
    # =========================================================================

    def get_tasks(self) -> Iterable[dict]:
        """
        Return tasks to process.

        Each task MUST be a dict with:
            - id: Unique identifier for the task (str)
            - description: Human-readable description (str)
            - ... any additional fields needed by on_step()

        Raises:
            InvalidTaskError: If any task is missing 'id' or 'description' field.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_tasks()"
        )

    def on_step(self, task: dict) -> Result:
        """
        Process one task.

        Args:
            task: Dict with 'id' and 'description' fields, plus any custom data.

        Returns:
            Result: Use Result.ok() for success, Result.fail("reason") for failure.

        Example:
            def on_step(self, task: dict) -> Result:
                try:
                    process(task["data"])
                    return Result.ok()
                except ValueError as e:
                    return Result.fail(f"Invalid data: {e}")
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement on_step()"
        )

    def on_start(self) -> None:
        """Called once before task execution starts. Override for setup logic."""
        pass

    # =========================================================================
    # Framework - Don't override
    # =========================================================================

    def _execute(self) -> None:
        """Execute all tasks from get_tasks() using on_step()."""
        # Call on_start hook for subclass initialization
        self.on_start()

        task_list = list(self.get_tasks())
        total = len(task_list)

        with self._batch_context(task_count=total) as batch:
            with self._log_context(Stage.EXECUTE):
                for i, task in enumerate(task_list):
                    if self.stop_requested:
                        self._logger.info(
                            "batch_interrupted",
                            message=f"Stop requested at task {i}/{total}",
                            current=i,
                            total=total,
                        )
                        break

                    # Check dependencies periodically (rate-limited)
                    if not self.check_dependencies():
                        break  # Dependency failed, stop processing

                    # Execute task with timing and record result
                    task_start = time.time()
                    task_result: Result = Result.ok()
                    try:
                        task_result = self.on_step(task)
                    except Exception as e:
                        task_result = Result.fail(str(e))
                        raise  # Exceptions still fail batch immediately
                    finally:
                        duration_ms = (time.time() - task_start) * 1000
                        batch.record_task(
                            task=task,
                            result=task_result,
                            duration_ms=duration_ms,
                            idx=i + 1,
                        )

                    # Check failure threshold after each task
                    self._check_failure_threshold()

                    # Pulse with batch progress (rate-limited)
                    self.pulse(Service.Enums.Status.PROCESSING)
