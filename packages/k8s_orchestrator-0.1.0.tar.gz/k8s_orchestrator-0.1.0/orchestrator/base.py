"""
ServiceBase - Abstract base class for all services.

Provides:
- Command listening and execution
- Lifecycle management (start, stop, signals)
- Heartbeat/pulse emission (via HeartbeatManager)
- Batch tracking (via BatchManager)
- Dependency checking (via DependencyChecker)

Subclasses should use one of the specialized types:
- ScheduledService: For scheduled tasks (single-step or multi-step)
- StreamService: For continuous message processing
"""

import os
import signal
import threading
import time
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Generator, Optional, Set

import psutil

from .config import get_project_config
from .constants import BatchFailedError, Constants, FailureReason
from .events import Event, Result
from .messages import Message
from .kafka import command_bus, event_bus
from .loggers import log, LogContext, ServiceContext, StageContext, set_trace_id, clear_trace_id
from .models import get_db_session
from .services import Service


# =============================================================================
# Exceptions
# =============================================================================


class ServiceAlreadyRunningError(Exception):
    """Raised when attempting to start a service that is already running.

    This typically means another orchestrator process is running, or the previous
    one was killed with SIGKILL (bypassing normal shutdown cleanup).
    """

    def __init__(self, service_name: str, status: str, pid: int = None):
        self.service_name = service_name
        self.status = status
        self.pid = pid

        msg = (
            f"Service '{service_name}' is already running (status={status}).\n\n"
            "This can happen if:\n"
            "  1. Another orchestrator process is running - stop it first\n"
            "  2. Previous orchestrator was killed with SIGKILL (bypassing cleanup)\n\n"
            "Solutions:\n"
            "  - Stop the existing orchestrator (Ctrl+C or SIGTERM)\n"
            "  - Wait for LifecycleManager to detect stale heartbeats and mark as failed\n"
        )
        if pid:
            msg += f"  - Kill specific process: kill {pid}\n"
        super().__init__(msg)


class InvalidTaskError(Exception):
    """Raised when a task is missing required fields (id, description).

    Includes a Result object for consistent error handling.
    """

    def __init__(self, idx: int, field: str, task: any):
        self.idx = idx
        self.field = field
        self.task = task
        self._message = (
            f"Task {idx} missing required '{field}' field. "
            f"Tasks must be dicts with 'id' and 'description' keys. Got: {task!r}"
        )
        super().__init__(self._message)

    @property
    def result(self) -> Result:
        """Return a Result.fail() for this validation error."""
        return Result.fail(self._message)


# =============================================================================
# Manager: BatchState
# =============================================================================


@dataclass
class BatchState:
    """In-memory batch state for tracking progress and metrics."""

    start_time: float = field(default_factory=time.time)
    task_count: int = 0  # Total items (known upfront for tasks, dynamic for streams)
    current_idx: int = 0  # Current progress (0-indexed)
    task_success: int = 0  # Count of successful tasks
    task_failed: int = 0  # Count of failed tasks
    longest_task_duration_ms: float = 0.0  # Duration of slowest task

    @property
    def progress(self) -> float:
        """Return progress ratio (0.0 to 1.0)."""
        if self.task_count == 0:
            return 0.0
        return min(self.current_idx / self.task_count, 1.0)

    @property
    def duration_ms(self) -> float:
        """Return elapsed time since batch started in milliseconds."""
        return (time.time() - self.start_time) * 1000


# =============================================================================
# Manager: DependencyChecker
# =============================================================================


class DependencyChecker:
    """
    Monitors service dependencies and triggers failure when dependencies fail.

    Rate-limits checks to avoid excessive DB queries. When a dependency fails,
    calls the provided failure callback to mark the service as failed.
    """

    def __init__(
        self,
        dependencies: tuple[str, ...],
        on_failure: Callable[[str], None],
    ):
        self._dependencies = set(dependencies) if dependencies else set()
        self._on_failure = on_failure
        self._last_check_time: float = 0

    @property
    def has_dependencies(self) -> bool:
        """Check if this service has any dependencies."""
        return len(self._dependencies) > 0

    def _should_check(self) -> bool:
        """Check if enough time has passed to check dependencies again."""
        if not self._dependencies:
            return False

        now = time.time()
        config = get_project_config()
        if now - self._last_check_time >= config.observability_interval:
            self._last_check_time = now
            return True
        return False

    def get_failed_dependencies(self) -> Set[str]:
        """Get set of dependency names that are currently FAILED."""
        if not self._dependencies:
            return set()

        failed = set()
        for svc in Service.Table.query():
            if svc.service_name in self._dependencies:
                if svc.status == Service.Enums.Status.FAILED.value:
                    failed.add(svc.service_name)

        return failed

    def check(self, force: bool = False) -> bool:
        """
        Check if dependencies are healthy.

        Rate-limited unless force=True. If a dependency has failed,
        calls the on_failure callback and returns False.

        Returns:
            True if dependencies are healthy (or not time to check)
            False if a dependency has failed
        """
        if not force and not self._should_check():
            return True  # Not time to check yet, assume healthy

        failed_deps = self.get_failed_dependencies()
        if failed_deps:
            failed_dep = next(iter(failed_deps))
            self._on_failure(failed_dep)
            return False

        return True


# =============================================================================
# Manager: BatchManager
# =============================================================================


class BatchManager:
    """
    Manages batch lifecycle and task metrics.

    Tracks batch progress, success/failure counts, and emits completion
    metrics via HeartbeatManager.
    """

    def __init__(
        self,
        heartbeat: "HeartbeatManager",
        get_resource_metrics: Callable[[], Dict[str, Any]],
        logger,
        log_context: Callable,
    ):
        self._heartbeat = heartbeat
        self._get_resource_metrics = get_resource_metrics
        self._logger = logger
        self._log_context = log_context
        self._batch: Optional[BatchState] = None

    @property
    def active(self) -> bool:
        """Check if a batch is currently active."""
        return self._batch is not None

    @property
    def state(self) -> Optional[BatchState]:
        """Get current batch state."""
        return self._batch

    @property
    def task_success(self) -> int:
        """Get successful task count."""
        return self._batch.task_success if self._batch else 0

    @property
    def task_failed(self) -> int:
        """Get failed task count."""
        return self._batch.task_failed if self._batch else 0

    def start(self, task_count: int = 0, wait_ms: float = None) -> None:
        """Start a new batch with optional known task count."""
        self._batch = BatchState(task_count=task_count)

        with self._log_context(Stage.RUN):
            event = Event.Batch.started(task_count=task_count, wait_ms=wait_ms)
            self._logger.info(event.name, **event.fields())

        payload = {
            "type": Constants.BatchProgress.TYPE,
            "progress": 0.0,
            "task_count": task_count,
            "current_idx": 0,
            **self._get_resource_metrics(),
        }
        if wait_ms is not None:
            payload["wait_ms"] = wait_ms
        self._heartbeat.pulse(Service.Enums.Status.PROCESSING, payload=payload)

    def end(self, status: str = "success") -> None:
        """End the current batch and emit completion metrics."""
        if not self._batch:
            return

        duration_ms = self._batch.duration_ms
        task_count = self._batch.task_count

        with self._log_context(Stage.RUN):
            success = status != "failed"
            event = Event.Batch.completed(
                duration_ms=duration_ms,
                task_count=task_count,
                task_success=self._batch.task_success,
                task_failed=self._batch.task_failed,
                success=success,
            )
            level = "info" if event.is_success else "warning"
            getattr(self._logger, level)(event.name, **event.fields())

        self._heartbeat.pulse(
            Service.Enums.Status.PROCESSING,
            payload=Constants.BatchComplete(
                duration_ms=duration_ms,
                task_count=task_count,
                task_success=self._batch.task_success,
                task_failed=self._batch.task_failed,
                longest_task_duration_ms=self._batch.longest_task_duration_ms,
                status=status,
            ).to_payload(),
        )

        self._batch = None

    def record_task(
        self,
        *,
        task: dict,
        result: Result,
        duration_ms: float,
        idx: int = None,
    ) -> None:
        """Record a task result and log completion.

        Validates task has required 'id' and 'description' fields, then combines
        the task description with the result message for logging.

        Args:
            task: Task dict with 'id' and 'description' fields
            result: Result object from on_step()
            duration_ms: Task duration in milliseconds
            idx: Current task index (1-based)

        Raises:
            InvalidTaskError: If task is missing required fields.
        """
        if not self._batch:
            raise RuntimeError("record_task called without active batch")

        # Validate task has required fields
        if not isinstance(task, dict):
            raise InvalidTaskError(idx or 0, "id", task)
        if "id" not in task:
            raise InvalidTaskError(idx or 0, "id", task)
        if "description" not in task:
            raise InvalidTaskError(idx or 0, "description", task)

        task_id = str(task["id"])
        description = str(task["description"])

        # Combine task description with result message
        message = f"{description}: {result.message}" if result.message else description

        # Update batch counters and progress
        if result.success:
            self._batch.task_success += 1
        else:
            self._batch.task_failed += 1
        if duration_ms > self._batch.longest_task_duration_ms:
            self._batch.longest_task_duration_ms = duration_ms
        if idx is not None:
            self._batch.current_idx = idx

        # Log task completion
        with self._log_context(Stage.RUN):
            event = Event.Task(
                name="task_processed",
                task_id=task_id,
                result=Result(success=result.success, message=message),
                idx=idx,
            )
            level = "info" if event.is_success else "warning"
            getattr(self._logger, level)(event.name, **event.fields())


# =============================================================================
# Manager: HeartbeatManager
# =============================================================================


class HeartbeatManager:
    """
    Handles heartbeat/pulse emission with rate limiting.

    Rate-limits same-status pulses to avoid flooding the event bus.
    Status changes and explicit payloads bypass rate limiting.
    """

    def __init__(
        self,
        service_id: str,
        identity: Service.Identity,
        logger,
        log_context: Callable,
        get_resource_metrics: Callable[[], Dict[str, Any]],
        get_batch_state: Callable[[], Optional[BatchState]],
    ):
        self._service_id = service_id
        self._identity = identity
        self._logger = logger
        self._log_context = log_context
        self._get_resource_metrics = get_resource_metrics
        self._get_batch_state = get_batch_state

        self._last_status: Optional[Service.Enums.Status] = None
        self._last_pulse_time: float = 0

    @property
    def last_status(self) -> Optional[Service.Enums.Status]:
        """Get the last pulsed status."""
        return self._last_status

    def pulse(
        self,
        status: Service.Enums.Status,
        payload: Optional[dict] = None,
    ) -> bool:
        """
        Send a heartbeat event for this service.

        Rate-limits same-status pulses. Status changes bypass rate limiting.

        Returns:
            True if pulse was sent, False if rate-limited
        """
        now = time.time()
        config = get_project_config()

        has_explicit_payload = payload is not None
        status_changed = status != self._last_status
        rate_limit_elapsed = (now - self._last_pulse_time) >= config.pulse_rate

        if not has_explicit_payload and not status_changed and not rate_limit_elapsed:
            return False  # Rate limited

        with self._log_context(Stage.RUN):
            if status_changed and self._last_status is not None:
                event = Event.Status.changed(
                    from_status=self._last_status.value,
                    to_status=status.value,
                )
                self._logger.debug(event.name, **event.fields())

            self._last_status = status
            self._last_pulse_time = now

            if payload is None and status == Service.Enums.Status.PROCESSING:
                batch = self._get_batch_state()
                if batch:
                    metrics = self._get_resource_metrics()
                    payload = {
                        "type": Constants.BatchProgress.TYPE,
                        "progress": round(batch.progress, 3),
                        "task_count": batch.task_count,
                        "current_idx": batch.current_idx,
                        **metrics,
                    }

            heartbeat = Message.Heartbeat(
                service_id=self._service_id,
                status=status,
                payload=payload,
            )

            try:
                event_bus.publish(heartbeat)
                return True
            except Exception as e:
                event = Event.Error.heartbeat_error(error=str(e))
                self._logger.warning(event.name, **event.fields())
                return False


# =============================================================================
# ServiceBase
# =============================================================================


# Stage shortcut
Stage = Constants.Stage


class ServiceBase(ABC):
    """
    Base class for all services.

    Subclasses should use one of the specialized types:
    - ScheduledService: For scheduled tasks (single-step or multi-step)
    - StreamService: For continuous message processing
    """

    # Set to True for services that self-start (e.g., Scheduler)
    auto_start: bool = False

    # =========================================================================
    # Class Methods
    # =========================================================================

    @classmethod
    def start(cls, config: dict) -> None:
        """
        Start listening for commands to run this service.

        This is the main entry point. Handles all setup:
        1. Configures logging and orchestrator
        2. Creates instance (which self-registers via Service.Table.bootstrap)
        3. Listens for commands

        Any uncaught exceptions are logged before the process exits.
        """
        from .config import OrchestratorConfig

        OrchestratorConfig(
            env=config["env"],
            project_name=config["project_name"],
            session_id=config.get("session_id"),  # Shared session from ProcessManager
        )

        try:
            service = cls()
            service._listen_to_commands(auto_start=cls.auto_start)
        except Exception:
            # Log the full traceback to Loki before crashing
            from infra_client import Infra
            log = Infra().logger
            log.exception("service_crashed", service_class=cls.__name__)
            raise

    # =========================================================================
    # Initialization
    # =========================================================================

    def __init__(self, identity: Service.Identity):
        if not identity:
            raise ValueError(
                f"{self.__class__.__name__} must provide identity (ServiceIdentity)"
            )

        self._identity: Service.Identity = identity
        self._logger = log
        self._start_time: Optional[float] = None
        self._config: Dict[str, Any] = {}
        self._trace_id: str = ""

        # Resource monitoring
        self._process = psutil.Process(os.getpid())
        self._net_baseline: Optional[tuple] = None

        # Stop signaling via thread-safe event
        self._stop_event = threading.Event()

        # Command listener state
        self._running = False
        self._subscription = None
        self._service_thread: Optional[threading.Thread] = None
        self._graceful_shutdown = False
        self._kill_reason: Optional[str] = None

        # Signal handlers for graceful shutdown (only in main thread)
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGTERM, self._handle_signal)
            signal.signal(signal.SIGINT, self._handle_signal)

        # Initialize managers
        self._heartbeat = HeartbeatManager(
            service_id=str(identity.id),
            identity=identity,
            logger=self._logger,
            log_context=self._log_context,
            get_resource_metrics=self._get_resource_metrics,
            get_batch_state=lambda: self._batch.state if self._batch else None,
        )

        self._batch = BatchManager(
            heartbeat=self._heartbeat,
            get_resource_metrics=self._get_resource_metrics,
            logger=self._logger,
            log_context=self._log_context,
        )

        self._deps = DependencyChecker(
            dependencies=identity.dependencies,
            on_failure=self._fail_for_dependency,
        )

        # Check for duplicate/stale instances at startup
        self._check_not_already_running()

    # =========================================================================
    # Logging Helpers
    # =========================================================================

    def _log_context(self, stage: str, **extra) -> StageContext:
        """Create a StageContext (service context should already be active)."""
        if extra:
            # If extra dims provided, use LogContext to merge them
            return LogContext(stage=stage, **extra)
        return StageContext(stage)

    # =========================================================================
    # Command Listener
    # =========================================================================

    def _listen_to_commands(self, auto_start: bool = False) -> None:
        """Listen for and execute scheduler commands (RUN/KILL)."""
        # Wrap entire service lifecycle in ServiceContext for consistent logging
        with ServiceContext(self._identity):
            self._running = True
            self._subscription = command_bus.subscribe(
                str(self._identity.id), self._handle_command
            )
            # Warm-up poll to initialize consumer BEFORE auto_start sends commands
            # Without this, commands sent during auto_start are missed because the
            # consumer offset isn't established until the first poll in the loop
            self._subscription.poll(timeout_ms=100)

            with self._log_context(Stage.INIT):
                event = Event.Command.listener_started()
                self._logger.info(event.name, **event.fields())

            try:
                if auto_start:
                    with self._lifecycle() as ready:
                        if ready:
                            self._execute()

                while self._running:
                    self._subscription.poll(timeout_ms=1000)
                    # Pulse IDLE only when no worker is running
                    # (worker thread pulses LISTENING/PROCESSING while active)
                    if not (self._service_thread and self._service_thread.is_alive()):
                        self.pulse(Service.Enums.Status.IDLE)
            except KeyboardInterrupt:
                with self._log_context(Stage.INIT):
                    event = Event.Shutdown.requested(trigger="keyboard")
                    self._logger.info(event.name, **event.fields())
            finally:
                self._shutdown()

    def _check_not_already_running(self) -> None:
        """Check that this service is not already running in another process.

        Uses heartbeat freshness to distinguish between:
        - Truly running service (fresh heartbeat) -> block startup
        - Crashed/stale service (old heartbeat) -> allow startup
        """
        with ServiceContext(self._identity), self._log_context(Stage.INIT):
            services = Service.Table.query(name=self._identity.service_name)
            svc = services[0] if services else None

            if svc and svc.is_stale:
                # Active status but stale heartbeat = crashed process, allow start
                event = Event.Status.stale_override(status=svc.status, reason="heartbeat_stale")
                self._logger.warning(event.name, **event.fields())
                return

            if svc and svc.status_enum and svc.status_enum.is_active:
                raise ServiceAlreadyRunningError(
                    service_name=self._identity.service_name,
                    status=svc.status,
                )

    def _shutdown(self) -> None:
        """Clean up resources and handle graceful shutdown."""
        with self._log_context(Stage.INIT):
            event = Event.Shutdown.started(graceful=self._graceful_shutdown)
            self._logger.debug(event.name, **event.fields())

            if self._graceful_shutdown:
                self._stop_event.set()

                thread = self._service_thread
                if thread and thread.is_alive():
                    thread.join(timeout=10)
                    if thread.is_alive():
                        event = Event.Shutdown.timeout("Worker thread did not stop")
                        self._logger.warning(event.name, **event.fields())

                reason = self._kill_reason or "signal"
                with get_db_session() as db:
                    svc = db.query(Service.Table).filter_by(id=self._identity.id).first()
                    if svc:
                        svc.stop_requested = True
                        svc.stop_reason = reason

            if self._subscription:
                self._subscription.stop()
                self._subscription = None

            event = Event.Service.stopped()
            self._logger.info(event.name, **event.fields())

    def _handle_command(self, cmd: Constants.Command) -> None:
        """Handle a command from the bus."""
        set_trace_id(cmd.trace_id)

        services = Service.Table.query(name=self._identity.service_name)
        svc = services[0] if services else None

        try:
            with self._log_context(Stage.INIT):
                event = Event.Command.received(cmd.command)
                self._logger.info(event.name, **event.fields())

                if cmd.command == Constants.Command.RUN:
                    self._spawn_worker(cmd, svc, force=False)
                elif cmd.command == Constants.Command.RUN_NOW:
                    self._spawn_worker(cmd, svc, force=True)
                elif cmd.command == Constants.Command.KILL:
                    event = Event.Shutdown.requested(trigger="kill", reason=cmd.reason)
                    self._logger.info(event.name, **event.fields())
                    self._kill_reason = cmd.reason
                    self._graceful_shutdown = True
                    self._running = False
                else:
                    event = Event.Command.unknown(cmd.command)
                    self._logger.warning(event.name, **event.fields())

        finally:
            clear_trace_id()

    def _spawn_worker(self, cmd: Constants.Command, svc, *, force: bool = False) -> None:
        """Execute a run command in a separate thread.

        Safety checks:
        - Thread check: Skip if already running (accurate local state)
        - Schedule check: Skip if not yet due (unless force=True)

        DB status is intentionally not checked here - it's updated asynchronously
        and may be stale. The thread check is sufficient for in-process safety.
        """
        if self._service_thread and self._service_thread.is_alive():
            # Already running - skip immediately, don't wait
            # Next scheduled run will try again
            event = Event.Status.run_skipped(reason="already_running")
            self._logger.debug(event.name, **event.fields())
            return

        if not force and svc and svc.next_run_at and svc.next_run_at > datetime.now(timezone.utc):
            event = Event.Status.run_skipped(reason="not_scheduled", next_run_at=str(svc.next_run_at))
            self._logger.debug(event.name, **event.fields())
            return

        self._stop_event.clear()

        def run_in_thread() -> None:
            try:
                # ServiceContext is thread-local, must be set in worker thread
                with ServiceContext(self._identity):
                    with self._lifecycle() as ready:
                        if ready:
                            self._execute()
            except Exception as e:
                # Log error if _lifecycle didn't already handle it
                self._logger.error(
                    "worker_thread_error",
                    error=str(e),
                    error_type=type(e).__name__,
                )
            finally:
                self._service_thread = None

        self._service_thread = threading.Thread(target=run_in_thread, daemon=True)
        self._service_thread.start()

    def _handle_signal(self, signum, _frame) -> None:
        """Handle shutdown signal (SIGTERM, SIGINT)."""
        with self._log_context(Stage.INIT):
            sig_name = signal.Signals(signum).name
            event = Event.Shutdown.requested(trigger="signal", signal=sig_name)
            self._logger.info(event.name, **event.fields())
            self._graceful_shutdown = True
            self._running = False

    # =========================================================================
    # Public API
    # =========================================================================

    @property
    def stop_requested(self) -> bool:
        """Check if stop has been requested via thread-safe event."""
        return self._stop_event.is_set()

    def request_stop(self) -> None:
        """Request the service to stop gracefully."""
        self._stop_event.set()

    def get_config(self) -> Dict[str, Any]:
        """Get merged service configuration."""
        return self._config

    # =========================================================================
    # Resource Monitoring
    # =========================================================================

    def _get_resource_metrics(self) -> Dict[str, Any]:
        """Get current resource metrics for this process."""
        try:
            cpu_percent = self._process.cpu_percent()
            memory_bytes = self._process.memory_info().rss

            kb_sent, kb_recv = 0, 0
            if self._net_baseline:
                net = psutil.net_io_counters()
                kb_sent = (net.bytes_sent - self._net_baseline[0]) // 1024
                kb_recv = (net.bytes_recv - self._net_baseline[1]) // 1024

            return {
                "cpu_percent": round(cpu_percent, 1),
                "memory_bytes": memory_bytes,
                "kb_sent": kb_sent,
                "kb_recv": kb_recv,
            }
        except Exception:
            return {}

    # =========================================================================
    # Heartbeat (delegates to HeartbeatManager)
    # =========================================================================

    def pulse(
        self,
        status: Service.Enums.Status,
        payload: Optional[dict] = None,
    ) -> bool:
        """Send a heartbeat event for this service."""
        return self._heartbeat.pulse(status, payload)

    @property
    def _last_pulse_status(self) -> Optional[Service.Enums.Status]:
        """Get the last pulsed status (for _finalize check)."""
        return self._heartbeat.last_status

    # =========================================================================
    # Batch Management
    # =========================================================================

    def on_batch_start(self) -> None:
        """Called when a batch starts. Override for batch setup."""
        pass

    def on_batch_end(self) -> None:
        """Called when a batch ends (even on error). Override for batch cleanup."""
        pass

    @contextmanager
    def _batch_context(self, task_count: int = 0, wait_ms: float = None):
        """Context manager for batch lifecycle.

        Usage:
            with self._batch_context(task_count=10) as batch:
                for task in tasks:
                    # process task
                    batch.record_task(
                        task=task,  # must have 'id' and 'description' keys
                        result=Result.ok(),
                        duration_ms=100,
                    )

        Calls on_batch_start on entry and on_batch_end on exit.
        """
        self._batch.start(task_count=task_count, wait_ms=wait_ms)
        self.on_batch_start()

        success = True
        try:
            yield self._batch
        except Exception:
            success = False
            raise
        finally:
            try:
                self.on_batch_end()
            except Exception as e:
                self._logger.exception("on_batch_end_error", error=str(e))
            # For streams (task_count=0), set task_count to actual count processed
            if self._batch._batch and self._batch._batch.task_count == 0:
                self._batch._batch.task_count = self._batch._batch.current_idx
            self._batch.end(status="success" if success else "failed")

    def _check_failure_threshold(self) -> None:
        """Check if failure threshold exceeded and raise BatchFailedError if so.

        Supports two threshold types (subclasses define one):
        - max_failure_ratio (0.0-1.0): Fail if failed/total > ratio
        - max_failure_count (int): Fail if failed >= count
        """
        if not self._batch:
            return

        failed = self._batch.task_failed
        total = self._batch.task_success + failed

        # Check ratio threshold (ScheduledService)
        max_ratio = getattr(self, "max_failure_ratio", 1.0)
        if max_ratio < 1.0 and total > 0:
            ratio = failed / total
            if ratio > max_ratio:
                raise BatchFailedError(
                    failed=failed,
                    total=total,
                    ratio=ratio,
                    ratio_threshold=max_ratio,
                )

        # Check count threshold (StreamService)
        max_count = getattr(self, "max_failure_count", 0)
        if max_count > 0 and failed >= max_count:
            raise BatchFailedError(
                failed=failed,
                total=total,
                count_threshold=max_count,
            )

    # =========================================================================
    # Dependency Checking (delegates to DependencyChecker)
    # =========================================================================

    def _fail_for_dependency(self, failed_dep: str) -> None:
        """Mark this service as FAILED due to dependency failure."""
        reason = f"Dependency '{failed_dep}' failed"

        with self._log_context(Stage.RUN):
            event = Event.Error.dependency_failed(failed_dep)
            self._logger.warning(event.name, **event.fields())

        self.pulse(
            status=Service.Enums.Status.FAILED,
            payload={
                "message": reason,
                "failure_reason": FailureReason.DEPENDENCY,
            },
        )

        self._stop_event.set()

    def check_dependencies(self) -> bool:
        """Check if dependencies are healthy (rate-limited)."""
        return self._deps.check()

    def _get_failed_dependencies(self) -> set:
        """Get set of dependency names that are currently FAILED."""
        return self._deps.get_failed_dependencies()

    # =========================================================================
    # Lifecycle Context Manager
    # =========================================================================

    @contextmanager
    def _lifecycle(self) -> Generator[bool, None, None]:
        """
        Context manager for service lifecycle (setup and cleanup).

        Usage:
            with self._lifecycle() as ready:
                if ready:
                    self._execute()

        Yields:
            bool: True if ready to proceed, False if dependencies failed
        """
        # === SETUP ===
        self._logger = log
        self._config = self._identity.config if self._identity else {}
        self._start_time = time.time()

        net = psutil.net_io_counters()
        self._net_baseline = (net.bytes_sent, net.bytes_recv)

        # Note: Don't pulse IDLE here - it would overwrite FAILED status during retries.
        # PROCESSING is pulsed when work actually starts, SUCCESS/FAILED when it ends.

        # Check dependencies - if failed, _fail_for_dependency already pulsed FAILED
        if not self._deps.check(force=True):
            yield False  # Signal: don't do work
            return  # No cleanup needed, dependency failure already handled

        with self._log_context(Stage.RUN):
            self._logger.info(
                "service_started",
                message=f"Starting {self._identity.execution_type} service",
                execution_type=self._identity.execution_type,
            )

        # === WORK HAPPENS HERE (in the 'with' block) ===
        success, error = True, ""
        try:
            yield True  # Signal: ready to proceed
        except Exception as e:
            success, error = False, str(e)
            with self._log_context(Stage.RUN):
                self._logger.exception("service_failed", error=str(e))
            raise
        finally:
            # === CLEANUP ===
            self._lifecycle_cleanup(success, error)

    def _lifecycle_cleanup(self, success: bool, error: str) -> None:
        """Emit final status (called automatically by _lifecycle context manager)."""
        duration_ms = (time.time() - self._start_time) * 1000

        # Don't overwrite FAILED status (e.g., from dependency failure during work)
        if self._last_pulse_status == Service.Enums.Status.FAILED:
            with self._log_context(Stage.RUN):
                self._logger.warning(
                    "service_failed",
                    message=error if error else "Dependency failure",
                    duration_ms=round(duration_ms, 1),
                )
            return

        with self._log_context(Stage.RUN):
            if success:
                self._logger.info(
                    "service_completed",
                    message="Service completed successfully",
                    duration_ms=round(duration_ms, 1),
                )
                if self._identity.execution_type == Service.Enums.ExecutionType.STREAM:
                    self.pulse(status=Service.Enums.Status.IDLE)
                else:
                    self.pulse(status=Service.Enums.Status.SUCCESS)
            else:
                self._logger.error(
                    "service_failed",
                    message=error,
                    duration_ms=round(duration_ms, 1),
                )
                self.pulse(status=Service.Enums.Status.FAILED, payload={"message": error})

    # =========================================================================
    # Service Entry Point
    # =========================================================================

    @abstractmethod
    def _execute(self) -> None:
        """Execute the service's main work. Subclasses must implement."""
        pass
