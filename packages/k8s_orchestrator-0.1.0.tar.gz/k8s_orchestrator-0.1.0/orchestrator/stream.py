"""
StreamService - Service that continuously processes Kafka messages.

User implements:
- on_step(task): Process a single task (Kafka message)

Optional hooks (inherited from ServiceBase):
- on_batch_start(): Called when a batch of messages starts
- on_batch_end(): Called when a batch ends (always called, even on error)
"""

import time
from typing import Optional

from .base import ServiceBase
from .constants import Constants
from .events import Event, Result
from .kafka import KafkaError, create_consumer
from .services import Service

# Stage shortcut
Stage = Constants.Stage


class StreamService(ServiceBase):
    """
    Service that continuously processes Kafka messages.

    Override on_step() to process tasks (Kafka messages):

        class MyStreamService(StreamService):
            def __init__(self):
                super().__init__(
                    "my_stream_service",
                    kafka_topic="my_project.events",
                )

            def on_step(self, task):
                # task MUST have 'id' and 'description' fields
                # e.g., {"id": "evt-123", "description": "Process order", "data": {...}}
                handle_event(task["data"])

    With batch hooks:

        class MyStreamService(StreamService):
            def on_step(self, task):
                self.conn.send(task)

            def on_batch_start(self):
                self.conn = create_connection()

            def on_batch_end(self):
                self.conn.close()

    Failure threshold:

        class StrictStreamService(StreamService):
            max_failure_count = 10  # Fail stream after 10 task failures

            def on_step(self, task):
                if not process(task):
                    return False
                return True
    """

    # Maximum allowed failure count before stream fails. 0 = disabled (no limit).
    # When reached, stream goes to FAILED and Scheduler handles retry.
    max_failure_count: int = 0

    def __init__(
        self,
        identity: Service.Identity,
        kafka_topic: str,
        auto_offset_reset: str = "latest",
        poll_timeout_ms: int = 5000,
    ) -> None:
        super().__init__(identity)
        self.kafka_topic = kafka_topic
        self.auto_offset_reset = auto_offset_reset
        self.poll_timeout_ms = poll_timeout_ms
        self._consumer = None

        # Stream-specific batch tracking
        self._batch_task_count: int = 0
        self._last_batch_ended_at: Optional[float] = None  # Unix timestamp

    # =========================================================================
    # User API - Override these
    # =========================================================================

    def on_step(self, task: dict) -> Result:
        """
        Process a single task (Kafka message). Override this.

        Args:
            task: Dict with 'id' and 'description' fields, plus any custom data.
                  Already deserialized from JSON.

        Returns:
            Result: Use Result.ok() for success, Result.fail("reason") for failure.

        Raises:
            InvalidTaskError: If task is missing 'id' or 'description' field.

        Example:
            def on_step(self, task: dict) -> Result:
                try:
                    handle_event(task["data"])
                    return Result.ok()
                except ValidationError as e:
                    return Result.fail(f"Invalid event: {e}")
        """
        raise NotImplementedError("Subclasses must implement on_step()")

    def on_start(self) -> None:
        """Called once before the stream loop starts. Override for setup logic."""
        pass

    def _on_listening_tick(self) -> None:
        """Called after each poll cycle. Internal use for system services."""
        pass

    # =========================================================================
    # Framework - Don't override
    # =========================================================================

    def _execute(self) -> None:
        """Kafka consumer loop."""
        service_name = self._identity.service_name

        if not self.kafka_topic:
            raise ValueError(f"StreamService {service_name} must provide kafka_topic.")

        try:
            self._consumer = create_consumer(
                service_name=service_name,
                topic=self.kafka_topic,
                auto_offset_reset=self.auto_offset_reset,
                group_suffix="stream",
            )
        except Exception as e:
            with self._log_context(Stage.EXECUTE):
                self._logger.error(
                    "consumer_failed",
                    message=f"Failed to create Kafka consumer for topic {self.kafka_topic}",
                    error=str(e),
                )
            raise

        # Call on_start hook for subclass initialization
        self.on_start()

        try:
            with self._log_context(Stage.EXECUTE):
                self.pulse(Service.Enums.Status.LISTENING)

            processed = 0
            while not self.stop_requested:
                # Check dependencies periodically (rate-limited)
                if not self.check_dependencies():
                    break  # Dependency failed, stop processing

                try:
                    # Poll for messages (LISTENING state)
                    with self._log_context(Stage.EXECUTE):
                        records = self._consumer.poll(timeout_ms=self.poll_timeout_ms)

                    if not records:
                        # No messages - stay in LISTENING state
                        self.pulse(Service.Enums.Status.LISTENING)
                        self._on_listening_tick()
                        continue

                    # Got messages - enter batch mode and process until empty
                    wait_ms = None
                    if self._last_batch_ended_at is not None:
                        wait_ms = (time.time() - self._last_batch_ended_at) * 1000

                    with self._batch_context(task_count=0, wait_ms=wait_ms) as batch:
                        self._batch_task_count = 0
                        self.pulse(Service.Enums.Status.PROCESSING)

                        while records and not self.stop_requested:
                            for topic_partition, messages in records.items():
                                for msg in messages:
                                    if self.stop_requested:
                                        break

                                    task = msg.value
                                    processed += 1
                                    self._batch_task_count += 1

                                    # Execute message processing with timing
                                    task_start = time.time()
                                    task_result: Result = Result.ok()
                                    try:
                                        with self._log_context(Stage.EXECUTE):
                                            task_result = self.on_step(task)
                                    except Exception as e:
                                        task_result = Result.fail(str(e))
                                        raise  # Exceptions still fail batch immediately
                                    finally:
                                        duration_ms = (time.time() - task_start) * 1000
                                        batch.record_task(
                                            task=task,
                                            result=task_result,
                                            duration_ms=duration_ms,
                                            idx=self._batch_task_count,
                                        )

                                    # Check failure threshold after each message
                                    self._check_failure_threshold()

                                    # Pulse progress (rate-limited in HeartbeatManager)
                                    self.pulse(Service.Enums.Status.PROCESSING)

                            # Poll for more messages
                            self._on_listening_tick()
                            with self._log_context(Stage.EXECUTE):
                                records = self._consumer.poll(timeout_ms=self.poll_timeout_ms)

                    # Batch ended - record end time
                    self._last_batch_ended_at = time.time()

                except KafkaError as e:
                    with self._log_context(Stage.EXECUTE):
                        event = Event.Error.kafka_error(str(e))
                        self._logger.error(event.name, **event.fields())
                    raise

        finally:
            if self._consumer:
                self._consumer.close()
