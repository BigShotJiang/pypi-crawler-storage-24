"""
Service Types - Core type definitions for service orchestration.

This module provides:
- Service.Enums.Category: Service categories (SYSTEM, BUSINESS, INFRASTRUCTURE, TEST)
- Service.Enums.ExecutionType: How services run (TASK, STREAM)
- Service.Enums.Status: Operational state (IDLE, LISTENING, PROCESSING, SUCCESS, FAILED)
- Service.Identity: Complete service metadata dataclass
- Service.Name: Service name enums (System, Infra, ApiClient, Business)

These are CONTRACTS. Changes here may break:
- Kafka message consumers
- Grafana dashboards
- Database queries
"""

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Dict, List, Optional, Union
from uuid import UUID


# =============================================================================
# Service Enums
# =============================================================================


class ServiceEnums:
    """
    Namespace for service-related enums.

    Usage:
        from orchestrator import Service

        status = Service.Enums.Status.PROCESSING
        category = Service.Enums.Category.BUSINESS
        exec_type = Service.Enums.ExecutionType.SCHEDULED
    """
    # Mapping for Prometheus numeric gauges (defined before class to avoid forward reference)
    _STATUS_NUMERIC_MAP = {
        "idle": 0,
        "listening": 1,
        "processing": 2,
        "success": 3,
        "failed": 4,
    }


    class Category(StrEnum):
        """Service category."""

        SYSTEM = "system"  # System services (scheduler, lifecycle_manager, etc.)
        BUSINESS = "business"  # Business logic services
        INFRASTRUCTURE = "infrastructure"  # External components (postgresql, kafka, etc.)
        TEST = "test"  # Test services (unit, integration, e2e)

    class ExecutionType(StrEnum):
        """Service execution model - how the service runs."""

        SCHEDULED = "scheduled"  # Scheduled task, runs to completion (single-step or multi-step)
        STREAM = "stream"  # Long-running, continuously processes messages

    class Status(StrEnum):
        """
        Service operational state.

        StrEnum ensures truthiness for all values (including IDLE) and
        stores human-readable values in the database.
        """

        IDLE = "idle"  # Not active (ready for next run, or waiting for schedule)
        LISTENING = "listening"  # Stream service waiting for messages
        PROCESSING = "processing"  # Actively handling work
        SUCCESS = "success"  # Last run completed successfully
        FAILED = "failed"  # Last run failed

        @property
        def numeric(self) -> int:
            """Numeric value for Prometheus gauges."""
            return ServiceEnums._STATUS_NUMERIC_MAP[self.value]

        @property
        def is_active(self) -> bool:
            """True if service is actively running."""
            return self in (
                ServiceEnums.Status.LISTENING,
                ServiceEnums.Status.PROCESSING,
            )


# =============================================================================
# ServiceName Namespace
# =============================================================================


class ServiceName:
    """
    Namespace for service name enums.

    Usage:
        from orchestrator import Service

        # Access enums - member IS the service name string
        name = Service.Name.Infra.Database.POSTGRESQL  # "postgresql"
        name = Service.Name.System.SCHEDULER           # "scheduler"
        name == "postgresql"                            # True
    """

    class System(StrEnum):
        """Orchestrator system service identifiers."""

        SCHEDULER = "scheduler"
        ARCHIVER = "archiver"
        LIFECYCLE_MANAGER = "lifecycle_manager"
        INFRA_MONITOR = "infra_monitor"

    class Infra(StrEnum):
        """Placeholder for infrastructure service names. Set by infra-client."""
        pass

    class Business(StrEnum):
        """Placeholder for business service names. Set by extending projects."""
        pass

    # Type alias for type hints (updated when Business is set)
    Any = Union[
        Infra,
        System,
        Business
    ]




# =============================================================================
# ServiceIdentity Dataclass
# =============================================================================


@dataclass(frozen=True)
class ServiceIdentity:
    """
    Complete identity of a service.

    This is the single source of truth for service metadata.
    - At definition time (in SERVICES): id=None
    - After bootstrap: id=UUID (use dataclasses.replace to set)

    The prometheus_labels property requires id to be set.
    """

    service_name: ServiceName.Any
    service_category: ServiceEnums.Category
    execution_type: ServiceEnums.ExecutionType
    description: str = ""
    display_name: Optional[str] = None  # Human-friendly name for Grafana
    cron_schedule: Optional[str] = None
    dependencies: tuple = ()  # Tuple of ServiceName.Any
    config: Dict[str, Any] = field(default_factory=dict)
    module_path: Optional[str] = None  # Python module path for ProcessManager
    id: Optional[UUID] = None

    @property
    def prometheus_labels(self) -> Dict[str, str]:
        """Get Prometheus labels dict for this service."""
        if self.id is None:
            raise ValueError(
                f"Cannot get prometheus_labels for {self.service_name}: id not set. "
                "Service not yet registered. Call Service.Table.bootstrap() first."
            )
        config = self.config or {}
        return {
            "id": str(self.id),
            "display_name": self.display_name or str(self.service_name),
            "service_name": str(self.service_name),
            "execution_type": str(self.execution_type),
            "service_category": str(self.service_category),
            "fetcher": config.get("fetcher", ""),
        }


# =============================================================================
# Registry Namespace
# =============================================================================


class SystemRegistry:
    """
    Namespace for service identity registries.

    Usage:
        from orchestrator import Registry

        # System services
        scheduler = Registry.System.SCHEDULER
        all_system = Registry.System.all()

        # Infrastructure components
        all_infra = Registry.Infra.all()
    """

    class Infra:
        """Placeholder for infrastructure service identities. Set by extending projects."""
        pass

    class Business:
        """Placeholder for business service identities. Set by extending projects."""
        pass

    class System:
        """Registry of system service identities."""
        _SYSTEM_MODULE_PREFIX = "orchestrator.system_services"

        SCHEDULER = ServiceIdentity(
            service_name=ServiceName.System.SCHEDULER,
            service_category=ServiceEnums.Category.SYSTEM,
            execution_type=ServiceEnums.ExecutionType.SCHEDULED,
            description="Central orchestrator service",
            display_name="Scheduler",
            cron_schedule="*/2 * * * * *",  # Every 2 seconds (must be < observability_interval)
            config={"heartbeat_stale_seconds": 30},  # Allow longer stale threshold
            module_path=f"{_SYSTEM_MODULE_PREFIX}.scheduler",
        )

        LIFECYCLE_MANAGER = ServiceIdentity(
            service_name=ServiceName.System.LIFECYCLE_MANAGER,
            service_category=ServiceEnums.Category.SYSTEM,
            execution_type=ServiceEnums.ExecutionType.STREAM,
            description="Centralized service lifecycle management",
            display_name="Lifecycle Manager",
            module_path=f"{_SYSTEM_MODULE_PREFIX}.lifecycle_manager",
        )

        INFRA_MONITOR = ServiceIdentity(
            service_name=ServiceName.System.INFRA_MONITOR,
            service_category=ServiceEnums.Category.SYSTEM,
            execution_type=ServiceEnums.ExecutionType.SCHEDULED,
            description="Monitors infrastructure and API client health",
            display_name="Infra Monitor",
            cron_schedule="*/2 * * * * *",  # Every 2 seconds
            module_path=f"{_SYSTEM_MODULE_PREFIX}.infra_monitor",
        )

        ARCHIVER = ServiceIdentity(
            service_name=ServiceName.System.ARCHIVER,
            service_category=ServiceEnums.Category.SYSTEM,
            execution_type=ServiceEnums.ExecutionType.SCHEDULED,
            description="Archives old data and cleans up stale records",
            display_name="Archiver",
            cron_schedule="0 * * * * *",  # Every minute
            module_path=f"{_SYSTEM_MODULE_PREFIX}.archiver",
        )

        @classmethod
        def all(cls) -> List[ServiceIdentity]:
            """Get all system service identities."""
            return [
                cls.SCHEDULER,
                cls.LIFECYCLE_MANAGER,
                cls.INFRA_MONITOR,
                cls.ARCHIVER,
            ]

class Service:
    """
    Unified namespace for all service-related types.

    Static attributes (available immediately):
        Enums - Service enums (Status, Category, ExecutionType)
        Name - Service name enums (System, Infra, ApiClient, Business)
        Identity - ServiceIdentity dataclass (static service metadata)

    Bootstrap-time attributes (set via Service.Table):
        Table - SQLAlchemy model with class methods:
            - Service.Table.init_db()       - Initialize schema and tables
            - Service.Table.bootstrap()     - Upsert service, returns identity with id
            - Service.Table.get_identity()  - Cached lookup by UUID
            - Service.Table.query()         - Query services with filters

    Usage:
        from orchestrator import Service, ScheduledService

        # Enums and system names
        status = Service.Enums.Status.PROCESSING
        scheduler = Service.Name.System.SCHEDULER

        # Define services
        SERVICES = (
            Service.Identity(
                service_name=MyServiceName.FETCHER,
                service_category=Service.Enums.Category.BUSINESS,
                execution_type=Service.Enums.ExecutionType.SCHEDULED,
                ...
            ),
        )

        # After Service.Table.bootstrap() is called:
        services = Service.Table.query(name=name)
        svc = services[0] if services else None
    """

    # Enums namespace
    Enums = ServiceEnums

    # Dataclass for static service metadata
    Identity = ServiceIdentity

    # Bootstrap-time attributes
    Table = None  # ServiceRecord model, set by bootstrap
    Registry = SystemRegistry


# =============================================================================
# Helper Functions
# =============================================================================
