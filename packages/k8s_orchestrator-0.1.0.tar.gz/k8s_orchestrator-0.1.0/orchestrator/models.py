"""
SQLAlchemy models for orchestrator.

This module provides ServiceModel, the SQLAlchemy model for the services table.
All operations are accessible via Service.Table:

Class Methods:
    Service.Table.init_db()      - Initialize database schema and tables
    Service.Table.bootstrap()    - Upsert service, returns identity with id
    Service.Table.get_identity() - Cached lookup of identity by UUID
    Service.Table.query()        - Query services with filters

Instance Properties:
    svc.is_stale                 - Check if service heartbeat is stale

Example:
    class MyService(ScheduledService):
        def __init__(self):
            identity = Service.Table.bootstrap(MY_SERVICE_IDENTITY)
            super().__init__(identity)

    # Query services
    services = Service.Table.query(category=Service.Enums.Category.BUSINESS)
    for svc in services:
        if svc.is_stale:
            handle_stale_service(svc)
"""

import uuid
from dataclasses import replace
from typing import Dict, Optional

from sqlalchemy import Boolean, Column, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, TIMESTAMP, UUID
from sqlalchemy.orm import declarative_base
from sqlalchemy.sql import func

from infra_client import Infra

from .services import Service


def get_db_session():
    """Get database session context manager (re-exported from infra_client)."""
    return Infra().api.get_db_session()


Base = declarative_base()


# =============================================================================
# System Metadata Schema - Service configuration and management
# =============================================================================
class ServiceModel(Base):
    """Service registry with default configurations."""

    __tablename__ = "services"
    # Schema is set at runtime by OrchestratorConfig.__post_init__
    __table_args__ = {"schema": None}

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Service identifier - must be a value from Service.Name
    service_name = Column(String(100), nullable=False, unique=True, index=True)

    service_category = Column(
        String(20),
        nullable=False,
        default=Service.Enums.Category.BUSINESS,
        server_default=Service.Enums.Category.BUSINESS,
    )
    execution_type = Column(
        String(20),
        nullable=False,
        default=Service.Enums.ExecutionType.SCHEDULED,
        server_default=Service.Enums.ExecutionType.SCHEDULED,
    )
    description = Column(Text)
    display_name = Column(String(100))  # Human-friendly name for Grafana
    config = Column(JSONB, nullable=False, default={})

    # Scheduling
    cron_schedule = Column(String(100))  # e.g., "0 */6 * * *"
    last_run_at = Column(TIMESTAMP(timezone=True))
    next_run_at = Column(TIMESTAMP(timezone=True), index=True)

    # Operational status (StrEnum: "idle", "listening", "processing", "success", "failed")
    status = Column(
        String(20),
        nullable=False,
        default=Service.Enums.Status.IDLE.value,
        server_default=Service.Enums.Status.IDLE.value,
    )

    last_error = Column(Text)
    last_heartbeat_at = Column(TIMESTAMP(timezone=True))

    # Stop request (for graceful shutdown)
    stop_requested = Column(Boolean, default=False, server_default="false")
    stop_reason = Column(Text)

    # Retry tracking (for automatic failure recovery)
    failure_count = Column(Integer, default=0, server_default="0")
    failure_reason = Column(String(20))  # FailureReason enum value
    last_failure_at = Column(TIMESTAMP(timezone=True))

    # Dependencies (list of service names this service depends on)
    dependencies = Column(JSONB, default=[], server_default="[]")

    # Module path for ProcessManager to spawn this service
    module_path = Column(String(255))

    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at = Column(
        TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # -------------------------------------------------------------------------
    # Computed Properties
    # -------------------------------------------------------------------------

    @property
    def has_run(self) -> bool:
        """Check if the service has ever run."""
        return self.last_run_at is not None

    @property
    def status_enum(self) -> Optional["Service.Enums.Status"]:
        """Status as enum for accessing properties like is_active, color."""
        if self.status is None:
            return None
        # DB stores string values ("idle", "processing", etc.)
        return Service.Enums.Status(self.status)

    @property
    def prometheus_labels(self) -> dict:
        """Get labels for Prometheus metrics."""
        config = self.config or {}
        return {
            "id": str(self.id),
            "display_name": self.display_name or self.service_name,
            "service_name": self.service_name,
            "execution_type": self.execution_type,
            "service_category": self.service_category,
            "fetcher": config.get("fetcher", ""),
        }

    def __repr__(self):
        return f"<Service(name={self.service_name})>"

    # -------------------------------------------------------------------------
    # Class Methods - Service Operations
    # -------------------------------------------------------------------------

    # Cache for identity lookups (immutable once created)
    _identity_cache: Dict[uuid.UUID, "Service.Identity"] = {}

    @classmethod
    def bootstrap(cls, identity: "Service.Identity") -> "Service.Identity":
        """
        Upsert a service to the database.

        Creates the service if it doesn't exist, updates mutable fields if it does.

        Args:
            identity: Service.Identity to register

        Returns:
            Service.Identity with id field populated from DB
        """
        from sqlalchemy.exc import IntegrityError

        name = str(identity.service_name)

        with get_db_session() as session:
            existing = session.query(cls).filter_by(service_name=name).first()

            if existing:
                # Update mutable fields from identity
                existing.service_category = identity.service_category
                existing.execution_type = identity.execution_type
                existing.description = identity.description
                existing.display_name = identity.display_name
                existing.config = dict(identity.config)
                existing.cron_schedule = identity.cron_schedule
                existing.dependencies = list(identity.dependencies)
                existing.module_path = identity.module_path
                service_id = existing.id
            else:
                # Create new service
                service_id = uuid.uuid4()
                service = cls(
                    id=service_id,
                    service_name=name,
                    service_category=identity.service_category,
                    execution_type=identity.execution_type,
                    description=identity.description,
                    display_name=identity.display_name,
                    config=dict(identity.config),
                    cron_schedule=identity.cron_schedule,
                    dependencies=list(identity.dependencies),
                    module_path=identity.module_path,
                )
                session.add(service)

                # Flush to detect IntegrityError from race condition
                try:
                    session.flush()
                except IntegrityError:
                    # Another process created this service - rollback and refetch
                    session.rollback()
                    existing = session.query(cls).filter_by(service_name=name).first()
                    if existing:
                        service_id = existing.id
                    else:
                        raise  # Unexpected error

            session.commit()

        return replace(identity, id=service_id)

    @classmethod
    def get_identity(
        cls, service_id: uuid.UUID, use_cache: bool = True
    ) -> Optional["Service.Identity"]:
        """
        Get service identity from database by ID, with optional caching.

        Args:
            service_id: Service UUID
            use_cache: If True, use and populate cache (default True)

        Returns:
            Service.Identity if found, None otherwise
        """
        if use_cache and service_id in cls._identity_cache:
            return cls._identity_cache[service_id]

        with get_db_session() as session:
            svc = session.query(cls).filter_by(id=service_id).first()
            if not svc:
                return None

            identity = Service.Identity(
                id=svc.id,
                service_name=svc.service_name,
                service_category=Service.Enums.Category(svc.service_category),
                execution_type=Service.Enums.ExecutionType(svc.execution_type),
                description=svc.description or "",
                display_name=svc.display_name,
                cron_schedule=svc.cron_schedule,
                dependencies=tuple(svc.dependencies) if svc.dependencies else (),
                config=dict(svc.config) if svc.config else {},
                module_path=svc.module_path,
            )

            if use_cache:
                cls._identity_cache[service_id] = identity

            return identity


    @classmethod
    def init_db(cls) -> None:
        """
        Initialize database schema and tables for the current project.

        Creates a project-specific schema using database_schema from config.
        Each project gets its own isolated schema (e.g., 'sec_fetcher.services').
        Safe to call multiple times (uses CREATE IF NOT EXISTS).
        """
        from sqlalchemy import text

        from .config import get_project_config

        schema = get_project_config().database_schema

        with get_db_session() as db:
            db.execute(text(f"CREATE SCHEMA IF NOT EXISTS {schema}"))
            db.commit()
            cls.__table__.create(db.get_bind(), checkfirst=True)

    @classmethod
    def query(
        cls,
        name: Optional[str] = None,
        execution_type: Optional["Service.Enums.ExecutionType"] = None,
        category: Optional["Service.Enums.Category"] = None,
    ) -> list["ServiceModel"]:
        """
        Query services from DB with optional filters.

        Args:
            name: Filter by exact service name (returns at most one service).
            execution_type: Filter by ExecutionType (TASK, STREAM).
            category: Filter by Category (SYSTEM, BUSINESS, INFRASTRUCTURE, TEST).

        All filters can be combined. If none specified, returns all services.

        Returns:
            List of ServiceModel objects (detached from session).

        Example:
            # Get single service by name
            services = Service.Table.query(name="scheduler")
            svc = services[0] if services else None

            # Get all stream services
            stream_services = Service.Table.query(
                execution_type=Service.Enums.ExecutionType.STREAM
            )

            # Get business task services
            tasks = Service.Table.query(
                category=Service.Enums.Category.BUSINESS,
                execution_type=Service.Enums.ExecutionType.SCHEDULED,
            )
        """
        with get_db_session() as session:
            query = session.query(cls)
            if name:
                query = query.filter(cls.service_name == name)
            if execution_type:
                query = query.filter(cls.execution_type == execution_type)
            if category:
                query = query.filter(cls.service_category == category)
            services = query.all()
            # Detach objects from session so they can be used outside
            for svc in services:
                session.expunge(svc)
            return services

    # -------------------------------------------------------------------------
    # Instance Properties - Status Checks
    # -------------------------------------------------------------------------

    @property
    def is_stale(self) -> bool:
        """
        Check if this service is stale (no recent heartbeat).

        A service is stale if:
        - It has an active status (LISTENING or PROCESSING)
        - Its last heartbeat is older than stale_seconds (from config)

        Returns:
            True if service is stale, False otherwise.
        """
        from datetime import datetime, timedelta, timezone

        from .config import get_project_config

        # Only active services can be stale
        if not (self.status_enum and self.status_enum.is_active):
            return False

        # Get stale threshold from service config or global config
        svc_config = self.config or {}
        stale_seconds = svc_config.get("heartbeat_stale_seconds")
        if stale_seconds is None:
            config = get_project_config()
            stale_seconds = int(config.stale_threshold)

        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(seconds=stale_seconds)

        last_heartbeat = self.last_heartbeat_at or self.last_run_at
        return last_heartbeat is None or last_heartbeat < cutoff


# Compile-time validation: ensure ServiceModel columns match expected fields
from dataclasses import fields as _get_fields

_identity_fields = frozenset(f.name for f in _get_fields(Service.Identity))
_state_fields = frozenset({
    "status",
    "last_error",
    "stop_requested",
    "stop_reason",
    "failure_count",
    "failure_reason",
    "last_run_at",
    "next_run_at",
    "last_heartbeat_at",
    "last_failure_at",
})
_audit_fields = frozenset({"created_at", "updated_at"})
_expected_fields = _identity_fields | _state_fields | _audit_fields
_model_columns = frozenset(c.key for c in ServiceModel.__table__.columns)
_missing = _expected_fields - _model_columns
_extra = _model_columns - _expected_fields
assert not _missing, f"ServiceModel missing fields: {_missing}"
assert not _extra, f"ServiceModel has extra columns: {_extra}"


# Set Service.Table for convenience
Service.Table = ServiceModel
