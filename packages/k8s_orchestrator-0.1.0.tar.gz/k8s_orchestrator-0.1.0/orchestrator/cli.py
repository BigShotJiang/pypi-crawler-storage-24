"""
Reusable CLI for orchestrator-based projects.

Provides a complete CLI that projects can use by simply instantiating ProjectCLI
with their service configuration.

Usage:
    # In your project's __main__.py:
    from orchestrator import ProjectCLI
    from registry import SERVICES, INFRA_MONITORS

    ProjectCLI(
        project_name="my_project",
        services=SERVICES,
        infra_services=tuple(str(m) for m in INFRA_MONITORS),
    ).run()

This gives your project these commands:
    python -m my_project start           # Start the orchestrator (background)
    python -m my_project stop            # Stop all services
    python -m my_project status          # Show system status
    python -m my_project list            # List all services
    python -m my_project run <service>   # Run a service immediately
    python -m my_project kill <service>  # Kill a running service
"""

import argparse
import os
import signal
import subprocess
import sys
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Callable, Optional, Tuple

if TYPE_CHECKING:
    from .services import Service


def cron_to_expected_hours(cron: str | None) -> float | None:
    """
    Estimate expected interval in hours from a cron expression.

    Useful for determining if a service is "overdue" based on its schedule.

    Args:
        cron: Cron expression (5 fields: minute hour dom month dow)

    Returns:
        Expected interval in hours, or None if cannot be determined
    """
    if not cron:
        return None
    parts = cron.split()
    if len(parts) < 5:
        return None
    minute, hour, dom, month, dow = parts[:5]

    # Every N minutes (*/5 * * * *)
    if minute.startswith("*/"):
        return int(minute[2:]) / 60
    # Every N hours (0 */2 * * *)
    if hour.startswith("*/"):
        return int(hour[2:])
    # Specific months - quarterly (0 6 20 2,5,8,11 *)
    if "," in month:
        return 24 * 90  # ~quarterly
    # Monthly - specific day of month (0 6 1 * *)
    if dom not in ("*",) and month == "*":
        return 24 * 30
    # Weekly - specific day of week (0 6 * * 6)
    if dow not in ("*",) and dom == "*":
        return 24 * 7
    # Daily - specific hour (0 6 * * *)
    if hour != "*" and dom == "*" and dow in ("*", "1-5"):
        return 24
    return 24  # default to daily


class ProjectCLI:
    """
    Reusable CLI for orchestrator-based projects.

    Encapsulates all CLI logic so projects only need to provide their
    configuration and call run().

    Args:
        project_name: Project identifier (also used as database name)
        services: Tuple of Service.Identity for business services
        infra_services: Tuple of infrastructure component names to monitor
        description: Optional CLI description (defaults to generic message)
        custom_commands: Dict of custom commands to add. Each entry is:
            {"command_name": {"help": "...", "args": [...], "handler": callable}}
            where args is a list of dicts with argparse.add_argument kwargs,
            and handler is a callable(cli, args) -> None
    """

    def __init__(
        self,
        project_name: str,
        services: Tuple["Service.Identity", ...],
        infra_services: Tuple[str, ...] = (),
        description: Optional[str] = None,
        custom_commands: Optional[dict] = None,
    ) -> None:
        self.project_name = project_name
        self.services = services
        self.infra_services = infra_services
        self.description = description or f"{project_name} - Orchestrator CLI"
        self.custom_commands = custom_commands or {}

        self._env: Optional[str] = None

    def run(self) -> None:
        """Parse arguments and execute the appropriate command."""
        parser = argparse.ArgumentParser(
            description=self.description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog=self._build_epilog(),
        )

        subparsers = parser.add_subparsers(dest="command", help="Available commands")

        # start command
        start_parser = subparsers.add_parser(
            "start",
            help="Start the orchestrator (lifecycle manager + scheduler)"
        )
        start_parser.add_argument(
            "--foreground", "-f",
            action="store_true",
            help="Run in foreground (default: background)"
        )

        # stop command
        subparsers.add_parser("stop", help="Stop all running services")

        # status command
        subparsers.add_parser("status", help="Show system status")

        # list command
        list_parser = subparsers.add_parser("list", help="List all registered services")
        list_parser.add_argument(
            "--filter", "-f",
            help="Filter by service name (substring match)"
        )
        list_parser.add_argument(
            "--status", "-s",
            choices=["idle", "listening", "processing", "success", "failed"],
            help="Filter by status"
        )

        # run command
        run_parser = subparsers.add_parser(
            "run",
            help="Run a service immediately (sends RUN_NOW command)"
        )
        run_parser.add_argument("service", help="Service name to run")

        # kill command
        kill_parser = subparsers.add_parser("kill", help="Kill a running service")
        kill_parser.add_argument("service", help="Service name to kill")
        kill_parser.add_argument("--reason", "-r", help="Reason for killing")

        # Register custom commands
        for cmd_name, cmd_config in self.custom_commands.items():
            cmd_parser = subparsers.add_parser(cmd_name, help=cmd_config.get("help", ""))
            for arg_config in cmd_config.get("args", []):
                # Handle positional vs optional arguments
                name = arg_config.pop("name", None)
                flags = arg_config.pop("flags", None)
                if flags:
                    cmd_parser.add_argument(*flags, **arg_config)
                elif name:
                    cmd_parser.add_argument(name, **arg_config)

        args = parser.parse_args()

        if not args.command:
            parser.print_help()
            sys.exit(0)

        # Dispatch to command handler (check custom commands first)
        if args.command in self.custom_commands:
            handler = self.custom_commands[args.command].get("handler")
            if handler:
                handler(self, args)
                return

        handler = getattr(self, f"cmd_{args.command}", None)
        if handler:
            handler(args)
        else:
            print(f"Unknown command: {args.command}")
            sys.exit(1)

    def _build_epilog(self) -> str:
        """Build the help epilog with examples."""
        return f"""
Examples:
  python -m {self.project_name} start           # Start orchestrator in background
  python -m {self.project_name} start -f        # Start in foreground
  python -m {self.project_name} stop            # Stop all services
  python -m {self.project_name} status          # Check if system is running
  python -m {self.project_name} list            # List all services
  python -m {self.project_name} list -s failed  # List failed services only
  python -m {self.project_name} run <service>   # Trigger immediate run
  python -m {self.project_name} kill <service>  # Kill a service

Environment:
  ENV    Required. One of: dev, test, prod
"""

    def _get_env(self) -> str:
        """Get and validate ENV environment variable."""
        if self._env:
            return self._env

        env = os.getenv("ENV")
        if not env:
            print("ERROR: ENV must be set (dev, test, or prod)")
            sys.exit(1)

        self._env = env
        return env

    def _init_config(self) -> None:
        """Initialize orchestrator config for database access."""
        from .config import OrchestratorConfig
        OrchestratorConfig(env=self._get_env(), project_name=self.project_name)

    def _format_status(self, status: str) -> str:
        """Format status with color codes for terminal."""
        colors = {
            "idle": "\033[90m",       # Gray
            "listening": "\033[34m",  # Blue
            "processing": "\033[33m", # Yellow
            "success": "\033[32m",    # Green
            "failed": "\033[31m",     # Red
        }
        reset = "\033[0m"
        color = colors.get(status, "")
        return f"{color}{status:10}{reset}"

    def _format_time(self, dt: Optional[datetime]) -> str:
        """Format datetime for display."""
        if not dt:
            return "-"
        now = datetime.now(timezone.utc)
        diff = now - dt
        if diff.total_seconds() < 60:
            return f"{int(diff.total_seconds())}s ago"
        elif diff.total_seconds() < 3600:
            return f"{int(diff.total_seconds() / 60)}m ago"
        elif diff.total_seconds() < 86400:
            return f"{int(diff.total_seconds() / 3600)}h ago"
        else:
            return dt.strftime("%Y-%m-%d %H:%M")

    def _find_running_processes(self) -> list[dict]:
        """Find running orchestrator processes for this project."""
        import json

        try:
            # Use pgrep to find python processes with our project name
            result = subprocess.run(
                ["pgrep", "-af", f"python.*{self.project_name}"],
                capture_output=True,
                text=True,
            )

            processes = []
            for line in result.stdout.strip().split("\n"):
                if not line:
                    continue
                parts = line.split(None, 1)
                if len(parts) >= 2:
                    pid = int(parts[0])
                    cmd = parts[1]

                    # Parse out the service name from the command
                    if "lifecycle_manager" in cmd:
                        name = "lifecycle_manager"
                    elif "scheduler" in cmd:
                        name = "scheduler"
                    elif self.project_name in cmd:
                        # Try to extract service name from JSON config
                        name = "orchestrator"
                    else:
                        continue

                    processes.append({"pid": pid, "name": name, "cmd": cmd})

            return processes
        except Exception:
            return []

    # =========================================================================
    # Command Handlers
    # =========================================================================

    def cmd_start(self, args) -> None:
        """Start the orchestrator."""
        env = self._get_env()

        # Only check for running processes when starting in background mode
        # Foreground mode is either user-initiated or spawned by background mode
        if not args.foreground:
            processes = self._find_running_processes()
            if processes:
                print(f"Orchestrator already running for '{self.project_name}':")
                for p in processes:
                    print(f"  PID {p['pid']}: {p['name']}")
                print("\nUse 'stop' to stop, or 'status' for details.")
                sys.exit(1)

        if args.foreground:
            # Run in foreground (blocking)
            print(f"Starting {self.project_name} orchestrator in foreground...")
            self._run_process_manager()
        else:
            # Run in background
            print(f"Starting {self.project_name} orchestrator in background...")

            # Build the command using the original script path
            # sys.argv[0] contains the script that was invoked
            script_path = os.path.abspath(sys.argv[0])
            cmd = [
                sys.executable, "-u", script_path,
                "start", "--foreground"
            ]

            # Start in background with output going to log file
            log_file = f"/tmp/{self.project_name}_orchestrator.log"
            with open(log_file, "w") as f:
                proc = subprocess.Popen(
                    cmd,
                    stdout=f,
                    stderr=subprocess.STDOUT,
                    env={**os.environ, "ENV": env},
                    start_new_session=True,  # Detach from terminal
                )

            print(f"Started with PID {proc.pid}")
            print(f"Logs: {log_file}")
            print(f"\nUse '{self.project_name} status' to check, '{self.project_name} stop' to stop.")

    def _run_process_manager(self) -> None:
        """Run the ProcessManager (blocking)."""
        from .manager import ProcessManager

        ProcessManager(
            env=self._get_env(),
            project_name=self.project_name,
            business_services=self.services,
            infra_services=self.infra_services,
        ).run()

    def cmd_stop(self, args) -> None:
        """Stop all running services."""
        self._get_env()  # Validate env is set

        processes = self._find_running_processes()
        if not processes:
            print(f"No orchestrator processes running for '{self.project_name}'")
            return

        print(f"Stopping {len(processes)} process(es)...")

        for p in processes:
            try:
                os.kill(p["pid"], signal.SIGTERM)
                print(f"  Sent SIGTERM to {p['name']} (PID {p['pid']})")
            except ProcessLookupError:
                print(f"  {p['name']} (PID {p['pid']}) already stopped")
            except PermissionError:
                print(f"  Permission denied for {p['name']} (PID {p['pid']})")

        print("\nServices stopping. Use 'status' to verify.")

    def cmd_status(self, args) -> None:
        """Show system status."""
        self._get_env()

        processes = self._find_running_processes()

        if not processes:
            print(f"Orchestrator is NOT running for '{self.project_name}'")
            print(f"\nUse '{self.project_name} start' to start.")
            return

        print(f"Orchestrator is RUNNING for '{self.project_name}':\n")
        print(f"  {'PROCESS':<20} {'PID':<10}")
        print(f"  {'-'*30}")
        for p in processes:
            print(f"  {p['name']:<20} {p['pid']:<10}")

        # Also show service summary from database
        self._init_config()
        from .services import Service

        services = Service.Table.query()
        if services:
            # Count by status
            status_counts = {}
            for svc in services:
                status = svc.status or "idle"
                status_counts[status] = status_counts.get(status, 0) + 1

            print(f"\n  Services: {len(services)} total")
            for status, count in sorted(status_counts.items()):
                print(f"    {status}: {count}")

    def cmd_list(self, args) -> None:
        """List all registered services."""
        self._init_config()

        from .services import Service

        services = Service.Table.query()

        if not services:
            print(f"No services found for project '{self.project_name}'")
            return

        # Apply filters
        if hasattr(args, "filter") and args.filter:
            services = [s for s in services if args.filter.lower() in s.service_name.lower()]

        if hasattr(args, "status") and args.status:
            services = [s for s in services if (s.status or "idle") == args.status]

        if not services:
            print("No services match the filter criteria")
            return

        # Sort by category, then name
        services.sort(key=lambda s: (s.service_category, s.service_name))

        # Print header
        print(f"\n{'SERVICE':<35} {'STATUS':<12} {'CATEGORY':<15} {'LAST RUN':<15} {'NEXT RUN':<15}")
        print("-" * 95)

        for svc in services:
            status = self._format_status(svc.status or "idle")
            last_run = self._format_time(svc.last_run_at)
            next_run = self._format_time(svc.next_run_at)
            print(f"{svc.service_name:<35} {status} {svc.service_category:<15} {last_run:<15} {next_run:<15}")

        print(f"\nTotal: {len(services)} services")

    def cmd_run(self, args) -> None:
        """Send RUN_NOW command to a service."""
        self._init_config()

        from .constants import Constants
        from .kafka import command_bus
        from .services import Service

        # Find service by name
        services = Service.Table.query(name=args.service)
        if not services:
            print(f"ERROR: Service '{args.service}' not found")
            self._suggest_services(args.service)
            sys.exit(1)

        svc = services[0]
        service_id = str(svc.id)

        # Send RUN_NOW command
        trace_id = command_bus.send_command(
            service_id=service_id,
            command=Constants.Command.RUN_NOW,
            reason="CLI run command",
        )

        print(f"Sent RUN_NOW command to '{svc.service_name}'")
        print(f"  Service ID: {service_id}")
        print(f"  Trace ID:   {trace_id}")
        print(f"\nThe service will execute immediately (bypassing schedule).")

    def cmd_kill(self, args) -> None:
        """Send KILL command to a service."""
        self._init_config()

        from .constants import Constants
        from .kafka import command_bus
        from .services import Service

        # Find service by name
        services = Service.Table.query(name=args.service)
        if not services:
            print(f"ERROR: Service '{args.service}' not found")
            self._suggest_services(args.service)
            sys.exit(1)

        svc = services[0]
        service_id = str(svc.id)

        # Send KILL command
        trace_id = command_bus.send_command(
            service_id=service_id,
            command=Constants.Command.KILL,
            reason=args.reason or "CLI kill command",
        )

        print(f"Sent KILL command to '{svc.service_name}'")
        print(f"  Service ID: {service_id}")
        print(f"  Trace ID:   {trace_id}")

    def _suggest_services(self, query: str) -> None:
        """Suggest similar service names."""
        from .services import Service

        all_services = Service.Table.query()

        # Find services that contain the query as substring
        matches = [s for s in all_services if query.lower() in s.service_name.lower()]

        if matches:
            print("\nDid you mean one of these?")
            for svc in sorted(matches, key=lambda s: s.service_name)[:10]:
                print(f"  - {svc.service_name}")
        else:
            print("\nAvailable services:")
            for svc in sorted(all_services, key=lambda s: s.service_name)[:10]:
                print(f"  - {svc.service_name}")
            if len(all_services) > 10:
                print(f"  ... and {len(all_services) - 10} more (use 'list' to see all)")
