"""
Prometheus metrics and gauge definitions.

Provides:
- Metric registries (service_metrics, batch_metrics, item_metrics)
- Prometheus primitives (Gauge, Counter, Histogram)
- Registry and serialization utilities

Note: Rate-limited status updates are handled by LifecycleManager.
This module only provides gauge/counter definitions.

Usage:
    from orchestrator import service_metrics

    # Update gauges/counters directly
    labels = {"id": "...", "name": "my_service", ...}
    service_metrics.status.labels(**labels).set(status.numeric)
"""

from prometheus_client import Counter, Gauge, Histogram

from .config import get_project_config, is_configured

# =============================================================================
# Label Constants (private - used only in this module)
# =============================================================================

_SERVICE_LABELS = ["id", "display_name", "service_name", "execution_type", "service_category", "fetcher"]

# Default bucket values (used if config not yet available)
_DEFAULT_BATCH_SIZE_BUCKETS = (1, 5, 10, 25, 50, 100, 250, 500, 1000)


def _get_batch_size_buckets():
    """Get batch size buckets from config or defaults."""
    if is_configured():
        return get_project_config().batch_size_buckets
    return _DEFAULT_BATCH_SIZE_BUCKETS


# =============================================================================
# Service Metrics
# =============================================================================


class ServiceMetrics:
    """
    Registry for service metrics.

    All service-level Prometheus gauges are defined here directly.
    LifecycleManager is the single owner that updates these.

    Note: Resource metrics (cpu, memory, network) are tracked at the batch level
    via BatchMetrics, not at the service level.
    """

    def __init__(self):
        # Status metrics
        self.status = Gauge(
            "service_status",
            "Service status (0=idle, 1=listening, 2=processing, 3=success, 4=failed)",
            _SERVICE_LABELS,
        )
        self.healthy = Gauge(
            "service_healthy",
            "Service is healthy (1=healthy, 0=unhealthy)",
            _SERVICE_LABELS,
        )


class BatchMetrics:
    """
    Registry for batch metrics.

    Completion metrics (emitted at batch end):
    - batch_last_duration_seconds: Duration of the most recent batch
    - batch_size: Number of items processed
    - batch_completed_total: Count of completed batches
    - task_success: Count of successful tasks
    - task_failed: Count of failed tasks
    - longest_task_duration_ms: Duration of slowest task in last batch

    Sampled metrics (updated during batch execution):
    - batch_active: 1 if batch running, 0 otherwise
    - batch_progress: 0.0 to 1.0 completion ratio
    - batch_cpu_percent: CPU usage during batch
    - batch_memory_bytes: Memory usage during batch
    """

    def __init__(self):
        # Completion metrics
        self.last_duration_seconds = Gauge(
            "batch_last_duration_seconds",
            "Duration of the most recent batch in seconds",
            _SERVICE_LABELS,
        )
        self.size = Histogram(
            "batch_size",
            "Number of items in batch",
            _SERVICE_LABELS,
            buckets=_get_batch_size_buckets(),
        )
        self.completed_total = Counter(
            "batch_completed_total",
            "Total batches completed",
            [*_SERVICE_LABELS, "status"],
        )

        # Task metrics (aggregated per batch)
        self.task_success = Counter(
            "task_success",
            "Total successful tasks across all batches",
            _SERVICE_LABELS,
        )
        self.task_failed = Counter(
            "task_failed",
            "Total failed tasks across all batches",
            _SERVICE_LABELS,
        )
        self.longest_task_duration_ms = Gauge(
            "longest_task_duration_ms",
            "Duration of the slowest task in the last batch (ms)",
            _SERVICE_LABELS,
        )

        # Sampled metrics (gauges)
        self.active = Gauge(
            "batch_active",
            "Batch is currently running (1=active, 0=inactive)",
            _SERVICE_LABELS,
        )
        self.progress = Gauge(
            "batch_progress",
            "Batch completion ratio (0.0 to 1.0)",
            _SERVICE_LABELS,
        )
        self.cpu_percent = Gauge(
            "batch_cpu_percent",
            "CPU usage percentage during batch execution",
            _SERVICE_LABELS,
        )
        self.memory_bytes = Gauge(
            "batch_memory_bytes",
            "Memory usage (RSS) in bytes during batch execution",
            _SERVICE_LABELS,
        )
        self.kb_sent = Gauge(
            "batch_kb_sent",
            "Network KB sent since batch start",
            _SERVICE_LABELS,
        )
        self.kb_recv = Gauge(
            "batch_kb_recv",
            "Network KB received since batch start",
            _SERVICE_LABELS,
        )

        # Timing metrics (for stream services)
        self.wait_seconds = Gauge(
            "batch_wait_seconds",
            "Seconds waited since last batch ended (streams only)",
            _SERVICE_LABELS,
        )
        self.ended_at_timestamp = Gauge(
            "batch_ended_at_timestamp",
            "Unix timestamp when last batch ended",
            _SERVICE_LABELS,
        )


# =============================================================================
# Singleton Instances
# =============================================================================

service_metrics = ServiceMetrics()
batch_metrics = BatchMetrics()

# =============================================================================
# Utility Exports
# =============================================================================

__all__ = [
    "service_metrics",
    "batch_metrics",
    "ServiceMetrics",
    "BatchMetrics",
    "REGISTRY",
    "generate_latest",
    "CONTENT_TYPE_LATEST",
    "Gauge",
    "Counter",
    "Histogram",
]
