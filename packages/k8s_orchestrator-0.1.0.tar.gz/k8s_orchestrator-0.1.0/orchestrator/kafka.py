"""
Kafka infrastructure - producer/consumer creation, topic management, and messaging.

Contains:
- Topic configuration and management
- Producer/consumer creation
- CommandBus: Scheduler sends commands to workers (RUN, KILL)
- EventBus: Services publish heartbeat events

Usage:
    from orchestrator import command_bus, event_bus, Constants

    # Scheduler sends commands (by service UUID)
    trace_id = command_bus.send_command(service_id, Constants.Command.RUN)

    # ServiceRunner subscribes to commands (by service UUID)
    subscription = command_bus.subscribe(service_id, handle_command)
    subscription.run_forever()

    # Services publish events (timestamp auto-filled)
    event_bus.publish(Message.Heartbeat(service_id="uuid-here", status=Service.Enums.Status.PROCESSING))
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from kafka import KafkaConsumer, KafkaProducer, TopicPartition
from kafka.admin import KafkaAdminClient
from kafka.errors import KafkaError as _KafkaError

from .config import get_project_config

# Re-export KafkaError for consumers
KafkaError = _KafkaError
from .constants import Constants
from .messages import Message
from .loggers import log

logger = log


# =============================================================================
# Topic Names (derived from project config)
# =============================================================================


def get_commands_topic() -> str:
    """Commands topic: {project_name}.commands"""
    return f"{get_project_config().project_name}.commands"


def get_events_topic() -> str:
    """Events topic: {project_name}.events"""
    return f"{get_project_config().project_name}.events"


def _get_dlq_topic() -> str:
    """Dead letter queue topic: {project_name}.dlq"""
    return f"{get_project_config().project_name}.dlq"


def _get_group_prefix() -> str:
    """Consumer group prefix: {project_name}.{env}"""
    config = get_project_config()
    return f"{config.project_name}.{config.env}"


def _get_bootstrap_servers() -> str:
    """Kafka bootstrap servers from infra config."""
    return get_project_config().infra.kafka_url


def get_topic_configs() -> list:
    """Get topic configurations for creation (framework topics)."""
    return [
        {
            "name": get_commands_topic(),
            "partitions": 3,
            "replication_factor": 1,
            "config": {"retention.ms": str(7 * 24 * 60 * 60 * 1000)},  # 7 days
        },
        {
            "name": get_events_topic(),
            "partitions": 3,
            "replication_factor": 1,
            "config": {"retention.ms": str(7 * 24 * 60 * 60 * 1000)},  # 7 days
        },
        {
            "name": _get_dlq_topic(),
            "partitions": 1,
            "replication_factor": 1,
            "config": {"retention.ms": str(30 * 24 * 60 * 60 * 1000)},  # 30 days
        },
    ]


def ensure_topics(topic_configs: list = None) -> Dict[str, bool]:
    """
    Ensure Kafka topics exist, creating them if necessary.

    Args:
        topic_configs: List of topic configurations. If None, uses get_topic_configs().

    Returns:
        Dict mapping topic names to whether they were created (True) or already existed (False).
    """
    from kafka.admin import NewTopic

    if topic_configs is None:
        topic_configs = get_topic_configs()

    admin = KafkaAdminClient(bootstrap_servers=_get_bootstrap_servers())
    result = {}

    try:
        existing_topics = set(admin.list_topics())

        topics_to_create = []
        for tc in topic_configs:
            if tc["name"] not in existing_topics:
                topics_to_create.append(NewTopic(
                    name=tc["name"],
                    num_partitions=tc.get("partitions", 3),
                    replication_factor=tc.get("replication_factor", 1),
                    topic_configs=tc.get("config", {}),
                ))
                result[tc["name"]] = True
            else:
                result[tc["name"]] = False
                logger.debug("topic_exists", topic=tc["name"])

        if topics_to_create:
            admin.create_topics(topics_to_create)
            for t in topics_to_create:
                logger.info("topic_created", topic=t.name)

    finally:
        admin.close()

    return result


def clear_topics(topics: List[str] = None) -> Dict[str, int]:
    """
    Clear all messages from Kafka topics by deleting records up to end offset.

    This is useful during bootstrap to ensure stale messages from previous
    runs don't affect new processes.

    Args:
        topics: List of topic names to clear. If None, clears commands and events topics.

    Returns:
        Dict mapping topic names to number of records deleted.
    """
    if topics is None:
        topics = [get_commands_topic(), get_events_topic()]

    admin = KafkaAdminClient(bootstrap_servers=_get_bootstrap_servers())
    consumer = KafkaConsumer(bootstrap_servers=_get_bootstrap_servers())

    result = {}

    try:
        for topic in topics:
            # Get partitions for this topic
            partitions = consumer.partitions_for_topic(topic)
            if not partitions:
                logger.warning("topic_not_found", topic=topic)
                result[topic] = 0
                continue

            # Get end offsets for all partitions
            topic_partitions = [TopicPartition(topic, p) for p in partitions]
            end_offsets = consumer.end_offsets(topic_partitions)
            begin_offsets = consumer.beginning_offsets(topic_partitions)

            # Build records_to_delete: dict of TopicPartition -> offset
            records_to_delete = {}
            total_deleted = 0
            for tp, end_offset in end_offsets.items():
                begin_offset = begin_offsets.get(tp, 0)
                if end_offset > begin_offset:
                    records_to_delete[tp] = end_offset
                    total_deleted += end_offset - begin_offset

            if records_to_delete:
                try:
                    admin.delete_records(records_to_delete)
                except AttributeError:
                    logger.warning("delete_records_not_supported", topic=topic)
                logger.info("topic_cleared", topic=topic, records=total_deleted)
            else:
                logger.debug("topic_empty", topic=topic)

            result[topic] = total_deleted

    finally:
        consumer.close()
        admin.close()

    return result


# =============================================================================
# Producer
# =============================================================================

_producer: Optional[KafkaProducer] = None


def get_producer() -> KafkaProducer:
    """Get or create singleton Kafka producer."""
    global _producer
    if _producer is None:
        _producer = KafkaProducer(
            bootstrap_servers=_get_bootstrap_servers(),
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            acks="all",
            retries=3,
        )
    return _producer


def close_producer() -> None:
    """Close the producer connection."""
    global _producer
    if _producer:
        _producer.close()
        _producer = None


def send_message(topic: str, key: str, value: dict) -> None:
    """Send a message to a Kafka topic."""
    producer = get_producer()
    producer.send(topic=topic, key=key, value=value)
    producer.flush()


# =============================================================================
# Consumer
# =============================================================================


def create_consumer(
    service_name: str,
    topic: str = None,
    auto_offset_reset: str = "latest",
    group_suffix: str = None,
) -> KafkaConsumer:
    """
    Create a Kafka consumer for a service.

    Note: Does NOT use group_id because kafka-python has a bug where
    group_id causes poll() to return no messages.

    Args:
        service_name: Name of the service (used in consumer client_id)
        topic: Topic to subscribe to (defaults to commands topic)
        auto_offset_reset: Where to start if no offset exists
        group_suffix: Unused, kept for API compatibility

    Returns:
        Configured KafkaConsumer
    """
    if topic is None:
        topic = get_commands_topic()

    # Build client_id for identification (not group coordination)
    client_id = f"{_get_group_prefix()}.{service_name}"
    if group_suffix:
        client_id = f"{client_id}.{group_suffix}"

    return KafkaConsumer(
        topic,
        bootstrap_servers=_get_bootstrap_servers(),
        client_id=client_id,
        # NO group_id - kafka-python bug causes poll() to return 0 messages
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset=auto_offset_reset,
        enable_auto_commit=False,  # No group means no auto-commit
        consumer_timeout_ms=1000,
    )

# =============================================================================
# Command Bus - Scheduler to Workers
# =============================================================================


class CommandBus:
    """
    Command bus for service communication.

    Scheduler uses send_command() to dispatch work.
    ServiceRunners use subscribe() to receive commands.
    """

    def send_command(
        self,
        service_id: str,
        command: str,
        config_overrides: Dict[str, Any] = None,
        reason: str = None,
    ) -> str:
        """
        Send a command to a service.

        Args:
            service_id: Target service UUID
            command: Command to send (RUN, KILL)
            config_overrides: Optional config overrides for this run
            reason: Optional reason for the command

        Returns:
            trace_id for correlation
        """
        trace_id = str(uuid.uuid4())
        timestamp = datetime.now(timezone.utc)

        message = {
            "service_id": service_id,
            "command": command,
            "trace_id": trace_id,
            "timestamp": timestamp.isoformat(),
            "config_overrides": config_overrides or {},
            "reason": reason,
        }

        producer = get_producer()
        producer.send(
            topic=get_commands_topic(),
            key=service_id,
            value=message,
        )
        producer.flush()

        logger.debug("command_sent", command=command, service_id=service_id, trace_id=trace_id)
        return trace_id

    def subscribe(
        self,
        service_id: str,
        handler: Callable[[Constants.Command], None],
    ) -> "CommandSubscription":
        """
        Subscribe to commands for a specific service.

        Args:
            service_id: Service UUID to subscribe for
            handler: Callback for each command

        Returns:
            CommandSubscription that can be polled or run in a loop
        """
        return CommandSubscription(service_id, handler)

    def close(self) -> None:
        """Close the producer connection."""
        close_producer()


class CommandSubscription:
    """Subscription to commands for a specific service."""

    def __init__(self, service_id: str, handler: Callable[[Constants.Command], None]):
        self.service_id = service_id
        self.handler = handler
        self._consumer = None
        self._running = False

    def _get_consumer(self):
        """Get or create Kafka consumer."""
        if self._consumer is None:
            self._consumer = create_consumer(self.service_id)
            # Warm-up poll
            self._consumer.poll(timeout_ms=500)
        return self._consumer

    def poll(self, timeout_ms: int = 1000) -> int:
        """
        Poll for commands and dispatch to handler.

        Args:
            timeout_ms: How long to wait for messages

        Returns:
            Number of commands processed
        """
        consumer = self._get_consumer()
        count = 0

        try:
            records = consumer.poll(timeout_ms=timeout_ms)
            if records:
                logger.debug(
                    "poll_received",
                    partitions=len(records),
                    total_messages=sum(len(msgs) for msgs in records.values()),
                    service_id=self.service_id[:8],
                )

            for topic_partition, messages in records.items():
                for msg in messages:
                    msg_service_id = msg.value.get("service_id")

                    # Filter for our service
                    if msg_service_id != self.service_id:
                        continue

                    try:
                        cmd = Constants.Command(
                            service_id=msg.value["service_id"],
                            command=msg.value["command"],
                            trace_id=msg.value.get("trace_id", ""),
                            config_overrides=msg.value.get("config_overrides"),
                        )
                        self.handler(cmd)
                        count += 1
                    except Exception as e:
                        logger.exception("command_handler_error", message="Error handling command", error=str(e))

        except KafkaError as e:
            logger.error("kafka_error", message="Error polling for commands", error=str(e))

        return count

    def run_forever(self) -> None:
        """Run poll loop forever until stop() is called."""
        self._running = True

        while self._running:
            try:
                self.poll()
            except Exception as e:
                logger.exception("poll_error", message="Error in command poll loop", error=str(e))

    def stop(self) -> None:
        """Stop the poll loop and close consumer."""
        self._running = False

        if self._consumer:
            self._consumer.close()
            self._consumer = None


# =============================================================================
# Event Bus - Unified Router for All Service Events
# =============================================================================


class EventBus:
    """
    Unified event bus for publishing service events to Kafka.

    All events (Heartbeat, StaleDetected, CrashDetected) go to events topic.
    Services only need to call event_bus.publish().
    """

    def publish(self, event: Message.Any) -> None:
        """
        Publish a service event to Kafka.

        Args:
            event: Any service event (Heartbeat, StaleDetected, CrashDetected, ServiceDeletion)
        """
        # ServiceDeletion uses service_ids (plural), others use service_id
        if isinstance(event, Message.ServiceDeletion):
            key = "deletion"
        else:
            key = event.service_id or ""

        data = event.model_dump(mode="json")
        send_message(topic=get_events_topic(), key=key, value=data)

        # Structured logging for each event type
        if isinstance(event, Message.ServiceDeletion):
            logger.debug("event_published", event_type=event.event_type, count=len(event.service_ids), reason=event.reason)
        elif isinstance(event, Message.Heartbeat):
            status = event.status.name if event.status else None
            logger.debug("event_published", event_type="heartbeat", service_id=key, status=status)
        else:
            logger.debug("event_published", event_type=event.event_type, service_id=key, reason=event.reason)



# =============================================================================
# Singleton Instances
# =============================================================================

command_bus = CommandBus()
event_bus = EventBus()


# =============================================================================
# Convenience exports
# =============================================================================

COMMANDS_TOPIC = property(lambda self: get_commands_topic())
EVENTS_TOPIC = property(lambda self: get_events_topic())
DLQ_TOPIC = property(lambda self: _get_dlq_topic())
