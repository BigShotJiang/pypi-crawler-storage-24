"""
System services for the orchestrator framework.

These are always-required services that manage the orchestrator lifecycle:
- Scheduler: Central orchestrator that manages cron schedules and retries
- LifecycleManager: Manages service lifecycle events and status updates

Optional system services (see orchestrator.models.bootstrap_registry):
- InfraMonitor: Monitors infrastructure component health (opt-in)
- Archiver: Archives old data to cold storage (opt-in)

Note: Service identities are now defined in orchestrator.registry.
Import identity functions from the main orchestrator module:
    from orchestrator import get_scheduler_identity
"""

from .archiver import Archiver
from .infra_monitor import InfraMonitor
from .lifecycle_manager import LifecycleManager
from .scheduler import Scheduler

__all__ = [
    # Core system services (always required)
    "Scheduler",
    "LifecycleManager",
    # Optional system services
    "InfraMonitor",
    "Archiver",
]
