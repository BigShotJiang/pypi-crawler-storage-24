"""
Scheduler - Orchestrates service scheduling and retry.

Runs as a ScheduledService triggered by its own cron schedule (every 10 seconds):
1. Bootstraps stream services at startup (once)
2. Checks cron schedules and triggers services that are due
3. Retries failed services after cooldown

The scheduler schedules itself via cron_dispatch - when it checks cron schedules,
it includes itself and sends a RUN command to trigger the next execution.

Note: Dependency checking is handled by ServiceBase. Services monitor their own
dependencies and mark themselves FAILED with DEPENDENCY reason. Scheduler then
retries them when dependencies recover.

Stale detection is handled by LifecycleManager, which monitors heartbeats and
marks services FAILED with STALE reason when they stop responding.

Retry Logic:
    Scheduler owns retry. On failure, services stay FAILED.
    Scheduler detects FAILED services and sends RUN after cooldown
    (up to max_retry_count).

Process Management:
    Process spawning is handled by ProcessManager (infra_client.manager).
    Projects use ProcessManager in their __main__.py to spawn all services.

Usage:
    # As entry point (in if __name__ == "__main__"):
    Scheduler.start({"env": "dev", "project_name": "my_project"})

    # Or via ProcessManager which spawns it as subprocess
"""

import re
import threading
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Set

from croniter import croniter

from ..config import get_project_config
from ..models import get_db_session
from ..constants import Constants, FailureReason
from ..events import Result
from ..kafka import command_bus
from ..loggers import log, LogContext
from ..services import Service
from ..scheduled import ScheduledService

logger = log

# Stage shortcut
Stage = Constants.Stage


# =============================================================================
# Scheduler Service
# =============================================================================


class Scheduler(ScheduledService):
    """
    Central orchestrator service.

    Responsibilities:
    - Cron scheduling: Trigger services on schedule (including itself)
    - Retry: Re-run failed services after cooldown
    - Bootstrap: Send RUN commands to stream services at startup
    - Kill: Send KILL commands to services (via static methods)

    Process spawning is handled by ProcessManager (infra_client.manager).
    Stale detection is handled by LifecycleManager.
    Dependency checking is handled by ServiceBase.

    Static methods for service control:
    - kill_service(service_id, reason): Kill a specific service
    - kill_all_services(reason): Kill all running services

    The reason parameter uses FailureReason enum (default: MANUAL).
    """

    # Auto-start so scheduler begins working immediately
    auto_start = True

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(Service.Registry.System.SCHEDULER)
        super().__init__(identity)

        # Auto-discover stream services that need RUN commands
        self._stream_services = self._get_stream_services()
        self._startup_done = False

        # Pending retry tracking: {service_name: timestamp_when_RUN_sent}
        # Prevents duplicate RUN commands while waiting for DB sync
        self._pending_retries: dict[str, datetime] = {}

        # Self-scheduling timer: triggers next run at cron interval
        self._self_timer: Optional[threading.Timer] = None
        self._timer_lock = threading.Lock()

    def _get_stream_services(self) -> List[str]:
        """Get all registered stream services that need RUN commands at startup.

        Returns:
            List of service names for stream services (excluding scheduler)
        """
        services = Service.Table.query(execution_type=Service.Enums.ExecutionType.STREAM)
        return [svc.service_name for svc in services if svc.service_name != str(self._identity.service_name)]

    # =========================================================================
    # Lifecycle Hooks
    # =========================================================================

    def on_start(self) -> None:
        """Called when scheduler starts."""
        # Validate scheduler interval < observability_interval
        config = get_project_config()
        cron_schedule = self._identity.cron_schedule
        if cron_schedule:
            # Parse cron to get interval (assumes */N format for seconds)
            match = re.match(r"\*/(\d+)", cron_schedule)
            if match:
                interval = int(match.group(1))
                if interval >= config.observability_interval:
                    raise ValueError(
                        f"Scheduler interval ({interval}s) must be less than "
                        f"observability_interval ({config.observability_interval}s)"
                    )
        logger.debug("scheduler_on_start")

    def on_stop(self) -> None:
        """Called when scheduler stops."""
        self._cancel_self_timer()
        logger.debug("scheduler_on_stop")

    def _cancel_self_timer(self) -> None:
        """Cancel any pending self-scheduling timer."""
        with self._timer_lock:
            if self._self_timer:
                self._self_timer.cancel()
                self._self_timer = None

    def _schedule_next_run(self) -> None:
        """Schedule the next scheduler run via timer.

        This is the self-scheduling mechanism. After each run completes,
        a timer is started that will send RUN_NOW at the next cron interval.
        """
        cron_schedule = self._identity.cron_schedule
        if not cron_schedule:
            return

        now = datetime.now(timezone.utc)
        cron = croniter(cron_schedule, now, second_at_beginning=True)
        next_run = cron.get_next(datetime)
        delay = (next_run - now).total_seconds()

        # Ensure minimum delay to prevent tight loops
        delay = max(delay, 0.1)

        def trigger_self():
            """Timer callback: send RUN_NOW to self."""
            if self.stop_requested:
                return
            command_bus.send_command(str(self._identity.id), Constants.Command.RUN_NOW)

        with self._timer_lock:
            # Cancel any existing timer
            if self._self_timer:
                self._self_timer.cancel()

            self._self_timer = threading.Timer(delay, trigger_self)
            self._self_timer.daemon = True
            self._self_timer.start()
            logger.debug("self_timer_scheduled", delay_seconds=round(delay, 2))

    # =========================================================================
    # ScheduledService Implementation
    # =========================================================================

    def get_tasks(self) -> List[dict]:
        """Generate scheduler tasks for this execution cycle.

        Returns tasks for:
        - Bootstrap: Send RUN to stream services (once)
        - Retry: Re-run failed services
        - Cron: Trigger scheduled services
        """
        tasks = []
        
        # Bootstrap task (only once)
        if not self._startup_done:
            tasks.append({
                "id": "scheduler_bootstrap_task",
                "description": "Scheduler is Bootstraping stream services",
                "type": "bootstrap",
            })

        # Retry task
        tasks.append({
            "id": "scheduler_retry_task",
            "description": "Scheduler is retrying failed services",
            "type": "retry",
        })

        # Cron task
        tasks.append({
            "id": "scheduler_cron_task",
            "description": "Scheduler is checking cron schedules",
            "type": "cron",
        })

        return tasks

    def on_step(self, task: dict) -> Result:
        """Process a scheduler task."""
        task_type = task.get("type")

        if task_type == "bootstrap":
            self._send_startup_commands()
        elif task_type == "retry":
            self._retry_failed_services()
        elif task_type == "cron":
            self._check_cron_schedules()
            # Schedule next scheduler run via timer (self-scheduling)
            self._schedule_next_run()

        return Result.ok()

    # =========================================================================
    # Bootstrap Stream Services
    # =========================================================================

    def _send_startup_commands(self) -> None:
        """Bootstrap StreamServices (only once on startup)."""
        if self._startup_done:
            return

        for name in self._stream_services:
            with LogContext(stage=Stage.SPAWN):
                logger.info("bootstrap_stream", service_name=name)
                services = Service.Table.query(name=name)
                if services:
                    command_bus.send_command(str(services[0].id), Constants.Command.RUN)

        self._startup_done = True

    # =========================================================================
    # Cron Scheduling
    # =========================================================================

    def _check_cron_schedules(self) -> None:
        """Check service schedules and trigger those that are due.

        Note: The scheduler itself is NOT dispatched here. Self-scheduling is
        handled by _schedule_next_run() which uses a timer to send RUN_NOW
        at the next cron interval.
        """
        business_services = Service.Table.query(category=Service.Enums.Category.BUSINESS) or []
        system_services = Service.Table.query(category=Service.Enums.Category.SYSTEM) or []
        services = business_services + system_services

        if not services:
            return

        now = datetime.now(timezone.utc)

        for svc in services:
            service_name = svc.service_name
            cron_schedule = svc.cron_schedule
            last_run_at = svc.last_run_at

            if not cron_schedule:
                continue

            # Skip self - scheduler uses timer-based self-scheduling
            is_self = service_name == str(self._identity.service_name)
            if is_self:
                continue

            # Skip active services
            if svc.status_enum and svc.status_enum.is_active:
                continue

            # Skip if next_run_at in future
            if svc.next_run_at and svc.next_run_at > now:
                continue

            if self._is_due(cron_schedule, last_run_at):
                with LogContext(stage=Stage.SCHEDULE, service_name=service_name):
                    logger.info("cron_dispatch", service_name=service_name)
                    # Use RUN_NOW to bypass next_run_at check in _spawn_worker
                    command_bus.send_command(str(svc.id), Constants.Command.RUN_NOW)

                # Update next_run_at for next cycle
                cron = croniter(cron_schedule, now, second_at_beginning=True)
                next_run = cron.get_next(datetime)
                self._update_next_run(service_name, next_run)

    def _is_due(self, cron_schedule: str, last_run_at: Optional[datetime]) -> bool:
        """Check if a service is due based on cron schedule."""
        if not cron_schedule:
            return False

        now = datetime.now(timezone.utc)

        if last_run_at is None:
            return True

        if last_run_at.tzinfo is None:
            last_run_at = last_run_at.replace(tzinfo=timezone.utc)

        cron = croniter(cron_schedule, last_run_at, second_at_beginning=True)
        next_run = cron.get_next(datetime)

        return next_run <= now

    def _update_next_run(self, service_name: str, next_run: datetime) -> None:
        """Update next_run_at for a service."""
        with get_db_session() as db:
            svc = db.query(Service.Table).filter_by(service_name=service_name).first()
            if svc:
                svc.next_run_at = next_run

    # =========================================================================
    # Retry Failed Services
    # =========================================================================

    def _retry_failed_services(self) -> int:
        """Retry FAILED services based on failure_reason strategy.

        Strategies by failure_reason:
        - DEPENDENCY: Wait for dependencies to recover, then retry immediately
                      (no cooldown, doesn't count against retry limit)
        - EXCEPTION/ITEM_FAILURE: Use configured cooldown and max_retry_count
        - STALE: Use configured cooldown, limited retries
        - None/unknown: Treat as EXCEPTION

        Returns:
            Number of services sent RUN commands
        """
        config = get_project_config()
        now = datetime.now(timezone.utc)
        retried = 0

        # Get unhealthy services for dependency checks
        all_services = Service.Table.query()
        unhealthy = {
            svc.service_name
            for svc in all_services
            if svc.status == Service.Enums.Status.FAILED.value
        }

        for svc in all_services:
            service_name = svc.service_name

            # Debug: log all failed services
            if svc.status == Service.Enums.Status.FAILED.value:
                with LogContext(stage=Stage.RETRY, service_name=service_name):
                    logger.debug(
                        "retry_candidate",
                        status=svc.status,
                        failure_count=svc.failure_count,
                        failure_reason=svc.failure_reason,
                        last_failure_at=svc.last_failure_at.isoformat() if svc.last_failure_at else None,
                    )

            # Clear pending retry if service is no longer FAILED
            # (the retry succeeded and DB synced)
            if svc.status != Service.Enums.Status.FAILED.value:
                if service_name in self._pending_retries:
                    with LogContext(stage=Stage.RETRY, service_name=service_name):
                        logger.debug(
                            "retry_pending_cleared",
                            reason="status_changed",
                            status=svc.status,
                        )
                    self._pending_retries.pop(service_name)
                continue

            # Skip if we already sent a retry RUN (waiting for DB to sync)
            # Clear pending if failure_count increased (service failed again after retry)
            pending_at = self._pending_retries.get(service_name)
            if pending_at:
                # If failure_count increased since we sent RUN, the retry failed
                # Clear pending so we can retry again
                if svc.last_failure_at and svc.last_failure_at > pending_at:
                    with LogContext(stage=Stage.RETRY, service_name=service_name):
                        logger.debug(
                            "retry_pending_cleared",
                            reason="new_failure",
                            failure_count=svc.failure_count,
                        )
                    self._pending_retries.pop(service_name)
                else:
                    with LogContext(stage=Stage.RETRY, service_name=service_name):
                        logger.debug(
                            "retry_skipped",
                            reason="pending",
                            pending_since=pending_at.isoformat(),
                        )
                    continue

            # Get failure reason (default to EXCEPTION for backward compatibility)
            failure_reason = svc.failure_reason or FailureReason.EXCEPTION

            # Handle DEPENDENCY failures specially
            if failure_reason == FailureReason.DEPENDENCY:
                if self._retry_dependency_failure(svc, unhealthy, now):
                    retried += 1
                continue

            # Get retry config for this service
            svc_config = svc.config or {}
            retry_enabled = svc_config.get("retry_enabled", True)
            max_retry_count = svc_config.get("max_retry_count", config.max_retry_count)
            cooldown_seconds = svc_config.get("retry_cooldown_seconds", config.retry_cooldown)

            if not retry_enabled:
                with LogContext(stage=Stage.RETRY, service_name=service_name):
                    logger.debug("retry_skipped", reason="disabled")
                continue

            # Check if exhausted
            if svc.failure_count >= max_retry_count:
                with LogContext(stage=Stage.RETRY, service_name=service_name):
                    logger.debug(
                        "retry_skipped",
                        reason="exhausted",
                        failure_count=svc.failure_count,
                        max_retry_count=max_retry_count,
                    )
                continue

            # Check cooldown
            if svc.last_failure_at:
                cooldown_end = svc.last_failure_at + timedelta(seconds=cooldown_seconds)
                if now < cooldown_end:
                    remaining = (cooldown_end - now).total_seconds()
                    with LogContext(stage=Stage.RETRY, service_name=service_name):
                        logger.debug(
                            "retry_skipped",
                            reason="cooldown",
                            remaining_seconds=round(remaining, 1),
                        )
                    continue

            # Retry: send RUN_NOW to bypass next_run_at check
            with LogContext(stage=Stage.RETRY, service_name=service_name):
                logger.info(
                    "retrying",
                    message=f"Retry {svc.failure_count}/{max_retry_count} for {failure_reason}",
                    failure_reason=failure_reason,
                    failure_count=svc.failure_count,
                    max_retry_count=max_retry_count,
                )
                command_bus.send_command(str(svc.id), Constants.Command.RUN_NOW)
            self._pending_retries[service_name] = now
            retried += 1

        return retried

    def _retry_dependency_failure(
        self, svc, unhealthy: Set[str], now: datetime
    ) -> bool:
        """Handle retry for DEPENDENCY failures.

        Special strategy: Wait for dependencies to recover, then retry immediately.
        No cooldown, doesn't count against retry limit.

        Returns:
            True if retry was triggered, False otherwise
        """
        service_name = svc.service_name
        dependencies = svc.dependencies or []
        still_failed = set(dependencies) & unhealthy

        if still_failed:
            with LogContext(stage=Stage.RETRY, service_name=service_name):
                logger.debug(
                    "retry_skipped",
                    reason="dependency_still_failed",
                    failed_deps=list(still_failed),
                )
            return False

        # All dependencies recovered - clear failure and retry immediately
        recovered_dep = "dependency"
        if svc.last_error:
            match = re.search(r"Dependency '([^']+)'", svc.last_error)
            if match:
                recovered_dep = match.group(1)

        with LogContext(stage=Stage.RETRY, service_name=service_name):
            logger.info(
                "dependency_restored",
                message=f"Dependency '{recovered_dep}' recovered, restarting service",
                recovered_dependency=recovered_dep,
            )

        # Check if manually stopped
        if self._is_manually_stopped(svc):
            with LogContext(stage=Stage.RETRY, service_name=service_name):
                logger.info(
                    "restart_skipped",
                    message="Service was manually stopped, not restarting",
                )
            return False

        # Clear failure state and retry
        with get_db_session() as db:
            service = db.query(Service.Table).filter_by(id=svc.id).first()
            if service:
                service.last_error = None
                service.failure_reason = None
                # Don't increment failure_count for dependency failures

        # Use RUN_NOW to bypass next_run_at check
        command_bus.send_command(str(svc.id), Constants.Command.RUN_NOW)
        self._pending_retries[service_name] = now
        return True

    def _is_manually_stopped(self, svc) -> bool:
        """Check if a service was manually stopped."""
        with get_db_session() as db:
            service = db.query(Service.Table).filter_by(id=svc.id).first()
            return service and service.stop_requested

    # =========================================================================
    # Service Control (Static Methods)
    # =========================================================================

    @staticmethod
    def kill_service(service_id: str, reason: FailureReason = FailureReason.MANUAL) -> bool:
        """
        Send KILL command to a specific service.

        Args:
            service_id: The UUID of the service to kill
            reason: FailureReason for the kill (default: MANUAL)

        Returns:
            True if command was sent successfully
        """
        try:
            command_bus.send_command(service_id, Constants.Command.KILL, reason=reason.value)
            return True
        except Exception:
            return False

    @staticmethod
    def kill_all_services(reason: FailureReason = FailureReason.MANUAL) -> int:
        """
        Send KILL command to all running services.

        Used by ProcessManager during orchestrator shutdown to trigger graceful
        shutdown of all services before terminating subprocesses.

        Args:
            reason: FailureReason for the kill (default: MANUAL)

        Returns:
            Number of KILL commands sent
        """
        # Get all service IDs that are currently running
        # Extract IDs inside session to avoid DetachedInstanceError
        with get_db_session() as db:
            service_ids = [
                str(svc.id) for svc in db.query(Service.Table).filter(
                    Service.Table.status.in_(["running", "listening", "processing"])
                ).all()
            ]

        count = 0
        for service_id in service_ids:
            if Scheduler.kill_service(service_id, reason):
                count += 1

        return count


if __name__ == "__main__":
    import json
    import sys

    Scheduler.start(json.loads(sys.argv[1]))
