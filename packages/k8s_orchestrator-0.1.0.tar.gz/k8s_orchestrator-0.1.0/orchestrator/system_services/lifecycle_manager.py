"""
LifecycleManager - Centralized service lifecycle management.

Responsibilities:
1. Receives lifecycle events (heartbeats) and maintains per-service status queues
2. Syncs status updates to database with deduplication
3. Detects stale services (no heartbeat while active) and marks them FAILED
4. Updates Prometheus metrics

Timing (REQUIRED for correctness):
    observability_interval config setting ensures each state transition persists
    long enough to be scraped. LifecycleManager queues ALL incoming states and
    pops ONE per sync cycle, guaranteeing no state is missed.

Runs as a StreamService triggered by Scheduler on boot.

Usage:
    # Projects include LifecycleManager in their service definitions
    LifecycleManager.start()
"""

import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Deque, Dict, Optional
from uuid import UUID

from ..config import get_project_config
from ..events import Result
from ..models import get_db_session
from ..constants import Constants, FailureReason
from ..messages import Message
from ..kafka import get_events_topic
from ..loggers import log, LogContext
from ..metrics import batch_metrics, service_metrics
from ..services import Service
from ..stream import StreamService

logger = log

# Stage shortcut
Stage = Constants.Stage


# =============================================================================
# Metrics Helpers
# =============================================================================


def _update_status_gauges(service_id: str, status: Service.Enums.Status) -> None:
    """Update status and healthy gauges for a service."""
    identity = Service.Table.get_identity(UUID(service_id))
    if identity:
        labels = identity.prometheus_labels
        service_metrics.status.labels(**labels).set(status.numeric)

        # Healthy logic:
        # - Task services: healthy if not FAILED (IDLE is normal between runs)
        # - Stream services: healthy if not FAILED and not IDLE (should be running)
        if identity.execution_type == Service.Enums.ExecutionType.STREAM:
            is_healthy = status not in (Service.Enums.Status.FAILED, Service.Enums.Status.IDLE)
        else:
            is_healthy = status != Service.Enums.Status.FAILED
        service_metrics.healthy.labels(**labels).set(1 if is_healthy else 0)

        # Initialize batch counters so Prometheus can track increase()
        # Accessing .labels() creates the counter with value 0 if it doesn't exist
        batch_metrics.completed_total.labels(**labels, status="success")
        batch_metrics.completed_total.labels(**labels, status="failed")
        batch_metrics.task_success.labels(**labels)
        batch_metrics.task_failed.labels(**labels)

        logger.debug(
            "gauge_updated",
            service_id=service_id,
            service_name=identity.service_name,
            status=status.name,
            status_numeric=status.numeric,
        )
    else:
        logger.warning(
            "gauge_update_skipped",
            service_id=service_id,
            reason="identity_not_found",
        )


def _update_batch_progress(
    service_id: str,
    progress: float,
    task_count: int,
    cpu_percent: Optional[float] = None,
    memory_bytes: Optional[int] = None,
    kb_sent: Optional[int] = None,
    kb_recv: Optional[int] = None,
    wait_ms: Optional[float] = None,
) -> None:
    """Update batch progress gauges (sampled metrics)."""
    identity = Service.Table.get_identity(UUID(service_id))
    if not identity:
        return
    labels = identity.prometheus_labels

    # Update batch gauges
    batch_metrics.active.labels(**labels).set(1)
    batch_metrics.progress.labels(**labels).set(progress)

    # Update batch resource gauges
    if cpu_percent is not None:
        batch_metrics.cpu_percent.labels(**labels).set(cpu_percent)
    if memory_bytes is not None:
        batch_metrics.memory_bytes.labels(**labels).set(memory_bytes)
    if kb_sent is not None:
        batch_metrics.kb_sent.labels(**labels).set(kb_sent)
    if kb_recv is not None:
        batch_metrics.kb_recv.labels(**labels).set(kb_recv)

    # Update wait time metric (streams only, set at batch start)
    # Prometheus uses seconds by convention
    if wait_ms is not None:
        batch_metrics.wait_seconds.labels(**labels).set(wait_ms / 1000)

    logger.debug(
        "batch_progress_updated",
        service_id=service_id,
        progress=progress,
        task_count=task_count,
    )


def _record_batch_complete(
    service_id: str,
    duration_ms: float,
    task_count: int,
    task_success: int,
    task_failed: int,
    longest_task_duration_ms: float,
    status: str,
) -> None:
    """Record batch completion metrics."""
    identity = Service.Table.get_identity(UUID(service_id))
    if not identity:
        return
    labels = identity.prometheus_labels

    # Reset active gauge
    batch_metrics.active.labels(**labels).set(0)
    batch_metrics.progress.labels(**labels).set(0)

    # Record completion metrics (Prometheus uses seconds by convention)
    batch_metrics.last_duration_seconds.labels(**labels).set(duration_ms / 1000)
    batch_metrics.size.labels(**labels).observe(task_count)
    batch_metrics.completed_total.labels(**labels, status=status).inc()

    # Record task metrics
    if task_success > 0:
        batch_metrics.task_success.labels(**labels).inc(task_success)
    if task_failed > 0:
        batch_metrics.task_failed.labels(**labels).inc(task_failed)
    batch_metrics.longest_task_duration_ms.labels(**labels).set(longest_task_duration_ms)

    # Record batch end timestamp (for wait time calculations)
    batch_metrics.ended_at_timestamp.labels(**labels).set(time.time())

    logger.debug(
        "batch_complete_recorded",
        service_id=service_id,
        duration_ms=round(duration_ms, 1),
        task_count=task_count,
        task_success=task_success,
        task_failed=task_failed,
        longest_task_duration_ms=round(longest_task_duration_ms, 1),
        status=status,
    )


# =============================================================================
# Per-Service Status Queue
# =============================================================================


@dataclass
class ServiceQueue:
    """Queue of pending status updates for a service, with deduplication."""

    statuses: Deque[Service.Enums.Status] = field(default_factory=deque)
    current_db_status: Optional[Service.Enums.Status] = None  # Last known DB status

    def push(self, status: Service.Enums.Status) -> None:
        """Add status to queue, deduplicating consecutive same statuses."""
        if self.statuses and self.statuses[-1] == status:
            return  # Same as last in queue, skip
        self.statuses.append(status)

    def pop(self) -> Optional[Service.Enums.Status]:
        """Get next status to persist, or None if empty."""
        if not self.statuses:
            return None
        return self.statuses.popleft()


# =============================================================================
# LifecycleManager Service
# =============================================================================


class LifecycleManager(StreamService):
    """
    Centralized service lifecycle management.

    - Receives Heartbeat events (pulses) from Kafka
    - Receives MonitoringEvent from Scheduler (stale detection, crash loop)
    - Maintains per-service queues with deduplication
    - Syncs status updates to DB every observability_interval
    - Updates Prometheus metrics directly (no intermediate Kafka topic)

    CRITICAL: observability_interval ensures all state transitions are observable.
    Queues ALL states and pops ONE per sync, guaranteeing each state persists
    long enough to be scraped.
    """

    def __init__(self) -> None:
        config = get_project_config()

        # Self-register: upsert identity to DB and get back with id populated
        identity = Service.Table.bootstrap(Service.Registry.System.LIFECYCLE_MANAGER)

        super().__init__(
            identity,
            kafka_topic=get_events_topic(),
            poll_timeout_ms=int(config.observability_interval * 1000),
        )
        self._queues: Dict[str, ServiceQueue] = defaultdict(ServiceQueue)
        self._last_sync_time: float = 0
        self._sync_interval: float = config.observability_interval
        self._lock = threading.Lock()

    def on_start(self) -> None:
        """Initialize ALL Prometheus service gauges from current DB state.

        LifecycleManager is the single owner of all service metrics:
        - registered: Set to 1 for each service in DB
        - status: Current status numeric value
        - up: 1 if service is active, 0 otherwise

        This runs before any heartbeats arrive, ensuring all services
        have initial metric values.
        """
        try:
            with get_db_session() as db:
                services = db.query(Service.Table).all()
                for svc in services:
                    # Set status/up gauges if service has a status
                    if svc.status:
                        status = Service.Enums.Status(svc.status)
                        _update_status_gauges(str(svc.id), status)

                logger.info("gauges_initialized", count=len(services))
        except Exception as e:
            logger.warning("gauge_init_error", error=str(e))

    def on_step(self, task: Any) -> Result:
        """Process incoming lifecycle event."""
        try:
            message_type = task.get("message_type")

            if message_type == Message.Type.HEARTBEAT:
                self._handle_heartbeat(task)
            elif message_type in (Message.Type.STALE_DETECTED, Message.Type.CRASH_DETECTED):
                self._handle_monitoring(task)
            elif message_type == Message.Type.SERVICE_DELETION:
                self._handle_deletion(task)

        except Exception as e:
            logger.error("task_processing_error", message="Error processing event", error=str(e))
        return Result.ok()

    def _handle_heartbeat(self, message: Any) -> None:
        """Handle heartbeat event from a service."""
        event = Message.deserialize(message)
        service_id = event.service_id
        if not service_id:
            return

        with LogContext(stage=Stage.EXECUTE, service_id=service_id):
            logger.debug(
                "heartbeat",
                service_id=service_id,
                status=event.status,
                has_payload=bool(event.payload),
            )

            if event.payload:
                payload_type = event.payload.get("type")

                # Handle batch progress (sampled metrics)
                if payload_type == Constants.BatchProgress.TYPE:
                    _update_batch_progress(
                        service_id=service_id,
                        progress=event.payload.get("progress", 0),
                        task_count=event.payload.get("task_count", 0),
                        cpu_percent=event.payload.get("cpu_percent"),
                        memory_bytes=event.payload.get("memory_bytes"),
                        kb_sent=event.payload.get("kb_sent"),
                        kb_recv=event.payload.get("kb_recv"),
                        wait_ms=event.payload.get("wait_ms"),
                    )

                # Handle batch completion
                elif payload_type == Constants.BatchComplete.TYPE:
                    _record_batch_complete(
                        service_id=service_id,
                        duration_ms=event.payload.get("duration_ms", 0),
                        task_count=event.payload.get("task_count", 0),
                        task_success=event.payload.get("task_success", 0),
                        task_failed=event.payload.get("task_failed", 0),
                        longest_task_duration_ms=event.payload.get("longest_task_duration_ms", 0),
                        status=event.payload.get("status", "success"),
                    )

                # Handle failure info (last_error and failure_reason)
                failure_reason = event.payload.get("failure_reason")
                message = event.payload.get("message")
                if event.status == Service.Enums.Status.FAILED and (failure_reason or message):
                    with get_db_session() as db:
                        svc = db.query(Service.Table).filter_by(id=service_id).first()
                        if svc:
                            if message:
                                svc.last_error = message
                            if failure_reason:
                                svc.failure_reason = failure_reason

            # Queue status update (with deduplication)
            if event.status is not None:
                with self._lock:
                    self._queues[service_id].push(event.status)

    def _handle_monitoring(self, message: Any) -> None:
        """Handle monitoring event from Scheduler (stale detection, crash loop)."""
        event = Message.deserialize(message)
        service_id = event.service_id
        if not service_id:
            return

        with LogContext(stage=Stage.EXECUTE, service_id=service_id):
            logger.info(
                "monitoring_event",
                message_type=event.message_type,
                reason=event.reason,
            )

        # Queue target status based on message type
        # CrashDetected → FAILED (terminal), everything else → IDLE (ready for restart)
        target = (
            Service.Enums.Status.FAILED
            if event.message_type == Message.Type.CRASH_DETECTED
            else Service.Enums.Status.IDLE
        )
        with self._lock:
            self._queues[service_id].push(target)

    def _handle_deletion(self, message: Any) -> None:
        """Handle service deletion request from pruner.

        1. Sets service_registered=0 for each ID (will be pushed to Mimir)
        2. Removes other metric labels for the services
        3. Deletes associated batches from DB
        4. Deletes the services from DB
        """
        event = Message.deserialize(message)
        service_ids = event.service_ids
        reason = event.reason

        if not service_ids:
            return

        with LogContext(stage=Stage.EXECUTE):
            logger.info(
                "deletion_request",
                count=len(service_ids),
                reason=reason,
            )

            deleted = []
            try:
                with get_db_session() as db:
                    for service_id in service_ids:
                        svc = db.query(Service.Table).filter_by(id=service_id).first()
                        if not svc:
                            logger.debug(
                                "deletion_skip",
                                service_id=service_id,
                                reason="not_found",
                            )
                            continue

                        # Remove metric labels
                        identity = Service.Table.get_identity(svc.id)
                        if identity:
                            labels = identity.prometheus_labels
                            # Remove service metrics (status/healthy only)
                            for gauge in [
                                service_metrics.status,
                                service_metrics.healthy,
                            ]:
                                try:
                                    gauge.remove(**labels)
                                except KeyError:
                                    pass  # Label set doesn't exist

                            # Remove batch metrics
                            for gauge in [
                                batch_metrics.active,
                                batch_metrics.progress,
                                batch_metrics.cpu_percent,
                                batch_metrics.memory_bytes,
                                batch_metrics.kb_sent,
                                batch_metrics.kb_recv,
                            ]:
                                try:
                                    gauge.remove(**labels)
                                except KeyError:
                                    pass

                        # Delete the service
                        db.delete(svc)
                        deleted.append(svc.service_name)

                    db.commit()

                logger.info("services_deleted", count=len(deleted), services=deleted)

            except Exception as e:
                logger.error("deletion_error", error=str(e))

    def _on_listening_tick(self) -> None:
        """Called on each Kafka poll cycle - sync queued statuses to DB."""
        now = time.time()
        if now - self._last_sync_time < self._sync_interval:
            return

        self._last_sync_time = now
        self._sync_to_db()
        self._detect_stale_services()

    def _sync_to_db(self) -> None:
        """Process all queues and sync status updates to database."""
        with self._lock:
            if not self._queues:
                return
            # Snapshot queues to process (keyed by service_id)
            to_process = {sid: q.pop() for sid, q in self._queues.items()}
            to_process = {
                sid: status for sid, status in to_process.items() if status is not None
            }

        if not to_process:
            return

        with LogContext(stage=Stage.EXECUTE):
            try:
                with get_db_session() as db:
                    for service_id, new_status in to_process.items():
                        svc = db.query(Service.Table).filter_by(id=service_id).first()
                        if not svc:
                            continue

                        old_status = svc.status
                        now = datetime.now(timezone.utc)

                        # Update heartbeat timestamp and status
                        svc.last_heartbeat_at = now
                        svc.status = new_status

                        # Update last_run fields on completion
                        if new_status in (
                            Service.Enums.Status.SUCCESS,
                            Service.Enums.Status.FAILED,
                        ):
                            svc.last_run_at = now

                        # For stream services: update last_run_at when batch completes
                        # (transition from PROCESSING to LISTENING)
                        if (
                            old_status == Service.Enums.Status.PROCESSING
                            and new_status == Service.Enums.Status.LISTENING
                        ):
                            svc.last_run_at = now

                        if new_status == Service.Enums.Status.FAILED:
                            svc.last_failure_at = now
                            old_failure_count = svc.failure_count or 0
                            svc.failure_count = old_failure_count + 1
                            logger.info(
                                "failure_count_incremented",
                                service_id=service_id,
                                failure_count=svc.failure_count,
                                old_failure_count=old_failure_count,
                            )

                        if new_status == Service.Enums.Status.SUCCESS:
                            if svc.failure_count and svc.failure_count > 0:
                                logger.info(
                                    "failure_count_reset",
                                    service_id=service_id,
                                    old_failure_count=svc.failure_count,
                                )
                            svc.failure_count = 0

                        # Always update Prometheus metrics (ensures new services get initial state)
                        _update_status_gauges(
                            service_id=service_id,
                            status=new_status,
                        )
                        if old_status != new_status:
                            logger.debug(
                                "status_synced",
                                service_id=service_id,
                                old_status=old_status,
                                new_status=new_status,
                            )

                        # Update queue's current_db_status
                        with self._lock:
                            self._queues[service_id].current_db_status = new_status

                    db.commit()

            except Exception as e:
                logger.error("sync_error", error=str(e))

    def _detect_stale_services(self) -> None:
        """Detect services stuck in active status without heartbeats.

        Checks all active services (LISTENING, PROCESSING) for stale heartbeats.
        If a service hasn't sent a heartbeat within the stale threshold,
        marks it as FAILED with STALE reason.

        Note: Skips self-check - if we're running this code, we're alive.
        """
        config = get_project_config()
        now = datetime.now(timezone.utc)
        own_id = str(self._identity.id)

        try:
            with get_db_session() as db:
                # Find active services
                active_services = (
                    db.query(Service.Table)
                    .filter(
                        Service.Table.status.in_([
                            Service.Enums.Status.LISTENING.value,
                            Service.Enums.Status.PROCESSING.value,
                        ])
                    )
                    .all()
                )

                for svc in active_services:
                    # Skip self - if we're running this code, we're alive
                    if str(svc.id) == own_id:
                        continue

                    # Get per-service stale threshold or use default
                    svc_config = svc.config or {}
                    stale_seconds = svc_config.get(
                        "heartbeat_stale_seconds", config.stale_threshold
                    )
                    cutoff = now - timedelta(seconds=stale_seconds)

                    # Check last heartbeat
                    last_heartbeat = svc.last_heartbeat_at or svc.last_run_at
                    if last_heartbeat and last_heartbeat < cutoff:
                        self._mark_stale(db, svc, stale_seconds)

                db.commit()

        except Exception as e:
            logger.error("stale_detection_error", error=str(e))

    def _mark_stale(self, db, svc, stale_seconds: float) -> None:
        """Handle a stale service (no heartbeat while active).

        If stop_requested=True: Graceful shutdown → set to IDLE
        If stop_requested=False: Crash → set to FAILED with STALE reason
        """
        service_id = str(svc.id)
        now = datetime.now(timezone.utc)

        # Check if this was a graceful shutdown (KILL command or signal)
        if svc.stop_requested:
            with LogContext(stage=Stage.EXECUTE, service_name=svc.service_name):
                logger.info(
                    "shutdown_completed",
                    message=f"Graceful shutdown completed: {svc.stop_reason}",
                    service_id=service_id,
                    stop_reason=svc.stop_reason,
                )

            # Reset to IDLE (ready for restart)
            svc.status = Service.Enums.Status.IDLE.value
            svc.stop_requested = False
            svc.stop_reason = None
            svc.last_error = None
            svc.failure_reason = None

            # Update Prometheus metrics
            _update_status_gauges(service_id=service_id, status=Service.Enums.Status.IDLE)
        else:
            # Crash - mark as FAILED
            with LogContext(stage=Stage.EXECUTE, service_name=svc.service_name):
                logger.warning(
                    "stale_detected",
                    message=f"Service unresponsive for {stale_seconds}s",
                    service_id=service_id,
                    stale_seconds=stale_seconds,
                    last_heartbeat=str(svc.last_heartbeat_at),
                )

            svc.status = Service.Enums.Status.FAILED.value
            svc.last_error = f"Stale: no heartbeat for {stale_seconds}s"
            svc.failure_reason = FailureReason.STALE
            svc.last_failure_at = now
            svc.failure_count = (svc.failure_count or 0) + 1

            # Update Prometheus metrics
            _update_status_gauges(service_id=service_id, status=Service.Enums.Status.FAILED)


# =============================================================================
# Entry Point (for subprocess spawning)
# =============================================================================


if __name__ == "__main__":
    import json
    import sys

    LifecycleManager.start(json.loads(sys.argv[1]))
