"""
InfraMonitor - Monitors infrastructure and API client health.

Periodically checks the health of infrastructure components (PostgreSQL, Kafka,
Redis, etc.) and API clients (SEC EDGAR, etc.), reporting status via heartbeat
events so they can be monitored using the same mechanism as services.

Runs as a ScheduledService triggered by Scheduler on schedule (default: every 10 seconds).

Infrastructure component names are passed as command line arguments from ProcessManager,
validated against supported components, registered to the database, and monitored.
"""

from typing import Any, Dict, List
from uuid import UUID

from infra_client import Infra

from ..events import Result
from ..messages import Message
from ..kafka import event_bus
from ..loggers import log
from ..services import Service
from ..scheduled import ScheduledService

logger = log


class InfraMonitor(ScheduledService):
    """Monitors infrastructure and API client health via heartbeats."""

    # Set by entry point before calling start()
    _init_component_names: List[str] = []

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(Service.Registry.System.INFRA_MONITOR)
        super().__init__(identity)

        # Validate, register, and cache infrastructure components
        component_names = self._init_component_names
        self._component_ids: Dict[str, UUID] = {}
        self._component_names: List[str] = []
        self._register_components(component_names)

    def _register_components(self, component_names: List[str]) -> None:
        """Validate component names and register to database."""
        if not component_names:
            logger.info("no_infrastructure_configured")
            return

        for name in component_names:
            # Validate against supported services
            if not Infra().api.is_service_supported(name):
                raise ValueError(
                    f"Unsupported infrastructure service: '{name}'. "
                    f"See InfraServiceName for valid names."
                )

            # Create identity and register to database
            identity = Service.Identity(
                service_name=name,
                service_category=Service.Enums.Category.INFRASTRUCTURE,
                execution_type=Service.Enums.ExecutionType.SCHEDULED,
                display_name=name.replace("_", " ").title(),
            )
            registered = Service.Table.bootstrap(identity)

            # Build tracking maps
            self._component_ids[name] = registered.id
            self._component_names.append(name)

        logger.info(
            "infrastructure_registered",
            count=len(self._component_names),
            components=self._component_names,
        )

    def get_tasks(self) -> list:
        return [{"id": "health_check", "description": "Check infrastructure health"}]

    def on_step(self, task: Any) -> Result:
        """Check all component health and send heartbeats."""
        logger.info("infra_monitor_tick")

        if not self._component_names:
            logger.warning("no_infrastructure_components")
            return Result.ok()

        try:
            for name, status in Infra().api.get_infra_health(self._component_names).items():
                if status["error"]:
                    logger.warning("service_unhealthy", service_name=name, error=status["error"])
                self._send_heartbeat(name, status["healthy"], status["error"])
        except Exception as e:
            logger.warning("health_check_failed", error=str(e))
        return Result.ok()

    def _send_heartbeat(self, name: str, healthy: bool, error: str = None) -> None:
        """Send a heartbeat event for a component."""
        service_id = self._component_ids.get(name)
        if not service_id:
            return

        event_bus.publish(
            Message.Heartbeat(
                service_id=str(service_id),
                status=Service.Enums.Status.SUCCESS if healthy else Service.Enums.Status.FAILED,
                payload={"message": error} if error else None,
            )
        )


# =============================================================================
# Entry Point (for subprocess spawning or standalone execution)
# =============================================================================


if __name__ == "__main__":
    import json
    import sys

    config = json.loads(sys.argv[1])
    InfraMonitor._init_component_names = config.get("infra_services", [])
    InfraMonitor.start(config)
