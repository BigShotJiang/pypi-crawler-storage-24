"""
Table Output Mixin for Services.

Provides `_save_to_table()` method for services that output to database tables.
Handles dynamic table creation and bulk upsert with deduplication.
"""

from contextlib import contextmanager
from datetime import datetime, timezone

from infra_client.postgres import get_db
from sqlalchemy import text


@contextmanager
def get_db_with_schema(schema: str = "public"):
    """
    Get database session with search_path set to the given schema.

    This allows queries to use unqualified table names (e.g., SELECT * FROM companies)
    instead of schema-qualified names (e.g., SELECT * FROM sec.companies).

    Args:
        schema: PostgreSQL schema name (default: "public")

    Usage:
        with get_db_with_schema("sec") as db:
            # Tables in 'sec' schema are accessible without prefix
            result = db.execute(text("SELECT * FROM companies"))
    """
    with get_db() as db:
        if schema and schema != "public":
            # Set search_path to include the schema first, then public
            db.execute(text(f"SET search_path TO {schema}, public"))
        yield db


# Type mapping from simple strings to PostgreSQL types
TYPE_MAP = {
    "TEXT": "TEXT",
    "INTEGER": "INTEGER",
    "BIGINT": "BIGINT",
    "NUMERIC": "NUMERIC",
    "BOOLEAN": "BOOLEAN",
    "DATE": "DATE",
    "TIMESTAMP": "TIMESTAMP",
    "TIMESTAMPTZ": "TIMESTAMPTZ",
    "JSONB": "JSONB",
    "UUID": "UUID",
}


def get_sql_type(type_str: str) -> str:
    """Convert schema type string to SQL type."""
    return TYPE_MAP.get(type_str.upper(), "TEXT")


class TableOutputMixin:
    """
    Mixin providing table output capabilities for services.

    Services should define:
    - output_table: str - Name of the target table
    - output_schema: dict - Column name -> type mapping
    - primary_key: list[str] - Columns forming the natural key (for upsert)
    - data_schema: str - PostgreSQL schema name (default: "public")

    Example:
        class MyService(ScheduledService, TableOutputMixin):
            data_schema = "sec"  # Tables go to sec.my_data
            output_table = "my_data"
            output_schema = {
                "id": "TEXT",
                "value": "NUMERIC",
                "date": "DATE",
            }
            primary_key = ["id"]

            def on_step(self, task):
                records = self._fetch_data()
                count = self._save_to_table(records)
                return Result.ok(f"{count} records")
    """

    data_schema: str = "public"  # PostgreSQL schema for data tables
    output_table: str = None
    output_schema: dict[str, str] = None
    primary_key: list[str] = None

    @property
    def qualified_table_name(self) -> str:
        """Get schema-qualified table name (e.g., 'sec.companies')."""
        if self.data_schema and self.data_schema != "public":
            return f"{self.data_schema}.{self.output_table}"
        return self.output_table

    def _save_to_table(
        self,
        records: list[dict],
        source_file: str | None = None,
    ) -> int:
        """
        Save records to the service table with upsert.

        Args:
            records: List of dicts matching output_schema
            source_file: Optional source file path for auditing

        Returns:
            Number of records inserted/updated
        """
        if not self.output_table:
            raise ValueError("output_table not defined on service")
        if not self.output_schema:
            raise ValueError("output_schema not defined on service")
        if not records:
            return 0

        with get_db() as db:
            # Ensure table exists
            self._ensure_table_exists(db)

            # Upsert records
            count = self._bulk_upsert(db, records, source_file)

            db.commit()

            # Log if logger available
            if hasattr(self, "_logger"):
                self._logger.info(
                    "table_saved",
                    table=self.output_table,
                    records=count,
                )

            return count

    def _ensure_schema_exists(self, db) -> None:
        """Create PostgreSQL schema if it doesn't exist."""
        if self.data_schema and self.data_schema != "public":
            db.execute(text(f"CREATE SCHEMA IF NOT EXISTS {self.data_schema}"))
            db.commit()

    def _ensure_table_exists(self, db) -> None:
        """Create schema and table if they don't exist."""
        # Create schema first
        self._ensure_schema_exists(db)

        columns = []
        for col_name, col_type in self.output_schema.items():
            sql_type = get_sql_type(col_type)
            columns.append(f'"{col_name}" {sql_type}')

        # Add audit columns
        columns.append('"_source_file" TEXT')
        columns.append('"_loaded_at" TIMESTAMPTZ DEFAULT NOW()')

        columns_sql = ",\n    ".join(columns)

        # Primary key constraint
        pk_constraint = ""
        if self.primary_key:
            pk_cols = ", ".join(f'"{c}"' for c in self.primary_key)
            pk_constraint = f",\n    PRIMARY KEY ({pk_cols})"

        # Use schema-qualified table name
        table_name = self.qualified_table_name

        create_sql = f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            {columns_sql}{pk_constraint}
        )
        """
        db.execute(text(create_sql))
        db.commit()

    def _bulk_upsert(
        self,
        db,
        records: list[dict],
        source_file: str | None,
    ) -> int:
        """Upsert records with ON CONFLICT handling."""
        if not records:
            return 0

        # Get columns from schema
        columns = list(self.output_schema.keys())
        col_names = ", ".join(f'"{c}"' for c in columns)
        col_names += ', "_source_file", "_loaded_at"'

        # Build placeholders
        placeholders = ", ".join(f":{c}" for c in columns)
        placeholders += ", :_source_file, :_loaded_at"

        # Build UPDATE SET clause (exclude primary key columns)
        update_cols = [c for c in columns if c not in (self.primary_key or [])]
        update_set = ", ".join(f'"{c}" = EXCLUDED."{c}"' for c in update_cols)
        update_set += ', "_source_file" = EXCLUDED."_source_file"'
        update_set += ', "_loaded_at" = EXCLUDED."_loaded_at"'

        # Build conflict clause
        if self.primary_key:
            pk_cols = ", ".join(f'"{c}"' for c in self.primary_key)
            conflict_clause = f"ON CONFLICT ({pk_cols}) DO UPDATE SET {update_set}"
        else:
            conflict_clause = "ON CONFLICT DO NOTHING"

        # Use schema-qualified table name
        table_name = self.qualified_table_name

        insert_sql = f"""
        INSERT INTO {table_name} ({col_names})
        VALUES ({placeholders})
        {conflict_clause}
        """

        now = datetime.now(timezone.utc)
        count = 0

        for record in records:
            # Add audit fields
            record["_source_file"] = source_file
            record["_loaded_at"] = now

            # Ensure all schema columns exist (set None if missing)
            for col in columns:
                if col not in record:
                    record[col] = None

            try:
                db.execute(text(insert_sql), record)
                count += 1
            except Exception as e:
                if hasattr(self, "_logger"):
                    self._logger.warning("upsert_error", error=str(e), record=record)

        return count
