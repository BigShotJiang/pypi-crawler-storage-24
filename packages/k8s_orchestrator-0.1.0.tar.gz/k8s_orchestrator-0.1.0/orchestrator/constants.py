"""
Constants - Shared data structures for Kafka messaging.

This module provides:
- ServiceCommand: Command messages (RUN, KILL)
- BatchProgress: Progress during batch execution
- BatchComplete: Completion metrics
- Stage: Service lifecycle stages for log filtering
- FailureReason: Why a service failed (for retry strategy selection)

All accessed through the Constants namespace:
    from orchestrator import Constants

    # Commands
    cmd = Constants.Command(service_id=..., command=Constants.Command.RUN, ...)

    # Failure reasons
    reason = Constants.FailureReason.EXCEPTION

CONTRACTS: Changes here may break Kafka consumers.
"""

from datetime import datetime
from enum import StrEnum
from typing import Any, ClassVar, Dict, Literal, Optional

from pydantic import BaseModel, ConfigDict


# =============================================================================
# Failure Reason Enum
# =============================================================================


class FailureReason(StrEnum):
    """
    Why a service failed - used to select appropriate retry strategy.

    Each reason can have different retry behavior configured:
    - EXCEPTION: Unhandled exception during execution
    - ITEM_FAILURE: Batch exceeded max_failure_ratio/max_failure_count threshold
    - DEPENDENCY: A dependency service failed
    - STALE: No heartbeat received (service crashed/hung)
    - MANUAL: Manually marked as failed

    Usage:
        from orchestrator import Constants

        reason = Constants.FailureReason.EXCEPTION

    Config example:
        {
            "retry_strategies": {
                "exception": {"max_retries": 3, "cooldown_seconds": 60},
                "item_failure": {"max_retries": 3, "cooldown_seconds": 30},
                "dependency": {"wait_for_recovery": True},
                "stale": {"max_retries": 1, "cooldown_seconds": 300},
            }
        }
    """

    EXCEPTION = "exception"
    ITEM_FAILURE = "item_failure"
    DEPENDENCY = "dependency"
    STALE = "stale"
    MANUAL = "manual"


# =============================================================================
# Exceptions
# =============================================================================


class BatchFailedError(Exception):
    """Raised when batch failure threshold is exceeded.

    Supports two modes:
    - Ratio-based (ScheduledService): fails when failure_ratio > max_failure_ratio
    - Count-based (StreamService): fails when failure_count >= max_failure_count
    """

    def __init__(
        self,
        failed: int,
        total: int,
        *,
        ratio: Optional[float] = None,
        ratio_threshold: Optional[float] = None,
        count_threshold: Optional[int] = None,
    ) -> None:
        self.failed = failed
        self.total = total
        self.ratio = ratio
        self.ratio_threshold = ratio_threshold
        self.count_threshold = count_threshold

        if count_threshold is not None:
            msg = f"Batch failed: {failed} failures reached threshold of {count_threshold}"
        elif ratio is not None and ratio_threshold is not None:
            msg = (
                f"Batch failed: {failed}/{total} tasks failed "
                f"({ratio:.1%} > {ratio_threshold:.1%} threshold)"
            )
        else:
            msg = f"Batch failed: {failed}/{total} tasks failed"

        super().__init__(msg)


# =============================================================================
# Payload Structures
# =============================================================================


class BatchProgress(BaseModel):
    """
    Batch progress payload structure for Heartbeat.payload during batch execution.

    Includes batch progress info plus resource metrics.

    Usage:
        payload = {
            "type": Constants.BatchProgress.TYPE,
            "progress": 0.5,
            "task_count": 100,
            "current_idx": 50,
            "cpu_percent": 45.2,
            ...
        }
    """

    model_config = ConfigDict(extra="forbid")

    TYPE: ClassVar[str] = "batch_progress"
    type: Literal["batch_progress"] = "batch_progress"

    # Batch progress
    progress: float  # 0.0 to 1.0
    task_count: int
    current_idx: int

    # Resource metrics (same as MetricReport)
    cpu_percent: Optional[float] = None
    memory_bytes: Optional[int] = None
    kb_sent: Optional[int] = None
    kb_recv: Optional[int] = None

    def to_payload(self) -> Dict[str, Any]:
        """Convert to dict for use as Heartbeat.payload."""
        return self.model_dump(exclude_none=True)


class BatchComplete(BaseModel):
    """
    Batch completion payload structure for emitting completion metrics.

    Sent at the end of a batch to record duration, size, and task stats.
    """

    model_config = ConfigDict(extra="forbid")

    TYPE: ClassVar[str] = "batch_complete"
    type: Literal["batch_complete"] = "batch_complete"

    duration_ms: float
    task_count: int
    task_success: int = 0
    task_failed: int = 0
    longest_task_duration_ms: float = 0.0
    status: str  # "success" or "failed"

    def to_payload(self) -> Dict[str, Any]:
        """Convert to dict for use as Heartbeat.payload."""
        return self.model_dump(exclude_none=True)


class ServiceCommand(BaseModel):
    """Command message sent via Kafka."""

    model_config = ConfigDict(populate_by_name=True)

    RUN: ClassVar[str] = "run"
    RUN_NOW: ClassVar[str] = "run_now"  # Bypass schedule check
    KILL: ClassVar[str] = "kill"

    service_id: str  # Service UUID
    command: str
    trace_id: str
    timestamp: Optional[datetime] = None
    config_overrides: Optional[Dict[str, Any]] = None
    reason: Optional[str] = None  # Why command was sent


class Stage:
    """
    Service lifecycle stages for log filtering.

    Usage:
        from orchestrator import Constants, LogContext

        with LogContext(stage=Constants.Stage.RUN):
            log.info("processing items")

    Filter:
        LOG_FILTER="stage=run"

    Stages:
        INIT     - Service starting up, waiting for commands
        RUN      - Service actively processing (general)
        EXECUTE  - Processing tasks/items
        SCHEDULE - Cron schedule evaluation
        SPAWN    - Starting/bootstrapping services
        RETRY    - Retry logic execution
    """

    INIT = "init"  # Service starting, waiting for first RUN command
    RUN = "run"  # Service actively processing (general)
    EXECUTE = "execute"  # Processing tasks/items
    SCHEDULE = "schedule"  # Cron schedule evaluation
    SPAWN = "spawn"  # Starting/bootstrapping services
    RETRY = "retry"  # Retry logic execution


class Constants:
    """
    Namespace for shared data structures.

    Usage:
        from orchestrator import Constants, LogContext, log

        # Commands
        cmd = Constants.Command(
            service_id="uuid-here",
            command=Constants.Command.RUN,
            trace_id="abc123"
        )

        # Log stages
        with LogContext(stage=Constants.Stage.RUN):
            log.info("processing")
    """

    Command = ServiceCommand
    BatchProgress = BatchProgress
    BatchComplete = BatchComplete
    Stage = Stage
    BatchFailedError = BatchFailedError
    FailureReason = FailureReason
