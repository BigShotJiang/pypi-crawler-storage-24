"""
Orchestrator Configuration - Project-configurable settings.

Usage:
    from orchestrator.config import OrchestratorConfig, get_project_config

    # Configure (typically in ProcessManager or service entry point)
    OrchestratorConfig(env="dev", project_name="my_project")

    # Get config anywhere
    config = get_project_config()
"""

from dataclasses import dataclass, field
from typing import Any, Literal, Optional

from infra_client import Infra


Env = Literal["dev", "test", "prod"]

# Global configuration instance (singleton)
_config: Optional["OrchestratorConfig"] = None


@dataclass
class OrchestratorConfig:
    """
    Configuration for the service orchestrator.

    Creating an instance configures the orchestrator globally (singleton).
    Use get_project_config() to retrieve the instance after creation.

    Args:
        env: Environment (dev, test, prod)
        project_name: Project identifier (used for Kafka topics, logging, database)
        session_id: Optional session ID for shared sessions across processes.
                   If not provided, a unique session_id is generated.
    """

    # Required - must be set by project
    env: Env
    project_name: str

    # Optional - for shared session across processes
    session_id: Optional[str] = None

    # Infrastructure client (from infra-client)
    _infra: Any = field(default=None, repr=False)

    # Intervals (seconds) - defaults from Infra config, can be overridden
    _observability_interval: Optional[float] = field(default=None, repr=False)
    pulse_rate: float = 1.0  # Heartbeat frequency

    # Timeouts (seconds) - stale_threshold defaults to 3x observability_interval
    _stale_threshold: Optional[float] = field(default=None, repr=False)

    # Retry configuration
    max_retry_count: int = 3
    retry_cooldown: float = 10.0

    # Prometheus buckets
    batch_size_buckets: tuple = (1, 5, 10, 25, 50, 100, 250, 500, 1000)

    def __post_init__(self):
        """Initialize and register as global singleton."""
        global _config

        # Initialize Infra client (configures logging, database, metrics)
        self._infra = Infra(self.env, self.project_name, self.project_name, session_id=self.session_id)

        # Update ServiceModel table schema for project isolation
        from .models import ServiceModel
        ServiceModel.__table__.schema = self.database_schema

        # Register as singleton
        _config = self

    @property
    def database_schema(self) -> str:
        """Database schema name (same as project_name for isolation)."""
        return self.project_name

    # =========================================================================
    # Infra config passthrough (access all infra settings via config.infra.*)
    # =========================================================================

    @property
    def infra(self):
        """Access infra-client config (kafka_url, database_url, redis_url, etc.)."""
        return self._infra.config

    # =========================================================================
    # Orchestrator-specific settings
    # =========================================================================

    @property
    def observability_interval(self) -> float:
        """Main tick for sync, scheduling, dependency checks."""
        if self._observability_interval is not None:
            return self._observability_interval
        return float(self._infra.config.observability_interval_seconds)

    @property
    def stale_threshold(self) -> float:
        """No heartbeat for this long = stale (default: 3x observability_interval)."""
        if self._stale_threshold is not None:
            return self._stale_threshold
        return self.observability_interval * 3


def get_project_config() -> OrchestratorConfig:
    """
    Get the current orchestrator configuration.

    Raises:
        RuntimeError: If OrchestratorConfig was not initialized
    """
    if _config is None:
        raise RuntimeError(
            "Orchestrator not configured. Create OrchestratorConfig first:\n"
            "  from orchestrator.config import OrchestratorConfig\n"
            "  OrchestratorConfig(env='dev', project_name='my_project')"
        )
    return _config


def is_configured() -> bool:
    """Check if the orchestrator has been configured."""
    return _config is not None
