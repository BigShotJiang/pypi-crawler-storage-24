"""
Mock Services - Controllable services for e2e testing.

Provides mock services for testing various failure scenarios:
1. Dependency failure/recovery (E2EDepProvider, E2EDepConsumer)
2. Task batch threshold failure (E2EScheduledThreshold)
3. Stream consecutive failure threshold (E2EStreamThreshold)
4. Task retry exhaustion (E2EScheduledRetry)

Control flags are stored in Redis to enable cross-process control:
- Tests running locally can set flags
- Mock services running on infra-dev read flags from Redis

Example:
    # In test process
    MockControl.set("e2e_scheduled_threshold", "fail_count", 3)

    # In mock service (reads from Redis)
    fail_count = MockControl.get_int("e2e_scheduled_threshold", "fail_count", default=0)
"""

from enum import StrEnum
from typing import Any, List, Optional, Tuple

import redis

from ..config import get_project_config
from ..events import Result
from ..loggers import log
from ..services import Service
from ..stream import StreamService
from ..scheduled import ScheduledService

logger = log


# =============================================================================
# Redis-based Control Flags
# =============================================================================


class MockControl:
    """Redis-based control flags for cross-process mock service control.

    Keys are stored as: e2e:control:{service_name}:{flag_name}
    """

    _client: Optional[redis.Redis] = None
    PREFIX = "e2e:control"

    @classmethod
    def _get_client(cls) -> redis.Redis:
        """Get or create Redis client."""
        if cls._client is None:
            config = get_project_config()
            cls._client = redis.from_url(config.infra.redis_url)
        return cls._client

    @classmethod
    def _key(cls, service: str, flag: str) -> str:
        return f"{cls.PREFIX}:{service}:{flag}"

    @classmethod
    def set(cls, service: str, flag: str, value: Any) -> None:
        """Set a control flag for a service."""
        client = cls._get_client()
        client.set(cls._key(service, flag), str(value))

    @classmethod
    def get(cls, service: str, flag: str, default: str = "") -> str:
        """Get a control flag value."""
        client = cls._get_client()
        val = client.get(cls._key(service, flag))
        return val.decode() if val else default

    @classmethod
    def get_int(cls, service: str, flag: str, default: int = 0) -> int:
        """Get a control flag as integer."""
        val = cls.get(service, flag, "")
        return int(val) if val else default

    @classmethod
    def get_bool(cls, service: str, flag: str, default: bool = False) -> bool:
        """Get a control flag as boolean."""
        val = cls.get(service, flag, "")
        if not val:
            return default
        return val.lower() in ("true", "1", "yes")

    @classmethod
    def reset(cls, service: str) -> None:
        """Clear all control flags for a service."""
        client = cls._get_client()
        pattern = f"{cls.PREFIX}:{service}:*"
        keys = client.keys(pattern)
        if keys:
            client.delete(*keys)

    @classmethod
    def reset_all(cls) -> None:
        """Clear all control flags for all services."""
        client = cls._get_client()
        pattern = f"{cls.PREFIX}:*"
        keys = client.keys(pattern)
        if keys:
            client.delete(*keys)


# =============================================================================
# Stream Message Seeding
# =============================================================================

E2E_STREAM_TOPIC = "orchestrator_e2e.stream_tasks"


def get_e2e_stream_topic() -> str:
    """Get the topic name for e2e stream services."""
    return E2E_STREAM_TOPIC


def seed_stream_messages(count: int = 10) -> None:
    """Seed test messages to the e2e stream topic.

    Args:
        count: Number of messages to send.
    """
    from ..kafka import send_message

    for i in range(count):
        send_message(
            topic=E2E_STREAM_TOPIC,
            key=f"e2e-task-{i}",
            value={
                "id": f"e2e-task-{i}",
                "message": f"E2E test task {i}",
                "data": {"index": i},
            },
        )
    logger.info("seeded_stream_messages", count=count, topic=E2E_STREAM_TOPIC)


class MockServiceName(StrEnum):
    """Mock service identifiers for e2e tests."""

    __test__ = False  # Prevent pytest from collecting this as a test class

    # Infrastructure services (external dependencies)
    E2E_INFRA_DATABASE = "e2e_infra_database"
    E2E_INFRA_CACHE = "e2e_infra_cache"
    E2E_INFRA_QUEUE = "e2e_infra_queue"

    # Business services (depend on infrastructure)
    E2E_DEP_PROVIDER = "e2e_dep_provider"
    E2E_DEP_CONSUMER = "e2e_dep_consumer"
    E2E_SCHEDULED_THRESHOLD = "e2e_scheduled_threshold"
    E2E_STREAM_THRESHOLD = "e2e_stream_threshold"
    E2E_SCHEDULED_RETRY = "e2e_scheduled_retry"


# Module prefix for entry point modules
_MODULE_PREFIX = "orchestrator.testing.mocks"


class MockRegistry:
    """Registry of mock service identities.

    Similar to Service.Registry.System but for mock services.
    """

    E2E_INFRA_DATABASE = Service.Identity(
        service_name=MockServiceName.E2E_INFRA_DATABASE,
        service_category=Service.Enums.Category.INFRASTRUCTURE,
        execution_type=Service.Enums.ExecutionType.STREAM,
        description="Mock database health monitor",
        display_name="Mock Database",
        module_path=f"{_MODULE_PREFIX}.e2e_infra_database",
        config={"poll_timeout_ms": 1000},
    )

    E2E_INFRA_CACHE = Service.Identity(
        service_name=MockServiceName.E2E_INFRA_CACHE,
        service_category=Service.Enums.Category.INFRASTRUCTURE,
        execution_type=Service.Enums.ExecutionType.STREAM,
        description="Mock cache health monitor",
        display_name="Mock Cache",
        module_path=f"{_MODULE_PREFIX}.e2e_infra_cache",
        config={"poll_timeout_ms": 1000},
    )

    E2E_INFRA_QUEUE = Service.Identity(
        service_name=MockServiceName.E2E_INFRA_QUEUE,
        service_category=Service.Enums.Category.INFRASTRUCTURE,
        execution_type=Service.Enums.ExecutionType.STREAM,
        description="Mock message queue health monitor",
        display_name="Mock Queue",
        module_path=f"{_MODULE_PREFIX}.e2e_infra_queue",
        config={"poll_timeout_ms": 1000},
    )

    E2E_DEP_PROVIDER = Service.Identity(
        service_name=MockServiceName.E2E_DEP_PROVIDER,
        service_category=Service.Enums.Category.BUSINESS,
        execution_type=Service.Enums.ExecutionType.STREAM,
        description="E2E test: upstream service that others depend on",
        display_name="E2E Upstream (Dependency)",
        module_path=f"{_MODULE_PREFIX}.e2e_dep_provider",
        dependencies=(MockServiceName.E2E_INFRA_DATABASE,),
        config={"poll_timeout_ms": 1000},
    )

    E2E_DEP_CONSUMER = Service.Identity(
        service_name=MockServiceName.E2E_DEP_CONSUMER,
        service_category=Service.Enums.Category.BUSINESS,
        execution_type=Service.Enums.ExecutionType.STREAM,
        description="E2E test: downstream service that depends on upstream",
        display_name="E2E Downstream (Dependent)",
        module_path=f"{_MODULE_PREFIX}.e2e_dep_consumer",
        dependencies=(
            MockServiceName.E2E_DEP_PROVIDER,
            MockServiceName.E2E_INFRA_CACHE,
        ),
        config={"poll_timeout_ms": 1000},
    )

    E2E_SCHEDULED_THRESHOLD = Service.Identity(
        service_name=MockServiceName.E2E_SCHEDULED_THRESHOLD,
        service_category=Service.Enums.Category.BUSINESS,
        execution_type=Service.Enums.ExecutionType.SCHEDULED,
        description="E2E test: scheduled batch failure threshold",
        display_name="E2E Scheduled Threshold",
        module_path=f"{_MODULE_PREFIX}.e2e_scheduled_threshold",
        cron_schedule="*/10 * * * * *",  # Every 10 seconds
        dependencies=(MockServiceName.E2E_INFRA_DATABASE,),
        config={
            "max_failure_ratio": 0.2,  # Fail batch if >20% items fail
        },
    )

    E2E_STREAM_THRESHOLD = Service.Identity(
        service_name=MockServiceName.E2E_STREAM_THRESHOLD,
        service_category=Service.Enums.Category.BUSINESS,
        execution_type=Service.Enums.ExecutionType.STREAM,
        description="E2E test: stream consecutive failure threshold",
        display_name="E2E Stream Threshold",
        module_path=f"{_MODULE_PREFIX}.e2e_stream_threshold",
        dependencies=(MockServiceName.E2E_INFRA_QUEUE,),
        config={
            "max_failure_count": 3,  # Fail service after 3 consecutive failures
        },
    )

    E2E_SCHEDULED_RETRY = Service.Identity(
        service_name=MockServiceName.E2E_SCHEDULED_RETRY,
        service_category=Service.Enums.Category.BUSINESS,
        execution_type=Service.Enums.ExecutionType.SCHEDULED,
        description="E2E test: scheduled retry exhaustion",
        display_name="E2E Scheduled Retry",
        module_path=f"{_MODULE_PREFIX}.e2e_scheduled_retry",
        cron_schedule="*/10 * * * * *",  # Every 10 seconds
        dependencies=(MockServiceName.E2E_INFRA_CACHE,),
        config={
            "max_retry_count": 3,
            "retry_cooldown_seconds": 5,
        },
    )

    @classmethod
    def all(cls) -> Tuple[Service.Identity, ...]:
        """Return all mock service identities."""
        return (
            cls.E2E_INFRA_DATABASE,
            cls.E2E_INFRA_CACHE,
            cls.E2E_INFRA_QUEUE,
            cls.E2E_DEP_PROVIDER,
            cls.E2E_DEP_CONSUMER,
            cls.E2E_SCHEDULED_THRESHOLD,
            cls.E2E_STREAM_THRESHOLD,
            cls.E2E_SCHEDULED_RETRY,
        )


# =============================================================================
# Infrastructure Services (External Dependencies)
# =============================================================================


class E2EInfraDatabase(StreamService):
    """Mock database health monitor.

    Simulates external database dependency that business services rely on.

    Control flags (via Redis):
        trigger_failure: When "true", service fails on next on_poll()
        fail_permanently: When "true", stays failed even after trigger
    """

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_INFRA_DATABASE)
        super().__init__(identity, kafka_topic="e2e_mock_unused")

    @classmethod
    def reset(cls) -> None:
        MockControl.reset(MockServiceName.E2E_INFRA_DATABASE)

    def _on_listening_tick(self) -> None:
        trigger = MockControl.get_bool(
            MockServiceName.E2E_INFRA_DATABASE, "trigger_failure"
        )
        if trigger:
            fail_permanently = MockControl.get_bool(
                MockServiceName.E2E_INFRA_DATABASE, "fail_permanently"
            )
            if not fail_permanently:
                MockControl.set(
                    MockServiceName.E2E_INFRA_DATABASE, "trigger_failure", "false"
                )
            logger.info("infra_database_failure")
            raise RuntimeError("Database connection failed")


class E2EInfraCache(StreamService):
    """Mock cache (Redis) health monitor.

    Simulates external cache dependency.

    Control flags (via Redis):
        trigger_failure: When "true", service fails on next on_poll()
    """

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_INFRA_CACHE)
        super().__init__(identity, kafka_topic="e2e_mock_unused")

    @classmethod
    def reset(cls) -> None:
        MockControl.reset(MockServiceName.E2E_INFRA_CACHE)

    def _on_listening_tick(self) -> None:
        trigger = MockControl.get_bool(
            MockServiceName.E2E_INFRA_CACHE, "trigger_failure"
        )
        if trigger:
            MockControl.set(
                MockServiceName.E2E_INFRA_CACHE, "trigger_failure", "false"
            )
            logger.info("infra_cache_failure")
            raise RuntimeError("Cache connection failed")


class E2EInfraQueue(StreamService):
    """Mock message queue (Kafka) health monitor.

    Simulates external queue dependency.

    Control flags (via Redis):
        trigger_failure: When "true", service fails on next on_poll()
    """

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_INFRA_QUEUE)
        super().__init__(identity, kafka_topic="e2e_mock_unused")

    @classmethod
    def reset(cls) -> None:
        MockControl.reset(MockServiceName.E2E_INFRA_QUEUE)

    def _on_listening_tick(self) -> None:
        trigger = MockControl.get_bool(
            MockServiceName.E2E_INFRA_QUEUE, "trigger_failure"
        )
        if trigger:
            MockControl.set(
                MockServiceName.E2E_INFRA_QUEUE, "trigger_failure", "false"
            )
            logger.info("infra_queue_failure")
            raise RuntimeError("Queue connection failed")


# =============================================================================
# Business Services
# =============================================================================


class E2EDepProvider(StreamService):
    """Controllable dependency provider for testing.

    Control flags (via Redis):
        trigger_failure: When "true", service fails on next on_poll()
        fail_permanently: When "true", stays failed even after trigger
    """

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_DEP_PROVIDER)
        super().__init__(identity, kafka_topic="e2e_mock_unused")

    @classmethod
    def reset(cls) -> None:
        """Reset all control flags to defaults."""
        MockControl.reset(MockServiceName.E2E_DEP_PROVIDER)

    def _on_listening_tick(self) -> None:
        """Called after each poll cycle. Fails if trigger_failure is set."""
        trigger = MockControl.get_bool(
            MockServiceName.E2E_DEP_PROVIDER, "trigger_failure"
        )
        if trigger:
            fail_permanently = MockControl.get_bool(
                MockServiceName.E2E_DEP_PROVIDER, "fail_permanently"
            )
            if not fail_permanently:
                MockControl.set(
                    MockServiceName.E2E_DEP_PROVIDER, "trigger_failure", "false"
                )
            logger.info("provider_triggered_failure")
            raise RuntimeError("Triggered failure for testing")


class E2EDepConsumer(StreamService):
    """Dependency consumer that depends on provider."""

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_DEP_CONSUMER)
        super().__init__(identity, kafka_topic="e2e_mock_unused")

    @classmethod
    def reset(cls) -> None:
        MockControl.reset(MockServiceName.E2E_DEP_CONSUMER)

    def _on_listening_tick(self) -> None:
        """Called after each poll cycle. Fails if trigger_failure is set."""
        trigger = MockControl.get_bool(
            MockServiceName.E2E_DEP_CONSUMER, "trigger_failure"
        )
        if trigger:
            MockControl.set(
                MockServiceName.E2E_DEP_CONSUMER, "trigger_failure", "false"
            )
            raise RuntimeError("Triggered failure for testing")


# =============================================================================
# Threshold Test Services
# =============================================================================


class E2EScheduledThreshold(ScheduledService):
    """Task service for testing batch failure threshold.

    Tests max_failure_ratio behavior: if too many items fail in a batch,
    the entire batch fails.

    Control flags (via Redis):
        fail_count: Number of items to fail (out of total_items)
        total_items: Total items in batch (default 10)
    """

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_SCHEDULED_THRESHOLD)
        super().__init__(identity)

    @classmethod
    def reset(cls) -> None:
        MockControl.reset(MockServiceName.E2E_SCHEDULED_THRESHOLD)

    def get_tasks(self) -> List[dict]:
        """Return batch of items."""
        total_items = MockControl.get_int(
            MockServiceName.E2E_SCHEDULED_THRESHOLD, "total_items", default=10
        )
        return [
            {"id": f"item-{i}", "description": f"Process item {i}", "item": i}
            for i in range(total_items)
        ]

    def on_step(self, task: dict) -> Result:
        """Process item. Returns Result.fail() for failures under fail_count threshold.

        Uses soft failure (Result.fail) instead of exceptions so the
        batch can continue and threshold behavior can be tested.

        Fails items at the END of the batch to avoid triggering threshold
        early (since threshold is checked after each task).
        """
        fail_count = MockControl.get_int(
            MockServiceName.E2E_SCHEDULED_THRESHOLD, "fail_count", default=0
        )
        total_items = MockControl.get_int(
            MockServiceName.E2E_SCHEDULED_THRESHOLD, "total_items", default=10
        )

        # Fail the LAST fail_count items instead of the first
        # This prevents early threshold triggers (1/1 = 100% > threshold)
        item_num = task["item"]
        fail_start = total_items - fail_count  # e.g., 10 items, 2 fails → start failing at item 8

        if item_num >= fail_start:
            logger.info("task_item_failing", item=item_num)
            return Result.fail(f"Simulated failure for item {item_num}")

        logger.info("task_item_success", item=item_num)
        return Result.ok()


class E2EStreamThreshold(StreamService):
    """Stream service for testing consecutive failure threshold.

    Tests max_failure_count behavior: if too many consecutive failures
    occur, service is marked as failed.

    Control flags (via Redis):
        fail_count: Number of consecutive failures to trigger
    """

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_STREAM_THRESHOLD)
        super().__init__(identity, kafka_topic=E2E_STREAM_TOPIC)
        self._failures_so_far = 0

    @classmethod
    def reset(cls) -> None:
        MockControl.reset(MockServiceName.E2E_STREAM_THRESHOLD)

    def on_step(self, task: dict) -> Result:
        """Process a stream task. Fails fail_count times consecutively."""
        fail_count = MockControl.get_int(
            MockServiceName.E2E_STREAM_THRESHOLD, "fail_count", default=0
        )
        if self._failures_so_far < fail_count:
            self._failures_so_far += 1
            logger.info(
                "stream_consecutive_failure",
                count=self._failures_so_far,
                task_id=task.get("id"),
            )
            raise RuntimeError(f"Consecutive failure {self._failures_so_far}")

        logger.debug("stream_task_processed", task_id=task.get("id"))
        return Result.ok()


# =============================================================================
# Retry Test Services
# =============================================================================


class E2EScheduledRetry(ScheduledService):
    """Task service for testing retry exhaustion.

    Fails until attempt_count reaches success_after.

    Control flags (via Redis):
        success_after: Succeed after this many attempts (0 = always succeed)
        attempt_count: Current attempt number (tracked in Redis)
    """

    def __init__(self) -> None:
        identity = Service.Table.bootstrap(MockRegistry.E2E_SCHEDULED_RETRY)
        super().__init__(identity)

    @classmethod
    def reset(cls) -> None:
        MockControl.reset(MockServiceName.E2E_SCHEDULED_RETRY)

    def get_tasks(self) -> List[dict]:
        return [{"id": "retry-task", "description": "Retry test task"}]

    def on_step(self, task: dict) -> Result:
        """Process task. Fails until attempt_count >= success_after."""
        # Track attempt count in Redis so it persists across process restarts
        attempt = MockControl.get_int(
            MockServiceName.E2E_SCHEDULED_RETRY, "attempt_count", default=0
        )
        attempt += 1
        MockControl.set(MockServiceName.E2E_SCHEDULED_RETRY, "attempt_count", attempt)

        success_after = MockControl.get_int(
            MockServiceName.E2E_SCHEDULED_RETRY, "success_after", default=0
        )

        if success_after > 0 and attempt < success_after:
            logger.info("task_retry_failing", attempt=attempt)
            raise RuntimeError(f"Failing on attempt {attempt}")

        logger.info("task_retry_success", attempt=attempt)
        return Result.ok()


def get_mock_service_identities() -> Tuple[Service.Identity, ...]:
    """Get service identities for all mock services."""
    return MockRegistry.all()
