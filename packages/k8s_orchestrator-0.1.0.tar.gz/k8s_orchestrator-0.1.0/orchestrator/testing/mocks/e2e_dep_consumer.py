""""""

import json
import sys

from ..mock_services import E2EDepConsumer

if __name__ == "__main__":
    E2EDepConsumer.start(json.loads(sys.argv[1]))
