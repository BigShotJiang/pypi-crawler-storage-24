""""""

import json
import sys

from ..mock_services import E2EDepProvider

if __name__ == "__main__":
    E2EDepProvider.start(json.loads(sys.argv[1]))
