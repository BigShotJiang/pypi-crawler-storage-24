""""""

import json
import sys

from ..mock_services import E2EStreamThreshold

if __name__ == "__main__":
    E2EStreamThreshold.start(json.loads(sys.argv[1]))
