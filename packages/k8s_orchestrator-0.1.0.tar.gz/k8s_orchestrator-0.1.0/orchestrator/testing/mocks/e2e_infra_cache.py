""""""

import json
import sys

from ..mock_services import E2EInfraCache

if __name__ == "__main__":
    E2EInfraCache.start(json.loads(sys.argv[1]))
