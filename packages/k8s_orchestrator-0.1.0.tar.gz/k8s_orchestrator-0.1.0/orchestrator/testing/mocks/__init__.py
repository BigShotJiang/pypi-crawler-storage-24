"""Mock service entry point modules for ProcessManager."""
