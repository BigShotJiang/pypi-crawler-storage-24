""""""

import json
import sys

from ..mock_services import E2EInfraDatabase

if __name__ == "__main__":
    E2EInfraDatabase.start(json.loads(sys.argv[1]))
