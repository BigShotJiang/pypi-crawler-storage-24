""""""

import json
import sys

from ..mock_services import E2EScheduledThreshold

if __name__ == "__main__":
    E2EScheduledThreshold.start(json.loads(sys.argv[1]))
