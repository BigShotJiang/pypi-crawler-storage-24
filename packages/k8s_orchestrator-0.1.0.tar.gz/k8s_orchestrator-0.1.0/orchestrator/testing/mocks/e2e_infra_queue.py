""""""

import json
import sys

from ..mock_services import E2EInfraQueue

if __name__ == "__main__":
    E2EInfraQueue.start(json.loads(sys.argv[1]))
