""""""

import json
import sys

from ..mock_services import E2EScheduledRetry

if __name__ == "__main__":
    E2EScheduledRetry.start(json.loads(sys.argv[1]))
