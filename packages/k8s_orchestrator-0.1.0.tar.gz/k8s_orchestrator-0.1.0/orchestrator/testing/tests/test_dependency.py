"""
E2E Dependency Tests - Verify dependency failure/recovery behavior.

Test Scenarios:
1. When a dependency fails, dependent services are stopped
2. When a dependency recovers, dependent services are restarted

Usage:
    # Start orchestrator first
    ENV=dev python -m orchestrator.testing

    # Run tests
    ENV=dev pytest tests/e2e/test_dependency.py -v -s -m e2e
"""

import pytest

from orchestrator import Service
from orchestrator.testing import (
    MockControl,
    MockServiceName,
)
from .helpers import (
    get_last_error,
    get_status,
    reset_service,
    send_run_command,
    set_status,
    wait_for_status,
)


@pytest.fixture
def reset_mock_services():
    """Reset mock service control flags before each test."""
    MockControl.reset(MockServiceName.E2E_DEP_PROVIDER)
    MockControl.reset(MockServiceName.E2E_DEP_CONSUMER)
    yield
    MockControl.reset(MockServiceName.E2E_DEP_PROVIDER)
    MockControl.reset(MockServiceName.E2E_DEP_CONSUMER)


@pytest.mark.e2e
class TestDependency:
    """Verify dependency failure and recovery behavior."""

    def test_dependency_failure_stops_consumer(
        self, orchestrator, reset_mock_services
    ):
        """
        Scenario 1: When provider fails, consumer is stopped.

        Steps:
        1. Reset both services to clean state
        2. Start provider and consumer (send RUN commands)
        3. Wait for both to reach LISTENING state
        4. Trigger provider failure
        5. Verify provider reaches FAILED state
        6. Verify consumer reaches FAILED with dependency error
        """
        provider = MockServiceName.E2E_DEP_PROVIDER
        consumer = MockServiceName.E2E_DEP_CONSUMER

        # Reset to clean state
        reset_service(provider)
        reset_service(consumer)

        # Start both services
        send_run_command(provider)
        send_run_command(consumer)

        # Wait for LISTENING state
        assert wait_for_status(provider, Service.Enums.Status.LISTENING, timeout=30), (
            f"Provider did not reach LISTENING, got {get_status(provider)}"
        )
        assert wait_for_status(consumer, Service.Enums.Status.LISTENING, timeout=30), (
            f"Consumer did not reach LISTENING, got {get_status(consumer)}"
        )

        # Trigger provider failure via Redis control
        MockControl.set(provider, "trigger_failure", "true")

        # Wait for provider to fail
        assert wait_for_status(provider, Service.Enums.Status.FAILED, timeout=30), (
            f"Provider did not fail, got {get_status(provider)}"
        )

        # Wait for consumer to detect dependency failure
        assert wait_for_status(consumer, Service.Enums.Status.FAILED, timeout=60), (
            f"Consumer did not fail after dependency failure, got {get_status(consumer)}"
        )

        # Verify consumer error mentions dependency
        error = get_last_error(consumer)
        assert error and "Dependency" in error, (
            f"Expected 'Dependency' in consumer error, got: {error}"
        )

    def test_dependency_recovery_restarts_consumer(
        self, orchestrator, reset_mock_services
    ):
        """
        Scenario 2: When provider recovers, consumer is restarted.

        Steps:
        1. Run scenario 1 to get both services failed
        2. Manually recover provider (set status to IDLE)
        3. Wait for scheduler to restart consumer
        4. Verify consumer reaches LISTENING state
        """
        provider = MockServiceName.E2E_DEP_PROVIDER
        consumer = MockServiceName.E2E_DEP_CONSUMER

        # First, get into failed state (run scenario 1)
        reset_service(provider)
        reset_service(consumer)

        send_run_command(provider)
        send_run_command(consumer)

        wait_for_status(provider, Service.Enums.Status.LISTENING, timeout=30)
        wait_for_status(consumer, Service.Enums.Status.LISTENING, timeout=30)

        MockControl.set(provider, "trigger_failure", "true")
        wait_for_status(provider, Service.Enums.Status.FAILED, timeout=30)
        wait_for_status(consumer, Service.Enums.Status.FAILED, timeout=60)

        # Now recover provider by setting status to IDLE
        # (simulates provider being successfully restarted)
        set_status(provider, Service.Enums.Status.IDLE)

        # Scheduler's retry logic should detect dependency is healthy
        # and restart the consumer automatically
        # Wait for consumer to be restarted (reach LISTENING again)
        assert wait_for_status(consumer, Service.Enums.Status.LISTENING, timeout=60), (
            f"Consumer should be restarted to LISTENING after dependency recovery, "
            f"got {get_status(consumer)}"
        )
