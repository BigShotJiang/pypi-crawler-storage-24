"""
E2E Failure Tests - Verify different failure behaviors.

Test Scenarios:
1. Task batch threshold: >20% item failures → batch fails
2. Stream consecutive threshold: 3+ consecutive failures → service fails
3. Task retry exhaustion: service fails after max_retries attempts
4. Dependency failure: dependent services are stopped

Usage:
    ENV=dev python -m orchestrator.testing
    ENV=dev pytest infra_client/orchestrator/testing/tests/ -v -s -m e2e
"""

import pytest

from orchestrator import Service
from orchestrator.testing import (
    MockControl,
    MockServiceName,
)
from .helpers import (
    get_status,
    reset_service,
    seed_stream_tasks,
    send_run_command,
    wait_for_status,
)


@pytest.fixture
def reset_all_services():
    """Reset all mock service control flags."""
    MockControl.reset_all()
    yield
    MockControl.reset_all()


@pytest.mark.e2e
class TestTaskBatchThreshold:
    """Verify task batch failure threshold behavior.

    When >20% of items in a batch fail (max_failure_ratio=0.2),
    the entire batch should be marked as FAILED.
    """

    def test_batch_under_threshold_succeeds(
        self, orchestrator, reset_all_services
    ):
        """
        Batch succeeds when failures < threshold.

        With 10 items and max_failure_ratio=0.2, failing 1 item (10%)
        should still result in SUCCESS.
        """
        service = MockServiceName.E2E_SCHEDULED_THRESHOLD

        reset_service(service)
        MockControl.set(service, "fail_count", 1)  # Fail 1 out of 10 = 10%

        send_run_command(service)

        # Should complete successfully (under 20% threshold)
        assert wait_for_status(service, Service.Enums.Status.SUCCESS, timeout=30), (
            f"Expected SUCCESS with 10% failures, got {get_status(service)}"
        )

    def test_batch_over_threshold_fails(
        self, orchestrator, reset_all_services
    ):
        """
        Batch fails when failures > threshold.

        With 10 items and max_failure_ratio=0.2, failing 3 items (30%)
        should result in FAILED.
        """
        service = MockServiceName.E2E_SCHEDULED_THRESHOLD

        reset_service(service)
        MockControl.set(service, "fail_count", 3)  # Fail 3 out of 10 = 30%

        send_run_command(service)

        # Should fail (over 20% threshold)
        assert wait_for_status(service, Service.Enums.Status.FAILED, timeout=30), (
            f"Expected FAILED with 30% failures, got {get_status(service)}"
        )


@pytest.mark.e2e
class TestStreamThreshold:
    """Verify stream consecutive failure threshold behavior.

    When max_failure_count consecutive failures occur,
    the service should be marked as FAILED.
    """

    def test_consecutive_failures_trigger_service_failure(
        self, orchestrator, reset_all_services
    ):
        """
        Service fails after max_failure_count consecutive failures.

        With max_failure_count=3, service should fail after 3 consecutive
        task failures.
        """
        service = MockServiceName.E2E_STREAM_THRESHOLD

        reset_service(service)
        # Seed messages so stream service has tasks to process
        seed_stream_tasks(count=10)
        MockControl.set(service, "fail_count", 5)  # Fail 5 times (> max_failure_count=3)

        send_run_command(service)

        # Should fail after 3 consecutive failures
        assert wait_for_status(service, Service.Enums.Status.FAILED, timeout=30), (
            f"Expected FAILED after consecutive failures, got {get_status(service)}"
        )


@pytest.mark.e2e
class TestRetryExhaustion:
    """Verify retry exhaustion behavior.

    When a task service fails max_retries times, it should stop
    being retried and remain in FAILED state.
    """

    def test_retry_eventually_succeeds(
        self, orchestrator, reset_all_services
    ):
        """
        Service succeeds after failing initial attempts.

        With success_after=2, the service fails once, then succeeds
        on the second retry.
        """
        service = MockServiceName.E2E_SCHEDULED_RETRY

        reset_service(service)
        MockControl.set(service, "success_after", 2)  # Succeed on 2nd attempt

        send_run_command(service)

        # Wait for eventual success (after retry)
        # Note: This may take time due to retry_cooldown_seconds
        assert wait_for_status(service, Service.Enums.Status.SUCCESS, timeout=60), (
            f"Expected SUCCESS after retry, got {get_status(service)}"
        )

    def test_retry_exhaustion_stays_failed(
        self, orchestrator, reset_all_services
    ):
        """
        Service stays FAILED after exhausting max_retries.

        With success_after=99 (never succeeds) and max_retries=3,
        the service should remain FAILED after exhausting retries.
        """
        service = MockServiceName.E2E_SCHEDULED_RETRY

        reset_service(service)
        MockControl.set(service, "success_after", 99)  # Never succeed

        send_run_command(service)

        # Should fail and stay failed
        assert wait_for_status(service, Service.Enums.Status.FAILED, timeout=30), (
            f"Expected initial FAILED, got {get_status(service)}"
        )

        # Wait for retry exhaustion
        # With max_retry_count=3 and retry_cooldown_seconds=5, we need ~20s
        # to exhaust all retries: failure → 5s → retry1 → 5s → retry2 → 5s → retry3
        import time
        from orchestrator.models import get_db_session

        # Wait for all retries to exhaust
        for attempt in range(30):  # Wait up to 30s
            with get_db_session() as db:
                svc = db.query(Service.Table).filter_by(service_name=service).first()
                if svc.failure_count >= 3 and svc.status == Service.Enums.Status.FAILED.value:
                    # Retry exhaustion reached
                    break
            time.sleep(1)

        # Allow a moment for status to stabilize
        time.sleep(2)

        # Check failure_count >= max_retry_count and service is still failed
        with get_db_session() as db:
            svc = db.query(Service.Table).filter_by(service_name=service).first()
            assert svc.failure_count >= 3, (
                f"Expected failure_count >= 3, got {svc.failure_count}"
            )
            assert svc.status == Service.Enums.Status.FAILED.value, (
                f"Expected to stay FAILED after exhausting retries, got {svc.status}"
            )
