"""
E2E InfraMonitor Tests - Verify infrastructure monitoring.

Test Scenarios:
1. Infrastructure components are registered in the database
2. InfraMonitor service is running
3. Infrastructure components have health status updates

Usage:
    ENV=dev python -m orchestrator.testing
    ENV=dev pytest orchestrator/testing/tests/test_infra_monitor.py -v -s -m e2e
"""

import time

import pytest

from orchestrator import Service
from orchestrator.models import get_db_session
from .helpers import get_status, wait_for_status


# Infrastructure services configured in testing/__main__.py
INFRA_SERVICES = ("postgresql", "redis", "kafka")


@pytest.mark.e2e
class TestInfraMonitorRegistration:
    """Verify infrastructure components are registered."""

    def test_infra_monitor_service_is_registered(self, orchestrator):
        """InfraMonitor system service should be registered in the database."""
        status = get_status("infra_monitor")
        assert status is not None, "infra_monitor service should be registered"

    def test_infra_monitor_is_running(self, orchestrator):
        """InfraMonitor should be actively running or listening."""
        status = get_status("infra_monitor")
        assert status in (
            Service.Enums.Status.IDLE.value,  # May be idle between checks
            Service.Enums.Status.LISTENING.value,
            Service.Enums.Status.PROCESSING.value,
            Service.Enums.Status.SUCCESS.value,
        ), f"infra_monitor should be active, got {status}"

    @pytest.mark.parametrize("component", INFRA_SERVICES)
    def test_infrastructure_component_is_registered(self, orchestrator, component):
        """Each infrastructure component should be registered as a service."""
        with get_db_session() as db:
            svc = db.query(Service.Table).filter_by(service_name=component).first()
            assert svc is not None, f"Infrastructure component '{component}' should be registered"
            assert svc.service_category == Service.Enums.Category.INFRASTRUCTURE.value


@pytest.mark.e2e
class TestInfraMonitorHealthChecks:
    """Verify infrastructure health checks are working."""

    @pytest.mark.parametrize("component", INFRA_SERVICES)
    def test_infrastructure_component_has_status(self, orchestrator, component):
        """Infrastructure components should have their status updated by health checks."""
        # Wait for at least one health check cycle (InfraMonitor runs every 5s)
        assert wait_for_status(
            component,
            Service.Enums.Status.SUCCESS,
            timeout=15,
        ) or get_status(component) == Service.Enums.Status.FAILED.value, (
            f"Component '{component}' should have health status, got {get_status(component)}"
        )

    def test_healthy_infrastructure_shows_success(self, orchestrator):
        """Healthy infrastructure components should show SUCCESS status."""
        # Wait for health checks to run
        time.sleep(10)

        healthy_count = 0
        with get_db_session() as db:
            for component in INFRA_SERVICES:
                svc = db.query(Service.Table).filter_by(service_name=component).first()
                if svc and svc.status == Service.Enums.Status.SUCCESS.value:
                    healthy_count += 1

        # At least some infrastructure should be healthy in a working test environment
        assert healthy_count > 0, (
            f"Expected at least one healthy infrastructure component, got {healthy_count}"
        )


@pytest.mark.e2e
class TestInfraMonitorContinuousOperation:
    """Verify InfraMonitor operates continuously."""

    def test_infra_monitor_keeps_running(self, orchestrator):
        """InfraMonitor should remain active over multiple intervals."""
        # Check initial state
        initial_status = get_status("infra_monitor")
        assert initial_status is not None

        # Wait for a few health check cycles
        time.sleep(5)

        # Should still be running (or idle between checks)
        final_status = get_status("infra_monitor")
        assert final_status in (
            Service.Enums.Status.IDLE.value,  # May be idle between checks
            Service.Enums.Status.LISTENING.value,
            Service.Enums.Status.PROCESSING.value,
            Service.Enums.Status.SUCCESS.value,
        ), f"infra_monitor should still be active after 5s, got {final_status}"
