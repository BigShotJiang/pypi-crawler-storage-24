"""
E2E Happy Path Tests - Verify normal operation.

Test Scenarios:
1. Task service runs successfully and completes
2. Stream service processes data continuously
3. Service recovers from transient failure and keeps working
4. Batch processes all items successfully

Usage:
    ENV=dev python -m orchestrator.testing
    ENV=dev pytest infra_client/orchestrator/testing/tests/ -v -s -m e2e
"""

import pytest

from orchestrator import Service
from orchestrator.testing import (
    MockControl,
    MockServiceName,
)
from .helpers import (
    get_status,
    reset_service,
    send_run_command,
    wait_for_status,
)


@pytest.fixture
def reset_all_services():
    """Reset all mock service control flags."""
    MockControl.reset_all()
    yield
    MockControl.reset_all()


@pytest.mark.e2e
class TestScheduledSuccess:
    """Verify scheduled services complete successfully."""

    def test_scheduled_batch_completes_successfully(
        self, orchestrator, reset_all_services
    ):
        """
        Task service processes all items and reaches SUCCESS.

        With no failures configured, all 10 items should process
        and service should reach SUCCESS state.
        """
        service = MockServiceName.E2E_SCHEDULED_THRESHOLD

        reset_service(service)
        MockControl.set(service, "fail_count", 0)  # No failures

        send_run_command(service)

        assert wait_for_status(service, Service.Enums.Status.SUCCESS, timeout=30), (
            f"Expected SUCCESS after processing all items, got {get_status(service)}"
        )

    def test_task_with_acceptable_failures_still_succeeds(
        self, orchestrator, reset_all_services
    ):
        """
        Task batch succeeds even with some failures under threshold.

        With 2 failures out of 10 (20%), exactly at the threshold,
        the batch should still succeed.
        """
        service = MockServiceName.E2E_SCHEDULED_THRESHOLD

        reset_service(service)
        MockControl.set(service, "fail_count", 2)  # 20% = at threshold

        send_run_command(service)

        assert wait_for_status(service, Service.Enums.Status.SUCCESS, timeout=30), (
            f"Expected SUCCESS at threshold, got {get_status(service)}"
        )


@pytest.mark.e2e
class TestRetryRecovery:
    """Verify services recover after transient failures."""

    def test_service_recovers_after_retry_and_continues(
        self, orchestrator, reset_all_services
    ):
        """
        Service fails once, retries, succeeds, and can run again.

        After recovering from a transient failure, the service
        should be able to accept new RUN commands.
        """
        service = MockServiceName.E2E_SCHEDULED_RETRY

        reset_service(service)
        MockControl.set(service, "success_after", 2)  # Fail once, succeed on retry

        # First run - will fail then succeed on retry
        send_run_command(service)

        assert wait_for_status(service, Service.Enums.Status.SUCCESS, timeout=60), (
            f"Expected SUCCESS after retry, got {get_status(service)}"
        )

        # Reset and run again - should work immediately
        reset_service(service)
        MockControl.set(service, "success_after", 1)  # Succeed immediately

        send_run_command(service)

        assert wait_for_status(service, Service.Enums.Status.SUCCESS, timeout=30), (
            f"Expected SUCCESS on second run, got {get_status(service)}"
        )


@pytest.mark.e2e
class TestStreamContinuous:
    """Verify stream services operate continuously."""

    def test_stream_service_stays_running(
        self, orchestrator, reset_all_services
    ):
        """
        Stream service starts and stays in LISTENING state.

        Unlike task services that complete, stream services
        should remain active (LISTENING/PROCESSING) while running.
        """
        service = MockServiceName.E2E_DEP_PROVIDER

        reset_service(service)
        MockControl.set(service, "trigger_failure", "false")

        send_run_command(service)

        # Should reach LISTENING and stay there
        assert wait_for_status(service, Service.Enums.Status.LISTENING, timeout=30), (
            f"Expected LISTENING for stream service, got {get_status(service)}"
        )

        # Wait a bit and verify still active
        import time
        time.sleep(3)

        status = get_status(service)
        assert status in (Service.Enums.Status.LISTENING.value, Service.Enums.Status.PROCESSING.value), (
            f"Expected stream to stay active, got {status}"
        )
