"""
E2E Test Fixtures.

Tests require the orchestrator to be running:
    ENV=dev python -m orchestrator.testing

Test scenarios:
1. Dependency failure → dependent services stopped
2. Dependency recovery → dependent services restarted
3. State transitions match Mimir metrics
"""

import os
from typing import Generator

import pytest

from orchestrator import OrchestratorConfig
from orchestrator.config import get_project_config
from .helpers import get_status

PROJECT_NAME = "orchestrator_e2e"


def setup_test_environment() -> None:
    """Set up environment variables for tests."""
    env = os.getenv("ENV", "dev")
    os.environ["PROJECT_NAME"] = PROJECT_NAME
    os.environ["ENV"] = env

    # Configure orchestrator first
    OrchestratorConfig(env=env, project_name=PROJECT_NAME)

    # Now we can get config
    config = get_project_config()
    if not os.getenv("KAFKA_BOOTSTRAP_SERVERS"):
        os.environ["KAFKA_BOOTSTRAP_SERVERS"] = config.infra.kafka_url


def is_orchestrator_running() -> bool:
    """Check if orchestrator is running by looking for scheduler status."""
    try:
        status = get_status("scheduler")
        return status is not None
    except Exception:
        return False


@pytest.fixture(scope="session")
def orchestrator() -> Generator[None, None, None]:
    """Session-scoped orchestrator fixture.

    Configures the test environment and verifies orchestrator is running.
    """
    # Set up environment (also configures OrchestratorConfig)
    setup_test_environment()

    # Verify orchestrator is running
    if not is_orchestrator_running():
        pytest.fail(
            "Orchestrator is not running. Start it with:\n"
            "  ENV=dev python -m orchestrator.testing"
        )

    yield


@pytest.fixture
def reset_mock_services():
    """Reset mock service control flags before each test."""
    from orchestrator.testing import MockControl, MockServiceName

    MockControl.reset(MockServiceName.E2E_DEP_PROVIDER)
    MockControl.reset(MockServiceName.E2E_DEP_CONSUMER)
    yield
    MockControl.reset(MockServiceName.E2E_DEP_PROVIDER)
    MockControl.reset(MockServiceName.E2E_DEP_CONSUMER)
