"""
E2E Test Helpers - Utilities for e2e tests.

Provides:
- DB helpers: get_status, wait_for_status, reset_service, set_status
- Kafka helpers: send_run_command, send_kill_command
- Mimir helpers: get_state_transitions, verify_transitions_match
"""

import time
from typing import List, Optional

from orchestrator import (
    Service,
    command_bus,
)
from orchestrator.models import get_db_session


def get_service_id(service_name: str) -> str:
    """Get service UUID by name."""
    services = Service.Table.query(name=service_name)
    if not services:
        raise ValueError(f"Service not found: {service_name}")
    return services[0].id


def get_status(service_name: str) -> str:
    """Get current status of a service from DB."""
    with get_db_session() as db:
        svc = db.query(Service.Table).filter_by(service_name=service_name).first()
        return svc.status if svc else None


def get_last_error(service_name: str) -> Optional[str]:
    """Get last_error of a service from DB."""
    with get_db_session() as db:
        svc = db.query(Service.Table).filter_by(service_name=service_name).first()
        return svc.last_error if svc else None


def set_status(service_name: str, status: Service.Enums.Status) -> None:
    """Manually set a service's status in DB (for testing recovery)."""
    with get_db_session() as db:
        svc = db.query(Service.Table).filter_by(service_name=service_name).first()
        if svc:
            svc.status = status.value


def reset_service(service_name: str) -> None:
    """Reset a service's DB and MockControl state to clean.

    This function:
    1. Waits for any in-flight processing to complete
    2. Resets MockControl flags (attempt_count, success_after, etc.)
    3. Resets DB state to IDLE

    This ensures test isolation by waiting for the service to stabilize
    before resetting state.
    """
    from orchestrator.testing.mock_services import MockControl

    # Wait for service to finish any in-flight processing
    # Check if status is active (processing/listening) and wait for it to settle
    for _ in range(20):  # Wait up to 10 seconds
        status = get_status(service_name)
        if status not in (
            Service.Enums.Status.PROCESSING.value,
            Service.Enums.Status.LISTENING.value,
        ):
            break
        time.sleep(0.5)

    # Reset MockControl flags (attempt_count, success_after, etc.)
    MockControl.reset(service_name)

    # Reset DB state
    with get_db_session() as db:
        svc = db.query(Service.Table).filter_by(service_name=service_name).first()
        if svc:
            svc.status = Service.Enums.Status.IDLE.value
            svc.failure_count = 0
            svc.failure_reason = None
            svc.last_error = None
            svc.stop_requested = False
            svc.stop_reason = None
            svc.last_failure_at = None
            svc.next_run_at = None  # Clear scheduled retries


def wait_for_status(
    service_name: str,
    expected_status: Service.Enums.Status,
    timeout: float = 30,
) -> bool:
    """Wait for a service to reach expected status.

    Returns True if status reached, False if timeout.
    """
    start = time.time()
    while time.time() - start < timeout:
        status = get_status(service_name)
        if status == expected_status.value:
            return True
        time.sleep(0.5)
    return False


def send_run_command(service_name: str) -> None:
    """Send RUN_NOW command to a service via Kafka (bypasses schedule checks)."""
    from orchestrator.constants import ServiceCommand

    service_id = str(get_service_id(service_name))
    command_bus.send_command(service_id, ServiceCommand.RUN_NOW, reason="e2e_test")


def send_kill_command(service_name: str, reason: str = "test") -> None:
    """Send KILL command to a service via Kafka."""
    from orchestrator.constants import ServiceCommand

    service_id = str(get_service_id(service_name))
    command_bus.send_command(service_id, ServiceCommand.KILL, reason=reason)


def seed_stream_tasks(count: int = 10) -> None:
    """Seed test messages to the e2e stream topic.

    Stream services consume messages, so tests may need to seed
    more messages before each run.
    """
    from orchestrator.testing import seed_stream_messages

    seed_stream_messages(count=count)


# =============================================================================
# Mimir Helpers
# =============================================================================


def get_mimir_state_transitions(
    service_name: str,
    start_time: str,
    end_time: str,
) -> List[dict]:
    """Query Mimir for state transitions of a service.

    Args:
        service_name: Service to query
        start_time: RFC3339 start time
        end_time: RFC3339 end time

    Returns:
        List of {timestamp, status} dicts ordered by time
    """
    from orchestrator.config import get_project_config

    config = get_project_config()
    # TODO: Implement Mimir query
    # Use config.mimir_url to query service_status metric
    # Filter by service_name label
    # Return state changes over time
    return []


def verify_transitions_match_mimir(
    service_name: str,
    expected_transitions: List[str],
    start_time: str,
    end_time: str,
) -> bool:
    """Verify DB state transitions match Mimir metrics.

    Args:
        service_name: Service to verify
        expected_transitions: List of expected status values in order
        start_time: RFC3339 start time
        end_time: RFC3339 end time

    Returns:
        True if transitions match, False otherwise
    """
    mimir_transitions = get_mimir_state_transitions(service_name, start_time, end_time)
    # Extract just the status values
    mimir_statuses = [t["status"] for t in mimir_transitions]
    return mimir_statuses == expected_transitions
