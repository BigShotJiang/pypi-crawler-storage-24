"""
E2E Testing Support - Mock services for testing orchestrator behavior.

Provides controllable mock services for testing various failure scenarios:

Infrastructure Services:
- E2EInfraDatabase: Mock database health monitor
- E2EInfraCache: Mock cache (Redis) health monitor
- E2EInfraQueue: Mock message queue (Kafka) health monitor

Business Services (depend on infrastructure):
- E2EDepProvider: Upstream service that others depend on (tests dependency failure)
- E2EDepConsumer: Downstream service that depends on upstream (tests dependency propagation)
- E2EScheduledThreshold: Scheduled batch failure threshold (max_failure_ratio)
- E2EStreamThreshold: Stream consecutive failure threshold (max_failure_count)
- E2EScheduledRetry: Scheduled retry exhaustion (max_retries)

Usage:
    from orchestrator.testing import (
        MockServiceName,
        MockControl,
        E2EInfraDatabase,
        E2EInfraCache,
        E2EInfraQueue,
        E2EDepProvider,
        E2EDepConsumer,
        E2EScheduledThreshold,
        E2EStreamThreshold,
        E2EScheduledRetry,
    )

To run the test orchestrator:
    ENV=dev python -m orchestrator.testing
"""

from .mock_services import (
    E2E_STREAM_TOPIC,
    E2EDepConsumer,
    E2EDepProvider,
    E2EInfraCache,
    E2EInfraDatabase,
    E2EInfraQueue,
    E2EScheduledRetry,
    E2EScheduledThreshold,
    E2EStreamThreshold,
    MockControl,
    MockServiceName,
    get_mock_service_identities,
    seed_stream_messages,
)

__all__ = [
    "MockControl",
    "MockServiceName",
    # Infrastructure
    "E2EInfraDatabase",
    "E2EInfraCache",
    "E2EInfraQueue",
    # Business
    "E2EDepProvider",
    "E2EDepConsumer",
    "E2EScheduledThreshold",
    "E2EStreamThreshold",
    "E2EScheduledRetry",
    "get_mock_service_identities",
    # Stream testing
    "E2E_STREAM_TOPIC",
    "seed_stream_messages",
]
