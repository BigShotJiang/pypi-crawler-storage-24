"""
Entry point for e2e testing orchestrator.

Usage:
    ENV=dev python -m orchestrator.testing              # Run normally
    ENV=dev python -m orchestrator.testing reset        # Reset statuses first
    ENV=dev python -m orchestrator.testing reset 30     # Reset and run for 30s

Creates database 'orchestrator_e2e' with test services registered.
Uses ProcessManager to spawn mock services as separate processes.
Cross-process control via Redis-based MockControl.
"""

import os
import signal
import sys
from threading import Timer

from ..manager import ProcessManager
from .mock_services import (
    E2E_STREAM_TOPIC,
    get_mock_service_identities,
    seed_stream_messages,
)

PROJECT_NAME = "orchestrator_e2e"


def reset_all_statuses():
    """Reset all service statuses to idle (for test cleanup only)."""
    from sqlalchemy import text

    from ..models import get_db_session
    from .mock_services import MockControl, MockServiceName

    # Reset mock control flags in Redis
    for name in MockServiceName:
        MockControl.reset(name)

    with get_db_session() as db:
        result = db.execute(
            text(f"""
            UPDATE {PROJECT_NAME}.services
            SET status = 'idle', failure_count = 0, failure_reason = NULL,
                last_error = NULL, stop_requested = false, stop_reason = NULL,
                last_failure_at = NULL, last_heartbeat_at = NULL
            WHERE 1=1
        """)
        )
        db.commit()
        count = result.rowcount
        if count > 0:
            print(f"Reset {count} services")


def setup_test_scenarios():
    """Set up mock control flags for test scenarios (called after reset)."""
    from .mock_services import MockControl, MockServiceName

    # Retry scenario: fail twice, succeed on third attempt
    MockControl.set(MockServiceName.E2E_SCHEDULED_RETRY, "success_after", 3)


def ensure_stream_topic():
    """Ensure the e2e stream topic exists and seed initial messages."""
    from ..kafka import ensure_topics

    topic_config = [
        {
            "name": E2E_STREAM_TOPIC,
            "partitions": 1,
            "replication_factor": 1,
            "config": {"retention.ms": str(24 * 60 * 60 * 1000)},  # 1 day
        }
    ]
    result = ensure_topics(topic_config)
    if result.get(E2E_STREAM_TOPIC):
        print(f"Created topic: {E2E_STREAM_TOPIC}")

    # Seed test messages so stream services have work to do
    seed_stream_messages(count=20)
    print(f"Seeded 20 messages to {E2E_STREAM_TOPIC}")


def main():
    """Run the e2e test orchestrator with mock services."""
    from ..config import OrchestratorConfig

    env = os.getenv("ENV")
    if not env:
        raise ValueError("ENV environment variable must be set (dev, test, prod)")

    # Configure orchestrator early (needed for kafka, db access)
    OrchestratorConfig(project_name=PROJECT_NAME, env=env)

    # Parse command line args
    args = sys.argv[1:]
    reset = False
    duration = None

    for arg in args:
        if arg == "reset":
            reset = True
        elif arg.isdigit():
            duration = int(arg)

    # Reset statuses if requested
    if reset:
        reset_all_statuses()
        setup_test_scenarios()

    # Ensure stream topic exists and seed messages
    ensure_stream_topic()

    # Schedule status report and shutdown after duration seconds
    if duration:
        from ..models import get_db_session, Service

        def print_status():
            """Print status of all services."""
            from datetime import datetime, timezone

            print(f"\n=== Service statuses after {duration}s ===")
            with get_db_session() as db:
                services = db.query(Service.Table).order_by(
                    Service.Table.service_name
                ).all()
                now = datetime.now(timezone.utc)
                for svc in services:
                    if svc.last_heartbeat_at:
                        hb_ago = int((now - svc.last_heartbeat_at).total_seconds())
                        hb_str = f"hb={hb_ago}s"
                    else:
                        hb_str = "no heartbeat"
                    print(
                        f"{svc.service_name}: {svc.status} "
                        f"(cat={svc.service_category}, {hb_str})"
                    )
            os.kill(os.getpid(), signal.SIGTERM)

        timer = Timer(duration, print_status)
        timer.daemon = True
        timer.start()

    ProcessManager(
        env=env,
        project_name=PROJECT_NAME,
        business_services=get_mock_service_identities(),
        infra_services=("postgresql", "redis", "kafka"),
    ).run()


if __name__ == "__main__":
    main()
