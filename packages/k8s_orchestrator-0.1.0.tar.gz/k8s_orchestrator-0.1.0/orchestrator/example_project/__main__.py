"""
Example Project - Runs the orchestrator with ProcessManager.

Usage:
    ENV=dev python -m orchestrator.example_project

Environment Variables:
    ENV: Required - dev, test, or prod (determines database connection)
    DATABASE_URL: Optional - Override the default postgres URL
    KAFKA_BOOTSTRAP_SERVERS: Optional - Override Kafka servers
"""

import os
import sys

from orchestrator import ProcessManager

from .identities import get_example_service_identities

if __name__ == "__main__":
    env = os.getenv("ENV")
    if not env:
        print("ERROR: ENV must be set (dev, test, or prod)")
        sys.exit(1)

    ProcessManager(
        env=env,
        project_name="example_project",
        business_services=get_example_service_identities(),
    ).run()
