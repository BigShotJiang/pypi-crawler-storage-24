"""
Example Project - Template for building projects on the orchestrator framework.

This package demonstrates the recommended structure for projects that extend
the infra-client orchestrator framework.

Structure:
    example_project/
    ├── __init__.py       # Package init
    ├── __main__.py       # Entry point for `python -m`
    ├── identities.py     # Service identity definitions
    ├── services.py       # Service implementations
    └── main.py           # Orchestrator configuration and startup

Usage:
    # Run the example orchestrator
    ENV=dev python -m orchestrator.example_project

    # Or from Python
    from orchestrator.example_project.main import main
    main()
"""

from .identities import (
    ExampleServiceName,
    get_example_service_identities,
)
from .services import (
    ExampleDataFetcher,
    ExampleStreamProcessor,
)

__all__ = [
    "ExampleServiceName",
    "get_example_service_identities",
    "ExampleDataFetcher",
    "ExampleStreamProcessor",
]
