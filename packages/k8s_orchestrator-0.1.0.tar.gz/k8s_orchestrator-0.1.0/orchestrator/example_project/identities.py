"""
Service Identities - Defines the service registry for this project.

Each service needs a Service.Identity that defines:
- service_name: Unique identifier (use an enum for type safety)
- service_category: BUSINESS, SYSTEM, INFRA, API, or TEST
- execution_type: TASK (scheduled) or STREAM (continuous)
- description: Human-readable description
- display_name: Optional friendly name for dashboards
- cron_schedule: For TASK services, when to run (cron expression)
- dependencies: Other services this service depends on
- config: Custom configuration passed to the service
- module_path: Python module path for ProcessManager to spawn the service

Usage:
    from .identities import ExampleRegistry

    # In your service __init__:
    identity = Service.Table.bootstrap(ExampleRegistry.DATA_FETCHER)
"""

from enum import StrEnum

from orchestrator import Service

# Module prefix for this project's services
_MODULE_PREFIX = "orchestrator.example_project.services"


class ExampleServiceName(StrEnum):
    """Service identifiers for this project.

    Using StrEnum provides type safety and IDE autocompletion.
    """

    DATA_FETCHER = "example_data_fetcher"
    STREAM_PROCESSOR = "example_stream_processor"


# =============================================================================
# Service Identity Registry
# =============================================================================


class ExampleRegistry:
    """Registry of example service identities with direct attribute access."""

    DATA_FETCHER = Service.Identity(
        service_name=ExampleServiceName.DATA_FETCHER,
        service_category=Service.Enums.Category.BUSINESS,
        execution_type=Service.Enums.ExecutionType.SCHEDULED,
        description="Fetches data from external API on schedule",
        display_name="Data Fetcher",
        cron_schedule="0 */6 * * *",  # Every 6 hours
        module_path=f"{_MODULE_PREFIX}.data_fetcher",
        config={
            "api_url": "https://api.example.com/data",
            "timeout_seconds": 30,
        },
    )

    STREAM_PROCESSOR = Service.Identity(
        service_name=ExampleServiceName.STREAM_PROCESSOR,
        service_category=Service.Enums.Category.BUSINESS,
        execution_type=Service.Enums.ExecutionType.STREAM,
        description="Processes incoming data stream continuously",
        display_name="Stream Processor",
        dependencies=(ExampleServiceName.DATA_FETCHER,),  # Depends on fetcher
        module_path=f"{_MODULE_PREFIX}.stream_processor",
        config={
            "poll_timeout_ms": 1000,
            "batch_size": 100,
        },
    )


def get_example_service_identities() -> tuple[Service.Identity, ...]:
    """Return all service identities for the example project."""
    return (
        ExampleRegistry.DATA_FETCHER,
        ExampleRegistry.STREAM_PROCESSOR,
    )
