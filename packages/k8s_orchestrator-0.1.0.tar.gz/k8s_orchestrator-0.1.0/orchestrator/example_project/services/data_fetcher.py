"""
Data Fetcher Service - Fetches data from external API on schedule.

This is a TASK service - it runs on a cron schedule, processes items,
then exits. The Scheduler will trigger it again at the next scheduled time.
"""

from typing import List

from ...events import Result
from ...loggers import log
from ...services import Service
from ...scheduled import ScheduledService
from ..identities import ExampleRegistry

logger = log


class ExampleDataFetcher(ScheduledService):
    """Fetches data from external API on schedule."""

    def __init__(self) -> None:
        # Self-register: upsert identity to DB and get back with id populated
        identity = Service.Table.bootstrap(ExampleRegistry.DATA_FETCHER)
        super().__init__(identity)

    def get_tasks(self) -> List[dict]:
        """Return list of data sources to fetch.

        Each task must have 'id' and 'description' fields.
        """
        return [
            {"id": "users", "description": "Fetch users", "endpoint": "/users", "params": {"limit": 100}},
            {"id": "orders", "description": "Fetch orders", "endpoint": "/orders", "params": {"since": "yesterday"}},
            {"id": "products", "description": "Fetch products", "endpoint": "/products", "params": {"category": "active"}},
        ]

    def on_step(self, task: dict) -> Result:
        """Process a single fetch task.

        Args:
            task: One item from get_tasks()

        Returns:
            Result: Use Result.ok() for success, Result.fail("reason") for failure.
        """
        endpoint = task["endpoint"]
        params = task["params"]

        logger.info(
            "fetching_data",
            endpoint=endpoint,
            params=params,
        )

        # TODO: Your actual fetch logic here
        # Example:
        # api_url = self._identity.config.get("api_url")
        # timeout = self._identity.config.get("timeout_seconds", 30)
        # response = requests.get(f"{api_url}{endpoint}", params=params, timeout=timeout)
        # self.save_data(response.json())

        logger.info("fetch_complete", endpoint=endpoint)
        return Result.ok()


# =============================================================================
# Entry Point (for ProcessManager spawning)
# =============================================================================

if __name__ == "__main__":
    ExampleDataFetcher.start()
