"""
Stream Processor Service - Processes incoming data stream continuously.

This is a STREAM service - it runs continuously, polling for Kafka messages
and processing them as they arrive. It only stops when told to via command.
"""

from ...config import get_project_config
from ...events import Result
from ...kafka import get_events_topic
from ...loggers import log
from ...services import Service
from ...stream import StreamService
from ..identities import ExampleRegistry

logger = log


class ExampleStreamProcessor(StreamService):
    """Processes incoming data stream continuously."""

    def __init__(self) -> None:
        # Self-register: upsert identity to DB and get back with id populated
        identity = Service.Table.bootstrap(ExampleRegistry.STREAM_PROCESSOR)

        config = get_project_config()
        poll_timeout = identity.config.get("poll_timeout_ms", 1000)

        super().__init__(
            identity,
            kafka_topic=get_events_topic(),
            poll_timeout_ms=poll_timeout,
        )

    def on_step(self, task: dict) -> Result:
        """Process a single task from the Kafka stream.

        Args:
            task: The task dict with 'id' and 'message' fields

        Returns:
            Result: Use Result.ok() for success, Result.fail("reason") for failure.
        """
        logger.info(
            "processing_task",
            task_id=task.get("id"),
            message=task.get("message"),
        )

        # TODO: Your actual processing logic here
        # Example:
        # result = transform(task)
        # save_to_db(result)

        logger.info("task_processed", task_id=task.get("id"))
        return Result.ok()


# =============================================================================
# Entry Point (for ProcessManager spawning)
# =============================================================================

if __name__ == "__main__":
    ExampleStreamProcessor.start()
