"""
Service implementations and entry points for the example project.

Each service has:
- Implementation class (ScheduledService or StreamService subclass)
- Entry point module (for ProcessManager to spawn)

Entry point modules are run with: python -m orchestrator.example_project.services.<service>
"""

from .data_fetcher import ExampleDataFetcher
from .stream_processor import ExampleStreamProcessor

__all__ = ["ExampleDataFetcher", "ExampleStreamProcessor"]
