"""
Orchestrator CLI entry point.

This is the framework's CLI, which requires --project for most commands.
For project-specific CLIs (without --project), use ProjectCLI in your
project's __main__.py instead.

Usage:
    python -m orchestrator                              # Show help
    python -m orchestrator example                      # Run example project
    python -m orchestrator list [--project NAME]        # List all services
    python -m orchestrator run SERVICE [--project NAME] # Run service immediately
    python -m orchestrator kill SERVICE [--project NAME] # Kill a running service

Environment Variables:
    ENV: Required - dev, test, or prod (determines database connection)
    PROJECT: Optional - project name (can also use --project flag)

For project-specific CLI (recommended):
    # In your project's __main__.py:
    from orchestrator import ProjectCLI
    ProjectCLI(project_name="my_project", services=SERVICES).run()

    # Then use:
    python -m my_project start    # No --project needed!
"""

import argparse
import sys
from typing import Optional

from .cli import ProjectCLI


def _get_project(args_project: Optional[str]) -> str:
    """Get project name from args or environment."""
    import os
    project = args_project or os.getenv("PROJECT")
    if not project:
        print("ERROR: Project name required. Use --project NAME or set PROJECT env var")
        print("\nTip: For project-specific CLI without --project, use ProjectCLI in your __main__.py")
        sys.exit(1)
    return project


def cmd_list(args) -> None:
    """List all registered services."""
    project = _get_project(args.project)
    # Create a minimal ProjectCLI just for this command
    cli = ProjectCLI(project_name=project, services=())
    cli.cmd_list(args)


def cmd_run(args) -> None:
    """Send RUN_NOW command to a service."""
    project = _get_project(args.project)
    cli = ProjectCLI(project_name=project, services=())
    cli.cmd_run(args)


def cmd_kill(args) -> None:
    """Send KILL command to a service."""
    project = _get_project(args.project)
    cli = ProjectCLI(project_name=project, services=())
    cli.cmd_kill(args)


def cmd_status(args) -> None:
    """Show system status."""
    project = _get_project(args.project)
    cli = ProjectCLI(project_name=project, services=())
    cli.cmd_status(args)


def cmd_stop(args) -> None:
    """Stop all running services."""
    project = _get_project(args.project)
    cli = ProjectCLI(project_name=project, services=())
    cli.cmd_stop(args)


def cmd_example(args) -> None:
    """Run the example project."""
    import os
    env = os.getenv("ENV")
    if not env:
        print("ERROR: ENV must be set (dev, test, or prod)")
        sys.exit(1)

    from .example_project.identities import get_example_service_identities
    from .manager import ProcessManager

    ProcessManager(
        env=env,
        project_name="example_project",
        business_services=get_example_service_identities(),
    ).run()


def main():
    parser = argparse.ArgumentParser(
        description="Orchestrator CLI - Manage distributed services",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ENV=dev python -m orchestrator list --project barren
  ENV=dev PROJECT=barren python -m orchestrator run sec_daily_index
  ENV=dev python -m orchestrator kill sec_bulk_submissions --project barren
  ENV=dev python -m orchestrator status --project barren
  ENV=dev python -m orchestrator stop --project barren

For project-specific CLI (recommended):
  # Add to your project's __main__.py:
  from orchestrator import ProjectCLI
  ProjectCLI(project_name="my_project", services=SERVICES).run()

  # Then use without --project:
  python -m my_project start
  python -m my_project list

Environment:
  ENV       Required. One of: dev, test, prod
  PROJECT   Optional. Project name (alternative to --project flag)
""",
    )

    # Global options
    parser.add_argument(
        "--project", "-p",
        help="Project name (or set PROJECT env var)",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # status command
    status_parser = subparsers.add_parser("status", help="Show system status")
    status_parser.add_argument("--project", "-p", help="Project name")
    status_parser.set_defaults(func=cmd_status)

    # stop command
    stop_parser = subparsers.add_parser("stop", help="Stop all running services")
    stop_parser.add_argument("--project", "-p", help="Project name")
    stop_parser.set_defaults(func=cmd_stop)

    # list command
    list_parser = subparsers.add_parser("list", help="List all registered services")
    list_parser.add_argument("--project", "-p", help="Project name")
    list_parser.add_argument("--filter", "-f", help="Filter by service name")
    list_parser.add_argument(
        "--status", "-s",
        choices=["idle", "listening", "processing", "success", "failed"],
        help="Filter by status"
    )
    list_parser.set_defaults(func=cmd_list)

    # run command
    run_parser = subparsers.add_parser("run", help="Run a service immediately (RUN_NOW)")
    run_parser.add_argument("service", help="Service name to run")
    run_parser.add_argument("--project", "-p", help="Project name")
    run_parser.set_defaults(func=cmd_run)

    # kill command
    kill_parser = subparsers.add_parser("kill", help="Kill a running service")
    kill_parser.add_argument("service", help="Service name to kill")
    kill_parser.add_argument("--project", "-p", help="Project name")
    kill_parser.add_argument("--reason", "-r", help="Reason for killing")
    kill_parser.set_defaults(func=cmd_kill)

    # example command
    example_parser = subparsers.add_parser("example", help="Run the example project")
    example_parser.set_defaults(func=cmd_example)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    # Execute command
    args.func(args)


if __name__ == "__main__":
    main()
