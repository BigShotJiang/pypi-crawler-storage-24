# Orchestrator — k8s Service Lifecycle Framework

Service lifecycle framework: scheduling, health, retry, process management.

## Architecture

```
┌─────────────────────────────────────────────────┐
│                 ProcessManager                   │
│          spawn / SIGTERM / SIGINT                 │
└──────────┬──────────────────────┬───────────────┘
           │                      │
  ┌────────┴────────┐   ┌────────┴────────┐
  │ScheduledService │   │  StreamService   │
  │   (CronJob)     │   │  (Deployment)    │
  └────────┬────────┘   └────────┬────────┘
           │                      │
     ┌─────┴─────┐         ┌─────┴─────┐
     │get_tasks() │         │  Kafka    │
     │on_step()   │         │ on_step() │
     │Result.ok/  │         │ Result.ok/│
     │Result.fail │         │ Result.fail│
     └─────┬─────┘         └─────┴─────┘
           │                      │
     ┌─────┴──────────────────────┴─────┐
     │         Postgres (state)          │
     │  Service.Table: status, heartbeat │
     │  TableOutputMixin: auto upsert    │
     └──────────────────────────────────┘
```

## Installation

```bash
pip install k8s-orchestrator
```

## Quick Start

### ScheduledService (→ k8s CronJob)

Runs on a schedule, processes tasks to completion, exits.

```python
from orchestrator import ScheduledService
from orchestrator.events import Result

class MyFetcher(ScheduledService):
    def get_tasks(self) -> list[dict]:
        return [
            {"id": "AAPL", "description": "Fetch AAPL data"},
            {"id": "MSFT", "description": "Fetch MSFT data"},
        ]

    def on_step(self, task: dict) -> Result:
        data = fetch_price(task["id"])
        save_to_db(data)
        return Result.ok(f"Fetched {len(data)} rows")
```

### StreamService (→ k8s Deployment)

Long-running, processes Kafka messages continuously.

```python
from orchestrator import StreamService
from orchestrator.events import Result

class EventProcessor(StreamService):
    def __init__(self):
        super().__init__(kafka_topic="myproject.events")

    def on_step(self, task: dict) -> Result:
        handle_event(task["data"])
        return Result.ok()
```

## Key Abstractions

- `ServiceIdentity` — Declarative metadata (name, category, schedule, dependencies, config, module_path)
- `Result` — Unified return type: `Result.ok()` / `Result.fail(msg)`. No boolean ambiguity.
- `ProcessManager` — Spawns services as subprocesses, handles SIGTERM/SIGINT
- `TableOutputMixin` — Schema + primary key → auto create + upsert
- `BatchManager` — Task tracking (success/fail counts, failure threshold)

## Registry Pattern

```python
from orchestrator import Service, ServiceIdentity

class SecRegistry:
    DAILY_INDEX = ServiceIdentity(
        service_name="sec_daily_index",
        execution_type="scheduled",
        cron_schedule="0 */2 * * *",
        module_path="fetchers.sec.services.daily_index",
    )

    @classmethod
    def all(cls) -> list[ServiceIdentity]:
        return [cls.DAILY_INDEX]
```

## Lifecycle Hooks

```python
class MyService(ScheduledService):
    def on_start(self):       # once before processing
    def on_batch_start(self): # start of each batch
    def on_batch_end(self):   # end of each batch (always, even on error)
```

## Failure Handling

- `max_failure_ratio = 0.1` — fail batch if >10% tasks fail (ScheduledService)
- `max_failure_count` — fail after N consecutive failures (StreamService)

## Key Principles

1. Each service = one container entrypoint
2. k8s handles lifecycle — scheduling, restart, scaling
3. Services are stateless — state lives in Postgres/Kafka
4. Result type everywhere
5. Registry is the source of truth — generates k8s manifests

## Development

Branches follow a promotion chain: `dev` → `test` → `main` (prod).

Merging to `main` auto-publishes to PyPI.

## License

MIT
