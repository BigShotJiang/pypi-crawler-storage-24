#!/usr/bin/env python3
"""
Setup Completeness Checker for PreAudit.

Analyzes ProverResult objects to identify setup issues that may affect verification quality.
Checks for: unresolved calls, timeouts, errors/unknown results, sanity failures, and PTA issues.
"""

import json
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from src.utils.runner_types import ProverResult


class SetupIssueType(Enum):
    """Types of setup completeness issues."""

    UNRESOLVED_CALL = "Unresolved Calls"
    TIMEOUT = "Timeouts"
    ERROR_OR_UNKNOWN = "Errors/Unknown"
    SANITY_FAILURE = "Sanity Failures"
    # PTA (Pointer Analysis) issue types
    PTA_STORAGE_SPLITTING = "PTA: Storage Splitting"
    PTA_STORAGE_ANALYSIS = "PTA: Storage Analysis"
    PTA_POINTER_ANALYSIS_OPTIMIZATION = "PTA: Pointer Analysis Optimization"
    PTA_MEMORY_PARTITIONING = "PTA: Memory Partitioning"
    PTA_INTERNAL_FUNCTION_ANALYSIS = "PTA: Internal Function Analysis"
    PTA_CALL_RESOLUTION = "PTA: Call Resolution"
    PTA_LINKING = "PTA: Linking"
    PTA_OTHER = "PTA: Other"


class SetupIssueSeverity(Enum):
    """Severity levels for setup issues."""

    WARNING = "warning"
    ERROR = "error"
    INFO = "info"


@dataclass
class SetupIssue:
    """Represents a single setup completeness issue."""

    issue_type: SetupIssueType
    severity: SetupIssueSeverity
    message: str
    source_location: Optional[str] = None
    contract: Optional[str] = None
    function: Optional[str] = None
    caller: Optional[str] = None  # For unresolved calls: the function making the call
    rule_name: Optional[str] = None
    job_url: Optional[str] = None
    raw_data: Optional[Dict[str, Any]] = None
    count: int = 1  # Number of occurrences of this issue

    def dedup_key(self) -> Tuple:
        """Return a key for deduplication. Issues with the same key are considered duplicates."""
        return (self.issue_type, self.contract, self.function, self.caller, self.rule_name, self.message)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result: Dict[str, Any] = {
            "type": self.issue_type.name.lower(),
            "severity": self.severity.value,
            "message": self.message,
        }
        if self.source_location:
            result["source_location"] = self.source_location
        if self.contract:
            result["contract"] = self.contract
        if self.function:
            result["function"] = self.function
        if self.caller:
            result["caller"] = self.caller
        if self.rule_name:
            result["rule_name"] = self.rule_name
        if self.job_url:
            result["job_url"] = self.job_url
        if self.count > 1:
            result["count"] = self.count
        return result


@dataclass
class SetupCompletenessReport:
    """Aggregated setup completeness report for one or more prover runs."""

    reports_dir: Path
    issues_by_type: Dict[SetupIssueType, List[SetupIssue]] = field(default_factory=dict)
    filename_prefix: str = "setup_completeness"

    @property
    def md_path(self) -> Path:
        return self.reports_dir / f"{self.filename_prefix}_report.md"

    @property
    def json_path(self) -> Path:
        return self.reports_dir / f"{self.filename_prefix}_report.json"

    def get_issues(self, issue_type: SetupIssueType) -> List[SetupIssue]:
        """Get issues of a specific type."""
        return self.issues_by_type.get(issue_type, [])

    def add_issues(self, issues: Sequence[SetupIssue]) -> None:
        """Add issues to the report, deduplicating by incrementing count for duplicates."""
        for issue in issues:
            issue_list = self.issues_by_type.setdefault(issue.issue_type, [])
            key = issue.dedup_key()
            # Check if duplicate exists
            for existing in issue_list:
                if existing.dedup_key() == key:
                    existing.count += issue.count
                    break
            else:
                issue_list.append(issue)

    @property
    def total_issues(self) -> int:
        """Total count of all issues."""
        return sum(len(issues) for issues in self.issues_by_type.values())

    @property
    def has_issues(self) -> bool:
        """Whether any issues were found."""
        return self.total_issues > 0

    def to_markdown(self) -> str:
        """Generate Markdown report content."""
        lines = [
            "# Setup Completeness Report",
            "",
            f"**Generated:** {time.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## Summary",
            "",
        ]
        for issue_type in SetupIssueType:
            count = len(self.get_issues(issue_type))
            anchor = issue_type.value.lower().replace(" ", "-").replace(":", "").replace("/", "")
            lines.append(f"- **[{issue_type.value}](#{anchor}):** {count}")
        lines.append("")

        if not self.has_issues:
            lines.append("**No setup completeness issues found.**")
            return "\n".join(lines)

        # Detailed sections
        for issue_type in SetupIssueType:
            issues = self.get_issues(issue_type)
            if issues:
                lines.extend(self._format_markdown_section(issue_type.value, issues))

        return "\n".join(lines)

    def _format_markdown_section(self, title: str, issues: List[SetupIssue]) -> List[str]:
        """Format a section of issues for Markdown output."""
        lines = [f"## {title}", ""]

        for i, issue in enumerate(issues, 1):
            header_msg = issue.message[:80] + ("..." if len(issue.message) > 80 else "")
            count_suffix = f" (x{issue.count})" if issue.count > 1 else ""
            lines.append(f"### {i}. {header_msg}{count_suffix}")
            lines.append("")

            if issue.count > 1:
                lines.append(f"- **Occurrences:** {issue.count}")
            if issue.contract:
                lines.append(f"- **Contract:** {issue.contract}")
            if issue.function:
                lines.append(f"- **Function:** {issue.function}")
            if issue.caller:
                lines.append(f"- **Called from:** {issue.caller}")
            if issue.rule_name:
                lines.append(f"- **Rule:** {issue.rule_name}")
            if issue.source_location:
                lines.append(f"- **Location:** `{issue.source_location}`")
            if issue.job_url:
                lines.append(f"- **Job:** [{issue.job_url}]({issue.job_url})")
            lines.append("")

        return lines

    def to_json(self) -> Dict[str, Any]:
        """Generate JSON report data."""
        summary: Dict[str, Any] = {"total_issues": self.total_issues}
        issues_dict: Dict[str, Any] = {}

        for issue_type in SetupIssueType:
            type_issues = self.get_issues(issue_type)
            key = issue_type.name.lower()
            summary[key] = len(type_issues)
            issues_dict[key] = [i.to_dict() for i in type_issues]

        return {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "summary": summary,
            "issues": issues_dict,
        }

    def save(self) -> None:
        """Save both Markdown and JSON reports."""
        self.reports_dir.mkdir(parents=True, exist_ok=True)

        with open(self.md_path, "w") as f:
            f.write(self.to_markdown())

        with open(self.json_path, "w") as f:
            json.dump(self.to_json(), f, indent=2)


class PTAMessageParser:
    """Parse PTA alert messages to categorize issues."""

    # Regex patterns for PTA issue categorization
    # Each pattern extracts contract and function names where applicable
    PATTERNS: Dict[SetupIssueType, re.Pattern] = {
        SetupIssueType.PTA_STORAGE_SPLITTING: re.compile(
            r"Storage splitting for \w+ failed in contract (\w+), function (\w+)"
        ),
        SetupIssueType.PTA_STORAGE_ANALYSIS: re.compile(
            r"Storage analysis for \w+ failed in contract (\w+), function (\w+)"
        ),
        SetupIssueType.PTA_POINTER_ANALYSIS_OPTIMIZATION: re.compile(
            r"Pointer analysis for optimization failed in contract (\w+), function (\w+)"
        ),
        SetupIssueType.PTA_MEMORY_PARTITIONING: re.compile(
            r"Memory partitioning failed while analyzing contract (\w+), function (\w+)"
        ),
        SetupIssueType.PTA_INTERNAL_FUNCTION_ANALYSIS: re.compile(
            r"Failed to locate an internal function called from (\S+)"
        ),
        SetupIssueType.PTA_CALL_RESOLUTION: re.compile(
            r"Pointer analysis for call resolution failed in contract (\w+), function (\w+)"
        ),
        SetupIssueType.PTA_LINKING: re.compile(
            r"Pointer analysis failed, could pose a linking issue in contract (\w+), function (\w+)"
        ),
    }

    @classmethod
    def parse_message(cls, message: str) -> Tuple[SetupIssueType, Optional[str], Optional[str]]:
        """
        Parse a PTA alert message and extract type, contract, function.

        Returns:
            Tuple of (SetupIssueType, contract_name or None, function_name or None)
        """
        for issue_type, pattern in cls.PATTERNS.items():
            match = pattern.search(message)
            if match:
                groups = match.groups()
                if issue_type == SetupIssueType.PTA_INTERNAL_FUNCTION_ANALYSIS:
                    # Pattern captures: function reference (e.g., "ContractName-fallback")
                    return (issue_type, None, groups[0])
                else:
                    # Pattern captures: (contract, function)
                    return (issue_type, groups[0], groups[1] if len(groups) > 1 else None)

        return (SetupIssueType.PTA_OTHER, None, None)


class SetupCompletenessChecker:
    """
    Analyzes ProverResult objects to identify setup completeness issues.

    Checks for:
    1. Unresolved calls from CallResolutionInfo
    2. Timeouts from RuleResult
    3. Errors/Unknown/Killed from RuleResult
    4. Sanity failures from RuleResult
    5. PTA issues from alert_report
    """

    # Statuses that indicate errors or unknown results
    ERROR_STATUSES = {"ERROR", "UNKNOWN", "KILLED"}

    def __init__(self, log_func: Optional[Callable[[str, str], None]] = None):
        """
        Initialize the checker.

        Args:
            log_func: Optional logging function with signature (message, level)
        """
        self.log = log_func or (lambda msg, level="INFO": print(f"[{level}] {msg}"))
        self.pta_parser = PTAMessageParser()

    def analyze_result(self, result: ProverResult) -> List[SetupIssue]:
        """
        Analyze a single ProverResult for setup issues.

        Args:
            result: ProverResult from a prover run

        Returns:
            List of detected issues
        """
        job_url = result.job_url
        issues: List[SetupIssue] = []
        issues.extend(self._check_unresolved_calls(result, job_url))
        issues.extend(self._check_timeouts(result, job_url))
        issues.extend(self._check_errors_and_unknowns(result, job_url))
        issues.extend(self._check_sanity_failures(result, job_url))
        issues.extend(self._check_pta_issues(result, job_url))
        return issues

    def _check_unresolved_calls(self, result: ProverResult, job_url: Optional[str]) -> List[SetupIssue]:
        """Extract unresolved calls from output_data."""
        issues = []
        # Can be CallResolutionInfo objects or dicts (when loaded from cache)
        unresolved_calls = result.output_data.get("unresolved_calls", [])

        for call_info in unresolved_calls:
            # Handle both CallResolutionInfo objects and dicts (when loaded from cache)
            if isinstance(call_info, dict):
                is_unresolved = call_info.get("is_unresolved", True)
                caller = call_info.get("caller", "unknown")
                callee = call_info.get("callee", "unknown")
                source_loc = call_info.get("source_location")
                call_site = call_info.get("call_site", "")
                raw = call_info
            else:
                is_unresolved = call_info.is_unresolved
                caller = call_info.caller_name
                callee = call_info.callee_name
                source_loc = call_info.source_location
                call_site = call_info.call_site_snippet
                raw = call_info.to_dict()

            if is_unresolved:
                msg = f"Unresolved call to {callee} from {caller}"
                if call_site:
                    msg += f": {call_site[:100]}"
                issues.append(
                    SetupIssue(
                        issue_type=SetupIssueType.UNRESOLVED_CALL,
                        severity=SetupIssueSeverity.WARNING,
                        message=msg,
                        source_location=source_loc,
                        function=callee,
                        caller=caller,
                        job_url=job_url,
                        raw_data=raw,
                    )
                )

        return issues

    def _check_timeouts(self, result: ProverResult, job_url: Optional[str]) -> List[SetupIssue]:
        """Check for TIMEOUT status in rule results."""
        issues = []
        for rule in result.rule_results:
            if rule.status.upper() == "TIMEOUT":
                issues.append(
                    SetupIssue(
                        issue_type=SetupIssueType.TIMEOUT,
                        severity=SetupIssueSeverity.WARNING,
                        message=f"Rule '{rule.rule_name}' timed out for method {rule.method or 'unknown'}",
                        contract=rule.contract,
                        function=rule.method,
                        rule_name=rule.rule_name,
                        job_url=job_url,
                    )
                )
        return issues

    def _check_errors_and_unknowns(self, result: ProverResult, job_url: Optional[str]) -> List[SetupIssue]:
        """Check for ERROR, UNKNOWN, or KILLED status in rule results."""
        issues = []

        for rule in result.rule_results:
            if rule.status.upper() in self.ERROR_STATUSES:
                issues.append(
                    SetupIssue(
                        issue_type=SetupIssueType.ERROR_OR_UNKNOWN,
                        severity=SetupIssueSeverity.WARNING,
                        message=f"Rule '{rule.rule_name}' has status {rule.status} for method {rule.method or 'unknown'}",
                        contract=rule.contract,
                        function=rule.method,
                        rule_name=rule.rule_name,
                        job_url=job_url,
                    )
                )
        return issues

    def _check_sanity_failures(self, result: ProverResult, job_url: Optional[str]) -> List[SetupIssue]:
        """Check for sanity rule violations."""
        issues = []
        for rule in result.rule_results:
            # Check for sanity rule failures
            if rule.rule_name == "sanity" and rule.status.upper() in {"VIOLATED", "FAILED"}:
                msg = f"Sanity check failed for method {rule.method or 'unknown'}"
                if rule.assert_message:
                    msg += f": {rule.assert_message}"
                issues.append(
                    SetupIssue(
                        issue_type=SetupIssueType.SANITY_FAILURE,
                        severity=SetupIssueSeverity.WARNING,
                        message=msg,
                        contract=rule.contract,
                        function=rule.method,
                        rule_name="sanity",
                        job_url=job_url,
                    )
                )
        return issues

    def _check_pta_issues(self, result: ProverResult, job_url: Optional[str]) -> List[SetupIssue]:
        """Parse alert_report for PTA issues."""
        issues = []

        for alert in result.alert_report:
            message = alert.get("message", "")
            if not message:
                continue

            severity_str = alert.get("severity", "warning").lower()
            severity = SetupIssueSeverity.ERROR if severity_str == "error" else SetupIssueSeverity.WARNING

            # Categorize the PTA issue
            issue_type, contract, function = self.pta_parser.parse_message(message)

            issues.append(
                SetupIssue(
                    issue_type=issue_type,
                    severity=severity,
                    message=message,
                    contract=contract,
                    function=function,
                    job_url=job_url,
                    raw_data=alert,
                )
            )

        return issues
