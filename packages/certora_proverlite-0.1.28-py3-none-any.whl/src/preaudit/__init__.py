#!/usr/bin/env python3
"""
End-to-end PreAudit runner.

Phases:
  1. Set up the project scene (clone or cd into the target directory).
  2. Run the orchestrator to generate verification configs and execute formal verification.
  3. Run the aggregated report generator to produce Markdown + HTML reports.

Usage:
    # Run from the project directory (simplest)
    python -m src.preaudit src/Token.sol

    # With contract name specified
    python -m src.preaudit src/Vault.sol:Vault

    # With explicit project directory
    python -m src.preaudit src/Token.sol --project-dir /path/to/project

    # From a GitHub repo URL
    python -m src.preaudit src/Token.sol --project-dir git@github.com:org/repo.git
"""

# --- Vendored dependency bootstrap (injected by build_wheel.py) ---
import sys as _sys
from pathlib import Path as _Path
_VENDOR_DIR = _Path(__file__).resolve().parent.parent.parent / "_vendor"
if _VENDOR_DIR.is_dir():
    _sys.path.insert(0, str(_VENDOR_DIR))
del _sys, _Path, _VENDOR_DIR
# --- End vendor bootstrap ---

import argparse
import json
import logging
import os
import shlex
import shutil
import subprocess
import sys
import warnings
from pathlib import Path

# Silence deprecation warnings from transitive dependencies (e.g. langchain verbose import)
warnings.filterwarnings("ignore", message=".*Importing.*from langchain root module.*", category=UserWarning)

# Ensure project root is on sys.path so `src.*` imports work.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("ANONYMIZED_TELEMETRY", "False")

from certora_login import login  # type: ignore[import-untyped]
from prover_output_utility import ProverOutputAPI  # type: ignore[import-untyped]

from src.utils.logger import logger as _singleton_logger
from src.utils.progress_display import CollectingSignalsProgress


def _setup_logging() -> logging.Logger:
    log_dir = Path(".certora_internal")
    log_dir.mkdir(exist_ok=True)

    logger = logging.getLogger("preaudit")
    logger.setLevel(logging.INFO)
    logger.propagate = False  # Prevent duplicate messages from parent loggers
    logger.handlers.clear()

    # File handler
    file_handler = logging.FileHandler(log_dir / "preaudit.log", mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
    logger.addHandler(file_handler)

    # Console handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("anthropic").setLevel(logging.WARNING)
    logging.getLogger("claude_agent_sdk").setLevel(logging.WARNING)
    logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
    logging.getLogger("transformers_modules").setLevel(logging.ERROR)
    logging.getLogger("transformers").setLevel(logging.ERROR)
    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
    os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
    os.environ["TRANSFORMERS_VERBOSITY"] = "error"

    return logger


def _is_git_url(target: str) -> bool:
    """Return True if *target* looks like a git remote URL."""
    return (
        target.startswith("git@")
        or target.startswith("https://github.com")
        or target.startswith("ssh://")
        or target.endswith(".git")
    )


def _clone_repo(url: str, logger: logging.Logger) -> Path:
    """Clone *url* via SSH and return the path to the cloned directory."""
    # Derive a directory name from the URL.
    repo_name = url.rstrip("/").split("/")[-1].removesuffix(".git")
    dest = Path.cwd() / repo_name
    if dest.exists():
        logger.info("Directory %s already exists — assuming previous clone, reusing it.", dest)
        return dest
    logger.info("Cloning %s …", url)
    result = subprocess.run(["git", "clone", url, str(dest)], capture_output=True, text=True)
    if result.stdout or result.stderr:
        logger.debug("%s", (result.stdout or "") + (result.stderr or ""))
    result.check_returncode()
    return dest


def _find_git_root(project_dir: Path) -> Path | None:
    """Return the git repository root for *project_dir*, or None if not in a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=str(project_dir),
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _run_js_install(install_dir: Path, logger: logging.Logger) -> bool:
    """Attempt to install JS dependencies in *install_dir*. Return True on success."""
    if (install_dir / "bun.lockb").exists() or (install_dir / "bun.lock").exists():
        cmd = ["bun", "install", "--frozen-lockfile"]
        label = "bun install --frozen-lockfile"
    elif (install_dir / "yarn.lock").exists():
        cmd = ["yarn", "install", "--frozen-lockfile"]
        label = "yarn install --frozen-lockfile"
    elif (install_dir / "package-lock.json").exists():
        cmd = ["npm", "ci"]
        label = "npm ci"
    else:
        cmd = ["npm", "install"]
        label = "npm install"

    logger.info("Running %s in %s …", label, install_dir)
    result = subprocess.run(cmd, cwd=str(install_dir), capture_output=True, text=True)
    if result.stdout or result.stderr:
        logger.debug("%s", (result.stdout or "") + (result.stderr or ""))
    if result.returncode != 0:
        logger.warning(
            "%s failed in %s (exit code %d) — continuing without JS deps.", label, install_dir, result.returncode
        )
        return False
    return True


# ---------------------------------------------------------------------------
# Phase 2 — Run Orchestrator
# ---------------------------------------------------------------------------

_ORCHESTRATOR_EXTRA_ARGS = (
    "--optimistic_loop --optimistic_hashing --auto_dispatcher --build_cache "
    "--optimistic_summary_recursion --summary_recursion_limit 1 "
    "--optimistic_fallback --optimistic_contract_recursion "
    "--contract_recursion_limit 1 --server prover"
)


def _install_js_deps(project_dir: Path, logger: logging.Logger) -> None:
    """Install JS/TS dependencies, trying the git repo root first for monorepo support."""
    git_root = _find_git_root(project_dir)
    dirs_to_try: list[Path] = []

    # If project_dir is inside a larger git repo, try the repo root first.
    if git_root is not None and git_root != project_dir:
        dirs_to_try.append(git_root)
    dirs_to_try.append(project_dir)

    for d in dirs_to_try:
        if not (d / "package.json").exists():
            continue
        if (d / "node_modules").exists():
            logger.info("node_modules/ already exists in %s — skipping JS dependency install.", d)
            continue
        _run_js_install(d, logger)


def _deduplicate_by_contract_name(contract_handles: list, logger: logging.Logger) -> list:
    """Deduplicate contract handles by contract name, keeping shortest path.

    When multiple files declare the same contract name, keep only the file with
    the shortest path.

    Args:
        contract_handles: List of ContractHandle objects
        logger: Logger instance

    Returns:
        Deduplicated list of ContractHandle objects
    """
    by_contract_name: dict[str, list] = {}
    for ch in contract_handles:
        by_contract_name.setdefault(ch.contract_name, []).append(ch)

    final_handles = []
    dropped_duplicates = []
    for contract_name, handles in by_contract_name.items():
        if len(handles) > 1:
            # Sort by path length, keep shortest
            handles.sort(key=lambda h: len(h.source_file))
            kept = handles[0]
            dropped = handles[1:]
            dropped_duplicates.extend(dropped)
            logger.warning(
                "Relaxed mode: contract '%s' declared in %d files. Keeping %s, dropping: %s",
                contract_name, len(handles), kept.source_file,
                ", ".join(h.source_file for h in dropped)
            )
            final_handles.append(kept)
        else:
            final_handles.append(handles[0])

    if dropped_duplicates:
        logger.info("Dropped %d duplicate contract declaration(s) in relaxed mode.", len(dropped_duplicates))

    return final_handles


def _extract_contracts_relaxed(logger: logging.Logger) -> list:
    """Extract contracts in 'relaxed' mode, dropping ambiguous/duplicate contracts.

    Preaudit's goal is to make as much progress as possible, so when encountering:
    - Files with multiple contracts where auto-resolution fails: drop them with a warning
    - Multiple files defining the same contract name: keep the shortest path, drop others

    Returns:
        List of ContractHandle objects
    """
    from pathlib import Path
    import os
    from src.parsers.build_system_detector import BuildSystemDetector
    from src.setup.solidity_utils import find_all_solidity_files
    from src.utils.types import ContractHandle

    # Detect build system and get appropriate extractor instance
    build_system = BuildSystemDetector.detect(Path.cwd())
    contract_extractor = BuildSystemDetector.get_contract_extractor(build_system, Path.cwd())

    # First try the standard extraction with auto_resolve_ambiguous=True
    try:
        contract_handles = contract_extractor.extract_logic_contracts_and_files([], auto_resolve_ambiguous=True)
        # Always deduplicate by contract name (handles same contract in multiple files)
        contract_handles = _deduplicate_by_contract_name(contract_handles, logger)
        if not contract_handles:
            raise Exception("No contracts remaining after deduplication")
        logger.info("Relaxed mode: proceeding with %d contract(s).", len(contract_handles))
        return contract_handles
    except Exception as e:
        logger.warning("Standard contract extraction failed: %s", e)
        logger.info("Falling back to relaxed mode — dropping problematic contracts to make progress.")

    # Fallback: manually build the list, skipping problematic files
    logic_contracts = contract_extractor.extract_logic_contracts()
    if not logic_contracts:
        raise Exception(f"No logic contracts found in {build_system.value} build output")

    all_solidity_files = find_all_solidity_files(
        include_test_files=False,
        include_dependencies=False,
        verbose=False
    )
    all_solidity_files = sorted(all_solidity_files)

    contract_handles = []
    dropped_ambiguous = []
    for sol_file in all_solidity_files:
        basename = Path(sol_file).stem
        if basename not in logic_contracts:
            continue

        relative_path = os.path.relpath(sol_file, Path.cwd())
        contract_names = logic_contracts[basename]

        if len(contract_names) > 1:
            # Try auto-resolve: if contract name matches filename exactly
            if basename in contract_names:
                logger.info(
                    "Relaxed mode: auto-resolved %s to contract '%s' (other contracts in file: %s)",
                    relative_path, basename, ", ".join(c for c in contract_names if c != basename)
                )
                contract_handles.append(ContractHandle(contract_name=basename, source_file=relative_path))
            else:
                # Cannot resolve — drop this file
                dropped_ambiguous.append((relative_path, contract_names))
                logger.warning(
                    "Relaxed mode: dropping %s — multiple contracts (%s) and none match filename",
                    relative_path, ", ".join(contract_names)
                )
        else:
            contract_handles.append(ContractHandle(contract_name=contract_names[0], source_file=relative_path))

    if dropped_ambiguous:
        logger.info("Dropped %d ambiguous file(s) in relaxed mode.", len(dropped_ambiguous))

    # Deduplicate by contract name (same contract declared in multiple files)
    contract_handles = _deduplicate_by_contract_name(contract_handles, logger)

    if not contract_handles:
        raise Exception("No contracts remaining after relaxed-mode filtering")

    logger.info("Relaxed mode: proceeding with %d contract(s).", len(contract_handles))
    return contract_handles


def _ensure_foundry_build(project_dir: Path, logger: logging.Logger) -> None:
    """Install all dependencies (JS + Foundry) and compile the project."""
    # JS/TS dependencies first (needed by some Foundry projects for remappings)
    _install_js_deps(project_dir, logger)

    # Install Foundry dependencies
    if (project_dir / "lib").exists():
        logger.info("Foundry lib/ directory exists — skipping forge install.")
    else:
        logger.info("Running forge install …")
        result = subprocess.run(["forge", "install"], cwd=str(project_dir), capture_output=True, text=True)
        if result.stdout or result.stderr:
            logger.debug("%s", (result.stdout or "") + (result.stderr or ""))
        result.check_returncode()

    # Build the project
    logger.info("Running forge build …")
    result = subprocess.run(["forge", "build"], cwd=str(project_dir), capture_output=True, text=True)
    if result.stdout or result.stderr:
        logger.debug("%s", (result.stdout or "") + (result.stderr or ""))
    result.check_returncode()


_SKIP_SUBDIRS = {"node_modules", ".git", "lib", "out", "cache", "artifacts"}


def _find_foundry_subdir(project_dir: Path, contract_files: list[str], logger: logging.Logger) -> Path | None:
    """Search immediate subdirectories of *project_dir* for a foundry.toml.

    Only called when *project_dir* itself does NOT contain foundry.toml.
    If multiple subdirs qualify, prefer the one whose name matches the first
    path component of the first contract file.
    """
    candidates: list[Path] = []
    for child in sorted(project_dir.iterdir()):
        if not child.is_dir() or child.name in _SKIP_SUBDIRS or child.name.startswith("."):
            continue
        if (child / "foundry.toml").exists():
            candidates.append(child)

    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    # Prefer candidate matching the first path component of the contract file
    first_file = contract_files[0].split(":")[0] if contract_files else ""
    first_component = Path(first_file).parts[0] if first_file else ""
    for c in candidates:
        if c.name == first_component:
            logger.info(
                "Multiple foundry.toml subdirs found (%s); selected '%s' (matches contract path).",
                ", ".join(c2.name for c2 in candidates),
                c.name,
            )
            return c

    return candidates[0]


def _strip_subdir_prefix(file_spec: str, subdir_name: str) -> str:
    """Strip a leading subdirectory component from a contract file spec.

    'contracts/src/Foo.sol:Bar' with subdir_name='contracts' -> 'src/Foo.sol:Bar'
    """
    if ":" in file_spec:
        file_path, suffix = file_spec.split(":", 1)
        suffix = ":" + suffix
    else:
        file_path, suffix = file_spec, ""

    parts = Path(file_path).parts
    if parts and parts[0] == subdir_name:
        file_path = str(Path(*parts[1:]))

    return file_path + suffix


def _run_orchestrator(
    project_dir: Path,
    files: list[str],
    logger: logging.Logger,
    certora_run_command: str = "certoraRun",
    prover_version: str | None = None,
    enable_autocvl: bool = True,
    autocvl_iterative: bool = False,
    autocvl_max_iterations: int = 3,
) -> tuple[Path | None, str]:
    """Run the orchestrator programmatically and return the path to the results JSON and contract name."""
    from src.orchestrator import CertoraOrchestrator
    from src.parsers.orchestrator_argparse import parse_contract_files
    from src.setup.setup_prover import SetupProver
    from src.utils.cloud_runner import CloudProverRunner

    import atexit
    import signal

    original_dir = Path.cwd()
    os.chdir(project_dir)

    try:
        # --- Phase 1: Setup (build/install) ---
        logger.info("\n[Phase 1: Setup]")
        if (project_dir / "foundry.toml").exists():
            _ensure_foundry_build(project_dir, logger)
        else:
            # Monorepo fallback: look for foundry.toml in immediate subdirectories
            foundry_subdir = _find_foundry_subdir(project_dir, files, logger)
            if foundry_subdir is not None:
                logger.info(
                    "Found Foundry project in subdirectory '%s' — building there.",
                    foundry_subdir.name,
                )
                _ensure_foundry_build(foundry_subdir, logger)
                files = [_strip_subdir_prefix(f, foundry_subdir.name) for f in files]
                os.chdir(foundry_subdir)

        # Parse contract files (required)
        contract_handles = parse_contract_files(files)
        if not contract_handles:
            logger.error("Failed to parse contract file")
            sys.exit(1)

        extra_args = shlex.split(_ORCHESTRATOR_EXTRA_ARGS)
        if prover_version:
            extra_args.extend(["--prover_version", prover_version])

        generator_config_base = {
            "enable_extcall": True,
            "extcall_mode": "default",
            "extcall_check_non_zero": False,
            "enable_privileged": True,
            "extra_args": extra_args,
            "additional_contracts": [],
        }

        orchestrator = CertoraOrchestrator(
            verbose=1,
            generator_config=generator_config_base,
            use_cache=True,
            require_all_submissions=False,  # --allow-submission-failures
            retry_difficult=True,  # --retry-difficult
            certora_run_command=certora_run_command,
            enable_autocvl=enable_autocvl,
            autocvl_iterative=autocvl_iterative,
            autocvl_max_iterations=autocvl_max_iterations,
        )

        orchestrator.ensure_git_config_files()

        orchestrator.execution_info = {
            "command_line": sys.argv,
            "parsed_args": {
                "extra_args": _ORCHESTRATOR_EXTRA_ARGS,
                "verbose": 1,
                "allow_submission_failures": True,
                "retry_difficult": True,
                "enable_autocvl": enable_autocvl,
                "autocvl_iterative": autocvl_iterative,
                "autocvl_max_iterations": autocvl_max_iterations,
            },
            "files": [ch.source_file for ch in contract_handles],
            "contract_names": [ch.contract_name for ch in contract_handles],
        }

        setup_prover = SetupProver(
            log=orchestrator.log,
            certora_dir=orchestrator.certora_dir,
            script_dir=orchestrator.script_dir,
            additional_contracts=orchestrator.additional_contracts,
            extra_args=orchestrator.extra_args,
            skip_llm=False,
            force_llm_regenerate=False,
            stop_after_summaries=False,
            scope=orchestrator.scope,
            verbose=orchestrator.verbose,
            certora_run_command=certora_run_command,
            contract_names=[ch.contract_name for ch in contract_handles],
            get_build_system_config_dict=orchestrator.get_build_system_config_dict,
        )
        orchestrator.setup_prover_instance = setup_prover

        # Signal handling for graceful cleanup
        from src.orchestrator import signal_handler
        import src.orchestrator as _orch_module
        _orch_module._orchestrator_instance = orchestrator
        signal.signal(signal.SIGINT, signal_handler)
        def _muted_cleanup():
            _singleton_logger.muted = True
            orchestrator.cleanup_running_jobs()

        atexit.register(_muted_cleanup)

        orchestrator.contract_handles.extend(contract_handles)
        orchestrator.main_contract_handle = contract_handles[0]

        # --- Phase 2: Collecting signals ---
        logger.info("\n[Phase 2: Collecting signals]")

        # Mute orchestrator's verbose logging (still goes to orchestrator.log file)
        _singleton_logger.muted = True

        # Set up progress spinner
        time_budget = CloudProverRunner.JOB_TIMEOUT_SECONDS * 3
        progress = CollectingSignalsProgress(
            time_budget,
            get_active_count=lambda: getattr(orchestrator.prover_runner, "active_jobs_count", 0),
            get_completed_count=lambda: getattr(orchestrator.prover_runner, "completed_jobs_count", 0),
        )
        _orch_module._progress_display = progress

        progress.start()
        try:
            success = orchestrator.run_orchestration(skip_warmup=False)
        finally:
            progress.stop(show_100=True)
            _singleton_logger.muted = False
            _orch_module._progress_display = None

        if orchestrator.results_json_path and orchestrator.results_json_path.exists():
            results_path = orchestrator.results_json_path
        else:
            # Fallback: look for the file in the reports dir
            results_path = orchestrator.reports_dir / "orchestrator_results.json"

        # Extract main contract name
        main_contract_name = contract_handles[0].contract_name if contract_handles else "Unknown"

        if not results_path.exists():
            logger.info("Could not collect signals by running the Certora Prover")
            return None, main_contract_name

        return results_path.resolve(), main_contract_name

    finally:
        os.chdir(original_dir)


# ---------------------------------------------------------------------------
# Phase 3 — Run Aggregated Report
# ---------------------------------------------------------------------------

def _run_aggregate_report(
    results_json: Path,
    project_dir: Path,
    logger: logging.Logger,
    iterations: int = 3,
    contract_name: str = "",
    ignore_calltrace_errors: bool = False,
    rag_db: str | None = None,
) -> Path | None:
    """Run the aggregated report generator and produce Markdown + HTML.

    Returns the absolute path to the HTML report, or None if no report was generated.
    """
    from src.preaudit.run_aggregate_report import (
        extract_jobs_from_orchestrator,
        run_checker_report_aggregate,
        setup_logging as setup_report_logging,
        _generate_html_report,
    )
    from src.generic_checkers.reporting.__main__ import AggregatedReportJSON

    report_logger = setup_report_logging()

    orch_jobs = extract_jobs_from_orchestrator(results_json)
    if not orch_jobs.jobs:
        logger.info("No jobs with violations found — nothing to aggregate.")
        return None

    job_urls = orch_jobs.job_urls

    # If results_json is already inside a .CertoraProverLiteReports dir (normal orchestrator flow),
    # write reports alongside it. Otherwise, create a timestamped subdirectory.
    if ".CertoraProverLiteReports" in results_json.parent.parts:
        reports_dir = results_json.parent
    else:
        from datetime import datetime

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        reports_dir = results_json.parent / ".CertoraProverLiteReports" / timestamp
        reports_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(results_json, reports_dir / results_json.name)

    output_file = reports_dir / "aggregated_findings_report.md"

    # Mute verbose logging — only tqdm progress bars should appear on console
    _singleton_logger.muted = True
    for handler in report_logger.handlers:
        if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
            handler.setLevel(logging.CRITICAL)

    try:
        success = run_checker_report_aggregate(
            job_urls=job_urls,
            output_file=output_file,
            logger=report_logger,
            multi_analysis=True,
            iterations=iterations,
            ignore_calltrace_errors=ignore_calltrace_errors,
            project_dir=str(project_dir),
            rag_db=rag_db,
            autocvl_job_urls=orch_jobs.autocvl_job_urls,
        )
    finally:
        _singleton_logger.muted = False
        for handler in report_logger.handlers:
            if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
                handler.setLevel(logging.INFO)

    if not success:
        logger.error("Aggregated report generation failed.")
        sys.exit(1)

    # Generate HTML report
    html_path: Path | None = None
    json_output = output_file.with_suffix(".json")
    if json_output.exists():
        report = AggregatedReportJSON.model_validate_json(json_output.read_text())

        # Build a minimal args namespace for _generate_html_report
        html_args = argparse.Namespace(
            project_dir=str(project_dir),
            contract_name=contract_name,
            results_json_stem=results_json.stem,
        )
        html_path = _generate_html_report(report, html_args, output_file, report_logger)
    else:
        logger.warning("JSON report not found at %s — skipping HTML generation.", json_output)

    return html_path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="ProverLite: Automated Smart Contract Security Analysis Powered by Formal Verification"
    )
    parser.add_argument(
        "contract",
        nargs="?",
        default=None,
        help="Contract file to verify. Format: src/Token.sol or src/Token.sol:ContractName. "
             "Required unless --skip-orchestrator is used.",
    )
    # --- Internal options (hidden from --help) ---
    # Number of AI analysis iterations per rule (default: 3)
    parser.add_argument("--iterations", type=int, default=3, help=argparse.SUPPRESS)
    # Command to use for running Certora verification (default: certoraRun)
    parser.add_argument("--certora-run-command", default="certoraRun", help=argparse.SUPPRESS)
    # Prover version to use (e.g. master, latest). If not specified, uses cloud default.
    parser.add_argument("--prover-version", "--prover_version", dest="prover_version", default=None, help=argparse.SUPPRESS)
    # Skip orchestrator and use existing results JSON file for report generation
    parser.add_argument("--skip-orchestrator", metavar="RESULTS_JSON", help=argparse.SUPPRESS)
    # Abort on calltrace source location extraction failures (default: skip gracefully)
    parser.add_argument("--strict-calltrace-errors", action="store_true", help=argparse.SUPPRESS)
    # Project directory or GitHub repo URL (git@ or https://). Defaults to current directory.
    parser.add_argument("--project-dir", default=".", help=argparse.SUPPRESS)
    # RAG database path (ChromaDB directory) or PostgreSQL connection string.
    parser.add_argument("--rag-db", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not args.skip_orchestrator and not args.contract:
        parser.error("contract argument is required unless --skip-orchestrator is used")

    missing = [v for v in ("CERTORAKEY", "ANTHROPIC_API_KEY") if not os.environ.get(v)]
    if missing:
        sys.exit(f"Error: required environment variable(s) not set: {', '.join(missing)}")

    # Authenticate with Certora
    try:
        login(env="prod", force_file=True)
        api = ProverOutputAPI()
        user_info = api.who_am_i()
        print(f"Authenticated as: {user_info.get('email', user_info.get('user', 'unknown'))}")
    except Exception as e:
        sys.exit(f"Certora authentication failed: {e}\nPlease sign up or log in at https://certora.com")

    logger = _setup_logging()
    logger.info("ProverLite — end-to-end runner")

    # --- Phase 1: Set up the project scene ---
    target = args.project_dir
    if _is_git_url(target):
        project_dir = _clone_repo(target, logger)
    else:
        project_dir = Path(target).resolve()
        if not project_dir.is_dir():
            logger.error("Target directory does not exist: %s", project_dir)
            sys.exit(1)

    logger.info("Project directory: %s", project_dir)

    # --- Phase 2: Run the Orchestrator (or skip if --skip-orchestrator) ---
    contract_name = ""  # Will be populated from orchestrator or inferred from results JSON
    if args.skip_orchestrator:
        results_json = Path(args.skip_orchestrator).resolve()
        if not results_json.exists():
            logger.error("Results JSON not found: %s", results_json)
            sys.exit(1)
        logger.info("Skipping orchestrator — using existing results: %s", results_json)
        # Infer contract name(s) from the results JSON
        with open(results_json) as f:
            results_data = json.load(f)
        contract_names = results_data.get("execution_info", {}).get("contract_names", [])
        contract_name = ", ".join(contract_names) if contract_names else ""
    else:
        results_json, contract_name = _run_orchestrator(
            project_dir, [args.contract], logger, args.certora_run_command, args.prover_version
        )

    if contract_name:
        sStr = "s" if "," in contract_name else ""
        logger.info("Contract%s: %s", sStr, contract_name)

    # --- Phase 3: Signal Analysis ---
    html_path = None
    if results_json is not None:
        logger.info("\n[Phase 3: Signal analysis]")
        html_path = _run_aggregate_report(
            results_json, project_dir, logger,
            iterations=args.iterations, contract_name=contract_name,
            ignore_calltrace_errors=not args.strict_calltrace_errors,
            rag_db=args.rag_db,
        )

    # --- Telemetry ---
    from src.telemetry import upload_telemetry
    upload_telemetry(project_dir, args, results_json, html_path)

    # --- Done ---
    logger.info("\nProverLite complete.")
    if html_path:
        logger.info("Report: %s", html_path)


if __name__ == "__main__":
    main()
