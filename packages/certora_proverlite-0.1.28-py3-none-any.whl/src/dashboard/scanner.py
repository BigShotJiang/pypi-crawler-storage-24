"""
Main project scanner for collecting conf, spec, and rule information.

Orchestrates the scanning process by:
1. Finding all conf files
2. Extracting spec files from confs
3. Building spec dependency graphs
4. Parsing rules from specs
5. Saving scan snapshots
"""

import json5
import time
from pathlib import Path
from typing import Dict, Optional

from src.dashboard.ast_manager import generate_local_asts_for_snapshot
from src.dashboard.cloud_sync import update_statuses_from_cloud
from src.dashboard.conf_parser import extract_main_spec, filter_rules, find_conf_files, identify_conf_type, parse_rule_filters
from src.dashboard.models import ConfInfo, RuleStatus, ScanSnapshot, SpecInfo
from src.dashboard.move_parser import find_move_spec_files, parse_cvlm_manifest
from src.dashboard.rust_parser import find_rust_spec_files, parse_rust_rules
from src.dashboard.progress_tracker import ScanProgress, save_scan_progress, clear_scan_progress
from src.dashboard.spec_diff_manager import compute_all_spec_diffs
from src.dashboard.spec_parser import (
    build_spec_dependency_graph,
    extract_rules_from_spec,
)
from src.dashboard.storage import (
    collect_files_by_extension,
    compare_scan_results,
    compute_file_hash,
    load_all_rule_statuses,
    load_latest_scan,
    load_rule_statuses,
    load_user_run_selections,
    save_rule_statuses,
    save_scan_snapshot,
)
from src.dashboard.logger import dashboard_logger as logger


class ProjectScanner:
    """
    Main scanner class for collecting project information.

    Scans the project directory for conf files, spec files, and rules,
    and stores the results in timestamped snapshots.
    """

    def __init__(self, cwd: Path, verbose: bool = False):
        """
        Initialize the project scanner.

        Args:
            cwd: Current working directory (project root)
            verbose: Enable verbose logging
        """
        self.cwd = cwd
        self.verbose = verbose
        self.certora_dir = cwd / "certora"
        self.dashboard_dir = cwd / ".certora_internal" / "local_dashboard"

    def log(self, message: str, level: str = "INFO"):
        """Log messages using centralized logger."""
        logger.log(message, level, "ProjectScanner")

    def scan_project(self) -> ScanSnapshot:
        """
        Perform a complete scan of the project.

        Steps:
        1. Find all conf files in certora/ subdirectory
        2. For each conf:
           a. Extract main spec file
           b. Build spec dependency graph
           c. Compute hashes for all specs
           d. Parse rules from all specs
        3. Create ScanSnapshot with all collected data
        4. Save snapshot to disk

        Returns:
            ScanSnapshot with all collected information

        Raises:
            Exception if scan fails
        """
        start_time = time.time()
        timestamp = int(start_time)

        self.log("Starting project scan...")

        # Find all conf files in certora/
        conf_files = find_conf_files(self.certora_dir)

        # For Rust/Solana projects, also check additional paths
        if (self.cwd / "Cargo.toml").exists():
            # Check src/certora/
            src_certora_dir = self.cwd / "src" / "certora"
            rust_conf_files = find_conf_files(src_certora_dir)
            if rust_conf_files:
                self.log(f"Found {len(rust_conf_files)} conf files in src/certora/ (Rust project)", "INFO")
                conf_files.extend(rust_conf_files)

            # Check programs/*/src/certora/ (common Solana/Anchor structure)
            programs_dir = self.cwd / "programs"
            if programs_dir.exists():
                for program_dir in programs_dir.iterdir():
                    if program_dir.is_dir():
                        program_certora_dir = program_dir / "src" / "certora"
                        program_conf_files = find_conf_files(program_certora_dir)
                        if program_conf_files:
                            self.log(f"Found {len(program_conf_files)} conf files in {program_certora_dir.relative_to(self.cwd)} (Rust/Solana)", "INFO")
                            conf_files.extend(program_conf_files)

        if not conf_files:
            self.log("No conf files found in certora/ or src/certora/ directories", "WARNING")

        # Initialize progress tracking
        scan_progress = ScanProgress(
            phase="scanning",
            total_items=len(conf_files),
            processed_items=0,
            current_item=None,
            status="running",
            start_time=start_time
        )
        save_scan_progress(self.dashboard_dir, scan_progress)

        # Track all specs we've seen (to avoid duplicate processing)
        all_specs: dict = {}  # Path -> SpecInfo

        # Track confs
        confs = []

        # Process each conf file
        for idx, conf_path in enumerate(conf_files):
            # Update progress
            scan_progress.processed_items = idx
            scan_progress.current_item = conf_path.name
            save_scan_progress(self.dashboard_dir, scan_progress)
            self.log(f"Processing conf: {conf_path.name}")

            # Identify conf type
            conf_type = identify_conf_type(conf_path, self.cwd)

            # Route to appropriate processor
            conf_info = None
            if conf_type == "EVM":
                conf_info = self._process_evm_conf(conf_path, all_specs)
            elif conf_type == "Move":
                conf_info = self._process_move_conf(conf_path, all_specs)
            elif conf_type == "Rust":
                conf_info = self._process_rust_conf(conf_path, all_specs)
            else:
                self.log(f"Skipping conf {conf_path.name} - unknown type", "WARNING")
                continue

            # Add to confs list if processing succeeded
            if conf_info:
                confs.append(conf_info)

        # Check if scan results have changed compared to previous scan
        previous_snapshot = load_latest_scan(self.dashboard_dir)
        if previous_snapshot and compare_scan_results(all_specs, confs, previous_snapshot):
            # Scan results unchanged - reuse existing snapshot
            self.log("Scan results unchanged, reusing existing snapshot", "INFO")

            # Mark scan as completed immediately
            scan_progress.phase = "completed"
            scan_progress.status = "completed"
            save_scan_progress(self.dashboard_dir, scan_progress)

            elapsed = time.time() - start_time
            self.log(
                f"Scan complete in {elapsed:.2f}s (unchanged) - "
                f"Found {len(confs)} confs, {len(all_specs)} specs"
            )

            return previous_snapshot

        # Collect source file hashes for caching
        self.log("Collecting source file hashes for caching...")
        source_file_hashes = self._collect_source_file_hashes(confs)
        self.log(f"Collected hashes for {len(source_file_hashes)} source files")

        # Create snapshot with new timestamp
        snapshot = ScanSnapshot(
            timestamp=timestamp,
            confs=confs,
            specs=all_specs
        )

        # Save snapshot with source file hashes
        save_scan_snapshot(snapshot, self.dashboard_dir, source_file_hashes=source_file_hashes)

        # Filter EVM confs for AST generation (skip Move confs)
        evm_confs = [conf for conf in snapshot.confs if conf.conf_type == "EVM"]

        if evm_confs:
            # Update progress for AST generation phase
            scan_progress.phase = "generating_asts"
            scan_progress.total_items = len(evm_confs)
            scan_progress.processed_items = 0
            scan_progress.current_item = None
            save_scan_progress(self.dashboard_dir, scan_progress)

            # Generate local ASTs for EVM conf files only
            self.log(f"Generating local ASTs for {len(evm_confs)} EVM conf files...")
            try:
                # Create a temporary snapshot with only EVM confs for AST generation
                evm_snapshot = ScanSnapshot(
                    timestamp=timestamp,
                    confs=evm_confs,
                    specs=all_specs
                )

                # Define progress callback
                def ast_progress_callback(processed: int, successful: int, conf_name: str):
                    scan_progress.processed_items = processed
                    scan_progress.successful_items = successful
                    scan_progress.current_item = conf_name
                    save_scan_progress(self.dashboard_dir, scan_progress)

                generate_local_asts_for_snapshot(evm_snapshot, self.cwd, timestamp, progress_callback=ast_progress_callback)
                self.log("Local ASTs generated successfully", "SUCCESS")
            except Exception as e:
                self.log(f"Error generating local ASTs: {e}", "ERROR")
        else:
            self.log("No EVM confs found, skipping AST generation", "INFO")

        # If we have existing rule statuses, compute spec diffs
        # Note: Move confs will be gracefully skipped during diff computation since they have no ASTs
        existing_statuses = load_rule_statuses(self.dashboard_dir, mode="local")
        if existing_statuses:
            # Update progress for spec diff computation
            scan_progress.phase = "computing_diffs"
            scan_progress.total_items = len(existing_statuses)
            scan_progress.processed_items = 0
            scan_progress.current_item = None
            save_scan_progress(self.dashboard_dir, scan_progress)

            self.log(f"Computing spec diffs for {len(existing_statuses)} rules...")
            try:
                timestamp_dir = self.dashboard_dir / str(timestamp)

                # Define progress callback
                def diff_progress_callback(processed: int, rule_name: str):
                    scan_progress.processed_items = processed
                    scan_progress.current_item = rule_name
                    save_scan_progress(self.dashboard_dir, scan_progress)

                spec_diffs = compute_all_spec_diffs(
                    snapshot,
                    existing_statuses,
                    timestamp_dir,
                    self.cwd,
                    progress_callback=diff_progress_callback
                )

                # Update statuses with diff info
                for rule_name, status in existing_statuses.items():
                    if rule_name in spec_diffs:
                        diff_info = spec_diffs[rule_name]
                        status.spec_diff_equivalent = diff_info.get("equivalent")
                        status.has_ambiguous_conf = diff_info.get("has_ambiguous_conf", False)
                        status.matched_main_contract = diff_info.get("matched_main_contract", "")
                        status.conf_path = diff_info.get("conf_path")

                # Save updated statuses
                save_rule_statuses(existing_statuses, self.dashboard_dir, mode="local")
                self.log("Spec diffs computed and statuses updated", "SUCCESS")
            except Exception as e:
                self.log(f"Error computing spec diffs: {e}", "ERROR")

        # Mark scan as completed
        scan_progress.phase = "completed"
        scan_progress.status = "completed"
        save_scan_progress(self.dashboard_dir, scan_progress)

        # Clear progress after a short delay (so UI can show completion)
        # Note: The UI will clear it when it detects completed status

        elapsed = time.time() - start_time
        self.log(
            f"Scan complete in {elapsed:.2f}s - "
            f"Found {len(confs)} confs, {len(all_specs)} specs"
        )

        return snapshot

    def _process_evm_conf(
        self, conf_path: Path, all_specs: Dict[Path, SpecInfo]
    ) -> Optional[ConfInfo]:
        """
        Process an EVM (Solidity/Vyper) conf file.

        Args:
            conf_path: Path to the conf file
            all_specs: Dictionary to populate with discovered specs

        Returns:
            ConfInfo for this conf, or None if processing failed
        """
        # Extract main spec and main contract
        main_spec = extract_main_spec(conf_path, self.cwd)
        if not main_spec:
            self.log(f"Skipping EVM conf {conf_path.name} - no valid spec found", "WARNING")
            return None

        # Extract main contract name from verify field
        main_contract = ""
        try:
            with conf_path.open("r") as cf:
                config_data = json5.load(cf)
                verify = config_data.get("verify", "")
                if ":" in verify:
                    main_contract = verify.split(":", 1)[0]
        except Exception as e:
            self.log(f"Error extracting main contract from {conf_path.name}: {e}", "WARNING")

        # Build spec dependency graph
        forward_graph, reverse_graph = build_spec_dependency_graph(main_spec)

        # Get all specs (main + transitively imported)
        all_spec_paths = {main_spec}
        all_spec_paths.update(forward_graph.keys())
        for imported_specs in forward_graph.values():
            all_spec_paths.update(imported_specs)

        # Process each spec if we haven't already
        for spec_path in all_spec_paths:
            if spec_path not in all_specs:
                # Compute hash
                try:
                    spec_hash = compute_file_hash(spec_path)
                except Exception as e:
                    self.log(f"Error hashing {spec_path}: {e}", "ERROR")
                    continue

                # Parse rules
                rules = extract_rules_from_spec(spec_path)

                # Get imported specs for this spec
                imported_specs = forward_graph.get(spec_path, [])

                # Create SpecInfo
                spec_info = SpecInfo(
                    path=spec_path,
                    hash=spec_hash,
                    rules=rules,
                    imported_specs=imported_specs
                )

                all_specs[spec_path] = spec_info

        # Collect all rule names from all specs for this conf
        rule_names = []
        for spec_path in all_spec_paths:
            if spec_path in all_specs:
                rule_names.extend([rule.name for rule in all_specs[spec_path].rules])

        # Apply rule filtering based on 'rule' and 'exclude_rule' conf options
        rule_patterns, exclude_patterns = parse_rule_filters(conf_path)
        rule_names = filter_rules(rule_names, rule_patterns, exclude_patterns)

        # Create ConfInfo
        conf_info = ConfInfo(
            conf_path=conf_path,
            main_spec=main_spec,
            all_specs=list(all_spec_paths),
            rules=rule_names,
            main_contract=main_contract,
            conf_type="EVM"
        )

        return conf_info

    def _process_move_conf(self, conf_path: Path, all_specs: Dict[Path, SpecInfo]) -> Optional[ConfInfo]:
        """
        Process a Move Prover conf file.

        Args:
            conf_path: Path to the conf file
            all_specs: Dictionary to populate with discovered specs

        Returns:
            ConfInfo for this conf, or None if processing failed
        """
        # Find all Move spec files in the conf directory
        conf_dir = conf_path.parent
        move_files = find_move_spec_files(conf_dir)

        if not move_files:
            self.log(f"No Move spec files found for {conf_path.name}", "WARNING")
            return None

        # Parse rules from all Move files
        all_rules = []
        all_move_specs = []

        for move_file in move_files:
            # Parse rules from this Move file
            rules = parse_cvlm_manifest(move_file)

            if rules:
                all_rules.extend(rules)
                all_move_specs.append(move_file)

                # Add SpecInfo to all_specs dict if not already present
                if move_file not in all_specs:
                    # Compute hash for this Move file
                    try:
                        move_hash = compute_file_hash(move_file)
                    except Exception as e:
                        self.log(f"Error hashing {move_file}: {e}", "ERROR")
                        continue

                    # Create SpecInfo for this Move file
                    # Move files don't import other specs like CVL, so imported_specs is empty
                    spec_info = SpecInfo(
                        path=move_file,
                        hash=move_hash,
                        rules=rules,  # Already parsed as RuleInfo objects
                        imported_specs=[]
                    )

                    # Add to all_specs dict so frontend can find it
                    all_specs[move_file] = spec_info

        # Get rule names
        rule_names = [rule.name for rule in all_rules]

        # Apply rule filtering based on 'rule' and 'exclude_rule' conf options
        rule_patterns, exclude_patterns = parse_rule_filters(conf_path)
        rule_names = filter_rules(rule_names, rule_patterns, exclude_patterns)

        # Create ConfInfo
        # For Move, main_spec is the first Move file with rules (or None if no rules)
        main_spec = all_move_specs[0] if all_move_specs else None

        conf_info = ConfInfo(
            conf_path=conf_path,
            main_spec=main_spec,
            all_specs=all_move_specs,
            rules=rule_names,
            main_contract="",  # Not applicable for Move
            conf_type="Move"
        )

        return conf_info

    def _process_rust_conf(self, conf_path: Path, all_specs: Dict[Path, SpecInfo]) -> Optional[ConfInfo]:
        """
        Process a Rust/Solana Prover conf file.

        Args:
            conf_path: Path to the conf file
            all_specs: Dictionary to populate with discovered specs

        Returns:
            ConfInfo for this conf, or None if processing failed
        """
        # Find project root by looking for Cargo.toml
        current = conf_path.parent
        project_root = None
        for _ in range(10):
            if (current / "Cargo.toml").exists():
                project_root = current
                break
            if current.parent == current:  # Reached filesystem root
                break
            current = current.parent

        if not project_root:
            self.log(f"No Cargo.toml found for {conf_path.name}", "WARNING")
            return None

        # Find all Rust spec files in src/certora
        rust_files = find_rust_spec_files(project_root)

        if not rust_files:
            self.log(f"No Rust spec files found for {conf_path.name}", "WARNING")
            return None

        # Parse rules from all Rust files
        all_rules = []
        all_rust_specs = []

        for rust_file in rust_files:
            # Parse rules from this Rust file
            rules = parse_rust_rules(rust_file)

            if rules:
                all_rules.extend(rules)
                all_rust_specs.append(rust_file)

                # Add SpecInfo to all_specs dict if not already present
                if rust_file not in all_specs:
                    # Compute hash for this Rust file
                    try:
                        rust_hash = compute_file_hash(rust_file)
                    except Exception as e:
                        self.log(f"Error hashing {rust_file}: {e}", "ERROR")
                        continue

                    # Create SpecInfo for this Rust file
                    # Rust files don't import other specs like CVL, so imported_specs is empty
                    spec_info = SpecInfo(
                        path=rust_file,
                        hash=rust_hash,
                        rules=rules,  # Already parsed as RuleInfo objects
                        imported_specs=[]
                    )

                    # Add to all_specs dict so frontend can find it
                    all_specs[rust_file] = spec_info

        # Get rule names
        rule_names = [rule.name for rule in all_rules]

        # Apply rule filtering based on 'rule' and 'exclude_rule' conf options
        rule_patterns, exclude_patterns = parse_rule_filters(conf_path)
        rule_names = filter_rules(rule_names, rule_patterns, exclude_patterns)

        # Create ConfInfo
        # For Rust, main_spec is the first Rust file with rules (or None if no rules)
        main_spec = all_rust_specs[0] if all_rust_specs else None

        conf_info = ConfInfo(
            conf_path=conf_path,
            main_spec=main_spec,
            all_specs=all_rust_specs,
            rules=rule_names,
            main_contract="",  # Not applicable for Rust
            conf_type="Rust"
        )

        return conf_info

    def get_latest_scan(self) -> Optional[ScanSnapshot]:
        """
        Load and return the latest scan snapshot.

        Returns:
            ScanSnapshot if available, None otherwise
        """
        return load_latest_scan(self.dashboard_dir)

    def check_scan_up_to_date(self) -> tuple[bool, list[Path], list[Path]]:
        """
        Check if the latest scan is still up-to-date with current spec files.

        Compares the hashes of current spec files with those in the latest scan.
        If any spec file has changed, identifies all affected specs (transitively)
        and all affected conf files.

        Returns:
            Tuple of (is_up_to_date, changed_specs, affected_confs):
            - is_up_to_date: True if all spec hashes match, False otherwise
            - changed_specs: List of spec file paths that have changed
            - affected_confs: List of conf file paths that are affected by changes

        If no scan exists, returns (False, [], [])
        """
        # Load latest scan
        snapshot = self.get_latest_scan()
        if not snapshot:
            self.log("No scan found to compare against", "WARNING")
            return (False, [], [])

        # Track changed specs
        changed_specs = []

        # Check each spec file in the snapshot
        for spec_path, spec_info in snapshot.specs.items():
            # Skip if file no longer exists
            if not spec_path.exists():
                self.log(f"Spec file no longer exists: {spec_path}", "WARNING")
                changed_specs.append(spec_path)
                continue

            # Compute current hash
            try:
                current_hash = compute_file_hash(spec_path)
                if current_hash != spec_info.hash:
                    self.log(f"Spec file changed: {spec_path.name}", "INFO")
                    changed_specs.append(spec_path)
            except Exception as e:
                self.log(f"Error hashing {spec_path}: {e}", "ERROR")
                changed_specs.append(spec_path)

        # If no changes, return early
        if not changed_specs:
            return (True, [], [])

        # Find all affected specs (transitively)
        affected_specs = self._get_affected_specs(changed_specs, snapshot)

        # Find all affected confs
        affected_confs = self._get_affected_confs(affected_specs, snapshot)

        self.log(
            f"Found {len(changed_specs)} changed specs, "
            f"{len(affected_specs)} affected specs, "
            f"{len(affected_confs)} affected confs"
        )

        return (False, changed_specs, affected_confs)

    def _get_affected_specs(
        self, changed_specs: list[Path], snapshot: ScanSnapshot
    ) -> list[Path]:
        """
        Find all specs that are affected by changed specs (transitively).

        A spec is affected if:
        1. It directly changed, OR
        2. It imports a changed/affected spec (transitively)

        Args:
            changed_specs: List of specs that have changed
            snapshot: The scan snapshot containing dependency information

        Returns:
            List of all affected spec paths (includes changed_specs)
        """
        # Build reverse dependency graph
        # reverse_graph[spec] = list of specs that import 'spec'
        reverse_graph: dict = {}
        for spec_path, spec_info in snapshot.specs.items():
            for imported_spec in spec_info.imported_specs:
                if imported_spec not in reverse_graph:
                    reverse_graph[imported_spec] = []
                reverse_graph[imported_spec].append(spec_path)

        # BFS to find all affected specs
        affected = set(changed_specs)
        queue = list(changed_specs)

        while queue:
            current_spec = queue.pop(0)

            # Find all specs that import this spec
            if current_spec in reverse_graph:
                for importing_spec in reverse_graph[current_spec]:
                    if importing_spec not in affected:
                        affected.add(importing_spec)
                        queue.append(importing_spec)

        return list(affected)

    def _get_affected_confs(
        self, affected_specs: list[Path], snapshot: ScanSnapshot
    ) -> list[Path]:
        """
        Find all conf files that use any of the affected specs.

        A conf is affected if any of its specs (main or imported) are affected.

        Args:
            affected_specs: List of affected spec paths
            snapshot: The scan snapshot containing conf information

        Returns:
            List of affected conf file paths
        """
        affected_specs_set = set(affected_specs)
        affected_confs = []

        for conf_info in snapshot.confs:
            # Check if any of the conf's specs are affected
            for spec_path in conf_info.all_specs:
                if spec_path in affected_specs_set:
                    affected_confs.append(conf_info.conf_path)
                    break  # No need to check other specs for this conf

        return affected_confs

    def sync_cloud_statuses(self, mode: str = "local") -> Dict[str, RuleStatus]:
        """
        Sync verification statuses from cloud runs.

        Fetches latest job results from .certora_recent_jobs.json (local mode)
        or .certora_remote_jobs.json (remote mode) and updates rule statuses.

        Args:
            mode: "local" for local runs or "remote" for all runs

        Returns:
            Dictionary of rule_name -> RuleStatus
        """
        self.log(f"Syncing statuses from cloud ({mode} mode)...", "INFO")

        # Load current snapshot
        snapshot = self.get_latest_scan()
        if not snapshot:
            self.log("No scan found - cannot sync cloud statuses", "WARNING")
            return {}

        self.log(f"Current snapshot has {len(snapshot.confs)} confs, {len(snapshot.specs)} specs", "INFO")

        # Update statuses from cloud
        self.log(f"Calling update_statuses_from_cloud ({mode} mode)", "INFO")
        statuses = update_statuses_from_cloud(
            snapshot,
            self.dashboard_dir,
            self.cwd,
            validate_specs=True,
            mode=mode
        )
        self.log(f"update_statuses_from_cloud returned {len(statuses)} statuses", "INFO")

        # Save statuses
        if statuses:
            self.log(f"Saving {len(statuses)} rule statuses ({mode} mode)", "INFO")
            save_rule_statuses(statuses, self.dashboard_dir, mode)
            self.log(f"Synced {len(statuses)} rule statuses from cloud ({mode} mode)", "SUCCESS")
        else:
            self.log("No statuses to save", "WARNING")

        return statuses

    def _collect_source_file_hashes(self, confs: list) -> Dict[str, str]:
        """
        Collect and hash all source files from the project.

        Args:
            confs: List of ConfInfo objects

        Returns:
            Dict mapping relative path to SHA256 hash
        """
        source_file_hashes: dict = {}

        # Determine which file extensions to collect based on conf types
        extensions_by_type = {
            "EVM": [".sol", ".vy"],
            "Move": [".move"],
            "Rust": [".rs"]
        }

        # Collect all unique extensions from confs
        extensions = set()
        for conf in confs:
            conf_type = conf.conf_type
            if conf_type in extensions_by_type:
                extensions.update(extensions_by_type[conf_type])

        if not extensions:
            return source_file_hashes

        # Use shared utility to collect source files efficiently
        source_files = collect_files_by_extension(self.cwd, list(extensions))

        # Compute hashes for collected files
        for rel_path, file_path in source_files.items():
            try:
                file_hash = compute_file_hash(file_path)
                source_file_hashes[rel_path] = file_hash
            except Exception as e:
                self.log(f"Error hashing {rel_path}: {e}", "WARNING")

        return source_file_hashes

    def get_rule_statuses(self, mode: str = "local") -> Dict[str, RuleStatus]:
        """
        Get rule statuses from storage.

        Args:
            mode: "local" for local runs or "remote" for all runs

        Returns:
            Dictionary of rule_name -> RuleStatus
        """
        return load_rule_statuses(self.dashboard_dir, mode)

    def get_all_rule_statuses_history(self) -> Dict[str, list]:
        """
        Get full history of all rule statuses from storage.

        Returns:
            Dictionary of rule_name -> List[RuleStatus] (sorted by timestamp, newest first)
        """
        return load_all_rule_statuses(self.dashboard_dir)

    def get_user_run_selections(self) -> Dict[str, Dict[str, str]]:
        """
        Get user's selected runs for each rule/method.

        Returns:
            Dictionary of rule_name -> {method_name -> job_id}
            Special key "_rule_level" for non-parametric rules
        """
        return load_user_run_selections(self.dashboard_dir)
