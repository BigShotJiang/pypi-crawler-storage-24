"""
Spec validation module for comparing local specs with cloud run specs.

Validates that rules from cloud runs still exist in the current local specs.
"""

from pathlib import Path
from typing import Dict, Optional

from src.dashboard.constants import BUILTIN_RULES
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import RuleStatus, ScanSnapshot


def find_spec_for_rule(rule_name: str, snapshot: ScanSnapshot) -> Optional[Path]:
    """
    Find the spec file that contains a given rule.

    Args:
        rule_name: Name of the rule to find
        snapshot: Current scan snapshot

    Returns:
        Path to the spec file containing the rule, or None if not found
    """
    for spec_path, spec_info in snapshot.specs.items():
        for rule in spec_info.rules:
            if rule.name == rule_name:
                return spec_path
    return None


def get_spec_hash(spec_path: Path, snapshot: ScanSnapshot) -> Optional[str]:
    """
    Get the hash of a spec file from the snapshot.

    Args:
        spec_path: Path to the spec file
        snapshot: Current scan snapshot

    Returns:
        Hash of the spec file, or None if not found
    """
    spec_info = snapshot.specs.get(spec_path)
    if spec_info:
        return spec_info.hash
    return None


def validate_rule_status(
    rule_status: RuleStatus,
    snapshot: ScanSnapshot
) -> RuleStatus:
    """
    Validate a rule status against the current local specs.

    Checks if the rule still exists in the current local specs.
    Updates the rule_status object with validation information.

    Args:
        rule_status: RuleStatus to validate
        snapshot: Current scan snapshot

    Returns:
        Updated RuleStatus with validation information
    """
    rule_name = rule_status.rule_name
    warnings = []

    # Find the spec file for this rule
    spec_path = find_spec_for_rule(rule_name, snapshot)

    if spec_path is None:
        # Rule not found in local specs - might be a built-in rule or removed
        if rule_name in BUILTIN_RULES:
            # Built-in Certora rules - these don't have local specs
            warnings.append(f"Built-in rule '{rule_name}' has no local spec file")
        else:
            # Rule was removed from local specs
            warnings.append(f"Rule '{rule_name}' not found in current local specs")
            rule_status.spec_matches = False

    rule_status.validation_warnings = warnings
    return rule_status


def validate_all_statuses(
    statuses: Dict[str, RuleStatus],
    snapshot: ScanSnapshot
) -> Dict[str, RuleStatus]:
    """
    Validate all rule statuses against current local specs.

    Args:
        statuses: Dictionary of rule_name -> RuleStatus
        snapshot: Current scan snapshot

    Returns:
        Updated dictionary of rule_name -> RuleStatus with validation info
    """
    logger.log(
        f"Validating {len(statuses)} rule statuses against local specs...",
        "INFO",
        "SpecValidator"
    )

    validated_statuses = {}
    for rule_name, status in statuses.items():
        validated_status = validate_rule_status(status, snapshot)
        validated_statuses[rule_name] = validated_status

    # Count validation results
    matched = sum(1 for s in validated_statuses.values() if s.spec_matches)
    mismatched = len(validated_statuses) - matched

    logger.log(
        f"Validation complete: {matched} matched, {mismatched} mismatched",
        "INFO",
        "SpecValidator"
    )

    return validated_statuses
