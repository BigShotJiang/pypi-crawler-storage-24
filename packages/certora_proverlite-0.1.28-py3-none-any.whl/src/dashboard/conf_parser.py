"""
Configuration file parser for extracting spec file references.

Handles parsing of Certora .conf files to extract the main spec file path.
"""

import fnmatch
import json5
from pathlib import Path
from typing import List, Optional, Tuple

from src.parsers.prover_config_parser import get_spec_from_verify_field
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.move_parser import detect_move_project
from src.dashboard.rust_parser import detect_rust_project


def find_conf_files(certora_dir: Path) -> List[Path]:
    """
    Find all configuration files in the certora/ subdirectory.

    Args:
        certora_dir: Path to the certora directory

    Returns:
        List of absolute paths to .conf files (excluding template files)
    """
    conf_files: list[Path] = []

    if not certora_dir.exists() or not certora_dir.is_dir():
        logger.log(
            f"Certora directory not found: {certora_dir}",
            "WARNING",
            "ConfParser"
        )
        return conf_files

    # Recursively find all .conf files
    for conf_file in certora_dir.rglob("*.conf"):
        # Exclude template files
        if ".template." not in conf_file.name:
            conf_files.append(conf_file.resolve())

    logger.log(
        f"Found {len(conf_files)} conf files in {certora_dir}",
        "INFO",
        "ConfParser"
    )

    return conf_files


def identify_conf_type(conf_path: Path, project_root: Path) -> str:
    """
    Identify the type of conf file (EVM, Move, Rust, or Unknown).

    Args:
        conf_path: Path to the .conf file
        project_root: Path to the project root directory

    Returns:
        "EVM" for Solidity/Vyper confs,
        "Move" for Move Prover confs,
        "Rust" for Solana Prover confs,
        "Unknown" if type cannot be determined
    """
    try:
        with open(conf_path, "r") as f:
            conf_data = json5.load(f)

        has_verify = "verify" in conf_data
        has_files = "files" in conf_data

        # Check for EVM indicators
        if has_verify:
            logger.log(
                f"Identified {conf_path.name} as EVM conf (has verify field)",
                "DEBUG",
                "ConfParser"
            )
            return "EVM"

        if has_files:
            files = conf_data["files"]
            if isinstance(files, list):
                # Check if any file is .sol or .vy
                for file_path in files:
                    if isinstance(file_path, str) and (file_path.endswith(".sol") or file_path.endswith(".vy")):
                        logger.log(
                            f"Identified {conf_path.name} as EVM conf (has .sol/.vy files)",
                            "DEBUG",
                            "ConfParser"
                        )
                        return "EVM"

                # Check if any file is .so (Rust/Solana indicator)
                for file_path in files:
                    if isinstance(file_path, str) and file_path.endswith(".so"):
                        logger.log(
                            f"Identified {conf_path.name} as Rust conf (has .so files)",
                            "INFO",
                            "ConfParser"
                        )
                        return "Rust"

        # Check for Rust indicators: no verify, (no files OR only .so files), and Cargo.toml exists
        if not has_verify:
            if detect_rust_project(conf_path):
                logger.log(
                    f"Identified {conf_path.name} as Rust conf (has Cargo.toml)",
                    "INFO",
                    "ConfParser"
                )
                return "Rust"

            # Check for Move indicators: no verify, no files, and Move.toml exists
            if not has_files:
                if detect_move_project(conf_path):
                    logger.log(
                        f"Identified {conf_path.name} as Move conf (no verify/files, has Move.toml)",
                        "INFO",
                        "ConfParser"
                    )
                    return "Move"

        # Cannot determine type
        logger.log(
            f"Cannot determine type for {conf_path.name}",
            "WARNING",
            "ConfParser"
        )
        return "Unknown"

    except Exception as e:
        logger.log(
            f"Error identifying conf type for {conf_path}: {e}",
            "ERROR",
            "ConfParser"
        )
        return "Unknown"


def extract_main_spec(conf_path: Path, project_root: Path) -> Optional[Path]:
    """
    Extract the main spec file path from a configuration file.

    Args:
        conf_path: Path to the .conf file
        project_root: Path to the project root directory (CWD)

    Returns:
        Absolute path to the main spec file, or None if not found or error

    The conf file's verify field has format: "ContractName:path/to/spec.spec"
    The spec path is relative to the project root, not the conf file directory.
    """
    try:
        with open(conf_path, "r") as f:
            conf_data = json5.load(f)

        # Extract verify field
        verify_field = conf_data.get("verify")
        if not verify_field:
            logger.log(
                f"No verify field found in {conf_path}",
                "WARNING",
                "ConfParser"
            )
            return None

        # Use existing parser to extract spec path
        spec_path_str = get_spec_from_verify_field(verify_field)
        if not spec_path_str:
            logger.log(
                f"Could not parse verify field in {conf_path}: {verify_field}",
                "WARNING",
                "ConfParser"
            )
            return None

        # Resolve relative to project root
        spec_path = (project_root / spec_path_str).resolve()

        if not spec_path.exists():
            logger.log(
                f"Spec file does not exist: {spec_path} (from {conf_path})",
                "WARNING",
                "ConfParser"
            )
            return None

        return spec_path

    except Exception as e:
        logger.log(
            f"Error parsing conf file {conf_path}: {e}",
            "ERROR",
            "ConfParser"
        )
        return None


def parse_rule_filters(conf_path: Path) -> Tuple[List[str], List[str]]:
    """
    Parse rule and exclude_rule filters from a configuration file.

    Args:
        conf_path: Path to the .conf file

    Returns:
        Tuple of (rule_patterns, exclude_patterns) where each is a list of patterns.
        Empty lists if the fields are not present or cannot be parsed.
    """
    try:
        with open(conf_path, "r") as f:
            conf_data = json5.load(f)

        rule_patterns = conf_data.get("rule", [])
        exclude_patterns = conf_data.get("exclude_rule", [])

        # Ensure they are lists
        if not isinstance(rule_patterns, list):
            rule_patterns = [rule_patterns] if rule_patterns else []
        if not isinstance(exclude_patterns, list):
            exclude_patterns = [exclude_patterns] if exclude_patterns else []

        return (rule_patterns, exclude_patterns)

    except Exception as e:
        logger.log(
            f"Error parsing rule filters from {conf_path}: {e}",
            "WARNING",
            "ConfParser"
        )
        return ([], [])


def matches_pattern(rule_name: str, pattern: str) -> bool:
    """
    Check if a rule name matches a pattern.

    Supports Unix shell-style wildcards where * matches any sequence of characters.

    Args:
        rule_name: Name of the rule
        pattern: Pattern to match against (may contain * wildcard)

    Returns:
        True if rule_name matches the pattern, False otherwise

    Examples:
        matches_pattern("withdraw_succeeds", "withdraw_*") -> True
        matches_pattern("withdraw_succeeds", "withdraw_succeeds") -> True
        matches_pattern("deposit", "withdraw_*") -> False
    """
    return fnmatch.fnmatch(rule_name, pattern)


def filter_rules(
    rule_names: List[str],
    rule_patterns: List[str],
    exclude_patterns: List[str]
) -> List[str]:
    """
    Filter rule names based on rule and exclude_rule patterns.

    Filtering logic (per Certora documentation):
    1. If rule_patterns is non-empty: keep only rules matching at least one pattern
    2. If exclude_patterns is non-empty: remove rules matching any pattern

    Args:
        rule_names: List of all rule names from specs
        rule_patterns: Patterns from the 'rule' conf option (whitelist)
        exclude_patterns: Patterns from the 'exclude_rule' conf option (blacklist)

    Returns:
        Filtered list of rule names

    Examples:
        filter_rules(["withdraw_succeeds", "withdraw_fails", "deposit"],
                     ["withdraw_*"], [])
        -> ["withdraw_succeeds", "withdraw_fails"]

        filter_rules(["withdraw_succeeds", "withdraw_fails", "deposit"],
                     [], ["withdraw_*"])
        -> ["deposit"]
    """
    filtered = rule_names[:]

    # Apply whitelist filter (rule option)
    if rule_patterns:
        filtered = [
            rule_name
            for rule_name in filtered
            if any(matches_pattern(rule_name, pattern) for pattern in rule_patterns)
        ]

    # Apply blacklist filter (exclude_rule option)
    if exclude_patterns:
        filtered = [
            rule_name
            for rule_name in filtered
            if not any(matches_pattern(rule_name, pattern) for pattern in exclude_patterns)
        ]

    return filtered
