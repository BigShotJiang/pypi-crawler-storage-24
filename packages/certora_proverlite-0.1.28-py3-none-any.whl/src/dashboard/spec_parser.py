"""
Spec file parser for extracting rules, invariants, and dependencies.

This module parses CVL spec files to extract:
- Rules and invariants defined in the spec
- Imported spec files
- Dependency graphs between spec files

The parsing logic is modular and can be easily replaced with official
Certora utilities when available.
"""

import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, List, Tuple

from src.dashboard.models import RuleInfo
from src.dashboard.logger import dashboard_logger as logger


def parse_imports(spec_path: Path) -> List[Path]:
    """
    Parse import statements from a spec file.

    Args:
        spec_path: Path to the spec file

    Returns:
        List of absolute paths to imported spec files

    Spec files use import statements like: import "path/to/file.spec"
    Paths are resolved relative to the spec file's directory.
    """
    imports = []

    try:
        with open(spec_path, "r") as f:
            for line in f:
                line = line.strip()
                # Match import statements: import "path/to/file.spec"
                if line.startswith("import") and '"' in line:
                    # Extract the path between quotes
                    import_match = re.search(r'import\s+"([^"]+)"', line)
                    if import_match:
                        import_path = import_match.group(1)
                        # Resolve relative to the current spec file's directory
                        resolved_path = (spec_path.parent / import_path).resolve()
                        if resolved_path.exists():
                            imports.append(resolved_path)
                        else:
                            logger.log(
                                f"Warning: Could not resolve import '{import_path}' from {spec_path}",
                                "WARNING",
                                "SpecParser"
                            )
    except Exception as e:
        logger.log(
            f"Error parsing imports from {spec_path}: {e}",
            "ERROR",
            "SpecParser"
        )

    return imports


def build_spec_dependency_graph(
    root_spec: Path,
) -> Tuple[Dict[Path, List[Path]], Dict[Path, List[Path]]]:
    """
    Build a dependency graph of spec files starting from a root spec.

    Args:
        root_spec: The root spec file to start from

    Returns:
        Tuple of (forward_graph, reverse_graph) where:
        - forward_graph[spec] = list of specs that 'spec' imports
        - reverse_graph[spec] = list of specs that import 'spec' (ancestors)

    This performs a BFS traversal to discover all transitively imported specs.
    """
    forward_graph: dict = defaultdict(list)
    reverse_graph: dict = defaultdict(list)
    visited = set()
    queue = deque([root_spec])

    while queue:
        current_spec = queue.popleft()
        if current_spec in visited:
            continue
        visited.add(current_spec)

        # Parse imports from current spec
        imports = parse_imports(current_spec)

        for imported_spec in imports:
            # Normalize both paths for comparison
            current_normalized = current_spec.resolve()
            imported_normalized = imported_spec.resolve()

            # Add to forward graph (current imports imported_spec)
            if imported_normalized not in forward_graph[current_normalized]:
                forward_graph[current_normalized].append(imported_normalized)

            # Add to reverse graph (imported_spec is imported by current)
            if current_normalized not in reverse_graph[imported_normalized]:
                reverse_graph[imported_normalized].append(current_normalized)

            # Add to queue for further exploration
            if imported_normalized not in visited:
                queue.append(imported_normalized)

    return dict(forward_graph), dict(reverse_graph)


def extract_rules_from_spec(spec_path: Path) -> List[RuleInfo]:
    """
    Extract all rules and invariants from a spec file.

    This is a custom parser that will be replaced with official Certora
    utilities when available. It uses regex to identify:
    - Invariants: invariant myInvariant(...)
    - Rules: rule myRule(...)
    - Use statements: use rule myRule;

    Args:
        spec_path: Path to the spec file

    Returns:
        List of RuleInfo objects for all rules/invariants found

    Parametric detection:
    - A rule/invariant is parametric if it has a 'method' parameter
    """
    rules = []

    # Regex patterns
    # Match rules/invariants with or without parentheses
    # Examples: "rule myRule {", "rule myRule(", "rule myRule (", "rule myRule{", "rule myRule;"
    invariant_pattern = re.compile(r'^\s*invariant\s+(\w+)\s*[\(\{;]?')
    rule_pattern = re.compile(r'^\s*rule\s+(\w+)\s*[\(\{;]?')
    use_pattern = re.compile(r'^\s*use\s+rule\s+(\w+)\s*;')
    use_builtin_pattern = re.compile(r'^\s*use\s+builtin\s+rule\s+(\w+)')
    # Pattern to detect method parameter in the same line or nearby
    method_param_pattern = re.compile(r'\bmethod\s+\w+')

    try:
        with open(spec_path, "r") as f:
            lines = f.readlines()

        i = 0
        while i < len(lines):
            line = lines[i]

            # Check for invariant
            invariant_match = invariant_pattern.search(line)
            if invariant_match:
                rule_name = invariant_match.group(1)
                # Check if parametric (has method parameter)
                # Look at current line and next few lines for method parameter
                is_parametric = False
                for j in range(i, min(i + 5, len(lines))):
                    if method_param_pattern.search(lines[j]):
                        is_parametric = True
                        break
                    # Stop if we hit the opening brace or semicolon
                    if '{' in lines[j] or ';' in lines[j]:
                        break

                rules.append(RuleInfo(
                    name=rule_name,
                    type="invariant",
                    is_parametric=is_parametric,
                    spec_file=spec_path,
                    from_use=False
                ))

            # Check for rule
            rule_match = rule_pattern.search(line)
            if rule_match:
                rule_name = rule_match.group(1)
                # Check if parametric (has method parameter)
                is_parametric = False
                for j in range(i, min(i + 5, len(lines))):
                    if method_param_pattern.search(lines[j]):
                        is_parametric = True
                        break
                    # Stop if we hit the opening brace
                    if '{' in lines[j]:
                        break

                rules.append(RuleInfo(
                    name=rule_name,
                    type="rule",
                    is_parametric=is_parametric,
                    spec_file=spec_path,
                    from_use=False
                ))

            # Check for use rule statement
            use_match = use_pattern.search(line)
            if use_match:
                rule_name = use_match.group(1)
                # For use statements, we don't know if it's parametric yet
                # We'll mark it as non-parametric for now
                rules.append(RuleInfo(
                    name=rule_name,
                    type="rule",
                    is_parametric=False,
                    spec_file=spec_path,
                    from_use=True
                ))

            # Check for use builtin rule statement
            use_builtin_match = use_builtin_pattern.search(line)
            if use_builtin_match:
                rule_name = use_builtin_match.group(1)
                # Builtin rules are marked as rules with from_use=True
                rules.append(RuleInfo(
                    name=rule_name,
                    type="rule",
                    is_parametric=False,
                    spec_file=spec_path,
                    from_use=True
                ))

            i += 1

    except Exception as e:
        logger.log(
            f"Error extracting rules from {spec_path}: {e}",
            "ERROR",
            "SpecParser"
        )

    logger.log(
        f"Extracted {len(rules)} rules/invariants from {spec_path}",
        "INFO",
        "SpecParser"
    )

    return rules
