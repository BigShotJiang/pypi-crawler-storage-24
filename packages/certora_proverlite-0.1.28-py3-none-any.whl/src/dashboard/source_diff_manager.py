"""
Source diff management module for comparing local and remote source files.

Handles comparison of source files (.sol for EVM, .move for Move) between
local project and cloud run sources, tracking whether verification results
were run with the same source code.
"""

import re
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from src.dashboard.constants import DIR_EXTRACTED_TARS
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.storage import (
    collect_files_by_extension,
    compute_file_hash,
    load_source_diff_for_job,
    load_source_file_hashes,
    save_source_diff_for_job,
    update_source_diff_index,
)

# Global lock dictionary for preventing concurrent computation of the same job
_job_locks = {}
_job_locks_lock = threading.Lock()


def compute_source_diff_for_job(
    job_id: str,
    job_url: str,
    conf_type: str,
    local_project_root: Path,
    timestamp_dir: Path,
    dashboard_path: Path
) -> Dict:
    """
    Compute source diff for a specific job.

    Args:
        job_id: The job ID (e.g., "60724_f7260fc26e764760a9534caa32691d94")
        job_url: The URL of the cloud run
        conf_type: Type of conf - "EVM" or "Move"
        local_project_root: Path to the local project root
        timestamp_dir: Path to the timestamped snapshot directory
        dashboard_path: Path to the project root

    Returns:
        Dict with diff result:
            - equivalent: bool or None (True/False if compared, None if couldn't compare)
            - reason: str explaining why comparison failed (if equivalent is None)
            - file_diffs: list of file differences with status (added/removed/modified)

    Side Effects:
        - Saves to source_diffs/{job_id}.json
        - Updates source_diffs/index.json

    Thread Safety:
        Uses per-job locks to prevent concurrent computation of the same job.
        If another thread is already computing this job, waits for it to complete.
    """
    certora_internal = dashboard_path / ".certora_internal"

    # Extract job_id from URL to ensure consistency with tarball extraction
    # The full job ID is userId_jobHash (e.g., "1000000000_abc123...")
    match = re.search(r'/output/(\d+)/([a-f0-9]+)', job_url)
    if match:
        job_number = match.group(1)
        job_hash = match.group(2)
        full_job_id = f"{job_number}_{job_hash}"
    else:
        # Fallback to provided job_id if URL doesn't match expected format
        full_job_id = job_id

    # Get or create a lock for this specific job
    with _job_locks_lock:
        if full_job_id not in _job_locks:
            _job_locks[full_job_id] = threading.Lock()
        job_lock = _job_locks[full_job_id]

    # Acquire the job-specific lock (will wait if another thread is computing)
    with job_lock:
        # Check if already computed while we were waiting
        existing_diff = load_source_diff_for_job(timestamp_dir, full_job_id)
        if existing_diff is not None:
            logger.log(
                f"Source diff for job {job_id} already computed by another thread",
                "INFO",
                "SourceDiffManager"
            )
            return existing_diff

        logger.log(
            f"Computing source diff for job {job_id} (conf_type={conf_type})",
            "INFO",
            "SourceDiffManager"
        )

        return _compute_source_diff_for_job_impl(
            job_id, job_url, conf_type, full_job_id,
            local_project_root, timestamp_dir, dashboard_path, certora_internal
        )


def _adjust_paths_for_prefix_mismatch(
    local_files: Dict[str, Path],
    remote_files: Dict[str, Path],
    local_project_root: Path,
    cached_local_hashes: Optional[Dict[str, str]] = None
) -> Tuple[Dict[str, Path], Optional[Dict[str, str]], Optional[Dict[str, str]]]:
    """
    Detect and fix path prefix mismatch between local and remote files.

    This occurs when the local working directory is a subdirectory of where
    the prover job ran. For example:
    - Local CWD: .../klend-audit/programs/kamino-lending/
    - Prover root: .../klend-audit/
    - Result: Local paths miss "programs/kamino-lending/" prefix

    Also handles directory name variations (e.g., klend vs kamino-lending).

    Detection criteria:
    - NO common files between local and remote (100% would be "added")
    - Remote files share a common directory prefix
    - Local project root ends with that same prefix (or similar structure)

    Args:
        local_files: Dict of relative_path -> absolute_path for local files
        remote_files: Dict of relative_path -> absolute_path for remote files
        local_project_root: Path to local project root
        cached_local_hashes: Optional dict of relative_path -> hash

    Returns:
        Tuple of (adjusted_local_files, adjusted_cached_hashes, path_replacement_info)
        Returns originals unchanged if no adjustment needed
        path_replacement_info is a dict like {"from": "klend", "to": "kamino-lending"} or None
    """
    import os

    # CRITICAL: Resolve to absolute path so .parts works correctly
    # If local_project_root is Path('.'), .parts will be empty!
    local_project_root = local_project_root.resolve()

    local_paths = set(local_files.keys())
    remote_paths = set(remote_files.keys())
    common_files = local_paths & remote_paths

    # DEBUG logging
    logger.log(
        f"Path adjustment check: local_project_root='{local_project_root}' (parts={local_project_root.parts})",
        "INFO",
        "SourceDiffManager"
    )
    logger.log(
        f"Path adjustment check: {len(local_files)} local files, {len(remote_files)} remote files, {len(common_files)} common files",
        "INFO",
        "SourceDiffManager"
    )
    logger.log(
        f"Sample local paths: {list(local_paths)[:3]}",
        "INFO",
        "SourceDiffManager"
    )
    logger.log(
        f"Sample remote paths: {list(remote_paths)[:3]}",
        "INFO",
        "SourceDiffManager"
    )

    # Only adjust if ALL files are mismatched
    if common_files or not local_files or not remote_files:
        if common_files:
            logger.log(
                f"Skipping path adjustment: {len(common_files)} files already match",
                "INFO",
                "SourceDiffManager"
            )
        return local_files, cached_local_hashes, None

    # Find common prefix of all remote paths
    remote_path_list = list(remote_paths)
    common_prefix = os.path.commonprefix(remote_path_list)

    # Trim to full directory path (not partial directory name)
    if common_prefix and '/' in common_prefix:
        common_prefix = common_prefix.rsplit('/', 1)[0] + '/'

    logger.log(
        f"Remote common prefix: '{common_prefix}'",
        "INFO",
        "SourceDiffManager"
    )

    if not common_prefix:
        logger.log(
            "No common prefix found, skipping path adjustment",
            "INFO",
            "SourceDiffManager"
        )
        return local_files, cached_local_hashes, None

    # Strategy 1: Try exact match (original logic)
    prefix_parts = Path(common_prefix.rstrip('/')).parts
    logger.log(
        f"Strategy 1: Checking exact match with prefix_parts={prefix_parts}",
        "INFO",
        "SourceDiffManager"
    )

    if len(prefix_parts) <= len(local_project_root.parts):
        local_suffix = local_project_root.parts[-len(prefix_parts):]
        local_suffix_path = '/'.join(local_suffix)

        logger.log(
            f"Strategy 1: local_suffix_path='{local_suffix_path}' vs common_prefix.strip('/')='{common_prefix.strip('/')}'",
            "INFO",
            "SourceDiffManager"
        )

        if common_prefix.strip('/') == local_suffix_path:
            # Exact match found! Adjust paths
            logger.log(
                f"Detected path prefix mismatch: local root ends with '{local_suffix_path}' "
                f"matching remote prefix '{common_prefix}'. Adjusting local paths...",
                "INFO",
                "SourceDiffManager"
            )

            adjusted_local_files = {
                common_prefix + rel_path: abs_path
                for rel_path, abs_path in local_files.items()
            }

            adjusted_hashes = None
            if cached_local_hashes:
                adjusted_hashes = {
                    common_prefix + rel_path: hash_val
                    for rel_path, hash_val in cached_local_hashes.items()
                }

            logger.log(
                f"Adjusted {len(adjusted_local_files)} local file paths with prefix '{common_prefix}'",
                "INFO",
                "SourceDiffManager"
            )

            return adjusted_local_files, adjusted_hashes, None
    else:
        logger.log(
            f"Strategy 1: Skipped - prefix too long ({len(prefix_parts)} > {len(local_project_root.parts)})",
            "INFO",
            "SourceDiffManager"
        )

    # Strategy 2: Try directory name replacement (e.g., klend -> kamino-lending)
    # Try progressively shorter prefixes to find the structural root
    # E.g., if common_prefix is "programs/klend/src/", try "programs/klend/" first
    logger.log(
        f"Strategy 2: Attempting directory name replacement",
        "INFO",
        "SourceDiffManager"
    )

    prefix_parts = Path(common_prefix.rstrip('/')).parts

    # Try from the full prefix down to just 2 components (e.g., "programs/klend")
    for trim_depth in range(0, max(0, len(prefix_parts) - 1)):
        test_prefix_parts = prefix_parts[:len(prefix_parts) - trim_depth]
        test_prefix_str = '/'.join(test_prefix_parts) + '/'

        logger.log(
            f"Strategy 2: Trying prefix depth {len(test_prefix_parts)}: '{test_prefix_str}'",
            "INFO",
            "SourceDiffManager"
        )

        if len(test_prefix_parts) > 0 and len(test_prefix_parts) <= len(local_project_root.parts):
            local_suffix = local_project_root.parts[-len(test_prefix_parts):]

            # Check if they have the same structure but different names
            # E.g., remote: programs/klend, local: programs/kamino-lending
            if len(test_prefix_parts) == len(local_suffix):
                # Find the differing component
                for i, (remote_part, local_part) in enumerate(zip(test_prefix_parts, local_suffix)):
                    if remote_part != local_part:
                        # Found a mismatch - try replacing this component
                        logger.log(
                            f"Detected directory name mismatch at depth {len(test_prefix_parts)}: remote '{remote_part}' vs local '{local_part}'. "
                            f"Testing replacement with prefix '{test_prefix_str}'...",
                            "INFO",
                            "SourceDiffManager"
                        )

                        # Create test adjusted paths by prepending the TEST prefix (not common_prefix!)
                        test_adjusted_files = {}
                        for rel_path, abs_path in local_files.items():
                            # Use the test prefix to make local paths match remote structure
                            test_adjusted_files[test_prefix_str + rel_path] = abs_path

                        # Validate: check if ANY file would now match
                        test_local_paths = set(test_adjusted_files.keys())
                        test_common_files = test_local_paths & remote_paths

                        logger.log(
                            f"Test result: {len(test_common_files)} files would match with prefix '{test_prefix_str}'",
                            "INFO",
                            "SourceDiffManager"
                        )

                        if test_common_files:
                            # Success! At least one file matches with this replacement
                            logger.log(
                                f"Replacement successful: {len(test_common_files)} files now match. "
                                f"Applying directory name replacement: '{remote_part}' -> '{local_part}'",
                                "INFO",
                                "SourceDiffManager"
                            )

                            # Apply the adjustment
                            adjusted_hashes = None
                            if cached_local_hashes:
                                adjusted_hashes = {}
                                for rel_path, hash_val in cached_local_hashes.items():
                                    # Use the test prefix
                                    adjusted_hashes[test_prefix_str + rel_path] = hash_val

                            path_replacement_info = {
                                "from": remote_part,
                                "to": local_part
                            }

                            return test_adjusted_files, adjusted_hashes, path_replacement_info

                        # This depth didn't work, try next one
                        break

    logger.log(
        "Strategy 2: No suitable prefix replacement found",
        "INFO",
        "SourceDiffManager"
    )

    # No adjustment needed or possible
    return local_files, cached_local_hashes, None


def _compute_source_diff_for_job_impl(
    job_id: str,
    job_url: str,
    conf_type: str,
    full_job_id: str,
    local_project_root: Path,
    timestamp_dir: Path,
    dashboard_path: Path,
    certora_internal: Path
) -> Dict:
    """
    Internal implementation of source diff computation (called with lock held).
    """

    # Log what we received
    logger.log(
        f"_compute_source_diff_for_job_impl called with local_project_root='{local_project_root}' (type={type(local_project_root)}, parts={local_project_root.parts if isinstance(local_project_root, Path) else 'N/A'})",
        "INFO",
        "SourceDiffManager"
    )
    logger.log(
        f"_compute_source_diff_for_job_impl dashboard_path='{dashboard_path}'",
        "INFO",
        "SourceDiffManager"
    )

    # Determine file extensions based on conf type
    if conf_type == "EVM":
        extensions = [".sol", ".vy"]
    elif conf_type == "Move":
        extensions = [".move"]
    elif conf_type == "Rust":
        extensions = [".rs"]
    else:
        logger.log(
            f"Unknown conf type '{conf_type}' for job {job_id}",
            "WARNING",
            "SourceDiffManager"
        )
        result: dict = {
            "equivalent": None,
            "reason": f"Unknown conf type: {conf_type}",
            "file_diffs": [],
            "path_replacement": None
        }
        save_source_diff_for_job(timestamp_dir, full_job_id, result)
        update_source_diff_index(timestamp_dir, full_job_id, None)
        return result

    # Get remote sources path
    remote_sources_path = (
        certora_internal / DIR_EXTRACTED_TARS / full_job_id / "inputs" / ".certora_sources"
    )

    if not remote_sources_path.exists():
        logger.log(
            f"Remote sources not found at {remote_sources_path}, attempting to extract...",
            "INFO",
            "SourceDiffManager"
        )

        # Try to extract sources from tarball
        from src.dashboard.tarball_manager import extract_from_tarball, download_tarball

        # Download tarball if needed
        cache_dir = certora_internal / "tarball_cache"
        cache_dir.mkdir(parents=True, exist_ok=True)

        logger.log(
            f"Downloading tarball for job {full_job_id} if needed...",
            "INFO",
            "SourceDiffManager"
        )

        try:
            tarball_path = download_tarball(full_job_id, job_url, cache_dir)
            if not tarball_path:
                logger.log(
                    f"Failed to download tarball for job {job_id}",
                    "ERROR",
                    "SourceDiffManager"
                )
                result = {
                    "equivalent": None,
                    "reason": "Failed to download tarball",
                    "file_diffs": [],
                    "path_replacement": None
                }
                save_source_diff_for_job(timestamp_dir, full_job_id, result)
                update_source_diff_index(timestamp_dir, full_job_id, None)
                return result

            logger.log(
                f"Tarball available at {tarball_path}",
                "INFO",
                "SourceDiffManager"
            )
        except Exception as e:
            logger.log(
                f"Error downloading tarball for job {job_id}: {e}",
                "ERROR",
                "SourceDiffManager"
            )
            result = {
                "equivalent": None,
                "reason": f"Failed to download tarball: {str(e)}",
                "file_diffs": [],
                "path_replacement": None
            }
            save_source_diff_for_job(timestamp_dir, full_job_id, result)
            update_source_diff_index(timestamp_dir, full_job_id, None)
            return result

        # Extract sources from tarball
        try:
            # extraction_base should point to where extracted_tars will be created
            # extract_from_tarball will create: extraction_base/extracted_tars/{job_id}/...
            extraction_base = certora_internal
            extracted_path = extract_from_tarball(
                tarball_path=tarball_path,
                job_id=full_job_id,
                extraction_base=extraction_base,
                subpath="inputs/.certora_sources"
            )

            if not extracted_path or not extracted_path.exists():
                logger.log(
                    f"Extraction failed or sources not in tarball for job {job_id}",
                    "WARNING",
                    "SourceDiffManager"
                )
                result = {
                    "equivalent": None,
                    "reason": "Sources not found in tarball",
                    "file_diffs": [],
                    "path_replacement": None
                }
                save_source_diff_for_job(timestamp_dir, full_job_id, result)
                update_source_diff_index(timestamp_dir, full_job_id, None)
                return result

            remote_sources_path = extracted_path
            logger.log(
                f"Successfully extracted sources to {remote_sources_path}",
                "SUCCESS",
                "SourceDiffManager"
            )

        except Exception as e:
            logger.log(
                f"Error extracting sources for job {job_id}: {e}",
                "ERROR",
                "SourceDiffManager"
            )
            result = {
                "equivalent": None,
                "reason": f"Failed to extract sources: {str(e)}",
                "file_diffs": [],
                "path_replacement": None
            }
            save_source_diff_for_job(timestamp_dir, full_job_id, result)
            update_source_diff_index(timestamp_dir, full_job_id, None)
            return result

    # Load cached source file hashes (required for optimization)
    cached_local_hashes = load_source_file_hashes(timestamp_dir)

    if not cached_local_hashes:
        logger.log(
            f"No cached source file hashes found in {timestamp_dir}. Cannot compute source diff.",
            "ERROR",
            "SourceDiffManager"
        )
        result = {
            "equivalent": None,
            "reason": "No cached source file hashes available",
            "file_diffs": [],
            "path_replacement": None
        }
        save_source_diff_for_job(timestamp_dir, full_job_id, result)
        update_source_diff_index(timestamp_dir, full_job_id, None)
        return result

    # Build local_files dict from cached hash keys (no filesystem scan needed)
    local_files = {
        rel_path: local_project_root / rel_path
        for rel_path in cached_local_hashes.keys()
    }
    logger.log(
        f"Using cached file list: {len(local_files)} local source files",
        "INFO",
        "SourceDiffManager"
    )

    logger.log(
        f"Collecting remote source files from {remote_sources_path} with extensions {extensions}",
        "INFO",
        "SourceDiffManager"
    )
    remote_files = _collect_source_files(remote_sources_path, extensions)
    logger.log(
        f"Found {len(remote_files)} remote source files",
        "INFO",
        "SourceDiffManager"
    )

    # Detect and fix path prefix mismatch
    local_files, cached_local_hashes, path_replacement_info = _adjust_paths_for_prefix_mismatch(
        local_files,
        remote_files,
        local_project_root,
        cached_local_hashes
    )

    # Compare file trees (use cached hashes for optimization if available)
    try:
        file_diffs, equivalent = _compare_file_trees_with_hashes(
            local_files,
            remote_files,
            local_project_root,
            remote_sources_path,
            cached_local_hashes
        )

        logger.log(
            f"Source diff for job {job_id}: equivalent={equivalent}, {len(file_diffs)} files changed",
            "INFO",
            "SourceDiffManager"
        )

        result = {
            "equivalent": equivalent,
            "reason": None if equivalent is not None else "Comparison failed",
            "file_diffs": file_diffs,
            "path_replacement": path_replacement_info
        }

        save_source_diff_for_job(timestamp_dir, full_job_id, result)
        update_source_diff_index(timestamp_dir, full_job_id, equivalent)

        return result

    except Exception as e:
        logger.log(
            f"Error comparing source files for job {job_id}: {e}",
            "ERROR",
            "SourceDiffManager"
        )
        result = {
            "equivalent": None,
            "reason": f"Comparison error: {str(e)}",
            "file_diffs": [],
            "path_replacement": None
        }
        save_source_diff_for_job(timestamp_dir, full_job_id, result)
        update_source_diff_index(timestamp_dir, full_job_id, None)
        return result


def _collect_source_files(base_path: Path, extensions: List[str]) -> Dict[str, Path]:
    """
    Recursively collect all source files with given extensions.

    Uses shared utility function that efficiently skips excluded directories,
    avoiding traversal of large directories like node_modules.

    Args:
        base_path: Root directory to search
        extensions: List of file extensions to include (e.g., [".sol", ".vy"])

    Returns:
        Dict mapping relative path to absolute path
    """
    return collect_files_by_extension(base_path, extensions)


def _compare_file_trees(
    local_files: Dict[str, Path],
    remote_files: Dict[str, Path],
    local_base: Path,
    remote_base: Path
) -> Tuple[List[Dict[str, Any]], bool]:
    """
    Compare two file trees and compute diffs.

    Args:
        local_files: Dict of relative_path -> absolute_path for local files
        remote_files: Dict of relative_path -> absolute_path for remote files
        local_base: Base path for local files
        remote_base: Base path for remote files

    Returns:
        Tuple of (file_diffs, equivalent):
            - file_diffs: List of dicts with {path, status, diff_lines}
            - equivalent: True if all files match, False otherwise
    """
    file_diffs = []
    local_paths = set(local_files.keys())
    remote_paths = set(remote_files.keys())

    # Note: We don't report "removed" files (local only) because cloud runs
    # only include relevant files, so missing files in remote is expected.

    # Files only in remote (added in remote)
    added_files = remote_paths - local_paths
    for rel_path in sorted(added_files):
        file_diffs.append({
            "path": rel_path,
            "status": "added",
            "diff_lines": None
        })
        logger.log(
            f"File added in remote: {rel_path}",
            "DEBUG",
            "SourceDiffManager"
        )

    # Files in both - check for modifications
    common_files = local_paths & remote_paths
    for rel_path in sorted(common_files):
        local_file = local_files[rel_path]
        remote_file = remote_files[rel_path]

        # Read file contents
        try:
            with open(local_file, 'r', encoding='utf-8') as f:
                local_content = f.read()
        except Exception as e:
            logger.log(
                f"Error reading local file {rel_path}: {e}",
                "WARNING",
                "SourceDiffManager"
            )
            continue

        try:
            with open(remote_file, 'r', encoding='utf-8') as f:
                remote_content = f.read()
        except Exception as e:
            logger.log(
                f"Error reading remote file {rel_path}: {e}",
                "WARNING",
                "SourceDiffManager"
            )
            continue

        # Compare contents
        if local_content != remote_content:
            # Files differ - compute line-by-line diff
            local_lines = local_content.splitlines()
            remote_lines = remote_content.splitlines()

            diff_entry: Dict[str, Any] = {
                "path": rel_path,
                "status": "modified",
                "local_lines": local_lines,
                "remote_lines": remote_lines
            }
            file_diffs.append(diff_entry)
            logger.log(
                f"File modified: {rel_path} (local: {len(local_lines)} lines, remote: {len(remote_lines)} lines)",
                "DEBUG",
                "SourceDiffManager"
            )

    # Determine equivalence
    equivalent = len(file_diffs) == 0

    return file_diffs, equivalent


def _compare_file_trees_with_hashes(
    local_files: Dict[str, Path],
    remote_files: Dict[str, Path],
    local_base: Path,
    remote_base: Path,
    cached_local_hashes: Optional[Dict[str, str]] = None
) -> Tuple[List[Dict], bool]:
    """
    Compare two file trees and compute diffs, using cached hashes for optimization.

    This function performs a two-phase comparison:
    1. Quick hash comparison for files that exist in both trees
    2. Line-by-line diff only for files with different hashes

    Args:
        local_files: Dict of relative_path -> absolute_path for local files
        remote_files: Dict of relative_path -> absolute_path for remote files
        local_base: Base path for local files
        remote_base: Base path for remote files
        cached_local_hashes: Optional dict of relative_path -> SHA256 hash for local files

    Returns:
        Tuple of (file_diffs, equivalent):
            - file_diffs: List of dicts with {path, status, diff_lines}
            - equivalent: True if all files match, False otherwise
    """
    file_diffs = []
    local_paths = set(local_files.keys())
    remote_paths = set(remote_files.keys())

    # Note: We don't report "removed" files (local only) because cloud runs
    # only include relevant files, so missing files in remote is expected.

    # Files only in remote (added in remote)
    added_files = remote_paths - local_paths
    for rel_path in sorted(added_files):
        # Calculate line count for added files
        try:
            remote_file = remote_files[rel_path]
            with open(remote_file, 'r', encoding='utf-8') as f:
                remote_lines = f.read().splitlines()
            lines_added = len(remote_lines)
        except Exception:
            lines_added = 0

        file_diffs.append({
            "path": rel_path,
            "status": "added",
            "diff_lines": None,
            "lines_added": lines_added,
            "lines_removed": 0
        })
        logger.log(
            f"File added in remote: {rel_path}",
            "DEBUG",
            "SourceDiffManager"
        )

    # Files in both - check for modifications using hash comparison
    common_files = local_paths & remote_paths
    for rel_path in sorted(common_files):
        local_file = local_files[rel_path]
        remote_file = remote_files[rel_path]

        # Try to use cached hash for local file first
        local_hash = None
        if cached_local_hashes and rel_path in cached_local_hashes:
            local_hash = cached_local_hashes[rel_path]
            logger.log(
                f"Using cached hash for {rel_path}",
                "DEBUG",
                "SourceDiffManager"
            )
        else:
            # Compute hash if not cached
            try:
                local_hash = compute_file_hash(local_file)
            except Exception as e:
                logger.log(
                    f"Error hashing local file {rel_path}: {e}",
                    "WARNING",
                    "SourceDiffManager"
                )

        # Always compute remote hash (not cached)
        remote_hash = None
        try:
            remote_hash = compute_file_hash(remote_file)
        except Exception as e:
            logger.log(
                f"Error hashing remote file {rel_path}: {e}",
                "WARNING",
                "SourceDiffManager"
            )

        # If hashing failed for either file, fall back to content comparison
        if local_hash is None or remote_hash is None:
            # Read and compare contents directly
            try:
                with open(local_file, 'r', encoding='utf-8') as f:
                    local_content = f.read()
                with open(remote_file, 'r', encoding='utf-8') as f:
                    remote_content = f.read()

                if local_content != remote_content:
                    local_lines = local_content.splitlines()
                    remote_lines = remote_content.splitlines()

                    # Calculate line stats using simple set difference
                    local_set = set(local_lines)
                    remote_set = set(remote_lines)
                    lines_added = len(remote_set - local_set)
                    lines_removed = len(local_set - remote_set)

                    diff_entry: Dict[str, Any] = {
                        "path": rel_path,
                        "status": "modified",
                        "local_lines": local_lines,
                        "remote_lines": remote_lines,
                        "lines_added": lines_added,
                        "lines_removed": lines_removed
                    }
                    file_diffs.append(diff_entry)
                    logger.log(
                        f"File modified (content comparison): {rel_path}",
                        "DEBUG",
                        "SourceDiffManager"
                    )
            except Exception as e:
                logger.log(
                    f"Error comparing file {rel_path}: {e}",
                    "WARNING",
                    "SourceDiffManager"
                )
            continue

        # Compare hashes - if different, read files for line-by-line diff
        if local_hash != remote_hash:
            # Files differ - read contents for detailed diff
            try:
                with open(local_file, 'r', encoding='utf-8') as f:
                    local_content = f.read()
                with open(remote_file, 'r', encoding='utf-8') as f:
                    remote_content = f.read()

                local_lines = local_content.splitlines()
                remote_lines = remote_content.splitlines()

                # Calculate line stats using simple set difference
                local_set = set(local_lines)
                remote_set = set(remote_lines)
                lines_added = len(remote_set - local_set)
                lines_removed = len(local_set - remote_set)

                diff_entry2: Dict[str, Any] = {
                    "path": rel_path,
                    "status": "modified",
                    "local_lines": local_lines,
                    "remote_lines": remote_lines,
                    "lines_added": lines_added,
                    "lines_removed": lines_removed
                }
                file_diffs.append(diff_entry2)
                logger.log(
                    f"File modified (hash mismatch): {rel_path} (local: {len(local_lines)} lines, remote: {len(remote_lines)} lines)",
                    "DEBUG",
                    "SourceDiffManager"
                )
            except Exception as e:
                logger.log(
                    f"Error reading files for diff {rel_path}: {e}",
                    "WARNING",
                    "SourceDiffManager"
                )
        else:
            # Hashes match - files are identical, no need to read contents
            logger.log(
                f"File unchanged (hash match): {rel_path}",
                "DEBUG",
                "SourceDiffManager"
            )

    # Determine equivalence
    equivalent = len(file_diffs) == 0

    return file_diffs, equivalent
