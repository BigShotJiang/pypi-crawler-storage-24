// Certora Dashboard JavaScript

// State
let currentScanData = null;
let expandedRules = new Set(); // Track which parametric rules are expanded
let expandedConfs = new Set(); // Track which confs are expanded
let currentMode = 'remote'; // Track current mode: 'local' or 'remote' (default: 'remote' = All Runs)
let syncProgressPollingInterval = null; // Track sync progress polling interval
let scanProgressPollingInterval = null; // Track scan progress polling interval
let cexPollingInterval = null; // Track CEX analysis polling interval
let runningCexAnalyses = new Set(); // Track which CEX analyses are running

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', function() {
    restoreState();
    loadScanData();
    setupEventListeners();
    startStatusPolling();

    // Start polling for sync and scan progress automatically
    // This ensures progress updates are shown even if page is reloaded during a scan
    console.log('Page loaded, starting progress polling...');
    startProgressPolling();

    // Save scroll position periodically
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
            saveState();
        }, 200);
    });
});

// Setup event listeners
function setupEventListeners() {
    const refreshBtn = document.getElementById('refresh-btn');
    refreshBtn.addEventListener('click', handleRefreshClick);

    // Mode toggle buttons
    const modeLocalBtn = document.getElementById('mode-local');
    const modeAllBtn = document.getElementById('mode-all');

    modeLocalBtn.addEventListener('click', () => switchMode('local'));
    modeAllBtn.addEventListener('click', () => switchMode('remote'));

    // Settings button and modal
    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settings-modal');
    const settingsModalClose = document.getElementById('settings-modal-close');
    const settingsSave = document.getElementById('settings-save');
    const settingsCancel = document.getElementById('settings-cancel');

    settingsBtn.addEventListener('click', openSettingsModal);
    settingsModalClose.addEventListener('click', closeSettingsModal);
    settingsSave.addEventListener('click', saveSettings);
    settingsCancel.addEventListener('click', closeSettingsModal);

    // Close modal when clicking outside
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            closeSettingsModal();
        }
    });
}

// Save state to localStorage
function saveState() {
    const state = {
        expandedConfs: Array.from(expandedConfs),
        expandedRules: Array.from(expandedRules),
        scrollPosition: window.scrollY,
        mode: currentMode
    };
    localStorage.setItem('certoraDashboardState', JSON.stringify(state));
}

// Restore state from localStorage
function restoreState() {
    try {
        const saved = localStorage.getItem('certoraDashboardState');
        if (saved) {
            const state = JSON.parse(saved);
            expandedConfs = new Set(state.expandedConfs || []);
            expandedRules = new Set(state.expandedRules || []);
            currentMode = state.mode || 'remote'; // Default to 'remote' (All Runs)
            // Scroll position will be restored after render
            if (state.scrollPosition) {
                setTimeout(() => window.scrollTo(0, state.scrollPosition), 100);
            }
        }
        // Update UI to reflect current mode
        updateModeUI();
    } catch (error) {
        console.error('Error restoring state:', error);
    }
}

// Load scan data from API
async function loadScanData() {
    try {
        const settings = loadSettings();
        const allUsers = settings.userFilter === 'all-users' ? 'true' : 'false';
        const lookbackDays = settings.lookbackDays;
        const astTimeout = settings.astTimeout;
        const response = await fetch(`/api/scan?mode=${currentMode}&allUsers=${allUsers}&lookbackDays=${lookbackDays}&astTimeout=${astTimeout}`);
        const data = await response.json();
        currentScanData = data;
        renderDashboard(data);
        updateLastUpdated(data.timestamp, data.last_cloud_sync);
    } catch (error) {
        console.error('Error loading scan data:', error);
        showError('Failed to load scan data');
    }
}

// Render the entire dashboard
function renderDashboard(data) {
    // Store data globally for access by other functions
    window.currentData = data;

    updateMetrics(data);
    renderConfTables(data);

    // Track running CEX analyses
    trackRunningCexAnalyses(data);

    // Resume polling for any running timeouter runs
    if (data.timeouter_runs) {
        resumeTimeouterPolling(data.timeouter_runs);
    }

    // Restore scroll position after rendering
    const saved = localStorage.getItem('certoraDashboardState');
    if (saved) {
        const state = JSON.parse(saved);
        if (state.scrollPosition) {
            setTimeout(() => window.scrollTo(0, state.scrollPosition), 50);
        }
    }
}

// Update header metrics
function updateMetrics(data) {
    const statuses = data.statuses || {};
    const totalConfs = data.total_confs;
    const totalRules = countTotalRules(data);
    const totalSubitems = countTotalSubitems(data, statuses);

    // Calculate verified counts
    const {verifiedRules, verifiedSubitems} = countVerifiedItems(data, statuses);
    const verifiedConfs = countVerifiedConfs(data, statuses);

    // Calculate attempted rules and subitems (rules/subitems that have any status from cloud)
    const attemptedRules = countAttemptedRules(data, statuses);
    const attemptedSubitems = countAttemptedSubitems(data, statuses);

    // Calculate compilation success (confs with successful AST generation)
    const compiledConfs = data.compilation_stats ? data.compilation_stats.successful : null;

    // Update conf metrics
    document.getElementById('metric-confs-verified').textContent = verifiedConfs;
    document.getElementById('metric-confs-total').textContent = `of ${totalConfs} total`;
    const confsProgress = totalConfs > 0 ? (verifiedConfs / totalConfs) * 100 : 0;
    document.getElementById('progress-fill-confs').style.width = `${confsProgress}%`;

    // Update compilation success display if available
    const compiledElement = document.getElementById('metric-confs-compiled');
    if (compiledConfs !== null && compiledConfs !== undefined) {
        compiledElement.textContent = `${compiledConfs} / ${totalConfs} compiled successfully`;
        compiledElement.style.display = 'block';
        // Color code: green if all compiled, orange/red if some failed
        if (compiledConfs === totalConfs) {
            compiledElement.style.color = '#28a745';
        } else if (compiledConfs > 0) {
            compiledElement.style.color = '#ffa500';
        } else {
            compiledElement.style.color = '#dc3545';
        }
    } else {
        compiledElement.style.display = 'none';
    }

    // Update rule metrics
    document.getElementById('metric-rules-verified').textContent = verifiedRules;
    document.getElementById('metric-rules-total').textContent = `of ${totalRules} total`;
    const rulesProgress = totalRules > 0 ? (verifiedRules / totalRules) * 100 : 0;
    document.getElementById('progress-fill-rules').style.width = `${rulesProgress}%`;

    // Update subitem metrics
    document.getElementById('metric-subitems-verified').textContent = verifiedSubitems;
    document.getElementById('metric-subitems-total').textContent = `of ${attemptedSubitems} attempted`;
    const subitemsProgress = attemptedSubitems > 0 ? (verifiedSubitems / attemptedSubitems) * 100 : 0;
    document.getElementById('progress-fill-subitems').style.width = `${subitemsProgress}%`;

    // Update attempted rules metrics
    document.getElementById('metric-rules-attempted').textContent = attemptedRules;
    document.getElementById('metric-rules-attempted-total').textContent = `of ${totalRules} total`;
    const attemptedProgress = totalRules > 0 ? (attemptedRules / totalRules) * 100 : 0;
    document.getElementById('progress-fill-attempted').style.width = `${attemptedProgress}%`;

    // Update overall verification progress (only of attempted subitems, not all)
    const progress = attemptedSubitems > 0 ? Math.round((verifiedSubitems / attemptedSubitems) * 100) : 0;
    document.getElementById('metric-progress').textContent = `${progress}%`;
    document.getElementById('progress-fill').style.width = `${progress}%`;
}

// Count total rules across all confs
function countTotalRules(data) {
    const uniqueRules = new Set();
    data.confs.forEach(conf => {
        conf.rules.forEach(rule => uniqueRules.add(rule));
    });
    return uniqueRules.size;
}

// Count total subitems (rules + methods for parametric rules)
function countTotalSubitems(data, statuses) {
    let total = 0;
    const uniqueRules = new Set();

    data.confs.forEach(conf => {
        conf.rules.forEach(ruleName => uniqueRules.add(ruleName));
    });

    uniqueRules.forEach(ruleName => {
        const status = statuses[ruleName];
        if (status && status.method_statuses && Object.keys(status.method_statuses).length > 0) {
            // Parametric rule - count each method
            total += Object.keys(status.method_statuses).length;
        } else {
            // Non-parametric rule
            total += 1;
        }
    });

    return total;
}

// Count verified items
function countVerifiedItems(data, statuses) {
    let verifiedRules = 0;
    let verifiedSubitems = 0;
    const uniqueRules = new Set();

    data.confs.forEach(conf => {
        conf.rules.forEach(ruleName => uniqueRules.add(ruleName));
    });

    uniqueRules.forEach(ruleName => {
        const status = statuses[ruleName];
        if (!status) return;

        // For parametric rules, count verified methods even if overall status isn't verified
        if (status.method_statuses && Object.keys(status.method_statuses).length > 0) {
            // Parametric rule - count verified methods
            let allMethodsVerified = true;
            Object.values(status.method_statuses).forEach(methodStatus => {
                if (methodStatus === 'verified') {
                    verifiedSubitems++;
                } else {
                    allMethodsVerified = false;
                }
            });

            // Only count the rule as verified if ALL methods are verified
            if (allMethodsVerified) {
                verifiedRules++;
            }
        } else {
            // Non-parametric rule
            if (status.overall_status === 'verified') {
                verifiedRules++;
                verifiedSubitems++;
            }
        }
    });

    return {verifiedRules, verifiedSubitems};
}

// Count verified confs
function countVerifiedConfs(data, statuses) {
    let count = 0;

    data.confs.forEach(conf => {
        const allVerified = conf.rules.every(ruleName => {
            const status = statuses[ruleName];
            return status && status.overall_status === 'verified';
        });

        if (allVerified && conf.rules.length > 0) {
            count++;
        }
    });

    return count;
}

// Count attempted rules (rules that have any cloud status)
function countAttemptedRules(data, statuses) {
    const uniqueRules = new Set();
    data.confs.forEach(conf => {
        conf.rules.forEach(ruleName => uniqueRules.add(ruleName));
    });

    let count = 0;
    uniqueRules.forEach(ruleName => {
        if (statuses[ruleName]) {
            count++;
        }
    });

    return count;
}

// Count attempted subitems (subitems that have any cloud status)
function countAttemptedSubitems(data, statuses) {
    const uniqueRules = new Set();
    data.confs.forEach(conf => {
        conf.rules.forEach(ruleName => uniqueRules.add(ruleName));
    });

    let count = 0;
    uniqueRules.forEach(ruleName => {
        const status = statuses[ruleName];
        if (!status) return;

        if (status.method_statuses && Object.keys(status.method_statuses).length > 0) {
            // Parametric rule - count all methods
            count += Object.keys(status.method_statuses).length;
        } else {
            // Non-parametric rule
            count += 1;
        }
    });

    return count;
}

// Render conf tables
function renderConfTables(data) {
    const container = document.getElementById('confs-container');
    const tocElement = document.getElementById('table-of-contents');

    if (data.confs.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <h3>No Configuration Files Found</h3>
                <p>No .conf files were found in the certora/ directory.</p>
            </div>
        `;
        tocElement.style.display = 'none';
        return;
    }

    // Generate Table of Contents
    renderTableOfContents(data.confs);
    tocElement.style.display = 'block';

    // Check if confs are in multiple folders by counting unique folder prefixes
    const folders = new Set(data.confs.map(c => {
        const path = c.conf_rel_path || '';
        const lastSlash = path.lastIndexOf('/');
        return lastSlash > 0 ? path.substring(0, lastSlash) : '';
    }));
    const showFullPaths = folders.size > 1;

    // Sort confs by folder (conf_rel_path) to group them
    const sortedConfs = [...data.confs].sort((a, b) => {
        const pathA = a.conf_rel_path || a.conf_name;
        const pathB = b.conf_rel_path || b.conf_name;
        return pathA.localeCompare(pathB);
    });

    let html = '';

    sortedConfs.forEach(conf => {
        html += renderConfSection(conf, data, showFullPaths);
    });

    container.innerHTML = html;

    // Attach event listeners to drill-down rows
    attachDrillDownListeners();

    // Attach event listeners to run selector dropdowns
    attachRunSelectorListeners();
}

// Render Table of Contents organized by folder
function renderTableOfContents(confs) {
    const tocContainer = document.getElementById('toc-container');

    // Group confs by folder
    const confsByFolder = {};

    confs.forEach(conf => {
        let folder;

        if (conf.conf_rel_path) {
            // Use relative path from project root
            const lastSlash = conf.conf_rel_path.lastIndexOf('/');
            if (lastSlash > 0) {
                folder = conf.conf_rel_path.substring(0, lastSlash);
            } else {
                folder = 'Root';
            }
        } else {
            // Fallback for backward compatibility
            const pathParts = conf.conf_path.split('/');
            const certoraIndex = pathParts.indexOf('certora');
            if (certoraIndex >= 0 && certoraIndex < pathParts.length - 2) {
                folder = pathParts.slice(certoraIndex + 1, -1).join('/');
            } else {
                folder = 'Root';
            }
        }

        if (!confsByFolder[folder]) {
            confsByFolder[folder] = [];
        }
        confsByFolder[folder].push(conf);
    });

    // Sort folders: "Root" first, then alphabetically
    const sortedFolders = Object.keys(confsByFolder).sort((a, b) => {
        if (a === 'Root') return -1;
        if (b === 'Root') return 1;
        return a.localeCompare(b);
    });

    // Generate HTML
    let html = '';
    sortedFolders.forEach(folder => {
        html += `
            <div class="toc-column">
                <div class="toc-column-title">${folder}</div>
        `;

        confsByFolder[folder].forEach(conf => {
            const confId = `conf-${conf.conf_name.replace(/\./g, '-')}`;
            // Remove .conf extension to save space
            const displayName = conf.conf_name.replace(/\.conf$/, '');
            html += `<a href="#${confId}" class="toc-link" onclick="navigateToConf('${conf.conf_name}', '${confId}'); return false;">${displayName}</a>`;
        });

        html += `</div>`;
    });

    tocContainer.innerHTML = html;
}

// Get runs for a rule that match a specific conf based on conf_path
// Returns array of matching runs (empty if rule shouldn't show in this conf)
function getRunsForRuleInConf(ruleName, confPath, statuses) {
    const ruleStatus = statuses[ruleName];
    if (!ruleStatus) {
        // No status data - show in all confs (backward compatibility)
        return [];
    }

    // Check if any run in available_runs has matching conf_path
    const availableRuns = ruleStatus.available_runs || [];
    if (availableRuns.length === 0) {
        // No runs available - don't show
        return [];
    }

    // Check if ANY run has a specific conf_path set
    const hasAnyConfPathSet = availableRuns.some(run => run.conf_path);

    // Filter runs that match this conf
    const matchingRuns = availableRuns.filter(run => {
        if (!run.conf_path) {
            // No conf_path - only include if NO other runs have conf_path set (backward compat)
            // If some runs have conf_path, don't show null ones in unrelated confs
            return !hasAnyConfPathSet;
        }
        // Compare conf paths
        return run.conf_path === confPath;
    });

    return matchingRuns;
}

// Check if a rule should be shown for a specific conf based on conf_path matching
function shouldShowRuleForConf(ruleName, confPath, statuses) {
    const matchingRuns = getRunsForRuleInConf(ruleName, confPath, statuses);
    return matchingRuns.length > 0;
}

// Count rule statuses for a conf
function countConfStatuses(conf, statuses) {
    const counts = {
        verified: 0,
        violated: 0,
        timeout: 0,
        pending: 0,
        other: 0
    };

    conf.rules.forEach(ruleName => {
        // Skip rules that don't belong to this conf based on conf_path matching
        if (!shouldShowRuleForConf(ruleName, conf.conf_path, statuses)) {
            return;
        }

        const status = statuses[ruleName];
        if (!status) {
            counts.pending++;
            return;
        }

        const overallStatus = status.overall_status;
        if (overallStatus === 'verified') {
            counts.verified++;
        } else if (overallStatus === 'violated') {
            counts.violated++;
        } else if (overallStatus === 'timeout') {
            counts.timeout++;
        } else if (overallStatus === 'pending') {
            counts.pending++;
        } else {
            counts.other++;
        }
    });

    return counts;
}

// Render a single conf section with table
function renderConfSection(conf, data, showFullPaths = false) {
    const confId = `conf-${conf.conf_name.replace(/\./g, '-')}`;
    const isExpanded = expandedConfs.has(conf.conf_name);
    const displayStyle = isExpanded ? 'block' : 'none';
    const toggleIcon = isExpanded ? '▼' : '▶';
    const displayTitle = showFullPaths ? (conf.conf_rel_path || conf.conf_name) : conf.conf_name;

    // Count statuses for this conf
    const statuses = data.statuses || {};
    const statusCounts = countConfStatuses(conf, statuses);

    // Check if conf has any rules with non-matching specs
    let hasSpecDiffIssues = false;
    conf.rules.forEach(ruleName => {
        // Skip rules that don't belong to this conf based on conf_path matching
        if (!shouldShowRuleForConf(ruleName, conf.conf_path, statuses)) {
            return;
        }

        const ruleStatus = statuses[ruleName];
        if (ruleStatus && ruleStatus.spec_diff_equivalent === false) {
            hasSpecDiffIssues = true;
        }
    });

    // Build status badges HTML
    let statusBadges = '';
    if (statusCounts.verified > 0) {
        statusBadges += `<span class="conf-status-badge conf-status-verified">${statusCounts.verified} verified</span>`;
    }
    if (statusCounts.violated > 0) {
        statusBadges += `<span class="conf-status-badge conf-status-violated">${statusCounts.violated} violated</span>`;
    }
    if (statusCounts.timeout > 0) {
        statusBadges += `<span class="conf-status-badge conf-status-timeout">${statusCounts.timeout} timeout</span>`;
    }
    if (statusCounts.pending > 0) {
        statusBadges += `<span class="conf-status-badge conf-status-pending">${statusCounts.pending} pending</span>`;
    }
    if (statusCounts.other > 0) {
        statusBadges += `<span class="conf-status-badge conf-status-other">${statusCounts.other} other</span>`;
    }

    // Add running badge if conf has a running job
    const runningBadge = conf.has_running_job ?
        `<span class="conf-status-badge conf-status-running">🔄 Running</span>` : '';

    // Add spec diff badge if conf has spec differences
    const specDiffBadge = hasSpecDiffIssues ?
        `<span class="conf-status-badge conf-status-spec-diff" title="Some rules have specs that differ from cloud runs">⚠️ Specs differ</span>` : '';

    // Add conf type label (Move or EVM)
    const confType = conf.conf_type || 'EVM';
    const confTypeClass = confType === 'Move' ? 'conf-type-move' : 'conf-type-evm';
    const confTypeLabel = `<span class="conf-type-label ${confTypeClass}">${confType}</span>`;

    let html = `
        <div class="conf-section" id="${confId}">
            <div class="conf-header" onclick="toggleConf('${conf.conf_name}')">
                <div class="conf-header-title">
                    <span class="toggle-icon">${toggleIcon}</span>
                    ${displayTitle}
                    ${confTypeLabel}
                </div>
                <div class="conf-header-stats">
                    ${runningBadge}
                    ${specDiffBadge}
                    ${statusBadges}
                </div>
            </div>
            <div class="conf-content" style="display: ${displayStyle};">
                <table class="conf-table">
                    <thead>
                        <tr>
                            <th>Rule Name</th>
                            <th>Method Name</th>
                            <th>Status</th>
                            <th>Run Link</th>
                            <th>Select Run</th>
                            <th>Actions</th>
                            <th>Comment</th>
                        </tr>
                    </thead>
                    <tbody>
    `;

    // Get unique rules for this conf
    const rules = getUniqueRulesForConf(conf, data);

    rules.forEach(rule => {
        // Get runs specific to this conf
        const confSpecificRuns = getRunsForRuleInConf(rule.name, conf.conf_path, statuses);
        html += renderRuleRow(rule, conf, data, confSpecificRuns);
    });

    html += `
                    </tbody>
                </table>
                <a href="#top" class="back-to-top-btn">⬆ Back to Top</a>
            </div>
        </div>
    `;

    return html;
}

// Get unique rule info for a conf
function getUniqueRulesForConf(conf, data) {
    const rulesMap = new Map();

    // Gather all rules from all specs used by this conf
    conf.all_specs.forEach(specPath => {
        const spec = data.specs[specPath];
        if (spec && spec.rules) {
            spec.rules.forEach(rule => {
                if (!rulesMap.has(rule.name)) {
                    rulesMap.set(rule.name, rule);
                }
            });
        }
    });

    // Filter to only rules that are in the conf's rules list and match this conf's conf_path
    const confRules = [];
    const statuses = data.statuses || {};
    conf.rules.forEach(ruleName => {
        if (rulesMap.has(ruleName) && shouldShowRuleForConf(ruleName, conf.conf_path, statuses)) {
            confRules.push(rulesMap.get(ruleName));
        }
    });

    return confRules;
}

// Format timestamp for dropdown display (DD-MMM-YY HH:MM:SS in local time)
function formatTimestampForDropdown(unixTimestamp) {
    const date = new Date(unixTimestamp * 1000);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    const day = String(date.getDate()).padStart(2, '0');
    const month = months[date.getMonth()];
    const year = String(date.getFullYear()).slice(-2);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
}

// Render run selection dropdown
function renderRunDropdown(ruleName, methodName, availableRuns, selectedJobId, currentMode) {
    if (!availableRuns || availableRuns.length === 0) {
        return '<span style="color: #7f8c8d; font-style: italic;">No runs</span>';
    }

    const dropdownId = methodName
        ? `run-select-${ruleName}-${methodName}`.replace(/[^a-zA-Z0-9-_]/g, '_')
        : `run-select-${ruleName}`.replace(/[^a-zA-Z0-9-_]/g, '_');

    let html = `<select class="run-selector" id="${dropdownId}"
                    data-rule-name="${ruleName}"
                    ${methodName ? `data-method-name="${methodName}"` : ''}
                    data-mode="${currentMode}">`;

    availableRuns.forEach((run, index) => {
        const isLatest = index === 0;
        const isSelected = run.job_id === selectedJobId;
        const jobIdShort = run.job_id.substring(0, 7);
        const timestamp = formatTimestampForDropdown(run.timestamp);
        const status = methodName && run.method_status ? run.method_status : run.overall_status;
        const statusFormatted = formatStatus(status);

        const latestLabel = isLatest ? '[latest] ' : '';
        const optionText = `${latestLabel}${jobIdShort} ${timestamp} ${statusFormatted}`;

        html += `<option value="${run.job_id}" ${isSelected ? 'selected' : ''}>${optionText}</option>`;
    });

    html += '</select>';
    return html;
}

// Render a single rule row
function renderRuleRow(rule, conf, data, confSpecificRuns) {
    const ruleId = `${conf.conf_name}-${rule.name}`;

    // Get status for this rule
    const statuses = data.statuses || {};
    const globalRuleStatus = statuses[rule.name];

    // Use the latest run specific to this conf
    // confSpecificRuns is sorted by timestamp descending, so [0] is latest
    const latestConfRun = confSpecificRuns && confSpecificRuns.length > 0 ? confSpecificRuns[0] : null;

    // Check if user has selected a specific run for this rule
    const userSelectedJobId = globalRuleStatus ? globalRuleStatus.selected_job_id : null;
    let selectedConfRun = null;

    if (userSelectedJobId && confSpecificRuns) {
        // Find the selected run in conf-specific runs
        selectedConfRun = confSpecificRuns.find(run => run.job_id === userSelectedJobId);
    }

    // Use selected run if available, otherwise fall back to latest
    const confRun = selectedConfRun || latestConfRun;

    // Build a ruleStatus object that combines global status with conf-specific run
    // If the global status job_id matches a conf-specific run, use it as-is
    // Otherwise, if we have a conf-specific run, use basic fields from it
    let ruleStatus = globalRuleStatus;
    if (globalRuleStatus && confRun && globalRuleStatus.job_id !== confRun.job_id) {
        // Global status is for a different job than the selected/latest for this conf
        // Use conf-specific run data for basic fields
        ruleStatus = {
            ...globalRuleStatus,
            job_id: confRun.job_id,
            run_url: confRun.run_url,
            overall_status: confRun.overall_status,
            timestamp: confRun.timestamp,
            // Preserve diff statuses from globalRuleStatus - they were loaded via /api/runs/select for the selected job
            spec_diff_equivalent: globalRuleStatus.spec_diff_equivalent,
            conf_diff_equivalent: globalRuleStatus.conf_diff_equivalent,
            source_diff_equivalent: globalRuleStatus.source_diff_equivalent,
            spec_diff_computing: globalRuleStatus.spec_diff_computing,
            spec_diff_error: globalRuleStatus.spec_diff_error,
            conf_diff_computing: globalRuleStatus.conf_diff_computing,
            source_diff_computing: globalRuleStatus.source_diff_computing,
            source_diff_error: globalRuleStatus.source_diff_error,
        };
    }

    // Check if parametric: either marked in spec, or has method_statuses in cloud status
    const hasMethodStatuses = ruleStatus && ruleStatus.method_statuses && Object.keys(ruleStatus.method_statuses).length > 0;
    const isParametric = rule.is_parametric || rule.type === 'invariant' || hasMethodStatuses;
    const isExpanded = expandedRules.has(ruleId);
    const overallStatus = ruleStatus ? ruleStatus.overall_status : 'pending';
    const runUrl = ruleStatus ? ruleStatus.run_url : null;

    // Check if rule is violated
    const isViolated = overallStatus === 'violated';
    const jobId = ruleStatus ? ruleStatus.job_id : null;
    const fullJobId = ruleStatus ? ruleStatus.full_job_id : null;  // Full job ID for diff lookups

    // Get CEX analysis state
    const cexAnalyses = data.cex_analyses || {};
    const analysisKey = jobId ? `${jobId}:${rule.name}` : null;
    const cexAnalysis = analysisKey ? cexAnalyses[analysisKey] : null;

    // Get spec diff status
    const specDiffEquivalent = ruleStatus ? ruleStatus.spec_diff_equivalent : null;
    const specDiffComputing = ruleStatus ? ruleStatus.spec_diff_computing : false;
    const specDiffError = ruleStatus ? ruleStatus.spec_diff_error : null;
    let specDiffIndicator = '';
    if (specDiffComputing) {
        // Computing - show spinner
        specDiffIndicator = `<span class="spec-diff-indicator spec-diff-spinner" title="Computing spec diff..."></span>`;
    } else if (specDiffError) {
        // Error during computation - show error indicator
        const jobIdShort = jobId ? jobId.substring(0, 7) : 'unknown';
        specDiffIndicator = `<span class="diff-badge diff-badge-error" title="Failed to compute spec diff with job ${jobIdShort}: ${specDiffError}">❌</span>`;
    } else if (specDiffEquivalent === false) {
        // Specs differ - show warning (clickable to show diff)
        // Use data attributes to avoid escaping issues in onclick
        specDiffIndicator = `<span class="diff-badge diff-badge-differ" title="Spec differs - click to view diff" data-rule-name="${rule.name.replace(/"/g, '&quot;')}" data-job-id="${jobId || ''}" onclick="event.stopPropagation(); openSpecDiffModal(this.dataset.ruleName, this.dataset.jobId)">🎓</span>`;
    } else if (specDiffEquivalent === true) {
        // Specs match - show graduation cap in green
        specDiffIndicator = `<span class="diff-badge diff-badge-same" title="Spec matches">🎓</span>`;
    }
    // If null or undefined (and not computing/error), don't show any indicator

    // Get conf diff status
    const confDiffEquivalent = ruleStatus ? ruleStatus.conf_diff_equivalent : null;
    const confDiffComputing = ruleStatus ? ruleStatus.conf_diff_computing : false;
    let confDiffIndicator = '';
    if (confDiffComputing) {
        // Computing - show spinner
        confDiffIndicator = `<span class="conf-diff-indicator conf-diff-spinner" title="Computing conf diff..."></span>`;
    } else if (confDiffEquivalent === false) {
        // Confs differ - show warning (clickable to show diff)
        // Use fullJobId for the API call to ensure we match the saved diff file
        confDiffIndicator = `<span class="diff-badge diff-badge-differ" title="Conf differs - click to view diff" data-job-id="${fullJobId || jobId || ''}" onclick="event.stopPropagation(); openConfDiffModal(this.dataset.jobId)">⚙️</span>`;
    } else if (confDiffEquivalent === true) {
        // Confs match - show gear in green
        confDiffIndicator = `<span class="diff-badge diff-badge-same" title="Conf matches">⚙️</span>`;
    }
    // If null or undefined (and not computing), don't show any indicator

    // Get source diff status
    const sourceDiffEquivalent = ruleStatus ? ruleStatus.source_diff_equivalent : null;
    const sourceDiffError = ruleStatus ? ruleStatus.source_diff_error : null;
    const sourceDiffComputing = ruleStatus ? ruleStatus.source_diff_computing : false;
    let sourceDiffIndicator = '';
    if (sourceDiffComputing) {
        // Computing - show spinner
        sourceDiffIndicator = `<span class="source-diff-indicator source-diff-spinner" title="Computing source diff..."></span>`;
    } else if (sourceDiffError) {
        // Error during computation - show error indicator
        const jobIdShort = jobId ? jobId.substring(0, 7) : 'unknown';
        sourceDiffIndicator = `<span class="diff-badge diff-badge-error" title="Failed to compute source diff with job ${jobIdShort}: ${sourceDiffError}">❌</span>`;
    } else if (sourceDiffEquivalent === false) {
        // Sources differ - show warning (clickable to show diff)
        // Use fullJobId for the API call to ensure we match the saved diff file
        sourceDiffIndicator = `<span class="diff-badge diff-badge-differ" title="Source differs - click to view diff" data-job-id="${fullJobId || jobId || ''}" onclick="event.stopPropagation(); openSourceDiffModal(this.dataset.jobId)">📄</span>`;
    } else if (sourceDiffEquivalent === true) {
        // Sources match - show document in green
        sourceDiffIndicator = `<span class="diff-badge diff-badge-same" title="Source matches">📄</span>`;
    }
    // If null or undefined (and not computing/error), don't show any indicator

    // Get ambiguous conf status
    const hasAmbiguousConf = ruleStatus ? ruleStatus.has_ambiguous_conf : false;
    const matchedMainContract = ruleStatus ? ruleStatus.matched_main_contract : '';
    let confAmbiguityIndicator = '';
    if (hasAmbiguousConf) {
        const contractInfo = matchedMainContract ? ` and main contract '${matchedMainContract}'` : '';
        confAmbiguityIndicator = `<span class="conf-ambiguity-indicator" title="Multiple confs match this rule name${contractInfo}. Rename the rule to avoid ambiguity.">❗</span>`;
    }

    // Get cloud rule name and ecosystem from status
    const cloudRuleName = ruleStatus ? ruleStatus.cloud_rule_name : null;
    const ecosystem = ruleStatus ? ruleStatus.ecosystem : 'evm';

    // Render action cell - but skip for parametric rules (they have subrules)
    let actionHtml;
    if (isParametric && ruleStatus && ruleStatus.method_statuses && Object.keys(ruleStatus.method_statuses).length > 0) {
        // Parametric rule with methods - no action for parent
        actionHtml = '-';
    } else {
        // Non-parametric rule or parametric without methods yet - show action
        actionHtml = renderActionCell(overallStatus, jobId, rule.name, null, cexAnalysis, runUrl, cloudRuleName, ecosystem, rule.is_parametric || false);
    }

    // Get available runs and selected job for dropdown
    // Use conf-specific runs instead of all available runs
    const availableRuns = confSpecificRuns || [];
    const selectedJobId = ruleStatus ? ruleStatus.selected_job_id : jobId;
    const dropdownHtml = renderRunDropdown(rule.name, null, availableRuns, selectedJobId, currentMode);

    // Check if showing historical run (non-latest selected)
    // Use the actual displayed job_id, not the globally selected one
    const displayedJobId = ruleStatus ? ruleStatus.job_id : jobId;
    const isHistoricalRun = (availableRuns && availableRuns.length > 0 && displayedJobId !== availableRuns[0]?.job_id);
    const historicalIcon = isHistoricalRun ? '<span class="historical-run-icon" title="Showing historical run">⏪</span>' : '';

    let html = `
        <tr class="rule-row${isParametric ? ' has-drill-down' : ''}${isExpanded ? ' expanded' : ''}"
            data-rule-id="${ruleId}"
            data-is-parametric="${isParametric}">
            <td>
                <div class="rule-name-container">
                    ${isParametric ? `<span class="drill-down-icon${isExpanded ? ' expanded' : ''}">▶</span>` : ''}
                    <span class="rule-name-text" title="${rule.name}">${rule.name}</span>
                    <span class="rule-indicators">
                        ${historicalIcon}
                        ${specDiffIndicator}
                        ${confDiffIndicator}
                        ${sourceDiffIndicator}
                        ${confAmbiguityIndicator}
                    </span>
                </div>
            </td>
            <td>${isParametric ? '' : '-'}</td>
            <td><span class="status-badge status-${overallStatus}"${overallStatus === 'no_status' ? ' title="Select latest run to see aggregated status"' : ''}>${formatStatus(overallStatus)}</span></td>
            <td>${runUrl && jobId ? `<a href="${runUrl}" target="_blank">${jobId.substring(0, 7)}</a>` : '-'}</td>
            <td>${dropdownHtml}</td>
            <td>${actionHtml}</td>
            <td>-</td>
        </tr>
    `;

    // If parametric and expanded, add method rows
    if (isParametric && isExpanded && ruleStatus && ruleStatus.method_statuses) {
        for (const [methodName, methodStatus] of Object.entries(ruleStatus.method_statuses)) {
            const isMethodViolated = methodStatus === 'violated';

            // Get available runs for this method - filter by conf_path to match rule-level behavior
            let methodAvailableRuns = (ruleStatus.method_available_runs && ruleStatus.method_available_runs[methodName]) || [];

            // Apply same conf_path filtering as rule-level dropdown for consistency
            if (methodAvailableRuns.length > 0) {
                // Check if ANY run has conf_path set
                const hasAnyConfPathSet = methodAvailableRuns.some(run => run.conf_path);

                // Filter to match current conf
                methodAvailableRuns = methodAvailableRuns.filter(run => {
                    if (!run.conf_path) {
                        // No conf_path - include only if no other runs have conf_path
                        return !hasAnyConfPathSet;
                    }
                    // Include if matches current conf
                    return run.conf_path === conf.conf_path;
                });
            }

            const methodSelectedJobId = (ruleStatus.method_selected_job_ids && ruleStatus.method_selected_job_ids[methodName]) || jobId;

            const methodDropdownHtml = renderRunDropdown(rule.name, methodName, methodAvailableRuns, methodSelectedJobId, currentMode);

            // Check if showing historical run for this method
            // Determine the actual displayed job: if selected exists in available runs, use it; otherwise use latest
            let methodDisplayedJobId = methodSelectedJobId;
            if (methodAvailableRuns && methodAvailableRuns.length > 0) {
                const selectedExists = methodAvailableRuns.some(r => r.job_id === methodSelectedJobId);
                if (!selectedExists) {
                    methodDisplayedJobId = methodAvailableRuns[0].job_id;
                }
            }
            const isMethodHistoricalRun = (methodAvailableRuns && methodAvailableRuns.length > 0 && methodDisplayedJobId !== methodAvailableRuns[0]?.job_id);
            const methodHistoricalIcon = isMethodHistoricalRun ? '<span class="historical-run-icon" title="Showing historical run">⏪</span>' : '';

            // Get the run URL for this specific method's selected job
            let methodRunUrl = runUrl;
            if (methodSelectedJobId !== jobId && methodAvailableRuns && methodAvailableRuns.length > 0) {
                // Find the run URL for the selected job
                const selectedRun = methodAvailableRuns.find(r => r.job_id === methodSelectedJobId);
                if (selectedRun) {
                    methodRunUrl = selectedRun.run_url;
                }
            }

            // Get CEX analysis for this method (using selected job ID)
            const methodAnalysisKey = methodSelectedJobId ? `${methodSelectedJobId}:${rule.name}:${methodName}` : null;
            const methodCexAnalysis = methodAnalysisKey ? cexAnalyses[methodAnalysisKey] : null;
            const methodActionHtml = renderActionCell(methodStatus, methodSelectedJobId, rule.name, methodName, methodCexAnalysis, methodRunUrl, cloudRuleName, ecosystem, rule.is_parametric || false);

            html += `
                <tr class="method-row">
                    <td></td>
                    <td title="${methodName}">${methodName}${methodHistoricalIcon}</td>
                    <td><span class="status-badge status-${methodStatus}">${formatStatus(methodStatus)}</span></td>
                    <td>${methodRunUrl && methodSelectedJobId ? `<a href="${methodRunUrl}" target="_blank">${methodSelectedJobId.substring(0, 7)}</a>` : '-'}</td>
                    <td>${methodDropdownHtml}</td>
                    <td>${methodActionHtml}</td>
                    <td>-</td>
                </tr>
            `;
        }
    } else if (isParametric && isExpanded) {
        html += `
            <tr class="method-row">
                <td colspan="7" style="text-align: center; color: #7f8c8d; font-style: italic;">
                    No method breakdown available yet
                </td>
            </tr>
        `;
    }

    return html;
}

// Format status for display
function formatStatus(status) {
    const statusMap = {
        'verified': 'Verified',
        'timeout': 'Timeout',
        'violated': 'Violated',
        'vacuity': 'Vacuity',
        'mixed-error': 'Error',
        'unknown': 'Unknown',
        'pending': 'Pending',
        // New statuses for parametric rules (methods/sub-rules)
        'not_run': 'Not Run',      // Method exists in history but wasn't tested in selected job
        'no_status': 'No Status'   // Main rule status when historical run selected for parametric rule
    };
    return statusMap[status] || status;
}

// Attach drill-down listeners
function attachDrillDownListeners() {
    const drillDownRows = document.querySelectorAll('.rule-row.has-drill-down');

    drillDownRows.forEach(row => {
        row.addEventListener('click', handleDrillDownClick);
    });
}

// Attach run selector listeners
function attachRunSelectorListeners() {
    const runSelectors = document.querySelectorAll('.run-selector');

    runSelectors.forEach(select => {
        select.addEventListener('change', handleRunSelectionChange);

        // Prevent dropdown from triggering drill-down on parametric rules
        select.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    });
}

// Handle run selection change
async function handleRunSelectionChange(event) {
    const select = event.target;
    const ruleName = select.dataset.ruleName;
    const methodName = select.dataset.methodName || null;
    const newJobId = select.value;
    const mode = select.dataset.mode || currentMode;

    console.log(`Run selection changed: ${ruleName}${methodName ? ':' + methodName : ''} -> ${newJobId}`);

    // Disable dropdown during update
    select.disabled = true;

    try {
        // Call API to save selection and get updated status
        const settings = loadSettings();
        const response = await fetch('/api/runs/select', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                rule_name: ruleName,
                method_name: methodName,
                job_id: newJobId,
                mode: mode,
                astTimeout: settings.astTimeout
            })
        });

        const result = await response.json();

        if (!result.success) {
            console.error('Failed to select run:', result.error);
            alert(`Failed to select run: ${result.error}`);
            // Re-enable dropdown
            select.disabled = false;
            return;
        }

        console.log('Run selection successful:', result);

        // Update current scan data with new status
        if (currentScanData && currentScanData.statuses && currentScanData.statuses[ruleName]) {
            const updatedStatus = result.updated_status;
            const currentRuleStatus = currentScanData.statuses[ruleName];

            // Preserve the available_runs and method_available_runs data (with defaults)
            const availableRuns = currentRuleStatus.available_runs || [];
            const methodAvailableRuns = currentRuleStatus.method_available_runs || {};
            const methodSelectedJobIds = currentRuleStatus.method_selected_job_ids || {};

            // Update the status fields (but preserve dropdown data)
            // For method-specific updates, only update that method's status
            if (methodName) {
                // Only update the specific method's status
                if (!currentRuleStatus.method_statuses) {
                    currentRuleStatus.method_statuses = {};
                }
                // Get the method status from the updated status
                if (updatedStatus.method_statuses && updatedStatus.method_statuses[methodName]) {
                    currentRuleStatus.method_statuses[methodName] = updatedStatus.method_statuses[methodName];
                }
                // For method-specific changes, preserve all rule-level fields
                // (spec_diff_equivalent, job_id, overall_status, etc. stay the same)
            } else {
                // Rule-level update - update all fields INCLUDING method dropdown data
                currentRuleStatus.overall_status = updatedStatus.overall_status;
                currentRuleStatus.method_statuses = updatedStatus.method_statuses;
                currentRuleStatus.job_id = updatedStatus.job_id;
                currentRuleStatus.timestamp = updatedStatus.timestamp;
                currentRuleStatus.run_url = updatedStatus.run_url;
                currentRuleStatus.job_status = updatedStatus.job_status;
                // Only update spec_diff_equivalent if it's defined in the response
                if (updatedStatus.spec_diff_equivalent !== undefined) {
                    currentRuleStatus.spec_diff_equivalent = updatedStatus.spec_diff_equivalent;
                }
                // Only update conf_diff_equivalent if it's defined in the response
                if (updatedStatus.conf_diff_equivalent !== undefined) {
                    currentRuleStatus.conf_diff_equivalent = updatedStatus.conf_diff_equivalent;
                }
                currentRuleStatus.has_ambiguous_conf = updatedStatus.has_ambiguous_conf;
                currentRuleStatus.matched_main_contract = updatedStatus.matched_main_contract;

                // NEW: Update method dropdown data from server (enables dynamic method list updates)
                // The server now returns complete method data including all methods across all jobs,
                // allowing the UI to show all methods with "not_run" status for historical runs
                // and to revert to latest-per-method when selecting the latest run.
                if (updatedStatus.method_available_runs !== undefined) {
                    currentRuleStatus.method_available_runs = updatedStatus.method_available_runs;
                } else {
                    // Fallback: preserve existing if server didn't send new data
                    currentRuleStatus.method_available_runs = methodAvailableRuns;
                }

                if (updatedStatus.method_selected_job_ids !== undefined) {
                    currentRuleStatus.method_selected_job_ids = updatedStatus.method_selected_job_ids;
                } else {
                    // Fallback: preserve existing if server didn't send new data
                    currentRuleStatus.method_selected_job_ids = methodSelectedJobIds;
                }
            }

            // Restore rule-level available_runs (always preserve this)
            currentRuleStatus.available_runs = availableRuns;

            // Update the selected job ID
            if (methodName) {
                if (!currentRuleStatus.method_selected_job_ids) {
                    currentRuleStatus.method_selected_job_ids = {};
                }
                currentRuleStatus.method_selected_job_ids[methodName] = newJobId;
            } else {
                currentRuleStatus.selected_job_id = newJobId;
            }

            // Handle spec diff status
            if (result.spec_diff_status === 'computing') {
                console.log('Spec diff computing, starting poll...');
                // Set computing flag to show spinner
                currentRuleStatus.spec_diff_computing = true;
                startDiffPolling(newJobId, ruleName);
            } else if (result.spec_diff_status === 'failed') {
                console.error('Spec diff computation failed:', result.spec_diff_error);
                // Set error flag to show error indicator
                currentRuleStatus.spec_diff_computing = false;
                currentRuleStatus.spec_diff_error = result.spec_diff_error || 'Unknown error';
            } else {
                // Status is 'available' or 'unknown' - clear flags
                currentRuleStatus.spec_diff_computing = false;
                currentRuleStatus.spec_diff_error = null;
            }

            // Handle conf diff status
            if (result.conf_diff_status === 'computing') {
                console.log('Conf diff computing...');
                currentRuleStatus.conf_diff_computing = true;
            } else if (result.conf_diff_status === 'failed') {
                console.error('Conf diff computation failed');
                currentRuleStatus.conf_diff_computing = false;
            } else {
                currentRuleStatus.conf_diff_computing = false;
            }

            // Handle source diff status
            if (result.source_diff_status === 'computing') {
                console.log('Source diff computing...');
                currentRuleStatus.source_diff_computing = true;
            } else if (result.source_diff_status === 'failed') {
                console.error('Source diff computation failed:', result.source_diff_error);
                currentRuleStatus.source_diff_computing = false;
                currentRuleStatus.source_diff_error = result.source_diff_error || 'Unknown error';
            } else {
                currentRuleStatus.source_diff_computing = false;
                currentRuleStatus.source_diff_error = null;
            }

            // Re-render dashboard with updated data
            renderDashboard(currentScanData);
        }

    } catch (error) {
        console.error('Error selecting run:', error);
        alert(`Error selecting run: ${error.message}`);
        select.disabled = false;
    }
}

// Poll for spec/conf/source diff completion
async function startDiffPolling(jobId, ruleName) {
    const maxAttempts = 60; // Poll for up to 5 minutes (5 second intervals)
    let attempts = 0;

    const pollInterval = setInterval(async () => {
        attempts++;

        if (attempts > maxAttempts) {
            console.log('Diff polling timeout');
            clearInterval(pollInterval);
            return;
        }

        try {
            const response = await fetch(`/api/runs/diff-status?job_id=${encodeURIComponent(jobId)}&rule_name=${encodeURIComponent(ruleName)}`);
            const result = await response.json();

            if (result.status === 'completed') {
                console.log('All diffs completed:', result);
                clearInterval(pollInterval);

                // Update the status in current data
                if (currentScanData && currentScanData.statuses && currentScanData.statuses[ruleName]) {
                    currentScanData.statuses[ruleName].spec_diff_equivalent = result.spec_diff_equivalent;
                    currentScanData.statuses[ruleName].spec_diff_computing = false;
                    currentScanData.statuses[ruleName].conf_diff_equivalent = result.conf_diff_equivalent;
                    currentScanData.statuses[ruleName].conf_diff_computing = false;
                    currentScanData.statuses[ruleName].source_diff_equivalent = result.source_diff_equivalent;
                    currentScanData.statuses[ruleName].source_diff_computing = false;

                    // Re-render to show updated diff indicators
                    renderDashboard(currentScanData);
                }
            } else if (result.status === 'failed') {
                console.error('Diff computation failed:', result);
                clearInterval(pollInterval);

                // Clear computing flags and set errors on failure
                if (currentScanData && currentScanData.statuses && currentScanData.statuses[ruleName]) {
                    currentScanData.statuses[ruleName].spec_diff_computing = false;
                    currentScanData.statuses[ruleName].spec_diff_error = result.spec_diff_error || 'Unknown error';
                    currentScanData.statuses[ruleName].conf_diff_computing = false;
                    currentScanData.statuses[ruleName].source_diff_computing = false;
                    currentScanData.statuses[ruleName].source_diff_error = result.source_diff_error || 'Unknown error';
                    renderDashboard(currentScanData);
                }
            }
            // Otherwise keep polling (status is 'computing')

        } catch (error) {
            console.error('Error polling diff status:', error);
            clearInterval(pollInterval);
        }
    }, 5000); // Poll every 5 seconds
}

// Handle drill-down click
function handleDrillDownClick(event) {
    const row = event.currentTarget;
    const ruleId = row.dataset.ruleId;

    if (expandedRules.has(ruleId)) {
        expandedRules.delete(ruleId);
    } else {
        expandedRules.add(ruleId);
    }

    // Save state and re-render
    saveState();
    renderDashboard(currentScanData);
}

// Toggle conf expanded/collapsed
function toggleConf(confName) {
    if (expandedConfs.has(confName)) {
        expandedConfs.delete(confName);
    } else {
        expandedConfs.add(confName);
    }

    // Save state and re-render
    saveState();
    renderDashboard(currentScanData);
}

// Navigate to conf from TOC - expand if needed
function navigateToConf(confName, confId) {
    // Ensure conf is expanded
    if (!expandedConfs.has(confName)) {
        expandedConfs.add(confName);
        saveState();
        renderDashboard(currentScanData);
    }

    // Scroll to the conf section
    setTimeout(() => {
        const element = document.getElementById(confId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 100);
}

// Switch mode between local and remote
async function switchMode(newMode) {
    if (newMode === currentMode) {
        return; // Already in this mode
    }

    currentMode = newMode;
    updateModeUI();
    saveState();

    // Reload data with new mode
    await loadScanData();
}

// Update UI to reflect current mode
function updateModeUI() {
    const modeLocalBtn = document.getElementById('mode-local');
    const modeAllBtn = document.getElementById('mode-all');

    if (currentMode === 'local') {
        modeLocalBtn.classList.add('active');
        modeAllBtn.classList.remove('active');
    } else {
        modeLocalBtn.classList.remove('active');
        modeAllBtn.classList.add('active');
    }
}

// Handle refresh button click
async function handleRefreshClick() {
    console.log('=== handleRefreshClick called ===');
    const btn = document.getElementById('refresh-btn');
    btn.disabled = true;
    btn.textContent = 'Refreshing...';

    try {
        const settings = loadSettings();
        const allUsers = settings.userFilter === 'all-users';
        const lookbackDays = settings.lookbackDays;
        const astTimeout = settings.astTimeout;

        console.log('Fetching /api/scan/refresh...');
        const response = await fetch('/api/scan/refresh', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mode: currentMode,
                allUsers: allUsers,
                lookbackDays: lookbackDays,
                astTimeout: astTimeout
            })
        });
        const result = await response.json();
        console.log('Refresh API result:', result);

        if (result.success) {
            console.log('Refresh successful, starting polling...');
            showStatusMessage('Scan started, syncing cloud data...', 'info');
            // Start polling for progress immediately
            startProgressPolling();
            // Also check scan progress immediately (scan starts before sync)
            checkScanProgress();
            console.log('After startProgressPolling() and checkScanProgress()');
        } else {
            console.log('Refresh failed:', result.message);
            showError(result.message || 'Failed to start scan');
        }
    } catch (error) {
        console.error('Error refreshing scan:', error);
        showError('Failed to refresh scan');
    } finally {
        btn.disabled = false;
        btn.textContent = 'Refresh Scan';
    }
}

// Start polling for status changes
function startStatusPolling() {
    // Check every 60 seconds
    setInterval(checkStatus, 60000);
}

// Check if scan is up-to-date
async function checkStatus() {
    try {
        const response = await fetch('/api/status/check');
        const status = await response.json();

        // Only show message if there are actual changes (not 0 files)
        if (!status.is_up_to_date && (status.changed_count > 0 || status.affected_count > 0)) {
            showStatusMessage(
                `Spec files have changed (${status.changed_count} file${status.changed_count !== 1 ? 's' : ''}). ` +
                `${status.affected_count} conf file${status.affected_count !== 1 ? 's are' : ' is'} affected. ` +
                `Click "Refresh Scan" to update.`,
                'warning'
            );
        } else {
            hideStatusMessage();
        }
    } catch (error) {
        console.error('Error checking status:', error);
    }
}

// Track current status message (so we can check if it's been dismissed)
let currentStatusMessage = null;

// Show status message
function showStatusMessage(message, type = 'info') {
    const banner = document.getElementById('status-banner');
    const text = document.getElementById('status-text');
    const icon = banner.querySelector('.status-icon');

    // If showing the same message that was already displayed, don't re-show
    // (user may have dismissed it)
    if (currentStatusMessage && currentStatusMessage.message === message && currentStatusMessage.dismissed) {
        return;
    }

    // Set message
    text.textContent = message;
    banner.className = `status-banner status-${type}`;

    // Set icon based on type
    const icons = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️'
    };
    icon.textContent = icons[type] || icons['info'];

    // Track current message
    currentStatusMessage = { message, type, dismissed: false };
}

// Dismiss status message (user clicks X)
function dismissStatusMessage() {
    const banner = document.getElementById('status-banner');
    banner.className = 'status-banner hidden';

    // Mark current message as dismissed
    if (currentStatusMessage) {
        currentStatusMessage.dismissed = true;
    }
}

// Hide status message (programmatic - only if not manually shown)
function hideStatusMessage() {
    // Only hide if there's no current message or it was auto-generated
    if (!currentStatusMessage || currentStatusMessage.dismissed) {
        const banner = document.getElementById('status-banner');
        banner.className = 'status-banner hidden';
        currentStatusMessage = null;
    }
}

// Show error message
function showError(message) {
    showStatusMessage(message, 'error');
}

// Update last updated timestamps
function updateLastUpdated(fileScanTimestamp, cloudSyncTimestamp) {
    // Update file scan timestamp
    const fileScanDate = new Date(fileScanTimestamp * 1000);
    const fileScanFormatted = fileScanDate.toLocaleString();
    document.getElementById('last-file-scan').textContent = `Last file scan: ${fileScanFormatted}`;

    // Update cloud sync timestamp
    if (cloudSyncTimestamp && cloudSyncTimestamp > 0) {
        const cloudSyncDate = new Date(cloudSyncTimestamp * 1000);
        const cloudSyncFormatted = cloudSyncDate.toLocaleString();
        document.getElementById('last-cloud-sync').textContent = `Last synced job submitted: ${cloudSyncFormatted}`;
    } else {
        document.getElementById('last-cloud-sync').textContent = `Last synced job submitted: Never`;
    }
}

// Render action cell (button based on status)
function renderActionCell(status, jobId, ruleName, methodName, cexAnalysis, runUrl, cloudRuleName, ecosystem, isParametric) {
    // For unknown status - show nothing
    if (status === 'unknown' || status === 'pending') {
        return '-';
    }

    // For violated rules - CEX analysis
    if (status === 'violated') {
        if (!jobId || !runUrl) {
            return '-';
        }

        // For Move, always use the base cloud rule name (without method suffix)
        // The method will be passed separately via the method parameter
        let effectiveCloudRuleName = cloudRuleName;

        // Check if analysis exists
        if (cexAnalysis) {
            if (cexAnalysis.status === 'running') {
                // Check if analysis has been running for more than 10 minutes
                const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
                const runningTime = currentTime - cexAnalysis.timestamp;
                const waitMinutesInSeconds = 10 * 60;

                if (runningTime > waitMinutesInSeconds) {
                    // Show retry button for stuck analysis
                    const methodArg = methodName ? `, '${methodName}'` : ', null';
                    const runUrlArg = runUrl ? `, '${runUrl}'` : ', null';
                    const cloudRuleNameArg = effectiveCloudRuleName ? `, '${effectiveCloudRuleName}'` : ', null';
                    const ecosystemArg = ecosystem ? `, '${ecosystem}'` : ', null';
                    return `<button class="cex-btn cex-failed" onclick="launchCexAnalyzer('${jobId}', '${ruleName}', event${methodArg}${runUrlArg}${cloudRuleNameArg}${ecosystemArg})" title="Analysis running for ${Math.floor(runningTime / 60)} minutes">Retry (Stuck)</button>`;
                }

                // Show loading spinner
                return `<span class="cex-loading">Analyzing...</span>`;
            } else if (cexAnalysis.status === 'completed' && cexAnalysis.output_file) {
                // Show link to open modal
                const fileName = cexAnalysis.output_file.split('/').pop();
                const title = methodName ? `${ruleName} - ${methodName}` : ruleName;
                const runUrlArg = runUrl ? `'${runUrl}'` : 'null';
                return `<a href="#" onclick="openCexModal('/${cexAnalysis.output_file}', '${title}', ${runUrlArg}); return false;" class="cex-link">View Analysis</a>`;
            } else if (cexAnalysis.status === 'failed') {
                // Show failed state with retry button
                const methodArg = methodName ? `, '${methodName}'` : ', null';
                const runUrlArg = runUrl ? `, '${runUrl}'` : ', null';
                const cloudRuleNameArg = effectiveCloudRuleName ? `, '${effectiveCloudRuleName}'` : ', null';
                const ecosystemArg = ecosystem ? `, '${ecosystem}'` : ', null';
                return `<button class="cex-btn cex-failed" onclick="launchCexAnalyzer('${jobId}', '${ruleName}', event${methodArg}${runUrlArg}${cloudRuleNameArg}${ecosystemArg})">Retry</button>`;
            }
        }

        // No analysis - show analyze button
        const methodArg = methodName ? `, '${methodName}'` : ', null';
        const runUrlArg = runUrl ? `, '${runUrl}'` : ', null';
        const cloudRuleNameArg = effectiveCloudRuleName ? `, '${effectiveCloudRuleName}'` : ', null';
        const ecosystemArg = ecosystem ? `, '${ecosystem}'` : ', null';
        return `<button class="cex-btn" onclick="launchCexAnalyzer('${jobId}', '${ruleName}', event${methodArg}${runUrlArg}${cloudRuleNameArg}${ecosystemArg})">Analyze</button>`;
    }

    // For verified rules - show disabled "Check coverage" button
    if (status === 'verified') {
        return `<button class="action-btn action-btn-disabled" disabled>Check coverage</button>`;
    }

    // For sanity/vacuity failures - show disabled "Check coverage" button
    if (status === 'vacuity') {
        return `<button class="action-btn action-btn-disabled" disabled>Check coverage</button>`;
    }

    // For timeout rules - show "Crack timeout" button or timeouter status
    if (status === 'timeout') {
        // Determine if we should pass --method or --rule only
        const isMethodLevel = isParametric && methodName;
        const useMethod = isMethodLevel;

        // Calculate run key to check timeouter status
        let runKey;
        if (useMethod && methodName) {
            runKey = `${jobId}_${ruleName}_${methodName}`;
        } else {
            runKey = `${jobId}_${ruleName}_fullrule`;
        }

        // Check if we have timeouter status for this run
        const timeouter_runs = window.currentData?.timeouter_runs || {};
        const timeouterRun = timeouter_runs[runKey];

        if (timeouterRun) {
            const status = timeouterRun.status;

            if (status === 'launching') {
                // Show spinner and start polling
                setTimeout(() => {
                    const element = document.querySelector(`[data-run-key="${runKey}"]`);
                    if (element) {
                        startTimeouterPolling(runKey, element);
                    }
                }, 100);
                return `<span data-run-key="${runKey}"><span class="spec-diff-spinner"></span> Starting...</span>`;
            } else if (status === 'running') {
                // Show spinner with elapsed time and start polling
                const elapsed_seconds = Math.floor(Date.now() / 1000) - timeouterRun.timestamp;
                const elapsed_minutes = Math.floor(elapsed_seconds / 60);
                setTimeout(() => {
                    const element = document.querySelector(`[data-run-key="${runKey}"]`);
                    if (element) {
                        startTimeouterPolling(runKey, element);
                    }
                }, 100);
                return `<span data-run-key="${runKey}"><span class="spec-diff-spinner"></span> Running for ${elapsed_minutes} min...</span>`;
            } else if (status === 'completed' && timeouterRun.group_url) {
                // Show link to results
                return `<a href="${timeouterRun.group_url}" target="_blank" class="action-btn">View results</a>`;
            } else if (status === 'failed') {
                // Show failed indicator
                return `<span class="action-btn action-btn-disabled">Failed</span>`;
            }
        }

        // No timeouter run exists - show launch button
        if (isMethodLevel) {
            // Parametric rule method - pass --method
            return `<button class="action-btn" onclick="launchTimeouter('${jobId}', '${ruleName}', '${methodName}', '${runUrl}', true, event)">Crack timeout</button>`;
        } else {
            // Non-parametric or assertion - pass --rule only
            return `<button class="action-btn" onclick="launchTimeouter('${jobId}', '${ruleName}', null, '${runUrl}', false, event)">Crack timeout (full rule)</button>`;
        }
    }

    // For mixed-error or other statuses - show nothing
    return '-';
}

// Launch CEX analyzer for a violated rule
async function launchCexAnalyzer(jobId, ruleName, event, methodName = null, runUrl = null, cloudRuleName = null, ecosystem = null) {
    // Prevent event propagation to avoid triggering drill-down
    if (event) {
        event.stopPropagation();
    }

    const btn = event.target;

    // Immediately change to "Analyzing..." for instant feedback
    btn.disabled = true;
    const originalHtml = btn.parentElement.innerHTML;
    btn.parentElement.innerHTML = '<span class="cex-loading">Analyzing...</span>';

    try {
        const response = await fetch('/api/cexanalyzer/launch', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                job_id: jobId,
                rule_name: ruleName,
                method_name: methodName,
                run_url: runUrl,
                cloud_rule_name: cloudRuleName,
                ecosystem: ecosystem
            })
        });

        const result = await response.json();

        if (response.ok) {
            // Check if analysis was actually launched or already running
            if (result.was_launched) {
                showStatusMessage('CEX Analyzer launched successfully', 'success');
            } else {
                showStatusMessage('CEX analysis already running for this rule', 'info');
            }
            // Keep "Analyzing..." state - it will be updated on next scan refresh
            // Refresh dashboard data (the "Analyzing..." will persist)
            await loadScanData();
            // Start polling for completion if not already polling
            startCexPolling();
        } else {
            // Restore button on error
            showError(result.error || 'Failed to launch CEX Analyzer');
            btn.parentElement.innerHTML = originalHtml;
        }
    } catch (error) {
        // Restore button on error
        showError(`Error launching CEX Analyzer: ${error.message}`);
        btn.parentElement.innerHTML = originalHtml;
    }
}

// Launch timeouter to crack a timeout
async function launchTimeouter(jobId, ruleName, methodName, runUrl, useMethod, event) {
    // Prevent event propagation to avoid triggering drill-down
    if (event) {
        event.stopPropagation();
    }

    const btn = event.target;

    // Calculate run key
    let runKey;
    if (useMethod && methodName) {
        runKey = `${jobId}_${ruleName}_${methodName}`;
    } else {
        runKey = `${jobId}_${ruleName}_fullrule`;
    }

    // Immediately change to spinner for instant feedback
    btn.disabled = true;
    const originalHtml = btn.parentElement.innerHTML;
    btn.parentElement.setAttribute('data-run-key', runKey);
    btn.parentElement.innerHTML = '<span class="spec-diff-spinner"></span> Starting...';

    try {
        const response = await fetch('/api/timeouter/launch', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                job_id: jobId,
                rule_name: ruleName,
                method_name: methodName,
                run_url: runUrl,
                use_method: useMethod
            })
        });

        const result = await response.json();

        if (response.ok) {
            if (result.was_launched) {
                // Started new run - begin polling
                showStatusMessage(result.message || 'Timeouter started', 'success');
            } else {
                // Already running - show current status
                showStatusMessage(result.message || 'Timeouter already running', 'info');
            }

            // Refresh dashboard data to update window.currentData.timeouter_runs
            // This ensures the UI stays consistent if user navigates away and back
            await loadScanData();

            // Start polling for status updates (data is now loaded)
            startCexPolling(); // Also restart CEX polling to pick up new data

            if (result.status !== "completed") {
                // Start timeouter polling for this specific run
                // Find the element again after re-render
                const element = document.querySelector(`[data-run-key="${runKey}"]`);
                if (element) {
                    startTimeouterPolling(runKey, element);
                }
            }
            // If completed, the re-rendered UI will show the "View results" link
        } else {
            // Restore button on error
            showError(result.error || 'Failed to launch timeouter');
            btn.parentElement.innerHTML = originalHtml;
            btn.parentElement.removeAttribute('data-run-key');
        }
    } catch (error) {
        // Restore button on error
        showError(`Error launching timeouter: ${error.message}`);
        btn.parentElement.innerHTML = originalHtml;
        btn.parentElement.removeAttribute('data-run-key');
    }
}

// Start polling for timeouter status updates
function startTimeouterPolling(runKey, element) {
    /**
     * Poll the backend every 10 seconds to check timeouter status.
     * Updates the UI with elapsed time and replaces with results link when complete.
     *
     * @param runKey - Unique identifier for the timeouter run
     * @param element - DOM element to update with status
     */

    // Initialize polling storage if needed
    if (!window.timeouterPolls) {
        window.timeouterPolls = {};
    }

    // Clear any existing poll for this run key
    if (window.timeouterPolls[runKey]) {
        clearInterval(window.timeouterPolls[runKey]);
    }

    // Poll every 10 seconds
    const pollInterval = setInterval(async () => {
        try {
            const response = await fetch(`/api/timeouter/status/${encodeURIComponent(runKey)}`);

            if (!response.ok) {
                if (response.status === 404) {
                    // Run not found - stop polling
                    clearInterval(pollInterval);
                    delete window.timeouterPolls[runKey];
                    return;
                }
                throw new Error(`HTTP ${response.status}`);
            }

            const data = await response.json();

            if (!data.success) {
                console.error('Polling error:', data.error);
                return;
            }

            if (data.status === "launching") {
                // Still launching - show spinner with text next to it
                element.innerHTML = '<span class="spec-diff-spinner"></span> Starting...';
            } else if (data.status === "running") {
                // Update spinner with elapsed time next to it
                const minutes = data.elapsed_minutes;
                element.innerHTML = `<span class="spec-diff-spinner"></span> Running for ${minutes} min...`;
            } else if (data.status === "completed") {
                // Stop polling
                clearInterval(pollInterval);
                delete window.timeouterPolls[runKey];

                // Show results link
                if (data.group_url) {
                    element.innerHTML = `<a href="${data.group_url}" target="_blank" rel="noopener noreferrer"
                                          class="action-btn" onclick="event.stopPropagation()">View results</a>`;
                    showStatusMessage('Timeouter completed! Click to view results.', 'success');
                } else {
                    element.innerHTML = '<span class="action-btn action-btn-disabled">Completed</span>';
                }
            } else if (data.status === "failed") {
                // Stop polling
                clearInterval(pollInterval);
                delete window.timeouterPolls[runKey];

                // Show error
                element.innerHTML = '<span class="action-btn action-btn-disabled" title="Timeouter failed - check logs">Failed</span>';
                showError('Timeouter failed. Check dashboard logs for details.');
            }
        } catch (error) {
            console.error('Timeouter polling error:', error);
            // Don't stop polling on error - might be temporary network issue
        }
    }, 10000); // Poll every 10 seconds

    // Store interval ID
    window.timeouterPolls[runKey] = pollInterval;

    // Do first poll immediately
    setTimeout(async () => {
        try {
            const response = await fetch(`/api/timeouter/status/${encodeURIComponent(runKey)}`);
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.status === "running") {
                    const minutes = data.elapsed_minutes;
                    element.innerHTML = `<span class="spec-diff-spinner"></span> Running for ${minutes} min...`;
                }
            }
        } catch (error) {
            console.error('Initial poll error:', error);
        }
    }, 1000); // First poll after 1 second
}

// Resume polling for any running timeouts on page load
function resumeTimeouterPolling(timeouter_runs) {
    /**
     * Called on page load to resume polling for any in-progress timeouter runs.
     * Finds the corresponding table elements and starts polling.
     *
     * @param timeouter_runs - Dictionary of run_key -> TimeouterRunInfo
     */
    if (!timeouter_runs) return;

    for (const [runKey, runInfo] of Object.entries(timeouter_runs)) {
        // Only resume polling for launching/running statuses
        if (runInfo.status !== "launching" && runInfo.status !== "running") {
            continue;
        }

        console.log(`Resuming timeouter polling for: ${runKey}, status: ${runInfo.status}`);

        // Find the element with this run key (set by renderActionCell)
        // We use setTimeout to ensure DOM has been rendered
        setTimeout(() => {
            const element = document.querySelector(`[data-run-key="${runKey}"]`);
            if (element) {
                console.log(`Found element for ${runKey}, starting poll`);
                startTimeouterPolling(runKey, element);
            } else {
                console.log(`Element not found for ${runKey} - may be in collapsed section`);
            }
        }, 200);
    }
}

// Toggle Table of Contents visibility
function toggleToC() {
    const tocContainer = document.getElementById('toc-container');
    const tocToggle = document.getElementById('toc-toggle');

    if (tocContainer.style.display === 'none') {
        tocContainer.style.display = 'grid';
        tocToggle.classList.remove('collapsed');
    } else {
        tocContainer.style.display = 'none';
        tocToggle.classList.add('collapsed');
    }
}

// Conf Diff Modal Functions
async function openConfDiffModal(jobId) {
    const modal = document.getElementById('conf-diff-modal');
    const modalTitle = document.getElementById('conf-diff-modal-title');
    const modalBody = document.getElementById('conf-diff-modal-body');

    modalTitle.innerHTML = `Configuration Differences`;
    modalBody.innerHTML = '<div class="loading">Loading diff...</div>';
    modal.style.display = 'block';

    try {
        const url = `/api/scan/conf-diff/${encodeURIComponent(jobId)}`;
        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
            modalBody.innerHTML = `<div class="error-message">${data.error || 'Failed to load diff'}</div>`;
            return;
        }

        if (!data.diff_data) {
            modalBody.innerHTML = `<div class="info-message">No detailed diff data available. ${data.reason || ''}</div>`;
            return;
        }

        // Update modal title to include job_id for transparency
        modalTitle.innerHTML = `
            Configuration Differences
            <br>
            <small style="font-size: 14px; color: #7f8c8d; font-weight: normal;">Job: ${data.job_id}</small>
        `;

        // Render the diff
        modalBody.innerHTML = renderConfDiff(data.diff_data);
    } catch (error) {
        console.error('Error loading conf diff:', error);
        modalBody.innerHTML = `<div class="error-message">Error loading diff: ${error.message}</div>`;
    }
}

function closeConfDiffModal() {
    const modal = document.getElementById('conf-diff-modal');
    modal.style.display = 'none';
}

function renderConfDiff(diffData) {
    if (!diffData) {
        return '<div class="info-message">No diff data available</div>';
    }

    let html = '<div class="conf-diff-container">';

    // Get JSON strings for both configs
    const beforeJson = JSON.stringify(diffData.before, null, 2);
    const afterJson = JSON.stringify(diffData.after, null, 2);

    // Split into lines for line-by-line comparison
    const beforeLines = beforeJson.split('\n');
    const afterLines = afterJson.split('\n');

    // Create unified diff view
    html += '<div class="conf-diff-unified">';
    html += renderUnifiedDiff(beforeLines, afterLines);
    html += '</div>';

    html += '</div>'; // end conf-diff-container

    return html;
}

// Source Diff Modal Functions
async function openSourceDiffModal(jobId) {
    const modal = document.getElementById('source-diff-modal');
    const modalTitle = document.getElementById('source-diff-modal-title');
    const modalBody = document.getElementById('source-diff-modal-body');

    modalTitle.innerHTML = `Source File Differences`;
    modalBody.innerHTML = '<div class="loading">Loading diff...</div>';
    modal.style.display = 'block';

    try {
        const url = `/api/scan/source-diff/${encodeURIComponent(jobId)}`;
        const response = await fetch(url);
        const data = await response.json();

        console.log('Source diff data received:', {
            equivalent: data.equivalent,
            path_replacement: data.path_replacement,
            file_diffs_count: data.file_diffs ? data.file_diffs.length : 0
        });

        if (!response.ok) {
            modalBody.innerHTML = `<div class="error-message">${data.error || 'Failed to load diff'}</div>`;
            return;
        }

        if (data.equivalent === null) {
            modalBody.innerHTML = `<div class="info-message">Could not compare sources. ${data.reason || ''}</div>`;
            return;
        }

        if (data.equivalent === true) {
            modalBody.innerHTML = `<div class="info-message">No source differences found. Local and remote sources match.</div>`;
            return;
        }

        // Update modal title to include job_id for transparency
        modalTitle.innerHTML = `
            Source File Differences
            <br>
            <small style="font-size: 14px; color: #7f8c8d; font-weight: normal;">Job: ${data.job_id}</small>
        `;

        // Render the diff (with path replacement notice if applicable)
        modalBody.innerHTML = renderSourceDiff(data.file_diffs, data.path_replacement);
    } catch (error) {
        console.error('Error loading source diff:', error);
        modalBody.innerHTML = `<div class="error-message">Error loading diff: ${error.message}</div>`;
    }
}

function closeSourceDiffModal() {
    const modal = document.getElementById('source-diff-modal');
    modal.style.display = 'none';
    window.currentSourceDiffs = null;
}

function selectSourceFile(filePath) {
    // Find the file in the stored diffs
    const file = window.currentSourceDiffs.find(f => f.path === filePath);
    if (!file) {
        console.error('File not found:', filePath);
        return;
    }

    // Update selection highlight
    document.querySelectorAll('.file-tree-item.clickable').forEach(item => {
        item.classList.remove('selected');
    });
    const selectedItem = document.querySelector(`.file-tree-item[data-file-path="${filePath}"]`);
    if (selectedItem) {
        selectedItem.classList.add('selected');
    }

    // Render the diff in the viewer
    const viewer = document.querySelector('.source-diff-viewer');
    if (!viewer) return;

    let html = '<div class="file-diff-section">';

    // Build header with navigation
    html += `<div class="file-diff-header">`;
    html += `<span class="file-path">${escapeHtml(file.path)}</span>`;
    html += `<div class="diff-navigation">`;
    html += `<button id="prev-diff-btn" class="diff-nav-btn" onclick="navigateToDiff(-1)" title="Previous change">↑ Prev</button>`;
    html += `<span id="diff-position" class="diff-position-text"></span>`;
    html += `<button id="next-diff-btn" class="diff-nav-btn" onclick="navigateToDiff(1)" title="Next change">↓ Next</button>`;
    html += `</div>`;
    html += `</div>`;

    if (file.status === 'modified') {
        // Render unified diff for modified files
        const localLines = file.local_lines || [];
        const remoteLines = file.remote_lines || [];
        html += renderUnifiedDiff(localLines, remoteLines);
    } else if (file.status === 'added') {
        // Show all lines as added
        const remoteLines = file.remote_lines || [];
        html += renderUnifiedDiff([], remoteLines);
    } else if (file.status === 'removed') {
        // Show all lines as removed
        const localLines = file.local_lines || [];
        html += renderUnifiedDiff(localLines, []);
    }

    html += '</div>';
    viewer.innerHTML = html;

    // Initialize diff navigation (scoped to this viewer only)
    initializeDiffNavigation(viewer);
}

function renderSourceDiff(fileDiffs, pathReplacement) {
    console.log('renderSourceDiff called with:', {
        fileDiffs_count: fileDiffs ? fileDiffs.length : 0,
        pathReplacement: pathReplacement
    });

    if (!fileDiffs || fileDiffs.length === 0) {
        return '<div class="info-message">No file differences found</div>';
    }

    // Store file diffs globally for click handler access
    window.currentSourceDiffs = fileDiffs;

    // Initialize collapsed folders state
    if (!window.collapsedFolders) {
        window.collapsedFolders = new Set();
    }

    let html = '';

    // Show path replacement notice if applicable
    if (pathReplacement && pathReplacement.from && pathReplacement.to) {
        console.log('Adding path replacement notice to HTML');
        html += `<div class="path-replacement-notice">
            <strong>Note:</strong> Path adjusted for comparison: <code>${escapeHtml(pathReplacement.from)}</code> → <code>${escapeHtml(pathReplacement.to)}</code>
        </div>`;
    } else {
        console.log('No path replacement to display');
    }

    html += '<div class="source-diff-container">';

    // Build file tree structure
    const fileTree = buildFileTree(fileDiffs);

    // Render file tree on left
    html += '<div class="source-file-tree">';
    html += '<h3>Changed Files</h3>';
    html += renderFileTree(fileTree, fileDiffs);
    html += '</div>';

    // Render diff viewer on right (initially shows placeholder)
    html += '<div class="source-diff-viewer">';
    html += '<div class="source-diff-viewer-placeholder">Select a file to view its diff</div>';
    html += '</div>';

    html += '</div>'; // end source-diff-container

    return html;
}

function buildFileTree(fileDiffs) {
    const tree = {};

    for (const file of fileDiffs) {
        const parts = file.path.split('/');
        let current = tree;

        for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            if (i === parts.length - 1) {
                // Leaf node (file) - store file path for click handler
                current[part] = {
                    status: file.status,
                    isFile: true,
                    path: file.path
                };
            } else {
                // Directory node
                if (!current[part]) {
                    current[part] = { isFile: false, children: {} };
                }
                current = current[part].children;
            }
        }
    }

    return tree;
}

function renderFileTree(tree, fileDiffs, indent = 0, pathPrefix = '') {
    let html = '<ul class="file-tree-list">';

    const entries = Object.entries(tree).sort((a, b) => {
        // Directories first, then files
        const aIsFile = a[1].isFile;
        const bIsFile = b[1].isFile;
        if (aIsFile !== bIsFile) return aIsFile ? 1 : -1;
        return a[0].localeCompare(b[0]);
    });

    for (const [name, node] of entries) {
        if (node.isFile) {
            // File node - make it clickable
            let statusClass = '';
            let statusIcon = '';
            if (node.status === 'added') {
                statusClass = 'file-status-added';
                statusIcon = '+ ';
            } else if (node.status === 'removed') {
                statusClass = 'file-status-removed';
                statusIcon = '- ';
            } else if (node.status === 'modified') {
                statusClass = 'file-status-modified';
                statusIcon = '~ ';
            }

            // Get the full file object to access line stats
            const fileObj = window.currentSourceDiffs.find(f => f.path === node.path);
            let statsHtml = '';
            if (fileObj) {
                const added = fileObj.lines_added || 0;
                const removed = fileObj.lines_removed || 0;
                if (added > 0 || removed > 0) {
                    statsHtml = ' <span class="file-stats">';
                    if (added > 0) {
                        statsHtml += `<span class="lines-added">+${added}</span>`;
                    }
                    if (removed > 0) {
                        if (added > 0) statsHtml += ' ';
                        statsHtml += `<span class="lines-removed">-${removed}</span>`;
                    }
                    statsHtml += '</span>';
                }
            }

            html += `<li class="file-tree-item clickable ${statusClass}" data-file-path="${escapeHtml(node.path)}" onclick="selectSourceFile('${escapeHtml(node.path).replace(/'/g, "\\'")}')">${statusIcon}${escapeHtml(name)}${statsHtml}</li>`;
        } else {
            // Directory node - make collapsible
            const folderPath = pathPrefix + name;
            const isCollapsed = window.collapsedFolders && window.collapsedFolders.has(folderPath);
            const icon = isCollapsed ? '▶' : '▼';

            html += `<li class="file-tree-item file-tree-directory">`;
            html += `<span class="folder-toggle" onclick="toggleFolder('${escapeHtml(folderPath).replace(/'/g, "\\'")}', event)">${icon}</span> `;
            html += `<span class="folder-name" onclick="toggleFolder('${escapeHtml(folderPath).replace(/'/g, "\\'")}', event)">📁 ${escapeHtml(name)}</span>`;

            // Children - render if not collapsed
            if (!isCollapsed) {
                html += renderFileTree(node.children, fileDiffs, indent + 1, folderPath + '/');
            }

            html += '</li>';
        }
    }

    html += '</ul>';
    return html;
}

function toggleFolder(folderPath, event) {
    event.stopPropagation();

    // Toggle collapsed state
    if (window.collapsedFolders.has(folderPath)) {
        window.collapsedFolders.delete(folderPath);
    } else {
        window.collapsedFolders.add(folderPath);
    }

    // Re-render just the file tree portion
    const fileTreeContainer = event.target.closest('.source-file-tree');
    if (fileTreeContainer && window.currentSourceDiffs) {
        const tree = buildFileTree(window.currentSourceDiffs);
        fileTreeContainer.innerHTML = '<h3>Changed Files</h3>' + renderFileTree(tree, window.currentSourceDiffs);
    }
}

function renderUnifiedDiff(beforeLines, afterLines) {
    // Simple line-by-line diff (uses a basic LCS-like algorithm)
    const diff = computeLineDiff(beforeLines, afterLines);

    let html = '<div class="diff-viewer">';
    let diffIndex = 0; // Track diff chunk index

    diff.forEach((item, idx) => {
        const beforeNum = item.beforeLineNum !== null ? item.beforeLineNum : '';
        const afterNum = item.afterLineNum !== null ? item.afterLineNum : '';

        // Check if this line is a diff (added or removed)
        const isDiff = (item.type === 'added' || item.type === 'removed');

        // Check if this is the start of a new diff chunk
        const isStartOfChunk = isDiff && (idx === 0 || diff[idx - 1].type === 'unchanged');
        let chunkAttr = '';
        if (isStartOfChunk) {
            chunkAttr = ` data-diff-chunk="${diffIndex}"`;
            diffIndex++;
        } else if (isDiff && idx > 0 && diff[idx - 1].type !== 'unchanged') {
            // Continue current chunk
            chunkAttr = ` data-diff-chunk="${diffIndex - 1}"`;
        }

        if (item.type === 'removed') {
            html += `<div class="diff-line diff-line-removed"${chunkAttr}>`;
            html += `<span class="diff-line-number-before">${beforeNum}</span>`;
            html += `<span class="diff-line-number-after"></span>`;
            html += `<span class="diff-line-content">${escapeHtml(item.content)}</span>`;
            html += `</div>`;
        } else if (item.type === 'added') {
            html += `<div class="diff-line diff-line-added"${chunkAttr}>`;
            html += `<span class="diff-line-number-before"></span>`;
            html += `<span class="diff-line-number-after">${afterNum}</span>`;
            html += `<span class="diff-line-content">${escapeHtml(item.content)}</span>`;
            html += `</div>`;
        } else {
            // unchanged line
            html += `<div class="diff-line diff-line-unchanged">`;
            html += `<span class="diff-line-number-before">${beforeNum}</span>`;
            html += `<span class="diff-line-number-after">${afterNum}</span>`;
            html += `<span class="diff-line-content">${escapeHtml(item.content)}</span>`;
            html += `</div>`;
        }
    });

    html += '</div>';
    return html;
}

function computeLineDiff(beforeLines, afterLines) {
    // Simple diff algorithm using dynamic programming (LCS-based)
    // Build LCS matrix
    const m = beforeLines.length;
    const n = afterLines.length;
    const lcs = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));

    for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
            if (beforeLines[i - 1] === afterLines[j - 1]) {
                lcs[i][j] = lcs[i - 1][j - 1] + 1;
            } else {
                lcs[i][j] = Math.max(lcs[i - 1][j], lcs[i][j - 1]);
            }
        }
    }

    // Backtrack to build diff with line numbers
    let i = m, j = n;
    const changes = [];
    let beforeLineNum = m;
    let afterLineNum = n;

    while (i > 0 || j > 0) {
        if (i > 0 && j > 0 && beforeLines[i - 1] === afterLines[j - 1]) {
            changes.unshift({
                type: 'unchanged',
                content: beforeLines[i - 1],
                beforeLineNum: beforeLineNum,
                afterLineNum: afterLineNum
            });
            i--;
            j--;
            beforeLineNum--;
            afterLineNum--;
        } else if (j > 0 && (i === 0 || lcs[i][j - 1] >= lcs[i - 1][j])) {
            changes.unshift({
                type: 'added',
                content: afterLines[j - 1],
                beforeLineNum: null,
                afterLineNum: afterLineNum
            });
            j--;
            afterLineNum--;
        } else if (i > 0) {
            changes.unshift({
                type: 'removed',
                content: beforeLines[i - 1],
                beforeLineNum: beforeLineNum,
                afterLineNum: null
            });
            i--;
            beforeLineNum--;
        }
    }

    return changes;
}

// Diff Navigation Functions
let currentDiffIndex = 0;
let totalDiffChunks = 0;
let diffContainer = document; // Store the current container for navigation

function initializeDiffNavigation(container = document) {
    // Store the container for use in navigation
    diffContainer = container;

    // Find all diff chunks within the specified container
    const diffChunks = container.querySelectorAll('[data-diff-chunk]');
    const uniqueChunks = new Set();
    diffChunks.forEach(line => {
        const chunkIndex = parseInt(line.getAttribute('data-diff-chunk'));
        uniqueChunks.add(chunkIndex);
    });

    totalDiffChunks = uniqueChunks.size;
    currentDiffIndex = 0;

    // Update UI
    updateDiffNavigationUI();

    // Navigate to first diff if any
    if (totalDiffChunks > 0) {
        navigateToDiff(0, true);
    }
}

function navigateToDiff(direction, absolute = false) {
    if (totalDiffChunks === 0) return;

    // Update index
    if (absolute) {
        currentDiffIndex = direction;
    } else {
        currentDiffIndex += direction;
    }

    // Clamp to valid range
    currentDiffIndex = Math.max(0, Math.min(currentDiffIndex, totalDiffChunks - 1));

    // Find and scroll to the target chunk (scoped to current container)
    const targetLines = diffContainer.querySelectorAll(`[data-diff-chunk="${currentDiffIndex}"]`);
    if (targetLines.length > 0) {
        // Remove previous highlights (scoped to current container)
        diffContainer.querySelectorAll('.current-diff-highlight').forEach(el => {
            el.classList.remove('current-diff-highlight');
        });

        // Highlight current chunk
        targetLines.forEach(line => {
            line.classList.add('current-diff-highlight');
        });

        // Scroll to first line of chunk with some offset
        targetLines[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    // Update UI
    updateDiffNavigationUI();
}

function updateDiffNavigationUI() {
    const positionText = document.getElementById('diff-position');
    const prevBtn = document.getElementById('prev-diff-btn');
    const nextBtn = document.getElementById('next-diff-btn');

    if (!positionText || !prevBtn || !nextBtn) return;

    if (totalDiffChunks === 0) {
        positionText.textContent = 'No changes';
        prevBtn.disabled = true;
        nextBtn.disabled = true;
    } else {
        positionText.textContent = `${currentDiffIndex + 1} / ${totalDiffChunks}`;
        prevBtn.disabled = (currentDiffIndex === 0);
        nextBtn.disabled = (currentDiffIndex === totalDiffChunks - 1);
    }
}

// CEX Analysis Modal Functions
let currentCexUrl = null;
let currentReportUrl = null;

async function openCexModal(fileUrl, title, reportUrl = null) {
    const modal = document.getElementById('cex-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const reportBtn = document.getElementById('modal-open-report');

    currentCexUrl = fileUrl;
    currentReportUrl = reportUrl;
    modalTitle.textContent = `CEX Analysis: ${title}`;
    modalBody.innerHTML = '<div class="loading">Loading analysis...</div>';

    // Show/hide report button based on whether we have a report URL
    if (reportUrl) {
        reportBtn.style.display = 'inline-block';
    } else {
        reportBtn.style.display = 'none';
    }

    modal.style.display = 'block';

    // Fetch and render the markdown (use ?raw=true to get markdown content)
    try {
        const response = await fetch(fileUrl + '?raw=true');
        if (!response.ok) {
            throw new Error('Failed to load analysis');
        }
        const markdown = await response.text();

        // Convert markdown to HTML using marked.js
        const html = marked.parse(markdown);
        modalBody.innerHTML = html;
    } catch (error) {
        modalBody.innerHTML = `<div class="error">Failed to load analysis: ${error.message}</div>`;
    }
}

function closeCexModal() {
    const modal = document.getElementById('cex-modal');
    modal.style.display = 'none';
    currentCexUrl = null;
    currentReportUrl = null;
}

function openCexInNewTab() {
    if (currentCexUrl) {
        window.open(currentCexUrl, '_blank');
    }
}

function openOriginalReport() {
    if (currentReportUrl) {
        window.open(currentReportUrl, '_blank');
    }
}

// Spec Diff Modal Functions
async function openSpecDiffModal(ruleName, jobId) {
    const modal = document.getElementById('spec-diff-modal');
    const modalTitle = document.getElementById('spec-diff-modal-title');
    const modalBody = document.getElementById('spec-diff-modal-body');

    modalTitle.innerHTML = `Spec Differences: ${ruleName}`;
    modalBody.innerHTML = '<div class="loading">Loading diff...</div>';
    modal.style.display = 'block';

    try {
        // Build URL with optional job_id parameter
        let url = `/api/scan/spec-diff/${encodeURIComponent(ruleName)}`;
        if (jobId) {
            url += `?job_id=${encodeURIComponent(jobId)}`;
        }

        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
            modalBody.innerHTML = `<div class="error-message">${data.error || 'Failed to load diff'}</div>`;
            return;
        }

        if (!data.diff_data) {
            modalBody.innerHTML = `<div class="info-message">No detailed diff data available. ${data.reason || ''}</div>`;
            return;
        }

        // Update modal title to include job_id for transparency
        modalTitle.innerHTML = `
            Spec Differences: ${ruleName}
            <br>
            <small style="font-size: 14px; color: #7f8c8d; font-weight: normal;">Job: ${data.job_id}</small>
        `;

        // Render the diff
        modalBody.innerHTML = renderSpecDiff(data.diff_data, ruleName);
    } catch (error) {
        console.error('Error loading spec diff:', error);
        modalBody.innerHTML = `<div class="error-message">Error loading diff: ${error.message}</div>`;
    }
}

function closeSpecDiffModal() {
    const modal = document.getElementById('spec-diff-modal');
    modal.style.display = 'none';
}

function toggleSection(header) {
    const section = header.parentElement;
    const content = section.querySelector('.collapsible-content');
    const icon = header.querySelector('.toggle-icon');

    if (section.classList.contains('collapsed')) {
        section.classList.remove('collapsed');
        content.style.display = 'block';
        icon.textContent = '▼';
    } else {
        section.classList.add('collapsed');
        content.style.display = 'none';
        icon.textContent = '▶';
    }
}

function renderSpecDiff(diffData, ruleName) {
    let html = '';

    // Render global elements section with collapsible categories
    const globalHtml = renderGlobalElements(diffData.global_elements);
    if (globalHtml.content) {
        html += `<div class="diff-section collapsible-section">
            <h3 class="diff-section-title collapsible-header" onclick="toggleSection(this)">
                <span class="toggle-icon">▼</span>
                Global Elements Changed
                <span class="section-summary">${globalHtml.summary}</span>
            </h3>
            <div class="collapsible-content">
                ${globalHtml.content}
            </div>
        </div>`;
    }

    // Render rules section
    const rulesResult = renderRulesDiff(diffData.rules, ruleName);
    if (rulesResult.content) {
        html += `<div class="diff-section collapsible-section">
            <h3 class="diff-section-title collapsible-header" onclick="toggleSection(this)">
                <span class="toggle-icon">▼</span>
                Rule Changes
                <span class="section-summary">${rulesResult.summary}</span>
            </h3>
            <div class="collapsible-content">
                ${rulesResult.content}
            </div>
        </div>`;
    }

    // Render invariants section
    const invariantsResult = renderInvariantsDiff(diffData.invariants);
    if (invariantsResult.content) {
        html += `<div class="diff-section collapsible-section">
            <h3 class="diff-section-title collapsible-header" onclick="toggleSection(this)">
                <span class="toggle-icon">▼</span>
                Invariant Changes
                <span class="section-summary">${invariantsResult.summary}</span>
            </h3>
            <div class="collapsible-content">
                ${invariantsResult.content}
            </div>
        </div>`;
    }

    if (!html) {
        html = '<div class="info-message">No differences found in the detailed comparison.</div>';
    }

    return html;
}

function renderGlobalElements(globalElements) {
    if (!globalElements) return { content: '', summary: '' };

    let html = '';
    const summaryBadges = [];

    // Categories to check
    const categories = [
        { key: 'ghosts', label: 'Ghosts' },
        { key: 'subs', label: 'Functions' },
        { key: 'definitions', label: 'Definitions' },
        { key: 'hooks', label: 'Hooks' },
        { key: 'internalSummaries', label: 'Internal Summaries' },
        { key: 'externalSummaries', label: 'External Summaries' },
        { key: 'unresolvedSummaries', label: 'Unresolved Summaries' }
    ];

    for (const cat of categories) {
        const data = globalElements[cat.key];
        if (!data) continue;

        const added = data.added || [];
        const removed = data.removed || [];
        const modified = data.modified || [];

        // Build summary badges for this category
        if (modified.length > 0) {
            summaryBadges.push(`<span class="summary-badge badge-modified">${modified.length} ${cat.label}</span>`);
        }
        if (added.length > 0) {
            summaryBadges.push(`<span class="summary-badge badge-added">${added.length} ${cat.label}</span>`);
        }
        if (removed.length > 0) {
            summaryBadges.push(`<span class="summary-badge badge-removed">${removed.length} ${cat.label}</span>`);
        }

        const catHtml = renderDiffCategory(data, cat.label);
        if (catHtml) {
            html += catHtml;
        }
    }

    const summary = summaryBadges.join(' ');
    return { content: html, summary: summary };
}

function renderDiffCategory(data, label) {
    if (!data) return '';

    const added = data.added || [];
    const removed = data.removed || [];
    const modified = data.modified || [];

    if (added.length === 0 && removed.length === 0 && modified.length === 0) {
        return '';
    }

    let html = `<div class="diff-category">
        <h4 class="diff-category-title">${label}</h4>`;

    // Added items
    for (const item of added) {
        const id = item.id || item.displayName || 'Unknown';
        html += `<div class="diff-item diff-added">
            <span class="diff-badge">+</span>
            <span class="diff-item-name">${id}</span>
            <span class="diff-label">added</span>
        </div>`;
    }

    // Removed items
    for (const item of removed) {
        const id = item.id || item.displayName || 'Unknown';
        html += `<div class="diff-item diff-removed">
            <span class="diff-badge">-</span>
            <span class="diff-item-name">${id}</span>
            <span class="diff-label">removed</span>
        </div>`;
    }

    // Modified items
    for (const item of modified) {
        const id = item.id || 'Unknown';
        html += `<div class="diff-item diff-modified">
            <div class="diff-item-header">
                <span class="diff-badge">~</span>
                <span class="diff-item-name">${id}</span>
                <span class="diff-label">modified</span>
            </div>
            <div class="diff-item-body">
                ${item.before_code && item.after_code
                    ? renderCodeSnippets(item.before_code, item.after_code) + renderFieldSnippets(item.field_snippets)
                    : renderModifiedDetails(item.diff, item.field_snippets)}
            </div>
        </div>`;
    }

    html += '</div>';
    return html;
}

function renderCodeSnippets(beforeCode, afterCode) {
    if (!beforeCode && !afterCode) return '';

    // If we have both before and after, render split diff view
    if (beforeCode && afterCode) {
        return renderSplitDiff(beforeCode, afterCode);
    }

    // If only one side exists, show it in a simple block
    let html = '<div class="diff-code-container">';

    if (beforeCode) {
        html += `<div class="diff-code-section">
            <div class="diff-code-header">Before (local):</div>
            <pre class="diff-code-block diff-code-before">${escapeHtml(beforeCode)}</pre>
        </div>`;
    }

    if (afterCode) {
        html += `<div class="diff-code-section">
            <div class="diff-code-header">After (cloud):</div>
            <pre class="diff-code-block diff-code-after">${escapeHtml(afterCode)}</pre>
        </div>`;
    }

    html += '</div>';
    return html;
}

function renderSplitDiff(beforeCode, afterCode) {
    // Split code into lines
    const beforeLines = beforeCode.split('\n');
    const afterLines = afterCode.split('\n');

    // Compute line-by-line diff
    const diff = computeLineDiff(beforeLines, afterLines);

    let html = '<div class="spec-diff-split-view">';

    // Header
    html += '<div class="split-view-header">';
    html += '<div class="split-view-column">Before (local)</div>';
    html += '<div class="split-view-column">After (cloud)</div>';
    html += '</div>';

    // Body with synchronized lines
    html += '<div class="split-view-body">';

    diff.forEach((item) => {
        const beforeNum = item.beforeLineNum !== null ? item.beforeLineNum : '';
        const afterNum = item.afterLineNum !== null ? item.afterLineNum : '';

        if (item.type === 'unchanged') {
            // Show same line on both sides
            html += '<div class="split-view-row">';
            html += `<div class="split-view-line split-line-unchanged">`;
            html += `<span class="split-line-number">${beforeNum}</span>`;
            html += `<span class="split-line-content">${escapeHtml(item.content)}</span>`;
            html += '</div>';
            html += `<div class="split-view-line split-line-unchanged">`;
            html += `<span class="split-line-number">${afterNum}</span>`;
            html += `<span class="split-line-content">${escapeHtml(item.content)}</span>`;
            html += '</div>';
            html += '</div>';
        } else if (item.type === 'removed') {
            // Show removed line on left, empty on right
            html += '<div class="split-view-row">';
            html += `<div class="split-view-line split-line-removed">`;
            html += `<span class="split-line-number">${beforeNum}</span>`;
            html += `<span class="split-line-content">${escapeHtml(item.content)}</span>`;
            html += '</div>';
            html += `<div class="split-view-line split-line-empty">`;
            html += `<span class="split-line-number"></span>`;
            html += `<span class="split-line-content"></span>`;
            html += '</div>';
            html += '</div>';
        } else if (item.type === 'added') {
            // Show empty on left, added line on right
            html += '<div class="split-view-row">';
            html += `<div class="split-view-line split-line-empty">`;
            html += `<span class="split-line-number"></span>`;
            html += `<span class="split-line-content"></span>`;
            html += '</div>';
            html += `<div class="split-view-line split-line-added">`;
            html += `<span class="split-line-number">${afterNum}</span>`;
            html += `<span class="split-line-content">${escapeHtml(item.content)}</span>`;
            html += '</div>';
            html += '</div>';
        }
    });

    html += '</div>'; // end split-view-body
    html += '</div>'; // end spec-diff-split-view

    return html;
}

function renderFieldSnippets(fieldSnippets) {
    if (!fieldSnippets || Object.keys(fieldSnippets).length === 0) return '';

    let html = '<div class="diff-field-snippets" style="margin-top: 10px;">';

    for (const [fieldName, snippets] of Object.entries(fieldSnippets)) {
        const beforeSnippet = snippets.before;
        const afterSnippet = snippets.after;

        if (!beforeSnippet && !afterSnippet) continue;

        html += `<div class="field-snippet-container" style="margin-bottom: 15px;">
            <div style="font-weight: 600; color: #333; margin-bottom: 5px;">Field: ${fieldName}</div>`;

        // If we have both snippets, use split diff view
        if (beforeSnippet && afterSnippet) {
            html += renderSplitDiff(beforeSnippet, afterSnippet);
        } else {
            // Otherwise, show single snippet
            html += '<div class="diff-code-container">';

            if (beforeSnippet) {
                html += `<div class="diff-code-section">
                    <div class="diff-code-header">Before:</div>
                    <pre class="diff-code-block diff-code-before" style="max-height: 150px; overflow-y: auto;">${escapeHtml(beforeSnippet)}</pre>
                </div>`;
            }

            if (afterSnippet) {
                html += `<div class="diff-code-section">
                    <div class="diff-code-header">After:</div>
                    <pre class="diff-code-block diff-code-after" style="max-height: 150px; overflow-y: auto;">${escapeHtml(afterSnippet)}</pre>
                </div>`;
            }

            html += '</div>';
        }

        html += '</div>';
    }

    html += '</div>';
    return html;
}

function escapeHtml(text) {
    if (!text) return '';
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function renderModifiedDetails(diff, fieldSnippets) {
    if (!diff || !diff.before || !diff.after) return '';

    let html = '<div class="diff-details">';

    // Show breadcrumb path with value change if available
    if (diff.path) {
        const beforeVal = formatValue(diff.path_before);
        const afterVal = formatValue(diff.path_after);

        html += `<div class="diff-path-label">
            <div class="diff-path-header">diff in: <code>${escapeHtml(diff.path)}</code></div>
            <div class="diff-path-values">
                <span class="diff-before">${beforeVal}</span>
                <span class="diff-arrow">→</span>
                <span class="diff-after">${afterVal}</span>
            </div>
        </div>`;
    }

    // Helper function to remove ignored fields for comparison
    function removeIgnoredFields(obj) {
        if (obj === null || obj === undefined) return obj;
        if (typeof obj !== 'object') return obj;

        if (Array.isArray(obj)) {
            return obj.map(item => removeIgnoredFields(item));
        }

        const cleaned = {};
        for (const [key, val] of Object.entries(obj)) {
            // Skip ignored fields (same as backend IGNORE_FIELDS_COMPARISON)
            // counter: non-deterministic rule numbering
            // range: source location
            // sourceSegment: source location (similar to range)
            // scope: internal scope info
            // relevantFuncs: internal function tracking
            // canonicalId: skip if name field is present or if it's in a VmType
            if (key === 'range' || key === 'sourceSegment' || key === 'scope' || key === 'relevantFuncs' || key === 'counter') {
                continue;
            }
            if (key === 'canonicalId' && (obj.name !== undefined || (obj.type && obj.type.includes('VmType')))) {
                continue;
            }
            cleaned[key] = removeIgnoredFields(val);
        }
        return cleaned;
    }

    // Get list of fields that have snippets
    const fieldsWithSnippets = fieldSnippets ? Object.keys(fieldSnippets) : [];

    // Find the differences between before and after (top-level fields)
    const changes = [];
    const before = diff.before;
    const after = diff.after;

    for (const key of Object.keys(after)) {
        if (key === 'type' || key === 'id' || key === 'range' || key === 'sourceSegment' || key === 'scope') continue;
        // Skip canonicalId if name is present or if it's in a VmType
        if (key === 'canonicalId' && (after.name !== undefined || before.name !== undefined || (after.type && after.type.includes('VmType')) || (before.type && before.type.includes('VmType')))) continue;

        const beforeVal = before[key];
        const afterVal = after[key];

        // Compare after removing ignored fields (range, sourceSegment, scope, relevantFuncs)
        const beforeCleaned = removeIgnoredFields(beforeVal);
        const afterCleaned = removeIgnoredFields(afterVal);

        if (JSON.stringify(beforeCleaned) !== JSON.stringify(afterCleaned)) {
            changes.push({
                field: key,
                before: formatValue(beforeVal),
                after: formatValue(afterVal)
            });
        }
    }

    if (changes.length === 0 && !diff.path) return '';

    // Render top-level field changes
    // Skip fields that:
    // 1. Have field snippets (they'll be shown below with actual code)
    // 2. Are too complex/verbose (>200 chars)
    const displayedChanges = changes.filter(change => {
        // Skip if we have a field snippet for this field
        if (fieldsWithSnippets.includes(change.field)) {
            return false;
        }

        // Skip very long JSON representations (>200 chars) - these are structural AST diffs
        const beforeLen = change.before.length;
        const afterLen = change.after.length;

        // If both are very long JSON objects, don't display - code snippets are better
        if (beforeLen > 200 && afterLen > 200 &&
            (change.before.startsWith('{') || change.before.startsWith('['))) {
            return false;
        }

        return true;
    });

    // Count fields that are hidden
    const hiddenCount = changes.length - displayedChanges.length;
    const hiddenWithSnippets = changes.filter(c => fieldsWithSnippets.includes(c.field)).length;
    const hiddenWithoutSnippets = hiddenCount - hiddenWithSnippets;

    // If we have complex changes but they're hidden without snippets, add a note
    if (hiddenWithoutSnippets > 0) {
        html += `<div class="diff-change" style="font-style: italic; color: #666;">
            <span>Structural changes in ${hiddenWithoutSnippets} field(s) - see code snippets below</span>
        </div>`;
    }

    for (const change of displayedChanges) {
        html += `<div class="diff-change">
            <span class="diff-field">${change.field}:</span>
            <span class="diff-before">${change.before}</span>
            <span class="diff-arrow">→</span>
            <span class="diff-after">${change.after}</span>
        </div>`;
    }
    html += '</div>';

    return html;
}

function formatValue(val) {
    if (val === null || val === undefined) return 'null';
    if (typeof val === 'boolean') return val ? 'true' : 'false';
    if (typeof val === 'string') return val;
    if (typeof val === 'number') return String(val);

    if (Array.isArray(val)) {
        // Show more info about arrays
        if (val.length === 0) {
            return '[]';
        }

        // For small arrays of primitives, show the full content
        if (val.length <= 3 && val.every(v => typeof v !== 'object' || v === null)) {
            try {
                return JSON.stringify(val);
            } catch (e) {
                return `[${val.length} items]`;
            }
        }

        // For arrays of objects, show count and type info
        if (val.length > 0 && typeof val[0] === 'object' && val[0] !== null) {
            // If first item has a 'type' field, mention it
            if (val[0].type) {
                let typeName;
                if (typeof val[0].type === 'string') {
                    typeName = val[0].type.split('.').pop();
                } else if (typeof val[0].type === 'object' && val[0].type.name) {
                    typeName = val[0].type.name;
                } else {
                    typeName = 'item';
                }
                return `[${val.length} ${typeName}${val.length > 1 ? 's' : ''}]`;
            }

            // For arrays with 1 item, always try to show meaningful info
            if (val.length === 1) {
                try {
                    const json = JSON.stringify(val[0]);
                    // For single item, show the object contents (not wrapped in array)
                    if (json.length <= 300) {
                        return `[1: ${json}]`;
                    }
                    // If too long, try to show key info
                    const item = val[0];
                    const keys = Object.keys(item);
                    const summary = keys.slice(0, 2).map(k => {
                        const v = item[k];
                        if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') {
                            return `${k}=${JSON.stringify(v)}`;
                        }
                        return k;
                    }).join(', ');
                    return `[1: {${summary}${keys.length > 2 ? ', ...' : ''}}]`;
                } catch (e) {}
            }

            // For 2 items, try to show both
            if (val.length === 2) {
                try {
                    const json = JSON.stringify(val);
                    if (json.length <= 300) {
                        return json;
                    }
                } catch (e) {}
            }

            // If first item has an 'id' or 'name', show it
            if (val[0].id) {
                return `[${val.length} items: ${val[0].id}${val.length > 1 ? ', ...' : ''}]`;
            }
            if (val[0].name) {
                return `[${val.length} items: ${val[0].name}${val.length > 1 ? ', ...' : ''}]`;
            }

            // Show key=value pairs of first object to give context
            const keys = Object.keys(val[0]);
            if (keys.length > 0) {
                try {
                    const summary = keys.slice(0, 2).map(k => {
                        const v = val[0][k];
                        if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') {
                            const vStr = typeof v === 'string' && v.length > 20 ? v.substring(0, 20) + '...' : v;
                            return `${k}=${JSON.stringify(vStr)}`;
                        }
                        return k;
                    }).join(', ');
                    return `[${val.length}: {${summary}${keys.length > 2 ? ', ...' : ''}}]`;
                } catch (e) {
                    const keyStr = keys.slice(0, 3).join(', ');
                    return `[${val.length} with: ${keyStr}${keys.length > 3 ? ', ...' : ''}]`;
                }
            }
        }

        // For larger arrays or mixed content, show compact JSON preview
        try {
            const json = JSON.stringify(val);
            if (json.length <= 200) {
                return json;
            }
            return `[${val.length} items: ${json.substring(0, 80)}...]`;
        } catch (e) {
            return `[${val.length} items]`;
        }
    }

    if (typeof val === 'object') {
        // Special formatting for type objects
        if (val.type) {
            // Extract the last part of the type name for readability
            let typeName;
            if (typeof val.type === 'string') {
                typeName = val.type.split('.').pop();
            } else if (typeof val.type === 'object' && val.type.name) {
                // If type is an object with a name, use that
                typeName = val.type.name;
            } else {
                // Fallback to JSON stringification
                typeName = JSON.stringify(val.type);
            }

            // If it has a name field, include it
            if (val.name) {
                if (typeof val.name === 'string') {
                    return `${typeName}<${val.name}>`;
                } else if (val.name.name) {
                    return `${typeName}<${val.name.name}>`;
                }
            }

            // Otherwise just show the type
            return typeName;
        }

        // For other objects, show compact JSON (max 150 chars)
        try {
            const json = JSON.stringify(val);
            if (json.length > 150) {
                return json.substring(0, 147) + '...';
            }
            return json;
        } catch (e) {
            return '{...}';
        }
    }
    return String(val);
}

function renderRulesDiff(rules, targetRuleName) {
    if (!rules) return { content: '', summary: '' };

    const added = rules.added || [];
    const removed = rules.removed || [];
    const modified = rules.modified || [];

    if (added.length === 0 && removed.length === 0 && modified.length === 0) {
        return { content: '', summary: '' };
    }

    // Build summary with colored badges
    const summaryBadges = [];
    if (modified.length > 0) {
        summaryBadges.push(`<span class="summary-badge badge-modified">${modified.length}</span>`);
    }
    if (added.length > 0) {
        summaryBadges.push(`<span class="summary-badge badge-added">${added.length}</span>`);
    }
    if (removed.length > 0) {
        summaryBadges.push(`<span class="summary-badge badge-removed">${removed.length}</span>`);
    }
    const summary = summaryBadges.join(' ');

    let html = '';

    // Added rules
    for (const item of added) {
        const name = item.displayName || 'Unknown';
        html += `<div class="diff-item diff-added">
            <span class="diff-badge">+</span>
            <span class="diff-item-name">${name}</span>
            <span class="diff-label">added</span>
        </div>`;
    }

    // Removed rules
    for (const item of removed) {
        const name = item.displayName || 'Unknown';
        html += `<div class="diff-item diff-removed">
            <span class="diff-badge">-</span>
            <span class="diff-item-name">${name}</span>
            <span class="diff-label">removed</span>
        </div>`;
    }

    // Modified rules
    for (const item of modified) {
        const name = item.id || 'Unknown';
        html += `<div class="diff-item diff-modified">
            <span class="diff-badge">~</span>
            <span class="diff-item-name">${name}</span>
            <span class="diff-label">modified</span>
            ${item.before_code && item.after_code
                ? renderCodeSnippets(item.before_code, item.after_code) + renderFieldSnippets(item.field_snippets)
                : renderModifiedDetails(item.diff, item.field_snippets)}
        </div>`;
    }

    return { content: html, summary: summary };
}

function renderInvariantsDiff(invariants) {
    if (!invariants) return { content: '', summary: '' };

    const added = invariants.added || [];
    const removed = invariants.removed || [];
    const modified = invariants.modified || [];

    if (added.length === 0 && removed.length === 0 && modified.length === 0) {
        return { content: '', summary: '' };
    }

    // Build summary with colored badges
    const summaryBadges = [];
    if (modified.length > 0) {
        summaryBadges.push(`<span class="summary-badge badge-modified">${modified.length}</span>`);
    }
    if (added.length > 0) {
        summaryBadges.push(`<span class="summary-badge badge-added">${added.length}</span>`);
    }
    if (removed.length > 0) {
        summaryBadges.push(`<span class="summary-badge badge-removed">${removed.length}</span>`);
    }
    const summary = summaryBadges.join(' ');

    let html = '';

    // Added invariants
    for (const item of added) {
        const name = item.displayName || item.id || 'Unknown';
        html += `<div class="diff-item diff-added">
            <span class="diff-badge">+</span>
            <span class="diff-item-name">${name}</span>
            <span class="diff-label">added</span>
        </div>`;
    }

    // Removed invariants
    for (const item of removed) {
        const name = item.displayName || item.id || 'Unknown';
        html += `<div class="diff-item diff-removed">
            <span class="diff-badge">-</span>
            <span class="diff-item-name">${name}</span>
            <span class="diff-label">removed</span>
        </div>`;
    }

    // Modified invariants
    for (const item of modified) {
        const name = item.id || 'Unknown';
        html += `<div class="diff-item diff-modified">
            <span class="diff-badge">~</span>
            <span class="diff-item-name">${name}</span>
            <span class="diff-label">modified</span>
            ${item.before_code && item.after_code
                ? renderCodeSnippets(item.before_code, item.after_code) + renderFieldSnippets(item.field_snippets)
                : renderModifiedDetails(item.diff, item.field_snippets)}
        </div>`;
    }

    return { content: html, summary: summary };
}

// Setup modal event listeners
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('cex-modal');
    const closeBtn = document.getElementById('modal-close');
    const newTabBtn = document.getElementById('modal-open-new-tab');
    const reportBtn = document.getElementById('modal-open-report');

    // Close button
    closeBtn.addEventListener('click', closeCexModal);

    // Open in new tab button
    newTabBtn.addEventListener('click', openCexInNewTab);

    // Open original report button
    reportBtn.addEventListener('click', openOriginalReport);

    // Close when clicking outside the modal content
    modal.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeCexModal();
        }
    });

    // Close on Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && modal.style.display === 'block') {
            closeCexModal();
        }
    });

    // Setup spec diff modal listeners
    const specDiffModal = document.getElementById('spec-diff-modal');
    const specDiffCloseBtn = document.getElementById('spec-diff-modal-close');

    if (specDiffCloseBtn) {
        specDiffCloseBtn.addEventListener('click', closeSpecDiffModal);
    }

    if (specDiffModal) {
        // Close when clicking outside the modal content
        specDiffModal.addEventListener('click', function(event) {
            if (event.target === specDiffModal) {
                closeSpecDiffModal();
            }
        });

        // Close on Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && specDiffModal.style.display === 'block') {
                closeSpecDiffModal();
            }
        });
    }

    // Setup conf diff modal listeners
    const confDiffModal = document.getElementById('conf-diff-modal');
    const confDiffCloseBtn = document.getElementById('conf-diff-modal-close');

    if (confDiffCloseBtn) {
        confDiffCloseBtn.addEventListener('click', closeConfDiffModal);
    }

    if (confDiffModal) {
        // Close when clicking outside the modal content
        confDiffModal.addEventListener('click', function(event) {
            if (event.target === confDiffModal) {
                closeConfDiffModal();
            }
        });

        // Close on Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && confDiffModal.style.display === 'block') {
                closeConfDiffModal();
            }
        });
    }

    // Setup source diff modal listeners
    const sourceDiffModal = document.getElementById('source-diff-modal');
    const sourceDiffCloseBtn = document.getElementById('source-diff-modal-close');

    if (sourceDiffCloseBtn) {
        sourceDiffCloseBtn.addEventListener('click', closeSourceDiffModal);
    }

    if (sourceDiffModal) {
        // Close when clicking outside the modal content
        sourceDiffModal.addEventListener('click', function(event) {
            if (event.target === sourceDiffModal) {
                closeSourceDiffModal();
            }
        });

        // Close on Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && sourceDiffModal.style.display === 'block') {
                closeSourceDiffModal();
            }
        });
    }
});

// Sync Progress Functions
async function checkSyncProgress() {
    try {
        const response = await fetch(`/api/scan/progress?mode=${currentMode}`);
        const progress = await response.json();

        if (!progress.has_progress) {
            hideSyncProgress();
            return;
        }

        // Show progress bar if sync is running
        if (progress.status === 'running' || progress.is_running) {
            showSyncProgress(progress);
        } else if (progress.status === 'completed') {
            // Sync completed - reload data and hide progress
            await loadScanData();
            hideSyncProgress();
            stopSyncProgressPolling(); // Only stop sync polling, not scan polling
        } else if (progress.status === 'failed') {
            // Sync failed - show error and hide progress
            showError(`Cloud sync failed: ${progress.error_message || 'Unknown error'}`);
            hideSyncProgress();
            stopSyncProgressPolling(); // Only stop sync polling, not scan polling
        }
    } catch (error) {
        console.error('Error checking sync progress:', error);
    }
}

function showSyncProgress(progress) {
    const progressBar = document.getElementById('sync-progress-bar');
    const progressText = document.getElementById('sync-progress-text');
    const progressStats = document.getElementById('sync-progress-stats');
    const progressFill = document.getElementById('sync-progress-fill');

    progressBar.classList.remove('hidden');

    let percentage = 0;
    let text = '';
    let stats = '';

    if (progress.phase === 'computing_diffs') {
        // Diff computation phase
        const totalDiffJobs = progress.total_diff_jobs || 0;
        const completedSpec = progress.completed_spec_diffs || 0;
        const completedConf = progress.completed_conf_diffs || 0;
        const completedSource = progress.completed_source_diffs || 0;
        const totalCompleted = completedSpec + completedConf + completedSource;
        const totalTasks = totalDiffJobs * 3; // spec, conf, source per job

        percentage = totalTasks > 0
            ? Math.round((totalCompleted / totalTasks) * 100)
            : 0;

        text = 'Computing diffs...';
        if (totalDiffJobs > 0) {
            stats = `${totalCompleted}/${totalTasks} (spec: ${completedSpec}/${totalDiffJobs}, conf: ${completedConf}/${totalDiffJobs}, source: ${completedSource}/${totalDiffJobs})`;
        } else {
            // Fallback to old format for backwards compatibility
            stats = `${progress.processed_rules || 0} / ${progress.total_rules || 0} rules`;
            if (progress.current_rule) {
                stats += ` (${progress.current_rule})`;
            }
        }
    } else {
        // Fetching jobs phase
        percentage = progress.total_jobs > 0
            ? Math.round((progress.processed_jobs / progress.total_jobs) * 100)
            : 0;
        text = 'Syncing cloud data...';
        stats = `${progress.processed_jobs} / ${progress.total_jobs} jobs`;
    }

    progressText.textContent = text;
    progressStats.textContent = stats;
    progressFill.style.width = `${percentage}%`;
}

function hideSyncProgress() {
    const progressBar = document.getElementById('sync-progress-bar');
    progressBar.classList.add('hidden');
}

function startProgressPolling() {
    console.log('startProgressPolling() called');
    startSyncProgressPolling();
    startScanProgressPolling();
}

function stopProgressPolling() {
    stopSyncProgressPolling();
    stopScanProgressPolling();
}

function startSyncProgressPolling() {
    if (syncProgressPollingInterval) {
        console.log('Sync progress polling already running');
        return;
    }
    console.log('Starting sync progress polling...');
    syncProgressPollingInterval = setInterval(() => {
        checkSyncProgress();
    }, 1000);
    checkSyncProgress(); // Check immediately
}

function stopSyncProgressPolling() {
    if (syncProgressPollingInterval) {
        console.log('Stopping sync progress polling');
        clearInterval(syncProgressPollingInterval);
        syncProgressPollingInterval = null;
    }
}

function startScanProgressPolling() {
    if (scanProgressPollingInterval) {
        console.log('Scan progress polling already running');
        return;
    }
    console.log('Starting scan progress polling...');
    scanProgressPollingInterval = setInterval(() => {
        console.log('Scan polling interval fired');
        checkScanProgress();
    }, 1000);
    checkScanProgress(); // Check immediately
}

function stopScanProgressPolling() {
    if (scanProgressPollingInterval) {
        console.log('Stopping scan progress polling');
        clearInterval(scanProgressPollingInterval);
        scanProgressPollingInterval = null;
    }
}

// Scan Progress Functions
let scanProgressCompleted = false; // Track if we've already handled completion

async function checkScanProgress() {
    try {
        // Add cache-busting to ensure we get fresh data every time
        const response = await fetch('/api/scan/scan-progress?_=' + Date.now());
        const progress = await response.json();

        console.log('[' + new Date().toISOString() + '] checkScanProgress received:', progress);

        if (!progress.has_progress) {
            console.log('No scan progress found');
            hideScanProgress();
            scanProgressCompleted = false;
            return;
        }

        console.log('Scan progress status:', progress.status, 'phase:', progress.phase);

        if (progress.status === 'running') {
            scanProgressCompleted = false;
            console.log('Calling showScanProgress with:', progress);
            showScanProgress(progress);
        } else if (progress.status === 'completed' && !scanProgressCompleted) {
            // Mark as completed so we don't trigger this multiple times
            scanProgressCompleted = true;
            console.log('Scan completed, showing completion');
            // Show completion briefly before hiding
            showScanProgress(progress);
            // Wait 1 second, then reload and hide
            setTimeout(async () => {
                await loadScanData();
                hideScanProgress();
            }, 1000);
        } else if (progress.status === 'failed') {
            scanProgressCompleted = false;
            // Scan failed - show error and hide progress
            showError(`Scan failed: ${progress.error_message || 'Unknown error'}`);
            hideScanProgress();
        }
    } catch (error) {
        console.error('Error checking scan progress:', error);
    }
}

function showScanProgress(progress) {
    console.log('showScanProgress called with:', progress);

    const progressBar = document.getElementById('scan-progress-bar');
    const progressText = document.getElementById('scan-progress-text');
    const progressStats = document.getElementById('scan-progress-stats');
    const progressFill = document.getElementById('scan-progress-fill');

    console.log('BEFORE remove hidden - classList:', progressBar.classList.toString());
    progressBar.classList.remove('hidden');
    console.log('AFTER remove hidden - classList:', progressBar.classList.toString());

    const percentage = progress.total_items > 0
        ? Math.round((progress.processed_items / progress.total_items) * 100)
        : 0;

    // Phase-specific messaging
    let phaseText = '';
    if (progress.phase === 'scanning') {
        phaseText = 'Scanning project...';
    } else if (progress.phase === 'generating_asts') {
        phaseText = 'Generating ASTs...';
    } else if (progress.phase === 'computing_diffs') {
        phaseText = 'Computing diffs...';
    } else if (progress.phase === 'completed') {
        phaseText = 'Scan complete!';
    }

    console.log('Setting progressText.textContent to:', phaseText);
    progressText.textContent = phaseText;
    const currentItem = progress.current_item ? ` (${progress.current_item})` : '';

    // Show compilation success info during AST generation phase
    let statsText = `${progress.processed_items} / ${progress.total_items}${currentItem}`;
    if (progress.phase === 'generating_asts' && progress.successful_items !== undefined) {
        statsText = `${progress.processed_items} / ${progress.total_items} (${progress.successful_items} compiled)${currentItem}`;
    }

    console.log('Setting progressStats.textContent to:', statsText);
    progressStats.textContent = statsText;
    console.log('Setting progressFill.style.width to:', `${percentage}%`);
    progressFill.style.width = `${percentage}%`;

    console.log('FINAL CHECK - progressStats.textContent:', progressStats.textContent);
    console.log('FINAL CHECK - progressBar visible?', !progressBar.classList.contains('hidden'));
}

function hideScanProgress() {
    const progressBar = document.getElementById('scan-progress-bar');
    progressBar.classList.add('hidden');
}

// CEX Analysis Polling Functions
function trackRunningCexAnalyses(data) {
    const cexAnalyses = data.cex_analyses || {};
    const newRunningAnalyses = new Set();

    // Find all running analyses
    for (const [key, analysis] of Object.entries(cexAnalyses)) {
        if (analysis.status === 'running') {
            newRunningAnalyses.add(key);
        }
    }

    // If we have running analyses, start polling
    if (newRunningAnalyses.size > 0) {
        runningCexAnalyses = newRunningAnalyses;
        startCexPolling();
    } else {
        runningCexAnalyses.clear();
        stopCexPolling();
    }
}

function startCexPolling() {
    if (cexPollingInterval) {
        return; // Already polling
    }
    // Check every 5 seconds for CEX analysis completion
    cexPollingInterval = setInterval(checkCexCompletion, 5000);
}

function stopCexPolling() {
    if (cexPollingInterval) {
        clearInterval(cexPollingInterval);
        cexPollingInterval = null;
    }
}

async function checkCexCompletion() {
    if (runningCexAnalyses.size === 0) {
        stopCexPolling();
        return;
    }

    try {
        // Reload scan data to get updated CEX analysis statuses
        const response = await fetch(`/api/scan?mode=${currentMode}`);
        const data = await response.json();

        const cexAnalyses = data.cex_analyses || {};
        let anyCompleted = false;

        // Check if any running analyses have completed
        for (const key of runningCexAnalyses) {
            const analysis = cexAnalyses[key];
            if (!analysis || analysis.status !== 'running') {
                anyCompleted = true;
                runningCexAnalyses.delete(key);
            }
        }

        // If any completed, update the UI without full page reload
        if (anyCompleted) {
            currentScanData = data;
            renderDashboard(data);
            updateLastUpdated(data.timestamp, data.last_cloud_sync);
        }

        // Stop polling if no more running analyses
        if (runningCexAnalyses.size === 0) {
            stopCexPolling();
        }
    } catch (error) {
        console.error('Error checking CEX completion:', error);
    }
}

// Settings functions

function getDefaultSettings() {
    return {
        userFilter: 'all-users',
        lookbackDays: 30,
        astTimeout: 600
    };
}

function loadSettings() {
    try {
        const saved = localStorage.getItem('certoraDashboardSettings');
        if (saved) {
            const settings = JSON.parse(saved);
            return {
                userFilter: settings.userFilter || 'all-users',
                lookbackDays: settings.lookbackDays || 30,
                astTimeout: settings.astTimeout || 600
            };
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
    return getDefaultSettings();
}

function saveSettingsToStorage(settings) {
    try {
        localStorage.setItem('certoraDashboardSettings', JSON.stringify(settings));
    } catch (error) {
        console.error('Error saving settings:', error);
    }
}

function openSettingsModal() {
    const modal = document.getElementById('settings-modal');
    const userFilterSelect = document.getElementById('user-filter');
    const lookbackDaysInput = document.getElementById('lookback-days');
    const astTimeoutInput = document.getElementById('ast-timeout');

    // Load current settings
    const settings = loadSettings();
    userFilterSelect.value = settings.userFilter;
    lookbackDaysInput.value = settings.lookbackDays;
    astTimeoutInput.value = settings.astTimeout;

    // Show modal
    modal.style.display = 'flex';
}

function closeSettingsModal() {
    const modal = document.getElementById('settings-modal');
    modal.style.display = 'none';
}

function saveSettings() {
    const userFilterSelect = document.getElementById('user-filter');
    const lookbackDaysInput = document.getElementById('lookback-days');
    const astTimeoutInput = document.getElementById('ast-timeout');

    const settings = {
        userFilter: userFilterSelect.value,
        lookbackDays: parseInt(lookbackDaysInput.value, 10),
        astTimeout: parseInt(astTimeoutInput.value, 10)
    };

    // Validate lookback days
    if (settings.lookbackDays < 1 || settings.lookbackDays > 365) {
        alert('Look-back period must be between 1 and 365 days');
        return;
    }

    // Validate AST timeout
    if (settings.astTimeout < 60 || settings.astTimeout > 1800) {
        alert('AST timeout must be between 60 and 1800 seconds');
        return;
    }

    // Save to storage
    saveSettingsToStorage(settings);

    // Close modal
    closeSettingsModal();

    // Reload data with new settings
    console.log('Settings saved, reloading data...');
    loadScanData();
}
