"""
Rust Solana Prover parser for extracting rules from Rust spec files.

This module handles parsing of Rust specification files to extract:
- Rules defined with #[rule] annotations
- Detection of Rust/Solana projects via Cargo.toml files
"""

import re
from pathlib import Path
from typing import List

from src.dashboard.models import RuleInfo
from src.dashboard.logger import dashboard_logger as logger


def detect_rust_project(conf_path: Path) -> bool:
    """
    Detect if a conf file is for a Rust/Solana project.

    Checks parent directories for the presence of Cargo.toml file,
    which indicates this is a Rust project.

    Args:
        conf_path: Path to the conf file

    Returns:
        True if Cargo.toml found in any parent directory, False otherwise
    """
    current = conf_path.parent
    # Check up to 10 levels up to avoid infinite loops
    for _ in range(10):
        if (current / "Cargo.toml").exists():
            logger.log(
                f"Detected Rust project at {current} (found Cargo.toml)",
                "INFO",
                "RustParser"
            )
            return True
        if current.parent == current:  # Reached root
            break
        current = current.parent

    return False


def find_rust_spec_files(project_root: Path) -> List[Path]:
    """
    Find all Rust spec files in src/certora directory.

    Args:
        project_root: Root directory of the project (where Cargo.toml is)

    Returns:
        List of absolute paths to .rs files in src/certora/
    """
    rust_files: list[Path] = []

    # Look for src/certora directory
    certora_dir = project_root / "src" / "certora"

    if not certora_dir.exists() or not certora_dir.is_dir():
        logger.log(
            f"No src/certora directory found at {certora_dir}",
            "DEBUG",
            "RustParser"
        )
        return rust_files

    # Recursively find all .rs files
    for rust_file in certora_dir.rglob("*.rs"):
        rust_files.append(rust_file.resolve())

    logger.log(
        f"Found {len(rust_files)} Rust spec files in {certora_dir}",
        "INFO",
        "RustParser"
    )

    return rust_files


def parse_rust_rules(rust_file: Path) -> List[RuleInfo]:
    """
    Extract rules from Rust spec file by finding #[rule] annotations.

    Searches for function definitions annotated with #[rule] attribute.

    Args:
        rust_file: Path to the Rust specification file

    Returns:
        List of RuleInfo objects for all rules found

    Example Rust syntax:
        #[rule]
        pub fn rule_fee_sanity() {
            compute_fee(nondet(), nondet()).unwrap();
            cvlr_satisfy!(true);
        }
    """
    rules = []

    try:
        with open(rust_file, "r") as f:
            lines = f.readlines()

        # Find all #[rule] annotations and extract the following function name
        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Check if this line has #[rule] or #[cvlr::rule]
            if line == "#[rule]" or line.startswith("#[rule] ") or \
               line == "#[cvlr::rule]" or line.startswith("#[cvlr::rule] "):
                # Look for the function definition
                # It could be on the same line or a few lines below

                # Check if function is on same line (e.g., "#[rule] pub fn name()" or "#[cvlr::rule] pub fn name()")
                same_line_match = re.search(r'#\[(?:cvlr::)?rule\]\s*(?:pub\s+)?fn\s+(\w+)\s*\(', line)
                if same_line_match:
                    rule_name = same_line_match.group(1)
                    rules.append(RuleInfo(
                        name=rule_name,
                        type="rule",
                        is_parametric=False,
                        spec_file=rust_file,
                        from_use=False
                    ))
                    i += 1
                    continue

                # Otherwise look in the next few lines for the function
                # Skip any other attributes or blank lines
                for j in range(i + 1, min(i + 10, len(lines))):
                    next_line = lines[j].strip()

                    # Skip empty lines and other attributes
                    if not next_line or next_line.startswith("#["):
                        continue

                    # Check if this is a function definition
                    fn_match = re.match(r'(?:pub\s+)?fn\s+(\w+)\s*\(', next_line)
                    if fn_match:
                        rule_name = fn_match.group(1)
                        rules.append(RuleInfo(
                            name=rule_name,
                            type="rule",
                            is_parametric=False,
                            spec_file=rust_file,
                            from_use=False
                        ))
                        break
                    else:
                        # Hit something that's not a function - stop looking
                        break

            i += 1

        # Also search for impl_cvlr_rule_for_bases! macro invocations
        # Format: impl_cvlr_rule_for_bases!(PropType, rule_name => base_name, ...)
        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Look for macro invocation start
            if "impl_cvlr_rule_for_bases!" in line:
                # Collect the full macro invocation (may span multiple lines)
                macro_content = line
                brace_depth = line.count('{') - line.count('}')
                paren_depth = line.count('(') - line.count(')')

                j = i + 1
                while j < len(lines) and (brace_depth > 0 or paren_depth > 0 or macro_content.rstrip().endswith(',')):
                    next_line = lines[j]
                    macro_content += next_line
                    brace_depth += next_line.count('{') - next_line.count('}')
                    paren_depth += next_line.count('(') - next_line.count(')')
                    j += 1

                # Extract rule names: look for patterns like "rule_name => base_name"
                # The rule name is the identifier before "=>"
                arrow_pattern = re.findall(r'(\w+)\s*=>\s*\w+', macro_content)
                for rule_name in arrow_pattern:
                    # Check we haven't already added this rule
                    if not any(r.name == rule_name for r in rules):
                        rules.append(RuleInfo(
                            name=rule_name,
                            type="rule",
                            is_parametric=False,
                            spec_file=rust_file,
                            from_use=False
                        ))
                        logger.log(
                            f"Extracted macro-generated rule '{rule_name}' from {rust_file.name}",
                            "DEBUG",
                            "RustParser"
                        )

            i += 1

        if rules:
            logger.log(
                f"Extracted {len(rules)} rules from {rust_file.name}",
                "INFO",
                "RustParser"
            )
        else:
            logger.log(
                f"No rules found in {rust_file.name}",
                "DEBUG",
                "RustParser"
            )

    except Exception as e:
        logger.log(
            f"Error parsing Rust file {rust_file}: {e}",
            "ERROR",
            "RustParser"
        )

    return rules
