"""
Flask web server for the Certora Dashboard.

Provides a web interface for viewing verification project status,
including conf files, rules, and verification results.
"""


import argparse
import json
import logging
import os
import sys
import threading
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file
from prover_output_utility.models import JobStatus  # type: ignore[import-untyped]

from src.utils.constants import ANTHROPIC_API_KEY_ENV
from src.dashboard.cex_manager import check_analysis_completion, get_analysis_key, launch_cex_analysis, load_cex_analyses
from src.dashboard.timeouter_manager import launch_timeouter, get_run_key, load_timeouter_runs
from src.dashboard.cloud_sync import get_last_cloud_sync_timestamp
from src.dashboard.constants import (
    DashboardEcosystem,
    DIR_CERTORA_INTERNAL,
    FILE_DASHBOARD_LOG,
    MODE_LOCAL,
    MODE_REMOTE,
    RUN_PROVENANCE_LOCAL,
    RUN_PROVENANCE_REMOTE,
    normalize_to_dashboard_ecosystem,
)
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.progress_tracker import load_progress, load_scan_progress, save_progress
from src.dashboard.scanner import ProjectScanner
from src.dashboard.sync_remote_jobs import sync_remote_jobs

# Track active sync threads per mode
_sync_threads: dict = {}


def _configure_all_logging_to_dashboard():
    """
    Configure Flask's werkzeug logger and Python's root logger to write to dashboard.log.

    This captures:
    - Flask HTTP request logs (127.0.0.1 - -)
    - Third-party library logs (prover_output_utility, etc.)
    - Any other logs using Python's standard logging
    """
    log_file = Path(DIR_CERTORA_INTERNAL) / FILE_DASHBOARD_LOG

    # Create file handler for dashboard.log with immediate flush
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=10*1024*1024,  # 10MB
        backupCount=5
    )

    # Force immediate flush after every write and strip ANSI color codes
    original_emit = file_handler.emit
    def emit_with_flush(record):
        # Strip ANSI color codes from the message
        if hasattr(record, 'msg') and isinstance(record.msg, str):
            import re
            # Remove ANSI escape sequences
            record.msg = re.sub(r'\x1b\[[0-9;]*m', '', record.msg)
        original_emit(record)
        if hasattr(file_handler.stream, 'flush'):
            file_handler.stream.flush()
    file_handler.emit = emit_with_flush

    # Set formatter (simpler format for Flask/third-party logs)
    formatter = logging.Formatter(
        '%(asctime)s [%(name)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)

    # Configure werkzeug logger (Flask HTTP logs)
    werkzeug_logger = logging.getLogger('werkzeug')
    werkzeug_logger.addHandler(file_handler)
    werkzeug_logger.setLevel(logging.INFO)

    # Configure root logger for third-party libraries
    root_logger = logging.getLogger()
    root_logger.addHandler(file_handler)
    root_logger.setLevel(logging.INFO)


# ============================================================================
# Helper Functions for Parametric Rule Method Handling
# ============================================================================
# These functions are used by both /api/scan and /api/runs/select endpoints
# to build complete method data for parametric rules.

def find_latest_job_with_method(method_name: str, status_list: list) -> str:
    """
    Find the most recent job where the given method was tested.

    This is used for the "latest-per-method" view, where each method can show
    results from a different job - specifically, the latest job where that
    method actually ran.

    Design choice: When viewing "latest" for a parametric rule, we don't force
    all methods to come from the same job. Instead, each method shows its own
    latest result, which provides the most up-to-date view of each method's status.

    Args:
        method_name: Name of the method to find
        status_list: List of RuleStatus objects (already sorted newest first)

    Returns:
        job_id of the latest job containing this method, or the latest job_id
        if method not found (fallback case that shouldn't normally occur)
    """
    for status in status_list:
        if status.method_statuses and method_name in status.method_statuses:
            return status.job_id

    # Fallback: return latest job if method somehow not found in any job
    return status_list[0].job_id if status_list else ""


def find_status_by_job_id(job_id: str, status_list: list):
    """
    Find a RuleStatus object by job_id.

    Used to retrieve the specific status information when a user has selected
    a particular job (either for the main rule or for an individual method).

    Args:
        job_id: The job identifier to find
        status_list: List of RuleStatus objects

    Returns:
        RuleStatus object if found, None otherwise
    """
    for status in status_list:
        if status.job_id == job_id:
            return status
    return None


def build_method_data_for_rule(
    rule_name: str,
    selected_job_id_rule_level: str,
    latest_status_job_id: str,
    all_rule_statuses_history: dict,
    user_run_selections: dict,
    get_available_runs_callback
):
    """
    Build complete method data for a parametric rule.

    This function implements the "latest-per-method" feature where:
    - When viewing latest: each method shows its status from its own latest job
    - When viewing historical: all methods show status from the selected job (or "not_run")

    Args:
        rule_name: Name of the rule
        selected_job_id_rule_level: The job_id selected for the main rule (from user selections or latest)
        latest_status_job_id: The job_id of the actual latest status
        all_rule_statuses_history: Full history dict (rule_name -> List[RuleStatus])
        user_run_selections: User's manual run selections
        get_available_runs_callback: Function to get available runs for a method

    Returns:
        Tuple of (display_method_statuses, method_runs, method_selections, processed_parametric_rule)
    """
    method_runs = {}
    method_selections = {}
    display_method_statuses = {}
    processed_parametric_rule = False

    # Check if this rule has methods (parametric rule)
    if rule_name in all_rule_statuses_history:
        # Step 1: Collect ALL unique methods across ALL jobs for this rule
        all_methods_across_jobs = set()
        for historical_status in all_rule_statuses_history[rule_name]:
            if historical_status.method_statuses:
                all_methods_across_jobs.update(historical_status.method_statuses.keys())

        # Only proceed if this is indeed a parametric rule (has methods)
        if all_methods_across_jobs:
            processed_parametric_rule = True

            # Step 2: Determine if user is viewing "latest" or a historical run
            is_latest_selected = (selected_job_id_rule_level == latest_status_job_id)

            # Step 3: Build status for each method
            user_selection = user_run_selections.get(rule_name, {})

            for method_name in all_methods_across_jobs:
                # Build available runs dropdown for this method
                method_runs[method_name] = get_available_runs_callback(rule_name, method_name)

                if not is_latest_selected:
                    # Historical mode: All methods locked to the selected historical run
                    method_selected_job_id = selected_job_id_rule_level
                    method_selections[method_name] = method_selected_job_id

                    # Look up method status from the selected historical job
                    historical_status = find_status_by_job_id(
                        method_selected_job_id,
                        all_rule_statuses_history[rule_name]
                    )

                    if historical_status and historical_status.method_statuses and method_name in historical_status.method_statuses:
                        # Method exists in this job
                        display_method_statuses[method_name] = historical_status.method_statuses[method_name]
                    else:
                        # Method doesn't exist in this job - show "not_run"
                        from src.dashboard.constants import STATUS_NOT_RUN
                        display_method_statuses[method_name] = STATUS_NOT_RUN
                else:
                    # Latest mode: Each method shows its own latest (or user-selected override)
                    if method_name in user_selection:
                        # User explicitly selected a run for this specific method
                        method_selected_job_id = user_selection[method_name]
                    else:
                        # No manual selection - find latest job where this method appeared
                        method_selected_job_id = find_latest_job_with_method(
                            method_name,
                            all_rule_statuses_history[rule_name]
                        )

                    method_selections[method_name] = method_selected_job_id

                    # Look up method status from its selected job
                    method_status_obj = find_status_by_job_id(
                        method_selected_job_id,
                        all_rule_statuses_history[rule_name]
                    )

                    if method_status_obj and method_status_obj.method_statuses and method_name in method_status_obj.method_statuses:
                        display_method_statuses[method_name] = method_status_obj.method_statuses[method_name]
                    else:
                        # Shouldn't happen if find_latest_job_with_method works correctly
                        from src.dashboard.constants import STATUS_NOT_RUN
                        display_method_statuses[method_name] = STATUS_NOT_RUN

    return display_method_statuses, method_runs, method_selections, processed_parametric_rule


def create_app(project_root: Path | None = None):
    """
    Create and configure the Flask application.

    Args:
        project_root: Path to the project root (CWD). If None, uses current directory.

    Returns:
        Configured Flask application
    """
    # Warn about missing API key but don't fail startup
    # CEX analysis will fail gracefully if the key is missing
    if not os.environ.get("WERKZEUG_RUN_MAIN"):  # Only check in main process
        if not os.environ.get(ANTHROPIC_API_KEY_ENV):
            warning_msg = f"""
================================================================================
WARNING: {ANTHROPIC_API_KEY_ENV} environment variable is not set
================================================================================

The dashboard will start, but CEX analysis features will not work.

To enable CEX analysis, set your API key:

    export {ANTHROPIC_API_KEY_ENV}="your-api-key-here"

Get an API key from: https://console.anthropic.com/

================================================================================
"""
            print(warning_msg, file=sys.stderr)

    if project_root is None:
        project_root = Path.cwd()

    # Create Flask app with template and static folders in dashboard package
    template_dir = Path(__file__).parent / "templates"
    static_dir = Path(__file__).parent / "static"

    app = Flask(
        __name__,
        template_folder=str(template_dir),
        static_folder=str(static_dir)
    )

    # Store project scanner in app config
    scanner = ProjectScanner(project_root, verbose=False)
    app.config["SCANNER"] = scanner
    app.config["PROJECT_ROOT"] = project_root

    # Configure logging to capture Flask and third-party logs
    _configure_all_logging_to_dashboard()

    @app.route("/")
    def index():
        """Render the main dashboard page."""
        project_root = app.config["PROJECT_ROOT"]

        # Try to read project name from package.json
        project_name = None
        package_json_path = project_root / "package.json"
        if package_json_path.exists():
            try:
                with open(package_json_path, 'r') as f:
                    package_data = json.load(f)
                    project_name = package_data.get("name")
            except Exception as e:
                logger.log(f"Error reading package.json: {e}", "WARNING", "DashboardServer")

        # Fallback: try to get name from git repo
        if not project_name:
            git_dir = project_root / ".git"
            if git_dir.exists():
                # Get the git remote origin URL and extract repo name
                import subprocess
                try:
                    result = subprocess.run(
                        ["git", "remote", "get-url", "origin"],
                        cwd=project_root,
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        # Extract repo name from URL (handles both HTTPS and SSH URLs)
                        remote_url = result.stdout.strip()
                        # Remove .git suffix if present
                        if remote_url.endswith(".git"):
                            remote_url = remote_url[:-4]
                        # Get the last part of the URL (repo name)
                        project_name = remote_url.split("/")[-1]
                except Exception as e:
                    logger.log(f"Error getting git repo name: {e}", "WARNING", "DashboardServer")

        # Fallback: use the containing folder name
        if not project_name:
            folder_name = project_root.name
            if folder_name:
                project_name = folder_name
            else:
                project_name = "unnamed"

        # Use project path for display (prefer env var for Docker, fallback to actual path)
        project_path = os.environ.get("PROJECT_PATH_DISPLAY", str(project_root.resolve()))

        return render_template(
            "dashboard.html",
            project_name=project_name,
            project_path=project_path
        )

    @app.route("/api/scan")
    def get_scan_data():
        """
        Get the latest scan data.

        Query params:
            mode: "local" (default) or "remote" - which job set to use

        Returns:
            JSON with scan data or error message
        """
        # Get mode from query parameters
        mode = request.args.get('mode', MODE_LOCAL)
        if mode not in [MODE_LOCAL, MODE_REMOTE]:
            mode = MODE_LOCAL

        # Get AST timeout setting (default 600 seconds)
        ast_timeout = request.args.get('astTimeout', 600, type=int)
        app.config['AST_TIMEOUT'] = ast_timeout

        logger.log(f"GET /api/scan - Starting scan data retrieval ({mode} mode, AST timeout: {ast_timeout}s)", "INFO", "DashboardServer")
        scanner = app.config["SCANNER"]

        # Check and perform migration if needed (only runs once if old format detected)
        # TODO: Re-enable when migration module is created
        # from src.dashboard.migration import check_and_migrate_if_needed
        # check_and_migrate_if_needed(scanner.dashboard_dir)

        # Check if we need to perform initial scan
        snapshot = scanner.get_latest_scan()
        logger.log(f"Latest scan snapshot: {snapshot is not None}", "INFO", "DashboardServer")

        if snapshot is None:
            # No scan exists, perform one
            logger.log("No scan found, performing initial scan", "INFO", "DashboardServer")
            snapshot = scanner.scan_project()
            logger.log(f"Initial scan complete - found {len(snapshot.confs)} confs, {len(snapshot.specs)} specs", "INFO", "DashboardServer")

            # Sync cloud statuses after initial scan for the selected mode
            logger.log(f"Syncing cloud statuses after initial scan ({mode} mode)", "INFO", "DashboardServer")
            scanner.sync_cloud_statuses(mode)
            logger.log(f"Cloud sync complete after initial scan ({mode} mode)", "INFO", "DashboardServer")

        # Get rule statuses for the selected mode
        rule_statuses = scanner.get_rule_statuses(mode)
        logger.log(f"Retrieved {len(rule_statuses)} rule statuses ({mode} mode)", "INFO", "DashboardServer")

        # Get full history of all rule statuses
        all_rule_statuses_history = scanner.get_all_rule_statuses_history()
        total_jobs = sum(len(jobs) for jobs in all_rule_statuses_history.values())
        logger.log(f"Retrieved history for {len(all_rule_statuses_history)} rules ({total_jobs} total jobs)", "INFO", "DashboardServer")

        # Get user's selected runs
        user_run_selections = scanner.get_user_run_selections()
        logger.log(f"Retrieved user selections for {len(user_run_selections)} rules", "INFO", "DashboardServer")

        # Check for completed CEX analyses
        check_analysis_completion(scanner.dashboard_dir, scanner.cwd)
        cex_analyses = load_cex_analyses(scanner.dashboard_dir)
        logger.log(f"Found {len(cex_analyses)} CEX analyses", "INFO", "DashboardServer")

        # Load timeouter runs
        timeouter_runs = load_timeouter_runs(scanner.dashboard_dir)
        logger.log(f"Found {len(timeouter_runs)} timeouter runs", "INFO", "DashboardServer")

        # Get the last cloud sync timestamp for this mode
        last_cloud_sync = get_last_cloud_sync_timestamp(scanner.dashboard_dir, mode)
        logger.log(f"Last cloud sync timestamp ({mode}): {last_cloud_sync}", "INFO", "DashboardServer")

        # Calculate compilation stats from ASTs
        successful_compilations = 0
        asts_mapping = None
        try:
            from src.dashboard.ast_manager import load_asts_mapping
            timestamp_dir = scanner.dashboard_dir / str(snapshot.timestamp)
            asts_mapping = load_asts_mapping(timestamp_dir)

            if asts_mapping:
                for conf_path, ast_info in asts_mapping.items():
                    # Count as successful if ast_path exists and no error
                    if ast_info.get("ast_path") and not ast_info.get("error"):
                        successful_compilations += 1
        except Exception as e:
            logger.log(f"Error loading AST mappings: {e}", "WARNING", "DashboardServer")

        # Convert snapshot to JSON-serializable format
        data = {
            "timestamp": snapshot.timestamp,
            "last_cloud_sync": last_cloud_sync,
            "confs": [],
            "specs": {},
            "statuses": {},
            "cex_analyses": {key: analysis.to_dict() for key, analysis in cex_analyses.items()},
            "timeouter_runs": {key: run.to_dict() for key, run in timeouter_runs.items()},
            "total_confs": len(snapshot.confs),
            "total_specs": len(snapshot.specs),
            "compilation_stats": {
                "successful": successful_compilations,
                "total": len(snapshot.confs)
            } if asts_mapping else None,
        }

        # Sort confs: main certora folder first, then subdirectories
        # A conf is in main folder if its parent is exactly "certora"
        def conf_sort_key(conf_info):
            conf_path = conf_info.conf_path
            # Get parent directory relative to project root
            try:
                rel_path = conf_path.relative_to(scanner.cwd)
                parent_parts = rel_path.parent.parts
                # If parent is exactly ("certora",), it's in main folder - sort first (0)
                # Otherwise sort by path (1, then alphabetically)
                if parent_parts == ("certora",):
                    return (0, str(conf_path))
                else:
                    return (1, str(conf_path))
            except ValueError:
                # Fallback if path is not relative to cwd
                return (1, str(conf_path))

        sorted_confs = sorted(snapshot.confs, key=conf_sort_key)

        # Add conf data
        for conf_info in sorted_confs:
            # Check if any rule in this conf has a RUNNING job
            # Use the cached job statuses we just fetched
            has_running_job = False
            for rule_name in conf_info.rules:
                if rule_name in rule_statuses:
                    status = rule_statuses[rule_name]
                    if status.job_status == JobStatus.RUNNING:
                        has_running_job = True
                        logger.log(f"Found running job {status.job_id} for rule {rule_name} in conf {conf_info.conf_path.name}", "INFO", "Server")
                        break

            # Compute relative path from project root for ToC grouping
            try:
                # Resolve cwd to absolute path in case it's relative (e.g., ".")
                abs_cwd = scanner.cwd.resolve()
                rel_path = conf_info.conf_path.relative_to(abs_cwd)
                conf_rel_path = str(rel_path).replace("\\", "/")  # Normalize Windows paths
            except ValueError:
                conf_rel_path = conf_info.conf_path.name

            data["confs"].append({
                "conf_path": str(conf_info.conf_path),
                "conf_name": conf_info.conf_path.name,
                "conf_rel_path": conf_rel_path,
                "main_spec": str(conf_info.main_spec),
                "all_specs": [str(s) for s in conf_info.all_specs],
                "rules": conf_info.rules,
                "has_running_job": has_running_job,
                "conf_type": conf_info.conf_type,
            })

        # Add spec data
        for spec_path, spec_info in snapshot.specs.items():
            data["specs"][str(spec_path)] = {
                "path": str(spec_path),
                "name": spec_path.name,
                "hash": spec_info.hash,
                "rules": [
                    {
                        "name": rule.name,
                        "type": rule.type,
                        "is_parametric": rule.is_parametric,
                        "from_use": rule.from_use,
                    }
                    for rule in spec_info.rules
                ],
                "imported_specs": [str(s) for s in spec_info.imported_specs],
            }

        # Helper function to filter available runs based on mode and eligibility
        # Note: find_latest_job_with_method() and find_status_by_job_id() are now
        # defined as module-level functions (lines 97-142) and can be used directly
        def get_available_runs_for_rule(rule_name: str, method_name: str | None = None):
            """
            Get available runs for a rule/method, filtered by mode and eligibility.

            Eligibility criteria:
            - Has both job_id and run_url
            - Matches mode filter (local mode: only local, remote mode: local+remote)
            - For methods: job must have tested that specific method
            """
            if rule_name not in all_rule_statuses_history:
                return []

            available = []
            for status in all_rule_statuses_history[rule_name]:
                # Check mode filter
                if mode == MODE_LOCAL and status.run_provenance != RUN_PROVENANCE_LOCAL:
                    continue
                # Remote mode accepts both local and remote

                # Check eligibility (must have job_id and run_url)
                if not status.job_id or not status.run_url:
                    continue

                # For method-specific requests, check if this job tested that method
                if method_name:
                    if not status.method_statuses or method_name not in status.method_statuses:
                        continue

                available.append({
                    "job_id": status.job_id,
                    "timestamp": status.timestamp,
                    "run_url": status.run_url,
                    "overall_status": status.overall_status,
                    "method_status": status.method_statuses.get(method_name) if method_name and status.method_statuses else None,
                    "run_provenance": status.run_provenance,
                    "conf_path": status.conf_path,
                })

            return available

        # Add status data with available runs and user selections
        for rule_name, status in rule_statuses.items():
            # Get available runs for this rule
            available_runs = get_available_runs_for_rule(rule_name)

            # Determine selected run (user selection or latest)
            user_selection = user_run_selections.get(rule_name, {})
            selected_job_id_rule_level = user_selection.get("_rule_level", status.job_id)

            # Look up the actual selected job's status from history (if user selected a different run)
            display_status = status  # Default to latest
            if selected_job_id_rule_level != status.job_id and rule_name in all_rule_statuses_history:
                # User selected a different run - find it in history
                for historical_status in all_rule_statuses_history[rule_name]:
                    if historical_status.job_id == selected_job_id_rule_level:
                        display_status = historical_status
                        break

            # Load spec diff from file for the selected job (not from status object)
            spec_diff_equivalent = None
            if display_status.job_id:
                from src.dashboard.storage import load_spec_diff_for_job
                spec_diff_data = load_spec_diff_for_job(timestamp_dir, display_status.job_id)
                if spec_diff_data and rule_name in spec_diff_data.get("rules", {}):
                    spec_diff_equivalent = spec_diff_data["rules"][rule_name].get("equivalent")

            # Construct full job ID from URL (userId_jobHash) for diff lookups
            # The display_status.job_id may only contain the hash part
            full_job_id_for_diff = display_status.job_id
            if display_status.run_url:
                import re
                match = re.search(r'/output/(\d+)/([a-f0-9]+)', display_status.run_url)
                if match:
                    job_number = match.group(1)
                    job_hash = match.group(2)
                    full_job_id_for_diff = f"{job_number}_{job_hash}"

            # Load conf diff from file for the selected job
            conf_diff_equivalent = None
            if full_job_id_for_diff:
                from src.dashboard.storage import load_conf_diff_for_job
                conf_diff_data = load_conf_diff_for_job(timestamp_dir, full_job_id_for_diff)
                if conf_diff_data:
                    conf_diff_equivalent = conf_diff_data.get("equivalent")

            # Load source diff from file for the selected job
            source_diff_equivalent = None
            source_diff_error = None
            if full_job_id_for_diff:
                from src.dashboard.storage import load_source_diff_for_job
                source_diff_data = load_source_diff_for_job(timestamp_dir, full_job_id_for_diff)
                if source_diff_data:
                    source_diff_equivalent = source_diff_data.get("equivalent")
                    # If equivalent is None, there was an error - store the reason
                    if source_diff_equivalent is None:
                        source_diff_error = source_diff_data.get("reason")

            # ====================================================================
            # Build method-level available runs and selections for parametric rules
            # ====================================================================
            # Design: For parametric rules (with methods/sub-rules), we collect ALL unique
            # methods from across ALL jobs in the rule's history. This allows users to see
            # the full picture of all methods that have been tested over time.
            #
            # Two modes of operation:
            # 1. "Latest per method" (default): Each method shows its status from the most
            #    recent job where that method was tested. Methods can have different selected
            #    jobs. Main rule shows aggregated status.
            #
            # 2. "Historical locked" (when user selects non-latest run): All methods are
            #    locked to the same selected job. Methods not in that job show "not_run".
            #    Main rule shows "no_status" instead of aggregating.
            #
            # The user switches between modes by selecting different runs in the main rule
            # dropdown. Selecting the latest run switches back to "latest per method" mode.
            method_runs = {}
            method_selections = {}
            display_method_statuses = {}
            processed_parametric_rule = False  # Track if we processed a parametric rule with methods

            # Check if this rule has methods (parametric rule)
            # We need to collect ALL methods from history, not just from display_status
            if rule_name in all_rule_statuses_history:
                # Step 1: Collect ALL unique methods across ALL jobs for this rule
                all_methods_across_jobs = set()
                for historical_status in all_rule_statuses_history[rule_name]:
                    if historical_status.method_statuses:
                        all_methods_across_jobs.update(historical_status.method_statuses.keys())

                # Only proceed if this is indeed a parametric rule (has methods)
                if all_methods_across_jobs:
                    processed_parametric_rule = True  # Mark that we're processing a parametric rule

                    # Step 2: Determine if user is viewing "latest" or a historical run
                    is_latest_selected = (selected_job_id_rule_level == status.job_id)

                    # Step 3: Build status for each method
                    for method_name in all_methods_across_jobs:
                        # Build available runs dropdown for this method
                        # Important: This still only shows runs where THIS method was tested
                        method_runs[method_name] = get_available_runs_for_rule(rule_name, method_name)

                        if not is_latest_selected:
                            # Historical mode: All methods locked to the selected historical run
                            method_selected_job_id = selected_job_id_rule_level
                            method_selections[method_name] = method_selected_job_id

                            # Look up method status from the selected historical job
                            historical_status = find_status_by_job_id(
                                method_selected_job_id,
                                all_rule_statuses_history[rule_name]
                            )

                            if historical_status and historical_status.method_statuses and method_name in historical_status.method_statuses:
                                # Method exists in this job
                                display_method_statuses[method_name] = historical_status.method_statuses[method_name]
                            else:
                                # Method doesn't exist in this job - show "not_run"
                                from src.dashboard.constants import STATUS_NOT_RUN
                                display_method_statuses[method_name] = STATUS_NOT_RUN
                        else:
                            # Latest mode: Each method shows its own latest (or user-selected override)
                            # Check if user manually selected a specific run for this method
                            if method_name in user_selection:
                                # User explicitly selected a run for this specific method
                                method_selected_job_id = user_selection[method_name]
                            else:
                                # No manual selection - find latest job where this method appeared
                                method_selected_job_id = find_latest_job_with_method(
                                    method_name,
                                    all_rule_statuses_history[rule_name]
                                )

                            method_selections[method_name] = method_selected_job_id

                            # Look up method status from its selected job
                            method_status_obj = find_status_by_job_id(
                                method_selected_job_id,
                                all_rule_statuses_history[rule_name]
                            )

                            if method_status_obj and method_status_obj.method_statuses and method_name in method_status_obj.method_statuses:
                                display_method_statuses[method_name] = method_status_obj.method_statuses[method_name]
                            else:
                                # Shouldn't happen if find_latest_job_with_method works correctly
                                from src.dashboard.constants import STATUS_NOT_RUN
                                display_method_statuses[method_name] = STATUS_NOT_RUN

                    # Step 4: Compute main rule overall_status
                    if not is_latest_selected:
                        # Historical run selected: Don't aggregate, show "no_status"
                        # Design choice: When viewing a historical run, methods may come from
                        # different jobs in latest mode, so aggregation would be misleading.
                        # User must select "latest" to see proper aggregated status.
                        from src.dashboard.constants import STATUS_NO_STATUS
                        display_status.overall_status = STATUS_NO_STATUS
                    else:
                        # Latest mode: Aggregate the method statuses we just computed
                        # These may come from different jobs (latest per method)
                        # Important: Must recompute here because display_status.overall_status
                        # only reflects the latest single job, not the aggregation across
                        # all methods from their respective latest jobs.
                        from src.dashboard.status_processor import aggregate_method_statuses
                        display_status.overall_status = aggregate_method_statuses(
                            display_method_statuses,
                            display_status.job_status
                        )

            data["statuses"][rule_name] = {
                "overall_status": display_status.overall_status,
                # For parametric rules, always use display_method_statuses (which includes all methods across jobs)
                # For non-parametric rules, use method_statuses from display_status
                # Bug fix: Don't rely on dict truthiness - empty dict {} is falsy but valid
                "method_statuses": display_method_statuses if processed_parametric_rule else (display_status.method_statuses or {}),
                "job_id": display_status.job_id,
                "full_job_id": full_job_id_for_diff,  # Full job ID (userId_jobHash) for diff lookups
                "timestamp": display_status.timestamp,
                "run_url": display_status.run_url,
                "job_status": display_status.job_status.value if display_status.job_status else "",
                "spec_diff_equivalent": spec_diff_equivalent,  # Use the value loaded from file, not from status
                "conf_diff_equivalent": conf_diff_equivalent,  # Use the value loaded from file, not from status
                "source_diff_equivalent": source_diff_equivalent,  # Use the value loaded from file, not from status
                "source_diff_error": source_diff_error,  # Error message if source diff failed
                "has_ambiguous_conf": display_status.has_ambiguous_conf,
                "matched_main_contract": display_status.matched_main_contract,
                "cloud_rule_name": display_status.cloud_rule_name,
                "ecosystem": display_status.ecosystem,
                # New fields for "Select Run" feature
                "available_runs": available_runs,
                "selected_job_id": selected_job_id_rule_level,
                "method_available_runs": method_runs,
                "method_selected_job_ids": method_selections,
            }

        return jsonify(data)

    @app.route("/api/scan/refresh", methods=["POST"])
    def refresh_scan():
        """
        Trigger a new project scan and cloud sync in background.

        JSON body:
            mode: "local" (default) or "remote" - which job set to sync
            allUsers: true/false - whether to fetch jobs from all users (remote mode only)
            lookbackDays: number - how many days to look back for jobs

        Returns:
            JSON with success status (sync runs in background)
        """
        # Get parameters from request body
        data = request.get_json() or {}
        mode = data.get('mode', MODE_LOCAL)
        if mode not in [MODE_LOCAL, MODE_REMOTE]:
            mode = MODE_LOCAL

        all_users = data.get('allUsers', True)
        lookback_days = data.get('lookbackDays', 30)
        ast_timeout = data.get('astTimeout', 600)
        app.config['AST_TIMEOUT'] = ast_timeout

        logger.log(f"POST /api/scan/refresh - Starting scan refresh ({mode} mode, allUsers={all_users}, lookbackDays={lookback_days}, astTimeout={ast_timeout})", "INFO", "DashboardServer")
        scanner = app.config["SCANNER"]

        # Check if sync is already running for this mode
        if mode in _sync_threads and _sync_threads[mode].is_alive():
            logger.log(f"Sync already running for {mode} mode", "INFO", "DashboardServer")
            return jsonify({
                "success": False,
                "message": f"Sync already in progress for {mode} mode"
            }), 409

        # Perform new scan (quick operation)
        logger.log("Triggering project scan", "INFO", "DashboardServer")
        snapshot = scanner.scan_project()
        logger.log(f"Scan complete - {len(snapshot.confs)} confs, {len(snapshot.specs)} specs", "INFO", "DashboardServer")

        # Start cloud sync in background thread
        def sync_in_background():
            try:
                logger.log(f"Background cloud sync starting ({mode} mode)", "INFO", "DashboardServer")

                # For remote mode, first sync the remote jobs file
                if mode == MODE_REMOTE:
                    logger.log(f"Syncing remote jobs from Certora API (allUsers={all_users}, lookbackDays={lookback_days})...", "INFO", "DashboardServer")
                    sync_remote_jobs(scanner.cwd, all_users=all_users, lookback_days=lookback_days)
                    logger.log("Remote jobs sync complete", "INFO", "DashboardServer")

                # Then sync cloud statuses from the jobs file
                scanner.sync_cloud_statuses(mode)
                logger.log(f"Background cloud sync complete ({mode} mode)", "INFO", "DashboardServer")
            except Exception as e:
                logger.log(f"Background cloud sync failed ({mode} mode): {e}", "ERROR", "DashboardServer")
                # Mark progress as failed
                progress = load_progress(scanner.dashboard_dir, mode)
                if progress:
                    progress.status = "failed"
                    progress.error_message = str(e)
                    save_progress(scanner.dashboard_dir, progress, mode)

        thread = threading.Thread(target=sync_in_background, daemon=True)
        _sync_threads[mode] = thread
        thread.start()

        return jsonify({
            "success": True,
            "timestamp": snapshot.timestamp,
            "message": f"Scan completed, cloud sync running in background"
        })

    @app.route("/api/scan/progress")
    def get_sync_progress():
        """
        Get the progress of an ongoing cloud sync.

        Query params:
            mode: "local" (default) or "remote"

        Returns:
            JSON with sync progress
        """
        mode = request.args.get('mode', MODE_LOCAL)
        if mode not in [MODE_LOCAL, MODE_REMOTE]:
            mode = MODE_LOCAL

        scanner = app.config["SCANNER"]
        progress = load_progress(scanner.dashboard_dir, mode)

        if not progress:
            return jsonify({
                "has_progress": False
            })

        # Check if thread is still alive
        is_running = mode in _sync_threads and _sync_threads[mode].is_alive()

        return jsonify({
            "has_progress": True,
            "total_jobs": progress.total_jobs,
            "processed_jobs": progress.processed_jobs,
            "current_job_id": progress.current_job_id,
            "status": progress.status,
            "error_message": progress.error_message,
            "is_running": is_running,
            "start_time": progress.start_time,
            "last_update_time": progress.last_update_time,
            "phase": progress.phase,
            "total_rules": progress.total_rules,
            "processed_rules": progress.processed_rules,
            "current_rule": progress.current_rule
        })

    @app.route("/api/scan/scan-progress")
    def get_scan_progress():
        """
        Get the progress of an ongoing project scan.

        Returns:
            JSON with scan progress
        """
        scanner = app.config["SCANNER"]
        progress = load_scan_progress(scanner.dashboard_dir)

        if not progress:
            return jsonify({
                "has_progress": False
            })

        return jsonify({
            "has_progress": True,
            "phase": progress.phase,
            "total_items": progress.total_items,
            "processed_items": progress.processed_items,
            "successful_items": progress.successful_items,
            "current_item": progress.current_item,
            "status": progress.status,
            "error_message": progress.error_message,
            "start_time": progress.start_time,
            "last_update_time": progress.last_update_time
        })

    @app.route("/api/scan/spec-diff/<path:rule_name>")
    def get_spec_diff(rule_name):
        """
        Get the spec diff data for a specific rule.

        Args:
            rule_name: The name of the rule to get diff for

        Query params:
            job_id: Optional job ID to load diff for (if not provided, uses current rule status)

        Returns:
            JSON with diff data or error message
        """
        from flask import request
        from src.dashboard.storage import load_spec_diff_for_job

        scanner = app.config["SCANNER"]

        # Get latest snapshot to find timestamp
        snapshot = scanner.get_latest_scan()
        if not snapshot:
            return jsonify({
                "error": "No scan data available"
            }), 404

        timestamp_dir = scanner.dashboard_dir / str(snapshot.timestamp)

        # Get job_id from query param OR from current rule status
        job_id = request.args.get('job_id')

        if not job_id:
            # Get from current rule status
            rule_statuses = scanner.get_rule_statuses(mode="remote")
            rule_status = rule_statuses.get(rule_name)

            if not rule_status:
                return jsonify({
                    "error": f"No status found for rule: {rule_name}"
                }), 404

            if not rule_status.job_id:
                return jsonify({
                    "error": f"Rule {rule_name} has no associated job_id"
                }), 404

            job_id = rule_status.job_id
            logger.log(f"Using job_id from rule status: {job_id}", "INFO", "DashboardServer")

        # Load diff for specific job
        diff_data = load_spec_diff_for_job(timestamp_dir, job_id)

        if not diff_data:
            return jsonify({
                "error": f"No spec diff found for job: {job_id}"
            }), 404

        if rule_name not in diff_data.get('rules', {}):
            return jsonify({
                "error": f"No diff data for rule {rule_name} in job {job_id}"
            }), 404

        rule_diff = diff_data['rules'][rule_name]

        return jsonify({
            "rule_name": rule_name,
            "job_id": diff_data['job_id'],
            "job_url": diff_data['job_url'],
            "computed_at": diff_data['computed_at'],
            "equivalent": rule_diff.get("equivalent"),
            "reason": rule_diff.get("reason"),
            "diff_data": rule_diff.get("diff_data")  # Already has code snippets
        })

    @app.route("/api/scan/conf-diff/<job_id>")
    def get_conf_diff(job_id):
        """
        Get the conf diff data for a specific job.

        Args:
            job_id: The job ID to get conf diff for

        Returns:
            JSON with diff data or error message
        """
        from src.dashboard.storage import load_conf_diff_for_job

        scanner = app.config["SCANNER"]

        # Get latest snapshot to find timestamp
        snapshot = scanner.get_latest_scan()
        if not snapshot:
            return jsonify({
                "error": "No scan data available"
            }), 404

        timestamp_dir = scanner.dashboard_dir / str(snapshot.timestamp)

        # Load diff for specific job
        diff_data = load_conf_diff_for_job(timestamp_dir, job_id)

        if not diff_data:
            return jsonify({
                "error": f"No conf diff found for job: {job_id}"
            }), 404

        return jsonify({
            "job_id": diff_data['job_id'],
            "job_url": diff_data['job_url'],
            "computed_at": diff_data['computed_at'],
            "equivalent": diff_data.get("equivalent"),
            "reason": diff_data.get("reason"),
            "diff_data": diff_data.get("diff_data")
        })

    @app.route("/api/scan/source-diff/<job_id>")
    def get_source_diff(job_id):
        """
        Get the source diff data for a specific job.

        Args:
            job_id: The job ID to get source diff for

        Returns:
            JSON with diff data or error message
        """
        from src.dashboard.storage import load_source_diff_for_job

        scanner = app.config["SCANNER"]

        # Get latest snapshot to find timestamp
        snapshot = scanner.get_latest_scan()
        if not snapshot:
            return jsonify({
                "error": "No scan data available"
            }), 404

        timestamp_dir = scanner.dashboard_dir / str(snapshot.timestamp)

        # Load diff for specific job
        diff_data = load_source_diff_for_job(timestamp_dir, job_id)

        if not diff_data:
            return jsonify({
                "error": f"No source diff found for job: {job_id}",
                "reason": "Source diff not computed or job not found"
            }), 404

        return jsonify({
            "job_id": diff_data['job_id'],
            "equivalent": diff_data.get("equivalent"),
            "reason": diff_data.get("reason"),
            "file_diffs": diff_data.get("file_diffs", []),
            "path_replacement": diff_data.get("path_replacement")
        })

    @app.route("/api/status/check")
    def check_status():
        """
        Check if the current scan is up-to-date.

        Returns:
            JSON with status information
        """
        scanner = app.config["SCANNER"]

        is_up_to_date, changed_specs, affected_confs = scanner.check_scan_up_to_date()

        return jsonify({
            "is_up_to_date": is_up_to_date,
            "changed_specs": [str(s) for s in changed_specs],
            "affected_confs": [str(c) for c in affected_confs],
            "changed_count": len(changed_specs),
            "affected_count": len(affected_confs),
        })

    @app.route("/api/cloud/sync", methods=["POST"])
    def sync_cloud():
        """
        Sync statuses from cloud verification runs.

        Returns:
            JSON with sync results
        """
        scanner = app.config["SCANNER"]
        logger.log("Syncing cloud statuses via API request", "INFO", "DashboardServer")

        # Sync statuses
        statuses = scanner.sync_cloud_statuses()

        return jsonify({
            "success": True,
            "synced_count": len(statuses),
            "message": f"Synced {len(statuses)} rule statuses from cloud"
        })

    @app.route("/api/cexanalyzer/launch", methods=["POST"])
    def launch_cexanalyzer():
        """
        Launch CEX analyzer for a violated rule.

        Request body:
            {
                "job_id": "...",
                "rule_name": "...",
                "method_name": "...",  # optional, for parametric rules
                "cloud_rule_name": "...",  # optional, full cloud rule name for Move
                "ecosystem": "..."  # optional, "evm" or "move"
            }

        Returns:
            JSON with launch result and analysis info
        """
        scanner = app.config["SCANNER"]
        data = request.get_json()
        job_id = data.get("job_id")
        rule_name = data.get("rule_name")
        method_name = data.get("method_name")
        run_url = data.get("run_url")
        cloud_rule_name = data.get("cloud_rule_name")
        ecosystem_str = data.get("ecosystem", "evm")

        if not job_id or not rule_name or not run_url:
            return jsonify({
                "success": False,
                "error": "Missing job_id, rule_name, or run_url"
            }), 400

        # Normalize ecosystem to DashboardEcosystem
        try:
            ecosystem = normalize_to_dashboard_ecosystem(ecosystem_str)
        except ValueError as e:
            return jsonify({
                "success": False,
                "error": f"Invalid ecosystem: {e}"
            }), 400

        logger.log(
            f"Launching CEX analyzer for rule '{rule_name}' (cloud: '{cloud_rule_name}', ecosystem: {ecosystem.value}) in job {job_id}",
            "INFO",
            "DashboardServer"
        )

        try:
            # Launch analysis
            analysis, was_launched = launch_cex_analysis(
                job_id,
                rule_name,
                method_name,
                run_url,
                scanner.dashboard_dir,
                scanner.cwd,
                cloud_rule_name,
                ecosystem
            )

            if was_launched:
                message = f"CEX Analyzer launched for {rule_name}"
                if method_name:
                    message += f" ({method_name})"
            else:
                message = f"CEX analysis already running for {rule_name}"
                if method_name:
                    message += f" ({method_name})"

            analysis_key = get_analysis_key(job_id, rule_name, method_name)

            return jsonify({
                "success": True,
                "message": message,
                "was_launched": was_launched,
                "analysis_key": analysis_key,
                "analysis": analysis.to_dict()
            })

        except Exception as e:
            logger.log(
                f"Error launching CEX analyzer: {e}",
                "ERROR",
                "DashboardServer"
            )
            return jsonify({
                "success": False,
                "error": str(e)
            }), 500

    @app.route("/api/timeouter/launch", methods=["POST"])
    def launch_timeouter_endpoint():
        """
        Launch timeouter to crack a timeout.

        Request body:
            {
                "job_id": "...",
                "rule_name": "...",
                "method_name": "...",
                "run_url": "..."
            }

        Returns:
            JSON with launch result and group URL
        """
        scanner = app.config["SCANNER"]
        data = request.get_json()
        job_id = data.get("job_id")
        rule_name = data.get("rule_name")
        method_name = data.get("method_name")
        run_url = data.get("run_url")
        use_method = data.get("use_method", True)  # Default to True for backward compat

        if not job_id or not rule_name or not run_url:
            return jsonify({
                "success": False,
                "error": "Missing job_id, rule_name, or run_url"
            }), 400

        # Log appropriate message based on use_method
        if use_method and method_name:
            logger.log(
                f"Launching timeouter for method '{method_name}' in rule '{rule_name}' (job {job_id})",
                "INFO",
                "DashboardServer"
            )
        else:
            logger.log(
                f"Launching timeouter for full rule '{rule_name}' (job {job_id})",
                "INFO",
                "DashboardServer"
            )

        try:
            # Launch timeouter
            run_info, was_launched = launch_timeouter(
                scanner.cwd,
                scanner.dashboard_dir,
                run_url,
                job_id,
                rule_name,
                method_name,
                use_method
            )

            if was_launched:
                if use_method and method_name:
                    message = f"Timeouter launched for {rule_name} ({method_name})"
                else:
                    message = f"Timeouter launched for {rule_name} (full rule)"
            else:
                if use_method and method_name:
                    message = f"Timeouter already {run_info.status} for {rule_name} ({method_name})"
                else:
                    message = f"Timeouter already {run_info.status} for {rule_name} (full rule)"

            run_key = get_run_key(job_id, rule_name, method_name, use_method)

            return jsonify({
                "success": True,
                "message": message,
                "was_launched": was_launched,
                "run_key": run_key,
                "group_url": run_info.group_url,
                "group_id": run_info.group_id,
                "status": run_info.status
            })

        except Exception as e:
            logger.log(
                f"Error launching timeouter: {e}",
                "ERROR",
                "DashboardServer"
            )
            return jsonify({
                "success": False,
                "error": str(e)
            }), 500

    @app.route("/api/timeouter/status/<run_key>", methods=["GET"])
    def get_timeouter_status(run_key):
        """
        Get current status of a timeouter run.

        Args:
            run_key: Unique run key (from launch response)

        Returns:
            JSON with status, group_url, and elapsed time
        """
        scanner = app.config["SCANNER"]

        try:
            runs = load_timeouter_runs(scanner.dashboard_dir)

            if run_key not in runs:
                return jsonify({
                    "success": False,
                    "error": "Run not found"
                }), 404

            run_info = runs[run_key]

            # Calculate elapsed time
            elapsed_seconds = int(time.time()) - run_info.timestamp
            elapsed_minutes = elapsed_seconds // 60

            return jsonify({
                "success": True,
                "status": run_info.status,
                "group_url": run_info.group_url,
                "group_id": run_info.group_id,
                "elapsed_seconds": elapsed_seconds,
                "elapsed_minutes": elapsed_minutes,
                "timestamp": run_info.timestamp
            })

        except Exception as e:
            logger.log(
                f"Error getting timeouter status for {run_key}: {e}",
                "ERROR",
                "DashboardServer"
            )
            return jsonify({
                "success": False,
                "error": str(e)
            }), 500

    @app.route("/api/runs/select", methods=["POST"])
    def select_run():
        """
        Handle user selecting a different run for a rule/method.

        Request body:
            {
                "rule_name": "myRule",
                "method_name": "myMethod",  // optional, null for rule-level
                "job_id": "60724_abc123",
                "mode": "local" or "remote"
            }

        Returns:
            JSON with updated status and spec diff status
        """
        scanner = app.config["SCANNER"]
        data = request.get_json()
        rule_name = data.get("rule_name")
        method_name = data.get("method_name")
        job_id = data.get("job_id")
        mode = data.get("mode", MODE_LOCAL)
        ast_timeout = data.get("astTimeout", 600)
        app.config['AST_TIMEOUT'] = ast_timeout

        if not rule_name or not job_id:
            return jsonify({
                "success": False,
                "error": "Missing rule_name or job_id"
            }), 400

        logger.log(
            f"POST /api/runs/select - {rule_name}" + (f":{method_name}" if method_name else "") + f" -> {job_id}",
            "INFO",
            "DashboardServer"
        )

        try:
            from src.dashboard.storage import load_user_run_selections, save_user_run_selections

            # Load current selections
            selections = load_user_run_selections(scanner.dashboard_dir)

            # Update selection for this rule/method
            if rule_name not in selections:
                selections[rule_name] = {}

            # ====================================================================
            # Handle selection update logic
            # ====================================================================
            # Design: When user selects a run for the main rule (method_name is None),
            # we need to cascade this selection to ALL methods. This implements the
            # "historical locked" mode where all methods sync to the same job.
            #
            # Special case: When user selects the LATEST run for the main rule, we
            # clear all selections to revert to "latest per method" mode.
            #
            # When user selects a run for a specific method (method_name is not None),
            # we only update that method's selection - this allows individual overrides.

            if method_name:
                # User selected a run for a specific method - only update that method
                selections[rule_name][method_name] = job_id
            else:
                # User selected a run for the main rule - cascade to all methods
                # First, get all methods for this rule from history
                all_statuses_history_for_update = scanner.get_all_rule_statuses_history()

                if rule_name in all_statuses_history_for_update:
                    all_methods = set()
                    for historical_status in all_statuses_history_for_update[rule_name]:
                        if historical_status.method_statuses:
                            all_methods.update(historical_status.method_statuses.keys())

                    # Check if selecting the latest run (revert to "latest per method" mode)
                    rule_statuses = scanner.get_rule_statuses(mode)
                    latest_status = rule_statuses.get(rule_name)
                    is_selecting_latest = (latest_status and job_id == latest_status.job_id)

                    if is_selecting_latest:
                        # Reverting to "latest per method" mode
                        # Clear rule-level selection
                        if "_rule_level" in selections[rule_name]:
                            del selections[rule_name]["_rule_level"]

                        # Clear all method-level selections (let them default to their own latest)
                        for method in all_methods:
                            if method in selections[rule_name]:
                                del selections[rule_name][method]

                        logger.log(
                            f"Cleared selections for {rule_name} - reverting to latest-per-method mode",
                            "INFO",
                            "DashboardServer"
                        )
                    else:
                        # Selecting a historical run - lock all methods to this job
                        selections[rule_name]["_rule_level"] = job_id

                        # Update ALL methods to this job
                        for method in all_methods:
                            selections[rule_name][method] = job_id

                        logger.log(
                            f"Locked {len(all_methods)} methods for {rule_name} to job {job_id}",
                            "INFO",
                            "DashboardServer"
                        )

            # Save updated selections
            save_user_run_selections(selections, scanner.dashboard_dir)

            # Get the full history to find the selected job's status
            all_statuses_history = scanner.get_all_rule_statuses_history()

            if rule_name not in all_statuses_history:
                return jsonify({
                    "success": False,
                    "error": f"Rule {rule_name} not found in history"
                }), 404

            # Find the selected job in history
            selected_status = None
            for status in all_statuses_history[rule_name]:
                if status.job_id == job_id:
                    selected_status = status
                    break

            if not selected_status:
                return jsonify({
                    "success": False,
                    "error": f"Job {job_id} not found for rule {rule_name}"
                }), 404

            # Check if spec diff exists for this job
            from src.dashboard.storage import load_spec_diff_for_job, load_conf_diff_for_job, load_source_diff_for_job
            snapshot = scanner.get_latest_scan()
            timestamp_dir = scanner.dashboard_dir / str(snapshot.timestamp)

            # Construct full job ID from URL for diff lookups
            full_job_id_for_diff = job_id
            if selected_status.run_url:
                import re
                match = re.search(r'/output/(\d+)/([a-f0-9]+)', selected_status.run_url)
                if match:
                    job_number = match.group(1)
                    job_hash = match.group(2)
                    full_job_id_for_diff = f"{job_number}_{job_hash}"

            spec_diff_data = load_spec_diff_for_job(timestamp_dir, job_id)

            spec_diff_status = "unknown"
            needs_computation = False
            spec_diff_equivalent = None
            spec_diff_error = None

            if spec_diff_data:
                # Check if this rule has diff data
                if rule_name in spec_diff_data.get("rules", {}):
                    rule_diff = spec_diff_data["rules"][rule_name]
                    equivalent = rule_diff.get("equivalent")
                    reason = rule_diff.get("reason")

                    if equivalent is not None:
                        spec_diff_status = "available"
                        spec_diff_equivalent = equivalent
                    elif reason and ("failed" in reason.lower() or "error" in reason.lower()):
                        # Computation failed with error
                        spec_diff_status = "failed"
                        spec_diff_error = reason
                    else:
                        spec_diff_status = "unknown"
                else:
                    # Job diff exists but this rule isn't in it - need to compute
                    spec_diff_status = "computing"
                    needs_computation = True
            else:
                # No diff data for this job at all - need to compute
                spec_diff_status = "computing"
                needs_computation = True

            # Check conf diff status
            conf_diff_data = load_conf_diff_for_job(timestamp_dir, full_job_id_for_diff)
            conf_diff_status = "unknown"
            conf_diff_equivalent = None

            if conf_diff_data:
                equivalent = conf_diff_data.get("equivalent")
                if equivalent is not None:
                    conf_diff_status = "available"
                    conf_diff_equivalent = equivalent
                else:
                    # File exists but equivalent is None - either computing or failed
                    reason = conf_diff_data.get("reason", "")
                    if reason and ("failed" in reason.lower() or "error" in reason.lower()):
                        conf_diff_status = "failed"
                    else:
                        conf_diff_status = "unknown"
            else:
                # No conf diff data - will be computed if spec diff needs computation
                if needs_computation:
                    conf_diff_status = "computing"

            # Check source diff status
            source_diff_data = load_source_diff_for_job(timestamp_dir, full_job_id_for_diff)
            source_diff_status = "unknown"
            source_diff_equivalent = None
            source_diff_error = None

            if source_diff_data:
                equivalent = source_diff_data.get("equivalent")
                if equivalent is not None:
                    source_diff_status = "available"
                    source_diff_equivalent = equivalent
                else:
                    # File exists but equivalent is None - either computing or failed
                    reason = source_diff_data.get("reason", "")
                    if reason and ("failed" in reason.lower() or "error" in reason.lower()):
                        source_diff_status = "failed"
                        source_diff_error = reason
                    else:
                        source_diff_status = "unknown"
            else:
                # No source diff data - will be computed if spec diff needs computation
                if needs_computation:
                    source_diff_status = "computing"

            # Trigger background spec diff computation if needed
            if needs_computation:
                logger.log(f"Triggering spec diff computation for job {job_id}, rule {rule_name}", "INFO", "DashboardServer")

                def compute_spec_diff_background():
                    """Background thread for spec diff and conf diff computation."""
                    try:
                        from src.dashboard.ast_manager import load_asts_mapping
                        from src.dashboard.spec_diff_manager import compute_spec_diffs_for_job
                        from src.dashboard.conf_diff_manager import compute_conf_diff_for_job

                        # Get all rules from this job's status
                        rules_in_job = [rule_name]
                        if selected_status.method_statuses:
                            # For parametric rules, we still only need the rule name
                            pass

                        # Load ASTs mapping
                        asts_mapping = load_asts_mapping(timestamp_dir)
                        if not asts_mapping:
                            logger.log(f"No ASTs mapping found, cannot compute spec diff", "WARNING", "DashboardServer")
                            return

                        # Compute spec diffs for this job
                        # Get AST timeout from app config (set by frontend)
                        current_ast_timeout = app.config.get('AST_TIMEOUT', 600)
                        compute_spec_diffs_for_job(
                            job_id=job_id,
                            job_url=selected_status.run_url,
                            rules_in_job=rules_in_job,
                            snapshot=snapshot,
                            asts_mapping=asts_mapping,
                            timestamp_dir=timestamp_dir,
                            dashboard_path=scanner.cwd,
                            ast_timeout=current_ast_timeout
                        )

                        logger.log(f"Spec diff computation completed for job {job_id}, rule {rule_name}", "SUCCESS", "DashboardServer")

                        # Also compute conf diff for this job
                        # Find the conf file for this rule
                        conf_path = None
                        for conf_info in snapshot.confs:
                            if rule_name in conf_info.rules:
                                conf_path = conf_info.conf_path
                                break

                        if conf_path:
                            compute_conf_diff_for_job(
                                job_id=job_id,
                                job_url=selected_status.run_url,
                                local_conf_path=conf_path,
                                timestamp_dir=timestamp_dir,
                                dashboard_path=scanner.cwd
                            )
                            logger.log(f"Conf diff computation completed for job {job_id}", "SUCCESS", "DashboardServer")

                            # Also compute source diff for this job
                            from src.dashboard.source_diff_manager import compute_source_diff_for_job

                            # Get conf type to determine which source files to compare
                            conf_type = "EVM"  # Default
                            for conf_info in snapshot.confs:
                                if rule_name in conf_info.rules:
                                    conf_type = conf_info.conf_type
                                    break

                            compute_source_diff_for_job(
                                job_id=job_id,
                                job_url=selected_status.run_url,
                                conf_type=conf_type,
                                local_project_root=scanner.cwd,
                                timestamp_dir=timestamp_dir,
                                dashboard_path=scanner.cwd
                            )
                            logger.log(f"Source diff computation completed for job {job_id}", "SUCCESS", "DashboardServer")
                        else:
                            logger.log(f"Could not find conf for rule {rule_name}, skipping conf diff and source diff", "WARNING", "DashboardServer")

                    except Exception as e:
                        logger.log(f"Error computing diffs in background: {e}", "ERROR", "DashboardServer")

                # Launch in background thread
                diff_thread = threading.Thread(target=compute_spec_diff_background, daemon=True)
                diff_thread.start()

            # Get CEX analysis status for this job
            cex_analyses = load_cex_analyses(scanner.dashboard_dir)
            analysis_key = get_analysis_key(job_id, rule_name, method_name)
            cex_analysis_status = None
            if analysis_key in cex_analyses:
                cex_analysis_status = cex_analyses[analysis_key].to_dict()

            # ====================================================================
            # Build complete method data for parametric rules
            # ====================================================================
            # For main rule selection changes (not method-specific), we need to return
            # the complete method data so the frontend can dynamically update the method list.
            # This enables the "latest-per-method" feature without requiring a page refresh.

            display_method_statuses = {}
            method_runs = {}
            method_selections = {}
            overall_status_to_return = selected_status.overall_status

            if not method_name:  # Only for main rule selection, not individual method selection
                # Get the latest status to compare
                rule_statuses = scanner.get_rule_statuses(mode)
                latest_status = rule_statuses.get(rule_name)

                if latest_status:
                    # Define a helper to get available runs (reusing the logic from /api/scan)
                    def get_available_runs_for_method(rule_name_param: str, method_name_param: str | None = None):
                        """Get available runs for a method, filtered by mode and eligibility."""
                        if rule_name_param not in all_statuses_history:
                            return []

                        available = []
                        for status in all_statuses_history[rule_name_param]:
                            # Check mode filter
                            if mode == MODE_LOCAL and status.run_provenance != RUN_PROVENANCE_LOCAL:
                                continue

                            # Check eligibility
                            if not status.job_id or not status.run_url:
                                continue

                            # For method-specific requests, check if this job tested that method
                            if method_name_param:
                                if not status.method_statuses or method_name_param not in status.method_statuses:
                                    continue

                            available.append({
                                "job_id": status.job_id,
                                "timestamp": status.timestamp,
                                "run_url": status.run_url,
                                "overall_status": status.overall_status,
                                "method_status": status.method_statuses.get(method_name_param) if method_name_param and status.method_statuses else None,
                                "run_provenance": status.run_provenance,
                                "conf_path": status.conf_path,
                            })

                        return available

                    # Build complete method data using the helper function
                    display_method_statuses, method_runs, method_selections, processed_parametric_rule = \
                        build_method_data_for_rule(
                            rule_name=rule_name,
                            selected_job_id_rule_level=job_id,
                            latest_status_job_id=latest_status.job_id,
                            all_rule_statuses_history=all_statuses_history,
                            user_run_selections=selections,
                            get_available_runs_callback=get_available_runs_for_method
                        )

                    # Compute overall status for parametric rules
                    if processed_parametric_rule:
                        is_latest_selected = (job_id == latest_status.job_id)

                        if not is_latest_selected:
                            # Historical run selected: show "no_status"
                            from src.dashboard.constants import STATUS_NO_STATUS
                            overall_status_to_return = STATUS_NO_STATUS
                        else:
                            # Latest selected: aggregate from all method statuses
                            from src.dashboard.status_processor import aggregate_method_statuses
                            overall_status_to_return = aggregate_method_statuses(
                                display_method_statuses,
                                selected_status.job_status
                            )

            return jsonify({
                "success": True,
                "updated_status": {
                    "overall_status": overall_status_to_return,
                    "method_statuses": display_method_statuses if display_method_statuses else selected_status.method_statuses,
                    "method_available_runs": method_runs if method_runs else {},
                    "method_selected_job_ids": method_selections if method_selections else {},
                    "job_id": selected_status.job_id,
                    "timestamp": selected_status.timestamp,
                    "run_url": selected_status.run_url,
                    "job_status": selected_status.job_status.value if selected_status.job_status else "",
                    "spec_diff_equivalent": spec_diff_equivalent,  # Use the value loaded from file, not from status
                    "conf_diff_equivalent": conf_diff_equivalent,  # Use the value loaded from file
                    "source_diff_equivalent": source_diff_equivalent,  # Use the value loaded from file
                    "source_diff_error": source_diff_error,  # Error message if source diff failed
                    "has_ambiguous_conf": selected_status.has_ambiguous_conf,
                    "matched_main_contract": selected_status.matched_main_contract,
                },
                "spec_diff_status": spec_diff_status,
                "conf_diff_status": conf_diff_status,
                "source_diff_status": source_diff_status,
                "cex_analysis_status": cex_analysis_status,
            })

        except Exception as e:
            logger.log(
                f"Error selecting run: {e}",
                "ERROR",
                "DashboardServer"
            )
            return jsonify({
                "success": False,
                "error": str(e)
            }), 500

    @app.route("/api/runs/diff-status")
    def get_diff_status():
        """
        Get the status of spec/conf/source diff computation for a specific job/rule.

        Query params:
            job_id: The job ID
            rule_name: The rule name

        Returns:
            JSON with diff computation status for all three diff types
        """
        scanner = app.config["SCANNER"]
        job_id = request.args.get("job_id")
        rule_name = request.args.get("rule_name")

        if not job_id or not rule_name:
            return jsonify({
                "error": "Missing job_id or rule_name"
            }), 400

        logger.log(
            f"GET /api/runs/diff-status - {job_id}:{rule_name}",
            "DEBUG",
            "DashboardServer"
        )

        try:
            from src.dashboard.storage import load_spec_diff_for_job, load_conf_diff_for_job, load_source_diff_for_job

            # Check if spec diff exists for this job
            snapshot = scanner.get_latest_scan()
            if not snapshot:
                return jsonify({
                    "status": "failed",
                    "spec_diff_equivalent": None,
                    "conf_diff_equivalent": None,
                    "source_diff_equivalent": None,
                    "error": "No scan snapshot available"
                }), 404

            timestamp_dir = scanner.dashboard_dir / str(snapshot.timestamp)

            # Get all rule statuses history to find the run_url for this job
            all_statuses_history = scanner.get_all_rule_statuses_history()
            run_url = None
            if rule_name in all_statuses_history:
                for status in all_statuses_history[rule_name]:
                    if status.job_id == job_id:
                        run_url = status.run_url
                        break

            # Construct full job ID from URL for conf/source diff lookups
            full_job_id_for_diff = job_id
            if run_url:
                import re
                match = re.search(r'/output/(\d+)/([a-f0-9]+)', run_url)
                if match:
                    job_number = match.group(1)
                    job_hash = match.group(2)
                    full_job_id_for_diff = f"{job_number}_{job_hash}"

            # Check spec diff
            spec_diff_data = load_spec_diff_for_job(timestamp_dir, job_id)
            spec_status = "computing"
            spec_diff_equivalent = None
            spec_diff_error = None

            if spec_diff_data:
                # Check if this rule has diff data
                if rule_name in spec_diff_data.get("rules", {}):
                    rule_diff = spec_diff_data["rules"][rule_name]
                    equivalent = rule_diff.get("equivalent")
                    reason = rule_diff.get("reason")

                    if equivalent is not None:
                        spec_status = "completed"
                        spec_diff_equivalent = equivalent
                    elif reason and ("failed" in reason.lower() or "error" in reason.lower()):
                        spec_status = "failed"
                        spec_diff_error = reason

            # Check conf diff
            conf_diff_data = load_conf_diff_for_job(timestamp_dir, full_job_id_for_diff)
            conf_status = "computing"
            conf_diff_equivalent = None

            if conf_diff_data:
                equivalent = conf_diff_data.get("equivalent")
                if equivalent is not None:
                    conf_status = "completed"
                    conf_diff_equivalent = equivalent
                else:
                    reason = conf_diff_data.get("reason", "")
                    if reason and ("failed" in reason.lower() or "error" in reason.lower()):
                        conf_status = "failed"

            # Check source diff
            source_diff_data = load_source_diff_for_job(timestamp_dir, full_job_id_for_diff)
            source_status = "computing"
            source_diff_equivalent = None
            source_diff_error = None

            if source_diff_data:
                equivalent = source_diff_data.get("equivalent")
                if equivalent is not None:
                    source_status = "completed"
                    source_diff_equivalent = equivalent
                else:
                    reason = source_diff_data.get("reason", "")
                    if reason and ("failed" in reason.lower() or "error" in reason.lower()):
                        source_status = "failed"
                        source_diff_error = reason

            # Overall status - all must be completed for overall completion
            if spec_status == "completed" and conf_status == "completed" and source_status == "completed":
                overall_status = "completed"
            elif spec_status == "failed" or conf_status == "failed" or source_status == "failed":
                overall_status = "failed"
            else:
                overall_status = "computing"

            return jsonify({
                "status": overall_status,
                "spec_diff_equivalent": spec_diff_equivalent,
                "conf_diff_equivalent": conf_diff_equivalent,
                "source_diff_equivalent": source_diff_equivalent,
                "spec_diff_error": spec_diff_error,
                "source_diff_error": source_diff_error
            })

        except Exception as e:
            logger.log(
                f"Error checking diff status: {e}",
                "ERROR",
                "DashboardServer"
            )
            return jsonify({
                "status": "failed",
                "spec_diff_equivalent": None,
                "error": str(e)
            }), 500

    @app.route("/.certora_internal/cex_analyses/<path:filename>")
    def serve_cex_analysis(filename):
        """
        Serve CEX analysis markdown files as rendered HTML or raw markdown.

        Args:
            filename: Name of the markdown file to serve

        Returns:
            Rendered HTML page or raw markdown file
        """
        scanner = app.config["SCANNER"]
        # Construct absolute path to the file in the project being analyzed
        file_path = scanner.cwd / ".certora_internal" / "cex_analyses" / filename

        # Ensure it's an absolute path
        file_path = file_path.resolve()

        if not file_path.exists():
            logger.log(
                f"CEX analysis file not found: {file_path}",
                "WARNING",
                "DashboardServer"
            )
            return jsonify({"error": "File not found"}), 404

        logger.log(
            f"Serving CEX analysis file: {filename} from {file_path}",
            "INFO",
            "DashboardServer"
        )

        # Check if raw markdown is requested
        if request.args.get('raw') == 'true':
            return send_file(
                str(file_path),
                mimetype="text/markdown",
                as_attachment=False
            )

        # Otherwise, render as HTML
        try:
            with open(file_path, 'r') as f:
                markdown_content = f.read()

            # Extract title from filename
            title = filename.replace('.md', '').replace('_', ' ')

            return render_template(
                "markdown_view.html",
                markdown_content=markdown_content,
                title=title
            )
        except Exception as e:
            logger.log(
                f"Error rendering markdown: {e}",
                "ERROR",
                "DashboardServer"
            )
            return jsonify({"error": f"Error rendering markdown: {str(e)}"}), 500

    return app


def run_server(project_root: Path | None = None, host: str = "127.0.0.1", port: int = 8080, debug: bool = False):
    """
    Run the dashboard server.

    Args:
        project_root: Path to the project root (CWD)
        host: Host to bind to (default: localhost)
        port: Port to bind to (default: 8080)
        debug: Enable debug logging (verbose=2)
    """
    if debug:
        logger.set_verbosity(2)
        logger.log("Debug logging enabled", "DEBUG", "DashboardServer")

    app = create_app(project_root)

    logger.log(
        f"Starting dashboard server at http://{host}:{port}",
        "INFO",
        "DashboardServer"
    )

    app.run(host=host, port=port, debug=True)


def main():
    """Main entry point with argument parsing."""
    parser = argparse.ArgumentParser(
        description="Certora Dashboard - Web interface for verification results"
    )
    parser.add_argument(
        "project_root",
        nargs="?",
        default=".",
        help="Path to the project root directory (default: current directory)"
    )
    parser.add_argument(
        "--port", "-p",
        type=int,
        default=8080,
        help="Port to bind to (default: 8080)"
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--debug", "-d",
        action="store_true",
        help="Enable debug logging (shows detailed matching and sync info)"
    )

    args = parser.parse_args()

    project_path = Path(args.project_root).resolve()
    if not project_path.exists():
        print(f"Error: Project path does not exist: {project_path}", file=sys.stderr)
        sys.exit(1)

    run_server(
        project_root=project_path,
        host=args.host,
        port=args.port,
        debug=args.debug
    )


if __name__ == "__main__":
    main()
