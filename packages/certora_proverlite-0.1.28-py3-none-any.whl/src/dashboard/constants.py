"""
Global constants for the dashboard module.

Centralizes all magic strings, file names, paths, and configuration values
to avoid duplication and improve maintainability.
"""


from enum import Enum

# Status color constants
STATUS_VERIFIED = "verified"
STATUS_TIMEOUT = "timeout"
STATUS_VIOLATED = "violated"
STATUS_VACUITY = "vacuity"
STATUS_MIXED_ERROR = "mixed-error"
STATUS_UNKNOWN = "unknown"
STATUS_PENDING = "pending"
STATUS_RUNNING = "running"

# Special statuses for parametric rules (rules with methods/sub-rules)
# STATUS_NOT_RUN: Used when a method exists in the rule's history but was not tested
#                 in the currently selected job. This allows us to show all methods
#                 from all jobs while indicating which ones are missing from specific runs.
STATUS_NOT_RUN = "not_run"

# STATUS_NO_STATUS: Used for the main rule's overall status when a user has selected
#                   a historical (non-latest) run for a parametric rule. In this case,
#                   we don't compute an aggregated status because different methods may
#                   have been tested in different jobs. The user must select "latest"
#                   to see the properly aggregated status across all methods.
STATUS_NO_STATUS = "no_status"

# Mode constants
MODE_LOCAL = "local"
MODE_REMOTE = "remote"

# Progress status constants
PROGRESS_STATUS_RUNNING = "running"
PROGRESS_STATUS_COMPLETED = "completed"
PROGRESS_STATUS_FAILED = "failed"

# File name constants
FILE_RECENT_JOBS = ".certora_recent_jobs.json"
FILE_REMOTE_JOBS = ".certora_remote_jobs.json"
FILE_RULE_STATUSES = "rule_statuses.json"  # Deprecated - use FILE_ALL_RULE_STATUSES instead
FILE_RULE_STATUSES_REMOTE = "rule_statuses_remote.json"  # Deprecated - use FILE_ALL_RULE_STATUSES instead
FILE_ALL_RULE_STATUSES = "all_rule_statuses.json"
FILE_SELECTED_USER_RUNS = "selected_user_runs.json"
FILE_LAST_CLOUD_SYNC = "last_cloud_sync"
FILE_LAST_CLOUD_SYNC_REMOTE = "last_cloud_sync_remote"
FILE_LATEST_SCAN = "latest_scan"
FILE_SCAN_METADATA = "scan_metadata.json"
FILE_RULES_DATA = "rules_data.json"
FILE_CONF_MAPPINGS = "conf_mappings.json"
# Combined AST mapping aggregated across conf files (not the same as .asts.json from certora-cli)
FILE_ASTS = "asts.json"
FILE_SPEC_DIFFS = "spec_diffs.json"  # Deprecated - use DIR_SPEC_DIFFS instead
FILE_SPEC_DIFF_INDEX = "index.json"
FILE_CONF_DIFF_INDEX = "index.json"
FILE_CEX_ANALYSES = "cex_analyses.json"
FILE_CEXANALYZER_LOG = "cexanalyzer.log"
FILE_TIMEOUTER_RUNS = "timeouter_runs.json"
FILE_TIMEOUTER_LOG = "timeouter.log"
FILE_DASHBOARD_LOG = "dashboard.log"

# Directory name constants
DIR_CERTORA_INTERNAL = ".certora_internal"
DIR_LOCAL_DASHBOARD = "local_dashboard"
DIR_CEX_ANALYSES = "cex_analyses"
DIR_TIMEOUTER = "timeouter"
DIR_EXTRACTED_TARS = "extracted_tars"
DIR_TMP = "tmp"
DIR_TARBALL_CACHE = "tarball_cache"
DIR_EXTRACTED = "extracted"
DIR_SPEC_DIFFS = "spec_diffs"
DIR_CONF_DIFFS = "conf_diffs"
DIR_SOURCE_DIFFS = "source_diffs"

# API endpoints
API_CERTORA_DATA_BASE = "https://data-api.certora.com/v1/domain/jobs"
API_JOB_METADATA = "https://data-api.certora.com/v1/domain/job-metadata"
DOMAIN_PROVER_CERTORA = "https://prover.certora.com"

# Time constants (in seconds)
TWO_HOURS_SECONDS = 2 * 60 * 60
FIVE_MINUTES_SECONDS = 5 * 60

# Built-in Certora rules (no local spec files)
BUILTIN_RULES = {"envfreeFuncsStaticCheck", "sanity"}

# Run provenance constants
RUN_PROVENANCE_LOCAL = "local"
RUN_PROVENANCE_REMOTE = "remote"

# ============================================================================
# Ecosystem Enums and Conversion Functions
# ============================================================================

class DashboardEcosystem(str, Enum):
    """Internal dashboard ecosystem types"""
    RUST = "rust"
    MOVE = "move"
    EVM = "evm"


class CloudAPIEcosystem(str, Enum):
    """Ecosystem types for Cloud API /jobs endpoint"""
    SOLANA = "SOLANA"
    SUI = "SUI"
    EVM = "EVM"


class AIComposerEcosystem(str, Enum):
    """Ecosystem types for AIComposer"""
    EVM = "evm"
    MOVE = "move"
    SOLANA = "solana"
    SOROBAN = "soroban"


# Mapping dictionaries
DASHBOARD_TO_CLOUD_API = {
    DashboardEcosystem.RUST: CloudAPIEcosystem.SOLANA,
    DashboardEcosystem.MOVE: CloudAPIEcosystem.SUI,
    DashboardEcosystem.EVM: CloudAPIEcosystem.EVM,
}

DASHBOARD_TO_AICOMPOSER = {
    DashboardEcosystem.RUST: AIComposerEcosystem.SOLANA,
    DashboardEcosystem.MOVE: AIComposerEcosystem.MOVE,
    DashboardEcosystem.EVM: AIComposerEcosystem.EVM,
}

CLOUD_API_TO_DASHBOARD = {
    CloudAPIEcosystem.SOLANA: DashboardEcosystem.RUST,
    CloudAPIEcosystem.SUI: DashboardEcosystem.MOVE,
    CloudAPIEcosystem.EVM: DashboardEcosystem.EVM,
}


def normalize_to_dashboard_ecosystem(value: str | DashboardEcosystem | CloudAPIEcosystem) -> DashboardEcosystem:
    """
    Normalize any ecosystem value to DashboardEcosystem.

    Handles:
    - DashboardEcosystem values (pass-through)
    - CloudAPIEcosystem values (convert to Dashboard)
    - Legacy string values (case-insensitive matching)

    Args:
        value: Ecosystem value (enum or string)

    Returns:
        DashboardEcosystem value

    Raises:
        ValueError: If value cannot be normalized to a valid ecosystem
    """
    # If already a DashboardEcosystem, return as-is
    if isinstance(value, DashboardEcosystem):
        return value

    # If CloudAPIEcosystem, convert to Dashboard
    if isinstance(value, CloudAPIEcosystem):
        return CLOUD_API_TO_DASHBOARD[value]

    # Handle string values (case-insensitive)
    value_lower = value.lower()

    # Try matching against DashboardEcosystem values
    for eco in DashboardEcosystem:
        if eco.value == value_lower:
            return eco

    # Try matching against CloudAPIEcosystem values (uppercase)
    value_upper = value.upper()
    for cloud_eco in CloudAPIEcosystem:
        if cloud_eco.value == value_upper:
            return CLOUD_API_TO_DASHBOARD[cloud_eco]

    raise ValueError(f"Unknown ecosystem value: {value}")


def to_cloud_api_ecosystem(dashboard_eco: DashboardEcosystem | str) -> CloudAPIEcosystem:
    """
    Convert DashboardEcosystem to CloudAPIEcosystem.

    Args:
        dashboard_eco: Dashboard ecosystem value (enum or string)

    Returns:
        CloudAPIEcosystem value
    """
    # Normalize to DashboardEcosystem first
    if not isinstance(dashboard_eco, DashboardEcosystem):
        dashboard_eco = normalize_to_dashboard_ecosystem(dashboard_eco)

    return DASHBOARD_TO_CLOUD_API[dashboard_eco]


def to_aicomposer_ecosystem(dashboard_eco: DashboardEcosystem | str) -> AIComposerEcosystem:
    """
    Convert DashboardEcosystem to AIComposerEcosystem.

    Args:
        dashboard_eco: Dashboard ecosystem value (enum or string)

    Returns:
        AIComposerEcosystem value
    """
    # Normalize to DashboardEcosystem first
    if not isinstance(dashboard_eco, DashboardEcosystem):
        dashboard_eco = normalize_to_dashboard_ecosystem(dashboard_eco)

    return DASHBOARD_TO_AICOMPOSER[dashboard_eco]
