"""
Move Prover parser for extracting rules from Move spec files.

This module handles parsing of Move specification files to extract:
- Rules defined in cvlm_manifest() functions
- Detection of Move projects via Move.toml files
"""

import re
from pathlib import Path
from typing import List

from src.dashboard.models import RuleInfo
from src.dashboard.logger import dashboard_logger as logger


def detect_move_project(conf_path: Path) -> bool:
    """
    Detect if a conf file is for a Move project.

    Checks parent directories for the presence of Move.toml file,
    which indicates this is a Move project.

    Args:
        conf_path: Path to the conf file

    Returns:
        True if Move.toml found in any parent directory, False otherwise
    """
    current = conf_path.parent
    # Check up to 10 levels up to avoid infinite loops
    for _ in range(10):
        if (current / "Move.toml").exists():
            logger.log(
                f"Detected Move project at {current} (found Move.toml)",
                "INFO",
                "MoveParser"
            )
            return True
        if current.parent == current:  # Reached root
            break
        current = current.parent

    return False


def find_move_spec_files(conf_dir: Path) -> List[Path]:
    """
    Find all Move spec files in the conf directory and subdirectories.

    Args:
        conf_dir: Directory containing the conf file

    Returns:
        List of absolute paths to .move files
    """
    move_files: list[Path] = []

    if not conf_dir.exists() or not conf_dir.is_dir():
        logger.log(
            f"Directory does not exist: {conf_dir}",
            "WARNING",
            "MoveParser"
        )
        return move_files

    # Recursively find all .move files
    for move_file in conf_dir.rglob("*.move"):
        move_files.append(move_file.resolve())

    logger.log(
        f"Found {len(move_files)} Move files in {conf_dir}",
        "INFO",
        "MoveParser"
    )

    return move_files


def parse_cvlm_manifest(move_file: Path) -> List[RuleInfo]:
    """
    Extract rules from cvlm_manifest() function in a Move file.

    Searches for the cvlm_manifest function and extracts all rule(b"...")
    declarations within it.

    Args:
        move_file: Path to the Move specification file

    Returns:
        List of RuleInfo objects for all rules found in cvlm_manifest

    Example Move syntax:
        public fun cvlm_manifest() {
            target(@bridge, b"bridge", b"send_token");
            rule(b"send_token_burns_coin");
            rule(b"only_owner_can_claim");
        }
    """
    rules: list = []

    # Pattern to match rule declarations: rule(b"RULE_NAME")
    rule_pattern = re.compile(r'rule\(b"([^"]+)"\)')

    try:
        with open(move_file, "r") as f:
            content = f.read()

        # Find the cvlm_manifest function
        # Match: public fun cvlm_manifest() { ... }
        manifest_pattern = re.compile(
            r'public\s+fun\s+cvlm_manifest\s*\(\s*\)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}',
            re.DOTALL
        )

        manifest_match = manifest_pattern.search(content)
        if not manifest_match:
            # No cvlm_manifest found - this is OK, not all Move files have it
            logger.log(
                f"No cvlm_manifest function found in {move_file.name}",
                "DEBUG",
                "MoveParser"
            )
            return rules

        manifest_body = manifest_match.group(1)

        # Extract all rule declarations from the manifest body
        for rule_match in rule_pattern.finditer(manifest_body):
            rule_name = rule_match.group(1)
            rules.append(RuleInfo(
                name=rule_name,
                type="rule",
                is_parametric=False,  # Move rules are not parametric in the CVL sense
                spec_file=move_file,
                from_use=False
            ))

        if rules:
            logger.log(
                f"Extracted {len(rules)} rules from cvlm_manifest in {move_file.name}",
                "INFO",
                "MoveParser"
            )

    except Exception as e:
        logger.log(
            f"Error parsing Move file {move_file}: {e}",
            "ERROR",
            "MoveParser"
        )

    return rules
