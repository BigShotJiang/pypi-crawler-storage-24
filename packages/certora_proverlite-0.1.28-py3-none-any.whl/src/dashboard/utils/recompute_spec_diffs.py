#!/usr/bin/env python3
"""
Standalone script to recompute spec diffs for the current snapshot.

This script reads existing data from the dashboard directory and regenerates
the spec_diffs folder without restarting the dashboard or erasing any files.

Usage:
    python recompute_spec_diffs.py /path/to/project
"""

import json
import sys
from pathlib import Path

# Add src to path so we can import dashboard modules
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from src.dashboard.constants import (
    DIR_CERTORA_INTERNAL,
    DIR_LOCAL_DASHBOARD,
    DIR_SPEC_DIFFS,
    FILE_LATEST_SCAN,
)
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import RuleStatus, ScanSnapshot
from src.dashboard.spec_diff_manager import compute_all_spec_diffs
from src.dashboard.storage import load_latest_scan, load_rule_statuses


def main():
    if len(sys.argv) < 2:
        print("Usage: python recompute_spec_diffs.py /path/to/project")
        sys.exit(1)

    project_path = Path(sys.argv[1]).resolve()

    if not project_path.exists():
        print(f"Error: Project path does not exist: {project_path}")
        sys.exit(1)

    print(f"Project path: {project_path}")

    # Set up paths
    certora_internal = project_path / DIR_CERTORA_INTERNAL
    dashboard_dir = certora_internal / DIR_LOCAL_DASHBOARD

    if not dashboard_dir.exists():
        print(f"Error: Dashboard directory not found: {dashboard_dir}")
        sys.exit(1)

    # Read latest_scan to get current snapshot timestamp
    latest_scan_file = dashboard_dir / FILE_LATEST_SCAN
    if not latest_scan_file.exists():
        print(f"Error: No latest_scan file found at {latest_scan_file}")
        sys.exit(1)

    with open(latest_scan_file, 'r') as f:
        timestamp_str = f.read().strip()

    print(f"Current snapshot timestamp: {timestamp_str}")

    timestamp_dir = dashboard_dir / timestamp_str

    if not timestamp_dir.exists():
        print(f"Error: Snapshot directory not found: {timestamp_dir}")
        sys.exit(1)

    # Load the snapshot
    print("Loading snapshot...")
    snapshot = load_latest_scan(dashboard_dir)

    if not snapshot:
        print("Error: Failed to load snapshot")
        sys.exit(1)

    print(f"Loaded snapshot with {len(snapshot.specs)} specs and {len(snapshot.confs)} confs")

    # Load rule statuses (remote mode for all runs)
    print("Loading rule statuses...")
    rule_statuses = load_rule_statuses(dashboard_dir, mode="remote")

    if not rule_statuses:
        print("Warning: No rule statuses found. Spec diffs can only be computed for rules with cloud runs.")
        response = input("Continue anyway? (y/n): ")
        if response.lower() != 'y':
            sys.exit(0)

    print(f"Loaded {len(rule_statuses)} rule statuses")

    # Clear existing spec_diffs directory
    spec_diffs_dir = timestamp_dir / DIR_SPEC_DIFFS
    print(f"Clearing spec diffs directory: {spec_diffs_dir}")

    if spec_diffs_dir.exists():
        import shutil
        shutil.rmtree(spec_diffs_dir)

    spec_diffs_dir.mkdir(parents=True, exist_ok=True)

    # Progress tracking
    total_rules = len([rs for rs in rule_statuses.values() if rs.job_id and rs.run_url])
    processed = 0

    def progress_callback(count: int, rule_name: str):
        nonlocal processed
        processed = count
        percent = (processed / total_rules * 100) if total_rules > 0 else 0
        print(f"  [{processed}/{total_rules}] ({percent:.1f}%) Processing: {rule_name}")

    # Compute spec diffs
    print(f"\nComputing spec diffs for {total_rules} rules...")
    spec_diffs = compute_all_spec_diffs(
        snapshot,
        rule_statuses,
        timestamp_dir,
        project_path,
        progress_callback
    )

    # Summary
    equivalent_count = sum(1 for d in spec_diffs.values() if d.get("equivalent") is True)
    different_count = sum(1 for d in spec_diffs.values() if d.get("equivalent") is False)
    unknown_count = sum(1 for d in spec_diffs.values() if d.get("equivalent") is None)

    print("\n" + "="*60)
    print("Spec Diff Computation Complete")
    print("="*60)
    print(f"Total rules processed: {len(spec_diffs)}")
    print(f"  Matching specs:      {equivalent_count}")
    print(f"  Differing specs:     {different_count}")
    print(f"  Unknown/Failed:      {unknown_count}")
    print()
    print(f"Results saved to: {spec_diffs_dir}")
    print("="*60)


if __name__ == "__main__":
    main()
