#!/usr/bin/env python3
"""
analyze_violations.py

Tool to download a Certora run output, extract it, and analyze violations using CexAnalyzer.

Usage:
    python3 analyze_violations.py <url> [--rule RULE_NAME [--method METHOD_NAME] | --all] [--output OUTPUT_FILE] [--output-dir-parent PARENT_DIR]

Examples:
    # Analyze a specific rule
    python3 analyze_violations.py https://prover.certora.com/output/12345/abc --rule myRule

    # Analyze a specific rule and method, save output to file
    python3 analyze_violations.py https://prover.certora.com/output/12345/abc --rule myRule --method MyContract.myMethod --output report.txt

    # Analyze all failed rules, save list of created files to JSON
    python3 analyze_violations.py https://prover.certora.com/output/12345/abc --all --output files.json

    # Extract tarball to a custom parent directory
    python3 analyze_violations.py https://prover.certora.com/output/12345/abc --rule myRule --output-dir-parent /tmp/certora_runs
"""


import sys
import os
import argparse
import subprocess
import json
import tarfile
import shutil
import time
from pathlib import Path
from typing import IO, List, Optional, Dict, Any, Tuple, NoReturn, Protocol, cast
from urllib.parse import urlparse
from datetime import datetime

from analyzer.analysis import analyze_with_calltraces, ecosystem_params  # type: ignore[import-untyped]
from analyzer.types import Ecosystem  # type: ignore[import-not-found]
from composer.templates.loader import load_jinja_template  # type: ignore[import-untyped]
from prover_output_utility import ProverOutputAPI  # type: ignore[import-untyped]
from jinja2 import Environment, FileSystemLoader

# Add logger import
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.constants import FILE_CEXANALYZER_LOG, DIR_CERTORA_INTERNAL, AIComposerEcosystem
from src.generic_checkers.reporting.extractors import TraceExtractor
from src.utils.rag_config import get_default_rag_db




class AnalysisConfig(Protocol):
    """Protocol for analyze_violations arguments - enables type checking and reuse."""
    url: str
    rule: str | None
    all: bool
    method: str | None
    ecosystem: str
    recursion_limit: int
    download_full_tarball: bool
    prompt_template: str | None
    output_dir_parent: str | None
    output_dir: str | None
    keep_tar: bool


class CexAnalysisArgs:
    """Arguments for CexAnalyzer matching the AnalysisArgs Protocol."""
    def __init__(
        self,
        folder: str,
        rule: str,
        method: str | None,
        recursion_limit: int = 5,
        thread_id: str | None = None,
        checkpoint_id: str | None = None,
        thinking_tokens: int = 2048,
        tokens: int = 4096,
        rag_db: str | None = None,
        ecosystem: str = AIComposerEcosystem.EVM.value,
    ):
        self._folder = folder
        self._rule = rule
        self._method = method
        self._recursion_limit = recursion_limit
        self._thread_id = thread_id
        self._checkpoint_id = checkpoint_id
        self._thinking_tokens = thinking_tokens
        self._tokens = tokens
        self._rag_db = rag_db if rag_db else get_default_rag_db()
        self._ecosystem = ecosystem

    @property
    def folder(self) -> str:
        return self._folder

    @property
    def rule(self) -> str:
        return self._rule

    @property
    def method(self) -> str | None:
        return self._method

    @property
    def quiet(self) -> bool:
        return True  # Always use quiet mode

    @property
    def recursion_limit(self) -> int:
        return self._recursion_limit

    @property
    def thread_id(self) -> str | None:
        return self._thread_id

    @property
    def checkpoint_id(self) -> str | None:
        return self._checkpoint_id

    @property
    def thinking_tokens(self) -> int:
        return self._thinking_tokens

    @property
    def tokens(self) -> int:
        return self._tokens

    @property
    def rag_db(self) -> str | None:
        return self._rag_db

    @property
    def ecosystem(self) -> str:
        return self._ecosystem


def fail(msg: str, code: int = 1) -> NoReturn:
    """Print error message and exit."""
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def extract_job_id_from_url(url: str) -> str:
    """
    Extract job ID from Certora URL.

    Args:
        url: Certora URL (e.g., https://prover.certora.com/output/60724/172e2bbed32f40e2b6bd45a356e75a6c)

    Returns:
        Job ID in format: {NUMBER}_{HASH}

    Raises:
        SystemExit: If URL format is invalid

    Examples:
        >>> extract_job_id_from_url("https://prover.certora.com/output/60724/172e2bbed32f40e2b6bd45a356e75a6c")
        '60724_172e2bbed32f40e2b6bd45a356e75a6c'

        >>> extract_job_id_from_url("https://prover.certora.com/output/60724/172e2bbed32f40e2b6bd45a356e75a6c/output.json")
        '60724_172e2bbed32f40e2b6bd45a356e75a6c'
    """
    parsed = urlparse(url)
    # Extract path components after /output/
    path_parts = parsed.path.split('/')

    # Find 'output' in path and get next two components
    try:
        output_idx = path_parts.index('output')
        number = path_parts[output_idx + 1]
        hash_val = path_parts[output_idx + 2]
        return f"{number}_{hash_val}"
    except (IndexError, ValueError):
        fail(f"Invalid Certora URL format: {url}. Expected format: https://prover.certora.com/output/NUMBER/HASH")


def collect_output_files(tree_status: Dict[str, Any]) -> List[str]:
    """
    Recursively collect all filenames from "output" keys in tree_status.

    Args:
        tree_status: Dictionary from get_treeview_status()

    Returns:
        List of unique filenames to fetch
    """
    output_files = []

    def traverse(obj):
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key == "output" and isinstance(value, list):
                    output_files.extend(value)
                else:
                    traverse(value)
        elif isinstance(obj, list):
            for item in obj:
                traverse(item)

    traverse(tree_status)
    return list(set(output_files))  # Remove duplicates


def extract_method_name_no_args(method_signature: str) -> str:
    """
    Extract method name without arguments.

    Args:
        method_signature: Full method signature with args

    Returns:
        Method name without arguments

    Examples:
        >>> extract_method_name_no_args("CorkPool.withdraw(bytes32,uint256,address,address)")
        'CorkPool.withdraw'
        >>> extract_method_name_no_args("CorkPool.withdraw")
        'CorkPool.withdraw'
    """
    if '(' in method_signature:
        return method_signature[:method_signature.index('(')]
    return method_signature


def fetch_treeview_data_only(
    job_url: str,
    job_id: str,
    output_dir_parent: Path
) -> Path:
    """
    Fetch only the treeview files needed for analysis using ProverOutputAPI.

    Args:
        job_url: Full Certora job URL (not used, for compatibility)
        job_id: Job ID in format NUMBER_HASH (e.g., "60724_172e2b...")
        output_dir_parent: Parent directory for extraction

    Returns:
        Path to the created output directory (job_id folder)

    Raises:
        Fatal error if API calls fail
    """
    print(f"Fetching treeview data via ProverOutputAPI for job {job_id}")

    # Extract hash part from job_id (ProverOutputAPI only needs hash)
    # job_id format: "NUMBER_HASH", we need just "HASH"
    hash_part = job_id.split('_')[1]

    # Create directory structure: output_dir_parent/job_id/Reports/treeView/
    extract_dir = output_dir_parent / job_id
    treeview_dir = extract_dir / "Reports" / "treeView"
    treeview_dir.mkdir(parents=True, exist_ok=True)

    # Initialize API
    api = ProverOutputAPI()

    try:
        # Step 1: Fetch treeViewStatus
        print("  Fetching treeViewStatus...")
        tree_status = api.get_treeview_status(hash_part)

        # Save treeViewStatus to treeViewStatus_0.json
        treeview_status_path = treeview_dir / "treeViewStatus_0.json"
        with open(treeview_status_path, 'w') as f:
            json.dump(tree_status, f, indent=2)
        print(f"  ✓ Saved treeViewStatus_0.json")

        # Step 2: Parse tree_status to find all "output" file references
        output_files = collect_output_files(tree_status)
        print(f"  Found {len(output_files)} output files to fetch")

        # Step 3: Fetch each output file
        for filename in output_files:
            try:
                print(f"  Fetching {filename}...")
                file_data = api.fetch_treeview_output_by_filename(hash_part, filename)

                # Save to Reports/treeView/{filename}
                output_path = treeview_dir / filename
                with open(output_path, 'w') as f:
                    json.dump(file_data, f, indent=2)

            except Exception as e:
                print(f"  ⚠️  Warning: Failed to fetch {filename}: {e}")
                # Continue with other files

        print(f"  ✓ Treeview data fetched successfully")
        return extract_dir

    except Exception as e:
        fail(f"Failed to fetch treeview data: {e}")


def sanitize_folder_name(name: str) -> str:
    """
    Replace filesystem-unsafe characters with underscores.

    Args:
        name: Folder name to sanitize

    Returns:
        Sanitized folder name safe for all filesystems
    """
    unsafe_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
    result = name
    for char in unsafe_chars:
        result = result.replace(char, '_')
    return result


def get_next_serial_number(directory: Path) -> int:
    """
    Get next serial number for files in directory.

    Scans directory for existing .md files matching pattern TIMESTAMP_JOBID_SERIAL.md
    and returns the next serial number.

    Args:
        directory: Directory to scan

    Returns:
        Next available serial number (1 if no files exist)
    """
    if not directory.exists():
        return 1

    max_serial = 0
    for file in directory.glob("*.md"):
        # Parse filename: TIMESTAMP_JOBID_SERIAL.md
        try:
            parts = file.stem.split('_')
            if len(parts) >= 3:
                serial = int(parts[-1])
                max_serial = max(max_serial, serial)
        except (ValueError, IndexError):
            continue

    return max_serial + 1


def run_certora_wget(url: str, output_file: str, script_dir: Path) -> int:
    """
    Run certora_wget.py with --zip-output flag to download the zip file.
    Returns exit code.

    Used when --download-full-tarball is specified to download complete job output.
    """
    certora_wget = script_dir / "certora_wget.py"
    if not certora_wget.exists():
        fail(f"certora_wget.py not found at {certora_wget}")

    cmd = [sys.executable, str(certora_wget), url, output_file, "--zip-output"]
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    return result.returncode


def extract_tar_gz(tar_path: Path, extract_to: Path) -> Path:
    """
    Extract tar.gz file to specified directory.
    Returns the actual path to the extracted content (handles nested directories).

    Used when --download-full-tarball is specified to extract complete job output.
    """
    print(f"Extracting {tar_path}...")
    temp_extract = extract_to.parent / f"{extract_to.name}_temp"

    try:
        # Extract to temporary location first
        with tarfile.open(tar_path, 'r:gz') as tar:
            tar.extractall(path=temp_extract)

        # Check if extraction created a single top-level directory
        extracted_items = list(temp_extract.iterdir())

        if len(extracted_items) == 1 and extracted_items[0].is_dir():
            # Move the nested directory content to the target location
            nested_dir = extracted_items[0]
            if extract_to.exists():
                shutil.rmtree(extract_to)
            shutil.move(str(nested_dir), str(extract_to))
            shutil.rmtree(temp_extract)
            print(f"Extraction complete to {extract_to}")
        else:
            # No nesting, just rename temp to target
            if extract_to.exists():
                shutil.rmtree(extract_to)
            shutil.move(str(temp_extract), str(extract_to))
            print(f"Extraction complete to {extract_to}")

        return extract_to
    except Exception as e:
        # Cleanup on failure
        if temp_extract.exists():
            shutil.rmtree(temp_extract)
        fail(f"Failed to extract {tar_path}: {e}")


# DEPRECATED: This function is no longer used in the optimized flow (replaced by get_failed_rules_from_api)
# It is kept for backwards compatibility or other scripts
def parse_output_json(json_path: Path) -> Dict[str, Any]:
    """
    Parse the output.json file and return its contents.

    DEPRECATED: Use get_failed_rules_from_api() instead for CEX analysis.
    """
    try:
        with open(json_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        fail(f"Failed to parse {json_path}: {e}")


# DEPRECATED: This function is no longer used in the optimized flow (replaced by get_failed_rules_from_api)
# It is kept for backwards compatibility or other scripts
def get_failed_rules(output_data: Dict[str, Any]) -> List[Tuple[Any, Optional[List[str]]]]:
    """
    Extract list of failed rules with their failed methods from output.json data.

    DEPRECATED: Use get_failed_rules_from_api() instead for CEX analysis.

    Returns a list of tuples: (rule_name, [method_names]) where method_names can be:
    - None for simple "FAIL" format (no specific methods)
    - Empty list [] for rules that fail but have no specific methods listed
    - List of method names for nested format with FAIL arrays

    Supports multiple formats:
    Format 1 (simple):
    {
        "rules": {
            "ruleName1": "FAIL",
            "ruleName2": {"SUCCESS": [...]},
            ...
        }
    }
    Returns: [("ruleName1", None)]

    Format 2 (nested):
    {
        "rules": {
            "ruleName1": {
                "Section 1": "SUCCESS",
                "Section 2": {
                    "Subsection": {
                        "FAIL": ["method1", "method2"],
                        "SUCCESS": [...]
                    }
                }
            }
        }
    }
    Returns: [("ruleName1", ["method1", "method2"])]
    """
    def collect_failed_methods(value: Any) -> List[str]:
        """Recursively collect all failed method names."""
        failed_methods = []

        if isinstance(value, str):
            # Simple "FAIL" string - no specific methods
            return []
        elif isinstance(value, dict):
            # Check if "FAIL" is a key with method list
            if "FAIL" in value:
                fail_value = value["FAIL"]
                if isinstance(fail_value, list):
                    failed_methods.extend(fail_value)
            # Also collect from SANITY_FAIL if needed
            # (commenting out for now as CexAnalyzer might not handle these)
            # if "SANITY_FAIL" in value:
            #     sanity_fail_value = value["SANITY_FAIL"]
            #     if isinstance(sanity_fail_value, list):
            #         failed_methods.extend(sanity_fail_value)

            # Recursively check nested structures
            for v in value.values():
                if not isinstance(v, str) or v not in ["SUCCESS", "FAIL", "SANITY_FAIL"]:
                    failed_methods.extend(collect_failed_methods(v))
        elif isinstance(value, list):
            for item in value:
                failed_methods.extend(collect_failed_methods(item))

        return failed_methods

    def has_failure(value: Any) -> bool:
        """Recursively check if a value contains any FAIL or SANITY_FAIL."""
        if isinstance(value, str):
            return value == "FAIL" or value == "SANITY_FAIL"
        elif isinstance(value, dict):
            # Check if "FAIL" or "SANITY_FAIL" is a key with non-empty value
            if "FAIL" in value:
                fail_value = value["FAIL"]
                if isinstance(fail_value, list):
                    return len(fail_value) > 0
                return bool(fail_value)
            if "SANITY_FAIL" in value:
                sanity_fail_value = value["SANITY_FAIL"]
                if isinstance(sanity_fail_value, list):
                    return len(sanity_fail_value) > 0
                return bool(sanity_fail_value)
            # Recursively check nested structures
            return any(has_failure(v) for v in value.values())
        elif isinstance(value, list):
            return any(has_failure(item) for item in value)
        return False

    failed_rules: List[Tuple[Any, Optional[List[str]]]] = []
    rules = output_data.get("rules", {})

    for rule_name, rule_value in rules.items():
        if has_failure(rule_value):
            # Check if it's simple "FAIL" string
            if isinstance(rule_value, str) and rule_value == "FAIL":
                failed_rules.append((rule_name, None))
            else:
                # Collect all failed methods
                methods = collect_failed_methods(rule_value)
                if methods:
                    failed_rules.append((rule_name, methods))
                else:
                    # Has failure but no specific methods listed
                    failed_rules.append((rule_name, None))

    return failed_rules


def get_failed_rules_from_api(job_id: str) -> List[Tuple[str, Optional[List[str]]]]:
    """
    Get list of failed rules with their failed methods using ProverOutputAPI.

    Args:
        job_id: Job ID in format NUMBER_HASH (e.g., "60724_172e2b...")

    Returns:
        List of tuples: (rule_name, [method_names] or None)
        - (rule_name, [method1, method2, ...]) for parametric rules with specific failed methods
        - (rule_name, None) for simple rule failures with no specific methods

    Uses ProverOutputAPI.get_violated_rules() which returns List[CheckResult].
    Each CheckResult has:
        - rule_name: str
        - method_name: str
        - status: NodeStatus (VIOLATED, etc.)
    """
    # Extract hash part from job_id
    hash_part = job_id.split('_')[1]

    # Initialize API and get violated rules
    api = ProverOutputAPI()

    try:
        check_results = api.get_violated_rules(hash_part)
    except Exception as e:
        fail(f"Failed to get violated rules from API: {e}")

    if not check_results:
        return []

    # Group by rule_name and collect method_names
    # Format: Dict[rule_name, List[method_name]]
    rules_dict: Dict[str, List[str]] = {}

    for result in check_results:
        rule_name = result.rule_name
        method_name = result.method_name

        if rule_name not in rules_dict:
            rules_dict[rule_name] = []

        # Add method_name if it's not empty and not already in list
        if method_name and method_name not in rules_dict[rule_name]:
            rules_dict[rule_name].append(method_name)

    # Convert to list of tuples: (rule_name, methods or None)
    failed_rules: List[Tuple[str, Optional[List[str]]]] = []
    for rule_name, methods in rules_dict.items():
        if methods:
            # Has specific methods
            failed_rules.append((rule_name, methods))
        else:
            # No specific methods (simple rule failure)
            failed_rules.append((rule_name, None))

    return failed_rules


def load_and_render_template(template_path: str, ecosystem: str = "evm") -> str:
    """
    Load and render a Jinja2 prompt template.

    Args:
        template_path: Path to the Jinja2 template file
        ecosystem: Ecosystem type for rendering template variables (default: "evm")

    Returns:
        Rendered prompt string
    """
    template_path_obj = Path(template_path)
    if not template_path_obj.exists():
        fail(f"Template file not found: {template_path}")

    # Load the template
    template_dir = template_path_obj.parent
    template_name = template_path_obj.name
    env = Environment(loader=FileSystemLoader(str(template_dir)))
    template = env.get_template(template_name)

    # Get ecosystem parameters (copy since EcosystemConfig is a TypedDict)
    eco = cast(Ecosystem, ecosystem)
    params = dict(ecosystem_params.get(eco, ecosystem_params["evm"]))

    # Render the template
    return template.render(**params)


def _fetch_and_analyze(
    api: ProverOutputAPI,
    job_url: str,
    job_id: str,
    rule_name: str,
    method_name: str | None,
    initial_prompt: str,
    args: CexAnalysisArgs,
    log: IO[str],
) -> tuple[int, str]:
    """Fetch calltraces from API and run analyze_with_calltraces. Returns (returncode, output_content)."""
    job_hash = job_id.split('_')[1]

    # Get violated checks for this rule/method
    all_checks = api.get_all_checks(job_hash)
    violated_checks = [c for c in all_checks if c.status == "VIOLATED" and c.rule_name == rule_name]
    if method_name:
        violated_checks = [c for c in violated_checks if c.method_name == method_name or c.method_only == method_name]

    if not violated_checks:
        msg = (f"No violated checks found for rule '{rule_name}'"
               + (f" and method '{method_name}'" if method_name else ""))
        log.write(msg + "\n")
        return (1, msg)

    # Collect XML calltraces from all violated checks
    trace_extractor = TraceExtractor(api, job_url, debug_recorder=None)
    xml_calltraces: list[str] = []
    for check in violated_checks:
        calltrace_result = trace_extractor.get_calltrace(check)
        if calltrace_result:
            xml_calltraces.append(calltrace_result["xml"])

    if not xml_calltraces:
        log.write("No calltraces available for violated checks\n")
        return (1, "No calltraces available for the violation")

    # Build input messages: context first, then all XML calltraces
    input_messages = [f"The individual rule that was checked by the prover was {rule_name}"]
    input_messages.extend(xml_calltraces)

    log.write(f"Calling analyze_with_calltraces with {len(xml_calltraces)} calltrace(s)\n")
    log.write(f"Total XML length: {sum(len(x) for x in xml_calltraces)} characters\n\n")

    output_content = analyze_with_calltraces(
        input_messages=input_messages,
        initial_prompt=initial_prompt,
        args=args  # type: ignore[arg-type]
    )
    return (0, output_content)


def run_cexanalyzer(
    extracted_dir: Path,
    rule_name: str,
    job_id: str,
    method_name: Optional[str] = None,
    save_to_file: bool = False,
    ecosystem: str = AIComposerEcosystem.EVM.value,
    job_url: Optional[str] = None,
    prompt_template_path: Optional[str] = None,
    recursion_limit: int = 50
) -> tuple[Optional[Path], Optional[str]]:
    """
    Run CexAnalyzer on the specified rule and optionally save output to markdown file.

    Args:
        extracted_dir: Directory containing extracted output
        rule_name: Name of the rule to analyze
        job_id: Job ID extracted from URL
        method_name: Optional method name that caused the failure
        save_to_file: If True, save output to .certora_internal/violated_rules/
        ecosystem: AIComposer ecosystem (solidity, move, solana, soroban)
        job_url: Optional job URL (required for custom prompt template to fetch calltraces)
        prompt_template_path: Optional path to custom Jinja2 prompt template
        recursion_limit: Recursion limit for AI analysis (default: 50)

    Returns:
        Tuple of (file_path, output_content):
        - file_path: Path to created file if save_to_file=True, else None
        - output_content: The stdout content from CexAnalyzer
    """
    print(f"\n{'='*60}")
    if method_name:
        print(f"Analyzing rule: {rule_name} (method: {method_name})")
    else:
        print(f"Analyzing rule: {rule_name}")
    print(f"{'='*60}\n")

    try:
        # Create analysis arguments
        # CexAnalysisArgs resolves rag_db default via get_default_rag_db() when None
        args = CexAnalysisArgs(
            folder=str(extracted_dir),
            rule=rule_name,
            method=method_name,
            recursion_limit=recursion_limit,
            ecosystem=ecosystem,
            rag_db=os.environ.get("RAG_DB_CONNECTION"),
        )

        # Log to cexanalyzer.log file (similar to timeouter.log)
        log_file = Path(DIR_CERTORA_INTERNAL) / FILE_CEXANALYZER_LOG
        log_file.parent.mkdir(parents=True, exist_ok=True)

        # Log execution start
        desc = f"rule '{rule_name}'" + (f" method '{method_name}'" if method_name else "")
        logger.log(
            f"Starting CexAnalyzer execution for {desc}",
            "INFO",
            "CexAnalyzer"
        )

        with open(log_file, "a") as log:
            log.write(f"\n{'='*80}\n")
            log.write(f"CexAnalyzer run started at {time.ctime()}\n")
            log.write(f"Rule: {rule_name}\n")
            if method_name:
                log.write(f"Method: {method_name}\n")
            log.write(f"Job ID: {job_id}\n")
            log.write(f"Ecosystem: {ecosystem}\n")
            log.write(f"{'='*80}\n\n")
            log.flush()

            # Fetch calltraces from API and analyze
            if not job_url:
                fail("job_url is required for analysis")

            api = ProverOutputAPI()

            if prompt_template_path:
                log.write("Using custom prompt template with analyze_with_calltraces\n")
                log.write(f"Template: {prompt_template_path}\n\n")
                initial_prompt = load_and_render_template(prompt_template_path, ecosystem)
            else:
                process = ecosystem_params[cast(Ecosystem, ecosystem)]
                initial_prompt = load_jinja_template("analyzer_tool_prompt.j2", **process)

            returncode, output_content = _fetch_and_analyze(
                api, job_url, job_id, rule_name, method_name, initial_prompt, args, log
            )

            # Write output to log file
            if output_content:
                log.write("=== OUTPUT ===\n")
                log.write(output_content)
                log.write("\n")

            log.write(f"{'='*80}\n")
            log.write(f"CexAnalyzer completed at {time.ctime()}\n")
            log.write(f"Exit code: {returncode}\n")
            log.write(f"{'='*80}\n")
            log.flush()

        # Log completion status
        if returncode != 0:
            logger.log(
                f"CexAnalyzer failed for {desc}: exit code {returncode}",
                "ERROR",
                "CexAnalyzer"
            )
            # Log the full output on failure (like timeouter does)
            if output_content:
                logger.log(
                    f"Output:\n{output_content}",
                    "ERROR",
                    "CexAnalyzer"
                )
        else:
            logger.log(
                f"CexAnalyzer completed successfully for {desc}",
                "SUCCESS",
                "CexAnalyzer"
            )

        if save_to_file:
            # Determine output path
            timestamp = int(time.time())

            if method_name:
                # Has method - create METHOD_NAME_NO_ARGS subfolder
                method_no_args = extract_method_name_no_args(method_name)
                method_folder = sanitize_folder_name(method_no_args)
                output_dir = Path(f".certora_internal/violated_rules/{rule_name}/{method_folder}")
            else:
                # Simple failure - directly under RULE_NAME
                output_dir = Path(f".certora_internal/violated_rules/{rule_name}")

            output_dir.mkdir(parents=True, exist_ok=True)

            serial = get_next_serial_number(output_dir)
            filename = f"{timestamp}_{job_id}_{serial}.md"
            output_path = output_dir / filename

            # Write markdown file (only stdout, not stderr)
            with open(output_path, 'w') as f:
                f.write(f"# CexAnalyzer Report\n\n")
                f.write(f"**Rule:** {rule_name}\n")
                if method_name:
                    f.write(f"**Method:** {method_name}\n")
                f.write(f"**Job ID:** {job_id}\n")
                f.write(f"**Generated:** {datetime.fromtimestamp(timestamp).isoformat()}\n\n")
                f.write("---\n\n")
                f.write(output_content)

            print(f"\n📄 Report saved to: {output_path}")
            logger.log(
                f"CEX analysis report saved to {output_path}",
                "INFO",
                "CexAnalyzer"
            )
            return (output_path, output_content)
        else:
            # Print to console
            print(output_content)
            return (None, output_content)

    except Exception as e:
        desc = f"rule '{rule_name}'" + (f" method '{method_name}'" if method_name else "")
        print(f"ERROR: Failed to run CexAnalyzer for {desc}: {e}", file=sys.stderr)
        return (None, None)


def create_argument_parser() -> argparse.ArgumentParser:
    """
    Create and return the argparse parser for analyze_violations.

    This function is extracted to enable reuse by other scripts (e.g., run_multi_analysis.py).

    Returns:
        Configured ArgumentParser instance
    """
    parser = argparse.ArgumentParser(
        description="Download Certora run output and analyze violations using CexAnalyzer.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )

    parser.add_argument("url", help="URL of the Certora run (e.g., https://prover.certora.com/output/12345/abc)")
    parser.add_argument("--rule", help="Name of specific rule to analyze")
    parser.add_argument("--method", help="Name of specific method to analyze (must be used with --rule)")
    parser.add_argument("--all", action="store_true", help="Analyze all failed rules")
    parser.add_argument("--ecosystem", choices=[e.value for e in AIComposerEcosystem], default=AIComposerEcosystem.EVM.value, help="AIComposer ecosystem type")
    parser.add_argument("--output", help="Output file path. For single reports: saves the report content. For multiple reports: saves a JSON array of created file paths")
    parser.add_argument("--keep-tar", action="store_true", help="Keep the downloaded tar.gz file (default: delete)")
    parser.add_argument("--output-dir", help="Directory name for extracted output (default: auto-detected from job ID)")
    parser.add_argument("--output-dir-parent", help="Parent directory for extracted output (default: current directory)")
    parser.add_argument("--download-full-tarball", action="store_true", help="Download full tarball with all sources (required for custom prompts)")
    parser.add_argument("--prompt-template", help="Path to custom Jinja2 prompt template file (requires --download-full-tarball)")
    parser.add_argument("--recursion-limit", type=int, default=50, help="Recursion limit for AI analysis (default: 50)")

    return parser


def main():
    parser = create_argument_parser()
    args = parser.parse_args()

    # Extract job ID from URL to use as default output directory
    job_id = extract_job_id_from_url(args.url)
    output_dir_name = args.output_dir if args.output_dir else job_id
    print(f"Detected job ID: {job_id}")
    if args.output_dir:
        print(f"Using custom output directory name: {output_dir_name}")
    else:
        print(f"Using job ID as output directory name: {output_dir_name}")

    if args.output_dir_parent:
        print(f"Using parent directory: {args.output_dir_parent}")

    # Validate mutually exclusive options
    if args.rule and args.all:
        fail("Cannot specify both --rule and --all")

    if not args.rule and not args.all:
        fail("Must specify either --rule RULE_NAME or --all")

    if args.method and not args.rule:
        fail("--method can only be used with --rule")

    if args.prompt_template and not args.download_full_tarball:
        fail("--prompt-template requires --download-full-tarball")

    # Construct output_dir_parent path
    if args.output_dir_parent:
        output_dir_parent = Path(args.output_dir_parent).expanduser().resolve()
    else:
        output_dir_parent = Path.cwd()

    extract_dir = output_dir_parent / output_dir_name

    # Check if output directory already exists (caching)
    treeview_status_path = extract_dir / "Reports" / "treeView" / "treeViewStatus_0.json"

    if extract_dir.exists() and treeview_status_path.exists():
        print(f"\n{'='*60}")
        print(f"Found existing directory: {extract_dir}")
        print(f"Skipping download and extraction (using cached data)")
        print(f"{'='*60}\n")
    else:
        # Step 1: Download job output
        if args.download_full_tarball:
            # Download full tarball with all sources (needed for custom prompts with VFS)
            print(f"\nStep 1: Downloading full tarball")
            tar_filename = f"{job_id}.tar.gz"
            tar_path = output_dir_parent / tar_filename
            script_dir = Path(__file__).parent

            # Download the tarball
            returncode = run_certora_wget(args.url, str(tar_path), script_dir)
            if returncode != 0:
                fail(f"Failed to download tarball: exit code {returncode}")

            # Extract the tarball
            extract_dir = extract_tar_gz(tar_path, extract_dir)

            # Optionally delete tar file
            if not args.keep_tar and tar_path.exists():
                tar_path.unlink()
                print(f"Deleted tar file: {tar_path}")
        else:
            # Fetch only required treeview files via API (optimized for standard analysis)
            print(f"\nStep 1: Fetching treeview data via ProverOutputAPI")
            extract_dir = fetch_treeview_data_only(args.url, job_id, output_dir_parent)

    # Step 2: Get failed rules from API (replaces parsing output.json)
    print(f"\nStep 2: Getting failed rules via ProverOutputAPI")
    failed_rules = get_failed_rules_from_api(job_id)

    if not failed_rules:
        print("No failed rules found")
        return

    # Display summary of failed rules
    rule_names = [rule_name for rule_name, _ in failed_rules]
    print(f"Found {len(failed_rules)} failed rule(s): {', '.join(rule_names)}")

    # Show details of failed methods per rule
    for rule_name, methods in failed_rules:
        if methods:
            methods_str = ", ".join(methods)
            print(f"  {rule_name}: {len(methods)} failed method(s): {methods_str}")
        else:
            print(f"  {rule_name}: no specific methods (simple failure)")

    # Step 3: Run CexAnalyzer on the specified rule(s)
    print(f"\nStep 3: Running CexAnalyzer")

    if args.rule:
        # --rule mode: Save to file ONLY if multiple methods
        matching_rule = None

        # For Move ecosystem with method, search for rule-method combination
        if args.ecosystem == 'move' and args.method:
            search_name = f"{args.rule}-{args.method}"
            for rule_name, methods in failed_rules:
                if rule_name == search_name:
                    matching_rule = (rule_name, methods)
                    break
        elif args.ecosystem == 'move':
            # Move without method: find rules that match the base name
            # Cloud returns: "0x0::bridge_rules::rule_name-method"
            # We search for rules starting with "0x0::bridge_rules::rule_name-"
            for rule_name, methods in failed_rules:
                # Exact match (non-parametric) or prefix match (parametric)
                if rule_name == args.rule or rule_name.startswith(f"{args.rule}-"):
                    matching_rule = (rule_name, methods)
                    break
        else:
            # EVM: exact match on rule name
            for rule_name, methods in failed_rules:
                if rule_name == args.rule:
                    matching_rule = (rule_name, methods)
                    break

        if not matching_rule:
            fail(f"Specified rule '{args.rule}' is not in the list of failed rules: {rule_names}")

        rule_name, methods = matching_rule
        # temporary hack until Sui Prover has better structure
        if args.ecosystem == 'move' and args.method:
            rule_name = f"{args.rule}-{args.method}"
            method_name = None
        else:
            method_name = args.method

        # If --method is specified, run only that method
        if args.method:
            file_path, output_content = run_cexanalyzer(extract_dir, rule_name, job_id, method_name, save_to_file=False, ecosystem=args.ecosystem, job_url=args.url, prompt_template_path=args.prompt_template, recursion_limit=args.recursion_limit)
            # Single report - save content to output file if specified
            if args.output and output_content:
                output_path = Path(args.output)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, 'w') as f:
                    f.write(output_content)
                print(f"\n📄 Output saved to: {output_path}")
        elif methods and len(methods) > 1:
            # Multiple methods - save to files
            created_files = []
            for method in methods:
                file_path, _ = run_cexanalyzer(extract_dir, rule_name, job_id, method, save_to_file=True, ecosystem=args.ecosystem, job_url=args.url, prompt_template_path=args.prompt_template, recursion_limit=args.recursion_limit)
                if file_path:
                    created_files.append(str(file_path))

            print(f"\n{'='*60}")
            print(f"Created {len(created_files)} report file(s):")
            for file in created_files:
                print(f"  📄 {file}")
            print(f"{'='*60}")

            # Save list of created files to output file if specified
            if args.output:
                output_path = Path(args.output)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, 'w') as f:
                    json.dump(created_files, f, indent=2)
                print(f"\n📄 File list saved to: {output_path}")
        else:
            # Single method or no methods - console only
            output_content = None
            if methods:
                for method in methods:
                    _, output_content = run_cexanalyzer(extract_dir, rule_name, job_id, method, save_to_file=False, ecosystem=args.ecosystem, job_url=args.url, prompt_template_path=args.prompt_template, recursion_limit=args.recursion_limit)
            else:
                _, output_content = run_cexanalyzer(extract_dir, rule_name, job_id, save_to_file=False, ecosystem=args.ecosystem, job_url=args.url, prompt_template_path=args.prompt_template, recursion_limit=args.recursion_limit)

            # Single report - save content to output file if specified
            if args.output and output_content:
                output_path = Path(args.output)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, 'w') as f:
                    f.write(output_content)
                print(f"\n📄 Output saved to: {output_path}")
    else:
        # --all mode: ALWAYS save to file
        created_files = []
        for rule_name, methods in failed_rules:
            if methods:
                # Has methods - save each to file
                for method in methods:
                    file_path, _ = run_cexanalyzer(extract_dir, rule_name, job_id, method, save_to_file=True, ecosystem=args.ecosystem, job_url=args.url, prompt_template_path=args.prompt_template, recursion_limit=args.recursion_limit)
                    if file_path:
                        created_files.append(str(file_path))
            else:
                # Simple failure - save to file (directly under rule name)
                file_path, _ = run_cexanalyzer(extract_dir, rule_name, job_id, save_to_file=True, ecosystem=args.ecosystem, job_url=args.url, prompt_template_path=args.prompt_template, recursion_limit=args.recursion_limit)
                if file_path:
                    created_files.append(str(file_path))

        print(f"\n{'='*60}")
        print(f"Analysis complete! Created {len(created_files)} report file(s):")
        for file in created_files:
            print(f"  📄 {file}")
        print(f"{'='*60}")

        # Save list of created files to output file if specified
        if args.output:
            output_path = Path(args.output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w') as f:
                json.dump(created_files, f, indent=2)
            print(f"\n📄 File list saved to: {output_path}")


if __name__ == "__main__":
    main()
