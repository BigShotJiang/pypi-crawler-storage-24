#!/usr/bin/env python3
"""
Utility for generating CVL spec AST JSON files from configuration files.

This module provides functionality to execute certoraRun with --compilation_steps_only
and --dump_cvl_ast flags to generate AST JSON files for spec comparison and analysis.
"""

import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

# Add project root to path for imports
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from src.dashboard.logger import dashboard_logger as logger
from src.utils.config_manager import convert_solc_version_to_certora_format
from src.utils.solc_version_resolver import resolve_pragma_to_version, extract_pragma_spec


def _run_command(cmd: list, cwd: Path, timeout: int) -> subprocess.CompletedProcess:
    """
    Execute a subprocess command and return the result.

    Args:
        cmd: Command to execute
        cwd: Working directory
        timeout: Timeout in seconds

    Returns:
        CompletedProcess result
    """
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=cwd
    )


def _has_remappings_conflict(result: subprocess.CompletedProcess) -> bool:
    """
    Check if the command failed with a remappings conflict error.

    Args:
        result: CompletedProcess result

    Returns:
        True if remappings conflict detected, False otherwise
    """
    if result.returncode == 0:
        return False

    remappings_conflict = "package.json and remappings.txt include duplicated keys in"
    error_output = (result.stdout or "") + (result.stderr or "")
    return remappings_conflict in error_output


def _try_with_relpaths_flag(cmd: list, cwd: Path, timeout: int) -> subprocess.CompletedProcess:
    """
    Try running command with --use_relpaths_for_solc_json flag added.

    Args:
        cmd: Command to execute
        cwd: Working directory
        timeout: Timeout in seconds

    Returns:
        CompletedProcess result
    """
    logger.log(
        "Trying with --use_relpaths_for_solc_json flag...",
        "INFO",
        "ASTUtil"
    )

    cmd_with_flag = cmd + ["--use_relpaths_for_solc_json"]
    return _run_command(cmd_with_flag, cwd, timeout)


def _restore_file(file_path: Path, backup_path: Path) -> bool:
    """
    Restore a file from its backup if the backup exists.

    Args:
        file_path: Path to the original file
        backup_path: Path to the backup file

    Returns:
        True if restoration succeeded or wasn't needed, False on error
    """
    if backup_path.exists() and not file_path.exists():
        try:
            backup_path.rename(file_path)
            logger.log(
                f"Restored {file_path.name}",
                "INFO",
                "ASTUtil"
            )
            return True
        except Exception as e:
            logger.log(
                f"Failed to restore {file_path.name}: {e}",
                "ERROR",
                "ASTUtil"
            )
            return False
    return True


def _try_file_rename_workaround(
    file_name: str,
    backup_name: str,
    cmd: list,
    cwd: Path,
    timeout: int
) -> Tuple[subprocess.CompletedProcess, bool]:
    """
    Try running command with a specific file temporarily renamed.

    Args:
        file_name: Name of file to rename (e.g., "remappings.txt")
        backup_name: Name for backup (e.g., "remappings.txt.bkup")
        cmd: Command to execute
        cwd: Working directory
        timeout: Timeout in seconds

    Returns:
        Tuple of (result, file_was_renamed)
        - result: CompletedProcess result
        - file_was_renamed: True if file was successfully renamed, False otherwise
    """
    file_path = cwd / file_name
    backup_path = cwd / backup_name

    if not file_path.exists():
        logger.log(
            f"{file_name} not found in {cwd}, skipping this workaround",
            "WARNING",
            "ASTUtil"
        )
        # Return a failed result to continue to next workaround
        return (subprocess.CompletedProcess(
            args=cmd,
            returncode=1,
            stdout="",
            stderr=f"{file_name} not found"
        ), False)

    try:
        logger.log(
            f"Temporarily renaming {file_name} to {backup_name}",
            "INFO",
            "ASTUtil"
        )
        file_path.rename(backup_path)

        logger.log(
            f"Retrying certoraRun without {file_name}...",
            "INFO",
            "ASTUtil"
        )
        result = _run_command(cmd, cwd, timeout)

        if result.returncode == 0:
            logger.log(
                f"Workaround successful - command succeeded without {file_name}",
                "SUCCESS",
                "ASTUtil"
            )

        return (result, True)

    except Exception as e:
        logger.log(
            f"Error during {file_name} workaround: {e}",
            "ERROR",
            "ASTUtil"
        )
        # Return failed result
        return (subprocess.CompletedProcess(
            args=cmd,
            returncode=1,
            stdout="",
            stderr=str(e)
        ), False)


def _detect_solc_version_mismatch_error(result: subprocess.CompletedProcess) -> Optional[str]:
    """
    Detect if the error is a solc version mismatch and extract required version.

    Looks for errors like:
    ParserError: Source file requires different compiler version (current compiler is 0.8.26...)
    ...
    pragma solidity >=0.8.0 <0.8.6;

    Args:
        result: CompletedProcess result from certoraRun

    Returns:
        Required solc version in solcX.YY format (e.g., "solc8.5"), or None if not detected
    """
    # Check both stdout and stderr for the error
    output = (result.stdout or "") + (result.stderr or "")

    # Check if this is a parser error about compiler version
    if "ParserError: Source file requires different compiler version" not in output:
        return None

    # Extract the pragma solidity specification from the error
    pragma_spec = extract_pragma_spec(output)
    if pragma_spec:
        # Resolve pragma spec to concrete version using shared logic
        version = resolve_pragma_to_version(pragma_spec)
        if not version:
            logger.log(
                f"Could not resolve pragma '{pragma_spec}' to concrete version",
                "WARNING",
                "ASTUtil"
            )
            return None

        # Convert to solcX.Y format for dashboard
        solc_version = convert_solc_version_to_certora_format(version)

        logger.log(
            f"Detected solc version mismatch: required version {version} (formatted as {solc_version})",
            "INFO",
            "ASTUtil"
        )

        return solc_version

    return None


def _retry_with_solc_override(
    cmd: list,
    cwd: Path,
    timeout: int,
    solc_version: str,
    include_relpaths: bool = False
) -> subprocess.CompletedProcess:
    """
    Retry command with --solc override.

    Args:
        cmd: Original command
        cwd: Working directory
        timeout: Timeout in seconds
        solc_version: Solc version to use (e.g., "solc8.28")
        include_relpaths: If True, also add --use_relpaths_for_solc_json flag

    Returns:
        CompletedProcess result
    """
    # Create new command with --solc override
    retry_cmd = cmd + ["--solc", solc_version]

    # Add relpaths flag if requested and not already present
    if include_relpaths and "--use_relpaths_for_solc_json" not in retry_cmd:
        retry_cmd.append("--use_relpaths_for_solc_json")

    flags_msg = f"--solc {solc_version}"
    if include_relpaths:
        flags_msg += " --use_relpaths_for_solc_json"

    logger.log(
        f"Retrying with {flags_msg}",
        "INFO",
        "ASTUtil"
    )

    return _run_command(retry_cmd, cwd, timeout)


def _execute_certora_with_remappings_workaround(
    cmd: list,
    cwd: Path,
    timeout: int = 300
) -> subprocess.CompletedProcess:
    """
    Execute certoraRun command with workarounds for common compilation failures.

    Cloud runs may have various issues that cause compilation to fail. This function
    attempts multiple workarounds in sequence to resolve these issues.

    Workaround strategy:
    1. Try running the command normally
    2. If it fails with solc version mismatch: Retry with --solc override for required version
    3. If it fails: Try with --use_relpaths_for_solc_json flag (if not already present)
       - If this fails with solc version mismatch: Retry with both --solc and --use_relpaths_for_solc_json
    4. If it fails with remappings conflict, try file-based workarounds:
       a) Rename remappings.txt and retry
          - If fails with solc mismatch: Retry with --solc
          - If still fails: Try with --use_relpaths_for_solc_json
          - If fails with solc mismatch: Retry with both --solc and --use_relpaths_for_solc_json
       b) Rename foundry.toml and retry (same solc checks as above)
    5. If a workaround succeeds, leave the renamed file in place and return success
    6. If all workarounds fail, restore all files to original state

    Note: After each failed attempt, we check for solc version mismatch errors and automatically
    retry with the correct --solc version, preserving any other flags that were applied.

    Args:
        cmd: Command to execute
        cwd: Working directory
        timeout: Timeout in seconds

    Returns:
        CompletedProcess result

    Notes:
        This workaround is needed because cloud runs may have been created with
        different tooling versions that handled package resolution and solc versioning
        differently. The structured approach tries multiple strategies to handle
        different scenarios.
    """
    # Track which files we've renamed for cleanup
    renamed_files = []

    try:
        # Step 1: Try vanilla command
        logger.log("Attempting vanilla command...", "INFO", "ASTUtil")
        result = _run_command(cmd, cwd, timeout)
        if result.returncode == 0:
            return result

        # Step 1.5: Check if vanilla command failed due to solc version mismatch
        required_solc = _detect_solc_version_mismatch_error(result)
        if required_solc:
            logger.log(
                f"Detected solc version mismatch, retrying with {required_solc}...",
                "INFO",
                "ASTUtil"
            )
            result = _retry_with_solc_override(cmd, cwd, timeout, required_solc)
            if result.returncode == 0:
                return result
            # If retry failed, continue with other workarounds

        # Step 2: Try vanilla + relpaths flag (if not already present)
        if "--use_relpaths_for_solc_json" not in cmd:
            logger.log(
                "Vanilla command failed, trying with --use_relpaths_for_solc_json...",
                "INFO",
                "ASTUtil"
            )
            result = _try_with_relpaths_flag(cmd, cwd, timeout)
            if result.returncode == 0:
                return result

            # Check if relpaths attempt failed due to solc version mismatch
            required_solc = _detect_solc_version_mismatch_error(result)
            if required_solc:
                logger.log(
                    f"Detected solc version mismatch, retrying with {required_solc} + relpaths...",
                    "INFO",
                    "ASTUtil"
                )
                result = _retry_with_solc_override(cmd, cwd, timeout, required_solc, include_relpaths=True)
                if result.returncode == 0:
                    return result
                # If retry failed, continue with other workarounds

        # Check if we have remappings conflict - if not, return the error
        if not _has_remappings_conflict(result):
            logger.log(
                "Command failed but not due to remappings conflict",
                "INFO",
                "ASTUtil"
            )
            return result

        # We have remappings conflict - try file-based workarounds
        logger.log(
            "Detected remappings conflict, attempting file-based workarounds...",
            "INFO",
            "ASTUtil"
        )

        # Define workaround strategies
        workarounds = [
            {"file": "remappings.txt", "backup": "remappings.txt.bkup", "name": "Workaround 1"},
            {"file": "foundry.toml", "backup": "foundry.toml.bkup", "name": "Workaround 2"}
        ]

        # Step 3: Try each file workaround (with and without relpaths flag)
        for workaround in workarounds:
            file_name = workaround["file"]
            backup_name = workaround["backup"]
            workaround_name = workaround["name"]

            logger.log(
                f"{workaround_name}: Trying to rename {file_name}...",
                "INFO",
                "ASTUtil"
            )

            # Try file rename alone
            result, was_renamed = _try_file_rename_workaround(
                file_name, backup_name, cmd, cwd, timeout
            )

            if was_renamed:
                renamed_files.append((cwd / file_name, cwd / backup_name))

            if result.returncode == 0:
                # Success - leave renamed file in place
                return result

            # Check if file rename attempt failed due to solc version mismatch
            if was_renamed:
                required_solc = _detect_solc_version_mismatch_error(result)
                if required_solc:
                    logger.log(
                        f"{workaround_name}: Detected solc version mismatch, retrying with {required_solc}...",
                        "INFO",
                        "ASTUtil"
                    )
                    result = _retry_with_solc_override(cmd, cwd, timeout, required_solc, include_relpaths=False)
                    if result.returncode == 0:
                        # Success - leave renamed file in place
                        return result

            # Try file rename + relpaths flag (if not already in cmd)
            if was_renamed and "--use_relpaths_for_solc_json" not in cmd:
                logger.log(
                    f"{workaround_name}: Trying with --use_relpaths_for_solc_json...",
                    "INFO",
                    "ASTUtil"
                )
                result = _try_with_relpaths_flag(cmd, cwd, timeout)
                if result.returncode == 0:
                    # Success - leave renamed file in place
                    return result

                # Check if this attempt failed due to solc version mismatch
                required_solc = _detect_solc_version_mismatch_error(result)
                if required_solc:
                    logger.log(
                        f"{workaround_name}: Detected solc version mismatch, retrying with {required_solc} + relpaths...",
                        "INFO",
                        "ASTUtil"
                    )
                    result = _retry_with_solc_override(cmd, cwd, timeout, required_solc, include_relpaths=True)
                    if result.returncode == 0:
                        # Success - leave renamed file in place
                        return result

            # Both attempts failed - restore file before trying next workaround
            if was_renamed:
                file_path = cwd / file_name
                backup_path = cwd / backup_name
                _restore_file(file_path, backup_path)
                renamed_files.remove((file_path, backup_path))

        # All workarounds failed
        logger.log(
            "All workarounds failed",
            "WARNING",
            "ASTUtil"
        )
        return result

    except Exception as e:
        # Error during workaround - try to restore all renamed files
        logger.log(
            f"Error during workaround execution: {e}",
            "ERROR",
            "ASTUtil"
        )

        # Restore all files that were renamed
        for file_path, backup_path in renamed_files:
            _restore_file(file_path, backup_path)

        # Return the last result we have, or create a failed result
        return subprocess.CompletedProcess(
            args=cmd,
            returncode=1,
            stdout="",
            stderr=f"Fatal error during workaround: {e}"
        )


def _get_solc_override_args(conf_file: Path) -> list:
    """
    Check conf file for solc version and return override args if needed.

    Cloud runs may have solc specified in the old format (solc-0.X.YY) instead
    of the current format (solcX.YY). This function detects the old format and
    returns override arguments to use the correct format.

    Args:
        conf_file: Path to the .conf configuration file

    Returns:
        List of arguments to append to certoraRun command:
        - ["--solc", "solcX.YY"] if override needed
        - [] if no override needed

    Notes:
        This handles differences between how cloud runs were created and how
        certoraRun currently expects solc versions to be specified.
    """
    import json5
    import re

    try:
        with open(conf_file, 'r') as f:
            conf_data = json5.load(f)

        # Check if "solc" field exists and matches old format: solc-0.X.YY
        solc_value = conf_data.get('solc', '')
        if not solc_value:
            return []

        # Match pattern: solc-0.X.YY (e.g., solc-0.8.24)
        old_format_match = re.match(r'solc-0\.(\d+)\.(\d+)', solc_value)
        if old_format_match:
            patch = old_format_match.group(2)
            new_format = f"solc8.{patch}"  # Convert to solcX.YY format

            logger.log(
                f"Detected old solc format '{solc_value}', overriding to '{new_format}'",
                "INFO",
                "ASTUtil"
            )

            return ["--solc", new_format]

        # Already in new format or different format - no override needed
        return []

    except Exception as e:
        logger.log(
            f"Error reading conf file for solc override check: {e}",
            "WARNING",
            "ASTUtil"
        )
        return []


def generate_ast(
    conf_file: str,
    output_ast: str,
    certora_run_command: str = "certoraRun",
    repo_base: Optional[str] = None,
    timeout: int = 600
) -> Tuple[bool, Optional[Path], Optional[str]]:
    """
    Generate AST JSON from a CVL spec configuration file.

    Executes: {certora_run_command} {conf_file} --compilation_steps_only --dump_cvl_ast {output_ast}

    Args:
        conf_file: Path to the .conf configuration file
        output_ast: Path where the AST JSON should be written
        certora_run_command: Command to run Certora (default: 'certoraRun')
        repo_base: Base directory for the repository (default: current working directory)
        timeout: Timeout in seconds for certoraRun execution (default: 600)

    Returns:
        Tuple of (success: bool, output_path: Optional[Path], error_message: Optional[str])
        - success: True if AST generation succeeded
        - output_path: Path to generated AST file if successful, None otherwise
        - error_message: Error message if failed, None if successful

    Raises:
        FileNotFoundError: If conf_file doesn't exist (fatal error per project policy)
    """
    conf_path = Path(conf_file).resolve()
    output_path = Path(output_ast).resolve()  # Make absolute so it's created in caller's cwd
    cwd = Path(repo_base).resolve() if repo_base else Path.cwd()

    # Validate conf file exists (fatal error if not)
    if not conf_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {conf_file}")

    # Make conf_path relative to cwd for the command
    try:
        conf_path_for_cmd = conf_path.relative_to(cwd)
    except ValueError:
        # If conf_path is not relative to cwd, use absolute path
        conf_path_for_cmd = conf_path

    logger.log(
        f"Generating AST from {conf_file} -> {output_path} (cwd: {cwd})",
        "INFO",
        "ASTUtil"
    )

    # Check if we need to override solc version (old format: solc-0.X.YY -> new format: solcX.YY)
    solc_override_args = _get_solc_override_args(conf_path)

    # Build command - use relative path for conf, absolute path for output
    cmd = [
        certora_run_command,
        str(conf_path_for_cmd),
        "--compilation_steps_only",
        "--dump_cvl_ast",
        str(output_path)
    ]
    # Add solc override if needed
    cmd.extend(solc_override_args)

    logger.log(
        f"Executing: {' '.join(cmd)}",
        "INFO",
        "ASTUtil"
    )

    try:
        # Execute command with workaround for remappings.txt conflicts
        result = _execute_certora_with_remappings_workaround(
            cmd,
            cwd,
            timeout=timeout
        )

        # Check if command succeeded
        if result.returncode != 0:
            error_msg = f"certoraRun failed with exit code {result.returncode}\n"
            error_msg += f"Command: {' '.join(cmd)}\n"
            error_msg += f"Working Directory: {cwd}\n"
            error_msg += "=== STDOUT ===\n"
            error_msg += result.stdout if result.stdout else "(empty)\n"
            error_msg += "\n=== STDERR ===\n"
            error_msg += result.stderr if result.stderr else "(empty)\n"

            logger.log(
                error_msg,
                "ERROR",
                "ASTUtil"
            )

            return (False, None, error_msg)

        # Verify output file was created
        if not output_path.exists():
            error_msg = f"AST file was not created at {output_ast}"
            logger.log(
                error_msg,
                "ERROR",
                "ASTUtil"
            )
            return (False, None, error_msg)

        # Success
        file_size = output_path.stat().st_size
        logger.log(
            f"AST generated successfully ({file_size} bytes)",
            "SUCCESS",
            "ASTUtil"
        )

        return (True, output_path, None)

    except subprocess.TimeoutExpired:
        error_msg = f"AST generation timed out after {timeout} seconds"
        logger.log(
            error_msg,
            "ERROR",
            "ASTUtil"
        )
        return (False, None, error_msg)

    except FileNotFoundError as e:
        error_msg = f"Command not found: {certora_run_command}"
        logger.log(
            error_msg,
            "ERROR",
            "ASTUtil"
        )
        raise FileNotFoundError(error_msg) from e

    except Exception as e:
        error_msg = f"Unexpected error during AST generation: {e}"
        logger.log(
            error_msg,
            "ERROR",
            "ASTUtil"
        )
        raise


def main():
    """Command-line interface for AST generation."""
    import argparse

    parser = argparse.ArgumentParser(
        description='Generate CVL spec AST JSON from configuration file or cloud run'
    )
    parser.add_argument(
        'input',
        help='Path to .conf configuration file OR cloud run URL (https://prover.certora.com/output/...)'
    )
    parser.add_argument(
        'output_ast',
        help='Path where AST JSON should be written'
    )
    parser.add_argument(
        '--certora-run',
        dest='certora_run_command',
        default='certoraRun',
        help='Command to run Certora (default: certoraRun)'
    )
    parser.add_argument(
        '--repo-base',
        dest='repo_base',
        default=None,
        help='Base directory for the repository (default: current working directory). Ignored for cloud runs.'
    )

    args = parser.parse_args()

    try:
        # Determine if input is a cloud run URL or local conf file
        is_cloud_run = args.input.startswith('http://') or args.input.startswith('https://')

        if is_cloud_run:
            # Generate AST from cloud run
            success, ast_path, error_msg = generate_ast_from_cloud_run(
                args.input,
                args.output_ast,
                args.certora_run_command
            )
        else:
            # Generate AST from local conf file
            success, ast_path, error_msg = generate_ast(
                args.input,
                args.output_ast,
                args.certora_run_command,
                args.repo_base
            )

        if success:
            print(f"AST generated successfully: {ast_path}")
            sys.exit(0)
        else:
            print(f"Failed to generate AST: {error_msg}", file=sys.stderr)
            sys.exit(1)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        raise


def generate_ast_from_cloud_run(
    cloud_run_url: str,
    output_ast: str,
    dashboard_path: Path,
    certora_run_command: str = "certoraRun",
    timeout: int = 600
) -> Tuple[bool, Optional[Path], Optional[str]]:
    """
    Generate AST JSON from a cloud run by downloading its tarball and extracting the run.conf.

    This function:
    1. Downloads the tarball from the cloud run URL
    2. Extracts it to find the run.conf in inputs/.certora_sources/
    3. Generates the AST using that run.conf with the extracted directory as repo_base

    Args:
        cloud_run_url: URL to the cloud run (e.g., https://prover.certora.com/output/...)
        output_ast: Path where the AST JSON should be written
        dashboard_path: Path to the project root (where .certora_internal should be)
        certora_run_command: Command to run Certora (default: 'certoraRun')
        timeout: Timeout in seconds for AST generation (default: 600)

    Returns:
        Tuple of (success: bool, output_path: Optional[Path], error_message: Optional[str])

    Raises:
        FileNotFoundError: If required files/directories don't exist
    """
    import re
    from src.dashboard.tarball_manager import download_tarball, extract_from_tarball
    from src.dashboard.constants import DIR_TARBALL_CACHE

    logger.log(
        f"Generating AST from cloud run: {cloud_run_url}",
        "INFO",
        "ASTUtil"
    )

    # Extract job ID from URL
    # URL format: https://prover.certora.com/output/12345/abc123def456...
    match = re.search(r'/output/(\d+)/([a-f0-9]+)', cloud_run_url)
    if not match:
        error_msg = f"Invalid cloud run URL format: {cloud_run_url}"
        logger.log(error_msg, "ERROR", "ASTUtil")
        raise ValueError(error_msg)

    job_number = match.group(1)
    job_hash = match.group(2)
    job_id = f"{job_number}_{job_hash}"

    # Create cache directory for tarballs using the dashboard_path
    cache_dir = dashboard_path / ".certora_internal" / DIR_TARBALL_CACHE
    cache_dir.mkdir(parents=True, exist_ok=True)

    # Download tarball
    logger.log(
        f"Downloading tarball for job {job_id}...",
        "INFO",
        "ASTUtil"
    )

    tarball_path = download_tarball(job_id, cloud_run_url, cache_dir)
    if not tarball_path:
        error_msg = f"Failed to download tarball from {cloud_run_url}"
        logger.log(error_msg, "ERROR", "ASTUtil")
        return (False, None, error_msg)

    # Extract inputs/.certora_sources from tarball
    certora_sources_dir = extract_from_tarball(
        tarball_path,
        job_id,
        cache_dir.parent,  # .certora_internal/local_dashboard
        subpath="inputs/.certora_sources"
    )

    if not certora_sources_dir:
        error_msg = f"Failed to extract inputs/.certora_sources from tarball"
        logger.log(error_msg, "ERROR", "ASTUtil")
        return (False, None, error_msg)

    # Find run.conf in .certora_sources
    run_conf_path = certora_sources_dir / "run.conf"
    if not run_conf_path.exists():
        error_msg = f"run.conf not found at {run_conf_path}"
        logger.log(error_msg, "ERROR", "ASTUtil")
        raise FileNotFoundError(error_msg)

    logger.log(
        f"Found run.conf at {run_conf_path}",
        "INFO",
        "ASTUtil"
    )

    # Generate AST using the run.conf with certora_sources as repo_base
    return generate_ast(
        str(run_conf_path),
        output_ast,
        certora_run_command=certora_run_command,
        repo_base=str(certora_sources_dir),
        timeout=timeout
    )


if __name__ == '__main__':
    main()
