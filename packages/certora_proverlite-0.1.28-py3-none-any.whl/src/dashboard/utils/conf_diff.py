#!/usr/bin/env python3
"""
Utility for comparing configuration files (run.conf).

This module provides deep comparison of conf files, reusing the proven
deep comparison logic from spec_diff.py.
"""

import json5
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from src.dashboard.utils.spec_diff import SpecDiff


def compare_confs(
    local_conf_path: str,
    remote_conf_path: str
) -> Tuple[bool, Optional[Dict[str, Any]]]:
    """
    Compare two configuration files, ignoring the 'msg' and 'group_id' fields.

    Args:
        local_conf_path: Path to local conf file
        remote_conf_path: Path to remote conf file (from extracted tarball)

    Returns:
        Tuple of (equivalent: bool, diff_data: Optional[Dict])
        - If equivalent is True, diff_data will be None
        - Otherwise, diff_data contains the detailed differences

    Raises:
        FileNotFoundError: If either file doesn't exist
        json.JSONDecodeError: If either file is not valid JSON
    """
    # Load conf files
    local_conf_file = Path(local_conf_path)
    remote_conf_file = Path(remote_conf_path)

    if not local_conf_file.exists():
        raise FileNotFoundError(f"Local conf file not found: {local_conf_path}")
    if not remote_conf_file.exists():
        raise FileNotFoundError(f"Remote conf file not found: {remote_conf_path}")

    with open(local_conf_file, 'r') as f:
        local_conf = json5.load(f)

    with open(remote_conf_file, 'r') as f:
        remote_conf = json5.load(f)

    # Remove 'msg' and 'group_id' fields from both confs (ignore them during comparison)
    local_conf_clean = _remove_ignored_fields(local_conf)
    remote_conf_clean = _remove_ignored_fields(remote_conf)

    # Create a SpecDiff instance to reuse deep comparison logic
    # We use it with the conf data (dicts) instead of spec ASTs
    spec_diff = SpecDiff(local_conf_clean, remote_conf_clean)

    # Check if confs are equivalent using deep comparison
    if spec_diff._deep_equals(local_conf_clean, remote_conf_clean):
        return (True, None)

    # Confs differ - compute detailed diff
    diff_result = spec_diff._compute_deep_diff(local_conf_clean, remote_conf_clean)

    if not diff_result:
        # This shouldn't happen (we already know they differ), but handle gracefully
        return (True, None)

    # Return the diff with a wrapper structure
    diff_data = {
        'equivalent': False,
        'before': diff_result.get('before'),
        'after': diff_result.get('after'),
        'path': diff_result.get('path'),
        'path_before': diff_result.get('path_before'),
        'path_after': diff_result.get('path_after')
    }

    return (False, diff_data)


def _remove_ignored_fields(obj: Any) -> Any:
    """
    Recursively remove 'msg' and 'group_id' fields from an object.

    Args:
        obj: Object to clean (dict, list, or primitive)

    Returns:
        Cleaned copy of the object without ignored fields
    """
    if isinstance(obj, dict):
        result = {}
        for key, val in obj.items():
            # Skip ignored fields
            if key in ('msg', 'group_id'):
                continue
            result[key] = _remove_ignored_fields(val)
        return result
    elif isinstance(obj, list):
        return [_remove_ignored_fields(item) for item in obj]
    else:
        return obj
