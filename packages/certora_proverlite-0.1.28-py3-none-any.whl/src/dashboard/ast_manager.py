"""
AST management module for generating and caching CVL spec ASTs.

Handles generation of ASTs for both local conf files and remote cloud runs,
with intelligent caching to avoid redundant work.
"""

import hashlib
import json
import os
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Callable, Dict, Optional, Tuple

from src.dashboard.constants import FILE_ASTS
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import ScanSnapshot
from src.dashboard.utils.ast_util import generate_ast, generate_ast_from_cloud_run


def _compute_conf_hash(conf_path: Path) -> str:
    """
    Compute a hash for a conf file path to use as cache key.

    Args:
        conf_path: Path to the conf file

    Returns:
        Short hash string (first 12 chars of SHA256)
    """
    sha256 = hashlib.sha256()
    sha256.update(str(conf_path.resolve()).encode('utf-8'))
    return sha256.hexdigest()[:12]


def _generate_single_ast(
    conf_info,
    timestamp: int,
    dashboard_path: Path,
    asts_dir: Path,
    dashboard_dir: Path
) -> Tuple[str, Dict, bool]:
    """
    Generate AST for a single conf file (used by parallel executor).

    Returns:
        Tuple of (conf_path_str, ast_info_dict, success_bool)
        success_bool is True if AST exists or was generated successfully, False if failed
    """
    conf_path_str = str(conf_info.conf_path)
    conf_hash = _compute_conf_hash(conf_info.conf_path)

    # Include timestamp in filename to avoid mixing ASTs from different scans
    ast_filename = f"local_{timestamp}_{conf_hash}.json"
    ast_path = asts_dir / ast_filename

    # Check if AST already exists (skip regeneration for performance)
    if ast_path.exists():
        logger.log(
            f"AST already exists for {conf_info.conf_path.name}, skipping generation",
            "INFO",
            "ASTManager"
        )
        # Return the existing AST info - count as success
        return (conf_path_str, {
            "ast_path": str(ast_path.relative_to(dashboard_dir)),
            "rules": conf_info.rules
        }, True)

    logger.log(
        f"Generating AST for conf: {conf_info.conf_path.name}",
        "INFO",
        "ASTManager"
    )

    try:
        # Generate the AST
        success, output_path, error_msg = generate_ast(
            conf_file=str(conf_info.conf_path),
            output_ast=str(ast_path),
            repo_base=str(dashboard_path)
        )

        if success and output_path:
            logger.log(
                f"Successfully generated AST: {ast_filename}",
                "SUCCESS",
                "ASTManager"
            )

            # Return mapping with success=True
            return (conf_path_str, {
                "ast_path": str(ast_path.relative_to(dashboard_dir)),
                "rules": conf_info.rules
            }, True)
        else:
            logger.log(
                f"Failed to generate AST for {conf_info.conf_path.name}: {error_msg}",
                "ERROR",
                "ASTManager"
            )
            # Return entry without ast_path to indicate failure, success=False
            return (conf_path_str, {
                "ast_path": None,
                "rules": conf_info.rules,
                "error": error_msg or "Unknown error"
            }, False)

    except Exception as e:
        logger.log(
            f"Exception generating AST for {conf_info.conf_path.name}: {e}",
            "ERROR",
            "ASTManager"
        )
        return (conf_path_str, {
            "ast_path": None,
            "rules": conf_info.rules,
            "error": str(e)
        }, False)


def generate_local_asts_for_snapshot(
    snapshot: ScanSnapshot,
    dashboard_path: Path,
    timestamp: int,
    progress_callback: Optional[Callable[[int, int, str], None]] = None,
    max_workers: Optional[int] = None
) -> Dict[str, Dict]:
    """
    Generate local ASTs for all conf files in a snapshot in parallel.

    This generates one AST per conf file (not per rule), which covers all
    rules in that conf's spec files. Results are cached in asts.json.
    Uses ThreadPoolExecutor to generate ASTs in parallel.

    Args:
        snapshot: The scan snapshot containing conf information
        dashboard_path: Path to the project root (used as repo_base)
        timestamp: Timestamp of the current snapshot
        progress_callback: Optional callback function(processed_count, successful_count, current_conf_name)
                          called after each conf's AST is generated/skipped
        max_workers: Maximum number of parallel workers. Defaults to min(10, cpu_count)

    Returns:
        Dict mapping conf_path → {ast_path, rules}

    Side Effects:
        - Creates AST files in .certora_internal/local_dashboard/asts/
        - Saves asts.json to .certora_internal/local_dashboard/{timestamp}/
    """
    # Determine number of workers
    if max_workers is None:
        max_workers = min(10, (os.cpu_count() or 1))

    logger.log(
        f"Generating local ASTs for {len(snapshot.confs)} conf files using {max_workers} workers",
        "INFO",
        "ASTManager"
    )

    # Setup directories
    dashboard_dir = dashboard_path / ".certora_internal" / "local_dashboard"
    asts_dir = dashboard_dir / "asts"
    asts_dir.mkdir(parents=True, exist_ok=True)

    timestamp_dir = dashboard_dir / str(timestamp)
    timestamp_dir.mkdir(parents=True, exist_ok=True)

    asts_mapping: dict = {"conf_mappings": {}}
    completed_count = 0
    successful_count = 0
    lock = threading.Lock()

    # Use ThreadPoolExecutor for parallel execution
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        future_to_conf = {
            executor.submit(
                _generate_single_ast,
                conf_info,
                timestamp,
                dashboard_path,
                asts_dir,
                dashboard_dir
            ): conf_info
            for conf_info in snapshot.confs
        }

        # Process results as they complete
        for future in as_completed(future_to_conf):
            conf_info = future_to_conf[future]

            try:
                conf_path_str, ast_info, success = future.result()

                with lock:
                    completed_count += 1
                    if success:
                        successful_count += 1
                    current_count = completed_count
                    current_success = successful_count
                    asts_mapping["conf_mappings"][conf_path_str] = ast_info

                # Call progress callback (outside lock to avoid blocking other threads)
                if progress_callback:
                    progress_callback(current_count, current_success, conf_info.conf_path.name)

            except Exception as e:
                logger.log(
                    f"Unexpected error processing {conf_info.conf_path.name}: {e}",
                    "ERROR",
                    "ASTManager"
                )
                # Record the error (don't increment successful_count)
                with lock:
                    completed_count += 1
                    current_count = completed_count
                    current_success = successful_count
                    asts_mapping["conf_mappings"][str(conf_info.conf_path)] = {
                        "ast_path": None,
                        "rules": conf_info.rules,
                        "error": str(e)
                    }

                # Call progress callback
                if progress_callback:
                    progress_callback(current_count, current_success, conf_info.conf_path.name)

    # Save asts.json to timestamp directory
    asts_json_path = timestamp_dir / FILE_ASTS
    try:
        with open(asts_json_path, "w") as f:
            json.dump(asts_mapping, f, indent=2)

        logger.log(
            f"Saved AST mappings to {asts_json_path}",
            "INFO",
            "ASTManager"
        )
    except Exception as e:
        logger.log(
            f"Failed to save asts.json: {e}",
            "ERROR",
            "ASTManager"
        )

    return asts_mapping["conf_mappings"]


def get_or_generate_remote_ast(
    job_id: str,
    run_url: str,
    dashboard_path: Path,
    ast_timeout: int = 600
) -> Optional[Path]:
    """
    Get cached remote AST or generate it from cloud run.

    Remote ASTs are cached by job_id in the shared asts/ directory.
    If the AST already exists, it's returned immediately. Otherwise,
    it's generated from the cloud run tarball.

    Args:
        job_id: The Certora job identifier
        run_url: URL to the cloud run output
        dashboard_path: Path to the project root
        ast_timeout: Timeout in seconds for AST generation (default: 600)

    Returns:
        Path to the AST file if successful, None if generation failed

    Side Effects:
        - May create AST file in .certora_internal/local_dashboard/asts/
        - Downloads and extracts cloud run tarball (via ast_util)
    """
    # Setup directories
    dashboard_dir = dashboard_path / ".certora_internal" / "local_dashboard"
    asts_dir = dashboard_dir / "asts"
    asts_dir.mkdir(parents=True, exist_ok=True)

    # Check cache first
    ast_filename = f"remote_{job_id}.json"
    ast_path = asts_dir / ast_filename

    if ast_path.exists():
        logger.log(
            f"Using cached remote AST for job {job_id}",
            "INFO",
            "ASTManager"
        )
        return ast_path

    # Need to generate
    logger.log(
        f"Generating remote AST for job {job_id} from {run_url}",
        "INFO",
        "ASTManager"
    )

    try:
        success, output_path, error_msg = generate_ast_from_cloud_run(
            cloud_run_url=run_url,
            output_ast=str(ast_path),
            dashboard_path=dashboard_path,
            timeout=ast_timeout,
        )

        if success and output_path:
            logger.log(
                f"Successfully generated remote AST: {ast_filename}",
                "SUCCESS",
                "ASTManager"
            )
            return output_path
        else:
            logger.log(
                f"Failed to generate remote AST for job {job_id}: {error_msg}",
                "ERROR",
                "ASTManager"
            )
            return None

    except Exception as e:
        logger.log(
            f"Exception generating remote AST for job {job_id}: {e}",
            "ERROR",
            "ASTManager"
        )
        return None


def load_asts_mapping(timestamp_dir: Path) -> Dict[str, Dict]:
    """
    Load the asts.json mapping from a timestamp directory.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory

    Returns:
        Dict mapping conf_path → {ast_path, rules}, or empty dict if not found
    """
    asts_json_path = timestamp_dir / FILE_ASTS

    if not asts_json_path.exists():
        logger.log(
            f"No asts.json found at {asts_json_path}",
            "INFO",
            "ASTManager"
        )
        return {}

    try:
        with open(asts_json_path, "r") as f:
            data = json.load(f)

        return data.get("conf_mappings", {})

    except Exception as e:
        logger.log(
            f"Failed to load asts.json: {e}",
            "ERROR",
            "ASTManager"
        )
        return {}
