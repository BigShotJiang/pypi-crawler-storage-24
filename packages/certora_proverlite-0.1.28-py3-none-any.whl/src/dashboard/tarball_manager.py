"""
Tarball manager for downloading and extracting cloud run tarballs.

Handles downloading tarballs from cloud verification runs, caching them locally,
and extracting spec files for hash comparison.
"""

import hashlib
import json
import shutil
import tarfile
import tempfile
import threading
from pathlib import Path
from typing import Dict, Optional

from src.dashboard.constants import DIR_EXTRACTED, DIR_EXTRACTED_TARS, DIR_TARBALL_CACHE
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.utils.certora_wget import download_with_auth

# Sidecar filename for tarball MD5 cache validation
_TARBALL_MD5_FILENAME = ".tarball_md5"

# Global lock dictionaries for preventing concurrent operations on the same job
_download_locks = {}
_download_locks_lock = threading.Lock()
_extraction_locks = {}
_extraction_locks_lock = threading.Lock()


def _compute_file_md5(file_path: Path) -> str:
    """Compute MD5 hash of a file by reading raw bytes (no decompression)."""
    md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            md5.update(chunk)
    return md5.hexdigest()


def get_tarball_url(output_url: str) -> str:
    """
    Convert output URL to tarball URL, preserving authentication parameters.

    Args:
        output_url: The output URL from the job (e.g., https://prover.certora.com/output/...)

    Returns:
        URL to the tarball - currently for certora_wget this is just the output URL
    """
    return output_url


def download_tarball(job_id: str, output_url: str, cache_dir: Path) -> Optional[Path]:
    """
    Download a tarball from the cloud, with caching.

    Uses certora_wget.py to handle authentication via browser cookies.

    Args:
        job_id: Job identifier
        output_url: Output URL for the job
        cache_dir: Directory to cache tarballs

    Returns:
        Path to the downloaded tarball, or None if download failed

    Thread Safety:
        Uses per-job locks to prevent concurrent downloads of the same tarball.
        If another thread is already downloading, waits for it to complete.
    """
    # Get or create a lock for this specific job
    with _download_locks_lock:
        if job_id not in _download_locks:
            _download_locks[job_id] = threading.Lock()
        job_lock = _download_locks[job_id]

    # Acquire the job-specific lock (will wait if another thread is downloading)
    with job_lock:
        # Check cache again after acquiring lock (another thread may have downloaded)
        cached_path = cache_dir / f"{job_id}.tar.gz"

        if cached_path.exists():
            logger.log(
                f"Tarball for job {job_id} already cached",
                "INFO",
                "TarballManager"
            )
            return cached_path

        logger.log(
            f"Downloading tarball for job {job_id} using certora_wget...",
            "INFO",
            "TarballManager"
        )

        return _download_tarball_impl(job_id, output_url, cached_path)


def _download_tarball_impl(job_id: str, output_url: str, cached_path: Path) -> Optional[Path]:
    """
    Internal implementation of tarball download (called with lock held).
    """
    # Download tarball using certora_wget.py
    tarball_url = get_tarball_url(output_url)

    try:
        rc = download_with_auth(tarball_url, str(cached_path), convert_to_zip_output=True)

        if rc != 0:
            logger.log(
                f"certora_wget failed for job {job_id} (exit code {rc})",
                "WARNING",
                "TarballManager"
            )
            return None

        # Check if file was created
        if not cached_path.exists():
            logger.log(
                f"Tarball download failed for job {job_id}: file not created",
                "WARNING",
                "TarballManager"
            )
            return None

        file_size = cached_path.stat().st_size

        logger.log(
            f"Downloaded tarball for job {job_id} ({file_size} bytes)",
            "INFO",
            "TarballManager"
        )

        return cached_path

    except Exception as e:
        logger.log(
            f"Error downloading tarball for job {job_id}: {e}",
            "ERROR",
            "TarballManager"
        )
        return None


def get_extraction_cache_path(tarball_path: Path, spec_filename: str) -> Path:
    """
    Get the cache path for an extracted spec file.

    Args:
        tarball_path: Path to the tarball
        spec_filename: Name of the spec file

    Returns:
        Path to cached extracted spec file
    """
    # Create extraction cache next to tarball cache
    extraction_cache_dir = tarball_path.parent / DIR_EXTRACTED
    extraction_cache_dir.mkdir(exist_ok=True)

    # Use tarball name + spec filename for cache key
    cache_name = f"{tarball_path.stem}_{spec_filename}"
    return extraction_cache_dir / cache_name


def extract_spec_from_tarball(tarball_path: Path, spec_filename: str) -> Optional[str]:
    """
    Extract a spec file from a tarball and return its contents.

    Uses extraction cache to avoid re-extracting the same file.

    Args:
        tarball_path: Path to the tarball
        spec_filename: Name of the spec file to extract (e.g., "AccountingConsistency.spec")

    Returns:
        Contents of the spec file, or None if not found
    """
    # Check extraction cache first
    cache_path = get_extraction_cache_path(tarball_path, spec_filename)

    if cache_path.exists():
        logger.log(
            f"Using cached extraction of {spec_filename} from {tarball_path.name}",
            "INFO",
            "TarballManager"
        )
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            logger.log(
                f"Failed to read cached extraction: {e}",
                "WARNING",
                "TarballManager"
            )
            # Fall through to re-extract

    # Extract from tarball
    try:
        with tarfile.open(tarball_path, "r:gz") as tar:
            # Look for the spec file in the tarball
            # Spec files are usually in the root or in a specs/ directory
            possible_paths = [
                spec_filename,
                f"specs/{spec_filename}",
                f"./{spec_filename}",
            ]

            for member in tar.getmembers():
                member_basename = Path(member.name).name

                if member_basename == spec_filename:
                    # Found the spec file
                    file_obj = tar.extractfile(member)
                    if file_obj:
                        content = file_obj.read().decode("utf-8", errors="ignore")

                        # Cache the extracted content
                        try:
                            with open(cache_path, "w", encoding="utf-8") as f:
                                f.write(content)
                            logger.log(
                                f"Cached extraction of {spec_filename}",
                                "INFO",
                                "TarballManager"
                            )
                        except Exception as e:
                            logger.log(
                                f"Failed to cache extraction: {e}",
                                "WARNING",
                                "TarballManager"
                            )

                        return content

        logger.log(
            f"Spec file '{spec_filename}' not found in tarball {tarball_path.name}",
            "WARNING",
            "TarballManager"
        )
        return None

    except Exception as e:
        logger.log(
            f"Error extracting spec from tarball {tarball_path.name}: {e}",
            "ERROR",
            "TarballManager"
        )
        return None


def compute_spec_hash(spec_content: str) -> str:
    """
    Compute SHA256 hash of spec file content.

    Args:
        spec_content: Content of the spec file

    Returns:
        SHA256 hash (hex string)
    """
    return hashlib.sha256(spec_content.encode("utf-8")).hexdigest()


def get_spec_hash_from_tarball(
    job_id: str,
    output_url: str,
    spec_filename: str,
    cache_dir: Path
) -> Optional[str]:
    """
    Get the hash of a spec file from a tarball.

    Downloads the tarball (with caching), extracts the spec file, and computes its hash.

    Args:
        job_id: Job identifier
        output_url: Output URL for the job
        spec_filename: Name of the spec file (e.g., "AccountingConsistency.spec")
        cache_dir: Directory to cache tarballs

    Returns:
        SHA256 hash of the spec file, or None if failed
    """
    # Download tarball
    tarball_path = download_tarball(job_id, output_url, cache_dir)
    if tarball_path is None:
        return None

    # Extract spec file
    spec_content = extract_spec_from_tarball(tarball_path, spec_filename)
    if spec_content is None:
        return None

    # Compute hash
    spec_hash = compute_spec_hash(spec_content)

    logger.log(
        f"Computed hash for {spec_filename} from job {job_id}: {spec_hash[:16]}...",
        "INFO",
        "TarballManager"
    )

    return spec_hash


def get_tarball_cache_stats(cache_dir: Path) -> Dict[str, int]:
    """
    Get statistics about the tarball cache and extraction cache.

    Args:
        cache_dir: Path to tarball cache directory

    Returns:
        Dictionary with cache statistics
    """
    if not cache_dir.exists():
        return {
            "tarball_count": 0,
            "tarball_size_bytes": 0,
            "extracted_count": 0,
            "extracted_size_bytes": 0,
        }

    # Tarball stats
    tarball_files = list(cache_dir.glob("*.tar.gz"))
    tarball_size = sum(f.stat().st_size for f in tarball_files)

    # Extraction cache stats
    extraction_dir = cache_dir / "extracted"
    extracted_files = list(extraction_dir.glob("*")) if extraction_dir.exists() else []
    extracted_size = sum(f.stat().st_size for f in extracted_files if f.is_file())

    return {
        "tarball_count": len(tarball_files),
        "tarball_size_bytes": tarball_size,
        "extracted_count": len(extracted_files),
        "extracted_size_bytes": extracted_size,
    }


def _extract_tar_gz_helper(tar_path: Path, extract_to: Path) -> Path:
    """
    Extract tar.gz file to specified directory.

    Handles nested directories by flattening single top-level directory structures.

    Args:
        tar_path: Path to the tar.gz file
        extract_to: Target directory for extraction

    Returns:
        Path to the extracted content

    Raises:
        Exception: If extraction fails (caller should handle)
    """
    logger.log(
        f"Extracting {tar_path.name} to {extract_to}...",
        "INFO",
        "TarballManager"
    )

    temp_extract = extract_to.parent / f"{extract_to.name}_temp"

    try:
        # Extract to temporary location first
        with tarfile.open(tar_path, 'r:gz') as tar:
            tar.extractall(path=temp_extract)

        # Check if extraction created a single top-level directory
        extracted_items = list(temp_extract.iterdir())

        if len(extracted_items) == 1 and extracted_items[0].is_dir():
            # Move the nested directory content to the target location
            nested_dir = extracted_items[0]
            if extract_to.exists():
                shutil.rmtree(extract_to)
            shutil.move(str(nested_dir), str(extract_to))
            shutil.rmtree(temp_extract)
        else:
            # No nesting, just rename temp to target
            if extract_to.exists():
                shutil.rmtree(extract_to)
            shutil.move(str(temp_extract), str(extract_to))

        logger.log(
            f"Extraction complete: {extract_to}",
            "INFO",
            "TarballManager"
        )
        return extract_to

    except Exception as e:
        # Cleanup on failure
        if temp_extract.exists():
            shutil.rmtree(temp_extract)
        raise


def extract_from_tarball(
    tarball_path: Path,
    job_id: str,
    extraction_base: Path,
    subpath: str = "inputs/.certora_sources"
) -> Optional[Path]:
    """
    Extract a specific path from tarball to standard location.

    Args:
        tarball_path: Path to the tar.gz file
        job_id: Job ID for naming the extraction directory
        extraction_base: Base path (typically .certora_internal/local_dashboard)
        subpath: Path within tarball to extract (default: "inputs/.certora_sources")
                Use "" or None to extract entire tarball

    Returns:
        Path to extracted content, or None if failed
        - For subpath extraction: returns path to the extracted subpath
        - For full extraction: returns path to extraction root

    Notes:
        - Logs errors but does not raise exceptions
        - Uses caching - if extraction directory exists, skips re-extraction
        - If subpath doesn't exist in tarball, logs ERROR and returns None

    Thread Safety:
        Uses per-job locks to prevent concurrent extractions of the same job.
        If another thread is already extracting, waits for it to complete.
    """
    # Get or create a lock for this specific job
    with _extraction_locks_lock:
        if job_id not in _extraction_locks:
            _extraction_locks[job_id] = threading.Lock()
        job_lock = _extraction_locks[job_id]

    # Acquire the job-specific lock (will wait if another thread is extracting)
    with job_lock:
        # Check cache again after acquiring lock (another thread may have extracted)
        extract_root = extraction_base / DIR_EXTRACTED_TARS / job_id
        extract_target = extract_root / subpath

        # Validate cache: compare stored MD5 against current tarball's MD5
        md5_file = extract_root / _TARBALL_MD5_FILENAME
        if extract_target.exists() and md5_file.exists():
            stored_md5 = md5_file.read_text().strip()
            current_md5 = _compute_file_md5(tarball_path)
            if stored_md5 == current_md5:
                logger.log(
                    f"Using cached extraction for job {job_id} at {extract_target}",
                    "INFO",
                    "TarballManager"
                )
                return extract_target
            else:
                logger.log(
                    f"Tarball changed for job {job_id} (md5 mismatch), re-extracting",
                    "INFO",
                    "TarballManager"
                )

        logger.log(
            f"Extracting {'full tarball' if not subpath else subpath} for job {job_id}...",
            "INFO",
            "TarballManager"
        )

        return _extract_from_tarball_impl(tarball_path, job_id, extraction_base, subpath, extract_root, extract_target)


def _extract_from_tarball_impl(
    tarball_path: Path,
    job_id: str,
    extraction_base: Path,
    subpath: str,
    extract_root: Path,
    extract_target: Path
) -> Optional[Path]:
    """
    Internal implementation of tarball extraction (called with lock held).
    """
    try:
        if subpath:
            # Extract only the specified subpath
            # Need to handle the top-level directory that tarballs often have (e.g., "TarName/")
            extract_root.mkdir(parents=True, exist_ok=True)
            temp_extract = extract_root.parent / f"{extract_root.name}_temp"
            temp_extract.mkdir(parents=True, exist_ok=True)

            try:
                with tarfile.open(tarball_path, 'r:gz') as tar:
                    # Find members matching the subpath
                    members_to_extract = [
                        member for member in tar.getmembers()
                        if subpath in member.name
                    ]

                    if not members_to_extract:
                        logger.log(
                            f"Subpath '{subpath}' not found in tarball {tarball_path.name}",
                            "ERROR",
                            "TarballManager"
                        )
                        if temp_extract.exists():
                            shutil.rmtree(temp_extract)
                        return None

                    # Extract matching members to temp location
                    tar.extractall(path=temp_extract, members=members_to_extract)

                # Now find where the subpath actually ended up
                # It might be directly in temp_extract or nested under a top-level dir
                actual_subpath_location = None

                # Check if subpath is directly in temp_extract
                direct_path = temp_extract / subpath
                if direct_path.exists():
                    actual_subpath_location = direct_path
                else:
                    # Look for it under any top-level directory
                    for item in temp_extract.iterdir():
                        if item.is_dir():
                            nested_path = item / subpath
                            if nested_path.exists():
                                actual_subpath_location = nested_path
                                break

                if not actual_subpath_location:
                    logger.log(
                        f"Could not locate {subpath} in extracted content",
                        "ERROR",
                        "TarballManager"
                    )
                    shutil.rmtree(temp_extract)
                    return None

                # Move the actual subpath content to the target location
                if extract_target.exists():
                    shutil.rmtree(extract_target)

                # Create parent directories for target
                extract_target.parent.mkdir(parents=True, exist_ok=True)

                # Move the content
                shutil.move(str(actual_subpath_location), str(extract_target))

                # Clean up temp directory
                shutil.rmtree(temp_extract)

                logger.log(
                    f"Extracted {len(members_to_extract)} files from {subpath}",
                    "INFO",
                    "TarballManager"
                )

            except Exception as e:
                # Clean up temp on error
                if temp_extract.exists():
                    shutil.rmtree(temp_extract)
                raise

        else:
            # Extract entire tarball
            _extract_tar_gz_helper(tarball_path, extract_root)

        # Write tarball MD5 for cache validation
        try:
            md5_file = extract_root / _TARBALL_MD5_FILENAME
            md5_file.write_text(_compute_file_md5(tarball_path))
        except Exception:
            pass  # Non-fatal: extraction succeeded, just can't cache-validate next time

        return extract_target

    except Exception as e:
        logger.log(
            f"Error extracting from tarball {tarball_path.name}: {e}",
            "ERROR",
            "TarballManager"
        )
        return None


def clear_tarball_cache(cache_dir: Path):
    """
    Clear the tarball cache.

    Args:
        cache_dir: Path to tarball cache directory
    """
    if not cache_dir.exists():
        return

    shutil.rmtree(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    logger.log(
        "Tarball cache cleared",
        "INFO",
        "TarballManager"
    )
