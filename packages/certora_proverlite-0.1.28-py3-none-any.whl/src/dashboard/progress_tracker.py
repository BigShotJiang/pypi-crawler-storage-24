"""
Progress tracking for long-running cloud sync operations.
"""

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from src.dashboard.constants import PROGRESS_STATUS_COMPLETED, PROGRESS_STATUS_FAILED, PROGRESS_STATUS_RUNNING


@dataclass
class SyncProgress:
    """Track progress of a cloud sync operation."""
    total_jobs: int
    processed_jobs: int
    current_job_id: Optional[str]
    status: str  # "running", "completed", "failed"
    error_message: Optional[str] = None
    start_time: float = 0
    last_update_time: float = 0
    # Diff computation phase
    phase: str = "fetching"  # "fetching", "computing_diffs", "completed"
    total_rules: int = 0  # Total rules to compute diffs for
    processed_rules: int = 0  # Rules with diffs computed
    current_rule: Optional[str] = None  # Current rule being processed
    # Detailed diff progress tracking
    total_diff_jobs: int = 0  # Total unique jobs to compute diffs for
    completed_spec_diffs: int = 0  # Number of jobs with spec diffs computed
    completed_conf_diffs: int = 0  # Number of jobs with conf diffs computed
    completed_source_diffs: int = 0  # Number of jobs with source diffs computed

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict):
        # Handle old progress files that don't have new fields
        defaults = {
            'total_diff_jobs': 0,
            'completed_spec_diffs': 0,
            'completed_conf_diffs': 0,
            'completed_source_diffs': 0,
        }
        for key, default_value in defaults.items():
            if key not in data:
                data[key] = default_value
        return cls(**data)


@dataclass
class ScanProgress:
    """Track progress of a project scan operation."""
    phase: str  # "scanning", "generating_asts", "computing_diffs", "completed"
    total_items: int
    processed_items: int
    current_item: Optional[str]
    status: str  # "running", "completed", "failed"
    error_message: Optional[str] = None
    start_time: float = 0
    last_update_time: float = 0
    successful_items: int = 0  # Track successful compilations (for AST generation phase)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict):
        return cls(**data)


def save_progress(dashboard_dir: Path, progress: SyncProgress, mode: str = "local"):
    """
    Save sync progress to disk.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        progress: SyncProgress object
        mode: "local" or "remote"
    """
    dashboard_dir.mkdir(parents=True, exist_ok=True)
    filename = f"sync_progress_{mode}.json"
    progress_file = dashboard_dir / filename

    progress.last_update_time = time.time()

    try:
        with open(progress_file, "w") as f:
            json.dump(progress.to_dict(), f, indent=2)
    except Exception as e:
        # Don't fail the sync if we can't save progress
        pass


def load_progress(dashboard_dir: Path, mode: str = "local") -> Optional[SyncProgress]:
    """
    Load sync progress from disk.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        mode: "local" or "remote"

    Returns:
        SyncProgress object or None if no progress file exists
    """
    filename = f"sync_progress_{mode}.json"
    progress_file = dashboard_dir / filename

    if not progress_file.exists():
        return None

    try:
        with open(progress_file, "r") as f:
            data = json.load(f)
            return SyncProgress.from_dict(data)
    except Exception:
        return None


def clear_progress(dashboard_dir: Path, mode: str = "local"):
    """
    Clear sync progress file.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        mode: "local" or "remote"
    """
    filename = f"sync_progress_{mode}.json"
    progress_file = dashboard_dir / filename

    if progress_file.exists():
        try:
            progress_file.unlink()
        except Exception:
            pass


def save_scan_progress(dashboard_dir: Path, progress: ScanProgress):
    """
    Save scan progress to disk.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        progress: ScanProgress object
    """
    dashboard_dir.mkdir(parents=True, exist_ok=True)
    progress_file = dashboard_dir / "scan_progress.json"

    progress.last_update_time = time.time()

    try:
        with open(progress_file, "w") as f:
            json.dump(progress.to_dict(), f, indent=2)
    except Exception as e:
        # Don't fail the scan if we can't save progress
        pass


def load_scan_progress(dashboard_dir: Path) -> Optional[ScanProgress]:
    """
    Load scan progress from disk.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        ScanProgress object or None if no progress file exists
    """
    progress_file = dashboard_dir / "scan_progress.json"

    if not progress_file.exists():
        return None

    try:
        with open(progress_file, "r") as f:
            data = json.load(f)
            return ScanProgress.from_dict(data)
    except Exception:
        return None


def clear_scan_progress(dashboard_dir: Path):
    """
    Clear scan progress file.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
    """
    progress_file = dashboard_dir / "scan_progress.json"

    if progress_file.exists():
        try:
            progress_file.unlink()
        except Exception:
            pass
