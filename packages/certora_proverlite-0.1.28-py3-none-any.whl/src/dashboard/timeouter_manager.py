"""
Timeouter manager for tracking and managing timeout cracker runs.

Handles launching timeouter, tracking run state, and persisting results.
"""

import json
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Dict, Optional, Tuple

from src.dashboard.constants import (
    DIR_TIMEOUTER,
    FILE_TIMEOUTER_RUNS,
    FILE_TIMEOUTER_LOG,
)
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import TimeouterRunInfo


def get_timeouter_runs_file(dashboard_dir: Path) -> Path:
    """
    Get the path to the timeouter runs tracking file.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        Path to timeouter_runs.json
    """
    return dashboard_dir / FILE_TIMEOUTER_RUNS


def load_timeouter_runs(dashboard_dir: Path) -> Dict[str, TimeouterRunInfo]:
    """
    Load timeouter run tracking data.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        Dictionary mapping run_key -> TimeouterRunInfo
    """
    runs_file = get_timeouter_runs_file(dashboard_dir)

    if not runs_file.exists():
        return {}

    try:
        with open(runs_file, "r") as f:
            data = json.load(f)

        runs = {}
        for key, run_data in data.items():
            runs[key] = TimeouterRunInfo.from_dict(run_data)

        return runs

    except Exception as e:
        logger.log(
            f"Error loading timeouter runs: {e}",
            "ERROR",
            "TimeouterManager"
        )
        return {}


def save_timeouter_runs(runs: Dict[str, TimeouterRunInfo], dashboard_dir: Path):
    """
    Save timeouter run tracking data.

    Args:
        runs: Dictionary of run_key -> TimeouterRunInfo
        dashboard_dir: Path to .certora_internal/local_dashboard
    """
    runs_file = get_timeouter_runs_file(dashboard_dir)

    try:
        runs_file.parent.mkdir(parents=True, exist_ok=True)
        data = {key: run.to_dict() for key, run in runs.items()}

        with open(runs_file, "w") as f:
            json.dump(data, f, indent=2)

    except Exception as e:
        logger.log(
            f"Error saving timeouter runs: {e}",
            "ERROR",
            "TimeouterManager"
        )


def get_run_key(job_id: str, rule_name: str, method_name: Optional[str], use_method: bool) -> str:
    """
    Generate a unique key for tracking a timeouter run.

    Args:
        job_id: Job identifier
        rule_name: Rule name
        method_name: Method name (optional)
        use_method: Whether this is a method-level run

    Returns:
        Unique key string
    """
    if use_method and method_name:
        return f"{job_id}_{rule_name}_{method_name}"
    else:
        return f"{job_id}_{rule_name}_fullrule"


def _run_timeouter_async(
    cmd: list,
    log_file: Path,
    run_key: str,
    dashboard_dir: Path,
    project_root: Path,
    rule_name: str,
    method_name: Optional[str],
    use_method: bool
):
    """
    Run timeouter in background thread and update status when complete.

    This function runs in a separate thread and blocks until timeouter completes.
    It updates the status in timeouter_runs.json as it progresses.

    Args:
        cmd: Command to run
        log_file: Path to log file
        run_key: Unique key for this run
        dashboard_dir: Dashboard directory
        project_root: Project root directory
        rule_name: Rule name (for logging)
        method_name: Method name (for logging)
        use_method: Whether this is a method-level run
    """
    try:
        # Mark as running
        runs = load_timeouter_runs(dashboard_dir)
        if run_key in runs:
            runs[run_key].status = "running"
            save_timeouter_runs(runs, dashboard_dir)

        logger.log(
            f"Starting timeouter execution for {run_key}",
            "INFO",
            "TimeouterManager"
        )

        # Run timeouter (blocks for 10+ minutes)
        with open(log_file, "a") as log:
            log.write(f"\n{'='*80}\n")
            log.write(f"Timeouter run started at {time.ctime()}\n")
            log.write(f"Command: {' '.join(cmd)}\n")
            log.write(f"{'='*80}\n\n")
            log.flush()

            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=project_root
            )

            # Write output to log
            log.write(result.stdout)
            log.write(f"\n{'='*80}\n")
            log.write(f"Timeouter completed at {time.ctime()}\n")
            log.write(f"Exit code: {result.returncode}\n")
            log.write(f"{'='*80}\n")
            log.flush()

        # Parse the group URL from output
        # Search for prover.certora.com URL with groupIds parameter directly
        # (bypasses rich library's ANSI formatting codes and markup)
        group_url = None
        group_id = None
        match = re.search(r'(https://prover\.certora\.com/\?groupIds=([a-f0-9-]+))', result.stdout)
        if match:
            group_url = match.group(1)
            group_id = match.group(2)

        # Update status
        runs = load_timeouter_runs(dashboard_dir)
        if run_key in runs:
            if result.returncode == 0 and group_url:
                runs[run_key].status = "completed"
                runs[run_key].group_url = group_url
                runs[run_key].group_id = group_id
                logger.log(
                    f"Timeouter completed successfully for {run_key}, group URL: {group_url}",
                    "INFO",
                    "TimeouterManager"
                )
            else:
                runs[run_key].status = "failed"
                logger.log(
                    f"Timeouter failed for {run_key}: exit code {result.returncode}",
                    "ERROR",
                    "TimeouterManager"
                )
                logger.log(
                    f"Output:\n{result.stdout}",
                    "ERROR",
                    "TimeouterManager"
                )
            save_timeouter_runs(runs, dashboard_dir)

    except Exception as e:
        # Mark as failed
        logger.log(
            f"Exception during timeouter execution for {run_key}: {e}",
            "ERROR",
            "TimeouterManager"
        )
        runs = load_timeouter_runs(dashboard_dir)
        if run_key in runs:
            runs[run_key].status = "failed"
            save_timeouter_runs(runs, dashboard_dir)


def launch_timeouter(
    project_root: Path,
    dashboard_dir: Path,
    job_url: str,
    job_id: str,
    rule_name: str,
    method_name: Optional[str],
    use_method: bool
) -> Tuple[TimeouterRunInfo, bool]:
    """
    Launch timeouter for a rule or method that timed out.

    Args:
        project_root: Path to project root
        dashboard_dir: Path to .certora_internal/local_dashboard
        job_url: URL of the original job that timed out
        job_id: Job identifier
        rule_name: Rule name
        method_name: Method name (optional, for parametric rules)
        use_method: If True, pass --method; if False, pass --rule only

    Returns:
        Tuple of (TimeouterRunInfo, was_launched)
        was_launched is True if a new run was started, False if reusing existing

    Raises:
        RuntimeError: If timeouter fails to launch
    """
    run_key = get_run_key(job_id, rule_name, method_name, use_method)

    # Load existing runs
    runs = load_timeouter_runs(dashboard_dir)

    # Check if already running or completed
    if run_key in runs:
        existing_run = runs[run_key]
        logger.log(
            f"Timeouter already {existing_run.status} for {run_key}",
            "INFO",
            "TimeouterManager"
        )
        return existing_run, False

    # Create run info (method_name might be None for full rule runs)
    run_info = TimeouterRunInfo(
        job_url=job_url,
        job_id=job_id,
        rule_name=rule_name,
        method_name=method_name or "",  # Store empty string if None
        status="launching",
        timestamp=int(time.time())
    )

    # Save initial state
    runs[run_key] = run_info
    save_timeouter_runs(runs, dashboard_dir)

    # Create timeouter directory for logs
    timeouter_dir = dashboard_dir / DIR_TIMEOUTER
    timeouter_dir.mkdir(parents=True, exist_ok=True)

    log_file = timeouter_dir / FILE_TIMEOUTER_LOG

    # Build timeouter command
    cmd = ["timeouter", job_url]

    if use_method and method_name:
        # Parametric rule with method - pass both --rule and --method
        cmd.extend(["--rule", rule_name, "--method", method_name])
    else:
        # Non-parametric rule or assertion - pass --rule only
        cmd.extend(["--rule", rule_name])

    cmd.append("--disable_local_typechecking")

    logger.log(
        f"Launching timeouter async: {' '.join(cmd)}",
        "INFO",
        "TimeouterManager"
    )

    # Start timeouter in background thread (non-blocking)
    thread = threading.Thread(
        target=_run_timeouter_async,
        args=(cmd, log_file, run_key, dashboard_dir, project_root, rule_name, method_name, use_method),
        daemon=True  # Thread will be killed when main process exits
    )
    thread.start()

    logger.log(
        f"Timeouter thread started for {run_key}",
        "INFO",
        "TimeouterManager"
    )

    # Return immediately (don't wait for completion)
    return run_info, True
