#!/usr/bin/env python3
"""
Contract Linker - Clean implementation of contract linking logic.

Based on Brain's linking algorithm but implemented as a self-contained module
for the autosetup system. Handles contract dependencies through state variable
type analysis and inheritance resolution.
"""

import json
import subprocess
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set

from .logger import logger
from .types import ContractInfo, ContractKind, ContractHandle


class LinkStatus(Enum):
    """Status of a linking attempt for a state variable."""

    LINKED = "linked"  # Successfully linked (1:1 match)
    AMBIGUOUS = "ambiguous"  # Multiple implementations found
    UNRESOLVED = "unresolved"  # No implementations found
    INTERFACE = "interface"  # Type is an interface (may be intentional)


@dataclass
class LinkingDecision:
    """Represents a linking decision for a specific state variable."""

    contract_name: str  # Contract containing the variable
    variable_name: str  # Name of the state variable
    variable_type: str  # Type of the state variable
    status: LinkStatus  # Linking status
    linked_to: Optional[str] = None  # Contract it was linked to (if successful)
    candidates: List[str] = field(
        default_factory=list
    )  # All potential implementations found
    reason: str = ""  # Explanation of the decision


@dataclass
class LinkingReport:
    """Complete report of all linking decisions and statistics."""

    total_contracts: int  # Total contracts analyzed
    total_state_variables: int  # Total state variables examined
    successful_links: int  # Number of successful links
    ambiguous_links: int  # Number of ambiguous cases
    unresolved_links: int  # Number of unresolved cases
    interface_variables: int  # Number of interface-typed variables

    # Detailed decision tracking
    decisions: List[LinkingDecision] = field(default_factory=list)

    # Additional metadata
    contracts_processed: List[str] = field(default_factory=list)
    timestamp: str = ""

    def add_decision(self, decision: LinkingDecision):
        """Add a linking decision to the report."""
        self.decisions.append(decision)

        # Update counters
        if decision.status == LinkStatus.LINKED:
            self.successful_links += 1
        elif decision.status == LinkStatus.AMBIGUOUS:
            self.ambiguous_links += 1
        elif decision.status == LinkStatus.UNRESOLVED:
            self.unresolved_links += 1
        elif decision.status == LinkStatus.INTERFACE:
            self.interface_variables += 1

    def get_decisions_by_contract(self) -> Dict[str, List[LinkingDecision]]:
        """Group linking decisions by contract."""
        by_contract = {}
        for decision in self.decisions:
            if decision.contract_name not in by_contract:
                by_contract[decision.contract_name] = []
            by_contract[decision.contract_name].append(decision)
        return by_contract

    def generate_markdown_report(self) -> str:
        """Generate a comprehensive markdown report of linking decisions."""
        from datetime import datetime

        if not self.timestamp:
            self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        report = []
        report.append("# Contract Linking Report")
        report.append(f"\n*Generated on {self.timestamp}*\n")

        # Executive Summary
        report.append("## Executive Summary")
        report.append(f"- **Total Contracts Analyzed:** {self.total_contracts}")
        report.append(f"- **Total State Variables:** {self.total_state_variables}")
        report.append(f"- **Successful Links:** {self.successful_links}")
        report.append(f"- **Ambiguous Cases:** {self.ambiguous_links}")
        report.append(f"- **Unresolved Cases:** {self.unresolved_links}")
        report.append(f"- **Interface Variables:** {self.interface_variables}")

        if self.total_state_variables > 0:
            success_rate = (self.successful_links / self.total_state_variables) * 100
            report.append(f"- **Success Rate:** {success_rate:.1f}%")

        # Generated Links Summary
        if self.successful_links > 0:
            report.append("\n## Generated Links")
            report.append("The following links were successfully generated:\n")
            for decision in self.decisions:
                if decision.status == LinkStatus.LINKED:
                    report.append(
                        f"- `{decision.contract_name}:{decision.variable_name}={decision.linked_to}`"
                    )

        # Detailed Analysis by Contract
        report.append("\n## Detailed Analysis by Contract")
        by_contract = self.get_decisions_by_contract()

        for contract_name in sorted(by_contract.keys()):
            decisions = by_contract[contract_name]
            report.append(f"\n### {contract_name}")

            if not decisions:
                report.append("*No user-defined state variables found.*")
                continue

            report.append(f"Found {len(decisions)} user-defined state variables:")
            report.append("")

            for decision in decisions:
                status_emoji = {
                    LinkStatus.LINKED: "✅",
                    LinkStatus.AMBIGUOUS: "⚠️",
                    LinkStatus.UNRESOLVED: "❌",
                    LinkStatus.INTERFACE: "ℹ️",
                }[decision.status]

                report.append(
                    f"#### {status_emoji} `{decision.variable_name}: {decision.variable_type}`"
                )
                report.append("")

                if decision.status == LinkStatus.LINKED:
                    report.append(
                        f"**Status:** Successfully linked to `{decision.linked_to}`"
                    )
                    report.append(
                        f"**Generated Link:** `{decision.contract_name}:{decision.variable_name}={decision.linked_to}`"
                    )

                elif decision.status == LinkStatus.AMBIGUOUS:
                    report.append(
                        "**Status:** Ambiguous - multiple implementations found"
                    )
                    report.append(
                        f"**Candidates:** {', '.join(f'`{c}`' for c in decision.candidates)}"
                    )
                    report.append(
                        "**Action Required:** Manual disambiguation needed. Choose one implementation and add manual linking."
                    )

                elif decision.status == LinkStatus.UNRESOLVED:
                    report.append(
                        "**Status:** Unresolved - no concrete implementations found"
                    )
                    report.append(
                        "**Action Required:** Ensure the implementing contract is included in the analysis or create the implementation."
                    )

                elif decision.status == LinkStatus.INTERFACE:
                    report.append(
                        "**Status:** Interface type - may be intentionally abstract"
                    )
                    if decision.candidates:
                        report.append(
                            f"**Available Implementations:** {', '.join(f'`{c}`' for c in decision.candidates)}"
                        )
                    report.append(
                        "**Note:** Interface variables may not need linking unless a specific implementation is required."
                    )

                if decision.reason:
                    report.append(f"**Details:** {decision.reason}")

                report.append("")

        # Recommendations
        if self.ambiguous_links > 0 or self.unresolved_links > 0:
            report.append("\n## Recommendations")

            if self.ambiguous_links > 0:
                report.append(f"\n### Resolve {self.ambiguous_links} Ambiguous Link(s)")
                report.append("For variables with multiple implementation candidates:")
                report.append(
                    "1. Review the contract logic to determine the intended implementation"
                )
                report.append("2. Add manual link entries to your configuration")
                report.append(
                    "3. Consider refactoring to use more specific types if appropriate"
                )

            if self.unresolved_links > 0:
                report.append(
                    f"\n### Resolve {self.unresolved_links} Unresolved Link(s)"
                )
                report.append("For variables with no implementations found:")
                report.append(
                    "1. Ensure all relevant contracts are included in the source directories"
                )
                report.append(
                    "2. Check that the implementing contracts are properly defined"
                )
                report.append("3. Verify import paths and inheritance relationships")

        if (
            self.successful_links == self.total_state_variables
            and self.total_state_variables > 0
        ):
            report.append("\n## ✅ All Clear!")
            report.append(
                "All user-defined state variables have been successfully linked. No manual intervention required."
            )

        # Appendix
        report.append("\n## Appendix")
        report.append("\n### Contracts Processed")
        for contract in sorted(self.contracts_processed):
            report.append(f"- {contract}")

        return "\n".join(report)

class ContractLinker:
    """
    Handles contract linking for Solidity verification.

    """

    def __init__(self, scope):
        """
        Initialize the contract linker.

        Args:
            scope: Centralized scope for file filtering
        """
        self.project_root = scope.project_root
        self.scope = scope

        # Cache for parsed contracts
        self._source_file_cache: Dict[str, List[ContractInfo]] = {}  # File path -> List of contracts in that file
        self._contracts_cache: Dict[str, ContractInfo] = {}  # Contract name -> ContractInfo
        self._expanded_contracts: Dict[str, ContractInfo] = {}

        # State tracking for incremental linking across iterations
        self._processed_contracts: Set[str] = set()  # Contracts we've already analyzed
        self._linking_decisions: Dict[
            str, LinkingDecision
        ] = {}  # Cache linking decisions

        # Cache remappings to avoid reloading for every file
        self._cached_remappings: Optional[List[str]] = None

    def _get_solc_command_for_file(self, source_file: Path) -> str:
        """
        Determine the appropriate solc command for a specific Solidity file based on its pragma.

        Args:
            source_file: Path to Solidity source file

        Returns:
            solc command to use (e.g., "solc8.26", "solc8.17", or "solc" as fallback)
        """
        from .enhanced_config_manager import ConfigManager

        try:
            # Create a temporary config manager to parse pragma
            config_manager = ConfigManager(self.project_root)
            pragma_spec = config_manager.parse_pragma_solidity(source_file)

            if pragma_spec:
                solc_version = config_manager.resolve_solc_version_for_pragma(
                    pragma_spec
                )
                if solc_version:
                    # Convert "solc-0.8.26" format to "solc8.26" format for command line
                    if solc_version.startswith("solc-"):
                        version_part = solc_version.replace("solc-", "")
                        # Convert "0.8.26" to "8.26" for Certora solc naming
                        if version_part.startswith("0."):
                            version_part = version_part[2:]  # Remove "0."
                        return f"solc{version_part}"
                    return solc_version

            # Fallback to default solc if no pragma found or parsing failed
            logger.debug(f"Using default solc for {source_file}")
            return "solc"

        except Exception as e:
            logger.warning(
                f"Failed to determine solc version for {source_file}: {e}"
            )
            return "solc"

    def _get_foundry_remappings(self) -> List[str]:
        """
        Get foundry remappings by merging remappings.txt and foundry config.

        Applies path corrections for common issues where auto-generated remappings
        may point to incorrect paths that cause import resolution failures.

        Returns:
            List of remapping strings in the format "prefix=path"
        """
        # Return cached remappings if available
        if self._cached_remappings is not None:
            return self._cached_remappings

        remappings = []

        try:
            # First collect remappings from remappings.txt
            remappings_file = self.project_root / "remappings.txt"
            if remappings_file.exists():
                with remappings_file.open("r") as f:
                    file_remappings = [
                        line.strip()
                        for line in f
                        if line.strip() and not line.startswith("#")
                    ]
                remappings.extend(file_remappings)
                logger.debug(
                    f"Loaded {len(file_remappings)} remappings from remappings.txt"
                )

            # Then collect remappings from foundry config using forge command
            foundry_remappings = []
            try:
                import subprocess

                result = subprocess.run(
                    ["forge", "config", "--json"],
                    capture_output=True,
                    text=True,
                    cwd=self.project_root,
                    timeout=10,
                )
                if result.returncode == 0:
                    import json

                    config = json.loads(result.stdout)
                    foundry_remappings = config.get("remappings", [])
                    if foundry_remappings:
                        logger.debug(
                            f"Loaded {len(foundry_remappings)} remappings from forge config"
                        )
            except Exception as e:
                logger.debug(f"Could not get remappings from forge config: {e}")

            # Apply path corrections to foundry remappings before merging
            # Foundry sometimes generates incorrect remappings with trailing /src/ that cause double src/ paths
            corrected_foundry_remappings = []
            for remapping in foundry_remappings:
                corrected_remapping = self._correct_foundry_remapping(remapping)
                corrected_foundry_remappings.append(corrected_remapping)
                if corrected_remapping != remapping:
                    logger.debug(
                        f"Corrected foundry remapping: {remapping} -> {corrected_remapping}"
                    )

            remappings.extend(corrected_foundry_remappings)

            # Remove duplicates while preserving order (file remappings take precedence)
            seen = set()
            unique_remappings = []
            for remapping in remappings:
                if remapping not in seen:
                    seen.add(remapping)
                    unique_remappings.append(remapping)

            logger.debug(f"Total unique remappings: {len(unique_remappings)}")
            # Cache the remappings for future use
            self._cached_remappings = unique_remappings
            return unique_remappings

        except Exception as e:
            logger.warning(f"Failed to get foundry remappings: {e}")
            return []

    def _correct_foundry_remapping(self, remapping: str) -> str:
        """
        Correct foundry remapping paths that may cause double-path issues.

        Detects when a remapping like "prefix/=path/src/" would cause imports like
        "prefix/src/file.sol" to resolve to "path/src/src/file.sol". Uses find command
        to locate the correct library root directory.

        Args:
            remapping: Original remapping string in format "prefix=path"

        Returns:
            Corrected remapping string
        """
        if "=" not in remapping:
            return remapping

        prefix, path = remapping.split("=", 1)
        library_name = prefix.rstrip("/")  # Remove trailing slash if present

        # Check if this remapping might cause double-path issues
        # This happens when the path ends with /src/ and the library name matches a directory
        if path.endswith("/src/"):
            try:
                import subprocess

                # Find the library directory anywhere in the project
                find_result = subprocess.run(
                    ["find", ".", "-name", library_name, "-type", "d"],
                    capture_output=True,
                    text=True,
                    cwd=self.project_root,
                    timeout=5,
                )

                if find_result.returncode == 0 and find_result.stdout.strip():
                    found_paths = find_result.stdout.strip().split("\n")

                    # Use the first found path and check if it's different from current mapping
                    corrected_path = found_paths[0].lstrip("./")  # Remove leading ./

                    # If the found path + "/src/" matches the original path,
                    # the correction should be just the found path
                    if path == f"{corrected_path}/src/":
                        corrected_full_path = self.project_root / corrected_path

                        if corrected_full_path.exists():
                            logger.debug(
                                f"Correcting double-src remapping for {library_name}: {corrected_path}"
                            )
                            return f"{prefix}={corrected_path}/"

            except Exception as e:
                logger.debug(f"Find command failed for {library_name}: {e}")

        # Return original remapping if no correction needed
        return remapping

    def extract_contract_info_from_source(
        self, source_file: Path
    ) -> List[ContractInfo]:
        """
        Extract contract information using solc AST output.

        Uses `solc --ast-compact-json` to get structured AST data for parsing.

        Args:
            source_file: Path to Solidity source file

        Returns:
            List of ContractInfo objects for contracts in the file
        """
        # Check cache first to avoid re-parsing the same file
        cache_key = str(source_file)
        if cache_key in self._source_file_cache:
            logger.debug(f"Using cached contracts for {source_file}")
            return self._source_file_cache[cache_key]

        try:
            contracts = self._parse_with_solc(source_file)
            # Cache the parsed contracts by both file path and contract name
            self._source_file_cache[cache_key] = contracts
            for contract in contracts:
                self._contracts_cache[contract.name] = contract
            return contracts
        except Exception as e:
            logger.error(f"Failed to parse {source_file}: {e}")
            return []

    def _parse_with_solc(self, source_file: Path) -> List[ContractInfo]:
        """
        Parse Solidity file using solc AST output.

        Args:
            source_file: Path to Solidity source file

        Returns:
            List of ContractInfo objects for contracts in the file
        """
        try:
            # Run solc to get AST - run from project root to resolve imports
            # Make source_file path relative to project_root if it's absolute
            if source_file.is_absolute():
                try:
                    relative_source = source_file.relative_to(self.project_root)
                except ValueError:
                    # source_file is not under project_root, use absolute path
                    relative_source = source_file
            else:
                relative_source = source_file

            # Determine the appropriate solc version for this file
            solc_cmd = self._get_solc_command_for_file(source_file)

            # Get remappings for import resolution
            remappings = self._get_foundry_remappings()

            # Build solc command with remappings
            cmd = [solc_cmd, "--ast-compact-json"]
            # Add base path to help solc resolve imports correctly
            cmd.extend(["--base-path", str(self.project_root)])
            # Add remappings
            for remapping in remappings:
                if "=" in remapping:
                    cmd.append(remapping)
            cmd.append(str(relative_source))

            result = subprocess.run(
                cmd, capture_output=True, text=True, cwd=self.project_root
            )

            if result.returncode != 0:
                logger.error(
                    f"{solc_cmd} failed for {source_file}: {result.stderr}"
                )
                return []

            # Parse the JSON output
            contracts = []
            output_lines = result.stdout.strip().split("\n")

            # Find JSON AST sections
            json_started = False
            current_json = ""

            for line in output_lines:
                if line.startswith("======= ") and line.endswith(" ======="):
                    # New file section
                    if json_started and current_json:
                        # Process previous JSON
                        try:
                            ast_data = json.loads(current_json)
                            contracts.extend(
                                self._extract_contracts_from_ast(ast_data, source_file)
                            )
                        except json.JSONDecodeError as e:
                            logger.warning(f"Failed to parse AST JSON: {e}")
                    current_json = ""
                    json_started = True
                elif json_started:
                    current_json += line

            # Process final JSON if exists
            if json_started and current_json:
                try:
                    ast_data = json.loads(current_json)
                    contracts.extend(
                        self._extract_contracts_from_ast(ast_data, source_file)
                    )
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse AST JSON: {e}")

            return contracts

        except FileNotFoundError:
            logger.error("solc not found - please install Solidity compiler")
            return []
        except Exception as e:
            logger.error(f"Failed to parse {source_file} with solc: {e}")
            return []

    def _extract_contracts_from_ast(
        self, ast_data: Dict, source_file: Path
    ) -> List[ContractInfo]:
        """
        Extract contract information from solc AST data.

        Args:
            ast_data: The AST JSON data from solc
            source_file: Path to the source file (fallback if absolutePath not found)

        Returns:
            List of ContractInfo objects
        """
        contracts = []

        # Extract the actual file path from the AST data
        actual_file_path = source_file  # fallback
        if "absolutePath" in ast_data:
            absolute_path_str = ast_data["absolutePath"]
            actual_file_path = self.project_root / absolute_path_str

        # Process all nodes looking for ContractDefinition
        for node in ast_data.get("nodes", []):
            if node.get("nodeType") == "ContractDefinition":
                contract_info = self._parse_contract_node(node, actual_file_path)
                contracts.append(contract_info)

        return contracts

    def _parse_contract_node(
        self, contract_node: Dict, source_file: Path
    ) -> ContractInfo:
        """
        Parse a single contract node from solc AST.

        Args:
            contract_node: The contract AST node
            source_file: Path to the source file

        Returns:
            ContractInfo object
        """
        name = contract_node.get("name", "Unknown")
        kind_str = contract_node.get("contractKind", "contract")

        # Check for abstract modifier - Solidity AST stores this separately
        if kind_str == "contract" and contract_node.get("abstract", False):
            kind_str = "abstract"

        # Convert to ContractKind enum
        try:
            kind = ContractKind(kind_str.upper())
        except ValueError:
            kind = ContractKind.CONTRACT  # fallback

        # Extract inheritance information
        inherits = set()
        for base_contract in contract_node.get("baseContracts", []):
            base_name = base_contract.get("baseName", {})
            if base_name.get("nodeType") == "IdentifierPath":
                parent_name = base_name.get("name")
                if parent_name:
                    inherits.add(parent_name)

        # Extract state variables (user-defined types, non-private)
        state_vars = set()
        for node in contract_node.get("nodes", []):
            if node.get("nodeType") == "VariableDeclaration" and node.get(
                "stateVariable"
            ):
                var_name = node.get("name")
                visibility = node.get("visibility", "internal")

                # Skip private variables
                if visibility == "private":
                    continue

                # Skip constant variables - they are compile-time constants that don't need linking
                if node.get("constant", False):
                    continue

                # Extract type information
                type_info = self._extract_type_from_node(node.get("typeName", {}))
                if type_info and self._is_user_defined_type_node(
                    node.get("typeName", {})
                ):
                    state_vars.add((var_name, type_info))

        return ContractInfo(
            name=name,
            kind=kind,
            source_file=source_file,
            inherits_from=list(inherits),
            state_vars=state_vars,
        )

    def _extract_type_from_node(self, type_node: Dict) -> Optional[str]:
        """
        Extract type name from a type node.

        Args:
            type_node: The typeName AST node

        Returns:
            Type name string or None
        """
        node_type = type_node.get("nodeType")

        if node_type == "UserDefinedTypeName":
            # Handle IdentifierPath
            path_node = type_node.get("pathNode", {})
            if path_node.get("nodeType") == "IdentifierPath":
                return path_node.get("name")
            # Handle direct name
            return type_node.get("name")

        return None

    def _is_user_defined_type_node(self, type_node: Dict) -> bool:
        """
        Check if a type node represents a user-defined type.

        Args:
            type_node: The typeName AST node

        Returns:
            True if it's a user-defined type
        """
        return type_node.get("nodeType") == "UserDefinedTypeName"

    def expand_inheritance(
        self, contracts: Dict[str, ContractInfo]
    ) -> Dict[str, ContractInfo]:
        """
        Expand inheritance relationships by flattening the hierarchy.

        This merges all inherited state variables and inheritance relationships
        into each contract, similar to Brain's expand_inherited_contracts.

        Args:
            contracts: Dictionary of contract name to ContractInfo

        Returns:
            Dictionary of expanded contracts
        """
        expanded = {}
        expansion_cache = {}

        def expand_contract(contract_name: str) -> ContractInfo:
            if contract_name in expansion_cache:
                return expansion_cache[contract_name]

            if contract_name not in contracts:
                # Create a stub for missing contracts
                stub = ContractInfo(
                    name=contract_name,
                    source_file=Path("unknown"),
                    kind=ContractKind.UNKNOWN,
                    state_vars=set(),
                    inherits_from=[],
                )
                expansion_cache[contract_name] = stub
                return stub

            contract = contracts[contract_name]

            # Create a copy to avoid modifying the original
            expanded_contract = ContractInfo(
                name=contract.name,
                kind=contract.kind,
                source_file=contract.source_file,
                inherits_from=contract.inherits_from.copy(),
                is_compilable=contract.is_compilable,
                compilation_error=contract.compilation_error,
                solidity_version=contract.solidity_version,
                artifact_path=contract.artifact_path,
                bytecode=contract.bytecode,
                function_signatures=contract.function_signatures.copy() if contract.function_signatures else {},
                compilation_metadata=contract.compilation_metadata,
                state_vars=contract.state_vars.copy() if contract.state_vars else set(),
            )

            # Recursively expand parent contracts
            for parent_name in contract.inherits_from:
                parent_expanded = expand_contract(parent_name)

                # Merge parent's state variables
                if parent_expanded.state_vars:
                    if expanded_contract.state_vars is None:
                        expanded_contract.state_vars = set()
                    expanded_contract.state_vars.update(parent_expanded.state_vars)

                # Merge parent's inheritance relationships
                expanded_contract.inherits_from.extend(parent_expanded.inherits_from)

            expansion_cache[contract_name] = expanded_contract
            return expanded_contract

        # Expand all contracts
        for contract_name in contracts:
            expanded[contract_name] = expand_contract(contract_name)

        self._expanded_contracts = expanded
        return expanded

    def generate_links(
        self,
        contracts: Dict[str, ContractInfo],
        target_contracts: Optional[Set[str]] = None,
    ) -> List[str]:
        """
        Generate contract links with caching for incremental processing.

        Args:
            contracts: Dictionary of expanded contracts
            target_contracts: Set of contract names to generate links for.
                            If None, generates for all contracts.

        Returns:
            List of generated links
        """
        if target_contracts is None:
            target_contracts = set(contracts.keys())

        # Split into new contracts (need analysis) and already processed contracts (use cache)
        new_contracts = target_contracts - self._processed_contracts
        already_processed = target_contracts & self._processed_contracts

        logger.debug(
            f"Incremental linking: {len(new_contracts)} new contracts, {len(already_processed)} already processed"
        )

        # Initialize report for this iteration
        report = LinkingReport(
            total_contracts=len(target_contracts),
            total_state_variables=0,
            successful_links=0,
            ambiguous_links=0,
            unresolved_links=0,
            interface_variables=0,
            contracts_processed=list(target_contracts),
        )

        links = []

        # First, add cached decisions from already processed contracts
        for contract_name in already_processed:
            if contract_name not in contracts:
                continue
            contract = contracts[contract_name]

            for var_name, type_name in (contract.state_vars or []):
                cache_key = f"{contract_name}:{var_name}"
                if cache_key in self._linking_decisions:
                    cached_decision = self._linking_decisions[cache_key]
                    report.add_decision(cached_decision)

                    # Add link if it was successful
                    if cached_decision.status == LinkStatus.LINKED:
                        link = f"{contract_name}:{var_name}={cached_decision.linked_to}"
                        if link not in links:
                            links.append(link)

        # Now process new contracts that haven't been analyzed yet
        for contract_name in new_contracts:
            if contract_name not in contracts:
                logger.warning(f"Contract {contract_name} not found for linking")
                continue

            contract = contracts[contract_name]

            # If state_vars is None or empty (loaded from JSON), extract it from source
            if contract.state_vars is None or not contract.state_vars:
                logger.debug(f"Contract {contract_name} has no state_vars, extracting from source: {contract.source_file}")
                try:
                    parsed_contracts = self.extract_contract_info_from_source(contract.source_file)
                    for parsed_contract in parsed_contracts:
                        if parsed_contract.name == contract_name:
                            contract.state_vars = parsed_contract.state_vars
                            if contract.state_vars:
                                logger.debug(f"Extracted {len(contract.state_vars)} state variables for {contract_name}: {contract.state_vars}")
                            break
                    else:
                        logger.warning(f"Could not find {contract_name} in parsed source {contract.source_file}")
                        contract.state_vars = set()
                except Exception as e:
                    logger.error(f"Failed to extract state vars for {contract_name}: {e}")
                    contract.state_vars = set()

            logger.debug(f"Processing contract {contract_name}, state_vars: {contract.state_vars}")

            for var_name, type_name in (contract.state_vars or []):
                report.total_state_variables += 1

                # Find concrete contracts that match this type
                matching_contracts = []
                interface_contracts = []

                for candidate in contracts.values():
                    # Match if the candidate's name matches the type OR
                    # if the candidate inherits from the type
                    if type_name == candidate.name or type_name in candidate.inherits_from:
                        if candidate.kind == ContractKind.CONTRACT:
                            matching_contracts.append(candidate)
                        elif candidate.kind == ContractKind.INTERFACE:
                            interface_contracts.append(candidate)

                # Determine linking status and create decision
                decision = None

                if len(matching_contracts) == 1:
                    # Unambiguous match - create link
                    impl_contract = matching_contracts[0]
                    link = f"{contract_name}:{var_name}={impl_contract.name}"
                    links.append(link)

                    decision = LinkingDecision(
                        contract_name=contract_name,
                        variable_name=var_name,
                        variable_type=type_name,
                        status=LinkStatus.LINKED,
                        linked_to=impl_contract.name,
                        candidates=[c.name for c in matching_contracts],
                        reason=f"Found single concrete implementation: {impl_contract.name}",
                    )
                    logger.info(
                        f"Successfully linked {contract_name}:{var_name} (type: {type_name}) to {impl_contract.name}"
                    )

                elif len(matching_contracts) == 0:
                    # Check if it's an interface type
                    if interface_contracts:
                        decision = LinkingDecision(
                            contract_name=contract_name,
                            variable_name=var_name,
                            variable_type=type_name,
                            status=LinkStatus.INTERFACE,
                            candidates=[c.name for c in interface_contracts],
                            reason=f"Type {type_name} is an interface with no concrete implementations found",
                        )
                    else:
                        decision = LinkingDecision(
                            contract_name=contract_name,
                            variable_name=var_name,
                            variable_type=type_name,
                            status=LinkStatus.UNRESOLVED,
                            reason=f"No concrete implementations or interfaces found for type {type_name}",
                        )

                    logger.debug(
                        f"No implementation found for {contract_name}:{var_name} (type: {type_name})"
                    )

                else:
                    # Ambiguous - multiple matches
                    impl_names = [c.name for c in matching_contracts]

                    decision = LinkingDecision(
                        contract_name=contract_name,
                        variable_name=var_name,
                        variable_type=type_name,
                        status=LinkStatus.AMBIGUOUS,
                        candidates=impl_names,
                        reason=f"Found {len(matching_contracts)} concrete implementations: {', '.join(impl_names)}",
                    )

                    logger.info(
                        f"Ambiguous link for {contract_name}:{var_name} (type: {type_name}). "
                        f"Found {len(matching_contracts)} implementations: {impl_names}. Skipping."
                    )

                if decision:
                    # Cache the decision for future iterations
                    cache_key = f"{contract_name}:{var_name}"
                    self._linking_decisions[cache_key] = decision
                    report.add_decision(decision)

        # Update processed contracts set
        self._processed_contracts.update(new_contracts)

        return links

    def generate_and_write_report(self, contract_name: str, report_file_path: Path) -> Optional[str]:
        """
        Generate comprehensive linking report and write it to file.

        Args:
            contract_name: Name of contract being processed (for logging)
            report_file_path: Path where to write the report file

        Returns:
            Path to the generated report file as string, or None if no linking was performed
        """
        report = self.generate_report()
        if not report:
            logger.debug("No linking decisions made, skipping report generation")
            return None

        try:
            # Generate markdown content
            markdown_content = report.generate_markdown_report()
            
            # Ensure parent directory exists
            report_file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write report to file
            with report_file_path.open("w") as f:
                f.write(markdown_content)
            
            logger.info(f"Generated final linking report for {contract_name}: {report_file_path}")
            return str(report_file_path)
            
        except Exception as e:
            logger.warning(f"Failed to generate final linking report: {e}")
            return None

    def generate_report(self) -> Optional[LinkingReport]:
        """
        Generate comprehensive linking report from all accumulated decisions.

        Returns:
            LinkingReport with all decisions made across all iterations, or None if no linking was performed
        """
        if not self._linking_decisions:
            return None

        # Create comprehensive report from cached decisions
        report = LinkingReport(
            total_contracts=len(self._processed_contracts),
            total_state_variables=len(self._linking_decisions),
            successful_links=0,
            ambiguous_links=0,
            unresolved_links=0,
            interface_variables=0,
            contracts_processed=list(self._processed_contracts),
        )

        # Add all cached decisions
        for decision in self._linking_decisions.values():
            report.add_decision(decision)

        return report

    def get_linked_contracts(self, links: List[str]) -> Set[str]:
        """
        Extract the set of contracts referenced in links.

        Args:
            links: List of link strings

        Returns:
            Set of contract names that are linked to
        """
        linked_contracts = set()
        for link in links:
            if "=" in link:
                implementation = link.split("=")[1]
                linked_contracts.add(implementation)
        return linked_contracts

    def get_additional_source_files(self, links: List[str]) -> List[ContractHandle]:
        """
        Get additional source files needed based on the links.

        Args:
            links: List of link strings

        Returns:
            List of ContractHandle objects for linked contracts
        """
        linked_contract_names = self.get_linked_contracts(links)
        contract_handles = []
        seen_files = set()

        # Get source files for linked contracts from both caches
        all_contracts = {**self._contracts_cache, **self._expanded_contracts}

        for contract_name in linked_contract_names:
            if contract_name in all_contracts:
                contract = all_contracts[contract_name]
                if (
                    contract.source_file not in seen_files
                    and contract.source_file.exists()
                ):
                    # Normalize path to relative (relative to project root)
                    try:
                        if contract.source_file.is_absolute():
                            rel_path = contract.source_file.relative_to(self.project_root)
                        else:
                            rel_path = contract.source_file
                        source_file_str = str(rel_path)
                    except ValueError:
                        # Path is outside project root, use absolute path
                        source_file_str = str(contract.source_file)

                    # Create ContractHandle with both name and source file
                    handle = ContractHandle(
                        contract_name=contract_name,
                        source_file=source_file_str
                    )
                    contract_handles.append(handle)
                    seen_files.add(contract.source_file)

        return contract_handles
