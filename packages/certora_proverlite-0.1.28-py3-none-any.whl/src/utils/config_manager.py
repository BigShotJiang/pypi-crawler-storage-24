# A bare-bones version of Jaroslav's config manager


def convert_solc_version_to_certora_format(version: str) -> str:
    """
    Convert solc version from standard format to Certora format.

    Args:
        version: Version in standard format (e.g., "0.8.19")

    Returns:
        Version in Certora format (e.g., "solc8.19")
    """
    # Remove any leading 'v' if present
    version_str = version.lstrip("v")

    # Convert "0.8.19" to "solc8.19"
    if version_str.startswith("0."):
        # Remove the '0.' prefix and add 'solc' prefix
        return f"solc{version_str[2:]}"
    else:
        # If it doesn't start with '0.', just add 'solc' prefix
        return f"solc{version_str}"