#!/usr/bin/env python3
"""
LocalProverRunner - Local Certora prover execution using direct certoraRun commands.

Executes prover jobs locally using `certoraRun <conf_file.conf>` with
caching and resume support.
"""

import asyncio
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from .enhanced_config_manager import ConfigManager, ProverJobSpec
from .prover_runner import EarlyTerminationCallback, ProverRunner, ResultTransformer
from .runner_types import JobHandle, JobStatus, ProverResult, RunnerType, SubmissionResult
from .logger import log_with_contract


class LocalProverRunner(ProverRunner):
    """
    Local prover runner using direct certoraRun execution.

    Executes prover jobs locally with:
    - Direct `certoraRun.py <conf_file.conf>` execution
    - Content-based caching for resume support
    - Process management and timeout handling
    """

    def __init__(
        self,
        project_root: Path,
        config_manager: ConfigManager,
        certora_run_path: str = "certoraRun.py",
        disable_cache: bool = False,
    ):
        """
        Initialize local prover runner.

        Args:
            project_root: Root directory of the project
            config_manager: Configuration manager for dependency tracking
            certora_run_path: Path to certoraRun executable (default: "certoraRun.py")
            disable_cache: If True, disable caching (useful for tests)
        """
        super().__init__(project_root, config_manager, use_local_api=True)
        self.component = "LocalRunner"
        self.certora_run_path = certora_run_path
        self.disable_cache = disable_cache

    async def get_runner_type(self) -> RunnerType:
        """Get the type of this runner."""
        return RunnerType.LOCAL

    async def check_with_prover(self, job_spec: ProverJobSpec) -> ProverResult:
        """
        Execute prover locally with automatic resume support and caching.

        Args:
            job_spec: Complete job specification

        Returns:
            ProverResult with job status and results
        """
        # Use existing cache key functionality from config_manager
        cache_key = self._get_cache_key(job_spec)

        log_with_contract(
            self.component, "info", job_spec.contract_name,
            f"Local prover request for {job_spec.phase} (cache_key: {cache_key[:16]}...)"
        )

        # Step 1: Check cache for completed results (unless disabled)
        if not self.disable_cache:
            cached_result = await self._check_cache(cache_key, job_spec)
            if cached_result:
                self.log(
                    f"Using cached result for {job_spec.contract_name}:{job_spec.phase}"
                )
                return cached_result

        # Step 2: Execute local prover run
        log_with_contract(self.component, "debug", job_spec.contract_name, f"Executing local prover for {job_spec.phase}")
        result = await self._execute_local_prover(job_spec, cache_key)

        # Step 3: Cache successful results (unless disabled)
        if result.success and not self.disable_cache:
            await self._cache_result(cache_key, result)

        return result

    async def _execute_local_prover(self, job_spec: ProverJobSpec, cache_key: str) -> ProverResult:
        """Execute local certoraRun command."""
        # Create job handle for result tracking (job_id will be set to emv-* folder path after execution)
        job_handle = JobHandle(
            job_id="",  # Will be updated with emv-* folder path after execution
            config_file=str(job_spec.config_file.path),
            config_content_hash=cache_key,
            phase=job_spec.phase,
            submitted_at=time.time(),
            runner_type=RunnerType.LOCAL,
            status=JobStatus.RUNNING,
        )

        start_time = time.time()

        try:
            # Build certoraRun command
            cmd = [self.certora_run_path, str(job_spec.config_file.path)]

            # Append extra_args if present
            if job_spec.extra_args:
                cmd.extend(job_spec.extra_args)

            # Append msg if present
            if job_spec.msg:
                cmd.extend(["--msg", job_spec.msg])

            self.log(f"Executing: {' '.join(cmd)}")

            # Execute command with timeout
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.project_root,
            )

            timeout: int = 3600
            # Wait for completion with timeout
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                # Kill the process on timeout
                process.kill()
                await process.wait()

                duration = time.time() - start_time
                self.log(f"Local prover timed out after {duration:.1f}s", "ERROR")

                job_handle.status = JobStatus.FAILED
                return ProverResult(
                    job_handle=job_handle,
                    success=False,
                    report_path=None,
                    output_data={},
                    job_spec=job_spec,
                    error_message=f"Prover execution timed out after {timeout} seconds",
                    duration=duration,
                    transformed_result=None,
                )

            duration = time.time() - start_time
            return_code = process.returncode or -1

            # Parse output and determine success
            stdout_str = stdout.decode("utf-8") if stdout else ""
            stderr_str = stderr.decode("utf-8") if stderr else ""

            # Parse output to extract emv-* folder path and use ProverOutputUtility
            emv_folder_path, output_data = self._parse_successful_output(stdout_str, stderr_str)

            # Update job_handle with emv-* folder path as job_id for ProverOutputUtility
            if emv_folder_path:
                job_handle.job_id = emv_folder_path
                # Extract unresolved calls using ProverOutputUtility for consistency with cloud runner
                output_data["unresolved_calls"] = self.extract_unresolved_calls(emv_folder_path)

            report_path = output_data.get("report_path")

            # Don't rely solely on return code as warnings can cause non-zero exit codes
            prover_success = self._check_prover_success(
                return_code, stdout_str, stderr_str, report_path
            )

            if prover_success:
                job_handle.status = JobStatus.COMPLETED
                emv_path_msg = f" (emv folder: {emv_folder_path})" if emv_folder_path else ""
                log_with_contract(
                    self.component, "info", job_spec.contract_name,
                    f"Local prover completed successfully in {duration:.1f}s{emv_path_msg}"
                )

                return ProverResult(
                    job_handle=job_handle,
                    success=True,
                    report_path=report_path,
                    output_data=output_data,
                    job_spec=job_spec,
                    duration=duration,
                    transformed_result=None,
                )
            else:
                # Failure - extract error message
                error_msg = self._extract_error_message(stdout_str, stderr_str, return_code)

                job_handle.status = JobStatus.FAILED
                self.log(f"Local prover failed after {duration:.1f}s: {error_msg}", "ERROR")

                return ProverResult(
                    job_handle=job_handle,
                    success=False,
                    report_path=report_path,  # Include report path even on failure (might have partial results)
                    output_data={
                        "stdout": stdout_str,
                        "stderr": stderr_str,
                        "return_code": return_code,
                    },
                    job_spec=job_spec,
                    error_message=error_msg,
                    duration=duration,
                    transformed_result=None,
                )

        except Exception as e:
            duration = time.time() - start_time
            error_msg = f"Local prover execution failed: {str(e)}"

            job_handle.status = JobStatus.FAILED
            self.log(error_msg)

            return ProverResult(
                job_handle=job_handle,
                success=False,
                report_path=None,
                output_data={},
                job_spec=job_spec,
                error_message=error_msg,
                duration=duration,
                transformed_result=None,
            )

    def _check_prover_success(
        self, return_code: int, stdout: str, stderr: str, report_path: Optional[str]
    ) -> bool:
        """
        Check if prover execution was successful using Brain's classification logic.

        Based on Brain's classification: timeouts and unknown results are NOT failures.
        Only genuine fatal errors are considered failures.

        Args:
            return_code: Process return code
            stdout: Standard output from prover
            stderr: Standard error from prover
            report_path: Path to JSON report file if found

        Returns:
            True if prover execution was successful (including timeouts/unknown results)
        """
        output = stdout + stderr

        # First check for JSON report existence - most reliable indicator
        if report_path:
            report_file = Path(report_path)
            if not report_file.is_absolute():
                report_file = self.project_root / report_path

            if report_file.exists():
                self.log(
                    f"Found JSON report at {report_file}, considering execution successful"
                )
                return True

        # Return code 0 is always success
        if return_code == 0:
            return True

        # Look for "Reports in" pattern which indicates successful report generation
        if "Reports in" in output:
            return True

        # Memory partitioning warnings are not failures
        if "Memory partitioning failed" in output and "Warning:" in output:
            return True

        # Timeouts are NOT failures (Brain's approach)
        timeout_patterns = [
            "Reached global timeout. Hard stopping.",
        ]
        if any(pattern in output for pattern in timeout_patterns):
            return True  # Timeout is successful execution, just incomplete
        if "TIMEOUT" in output and "|Timeout" in output:
            return True

        # Unknown results are NOT failures
        if "all events were sent without errors" in output:
            return True

        # Only these patterns indicate genuine failures
        fatal_error_patterns = [
            "has no bytecode.",
            "ERROR FUNCTION_BUILDER",
            "java.lang.OutOfMemoryError",
            "no candidate functions to instantiate parametric rule",
            "compilation failed",
            "syntax error",
            "file not found",
            "permission denied",
        ]

        for pattern in fatal_error_patterns:
            if pattern in output:
                return False

        # For everything else with non-zero return code, check if it's just warnings
        # If we don't see fatal errors, consider it successful
        return True

    def _parse_successful_output(
        self, stdout: str, stderr: str
    ) -> tuple[Optional[str], Dict[str, Any]]:
        """Parse successful prover output to extract emv-* folder path for ProverOutputUtility."""
        emv_folder_path = None
        output_data: Dict[str, Any] = {}

        # Look for Certora output patterns in stdout to find emv-* folder
        for line in stdout.split("\n"):
            line = line.strip()

            # Look for "Reports in file:///path/to/emv-X-certora-date--time/Reports"
            if line.startswith("Reports in file://"):
                import re

                # Extract the directory path from file:// URL
                path_match = re.search(r"file://([^/].*/emv-[^/]+)", line)
                if path_match:
                    emv_folder_path = path_match.group(1)

                    # Set report_path for compatibility
                    reports_dir = Path(emv_folder_path) / "Reports"
                    output_json = reports_dir / "output.json"
                    if output_json.exists():
                        output_data["report_path"] = str(output_json)

            # Also look for "Final report in emv-X-certora-date--time/Reports/FinalResults.html"
            elif line.startswith("Final report in ") and "emv-" in line:
                import re

                # Extract the path relative to project root
                path_match = re.search(r"Final report in ([^/]*emv-[^/]+)/Reports/", line)
                if path_match:
                    relative_output_dir = path_match.group(1)
                    emv_folder_path = str(self.project_root / relative_output_dir)

                    # Set report_path for compatibility
                    reports_dir = Path(emv_folder_path) / "Reports"
                    output_json = reports_dir / "output.json"
                    if output_json.exists():
                        output_data["report_path"] = str(output_json)

            # Look for verification results summary
            if "verified" in line.lower() or "failed" in line.lower():
                if "verification_summary" not in output_data:
                    output_data["verification_summary"] = []
                output_data["verification_summary"].append(line)

        # Store raw output for debugging
        output_data["stdout"] = stdout
        output_data["raw_stdout"] = stdout
        if stderr:
            output_data["stderr"] = stderr

        return emv_folder_path, output_data

    def _extract_error_message(self, stdout: str, stderr: str, return_code: int) -> str:
        """Extract meaningful error message from failed execution."""
        # Try to find specific error messages in stderr first
        if stderr:
            error_lines = []
            for line in stderr.split("\n"):
                line = line.strip()
                if line and (
                    "error" in line.lower()
                    or "failed" in line.lower()
                    or "exception" in line.lower()
                ):
                    error_lines.append(line)

            if error_lines:
                return "; ".join(error_lines[:3])  # Take first 3 error lines

        # Try stdout for error messages
        if stdout:
            error_lines = []
            for line in stdout.split("\n"):
                line = line.strip()
                if line and ("error" in line.lower() or "failed" in line.lower()):
                    error_lines.append(line)

            if error_lines:
                return "; ".join(error_lines[:3])

        # Fallback to generic error with return code
        return f"Local prover failed with return code {return_code}"

    async def cleanup_completed_jobs(self) -> None:
        """Clean up tracking data for completed jobs (no-op for local runner)."""
        # Local runner doesn't maintain persistent job tracking
        # All cleanup happens automatically after execution
        self.log("Local runner cleanup completed (no persistent jobs)")
        pass

    async def submit_jobs(
        self, job_specs: List[ProverJobSpec], pre_execute_callback=None
    ) -> List[SubmissionResult]:
        """Submit multiple jobs (not supported for local runner)."""
        raise NotImplementedError("LocalProverRunner does not support submit_jobs - use check_with_prover instead")

    async def submit_and_wait_for_jobs_with_transformer(
        self,
        job_specs: List[ProverJobSpec],
        completion_callback=None,
        pre_execute_callback=None,
        early_termination_callback: Optional[EarlyTerminationCallback] = None,
        result_transformer: Optional[ResultTransformer] = None,
    ) -> List[ProverResult]:
        """Submit and wait for jobs with transformer (not supported for local runner)."""
        raise NotImplementedError(
            "LocalProverRunner does not support submit_and_wait_for_jobs_with_transformer - use check_with_prover instead"
        )
