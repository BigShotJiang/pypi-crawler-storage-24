#!/usr/bin/env python3
"""
Replay an LLM analysis call from a debug dump.

Usage:
    python src/utils/replay_llm.py path/to/.certora_internal/llm_input_dumps/XXXX.in.json

Reads an .in.json file produced by the LLM debug dumper and replays
the exact same call, printing output to stdout.

Prerequisites:
    - The 'analyzer' package must be installed
    - The report folder referenced in args.folder must still exist on disk
"""

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Optional

# Ensure the PreAudit project root is on sys.path so we can import from src/
_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent.parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from analyzer.analysis import analyze_with_calltraces  # type: ignore[import-not-found]
from pydantic import BaseModel

from src.generic_checkers.reporting.analyzer import IterationResult
from src.utils.rag_config import get_default_rag_db


Ecosystem = Literal["evm", "soroban", "move", "solana"]

# Map from serialized output_type name to the actual class
OUTPUT_TYPE_REGISTRY: dict[str, type[BaseModel]] = {
    "IterationResult": IterationResult,
}


@dataclass
class ReplayArgs:
    """Minimal AnalysisArgs implementation for replay."""

    folder: str
    rule: str
    method: Optional[str] = None
    quiet: bool = True
    recursion_limit: int = 30
    thread_id: Optional[str] = None
    checkpoint_id: Optional[str] = None
    thinking_tokens: int = 2048
    tokens: int = 4096
    ecosystem: Ecosystem = "evm"
    rag_db: str = ""  # Resolved at construction time; empty means use get_default_rag_db()

    def __post_init__(self):
        if not self.rag_db:
            self.rag_db = get_default_rag_db()


def main():
    parser = argparse.ArgumentParser(description="Replay an LLM analysis call from a .in.json debug dump")
    parser.add_argument("input_file", help="Path to the .in.json file to replay")
    parser.add_argument("--rag-db", help="RAG database path (ChromaDB dir) or PostgreSQL connection string")
    cli_args = parser.parse_args()

    input_path = Path(cli_args.input_file)
    if not input_path.exists():
        print(f"ERROR: File not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    if not input_path.name.endswith(".in.json"):
        print(f"WARNING: File does not end with .in.json: {input_path}", file=sys.stderr)

    with open(input_path) as f:
        dump = json.load(f)

    args_dict = dump["args"]

    # Validate the report folder exists
    folder = args_dict["folder"]
    if not Path(folder).exists():
        print(f"ERROR: Report folder does not exist: {folder}", file=sys.stderr)
        print("The report folder must still exist on disk to replay the call.", file=sys.stderr)
        sys.exit(1)

    replay_args = ReplayArgs(
        folder=folder,
        rule=args_dict["rule"],
        method=args_dict.get("method"),
        quiet=args_dict.get("quiet", True),
        recursion_limit=args_dict.get("recursion_limit", 30),
        thread_id=args_dict.get("thread_id"),
        checkpoint_id=args_dict.get("checkpoint_id"),
        thinking_tokens=args_dict.get("thinking_tokens", 2048),
        tokens=args_dict.get("tokens", 4096),
        ecosystem=args_dict.get("ecosystem", "evm"),
        rag_db=cli_args.rag_db if cli_args.rag_db else args_dict.get("rag_db", get_default_rag_db()),
    )

    function_name = dump["function"]
    input_messages = dump["input_messages"]
    initial_prompt = dump["initial_prompt"]

    print(f"Replaying {function_name} for rule '{replay_args.rule}'", file=sys.stderr)
    print(f"  folder: {replay_args.folder}", file=sys.stderr)
    print(f"  ecosystem: {replay_args.ecosystem}", file=sys.stderr)
    print(f"  recursion_limit: {replay_args.recursion_limit}", file=sys.stderr)

    if function_name not in ("analyze_with_calltraces", "validation_pass"):
        print(f"ERROR: Unknown function: {function_name}", file=sys.stderr)
        sys.exit(1)

    if input_messages is None or initial_prompt is None:
        print("ERROR: input_messages and initial_prompt are required", file=sys.stderr)
        sys.exit(1)

    # Resolve output_type if present (used by validation_pass dumps)
    output_type_name = dump.get("output_type")
    output_type = None
    if output_type_name is not None:
        output_type = OUTPUT_TYPE_REGISTRY.get(output_type_name)
        if output_type is None:
            print(f"ERROR: Unknown output_type: {output_type_name}", file=sys.stderr)
            print(f"  Known types: {list(OUTPUT_TYPE_REGISTRY.keys())}", file=sys.stderr)
            sys.exit(1)
        print(f"  output_type: {output_type_name}", file=sys.stderr)

    # Track token usage across all LLM calls
    token_usage: dict[str, int] = {}

    # Call AIComposer directly — output goes to stdout
    if output_type is not None:
        result = analyze_with_calltraces(input_messages, initial_prompt, replay_args, output_type, token_usage)
        print(result.model_dump_json(indent=2))
    else:
        result = analyze_with_calltraces(input_messages, initial_prompt, replay_args, token_usage=token_usage)
        print(result)

    # Print token usage summary
    if token_usage:
        print("\n--- Token Usage Summary ---", file=sys.stderr)
        print(f"  Input tokens: {token_usage.get('input_tokens', 0)}", file=sys.stderr)
        print(f"  Output tokens: {token_usage.get('output_tokens', 0)}", file=sys.stderr)
        print(f"  Cache read: {token_usage.get('cache_read_input_tokens', 0)}", file=sys.stderr)
        print(f"  Cache write: {token_usage.get('cache_creation_input_tokens', 0)}", file=sys.stderr)


if __name__ == "__main__":
    main()
