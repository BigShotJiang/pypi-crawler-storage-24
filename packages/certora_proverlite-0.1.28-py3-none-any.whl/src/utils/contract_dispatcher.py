#!/usr/bin/env python3
"""
Contract Dispatcher - Custom dispatching implementation with prover invocation caps.

This module implements dispatching logic that reuses existing infrastructure:
- Uses CloudJobManager for prover execution (no direct prover calls)
- Implements prover invocation caps at the dispatcher level
- Parses prover outputs using similar approach to Brain's reports_parser
- Integrates with existing state management and resume functionality
"""

import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from functools import wraps
from pathlib import Path
from typing import Any, Dict, List, Optional

# Setup path for local modules
current_dir = Path(__file__).parent
preaudit_root = current_dir.parent
sys.path.insert(0, str(preaudit_root))

from src.utils.enhanced_config_manager import ConfigManager, FileContent, ProverJobSpec
from src.utils.logger import logger
from src.utils.prover_runner import ProverRunner
from src.utils.runner_types import ProverResult
from src.utils.types import ContractHandle, FunctionSignature
from src.utils.scope import Scope
from src.setup.signature_types import extract_sighash_from_callee
from prover_output_utility.models import CallResolutionInfo  # type: ignore


class DispatchingStatus(Enum):
    """Status of dispatching process."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    CONVERGED = "converged"
    LIMIT_REACHED = "limit_reached"
    FAILED = "failed"


@dataclass
class DispatchingResult:
    """Result from a single dispatching step."""

    unresolved_calls_before: int
    signatures_added: int
    converged: bool
    success: bool
    error_message: Optional[str] = None


@dataclass
class UnresolvedCall:
    """Represents an unresolved function call found in prover output."""

    caller: str  # Contract and function making the call
    call_site: str  # Code snippet where call occurs
    callee: str  # Unresolved function being called
    sighash: Optional[str] = None  # 4-byte function selector
    signature: Optional[str] = None  # Function signature if known
    source_location: Optional[str] = None  # File and line number

    def __post_init__(self):
        """Extract or compute sighash from callee."""
        if self.sighash is None:
            extracted_sighash = extract_sighash_from_callee(self.callee)
            if extracted_sighash:
                self.sighash = extracted_sighash
                # If we got sighash from function signature extraction, also store the signature
                if "]." in self.callee and "[sighash=" not in self.callee:
                    self.signature = self.callee.split("].", 1)[1]



@dataclass
class DispatchingIteration:
    """Results from a single dispatching iteration."""

    iteration: int
    unresolved_calls_before: int
    unresolved_calls_after: int
    signatures_added: List[str]
    new_dispatcher_entries: List[str]
    prover_runtime: float
    success: bool
    error_message: Optional[str] = None


@dataclass
class DispatchingReport:
    """Comprehensive report of the dispatching process."""

    contract_name: str
    total_iterations: int
    total_prover_invocations: int
    final_status: DispatchingStatus

    # Statistics
    initial_unresolved_calls: int = 0
    final_unresolved_calls: int = 0
    total_signatures_added: int = 0
    total_runtime: float = 0.0

    # Detailed tracking
    iterations: List[DispatchingIteration] = field(default_factory=list)
    unresolved_calls: List[CallResolutionInfo] = field(default_factory=list)
    signature_database: Dict[str, FunctionSignature] = field(default_factory=dict)

    # Files created
    dispatcher_spec_file: Optional[Path] = None
    updated_config_file: Optional[Path] = None

    def add_iteration(self, iteration: DispatchingIteration):
        """Add an iteration to the report."""
        self.iterations.append(iteration)
        self.total_signatures_added += len(iteration.signatures_added)
        self.total_runtime += iteration.prover_runtime

    @property
    def success_rate(self) -> float:
        """Calculate the success rate of call resolution."""
        if self.initial_unresolved_calls == 0:
            return 100.0
        resolved = self.initial_unresolved_calls - self.final_unresolved_calls
        return (resolved / self.initial_unresolved_calls) * 100.0


    def generate_markdown_report(self, scope) -> str:
        """Generate a comprehensive markdown report."""
        logger.debug("Generating markdown report using scope signature database")
        lines = []
        lines.append(f"# Dispatching Report: {self.contract_name}")
        lines.append(f"\n*Generated on {time.strftime('%Y-%m-%d %H:%M:%S')}*\n")

        # Executive Summary
        lines.append("## Executive Summary")
        lines.append(f"- **Final Status:** {self.final_status.value}")
        lines.append(f"- **Total Iterations:** {self.total_iterations}")
        lines.append(f"- **Prover Invocations:** {self.total_prover_invocations}")
        lines.append(f"- **Success Rate:** {self.success_rate:.1f}%")
        lines.append(f"- **Total Runtime:** {self.total_runtime:.1f}s")
        lines.append(f"- **Signatures Added:** {self.total_signatures_added}")

        # Status indicator
        if self.final_status == DispatchingStatus.CONVERGED:
            lines.append("- **Result:** ✅ Converged successfully")
        elif self.final_status == DispatchingStatus.LIMIT_REACHED:
            lines.append("- **Result:** 🚫 Analysis stopped due to hitting iteration limits")
        else:
            lines.append("- **Result:** ❌ Failed")

        # Iteration Details
        if self.iterations:
            lines.append("\n## Iteration Details")
            lines.append(
                "| Iteration | Unresolved Before | Unresolved After | Signatures Added | Runtime |"
            )
            lines.append(
                "|-----------|-------------------|------------------|------------------|---------|"
            )

            for iter_data in self.iterations:
                lines.append(
                    f"| {iter_data.iteration} | {iter_data.unresolved_calls_before} | "
                    f"{iter_data.unresolved_calls_after} | {len(iter_data.signatures_added)} | "
                    f"{iter_data.prover_runtime:.1f}s |"
                )

        # Remaining Unresolved Calls
        if self.unresolved_calls:
            lines.append(
                f"\n## Remaining Unresolved Calls ({len(self.unresolved_calls)})"
            )
            for call in self.unresolved_calls:
                lines.append(f"\n### `{call.callee_name}`")
                lines.append(f"- **Caller:** {call.caller_name}")
                lines.append(f"- **Call Site:** `{call.call_site_snippet}`")
                # Extract sighash from this specific call
                call_sighash = extract_sighash_from_callee(
                    call.callee_name
                )
                if call_sighash:
                    lines.append(f"- **Sighash:** `{call_sighash}`")
                if call.source_location:
                    lines.append(f"- **Location:** {call.source_location}")

        # Files Created
        lines.append("\n## Generated Files")
        if self.dispatcher_spec_file:
            lines.append(f"- **Dispatcher Spec:** `{self.dispatcher_spec_file}`")
        if self.updated_config_file:
            lines.append(f"- **Updated Config:** `{self.updated_config_file}`")

        # Signature Database (all signatures available)
        all_signatures = scope.signature_database.get_all_signatures()
        if all_signatures:
            lines.append(
                f"\n## Available Signatures ({len(all_signatures)} total)"
            )
            lines.append(
                "Function signatures available in the signature database:\n"
            )

            for sighash, func_sig in sorted(all_signatures.items()):
                lines.append(f"### `{func_sig.signature}` → `{sighash}`")

                # Get implementing contracts from scope
                implementing_contracts = scope.get_implementing_contracts_by_selector(
                    sighash
                )
                if implementing_contracts:
                    lines.append(
                        f"- **Implementing Contracts:** {', '.join(implementing_contracts)}"
                    )

                    # Get source files
                    source_files = scope.get_source_files_for_contracts(
                        implementing_contracts
                    )
                    if source_files:
                        lines.append(
                            f"- **Source Files:** {', '.join(str(f) for f in source_files)}"
                        )

                lines.append(
                    f"- **Dispatcher Entry:** `{ContractDispatcher._generate_dispatcher_entry(func_sig)}`"
                )
                if func_sig.is_view:
                    lines.append("- **Type:** View function")
                elif func_sig.is_pure:
                    lines.append("- **Type:** Pure function")
                lines.append("")

        # Recommendations
        lines.append("\n## Recommendations")
        if self.final_status == DispatchingStatus.CONVERGED:
            if (not self.unresolved_calls) or len(self.unresolved_calls) == 0:
                lines.append(
                    "✅ Dispatching completed successfully with all calls resolved. "
                    "No further action needed."
                )
            else:
                lines.append(f"⚠️ Call resolution converged with {len(self.unresolved_calls)} remaining unresolved calls. Consider manual calls resolution.")

        elif self.final_status == DispatchingStatus.LIMIT_REACHED:
            lines.append("⚠️ Hit number of iterations limit. Consider:")
            lines.append("1. Increasing the iteration cap if needed")
            lines.append("2. Manual review of remaining unresolved calls")
            lines.append("3. Adding manual summaries for complex functions")
        else:
            lines.append("❌ Dispatching failed. Recommended actions:")
            lines.append("1. Check prover configuration and permissions")
            lines.append("2. Verify contract compilation succeeds")
            lines.append("3. Review error logs for specific issues")

        return "\n".join(lines)


def store_dispatching_result(func):
    """Decorator to automatically store _last_dispatching_result on function exit."""
    @wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            result = await func(self, *args, **kwargs)
            self._last_dispatching_result = result
            return result
        except Exception as e:
            # Even on exception, store a failed result
            failed_result = DispatchingResult(
                unresolved_calls_before=0,
                signatures_added=0,
                converged=False,
                success=False,
                error_message=str(e),
            )
            self._last_dispatching_result = failed_result
            raise  # Re-raise the original exception
    return wrapper


class ContractDispatcher:
    """
    Custom dispatching implementation with prover invocation caps.

    This class implements the dispatching algorithm while using existing infrastructure:
    - ProverRunner for prover execution
    - ConfigManager for management of .conf files
    - Scope, including SignatureDatabase for defining the search space
    - Prover invocation caps implemented at dispatcher level
    """

    def __init__(
        self,
        scope: Scope,
        prover_runner: ProverRunner,
        config_manager: ConfigManager,
        extra_args: List[str],
    ):
        """
        Initialize contract dispatcher.

        Args:
            scope: Scope defining project boundaries and file filtering
            prover_runner: Prover runner for execution (local or cloud)
            config_manager: Configuration manager for dependency tracking
            extra_args: Extra arguments to pass to certoraRun
        """
        self.scope = scope
        self.prover_runner = prover_runner
        self.config_manager = config_manager
        self.extra_args = extra_args

        self.current_iteration = 0
        self.total_prover_invocations = 0

        # Caching for dispatcher resolution
        self.failed_sighashes: set = set()  # Track sighashes we've failed to resolve
        self.resolved_sighashes: Dict[
            str, FunctionSignature
        ] = {}  # Cache successful resolutions

        # Track current state for reporting
        self._last_unresolved_calls: List[CallResolutionInfo] = []
        self._last_dispatching_result: Optional[DispatchingResult] = None
        self._initial_unresolved_calls: List[
            CallResolutionInfo
        ] = []  # Calls at start of iteration
        self._total_runtime: float = 0.0
        self._contract_file_mapping: Dict[
            str, str
        ] = {}  # contract_name -> source_file_path


    @staticmethod
    def _generate_dispatcher_entry(signature: FunctionSignature) -> str:
        """Generate dispatcher entry for CVL spec file using appropriate signature."""
        # Use dispatcher_entry_name if available (for contract-qualified user-defined types)
        # Otherwise fall back to canonical signature
        if signature.dispatcher_entry_name:
            dispatcher_signature = signature.dispatcher_entry_name
        else:
            # Fallback to canonical signature for backward compatibility
            dispatcher_signature = signature.signature

        return f"function _.{dispatcher_signature} external => DISPATCHER(true);"

    async def _run_prover_and_parse_calls(
        self, config_file: Path, contract_name: str
    ) -> List[CallResolutionInfo]:
        """
        Run prover via CloudJobManager and parse unresolved calls from output.

        This method uses the shared CloudJobManager instead of directly invoking the prover,
        which allows for proper caching, resume logic, and centralized prover management.
        """
        self.total_prover_invocations += 1
        logger.debug(f"[{contract_name}] Prover invocation {self.total_prover_invocations}")

        # Create job spec for dispatching phase
        config_content = FileContent.from_file(config_file)
        job_spec = ProverJobSpec(
            contract_name=contract_name, phase="dispatching", config_file=config_content, extra_args=self.extra_args
        )

        # Use CloudJobManager to execute prover
        prover_result = await self.prover_runner.check_with_prover(job_spec)

        if not prover_result.success:
            logger.error(f"Prover execution failed: {prover_result.error_message}")
            return []

        # Parse unresolved calls from prover output
        return self._parse_unresolved_calls_from_prover_result(prover_result)

    def _parse_unresolved_calls_from_prover_result(
        self, prover_result: ProverResult
    ) -> List[CallResolutionInfo]:
        """
        Parse unresolved calls from prover result.

        This method extracts unresolved calls from the prover output data that
        was already parsed by the ProverRunner.
        """
        unresolved_calls = []

        try:
            # Get CallResolutionInfo objects directly from prover result
            output_data = prover_result.output_data

            # TODO: make this extraction a part of ProverAPI
            if "unresolved_calls" in output_data:
                raw_calls = output_data["unresolved_calls"]

                # Convert to CallResolutionInfo objects if they're raw dicts
                for call_data in raw_calls:
                    if isinstance(call_data, dict):
                        try:
                            # Create CallResolutionInfo with proper key mapping
                            call_info = CallResolutionInfo(
                                callee_name=call_data.get(
                                    "callee_name", call_data.get("callee", "")
                                ),
                                caller_name=call_data.get(
                                    "caller_name", call_data.get("caller", "")
                                ),
                                call_site_snippet=call_data.get(
                                    "call_site_snippet", ""
                                ),
                                source_location=call_data.get("source_location", ""),
                                summary=call_data.get("summary", ""),
                                is_warning=call_data.get("is_warning", False),
                                callee_resolution=call_data.get(
                                    "callee_resolution", ""
                                ),
                                resolved_callees=call_data.get("resolved_callees"),
                                havoc_cause=call_data.get("havoc_cause"),
                                havoc_scope=call_data.get("havoc_scope"),
                                summary_application_reason=call_data.get(
                                    "summary_application_reason"
                                ),
                                raw_resolution_group=call_data.get(
                                    "raw_resolution_group", {}
                                ),
                            )
                            unresolved_calls.append(call_info)
                        except Exception as e:
                            logger.warning(
                                f"Failed to create CallResolutionInfo from dict: {e}"
                            )
                            logger.debug(f"Call data: {call_data}")
                    elif hasattr(call_data, "callee_name"):
                        # Already a CallResolutionInfo object
                        unresolved_calls.append(call_data)
                    else:
                        logger.warning(
                            f"Unknown call data format: {type(call_data)}"
                        )
            else:
                logger.warning(
                    "No unresolved calls data available from prover result"
                )

            logger.info(f"Found {len(unresolved_calls)} unresolved calls")

        except Exception as e:
            logger.error(f"Failed to parse unresolved calls: {e}")

        return unresolved_calls

    def _resolve_signature_with_canonical_and_noncanonical_lookup(self, sighash: str) -> tuple[Optional[FunctionSignature], List[str]]:
        """
        Helper method to resolve a signature using both canonical and non-canonical lookups.

        A function can have both canonical signatures (using basic types like uint256)
        and non-canonical signatures (using custom types), which result in different sighashes.
        This method tries both approaches and returns the union of results when
        both exist.
        TODO: Using union might be wrong and should be checked. It's on the
        sound side though; we might revisit this if we see prover issues in a
        customer project.

        TODO: The optimal solution might be to use always canonical signatures in the signature database.

        Args:
            sighash: The function selector to resolve

        Returns:
            Tuple of (signature_info, implementing_contracts) or (None, []) if not found
        """
        signature_info = None
        implementing_contracts = []

        # Try canonical selector first (standard approach)
        canonical_implementing_contracts = self.scope.get_implementing_contracts_by_selector(sighash)
        if canonical_implementing_contracts:
            signature_info = self.scope.signature_database.get_signature(sighash)
            if signature_info:
                implementing_contracts.extend(canonical_implementing_contracts)

        # Try non-canonical (internal type) selector lookup
        noncanonical_signature_info = self.scope.signature_database.get_signature_by_internal_selector(sighash)
        if noncanonical_signature_info:
            # Get implementing contracts for the canonical selector of the non-canonical signature
            noncanonical_implementing_contracts = self.scope.get_implementing_contracts_by_selector(
                noncanonical_signature_info.selector
            )

            if noncanonical_implementing_contracts:
                # Take union of results when both canonical and non-canonical signatures exist
                if signature_info:
                    # Both exist - take union of implementing contracts
                    implementing_contracts.extend(noncanonical_implementing_contracts)
                    implementing_contracts = list(set(implementing_contracts))  # Remove duplicates
                else:
                    # Only non-canonical found
                    signature_info = noncanonical_signature_info
                    implementing_contracts = noncanonical_implementing_contracts

        return signature_info, implementing_contracts

    def _resolve_calls_to_signatures(
        self, unresolved_calls: List[CallResolutionInfo]
    ) -> Dict[str, FunctionSignature]:
        """Resolve unresolved calls to function signatures with caching."""
        resolved = {}
        attempted_to_fix_count = 0
        new_failures = 0
        cached_successes = 0
        cached_failures = 0

        all_signatures = self.scope.signature_database.get_all_signatures()
        logger.debug(f"Scope signature database has {len(all_signatures)} entries")

        for call in unresolved_calls:
            # Extract sighash from callee_name (CallResolutionInfo doesn't have sighash field)
            sighash = extract_sighash_from_callee(call.callee_name)
            logger.debug(
                f"Processing call: caller={call.caller_name}, callee={call.callee_name}, sighash={sighash}, location={call.source_location}"
            )
            if sighash:
                # Check cache first
                if sighash in self.resolved_sighashes:
                    # Previously resolved successfully
                    signature = self.resolved_sighashes[sighash]
                    if sighash not in resolved:
                        resolved[sighash] = signature
                        logger.debug(
                            f"🔄 Using cached resolution for {sighash}: {signature.signature}"
                        )
                    attempted_to_fix_count += 1
                    cached_successes += 1
                elif sighash in self.failed_sighashes:
                    # Previously failed to resolve - skip silently
                    cached_failures += 1
                else:
                    # New sighash - attempt resolution using scope's signature database
                    signature_info, implementing_contracts = self._resolve_signature_with_canonical_and_noncanonical_lookup(sighash)

                    if signature_info and implementing_contracts:
                        # Cache successful resolution
                        self.resolved_sighashes[sighash] = signature_info
                        if sighash not in resolved:
                            resolved[sighash] = signature_info
                            logger.info(
                                f"✅ Found signature for {sighash}: {signature_info.signature} (implemented by: {', '.join(implementing_contracts[:3])}{'+' + str(len(implementing_contracts) - 3) + ' more' if len(implementing_contracts) > 3 else ''})"
                            )
                        attempted_to_fix_count += 1
                    else:
                        # Cache failure
                        self.failed_sighashes.add(sighash)
                        logger.warning(
                            f"❌ Sighash {sighash} (call: {call.callee_name}) not found in signature database"
                        )
                        new_failures += 1
            else:
                logger.warning(
                    f"❌ No sighash extracted for call: {call.callee_name}"
                )

        if attempted_to_fix_count > 0:
            logger.info(
                f"Attempted to fix {attempted_to_fix_count} calls using {len(resolved)} unique signatures"
            )
        if cached_failures > 0:
            logger.debug(f"Skipped {cached_failures} previously failed calls")
        return resolved

    @store_dispatching_result
    async def detectAndFixUnresolvedCallsStep(
        self,
        config_file: Path,
        spec_file: Path,
        contract_name: str,
        iteration: int
    ) -> DispatchingResult:
        """
        Execute one complete step of unresolved call detection and fixing:
        1. Run verification to detect unresolved calls
        2. Add dispatcher entries for resolvable calls
        3. Run re-verification to check progress
        4. Return convergence status

        Args:
            config_file: Path to config file
            spec_file: Path to spec file to update
            contract_name: Name of contract being processed
            iteration: Current iteration number

        Returns:
            DispatchingStepResult with convergence information
        """
        try:
            # Track iteration and start timing
            self.current_iteration = iteration
            step_start_time = time.time()

            # Signature database is now available through self.scope.signature_database
            # No initialization check needed

            # Step 1: Run verification to detect unresolved calls
            unresolved_calls = await self._run_prover_and_parse_calls(
                config_file, contract_name
            )
            unresolved_calls_before = len(unresolved_calls)

            # Store initial unresolved calls for reporting
            self._initial_unresolved_calls = unresolved_calls.copy()

            if unresolved_calls_before == 0:
                # Already converged
                return DispatchingResult(
                    unresolved_calls_before=0,
                    signatures_added=0,
                    converged=True,
                    success=True,
                )

            # Step 2: Add dispatcher entries for resolvable calls
            resolved_signatures = self._resolve_calls_to_signatures(unresolved_calls)
            signatures_added = await self.add_dispatcher_entries_to_spec_and_conf_files(
                spec_file, resolved_signatures, config_file
            )

            if signatures_added > 0:
                logger.info(f"Added {signatures_added} dispatcher entries - continuing iteration")
            else:
                logger.info("No dispatcher entries added - converged")

            # Store the current unresolved calls for reporting (from initial verification)
            self._last_unresolved_calls = unresolved_calls

            # Determine convergence: we converge when no dispatcher entries are added
            converged = signatures_added == 0

            # Track runtime for this step
            step_runtime = time.time() - step_start_time
            self._total_runtime += step_runtime

            return DispatchingResult(
                unresolved_calls_before=unresolved_calls_before,
                signatures_added=signatures_added,
                converged=converged,
                success=True,
            )

        except Exception as e:
            logger.error(f"Dispatching step failed: {e}")
            return DispatchingResult(
                unresolved_calls_before=0,
                signatures_added=0,
                converged=False,
                success=False,
                error_message=str(e),
            )

    async def add_dispatcher_entries_to_spec_and_conf_files(
        self,
        spec_file: Path,
        signatures: Dict[str, FunctionSignature],
        config_file: Path,
    ) -> int:
        """
        Add dispatcher entries to the methods block of an existing spec file
        and add corresponding contract files to the config file.

        Args:
            spec_file: Path to the spec file to update
            signatures: Dictionary of function signatures to add
            config_file: Path to the config file to update with contract files

        Returns:
            Number of signatures actually added (excluding duplicates)
        """
        try:
            if not spec_file.exists():
                logger.error(f"Spec file not found: {spec_file}")
                return 0

            content = spec_file.read_text()
            lines = content.split("\n")

            # Find or create methods block
            methods_start = -1
            methods_end = -1
            brace_count = 0
            in_methods = False

            for i, line in enumerate(lines):
                stripped = line.strip()
                if stripped.startswith("methods") and "{" in stripped:
                    methods_start = i
                    in_methods = True
                    brace_count = stripped.count("{") - stripped.count("}")
                elif in_methods:
                    brace_count += stripped.count("{") - stripped.count("}")
                    if brace_count == 0:
                        methods_end = i
                        break

            # Collect existing dispatcher entries to avoid duplicates
            existing_entries = set()
            if methods_start != -1 and methods_end != -1:
                for i in range(methods_start + 1, methods_end):
                    line = lines[i].strip()
                    if line and not line.startswith("//"):
                        existing_entries.add(line.rstrip(";"))

            # Generate new dispatcher entries
            new_entries = []
            for signature in signatures.values():
                entry = self._generate_dispatcher_entry(signature).rstrip(";")
                if entry not in existing_entries:
                    new_entries.append(f"    {entry};")

            if not new_entries:
                logger.debug(f"No new dispatcher entries to add to {spec_file}")
                return 0

            # Update the spec file
            if methods_start == -1:
                # No methods block exists, create one
                lines.extend(["", "methods {", *new_entries, "}"])
            else:
                # Insert new entries before the closing brace
                for entry in reversed(new_entries):
                    lines.insert(methods_end, entry)

            # Write updated content
            spec_file.write_text("\n".join(lines))

            # Log the actual dispatcher entries that were added
            if len(new_entries) == 1:
                entry_text = new_entries[0].strip()
                logger.info(
                    f"Added dispatcher entry to {spec_file.name}: {entry_text}"
                )
            else:
                logger.info(
                    f"Added {len(new_entries)} dispatcher entries to {spec_file.name}:"
                )
                for entry in new_entries:
                    logger.info(f"  {entry.strip()}")

            # Also add contract files to config if we added dispatcher entries
            if new_entries and signatures:
                contract_files = self._get_contract_files_for_signatures(signatures)
                if contract_files:
                    # Add contract files to config (pass empty links since we only want to add files)
                    self.config_manager.add_files_and_links_to_config(
                        config_file, [], contract_files
                    )

            return len(new_entries)

        except Exception as e:
            logger.error(
                f"Error adding dispatcher entries to spec file {spec_file}: {e}"
            )
            return 0

    def get_cached_dispatching_results(
        self, contract_state, iteration: int
    ) -> Optional[Dict[str, Any]]:
        """Get cached dispatching results for resume capability."""
        if (
            hasattr(contract_state, "dispatching_reports")
            and iteration in contract_state.dispatching_reports
        ):
            cached = contract_state.dispatching_reports[iteration]
            logger.info(
                f"Using cached dispatching results for iteration {iteration}"
            )
            return cached
        return None


    def generate_and_write_report(
        self,
        contract_name: str,
        report_file_path: Path,
        spec_file: Optional[Path] = None,
        limit_reached: bool = False
    ) -> Optional[str]:
        """
        Generate comprehensive dispatching report and write it to file.

        Args:
            contract_name: Name of contract that was processed
            report_file_path: Path where to write the report file
            spec_file: Path to the spec file that was updated

        Returns:
            Path to the generated report file as string, or None if generation failed
        """
        try:
            # Generate report object
            report = self.generate_report(contract_name, spec_file, limit_reached)

            # Generate markdown content
            markdown_content = report.generate_markdown_report(self.scope)

            # Ensure parent directory exists
            report_file_path.parent.mkdir(parents=True, exist_ok=True)

            # Write report to file
            with report_file_path.open("w") as f:
                f.write(markdown_content)

            logger.info(f"Generated final dispatching report for {contract_name}: {report_file_path}")
            return str(report_file_path)

        except Exception as e:
            logger.warning(f"Failed to generate final dispatching report: {e}")
            return None

    def generate_report(
        self, contract_name: str, spec_file: Optional[Path] = None, limit_reached: bool = False
    ) -> DispatchingReport:
        """
        Generate comprehensive dispatching report from accumulated data across all iterations.

        Args:
            contract_name: Name of contract that was processed
            spec_file: Path to the spec file that was updated

        Returns:
            DispatchingReport with comprehensive data
        """
        report = DispatchingReport(
            contract_name=contract_name,
            total_iterations=self.current_iteration,
            total_prover_invocations=self.total_prover_invocations,
            final_status=self._determine_final_status(limit_reached),
            total_signatures_added=len(self.resolved_sighashes),
            total_runtime=self._total_runtime,
            final_unresolved_calls=len(self._last_unresolved_calls),
            unresolved_calls=self._last_unresolved_calls.copy(),
            signature_database=self.resolved_sighashes.copy(),
            dispatcher_spec_file=spec_file,
        )

        return report

    def _determine_final_status(self, limit_reached: bool) -> DispatchingStatus:
        """Determine the final dispatching status based on results and external limits."""
        # If no result, it's failed
        if not self._last_dispatching_result:
            return DispatchingStatus.FAILED

        # If explicitly not successful, it's failed
        if not self._last_dispatching_result.success:
            return DispatchingStatus.FAILED

        # Check if caller indicated we hit limits (max iterations, etc.)
        if limit_reached:
            return DispatchingStatus.LIMIT_REACHED

        # If converged successfully, it's converged
        if self._last_dispatching_result.converged:
            return DispatchingStatus.CONVERGED

        # Default fallback
        return DispatchingStatus.FAILED

    def set_contract_file_mapping(self, contract_file_mapping: Dict[str, str]) -> None:
        """
        Set the mapping of contract names to source file paths.

        Args:
            contract_file_mapping: Dictionary mapping contract names to source file paths
        """
        self._contract_file_mapping = contract_file_mapping.copy()

    def _get_contract_files_for_signatures(
        self, signatures: Dict[str, FunctionSignature]
    ) -> List[ContractHandle]:
        """
        Get the contract handles for the given function signatures using the signature database.

        Args:
            signatures: Dictionary of function signatures from dispatcher

        Returns:
            List of ContractHandle objects (contract_name + source_file) for contracts that implement these methods
        """
        contract_handles_dict = {}  # Use dict to avoid duplicates: key = (source_file, contract_name)

        # Use scope's signature database to find contracts containing the dispatched methods
        logger.debug(
            f"Looking for {len(signatures)} dispatched methods using scope's signature database"
        )

        for sig in signatures.values():
            logger.debug(
                f"Searching for method {getattr(sig, 'signature', 'unknown')} in signature database"
            )

            # Get verifiable contracts that implement this signature (excludes abstract contracts)
            if hasattr(sig, "signature") and hasattr(sig, "selector"):
                implementing_contracts = (
                    self.scope.signature_database.get_verifiable_implementing_contracts(
                        sig.selector
                    )
                )
                if implementing_contracts:
                    # For each implementing contract, create a ContractHandle with both name and source file
                    for contract_name in implementing_contracts:
                        source_file = self.scope.signature_database.get_source_file_for_contract(
                            contract_name
                        )
                        if source_file:
                            # Make relative to project root
                            try:
                                rel_path = source_file.relative_to(self.scope.project_root)
                                source_file_str = str(rel_path)
                            except ValueError:
                                source_file_str = str(source_file)

                            # Create ContractHandle and add to dict to avoid duplicates
                            handle_key = (source_file_str, contract_name)
                            if handle_key not in contract_handles_dict:
                                contract_handle = ContractHandle(
                                    contract_name=contract_name,
                                    source_file=source_file_str
                                )
                                contract_handles_dict[handle_key] = contract_handle
                                logger.debug(
                                    f"Added {contract_handle.to_config_str()} for method {sig.signature}"
                                )

        return list(contract_handles_dict.values())

    def _find_contract_source_path(self, source_file: str) -> Optional[str]:
        """
        Find the full source path for a contract file using scope filter.

        Args:
            source_file: Source file name like "PremiumERC20.sol"

        Returns:
            Full path like "src/tokens/PremiumERC20.sol" or None if not found
        """
        try:
            scoped_file = self.scope.find_scoped_file(source_file)
            if scoped_file:
                return self.scope.get_relative_path(scoped_file)
        except Exception as e:
            logger.debug(f"Could not find source path for {source_file}: {e}")

        return None
