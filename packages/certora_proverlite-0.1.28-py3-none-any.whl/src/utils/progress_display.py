"""
Progress display for PreAudit's signal collection phase.

Shows a tqdm progress bar with active job count, elapsed time,
and time-budget-based progress percentage.
"""

import sys
import threading
import time
from typing import Callable

from tqdm import tqdm


class CollectingSignalsProgress:
    """tqdm-based progress display during orchestrator execution.

    Display (two lines):
        Collecting signals:  12%|████████████████░░░░░░░░░░░░░░░░|
          5 active, 3 done | elapsed 18:30 / budget 450:00

    Progress is based on elapsed time vs a total time budget.
    Once the orchestrator finishes, progress jumps to 100%.
    """

    REFRESH_INTERVAL = 0.5  # seconds

    def __init__(
        self,
        time_budget_seconds: float,
        get_active_count: Callable[[], int],
        get_completed_count: Callable[[], int],
    ):
        self._time_budget = time_budget_seconds
        self._get_active = get_active_count
        self._get_completed = get_completed_count
        self._start_time = 0.0
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._finished = False
        self._bar: tqdm | None = None  # type: ignore[type-arg]
        self._stats: tqdm | None = None  # type: ignore[type-arg]

    def start(self) -> None:
        """Start the progress display in a background thread."""
        self._start_time = time.time()
        self._stop_event.clear()
        self._finished = False
        self._bar = tqdm(
            total=100,
            desc="Collecting signals",
            bar_format="{desc}: {percentage:3.0f}%|{bar}|",
            position=1,
            leave=False,
            file=sys.stderr,
        )
        self._stats = tqdm(
            total=0,
            bar_format="  {desc}",
            position=0,
            leave=False,
            file=sys.stderr,
        )
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self, show_100: bool = True) -> None:
        """Stop the progress display. Optionally show 100% completion line."""
        if self._finished:
            return
        self._finished = True
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        if self._bar:
            self._bar.close()
        if self._stats:
            self._stats.close()
        if show_100:
            elapsed = time.time() - self._start_time
            completed = self._get_completed()
            sys.stderr.write(f"Collecting signals: 100% | {completed} runs completed | elapsed {self._format_time(elapsed)}\n")
            sys.stderr.flush()

    def _run(self) -> None:
        """Background thread: update the display periodically."""
        while not self._stop_event.is_set():
            self._render()
            self._stop_event.wait(self.REFRESH_INTERVAL)

    def _render(self) -> None:
        """Render one frame of the progress display."""
        elapsed = time.time() - self._start_time
        pct = min(99, int(100 * elapsed / self._time_budget)) if self._time_budget > 0 else 0
        active = self._get_active()
        completed = self._get_completed()

        if self._bar:
            self._bar.n = pct
            self._bar.refresh()
        if self._stats:
            self._stats.set_description_str(
                f"{active} active, {completed} done | elapsed {self._format_time(elapsed)} / budget {self._format_time(self._time_budget)}"
            )
            self._stats.refresh()

    @staticmethod
    def _format_time(seconds: float) -> str:
        """Format seconds as MM:SS."""
        m, s = divmod(int(seconds), 60)
        return f"{m}:{s:02d}"
