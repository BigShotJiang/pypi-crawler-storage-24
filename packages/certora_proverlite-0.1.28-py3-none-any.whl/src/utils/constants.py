"""Canonical environment variable names and paths used across PreAudit."""

# This is the default env var name used by Anthropic's SDKs (Python, TypeScript, etc.)
ANTHROPIC_API_KEY_ENV = "ANTHROPIC_API_KEY"

CERTORA_REPORTS_DIR = ".CertoraProverLiteReports"
