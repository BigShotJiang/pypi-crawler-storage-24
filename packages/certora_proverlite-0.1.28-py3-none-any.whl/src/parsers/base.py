#!/usr/bin/env python3
"""
Abstract base class for contract extractors.

This module provides the ContractExtractor ABC that extracts common logic from
build-system-specific contract extraction implementations (Foundry, Hardhat).

Leverages BuildSystemManager and BuildSystemConfig for build system details,
requiring only build-system-specific artifact parsing logic.
"""

import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional

from src.setup.solidity_utils import find_all_solidity_files
from src.utils import logger
from src.utils.types import ContractHandle


class ContractExtractor(ABC):
    """
    Abstract base class for extracting contract information from build artifacts.

    Leverages BuildSystemManager and BuildSystemConfig for build system details.
    Concrete extractors only need to implement build-system-specific artifact parsing.
    """

    def __init__(self, project_root: Path, manager_class, profile: Optional[str] = None):
        """
        Initialize contract extractor.

        Args:
            project_root: Root directory of the project
            manager_class: BuildSystemManager class (FoundryManager or HardhatManager)
            profile: Build system profile to use (e.g. Foundry profile name)
        """
        self.project_root = project_root
        self.profile = profile

        # Create minimal scope for manager
        class MinimalScope:
            def is_file_in_scope(self, file_path):
                return True

        self.manager = manager_class(project_root, MinimalScope())

    def log(self, message: str, level: str = "INFO"):
        """Log message using component name from manager."""
        logger.log(message, level, self.manager.component)

    @abstractmethod
    def extract_logic_contracts_impl(self, artifacts_dir: Path) -> Dict[str, List[str]]:
        """
        Build-system-specific implementation of contract extraction.

        Reads artifact JSON files and returns which contracts have bytecode.

        Args:
            artifacts_dir: Path to artifacts directory

        Returns:
            Dict mapping source file basename to list of contract names
        """
        pass

    def extract_logic_contracts(self) -> Dict[str, List[str]]:
        """Extract logic contracts from build artifacts with config fallback."""
        # Get default artifact directory from manager
        default_artifact_dir = self.project_root / self.manager.get_default_artifact_dir()

        artifacts_dir = default_artifact_dir

        # Config file fallback: use manager's auto_detect_config()
        if not artifacts_dir.exists():
            artifacts_dir = self._try_read_artifact_dir_from_config()
            if not artifacts_dir or not artifacts_dir.exists():
                raise Exception(
                    f"{self.manager.component} artifacts directory '{artifacts_dir}' does not exist. "
                    f"Please run '{self.manager.get_build_command(profile=self.profile)}' first."
                )

        if not artifacts_dir.is_dir():
            raise Exception(f"'{artifacts_dir}' exists but is not a directory")

        # Delegate to build-system-specific implementation
        return self.extract_logic_contracts_impl(artifacts_dir)

    def _try_read_artifact_dir_from_config(self) -> Optional[Path]:
        """
        Try to read artifact directory from config using manager's auto_detect_config().

        Returns artifact directory Path or None if reading failed.
        """
        try:
            # Use manager's auto_detect_config() which handles finding and parsing config
            config = self.manager.auto_detect_config(profile=self.profile)

            # Use BuildSystemConfig's get_artifact_directory() method
            artifact_dir_str = config.get_artifact_directory()

            if artifact_dir_str:
                artifact_dir = Path(artifact_dir_str)
                self.log(f"Using artifact directory from config: {artifact_dir}")
                return self.project_root / artifact_dir

        except Exception as e:
            self.log(f"Failed to read artifact directory from config: {e}", "WARNING")

        return None

    def extract_logic_contracts_and_files(
        self,
        ambiguous_files: List[ContractHandle] = [],
        auto_resolve_ambiguous: bool = False
    ) -> List[ContractHandle]:
        """Extract logic contracts and match to source files with ambiguous resolution."""
        # Get logic contracts
        logic_contracts = self.extract_logic_contracts()

        if not logic_contracts:
            raise Exception(
                f"No logic contracts found in {self.manager.component} build output"
            )

        self.log(
            f"Found {len(logic_contracts)} files with logic contracts from {self.manager.component}: "
            f"{', '.join([x for x in logic_contracts])}"
        )

        # Build ambiguous_map
        ambiguous_map = {}
        if ambiguous_files:
            for handle in ambiguous_files:
                file_basename = Path(handle.source_file).stem
                if file_basename in ambiguous_map:
                    raise Exception(
                        f"File '{file_basename}' specified multiple times in ambiguous_files"
                    )
                ambiguous_map[file_basename] = handle.contract_name

        # Get all Solidity files
        all_solidity_files = find_all_solidity_files(
            include_test_files=False,
            include_dependencies=False,
            verbose=False
        )
        all_solidity_files = sorted(all_solidity_files)

        # Match contracts to files with ambiguous resolution
        contract_handles = []
        raise_ambiguous = False

        for sol_file in all_solidity_files:
            basename = Path(sol_file).stem

            if basename in logic_contracts:
                relative_path = os.path.relpath(sol_file, self.project_root)
                contract_names = logic_contracts[basename]

                if len(contract_names) > 1:
                    # Ambiguous - multiple contracts in file
                    if basename in ambiguous_map:
                        # Explicit resolution
                        selected_contract = ambiguous_map[basename]
                        if selected_contract in contract_names:
                            self.log(
                                f"Resolved ambiguous file {relative_path} to contract {selected_contract}"
                            )
                            contract_handles.append(ContractHandle(
                                contract_name=selected_contract,
                                source_file=relative_path
                            ))
                        else:
                            self.log(
                                f"Specified contract {selected_contract} not found in {relative_path}. "
                                f"Available: {', '.join(contract_names)}",
                                "WARNING"
                            )
                            raise_ambiguous = True

                    elif auto_resolve_ambiguous:
                        # Auto-resolve by filename matching
                        if basename in contract_names:
                            other_contracts = [c for c in contract_names if c != basename]
                            self.log(
                                f"Auto-resolved ambiguous file {relative_path}: selected contract '{basename}' "
                                f"(matches filename). Other contracts in file: {', '.join(other_contracts)}"
                            )
                            contract_handles.append(ContractHandle(
                                contract_name=basename,
                                source_file=relative_path
                            ))
                        else:
                            self.log(
                                f"Cannot auto-resolve ambiguous file {relative_path}: no contract matches filename. "
                                f"Available contracts: {', '.join(contract_names)}. "
                                f"Please specify via --ambiguous-files flag.",
                                "WARNING"
                            )
                            raise_ambiguous = True
                    else:
                        # No resolution - error
                        self.log(
                            f"Multiple contracts found in file {relative_path}: {', '.join(contract_names)} - "
                            f"Please specify via --ambiguous-files flag.",
                            "WARNING"
                        )
                        raise_ambiguous = True
                    continue

                # Single contract - no ambiguity
                contract_handles.append(ContractHandle(
                    contract_name=contract_names[0],
                    source_file=relative_path
                ))

        if raise_ambiguous:
            raise Exception(
                f"Files with multiple contracts found. Please specify which to verify via "
                f"--ambiguous-files flag or use --auto-ambiguous-contracts-resolve."
            )

        if not contract_handles:
            raise Exception(
                f"No Solidity files found matching {self.manager.component} logic contracts {Path.cwd()}"
            )

        self.log(f"Matched {len(contract_handles)} Solidity files to logic contracts")
        self.log(
            f"Contract handles: {[f'{ch.contract_name}@{ch.source_file}' for ch in contract_handles]}"
        )

        return contract_handles
