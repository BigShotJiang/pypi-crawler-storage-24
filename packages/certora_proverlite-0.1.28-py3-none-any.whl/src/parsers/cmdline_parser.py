#!/usr/bin/env python3
"""
Command line output parsing utilities.

This module contains functions for parsing command line output from various tools,
particularly for extracting useful information like job URLs from tool output.
"""

import re
from typing import Optional


def extract_job_url(output: str) -> Optional[str]:
    """Extract job URL from certoraRun output.

    Args:
        output: The stdout/stderr output from certoraRun command

    Returns:
        str: The job URL if found, None otherwise
    """
    # Look for prover.certora.com URLs in the output
    url_pattern = r'https://prover\.certora\.com/output/[^\s]+|https://prover\.certora\.com/[^\s]+'
    matches = re.findall(url_pattern, output)
    if matches:
        return matches[-1]  # Return the last (most recent) URL found
    return None