#!/usr/bin/env python3
"""
Foundry parser for extracting logic contracts from build artifacts.

This module parses Foundry's compilation output to identify which contracts
contain actual bytecode (logic contracts) vs interfaces/abstract contracts.
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Optional

from src.build_systems.foundry import FoundryManager
from src.parsers.base import ContractExtractor
from src.setup.solidity_utils import find_all_library_files_and_names, DEPENDENCIES


class FoundryContractExtractor(ContractExtractor):
    """Foundry-specific contract extractor."""

    def __init__(self, project_root: Path, profile: Optional[str] = None):
        """
        Initialize Foundry contract extractor.

        Args:
            project_root: Root directory of the project
            profile: Foundry profile to use for config resolution
        """
        super().__init__(project_root, FoundryManager, profile=profile)

    def extract_logic_contracts_impl(self, artifacts_dir: Path) -> Dict[str, List[str]]:
        """
        Extract logic contracts from Foundry artifacts.

        Assumes that `forge build` has already been run and the artifacts directory exists
        with the standard Foundry structure:

        out/
        ├── ContractA.sol/
        │   └── ContractA.json
        ├── IInterface.sol/
        │   └── IInterface.json
        └── ContractB.sol/
            └── ContractB.json

        A contract is considered a "logic contract" if:
        - It has a bytecode.object field in the JSON artifact
        - The bytecode starts with "0x"
        - The bytecode is not empty ("0x")

        Args:
            artifacts_dir: Path to Foundry out directory

        Returns:
            Dict mapping source file basename to list of contract names
        """
        logic_contracts: dict[str, list[str]] = {}
        library_files = find_all_library_files_and_names()
        library_files = {Path(file).stem: names for file, names in library_files.items()}

        # Iterate over all subdirectories in out/
        for subdir in sorted(artifacts_dir.iterdir()):
            if not subdir.is_dir():
                continue

            # Each subdirectory should be named {ContractName}.sol
            if not subdir.name.endswith(".sol"):
                continue

            # Skip test files (*.t.sol) and script files (*.s.sol)
            if subdir.name.endswith(".t.sol") or subdir.name.endswith(".s.sol"):
                continue

            # Extract source file name (without .sol extension)
            source_file_name = subdir.stem

            # If this source file is a library file, we need to skip the libraries in it
            library_names = []
            if source_file_name in library_files:
                library_names = library_files[source_file_name]

            # Iterate over all JSON files in the subdirectory
            for json_file in sorted(subdir.glob("*.json")):
                # Extract contract name from JSON filename (without .json extension)
                contract_name = json_file.stem

                # If this contract is known to be a library, skip it
                if contract_name in library_names:
                    continue

                try:
                    # Parse the JSON artifact
                    with open(json_file, 'r') as f:
                        artifact = json.load(f)

                    # Check if bytecode exists
                    if "bytecode" not in artifact:
                        continue

                    bytecode = artifact["bytecode"]
                    if not isinstance(bytecode, dict):
                        raise Exception(
                            f"Invalid bytecode format in {json_file}: expected dictionary, got {type(bytecode)}"
                        )

                    if "object" not in bytecode:
                        continue

                    bytecode_object = bytecode["object"]

                    # Validate bytecode format
                    if not isinstance(bytecode_object, str):
                        raise Exception(
                            f"Invalid bytecode.object in {json_file}: expected string, got {type(bytecode_object)}"
                        )

                    # Check if bytecode starts with 0x
                    if bytecode_object and not bytecode_object.startswith("0x"):
                        raise Exception(
                            f"Invalid bytecode in {json_file}: bytecode must start with '0x' but got "
                            f"'{bytecode_object[:10]}...'"
                        )

                    # Check if bytecode is not empty or just "0x"
                    if bytecode_object and bytecode_object != "" and bytecode_object != "0x":
                        # Extract actual contract name and source path from metadata
                        actual_contract_name = contract_name
                        source_path = None
                        try:
                            metadata = artifact.get("metadata")
                            if metadata:
                                settings = metadata.get("settings")
                                if settings:
                                    compilation_target = settings.get("compilationTarget")
                                    if compilation_target:
                                        # If more than 1 contract in compilation_target, use json filename
                                        if len(compilation_target) > 1:
                                            actual_contract_name = contract_name
                                        else:
                                            # Take the single contract name value and source path
                                            for file_path, contract_name_from_metadata in compilation_target.items():
                                                actual_contract_name = contract_name_from_metadata
                                                source_path = file_path
                                                break
                        except Exception:
                            # If we can't extract metadata, continue with the name of the json file
                            actual_contract_name = contract_name
                            pass

                        # Skip contracts from dependency directories or test/script directories
                        if source_path:
                            # Check if source_path contains any dependency directory
                            is_dependency = any(dep in source_path for dep in DEPENDENCIES)
                            # Check if source_path is in test or script directories
                            is_test_or_script = "/test/" in source_path or "/script/" in source_path or source_path.startswith("test/") or source_path.startswith("script/")
                            if is_dependency or is_test_or_script:
                                continue

                        if source_file_name in logic_contracts:
                            logic_contracts[source_file_name].append(actual_contract_name)
                        else:
                            logic_contracts[source_file_name] = [actual_contract_name]

                except json.JSONDecodeError as e:
                    raise Exception(f"Failed to parse JSON file {json_file}: {e}")
                except KeyError as e:
                    raise Exception(f"Missing required field in {json_file}: {e}")
                except Exception as e:
                    # Re-raise any other exceptions as fatal errors
                    raise Exception(f"Error processing {json_file}: {e}")

        return logic_contracts


def main():
    """Main entry point for command-line usage."""
    try:
        extractor = FoundryContractExtractor(Path.cwd())
        contracts = extractor.extract_logic_contracts()

        if contracts:
            from src.utils import logger
            logger.log(f"Found {len(contracts)} logic contracts:", "INFO", "Foundry")
            for source_file, contract_names in contracts.items():
                for contract_name in contract_names:
                    logger.log(f"  - {source_file} (contract: {contract_name})", "INFO", "Foundry")
        else:
            from src.utils import logger
            logger.log("No logic contracts found in Foundry build output", "ERROR", "Foundry")
            sys.exit(1)

    except Exception as e:
        from src.utils import logger
        logger.log(f"Error: {e}", "ERROR", "Foundry")
        sys.exit(1)


if __name__ == "__main__":
    main()
