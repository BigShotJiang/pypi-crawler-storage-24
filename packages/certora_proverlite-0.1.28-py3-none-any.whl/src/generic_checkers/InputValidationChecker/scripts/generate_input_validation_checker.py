#!/usr/bin/env python3
"""
Script to generate Certora Input Validation Checker configuration and spec files.
"""

import argparse
import json
import os
import sys
from pathlib import Path

from src.generic_checkers.InputValidationChecker.scripts.cvl_rule_generator import (
    CVLRuleGenerator, generate_spec_file_header
)
from src.parsers.orchestrator_argparse import parse_contract_files
from src.parsers.type_analyzer import TypeAnalyzer
from src.utils.logger import logger


def validate_args(args):
    """Validate command line arguments."""
    # Either files or base_config must be provided
    if not args.files and not args.base_config:
        logger.error("Either files or --base-config must be provided")
        sys.exit(1)

    if args.files and args.base_config:
        logger.error("Cannot specify both files and --base-config")
        sys.exit(1)

    if args.base_config:
        if not os.path.exists(args.base_config):
            logger.error(f"Base config file {args.base_config} does not exist")
            sys.exit(1)

    if not args.contract:
        logger.error("Main contract name is required")
        sys.exit(1)

    if args.files:
        contracts = parse_contract_files(args.files)
        for handle in contracts:
            if not handle.source_file.endswith('.sol'):
                logger.error(f"{handle.source_file} is not a .sol file")
                sys.exit(1)
            if not os.path.exists(handle.source_file):
                logger.error(f"File {handle.source_file} does not exist")
                sys.exit(1)
        contract_names = [c.contract_name for c in contracts]
        if args.contract not in contract_names:
            logger.error(f"Main contract '{args.contract}' not found in provided files")
            logger.error(f"Available contracts: {', '.join(contract_names)}")
            sys.exit(1)


def load_config_for_loop_iter(base_config_path: str) -> int:
    """Load loop_iter from base config, default to 3."""
    try:
        with open(base_config_path, 'r') as f:
            config = json.load(f)
            return config.get('loop_iter', 3)
    except Exception as e:
        logger.warning(f"Could not load loop_iter from config: {e}")
        return 3


def process_templates(args):
    """Process template files and generate configuration."""
    script_dir = Path(__file__).parent
    project_dir = script_dir.parent

    # Determine output directory - use specified path directly or default
    output_dir = getattr(args, 'output_dir', None) or Path("certora_input_validation_checker")
    output_dir = Path(output_dir)

    # Create output directory if it doesn't exist (don't delete if exists - for per-contract accumulation)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Get loop_iter from config if available
    loop_iter = 3
    if args.base_config:
        loop_iter = load_config_for_loop_iter(args.base_config)

    logger.info(f"Using loop_iter={loop_iter} for array bounds")

    # Initialize type analyzer - use specified path or default
    certora_internal_path = getattr(args, 'certora_internal_path', None) or ".certora_internal"
    analyzer = TypeAnalyzer(certora_internal_path=certora_internal_path)

    # Load and parse build data
    logger.info("Loading build data from pre-generated JSON files...")
    if not analyzer.parse_all():
        logger.error("Failed to parse build data")
        sys.exit(1)

    logger.info(f"Found {len(analyzer.methods)} methods in build data")
    logger.info(f"Found {len(analyzer.registry.structs)} struct definitions")

    # Get contracts to process - either list from orchestrator or single contract from CLI
    contracts = getattr(args, 'contracts', None) or [args.contract]

    # Initialize rule generator with satisfy mode if requested
    use_satisfy_mode = getattr(args, 'use_satisfy_mode', False)
    if use_satisfy_mode:
        logger.info("Using SATISFY mode (requires nondeterminism control for accurate results)")
    rule_gen = CVLRuleGenerator(loop_iter=loop_iter, use_satisfy_mode=use_satisfy_mode)

    # Generate spec file for EACH contract
    for contract_name in contracts:
        # Get methods for this contract
        methods = analyzer.get_public_non_view_methods(contract_name)
        logger.info(f"Generating input validation rules for {len(methods)} public/external non-view methods in {contract_name}")

        if not methods:
            logger.warning(f"No suitable methods found for contract {contract_name}")
            logger.warning("Input validation checker will not generate any rules for this contract.")
            continue

        # Generate rules for all methods of this contract
        all_rules = []
        for method in methods:
            logger.info(f"  Generating rules for {method.method_name} ({len(method.parameters)} parameters)...")
            method_rules = rule_gen.generate_rules_for_method(method)
            all_rules.extend(method_rules)
            logger.info(f"    Generated {len(method_rules)} rules")

        logger.info(f"Total rules generated for {contract_name}: {len(all_rules)}")

        # Write spec file for this contract
        spec_file_path = output_dir / f"input_validation_{contract_name}.spec"
        with open(spec_file_path, 'w') as f:
            # Write header
            f.write(generate_spec_file_header(contract_name))

            # Write all rules
            for rule in all_rules:
                f.write(rule)
                f.write("\n")

        logger.info(f"Generated spec file: {spec_file_path}")

    # Process configuration template for EACH contract
    conf_template = project_dir / "confs" / "InputValidationChecker.template.conf"

    if not conf_template.exists():
        logger.error(f"Template configuration file not found: {conf_template}")
        sys.exit(1)

    # Read template
    with open(conf_template, 'r') as f:
        template_content = f.read()

    conf_files = []
    for contract_name in contracts:
        # Check if spec file exists for this contract (might not if no methods)
        spec_file_path = output_dir / f"input_validation_{contract_name}.spec"
        if not spec_file_path.exists():
            logger.info(f"Skipping config for {contract_name} (no spec file generated)")
            continue

        # Replace placeholders
        content = template_content.replace("{{CONTRACT_NAME}}", contract_name)
        if args.base_config:
            content = content.replace("$BASE_CONFIG_OR_FILES$", f'"override_base_config": "{args.base_config}"')
        elif args.files:
            files_json = json.dumps(args.files)
            content = content.replace("$BASE_CONFIG_OR_FILES$", f'"files": {files_json}')

        # Write processed file for this contract
        output_conf = output_dir / f"InputValidationChecker_{contract_name}.conf"
        with open(output_conf, 'w') as f:
            f.write(content)

        conf_files.append(f"InputValidationChecker_{contract_name}.conf")
        logger.info(f"Generated config file: {output_conf}")

    # Create runner script
    create_runner_script(output_dir, conf_files)

    logger.info(f"✓ Generated configuration in {output_dir}/")
    if conf_files:
        logger.info("Run verification with:")
        for conf_file in conf_files:
            logger.info(f"  certoraRun {output_dir}/{conf_file}")


def create_runner_script(output_dir, conf_files):
    """Create a runner script for easy execution."""
    runner_content = """#!/bin/bash
# Auto-generated runner script for Input Validation Checker

echo "Running Input Validation Checker..."

"""

    for conf_file in conf_files:
        runner_content += f"""echo "Running {conf_file}..."
certoraRun {conf_file}
echo "Completed {conf_file}"
echo ""

"""

    runner_content += 'echo "All checks completed!"'

    runner_file = output_dir / "run_checker.sh"
    with open(runner_file, 'w') as f:
        f.write(runner_content)

    # Make executable
    os.chmod(runner_file, 0o755)
    logger.info(f"Generated runner script: {runner_file}")


def main():
    parser = argparse.ArgumentParser(
        description="Generate Certora Input Validation Checker configuration and spec files"
    )

    parser.add_argument(
        '--base-config',
        type=str,
        help='Path to base config file (mutually exclusive with files)'
    )

    parser.add_argument(
        'files',
        nargs='*',
        help='List of Solidity contract files (.sol) - required if --base-config not provided'
    )

    parser.add_argument(
        'contract',
        help='Name of the main contract (without .sol extension)'
    )

    parser.add_argument(
        '--use-satisfy-mode',
        action='store_true',
        help='Use satisfy statements instead of assert (requires nondeterminism control for stronger validation checking)'
    )

    args = parser.parse_args()

    validate_args(args)
    process_templates(args)


if __name__ == "__main__":
    main()
