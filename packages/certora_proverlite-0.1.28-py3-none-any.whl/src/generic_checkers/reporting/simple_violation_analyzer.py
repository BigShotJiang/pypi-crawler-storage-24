"""
Simple violation analyzer using direct Claude API calls.
Alternative to AIComposer. Used when USE_AICOMPOSER=false (default).
"""

from typing import Any, List, Optional, Tuple

import anthropic.types
from pydantic import BaseModel

from src.utils.llm_util import call_llm_messages, call_llm_messages_structured, MODEL_SONNET
from src.utils.logger import logger
from .token_usage import AnalysisPhase, get_global_tracker

VIOLATION_ANALYZER_SYSTEM_PROMPT = """You are analyzing smart contract verification results from the Certora Prover.

The Certora Prover is a formal verification tool that checks if smart contract implementations satisfy their specifications. When verification fails, it produces counterexamples showing concrete scenarios where the specification is violated.

Key Context:
1. Specifications are written by humans and may have mistakes - a verification failure could be due to specification errors, not implementation bugs.
2. The Prover considers ALL possible starting states. Some counterexamples may start from states that are unrealistic in practice.
3. You have access to the implementation and specification files.

Your analysis should:
- Be concrete: Use specific function names, variable names, and values
- Note uncertainties: If starting states seem unreachable, say so
- Focus on security-relevant details vs. noise"""


class SimpleViolationAnalyzer:
    """Analyzes violations using direct Claude API calls with prompt caching."""

    def __init__(
        self,
        model: str = MODEL_SONNET,
        max_tokens: int = 4096,
        temperature: float = 0.0,
    ):
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    def _build_messages(
        self,
        initial_prompt: str,
        input_messages: List[str],
        _folder: str,  # Reserved for future file selection
        code_snippets: Optional[str] = None,
    ) -> tuple[list, list]:
        """Build system and user messages with caching enabled.

        Message structure for optimal Claude prompt caching:
        - System: base prompt + initial_prompt (per-rule, cached)
        - User: code_snippets (cached, shared across findings) + input_messages (varying)
        """
        # System message with cache control after initial_prompt
        system_content = [
            {"type": "text", "text": VIOLATION_ANALYZER_SYSTEM_PROMPT},
            {"type": "text", "text": initial_prompt, "cache_control": {"type": "ephemeral"}},
        ]

        # User content: code_snippets FIRST (cached), then input_messages (varying)
        user_content = []

        # Add code snippets as FIRST user content block with cache control
        # This enables cache hits when multiple findings share the same source code
        if code_snippets:
            user_content.append({
                "type": "text",
                "text": code_snippets,
                "cache_control": {"type": "ephemeral"},
            })

        # Then add input_messages (calltraces, rule info, etc.)
        user_content.extend([{"type": "text", "text": msg} for msg in input_messages])

        return system_content, [{"role": "user", "content": user_content}]

    def analyze(
        self,
        input_messages: List[str],
        initial_prompt: str,
        folder: str,
        phase: AnalysisPhase,
        tracking_rule_name: str,
        output_type: Optional[type[BaseModel]] = None,
        code_snippets: Optional[str] = None,
        iteration_index: Optional[int] = None,
    ) -> Tuple[int, str, str]:
        """Analyze violations using Claude API with prompt caching.

        Args:
            input_messages: List of user input messages
            initial_prompt: System prompt for the analysis
            folder: Path to the report folder
            phase: Analysis phase for token tracking
            tracking_rule_name: Rule name for token tracking
            output_type: Optional Pydantic model for structured output
            code_snippets: Optional code snippets for context
            iteration_index: Optional iteration index (for token tracking)
        """
        system_content, messages = self._build_messages(initial_prompt, input_messages, folder, code_snippets)

        def track_response(response: anthropic.types.Message) -> None:
            self._track_token_usage(response, phase, tracking_rule_name, iteration_index)

        try:
            if output_type is not None:
                result = call_llm_messages_structured(
                    system=system_content,
                    messages=messages,
                    output_type=output_type,
                    model=self.model,
                    max_tokens=self.max_tokens,
                    temperature=self.temperature,
                    on_api_response=track_response,
                )
                return 0, result.model_dump_json(indent=2), "simple_api"
            else:
                text = call_llm_messages(
                    system=system_content,
                    messages=messages,
                    model=self.model,
                    max_tokens=self.max_tokens,
                    temperature=self.temperature,
                    on_api_response=track_response,
                )
                return 0, text, "simple_api"
        except Exception as e:
            from .retry_utils import is_fatal_api_error

            if is_fatal_api_error(e):
                raise
            logger.error(f"Simple analyzer failed: {e}")
            return 1, f"[API_ERROR] {type(e).__name__}: {e}", "simple_api"

    def _track_token_usage(
        self,
        response: anthropic.types.Message,
        phase: AnalysisPhase,
        rule_name: str,
        iteration_index: Optional[int],
    ) -> None:
        """Track token usage from API response."""
        usage = response.usage
        tracker = get_global_tracker()

        # Extract cache-specific token counts
        cache_creation = getattr(usage, "cache_creation_input_tokens", 0) or 0
        cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0

        tracker.record_api_usage(
            phase=phase,
            rule_name=rule_name,
            iteration_index=iteration_index,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            cache_creation_input_tokens=cache_creation,
            cache_read_input_tokens=cache_read,
            model=self.model,
        )


def simple_analyze(
    input_messages: List[str],
    initial_prompt: str,
    args: Any,
    phase: AnalysisPhase,
    tracking_rule_name: str,
    output_type: Optional[type[BaseModel]] = None,
    code_snippets: Optional[str] = None,
    iteration_index: Optional[int] = None,
) -> Tuple[int, str, str]:
    """Simple analyzer function matching _call_analyzer signature."""
    analyzer = SimpleViolationAnalyzer()
    return analyzer.analyze(
        input_messages=input_messages,
        initial_prompt=initial_prompt,
        folder=args.folder,
        phase=phase,
        tracking_rule_name=tracking_rule_name,
        output_type=output_type,
        code_snippets=code_snippets,
        iteration_index=iteration_index,
    )
