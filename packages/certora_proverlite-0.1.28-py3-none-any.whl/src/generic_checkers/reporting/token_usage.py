"""
Global token usage tracking for simple violation analyzer.

Tracks:
- API token usage (input, output, cache read, cache write)
- Analysis cache hits/misses
- Per-phase and aggregated stats
"""

import json
import threading
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Literal, Optional


class AnalysisPhase(Enum):
    """Analysis phases for token tracking and cache keys."""

    CALLTRACE_ANALYSIS = "calltrace_analysis"  # Step 1
    DEFECT_ANALYSIS = "defect_analysis"  # Step 2
    SYNTHESIS = "synthesis"  # Step 3
    VALIDATION = "validation"  # Step 3.5
    IMPACT_LIKELIHOOD = "impact_likelihood"  # Step 3.6
    FIX_GENERATION = "fix_generation"  # Step 3.7


# Model pricing in USD per 1M tokens (as of 2025)
MODEL_PRICING = {
    "claude-sonnet-4-20250514": {
        "input": 3.00,
        "output": 15.00,
        "cache_read": 0.30,
        "cache_write": 3.75,
    },
    "claude-sonnet-4.5": {
        "input": 3.00,
        "output": 15.00,
        "cache_read": 0.30,
        "cache_write": 3.75,
    },
    "claude-opus-4-20250514": {
        "input": 15.00,
        "output": 75.00,
        "cache_read": 1.50,
        "cache_write": 18.75,
    },
    "claude-opus-4.5": {
        "input": 15.00,
        "output": 75.00,
        "cache_read": 1.50,
        "cache_write": 18.75,
    },
    "claude-sonnet-4-5-20250929": {
        "input": 3.00,
        "output": 15.00,
        "cache_read": 0.30,
        "cache_write": 3.75,
    },
}

# Default model for pricing calculations when model is unknown
DEFAULT_PRICING_MODEL = "claude-sonnet-4-20250514"


@dataclass
class TokenUsageEntry:
    """Single token usage record."""

    phase: AnalysisPhase
    rule_name: str
    iteration_index: Optional[int]
    input_tokens: int
    output_tokens: int
    cache_creation_input_tokens: int
    cache_read_input_tokens: int
    source: Literal["api", "analysis_cache", "aicomposer", "claude_agent_sdk"]
    model: str = DEFAULT_PRICING_MODEL
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {
            "phase": self.phase.value,
            "rule_name": self.rule_name,
            "iteration_index": self.iteration_index,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cache_creation_input_tokens": self.cache_creation_input_tokens,
            "cache_read_input_tokens": self.cache_read_input_tokens,
            "source": self.source,
            "model": self.model,
            "timestamp": self.timestamp,
        }

    def estimated_cost_usd(self) -> float:
        """Estimate cost in USD for this entry."""
        pricing = MODEL_PRICING.get(self.model, MODEL_PRICING[DEFAULT_PRICING_MODEL])
        input_cost = (self.input_tokens / 1_000_000) * pricing["input"]
        output_cost = (self.output_tokens / 1_000_000) * pricing["output"]
        cache_read_cost = (self.cache_read_input_tokens / 1_000_000) * pricing["cache_read"]
        cache_write_cost = (self.cache_creation_input_tokens / 1_000_000) * pricing["cache_write"]
        return input_cost + output_cost + cache_read_cost + cache_write_cost


@dataclass
class TokenUsageStats:
    """Aggregated token usage statistics."""

    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cache_creation_tokens: int = 0
    total_cache_read_tokens: int = 0
    api_calls: int = 0
    analysis_cache_hits: int = 0
    analysis_cache_misses: int = 0

    # Per-phase breakdown
    calltrace_analysis_tokens: int = 0
    defect_analysis_tokens: int = 0
    synthesis_tokens: int = 0
    validation_tokens: int = 0
    impact_likelihood_tokens: int = 0
    fix_generation_tokens: int = 0

    # Cost tracking (accumulated from entries with model-aware pricing)
    estimated_cost_usd: float = 0.0

    # AIComposer-specific breakdown
    aicomposer_tokens: int = 0
    aicomposer_cost_usd: float = 0.0
    aicomposer_calls: int = 0

    # Claude Agent SDK (fix generation) breakdown
    claude_agent_sdk_tokens: int = 0
    claude_agent_sdk_cost_usd: float = 0.0
    claude_agent_sdk_calls: int = 0

    # Prover compute cost breakdown
    prover_compute_total_seconds: float = 0.0
    prover_compute_minutes: int = 0  # rounded up to nearest minute
    prover_compute_cost_usd: float = 0.0
    prover_job_count: int = 0

    def to_dict(self) -> dict:
        return {
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_cache_creation_tokens": self.total_cache_creation_tokens,
            "total_cache_read_tokens": self.total_cache_read_tokens,
            "total_tokens": self.total_tokens,
            "api_calls": self.api_calls,
            "analysis_cache_hits": self.analysis_cache_hits,
            "analysis_cache_misses": self.analysis_cache_misses,
            "calltrace_analysis_tokens": self.calltrace_analysis_tokens,
            "defect_analysis_tokens": self.defect_analysis_tokens,
            "synthesis_tokens": self.synthesis_tokens,
            "validation_tokens": self.validation_tokens,
            "impact_likelihood_tokens": self.impact_likelihood_tokens,
            "fix_generation_tokens": self.fix_generation_tokens,
            "estimated_cost_usd": round(self.estimated_cost_usd, 4),
            "aicomposer_tokens": self.aicomposer_tokens,
            "aicomposer_cost_usd": round(self.aicomposer_cost_usd, 4),
            "aicomposer_calls": self.aicomposer_calls,
            "claude_agent_sdk_tokens": self.claude_agent_sdk_tokens,
            "claude_agent_sdk_cost_usd": round(self.claude_agent_sdk_cost_usd, 4),
            "claude_agent_sdk_calls": self.claude_agent_sdk_calls,
            "prover_compute_total_seconds": round(self.prover_compute_total_seconds, 2),
            "prover_compute_minutes": self.prover_compute_minutes,
            "prover_compute_cost_usd": round(self.prover_compute_cost_usd, 4),
            "prover_job_count": self.prover_job_count,
        }

    @property
    def total_tokens(self) -> int:
        """Total tokens consumed (input + output)."""
        return self.total_input_tokens + self.total_output_tokens


class TokenUsageTracker:
    """Thread-safe global token usage tracker."""

    def __init__(self):
        self._lock = threading.Lock()
        self._entries: list[TokenUsageEntry] = []
        self._stats = TokenUsageStats()

    def record_api_usage(
        self,
        phase: AnalysisPhase,
        rule_name: str,
        iteration_index: Optional[int],
        input_tokens: int,
        output_tokens: int,
        cache_creation_input_tokens: int = 0,
        cache_read_input_tokens: int = 0,
        model: str = DEFAULT_PRICING_MODEL,
        source: Literal["api", "aicomposer", "claude_agent_sdk"] = "api",
    ) -> None:
        """Record token usage from an API call."""
        entry = TokenUsageEntry(
            phase=phase,
            rule_name=rule_name,
            iteration_index=iteration_index,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_creation_input_tokens=cache_creation_input_tokens,
            cache_read_input_tokens=cache_read_input_tokens,
            source=source,
            model=model,
        )

        with self._lock:
            self._entries.append(entry)
            self._stats.total_input_tokens += input_tokens
            self._stats.total_output_tokens += output_tokens
            self._stats.total_cache_creation_tokens += cache_creation_input_tokens
            self._stats.total_cache_read_tokens += cache_read_input_tokens
            self._stats.api_calls += 1
            self._stats.analysis_cache_misses += 1
            self._stats.estimated_cost_usd += entry.estimated_cost_usd()

            # AIComposer-specific breakdown
            if source == "aicomposer":
                self._stats.aicomposer_tokens += input_tokens + output_tokens
                self._stats.aicomposer_cost_usd += entry.estimated_cost_usd()
                self._stats.aicomposer_calls += 1
            elif source == "claude_agent_sdk":
                self._stats.claude_agent_sdk_tokens += input_tokens + output_tokens
                self._stats.claude_agent_sdk_cost_usd += entry.estimated_cost_usd()
                self._stats.claude_agent_sdk_calls += 1

            # Per-phase breakdown
            total_for_call = input_tokens + output_tokens
            if phase == AnalysisPhase.CALLTRACE_ANALYSIS:
                self._stats.calltrace_analysis_tokens += total_for_call
            elif phase == AnalysisPhase.DEFECT_ANALYSIS:
                self._stats.defect_analysis_tokens += total_for_call
            elif phase == AnalysisPhase.SYNTHESIS:
                self._stats.synthesis_tokens += total_for_call
            elif phase == AnalysisPhase.VALIDATION:
                self._stats.validation_tokens += total_for_call
            elif phase == AnalysisPhase.IMPACT_LIKELIHOOD:
                self._stats.impact_likelihood_tokens += total_for_call
            elif phase == AnalysisPhase.FIX_GENERATION:
                self._stats.fix_generation_tokens += total_for_call

    def record_cache_hit(
        self,
        phase: AnalysisPhase,
        rule_name: str,
        iteration_index: Optional[int],
    ) -> None:
        """Record an analysis cache hit (no API call made)."""
        entry = TokenUsageEntry(
            phase=phase,
            rule_name=rule_name,
            iteration_index=iteration_index,
            input_tokens=0,
            output_tokens=0,
            cache_creation_input_tokens=0,
            cache_read_input_tokens=0,
            source="analysis_cache",
        )

        with self._lock:
            self._entries.append(entry)
            self._stats.analysis_cache_hits += 1

    def record_prover_compute(self, total_seconds: float, num_jobs: int) -> None:
        """Record prover compute costs from job metadata."""
        import math

        with self._lock:
            self._stats.prover_compute_total_seconds += total_seconds
            minutes = math.ceil(total_seconds / 60) if total_seconds > 0 else 0
            self._stats.prover_compute_minutes += minutes
            self._stats.prover_compute_cost_usd += minutes * 0.0255
            self._stats.prover_job_count += num_jobs

    def get_stats(self) -> TokenUsageStats:
        """Get current aggregated statistics."""
        with self._lock:
            return TokenUsageStats(
                total_input_tokens=self._stats.total_input_tokens,
                total_output_tokens=self._stats.total_output_tokens,
                total_cache_creation_tokens=self._stats.total_cache_creation_tokens,
                total_cache_read_tokens=self._stats.total_cache_read_tokens,
                api_calls=self._stats.api_calls,
                analysis_cache_hits=self._stats.analysis_cache_hits,
                analysis_cache_misses=self._stats.analysis_cache_misses,
                calltrace_analysis_tokens=self._stats.calltrace_analysis_tokens,
                defect_analysis_tokens=self._stats.defect_analysis_tokens,
                synthesis_tokens=self._stats.synthesis_tokens,
                validation_tokens=self._stats.validation_tokens,
                impact_likelihood_tokens=self._stats.impact_likelihood_tokens,
                fix_generation_tokens=self._stats.fix_generation_tokens,
                estimated_cost_usd=self._stats.estimated_cost_usd,
                aicomposer_tokens=self._stats.aicomposer_tokens,
                aicomposer_cost_usd=self._stats.aicomposer_cost_usd,
                aicomposer_calls=self._stats.aicomposer_calls,
                claude_agent_sdk_tokens=self._stats.claude_agent_sdk_tokens,
                claude_agent_sdk_cost_usd=self._stats.claude_agent_sdk_cost_usd,
                claude_agent_sdk_calls=self._stats.claude_agent_sdk_calls,
                prover_compute_total_seconds=self._stats.prover_compute_total_seconds,
                prover_compute_minutes=self._stats.prover_compute_minutes,
                prover_compute_cost_usd=self._stats.prover_compute_cost_usd,
                prover_job_count=self._stats.prover_job_count,
            )

    def get_entries(self) -> list[dict]:
        """Get all recorded entries as dictionaries."""
        with self._lock:
            return [e.to_dict() for e in self._entries]

    def reset(self) -> None:
        """Reset all tracked data."""
        with self._lock:
            self._entries.clear()
            self._stats = TokenUsageStats()

    def write_stats_file(self, output_dir: Path, filename: str = "token_usage_stats.json") -> Path:
        """Write full stats to a JSON file.

        Args:
            output_dir: Directory to write the file to
            filename: Name of the stats file

        Returns:
            Path to the written file
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / filename

        data = {
            "generated_at": datetime.now().isoformat(),
            "summary": self.get_stats().to_dict(),
            "entries": self.get_entries(),
        }

        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

        return output_path


# Global singleton instance
_global_tracker: Optional[TokenUsageTracker] = None
_tracker_lock = threading.Lock()


def get_global_tracker() -> TokenUsageTracker:
    """Get or create the global token usage tracker."""
    global _global_tracker
    with _tracker_lock:
        if _global_tracker is None:
            _global_tracker = TokenUsageTracker()
        return _global_tracker


def reset_global_tracker() -> None:
    """Reset the global tracker (for testing or new runs)."""
    global _global_tracker
    with _tracker_lock:
        if _global_tracker is not None:
            _global_tracker.reset()
