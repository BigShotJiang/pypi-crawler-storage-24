"""
Extract code snippets from source files based on jumpToDefinition locations in calltraces.

This module walks calltrace trees, extracts jumpToDefinition locations, finds the
enclosing functions, merges overlapping snippets, and formats them for LLM analysis.
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from src.utils.logger import logger

# Patterns for function-like declarations in Solidity
SOLIDITY_FUNCTION_PATTERN = re.compile(
    r"^\s*(function|modifier|constructor|fallback|receive)\s*(\w+)?\s*\("
)

# Patterns for function-like declarations in CVL (.spec files)
CVL_FUNCTION_PATTERN = re.compile(r"^\s*(rule|invariant|function|ghost|definition)\s+(\w+)")


@dataclass(frozen=True)
class CodeLocation:
    """A source code location from jumpToDefinition."""

    file_path: str  # e.g., "contracts/Token.sol"
    line: int  # 1-indexed line number


@dataclass
class CodeSnippet:
    """A code snippet with file location and content."""

    file_path: str
    start_line: int  # 1-indexed, inclusive
    end_line: int  # 1-indexed, inclusive
    code: str
    function_name: Optional[str] = None


def extract_locations_from_calltrace(calltrace: dict[str, Any]) -> list[CodeLocation]:
    """
    Recursively walk a calltrace tree and extract all jumpToDefinition locations.

    Args:
        calltrace: Root node of the calltrace dict tree

    Returns:
        List of CodeLocation objects (may contain duplicates)
    """
    locations: list[CodeLocation] = []
    _walk_calltrace_node(calltrace, locations)
    return locations


def _walk_calltrace_node(node: dict[str, Any], locations: list[CodeLocation]) -> None:
    """Recursively walk a calltrace node and collect jumpToDefinition locations."""
    if not isinstance(node, dict):
        return

    # Extract jumpToDefinition from this node
    jump = node.get("jumpToDefinition")
    if jump and isinstance(jump, dict):
        file_path = jump.get("file", "")
        start = jump.get("start", {})
        line = start.get("line", 0) if isinstance(start, dict) else 0

        if file_path and line > 0:
            locations.append(CodeLocation(file_path=file_path, line=line))

    # Recurse into children
    children = node.get("childrenList", [])
    if isinstance(children, list):
        for child in children:
            if isinstance(child, dict):
                _walk_calltrace_node(child, locations)


def find_enclosing_function(
    lines: list[str], target_line: int, file_path: str
) -> tuple[int, int, Optional[str]]:
    """
    Find the function boundaries containing target_line.

    Args:
        lines: List of source code lines (0-indexed)
        target_line: 1-indexed line number to find enclosing function for
        file_path: File path (used to determine if Solidity or CVL)

    Returns:
        Tuple of (start_line, end_line, function_name) where lines are 1-indexed.
        If no function found, returns (1, len(lines), None) for the whole file.
    """
    if not lines or target_line < 1:
        return (1, max(1, len(lines)), None)

    # Convert to 0-indexed for array access
    target_idx = target_line - 1
    if target_idx >= len(lines):
        target_idx = len(lines) - 1

    # Choose pattern based on file type
    is_cvl = file_path.endswith(".spec")
    pattern = CVL_FUNCTION_PATTERN if is_cvl else SOLIDITY_FUNCTION_PATTERN

    # Search backward for function declaration
    func_start_idx = None
    func_name = None

    for i in range(target_idx, -1, -1):
        line = lines[i]
        match = pattern.search(line)
        if match:
            func_start_idx = i
            # Group 2 is the function name (may be None for constructor/fallback/receive)
            func_name = match.group(2) if match.lastindex and match.lastindex >= 2 else match.group(1)
            break

    # If no function found, return whole file
    if func_start_idx is None:
        return (1, len(lines), None)

    # Find the end of the function using brace matching
    func_end_idx = _find_function_end(lines, func_start_idx)

    return (func_start_idx + 1, func_end_idx + 1, func_name)


def _find_function_end(lines: list[str], start_idx: int) -> int:
    """
    Find the end of a function using brace matching.

    Args:
        lines: List of source code lines (0-indexed)
        start_idx: 0-indexed line where function declaration starts

    Returns:
        0-indexed line number where function ends (closing brace)
    """
    depth = 0
    found_first_brace = False

    for i in range(start_idx, len(lines)):
        line = lines[i]

        # Remove string literals and comments to avoid false brace matches
        cleaned_line = _remove_strings_and_comments(line)

        for char in cleaned_line:
            if char == "{":
                depth += 1
                found_first_brace = True
            elif char == "}":
                depth -= 1
                if found_first_brace and depth == 0:
                    return i

    # If we never found matching braces, return the last line
    return len(lines) - 1


def _remove_strings_and_comments(line: str) -> str:
    """Remove string literals and comments from a line for brace matching."""
    result = []
    i = 0
    in_string = None  # None, '"', or "'"

    while i < len(line):
        char = line[i]

        # Handle string start/end
        if char in ('"', "'") and in_string is None:
            in_string = char
            i += 1
            continue
        elif char == in_string:
            # Check for escape
            if i > 0 and line[i - 1] == "\\":
                i += 1
                continue
            in_string = None
            i += 1
            continue

        # Skip characters inside strings
        if in_string:
            i += 1
            continue

        # Handle single-line comments
        if char == "/" and i + 1 < len(line) and line[i + 1] == "/":
            break  # Rest of line is comment

        # Handle multi-line comment start (just skip the rest for simplicity)
        if char == "/" and i + 1 < len(line) and line[i + 1] == "*":
            break

        result.append(char)
        i += 1

    return "".join(result)


def merge_overlapping_snippets(snippets: list[CodeSnippet]) -> list[CodeSnippet]:
    """
    Merge snippets that overlap or are contained within each other.

    For the same file, if snippet A's range contains snippet B's range, keep only A.
    If ranges overlap, merge them into one.

    Args:
        snippets: List of code snippets (may have overlaps)

    Returns:
        List of merged snippets with no overlaps within the same file
    """
    if not snippets:
        return []

    # Group by file path
    by_file: dict[str, list[CodeSnippet]] = {}
    for snippet in snippets:
        if snippet.file_path not in by_file:
            by_file[snippet.file_path] = []
        by_file[snippet.file_path].append(snippet)

    merged: list[CodeSnippet] = []

    for file_path, file_snippets in by_file.items():
        # Sort by start line
        sorted_snippets = sorted(file_snippets, key=lambda s: s.start_line)

        # Merge overlapping ranges
        merged_for_file: list[CodeSnippet] = []
        for snippet in sorted_snippets:
            if not merged_for_file:
                merged_for_file.append(snippet)
                continue

            last = merged_for_file[-1]

            # Check if current snippet overlaps with or is adjacent to the last one
            if snippet.start_line <= last.end_line + 1:
                # Merge: extend the last snippet to include this one
                if snippet.end_line > last.end_line:
                    # Create new merged snippet
                    merged_code = _merge_code(last, snippet)
                    merged_name = last.function_name or snippet.function_name
                    merged_for_file[-1] = CodeSnippet(
                        file_path=file_path,
                        start_line=last.start_line,
                        end_line=snippet.end_line,
                        code=merged_code,
                        function_name=merged_name,
                    )
            else:
                merged_for_file.append(snippet)

        merged.extend(merged_for_file)

    return merged


def _merge_code(snippet1: CodeSnippet, snippet2: CodeSnippet) -> str:
    """Merge code from two overlapping snippets."""
    # Split into lines
    lines1 = snippet1.code.split("\n")
    lines2 = snippet2.code.split("\n")

    # Calculate the overlap
    overlap_start = snippet2.start_line - snippet1.start_line
    if overlap_start < 0:
        overlap_start = 0

    # Take lines from snippet1 up to where snippet2 starts, then all of snippet2
    if overlap_start < len(lines1):
        return "\n".join(lines1[:overlap_start] + lines2)
    else:
        return "\n".join(lines1 + lines2)


def read_code_snippets(locations: list[CodeLocation], folder: str) -> str:
    """
    Read full function bodies for each location, merge overlaps, return formatted block.

    Args:
        locations: List of CodeLocation objects from calltraces
        folder: Path to extracted tarball (source files are in inputs/.certora_sources/)

    Returns:
        Formatted markdown string with code snippets, or empty string if no snippets
    """
    if not locations:
        return ""

    # Deduplicate locations first
    unique_locations = list(set(locations))

    # Group locations by file
    by_file: dict[str, list[CodeLocation]] = {}
    for loc in unique_locations:
        if loc.file_path not in by_file:
            by_file[loc.file_path] = []
        by_file[loc.file_path].append(loc)

    snippets: list[CodeSnippet] = []
    sources_dir = Path(folder) / "inputs" / ".certora_sources"

    for file_path, file_locations in by_file.items():
        # Try to read the file
        full_path = sources_dir / file_path
        if not full_path.exists():
            logger.warning(f"Source file not found: {full_path}")
            continue

        try:
            content = full_path.read_text(encoding="utf-8")
            lines = content.split("\n")
        except Exception as e:
            logger.warning(f"Failed to read {full_path}: {e}")
            continue

        # For each location, find enclosing function
        for loc in file_locations:
            start_line, end_line, func_name = find_enclosing_function(lines, loc.line, file_path)

            # Extract the code (convert to 0-indexed for slicing)
            code_lines = lines[start_line - 1 : end_line]
            code = "\n".join(code_lines)

            snippets.append(
                CodeSnippet(
                    file_path=file_path,
                    start_line=start_line,
                    end_line=end_line,
                    code=code,
                    function_name=func_name,
                )
            )

    # Merge overlapping snippets
    merged_snippets = merge_overlapping_snippets(snippets)

    if not merged_snippets:
        return ""

    # Sort by file path for consistent ordering (cache key stability)
    merged_snippets.sort(key=lambda s: (s.file_path, s.start_line))

    # Format as markdown
    return _format_snippets_as_markdown(merged_snippets)


def _format_snippets_as_markdown(snippets: list[CodeSnippet]) -> str:
    """Format code snippets as a markdown block."""
    parts = ["## Relevant Source Code\n"]

    for snippet in snippets:
        # Determine language for syntax highlighting
        if snippet.file_path.endswith(".spec"):
            lang = "cvl"
        elif snippet.file_path.endswith(".sol"):
            lang = "solidity"
        else:
            lang = ""

        # Build header
        if snippet.function_name:
            header = f"### {snippet.file_path} - {snippet.function_name} (lines {snippet.start_line}-{snippet.end_line})"
        else:
            header = f"### {snippet.file_path} (lines {snippet.start_line}-{snippet.end_line})"

        parts.append(header)
        parts.append(f"```{lang}")
        parts.append(snippet.code)
        parts.append("```\n")

    return "\n".join(parts)
