"""
Rule-specific grouping strategies for violation aggregation.

Defines how violations should be grouped for different rule types:
- Category 1 (Default): Group by (rule_name, method_name) - crash on duplicates
- Category 2: Group by source location extracted from calltrace hooks
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]

from src.utils.logger import logger

from .base.models import SourceLocation


class GroupingCategory(Enum):
    """Grouping category for rules."""
    RULE_METHOD = "rule_method"  # Category 1: (rule_name, method_name)
    SOURCE_LOCATION = "source_location"  # Category 2: calltrace-based
    RULE_ONLY = "rule_only"  # Category 3: just rule_name (non-parametric rules)


class HookType(Enum):
    """Types of CVL hooks for source location extraction."""
    CALL = "CALL"
    ALL_SSTORE = "ALL_SSTORE"
    ASSERT = "ASSERT"  # For builtin rules


class SourceLocationExtractionError(Exception):
    """Raised when source location extraction fails for Category 2 rules.

    This is a fatal error - the user needs to refine the extraction logic
    or investigate why calltrace data is missing.
    """
    pass


class DuplicateViolationError(Exception):
    """Raised when multiple violations exist for the same rule+method in Category 1.

    This is a fatal error - the user needs to investigate why multiple violations
    exist for the same (rule, method) pair and potentially refine the rule.
    """
    pass


# Rule configuration mapping: rule pattern -> hook type
# These rules use Category 2 (source-location-based grouping)
CATEGORY_2_RULES: Dict[str, HookType] = {
    "stable_extcall_targets_and_selectors": HookType.CALL,
    "detect_privileged_writes": HookType.ALL_SSTORE,
    "detect_time_sensitive_writes": HookType.ALL_SSTORE,
    "failing_CALL_leads_to_revert": HookType.CALL,
    "safeCasting": HookType.ASSERT,
    "uncheckedOverflows": HookType.ASSERT,
}

# Rule prefix patterns for Category 3 (non-parametric, rule-only grouping)
# These rules have 1 violation per rule, not grouped by method or source location
CATEGORY_3_RULES: List[str] = [
    "input_validation_",
]


def get_grouping_category(rule_name: str) -> GroupingCategory:
    """Determine the grouping category for a rule.

    Category 3 rules are non-parametric (1 violation per rule, no method grouping).
    Category 2 rules need source-location-based grouping from calltraces.
    All other rules use Category 1 (rule+method).
    """
    # Check Category 3 first (non-parametric rules like input validation)
    for pattern in CATEGORY_3_RULES:
        if rule_name.startswith(pattern):
            logger.debug(f"[get_grouping_category] rule='{rule_name}' -> Category 3 (matched prefix '{pattern}')")
            return GroupingCategory.RULE_ONLY
    # Check Category 2 (source-location-based)
    for pattern in CATEGORY_2_RULES.keys():
        if pattern in rule_name:
            logger.debug(f"[get_grouping_category] rule='{rule_name}' -> Category 2 (matched pattern '{pattern}')")
            return GroupingCategory.SOURCE_LOCATION
    # Default: Category 1 (rule+method)
    logger.debug(f"[get_grouping_category] rule='{rule_name}' -> Category 1 (no pattern match)")
    return GroupingCategory.RULE_METHOD


def get_hook_type(rule_name: str) -> Optional[HookType]:
    """Get the hook type for a Category 2 rule.

    Returns None if the rule is not a Category 2 rule.
    """
    for pattern, hook_type in CATEGORY_2_RULES.items():
        if pattern in rule_name:
            return hook_type
    return None


@dataclass
class GroupingKey:
    """Key used for grouping violations.

    For Category 1: Uses rule_name + method_name
    For Category 2: Uses rule_name + source_location
    """
    rule_name: str
    method_name: Optional[str] = None  # For Category 1
    source_location: Optional[SourceLocation] = None  # For Category 2

    @property
    def key_tuple(self) -> Tuple[str, str]:
        """Return a tuple suitable for hashing/comparison."""
        if self.method_name is not None:
            return (self.rule_name, self.method_name)
        elif self.source_location is not None:
            return (self.rule_name, self.source_location.location_key)
        raise ValueError("GroupingKey must have either method_name or source_location")

    def __hash__(self) -> int:
        return hash(self.key_tuple)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, GroupingKey):
            return False
        return self.key_tuple == other.key_tuple


class CalltraceSourceExtractor:
    """Extracts source locations from calltraces based on hook type.

    Used for Category 2 rules that need to group violations by the
    source location of specific CVL hooks (CALL, SSTORE, etc.).
    """

    def __init__(self, trace_extractor: Any):
        """Initialize with a TraceExtractor instance.

        Args:
            trace_extractor: TraceExtractor from extractors module with api and job_url
        """
        self.trace_extractor = trace_extractor

    def extract_hook_source_location(
        self,
        check: CheckResult,
        hook_type: HookType,
        rule_name: str,
    ) -> SourceLocation:
        """Extract source location from calltrace based on the hook type.

        For CALL hooks: Find the CALL instruction node
        For ALL_SSTORE hooks: Find the SSTORE instruction node
        For ASSERT hooks: Use the assert's source location directly

        Args:
            check: The CheckResult to extract location from
            hook_type: The type of hook to look for
            rule_name: Name of the rule (for error messages)

        Returns:
            SourceLocation for the relevant hook

        Raises:
            SourceLocationExtractionError: If extraction fails
        """
        logger.debug(
            f"[extract_hook_source_location] START rule='{rule_name}' hook_type={hook_type.value} method='{check.method_name}'"
        )

        if hook_type == HookType.ASSERT:
            # Builtin rules - use the prover's assert location
            logger.debug("[extract_hook_source_location] Using ASSERT path (builtin rule)")
            result = self._extract_assert_location(check, rule_name)
            logger.debug(f"[extract_hook_source_location] ASSERT result: {result}")
            return result

        # Get calltrace data
        logger.debug("[extract_hook_source_location] Fetching calltrace data...")
        calltrace_data = self._get_calltrace_data(check)
        if calltrace_data is None:
            logger.debug("[extract_hook_source_location] ERROR: No calltrace data available")
            raise SourceLocationExtractionError(
                f"No calltrace data available for rule '{rule_name}' "
                f"on method '{check.method_name}'. "
                f"Check that the job has output files with calltrace data."
            )

        logger.debug(f"[extract_hook_source_location] Got calltrace data, keys: {list(calltrace_data.keys()) if isinstance(calltrace_data, dict) else type(calltrace_data)}")

        if hook_type == HookType.CALL:
            logger.debug("[extract_hook_source_location] Using CALL hook extraction")
            result = self._extract_call_hook_location(calltrace_data, check, rule_name)
            logger.debug(f"[extract_hook_source_location] CALL result: {result}")
            return result
        elif hook_type == HookType.ALL_SSTORE:
            logger.debug("[extract_hook_source_location] Using SSTORE hook extraction")
            result = self._extract_sstore_hook_location(calltrace_data, check, rule_name)
            logger.debug(f"[extract_hook_source_location] SSTORE result: {result}")
            return result

        raise SourceLocationExtractionError(
            f"Unknown hook type '{hook_type}' for rule '{rule_name}'"
        )

    def _get_calltrace_data(self, check: CheckResult) -> Optional[Dict[str, Any]]:
        """Get raw calltrace data from the API.

        Returns the callTrace dict from the prover output, or None if unavailable.
        """
        logger.debug(f"[_get_calltrace_data] check.output_files={check.output_files}")
        if not check.output_files:
            logger.debug("[_get_calltrace_data] No output files, returning None")
            return None

        try:
            output_file = check.output_files[0]
            logger.debug(f"[_get_calltrace_data] Fetching calltrace for output_file='{output_file}'")
            calltrace = self.trace_extractor.api.get_calltrace(
                self.trace_extractor.job_url, output_file
            )
            logger.debug(f"[_get_calltrace_data] Got calltrace object, has trace_data={hasattr(calltrace, 'trace_data')}")
            if hasattr(calltrace, 'trace_data') and calltrace.trace_data:
                trace_data = calltrace.trace_data
                logger.debug(f"[_get_calltrace_data] trace_data type={type(trace_data)}")
                if isinstance(trace_data, dict):
                    logger.debug(f"[_get_calltrace_data] trace_data keys={list(trace_data.keys())}")
                    if "callTrace" in trace_data:
                        logger.debug("[_get_calltrace_data] Found 'callTrace' key, returning data")
                        return trace_data["callTrace"]
                    else:
                        logger.debug("[_get_calltrace_data] No 'callTrace' key in trace_data")
        except Exception as e:
            logger.debug(f"[_get_calltrace_data] Exception: {e}")
        logger.debug("[_get_calltrace_data] Returning None")
        return None

    def _extract_assert_location(
        self, check: CheckResult, rule_name: str
    ) -> SourceLocation:
        """Extract source location for builtin assert rules (safeCasting, uncheckedOverflows).

        These rules use the prover's built-in source location tracking.
        Falls back to parsing location from assert_message if source_location is not set.
        """
        if check.source_location:
            if hasattr(check.source_location, 'file') and hasattr(check.source_location, 'line'):
                pou_loc = check.source_location
                start_line = pou_loc.line if pou_loc.line is not None else 0
                end_line = pou_loc.end_line if pou_loc.end_line is not None else start_line
                return SourceLocation(
                    file_path=pou_loc.file,
                    start_line=start_line,
                    end_line=end_line,
                )
            elif isinstance(check.source_location, str):
                # Try to parse string format like "file.sol:42-45"
                loc = self._parse_source_location_string(check.source_location)
                if loc:
                    return loc

        # Fallback: try to extract location from assert_message
        # Format: "safe casting from uint256 to uint128 at Moolah.sol:292:23"
        if check.assert_message:
            loc = self._parse_location_from_message(check.assert_message)
            if loc:
                return loc

        raise SourceLocationExtractionError(
            f"No source location available for builtin rule '{rule_name}' "
            f"on method '{check.method_name}'. "
            f"The prover did not provide source_location for this check."
        )

    def _parse_location_from_message(self, message: str) -> Optional[SourceLocation]:
        """Parse source location from assert message text.

        Handles formats like:
        - "safe casting from uint256 to uint128 at Moolah.sol:292:23"
        - "overflow at Contract.sol:100:5"
        """
        import re
        # Match pattern: "at <file>.sol:<line>:<col>" or "at <file>.sol:<line>"
        match = re.search(r'at\s+(\S+\.sol):(\d+)(?::(\d+))?', message)
        if match:
            file_path = match.group(1)
            line = int(match.group(2))
            return SourceLocation(
                file_path=file_path,
                start_line=line,
                end_line=line,
            )
        return None

    def _parse_source_location_string(self, location_str: str) -> Optional[SourceLocation]:
        """Parse a source location string like 'file.sol:10-15'."""
        if not location_str or ':' not in location_str:
            return None

        try:
            parts = location_str.rsplit(':', 1)
            file_path = parts[0]
            line_info = parts[1]

            if '-' in line_info:
                start, end = line_info.split('-', 1)
                start_line = int(start.split(':')[0])
                end_line = int(end.split(':')[0])
            else:
                start_line = int(line_info.split(':')[0])
                end_line = start_line

            return SourceLocation(
                file_path=file_path,
                start_line=start_line,
                end_line=end_line
            )
        except (ValueError, IndexError):
            return None

    def _extract_call_hook_location(
        self,
        calltrace: Dict[str, Any],
        check: CheckResult,
        rule_name: str,
    ) -> SourceLocation:
        """Extract the source location of a CALL instruction from calltrace.

        Walks the calltrace looking for external call nodes and returns
        the jumpToDefinition of the first one found (for failing_CALL_leads_to_revert)
        or the one enclosing the failing assert.
        """
        location = self._find_call_instruction_location(calltrace)
        if location is None:
            raise SourceLocationExtractionError(
                f"Could not find CALL instruction location in calltrace for "
                f"rule '{rule_name}' on method '{check.method_name}'. "
                f"The calltrace may not contain external call information."
            )
        return location

    def _extract_sstore_hook_location(
        self,
        calltrace: Dict[str, Any],
        check: CheckResult,
        rule_name: str,
    ) -> SourceLocation:
        """Extract the source location of an SSTORE instruction from calltrace.

        Walks the calltrace looking for storage write operations.
        """
        location = self._find_sstore_instruction_location(calltrace)
        if location is None:
            raise SourceLocationExtractionError(
                f"Could not find SSTORE instruction location in calltrace for "
                f"rule '{rule_name}' on method '{check.method_name}'. "
                f"The calltrace may not contain storage write information."
            )
        return location

    def _find_call_instruction_location(
        self, node: Dict[str, Any], enclosing_call_location: Optional[SourceLocation] = None, depth: int = 0
    ) -> Optional[SourceLocation]:
        """Recursively find CALL instruction that encloses the failing assert.

        The failing assert is a descendant of the CALL hook node.
        We track the most recent CALL ancestor and return its location when we find an assert.
        """
        indent = "  " * depth
        current_location = self._extract_node_location(node)

        msg = node.get("message", {})
        text = msg.get("text", "") if isinstance(msg, dict) else str(msg) if msg else ""

        logger.debug(f"{indent}[_find_call] text='{text[:80] if text else '<empty>'}' current_loc={current_location}")

        # Check if this node represents a CALL instruction - update the enclosing location
        call_patterns = ["CALL(", "DELEGATECALL(", "STATICCALL(", "call(", "delegatecall(", "staticcall("]
        is_call_node = any(pattern in text for pattern in call_patterns)

        if is_call_node and current_location:
            logger.debug(f"{indent}[_find_call] MATCHED CALL pattern, updating enclosing_call_location")
            enclosing_call_location = current_location

        # Check if this node is a failing assert - if so, return the enclosing CALL location
        assert_patterns = ["assert", "Assert", "ASSERT", "require", "Require"]
        is_assert_node = any(pattern in text for pattern in assert_patterns)

        if is_assert_node and enclosing_call_location:
            logger.debug(f"{indent}[_find_call] Found ASSERT node enclosed by CALL, returning: {enclosing_call_location}")
            return enclosing_call_location

        # Recurse into children IN REVERSE ORDER (last child first)
        # The failing assert is the last node in the execution trace
        children = node.get("childrenList", [])
        logger.debug(f"{indent}[_find_call] Recursing into {len(children)} children (reverse order)")
        for child in reversed(children):
            if isinstance(child, dict):
                result = self._find_call_instruction_location(child, enclosing_call_location, depth + 1)
                if result:
                    return result

        # If we're at the root and have an enclosing call but didn't find an assert,
        # return the call location anyway (fallback for failing_CALL_leads_to_revert)
        if depth == 0 and enclosing_call_location:
            logger.debug(f"[_find_call] Fallback: returning first CALL location found: {enclosing_call_location}")
            return enclosing_call_location

        return None

    def _find_sstore_instruction_location(
        self, node: Dict[str, Any], enclosing_sstore_location: Optional[SourceLocation] = None, depth: int = 0
    ) -> Optional[SourceLocation]:
        """Recursively find SSTORE instruction that encloses the failing assert.

        The failing assert is a descendant of the SSTORE hook node.
        We track the most recent SSTORE ancestor and return its location when we find an assert.
        """
        indent = "  " * depth
        current_location = self._extract_node_location(node)

        msg = node.get("message", {})
        text = msg.get("text", "") if isinstance(msg, dict) else str(msg) if msg else ""

        logger.debug(f"{indent}[_find_sstore] text='{text[:80] if text else '<empty>'}' current_loc={current_location}")

        # Check if this node represents an SSTORE instruction - update the enclosing location
        sstore_patterns = ["SSTORE", "sstore", "storage write", "Storage write", "ALL_SSTORE"]
        is_sstore_node = any(pattern in text for pattern in sstore_patterns)

        # Also check for assignment patterns that might indicate storage writes
        if not is_sstore_node and "=" in text and "[" in text:
            is_sstore_node = True
            logger.debug(f"{indent}[_find_sstore] Detected assignment pattern as potential SSTORE")

        if is_sstore_node and current_location:
            logger.debug(f"{indent}[_find_sstore] MATCHED SSTORE pattern, updating enclosing_sstore_location")
            enclosing_sstore_location = current_location

        # Check if this node is a failing assert - if so, return the enclosing SSTORE location
        assert_patterns = ["assert", "Assert", "ASSERT", "require", "Require"]
        is_assert_node = any(pattern in text for pattern in assert_patterns)

        if is_assert_node and enclosing_sstore_location:
            logger.debug(f"{indent}[_find_sstore] Found ASSERT node enclosed by SSTORE, returning: {enclosing_sstore_location}")
            return enclosing_sstore_location

        # Recurse into children IN REVERSE ORDER (last child first)
        # The failing assert is the last node in the execution trace
        children = node.get("childrenList", [])
        logger.debug(f"{indent}[_find_sstore] Recursing into {len(children)} children (reverse order)")
        for child in reversed(children):
            if isinstance(child, dict):
                result = self._find_sstore_instruction_location(child, enclosing_sstore_location, depth + 1)
                if result:
                    return result

        return None

    def _extract_node_location(self, node: Dict[str, Any]) -> Optional[SourceLocation]:
        """Extract SourceLocation from a calltrace node's jumpToDefinition.

        Only returns locations for Solidity files (.sol).
        """
        jump = node.get("jumpToDefinition")
        if not jump:
            return None

        file_path = jump.get("file", "")
        if not file_path or not file_path.endswith(".sol"):
            return None

        start = jump.get("start", {})
        line = start.get("line", 0)

        if not line:
            return None

        return SourceLocation(
            file_path=file_path,
            start_line=line,
            end_line=line,
        )


class GroupingStrategy(ABC):
    """Base class for violation grouping strategies."""

    @abstractmethod
    def group_violations(
        self,
        rule_name: str,
        checks: List[CheckResult],
    ) -> Dict[GroupingKey, List[CheckResult]]:
        """Group violations according to the strategy.

        Args:
            rule_name: Name of the rule being processed
            checks: List of violated checks to group

        Returns:
            Dictionary mapping GroupingKey to list of checks in that group

        Raises:
            DuplicateViolationError: For Category 1 if duplicates found
            SourceLocationExtractionError: For Category 2 if extraction fails
        """
        pass


class RuleMethodGroupingStrategy(GroupingStrategy):
    """Category 1: Group by (rule_name, method_name).

    Each unique (rule, method) pair should have exactly one violation.
    Raises DuplicateViolationError if multiple violations exist for the same pair.
    """

    def group_violations(
        self,
        rule_name: str,
        checks: List[CheckResult],
    ) -> Dict[GroupingKey, List[CheckResult]]:
        """Group checks by method name, crash on duplicates."""
        logger.debug(f"[RuleMethodGroupingStrategy] START rule='{rule_name}' num_checks={len(checks)}")
        groups: Dict[str, Tuple[GroupingKey, List[CheckResult]]] = {}

        for check in checks:
            method_name = check.method_only or check.method_name or "<unknown>"
            logger.debug(f"[RuleMethodGroupingStrategy] Processing check: method='{method_name}'")

            if method_name in groups:
                # Found a duplicate - this is an error
                _, existing_checks = groups[method_name]
                logger.debug(f"[RuleMethodGroupingStrategy] ERROR: Duplicate method '{method_name}' found!")
                raise DuplicateViolationError(
                    f"Multiple violations found for rule '{rule_name}' "
                    f"and method '{method_name}'. "
                    f"Found {len(existing_checks) + 1} violations. "
                    f"This rule uses Category 1 grouping (rule+method), which expects "
                    f"at most one violation per method. Please investigate why multiple "
                    f"violations exist or refine the grouping strategy for this rule."
                )

            key = GroupingKey(rule_name=rule_name, method_name=method_name)
            groups[method_name] = (key, [check])
            logger.debug(f"[RuleMethodGroupingStrategy] Added group for method='{method_name}'")

        logger.debug(f"[RuleMethodGroupingStrategy] END returning {len(groups)} groups")
        return {g[0]: g[1] for g in groups.values()}


class SourceLocationGroupingStrategy(GroupingStrategy):
    """Category 2: Group by source location extracted from calltraces.

    Multiple violations at the same source location are grouped together.
    Raises SourceLocationExtractionError if location cannot be determined.
    """

    def __init__(self, source_extractor: CalltraceSourceExtractor, hook_type: HookType):
        """Initialize with extractor and hook type.

        Args:
            source_extractor: CalltraceSourceExtractor for extracting locations
            hook_type: Type of hook to look for in calltraces
        """
        self.source_extractor = source_extractor
        self.hook_type = hook_type

    def group_violations(
        self,
        rule_name: str,
        checks: List[CheckResult],
    ) -> Dict[GroupingKey, List[CheckResult]]:
        """Group checks by extracted source location."""
        logger.debug(
            f"[SourceLocationGroupingStrategy] START rule='{rule_name}' hook_type={self.hook_type.value} num_checks={len(checks)}"
        )
        groups: Dict[str, Tuple[GroupingKey, List[CheckResult]]] = {}

        for i, check in enumerate(checks):
            logger.debug(
                f"[SourceLocationGroupingStrategy] Processing check {i + 1}/{len(checks)}: method='{check.method_name}'"
            )
            # Extract source location from calltrace - may raise
            source_location = self.source_extractor.extract_hook_source_location(
                check, self.hook_type, rule_name
            )

            location_key = source_location.location_key
            logger.debug(f"[SourceLocationGroupingStrategy] Extracted location_key='{location_key}'")

            if location_key in groups:
                # Same location - add to existing group
                groups[location_key][1].append(check)
                logger.debug(f"[SourceLocationGroupingStrategy] Added to existing group (now {len(groups[location_key][1])} checks)")
            else:
                # New location - create new group
                key = GroupingKey(rule_name=rule_name, source_location=source_location)
                groups[location_key] = (key, [check])
                logger.debug("[SourceLocationGroupingStrategy] Created new group for location")

        logger.debug(f"[SourceLocationGroupingStrategy] END returning {len(groups)} groups")
        return {g[0]: g[1] for g in groups.values()}


class GroupingStrategyFactory:
    """Factory for creating appropriate grouping strategies.

    Determines the correct strategy based on rule name and provides
    the necessary dependencies for source location extraction.
    """

    def __init__(self, trace_extractor: Any):
        """Initialize with a TraceExtractor.

        Args:
            trace_extractor: TraceExtractor instance from extractors module
        """
        self.trace_extractor = trace_extractor
        self.source_extractor = CalltraceSourceExtractor(trace_extractor)

    def get_strategy(self, rule_name: str) -> GroupingStrategy:
        """Get the appropriate grouping strategy for a rule.

        Args:
            rule_name: Name of the rule

        Returns:
            GroupingStrategy instance appropriate for the rule

        Raises:
            ValueError: If rule is Category 2 but has no configured hook type
        """
        category = get_grouping_category(rule_name)

        if category == GroupingCategory.SOURCE_LOCATION:
            hook_type = get_hook_type(rule_name)
            if hook_type is None:
                raise ValueError(
                    f"Rule '{rule_name}' is configured as Category 2 (source-location) "
                    f"but has no hook type configured in CATEGORY_2_RULES"
                )
            return SourceLocationGroupingStrategy(self.source_extractor, hook_type)

        return RuleMethodGroupingStrategy()
