"""
Reporting module for generic checker output processing.

This module provides structured output processing for checker results,
generating findings with:
- Problem location from source maps
- List of failure contexts (violating methods)
- AI-based text feedback
- Confidence scores (0-100)

Usage:
    from generic_checkers.reporting import CheckerOutputProcessor

    processor = CheckerOutputProcessor(job_url)

    # Analyze the job to see what's present
    analysis = processor.analyze_job()
    print(f"Detected checkers: {analysis.checker_types_present}")
    print(f"Checkers with violations: {analysis.checker_types_with_violations}")
"""

from .analyzer import AIViolationAnalyzer
from .base.checker_type import CheckerType
from .base.interfaces import CheckerModule, RuleMatcher
from .base.models import (
    CheckerFinding,
    CheckerReport,
    ConfidenceLevel,
    DefectVerdict,
    FailureContext,
    FinalFeedback,
    SourceLocation,
)
from .checkers import (
    ALL_CHECKERS,
    CHECKER_REGISTRY,
    ExternalCallChecker,
    GenericChecker,
    PrivilegedOperationsChecker,
    get_all_matchers,
    get_checker,
)
from .checkers.external_call import ExternalCallMatcher
from .checkers.generic import GenericMatcher
from .checkers.privileged_operations import PrivilegedOperationsMatcher
from .extractors import JobDataExtractor, SourceMapExtractor, TraceExtractor
from .processor import CheckerOutputProcessor, DetectedChecker, JobAnalysis

__all__ = [
    # Enums
    "CheckerType",
    "DefectVerdict",
    "ConfidenceLevel",
    # Models
    "SourceLocation",
    "FailureContext",
    "FinalFeedback",
    "CheckerFinding",
    "CheckerReport",
    # Interfaces
    "RuleMatcher",
    "CheckerModule",
    # Checker Modules
    "ExternalCallChecker",
    "PrivilegedOperationsChecker",
    "GenericChecker",
    "ALL_CHECKERS",
    "CHECKER_REGISTRY",
    "get_checker",
    "get_all_matchers",
    # Matchers
    "ExternalCallMatcher",
    "PrivilegedOperationsMatcher",
    "GenericMatcher",
    # Extractors
    "JobDataExtractor",
    "SourceMapExtractor",
    "TraceExtractor",
    # Analyzer
    "AIViolationAnalyzer",
    # Processor
    "CheckerOutputProcessor",
    "DetectedChecker",
    "JobAnalysis",
]
