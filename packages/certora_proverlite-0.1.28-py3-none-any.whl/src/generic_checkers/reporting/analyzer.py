"""
AI-based violation analyzer for checker output processing.

Integrates with AI Composer's analyze_with_calltraces for deep AI analysis.
"""

from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterator, List, Literal, Optional, Tuple

from analyzer.analysis import ecosystem_params  # type: ignore[import-not-found]
from analyzer.types import Ecosystem  # type: ignore[import-not-found]
from jinja2 import Environment, FileSystemLoader
from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]
from pydantic import BaseModel, Field

from src.dashboard.constants import DIR_CERTORA_INTERNAL, DIR_TARBALL_CACHE
from src.dashboard.tarball_manager import download_tarball, extract_from_tarball
from src.dashboard.utils.analyze_violations import extract_job_id_from_url
from src.utils.logger import logger

from .base.checker_type import CheckerType
from .base.models import FinalFeedback, IssueClassification
from .cache import AnalysisCache, get_global_cache
from .cached_analysis import analyze_with_calltraces_cached
from .token_usage import AnalysisPhase
from .calltrace_code_extractor import CodeLocation, read_code_snippets
from .defect_aggregator import compute_confidence_score
from .retry_utils import is_fatal_api_error, retry_on_api_errors
from src.utils.rag_config import get_default_rag_db

# Analysis configuration constants
DEFAULT_RECURSION_LIMIT = 30
SATISFY_RECURSION_LIMIT = 60


class BehaviorSummary(BaseModel):
    """Step 1: English summary of calltrace behavior.

    Generated once per rule (cached), describes what the
    Certora prover detected in the calltraces.
    """

    execution_trace: str = Field(
        description="What happens in this counterexample: the scenario, code path "
        "(functions called and sequence), and inputs/parameters with concrete values."
    )

    state_impact: str = Field(
        description="Effects of this execution: state modifications (storage changes, balance updates) "
        "and which parts of the counterexample are security-relevant vs. noise."
    )

    def to_prose(self) -> str:
        """Convert to prose summary for Step 2 consumption."""
        return f"""## Behavior Summary

### Execution Trace
{self.execution_trace}

### State Impact
{self.state_impact}
"""


class IterationResult(BaseModel):
    """Step 2: Single iteration's defect classification.

    Run N times (--iterations), each producing an independent
    verdict + confidence evaluation.
    """

    is_defect: Literal["YES", "NO"] = Field(description="Does this behavior indicate a real defect? YES or NO.")

    confidence: Literal["HIGH", "LOW"] = Field(description="How confident are you? HIGH or LOW.")

    reasoning: str = Field(
        description="Integrated analysis explaining your verdict. State your conclusion, "
        "cite key evidence, and acknowledge any counter-arguments or uncertainties."
    )

    recommendation: str = Field(
        default="",
        description="If IS_DEFECT is YES, provide a concrete fix recommendation. "
        "If IS_DEFECT is NO, leave empty or state 'No fix needed.'",
    )

    def to_outcome_code(self) -> Literal["YH", "YL", "NH", "NL"]:
        """Convert to DefectAggregator outcome code (YH, YL, NH, NL)."""
        if self.is_defect == "YES":
            return "YH" if self.confidence == "HIGH" else "YL"
        else:
            return "NH" if self.confidence == "HIGH" else "NL"

    def to_markdown(self) -> str:
        """Convert to markdown format for reports."""
        md = f"""## IS_DEFECT: {self.is_defect}

## CONFIDENCE: {self.confidence}

## REASONING
{self.reasoning}
"""
        if self.recommendation and self.recommendation.strip():
            md += f"""
## RECOMMENDATION
{self.recommendation}
"""
        return md


@dataclass
class CheckerAnalysisArgs:
    """Implementation of AnalysisArgs Protocol for checker reporting."""

    folder: str
    rule: str
    method: Optional[str] = None
    quiet: bool = True
    recursion_limit: int = DEFAULT_RECURSION_LIMIT
    thread_id: Optional[str] = None
    checkpoint_id: Optional[str] = None
    thinking_tokens: int = 2048
    tokens: int = 4096
    ecosystem: Ecosystem = "evm"
    rag_db: str = ""  # Resolved at construction time; empty means use get_default_rag_db()

    def __post_init__(self):
        if not self.rag_db:
            self.rag_db = get_default_rag_db()


class AIViolationAnalyzer:
    """Analyzes violations using AI Composer's deep analysis."""

    def __init__(
        self,
        job_url: Optional[str] = None,
        extracted_dir: Optional[Path] = None,
        debug_recorder=None,
        use_cache: bool = True,
        use_retry: bool = True,
        cache: Optional[AnalysisCache] = None,
        iteration_index: Optional[int] = None,
        ext_logger=None,
        progress=None,
        precomputed_snippets: Optional[str] = None,
        rag_db: Optional[str] = None,
        checker_type: Optional[CheckerType] = None,
    ):
        """
        Initialize the analyzer.

        Args:
            job_url: The Certora prover job URL (for downloading report)
            extracted_dir: Optional path to already-extracted report directory
            debug_recorder: Optional DebugRecorder for crash dumps
            use_cache: Whether to use caching for analysis results (default: True)
            use_retry: Whether to use retry logic for API calls (default: True)
            cache: Optional custom cache instance (uses global cache if None)
            iteration_index: Optional iteration index for multi-analysis (included in cache key)
            progress: Optional tqdm progress bar for logging via tqdm.write()
            precomputed_snippets: Optional pre-extracted code snippets from Step 1.5
            rag_db: RAG database path (ChromaDB dir) or PostgreSQL connection string
            checker_type: Optional checker type for template resolution (e.g., AUTOCVL)
        """
        self.job_url = job_url
        self.extracted_dir = extracted_dir
        self.debug_recorder = debug_recorder
        self.use_cache = use_cache
        self.use_retry = use_retry
        self.cache = cache if cache is not None else get_global_cache()
        self.iteration_index = iteration_index
        self.ext_logger = ext_logger
        self.progress = progress
        self.precomputed_snippets = precomputed_snippets
        self.rag_db = rag_db if rag_db is not None else get_default_rag_db()
        self.checker_type = checker_type
        self.prompts_dir = Path(__file__).parent.parent.parent / "prompts"

    @contextmanager
    def _download_report(self, job_url: str) -> Iterator[Path]:
        """
        Download and extract Certora report from job URL, with caching.

        Uses tarball_manager for cached downloads (in .certora_internal/tarball_cache/)
        and cached extraction (in .certora_internal/extracted_tars/).

        Yields:
            Path to the extracted report directory
        """
        tarball_cache_dir = Path(DIR_CERTORA_INTERNAL) / DIR_TARBALL_CACHE
        tarball_cache_dir.mkdir(parents=True, exist_ok=True)

        job_id = extract_job_id_from_url(job_url)

        tarball_path = download_tarball(job_id, job_url, tarball_cache_dir)
        if tarball_path is None:
            raise RuntimeError(f"Failed to download report from {job_url}")

        extraction_base = Path(DIR_CERTORA_INTERNAL)
        extract_dir = extract_from_tarball(tarball_path, job_id, extraction_base, subpath="")
        if extract_dir is None:
            raise RuntimeError(f"Failed to extract report for {job_url}")

        yield extract_dir

    def _get_template_base_name(self, rule_name: str, checker_type: CheckerType | None = None) -> str:
        """
        Get the base template name for a rule (without directory or extension).

        Maps rule names to template base names for both calltrace_analysis and
        defect_analysis subdirectories.

        Args:
            rule_name: The name of the rule (e.g., "privilegedOperation", "safeCasting")
            checker_type: If provided, used for direct template resolution (e.g., AUTOCVL -> "autocvl")

        Returns:
            Base template name (e.g., "privilegedOperation", "input_validation")

        Raises:
            ValueError: If no template mapping exists for the rule
        """
        if checker_type == CheckerType.AUTOCVL:
            return "autocvl"
        # Direct mappings for standard rules
        direct_mappings = {
            "privilegedOperation": "privilegedOperation",
            "safeCasting": "safeCasting",
            "viewReentrancy": "viewReentrancy",
            "stable_extcall_targets_and_selectors": "stable_extcall_targets_and_selectors",
            "msg_value_in_loop": "msg_value_in_loop",
            "nonGettersThatNeverRevert": "nonGettersThatNeverRevert",
            "detect_privileged_writes": "detect_privileged_writes",
            "detect_time_sensitive_writes": "detect_time_sensitive_writes",
            "failing_CALL_leads_to_revert": "failing_CALL_leads_to_revert",
        }

        # Check direct mapping first
        if rule_name in direct_mappings:
            return direct_mappings[rule_name]

        # Pattern matching for auto-generated rules
        if rule_name.startswith("input_validation_"):
            return "input_validation"

        # Pattern matching for generic rules
        if rule_name.startswith("oneTimeFunction"):
            return "oneTimeFunction"
        if "SelfCalls" in rule_name or "selfCalls" in rule_name:
            return "selfCalls"

        # No template found - fail fast
        raise ValueError(
            f"No analysis template found for rule '{rule_name}'. "
            f"Add a template mapping in _get_template_base_name()."
        )

    def _load_prompt_template(self, template_name: str, ecosystem: Ecosystem = "evm", **extra_params) -> str:
        """
        Load and render a Jinja2 prompt template.

        Args:
            template_name: Name of the template file (e.g., "privileged_operations_calltrace_analysis.j2")
            ecosystem: Ecosystem type for rendering template variables
            **extra_params: Additional parameters for template rendering (e.g., has_calltraces)

        Returns:
            Rendered prompt string
        """
        # Load the template
        env = Environment(loader=FileSystemLoader(str(self.prompts_dir)))
        template = env.get_template(template_name)

        # Get ecosystem parameters (copy since EcosystemConfig is a TypedDict)
        params = dict(ecosystem_params.get(ecosystem, ecosystem_params["evm"]))

        # Merge extra parameters
        params.update(extra_params)

        # Render the template
        return template.render(**params)

    def _extract_code_snippets(self, traces: List[Dict[str, Any]], report_dir: Path) -> Optional[str]:
        """
        Extract code snippets from calltrace locations.

        Uses precomputed snippets if available (from Step 1.5 pre-scan),
        otherwise extracts from disk.

        Args:
            traces: List of trace data (includes XML calltraces with locations)
            report_dir: Path to extracted report directory

        Returns:
            Formatted markdown string with code snippets, or None if no snippets
        """
        # Use precomputed snippets if available (from Step 1.5)
        if self.precomputed_snippets is not None:
            return self.precomputed_snippets if self.precomputed_snippets else None

        # Otherwise extract from disk
        all_locations: List[CodeLocation] = []
        for trace in traces:
            if trace.get("type") == "calltrace_xml":
                locations = trace.get("locations", [])
                if locations:
                    all_locations.extend(locations)

        if not all_locations:
            return None

        return read_code_snippets(all_locations, str(report_dir)) or None

    def _run_calltrace_analysis(
        self,
        checks: List[CheckResult],
        rule_name: str,
        traces: List[Dict[str, Any]],
        report_dir: Path,
        code_snippets: Optional[str],
    ) -> Tuple[str, str]:
        """
        Step 1: Analyze calltrace and produce English behavior description.

        This is run ONCE and cached (without iteration_index in cache key).
        The result is fed to Step 2.

        Args:
            checks: List of violated check results
            rule_name: Name of the rule that was violated
            traces: List of trace data (includes XML calltraces)
            report_dir: Path to extracted report directory
            code_snippets: Pre-extracted code snippets from calltrace locations

        Returns:
            Tuple of (behavior_summary, source_info) where behavior_summary is
            the English description of the behavior and source_info is "cache" or "api"
        """
        if not self.job_url:
            raise RuntimeError("No job URL provided for calltrace analysis")

        # Collect XML calltraces from traces
        xml_calltraces: List[str] = []
        for trace in traces:
            if trace.get("type") == "calltrace_xml":
                xml_str = trace.get("xml")
                if xml_str:
                    xml_calltraces.append(xml_str)

        # Check if this is a satisfy rule
        is_satisfy_rule = rule_name.startswith("oneTimeFunction")

        if not xml_calltraces and not is_satisfy_rule:
            raise RuntimeError(f"No calltraces available for rule '{rule_name}'")

        # Load Step 1 template from prompts/calltrace_analysis/
        template_base = self._get_template_base_name(rule_name, checker_type=self.checker_type)
        template_name = f"calltrace_analysis/{template_base}.j2"
        initial_prompt = self._load_prompt_template(template_name, ecosystem="evm", has_calltraces=bool(xml_calltraces))

        # Build input messages
        if not xml_calltraces and is_satisfy_rule:
            # Satisfy rule failed - no counterexample exists
            contracts = sorted(
                set(c.contract_name for c in checks if c.contract_name and c.contract_name != "unknown_contract")
            )
            methods = sorted(set(c.method_name for c in checks if c.method_name))

            input_messages = [
                f"The satisfy rule '{rule_name}' FAILED (no satisfying model found).",
                f"Violating methods: {', '.join(methods)}",
            ]

            if contracts:
                input_messages.append(f"Contracts: {', '.join(contracts)}")

            input_messages.append("Analyze the function signatures and patterns to describe the behavior.")
        else:
            # Normal calltrace-based analysis
            input_messages = [
                f"The individual rule that was checked by the prover was {rule_name}",
            ]
            input_messages.extend(xml_calltraces)

        # Create analysis args
        args = CheckerAnalysisArgs(
            folder=str(report_dir),
            rule=rule_name,
            quiet=True,
            ecosystem="evm",
            rag_db=self.rag_db,
            recursion_limit=SATISFY_RECURSION_LIMIT,
        )

        # Record AI inputs for debugging
        if self.debug_recorder:
            self.debug_recorder.record_ai_input(
                rule_name=f"{rule_name}_step1",
                prompt=initial_prompt,
                xmls=xml_calltraces,
                report_dir=str(report_dir),
                rag_db=self.rag_db,
            )

        # Build violation info for logging
        method_names = sorted(set(c.method_only or c.method_name or "?" for c in checks))
        violation_info = f"methods: {', '.join(method_names)}"

        def call_calltrace_analysis():
            assert self.job_url is not None
            # Step 1 cache key: NO iteration_index (cached once)
            exit_code, analysis_result, source_file = analyze_with_calltraces_cached(
                input_messages=input_messages,
                initial_prompt=initial_prompt,
                args=args,
                job_url=self.job_url,
                rule_name=rule_name,
                phase=AnalysisPhase.CALLTRACE_ANALYSIS,
                model_name="claude-sonnet-4.5",
                use_cache=self.use_cache,
                cache=self.cache,
                iteration_index=None,  # Step 1 is always cached without iteration
                ext_logger=self.ext_logger,
                progress=self.progress,
                output_type=BehaviorSummary,
                violation_info=violation_info,
                code_snippets=code_snippets,
            )

            if self.debug_recorder:
                self.debug_recorder.record_ai_output(
                    rule_name=f"{rule_name}_step1", result=analysis_result, exit_code=exit_code
                )

            if exit_code != 0 or not analysis_result:
                raise RuntimeError(f"Step 1 analysis failed with exit code {exit_code}")

            return analysis_result, source_file

        # Call with or without retry
        if self.use_retry:
            call_calltrace_analysis = retry_on_api_errors(
                max_attempts=3, log_func=lambda msg: logger.debug(f"  {msg}")
            )(call_calltrace_analysis)

        analysis_result, source_file = call_calltrace_analysis()

        # Parse structured result and convert to behavior summary
        result = BehaviorSummary.model_validate_json(analysis_result)
        behavior_summary = result.to_prose()

        return behavior_summary, source_file

    def _run_defect_analysis(
        self,
        behavior_summary: str,
        rule_name: str,
        report_dir: Path,
        code_snippets: Optional[str],
    ) -> IterationResult:
        """
        Step 2: Evaluate if the behavior indicates a defect.

        This is run N times (iterations), each with a different iteration_index for caching.

        Args:
            behavior_summary: English description from Step 1
            rule_name: Name of the rule that was violated
            report_dir: Path to extracted report directory
            code_snippets: Pre-extracted code snippets from calltrace locations

        Returns:
            IterationResult with is_defect (YES/NO) and confidence (HIGH/LOW)
        """
        if not self.job_url:
            raise RuntimeError("No job URL provided for defect analysis")

        # Load Step 2 template from prompts/defect_analysis/
        template_base = self._get_template_base_name(rule_name, checker_type=self.checker_type)
        template_name = f"defect_analysis/{template_base}.j2"
        initial_prompt = self._load_prompt_template(template_name, ecosystem="evm")

        # Step 2 input: behavior summary from Step 1 comes AT THE END
        # This allows better prompt caching (static prompt prefix is shared)
        input_messages = [
            f"Rule: {rule_name}",
            "## Behavior Description (from Step 1 analysis)",
            behavior_summary,
        ]

        # Create analysis args
        args = CheckerAnalysisArgs(
            folder=str(report_dir),
            rule=rule_name,
            quiet=True,
            ecosystem="evm",
            rag_db=self.rag_db,
            recursion_limit=DEFAULT_RECURSION_LIMIT,
        )

        # Record AI inputs for debugging
        if self.debug_recorder:
            self.debug_recorder.record_ai_input(
                rule_name=f"{rule_name}_step2",
                prompt=initial_prompt,
                xmls=[],
                report_dir=str(report_dir),
                rag_db=self.rag_db,
            )

        def call_defect_analysis():
            assert self.job_url is not None
            # Step 2 cache key: INCLUDES iteration_index
            exit_code, analysis_result, source_file = analyze_with_calltraces_cached(
                input_messages=input_messages,
                initial_prompt=initial_prompt,
                args=args,
                job_url=self.job_url,
                rule_name=rule_name,
                phase=AnalysisPhase.DEFECT_ANALYSIS,
                model_name="claude-sonnet-4.5",
                use_cache=self.use_cache,
                cache=self.cache,
                iteration_index=self.iteration_index,  # Step 2 is cached per-iteration
                ext_logger=self.ext_logger,
                progress=self.progress,
                output_type=IterationResult,
                violation_info=None,
                code_snippets=code_snippets,
            )

            if self.debug_recorder:
                self.debug_recorder.record_ai_output(
                    rule_name=f"{rule_name}_step2", result=analysis_result, exit_code=exit_code
                )

            if exit_code != 0 or not analysis_result:
                raise RuntimeError(f"Step 2 analysis failed with exit code {exit_code}")

            return analysis_result, source_file

        # Call with or without retry
        if self.use_retry:
            call_defect_analysis = retry_on_api_errors(
                max_attempts=3,
                log_func=lambda msg: logger.debug(f"  {msg}")
            )(call_defect_analysis)

        analysis_result, _ = call_defect_analysis()

        # Parse structured result
        return IterationResult.model_validate_json(analysis_result)

    def _run_two_step_analysis(
        self,
        checks: List[CheckResult],
        rule_name: str,
        traces: List[Dict[str, Any]],
    ) -> Tuple[FinalFeedback, int, IterationResult]:
        """
        Run the two-step analysis flow.

        Step 1: Calltrace analysis (run once, cached)
        Step 2: Defect analysis (run per iteration)

        Args:
            checks: List of violated check results
            rule_name: Name of the rule that was violated
            traces: List of trace data (includes XML calltraces)

        Returns:
            Tuple of (FinalFeedback, confidence_score, IterationResult)
        """
        if not self.job_url:
            raise RuntimeError("No job URL provided for two-step analysis")

        # Download report ONCE at the top level
        with self._download_report(self.job_url) as report_dir:
            # Extract code snippets ONCE, use in both steps
            code_snippets = self._extract_code_snippets(traces, report_dir)

            # Step 1: Get behavior summary (cached without iteration_index)
            behavior_summary, _ = self._run_calltrace_analysis(checks, rule_name, traces, report_dir, code_snippets)

            # Step 2: Run defect analysis for this iteration
            defect_result = self._run_defect_analysis(behavior_summary, rule_name, report_dir, code_snippets)

            # Convert to FinalFeedback for backward compatibility
            ai_feedback = self._convert_defect_to_ai_feedback(defect_result, behavior_summary)

            # Compute preliminary confidence score from single result
            # (Final aggregation happens in __main__.py with all iterations)
            n_yh, n_yl, n_nl, n_nh = 0, 0, 0, 0
            outcome = defect_result.to_outcome_code()
            if outcome == "YH":
                n_yh = 1
            elif outcome == "YL":
                n_yl = 1
            elif outcome == "NL":
                n_nl = 1
            elif outcome == "NH":
                n_nh = 1
            confidence_score = compute_confidence_score(n_yh, n_yl, n_nl, n_nh)

            return ai_feedback, confidence_score, defect_result

    def _convert_defect_to_ai_feedback(
        self,
        defect_result: IterationResult,
        behavior_summary: str,
    ) -> FinalFeedback:
        """
        Convert an IterationResult to FinalFeedback.

        Args:
            defect_result: Result from Step 2 defect analysis
            behavior_summary: Behavior description from Step 1

        Returns:
            FinalFeedback instance with raw_output and classification
        """
        # Map is_defect to classification
        if defect_result.is_defect == "YES":
            if defect_result.confidence == "HIGH":
                classification = IssueClassification.LIKELY_ISSUE
            else:
                classification = IssueClassification.UNCERTAIN
        else:
            if defect_result.confidence == "HIGH":
                classification = IssueClassification.LIKELY_NON_ISSUE
            else:
                classification = IssueClassification.UNCERTAIN

        # Construct raw_output from structured fields
        raw_output = f"## BEHAVIOR SUMMARY (Step 1)\n\n{behavior_summary}\n\n"
        raw_output += f"## DEFECT ANALYSIS (Step 2)\n\n"
        raw_output += defect_result.to_markdown()

        return FinalFeedback(
            raw_output=raw_output,
            classification=classification,
            behavior_summary=behavior_summary,
        )

    def analyze_violation_group_two_step(
        self,
        checks: List[CheckResult],
        rule_name: str,
        traces: List[Dict[str, Any]],
    ) -> Tuple[Optional[FinalFeedback], int, Optional[IterationResult]]:
        """
        Analyze a group of violations using the new two-step flow.

        Step 1: Calltrace analysis (run once, cached)
        Step 2: Defect analysis (YES/NO + HIGH/LOW, run per iteration)

        Args:
            checks: List of violated check results
            rule_name: Name of the rule that was violated
            traces: List of trace data (includes XML calltraces)

        Returns:
            Tuple of (FinalFeedback, confidence_score, IterationResult)
            IterationResult is None if analysis failed
        """
        try:
            ai_feedback, confidence_score, defect_result = self._run_two_step_analysis(checks, rule_name, traces)
            return ai_feedback, confidence_score, defect_result
        except Exception as e:
            # Fatal auth errors (403, 401) must propagate
            if is_fatal_api_error(e):
                import traceback

                logger.error(
                    f"Fatal API error during two-step analysis of rule '{rule_name}':\n{traceback.format_exc()}"
                )
                raise
            # Log the error but don't fail - fall back to placeholder
            logger.warning(f"Two-step AI analysis failed ({e}), using placeholder feedback")
            return self._generate_placeholder_feedback(checks, rule_name), 50, None

    def _generate_placeholder_feedback(self, checks: List[CheckResult], rule_name: str) -> FinalFeedback:
        """Generate placeholder feedback (fallback when AI analysis unavailable)."""
        method_names = [c.method_name for c in checks if c.method_name]

        raw_output = f"""## AI Analysis Unavailable

**Rule:** {rule_name}
**Methods:** {', '.join(method_names)}

AI analysis could not be performed. Review these methods manually for potential vulnerabilities.
"""

        return FinalFeedback(raw_output=raw_output, classification=IssueClassification.UNCERTAIN)
