"""
Shared interfaces for checker output processing.

Contains abstract base classes that define contracts for checker modules.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]

from .checker_type import CheckerType
from .models import SourceLocation


class RuleMatcher(ABC):
    """Base class for matching rules to their checker type."""

    @property
    @abstractmethod
    def checker_type(self) -> CheckerType:
        """Return the checker type identifier."""
        pass

    @property
    @abstractmethod
    def rule_patterns(self) -> List[str]:
        """Return list of rule name patterns this matcher handles."""
        pass

    @abstractmethod
    def matches(self, rule_name: str) -> bool:
        """Return True if the rule belongs to this checker."""
        pass

    @abstractmethod
    def extract_assert_type(self, assert_message: str) -> Optional[str]:
        """Extract the specific assert type from the message."""
        pass


class CheckerModule(ABC):
    """
    Base class for checker-specific modules.

    Each checker (ExternalCall, PrivilegedOperations, etc.) implements this
    interface to provide its own matching, extraction, and formatting logic.
    """

    @property
    @abstractmethod
    def checker_type(self) -> CheckerType:
        """Return the checker type identifier (e.g., CheckerType.EXTERNAL_CALL)."""
        pass

    @property
    @abstractmethod
    def matcher(self) -> RuleMatcher:
        """Return the rule matcher for this checker."""
        pass

    def extract_source_location(
        self,
        check: CheckResult,
        api: Any
    ) -> Optional[SourceLocation]:
        """
        Extract source location from a check result.

        Override for checker-specific source location extraction logic.
        Default implementation uses the check's source_location field.
        """
        if not check.source_location:
            return None

        # Handle both SourceLocation objects and string formats
        if hasattr(check.source_location, 'file') and hasattr(check.source_location, 'line'):
            # Already a SourceLocation object from prover_output_utility
            pou_loc = check.source_location
            start_line = pou_loc.line if pou_loc.line is not None else 0
            end_line = pou_loc.end_line if pou_loc.end_line is not None else start_line
            return SourceLocation(
                file_path=pou_loc.file,
                start_line=start_line,
                end_line=end_line,
                start_column=pou_loc.column,
                end_column=pou_loc.end_column
            )
        elif isinstance(check.source_location, str):
            return self._parse_source_location_string(check.source_location)

        return None

    def _parse_source_location_string(self, location_str: str) -> Optional[SourceLocation]:
        """Parse a source location string like 'file.sol:10-15'."""
        if not location_str:
            return None

        try:
            if ':' not in location_str:
                return None

            parts = location_str.rsplit(':', 1)
            file_path = parts[0]
            line_info = parts[1]

            if '-' in line_info:
                start, end = line_info.split('-', 1)
                start_line = int(start.split(':')[0])
                end_line = int(end.split(':')[0])
            else:
                start_line = int(line_info.split(':')[0])
                end_line = start_line

            return SourceLocation(
                file_path=file_path,
                start_line=start_line,
                end_line=end_line
            )
        except (ValueError, IndexError):
            return None

    def extract_additional_context(
        self,
        check: CheckResult,
        api: Any
    ) -> Dict[str, Any]:
        """
        Extract checker-specific additional context from a check.

        Override to provide custom context extraction.
        Returns a dictionary that will be merged into the finding.
        """
        return {}
