"""
Data models for checker output processing.

Contains all dataclasses and enums used across the reporting module.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, List, Literal, Optional, TypedDict

if TYPE_CHECKING:
    from .checker_type import CheckerType


class DefectVerdict(Enum):
    """Step 2: Is this a defect?"""

    YES = "YES"
    NO = "NO"


class ConfidenceLevel(Enum):
    """Step 2: How confident is the assessment?"""

    HIGH = "HIGH"
    LOW = "LOW"


class IssueClassification(Enum):
    """Classification of findings by issue assessment."""

    DEFINITE_ISSUE = "DEFINITE_ISSUE"
    LIKELY_ISSUE = "LIKELY_ISSUE"
    UNCERTAIN = "UNCERTAIN"
    LIKELY_NON_ISSUE = "LIKELY_NON_ISSUE"
    DEFINITE_NON_ISSUE = "DEFINITE_NON_ISSUE"

    @classmethod
    def ordered_list(cls) -> List["IssueClassification"]:
        """Get classifications in severity order (most severe first)."""
        return [cls.DEFINITE_ISSUE, cls.LIKELY_ISSUE, cls.UNCERTAIN, cls.LIKELY_NON_ISSUE, cls.DEFINITE_NON_ISSUE]

    @property
    def display_name(self) -> str:
        """Get human-readable display name."""
        name = self.value.replace("_", " ").title()
        return name.replace("Non Issue", "Non-Issue")


@dataclass(frozen=True)
class SourceLocation:
    """Represents a source code location from the source map."""

    file_path: str
    start_line: int
    end_line: int
    start_column: Optional[int] = None
    end_column: Optional[int] = None
    code_snippet: Optional[str] = None

    @property
    def location_key(self) -> str:
        """Unique key for grouping violations by location."""
        return f"{self.file_path}:{self.start_line}-{self.end_line}"


@dataclass
class FailureContext:
    """Context about a specific method that triggered a violation."""

    method_name: str
    contract_name: Optional[str] = None
    call_chain: Optional[List[str]] = None
    trace_file: Optional[str] = None
    calltrace_xml: Optional[str] = None  # XML-formatted calltrace from AI Composer

    @property
    def full_method_name(self) -> str:
        """Get the fully qualified method name, skipping 'unknown_contract'."""
        if self.contract_name and self.contract_name != "unknown_contract":
            return f"{self.contract_name}.{self.method_name}"
        return self.method_name


@dataclass
class FinalFeedback:
    """Step 4: Final presentation for HTML report.

    Contains the human-readable output that appears in findings.
    """

    raw_output: Optional[str] = None
    classification: Optional[IssueClassification] = None
    behavior_summary: Optional[str] = None


@dataclass
class CheckerFinding:
    """
    A single finding from a checker rule.

    Represents a problematic code location with all associated context.
    """

    # Core identification
    rule_name: str
    finding_id: str

    # Problem location
    source_location: SourceLocation

    # Failure contexts (all methods reaching this location)
    failure_contexts: List[FailureContext] = field(default_factory=list)

    # AI analysis
    final_feedback: Optional[FinalFeedback] = None

    # Confidence assessment
    confidence_score: int = 0  # 0-100: AI's confidence that this is a REAL issue
    classification: Optional[IssueClassification] = None

    # Additional metadata
    checker_type: Optional["CheckerType"] = None

    @property
    def is_high_confidence(self) -> bool:
        """Check if this is a high confidence finding (80-100)."""
        return self.confidence_score >= 80

    @property
    def violating_methods(self) -> List[str]:
        """Get list of all violating method names."""
        return [ctx.full_method_name for ctx in self.failure_contexts]


@dataclass
class CheckerReport:
    """Complete report from processing a checker's output."""

    job_url: str
    job_id: str
    checker_type: "CheckerType | str"
    findings: List[CheckerFinding] = field(default_factory=list)
    processing_errors: List[str] = field(default_factory=list)

    @property
    def total_findings(self) -> int:
        return len(self.findings)

    @property
    def high_confidence_findings(self) -> List[CheckerFinding]:
        """Get findings with confidence score >= 80."""
        return [f for f in self.findings if f.is_high_confidence]

    def get_sorted_findings(self) -> List[CheckerFinding]:
        """Get findings sorted by confidence_score (most confident first)."""
        return sorted(self.findings, key=lambda f: f.confidence_score, reverse=True)


# TypedDicts for JSON sidecar files


class FindingMetadataDict(TypedDict, total=False):
    """Metadata about a finding within an iteration sidecar."""

    source_location: str
    source_file: str
    violating_methods: list[str]
    contracts: list[str]
    methods_by_contract: dict[str, list[str]]


class IterationSidecarData(TypedDict, total=False):
    """JSON sidecar structure for each analysis iteration (run_*.json).

    Written by run_single_analysis_for_group() in __main__.py.
    Read by build_iteration_details_section() in synthesize_analyses.py.
    """

    # Core defect analysis fields (from two-step flow)
    is_defect: Literal["YES", "NO"]
    confidence: Literal["HIGH", "LOW"]
    outcome_code: Literal["YH", "YL", "NH", "NL"]
    reasoning: str
    recommendation: str
    behavior_summary: str

    # Metadata
    findings_metadata: list[FindingMetadataDict]
    ai_analysis_success: bool

    # Legacy field (for backward compatibility)
    confidence_score: int
