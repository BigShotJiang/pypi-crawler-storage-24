"""CheckerType enum for identifying checker types across the reporting pipeline."""

from enum import Enum


class CheckerType(str, Enum):
    EXTERNAL_CALL = "external_call"
    PRIVILEGED_OPERATIONS = "privileged_operations"
    INPUT_VALIDATION = "input_validation"
    GENERIC = "generic"
    AUTOCVL = "autocvl"
