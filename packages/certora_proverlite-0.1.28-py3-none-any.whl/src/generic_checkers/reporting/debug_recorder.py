"""
Debug recorder for crash dumps and debugging.

Records all data collected during reporter execution for debugging purposes.
Automatically dumps to JSON on crash.
"""

import json
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.utils.logger import logger


class DebugRecorder:
    """
    Records debug information during reporter execution.

    Collects raw API responses, calltraces, and AI analysis I/O
    for debugging purposes. Automatically dumps to file on crash.
    """

    def __init__(self, job_url: str):
        """
        Initialize debug recorder.

        Args:
            job_url: The Certora prover job URL
        """
        self.job_url = job_url
        self.job_id = self._extract_job_id(job_url)
        self.start_time = datetime.now()

        # Storage for debug data
        self.api_calls: List[Dict[str, Any]] = []
        self.calltraces: Dict[str, Dict[str, Any]] = {}
        self.ai_analysis: List[Dict[str, Any]] = []

        # Crash information
        self.crash_info: Optional[Dict[str, Any]] = None

    def _extract_job_id(self, job_url: str) -> str:
        """Extract job ID from URL."""
        # URL format: https://prover.certora.com/output/{run_id}/{job_id}/
        parts = job_url.rstrip('/').split('/')
        if len(parts) >= 2:
            return f"{parts[-2]}_{parts[-1]}"
        return "unknown"

    def record_api_call(self, endpoint: str, response: Any, duration_ms: Optional[float] = None):
        """
        Record a raw API call.

        Args:
            endpoint: The API endpoint called (e.g., "get_calltrace", "get_all_checks")
            response: The raw response object
            duration_ms: Optional duration of the call in milliseconds
        """
        record = {
            "timestamp": datetime.now().isoformat(),
            "endpoint": endpoint,
            "duration_ms": duration_ms,
            "response_type": str(type(response).__name__),
        }

        # Try to capture response summary without storing full data
        try:
            if hasattr(response, '__len__'):
                record["response_size"] = len(response)
            if isinstance(response, dict):
                record["response_keys"] = list(response.keys())
        except Exception as e:
            logger.warning(f"Failed to capture response metadata for {endpoint}: {e}")

        self.api_calls.append(record)

    def record_calltrace(self, check_id: str, raw_calltrace: Any, xml_calltrace: Optional[str]):
        """
        Record a calltrace (both raw and XML).

        Args:
            check_id: Unique identifier for the check (e.g., rule_name + method_name)
            raw_calltrace: The raw calltrace object from API
            xml_calltrace: The converted XML string
        """
        self.calltraces[check_id] = {
            "timestamp": datetime.now().isoformat(),
            "raw_type": str(type(raw_calltrace).__name__),
            "xml": xml_calltrace,
        }

        # Try to capture raw calltrace data structure
        try:
            if hasattr(raw_calltrace, 'trace_data'):
                trace_data = raw_calltrace.trace_data
                if isinstance(trace_data, dict):
                    self.calltraces[check_id]["raw_keys"] = list(trace_data.keys())
                    # Store the actual raw trace data for debugging
                    self.calltraces[check_id]["raw_data"] = trace_data
        except Exception as e:
            logger.warning(f"Failed to capture calltrace data for {check_id}: {e}")

    def record_ai_input(self, rule_name: str, prompt: str, xmls: List[str], **kwargs):
        """
        Record AI analysis input.

        Args:
            rule_name: The rule being analyzed
            prompt: The initial prompt template
            xmls: List of XML calltraces passed to analyzer
            **kwargs: Additional analysis parameters
        """
        record = {
            "timestamp": datetime.now().isoformat(),
            "type": "ai_input",
            "rule_name": rule_name,
            "prompt": prompt,
            "xml_count": len(xmls),
            "xmls": xmls,
            "parameters": kwargs,
        }
        self.ai_analysis.append(record)

    def record_ai_output(self, rule_name: str, result: Any, exit_code: Optional[int] = None):
        """
        Record AI analysis output.

        Args:
            rule_name: The rule that was analyzed
            result: The analysis result
            exit_code: The exit code from analyzer (if applicable)
        """
        record = {
            "timestamp": datetime.now().isoformat(),
            "type": "ai_output",
            "rule_name": rule_name,
            "exit_code": exit_code,
            "result_type": str(type(result).__name__),
        }

        # Try to capture result summary
        try:
            if hasattr(result, '__dict__'):
                record["result_fields"] = list(result.__dict__.keys())
            elif isinstance(result, dict):
                record["result_keys"] = list(result.keys())
                record["result"] = result
            elif isinstance(result, str):
                record["result"] = result[:1000]  # Truncate long strings
        except Exception as e:
            logger.warning(f"Failed to capture AI result metadata for {rule_name}: {e}")

        self.ai_analysis.append(record)

    def dump_on_crash(self, exception: Exception):
        """
        Dump all collected debug data to file on crash.

        Args:
            exception: The exception that caused the crash
        """
        # Capture crash information
        self.crash_info = {
            "timestamp": datetime.now().isoformat(),
            "exception_type": type(exception).__name__,
            "exception_message": str(exception),
            "traceback": traceback.format_exc(),
        }

        # Generate dump file path
        debug_dir = Path(".certora_internal/preaudit_debug")
        debug_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dump_file = debug_dir / f"crash_dump_{self.job_id}_{timestamp}.json"

        # Collect all debug data
        dump_data = {
            "job_url": self.job_url,
            "job_id": self.job_id,
            "start_time": self.start_time.isoformat(),
            "crash_time": datetime.now().isoformat(),
            "duration_seconds": (datetime.now() - self.start_time).total_seconds(),
            "crash_info": self.crash_info,
            "api_calls": self.api_calls,
            "calltraces": self.calltraces,
            "ai_analysis": self.ai_analysis,
        }

        # Write to file
        try:
            with open(dump_file, 'w') as f:
                json.dump(dump_data, f, indent=2, default=str)
            print(f"\nDebug dump saved to: {dump_file}", flush=True)
        except Exception as e:
            print(f"\nFailed to save debug dump: {e}", flush=True)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - dump on exception."""
        if exc_type is not None:
            self.dump_on_crash(exc_val)
        # Don't suppress the exception
        return False
