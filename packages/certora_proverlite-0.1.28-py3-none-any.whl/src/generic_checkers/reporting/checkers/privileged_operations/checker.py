"""
Privileged Operations Checker module implementation.

Provides extraction, analysis, and formatting specific to access control issues.
"""

from typing import Any, Dict, Optional

from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]

from ...base.checker_type import CheckerType
from ...base.interfaces import CheckerModule, RuleMatcher
from ...base.models import SourceLocation
from .matcher import PrivilegedOperationsMatcher


class PrivilegedOperationsChecker(CheckerModule):
    """
    Checker module for Privileged Operations issues.

    Detects access control issues including:
    - Functions that should be privileged but aren't
    - Storage writes that can be modified by multiple addresses
    - Time-sensitive operations that could be manipulated
    """

    def __init__(self) -> None:
        self._matcher = PrivilegedOperationsMatcher()

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.PRIVILEGED_OPERATIONS

    @property
    def matcher(self) -> RuleMatcher:
        return self._matcher

    def extract_source_location(self, check: CheckResult, api: Any) -> Optional[SourceLocation]:
        """
        Extract source location from a check result.

        For privileged operations, the location is typically the function definition
        or the specific state-changing operation.
        """
        if check.source_location:
            # Handle both SourceLocation objects and string formats
            if hasattr(check.source_location, "file") and hasattr(check.source_location, "line"):
                pou_loc = check.source_location
                start_line = pou_loc.line if pou_loc.line is not None else 0
                end_line = pou_loc.end_line if pou_loc.end_line is not None else start_line
                return SourceLocation(
                    file_path=pou_loc.file,
                    start_line=start_line,
                    end_line=end_line,
                    start_column=pou_loc.column,
                    end_column=pou_loc.end_column,
                )
            elif isinstance(check.source_location, str):
                return self._parse_source_location_string(check.source_location)
        return None

    def extract_additional_context(self, check: CheckResult, api: Any) -> Dict[str, Any]:
        """
        Extract access-control-specific context from a check.

        Extracts information about:
        - Type of access control issue
        - Affected state variables
        - Risk assessment
        """
        context: Dict[str, Any] = {}

        if check.assert_message:
            assert_type = self._matcher.extract_assert_type(check.assert_message)
            if assert_type:
                context["violation_type"] = assert_type

                # Add risk assessment based on violation type
                if assert_type == "not_privileged":
                    context["risk_category"] = "access_control"
                    context["impact"] = "unauthorized_access"
                    context["severity_hint"] = "critical_if_state_changing"
                elif assert_type == "non_privileged_write":
                    context["risk_category"] = "state_integrity"
                    context["impact"] = "unauthorized_state_modification"
                    context["severity_hint"] = "depends_on_affected_state"

        # Add method context if available
        if check.method_name:
            context["affected_method"] = check.method_name

            # Check for common patterns that might indicate severity
            method_lower = check.method_name.lower()
            if any(kw in method_lower for kw in ["owner", "admin", "set", "update", "withdraw"]):
                context["high_risk_keywords"] = True

        return context
