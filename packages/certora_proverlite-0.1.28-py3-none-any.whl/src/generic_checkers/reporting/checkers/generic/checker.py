"""
Generic Checker module implementation.

Provides extraction, analysis, and formatting for generic verification rules.
"""

from typing import Any, Dict, Optional

from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]

from ...base.checker_type import CheckerType
from ...base.interfaces import CheckerModule, RuleMatcher
from ...base.models import SourceLocation
from .matcher import GenericMatcher


class GenericChecker(CheckerModule):
    """
    Checker module for Generic verification rules.

    Handles rules that don't fit into specialized categories, providing
    basic extraction and formatting capabilities.
    """

    def __init__(self) -> None:
        self._matcher = GenericMatcher()

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.GENERIC

    @property
    def matcher(self) -> RuleMatcher:
        return self._matcher

    def extract_source_location(
        self,
        check: CheckResult,
        api: Any
    ) -> Optional[SourceLocation]:
        """
        Extract source location from a check result.

        For generic rules, uses the standard source_location field.
        """
        if check.source_location:
            # Handle both SourceLocation objects and string formats
            if hasattr(check.source_location, 'file') and hasattr(check.source_location, 'line'):
                pou_loc = check.source_location
                start_line = pou_loc.line if pou_loc.line is not None else 0
                end_line = pou_loc.end_line if pou_loc.end_line is not None else start_line
                return SourceLocation(
                    file_path=pou_loc.file,
                    start_line=start_line,
                    end_line=end_line,
                    start_column=pou_loc.column,
                    end_column=pou_loc.end_column
                )
            elif isinstance(check.source_location, str):
                return self._parse_source_location_string(check.source_location)
        return None

    def extract_additional_context(
        self,
        check: CheckResult,
        api: Any
    ) -> Dict[str, Any]:
        """
        Extract additional context from a check.

        For generic rules, provides basic method and contract context.
        """
        context: Dict[str, Any] = {}

        if check.method_name:
            context["affected_method"] = check.method_name

        if check.contract_name:
            context["affected_contract"] = check.contract_name

        return context
