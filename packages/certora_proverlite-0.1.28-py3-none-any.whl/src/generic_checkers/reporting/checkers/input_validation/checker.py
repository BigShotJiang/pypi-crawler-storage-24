"""
Input Validation Checker module implementation.

Provides extraction, analysis, and formatting specific to input validation issues.
"""

from typing import Any, Dict, Optional

from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]

from ...base.checker_type import CheckerType
from ...base.interfaces import CheckerModule, RuleMatcher
from ...base.models import SourceLocation
from .matcher import InputValidationMatcher


class InputValidationChecker(CheckerModule):
    """
    Checker module for Input Validation issues.

    Detects missing or inadequate input validation that could indicate:
    - Unvalidated array lengths
    - Unvalidated parameter values
    - Unvalidated struct fields
    - Missing bounds checks
    - Missing business logic constraints
    """

    def __init__(self) -> None:
        self._matcher = InputValidationMatcher()

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.INPUT_VALIDATION

    @property
    def matcher(self) -> RuleMatcher:
        return self._matcher

    def extract_source_location(self, check: CheckResult, api: Any) -> Optional[SourceLocation]:
        """
        Extract source location from a check result.

        For input validation checker, we use the standard source location
        which should point to the function being tested.
        """
        # Use default implementation from base class
        return super().extract_source_location(check, api)

    def extract_additional_context(self, check: CheckResult, api: Any) -> Dict[str, Any]:
        """
        Extract input-validation-specific context from a check.

        Extracts information about:
        - The type of validation missing (length, value, field)
        - The parameter or field being tested
        - Risk level based on input type
        """
        context: Dict[str, Any] = {}

        # Extract validation type from assert message
        if check.assert_message:
            assert_type = self._matcher.extract_assert_type(check.assert_message)
            if assert_type:
                context["validation_type"] = assert_type

                # Add specific context and risk level based on validation type
                if assert_type == "missing_length_validation":
                    context["affected_component"] = "array_length"
                    context["risk_level"] = "medium"
                elif assert_type == "missing_value_validation":
                    context["affected_component"] = "parameter_value"
                    context["risk_level"] = "medium"
                elif assert_type == "missing_bytes_validation":
                    context["affected_component"] = "bytes_parameter"
                    context["risk_level"] = "high"  # Bytes often represent calldata or signatures
                elif assert_type == "missing_field_validation":
                    context["affected_component"] = "struct_field"
                    context["risk_level"] = "medium"
                else:  # Generic missing_validation
                    context["affected_component"] = "input_parameter"
                    context["risk_level"] = "low"

        # Try to extract parameter information from rule name
        if check.rule_name:
            # Parse rule name to extract parameter index and type
            # Example: input_validation_requestWithdrawal_WithdrawalRequestArray_param0_...
            if "_param" in check.rule_name:
                parts = check.rule_name.split("_param")
                if len(parts) > 1:
                    # Extract parameter index
                    param_part = parts[1].split("_")[0]
                    try:
                        param_index = int(param_part)
                        context["parameter_index"] = param_index
                    except ValueError:
                        pass

            # Check if it's testing a specific field
            if "_field_" in check.rule_name:
                field_parts = check.rule_name.split("_field_")
                if len(field_parts) > 1:
                    field_name = field_parts[1].split("_")[0] if "_" in field_parts[1] else field_parts[1]
                    # Remove any trailing closing parentheses from field name
                    field_name = field_name.rstrip("()")
                    context["tested_field"] = field_name

            # Check if it's testing array length
            if "_length" in check.rule_name:
                context["validation_aspect"] = "array_length"

        return context
