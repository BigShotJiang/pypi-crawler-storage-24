"""
Rule matcher for Input Validation Checker.

Identifies rules that detect missing or inadequate input validation in smart contracts.
"""

from typing import Dict, List, Optional

from ...base.checker_type import CheckerType
from ...base.interfaces import RuleMatcher


class InputValidationMatcher(RuleMatcher):
    """Matcher for Input Validation Checker rules.

    Covers rules that detect missing input validation:
    - input_validation_*_length: Verifies array length changes cause reverts
    - input_validation_*_param*: Verifies parameter value changes cause reverts
    - input_validation_*_field_*: Verifies struct field changes cause reverts
    """

    RULE_PATTERNS: List[str] = [
        "input_validation_",  # Prefix match for all input validation rules
    ]

    # Assert patterns map message substrings to violation types
    ASSERT_PATTERNS: Dict[str, str] = {
        "array1.length != array2.length => lastReverted": "missing_length_validation",
        ".length != ": "missing_length_validation",
        "input1 != input2 && lastReverted": "missing_value_validation",
        "!= input2 && lastReverted": "missing_value_validation",
        "keccak256(input1) != keccak256(input2)": "missing_bytes_validation",
        "[0].": "missing_field_validation",
        "satisfy": "missing_validation",  # Generic catch-all for satisfy statements
    }

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.INPUT_VALIDATION

    @property
    def rule_patterns(self) -> List[str]:
        return self.RULE_PATTERNS

    def matches(self, rule_name: str) -> bool:
        return any(pattern in rule_name for pattern in self.RULE_PATTERNS)

    def extract_assert_type(self, assert_message: str) -> Optional[str]:
        """Extract the specific validation type from assert/satisfy message."""
        if not assert_message:
            return None

        # Check patterns in order of specificity (most specific first)
        for pattern, assert_type in self.ASSERT_PATTERNS.items():
            if pattern in assert_message:
                return assert_type

        return None
