"""
Input Validation Checker module.

Detects missing or inadequate input validation in smart contract functions.
"""

from .checker import InputValidationChecker
from .matcher import InputValidationMatcher

__all__ = [
    "InputValidationChecker",
    "InputValidationMatcher",
]
