"""
External Call Checker module.

Detects unstable external call targets and selectors that vary with user input.
"""

from .checker import ExternalCallChecker
from .matcher import ExternalCallMatcher

__all__ = [
    "ExternalCallChecker",
    "ExternalCallMatcher",
]
