"""
External Call Checker module implementation.

Provides extraction, analysis, and formatting specific to external call issues.
"""

from typing import Any, Dict, Optional

from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]

from ...base.checker_type import CheckerType
from ...base.interfaces import CheckerModule, RuleMatcher
from ...base.models import SourceLocation
from .matcher import ExternalCallMatcher


class ExternalCallChecker(CheckerModule):
    """
    Checker module for External Call issues.

    Detects unstable external call targets and selectors that vary with user input,
    which could indicate potential vulnerabilities like:
    - Arbitrary external calls
    - Call injection attacks
    - Uncontrolled delegate calls
    """

    def __init__(self) -> None:
        self._matcher = ExternalCallMatcher()

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.EXTERNAL_CALL

    @property
    def matcher(self) -> RuleMatcher:
        return self._matcher

    def extract_source_location(self, check: CheckResult, api: Any) -> Optional[SourceLocation]:
        """
        Extract source location from a check result.

        For external call checker, we try to identify the specific CALL opcode location.
        """
        # First try standard source location
        if check.source_location:
            # Handle both SourceLocation objects and string formats
            if hasattr(check.source_location, "file") and hasattr(check.source_location, "line"):
                pou_loc = check.source_location
                start_line = pou_loc.line if pou_loc.line is not None else 0
                end_line = pou_loc.end_line if pou_loc.end_line is not None else start_line
                return SourceLocation(
                    file_path=pou_loc.file,
                    start_line=start_line,
                    end_line=end_line,
                    start_column=pou_loc.column,
                    end_column=pou_loc.end_column,
                )
            elif isinstance(check.source_location, str):
                location = self._parse_source_location_string(check.source_location)
                if location:
                    return location

        # TODO: For external call checker, we could parse breadcrumbs to find
        # the specific CALL/DELEGATECALL/STATICCALL opcode location
        return None

    def extract_additional_context(self, check: CheckResult, api: Any) -> Dict[str, Any]:
        """
        Extract external-call-specific context from a check.

        Extracts information about:
        - The type of call (CALL, DELEGATECALL, STATICCALL)
        - Target address variability
        - Selector variability
        """
        context: Dict[str, Any] = {}

        # Extract assert type to understand the violation
        if check.assert_message:
            assert_type = self._matcher.extract_assert_type(check.assert_message)
            if assert_type:
                context["violation_type"] = assert_type

                # Add specific context based on violation type
                if assert_type in ["unstable_target", "target_mismatch"]:
                    context["affected_component"] = "call_target"
                    context["risk_level"] = "high"
                elif assert_type in ["unstable_selector", "selector_mismatch"]:
                    context["affected_component"] = "call_selector"
                    context["risk_level"] = "medium"
                elif assert_type == "zero_target":
                    context["affected_component"] = "call_target"
                    context["risk_level"] = "low"

        return context
