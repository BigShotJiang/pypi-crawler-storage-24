"""
Rule matcher for External Call Checker.

Identifies rules that detect unstable external call targets/selectors.
"""

from typing import Dict, List, Optional

from ...base.checker_type import CheckerType
from ...base.interfaces import RuleMatcher


class ExternalCallMatcher(RuleMatcher):
    """Matcher for External Call Checker rules.

    Covers rules that detect unstable external call targets/selectors:
    - stable_extcall_targets_and_selectors: Verifies call targets and selectors are consistent
    """

    RULE_PATTERNS: List[str] = [
        "stable_extcall_targets_and_selectors",
        "stable_extcall_",  # Prefix match for variants
    ]

    ASSERT_PATTERNS: Dict[str, str] = {
        "target == call_target": "unstable_target",
        "selector == call_selector": "unstable_selector",
        "target > 0": "zero_target",
        "call_target[pc] == target": "target_mismatch",
        "call_selector[pc] == selector": "selector_mismatch",
    }

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.EXTERNAL_CALL

    @property
    def rule_patterns(self) -> List[str]:
        return self.RULE_PATTERNS

    def matches(self, rule_name: str) -> bool:
        return any(pattern in rule_name for pattern in self.RULE_PATTERNS)

    def extract_assert_type(self, assert_message: str) -> Optional[str]:
        if not assert_message:
            return None
        for pattern, assert_type in self.ASSERT_PATTERNS.items():
            if pattern in assert_message:
                return assert_type
        return None
