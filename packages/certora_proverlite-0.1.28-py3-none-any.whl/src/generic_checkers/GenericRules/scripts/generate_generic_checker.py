#!/usr/bin/env python3
"""
Script to generate Certora Generic Rules Checker configuration and spec files.
"""

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

from src.parsers.orchestrator_argparse import parse_contract_files
from src.parsers.spec_imports import find_shared_specs
from src.utils.logger import logger

def validate_args(args):
    """Validate command line arguments."""
    # Either files or base_config must be provided
    if not args.files and not args.base_config:
        logger.error("Either files or --base-config must be provided")
        sys.exit(1)

    if args.files and args.base_config:
        logger.error("Cannot specify both files and --base-config")
        sys.exit(1)

    if args.base_config:
        if not os.path.exists(args.base_config):
            logger.error(f"Base config file {args.base_config} does not exist")
            sys.exit(1)

    if not args.contract:
        logger.error("Main contract name is required")
        sys.exit(1)

    if args.files:
        contracts = parse_contract_files(args.files)
        for handle in contracts:
            if not handle.source_file.endswith('.sol'):
                logger.error(f"{handle.source_file} is not a .sol file")
                sys.exit(1)
            if not os.path.exists(handle.source_file):
                logger.error(f"File {handle.source_file} does not exist")
                sys.exit(1)
        contract_names = [c.contract_name for c in contracts]
        if args.contract not in contract_names:
            logger.error(f"Main contract '{args.contract}' not found in provided files")
            logger.error(f"Available contracts: {', '.join(contract_names)}")
            sys.exit(1)

def process_templates(args):
    """Process template files and generate configuration."""
    script_dir = Path(__file__).parent
    project_dir = script_dir.parent

    # Use args.output_dir if provided, else default
    output_dir = getattr(args, 'output_dir', None) or Path("certora_generic_checker")
    contract_suffix = getattr(args, 'contract_suffix', "") or ""

    # Create output directory if it doesn't exist (don't delete if exists - for per-contract accumulation)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Find all template conf files in the confs directory
    confs_dir = project_dir / "confs"
    conf_templates = list(confs_dir.glob("*.template.conf"))

    if not conf_templates:
        logger.error(f"No template configuration files found in {confs_dir}")
        sys.exit(1)

    # Process each configuration template
    processed_files = []
    for conf_template in conf_templates:
        # Read template
        with open(conf_template, 'r') as f:
            content = f.read()

        # Replace placeholders
        content = content.replace("{{CONTRACT_NAME}}", args.contract)
        content = content.replace("{{CONTRACT_SUFFIX}}", contract_suffix)
        if args.base_config:
            content = content.replace("$BASE_CONFIG_OR_FILES$", f'"override_base_config": "{args.base_config}"')
        elif args.files:
            files_json = json.dumps(args.files)
            content = content.replace("$BASE_CONFIG_OR_FILES$", f'"files": {files_json}')

        # Write processed file with suffix in filename
        base_name = conf_template.stem.replace('.template', '')
        output_file = output_dir / f"{base_name}{contract_suffix}.conf"
        with open(output_file, 'w') as f:
            f.write(content)

        processed_files.append(output_file.name)
        logger.info(f"Generated: {output_file}")

    # Copy spec files - shared specs without suffix, main specs with suffix
    specs_dir = project_dir / "specs"
    spec_files = list(specs_dir.glob("*.spec"))

    if not spec_files:
        logger.error(f"No spec files found in {specs_dir}")
        sys.exit(1)

    # Ensure generic_rules.spec exists
    main_spec = specs_dir / "generic_rules.spec"
    if not main_spec.exists():
        logger.error(f"Main spec file not found: {main_spec}")
        sys.exit(1)

    # Identify shared specs (those imported by others)
    shared_specs = find_shared_specs(spec_files)

    # Copy spec files - shared specs without suffix, main specs with suffix
    for spec_file in spec_files:
        if spec_file.stem in shared_specs:
            # Shared spec - copy only once (no suffix, skip if exists)
            output_spec = output_dir / f"{spec_file.stem}.spec"
            if not output_spec.exists():
                shutil.copy2(spec_file, output_spec)
                logger.info(f"Copied shared: {output_spec}")
        else:
            # Main spec - copy with suffix
            output_spec = output_dir / f"{spec_file.stem}{contract_suffix}.spec"
            shutil.copy2(spec_file, output_spec)
            logger.info(f"Copied: {output_spec}")

    # Create runner script
    create_runner_script(output_dir, processed_files)

    logger.info(f"✓ Generated configuration in {output_dir}/")
    logger.info("Run verification with:")
    for conf_file in processed_files:
        logger.info(f"  certoraRun {output_dir}/{conf_file}")

def create_runner_script(output_dir, conf_files):
    """Create a runner script for easy execution."""
    runner_content = """#!/bin/bash
# Auto-generated runner script for Generic Rules Checker

echo "Running Generic Rules Checker..."

"""

    for conf_file in conf_files:
        runner_content += f"""echo "Running {conf_file}..."
certoraRun {conf_file}
echo "Completed {conf_file}"
echo ""

"""

    runner_content += 'echo "All checks completed!"'

    runner_file = output_dir / "run_checker.sh"
    with open(runner_file, 'w') as f:
        f.write(runner_content)

    # Make executable
    os.chmod(runner_file, 0o755)
    logger.info(f"Generated: {runner_file}")

def main():
    parser = argparse.ArgumentParser(
        description="Generate Certora Generic Rules Checker configuration and spec files"
    )

    parser.add_argument(
        '--base-config',
        type=str,
        help='Path to base config file (mutually exclusive with files)'
    )

    parser.add_argument(
        'files',
        nargs='*',
        help='List of Solidity contract files (.sol) - required if --base-config not provided'
    )

    parser.add_argument(
        'contract',
        help='Name of the main contract (without .sol extension)'
    )

    args = parser.parse_args()

    validate_args(args)
    process_templates(args)

if __name__ == "__main__":
    main()
