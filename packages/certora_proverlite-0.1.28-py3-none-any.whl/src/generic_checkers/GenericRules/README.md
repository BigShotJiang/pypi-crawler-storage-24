# Generic Rules

Flexible framework for implementing custom Certora verification rules.

## Usage

```bash
# Generate generic rules checker
./scripts/generate_generic_checker.py Contract1.sol Contract2.sol MainContract
```

**Run the checker:**
```bash
certoraRun certora_generic_checker/GenericRules.conf
```

## Purpose

Template-based system for creating custom verification rules that don't fit specialized tools. Define project-specific security invariants, custom access patterns, and business logic constraints.

## Files

- `specs/generic_rules.template.spec` - Customizable rule template
- `confs/GenericRules.template.conf` - Configuration template  
- `scripts/generate_generic_checker.py` - Generator script