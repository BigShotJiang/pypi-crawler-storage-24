// Main Generic Rules Specification
// Imports and uses all rules from individual spec files

import "reverts.spec";
import "failing_calls.spec";

// Use revert-related rules
use rule nonGettersThatNeverRevert;
use rule gettersThatNeverRevert;
use rule payableFunctionsThatNeverRevert;
use rule alwaysRevert;

// Use failing call rules
use rule failing_CALL_leads_to_revert;
