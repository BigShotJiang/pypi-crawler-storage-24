
persistent ghost bool callMade;
persistent ghost bool delegatecallMade;


hook CALL(uint g, address addr, uint value, uint argsOffset, uint argsLength, uint retOffset, uint retLength) uint rc {
    if (addr == executingContract) {
        callMade = true;
    }
}

hook DELEGATECALL(uint g, address addr, uint argsOffset, uint argsLength, uint retOffset, uint retLength) uint rc {
    if (addr == executingContract) {
        delegatecallMade = true;
    }
}

// TODO add CALLCODE for completeness, even though it's deprecated

/*
    This rule proves there are no instances in the code in which it calls itself (not statically).
    By proving this rule we can safely assume in our spec that e.msg.sender != currentContract.
*/
rule noSelfCalls(method certoraF) {
    env e;
    calldataarg args;

    callMade = false;
    delegatecallMade = false;

    certoraF(e, args);

    assert !callMade && !delegatecallMade, "self call detected";
}