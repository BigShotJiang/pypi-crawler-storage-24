
/**
 * Checks whether a function can only be executed 'once' in every state,
 * even if inputs differ.
 * There are different ways to define 'once' - per user? globally?
 * Same inputs? Different inputs?
 */

// Per-user one-time function check
rule oneTimeFunctionPerUserAnyInput(method certoraF) {
    env e1;
    calldataarg arg1;
    env e2; 
    calldataarg arg2;

    // per user
    require e1.msg.sender == e2.msg.sender, "per user one-time function check";

    timeProgresses(e1, e2);

    certoraF(e1, arg1); // first call, assume succeeds
    certoraF(e2, arg2); // second call, may revert and then we hit sanity
    satisfy true, "satisfy would be violated if it is a one-time function"; // a one-time function will revert in the second call, and this satisfy will be 'violated' 
}

rule oneTimeFunctionPerUserSameInput(method certoraF) {
    env e1;
    calldataarg arg;
    env e2; 

    // per user
    require e1.msg.sender == e2.msg.sender, "per user one-time function check";

    timeProgresses(e1, e2);

    certoraF(e1, arg); // first call, assume succeeds
    certoraF(e2, arg); // second call, may revert and then we hit sanity
    satisfy true, "satisfy would be violated if it is a one-time function"; // a one-time function will revert in the second call, and this satisfy will be 'violated'
}

// Globally one-time function check
rule oneTimeFunctionGlobalAnyInput(method certoraF) {
    env e1;
    calldataarg arg1;
    env e2; 
    calldataarg arg2;
    
    timeProgresses(e1, e2);
    
    certoraF(e1, arg1); // first call, assume succeeds
    certoraF(e2, arg2); // second call, may revert and then we hit sanity
    satisfy true, "satisfy would be violated if it is a one-time function"; // a one-time function will revert in the second call, and this satisfy will be 'violated'
}

rule oneTimeFunctionGlobalSameInput(method certoraF) {
    env e1;
    calldataarg arg;
    env e2; 
    
    timeProgresses(e1, e2);
    
    certoraF(e1, arg); // first call, assume succeeds
    certoraF(e2, arg); // second call, may revert and then we hit sanity
    satisfy true, "satisfy would be violated if it is a one-time function"; // a one-time function will revert in the second call, and this satisfy will be 'violated'
}


function timeProgresses(env e1, env e2) {
    require e1.block.timestamp <= e2.block.timestamp, "time can only progress";
    require e1.block.number <= e2.block.number, "block number can only progress";
}