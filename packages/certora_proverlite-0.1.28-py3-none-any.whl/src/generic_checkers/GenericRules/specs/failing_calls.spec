/* failing CALL should lead to a revert */
persistent ghost bool saw_failing_call;

hook CALL(uint g, address addr, uint value, uint argsOffset, uint argsLength, uint retOffset, uint retLength) uint rc {
	saw_failing_call = saw_failing_call || rc == 0;
}

rule failing_CALL_leads_to_revert(method certoraF) {
	saw_failing_call = false;
	env e;
	calldataarg arg;
	certoraF@withrevert(e, arg);
	bool reverted = lastReverted;
	assert saw_failing_call => reverted, "a failing CALL did not lead to a revert of caller";
}