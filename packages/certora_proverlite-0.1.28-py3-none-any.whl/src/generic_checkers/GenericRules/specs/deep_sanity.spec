use builtin rule deepSanity;
