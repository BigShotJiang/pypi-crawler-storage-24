
/**
 * Checks whether a non-payable, non-view function never reverts. 
 * It is expected to fail on most functions.
 * When should it not fail? Simple getters - see `gettersThatNeverRevert`.
 * When would it be interesting that getters fails?
 *  Getters that perform a computation and can be made to fail, e.g. division by zero. 
 * Payable functions that never revert are checked in `payableFunctionsThatNeverRevert`.
 */
rule nonGettersThatNeverRevert(method certoraF) 
filtered { certoraF -> !certoraF.isView && !certoraF.isPayable }
{
	env e;
	calldataarg arg;
	certoraF@withrevert(e, arg); 
	assert !lastReverted;
}

rule gettersThatNeverRevert(method certoraF) 
filtered { certoraF -> certoraF.isView }
{
	env e;
	require e.msg.value == 0, "getters should not be payable";
	calldataarg arg;
	certoraF@withrevert(e, arg);
	assert !lastReverted, "getters should usually not revert";
}

rule payableFunctionsThatNeverRevert(method certoraF) 
filtered { certoraF -> certoraF.isPayable }
{
	env e;
	calldataarg arg;
	require nativeBalances[e.msg.sender] >= e.msg.value, "sender should have enough balance";
	certoraF@withrevert(e, arg);
	assert !lastReverted, "payable functions should usually not revert";
}

/**
 * Checks whether a function always reverts.
 * If it does, we try to find a concrete reverting path. 
 * This rules out sanity issue.
 * If the code of the function is not trivial, it may indicate a Prover configuration issue.
 */
rule alwaysRevert(method certoraF) {
	env e;
	calldataarg arg;
	certoraF@withrevert(e, arg); 
	assert lastReverted, "function always reverts";
	satisfy lastReverted, "found a reverting path";
}
