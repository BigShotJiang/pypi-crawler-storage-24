use builtin rule msgValueInLoopRule;
