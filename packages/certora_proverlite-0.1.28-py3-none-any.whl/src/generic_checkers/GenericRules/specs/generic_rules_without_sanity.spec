import "one_time_functions.spec"; 

// Use one-time function rules - these need to be checked with sanity disabled
use rule oneTimeFunctionPerUserAnyInput;
use rule oneTimeFunctionPerUserSameInput;
use rule oneTimeFunctionGlobalAnyInput;
use rule oneTimeFunctionGlobalSameInput;
