/*
This rule find which functions are privileged.
A function is privileged if there is only one address that can call it.

The rules finds this by finding which functions can be called by two different users.
*/
rule privilegedOperation(method certoraF, address privileged) 
filtered {
	certoraF -> !certoraF.isView
}
{
	// ACCESS_CONTROL_SINGLE_OWNERSHIP_CHECK_PLACEHOLDER
	
	env e1;
	calldataarg arg;
	require e1.msg.sender == privileged, "we assume first call is the privileged one";

	storage initialStorage = lastStorage;
	certoraF(e1, arg); // privileged succeeds executing candidate privileged operation.

	env e2;
	calldataarg arg2;
	require e2.msg.sender != privileged, "we assume second call is from a different user";
	certoraF@withrevert(e2, arg2) at initialStorage; // unprivileged
	bool secondSucceeded = !lastReverted;

    // we will assert that second did not succeed. we will get a counterexample in 
    // which first call to `f` must have succeeded.
	assert !secondSucceeded, "not privileged operation - another address can call method";
}