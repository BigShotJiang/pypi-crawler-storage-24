/**
 * We run a parametric function `f` in two phases starting from the same initial state,
 * but different inputs and environments:
 * same block.timestamp and block.number, msg.sender must be different.
 * In phase one, we mark all writes that have been made.
 * In phase two, every write that was written to before, we check if the same value is
 * being written, or a different value. 
 * We assert the equality, since if they are not equal,
 * it means two users are able to write distinct values
 * to the same storage slot, indicating it is not a privileged write.
 */
rule detect_privileged_writes(method certoraF)
filtered {
	certoraF -> !certoraF.isView
}
{
	// ACCESS_CONTROL_SINGLE_OWNERSHIP_CHECK_PLACEHOLDER

    phase_one = true;
    init_ghost_maps();
    storage initialStorage = lastStorage;
    env e1;
    env e2;
    calldataarg args1;
    calldataarg args2;
    require e1.msg.sender != e2.msg.sender, "we assume two different users are calling the function";
    require e1.block.timestamp == e2.block.timestamp, "we assume same timestamp";
    require e1.block.number == e2.block.number, "we assume same block number";
    certoraF(e1, args1); // first call
    phase_one = false;
    certoraF(e2, args2) at initialStorage; // second call
    assert true;
}


/**
 * Similar to the above rule, but only using different timestamp/blocknumber. 
 * State and inputs are the same.
 * This checks if the write if the write is time-sensitive.
 * A common false positive is reentrancy guards since the slot is written twice. TODO: maintain list of writes
 */
rule detect_time_sensitive_writes(method certoraF) 
filtered {
	certoraF -> !certoraF.isView
}
{
    phase_one = true;
    init_ghost_maps();
    storage initialStorage = lastStorage;
    env e1;
    env e2;
    calldataarg args;
    require e1.msg.sender == e2.msg.sender, "we assume same user is calling the function";
    require e1.block.timestamp != e2.block.timestamp, "we assume different timestamp";
    require e1.block.number != e2.block.number, "we assume different block number";
    certoraF(e1, args); // first call
    phase_one = false;
    certoraF(e2, args) at initialStorage; // second call
    assert true;
}

function init_ghost_maps() {
    // Initialize ghosts
    require forall uint i. is_written[i] == false, "initializing is_written";
    require forall uint i. written_value[i] == 0, "initializing written_value";
}

// ghosts
persistent ghost mapping(uint => bool) is_written;
persistent ghost mapping(uint => uint) written_value;
persistent ghost bool phase_one;

// hooks
hook ALL_SSTORE(uint loc, uint v) {
    if (phase_one) {
        is_written[loc] = true;
        written_value[loc] = v;
    } else {
        if (is_written[loc]) {
            assert written_value[loc] == v, "Write to storage slot is different";
        }
    }
}

