import "extcall_checker_advanced.spec";

// Filter definition: only select view functions
override definition selected(method certoraF) returns bool = certoraF.isView;

use rule stable_extcall_targets_and_selectors;