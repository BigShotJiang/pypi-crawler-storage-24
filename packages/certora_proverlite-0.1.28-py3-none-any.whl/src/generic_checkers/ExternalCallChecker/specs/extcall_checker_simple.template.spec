/** this is a basic version of the checker that may have false positives due to patterns like `callOptionalReturn`.
 the more advanced version keeps a 'list' of calls in a particular PC. 
 If passing it would imply some path stability since the order would be the same.
*/ 
persistent ghost mapping(uint => address) call_target;
persistent ghost mapping(uint => uint32) call_selector;
persistent ghost bool phase_one;

// only check that recurring visits at the same PC have the same target and selector
definition stable_data_id() returns uint = 1;
// also check that we do not visit new callsites in phase two.
definition stable_path_id() returns uint = 2;
persistent ghost uint check_id;


hook CALL(uint g, address target, uint v, uint aO, uint aL, uint rO, uint rL) uint rc {
    assert pc > 0;
    $HOLD$ target > 0, "$HOLD$ target contract is non-zero"; // this is not a reasonable thing to see and would be good to flag it
    if (phase_one) {
        // revisiting the same callsite again - loops/repeated internal calls
        if (call_target[pc] != 0) {
            assert call_target[pc] == target;
            assert call_selector[pc] == selector;
        } else {    
            call_target[pc] = target;
            call_selector[pc] = selector;
        }
    } else {
        // if we revisit the same pc, it's the same target and selector.
        // note that we do not check a different input indeed reaches the same PCs unless we extended the check with the path check
        if ((call_target[pc] != 0 && check_id == stable_data_id()) || (check_id == stable_path_id())) {
            assert target == call_target[pc];
            assert selector == call_selector[pc];
        }
    }
}

definition selected(method certoraF) returns bool = true;

// run with multi_assert
rule stable_extcall_targets_and_selectors(method certoraF) 
filtered { certoraF -> selected(certoraF) }
{
    check_id = stable_data_id(); // only check that recurring visits at the same PC have the same target and selector
    // init ghosts
    require forall uint i. call_target[i] == 0, "initializing call_target";
    require forall uint i. call_selector[i] == 0, "initializing call_selector";
    phase_one = true;
    storage init = lastStorage;

    env e1;
    calldataarg args1;
    env e2;
    calldataarg args2;

    certoraF(e1, args1);

    phase_one = false;
    certoraF(e2, args2) at init;

    assert true;
}
