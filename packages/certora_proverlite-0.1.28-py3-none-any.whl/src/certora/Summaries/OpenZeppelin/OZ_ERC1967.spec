methods {
    function _.upgradeToAndCall(address, bytes) external => HAVOC_ALL DELETE;
}