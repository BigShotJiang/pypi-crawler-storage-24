rule trivial {
    assert true;
}
