#!/usr/bin/env python3
"""
Smart Contract Formal Verification Rule Analysis Tool

This tool analyzes formal verification rule violations for smart contracts,
identifying false positives by validating state reachability and consistency.
"""

from pathlib import Path
import sys

# Add parent directory to Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

import argparse
import asyncio
import json
from typing import Any, Literal

from langchain.chat_models import init_chat_model
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.runnables import RunnableLambda, RunnableParallel
from pydantic import BaseModel, Field

from token_usage_tracker import TokenUsageTracker
from violation_analyzer.prover_utils import ViolationData, PathJobSource, UrlJobSource, JobDataSource


class ViolationAnalyzer:
    """Main violation analyzer class that encapsulates the analysis logic."""

    def __init__(
        self,
        job_source: JobDataSource | None = None,
        job_url: str | None = None,
        job_dir: Path | None = None,
        contract_file: Path | None = None,
        collect_sources: bool = False,
    ):
        """Initialize the violation analyzer.

        Args:
            job_source: The job data source (mutually exclusive with job_url/job_dir)
            job_url: URL to Certora job (mutually exclusive with job_source/job_dir)
            job_dir: Path to job directory (mutually exclusive with job_source/job_url)
            contract_file: Optional path to contract file
            collect_sources: Whether to collect sources from the job

        Raises:
            ValueError: If none or multiple job source options are provided
        """
        self.set_job_source(job_source=job_source, job_dir=job_dir, job_url=job_url)

        self.contract_file = contract_file
        self.collect_sources = collect_sources
        self.contract_code: str | None = None

    async def load_contract_code(self) -> bool:
        """Load the contract code from either file or job sources."""
        if self.contract_file:
            self.contract_code = load_contract_code(self.contract_file)
            return True
        elif self.collect_sources:
            print("Collecting all .sol files from the job...")
            self.contract_code = await self.current_job_source.get_sol_files()
            if not self.contract_code:
                print("No .sol files found to analyze.")
                return False
            return True
        else:
            print("Error: Either contract_file or collect_sources must be specified")
            return False

    def get_non_violated_rules(self) -> dict[str, str]:
        """
        Returns:
            a dict from rule name to its (non-violated) status
        """
        # Ensure contract code is loaded
        if self.contract_code is None:
            print("Error: Contract code not loaded. Call load_contract_code() first.")
            return {}

        return self.current_job_source.get_non_violated_rules()

    def set_job_source(
        self, job_source: JobDataSource | None = None, job_url: str | None = None, job_dir: Path | None = None
    ) -> None:
        """Update the current job source.

        Args:
            job_source: The job data source (mutually exclusive with job_url/job_dir)
            job_url: URL to Certora job (mutually exclusive with job_source/job_dir)
            job_dir: Path to job directory (mutually exclusive with job_source/job_url)

        Raises:
            ValueError: If none or multiple job source options are provided
        """
        # Validate that exactly one job source option is provided
        sources_provided = sum(x is not None for x in [job_source, job_url, job_dir])
        if sources_provided == 0:
            raise ValueError("Must provide exactly one of: job_source, job_url, or job_dir")
        if sources_provided > 1:
            raise ValueError("Cannot specify multiple job source options (job_source, job_url, job_dir)")

        # Update the current job source
        if job_source is not None:
            self.current_job_source = job_source
        elif job_url is not None:
            self.current_job_source = UrlJobSource(job_url)
        elif job_dir is not None:
            self.current_job_source = PathJobSource(job_dir)

    async def run(
        self,
        output_file: Path | None = None,
        num_votes: int = 3,
        vote_threshold: float = 0.5,
        token_tracker: TokenUsageTracker | None = None,
    ) -> bool:
        """Run the violation analysis with the current job source.

        Args:
            output_file: Path to save analysis results (defaults to analysis_results.json)
            num_votes: Number of votes for majority voting
            vote_threshold: Threshold for false positive classification
            token_tracker: TokenUsageTracker instance for recording token usage

        Returns:
            True if analysis completed successfully, False otherwise
        """
        # Use the current job source
        source = self.current_job_source

        # Ensure contract code is loaded
        if self.contract_code is None:
            print("Error: Contract code not loaded. Call load_contract_code() first.")
            return False

        # Set default output file
        if output_file is None:
            output_file = Path("analysis_results.json")

        # Use provided token tracker or create a disabled one
        if token_tracker is None:
            token_tracker = TokenUsageTracker()

        # Process verification files
        violations_data = await source.process_verification_files()

        if not violations_data:
            print("No rule violations found to analyze.")
            return True

        # Filter out problematic violations
        call_resolution_failures = [rule for rule, data in violations_data.items() if data["has_counter_example_havoc"]]
        imprecisions = [
            rule
            for rule, data in violations_data.items()
            if data["has_imprecision"] and rule not in call_resolution_failures
        ]
        remaining_violations = {
            k: v for k, v in violations_data.items() if k not in call_resolution_failures + imprecisions
        }

        if call_resolution_failures:
            print(
                f"{len(call_resolution_failures)} rules have unresolved external calls. Excluding them from the analysis"
            )

        if imprecisions:
            print(f"{len(imprecisions)} rules have imprecisions. Excluding them from the analysis")

        if not remaining_violations:
            print("No violations remain to be analyzed")

        majority_vote_results = []
        if remaining_violations:
            # Use majority voting for more reliable results
            majority_vote_results = analyze_all_violations_with_majority_voting(
                self.contract_code, remaining_violations, num_votes, vote_threshold, token_tracker
            )

        # Categorize the results
        try:
            if remaining_violations:
                categorization_result = categorize_violations(
                    majority_vote_results, num_votes, self.contract_code, token_tracker
                )
            else:
                categorization_result = CategorizationResult(categories=[])

            if call_resolution_failures:
                categorization_result.categories.append(
                    CategoryGroup(
                        category_name="Unresolved External Calls",
                        description="These rules contain havocs due to unresolved external calls. This may be the cause for the violation. Try resolving the call e.g. by adding relevant contracts to the scene or summarization",
                        rule_names=call_resolution_failures,
                        assumption_expression="",
                        invariant_expression="",
                    )
                )

            if imprecisions:
                categorization_result.categories.append(
                    CategoryGroup(
                        category_name="Imprecise Modelling",
                        description="These rules contain some imprecision in the way the SMT solvers modeled some functions (e.g. BV operations without the `--smt_use_bv` flag set). Try summarizing or adding that flag",
                        rule_names=imprecisions,
                        assumption_expression="",
                        invariant_expression="",
                    )
                )

            # Save majority vote results and categorization
            output_data: dict[str, Any] = {"categorization": categorization_result.model_dump()}
            if majority_vote_results:
                output_data["majority_vote_results"] = [r.model_dump() for r in majority_vote_results]

            with open(output_file, "w") as f:
                json.dump(output_data, f, indent=2)

            print(f"\nAnalysis complete. Results saved to {output_file}")
            print(f"Created {len(categorization_result.categories)} violation categories")

            # Print overall token usage summary
            token_tracker.log_summary("Violation analysis")
            token_tracker.save_to_file()

            return True

        except Exception as e:
            print(f"Categorization failed: {e}")
            print("Saving individual analyses only...")

            # Save just the majority vote results if categorization fails
            with open(output_file, "w") as f:
                json.dump([r.model_dump() for r in majority_vote_results], f, indent=2)

            print(f"Majority vote results saved to {output_file}")
            return False


class ViolationAnalysis(BaseModel):
    rule_name: str = Field(description="The name of the rule being analyzed")
    classification: Literal["FALSE_POSITIVE", "POTENTIAL_TRUE_POSITIVE", "NO_OP_REVERSION"] = Field(
        description="The final decision on whether this violation is a false positive, potential true positive, or a no-op that doesn't revert"
    )
    reason: str = Field(
        description="An analysis of the pre-state explaining the reason for the classification decision"
    )


class CategoryGroupBasic(BaseModel):
    category_name: str = Field(
        description="Name of the category (e.g., 'Mathematical Inconsistencies', 'Potential True Positives')"
    )
    description: str = Field(description="Brief description of what makes violations fall into this category")
    rule_names: list[str] = Field(description="List of rule names that belong to this category")


class CategoryGroup(CategoryGroupBasic):
    assumption_expression: str = Field(
        description="A CVL expression for blockchain state assumptions that could be added as 'require <expression>;' at the start of each rule to prevent false positives. Examples: 'block.timestamp < type(uint40).max', 'block.number > 0'. Return empty string if no blockchain state assumption is needed."
    )
    invariant_expression: str = Field(
        description="A CVL expression for contract-specific invariants that could be added as 'require <expression>;' at the start of each rule to prevent false positives. Examples: 'balance > 0', 'amount <= totalSupply', 'owner != address(0)', block.timestamp >= lastUpdate. Return empty string if no contract invariant is needed."
    )


class CategorizationResultBasic(BaseModel):
    categories: list[CategoryGroupBasic] = Field(description="List of categories with their associated rule violations")


class CategorizationResult(BaseModel):
    categories: list[CategoryGroup] = Field(description="List of categories with their associated rule violations")


class MajorityVoteResult(BaseModel):
    rule_name: str = Field(description="The name of the rule being analyzed")
    final_classification: Literal["FALSE_POSITIVE", "POTENTIAL_TRUE_POSITIVE", "NO_OP_REVERSION"] = Field(
        description="The majority vote decision"
    )
    individual_votes: list[ViolationAnalysis] = Field(description="All individual analysis results")
    false_positive_votes: int = Field(description="Number of votes for FALSE_POSITIVE")
    potential_true_positive_votes: int = Field(description="Number of votes for POTENTIAL_TRUE_POSITIVE")
    no_op_reversion_votes: int = Field(description="Number of votes for NO_OP_REVERSION")


def load_prompt_template(template_name: str) -> str:
    """Load a prompt template from the prompts directory.

    Args:
        template_name: The name of the template file (without .md extension)

    Returns:
        The template content as a string

    Raises:
        FileNotFoundError: If the template file doesn't exist
        IOError: If there's an error reading the file
    """
    script_dir = Path(__file__).parent
    template_path = script_dir / "prompts" / f"{template_name}.md"

    try:
        if not template_path.is_file():
            raise FileNotFoundError(f"Template file not found: {template_path}")
        return template_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"Error loading template '{template_name}': {e}")
        raise


def load_contract_code(contract_file: Path) -> str:
    """Load and return the smart contract source code."""
    if not contract_file.is_file():
        print(f"Error: Cannot find contract file {contract_file}")
        sys.exit(1)

    return contract_file.read_text()


def create_contract_system_message(contract_code: str) -> str:
    """Create the contract code system message for caching."""
    try:
        template = load_prompt_template("contract_code_system")
        return template.format(contract_code=contract_code)
    except Exception as e:
        print(f"Error creating contract system message: {e}")
        raise


def create_violation_specific_prompt(rule_name: str, violation_data: ViolationData) -> str:
    """Create the rule-specific portion of the analysis prompt."""
    try:
        template = load_prompt_template("violation_specific")
        return template.format(rule_name=rule_name, violation_data=json.dumps(violation_data, indent=2))
    except Exception as e:
        print(f"Error creating violation specific prompt: {e}")
        raise


def get_analysis_system_prompt() -> str:
    """Return the system prompt for analysis."""
    try:
        return load_prompt_template("analysis_system_prompt")
    except Exception as e:
        print(f"Error loading system prompt: {e}")
        raise


def get_categorization_basic_system_prompt() -> str:
    """Return the system prompt for basic categorization without expressions."""
    try:
        return load_prompt_template("categorization_basic_system_prompt")
    except Exception as e:
        print(f"Error loading basic categorization system prompt: {e}")
        raise


def get_expression_generation_system_prompt() -> str:
    """Return the system prompt for generating expressions from categories."""
    try:
        # Load the base template
        template = load_prompt_template("expression_generation_system_prompt")

        # Load the grammar file to embed in the template
        grammar_path = Path(__file__).parent.parent / "auto_cvl" / "properties_grammar.lark"

        return template.format(grammar=grammar_path.read_text())
    except Exception as e:
        print(f"Error loading expression generation system prompt: {e}")
        raise


def create_categorization_prompt(majority_results: list[MajorityVoteResult], num_votes: int) -> str:
    """Create the user message prompt for categorizing majority vote results."""
    try:
        total_count = len(majority_results)
        false_positive_count = sum(1 for r in majority_results if r.final_classification == "FALSE_POSITIVE")
        true_positive_count = sum(1 for r in majority_results if r.final_classification == "POTENTIAL_TRUE_POSITIVE")
        no_op_count = sum(1 for r in majority_results if r.final_classification == "NO_OP_REVERSION")

        template = load_prompt_template("categorization_prompt")
        return template.format(
            total_count=total_count,
            false_positive_count=false_positive_count,
            true_positive_count=true_positive_count,
            no_op_count=no_op_count,
            num_votes=num_votes,
            majority_results_json=json.dumps([r.model_dump() for r in majority_results], indent=2),
        )
    except Exception as e:
        print(f"Error creating categorization prompt: {e}")
        raise


def analyze_violation(
    structured_model: Any,
    contract_system_message: str,
    rule_name: str,
    violation_data: ViolationData,
    token_tracker: TokenUsageTracker,
) -> ViolationAnalysis:
    """Analyze a single violation using the structured model with contract code in system message for caching.

    Args:
        structured_model: The LangChain model with structured output
        contract_system_message: The contract code system message
        rule_name: The name of the rule being analyzed
        violation_data: The violation data
        token_tracker: Optional TokenUsageTracker to record usage

    Returns:
        ViolationAnalysis object
    """
    try:
        # First system message: Contract code (cacheable)
        contract_msg = SystemMessage(
            content=[{"type": "text", "text": contract_system_message, "cache_control": {"type": "ephemeral"}}]
        )

        # Second system message: Analysis instructions
        system_msg = SystemMessage(
            content=[{"type": "text", "text": get_analysis_system_prompt(), "cache_control": {"type": "ephemeral"}}]
        )

        # User message: Specific violation details
        violation_msg = HumanMessage(
            content=[
                {
                    "type": "text",
                    "text": create_violation_specific_prompt(rule_name, violation_data),
                    "cache_control": {"type": "ephemeral"},
                }
            ]
        )

        messages = [contract_msg, system_msg, violation_msg]

        print(f"\nAnalyzing {rule_name}...")
        analysis_dict = structured_model.invoke(messages)
        assert isinstance(analysis_dict, dict)
        analysis = analysis_dict["parsed"]
        assert isinstance(analysis, ViolationAnalysis)
        print(f"Completed analysis for {rule_name}: {analysis.classification}")

        # Extract and track token usage from the raw response
        token_tracker.log_usage_analyser(analysis_dict["raw"], rule_name, description="  ")

        return analysis

    except Exception as e:
        print(f"Error analyzing {rule_name}: {e}")
        # Return a fallback analysis instead of exiting
        return ViolationAnalysis(
            rule_name=rule_name, classification="POTENTIAL_TRUE_POSITIVE", reason=f"Error during analysis: {e}"
        )


def aggregate_majority_vote(
    rule_name: str, analyses: list[ViolationAnalysis], vote_threshold: float
) -> MajorityVoteResult:
    """
    Aggregate analyses into a majority vote result.

    Args:
        rule_name: The rule being analyzed
        analyses: List of ViolationAnalysis objects
        vote_threshold: Threshold for false positive classification

    Returns:
        MajorityVoteResult with the final decision
    """
    # Count votes
    false_positive_count = sum(1 for a in analyses if a.classification == "FALSE_POSITIVE")
    true_positive_count = sum(1 for a in analyses if a.classification == "POTENTIAL_TRUE_POSITIVE")
    no_op_count = sum(1 for a in analyses if a.classification == "NO_OP_REVERSION")

    # Determine majority - check for clear winner first
    total_votes = len(analyses)

    # If any single classification has majority, use it
    if no_op_count / total_votes >= vote_threshold:
        final_classification = "NO_OP_REVERSION"
    elif false_positive_count / total_votes >= vote_threshold:
        final_classification = "FALSE_POSITIVE"
    else:
        # Default to most cautious classification
        final_classification = "POTENTIAL_TRUE_POSITIVE"

    return MajorityVoteResult(
        rule_name=rule_name,
        final_classification=final_classification,
        individual_votes=analyses,
        false_positive_votes=false_positive_count,
        potential_true_positive_votes=true_positive_count,
        no_op_reversion_votes=no_op_count,
    )


def analyze_all_violations_with_majority_voting(
    contract_code: str,
    violations_data: dict[str, ViolationData],
    num_votes: int,
    vote_threshold: float,
    token_tracker: TokenUsageTracker,
) -> list[MajorityVoteResult]:
    """
    Analyze all violations using majority voting with full parallelization.
    Creates 3 analyses per rule and runs ALL analyses in parallel.

    Args:
        contract_code: The smart contract source code
        violations_data: Dictionary of rule violations
        num_votes: Number of votes for majority voting
        vote_threshold: Threshold for false positive classification
        token_tracker: TokenUsageTracker instance for recording token usage

    Returns:
        List of MajorityVoteResult objects
    """
    num_violations = len(violations_data)
    print(
        f"Found {num_violations} violations - running majority voting with {num_votes} analyses each ({num_violations * num_votes} total parallel analyses)"
    )

    # Save violations data for reference
    with open("violations_data.json", "w") as f:
        json.dump(violations_data, f, indent=2)

    # Create model for all analyses
    model = ChatAnthropic(  # type: ignore - ChatAnthropic constructor signature varies between versions
        model_name="claude-sonnet-4-20250514",
        max_tokens=20000,  # type: ignore - parameter name varies between versions
        temperature=0.8,
    )
    structured_model = model.with_structured_output(ViolationAnalysis, include_raw=True)

    # Create the contract system message once for all analyses
    contract_system_message = create_contract_system_message(contract_code)

    rule_items = list(violations_data.items())
    all_results = {}

    if not rule_items:
        return []

    print(f"Three-phase caching strategy for {len(rule_items)} rules:")

    # PHASE 1: Warm global cache (system prompt + contract context) with first rule's first vote
    first_rule_name, first_violation_data = rule_items[0]
    print(f"Phase 1: Warming global cache with {first_rule_name}")
    first_analysis = analyze_violation(
        structured_model, contract_system_message, first_rule_name, first_violation_data, token_tracker
    )
    all_results[first_rule_name] = {0: first_analysis}

    def create_runnable(rule_name: str, violation_data: ViolationData):
        return RunnableLambda(
            lambda _: analyze_violation(
                structured_model, contract_system_message, rule_name, violation_data, token_tracker
            )
        )

    # PHASE 2: Warm violation-specific caches by running first vote for each remaining rule
    if len(rule_items) > 1:
        print(f"Phase 2: Warming violation-specific caches for {len(rule_items) - 1} remaining rules...")
        phase2_runnables = {}

        for rule_name, violation_data in rule_items[1:]:
            phase2_runnables[rule_name] = create_runnable(rule_name, violation_data)

        # Run first votes for remaining rules in parallel (benefit from global cache)
        parallel_phase2 = RunnableParallel(phase2_runnables).with_config({"max_concurrency": 10})
        phase2_results = parallel_phase2.invoke({})

        # Update all_results with new nested structure
        for rule_name, analysis in phase2_results.items():
            all_results[rule_name] = {0: analysis}

    # PHASE 3: Run all remaining votes (num_votes-1 for each rule) in parallel
    # All caches should be established now
    print("Phase 3: Running remaining votes in parallel (all caches ready)...")
    phase3_runnables = {}

    for rule_name, violation_data in rule_items:
        # Add votes 1 and 2 (0-indexed) for each rule
        for vote_idx in range(1, num_votes):
            key = f"{rule_name}_vote_{vote_idx}"
            phase3_runnables[key] = create_runnable(rule_name, violation_data)

    if phase3_runnables:
        parallel_phase3 = RunnableParallel(phase3_runnables).with_config({"max_concurrency": 20})
        phase3_results = parallel_phase3.invoke({})

        # Update all_results with new nested structure
        for key, analysis in phase3_results.items():
            parts = key.split("_vote_")
            rule_name = parts[0]
            vote_idx = int(parts[1])
            if rule_name not in all_results:
                all_results[rule_name] = {}
            all_results[rule_name][vote_idx] = analysis

    # Group results by rule and aggregate majority votes
    majority_vote_results = []
    for rule_name in violations_data.keys():
        # Aggregate into majority vote
        majority_result = aggregate_majority_vote(rule_name, list(all_results[rule_name].values()), vote_threshold)
        majority_vote_results.append(majority_result)

    # Print summary
    false_positive_count = sum(1 for r in majority_vote_results if r.final_classification == "FALSE_POSITIVE")
    true_positive_count = sum(1 for r in majority_vote_results if r.final_classification == "POTENTIAL_TRUE_POSITIVE")
    no_op_count = sum(1 for r in majority_vote_results if r.final_classification == "NO_OP_REVERSION")

    print("Majority voting complete:")
    print(f"  - FALSE_POSITIVE: {false_positive_count}")
    print(f"  - POTENTIAL_TRUE_POSITIVE: {true_positive_count}")
    print(f"  - NO_OP_REVERSION: {no_op_count}")

    return majority_vote_results


def categorize_violations(
    majority_results: list[MajorityVoteResult], num_votes: int, contract_code: str, token_tracker: TokenUsageTracker
) -> CategorizationResult:
    """
    Categorize majority vote results into groups using a two-step process:
    1. Basic categorization without expressions
    2. Expression generation with grammar validation

    Args:
        majority_results: List of majority vote results
        num_votes: Number of votes used for majority decision
        contract_code: The smart contract source code
        token_tracker: TokenUsageTracker instance for recording token usage

    Returns:
        Categorization result with grouped violations and expressions
    """
    print(f"\nCategorizing {len(majority_results)} majority vote results using two-step process...")

    model = init_chat_model("claude-sonnet-4-20250514", model_provider="anthropic", max_tokens=10000, temperature=0)

    # Step 1: Basic categorization without expressions
    print("Step 1: Running basic categorization...")
    basic_model = model.with_structured_output(CategorizationResultBasic, include_raw=True)

    try:
        basic_messages = [
            SystemMessage(content=get_categorization_basic_system_prompt()),
            HumanMessage(content=create_categorization_prompt(majority_results, num_votes)),
        ]

        basic_categorization_dict = basic_model.invoke(basic_messages)
        assert isinstance(basic_categorization_dict, dict)
        basic_categorization = basic_categorization_dict["parsed"]
        assert isinstance(basic_categorization, CategorizationResultBasic)
        print(f"Basic categorization complete. Created {len(basic_categorization.categories)} categories.")

        # Track token usage for basic categorization
        token_tracker.log_usage_analyser(
            basic_categorization_dict["raw"], "categorization", description="  Basic categorization - "
        )

        # Step 2: Generate expressions for each category
        print("Step 2: Generating expressions...")
        expression_model = model.with_structured_output(CategorizationResult, include_raw=True)

        # Create contract system message (should still be in the cache from the analysis phase)
        contract_system_message = create_contract_system_message(contract_code)

        # Create prompt for expression generation
        expression_prompt = f"Here are the categorized violations that need expressions:\n\n{json.dumps(basic_categorization.model_dump(), indent=2)}"

        expression_messages = [
            SystemMessage(content=contract_system_message),
            SystemMessage(content=get_expression_generation_system_prompt()),
            HumanMessage(content=expression_prompt),
        ]

        final_categorization_dict = expression_model.invoke(expression_messages)
        assert isinstance(final_categorization_dict, dict)
        final_categorization = final_categorization_dict["parsed"]
        assert isinstance(final_categorization, CategorizationResult)
        print("Expression generation complete.")

        # Track token usage for expression generation
        token_tracker.log_usage_analyser(
            final_categorization_dict["raw"], "expression", description="  Expression generation - "
        )

        return final_categorization

    except Exception as e:
        print(f"Error during two-step categorization: {e}")
        raise


async def main():
    """Main entry point for the contract verification analyzer."""
    parser = argparse.ArgumentParser(description="Analyze smart contract formal verification rule violations")
    exclusive_group = parser.add_mutually_exclusive_group(required=True)
    exclusive_group.add_argument(
        "--job-dir",
        type=Path,
        help="Directory containing outputs of the Prover (zipOutput of cloud runs, or emv-* of local runs)",
    )
    exclusive_group.add_argument("--job-url", type=str, help="Public url to a Prover job")
    contract_group = parser.add_mutually_exclusive_group(required=True)
    contract_group.add_argument("--contract-file", type=Path, help="Path to the smart contract source file")
    contract_group.add_argument("--collect-sources", action="store_true", help="Collect all .sol files from the job")
    parser.add_argument(
        "--output-file",
        type=Path,
        default="analysis_results.json",
        help="Output file for AI's analysis (default: analysis_results.json)",
    )
    parser.add_argument("--num_votes", type=int, default=3, help="Number of votes for the majority vote (default: 3)")
    parser.add_argument(
        "--vote-threshold",
        type=float,
        default=0.5,
        help="Threshold for false positive classification. Higher values are more cautious (default: 0.5)",
    )
    parser.add_argument(
        "--log-tokens",
        type=str,
        metavar="FILEPATH",
        help="Enable detailed token usage tracking and save to specified filepath (e.g., token_usage.json)",
    )

    args = parser.parse_args()

    # Create violation analyzer
    analyzer = ViolationAnalyzer(
        job_url=args.job_url,
        job_dir=args.job_dir,
        contract_file=args.contract_file,
        collect_sources=args.collect_sources,
    )

    # Load contract code
    if not await analyzer.load_contract_code():
        return

    # Create token tracker
    token_tracker = TokenUsageTracker(filepath=args.log_tokens)

    # Run analysis
    await analyzer.run(
        output_file=args.output_file,
        num_votes=args.num_votes,
        vote_threshold=args.vote_threshold,
        token_tracker=token_tracker,
    )


if __name__ == "__main__":
    asyncio.run(main())
