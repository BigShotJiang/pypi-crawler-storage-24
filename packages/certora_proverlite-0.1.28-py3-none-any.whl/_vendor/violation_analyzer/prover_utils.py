import asyncio
import json
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, TypeAlias, TypedDict, cast
from urllib.parse import parse_qs, urlparse

import requests

StorageLayout: TypeAlias = list[dict[str, Any]]
RuleStatus: TypeAlias = Literal[
    "VIOLATED", "UNKNOWN", "ERROR", "TIMEOUT", "SKIPPED", "VERIFIED", "RUNNING", "SANITY_FAILED"
]


@dataclass
class RuleInfo:
    """Structure for info about violated rules returned by get_violated_rule_infos."""

    rule_output_file: str | None
    code_location: dict
    status: RuleStatus


class ViolationData(TypedDict):
    """Structure for violation data returned by process_verification_files."""

    rule_code: str
    variables: list[dict[str, Any]]
    storage: StorageLayout
    has_counter_example_havoc: bool
    has_imprecision: bool


class JobDataSource(ABC):
    """Abstract base class for accessing job data from different sources."""

    @abstractmethod
    def _get_treeview_status(self) -> dict[str, Any]:
        """Get the treeview status data."""
        pass

    @abstractmethod
    async def get_sol_files(self) -> str:
        """Get all .sol files combined into a single string."""
        pass

    @abstractmethod
    def _fetch_rule_file(self, rule_info: RuleInfo) -> dict[str, Any]:
        """Fetch a specific rule file."""
        pass

    async def process_verification_files(self) -> dict[str, ViolationData]:
        """
        Process all verification output files using this job data source.

        Returns:
            Dictionary mapping rule paths to ViolationData dictionaries
        """
        treeview_status = self._get_treeview_status()
        violated_rule_infos = self._get_violated_rule_infos(treeview_status)

        # Semaphore to limit concurrent operations
        semaphore = asyncio.Semaphore(10)

        async def process_rule(name: str, rule_info: RuleInfo) -> tuple[str, ViolationData] | None:
            rule_output_file = rule_info.rule_output_file
            code_location = rule_info.code_location
            async with semaphore:
                try:
                    tree_data = await asyncio.to_thread(self._fetch_rule_file, rule_info)
                    rule_file = await asyncio.to_thread(
                        self._fetch_source_file, f".certora_sources/{code_location['file']}"
                    )
                except (json.JSONDecodeError, IOError) as e:
                    print(f"Warning: Could not process {rule_output_file}: {e}")
                    print(code_location)
                    raise e

                # Skip files without call traces or vacuous rules
                if "callTrace" not in tree_data:
                    # This is probably a failing satisfy rule
                    return None

                rule_code = "\n".join(
                    rule_file.split("\n")[code_location["start"]["line"] - 1 : code_location["end"]["line"]]
                )

                # Extract storage states and variables
                all_storage_states = self._extract_storage_states(tree_data["callTrace"])
                if not all_storage_states:
                    return None

                cleaned_variables = self._clean_tree_structure(tree_data.get("variables", []), self.DELETEABLE_NODES)

                # Check for counter-example havoc and imprecision
                has_counter_example_havoc = self._has_counter_example_havoc(tree_data)
                has_imprecision = self._has_imprecision(tree_data)

                return (
                    name,
                    ViolationData(
                        rule_code=rule_code,
                        variables=cleaned_variables,
                        storage=all_storage_states[0],
                        has_counter_example_havoc=has_counter_example_havoc,
                        has_imprecision=has_imprecision,
                    ),
                )

        # Process all rules concurrently
        tasks = [process_rule(name, rule_info) for name, rule_info in violated_rule_infos.items()]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        violation_data = {}
        for result in results:
            if isinstance(result, BaseException):
                raise result
            elif result is not None:
                name, data = result
                violation_data[name] = data

        return violation_data

    @abstractmethod
    def _fetch_source_file(self, file_path: str) -> str:
        """Fetch a specific source file by path."""
        pass

    # Node types to remove from the analysis tree for cleaner output
    DELETEABLE_NODES = [
        "jumpToDefinition",
        "values",
        "storageId",
        "truncatable",
        "tooltip",
        "changedSinceStart",
        "changedSincePreviousPrint",
    ]

    def _clean_tree_structure(self, tree: Any, nodes_to_delete: list[str]) -> Any:
        """
        Recursively remove specified nodes from a nested data structure.

        Args:
            tree: The nested structure (dict, list, or primitive)
            nodes_to_delete: List of node names to remove

        Returns:
            Cleaned structure with specified nodes removed
        """
        if isinstance(tree, dict):
            return {
                key: self._clean_tree_structure(value, nodes_to_delete)
                for key, value in tree.items()
                if key not in nodes_to_delete
            }
        elif isinstance(tree, list):
            return [self._clean_tree_structure(item, nodes_to_delete) for item in tree]
        else:
            return tree

    def _extract_storage_states(self, tree: dict[str, Any]) -> list[StorageLayout]:
        """
        Extract storage states from the call trace tree.

        Args:
            tree: The call trace tree structure

        Returns:
            List of storage layouts found in the tree
        """
        if tree.get("message", {}).get("text") == "Global State":
            return [self._clean_tree_structure(tree["childrenList"], self.DELETEABLE_NODES)]

        storage_states = []
        for subtree in tree.get("childrenList", []):
            storage_states.extend(self._extract_storage_states(subtree))

        return storage_states

    def _get_violated_subrule_infos(self, node: dict, path: str) -> dict[str, RuleInfo]:
        full_name = f"{path}{node['name']}"
        match len(node["output"]):
            case 0:
                outputs = {}
                for child in node["children"]:
                    outputs |= self._get_violated_subrule_infos(child, full_name + "-")
                return outputs
            case 1:
                # Is it a violated node with a calltrace (i.e. not a failed satisfy rule)
                if node["status"] == "VIOLATED":
                    return {
                        full_name: RuleInfo(
                            rule_output_file=node["output"][0],
                            code_location=node["jumpToDefinition"],
                            status="VIOLATED",
                        )
                    }
                else:
                    return {}
            case _:
                print(f"While parsing treeViewStatus found a node ({full_name}) with multiple outputs")
                return {}

    def _get_violated_rule_infos(self, treeview_status: dict) -> dict[str, RuleInfo]:
        rule_infos = {}
        for rule in treeview_status.get("rules", []):
            rule_infos |= self._get_violated_subrule_infos(rule, "")

        return rule_infos

    def _get_non_violated_rule_infos(self, treeview_status: dict) -> dict[str, RuleInfo]:
        rule_infos = {}
        for rule in treeview_status.get("rules", []):
            if rule["status"] != "VIOLATED":
                rule_infos[rule["name"]] = RuleInfo(
                    rule_output_file=None,
                    code_location=rule["jumpToDefinition"],
                    status=cast(RuleStatus, rule["status"]),
                )
        return rule_infos

    def get_non_violated_rules(self) -> dict[str, str]:
        """
        Returns:
            a dict from rule name to its (non-violated) status
        """
        treeview_status = self._get_treeview_status()
        infos = self._get_non_violated_rule_infos(treeview_status)
        return {name: info.status for name, info in infos.items()}

    def _has_counter_example_havoc(self, tree_data: dict[str, Any]) -> bool:
        """
        Check if the rule has havoc nodes with isInCounterExample: true in callResolutionWarnings.

        Args:
            tree_data: The rule output JSON data

        Returns:
            True if there's a havoc node with isInCounterExample: true
        """
        call_resolution_warnings = tree_data.get("callResolutionWarnings", [])
        for warning in call_resolution_warnings:
            if warning.get("isInCounterExample") is True:
                return True
        return False

    def _has_imprecision(self, tree_data: dict[str, Any]) -> bool:
        """
        Check if the rule has imprecision nodes in the call trace.

        Args:
            tree_data: The rule output JSON data

        Returns:
            True if there's a node with status "IMPRECISION" in the call trace
        """
        call_trace = tree_data.get("callTrace")
        if call_trace:
            return self._check_tree_for_imprecision(call_trace)
        return False

    def _check_tree_for_imprecision(self, node: dict[str, Any]) -> bool:
        """
        Recursively check a call trace tree node for imprecision.

        Args:
            node: A node in the call trace tree

        Returns:
            True if this node or any child has status "IMPRECISION"
        """
        # Check if this node has imprecision status
        if node.get("status") == "IMPRECISION":
            return True

        # Recursively check children
        for child in node.get("childrenList", []):
            if self._check_tree_for_imprecision(child):
                return True

        return False


class PathJobSource(JobDataSource):
    """Job data source that reads from local filesystem paths."""

    def __init__(self, job_dir: Path):
        self.job_dir = job_dir
        self.treeview_dir = job_dir / "Reports" / "treeView"
        if not self.treeview_dir.is_dir():
            print(f"Error: {self.treeview_dir} is not a directory")
            raise RuntimeError(f"Could not find dir {self.treeview_dir}")
        self.sources_dir = job_dir / "inputs" / ".certora_sources"
        if not self.sources_dir.is_dir():
            print(f"Error: {self.sources_dir} is not a directory")
            raise RuntimeError(f"Could not find dir {self.sources_dir}")

    def _get_treeview_status(self) -> dict[str, Any]:
        """Get the treeview status from local files."""
        # Find the treeViewStatus file with the largest N
        max_n = -1
        latest_status_file = None
        for file_path in self.treeview_dir.iterdir():
            if file_path.name.startswith("treeViewStatus_") and file_path.suffix == ".json":
                try:
                    n_value = int(file_path.stem.split("_")[1])
                    if n_value > max_n:
                        max_n = n_value
                        latest_status_file = file_path
                except (ValueError, IndexError):
                    continue

        if latest_status_file:
            print(f"Found latest treeViewStatus file: {latest_status_file.name}")
        else:
            raise FileExistsError("No treeViewStatus_N.json files found")

        return json.loads(latest_status_file.read_text())

    async def get_sol_files(self) -> str:
        combined_content = ""
        for sol_file in self.sources_dir.rglob("*.sol"):
            try:
                relative_path = sol_file.relative_to(self.sources_dir)
                # Skip if any directory component in the path is hidden
                if any(part.startswith(".") for part in relative_path.parts[:-1]):  # Exclude filename from check
                    continue

                content = sol_file.read_text()
                combined_content += f"// File: {relative_path}\n{content}\n\n"
            except Exception as e:
                print(f"Warning: Could not read {sol_file}: {e}")

        return combined_content

    def _fetch_rule_file(self, rule_info: RuleInfo) -> dict[str, Any]:
        """Fetch a rule file from local filesystem."""
        assert rule_info.rule_output_file is not None, "Attempting to fetch rule file for rule with no such file"
        treeview_output_file_path = self.treeview_dir / rule_info.rule_output_file
        try:
            return json.loads(treeview_output_file_path.read_text())
        except Exception as e:
            print(f"Error reading file {treeview_output_file_path}: {e}")
            sys.exit(1)

    def _fetch_source_file(self, file_path: str) -> str:
        """Fetch a source file from local filesystem."""
        source_file_path = self.job_dir / "inputs" / file_path
        return source_file_path.read_text()


class UrlJobSource(JobDataSource):
    """Job data source that fetches from remote Certora URLs."""

    def __init__(self, job_url: str):
        self.job_id, self.anonymous_key = self._parse_certora_url(job_url)

    def _parse_certora_url(self, job_url: str) -> tuple[str, str]:
        """
        Parse a Certora output URL to extract job_id and anonymous key.

        Args:
            url: Certora output URL like 'https://prover.certora.com/output/97560/85cdc83bc611411da28ac63f76e2e445/?anonymousKey=...'

        Returns:
            Tuple of (job_id, anonymous_key)

        Raises:
            ValueError: If the URL format is invalid
        """
        parsed_url = urlparse(job_url)

        # Extract job_id from path like /output/97560/85cdc83bc611411da28ac63f76e2e445/
        path_parts = parsed_url.path.strip("/").split("/")
        if len(path_parts) < 3 or path_parts[0] != "output":
            raise ValueError(f"Invalid Certora URL format: {job_url}")

        job_id = path_parts[2]  # The third part is the job_id

        # Extract anonymousKey from query parameters
        query_params = parse_qs(parsed_url.query)
        if "anonymousKey" not in query_params:
            raise ValueError(f"anonymousKey not found in URL: {job_url}")

        anonymous_key = query_params["anonymousKey"][0]

        return job_id, anonymous_key

    def _fetch_treeview_file(self, path: str) -> str:
        """
        Fetch a tree-view file from Certora's API.

        Args:
            url: Certora output URL
            path: Path to the tree-view file (e.g., 'treeViewStatus.json', 'rule_output.json')

        Returns:
            Contents of the file as a string
        """

        api_url = f"https://prover.certora.com/v1/domain/jobs/{self.job_id}/tree-view"
        params = {"path": path, "anonymousKey": self.anonymous_key}

        response = requests.get(api_url, params=params, allow_redirects=True)
        response.raise_for_status()

        return response.text

    def _fetch_source_file(self, file_path: str) -> str:
        """
        Fetch a source file from Certora's API.

        Args:
            url: Certora output URL
            path: Path to the source file (e.g., 'rule.spec', 'contract.sol')

        Returns:
            Contents of the file as a string
        """
        api_url = f"https://prover.certora.com/v1/domain/jobs/{self.job_id}/source-files"
        params = {"path": file_path, "anonymousKey": self.anonymous_key}

        response = requests.get(api_url, params=params, allow_redirects=True)
        response.raise_for_status()

        return response.text

    def _fetch_file(self, filename: str) -> str:
        """
        Fetch a general file from Certora's API using the legacy endpoint.

        Args:
            url: Certora output URL
            filename: Name of the file to fetch (can include subdirectories like 'treeView/file.json')

        Returns:
            Contents of the file as a string
        """
        api_url = f"https://prover.certora.com/v1/domain/jobs/{self.job_id}/f/{filename}"
        params = {"anonymousKey": self.anonymous_key}

        response = requests.get(api_url, params=params, allow_redirects=True)
        response.raise_for_status()

        return response.text

    def _get_treeview_status(self) -> dict[str, Any]:
        """Get the treeview status from remote API."""
        return json.loads(self._fetch_treeview_file("treeViewStatus.json"))

    def _list_certora_source_files(self) -> list[dict]:
        """List all source files available from Certora's API."""
        return json.loads(self._fetch_source_file(""))

    def _extract_sol_files(self, file_tree: list[dict]) -> list[str]:
        """Recursively extract all .sol file paths from the file tree structure, ignoring hidden subdirectories."""
        sol_files = []

        for item in file_tree:
            if item.get("selectable", False) and item.get("output", "").endswith(".sol"):
                sol_files.append(item["output"])

            # Recursively process children, but skip hidden directories
            if "children" in item and item["children"]:
                item_name = item.get("name", "")
                if not item_name.startswith("."):
                    sol_files.extend(self._extract_sol_files(item["children"]))

        return sol_files

    async def get_sol_files(self) -> str:
        """Get all .sol files from remote sources."""

        async def fetch_remote_files():
            file_tree = self._list_certora_source_files()
            sol_file_paths = self._extract_sol_files(file_tree)

            print(f"Found {len(sol_file_paths)} .sol files to fetch")

            # Fetch all .sol files concurrently
            semaphore = asyncio.Semaphore(10)  # Limit concurrent requests

            async def fetch_single_file(file_path: str) -> tuple[str, str]:
                async with semaphore:
                    try:
                        content = await asyncio.to_thread(self._fetch_source_file, file_path)
                        return file_path, content
                    except Exception as e:
                        print(f"Warning: Could not fetch {file_path}: {e}")
                        return file_path, ""

            # Fetch all files
            tasks = [fetch_single_file(path) for path in sol_file_paths]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Combine all files
            combined_content = ""
            for result in results:
                if isinstance(result, BaseException):
                    print(f"Error fetching file: {result}")
                    continue

                file_path, content = result
                if content:
                    # Remove .certora_sources/ prefix for cleaner display
                    display_path = file_path.replace(".certora_sources/", "")
                    combined_content += f"// File: {display_path}\n{content}\n\n"

            return combined_content

        return await fetch_remote_files()

    def _fetch_rule_file(self, rule_info: RuleInfo) -> dict[str, Any]:
        """Fetch a rule file from remote API."""
        assert rule_info.rule_output_file is not None, "Attempting to fetch rule file for rule with no such file"
        return json.loads(self._fetch_treeview_file(rule_info.rule_output_file))
