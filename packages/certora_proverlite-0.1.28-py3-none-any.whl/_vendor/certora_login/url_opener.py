"""URL opener with non-raising HTTPErrorProcessor."""

import re
from datetime import UTC, datetime
from http.client import HTTPResponse
from logging import getLogger
from urllib.request import HTTPErrorProcessor, Request, build_opener

from .exceptions import CertoraLoginValidationError

logger = getLogger(__name__)


RE_CERTORA_COOKIE = re.compile(r"(?P<name>certora.*?)=(?P<token>.*);?")


def obfuscate_cookies(header: str | list[str]) -> str:
    """Obfuscate Certora cookies in header for logging."""
    if isinstance(header, str):
        return RE_CERTORA_COOKIE.sub(
            lambda m: f"{m['name']}={m['token'][:3]}...{m['token'][-3:]}",
            header,
        )

    return " ".join(
        # Name, first and last 3 characters of the token with ... in between
        RE_CERTORA_COOKIE.sub(
            lambda m: f"{m['name']}={m['token'][:3]}...{m['token'][-3:]}",
            h,
        )
        for h in header
    )


def _sanitize_url(url: str) -> str:
    if "?" in url:
        url = url[: url.find("?")]
    return url


class _NonRaisingHTTPErrorProcessor(HTTPErrorProcessor):
    def https_response(
        self,
        request: Request,
        response: HTTPResponse,
    ) -> HTTPResponse:  # pragma: no cover
        url = _sanitize_url(str(request.full_url))
        logger.debug(
            "HTTP Request: %s %s - Headers: %s",
            request.get_method(),
            url,
            " ".join(f"{k}={v}" for k, v in request.headers.items()),
        )

        if response.status >= 400:  # noqa: PLR2004
            url = _sanitize_url(str(request.full_url))
            logger.debug(
                "HTTP Response: %s: %s (%s) - Headers: %s",
                url,
                response.reason,
                response.status,
                " ".join(f"{k}={v}" for k, v in request.headers.items()),
            )

        return response


URL_OPENER = build_opener(_NonRaisingHTTPErrorProcessor)

_DEFAULT_HEADERS: dict[str, str] = {
    # Identifies the client application
    "User-Agent": "CertoraCloudCLI/1.0",
    # Indicates accepted response media types
    "Accept": "application/json, text/plain, */*",
    # Controls connection persistence
    "Connection": "keep-alive",
    # Controls caching behavior
    "Cache-Control": "no-cache",
    # Indicates preferred language (optional, can be customized)
    "Accept-Language": "en-US,en;q=0.9",
}
COOKIE_FINDER = re.compile(
    r"^(?P<name>certoraToken|certoraRefreshToken|user)=(?P<value>[^;]+);",
)


def get_url(url: str, cookies: str | None = None) -> tuple[bytes, dict[str, str]]:
    """Read URL content."""
    headers = {
        **_DEFAULT_HEADERS,
    }
    if cookies:
        headers["Cookie"] = cookies

    cert_cookies = {}
    with URL_OPENER.open(Request(url, headers=headers)) as f:
        data = f.read()

        cookies = f.info().get_all("Set-Cookie")
        if cookies:
            cert_cookies = {
                match.group("name"): match.group("value")
                for c in cookies
                if (match := COOKIE_FINDER.search(c))
            }
            cert_cookies["timestamp"] = int(
                datetime.now(tz=UTC).timestamp(),
            )
            logger.debug("Cookies: %s", obfuscate_cookies(cookies))

        if f.status >= 400:  # noqa: PLR2004
            msg = "Failed to read URL %s: %s (%d) - %s"
            raise CertoraLoginValidationError(
                msg, url, f.reason, f.status, data.decode(errors="ignore")
            )

    return data, cert_cookies
