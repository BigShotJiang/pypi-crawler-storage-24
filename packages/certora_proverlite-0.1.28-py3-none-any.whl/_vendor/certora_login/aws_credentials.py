"""Module to get temporal AWS credentials from Certora."""

import json
from datetime import datetime
from typing import Literal, overload

from .constants import SERVERS
from .exceptions import CertoraLoginValidationError
from .models import (
    AwsBotoSession,
    AwsCredentialsEnv,
    AwsCredentialsProcess,
    CertoraTokens,
    Env,
    TempAwsCredentials,
    cookie_string,
)
from .url_opener import get_url


def get_temporal_aws_credentials(
    certora_tokens: CertoraTokens,
    *,
    env: Env = "prod",
) -> TempAwsCredentials:  # pragma: no cover
    """Get temporal AWS credentials from Certora.

    This function gets temporal AWS credentials from Certora using the provided
    Certora tokens. The credentials are returned as a TempAwsCredentials object.

    Args:
        certora_tokens (CertoraTokens): Certora tokens
        env (Literal["dev", "stg", "prod"], optional): Environment to get credentials
            from. Defaults to "prod".

    Returns:
        TempAwsCredentials: Temporal AWS credentials

    Raises:
        ValueError: If the request fails

    """
    data, _ = get_url(
        f"{SERVERS[env]}/v1/auth/aws-credentials", cookies=cookie_string(certora_tokens)
    )

    try:
        creds_dict = json.loads(data)
    except json.JSONDecodeError:
        creds_dict = {}

    return TempAwsCredentials(
        aws_access_key_id=creds_dict.get("aws_access_key_id", ""),
        aws_secret_access_key=creds_dict.get("aws_secret_access_key", ""),
        aws_session_token=creds_dict.get("aws_session_token", ""),
        expiration=datetime.fromisoformat(
            creds_dict.get("expiration", "2000-01-01T00:00:00+00:00")
        ),
    )


@overload
def convert_credentials(
    aws_credentials: TempAwsCredentials,
    cred_format: Literal["boto-session"],
) -> AwsBotoSession: ...


@overload
def convert_credentials(
    aws_credentials: TempAwsCredentials,
    cred_format: Literal["env"],
) -> AwsCredentialsEnv: ...


@overload
def convert_credentials(
    aws_credentials: TempAwsCredentials,
    cred_format: Literal["process"],
) -> AwsCredentialsProcess: ...


def convert_credentials(
    aws_credentials: TempAwsCredentials,
    cred_format: Literal["boto-session", "process", "env"],
) -> AwsCredentialsEnv | AwsBotoSession | AwsCredentialsProcess:  # pragma: no cover
    """Convert temporal AWS credentials to different formats.

    This function converts temporal AWS credentials to different formats. The supported
    formats are "boto-session", "env", and "process".

    Args:
        aws_credentials (TempAwsCredentials): Temporal AWS credentials
        cred_format (Literal["boto-session", "env", "process"]): Format to convert to.
            Supported values: "boto-session", "env", "process"

    Returns:
        Union[AwsBotoSession, AwsCredentialsEnv, AwsCredentialsProcess]: Converted
            credentials.

    Raises:
        CertoraLoginValidationError: If the format is invalid

    """
    if cred_format not in ("boto-session", "env", "process"):
        msg = "Invalid credentials format: %s"
        raise CertoraLoginValidationError(msg, cred_format)

    if cred_format == "boto-session":
        return AwsBotoSession(
            aws_access_key_id=aws_credentials["aws_access_key_id"],
            aws_secret_access_key=aws_credentials["aws_secret_access_key"],
            aws_session_token=aws_credentials["aws_session_token"],
        )
    if cred_format == "env":
        return AwsCredentialsEnv(
            AWS_ACCESS_KEY_ID=aws_credentials["aws_access_key_id"],
            AWS_SECRET_ACCESS_KEY=aws_credentials["aws_secret_access_key"],
            AWS_SESSION_TOKEN=aws_credentials["aws_session_token"],
            AWS_CREDENTIAL_EXPIRATION=aws_credentials["expiration"].isoformat(),
        )
    return AwsCredentialsProcess(
        Version=1,
        AccessKeyId=aws_credentials["aws_access_key_id"],
        SecretAccessKey=aws_credentials["aws_secret_access_key"],
        SessionToken=aws_credentials["aws_session_token"],
        Expiration=aws_credentials["expiration"].isoformat(),
    )
