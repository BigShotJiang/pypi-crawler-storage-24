"""Module to handle credentials."""

import json
from functools import lru_cache
from logging import getLogger

try:
    from keyring import delete_password, get_password, set_password
    from keyring.errors import KeyringError

    _KEYRING = True
except ImportError:  # pragma: no cover
    _KEYRING = False

    # fmt: off
    def get_password(service_name: str, username: str) -> str | None: ... # noqa: D103
    def set_password(service_name: str, username: str, password: str) -> None: ... # noqa: D103
    def delete_password(service_name: str, username: str) -> None: ... # noqa: D103

    class KeyringError(Exception): ...  # type: ignore[no-redef] # noqa: D101
    # fmt: on


from .exceptions import CertoraLoginValidationError
from .models import CertoraTokens
from .settings import settings

logger = getLogger(__name__)


def save_credentials(tokens: CertoraTokens, *, force_file: bool = False) -> None:
    """Save credentials to file or keyring.

    If keyring is available, the credentials are saved there. Otherwise, they are saved
    to a file.

    Args:
        tokens (CertoraTokens): Credentials to save
        force_file (bool, optional): Force saving to file even if keyring is available.
            Defaults to False.

    """
    token_string = json.dumps(tokens)
    if _KEYRING and not force_file:  # pragma: no cover
        set_password("com.certora.", "certoraTokens", token_string)
    else:
        logger.warning("Keyring not available, saving to file %s", settings.cred_file)
        settings.cred_file.parent.mkdir(exist_ok=True)
        settings.cred_file.write_text(token_string)
        settings.cred_file.chmod(0o600)

    get_credentials.cache_clear()


def convert_credentials(obj: object) -> CertoraTokens:
    """Convert credentials from various sources to CertoraTokens.

    Two main sources are supported:
        1. A dictionary with keys "certoraToken", "certoraRefreshToken", "user", and
           "timestamp"
        2. An object with attributes "certora_token", "certora_refresh_token", "user",
           and "timestamp"

    Args:
        obj (object): Object to convert

    Raises:
        CertoraLoginValidationError: If one or more of the required fields are missing
            or invalid.

    Returns:
        CertoraTokens: CertoraTokens object

    """
    token = None
    refresh_token = None
    user_id = None

    if isinstance(obj, dict):
        token = obj.get("certoraToken")
        refresh_token = obj.get("certoraRefreshToken")
        user_id = obj.get("user")
        timestamp = obj.get("timestamp")
    else:  # pragma: no cover
        token = getattr(obj, "certora_token", None)
        refresh_token = getattr(obj, "certora_refresh_token", None)
        user_id = getattr(obj, "user", None)
        timestamp = getattr(obj, "timestamp", None)

    if not (
        token
        and refresh_token
        and user_id
        and isinstance(token, str)
        and isinstance(refresh_token, str)
        and isinstance(user_id, str)
        and isinstance(timestamp, int)
    ):  # pragma: no cover
        msg = "Invalid credentials"
        raise CertoraLoginValidationError(msg)

    return CertoraTokens(
        certoraToken=token,
        certoraRefreshToken=refresh_token,
        user=user_id,
        timestamp=timestamp,
    )


@lru_cache
def get_credentials() -> CertoraTokens | None:
    """Load credentials from file or keyring.

    Loads credentials from file if available, otherwise from keyring. If neither is
    available, returns None. Use `login` to get new credentials.

    Method is cached to avoid multiple reads (`functools.lru_cache`). In order to clean
    the cache, use `get_credentials.cache_clear()`.

    Returns:
        CertoraTokens | None: Credentials if found, None otherwise

    """
    if settings.cred_file.exists():
        logger.info("Reading credentials from file %s", settings.cred_file)
        t = json.loads(settings.cred_file.read_text())
    elif _KEYRING:  # pragma: no cover
        logger.info("Reading credentials from keyring")
        t = get_password("com.certora.", "certoraTokens")
        if not t:
            return None
        t = json.loads(t)
    else:
        return None

    return convert_credentials(t)


def delete_credentials() -> None:
    """Remove credentials from file or keyring."""
    get_credentials.cache_clear()
    if settings.cred_file.exists():
        logger.info("Deleting credentials from file %s", settings.cred_file)
        settings.cred_file.unlink()
    if _KEYRING and get_credentials() is not None:  # pragma: no cover
        logger.info("Deleting credentials from keyring")
        try:
            delete_password("com.certora.", "certoraTokens")
        except Exception as e:  # pragma: no cover # noqa: BLE001
            logger.warning("Failed to delete credentials from keyring: %s", e)
            set_password("com.certora.", "certoraTokens", "")
    get_credentials.cache_clear()
