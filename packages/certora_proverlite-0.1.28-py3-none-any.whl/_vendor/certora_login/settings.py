"""Simple settings for Certora Login."""

from dataclasses import dataclass
from pathlib import Path


@dataclass
class Settings:
    """Settings for Certora Login."""

    cred_file: Path


settings = Settings(cred_file=Path.home() / ".certora" / "credentials.json")
