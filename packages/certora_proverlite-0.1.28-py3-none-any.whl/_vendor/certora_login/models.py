"""Dta models for the certora-login package."""

from datetime import datetime
from typing import Literal, TypedDict

Env = Literal["prod", "stg", "dev"]
ExportType = Literal["process", "env", "env-no-export"]


class CertoraTokens(TypedDict):
    """CertoraTokens represents the tokens returned by the Certora login API."""

    certoraToken: str
    certoraRefreshToken: str
    user: str
    timestamp: int


def cookie_string(credentials: CertoraTokens) -> str:
    """Convert credentials to a cookie string.

    This function converts the credentials to a cookie string that can be used
    in an HTTP request. The timestamp field is excluded from the cookie string.

    Args:
        credentials (CertoraTokens): Credentials to convert

    """
    return "; ".join(f"{k}={v}" for k, v in credentials.items() if k != "timestamp")


class AwsBotoSession(TypedDict):
    """BotoSession represents arguments for creating a boto3 session."""

    aws_access_key_id: str
    aws_secret_access_key: str
    aws_session_token: str


class TempAwsCredentials(AwsBotoSession):
    """TempAwsCredentials AWS credentials returned by the Certora login API."""

    expiration: datetime


class AwsCredentialsEnv(TypedDict):
    """AWS credentials in environment variable format."""

    AWS_ACCESS_KEY_ID: str
    AWS_SECRET_ACCESS_KEY: str
    AWS_SESSION_TOKEN: str
    AWS_CREDENTIAL_EXPIRATION: str


class AwsCredentialsProcess(TypedDict):
    """AWS credentials in process environment variable format."""

    Version: int
    AccessKeyId: str
    SecretAccessKey: str
    SessionToken: str
    Expiration: str
