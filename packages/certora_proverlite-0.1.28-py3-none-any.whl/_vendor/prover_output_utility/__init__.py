"""
ProverOutputUtility - Python API for parsing Certora Prover outputs.

This module provides an easy-to-use API for fetching and parsing outputs from the Certora Prover.
Supports both job URLs and job IDs as input.
"""

from .prover_api import ProverOutputAPI
from .models import (
    AssertType,
    CheckResult,
    JobStatus,
    NodeStatus,
    NodeType,
)

__version__ = "1.0.0"
__all__ = [
    "ProverOutputAPI",
    "AssertType",
    "CheckResult",
    "JobStatus",
    "NodeStatus",
    "NodeType",
]
