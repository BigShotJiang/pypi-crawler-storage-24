"""
Low-level data fetching utilities for the Prover API.
"""
import functools
from typing import Any, Callable, Dict, List, Optional, TypeVar, cast

import requests

from ..exceptions import AuthenticationError, JobNotFoundError, ProverAPIError
from .base_data_fetcher import BaseDataFetcher

T = TypeVar("T")


def handle_token_expiration(func: Callable[..., T]) -> Callable[..., T]:
    """Decorator to handle token expiration and retry with re-authentication."""

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs) -> T:
        try:
            return func(self, *args, **kwargs)
        except AuthenticationError as e:
            # Check if this is a token expiration error (401 response)
            if "401" in str(e) or "Authentication failed" in str(e):
                # Only retry once
                if not getattr(self, "_retry_auth", False):
                    self._retry_auth = True
                    try:
                        # Get the API instance and force re-login
                        if hasattr(self, "_api_instance"):
                            self._api_instance._setup_session(force_relogin=True)
                            # Update our session reference
                            self.session = self._api_instance.session
                        # Retry the original request
                        result = func(self, *args, **kwargs)
                        self._retry_auth = False
                        return result
                    finally:
                        self._retry_auth = False
            raise

    return wrapper


class DataFetcher(BaseDataFetcher):
    """Handles low-level data fetching from Certora API endpoints."""

    def __init__(self, session: requests.Session, api_instance=None):
        """
        Initialize the data fetcher.

        Args:
            session: Configured requests session with authentication
            api_instance: Reference to the ProverOutputAPI instance for re-auth
        """
        self.session = session
        self.base_url = "https://data-api.certora.com"
        self._api_instance = api_instance
        self._retry_auth = False

    def _execute_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None
    ) -> requests.Response:
        """
        Execute HTTP request with method dispatch.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: Full URL endpoint
            params: Query parameters (for GET/DELETE)
            json_data: JSON body data (for POST/PUT)

        Returns:
            requests.Response object

        Raises:
            ProverAPIError: If HTTP method is unsupported
        """
        if method.upper() == "GET":
            return self.session.get(endpoint, params=params)
        elif method.upper() == "POST":
            return self.session.post(endpoint, json=json_data)
        elif method.upper() == "PUT":
            return self.session.put(endpoint, json=json_data)
        elif method.upper() == "DELETE":
            return self.session.delete(endpoint, params=params)
        else:
            raise ProverAPIError(f"Unsupported HTTP method: {method}")

    @handle_token_expiration
    def fetch_raw_output(self, job_identifier: str) -> Dict[str, Any]:
        """
        Fetch raw output data from the prover API.

        Args:
            job_identifier: Job ID to fetch

        Returns:
            Raw API response data

        Raises:
            AuthenticationError: If authentication fails
            JobNotFoundError: If job is not found
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/v1/domain/jobs/{job_identifier}"

        try:
            response = self.session.get(endpoint)

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check CERTORAKEY")
            elif response.status_code == 404:
                raise JobNotFoundError(f"Job {job_identifier} not found")
            else:
                response.raise_for_status()
                return cast(Dict[str, Any], response.json())

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch job data for {job_identifier}: {e}")

    @handle_token_expiration
    def fetch_tree_view_data(
        self, job_identifier: str, path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Fetch tree-view data for a job.

        Args:
            job_identifier: Job ID to fetch
            path: Optional path within the tree-view

        Returns:
            Tree-view data

        Raises:
            AuthenticationError: If authentication fails
            JobNotFoundError: If job is not found
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/v1/domain/jobs/{job_identifier}/tree-view"

        params = {}
        if path:
            params["path"] = path

        try:
            response = self.session.get(endpoint, params=params)

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check CERTORAKEY")
            elif response.status_code == 404:
                raise JobNotFoundError(f"Tree-view data not found for job {job_identifier}")
            else:
                response.raise_for_status()
                return cast(Dict[str, Any], response.json())

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch tree-view data for {job_identifier}: {e}")

    @handle_token_expiration
    def fetch_statsdata(self, job_identifier: str) -> Dict[str, Any]:
        """
        Fetch statsdata.json for a job.

        Args:
            job_identifier: Job ID to fetch

        Returns:
            Stats data from statsdata.json

        Raises:
            AuthenticationError: If authentication fails
            JobNotFoundError: If job is not found
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/v1/domain/jobs/{job_identifier}/f/statsdata.json"

        try:
            response = self.session.get(endpoint)

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check CERTORAKEY")
            elif response.status_code == 404:
                raise JobNotFoundError(f"Stats data not found for job {job_identifier}")
            else:
                response.raise_for_status()
                return cast(Dict[str, Any], response.json())

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch stats data for {job_identifier}: {e}")

    def fetch_outputs(self, job_identifier: str) -> bytes:
        """
        Fetch outputs archive (tar.gz) for a job.

        Args:
            job_identifier: Job ID to fetch

        Returns:
            Raw tar.gz content as bytes

        Raises:
            AuthenticationError: If authentication fails
            JobNotFoundError: If job is not found
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/v1/domain/jobs/{job_identifier}/f/outputs"

        try:
            response = self.session.get(endpoint)

            if response.status_code == 200:
                return response.content
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check CERTORAKEY")
            elif response.status_code == 404:
                raise JobNotFoundError(f"Outputs not found for job {job_identifier}")
            else:
                response.raise_for_status()
                return response.content

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch outputs for {job_identifier}: {e}")

    def list_recent_jobs(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        List recent jobs for the authenticated user.

        Args:
            limit: Maximum number of jobs to return

        Returns:
            List of job information dictionaries

        Raises:
            ProverAPIError: If API call fails
        """
        # Placeholder for jobs listing endpoint
        endpoint = "https://prover.certora.com/api/jobs"

        try:
            response = self.session.get(endpoint, params={"limit": limit})
            response.raise_for_status()
            return cast(List[Dict[str, Any]], response.json().get("jobs", []))

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to list recent jobs: {e}")

    @handle_token_expiration
    def cancel_jobs(self, job_ids: List[str]) -> Dict[str, Any]:
        """
        Cancel multiple jobs by their IDs.

        Args:
            job_ids: List of job IDs to cancel

        Returns:
            API response data

        Raises:
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/v1/domain/jobs/cancel"
        payload = {"ids": job_ids}

        try:
            response = self.session.post(endpoint, json=payload)

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check CERTORAKEY")
            elif response.status_code == 404:
                raise JobNotFoundError("Cancel endpoint not found")
            else:
                response.raise_for_status()
                return cast(Dict[str, Any], response.json())

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to cancel jobs {job_ids}: {e}")

    @handle_token_expiration
    def fetch_console_logs(self, job_identifier: str) -> str:
        """
        Fetch console logs for a job.

        Args:
            job_identifier: Job ID to fetch logs for

        Returns:
            Console logs as a string

        Raises:
            AuthenticationError: If authentication fails
            JobNotFoundError: If job is not found
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/v1/domain/jobs/{job_identifier}/logs"

        try:
            response = self.session.get(endpoint)

            if response.status_code == 200:
                return response.text
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check CERTORAKEY")
            elif response.status_code == 404:
                raise JobNotFoundError(f"Console logs not found for job {job_identifier}")
            else:
                response.raise_for_status()
                return response.text

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch console logs for {job_identifier}: {e}")

    @handle_token_expiration
    def who_am_i(self) -> Dict[str, Any]:
        """
        Get information about the currently authenticated user.

        Returns:
            User information including email and user ID

        Raises:
            AuthenticationError: If authentication fails
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/who-am-i"

        try:
            response = self.session.get(endpoint)

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check credentials")
            else:
                response.raise_for_status()
                return cast(Dict[str, Any], response.json())

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to get user information: {e}")

    @handle_token_expiration
    def fetch_custom_endpoint(
        self, endpoint: str, params: Optional[Dict[str, Any]] = None, method: str = "GET"
    ) -> Dict[str, Any]:
        """
        Fetch data from an arbitrary user-provided endpoint.

        Args:
            endpoint: The full URL endpoint to fetch from
            params: Optional query parameters or request body
            method: HTTP method (GET, POST, etc.)

        Returns:
            API response data

        Raises:
            AuthenticationError: If authentication fails
            ProverAPIError: If API call fails
        """
        try:
            # Use helper method for HTTP method dispatch
            if method.upper() in ("GET", "DELETE"):
                response = self._execute_request(method, endpoint, params=params)
            elif method.upper() in ("POST", "PUT"):
                response = self._execute_request(method, endpoint, json_data=params)
            else:
                raise ProverAPIError(f"Unsupported HTTP method: {method}")

            if response.status_code == 200:
                return cast(Dict[str, Any], response.json())
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check credentials")
            else:
                response.raise_for_status()
                return cast(Dict[str, Any], response.json())

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch from custom endpoint {endpoint}: {e}")

    @handle_token_expiration
    def fetch_alert_report(self, job_identifier: str) -> List[Dict[str, Any]]:
        """
        Fetch alert report (alertReport.json) for a job.

        Args:
            job_identifier: Job ID to fetch

        Returns:
            Alert report data as a list of alert objects

        Raises:
            AuthenticationError: If authentication fails
            JobNotFoundError: If job is not found
            ProverAPIError: If API call fails
        """
        endpoint = f"{self.base_url}/v1/domain/jobs/{job_identifier}/f/alertReport.json"

        try:
            response = self.session.get(endpoint)

            if response.status_code == 200:
                return cast(List[Dict[str, Any]], response.json())
            elif response.status_code == 401:
                raise AuthenticationError("Authentication failed - check CERTORAKEY")
            elif response.status_code == 404:
                raise JobNotFoundError(f"Alert report not found for job {job_identifier}")
            else:
                response.raise_for_status()
                return cast(List[Dict[str, Any]], response.json())

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch alert report for {job_identifier}: {e}")
