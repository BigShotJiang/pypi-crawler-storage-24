"""
Main ProverOutputAPI class that provides the high-level interface.
"""

import io
import json
import logging
import os
import tarfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from ..auth import ProverAuth
from ..aws_auth import AWSAuth
from ..breadcrumb import BreadcrumbParser
from ..exceptions import ProverAPIError
from ..models import (
    BreadcrumbInfo,
    CallResolutionInfo,
    CalltraceInfo,
    CheckResult,
    JobInfo,
    JobStatus,
    TreeViewData,
    convert_job_status,
)
from ..parsers import OutputParser
from .aws_data_fetcher import AWSDataFetcher
from .cache import APICache
from .data_fetcher import DataFetcher
from .local_data_fetcher import LocalDataFetcher
from .tree_parser import TreeParser
from .url_utils import extract_job_id, extract_job_identifier


class ProverOutputAPI:
    """
    Main API class for fetching and parsing Certora Prover outputs.

    Authentication is handled automatically via cert_cli_login when accessing remote APIs.
    No CERTORAKEY required.

    Usage:
        # Remote API (default) - uses cert_cli_login for authentication
        api = ProverOutputAPI()
        violations = api.get_violated_rules("https://prover.certora.com/output/12345/...")
        violations = api.get_violated_rules("12345")

        # Local emv-* folders (no authentication needed)
        api = ProverOutputAPI(use_local=True)
        violations = api.get_violated_rules("/path/to/emv-1-certora-19-Aug--13-09")
        violations = api.get_violated_rules("./emv-1-certora-19-Aug--13-09")
    """

    def __init__(
        self,
        certora_key: Optional[str] = None,
        enable_cache: bool = True,
        use_local: bool = False,
    ):
        """
        Initialize the ProverOutputAPI.

        Args:
            certora_key: Deprecated - authentication is handled automatically via cert_cli_login
            enable_cache: Whether to enable persistent caching of API responses (default: True)
            use_local: Whether to use local emv-* folders instead of remote API (default: False)
        """
        self.logger = logging.getLogger(__name__)
        self.parser = OutputParser()
        self.breadcrumb_parser = BreadcrumbParser()
        self.tree_parser = TreeParser()
        self.use_local = use_local
        

        # Initialize cache
        self.cache = APICache() if enable_cache else None

        # Initialize appropriate data fetcher
        if use_local:
            self.data_fetcher = LocalDataFetcher()
        elif os.getenv("CI") and self._is_aws_available():
            # In CI with AWS credentials, use AWS Lambda authentication
            self.logger.info("Using AWS Lambda authentication in CI")
            aws_auth = AWSAuth()
            aws_session = aws_auth.get_session()
            self.data_fetcher = AWSDataFetcher(aws_session)
            # No session needed for AWS auth
            self.session = None
        else:
            # Regular cookie-based authentication
            self.auth = ProverAuth()
            self._setup_session()

    def _setup_session(self, force_relogin: bool = False):
        """Setup session with authentication cookies."""
        self.session = requests.Session()
        # Set up authentication
        self.session.cookies = self.auth.get_auth_cookies(force_relogin=force_relogin)
        self.data_fetcher = DataFetcher(self.session, api_instance=self)

    def _is_aws_available(self) -> bool:
        """Check if AWS authentication is available."""
        try:
            aws_auth = AWSAuth()
            return aws_auth.is_available()
        except Exception:
            return False

    def _extract_job_identifier(self, job_input: str) -> str:
        """
        Extract job identifier based on the fetcher type.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            Job identifier (job_id for remote, emv_path for local)
        """
        if self.use_local:
            # For local, validate it's an emv-* path and return the path
            job_identifier, input_type = extract_job_identifier(job_input)
            if input_type != "local":
                raise ProverAPIError(
                    f"ProverOutputAPI configured for local use but got remote input: {job_input}"
                )
            return job_identifier
        else:
            # For remote, extract job ID from URL or use direct job ID
            return extract_job_id(job_input)


    def get_treeview_status(self, job_input: str) -> Dict[str, Any]:
        """
        Get tree view status data with caching for completed jobs.

        This is a public API method that retrieves the treeViewStatus.json file
        for a job. The data is cached for completed jobs to improve performance.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            Tree view status data as a dictionary

        Example:
            ```python
            api = ProverOutputAPI()
            tree_status = api.get_treeview_status("12345678")
            print(f"Tree status: {tree_status}")
            ```
        """
        job_identifier = self._extract_job_identifier(job_input)
        return self._get_tree_view_status(job_identifier)

    def _get_tree_view_status(self, job_identifier: str) -> Dict[str, Any]:
        """
        Get tree view status data with caching for completed jobs.

        Internal method - use get_treeview_status() for the public API.
        Only caches treeViewStatus.json if the job is not running.

        Args:
            job_identifier: Job ID or local emv-* path

        Returns:
            Tree view status data
        """
        # Check cache first (only for remote jobs)
        cache_key = "treeViewStatus.json"
        if self.cache and not self.use_local:
            cached_data = self.cache.get("tree_view_status", job_identifier, cache_key)
            if cached_data:
                self.logger.debug(f"Using cached treeViewStatus for job {job_identifier}")
                return cached_data

        # Fetch the data
        tree_data = self.data_fetcher.fetch_tree_view_data(
            job_identifier, path="treeViewStatus.json"
        )

        # Cache if job is not running (only for remote jobs)
        if self.cache and not self.use_local:
            # Check if job is running by looking for finish_time in the tree data
            # or by calling is_job_running
            try:
                # Get job info to check if it's running
                raw_output = self.data_fetcher.fetch_raw_output(job_identifier)
                is_running = raw_output.get("finish_time") is None

                if not is_running:
                    self.logger.debug(f"Caching treeViewStatus for completed job {job_identifier}")
                    self.cache.set("tree_view_status", tree_data, job_identifier, cache_key)
                else:
                    self.logger.debug(
                        f"Not caching treeViewStatus for running job {job_identifier}"
                    )
            except Exception as e:
                # If we can't determine job status, don't cache
                self.logger.debug(f"Could not determine job status for caching: {e}")

        return tree_data

    def fetch_output(self, job_input: str) -> Dict[str, Any]:
        """
        Fetch and parse prover output from either a job URL, job ID, or local emv-* path.

        This method is kept for backward compatibility.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            Parsed output data as a dictionary

        Raises:
            ProverAPIError: If API call fails
        """
        job_identifier = self._extract_job_identifier(job_input)
        self.logger.info(f"Fetching output for job: {job_identifier}")

        try:
            raw_output = self.data_fetcher.fetch_raw_output(job_identifier)
            parsed_output = self.parser.parse(raw_output)
            return parsed_output

        except requests.exceptions.RequestException as e:
            raise ProverAPIError(f"Failed to fetch output for job {job_identifier}: {e}")

    def get_violated_rules(self, job_input: str) -> List[CheckResult]:
        """
        Get all violated rules for a job with assert messages.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            List of ViolationInfo objects for violated rules
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            tree_data = self._get_tree_view_status(job_identifier)
            violations = self.tree_parser.parse_violations(tree_data)
            return violations

        except Exception as e:
            raise ProverAPIError(f"Failed to get violated rules for job {job_identifier}: {e}")

    def get_all_checks(self, job_input: str) -> List[CheckResult]:
        """
        Get all checks (both successful and failed) for a job.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            List of ViolationInfo objects for all checks
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            tree_data = self._get_tree_view_status(job_identifier)
            all_checks = self.tree_parser.parse_all_checks(tree_data)
            return all_checks

        except Exception as e:
            raise ProverAPIError(f"Failed to get all checks for job {job_identifier}: {e}")

    def get_leaf_checks(self, job_input: str) -> List[CheckResult]:
        """
        Get only leaf checks (actual assertions without intermediate tree nodes) for a job.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            List of CheckResult objects for leaf checks only
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            tree_data = self._get_tree_view_status(job_identifier)
            leaf_checks = self.tree_parser.parse_leaf_checks(tree_data)
            return leaf_checks

        except Exception as e:
            raise ProverAPIError(f"Failed to get leaf checks for job {job_identifier}: {e}")

    def fetch_treeview_output_by_filename(self, job_input: str, filename: str) -> Dict[str, Any]:
        """
        Fetch a specific tree view output file by filename.

        This is a public API method that retrieves individual output files from
        the tree-view data, such as rule outputs, calltraces, or other JSON files.
        The data is cached for completed jobs to improve performance.

        Args:
            job_input: Job URL, job ID, or local emv-* path
            filename: Filename within tree-view (e.g., 'rule_output_58.json', 'dap_calltrace_56-certora-dap.json')

        Returns:
            Tree view output data as a dictionary

        Example:
            ```python
            api = ProverOutputAPI()

            # Fetch a rule output file
            rule_output = api.fetch_treeview_output_by_filename("12345678", "rule_output_58.json")
            print(f"Rule data: {rule_output}")

            # Fetch a calltrace/DAP file
            dap_data = api.fetch_treeview_output_by_filename("12345678", "dap_calltrace_56-certora-dap.json")
            print(f"DAP data: {dap_data}")
            ```
        """
        job_identifier = self._extract_job_identifier(job_input)
        return self._fetch_tree_view_data_with_cache(job_identifier, filename)

    def _fetch_tree_view_data_with_cache(self, job_identifier: str, path: str) -> Dict[str, Any]:
        """
        Fetch tree view data with caching support.

        Internal method - use fetch_treeview_output_by_filename() for the public API.
        Handles caching logic for tree view data fetches.
        Checks bulk cache first, then individual cache, then API.

        Args:
            job_identifier: Job ID or local emv-* path
            path: Path within tree-view (e.g., 'rule_output_58.json')

        Returns:
            Tree view data
        """
        # Check bulk cache first (disk-based)
        if not self.use_local:
            bulk_cache_dir = self._get_bulk_cache_dir(job_identifier)
            bulk_file_path = bulk_cache_dir / path
            if bulk_file_path.exists():
                try:
                    with open(bulk_file_path, 'r') as f:
                        data = json.load(f)
                    self.logger.debug(f"Using bulk cache for {path} in job {job_identifier}")
                    return data
                except Exception as e:
                    self.logger.warning(f"Failed to read bulk cache file {bulk_file_path}: {e}")

        # Check individual hash-based cache
        cache_key = f"tree_view:{path}"

        if self.cache and not self.use_local:
            cached_data = self.cache.get("tree_view_data", job_identifier, cache_key)
            if cached_data:
                self.logger.debug(f"Using cached tree view data for {path} in job {job_identifier}")
                return cached_data

        # Fetch from API if not cached
        data = self.data_fetcher.fetch_tree_view_data(job_identifier, path=path)

        # Cache for completed jobs (rule outputs and calltraces are immutable once job completes)
        if self.cache and not self.use_local and data:
            try:
                # Check if job is completed before caching
                raw_output = self.data_fetcher.fetch_raw_output(job_identifier)
                is_running = raw_output.get("finish_time") is None

                if not is_running:
                    self.logger.debug(
                        f"Caching tree view data for {path} in completed job {job_identifier}"
                    )
                    self.cache.set("tree_view_data", data, job_identifier, cache_key)
            except Exception:
                # If we can't determine job status, cache anyway for rule outputs
                # (they're immutable and won't change)
                if path.startswith("rule_output") or path.endswith(".json"):
                    self.logger.debug(f"Caching tree view data for {path}")
                    self.cache.set("tree_view_data", data, job_identifier, cache_key)

        return data

    def get_calltrace(self, job_input: str, output_file: str) -> CalltraceInfo:
        """
        Get calltrace data for a specific rule using its output file path.

        Args:
            job_input: Job URL, job ID, or local emv-* path
            output_file: Output file path from the violation's output field

        Returns:
            CalltraceInfo object with wrapped calltrace data
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            calltrace_data = self._fetch_tree_view_data_with_cache(job_identifier, output_file)
            return CalltraceInfo(
                job_id=job_identifier,
                output_file=output_file,
                trace_data=calltrace_data,
            )

        except Exception as e:
            raise ProverAPIError(
                f"Failed to get calltrace for output file {output_file} in job {job_identifier}: {e}"
            )

    def get_calltrace_for_violation(self, job_input: str, violation: CheckResult) -> CalltraceInfo:
        """
        Get calltrace data for a specific violation using its output files.

        Args:
            job_input: Job URL, job ID, or local emv-* path
            violation: ViolationInfo object

        Returns:
            CalltraceInfo object, or raises error if no output files
        """
        if not violation.output_files:
            raise ProverAPIError("No output files available for this violation")

        # Use the first output file (there might be multiple)
        output_file = violation.output_files[0]
        calltrace = self.get_calltrace(job_input, output_file)
        calltrace.rule_name = violation.rule_name
        return calltrace

    def get_breadcrumbs(self, job_input: str, dap_file: str) -> BreadcrumbInfo:
        """
        Get breadcrumb trace summary from a DAP file with caching.

        Args:
            job_input: Job URL, job ID, or local emv-* path
            dap_file: DAP file path (e.g., 'dap_calltrace_56-certora-dap.json')

        Returns:
            BreadcrumbInfo object with execution trace
        """
        job_identifier = self._extract_job_identifier(job_input)

        # Check cache first
        if self.cache:
            cached_data = self.cache.get("get_breadcrumbs", job_identifier, dap_file)
            if cached_data:
                self.logger.debug(
                    f"Using cached breadcrumbs for {dap_file} in job {job_identifier}"
                )
                return BreadcrumbInfo.from_dict(cached_data, dap_file=dap_file)

        try:
            dap_data = self.data_fetcher.fetch_tree_view_data(job_identifier, path=dap_file)
            breadcrumbs_data = self.breadcrumb_parser.parse_dap_file(dap_data)

            # Cache the result
            if self.cache:
                self.cache.set("get_breadcrumbs", breadcrumbs_data, job_identifier, dap_file)

            return BreadcrumbInfo.from_dict(breadcrumbs_data, dap_file=dap_file)

        except Exception as e:
            raise ProverAPIError(
                f"Failed to get breadcrumbs from DAP file {dap_file} in job {job_identifier}: {e}"
            )

    def get_breadcrumbs_for_violation(
        self, job_input: str, violation: CheckResult
    ) -> BreadcrumbInfo:
        """
        Get breadcrumb trace summary for a specific violation using its debug trace file.

        Args:
            job_input: Job URL, job ID, or local emv-* path
            violation: ViolationInfo object

        Returns:
            BreadcrumbInfo object with execution trace
        """
        if not violation.debug_trace_file:
            raise ProverAPIError("No debug trace file available for this violation")

        return self.get_breadcrumbs(job_input, violation.debug_trace_file)

    def get_unresolved_calls(self, job_input: str) -> List[CallResolutionInfo]:
        """
        Get call resolution information from the globalCallResolution field.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            List of CallResolutionInfo objects
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            tree_data = self._get_tree_view_status(job_identifier)
            call_resolutions = self.tree_parser.parse_call_resolutions(tree_data)
            return call_resolutions

        except Exception as e:
            raise ProverAPIError(f"Failed to get unresolved calls for job {job_identifier}: {e}")

    def get_tree_view_data(self, job_input: str) -> TreeViewData:
        """
        Get wrapped tree-view data for a job.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            TreeViewData object
        """
        job_identifier = self._extract_job_identifier(job_input)
        raw_data = self._get_tree_view_status(job_identifier)
        return TreeViewData.from_dict(raw_data, job_identifier)

    def get_job_status(self, job_input: str) -> JobStatus:
        """
        Get the status of a job without fetching full output.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            JobStatus enum value
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            raw_output = self.data_fetcher.fetch_raw_output(job_identifier)
            status_str = raw_output.get("job_status", "unknown")
            return convert_job_status(status_str)
        except Exception as e:
            raise ProverAPIError(f"Failed to get status for job {job_identifier}: {e}")

    def get_job_info(self, job_input: str) -> JobInfo:
        """
        Get comprehensive job information.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            JobInfo object with job details
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            raw_output = self.data_fetcher.fetch_raw_output(job_identifier)
            status_str = raw_output.get("job_status", "unknown")
            return JobInfo(
                job_id=job_identifier,
                status=convert_job_status(status_str),
                start_time=raw_output.get("start_time"),
                finish_time=raw_output.get("finish_time"),
                user_id=raw_output.get("user_id"),
                project=raw_output.get("project"),
                contract=raw_output.get("contract"),
                raw_data=raw_output,
            )
        except Exception as e:
            raise ProverAPIError(f"Failed to get job info for {job_identifier}: {e}")

    def is_job_running(self, job_input: str) -> bool:
        """
        Check if a job is still running by checking if finish_time is null.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            True if job is still running, False if completed
        """
        job_info = self.get_job_info(job_input)
        return job_info.is_running

    def list_recent_jobs(self, limit: int = 10) -> List[JobInfo]:
        """
        List recent jobs for the authenticated user.

        Args:
            limit: Maximum number of jobs to return

        Returns:
            List of JobInfo objects

        Raises:
            ProverAPIError: If configured for local use
        """
        if self.use_local:
            raise ProverAPIError(
                "list_recent_jobs is not supported when using local prover outputs"
            )

        raw_jobs = self.data_fetcher.list_recent_jobs(limit)
        return [JobInfo.from_dict(job_data) for job_data in raw_jobs]

    def cancel_jobs(self, job_inputs: List[str]) -> Dict[str, Any]:
        """
        Cancel multiple jobs by their URLs or IDs.

        Args:
            job_inputs: List of job URLs or job IDs to cancel

        Returns:
            API response data with cancellation results

        Raises:
            ProverAPIError: If cancellation fails or configured for local use
        """
        if self.use_local:
            raise ProverAPIError("cancel_jobs is not supported when using local prover outputs")

        # Extract job IDs from URLs or use IDs directly
        job_ids = []
        for job_input in job_inputs:
            try:
                job_id = extract_job_id(job_input)
                job_ids.append(job_id)
            except Exception as e:
                self.logger.warning(f"Failed to extract job ID from {job_input}: {e}")
                # Skip invalid inputs rather than failing completely
                continue

        if not job_ids:
            raise ProverAPIError("No valid job IDs found to cancel")

        self.logger.info(f"Cancelling {len(job_ids)} jobs: {job_ids}")
        return self.data_fetcher.cancel_jobs(job_ids)

    def cancel_job(self, job_input: str) -> Dict[str, Any]:
        """
        Cancel a single job by its URL or ID.

        Args:
            job_input: Job URL or job ID to cancel

        Returns:
            API response data with cancellation results

        Raises:
            ProverAPIError: If cancellation fails or configured for local use
        """
        return self.cancel_jobs([job_input])

    def get_statsdata(self, job_input: str) -> Dict[str, Any]:
        """
        Get statsdata.json for a job.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            Stats data from statsdata.json

        Raises:
            ProverAPIError: If fetching fails
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            return self.data_fetcher.fetch_statsdata(job_identifier)
        except Exception as e:
            raise ProverAPIError(f"Failed to get statsdata for job {job_identifier}: {e}")

    def get_console_logs(self, job_input: str) -> str:
        """
        Get console logs for a job. This contains the full console output 
        including error messages like filtering errors.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            Console logs as a string

        Raises:
            AuthenticationError: If authentication fails
            JobNotFoundError: If job is not found or logs are not available
            ProverAPIError: If API call fails or configured for local use
        """
        if self.use_local:
            raise ProverAPIError("get_console_logs is not supported when using local prover outputs")

        job_identifier = self._extract_job_identifier(job_input)

        try:
            return self.data_fetcher.fetch_console_logs(job_identifier)
        except Exception as e:
            raise ProverAPIError(f"Failed to get console logs for job {job_identifier}: {e}")

    def get_alert_report(self, job_input: str) -> List[Dict[str, Any]]:
        """
        Get alert report for a job. This contains prover alerts and messages.

        Args:
            job_input: Job URL, job ID, or local emv-* path

        Returns:
            Alert report data as a list of alert objects

        Raises:
            JobNotFoundError: If job is not found or alert report is not available  
            ProverAPIError: If API call fails
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            return self.data_fetcher.fetch_alert_report(job_identifier)
        except Exception as e:
            raise ProverAPIError(f"Failed to get alert report for job {job_identifier}: {e}")

    def who_am_i(self) -> Dict[str, Any]:
        """
        Get information about the currently authenticated user.

        Returns:
            User information including email, user ID, and other details

        Raises:
            AuthenticationError: If authentication fails
            ProverAPIError: If API call fails or configured for local use
        """
        if self.use_local:
            raise ProverAPIError("who_am_i is not supported when using local prover outputs")

        try:
            return self.data_fetcher.who_am_i()
        except Exception as e:
            raise ProverAPIError(f"Failed to get user information: {e}")

    def parse_tree_view_path(self, tree_view_path: str) -> List[str]:
        """
        Parse a treeViewPath field to extract the rule hierarchy.

        The treeViewPath is split by '-' to create a list representing
        the hierarchical structure of the rule.

        Args:
            tree_view_path: The treeViewPath string from rule_output files

        Returns:
            List of hierarchy levels extracted from the path

        Example:
            Input: "sanity-previewUnwindExercise(bytes32,uint256)-Satisfy_sanity_check_failed_(sanity_spec_11_5)-sanity check failed"
            Output: ["sanity", "previewUnwindExercise(bytes32,uint256)", "Satisfy_sanity_check_failed_(sanity_spec_11_5)", "sanity check failed"]
        """
        if not tree_view_path:
            return []

        # Split by '-' to get hierarchy levels
        hierarchy = tree_view_path.split("-")

        # Clean up any extra whitespace
        hierarchy = [level.strip() for level in hierarchy if level.strip()]

        return hierarchy

    def get_rule_hierarchy(self, job_input: str, output_file: str) -> List[str]:
        """
        Get the rule hierarchy from a rule output file's treeViewPath.

        Args:
            job_input: Job URL, job ID, or local emv-* path
            output_file: Output file path (e.g., 'rule_output_58.json')

        Returns:
            List of hierarchy levels extracted from the treeViewPath

        Example:
            Returns ["sanity", "previewUnwindExercise(bytes32,uint256)",
                     "Satisfy_sanity_check_failed_(sanity_spec_11_5)", "sanity check failed"]
        """
        job_identifier = self._extract_job_identifier(job_input)

        try:
            # Use the cached fetch method
            rule_data = self._fetch_tree_view_data_with_cache(job_identifier, output_file)

            # Extract and parse the treeViewPath
            if isinstance(rule_data, dict) and "treeViewPath" in rule_data:
                return self.parse_tree_view_path(rule_data["treeViewPath"])

            return []

        except Exception as e:
            raise ProverAPIError(
                f"Failed to get rule hierarchy for {output_file} in job {job_identifier}: {e}"
            )

    # Backward compatibility methods that return raw dicts
    def _get_violated_rules_dict(self, job_input: str) -> List[Dict[str, Any]]:
        """Get violated rules as raw dictionaries (backward compatibility)."""
        violations = self.get_violated_rules(job_input)
        return [v.to_dict() for v in violations]

    def _get_all_checks_dict(self, job_input: str) -> List[Dict[str, Any]]:
        """Get all checks as raw dictionaries (backward compatibility)."""
        checks = self.get_all_checks(job_input)
        return [c.to_dict() for c in checks]

    def _get_leaf_checks_dict(self, job_input: str) -> List[Dict[str, Any]]:
        """Get leaf checks as raw dictionaries (backward compatibility)."""
        leaf_checks = self.get_leaf_checks(job_input)
        return [c.to_dict() for c in leaf_checks]

    # Compatibility methods for tests that use internal parsing methods
    def _parse_tree_view_for_all_checks(self, tree_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Parse tree-view data for all checks (backward compatibility for tests)."""
        # Create parser if not exists (for tests that bypass __init__)
        if not hasattr(self, "tree_parser"):
            from .tree_parser import TreeParser

            self.tree_parser = TreeParser()
        checks = self.tree_parser.parse_all_checks(tree_data)
        return [c.to_dict() for c in checks]

    def _parse_tree_view_for_violations(self, tree_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Parse tree-view data for VIOLATED_ASSERT nodes (backward compatibility for tests).

        Note: This returns only VIOLATED_ASSERT nodes, not all nodes with VIOLATED status.
        For all violated nodes, use parse_violations() directly.
        """
        # Create parser if not exists (for tests that bypass __init__)
        if not hasattr(self, "tree_parser"):
            from .tree_parser import TreeParser

            self.tree_parser = TreeParser()
        violations = self.tree_parser.parse_violated_asserts(tree_data)
        return [v.to_dict() for v in violations]

    def fetch_custom_endpoint(
        self, endpoint: str, params: Optional[Dict[str, Any]] = None, method: str = "GET"
    ) -> Dict[str, Any]:
        """
        Fetch data from an arbitrary user-provided endpoint.

        Args:
            endpoint: The full URL endpoint to fetch from
            params: Optional query parameters (for GET/DELETE) or request body (for POST/PUT)
            method: HTTP method (GET, POST, PUT, DELETE)

        Returns:
            API response data

        Raises:
            ProverAPIError: If configured for local use or if API call fails
            AuthenticationError: If authentication fails
        """
        if self.use_local:
            raise ProverAPIError(
                "fetch_custom_endpoint is not supported when using local prover outputs"
            )

        try:
            return self.data_fetcher.fetch_custom_endpoint(endpoint, params, method)
        except Exception as e:
            raise ProverAPIError(f"Failed to fetch from custom endpoint {endpoint}: {e}")

    def download_job_outputs(self, job_input: str) -> Dict[str, Any]:
        """
        Download and extract all output files for a job using bulk tar.gz download.
        
        This method downloads the entire job output archive and extracts individual
        JSON files to disk cache. Subsequent calls to get_rule_hierarchy, get_calltrace, 
        etc. will read from local disk instead of making individual API calls.
        
        Args:
            job_input: Job URL, job ID, or local emv-* path
        
        Returns:
            Dictionary with download statistics:
            {
                'files_extracted': 123,
                'download_size_mb': 30.4,
                'download_time_s': 4.22,
                'extraction_time_s': 1.15,
                'cache_dir': '/path/to/cache'
            }
        
        Raises:
            ProverAPIError: If configured for local use or if download fails
        """
        if self.use_local:
            raise ProverAPIError(
                "download_job_outputs is not supported when using local prover outputs"
            )
        
        job_identifier = self._extract_job_identifier(job_input)
        
        # Check if already downloaded
        cache_dir = self._get_bulk_cache_dir(job_identifier)
        if cache_dir.exists():
            existing_files = list(cache_dir.glob("*.json"))
            if existing_files:
                self.logger.info(f"Job outputs already cached for {job_identifier} ({len(existing_files)} files)")
                return {
                    'files_extracted': len(existing_files),
                    'download_size_mb': 0,
                    'download_time_s': 0,
                    'extraction_time_s': 0,
                    'cache_hit': True,
                    'cache_dir': str(cache_dir)
                }
        
        self.logger.info(f"Downloading bulk outputs for job {job_identifier}")
        
        try:
            import time
            
            # Download tar.gz using data_fetcher
            start_download = time.time()
            tar_content = self.data_fetcher.fetch_outputs(job_identifier)
            download_time = time.time() - start_download
            download_size_mb = len(tar_content) / (1024 * 1024)
            
            # Create cache directory
            cache_dir = self._get_bulk_cache_dir(job_identifier)
            cache_dir.mkdir(parents=True, exist_ok=True)
            
            # Extract tar.gz directly to disk
            start_extraction = time.time()
            files_extracted = 0
            
            with tarfile.open(fileobj=io.BytesIO(tar_content), mode='r:gz') as tar:
                for member in tar.getmembers():
                    if member.isfile() and member.name.endswith('.json'):
                        try:
                            # Extract file content
                            file_obj = tar.extractfile(member)
                            if file_obj:
                                content = file_obj.read().decode('utf-8')
                                # Validate JSON
                                json_data = json.loads(content)
                                
                                # Save to disk with just filename
                                filename = os.path.basename(member.name)
                                file_path = cache_dir / filename
                                
                                with open(file_path, 'w') as f:
                                    json.dump(json_data, f, indent=2, default=str)
                                
                                files_extracted += 1
                                
                        except (json.JSONDecodeError, UnicodeDecodeError) as e:
                            self.logger.warning(f"Skipping invalid file {member.name}: {e}")
                            continue
            
            extraction_time = time.time() - start_extraction
            
            self.logger.info(
                f"Downloaded {files_extracted} files for job {job_identifier} "
                f"({download_size_mb:.1f}MB in {download_time:.2f}s + {extraction_time:.2f}s extraction)"
            )
            
            return {
                'files_extracted': files_extracted,
                'download_size_mb': download_size_mb,
                'download_time_s': download_time,
                'extraction_time_s': extraction_time,
                'cache_hit': False,
                'cache_dir': str(cache_dir)
            }
            
        except Exception as e:
            raise ProverAPIError(f"Failed to download job outputs for {job_identifier}: {e}")

    def _get_bulk_cache_dir(self, job_identifier: str) -> Path:
        """Get the bulk cache directory for a specific job."""
        if self.cache:
            base_dir = self.cache.cache_dir.parent / "bulk_cache"
        else:
            # Fallback if no regular cache enabled
            base_dir = Path.cwd() / ".certora_internal" / "bulk_cache"
        
        return base_dir / f"job_{job_identifier}"
