"""
Token usage tracking utilities for Claude API calls.

This module provides TokenUsageTracker for extracting,
recording, and reporting token usage from Claude responses.
"""

import json
import logging
import shutil
import os
from collections import defaultdict
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
from typing import Any

# Configure logging
log_level = os.getenv("LOGLEVEL", "WARNING").upper()
logging.basicConfig(level=getattr(logging, log_level), format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


class TokenType(str, Enum):
    """Enumeration of token usage types."""

    GENERATOR = "GENERATOR"
    VIOLATION_ANALYSER = "VIOLATION_ANALYSER"
    SUMMARIZATION = "SUMMARIZATION"
    TOTAL = "TOTAL"


@dataclass
class TokenUsageRecord:
    """Represents a single token usage record with metrics and context.

    Attributes:
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        cache_creation_input_tokens: Tokens written to cache
        cache_read_input_tokens: Tokens read from cache
        total_tokens: Sum of all token types
        total_calls: Always 1 for individual records
        key: Optional context key identifying the request
        type: Type of operation (TokenType enum)
    """

    input_tokens: int
    output_tokens: int
    cache_creation_input_tokens: int
    cache_read_input_tokens: int
    total_tokens: int
    total_calls: int
    key: str | None = None
    type: TokenType | None = None

    def to_dict(self) -> dict:
        """Convert record to dictionary, excluding None values and converting enums to strings."""
        result = asdict(self)
        # Convert enum to string for JSON serialization
        if result.get("type") is not None:
            result["type"] = result["type"].value
        # Remove None values to maintain backward compatibility
        return {k: v for k, v in result.items() if v is not None}


class TokenUsageTracker:
    """Tracks and extracts token usage from LangChain responses.

    This class provides utilities to extract token usage information from
    Claude API responses, record usage across multiple calls, and generate
    reports showing total token consumption and cache efficiency.

    Class Constants:
        INPUT_TOKENS: Key for input token count
        OUTPUT_TOKENS: Key for output token count
        CACHE_CREATION_TOKENS: Key for cache creation token count
        CACHE_READ_TOKENS: Key for cache read token count
        TOTAL_TOKENS: Key for total token count
        TOTAL_CALLS: Key for total API call count

    Attributes:
        records: List of dictionaries containing token usage for each API call

    Example:
        >>> tracker = TokenUsageTracker(filepath="token_usage.json")
        >>> response = model.invoke(messages)
        >>> tracker.print_usage(response, prefix="API call - ")
        >>> totals = tracker.get_totals()
        >>> print(f"Total tokens used: {totals[TokenUsageTracker.TOTAL_TOKENS]}")
        >>> tracker.save_to_file()  # Saves to the filepath specified in constructor
    """

    # Token usage dictionary keys
    INPUT_TOKENS = "input_tokens"
    OUTPUT_TOKENS = "output_tokens"
    CACHE_CREATION_TOKENS = "cache_creation_input_tokens"
    CACHE_READ_TOKENS = "cache_read_input_tokens"
    TOTAL_TOKENS = "total_tokens"
    TOTAL_CALLS = "total_calls"

    def __init__(self, filepath: str | None = None):
        """Initialize a new TokenUsageTracker with an empty record list.

        Args:
            enabled: If False, tracking is disabled and methods become no-ops
            filepath: Path to save the JSON file (default: "token_usage.json")
        """
        self.records: list[TokenUsageRecord] = []
        self.enabled = bool(filepath)
        self.filepath = filepath if filepath is not None else "token_usage.json"

    def extract_and_record(
        self, response: Any, key: str | None = None, type: TokenType | None = None
    ) -> TokenUsageRecord | None:
        """Extract token usage from a response and record it.

        Attempts to extract token usage information from the response object
        by checking both usage_metadata and response_metadata attributes.
        Records the usage information with optional key for identification.

        Args:
            response: The response object from a LangChain model invocation
            key: Optional key identifying the request (e.g., function name)
            type: Type of operation (TokenType enum)

        Returns:
            TokenUsageRecord instance with token usage information, or None if tracking is disabled
            or no metadata could be extracted from the response.
        """
        if not self.enabled:
            return None

        input_tokens = 0
        output_tokens = 0
        cache_creation_tokens = 0
        cache_read_tokens = 0
        data_extracted = False

        # Try to extract from usage_metadata first (preferred for basic tokens)
        if hasattr(response, "usage_metadata") and response.usage_metadata:
            usage = response.usage_metadata
            input_tokens = usage.get(self.INPUT_TOKENS, 0)
            output_tokens = usage.get(self.OUTPUT_TOKENS, 0)
            cache_creation_tokens = usage.get(self.CACHE_CREATION_TOKENS, 0)
            cache_read_tokens = usage.get(self.CACHE_READ_TOKENS, 0)
            data_extracted = True
        # Fallback to response_metadata
        elif hasattr(response, "response_metadata"):
            metadata = response.response_metadata.get("usage", {})
            if metadata:  # Only if usage dict exists
                input_tokens = metadata.get(self.INPUT_TOKENS, 0)
                output_tokens = metadata.get(self.OUTPUT_TOKENS, 0)
                cache_creation_tokens = metadata.get(self.CACHE_CREATION_TOKENS, 0)
                cache_read_tokens = metadata.get(self.CACHE_READ_TOKENS, 0)
                data_extracted = True

        # IMPORTANT: LangChain's Anthropic integration does NOT include cache tokens in usage_metadata,
        # so we must ALWAYS check response_metadata for cache tokens, even if we got basic tokens from usage_metadata
        if hasattr(response, "response_metadata") and response.response_metadata:
            metadata = response.response_metadata.get("usage", {})
            if metadata:
                # Override cache tokens from response_metadata (authoritative source for cache metrics)
                cache_creation_tokens = metadata.get(self.CACHE_CREATION_TOKENS, 0)
                cache_read_tokens = metadata.get(self.CACHE_READ_TOKENS, 0)
                data_extracted = True

        # Return None if no metadata could be extracted
        if not data_extracted:
            return None

        # IMPORTANT: input_tokens already includes cache_creation_tokens and cache_read_tokens
        # So total = input_tokens + output_tokens (not adding cache tokens separately)
        total_tokens = input_tokens + output_tokens

        record = TokenUsageRecord(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_creation_input_tokens=cache_creation_tokens,
            cache_read_input_tokens=cache_read_tokens,
            total_tokens=total_tokens,
            total_calls=1,
            key=key,
            type=type,
        )

        self.records.append(record)

        # Diagnostic logging to help track token recording
        logger.debug(
            f"[DEBUG] Recorded tokens: Input={input_tokens}, Output={output_tokens}, Total records={len(self.records)}"
        )

        return record

    def print_usage(self, response: Any, prefix: str = ""):
        """Extract and print token usage from a response.

        Convenience method that extracts token usage and prints it to stdout
        in a human-readable format.

        Args:
            response: The response object from  Claude invocation
            prefix: Optional prefix for the print output
        """
        token_usage = self.extract_and_record(response)
        if token_usage:
            print(
                f"{prefix}Tokens - Input: {token_usage.input_tokens}, "
                f"Output: {token_usage.output_tokens}, "
                f"Cache creation: {token_usage.cache_creation_input_tokens}, "
                f"Cache read: {token_usage.cache_read_input_tokens}"
            )
        else:
            print("No token usage related data was extracted")

    def log_usage(self, response: Any, key: str, type: TokenType, description: str = ""):
        """Extract and log token usage from a response.

        Similar to print_usage but uses Python's logging module instead of print.
        Useful for integration with existing logging infrastructure.

        Args:
            response: The response object from a LangChain model invocation
            key: The key identifying the request (e.g., function name)
            type: Type of operation (TokenType enum)
            description: Optional description of the request
        """
        token_usage = self.extract_and_record(response, key=key, type=type)
        if token_usage:
            logger.info(
                f"{key}: {description} - Input tokens: {token_usage.input_tokens}, "
                f"Output tokens: {token_usage.output_tokens}, "
                f"Cache creation: {token_usage.cache_creation_input_tokens}, "
                f"Cache read: {token_usage.cache_read_input_tokens}"
            )
        else:
            logger.info("No token usage related data was extracted")

    def log_usage_generator(self, response: Any, key: str, description: str = ""):
        """Log token usage for generator operations.

        Convenience method that calls log_usage with type=TokenType.GENERATOR.

        Args:
            response: The response object from a LangChain model invocation
            key: The key identifying the request (e.g., function name)
            description: Optional description of the request
        """
        self.log_usage(response, key, type=TokenType.GENERATOR, description=description)

    def log_usage_analyser(self, response: Any, key: str, description: str = ""):
        """Log token usage for violation analyser operations.

        Convenience method that calls log_usage with type=TokenType.VIOLATION_ANALYSER.

        Args:
            response: The response object from a LangChain model invocation
            key: The key identifying the request (e.g., function name)
            description: Optional description of the request
        """
        self.log_usage(response, key, type=TokenType.VIOLATION_ANALYSER, description=description)

    def log_usage_summarization(self, response: Any, key: str, description: str = ""):
        """Log token usage for summarization operations.

        Convenience method that calls log_usage with type=TokenType.SUMMARIZATION.

        Args:
            response: The response object from a LangChain model invocation
            key: The key identifying the request (e.g., function name or contract name)
            description: Optional description of the request
        """
        self.log_usage(response, key, type=TokenType.SUMMARIZATION, description=description)

    @staticmethod
    def _calculate_totals(
        records: list[TokenUsageRecord], key: str | None = None, type: TokenType | None = None
    ) -> TokenUsageRecord:
        """Calculate total token usage for a list of records.

        Args:
            records: List of TokenUsageRecord instances to aggregate
            key: Optional key for the resulting record
            type: Optional type for the resulting record

        Returns:
            TokenUsageRecord instance with total counts for each token type.
            The total_calls field contains the number of records aggregated.
        """
        if not records:
            return TokenUsageRecord(
                input_tokens=0,
                output_tokens=0,
                cache_creation_input_tokens=0,
                cache_read_input_tokens=0,
                total_tokens=0,
                total_calls=0,
                key=key,
                type=type,
            )

        return TokenUsageRecord(
            input_tokens=sum(r.input_tokens for r in records),
            output_tokens=sum(r.output_tokens for r in records),
            cache_creation_input_tokens=sum(r.cache_creation_input_tokens for r in records),
            cache_read_input_tokens=sum(r.cache_read_input_tokens for r in records),
            total_tokens=sum(r.total_tokens for r in records),
            total_calls=len(records),
            key=key,
            type=type,
        )

    def get_totals(self, key: str | None = None, type: TokenType | None = None) -> TokenUsageRecord:
        """Calculate total token usage across all recorded calls.

        Returns:
            TokenUsageRecord instance with total counts for each token type.
            The total_calls field contains the number of API calls tracked.
        """
        return self._calculate_totals(self.records, key=key, type=type)

    def print_summary(self):
        """Print a comprehensive summary of token usage.

        Displays a formatted table showing:
        - Total number of API calls
        - Total input/output tokens
        - Cache creation and read tokens
        - Effective cost breakdown (considering cache pricing multipliers)

        Args:
            property_dir: Optional directory to also save the token log file to
        """
        if not self.enabled:
            return

        totals = self.get_totals()

        if totals.total_calls == 0:
            print("\nNo token usage data collected.")
            return

        print("\n" + "=" * 80)
        print("TOKEN USAGE SUMMARY")
        print("=" * 80)
        print(f"[DEBUG] Total records in tracker: {len(self.records)}")
        print(f"Total API calls: {totals.total_calls}")
        print(f"Input tokens: {totals.input_tokens:,}")
        print(f"Output tokens: {totals.output_tokens:,}")
        print(f"Total tokens: {totals.total_tokens:,}")
        print("\nEffective cost breakdown:")
        regular_input = totals.input_tokens - totals.cache_creation_input_tokens - totals.cache_read_input_tokens
        print(f"  - Regular input tokens: {regular_input:,}")
        print(f"  - Cache write tokens (1.25x cost): {totals.cache_creation_input_tokens:,}")
        print(f"  - Cache read tokens (0.1x cost): {totals.cache_read_input_tokens:,}")
        print("=" * 80)

    def log_summary(self, key: str):
        """Log a summary of total token usage.

        Similar to print_summary but uses logging instead of print.
        Includes effective cost breakdown with cache pricing multipliers.

        Args:
            key: The key identifying the context (e.g., function name)
        """
        totals = self.get_totals()

        if totals.total_calls == 0:
            logger.info("No token usage data collected.")
            return

        regular_input = totals.input_tokens - totals.cache_creation_input_tokens - totals.cache_read_input_tokens

        logger.info(
            f"{key}: TOTAL TOKEN USAGE - "
            f"API calls: {totals.total_calls}, "
            f"Input: {totals.input_tokens:,}, "
            f"Output: {totals.output_tokens:,}, "
            f"Total: {totals.total_tokens:,}"
        )
        logger.info(
            f"{key}: COST BREAKDOWN - "
            f"Regular input: {regular_input:,}, "
            f"Cache write (1.25x): {totals.cache_creation_input_tokens:,}, "
            f"Cache read (0.1x): {totals.cache_read_input_tokens:,}"
        )

    def save_to_file(self, property_dir: Path | None = None):
        """Save detailed token usage records to a JSON file.

        Writes all recorded token usage data to a JSON file for later analysis
        or auditing purposes. The filepath is specified in the constructor.
        Includes summary entries at the end: GENERATOR, VIOLATION_ANALYSER, and TOTAL.
        """
        if not self.enabled:
            return

        if self.records:
            # Convert individual records to dictionaries
            records_list = [r.to_dict() for r in self.records]

            # Group records by type
            records_by_type: dict[TokenType, list[TokenUsageRecord]] = defaultdict(list)
            for record in self.records:
                if record.type:
                    records_by_type[record.type].append(record)

            # Add summary entry for each type
            for token_type, typed_records in records_by_type.items():
                type_totals = self._calculate_totals(typed_records, key=token_type.value, type=TokenType.TOTAL)
                records_list.append(type_totals.to_dict())

            # Add TOTAL summary entry at the end
            totals = self.get_totals(key="TOTAL", type=TokenType.TOTAL)
            records_list.append(totals.to_dict())

            with open(self.filepath, "w") as f:
                json.dump(records_list, f, indent=2)
            print(f"Detailed token usage saved to {self.filepath}")

            # If property_dir provided, save a copy there as well
            if property_dir and self.records:
                source_path = Path(self.filepath)
                if source_path.exists():
                    dest_path = property_dir / source_path.name
                    shutil.copy(source_path, dest_path)
                    print(f"Token log copied to: {dest_path}")
