#!/usr/bin/env python3
from pathlib import Path
import sys

# Add parent directory to Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

import argparse
from dataclasses import dataclass, field
from enum import Enum
import json
import shutil
from auto_cvl.auto_generate_properties import request_properties
from auto_cvl.properties_to_cvl import get_new_auto_cvl_dir, generate_spec
from auto_cvl.solc_parsing import SolcParser
from token_usage_tracker import TokenUsageTracker


class Optimization(str, Enum):
    """Available token optimization strategies."""

    EXCLUDE_LIBS = "exclude-libs"
    COMPACT = "compact"
    SUMMARIZE = "summarize"


# Default optimizations (all enabled)
DEFAULT_OPTIMIZATIONS = [Optimization.EXCLUDE_LIBS, Optimization.COMPACT, Optimization.SUMMARIZE]


@dataclass
class AutoGenerateCvlArgs:
    """Arguments for auto_generate_cvl.py script."""

    contract_file: Path = field(default_factory=lambda: Path())
    contract: str = field(default="")
    solc: str = field(default="solc")
    remappings: list[str] = field(default_factory=list)
    via_ir: bool = field(default=False)
    n_concurrent: int = field(default=5)
    cvl_imports: list[str] = field(default_factory=list)
    out: Path = field(default_factory=lambda: Path("nat.spec"))
    properties_dir: Path = field(default_factory=lambda: get_new_auto_cvl_dir())
    methods: list[str] | None = field(default=None)
    generate_invariants: bool = field(default=False)
    extra_info: list[Path] = field(default_factory=list)
    no_validate: bool = field(default=False)
    log_tokens: str | None = field(default=None)
    optimizations: str = field(default=",".join(o.value for o in DEFAULT_OPTIMIZATIONS))
    summary_file: Path | None = field(default=None)
    # Internal fields set based on optimizations flag
    exclude_libs: bool = field(default=True)
    compact: bool = field(default=True)
    summarize: bool = field(default=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract-file", type=Path, required=True)
    parser.add_argument("--contract", type=str, required=True)
    parser.add_argument("--solc", type=str, default="solc")
    parser.add_argument("--remappings", type=str, nargs="+", default=list())
    parser.add_argument("--via-ir", action="store_true")
    parser.add_argument("--n-concurrent", type=int, default=5)
    parser.add_argument("--cvl-imports", type=str, nargs="+", default=list())
    parser.add_argument("--out", type=Path, default=Path("nat.spec"))
    parser.add_argument(
        "--properties-dir",
        type=Path,
        default=get_new_auto_cvl_dir(),
    )
    parser.add_argument("--methods", type=str, nargs="*")
    parser.add_argument("--generate-invariants", action="store_true")
    parser.add_argument("--extra_info", type=Path, nargs="+", default=list())
    parser.add_argument("--no-validate", action="store_true")
    parser.add_argument(
        "--log-tokens",
        type=str,
        metavar="FILEPATH",
        help="Enable detailed token usage tracking and save to specified filepath (e.g., token_usage.json)",
    )
    parser.add_argument(
        "--optimizations",
        type=str,
        default=",".join(o.value for o in DEFAULT_OPTIMIZATIONS),
        metavar="OPT1,OPT2,...",
        help=(
            f"Comma-separated list of token optimizations to enable. "
            f"Available optimizations: {', '.join(o.value for o in Optimization)}. "
            f"Use 'none' to disable all optimizations. "
            f"Default: '{','.join(o.value for o in DEFAULT_OPTIMIZATIONS)}' (all enabled). "
            f"Examples: --optimizations compact,summarize  OR  --optimizations none"
        ),
    )
    parser.add_argument(
        "--summary-file",
        type=Path,
        metavar="FILEPATH",
        help="Load pre-generated summaries from JSON file instead of generating them via Claude API (e.g., summaries.json)",
    )

    # Parse args into our dataclass
    args = parser.parse_args(namespace=AutoGenerateCvlArgs())

    # Parse optimizations flag and set individual optimization booleans
    optimizations_str = args.optimizations.strip().lower()

    if optimizations_str == "none" or optimizations_str == "":
        # Disable all optimizations
        args.exclude_libs = False
        args.compact = False
        args.summarize = False
    else:
        # Parse comma-separated list
        enabled_opts = set(opt.strip() for opt in optimizations_str.split(",") if opt.strip())

        # Validate that all specified optimizations are valid
        valid_opt_values = set(o.value for o in Optimization)
        invalid_opts = enabled_opts - valid_opt_values
        if invalid_opts:
            print(f"Error: Invalid optimization(s): {', '.join(invalid_opts)}")
            print(f"Available optimizations: {', '.join(valid_opt_values)}")
            exit(1)

        # Set each optimization flag based on whether it's in the list
        args.exclude_libs = Optimization.EXCLUDE_LIBS.value in enabled_opts
        args.compact = Optimization.COMPACT.value in enabled_opts
        args.summarize = Optimization.SUMMARIZE.value in enabled_opts

    # If summary_file is provided, automatically enable summary mode
    if args.summary_file:
        args.summarize = True

    solc_parser = SolcParser(args.contract_file, args.solc, args.remappings, args.via_ir)

    # Create the folder
    args.properties_dir.mkdir(parents=True, exist_ok=True)
    with open(args.properties_dir / "compiled.json", "w") as f:
        json.dump(solc_parser.ast, f, indent=2)

    token_tracker = TokenUsageTracker(filepath=args.log_tokens)
    properties = request_properties(
        contract_file=args.contract_file,
        solc_parser=solc_parser,
        contract=args.contract,
        properties_dir=args.properties_dir,
        n_concurrent=args.n_concurrent,
        methods=args.methods,
        generate_invariants=args.generate_invariants,
        extra_info=args.extra_info,
        validate=not args.no_validate,
        token_tracker=token_tracker,
        exclude_libs=args.exclude_libs,
        compact=args.compact,
        summarize=args.summarize,
        summary_file=args.summary_file,
    )
    if not properties:
        exit(1)

    ret = generate_spec(
        properties=properties,
        solc_parser=solc_parser,
        contract=args.contract,
        out=args.out,
        cvl_imports=args.cvl_imports,
        property=None,
    )

    # Copy spec file to properties directory if generation succeeded
    if ret in (0, 2) and args.out.exists():
        spec_dest = args.properties_dir / args.out.name
        shutil.copy(args.out, spec_dest)
        print(f"Spec file copied to: {spec_dest}")

    exit(ret)
