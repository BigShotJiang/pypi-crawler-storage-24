from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
from typing import Any, Literal, Self


# Define the dataclass hierarchy
@dataclass(frozen=True)
class SolidityType:
    """Base dataclass for all storage types."""

    type_str: str  # The full Solidity type string (e.g., "uint256", "mapping(address => uint256)")

    def __str__(self):
        return self.type_str


@dataclass(frozen=True)
class SimpleType(SolidityType):
    """Represents simple types like uint, address, bool, string, etc."""

    def __post_init__(self):
        if self.type_str.startswith(("enum ", "struct ", "contract ")):
            assert False, f"`{self.type_str}` is not a simple type"

    def __eq__(self, other):
        if isinstance(other, SimpleType):
            return self.type_str == other.type_str
        if self.type_str == "address" and isinstance(other, ContractType):
            return True
        return False


@dataclass(frozen=True)
class ContractType(SolidityType):
    """Represents simple types like uint, address, bool, string, etc."""

    contract: str

    @classmethod
    def create(cls, contract: str) -> Self:
        return cls("address", contract)

    def __eq__(self, other):
        if isinstance(other, ContractType):
            return self.contract == other.contract
        if isinstance(other, SimpleType) and other.type_str == "address":
            return True
        return False


@dataclass(frozen=True)
class ArrayType(SolidityType):
    """Represents array types (dynamic or fixed-size)."""

    base: SolidityType  # The type of the elements in the array


@dataclass(frozen=True)
class MappingType(SolidityType):
    """Represents mapping types."""

    key: SolidityType  # The type of the mapping key
    value: SolidityType  # The type of the mapping value


@dataclass(frozen=True)
class StructType(SolidityType):
    """Represents struct types."""

    _members: tuple[tuple[str, SolidityType], ...] = field(default=())  # Map member name to SolidityType object

    @classmethod
    def struct(cls, type_str: str, members: dict[str, SolidityType]) -> Self:
        return cls(type_str=type_str, _members=tuple(sorted(members.items())))

    @property
    def members(self):
        return dict(self._members)

    def __eq__(self, other):
        if not isinstance(other, StructType):
            return False
        return self.type_str == other.type_str


@dataclass(frozen=True)
class EnumType(SolidityType):
    """Represents enum types."""

    members: list[str] | None = None  # None if there's no available information on the members

    def __eq__(self, other):
        if not isinstance(other, EnumType):
            return False
        return self.type_str == other.type_str


@dataclass(frozen=True)
class NamedParameter:
    name: str
    type: SolidityType


@dataclass(frozen=True)
class FunctionABI:
    name: str
    inputs: list[NamedParameter]
    outputs: list[NamedParameter]
    abi_inputs: list[str]

    def sig(self) -> str:
        """Returns an ABI-compliant function signature"""
        return f"{self.name}({','.join(self.abi_inputs)})"


NUMBER_LITERAL = SimpleType("number_literal")
MATHINT = SimpleType("mathint")
BOOL_TYPE = SimpleType("bool")
ADDRESS_TYPE = SimpleType("address")
INT_TYPES = [SimpleType(f"int{n}") for n in range(8, 257, 8)] + [SimpleType("int")]
UINT_TYPES = [SimpleType(f"uint{n}") for n in range(8, 257, 8)] + [SimpleType("uint")]
INTEGER_TYPES = UINT_TYPES + INT_TYPES + [MATHINT, NUMBER_LITERAL]
BYTES_TYPES = [SimpleType(f"bytes{n}") for n in range(1, 33)]
SIMPLE_TYPES = [SimpleType("bytes"), SimpleType("string"), ADDRESS_TYPE, BOOL_TYPE] + INTEGER_TYPES + BYTES_TYPES


def solidity_type_bounds(type_string: str) -> tuple[str, str]:
    match = re.match(r"^(u?int)(\d+)?$", type_string)
    if not match:
        raise ValueError(f"Invalid type: {type_string}")

    is_unsigned = match.group(1) == "uint"
    bits = int(match.group(2)) if match.group(2) else 256

    if is_unsigned:
        return ("0", f"(2 ^ {bits} - 1)")
    else:
        return (f"(-2 ^ {bits - 1})", f"(2 ^ {bits - 1} - 1)")


@dataclass(frozen=True)
class StorageLayoutInfo:
    name: str
    type: SolidityType
    multiple_inheritance: bool = False


@dataclass
class ConstantValue:
    mutability: Literal["immutable", "constant"]
    value: Any
    type: SolidityType
    visibility: Literal["internal", "private", "public"]


class SolcParser:
    def __init__(self, file_path: Path, solc: str, remappings: list[str], via_ir: bool):
        self.file_path = file_path
        self.source_code = file_path.read_bytes()

        ast = self._compile_solidity(file_path, solc, remappings, via_ir)
        if not ast:
            raise RuntimeError("Failed to generate ast")
        self.ast = ast

    # Helper function to recursively search for a node in the AST
    def _find_node(self, node, node_type):
        if isinstance(node, dict):
            if node.get("nodeType") == node_type:
                yield node
            for key, value in node.items():
                yield from self._find_node(value, node_type)
        elif isinstance(node, list):
            for item in node:
                yield from self._find_node(item, node_type)

    def _parse_type_from_ast_node(self, type_node: dict[str, Any], contract: str = "") -> SolidityType:
        """
        Parses a Solidity type from an AST type node.
        Shared implementation for both storage layout and immutable constants parsing.

        Args:
            type_node: AST node representing a type
            contract: Contract name for proper namespacing (optional)
        """
        if not type_node:
            return SimpleType("unknown")

        node_type = type_node.get("nodeType")
        type_descriptions = type_node.get("typeDescriptions", {})
        type_string = type_descriptions.get("typeString", "")

        if node_type == "ElementaryTypeName":
            # Basic types like uint256, address, bool, etc.
            name = type_node.get("name", type_string)
            return SimpleType(name)

        elif node_type == "UserDefinedTypeName":
            # Contract, struct, enum, or other user-defined types
            if type_string.startswith("contract "):
                contract_name = type_string.replace("contract ", "")
                return ContractType.create(contract_name)
            elif type_string.startswith("struct "):
                struct_name = type_string[len("struct ") :]

                # Now find the type's members
                members = {}
                for n in self._find_node(self.ast, "StructDefinition"):
                    if n["canonicalName"] == struct_name:
                        struct_node = n
                        break
                else:
                    assert False, f"Couldn't find struct definition for {struct_name}"

                for m in struct_node["members"]:
                    members[m["name"]] = self._parse_type_from_ast_node(m["typeName"], contract)

                # If it's a file-level struct definition, prepend a contract since that's how it's done in CVL.
                if contract and "." not in struct_name:
                    struct_name = f"{contract}.{struct_name}"

                return StructType.struct(struct_name, members)
            elif type_string.startswith("enum "):
                enum_name = type_string[len("enum ") :]
                if contract and "." not in enum_name:
                    enum_name = f"{contract}.{enum_name}"
                return EnumType(enum_name)
            else:
                # Generic user-defined type
                path_node = type_node.get("pathNode", {})
                name = path_node.get("name") or type_node.get("name", type_string)
                if contract and "." not in name and name not in (t.type_str for t in SIMPLE_TYPES):
                    name = f"{contract}.{name}"
                return SimpleType(name)

        elif node_type == "ArrayTypeName":
            # Array types
            base_type_node = type_node.get("baseType", {})
            base_type = self._parse_type_from_ast_node(base_type_node, contract)
            return ArrayType(type_string, base_type)

        elif node_type == "Mapping":
            # Mapping types
            key_type_node = type_node.get("keyType", {})
            value_type_node = type_node.get("valueType", {})
            key_type = self._parse_type_from_ast_node(key_type_node, contract)
            value_type = self._parse_type_from_ast_node(value_type_node, contract)
            return MappingType(type_string, key_type, value_type)

        elif node_type == "FunctionTypeName":
            # Function types
            return SimpleType(type_string or "function")

        else:
            # Fallback for unknown types
            return SimpleType(type_string or "unknown")

    def _get_parent_contract_names(self, contract_node: dict[str, Any]) -> list[str]:
        """
        Extract the names of parent contracts from the inheritance specifiers.
        Shared implementation for both storage layout and immutable constants parsing.
        """
        parent_names = []
        base_contracts = contract_node.get("baseContracts", [])

        for base_contract in base_contracts:
            base_name = base_contract.get("baseName", {})
            node_type = base_name.get("nodeType")

            if node_type == "IdentifierPath":
                # Newer AST format
                name = base_name.get("name")
                if name:
                    parent_names.append(name)
            elif node_type == "UserDefinedTypeName":
                # Older AST format
                name = base_name.get("pathNode", {}).get("name") or base_name.get("name")
                if name:
                    parent_names.append(name)

        return parent_names

    def _find_all_contracts(self) -> dict[str, dict[str, Any]]:
        """
        Find all contract definitions in the AST and return them as a dictionary.
        Shared implementation for both storage layout and immutable constants parsing.
        """
        all_contracts: dict[str, dict[str, Any]] = {}
        sources = self.ast.get("sources", {})

        for source_path, source_data in sources.items():
            ast_root = source_data.get("ast")
            if not ast_root:
                continue

            # Find all contract definitions in this source
            def find_contracts(node):
                contracts = []
                if isinstance(node, dict):
                    node_type = node.get("nodeType")
                    if node_type in ["ContractDefinition"]:
                        contracts.append(node)
                    for key, value in node.items():
                        if isinstance(value, (dict, list)):
                            contracts.extend(find_contracts(value))
                elif isinstance(node, list):
                    for item in node:
                        contracts.extend(find_contracts(item))
                return contracts

            contracts = find_contracts(ast_root)

            for contract_node in contracts:
                contract_name = contract_node.get("name")
                if contract_name:
                    all_contracts[contract_name] = contract_node

        return all_contracts

    def _is_foundry_available(self) -> bool:
        """Check if forge command is available."""
        try:
            subprocess.run(["forge", "--version"], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def _is_foundry_project(self) -> bool:
        """Check if we're within a Foundry project by looking for foundry.toml up the tree."""
        current_dir = Path.cwd()

        # Check current directory and all parent directories
        for parent in [current_dir] + list(current_dir.parents):
            if (parent / "foundry.toml").exists():
                return True
        return False

    def _try_flatten_with_forge(
        self,
        file_path: Path,
        remappings: list[str],
        temp_dir: Path,
    ) -> Path | None:
        """
        Attempts to flatten a Solidity file using forge flatten.

        Args:
            file_path (Path): The path to the Solidity file to flatten.
            remappings (list[str]): List of remapping strings for forge.
            temp_dir (Path): Temporary directory to write the flattened file.

        Returns:
            Path | None: Path to the flattened file if successful, None otherwise.
        """
        try:
            # Build forge flatten command
            cmd = ["forge", "flatten", str(file_path)]

            # Add remappings if provided and not in a Foundry project
            if remappings and not self._is_foundry_project():
                cmd.extend(["--root", "."])
                for remapping in remappings:
                    cmd.extend(["--remappings", remapping])

            # Run forge flatten
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            # Write flattened content to temp file
            flattened_file = temp_dir / f"{file_path.stem}_flattened.sol"
            flattened_file.write_text(result.stdout)

            return flattened_file

        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            print(f"Failed to flatten with forge: {e}")
            return None

    def _compile_with_foundry(self, temp_dir: Path) -> dict[str, Any] | None:
        """
        Compiles a Solidity file using Foundry's forge build.

        Args:
            temp_dir (Path): Temporary directory to write build artifacts.

        Returns:
            dict: The parsed JSON output similar to solc format if successful, None otherwise.
        """
        try:
            # Build the file with forge
            subprocess.run(
                ["forge", "build", str(self.file_path), "--build-info", "--build-info-path", str(temp_dir)],
                capture_output=True,
                text=True,
                check=True,
            )

            # Read the compiled artifacts from build-info
            build_info_files = list(temp_dir.glob("*.json"))
            if not build_info_files:
                print("Error: forge build did not create build-info JSON files")
                return None

            build_info = build_info_files[0]
            with open(build_info) as f:
                build_info_json = json.load(f)

            return build_info_json["output"]

        except (subprocess.CalledProcessError, json.JSONDecodeError, FileNotFoundError) as e:
            print(f"Error compiling with Foundry: {e}")
            return None

    def _compile_solidity(
        self, file_path: Path, solc: str, remappings: list[str], via_ir: bool
    ) -> dict[str, Any] | None:
        """
        Compiles a Solidity file, attempting to flatten with forge first if available,
        otherwise falls back to direct solc compilation. If solc compilation fails,
        retries both forge and solc compilation with the original unflattened file.

        Args:
            file_path (Path): The path to the Solidity file.
            solc (str): Path to the solc compiler.
            remappings (list[str]): List of remapping strings.
            via_ir (bool): Whether to use via-IR compilation.

        Returns:
            dict: The parsed JSON output from compilation if successful, None otherwise.
        """
        if not file_path.exists():
            print(f"Error: File not found at '{file_path}'")
            return None

        # Store original file path and source code for potential retry
        original_file_path = file_path
        original_source_code = self.source_code

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir_path = Path(temp_dir)

            # Build remappings list from remappings.txt if not provided
            if not remappings and Path("remappings.txt").exists():
                with open("remappings.txt") as f:
                    remappings = [line.strip() for line in f.read().split() if line.strip()]

            flattened_used = False
            # Try to flatten with Foundry if available (even outside Foundry projects)
            if self._is_foundry_available():
                flattened_file_path = self._try_flatten_with_forge(file_path, remappings, temp_dir_path)
                if flattened_file_path:
                    print(f"Successfully flattened file to {flattened_file_path}")
                    self.file_path = flattened_file_path
                    self.source_code = self.file_path.read_bytes()
                    flattened_used = True
                else:
                    print("Forge flatten failed, using original file")

            # Check if we should use full Foundry compilation for Foundry projects
            if self._is_foundry_available() and self._is_foundry_project():
                print("Foundry project found, compile using forge")
                result = self._compile_with_foundry(temp_dir_path)
                if result:
                    return result
                print("Foundry compilation failed, falling back to solc")

            # Compile with solc
            result = self._compile_with_solc(solc, remappings, via_ir)

            # If solc compilation failed and we used a flattened file, retry with original file
            if result is None and flattened_used:
                print("Solc compilation failed with flattened file, retrying with original file")

                # Reset to original file
                self.file_path = original_file_path
                self.source_code = original_source_code

                # Try Foundry compilation with original file if available
                if self._is_foundry_available() and self._is_foundry_project():
                    print("Retrying Foundry compilation with original file")
                    result = self._compile_with_foundry(temp_dir_path)
                    if result:
                        return result
                    print("Foundry compilation failed with original file, trying solc")

                # Try solc compilation with original file
                print("Retrying solc compilation with original file")
                result = self._compile_with_solc(solc, remappings, via_ir)

            return result

    def _compile_with_solc(self, solc: str, remappings: list[str], via_ir: bool) -> dict[str, Any] | None:
        """
        Compiles a Solidity file directly with solc using standard JSON.

        Args:
            solc (str): Path to the solc compiler.
            remappings (list[str]): List of remapping strings.
            via_ir (bool): Whether to use via-IR compilation.

        Returns:
            dict: The parsed JSON output from compilation if successful, None otherwise.
        """
        # Create standard JSON input
        standard_json_input = {
            "language": "Solidity",
            "sources": {str(self.file_path): {"urls": [str(self.file_path)]}},
            "settings": {
                "remappings": remappings,
                "viaIR": via_ir,
                "outputSelection": {"*": {"*": ["abi", "devdoc", "storageLayout"], "": ["ast"]}},
            },
        }

        command = [solc, "--allow-paths", str(self.file_path.parent), "--standard-json"]

        try:
            result = subprocess.run(
                command, input=json.dumps(standard_json_input), capture_output=True, text=True, check=True
            )
        except subprocess.CalledProcessError as e:
            print(f"Error compiling Solidity file: {e}")
            print(f"Stderr: {e.stderr}")
            return None

        try:
            output = json.loads(result.stdout)

            # Check for compilation errors
            if "errors" in output:
                for error in output["errors"]:
                    if error.get("severity") == "error":
                        print(f"Solc compilation error: {error.get('formattedMessage', 'Unknown error')}")
                        return None

            return output
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON output from solc: {e}")
            print(f"Solc stdout: {result.stdout}")
            return None

    def parse_solc_abi(self) -> dict[str, dict[str, FunctionABI]]:
        """
        Parses the solc standard json output and returns a dictionary
        of function signatures to their inputs and outputs.

        Signatures use ABI-compliant type strings (tuple notation for structs).
        Inputs/Outputs lists use 'internalType' (e.g., struct name) if available,
        otherwise fall back to ABI type.

        Args:
            solc_json_output (dict): The dictionary output from
                                            `solc --standard-json ...abi`.

        Returns:
            dict: A dictionary where keys are abi-compliant function signatures,
                and values are another dictionary with 'inputs' and 'outputs' keys.
                Each of 'inputs' and 'outputs' is a list of (type, name) pairs.
                If an output parameter has no name, its name will be None.
        """

        def _get_abi_signature_type_string(param: dict[str, Any]) -> str:
            """
            Recursively constructs the ABI type string for a given parameter,
            handling complex types like tuples and structs for *signature generation*.
            """
            param_type: str = param["type"]

            # Handle array types
            if param_type.endswith("[]"):
                base_type = param_type[:-2]
                if base_type == "tuple" and "components" in param:
                    components_str = ",".join([_get_abi_signature_type_string(comp) for comp in param["components"]])
                    return f"({components_str})[]"
                else:
                    return param_type
            elif param_type.endswith("]") and "[" in param_type:  # Fixed-size arrays
                base_type = param_type[: param_type.rfind("[")]
                if base_type == "tuple" and "components" in param:
                    components_str = ",".join([_get_abi_signature_type_string(comp) for comp in param["components"]])
                    array_suffix = param_type[param_type.rfind("[") :]
                    return f"({components_str}){array_suffix}"
                else:
                    return param_type

            # Handle tuple types (structs are represented as tuples in ABI signature)
            if param_type == "tuple" and "components" in param:
                components_str = ",".join([_get_abi_signature_type_string(comp) for comp in param["components"]])
                return f"({components_str})"

            # For all other simple types
            return param_type

        def _build_detailed_abi_type(param: dict[str, Any], contract: str) -> SolidityType:
            """
            Recursively builds a detailed dataclass representation of an ABI parameter type,
            mapping it to the StorageType hierarchy, and correctly handling nested arrays.
            """
            param_type_str_raw: str = param["type"]
            internal_type_str_raw: str = param["internalType"]
            components = param.get("components")

            # Determine the 'label' for StorageType.type_str
            # Prioritize internalType for user-friendly names.
            type_str_current = internal_type_str_raw if internal_type_str_raw else param_type_str_raw

            # --- Handle potential array dimensions iteratively ---
            # We strip dimensions from right to left (outermost to innermost)
            current_param_type = param_type_str_raw
            current_internal_type = internal_type_str_raw

            array_dimensions: list[int | str] = []  # Stores lengths or "dynamic" for each dimension

            while True:
                # Regex to find array suffix (e.g., [], [5], [3][2])
                # It finds the *rightmost* array suffix
                array_match = re.search(r"(\[(\d*)\])$", current_param_type)

                if array_match:
                    array_suffix = array_match.group(1)  # e.g., "[]", "[5]"
                    array_length_str = array_match.group(2)  # e.g., "", "5"

                    array_length: int | str = "dynamic"
                    if array_length_str:
                        array_length = int(array_length_str)

                    array_dimensions.append(array_length)

                    # Remove the outermost array dimension to process the base type
                    current_param_type = current_param_type[: array_match.start()]
                    current_internal_type = current_internal_type.replace(
                        array_suffix, ""
                    )  # Strip from internal type too
                else:
                    break  # No more array dimensions found

            # If array_dimensions list is not empty, we are building an ArrayType (possibly nested)
            if array_dimensions:
                # The innermost base type (after stripping all array dimensions)
                base_param: dict[str, Any] = {
                    "type": current_param_type,
                    "internalType": current_internal_type,
                }
                if current_param_type == "tuple":
                    base_param["components"] = components  # Pass components for nested tuples/structs

                # Build the ArrayType dataclasses from innermost to outermost dimension
                current_base_dataclass = _build_detailed_abi_type(base_param, contract)

                # Iterate dimensions in reverse (from innermost array length to outermost)
                # to construct the nested ArrayType objects correctly
                for dim_length in reversed(array_dimensions):
                    # Construct the type_str for this level of array
                    # This is tricky because internalType only provides the full string, not per level.
                    # We'll reconstruct a more accurate array type_str based on the base.
                    current_array_type_str = (
                        f"{current_base_dataclass.type_str}[{dim_length}]"
                        if dim_length != "dynamic"
                        else f"{current_base_dataclass.type_str}[]"
                    )

                    current_base_dataclass = ArrayType(type_str=current_array_type_str, base=current_base_dataclass)
                return current_base_dataclass

            # --- Struct/tuple Type Check (only if no array dimensions were found) ---
            if param_type_str_raw == "tuple" and components:
                struct_members: dict[str, SolidityType] = {}
                for comp_info in components:
                    member_label = comp_info.get("name", "")
                    member_type_dataclass = _build_detailed_abi_type(comp_info, contract)  # Recursive call
                    struct_members[member_label] = member_type_dataclass

                struct_type_str = internal_type_str_raw[len("struct ") :]
                if "." not in struct_type_str:
                    struct_type_str = f"{contract}.{struct_type_str}"
                return StructType.struct(type_str=struct_type_str, members=struct_members)

            if internal_type_str_raw.startswith("enum "):
                ty = internal_type_str_raw[len("enum ") :]
                if "." not in ty:
                    ty = f"{contract}.{ty}"
                return EnumType(
                    type_str=ty,
                )

            if internal_type_str_raw.startswith("contract "):
                return ContractType.create(internal_type_str_raw[len("contract ") :])

            # --- Simple Type ---
            # If no arrays or tuples, it's a simple type.
            type_str_current = type_str_current.replace(" payable", "")
            if param_type_str_raw != type_str_current and "." not in type_str_current:
                type_str_current = f"{contract}.{type_str_current}"

            return SimpleType(type_str=type_str_current)

        ret: dict[str, dict[str, FunctionABI]] = {}
        for file_name, file_data in self.ast.get("contracts", {}).items():
            for contract, contract_data in file_data.items():
                abi: list[dict[str, Any]] = contract_data.get("abi", [])
                parsed_abi: dict[str, FunctionABI] = {}
                for item in abi:
                    if item.get("type") == "function":
                        function_name = item["name"]

                        inputs: list[NamedParameter] = []
                        input_signature_types = []  # To build the function signature string
                        for param in item.get("inputs", []):
                            # Type for the signature (ABI-compliant)
                            abi_signature_type = _get_abi_signature_type_string(param)
                            input_signature_types.append(abi_signature_type)

                            # Type for the inputs list (preferring internalType)
                            solidity_type = _build_detailed_abi_type(param, contract)
                            inputs.append(NamedParameter(type=solidity_type, name=param.get("name")))

                        outputs: list[NamedParameter] = []
                        for i, param in enumerate(item.get("outputs", [])):
                            # Type for the outputs list (preferring internalType)
                            solidity_type = _build_detailed_abi_type(param, contract)
                            name = param.get("name")

                            outputs.append(NamedParameter(type=solidity_type, name=name))

                        function_abi = FunctionABI(
                            name=function_name,
                            inputs=inputs,
                            outputs=outputs,
                            abi_inputs=input_signature_types,
                        )
                        parsed_abi[function_abi.sig()] = function_abi
                ret[contract] = parsed_abi
        return ret

    def parse_solc_storage_layout(self) -> dict[str, dict[str, StorageLayoutInfo]]:
        """
        Parses the solc AST and returns a dictionary mapping contracts to storage variable names
        to their detailed type information. Includes inherited storage variables from parent contracts.

        Returns:
            dict: A dictionary where contract names map to dictionaries of variable names to StorageLayoutInfo.
        """
        result: dict[str, dict[str, StorageLayoutInfo]] = {}
        all_contracts = self._find_all_contracts()
        contract_storage_vars: dict[str, dict[str, StorageLayoutInfo]] = {}  # Contract name -> storage vars

        def _extract_storage_variables_from_contract(
            contract_node: dict[str, Any], contract_name: str
        ) -> dict[str, StorageLayoutInfo]:
            """
            Extract storage variables from a single contract node.
            Only includes state variables (not constants/immutables).
            """
            variables: dict[str, StorageLayoutInfo] = {}

            def _traverse_for_storage_variables(node: dict[str, Any] | list[Any]):
                if isinstance(node, dict):
                    node_type = node.get("nodeType")

                    if node_type == "VariableDeclaration":
                        # Check if this is a state variable (not constant or immutable)
                        state_variable = node.get("stateVariable", False)
                        mutability = node.get("mutability", "")

                        if state_variable and mutability not in ["immutable", "constant"]:
                            var_name = node.get("name")
                            type_name_node = node.get("typeName", {})

                            if var_name:
                                # Parse the type
                                solidity_type = self._parse_type_from_ast_node(type_name_node, contract_name)

                                # Check for multiple inheritance (variable exists in parent)
                                multiple_inheritance = var_name in variables

                                variables[var_name] = StorageLayoutInfo(
                                    var_name, solidity_type, multiple_inheritance=multiple_inheritance
                                )

                    # Recursively traverse child nodes
                    for key, value in node.items():
                        if isinstance(value, (dict, list)):
                            _traverse_for_storage_variables(value)

                elif isinstance(node, list):
                    for item in node:
                        _traverse_for_storage_variables(item)

            _traverse_for_storage_variables(contract_node)
            return variables

        def _collect_inherited_storage_variables(
            contract_name: str, visited: set | None = None
        ) -> dict[str, StorageLayoutInfo]:
            """
            Recursively collect storage variables from this contract and all its parents.
            Uses topological order so child contract variables override parent ones.
            """
            if visited is None:
                visited = set()

            if contract_name in visited:
                # Circular inheritance - return empty dict
                return {}

            if contract_name not in all_contracts:
                # Contract not found - might be external or built-in
                return {}

            visited.add(contract_name)
            combined_variables = {}

            # First, collect from parent contracts (so child can override)
            contract_node = all_contracts[contract_name]
            parent_names = self._get_parent_contract_names(contract_node)

            for parent_name in parent_names:
                parent_variables = _collect_inherited_storage_variables(parent_name, visited.copy())
                # Mark inherited variables as having multiple inheritance if they conflict
                for var_name, var_info in parent_variables.items():
                    if var_name in combined_variables:
                        # Create new StorageLayoutInfo with multiple_inheritance=True
                        combined_variables[var_name] = StorageLayoutInfo(
                            var_info.name, var_info.type, multiple_inheritance=True
                        )
                    else:
                        combined_variables[var_name] = var_info

            # Then add this contract's own variables (overriding parents)
            if contract_name in contract_storage_vars:
                for var_name, var_info in contract_storage_vars[contract_name].items():
                    # If variable exists in parent, mark as multiple inheritance
                    if var_name in combined_variables:
                        combined_variables[var_name] = StorageLayoutInfo(
                            var_info.name, var_info.type, multiple_inheritance=True
                        )
                    else:
                        combined_variables[var_name] = var_info

            return combined_variables

        # First pass: collect all contracts and their direct storage variables
        for contract_name, contract_node in all_contracts.items():
            # Extract storage variables from this contract
            variables = _extract_storage_variables_from_contract(contract_node, contract_name)
            contract_storage_vars[contract_name] = variables

        # Second pass: resolve inheritance and build final result
        for contract_name in all_contracts.keys():
            inherited_variables = _collect_inherited_storage_variables(contract_name)
            if inherited_variables:
                result[contract_name] = inherited_variables

        return result

    def remove_function_body_by_name_and_selector(
        self,
        contract_name: str,
        function_name: str,
        function_selector: str,
    ) -> str | None:
        """
        Receives the parsed AST JSON from solc, the original Solidity file path,
        a function name, and a function selector. Removes the body of the specific
        function that matches both the name and selector.

        Args:
            ast_json (dict): The parsed JSON output from solc.
            solidity_file_path (str): The path to the original Solidity contract file.
            function_name (str): The name of the function to remove body from.
            function_selector (str): The selector (sighash) of the function to remove body from.

        Returns:
            str: The Solidity contract code with the specified function body removed.
                Returns None if the file cannot be read, AST structure is unexpected,
                or no function with the given name and selector is found.
        """

        # Find the AST root for the specific file
        ast_root = None
        if self.file_path in self.ast.get("sources", {}):
            ast_root = self.ast["sources"][self.file_path]["ast"]
        else:
            # Fallback: iterate through sources keys, in case path representation differs
            found_source_key = None
            for key in self.ast.get("sources", {}):
                if os.path.basename(key) == os.path.basename(self.file_path):
                    found_source_key = key
                    break
            if found_source_key:
                ast_root = self.ast["sources"][found_source_key]["ast"]
            else:
                print(
                    f"Error: Could not find ast for '{self.file_path}' in solc standard json output. Available sources: {list(self.ast.get('sources', {}).keys())}"
                )
                return None

        # Find the required contract's node
        for node in self._find_node(ast_root, "ContractDefinition"):
            if node.get("name") == contract_name:
                contract_node = node
                break
        else:
            print(f"Couldn't find contract node for {contract_name}")
            return None

        # Find the specific function that matches both name and selector
        # Iterate through all FunctionDefinition nodes
        for node in self._find_node(contract_node, "FunctionDefinition"):
            func_name = node.get("name")
            func_selector = node.get("functionSelector")

            # Check if both the function name and selector match
            if func_name == function_name and func_selector == function_selector:
                target_function_node = node
                break
        else:
            print(f"Warning: No function with name '{function_name}' and selector '{function_selector}' was found.")
            return None

        # Get the function body
        function_body_node = target_function_node.get("body")

        # Ensure it has a body and it's a Block node
        if not function_body_node or function_body_node.get("nodeType") != "Block":
            print(
                f"Warning: Function '{function_name}' with selector '{function_selector}' found, but has no identifiable body (not a Block node)."
            )
            return None

        # Extract body source information
        body_src = function_body_node["src"]
        try:
            parts = body_src.split(":")
            body_start_offset = int(parts[0])
            body_length = int(parts[1])
        except (ValueError, IndexError):
            print(f"Error: Invalid 'src' format for function body in AST: {body_src}")
            return None

        # Ensure the identified body starts with '{' and ends with '}' in the source string
        if (
            self.source_code[body_start_offset : body_start_offset + 1] != b"{"
            or self.source_code[body_start_offset + body_length - 1 : body_start_offset + body_length] != b"}"
        ):
            print(
                f"Error: Body at offset {body_start_offset} identified by AST doesn't start/end with curly braces as expected."
            )
            print(
                f"Found: start='{self.source_code[body_start_offset : body_start_offset + 1]!r}', end='{self.source_code[body_start_offset + body_length - 1 : body_start_offset + body_length]!r}'"
            )
            return None

        # Part before the opening brace (including the brace itself)
        code_before_body_content = self.source_code[: body_start_offset + 1]

        # Part after the closing brace (including the brace itself)
        code_after_body_content = self.source_code[body_start_offset + body_length - 1 :]

        # Combine to form the modified code. Add a newline for an empty body for readability.
        modified_source_code = code_before_body_content + b"\n" + code_after_body_content

        return modified_source_code.decode("utf-8")

    def get_method_selector_pairs_from_ast(self, contract_name: str) -> list[tuple[str, str]] | None:
        """
        Given the standard json output and a contract name,
        returns a list of tuples containing (function_name, selector) pairs
        for all functions in that contract.

        Args:
            ast_json (dict): The parsed JSON output.
            contract_name (str): The name of the contract (e.g., "MyContract").

        Returns:
            list[tuple[str, str]]: A list of (function_name, selector) pairs,
                                or None if the contract is not found or ast structure is unexpected.
        """
        if "sources" not in self.ast:
            print("Error: Invalid ast JSON format. Missing 'sources' key.")
            return None

        def _find_contract_in_ast(ast_node: dict[str, Any], target_name: str) -> dict[str, Any] | None:
            """Recursively find a contract definition in the AST."""
            if isinstance(ast_node, dict):
                # Check if this is a contract definition
                if ast_node.get("nodeType") == "ContractDefinition" and ast_node.get("name") == target_name:
                    return ast_node

                # Recursively search in child nodes
                for key, value in ast_node.items():
                    if isinstance(value, dict):
                        result = _find_contract_in_ast(value, target_name)
                        if result:
                            return result
                    elif isinstance(value, list):
                        for item in value:
                            if isinstance(item, dict):
                                result = _find_contract_in_ast(item, target_name)
                                if result:
                                    return result
            return None

        # Find the contract in the ast
        contract_node = None
        for source_path, source_data in self.ast["sources"].items():
            ast_root = source_data.get("ast", {})
            contract_node = _find_contract_in_ast(ast_root, contract_name)
            if contract_node:
                break

        if not contract_node:
            print(f"Error: Contract '{contract_name}' not found in AST. ")
            print(self.ast["sources"][str(self.file_path)]["ast"].keys())
            return None

        # Extract function definitions
        function_nodes = []
        nodes = contract_node.get("nodes", [])

        for node in nodes:
            if (
                isinstance(node, dict)
                and node.get("nodeType") == "FunctionDefinition"
                and node.get("visibility") in ["public", "external"]
                and node.get("kind") == "function"
                and node.get("stateMutability") in ["payable", "nonpayable"]
            ):
                function_nodes.append(node)

        # Generate method name and selector pairs
        method_selector_pairs = []

        for func_node in function_nodes:
            try:
                function_name = func_node.get("name", "")
                selector = func_node.get("functionSelector", "")

                if function_name and selector:
                    method_selector_pairs.append((function_name, selector))
            except Exception as e:
                function_name = func_node.get("name", "unknown")
                print(f"Warning: Could not process function '{function_name}': {e}")
                continue

        return method_selector_pairs

    def parse_solc_ast_immutable_constants(self) -> dict[str, dict[str, ConstantValue]]:
        """
        Parses the solc standard json output and returns a dictionary
        mapping contract names to their immutable and constant variables with their values and types.
        Includes inherited constants and immutables from parent contracts.

        Args:
            ast_json (dict): The ast dictionary.

        Returns:
            dict: A dictionary where keys are contract names, and values are dictionaries
                mapping variable names to ConstantValue instances. Only includes variables with
                'immutable' or 'constant' mutability.
        """
        result: dict[str, dict[str, ConstantValue]] = {}
        all_contracts = self._find_all_contracts()
        contract_variables: dict[str, dict[str, ConstantValue]] = {}  # Contract name -> variables

        def _parse_value_from_ast_node(node: dict[str, Any]) -> Any:
            """
            Extracts the value from an AST expression node.
            Handles literals, identifiers, member access, and basic expressions.
            """
            if not node:
                return None

            node_type = node.get("nodeType")

            if node_type == "Literal":
                # Direct literal values
                value = node.get("value")
                kind = node.get("kind")

                if kind == "number":
                    # Try to convert to int, fallback to string if it fails
                    try:
                        return int(value) if "." not in str(value) else float(value)  # type: ignore
                    except (ValueError, TypeError):
                        try:
                            coefficient, exponent = value.replace(" ", "").split("e")  # type: ignore
                            return int(coefficient) * 10 ** int(exponent)
                        except (ValueError, TypeError):
                            return value
                elif kind == "string":
                    return f'"{value}"'
                elif kind == "bool":
                    return value
                else:
                    return value

            elif node_type == "Identifier":
                # Variable references - return the name
                return f"${node.get('name', 'unknown')}"

            elif node_type == "MemberAccess":
                # Property access like msg.sender, block.timestamp
                expression = node.get("expression", {})
                member_name = node.get("memberName", "")

                if expression.get("nodeType") == "Identifier":
                    base_name = expression.get("name", "")
                    return f"{base_name}.{member_name}"
                else:
                    # Nested member access
                    base_value = _parse_value_from_ast_node(expression)
                    return f"{base_value}.{member_name}"

            elif node_type == "BinaryOperation":
                # Binary operations like addition, multiplication, etc.
                left = _parse_value_from_ast_node(node.get("leftExpression", {}))
                right = _parse_value_from_ast_node(node.get("rightExpression", {}))
                operator = node.get("operator", "")

                # Try to evaluate simple numeric operations
                if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                    if operator == "+":
                        return left + right
                    elif operator == "-":
                        return left - right
                    elif operator == "*":
                        return left * right
                    elif operator == "/":
                        return left // right
                    elif operator == "**":
                        return left**right
                    elif operator == "%":
                        return left % right

                # Return expression string for complex cases
                return f"({left} {operator} {right})"

            elif node_type == "UnaryOperation":
                # Unary operations like negation
                operand = _parse_value_from_ast_node(node.get("subExpression", {}))
                operator = node.get("operator", "")

                if operator == "-" and isinstance(operand, (int, float)):
                    return -operand
                elif operator == "!" and isinstance(operand, bool):
                    return not operand

                return f"{operator}{operand}"

            elif node_type == "FunctionCall":
                # Function calls - return a representation
                expression = node.get("expression", {})
                arguments = node.get("arguments", [])

                if expression.get("nodeType") == "Identifier":
                    func_name = expression.get("name", "")
                    arg_values = [_parse_value_from_ast_node(arg) for arg in arguments]
                    return f"{func_name}({', '.join(map(str, arg_values))})"

                return "function_call"

            elif node_type == "NewExpression":
                # Constructor calls
                type_name = node.get("typeName", {})
                if type_name.get("nodeType") == "UserDefinedTypeName":
                    type_id = type_name.get("pathNode", {}).get("name", "") or type_name.get("name", "")
                    return f"new {type_id}()"
                return "new_expression"

            # For other node types, try to return a meaningful representation
            return f"<{node_type}>"

        def _extract_variables_from_contract(
            contract_node: dict[str, Any],
        ) -> dict[str, ConstantValue]:
            """
            Extract immutable and constant variables from a single contract node.
            """
            variables: dict[str, ConstantValue] = {}

            def _traverse_for_variables(node: dict[str, Any] | list[Any]):
                if isinstance(node, dict):
                    node_type = node.get("nodeType")

                    if node_type == "VariableDeclaration":
                        mutability = node.get("mutability")
                        if mutability in ["immutable", "constant"]:
                            var_name = node.get("name")
                            initial_value_node = node.get("value")
                            type_name_node = node.get("typeName", {})

                            # Extract visibility
                            visibility = node.get("visibility", "public")
                            # Ensure visibility is one of the expected values
                            if visibility not in ["internal", "private", "public"]:
                                visibility = "internal"  # Default to private if unknown

                            if var_name:
                                # Parse the type
                                solidity_type = self._parse_type_from_ast_node(type_name_node)

                                # Parse the value
                                if initial_value_node:
                                    value = _parse_value_from_ast_node(initial_value_node)
                                else:
                                    # Variable declared but not initialized in this declaration
                                    value = None

                                variables[var_name] = ConstantValue(mutability, value, solidity_type, visibility)

                    # Recursively traverse child nodes
                    for key, value in node.items():
                        if isinstance(value, (dict, list)):
                            _traverse_for_variables(value)

                elif isinstance(node, list):
                    for item in node:
                        _traverse_for_variables(item)

            _traverse_for_variables(contract_node)
            return variables

        def _collect_inherited_variables(contract_name: str, visited: set | None = None) -> dict[str, ConstantValue]:
            """
            Recursively collect variables from this contract and all its parents.
            Uses topological order so child contract variables override parent ones.
            """
            if visited is None:
                visited = set()

            if contract_name in visited:
                # Circular inheritance - return empty dict
                return {}

            if contract_name not in all_contracts:
                # Contract not found - might be external or built-in
                return {}

            visited.add(contract_name)
            combined_variables = {}

            # First, collect from parent contracts (so child can override)
            contract_node = all_contracts[contract_name]
            parent_names = self._get_parent_contract_names(contract_node)

            for parent_name in parent_names:
                parent_variables = _collect_inherited_variables(parent_name, visited.copy())
                combined_variables.update(parent_variables)

            # Then add this contract's own variables (overriding parents)
            if contract_name in contract_variables:
                combined_variables.update(contract_variables[contract_name])

            return combined_variables

        # First pass: collect all contracts and their direct variables
        for contract_name, contract_node in all_contracts.items():
            # Extract variables from this contract
            variables = _extract_variables_from_contract(contract_node)
            # Always store the contract, even if it has no variables of its own
            contract_variables[contract_name] = variables

        # Second pass: resolve inheritance and build final result
        for contract_name in all_contracts.keys():
            inherited_variables = _collect_inherited_variables(contract_name)
            if inherited_variables:
                result[contract_name] = inherited_variables

        return result

    def extract_udvt_mappings(self) -> dict[str, str]:
        """
        Extract user-defined value types (UDVTs) and their underlying types from solc AST output.

        Args:
            solc_output: The ast from the solc standard json output

        Returns:
            dict mapping UDVT names to their underlying type names
        """
        udvt_mappings = {}

        contracts = self.ast.get("sources", {})

        for contract_name, contract_data in contracts.items():
            # Get the AST for this contract
            ast = contract_data.get("ast")
            if not ast:
                continue

            # Recursively search for UserDefinedValueTypeDefinition nodes
            def find_udvts(node):
                if isinstance(node, dict):
                    # Check if this is a UserDefinedValueTypeDefinition
                    if node.get("nodeType") == "UserDefinedValueTypeDefinition":
                        udvt_name = node.get("canonicalName")
                        underlying_type = node.get("underlyingType", {})

                        if udvt_name and underlying_type:
                            # Extract the underlying type name
                            type_name = underlying_type.get("name", "")
                            if type_name:  # Only add if it's a valid value type
                                udvt_mappings[udvt_name] = type_name

                    # Recursively search in all child nodes
                    for key, value in node.items():
                        if key == "nodes" and isinstance(value, list):
                            for child_node in value:
                                find_udvts(child_node)
                        elif isinstance(value, dict):
                            find_udvts(value)
                        elif isinstance(value, list):
                            for item in value:
                                if isinstance(item, dict):
                                    find_udvts(item)

            find_udvts(ast)

        return udvt_mappings

    def extract_enums_from_solc_output(self) -> dict[str, EnumType]:
        """
        Extract all enum definitions from solc's standard json output.

        Supports Solidity compiler version 0.8.0 and above only.

        Args:
            solc_output: the json output of solc

        Returns:
            list of EnumType objects containing enum names and their members

        Raises:
            ValueError: If solc version is below 0.8.0 or JSON is invalid
        """

        def _extract_enums_from_ast_node(node: dict[str, Any]) -> dict[str, EnumType]:
            """
            Recursively extract enum definitions from an AST node.

            Args:
                node: AST node dictionary

            Returns:
                list of EnumType objects found in this node and its children
            """
            enums = {}

            # Check if current node is an enum definition (0.8+ AST structure)
            if node.get("nodeType") == "EnumDefinition":
                # Use canonicalName if available, fallback to name
                enum_name = node.get("canonicalName") or node.get("name", "UnnamedEnum")
                members = []

                # In Solidity 0.8+, enum members are in 'members' array with 'name' property
                if "members" in node and isinstance(node["members"], list):
                    for member in node["members"]:
                        if isinstance(member, dict) and "name" in member:
                            members.append(member["name"])

                enums[enum_name] = EnumType(type_str=enum_name, members=members)

            # Recursively search in child nodes (0.8+ AST structure)
            # In Solidity 0.8+, the main child container is 'nodes'
            if "nodes" in node and isinstance(node["nodes"], list):
                for child_node in node["nodes"]:
                    if isinstance(child_node, dict):
                        enums |= _extract_enums_from_ast_node(child_node)

            return enums

        enums: dict[str, EnumType] = {}

        # The AST is typically under 'sources' key, with each source file having an 'ast' key
        if "sources" in self.ast:
            for source_name, source_data in self.ast["sources"].items():
                if "ast" in source_data:
                    ast_node = source_data["ast"]
                    enums |= _extract_enums_from_ast_node(ast_node)

        return enums

    def parse_solc_devdoc(self) -> dict[str, dict[str, str]]:
        """
        Parses the solc standard json output and returns a mapping
        from contract name to method signature to devdoc string.

        Args:
            solc_output: The solc standard json output

        Returns:
            Dict mapping contract names to method signatures to devdoc strings

        Example:
            {
                "MyContract": {
                    "transfer(address,uint256)": "Transfer tokens to another address...",
                    "balanceOf(address)": "Get the balance of an address..."
                }
            }
        """
        result = {}

        # The structure is typically: {"contracts": {"filename:ContractName": {"devdoc": {...}}}}
        contracts = self.ast.get("contracts", {})
        for file_name, file_data in contracts.items():
            for contract_name, contract_data in file_data.items():
                devdoc = contract_data.get("devdoc", {})
                methods = devdoc.get("methods", {})

                contract_methods = {}

                for method_sig, method_doc in methods.items():
                    # Convert the method documentation to a string representation
                    if isinstance(method_doc, dict):
                        # Format the devdoc as a readable string
                        doc_parts = []

                        if "details" in method_doc:
                            doc_parts.append(f"Details: {method_doc['details']}")

                        if "params" in method_doc:
                            params_str = []
                            for param_name, param_desc in method_doc["params"].items():
                                params_str.append(f"{param_name}: {param_desc}")
                            if params_str:
                                doc_parts.append(f"Parameters: {', '.join(params_str)}")

                        if "returns" in method_doc:
                            returns_str = []
                            for return_name, return_desc in method_doc["returns"].items():
                                returns_str.append(f"{return_name}: {return_desc}")
                            if returns_str:
                                doc_parts.append(f"Returns: {', '.join(returns_str)}")

                        # Include any other fields that might be present
                        for key, value in method_doc.items():
                            if key not in ["details", "params", "returns"] and value:
                                doc_parts.append(f"{key.capitalize()}: {value}")

                        contract_methods[method_sig] = "; ".join(doc_parts) if doc_parts else ""
                    else:
                        # If method_doc is already a string
                        contract_methods[method_sig] = str(method_doc)

                if contract_methods:  # Only add contracts that have methods with devdoc
                    result[contract_name] = contract_methods

        return result
