#!/usr/bin/env python3
"""
Summarizer class for generating function summaries using Claude API.

This module provides functionality to:
1. Generate summaries for all functions in a Solidity contract
2. Cache summaries in memory (one-time generation per execution)
3. Save summaries to .certora_internal/summaries.json
4. Validate that all functions are covered
5. Provide declarations-only contract code for property generation
"""

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import Any

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage
from pydantic import BaseModel, Field

# Import find_block_end from compactor
from auto_cvl.compactor import find_block_end, filter_library_files

# Configure logging
logger = logging.getLogger(__name__)

# Model configuration
SUMMARIZER_MODEL = "claude-opus-4-5-20251101"  # Model used for generating function summaries


# ========== TRANSFORMATION FUNCTIONS ==========


def transform_implementations(lines, summaries):
    """
    Add summary comments and convert function implementations to declarations.

    Args:
        lines: List of file lines
        summaries: Dict mapping line numbers to summary strings

    Returns:
        List of transformed lines
    """
    output_lines = []
    i = 0
    transform_count = 0

    while i < len(lines):
        line_num = i + 1
        line = lines[i]

        # Check if this line has a summary to add
        if line_num in summaries:
            summary = summaries[line_num]

            # Look for function/modifier/fallback keyword
            if "function " in line or "modifier " in line or "fallback()" in line:
                # Determine indentation
                indent_match = re.match(r"^(\s*)", line)
                indent = indent_match.group(1) if indent_match else "    "

                # Add summary comment before the function
                output_lines.append(f"{indent}// Summary: {summary}\n")

                # Collect the full function signature (might span multiple lines)
                sig_lines = []
                j = i
                found_opening_brace = False

                while j < len(lines) and not found_opening_brace:
                    sig_lines.append(lines[j])
                    if "{" in lines[j]:
                        found_opening_brace = True
                        break
                    j += 1

                if found_opening_brace:
                    # Find the end of the function body
                    body_end = find_block_end(lines, j)

                    if body_end != -1:
                        # Process the signature to replace body with semicolon
                        signature = "".join(sig_lines)

                        # Remove the opening brace and replace with semicolon
                        brace_pos = signature.find("{")
                        if brace_pos != -1:
                            new_signature = signature[:brace_pos].rstrip() + ";\n"
                            output_lines.append(new_signature)
                        else:
                            output_lines.extend(sig_lines)

                        # Skip past the function body
                        i = body_end + 1
                        transform_count += 1
                        continue

        # If we didn't process a function, just copy the line
        output_lines.append(line)
        i += 1

    print(f"  ✓ Transformed {transform_count} functions (added summaries, removed bodies)")
    return output_lines


def summarize(content: str, summaries: dict[int, str]) -> tuple[str, int]:
    """
    Convenience wrapper to transform function implementations to declarations.

    Performs two operations:
    1. Add summary comments before function implementations
    2. Convert implementations to declarations (remove function bodies)

    Args:
        content: Solidity source code as string
        summaries: Dict mapping line numbers to summary strings

    Returns:
        Tuple of (transformed_code, transform_count)
        where transform_count is the number of functions transformed

    Example:
        >>> code = open("contract.sol").read()
        >>> summaries = {
        ...     150: "Calculates next day timestamp",
        ...     165: "Returns week start timestamp"
        ... }
        >>> transformed, count = summarize(code, summaries)
        >>> print(f"Transformed {count} functions")
        >>> with open("declarations.sol", "w") as f:
        ...     f.write(transformed)
    """
    lines = content.splitlines(keepends=True)

    # Run transformation
    transformed_lines = transform_implementations(lines, summaries)

    # Convert back to string
    result = "".join(transformed_lines)

    # Count how many transformations were applied
    transform_count = len([ln for ln in summaries.keys() if ln <= len(lines)])

    return result, transform_count


# ========== PYDANTIC MODELS ==========


class FunctionSummary(BaseModel):
    """Summary of a single function."""

    location: str = Field(description="Location in format 'ContractName:functionName:lineNumber'")
    summary: str = Field(description="One-sentence summary of what the function does")

    @property
    def contract(self) -> str:
        """Extract contract name from location."""
        return self.location.split(":")[0]

    @property
    def function(self) -> str:
        """Extract function name from location."""
        return self.location.split(":")[1]

    @property
    def line(self) -> int:
        """Extract line number from location."""
        return int(self.location.split(":")[2])


class ContractSummaries(BaseModel):
    """Collection of function summaries."""

    summaries: list[FunctionSummary] = Field(description="List of function summaries")


class Summarizer:
    """
    Generates summaries for all functions in a contract using Claude API.

    Summaries are generated once per execution and cached in memory.
    They are also saved to .certora_internal/summaries.json for inspection.
    """

    # Configuration constants
    MAX_SUMMARY_TOKENS = 10000  # Maximum tokens for summary generation API call
    FUNCTION_LOOKAHEAD_LINES = 10  # Number of lines to search ahead for function body markers

    def __init__(self, enabled: bool, properties_dir: Path, token_tracker: Any):
        """
        Initialize the Summarizer.

        Args:
            enabled: Whether summary generation is enabled (--summarize flag)
            properties_dir: Directory to store summaries.json
            token_tracker: Token usage tracker instance
        """
        self.enabled = enabled
        self.properties_dir = properties_dir
        self.token_tracker = token_tracker
        self.summaries: dict[int, str] = {}  # line_number -> summary
        self.summaries_list: list[FunctionSummary] = []  # For validation and storage
        self.contract_code: str = ""  # Original contract code
        self.generated = False

    def load_from_file(self, summary_file: Path, contract_code: str) -> None:
        """
        Load summaries from a JSON file instead of generating them.

        Args:
            summary_file: Path to JSON file containing summaries
            contract_code: The contract code (stored for later use)

        Raises:
            RuntimeError: If file cannot be parsed or has invalid format
        """
        if not summary_file.exists():
            raise RuntimeError(f"Summary file not found: {summary_file}")

        logger.info(f"Loading summaries from {summary_file}")

        try:
            with open(summary_file) as f:
                summaries_data = json.load(f)

            # Parse summaries - handle both compressed format (location, summary)
            # and verbose format (contract, function, line, summary)
            self.summaries_list = []
            for item in summaries_data:
                if "location" in item:
                    # Compressed format: {"location": "Contract:function:line", "summary": "..."}
                    self.summaries_list.append(FunctionSummary(location=item["location"], summary=item["summary"]))
                elif "contract" in item and "function" in item and "line" in item:
                    # Verbose format (saved by _save_summaries): {"contract": "...", "function": "...", "line": ..., "summary": "..."}
                    location = f"{item['contract']}:{item['function']}:{item['line']}"
                    self.summaries_list.append(FunctionSummary(location=location, summary=item["summary"]))
                else:
                    raise ValueError(f"Invalid summary format: {item}")

            # Convert to dict for easy lookup
            self.summaries = {s.line: s.summary for s in self.summaries_list}

            # Store contract code
            self.contract_code = contract_code

            # Mark as generated
            self.generated = True

            logger.info(f"✓ Loaded {len(self.summaries)} summaries from file")

        except json.JSONDecodeError as e:
            raise RuntimeError(f"Failed to parse summary file as JSON: {e}")
        except Exception as e:
            raise RuntimeError(f"Failed to load summaries from file: {e}")

    async def generate_summaries_once(self, contract_code: str, contract_name: str) -> None:
        """
        Generate summaries for all functions in the contract (called once per execution).

        Args:
            contract_code: The full Solidity contract code
            contract_name: Name of the contract being analyzed

        Raises:
            RuntimeError: If summary generation fails or validation fails
        """
        if not self.enabled:
            logger.info("Summary generation disabled, skipping")
            return

        if self.generated:
            logger.info("Summaries already generated, skipping")
            return

        logger.info(f"Generating summaries for contract {contract_name}...")
        self.contract_code = contract_code

        # Step 1: Extract function hints to help Claude find all functions
        function_hints = self._extract_function_hints(contract_code)
        logger.info(f"Found {len(function_hints)} functions to summarize")

        # Step 2: Request summaries from Claude
        try:
            self.summaries_list = await self._request_summaries_from_claude(
                contract_code, contract_name, function_hints
            )
        except Exception as e:
            logger.error(f"Failed to generate summaries: {e}")
            raise RuntimeError(f"Summary generation failed: {e}")

        # Step 3: Convert to dict for easy lookup (do this before validation)
        self.summaries = {s.line: s.summary for s in self.summaries_list}

        # Step 4: Save to disk (do this before validation so we save even if validation fails)
        self._save_summaries()

        # Step 5: Validate that all functions are covered
        try:
            self._validate_summaries(function_hints)
        except RuntimeError:
            # Validation failed, but we've already saved partial summaries
            logger.error("Validation failed - partial summaries saved")
            raise

        self.generated = True
        logger.info(f"✓ Generated {len(self.summaries)} function summaries")

    async def _request_summaries_from_claude(
        self, contract_code: str, contract_name: str, function_hints: list[tuple[str, int]]
    ) -> list[FunctionSummary]:
        """
        Make the API call to Claude to generate summaries.

        Args:
            contract_code: The full Solidity contract code
            contract_name: Name of the contract being analyzed
            function_hints: List of (function_name, line_number) tuples

        Returns:
            List of FunctionSummary objects
        """
        # Build hint list for Claude
        hint_text = "\n".join(f"  - {name} (around line {line})" for name, line in function_hints)

        prompt = f"""
You are analyzing a Solidity smart contract to generate concise summaries for property verification.

Below is the contract code:

```solidity
{contract_code}
```

Contract name: {contract_name}

IMPORTANT: You must provide summaries for ALL {len(function_hints)} items listed below. Do not skip any item.

Functions and modifiers to summarize:
{hint_text}

For EACH item in the list above (functions, modifiers, constructors, fallback, receive), provide:

1. Location: Use format "ContractName:functionName:lineNumber" where:
   - ContractName: The contract containing the function/modifier (e.g., "{contract_name}")
   - functionName: The exact name from the list above (e.g., "transfer")
   - lineNumber: The line number where the function/modifier is declared, as shown in the list above (e.g., 150)

2. Summary: One-sentence description of what it does (not implementation details)

Summary guidelines:
- Be concise (1 sentence, max 100 chars)
- Focus on behavior and purpose
- Mention key state changes if relevant
- For view functions, describe what they calculate/return
- For modifiers, describe the access control check or validation they perform
- For simple modifiers with revert statements, describe the condition being enforced

CRITICAL: Your response must include exactly {len(function_hints)} summaries - one for each item in the list above.

Output format: JSON array of objects with fields: location, summary

Example:
Given this Solidity function at line 150:
```solidity
/// @notice Transfers tokens from sender to recipient
/// @param recipient The address to receive tokens
/// @param amount The amount of tokens to transfer
function transfer(address recipient, uint256 amount) public returns (bool) {{
    require(recipient != address(0), "Invalid recipient");
    balances[msg.sender] -= amount;
    balances[recipient] += amount;
    emit Transfer(msg.sender, recipient, amount);
    return true;
}}
```
Expected output:
{{"location": "{contract_name}:transfer:150", "summary": "Transfers tokens from sender to recipient"}}
""".strip()

        model = ChatAnthropic(
            model_name=SUMMARIZER_MODEL,
            max_tokens=self.MAX_SUMMARY_TOKENS,  # type: ignore[call-arg]
            temperature=0,
        )

        structured_model = model.with_structured_output(ContractSummaries, include_raw=True)

        messages = [HumanMessage(content=prompt)]

        logger.info("Requesting summaries from Claude API...")
        response = await structured_model.ainvoke(messages)

        # Track token usage using the raw response
        if "raw" in response:  # type: ignore[operator]
            self.token_tracker.log_usage_summarization(
                response["raw"],  # type: ignore[index]
                key=contract_name,
                description=f"Generated summaries for {len(function_hints)} functions",
            )

        parsed: ContractSummaries = response["parsed"]  # type: ignore[index]
        return parsed.summaries

    def _extract_function_hints(self, contract_code: str) -> list[tuple[str, int]]:
        """
        Extract function names and line numbers from the contract code.

        Only returns functions with implementations (not interface declarations).
        A function has an implementation if it has an opening brace '{' after the signature.

        Args:
            contract_code: The full Solidity contract code

        Returns:
            List of (function_name, line_number) tuples for functions with implementations
        """
        lines = contract_code.split("\n")
        functions = []

        for i, line in enumerate(lines, start=1):
            # Look for function/modifier/constructor/fallback/receive
            # Match patterns like:
            # - function foo(...) ...
            # - modifier bar(...) ...
            # - constructor(...) ...
            # - fallback() ...
            # - receive() ...
            stripped = line.strip()

            # Skip comments and empty lines
            if not stripped or stripped.startswith("//") or stripped.startswith("*"):
                continue

            function_name = None

            # Match function declarations
            func_match = re.search(r"\bfunction\s+(\w+)\s*\(", line)
            if func_match:
                function_name = func_match.group(1)

            # Match modifiers
            if not function_name:
                mod_match = re.search(r"\bmodifier\s+(\w+)\s*\(", line)
                if mod_match:
                    function_name = mod_match.group(1)

            # Match constructor
            if not function_name and re.search(r"\bconstructor\s*\(", line):
                function_name = "constructor"

            # Match fallback/receive
            if not function_name and re.search(r"\bfallback\s*\(", line):
                function_name = "fallback"

            if not function_name and re.search(r"\breceive\s*\(", line):
                function_name = "receive"

            # If we found a function, check if it has an implementation
            if function_name:
                # Look ahead to find if there's a '{' (implementation) or ';' (declaration only)
                # The function signature might span multiple lines
                has_implementation = False
                j = i - 1  # Convert to 0-based index

                # Search ahead for '{' or ';' to determine if function has implementation
                for k in range(j, min(j + self.FUNCTION_LOOKAHEAD_LINES, len(lines))):
                    check_line = lines[k]

                    # Check for opening brace FIRST (before semicolon)
                    # This handles cases where { and ; are on the same line
                    # e.g., function foo() { value = 1; }
                    if "{" in check_line:
                        has_implementation = True
                        break

                    # If we find a semicolon and no brace yet, it's a declaration only (interface)
                    if ";" in check_line:
                        break

                # Only add functions with implementations
                if has_implementation:
                    functions.append((function_name, i))

        return functions

    def _validate_summaries(self, function_hints: list[tuple[str, int]]) -> None:
        """
        Validate that all functions have summaries.

        Args:
            function_hints: List of (function_name, line_number) tuples from extraction

        Raises:
            RuntimeError: If validation fails (missing functions)
        """
        # Get function names from hints
        expected_functions = {name for name, _ in function_hints}

        # Get function names from summaries
        summarized_functions = {s.function for s in self.summaries_list}

        # Check for missing functions
        missing = expected_functions - summarized_functions

        if missing:
            logger.error(f"Validation failed: Missing summaries for {len(missing)} functions")
            logger.error(f"Missing functions: {', '.join(sorted(missing))}")
            raise RuntimeError(
                f"Summary validation failed: {len(missing)} functions not summarized: {', '.join(sorted(missing)[:5])}"
            )

        # Check for extra functions (not critical, just log)
        extra = summarized_functions - expected_functions
        if extra:
            logger.warning(f"Summaries include {len(extra)} functions not found by hint extraction")
            logger.warning(f"Extra functions: {', '.join(sorted(extra)[:5])}")

        logger.info(f"✓ Validation passed: All {len(expected_functions)} functions have summaries")

    def _save_summaries(self) -> None:
        """Save summaries to .certora_internal/summaries.json."""
        output_path = self.properties_dir / "summaries.json"

        # Convert to serializable format
        summaries_data = [
            {"contract": s.contract, "function": s.function, "line": s.line, "summary": s.summary}
            for s in self.summaries_list
        ]

        with open(output_path, "w") as f:
            json.dump(summaries_data, f, indent=2)

        logger.info(f"Summaries saved to: {output_path}")

    def get_contract_for_properties(self) -> str:
        """
        Get the contract code to use for property generation.

        If summaries are enabled and generated, returns declarations-only contract.
        Otherwise, returns the original contract code.

        Returns:
            Contract code (either declarations-only or original)
        """
        if not self.enabled or not self.generated:
            return self.contract_code

        # Use the summarize function to convert to declarations-only
        declarations_only, _ = summarize(self.contract_code, self.summaries)
        return declarations_only

    def get_summaries(self) -> dict[int, str]:
        """Get the generated summaries dict (line_number -> summary)."""
        return self.summaries

    def is_ready(self) -> bool:
        """Check if summaries have been generated."""
        return self.enabled and self.generated

    def get_summary_stats(self) -> dict[str, Any]:
        """Get statistics about the summaries."""
        return {
            "enabled": self.enabled,
            "generated": self.generated,
            "num_summaries": len(self.summaries),
            "contracts": list(set(s.contract for s in self.summaries_list)),
        }


# ========== FACTORY METHOD ==========


def create_summarizer(
    enabled: bool,
    properties_dir: Path,
    token_tracker: Any,
    solc_parser: Any,
    contract: str,
    exclude_libs: bool = False,
    summary_file: Path | None = None,
) -> Summarizer:
    """
    Factory method to create and initialize a Summarizer instance.

    If summary mode is enabled, this will either:
    - Load summaries from file (if summary_file is provided), OR
    - Generate summaries via Claude API

    Steps when generating (not loading from file):
    1. Create the Summarizer instance
    2. Extract flattened code from SolcParser
    3. Filter library code if requested
    4. Generate summaries via Claude API
    5. Validate all functions are covered
    6. Save summaries to disk

    If summary mode is disabled, returns an empty Summarizer instance.

    Args:
        enabled: Whether summary generation is enabled (--summary flag)
        properties_dir: Directory to store summaries.json
        token_tracker: Token usage tracker instance
        solc_parser: SolcParser instance (contains flattened code)
        contract: Name of the contract being analyzed
        exclude_libs: Whether to filter library code before summarization
        summary_file: Optional path to JSON file with pre-generated summaries

    Returns:
        Summarizer instance

    Raises:
        RuntimeError: If summary generation or loading fails
    """

    # Create Summarizer instance
    summarizer = Summarizer(enabled=enabled, properties_dir=properties_dir, token_tracker=token_tracker)

    # If summary mode is enabled
    if enabled:
        # Get the flattened code from SolcParser (already flattened if forge flatten succeeded)
        contract_code = solc_parser.source_code.decode("utf-8")

        # Filter library code if requested
        if exclude_libs:
            contract_code, _ = filter_library_files(contract_code)

        try:
            # Load from file if provided, otherwise generate via Claude API
            if summary_file:
                summarizer.load_from_file(summary_file, contract_code)
            else:

                async def generate_summaries():
                    await summarizer.generate_summaries_once(contract_code, contract)

                asyncio.run(generate_summaries())
        except RuntimeError as e:
            if summary_file:
                logger.error(f"Failed to load summaries from {summary_file}: {e}", exc_info=True)
            else:
                logger.error(f"Failed to generate summaries for contract {contract}: {e}", exc_info=True)
            raise  # Re-raise the exception to caller

    return summarizer
