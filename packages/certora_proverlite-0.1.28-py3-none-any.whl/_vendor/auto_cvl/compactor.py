#!/usr/bin/env python3
"""
Unified script to process Solidity contracts for property generation.

Pipeline:
1. Filter library files (for flattened contracts with file markers)
2. Add summary comments before function implementations
3. Convert implementations to declarations (remove function bodies)
4. Remove interfaces and specified libraries
5. Remove verbose NatSpec (@param, @return, @dev) but keep @notice
6. Reduce excessive whitespace
"""

import logging
import re

# Configure logging
logging.basicConfig(level=logging.WARNING, format="%(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Compile regex patterns for performance
FILE_MARKER_PATTERN = re.compile(r"//\s*(?:====\s*)?[Ff]ile:\s*(.+?)(?:\s*====)?$")
PATH_PATTERN = re.compile(r"//\s*([a-zA-Z0-9_\-./@ ]+\.sol)\s*$")
INTERFACE_PATTERN = re.compile(r"\binterface\s+(\w+)")
LIBRARY_PATTERN = re.compile(r"\blibrary\s+(\w+)")


def find_block_end(lines: list[str], start_idx: int, open_char: str = "{", close_char: str = "}") -> int:
    """Find the end of a block by counting braces."""
    brace_count = 0
    started = False

    for i in range(start_idx, len(lines)):
        line = lines[i]
        for char in line:
            if char == open_char:
                brace_count += 1
                started = True
            elif char == close_char:
                brace_count -= 1
                if started and brace_count == 0:
                    return i
    return -1


def filter_library_files(content: str, exclude_dirs: list[str] | None = None) -> tuple[str, list[str]]:
    """
    Filters out sections of flattened Solidity code from excluded directories.

    Forge flatten marks file boundaries with comments like:
    // ==== File: path/to/file.sol ====
    // File: path/to/file.sol
    // path/to/file.sol

    Args:
        content: The Solidity content string (possibly flattened)
        exclude_dirs: List of directory prefixes to exclude (e.g., ["lib/", "node_modules/"])
                     If None, defaults to common library directories

    Returns:
        Tuple of (filtered_content, list of excluded files)
    """
    if exclude_dirs is None:
        # Common library directory patterns
        exclude_dirs = [
            "lib/",
            "node_modules/",
            ".git/",
            "deps/",
            "dependencies/",
        ]

    lines = content.split("\n")
    filtered_lines = []
    skip_section = False
    current_file = None
    excluded_files = []

    for line in lines:
        stripped = line.strip()

        # NOTE: file_marker_match and path_match are empirically collected patterns used to mark
        # the beginnings of the contract and libraries in a flattened file. It's a heuristic approach
        # to detect the librariese in a flattened file produced by Forge.
        # A more robust approach to this task is a subject of future work.

        # Detect file markers (forge uses different formats)
        # Patterns: "// ==== File: ...", "// File: ...", "// path/to/file.sol"
        # First try the explicit "File:" format
        file_marker_match = FILE_MARKER_PATTERN.match(stripped)

        # If that doesn't match, try to detect path-like comments (contains / and .sol)
        if not file_marker_match:
            # Match comments that look like file paths (contain / and end with .sol)
            # Include @ symbol for scoped packages like @openzeppelin, @chainlink, etc.
            path_match = PATH_PATTERN.match(stripped)
            if path_match:
                file_marker_match = path_match

        if file_marker_match:
            current_file = file_marker_match.group(1).strip()

            # Check if this file is in an excluded directory
            skip_section = any(current_file.startswith(excluded) for excluded in exclude_dirs)

            if skip_section:
                logger.debug(f"Filtering out library file: {current_file}")
                excluded_files.append(current_file)
                continue  # Skip the file marker line itself
            else:
                logger.debug(f"Including code from: {current_file}")

        # Include line if we're not in an excluded section
        if not skip_section:
            filtered_lines.append(line)

    result = "\n".join(filtered_lines)

    # Validate filtering result
    if not result.strip():
        logger.warning("filter_library_files removed all content - check exclude_dirs patterns")

    return result, excluded_files


def should_remove_natspec_line(line: str) -> bool:
    """Check if this NatSpec line should be removed."""
    stripped = line.strip()

    # Keep @notice - it describes intended behavior
    if "@notice" in stripped:
        return False

    # Remove @param, @return, @dev, @custom, @title, @author
    return any(tag in stripped for tag in ["@param", "@return", "@dev", "@custom:", "@title", "@author"])


def is_removable_definition(
    line: str, remove_interfaces: bool, libraries_to_remove: set[str] | None
) -> tuple[bool, str | None, str | None]:
    """Check if line starts an interface or library that should be removed."""
    # Check for interface
    if remove_interfaces:
        match = INTERFACE_PATTERN.search(line)
        if match:
            return True, "interface", match.group(1)

    # Check for libraries in the removal list
    if libraries_to_remove:
        match = LIBRARY_PATTERN.search(line)
        if match:
            lib_name = match.group(1)
            if lib_name in libraries_to_remove:
                return True, "library", lib_name

    return False, None, None


def compact_contract(
    lines: list[str], remove_interfaces: bool = True, libraries_to_remove: set[str] | None = None
) -> tuple[list[str], list[str], list[str]]:
    """
    Remove interfaces, libraries, and verbose NatSpec to reduce token count.

    Args:
        lines: List of file lines
        remove_interfaces: Whether to remove interface definitions
        libraries_to_remove: Set of library names to remove

    Returns:
        Tuple of (compacted_lines, removed_interfaces, removed_libraries)
    """
    if libraries_to_remove is None:
        libraries_to_remove = set()

    output_lines = []
    i = 0
    removed_interfaces = []
    removed_libraries = []
    in_comment_block = False
    removing_natspec_section = False  # use to track if we're removing a multi-line NatSpec tag

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Track comment blocks
        if "/**" in line:
            in_comment_block = True
            removing_natspec_section = False

        # If in comment block, check if we should remove this line
        if in_comment_block:
            # Check if this line starts a new @ tag and eventually remove it
            has_tag = "@" in stripped and stripped.startswith("*")
            if has_tag:
                removing_natspec_section = should_remove_natspec_line(line)

            # Remove this line if we're in a removable section
            if removing_natspec_section:
                i += 1
                if "*/" in line:
                    in_comment_block = False
                    removing_natspec_section = False
                continue

            if "*/" in line:
                in_comment_block = False
                removing_natspec_section = False

        # Check if this line starts an interface or library to remove
        is_removable, block_type, name = is_removable_definition(line, remove_interfaces, libraries_to_remove)

        if is_removable:
            if block_type == "interface":
                removed_interfaces.append(name)
            elif block_type == "library":
                removed_libraries.append(name)

            # Find the end of this block
            end_idx = find_block_end(lines, i)

            if end_idx != -1:
                # Skip the entire block
                i = end_idx + 1
                continue

        # Check for excessive blank lines (more than 1 consecutive)
        if not stripped:
            # Count consecutive blank lines ahead
            blank_count = 1
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                blank_count += 1
                j += 1

            # Keep at most 1 blank line
            if blank_count > 1:
                output_lines.append("\n")
                i = j
                continue

        # Keep this line
        output_lines.append(line)
        i += 1

    return output_lines, removed_interfaces, removed_libraries


def compact_solidity_code(
    content: str, remove_interfaces: bool = True, libraries_to_remove: set[str] | None = None
) -> tuple[str, dict[str, list[str]]]:
    """
    Convenience wrapper to compact Solidity code in one call.

    Performs three operations:
    1. Remove interfaces and specified libraries
    2. Remove verbose NatSpec (@param, @return, @dev) but keep @notice
    3. Reduce excessive whitespace

    Args:
        content: Solidity source code as string
        remove_interfaces: Whether to remove interface definitions (default: True)
        libraries_to_remove: Set of library names to remove (default: None)

    Returns:
        Tuple of (compacted_code, removed_items_dict)
        where removed_items_dict = {
            "interfaces": [list of interface names],
            "libraries": [list of library names]
        }

    Example:
        >>> code = open("contract.sol").read()
        >>> compacted, removed = compact_solidity_code(code, libraries_to_remove={"TimeLib"})
        >>> print(f"Removed: {removed}")
        >>> with open("compacted.sol", "w") as f:
        ...     f.write(compacted)
    """
    if libraries_to_remove is None:
        libraries_to_remove = set()

    lines = content.splitlines(keepends=True)

    # Run compact_contract
    compacted_lines, removed_interfaces, removed_libraries = compact_contract(
        lines, remove_interfaces, libraries_to_remove
    )

    # Convert back to string
    result = "".join(compacted_lines)

    # Return with metadata
    removed_items = {"interfaces": removed_interfaces, "libraries": removed_libraries}

    return result, removed_items
