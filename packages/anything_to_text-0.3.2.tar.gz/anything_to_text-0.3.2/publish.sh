#!/bin/bash
set -e

echo "================================"
echo "  Publishing anything-to-text"
echo "================================"
echo ""

# Clean previous builds
echo "Cleaning previous builds..."
rm -rf dist/ build/ src/*.egg-info *.egg-info

# Build
echo "Building package..."
python -m build

# Show what was built
echo ""
echo "Built files:"
ls -lh dist/

# Upload to PyPI
echo ""
echo "Uploading to PyPI..."
twine upload dist/*

echo ""
echo "================================"
echo "  Published successfully!"
echo "================================"
echo ""
echo "Verify at: https://pypi.org/project/anything-to-text/"
