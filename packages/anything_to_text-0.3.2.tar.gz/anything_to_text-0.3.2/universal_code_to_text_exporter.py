#!/usr/bin/env python3
# If you hit import errors, run:
#   pip install pathspec rich questionary
"""
universal_anything_to_text_exporter.py

Export source code and important project text files into AI-friendly bundle_XXX.txt files,
while producing a compact MANIFEST.json that tells an AI assistant exactly which source file
(or file chunk) appears in which bundle and on which line range.

Key capabilities
----------------
- Respects .gitignore via pathspec, plus skips common build / cache / generated folders.
- Supports common backend, mobile, frontend, and config file types:
  Python, TypeScript, JavaScript, Java, Kotlin, Swift / Objective-C headers, HTML/CSS,
  JSON / YAML / TOML / XML / GraphQL / Markdown / text config files, and common special
  filenames such as Dockerfile, Podfile, Jenkinsfile, package.json, pyproject.toml, etc.
- Interactive selection modes:
  1) all supported files
  2) categories
  3) file / folder paths
  4) mixed mode (categories + paths + filename contains filter)
- Fancy checkbox UI is available with --fancy-ui when questionary is installed.
- Path selection is flexible:
  - accepts project-relative paths
  - accepts absolute paths
  - accepts plain filenames (for example: AndroidManifest.xml, DashboardItem.kt)
  - if a plain filename matches exactly one supported file, the script shows the resolved path
    and asks whether to use it
  - if a plain filename matches multiple supported files, the script asks the user which one
    they mean before continuing
- Keeps each generated bundle within the configured max rendered line limit (default: 8000),
  including the extra header/footer lines inserted around each exported file chunk.
- Large files are split into multiple chunks safely instead of failing the full run.
- If a file or chunk still cannot be packed safely, the script continues exporting everything
  else and records the skipped items in MANIFEST.json and terminal output.
- MANIFEST.json is intentionally compact:
  - bundle-level file entries contain the exact mapping needed by AI tools
  - redundant top-level per-file duplication is avoided
- Optional PROJECT_OVERVIEW.txt summarizes architecture hints, top folders, frameworks,
  dependency files, and a suggested reading order for Copilot / AI assistants.
- Secret-like files (.env, keys, certs, keystores, etc.) are skipped by default unless
  --include-secret-files is used.

Typical usage
-------------
Interactive mode:
    python universal_anything_to_text_exporter.py

Fancy checkbox UI:
    python universal_anything_to_text_exporter.py --fancy-ui

Specific project root:
    python universal_anything_to_text_exporter.py /path/to/project

Non-interactive export of selected categories:
    python universal_anything_to_text_exporter.py /path/to/project \
        --non-interactive --categories python web_ui --max-lines 8000

Non-interactive export of selected files / folders:
    python universal_anything_to_text_exporter.py . \
        --non-interactive --paths src app/backend/main.py /absolute/path/to/file.py

Generate an overview file too:
    python universal_anything_to_text_exporter.py . --project-overview
"""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


INSTALL_HINT = "pip install pathspec rich questionary"

# Required dependency
try:
    import pathspec
except Exception:
    print(
        "\nMissing required dependency: pathspec\n"
        "Please run:\n"
        f"    {INSTALL_HINT}\n",
        file=sys.stderr,
    )
    raise SystemExit(2)

# Optional dependency: rich (pretty terminal output)
try:
    from rich.console import Console
    from rich.table import Table
    RICH_AVAILABLE = True
except Exception:
    Console = None
    Table = None
    RICH_AVAILABLE = False
    print(
        "\nOptional dependency 'rich' is not available.\n"
        "The script will still work, but output will be plain text.\n"
        "If you want better terminal tables/colors, run:\n"
        f"    {INSTALL_HINT}\n",
        file=sys.stderr,
    )

# Optional dependency: questionary (fancy checkbox UI)
try:
    import questionary
    QUESTIONARY_AVAILABLE = True
except Exception:
    questionary = None
    QUESTIONARY_AVAILABLE = False
    print(
        "\nOptional dependency 'questionary' is not available.\n"
        "Standard interactive mode will still work, but fancy checkbox UI will not.\n"
        "If you want fancy UI, run:\n"
        f"    {INSTALL_HINT}\n",
        file=sys.stderr,
    )

# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------
DEFAULT_MAX_LINES = 8000
DEFAULT_OUTPUT_DIR = "exported_sources"
DEFAULT_TEXT_ENCODING = "utf-8"

console = Console() if Console else None

CATEGORY_EXTENSIONS: Dict[str, set[str]] = {
    "python": {".py"},
    "typescript": {".ts", ".tsx"},
    "javascript": {".js", ".jsx", ".mjs", ".cjs"},
    "java_kotlin": {".java", ".kt", ".kts", ".gradle", ".properties", ".pro"},
    "ios_apple": {".swift", ".m", ".mm", ".h", ".hpp", ".pbxproj", ".plist", ".xcconfig"},
    "web_ui": {".html", ".css", ".scss", ".sass", ".less", ".vue", ".svelte"},
    "config_docs": {".json", ".yaml", ".yml", ".xml", ".toml", ".graphql", ".gql", ".md", ".txt"},
}

SPECIAL_FILENAMES = {
    "Dockerfile",
    "Podfile",
    "Gemfile",
    "Fastfile",
    "Makefile",
    "Jenkinsfile",
    "package.json",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "tsconfig.json",
    "pyproject.toml",
    "requirements.txt",
    "requirements-dev.txt",
    "requirements-ci.txt",
    "Pipfile",
    "Pipfile.lock",
    ".swiftlint.yml",
    ".eslintrc",
    ".eslintrc.json",
    ".eslintrc.js",
    ".prettierrc",
    ".prettierrc.json",
    ".prettierrc.js",
    "AndroidManifest.xml",
    "gradle.properties",
    "settings.gradle",
    "settings.gradle.kts",
    "build.gradle",
    "build.gradle.kts",
}

DEFAULT_EXCLUDED_DIRS = {
    ".git",
    ".svn",
    ".hg",
    ".idea",
    ".vscode",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    "node_modules",
    "dist",
    "build",
    ".next",
    ".nuxt",
    ".turbo",
    "coverage",
    ".coverage",
    ".gradle",
    ".kotlin",
    "Pods",
    "DerivedData",
    ".dart_tool",
    ".serverless",
    ".terraform",
    ".expo",
    ".parcel-cache",
    ".yarn",
    ".pnpm-store",
    ".cache",
    "out",
    "bin",
    "obj",
    "target",
}

DEFAULT_SECRET_PATTERNS = {
    ".env",
    ".env.*",
    "*.pem",
    "*.key",
    "*.crt",
    "*.cer",
    "*.p12",
    "*.pfx",
    "*.jks",
    "*.keystore",
    "*.mobileprovision",
    "*.der",
    "*.p8",
    "id_rsa",
    "id_ed25519",
    "google-services.json",
    "GoogleService-Info.plist",
}

CATEGORY_DESCRIPTIONS = {
    "python": "Python backend / scripts",
    "typescript": "TypeScript / TSX",
    "javascript": "JavaScript / JSX",
    "java_kotlin": "Android / JVM (Java, Kotlin, Gradle, properties)",
    "ios_apple": "iOS / Apple platform files",
    "web_ui": "HTML / CSS / UI frameworks",
    "config_docs": "Config / metadata / docs",
}

CATEGORY_ALIASES = {
    "py": "python",
    "python": "python",
    "ts": "typescript",
    "tsx": "typescript",
    "typescript": "typescript",
    "js": "javascript",
    "jsx": "javascript",
    "javascript": "javascript",
    "java": "java_kotlin",
    "kotlin": "java_kotlin",
    "android": "java_kotlin",
    "jvm": "java_kotlin",
    "ios": "ios_apple",
    "swift": "ios_apple",
    "apple": "ios_apple",
    "web": "web_ui",
    "frontend": "web_ui",
    "ui": "web_ui",
    "config": "config_docs",
    "docs": "config_docs",
}

# -----------------------------------------------------------------------------
# Data structures
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class SourceFile:
    abs_path: Path
    rel_path: Path
    category: str
    line_count: int
    size_bytes: int
    sha256: str
    lines: List[str] = field(repr=False)


@dataclass(frozen=True)
class FileChunk:
    rel_path: Path
    category: str
    chunk_index: int
    chunk_count: int
    start_line: int
    end_line: int
    total_file_lines: int
    lines: List[str] = field(repr=False)

    @property
    def line_count(self) -> int:
        return len(self.lines)

# -----------------------------------------------------------------------------
# Small output helpers
# -----------------------------------------------------------------------------
def print_info(message: str) -> None:
    if console:
        console.print(f"[cyan]{message}[/cyan]")
    else:
        print(message)


def print_success(message: str) -> None:
    if console:
        console.print(f"[green]{message}[/green]")
    else:
        print(message)


def print_warning(message: str) -> None:
    if console:
        console.print(f"[yellow]{message}[/yellow]")
    else:
        print(message)


def print_error(message: str) -> None:
    if console:
        console.print(f"[bold red]{message}[/bold red]")
    else:
        print(message)


def prompt_yes_no(message: str, default: bool = True) -> bool:
    suffix = " [Y/n]: " if default else " [y/N]: "
    raw = input(message + suffix).strip().lower()
    if not raw:
        return default
    return raw in {"y", "yes"}

# -----------------------------------------------------------------------------
# .gitignore and path filtering
# -----------------------------------------------------------------------------
def load_gitignore_spec(root: Path) -> pathspec.PathSpec:
    gitignore_path = root / ".gitignore"
    patterns: List[str] = []
    if gitignore_path.exists():
        try:
            patterns.extend(gitignore_path.read_text(encoding=DEFAULT_TEXT_ENCODING).splitlines())
        except UnicodeDecodeError:
            patterns.extend(gitignore_path.read_text(errors="ignore").splitlines())
    return pathspec.PathSpec.from_lines("gitwildmatch", patterns)


def path_matches_any_pattern(rel_path: str, patterns: Iterable[str]) -> bool:
    return any(fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(Path(rel_path).name, pattern) for pattern in patterns)


def should_skip_by_dir(rel_path: Path) -> bool:
    return any(part in DEFAULT_EXCLUDED_DIRS for part in rel_path.parts)


def is_ignored(rel_path: Path, gitignore_spec: pathspec.PathSpec, skip_secret_files: bool) -> Tuple[bool, str]:
    rel_str = rel_path.as_posix()
    if should_skip_by_dir(rel_path):
        return True, "default_excluded_dir"
    if gitignore_spec.match_file(rel_str):
        return True, ".gitignore"
    if skip_secret_files and path_matches_any_pattern(rel_str, DEFAULT_SECRET_PATTERNS):
        return True, "secret_like_file"
    return False, ""

# -----------------------------------------------------------------------------
# File detection and reading
# -----------------------------------------------------------------------------
def detect_category(path: Path) -> str | None:
    name = path.name
    suffix = path.suffix.lower()
    if name in SPECIAL_FILENAMES:
        if name in {"Podfile", ".swiftlint.yml"}:
            return "ios_apple"
        if name in {"AndroidManifest.xml", "gradle.properties", "settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts"}:
            return "java_kotlin"
        return "config_docs"
    for category, extensions in CATEGORY_EXTENSIONS.items():
        if suffix in extensions:
            return category
    return None


def is_probably_binary(path: Path) -> bool:
    try:
        with path.open("rb") as fh:
            sample = fh.read(4096)
        return b"\x00" in sample
    except OSError:
        return True


def read_text_lines(path: Path) -> List[str]:
    encodings = ["utf-8", "utf-8-sig", "latin-1"]
    last_error: Exception | None = None
    for encoding in encodings:
        try:
            return path.read_text(encoding=encoding).splitlines()
        except UnicodeDecodeError as exc:
            last_error = exc
    if last_error is not None:
        return path.read_text(encoding="utf-8", errors="ignore").splitlines()
    return []


def sha256_of_lines(lines: Sequence[str]) -> str:
    joined = "\n".join(lines).encode("utf-8", errors="ignore")
    return hashlib.sha256(joined).hexdigest()


def scan_supported_files(root: Path, skip_secret_files: bool) -> Tuple[List[SourceFile], Dict[str, int]]:
    gitignore_spec = load_gitignore_spec(root)
    discovered: List[SourceFile] = []
    skipped_reasons: Dict[str, int] = defaultdict(int)
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel_path = path.relative_to(root)
        ignored, reason = is_ignored(rel_path, gitignore_spec, skip_secret_files)
        if ignored:
            skipped_reasons[reason] += 1
            continue
        category = detect_category(path)
        if not category:
            skipped_reasons["unsupported_type"] += 1
            continue
        if is_probably_binary(path):
            skipped_reasons["binary"] += 1
            continue
        try:
            lines = read_text_lines(path)
        except OSError:
            skipped_reasons["read_error"] += 1
            continue
        discovered.append(
            SourceFile(
                abs_path=path.resolve(),
                rel_path=rel_path,
                category=category,
                line_count=len(lines),
                size_bytes=path.stat().st_size,
                sha256=sha256_of_lines(lines),
                lines=lines,
            )
        )
    discovered.sort(key=lambda item: item.rel_path.as_posix())
    return discovered, dict(sorted(skipped_reasons.items()))

# -----------------------------------------------------------------------------
# Selection logic
# -----------------------------------------------------------------------------
def summarize_by_category(files: Sequence[SourceFile]) -> Dict[str, Dict[str, int]]:
    summary: Dict[str, Dict[str, int]] = defaultdict(lambda: {"files": 0, "lines": 0, "bytes": 0})
    for item in files:
        summary[item.category]["files"] += 1
        summary[item.category]["lines"] += item.line_count
        summary[item.category]["bytes"] += item.size_bytes
    return dict(summary)


def summarize_top_folders(files: Sequence[SourceFile], max_depth: int = 2) -> Dict[str, Dict[str, int]]:
    summary: Dict[str, Dict[str, int]] = defaultdict(lambda: {"files": 0, "lines": 0})
    for item in files:
        parts = item.rel_path.parts[:max_depth]
        folder = "/".join(parts[:-1]) if len(parts) > 1 else "."
        summary[folder]["files"] += 1
        summary[folder]["lines"] += item.line_count
    return dict(sorted(summary.items(), key=lambda pair: (-pair[1]["files"], pair[0])))


def render_category_table(files: Sequence[SourceFile]) -> None:
    summary = summarize_by_category(files)
    if Table and console:
        table = Table(title="Detected source files by category")
        table.add_column("Category")
        table.add_column("Description")
        table.add_column("Files", justify="right")
        table.add_column("Lines", justify="right")
        table.add_column("Bytes", justify="right")
        for category in CATEGORY_DESCRIPTIONS:
            row = summary.get(category, {"files": 0, "lines": 0, "bytes": 0})
            table.add_row(category, CATEGORY_DESCRIPTIONS[category], str(row["files"]), str(row["lines"]), str(row["bytes"]))
        console.print(table)
    else:
        print("\nDetected source files by category")
        for category in CATEGORY_DESCRIPTIONS:
            row = summary.get(category, {"files": 0, "lines": 0, "bytes": 0})
            print(f"- {category:12} | files={row['files']:4} lines={row['lines']:6} bytes={row['bytes']:8} | {CATEGORY_DESCRIPTIONS[category]}")


def render_folder_table(files: Sequence[SourceFile], limit: int = 20) -> None:
    folder_summary = summarize_top_folders(files)
    items = list(folder_summary.items())[:limit]
    if not items:
        return
    if Table and console:
        table = Table(title=f"Top folders (showing first {len(items)})")
        table.add_column("Folder")
        table.add_column("Files", justify="right")
        table.add_column("Lines", justify="right")
        for folder, data in items:
            table.add_row(folder, str(data["files"]), str(data["lines"]))
        console.print(table)
    else:
        print("\nTop folders")
        for folder, data in items:
            print(f"- {folder:30} files={data['files']:4} lines={data['lines']:6}")


def ask_choice(prompt: str, valid_choices: Sequence[str], default: str | None = None) -> str:
    valid_normalized = {choice.lower(): choice for choice in valid_choices}
    while True:
        suffix = f" [{'/'.join(valid_choices)}]"
        if default:
            suffix += f" (default: {default})"
        raw = input(f"{prompt}{suffix}: ").strip().lower()
        if not raw and default:
            return default
        if raw in valid_normalized:
            return valid_normalized[raw]
        print_warning(f"Please choose one of: {', '.join(valid_choices)}")


def parse_csv_input(raw: str) -> List[str]:
    return [token.strip() for token in raw.split(",") if token.strip()]


def normalize_categories(values: Sequence[str]) -> List[str]:
    normalized: List[str] = []
    for value in values:
        key = value.strip().lower()
        if not key:
            continue
        mapped = CATEGORY_ALIASES.get(key, key)
        if mapped in CATEGORY_DESCRIPTIONS and mapped not in normalized:
            normalized.append(mapped)
    return normalized


def normalize_selection_paths(raw_paths: Sequence[str], root: Path) -> List[str]:
    normalized: List[str] = []
    for raw in raw_paths:
        value = raw.strip()
        if not value:
            continue
        candidate = Path(value).expanduser()
        if candidate.is_absolute():
            try:
                rel = candidate.resolve().relative_to(root)
                value = rel.as_posix()
            except Exception:
                value = candidate.resolve().as_posix()
        else:
            value = value.rstrip("/")
        if value not in normalized:
            normalized.append(value)
    return normalized


def _select_single_match_with_prompt(raw_token: str, matches: List[SourceFile], fancy: bool) -> List[SourceFile]:
    if len(matches) == 1:
        match = matches[0]
        resolved_message = f"'{raw_token}' resolved to '{match.rel_path.as_posix()}'"
        if fancy and QUESTIONARY_AVAILABLE:
            accepted = questionary.confirm(f"{resolved_message}. Use this file?", default=True).ask()
            return [match] if accepted else []
        accepted = prompt_yes_no(f"{resolved_message}. Use this file?", default=True)
        return [match] if accepted else []

    if fancy and QUESTIONARY_AVAILABLE:
        choice = questionary.select(
            f"'{raw_token}' matches multiple files. Which one do you mean?",
            choices=[m.rel_path.as_posix() for m in matches] + ["<skip this token>"],
        ).ask()
        if not choice or choice == "<skip this token>":
            return []
        return [m for m in matches if m.rel_path.as_posix() == choice][:1]

    print_warning(f"'{raw_token}' matches multiple files:")
    for idx, item in enumerate(matches, start=1):
        print_warning(f"  {idx}) {item.rel_path.as_posix()}")
    print_warning("  0) skip this token")
    while True:
        raw = input("Choose the matching file number: ").strip()
        if raw.isdigit():
            value = int(raw)
            if value == 0:
                return []
            if 1 <= value <= len(matches):
                return [matches[value - 1]]
        print_warning("Please enter a valid number.")


def filter_files_by_paths(
    files: Sequence[SourceFile],
    root: Path,
    raw_paths: Sequence[str],
    *,
    interactive: bool,
    fancy: bool,
) -> Tuple[List[SourceFile], List[str], List[str]]:
    normalized_paths = normalize_selection_paths(raw_paths, root)
    if not normalized_paths:
        return list(files), [], []

    matched: List[SourceFile] = []
    missing_inputs: List[str] = []

    for raw_input, normalized in zip(raw_paths, normalized_paths):
        raw_candidate = Path(raw_input).expanduser()
        abs_candidate = raw_candidate.resolve() if raw_candidate.is_absolute() else (root / raw_candidate).resolve()
        raw_name = raw_candidate.name
        looks_like_file_name_only = (not raw_candidate.is_absolute()) and ("/" not in raw_input) and ("\\" not in raw_input)

        exact_matches = [
            item for item in files
            if item.rel_path.as_posix() == normalized
            or item.rel_path.as_posix().startswith(normalized.rstrip("/") + "/")
            or item.abs_path.resolve() == abs_candidate
        ]

        if exact_matches:
            for item in exact_matches:
                if item not in matched:
                    matched.append(item)
            continue

        if looks_like_file_name_only:
            basename_matches = [item for item in files if item.rel_path.name == raw_name]
            if len(basename_matches) == 1 and interactive:
                for item in _select_single_match_with_prompt(raw_input, basename_matches, fancy):
                    if item not in matched:
                        matched.append(item)
                continue
            if len(basename_matches) > 1 and interactive:
                for item in _select_single_match_with_prompt(raw_input, basename_matches, fancy):
                    if item not in matched:
                        matched.append(item)
                continue
            if len(basename_matches) == 1 and not interactive:
                item = basename_matches[0]
                if item not in matched:
                    matched.append(item)
                continue
            if len(basename_matches) > 1 and not interactive:
                missing_inputs.append(f"{raw_input} (ambiguous: {len(basename_matches)} matches)")
                continue

        missing_inputs.append(raw_input)

    matched.sort(key=lambda item: item.rel_path.as_posix())
    return matched, normalized_paths, missing_inputs


def interactive_select_files(all_files: Sequence[SourceFile], root: Path) -> Tuple[List[SourceFile], Dict[str, object]]:
    if not all_files:
        return [], {"selection_mode": "interactive", "selected_categories": [], "selected_paths": [], "name_filters": []}

    render_category_table(all_files)
    render_folder_table(all_files)

    print_info("\nSelection modes:")
    print_info("  1) all       -> export everything supported")
    print_info("  2) category  -> pick categories like python, typescript, ios_apple")
    print_info("  3) path      -> pick files/folders by relative path, absolute path, or just filename")
    print_info("  4) mixed     -> categories + paths + file name contains filter")

    mode = ask_choice("Choose selection mode", ["1", "2", "3", "4"], default="1")
    selected = list(all_files)
    metadata: Dict[str, object] = {
        "selection_mode": {"1": "all", "2": "category", "3": "path", "4": "mixed"}[mode],
        "selected_categories": [],
        "selected_paths": [],
        "name_filters": [],
        "missing_paths": [],
    }

    if mode in {"2", "4"}:
        print_info("Available categories: " + ", ".join(CATEGORY_DESCRIPTIONS.keys()))
        raw = input("Enter comma-separated categories (example: python,typescript,web_ui): ").strip()
        categories = normalize_categories(parse_csv_input(raw))
        metadata["selected_categories"] = categories
        if categories:
            selected = [item for item in selected if item.category in categories]
        elif mode == "2":
            selected = []

    if mode in {"3", "4"}:
        raw = input(
            "Enter comma-separated file/folder paths or filenames (relative, absolute, or filename only): "
        ).strip()
        path_inputs = parse_csv_input(raw)
        selected, normalized_paths, missing_paths = filter_files_by_paths(
            selected,
            root,
            path_inputs,
            interactive=True,
            fancy=False,
        )
        metadata["selected_paths"] = normalized_paths
        metadata["missing_paths"] = missing_paths
        if missing_paths:
            print_warning("These paths did not match supported files: " + ", ".join(missing_paths))

    if mode == "4":
        raw = input("Optional file-name contains filters (comma-separated, example: auth,login,api) or press Enter to skip: ").strip()
        filters = parse_csv_input(raw)
        metadata["name_filters"] = filters
        if filters:
            selected = [item for item in selected if any(token.lower() in item.rel_path.as_posix().lower() for token in filters)]

    selected.sort(key=lambda item: item.rel_path.as_posix())
    print_info(f"Selected {len(selected)} file(s) out of {len(all_files)} supported file(s).")
    return selected, metadata


def interactive_select_files_questionary(all_files: Sequence[SourceFile], root: Path) -> Tuple[List[SourceFile], Dict[str, object]]:
    if not all_files:
        return [], {
            "selection_mode": "interactive_questionary",
            "selected_categories": [],
            "selected_paths": [],
            "name_filters": [],
        }

    if not QUESTIONARY_AVAILABLE:
        print_warning("questionary is not installed. Falling back to standard interactive mode.")
        return interactive_select_files(all_files, root)

    category_summary = summarize_by_category(all_files)
    folder_summary = summarize_top_folders(all_files)

    mode_label_to_value = {
        "All supported files": "all",
        "By category": "category",
        "By file/folder path": "path",
        "Mixed (category + path + file-name filter)": "mixed",
    }

    mode_label = questionary.select(
        "Choose selection mode",
        choices=list(mode_label_to_value.keys()),
    ).ask()

    if mode_label is None:
        return [], {
            "selection_mode": "interactive_questionary_cancelled",
            "selected_categories": [],
            "selected_paths": [],
            "name_filters": [],
        }

    mode = mode_label_to_value[mode_label]
    selected = list(all_files)
    metadata: Dict[str, object] = {
        "selection_mode": f"interactive_questionary_{mode}",
        "selected_categories": [],
        "selected_paths": [],
        "name_filters": [],
        "missing_paths": [],
    }

    if mode in {"category", "mixed"}:
        category_choice_labels = []
        for category in CATEGORY_DESCRIPTIONS:
            row = category_summary.get(category, {"files": 0, "lines": 0})
            category_choice_labels.append(
                f"{category} | files={row.get('files', 0)} lines={row.get('lines', 0)} | {CATEGORY_DESCRIPTIONS[category]}"
            )
        selected_category_labels = questionary.checkbox(
            "Select categories",
            choices=category_choice_labels,
        ).ask() or []
        categories = [label.split(" | ", 1)[0] for label in selected_category_labels]
        metadata["selected_categories"] = categories
        if categories:
            selected = [item for item in selected if item.category in categories]
        elif mode == "category":
            selected = []

    if mode in {"path", "mixed"}:
        folder_choice_labels = [
            f"{folder} | files={stats['files']} lines={stats['lines']}"
            for folder, stats in list(folder_summary.items())[:50]
        ]
        selected_folder_labels = questionary.checkbox(
            "Optional: select folders from the detected list",
            choices=folder_choice_labels,
        ).ask() or []
        folder_paths = [label.split(" | ", 1)[0] for label in selected_folder_labels]
        freeform_paths = questionary.text(
            "Optional: paste comma-separated file/folder paths or filenames (relative, absolute, or filename only). Leave empty to skip.",
            default="",
        ).ask() or ""
        path_inputs = folder_paths + parse_csv_input(freeform_paths)
        selected, normalized_paths, missing_paths = filter_files_by_paths(
            selected,
            root,
            path_inputs,
            interactive=True,
            fancy=True,
        )
        metadata["selected_paths"] = normalized_paths
        metadata["missing_paths"] = missing_paths
        if missing_paths:
            print_warning("These paths did not match supported files: " + ", ".join(missing_paths))

    if mode == "mixed":
        raw = questionary.text(
            "Optional file-name contains filters (comma-separated, e.g. auth,login,api)",
            default="",
        ).ask() or ""
        filters = parse_csv_input(raw)
        metadata["name_filters"] = filters
        if filters:
            selected = [item for item in selected if any(token.lower() in item.rel_path.as_posix().lower() for token in filters)]

    selected.sort(key=lambda item: item.rel_path.as_posix())
    print_info(f"Selected {len(selected)} file(s) out of {len(all_files)} supported file(s).")
    return selected, metadata


def non_interactive_select_files(
    all_files: Sequence[SourceFile],
    categories: Sequence[str],
    path_prefixes: Sequence[str],
    root: Path,
) -> Tuple[List[SourceFile], Dict[str, object]]:
    selected = list(all_files)
    if categories:
        normalized_categories = normalize_categories(categories)
        invalid = [item for item in categories if CATEGORY_ALIASES.get(item.strip().lower(), item.strip().lower()) not in CATEGORY_DESCRIPTIONS]
        if invalid:
            raise ValueError(f"Unsupported categories requested: {', '.join(invalid)}")
        selected = [item for item in selected if item.category in normalized_categories]
        categories = normalized_categories
    else:
        categories = []
    missing_paths: List[str] = []
    normalized_paths: List[str] = []
    if path_prefixes:
        selected, normalized_paths, missing_paths = filter_files_by_paths(
            selected,
            root,
            path_prefixes,
            interactive=False,
            fancy=False,
        )
    selected.sort(key=lambda item: item.rel_path.as_posix())
    return selected, {
        "selection_mode": "non_interactive",
        "selected_categories": list(categories),
        "selected_paths": normalized_paths,
        "name_filters": [],
        "missing_paths": missing_paths,
    }

# -----------------------------------------------------------------------------
# Chunking and packing
# -----------------------------------------------------------------------------
def bundle_header(chunk: FileChunk) -> str:
    return (
        f"\n# ===== BEGIN FILE: {chunk.rel_path.as_posix()} =====\n"
        f"# category : {chunk.category}\n"
        f"# chunk : {chunk.chunk_index}/{chunk.chunk_count}\n"
        f"# line_range : {chunk.start_line}-{chunk.end_line}\n"
        f"# total_lines : {chunk.total_file_lines}\n"
        f"# ===== CONTENT =====\n"
    )


def bundle_footer(chunk: FileChunk) -> str:
    return f"# ===== END FILE: {chunk.rel_path.as_posix()} (chunk {chunk.chunk_index}/{chunk.chunk_count}) =====\n"


def render_chunk_block(chunk: FileChunk) -> str:
    parts: List[str] = [bundle_header(chunk)]
    parts.extend(line + "\n" for line in chunk.lines)
    parts.append(bundle_footer(chunk))
    return "".join(parts)


def chunk_overhead_lines() -> int:
    dummy = FileChunk(
        rel_path=Path("dummy.py"),
        category="python",
        chunk_index=1,
        chunk_count=1,
        start_line=1,
        end_line=1,
        total_file_lines=1,
        lines=["x"],
    )
    return len(render_chunk_block(dummy).splitlines()) - 1


def split_into_chunks(files: Sequence[SourceFile], max_lines: int) -> Tuple[List[FileChunk], List[Dict[str, object]]]:
    skipped: List[Dict[str, object]] = []
    chunks: List[FileChunk] = []

    overhead = chunk_overhead_lines()
    content_limit = max_lines - overhead
    if content_limit <= 0:
        raise ValueError(f"--max-lines must be greater than bundle wrapper overhead ({overhead}).")

    for item in files:
        if item.line_count <= content_limit:
            chunks.append(
                FileChunk(
                    rel_path=item.rel_path,
                    category=item.category,
                    chunk_index=1,
                    chunk_count=1,
                    start_line=1 if item.line_count > 0 else 0,
                    end_line=item.line_count,
                    total_file_lines=item.line_count,
                    lines=item.lines,
                )
            )
            continue

        total_chunks = (item.line_count + content_limit - 1) // content_limit
        if total_chunks <= 0:
            skipped.append({"path": item.rel_path.as_posix(), "reason": "unable_to_chunk", "line_count": item.line_count})
            continue

        item_chunks: List[FileChunk] = []
        chunk_failed = False
        for index in range(total_chunks):
            start = index * content_limit
            end = min(start + content_limit, item.line_count)
            chunk_lines = item.lines[start:end]
            chunk = FileChunk(
                rel_path=item.rel_path,
                category=item.category,
                chunk_index=index + 1,
                chunk_count=total_chunks,
                start_line=start + 1,
                end_line=end,
                total_file_lines=item.line_count,
                lines=chunk_lines,
            )
            rendered_line_count = len(render_chunk_block(chunk).splitlines())
            if rendered_line_count > max_lines:
                skipped.append(
                    {
                        "path": item.rel_path.as_posix(),
                        "reason": "rendered_chunk_exceeds_limit",
                        "line_count": item.line_count,
                        "chunk_index": index + 1,
                        "chunk_count": total_chunks,
                        "rendered_line_count": rendered_line_count,
                    }
                )
                chunk_failed = True
                break
            item_chunks.append(chunk)
        if not chunk_failed:
            chunks.extend(item_chunks)
    return chunks, skipped


def pack_chunks(chunks: Sequence[FileChunk], max_lines: int) -> Tuple[List[List[FileChunk]], List[Dict[str, object]]]:
    bundles: List[List[FileChunk]] = []
    skipped: List[Dict[str, object]] = []
    current_bundle: List[FileChunk] = []
    current_lines = 0
    for chunk in chunks:
        rendered_block = render_chunk_block(chunk)
        rendered_line_count = len(rendered_block.splitlines())
        if rendered_line_count > max_lines:
            skipped.append(
                {
                    "path": chunk.rel_path.as_posix(),
                    "reason": "rendered_chunk_exceeds_limit",
                    "chunk_index": chunk.chunk_index,
                    "chunk_count": chunk.chunk_count,
                    "rendered_line_count": rendered_line_count,
                }
            )
            continue
        if current_bundle and (current_lines + rendered_line_count > max_lines):
            bundles.append(current_bundle)
            current_bundle = []
            current_lines = 0
        current_bundle.append(chunk)
        current_lines += rendered_line_count
    if current_bundle:
        bundles.append(current_bundle)
    return bundles, skipped

# -----------------------------------------------------------------------------
# Output writing
# -----------------------------------------------------------------------------
def sanitize_output_dir_name(root: Path) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    project_name = root.name.replace(" ", "_") or "project"
    return f"{DEFAULT_OUTPUT_DIR}_{project_name}_{timestamp}"


def write_bundles_and_manifest(
    root: Path,
    selected_files: Sequence[SourceFile],
    bundles: Sequence[Sequence[FileChunk]],
    output_dir: Path,
    max_lines: int,
    skipped_reasons: Dict[str, int],
    selection_metadata: Dict[str, object],
    skip_secret_files: bool,
    skipped_during_pack: Sequence[Dict[str, object]],
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)

    source_lookup: Dict[str, SourceFile] = {item.rel_path.as_posix(): item for item in selected_files}

    manifest: Dict[str, object] = {
        "tool": "universal_anything_to_text_exporter",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "project_root": str(root),
        "max_lines_per_bundle": max_lines,
        "bundle_count": len(bundles),
        "skip_secret_like_files": skip_secret_files,
        "selection": selection_metadata,
        "summary": {
            "selected_file_count": len(selected_files),
            "selected_total_lines": sum(item.line_count for item in selected_files),
            "selected_total_bytes": sum(item.size_bytes for item in selected_files),
            "skipped_counts": skipped_reasons,
            "skipped_during_pack_count": len(skipped_during_pack),
        },
        "skipped_during_pack": list(skipped_during_pack),
        "bundles": [],
    }

    for index, bundle in enumerate(bundles, start=1):
        bundle_name = f"bundle_{index:03d}.txt"
        bundle_path = output_dir / bundle_name
        text_parts: List[str] = []
        next_bundle_line = 1
        bundle_files: List[Dict[str, object]] = []

        for chunk in bundle:
            rel_path_str = chunk.rel_path.as_posix()
            source = source_lookup[rel_path_str]
            block_text = render_chunk_block(chunk)
            block_line_count = len(block_text.splitlines())
            bundle_start_line = next_bundle_line
            bundle_end_line = next_bundle_line + block_line_count - 1
            next_bundle_line = bundle_end_line + 1
            text_parts.append(block_text)
            bundle_files.append(
                {
                    "path": rel_path_str,
                    "category": chunk.category,
                    "size_bytes": source.size_bytes,
                    "sha256": source.sha256,
                    "total_file_lines": source.line_count,
                    "chunk_index": chunk.chunk_index,
                    "chunk_count": chunk.chunk_count,
                    "file_start_line": chunk.start_line,
                    "file_end_line": chunk.end_line,
                    "file_line_count": chunk.line_count,
                    "bundle_start_line": bundle_start_line,
                    "bundle_end_line": bundle_end_line,
                    "bundle_line_count": block_line_count,
                }
            )

        bundle_text = "".join(text_parts)
        bundle_path.write_text(bundle_text, encoding=DEFAULT_TEXT_ENCODING)
        manifest["bundles"].append(
            {
                "bundle": bundle_name,
                "rendered_total_lines": len(bundle_text.splitlines()),
                "files": bundle_files,
            }
        )

    summary_path = output_dir / "README_EXPORT.txt"
    summary_text = [
        "Universal Code To Text Exporter\n",
        "================================\n\n",
        f"Project root            : {root}\n",
        f"Created at (UTC)        : {manifest['created_at_utc']}\n",
        f"Bundles created         : {len(bundles)}\n",
        f"Selected files          : {len(selected_files)}\n",
        f"Selected total lines    : {manifest['summary']['selected_total_lines']}\n",
        f"Max lines per bundle    : {max_lines}\n",
        f"Secret-like files skipped: {skip_secret_files}\n",
        f"Skipped during pack     : {len(skipped_during_pack)}\n\n",
        "How to use\n",
        "----------\n",
        "1) Attach one or more bundle_XXX.txt files to your AI assistant.\n",
        "2) Attach MANIFEST.json as well so the assistant understands the mapping.\n",
        "3) Use bundles[].files[].bundle_start_line / bundle_end_line for exact positions inside each bundle file.\n",
        "4) Use bundles[].files[].file_start_line / file_end_line for the original source-file line ranges.\n",
    ]
    summary_path.write_text("".join(summary_text), encoding=DEFAULT_TEXT_ENCODING)

    manifest_path = output_dir / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding=DEFAULT_TEXT_ENCODING)
    return manifest_path


def detect_dependency_files(all_files: Sequence[SourceFile]) -> List[str]:
    interesting = {
        "pyproject.toml",
        "requirements.txt",
        "requirements-dev.txt",
        "requirements-ci.txt",
        "Pipfile",
        "package.json",
        "package-lock.json",
        "yarn.lock",
        "pnpm-lock.yaml",
        "tsconfig.json",
        "Podfile",
        "Gemfile",
        "Fastfile",
        "Makefile",
        "Dockerfile",
        "Jenkinsfile",
        "AndroidManifest.xml",
        "gradle.properties",
        "settings.gradle",
        "settings.gradle.kts",
        "build.gradle",
        "build.gradle.kts",
    }
    return sorted(item.rel_path.as_posix() for item in all_files if item.rel_path.name in interesting)


def detect_frameworks(all_files: Sequence[SourceFile]) -> List[str]:
    rel_paths = {item.rel_path.as_posix() for item in all_files}
    names = {item.rel_path.name for item in all_files}
    categories = {item.category for item in all_files}
    frameworks: List[str] = []
    if "python" in categories or "pyproject.toml" in names or "requirements.txt" in names:
        frameworks.append("Python")
    if "typescript" in categories or "tsconfig.json" in names:
        frameworks.append("TypeScript")
    if "javascript" in categories or "package.json" in names:
        frameworks.append("JavaScript / Node.js")
    if "java_kotlin" in categories or any(path.endswith((".gradle", ".gradle.kts")) for path in rel_paths):
        frameworks.append("Android / Java / Kotlin / Gradle")
    if "ios_apple" in categories or "Podfile" in names:
        frameworks.append("iOS / Apple")
    if "web_ui" in categories:
        frameworks.append("Web UI / Frontend")
    if "Dockerfile" in names:
        frameworks.append("Docker")
    if "Jenkinsfile" in names:
        frameworks.append("Jenkins / CI")
    return frameworks


def suggest_reading_order(root: Path, all_files: Sequence[SourceFile], selected_files: Sequence[SourceFile]) -> List[str]:
    existing_paths = {item.rel_path.as_posix() for item in all_files}
    preferred = [
        "README.md",
        "pyproject.toml",
        "requirements.txt",
        "requirements-dev.txt",
        "requirements-ci.txt",
        "package.json",
        "tsconfig.json",
        "Jenkinsfile",
        "AndroidManifest.xml",
        "build.gradle",
        "build.gradle.kts",
        "src",
        "app",
        "scripts",
        "tools",
    ]
    ordered: List[str] = []
    for candidate in preferred:
        if candidate in existing_paths or (root / candidate).exists():
            ordered.append(candidate)
    selected_top_folders = []
    for item in selected_files:
        parts = item.rel_path.parts
        if len(parts) > 1:
            folder = "/".join(parts[:2])
        elif len(parts) == 1:
            folder = parts[0]
        else:
            folder = "."
        selected_top_folders.append(folder)
    for folder in sorted(dict.fromkeys(selected_top_folders)):
        if folder not in ordered:
            ordered.append(folder)
    return ordered


def write_project_overview(
    root: Path,
    all_files: Sequence[SourceFile],
    selected_files: Sequence[SourceFile],
    output_dir: Path,
    selection_metadata: Dict[str, object],
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    category_summary = summarize_by_category(all_files)
    top_folders = summarize_top_folders(all_files, max_depth=2)
    dependency_files = detect_dependency_files(all_files)
    frameworks = detect_frameworks(all_files)
    reading_order = suggest_reading_order(root, all_files, selected_files)
    lines: List[str] = []
    lines.append("PROJECT OVERVIEW\n")
    lines.append("================\n\n")
    lines.append("1) Architecture summary\n")
    lines.append("-----------------------\n")
    lines.append(f"- Project root: {root}\n")
    lines.append(f"- Total supported files detected: {len(all_files)}\n")
    lines.append(f"- Files selected for export: {len(selected_files)}\n")
    lines.append(f"- Selection mode: {selection_metadata.get('selection_mode', 'unknown')}\n\n")
    lines.append("2) Major folders\n")
    lines.append("----------------\n")
    for folder, stats in list(top_folders.items())[:20]:
        lines.append(f"- {folder}: files={stats['files']}, lines={stats['lines']}\n")
    lines.append("\n")
    lines.append("3) Detected frameworks / stack hints\n")
    lines.append("------------------------------------\n")
    if frameworks:
        for item in frameworks:
            lines.append(f"- {item}\n")
    else:
        lines.append("- No obvious framework hints detected.\n")
    lines.append("\n")
    lines.append("4) Dependency / configuration files\n")
    lines.append("-----------------------------------\n")
    if dependency_files:
        for item in dependency_files:
            lines.append(f"- {item}\n")
    else:
        lines.append("- No major dependency files detected.\n")
    lines.append("\n")
    lines.append("5) Codebase composition by category\n")
    lines.append("----------------------------------\n")
    for category in CATEGORY_DESCRIPTIONS:
        row = category_summary.get(category, {"files": 0, "lines": 0, "bytes": 0})
        lines.append(f"- {category}: files={row['files']}, lines={row['lines']}, bytes={row['bytes']} ({CATEGORY_DESCRIPTIONS[category]})\n")
    lines.append("\n")
    lines.append("6) Suggested reading order for Copilot / AI assistant\n")
    lines.append("-----------------------------------------------------\n")
    if reading_order:
        for idx, item in enumerate(reading_order, start=1):
            lines.append(f"{idx}. {item}\n")
    lines.append("\n")
    lines.append("7) Notes\n")
    lines.append("--------\n")
    lines.append("- Use this file together with MANIFEST.json and the bundle_XXX.txt files.\n")
    lines.append("- Start from the suggested reading order, then use MANIFEST.json to locate exact file chunks.\n")
    lines.append("- If asking targeted questions, attach only the most relevant bundles first.\n")
    overview_path = output_dir / "PROJECT_OVERVIEW.txt"
    overview_path.write_text("".join(lines), encoding=DEFAULT_TEXT_ENCODING)
    return overview_path

# -----------------------------------------------------------------------------
# Main CLI flow
# -----------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Export supported source files into AI-friendly text bundles with a manifest."
    )
    parser.add_argument(
        "project_root",
        nargs="?",
        default=".",
        help="Project root to scan. Defaults to the current working directory.",
    )
    parser.add_argument(
        "--max-lines",
        type=int,
        default=DEFAULT_MAX_LINES,
        help=f"Maximum rendered lines per output bundle (default: {DEFAULT_MAX_LINES}).",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Optional output directory. Defaults to a timestamped folder under the current working directory.",
    )
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help="Run without prompts. Optionally combine with --categories and/or --paths.",
    )
    parser.add_argument(
        "--categories",
        nargs="*",
        default=[],
        help="Categories to include in non-interactive mode. Example: --categories python typescript web_ui",
    )
    parser.add_argument(
        "--paths",
        nargs="*",
        default=[],
        help="Relative paths, absolute paths, or filenames to include in non-interactive mode.",
    )
    parser.add_argument(
        "--include-secret-files",
        action="store_true",
        help="Include files that look like secrets (.env, *.pem, *.key, keystores, etc.). Use with care.",
    )
    parser.add_argument(
        "--fancy-ui",
        action="store_true",
        help="Use checkbox-style interactive selection with questionary (if installed).",
    )
    parser.add_argument(
        "--project-overview",
        action="store_true",
        help="Generate PROJECT_OVERVIEW.txt alongside the manifest and bundles.",
    )
    return parser


def validate_root(path_str: str) -> Path:
    root = Path(path_str).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"Project root does not exist: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"Project root is not a directory: {root}")
    return root


def run_export(args: argparse.Namespace) -> int:
    root = validate_root(args.project_root)
    if args.max_lines <= 0:
        raise ValueError("--max-lines must be greater than zero")

    if args.fancy_ui and not QUESTIONARY_AVAILABLE:
        print_warning(
            "Fancy UI requires 'questionary'. Standard mode will be used instead.\n"
            f"If you want fancy UI, run:\n    {INSTALL_HINT}"
        )

    skip_secret_files = not args.include_secret_files
    print_info(f"Scanning project: {root}")
    all_files, skipped_reasons = scan_supported_files(root, skip_secret_files=skip_secret_files)
    if not all_files:
        print_warning("No supported files were found after applying .gitignore and default exclusions.")
        return 0
    print_info(f"Detected {len(all_files)} supported text file(s).")
    if args.non_interactive:
        selected_files, selection_metadata = non_interactive_select_files(
            all_files,
            categories=args.categories,
            path_prefixes=args.paths,
            root=root,
        )
    else:
        if args.fancy_ui and QUESTIONARY_AVAILABLE:
            selected_files, selection_metadata = interactive_select_files_questionary(all_files, root)
        else:
            selected_files, selection_metadata = interactive_select_files(all_files, root)
    if not selected_files:
        print_warning("No files selected. Nothing was exported.")
        return 0

    chunks, skipped_during_split = split_into_chunks(selected_files, max_lines=args.max_lines)
    bundles, skipped_during_pack = pack_chunks(chunks, max_lines=args.max_lines)
    skipped_during_processing = skipped_during_split + skipped_during_pack

    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else Path.cwd() / sanitize_output_dir_name(root)
    manifest_path = write_bundles_and_manifest(
        root=root,
        selected_files=selected_files,
        bundles=bundles,
        output_dir=output_dir,
        max_lines=args.max_lines,
        skipped_reasons=skipped_reasons,
        selection_metadata=selection_metadata,
        skip_secret_files=skip_secret_files,
        skipped_during_pack=skipped_during_processing,
    )

    overview_path = None
    if args.project_overview:
        overview_path = write_project_overview(
            root=root,
            all_files=all_files,
            selected_files=selected_files,
            output_dir=output_dir,
            selection_metadata=selection_metadata,
        )

    print_success("\nExport complete.")
    print_success(f"Output directory : {output_dir}")
    print_success(f"Manifest         : {manifest_path}")
    if overview_path is not None:
        print_success(f"Project overview : {overview_path}")
    print_success(f"Bundles created  : {len(bundles)}")
    print_success(f"Files exported   : {len(selected_files)}")
    if skipped_during_processing:
        print_warning("Files/chunks skipped during processing:")
        for item in skipped_during_processing:
            print_warning("  - " + json.dumps(item, ensure_ascii=False))
    missing_paths = selection_metadata.get("missing_paths", []) if isinstance(selection_metadata, dict) else []
    if missing_paths:
        print_warning("Paths that did not match supported files:")
        for value in missing_paths:
            print_warning(f"  - {value}")
    return 0


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return run_export(args)
    except KeyboardInterrupt:
        print_error("Interrupted by user.")
        return 130
    except Exception as exc:
        print_error(f"Error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
