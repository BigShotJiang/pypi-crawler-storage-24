# Publishing Guide

This guide explains how to publish `anything-to-text` to PyPI.

## Prerequisites

Install required tools:

```bash
pip install build twine
```

Create accounts:
- [PyPI](https://pypi.org/account/register/) - for production
- [TestPyPI](https://test.pypi.org/account/register/) - for testing

## Step 1: Update Version Number

Edit `pyproject.toml` and update the version:

```toml
[project]
name = "anything-to-text"
version = "1.0.0"  # <-- Update this
```

Follow [Semantic Versioning](https://semver.org/):
- `1.0.0` → `1.0.1` (bug fix)
- `1.0.0` → `1.1.0` (new feature)
- `1.0.0` → `2.0.0` (breaking change)

## Step 2: Build the Package

```bash
# Clean previous builds
rm -rf dist/ build/ *.egg-info

# Build source distribution and wheel
python -m build
```

This creates:
```
dist/
├── anything_to_text-1.0.0-py3-none-any.whl  # Wheel (pre-built)
└── anything-to-text-1.0.0.tar.gz            # Source distribution
```

## Step 3: Test Locally (Recommended)

```bash
# Create a test virtual environment
python -m venv test_env
source test_env/bin/activate  # Linux/Mac
# test_env\Scripts\activate   # Windows

# Install from the wheel
pip install dist/anything_to_text-1.0.0-py3-none-any.whl

# Test the commands
anything-to-text --version
att --version

# Test with a real project
anything-to-text . --non-interactive --categories python

# Clean up
deactivate
rm -rf test_env
```

## Step 4: Upload to TestPyPI (Recommended First)

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*
```

You'll be prompted for credentials:
- Username: `__token__`
- Password: Your TestPyPI API token (create at https://test.pypi.org/manage/account/token/)

Test installation from TestPyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ anything-to-text
```

## Step 5: Upload to PyPI

Once testing is complete:

```bash
twine upload dist/*
```

For automated uploads, use an API token:
1. Go to https://pypi.org/manage/account/token/
2. Create a new token
3. Use it:

```bash
twine upload -u __token__ -p pypi-XXXX... dist/*
```

Or configure `~/.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-YOUR-API-TOKEN-HERE

[testpypi]
username = __token__
password = pypi-YOUR-TESTPYPI-API-TOKEN-HERE
```

Then simply:
```bash
twine upload dist/*
```

## Quick Publishing Script

Create `publish.sh`:

```bash
#!/bin/bash
set -e

echo "Cleaning..."
rm -rf dist/ build/ *.egg-info src/*.egg-info

echo "Building..."
python -m build

echo "Uploading to PyPI..."
twine upload dist/*

echo "Done! Package published to PyPI"
```

Run with:
```bash
chmod +x publish.sh
./publish.sh
```

## GitHub Actions (Automated Publishing)

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      
      - name: Install build tools
        run: pip install build twine
      
      - name: Build package
        run: python -m build
      
      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          password: ${{ secrets.PYPI_API_TOKEN }}
```

Add your PyPI API token as a GitHub secret:
1. Go to repository Settings → Secrets → Actions
2. Add `PYPI_API_TOKEN` with your PyPI token

## Verify Installation

After publishing, verify:

```bash
# Wait 5-10 minutes for PyPI to update
pip install anything-to-text
anything-to-text --version
att --version
```

## Troubleshooting

### Package name already exists
Choose a different name in `pyproject.toml`.

### Version already exists
Update version number. PyPI doesn't allow re-uploading same version.

### Long description not rendering
Make sure `readme = "README.md"` is set and README uses valid Markdown.

### Missing dependencies
Ensure all dependencies are listed in `pyproject.toml` under `dependencies`.
