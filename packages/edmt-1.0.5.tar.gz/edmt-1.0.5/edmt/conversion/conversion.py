from typing import Optional
import uuid
import pandas as pd
import geopandas as gpd
import numpy as np
from shapely import make_valid
from edmt.contrib.utils import clean_vars
from typing import Iterable, Tuple, List, Union
from matplotlib import pyplot as plt, colors


ArrayLike = Union[Iterable[float], np.ndarray]

# Time unit conversion factors relative to seconds
time_chart: dict[str, float] = {
    "microseconds": 0.000001,
    "microsecond": 0.000001,
    "µs": 0.000001,
    "milliseconds": 0.001,
    "millisecond": 0.001,
    "ms": 0.001,
    "seconds": 1.0,
    "second": 1.0,
    "s": 1.0,
    "minutes": 60.0,
    "minute": 60.0,
    "min": 60.0,
    "m": 60.0,
    "hours": 3600.0,
    "hour": 3600.0,
    "hr": 3600.0,
    "h": 3600.0,
    "days": 86400.0,
    "day": 86400.0,
    "d": 86400.0,
    "weeks": 604800.0,
    "week": 604800.0,
    "wk": 604800.0,
    "w": 604800.0,
    "months": 2629800.0,
    "month": 2629800.0,
    "years": 31557600.0,
    "year": 31557600.0,
    "yr": 31557600.0,
    "y": 31557600.0,
}

# Inverse of time_chart for reverse lookup
time_chart_inverse: dict[str, float] = {
    key: 1.0 / value for key, value in time_chart.items()
}

# Speed unit conversion factors relative to km/h
speed_chart: dict[str, float] = {
    "km/h": 1.0,
    "m/s": 3.6,
    "mph": 1.609344,
    "knot": 1.852,
}

# Inverse speed chart for faster reverse conversions
speed_chart_inverse: dict[str, float] = {
    "km/h": 1.0,
    "m/s": 0.277777778,
    "mph": 0.621371192,
    "knot": 0.539956803,
}

# Mapping full unit names to standard symbols
UNIT_SYMBOL = {
    "meter": "m", "meters": "m",
    "kilometer": "km", "kilometers": "km",
    "centimeter": "cm", "centimeters": "cm",
    "millimeter": "mm", "millimeters": "mm",
    "mile": "mi", "miles": "mi",
    "yard": "yd", "yards": "yd",
    "foot": "ft", "feet": "ft",
    "inch": "in", "inches": "in",
}

# Metric prefix powers of ten
METRIC_CONVERSION = {
    "mm": -3,
    "cm": -2,
    "dm": -1,
    "m": 0,
    "dam": 1,
    "hm": 2,
    "km": 3,
}

# Distance unit to meter conversion factors
distance_chart = {
    "mm": 0.001,
    "cm": 0.01,
    "dm": 0.1,
    "m": 1.0,
    "dam": 10.0,
    "hm": 100.0,
    "km": 1000.0,
    "in": 0.0254,
    "ft": 0.3048,
    "yd": 0.9144,
    "mi": 1609.344,
}

temp_units: tuple[str, ...] = ("C", "F", "K")

temp_unit_aliases: dict[str, str] = {
    "c": "C",
    "°c": "C",
    "celsius": "C",

    "f": "F",
    "°f": "F",
    "fahrenheit": "F",

    "k": "K",
    "°k": "K",
    "kelvin": "K",
}



def sdf_to_gdf(sdf, crs=None):
    """
    Converts a spatial DataFrame to a GeoDataFrame with optional CRS assignment.

    Args:
        sdf (pd.DataFrame): Input spatial DataFrame containing geometry column.
        crs (str or int, optional): Coordinate Reference System. Defaults to EPSG:4326.

    Returns:
        gpd.GeoDataFrame: A cleaned GeoDataFrame with valid geometries.

    Raises:
        ValueError: If input is not a DataFrame or is empty.

    """
    if not isinstance(sdf, pd.DataFrame):
        raise ValueError("Input must be a pandas DataFrame.")
    if sdf.empty:
        raise ValueError("DataFrame is empty.")

    params = clean_vars(
        shape="SHAPE",
        geometry="geometry",
        columns=["Shape__Area", "Shape__Length", "SHAPE"],
        crs=crs
    )

    tmp = sdf.copy()
    tmp = tmp[~tmp[params["shape"]].isna()]

    gdf = gpd.GeoDataFrame(tmp, geometry=tmp[params["shape"]], crs=params["crs"])
    gdf['geometry'] = gdf.geometry.apply(make_valid)
    gdf.drop(columns=params.get("columns"), errors='ignore', inplace=True)

    return gdf

def _is_valid_uuid(val) -> bool:
    if pd.isna(val):
        return False
    try:
        uuid.UUID(str(val))
        return True
    except Exception:
        return False


def _find_uuid_like_column(
    df: pd.DataFrame,
    contains: tuple[str, ...] = ("uuid",),
) -> Optional[str]:
    """
    Return the first column name that looks like it contains a uuid marker.
    E.g. 'uuid', 'UUID', 'user_uuid', 'myUuid', etc.
    """
    lowered = {c.lower(): c for c in df.columns}
    for lc, original in lowered.items():
        if any(k in lc for k in contains):
            return original
    return None


def generate_uuid(
    df: pd.DataFrame,
    *,
    force: bool = False,
    index: bool = False,
    uuid_col: str = "uuid",
    detect_uuid_cols: bool = True,
    detect_contains: tuple[str, ...] = ("uuid",),
) -> pd.DataFrame:
    """
    Ensure a pandas DataFrame contains a column of valid UUIDs, creating or repairing as needed.

    This function adds a new UUID column or validates/repairs an existing one. It can optionally 
    detect existing UUID-like columns to avoid duplication and control column placement.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame to process.
    force : bool, optional
        If True, always generate new UUIDs—even if a valid UUID column already exists 
        (default: False).
    index : bool, optional
        If True, place the UUID column at the beginning of the DataFrame; otherwise, 
        place it at the end (default: False).
    uuid_col : str, optional
        Name of the target UUID column (default: "uuid").
    detect_uuid_cols : bool, optional
        If True and `force=False`, scan for existing columns that appear to contain UUIDs 
        (based on name and content) to avoid redundant generation (default: True).
    detect_contains : tuple of str, optional
        Substrings used to identify potential UUID columns by name when `detect_uuid_cols=True` 
        (default: ("uuid",)).

    Returns
    -------
    pd.DataFrame
        A copy of the input DataFrame with a valid UUID column named `uuid_col`.

    Raises
    ------
    ValueError
        If input is not a DataFrame or if the DataFrame is empty.

    Notes
    -----
    - A value is considered a valid UUID if it is a string matching the standard UUID format 
      (e.g., "f47ac10b-58cc-4372-a567-0e02b2c3d479").
    - When `force=False` and a UUID-like column is detected (by name and content), the function 
      reuses it but repairs any invalid entries by replacing them with new UUIDs.
    - The output DataFrame is always a copy; the original is not modified.
    - Column ordering is explicitly controlled: UUID column is moved to front if `index=True`, 
      otherwise to the back.

    Examples
    --------
    >>> df = pd.DataFrame({"name": ["Alice", "Bob"]})
    >>> df_with_uuid = generate_uuid(df)
    >>> "uuid" in df_with_uuid.columns
    True

    >>> df_existing = pd.DataFrame({"uuid": ["invalid", "7af3ea7c-5a14-48c2-a3c2-b014488c0216"], "val": [1, 2]})
    >>> fixed = generate_uuid(df_existing)
    # First entry replaced with valid UUID; second preserved
    """
    if not isinstance(df, pd.DataFrame):
        raise ValueError("Input must be a pandas DataFrame.")
    if df.empty:
        raise ValueError("DataFrame is empty.")

    out = df.copy()

    existing_uuid_like = None
    if detect_uuid_cols:
        existing_uuid_like = _find_uuid_like_column(out, contains=detect_contains)

    should_create = force or (existing_uuid_like is None and uuid_col not in out.columns)

    if should_create:
        out[uuid_col] = [str(uuid.uuid4()) for _ in range(len(out))]
    else:
        if uuid_col in out.columns:
            out[uuid_col] = [
                str(v) if _is_valid_uuid(v) else str(uuid.uuid4())
                for v in out[uuid_col]
            ]

    if uuid_col in out.columns:
        out[uuid_col] = out[uuid_col].astype(str)

        if index:
            cols = [uuid_col] + [c for c in out.columns if c != uuid_col]
            out = out.loc[:, cols]
        else:
            cols = [c for c in out.columns if c != uuid_col] + [uuid_col]
            out = out.loc[:, cols]

    return out


def generate_cmap(
    data: ArrayLike,
    num_divisions: int,
    cmap: str = "viridis",
) -> Tuple[List[str], List[str]]:
    """
    Generate range labels and corresponding hex colors from a colormap.

    Parameters
    ----------
    data : array-like
        Numeric data used to determine the value range.
    num_divisions : int
        Number of intervals to divide the data range into.
    cmap : str, default="viridis"
        Name of the matplotlib colormap.

    Returns
    -------
    tuple[list[str], list[str]]
        labels :
            Range labels formatted as "min - max".
        colors :
            Hexadecimal color codes corresponding to each range.

    Raises
    ------
    ValueError
        If num_divisions is less than 1 or data is empty.
    """

    data_arr = np.asarray(list(data), dtype=float)

    if data_arr.size == 0:
        raise ValueError("Input data is empty.")

    if num_divisions < 1:
        raise ValueError("num_divisions must be >= 1.")

    min_val = float(np.nanmin(data_arr))
    max_val = float(np.nanmax(data_arr))

    cmap = plt.get_cmap(cmap)

    if np.isclose(min_val, max_val):
        return (
            [f"{min_val:.2f}"],
            [colors.to_hex(cmap(0.5))]
        )

    bins = np.linspace(min_val, max_val, num_divisions + 1)

    labels = [
        f"{bins[i]:.2f} - {bins[i + 1]:.2f}"
        for i in range(num_divisions)
    ]

    color_positions = (
        np.linspace(0, 1, num_divisions)
        if num_divisions > 1
        else np.array([0.5])
    )

    hex_colors = [
        colors.to_hex(cmap(pos))
        for pos in color_positions
    ]

    return labels, hex_colors


def get_utm_epsg(longitude=None):
    """
    Generates UTM EPSG code based on longitude.

    Args:
        longitude (float): Longitude value to determine UTM zone.

    Returns:
        str: EPSG code as a string.

    Raises:
        KeyError: If longitude is not provided.

    """
    if longitude is None:
        raise KeyError("Select column with longitude values")

    zone_number = int((longitude + 180) / 6) + 1
    hemisphere = '6' if longitude >= 0 else '7'
    return f"32{hemisphere}{zone_number:02d}"


def convert_time(value: float, unit_from: str, unit_to: str) -> float:
    """
    Converts a given time value between different units.

    Args:
        time_value (float): The numerical value of the time.
        unit_from (str): The original unit of time.
        unit_to (str): The target unit to convert to.

    Returns:
        float: The converted time value rounded to 3 decimal places.

    Raises:
        ValueError: If units are unsupported or value is invalid.

    """
    if not isinstance(value, (int, float)) or value < 0:
        raise ValueError("'value' must be a non-negative number.")

    unit_from = unit_from.lower().strip()
    unit_to = unit_to.lower().strip()

    unit_from = {
        "us": "microseconds", 
        "μs": "microseconds", 
        "microsec": "microseconds", 
        "usec": "microseconds"
        }.get(unit_from, unit_from)
    unit_to = {
        "us": "microseconds", 
        "μs": "microseconds", 
        "microsec": "microseconds", 
        "usec": "microseconds"
        }.get(unit_to, unit_to)

    if unit_from not in time_chart:
        raise ValueError(f"Invalid 'unit_from': {unit_from}. Supported units: {', '.join(time_chart.keys())}")
    if unit_to not in time_chart:
        raise ValueError(f"Invalid 'unit_to': {unit_to}. Supported units: {', '.join(time_chart.keys())}")

    seconds = value * time_chart[unit_from]
    converted = seconds / time_chart[unit_to]

    return round(converted, 3)


def convert_speed(speed: float, unit_from: str, unit_to: str) -> float:
    """
    Converts speed between different units.

    Args:
        speed (float): Input speed value.
        unit_from (str): Original unit.
        unit_to (str): Target unit.

    Returns:
        float: Converted speed value.

    Raises:
        ValueError: If unit is unsupported.

    """
    if unit_to not in speed_chart or unit_from not in speed_chart_inverse:
        msg = (
            f"Incorrect 'from_type' or 'to_type' value: {unit_from!r}, {unit_to!r}\n"
            f"Valid values are: {', '.join(speed_chart_inverse)}"
        )
        raise ValueError(msg)
    return round(speed * speed_chart[unit_from] * speed_chart_inverse[unit_to], 3)


def convert_distance(value: float, unit_from: str, unit_to: str) -> float:
    """
    Converts distance values between metric and imperial units.

    Args:
        value (float): Input distance value.
        from_type (str): Original unit.
        to_type (str): Target unit.

    Returns:
        float: Converted distance value.

    Raises:
        ValueError: If unit is unsupported.

    """
    from_sanitized = unit_from.lower().strip("s")
    to_sanitized = unit_to.lower().strip("s")

    from_sanitized = UNIT_SYMBOL.get(from_sanitized, from_sanitized)
    to_sanitized = UNIT_SYMBOL.get(to_sanitized, to_sanitized)

    valid_units = set(distance_chart.keys())
    if from_sanitized not in valid_units:
        raise ValueError(f"Invalid 'from_type': {unit_from!r}. Valid units: {', '.join(valid_units)}")
    if to_sanitized not in valid_units:
        raise ValueError(f"Invalid 'to_type': {unit_to!r}. Valid units: {', '.join(valid_units)}")
    if from_sanitized in METRIC_CONVERSION and to_sanitized in METRIC_CONVERSION:
        from_exp = METRIC_CONVERSION[from_sanitized]
        to_exp = METRIC_CONVERSION[to_sanitized]
        exponent_diff = from_exp - to_exp
        return round(value * pow(10, exponent_diff), 3)

    value_in_meters = value * distance_chart[from_sanitized]
    converted = value_in_meters / distance_chart[to_sanitized]

    return round(converted, 3)


def _norm_temp_unit(unit: str) -> str:
    if not isinstance(unit, str) or not unit.strip():
        raise ValueError("Temperature unit must be a non-empty string.")
    u = unit.strip().lower()
    return temp_unit_aliases.get(u, unit.strip().upper())


def _to_celsius(value: float, unit_from: str) -> float:
    u = _norm_temp_unit(unit_from)
    if u == "C":
        return float(value)
    if u == "F":
        return (float(value) - 32.0) * (5.0 / 9.0)
    if u == "K":
        if float(value) < 0.0:
            raise ValueError("Kelvin cannot be below 0.")
        return float(value) - 273.15
    raise ValueError(f"Unsupported temperature unit: {unit_from!r}")


def _from_celsius(c: float, unit_to: str) -> float:
    u = _norm_temp_unit(unit_to)
    if u == "C":
        return float(c)
    if u == "F":
        return float(c) * (9.0 / 5.0) + 32.0
    if u == "K":
        k = float(c) + 273.15
        if k < 0.0:
            raise ValueError("Resulting Kelvin cannot be below 0.")
        return k
    raise ValueError(f"Unsupported temperature unit: {unit_to!r}")


def convert_temperature(value: float, unit_from: str, unit_to: str) -> float:
    """
    Converts temperature between different scales.

    Args:
        value (float): Input temperature value.
        unit_from (str): Original unit. Supported: C, F, K (also °C, °F, °K).
        unit_to (str): Target unit. Supported: C, F, K (also °C, °F, °K).

    Returns:
        float: Converted temperature value (rounded to 3 decimals).

    Raises:
        ValueError: If unit is unsupported or Kelvin is invalid (< 0).

    """
    u_from = _norm_temp_unit(unit_from)
    u_to = _norm_temp_unit(unit_to)

    if u_from not in temp_units or u_to not in temp_units:
        msg = (
            f"Incorrect 'unit_from' or 'unit_to' value: {unit_from!r}, {unit_to!r}\n"
            f"Valid values are: {', '.join(temp_units)}"
        )
        raise ValueError(msg)

    c = _to_celsius(float(value), u_from)
    out = _from_celsius(c, u_to)
    return round(out, 3)


def format_temperature(value: float, unit: str, decimals: int = 1, symbol: bool = True) -> str:
    """
    Formats a temperature value with unit, e.g. '23.5 °C' or '296.6 K'.

    Args:
        value (float): Temperature value.
        unit (str): Unit to display (C, F, K).
        decimals (int): Decimal places.
        symbol (bool): If True, uses °C/°F, and K without degree symbol.

    Returns:
        str: Formatted temperature string.
    """
    u = _norm_temp_unit(unit)
    if u not in temp_units:
        raise ValueError(f"Unsupported temperature unit: {unit!r}. Valid: {', '.join(temp_units)}")

    val_str = f"{float(value):.{int(decimals)}f}"

    if not symbol:
        return f"{val_str} {u}"

    if u in ("C", "F"):
        return f"{val_str} °{u}"
    return f"{val_str} K"





