<template>
    <li>
        <a id="tabitemRequestsAnchorTab" href="#starterAppTab" data-toggle="tab">
            <i class="jli jl-ic-apps"></i>
            <span class="jl-localization">Starter App</span>
        </a>
    </li>
</template>
