<template>
  <div class="project-details">
    <!-- Header Section -->
    <div class="header-card">
      <div class="header-content">
        <div class="title-row">
          <h1 class="project-title">{{ companyName }}</h1>
          <span class="app-badge">Embedded App</span>
        </div>
        <p class="tenant-info">Tenant ID: <span>{{ tenantId || 'Not Set' }}</span></p>
      </div>
      <button @click="refreshData" class="refresh-btn" :disabled="isLoading">
        <svg v-if="!isLoading" class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
        <span v-if="isLoading" class="spinner"></span>
        {{ isLoading ? 'Loading...' : 'Refresh' }}
      </button>
    </div>

    <!-- Dynamic Content Section -->
    <div class="content-section">
      <h2 class="section-title">Project Information</h2>
      
      <!-- Loading State -->
      <div v-if="isLoading" class="loading-state">
        <div class="spinner-large"></div>
        <p>Loading project details...</p>
      </div>

      <!-- Error State -->
      <div v-else-if="error" class="error-state">
        <svg class="error-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p>{{ error }}</p>
        <button @click="refreshData" class="retry-btn">Try Again</button>
      </div>

      <!-- Data Display -->
      <div v-else-if="companyData && Object.keys(companyData).length > 0" class="data-grid">
        <div v-for="(value, key) in companyData" :key="key" class="data-item">
          <span class="data-label">{{ formatLabel(key) }}</span>
          <span class="data-value">{{ formatValue(value) }}</span>
        </div>
      </div>

      <!-- Empty State -->
      <div v-else class="empty-state">
        <svg class="empty-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
        </svg>
        <p>No project data available</p>
        <p class="empty-subtitle">Start by configuring your project settings</p>
      </div>
    </div>

    <!-- Additional Info Section (if needed) -->
    <div v-if="additionalInfo && additionalInfo.length > 0" class="info-section">
      <h2 class="section-title">Additional Information</h2>
      <div class="info-list">
        <div v-for="(item, index) in additionalInfo" :key="index" class="info-item">
          <div class="info-icon">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div class="info-content">
            <h3>{{ item.title }}</h3>
            <p>{{ item.description }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { STORAGE_KEY } from '@/utils/const';
import { addSuccessMessage, addErrorMessage } from '@/utils/notify';
import { getCompany } from '@/services/company.service';

// Reactive state
const companyName = ref('{{ project_name }}');
const tenantId = ref('');
const isLoading = ref(false);
const error = ref<string | null>(null);
const companyData = ref<Record<string, any>>({});
const additionalInfo = ref<Array<{ title: string; description: string }>>([]);

// Load tenant ID and project data on mount
onMounted(() => {
  const storedTenantId = sessionStorage.getItem(STORAGE_KEY.TENANT_ID);
  if (storedTenantId) {
    tenantId.value = storedTenantId;
  }
  loadProjectData();
});

// Load project data
const loadProjectData = async () => {
  isLoading.value = true;
  error.value = null;

  try {
    // Fetch company data from API
    const result = await getCompany();
    
    if (result.success && Array.isArray(result.additionalData) && result.additionalData.length > 0) {
      // Find the company matching the current tenant ID
      const currentCompany = result.additionalData.find(
        (company: any) => company.TenantId === tenantId.value
      ) || result.additionalData[0];

      // Set company name
      companyName.value = currentCompany.CompanyName || 'Unknown Company';

      // Prepare company data for display (excluding sensitive fields)
      companyData.value = {
        companyName: currentCompany.CompanyName,
        industryName: currentCompany.IndustryName,
        hasSubscription: currentCompany.hasSubscription ? 'Yes' : 'No',
        guidId: currentCompany.GuidId,
        ...(currentCompany.LogoUrl && { logoUrl: currentCompany.LogoUrl })
      };

      // Set additional info
      additionalInfo.value = [
        {
          title: 'Getting Started',
          description: 'Configure your project settings and start building your application.'
        },
        {
          title: 'Documentation',
          description: 'Visit our documentation to learn more about available features.'
        }
      ];
    } else {
      companyName.value = 'No Company Found';
      error.value = 'No company data available for this tenant';
    }

  } catch (err: any) {
    error.value = err.message || 'Failed to load project data';
    companyName.value = 'Error Loading';
    console.error('Error loading project data:', err);
  } finally {
    isLoading.value = false;
  }
};

// Refresh data
const refreshData = async () => {
  try {
    await loadProjectData();
    addSuccessMessage('Data refreshed successfully');
  } catch (err) {
    addErrorMessage('Failed to refresh data');
  }
};

// Format label for display
const formatLabel = (key: string): string => {
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, str => str.toUpperCase())
    .trim();
};

// Format value for display
const formatValue = (value: any): string => {
  if (value === null || value === undefined) return 'N/A';
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
};
</script>

<style scoped>
.project-details {
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px;
}

/* Header Card */
.header-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
}

.header-content {
  flex: 1;
}

.title-row {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.project-title {
  font-size: 28px;
  font-weight: 700;
  color: #1a202c;
  margin: 0;
}

.app-badge {
  display: inline-flex;
  align-items: center;
  padding: 4px 12px;
  background: #3182ce;
  color: white;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.tenant-info {
  font-size: 14px;
  color: #718096;
  margin: 0;
}

.tenant-info span {
  font-weight: 600;
  color: #2d3748;
}

.refresh-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  background: #3182ce;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.refresh-btn:hover:not(:disabled) {
  background: #2c5282;
  transform: translateY(-1px);
}

.refresh-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.refresh-btn .icon {
  width: 18px;
  height: 18px;
}

/* Content Section */
.content-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.section-title {
  font-size: 20px;
  font-weight: 600;
  color: #1a202c;
  margin: 0 0 20px 0;
  padding-bottom: 12px;
  border-bottom: 2px solid #e2e8f0;
}

/* Loading State */
.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  color: #718096;
}

.spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: white;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}

.spinner-large {
  width: 48px;
  height: 48px;
  border: 4px solid #e2e8f0;
  border-top-color: #3182ce;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin-bottom: 16px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* Error State */
.error-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  color: #e53e3e;
}

.error-icon {
  width: 48px;
  height: 48px;
  margin-bottom: 16px;
}

.retry-btn {
  margin-top: 16px;
  padding: 8px 16px;
  background: #e53e3e;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.2s;
}

.retry-btn:hover {
  background: #c53030;
}

/* Data Grid */
.data-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}

.data-item {
  display: flex;
  flex-direction: column;
  padding: 16px;
  background: #f7fafc;
  border-radius: 8px;
  border-left: 4px solid #3182ce;
  transition: all 0.2s;
}

.data-item:hover {
  background: #edf2f7;
  transform: translateX(4px);
}

.data-label {
  font-size: 12px;
  font-weight: 600;
  color: #718096;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 6px;
}

.data-value {
  font-size: 16px;
  font-weight: 500;
  color: #2d3748;
  word-break: break-word;
}

/* Empty State */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  color: #718096;
}

.empty-icon {
  width: 64px;
  height: 64px;
  margin-bottom: 16px;
  color: #cbd5e0;
}

.empty-state p {
  margin: 8px 0;
  font-size: 16px;
  font-weight: 500;
}

.empty-subtitle {
  font-size: 14px !important;
  font-weight: 400 !important;
  color: #a0aec0 !important;
}

/* Info Section */
.info-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.info-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.info-item {
  display: flex;
  gap: 16px;
  padding: 16px;
  background: #f7fafc;
  border-radius: 8px;
  transition: background 0.2s;
}

.info-item:hover {
  background: #edf2f7;
}

.info-icon {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #3182ce;
  border-radius: 8px;
  color: white;
}

.info-icon svg {
  width: 24px;
  height: 24px;
}

.info-content h3 {
  font-size: 16px;
  font-weight: 600;
  color: #1a202c;
  margin: 0 0 6px 0;
}

.info-content p {
  font-size: 14px;
  color: #718096;
  margin: 0;
  line-height: 1.5;
}

/* Responsive Design */
@media (max-width: 768px) {
  .project-details {
    padding: 16px;
  }

  .header-card {
    flex-direction: column;
    align-items: flex-start;
  }

  .refresh-btn {
    width: 100%;
    justify-content: center;
  }

  .title-row {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }

  .project-title {
    font-size: 24px;
  }

  .data-grid {
    grid-template-columns: 1fr;
  }
}
</style>
