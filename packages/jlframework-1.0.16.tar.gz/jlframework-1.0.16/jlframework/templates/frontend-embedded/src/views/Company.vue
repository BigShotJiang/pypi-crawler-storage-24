<template>
    <div class="company-container">
        <h2>Tenant Selection</h2>

        <div v-if="error" class="error-message">
            <p>{{ error }}</p>
        </div>

        <BaseSelect v-model="selected" :options="options" label="Company Name" labelKey="CompanyName"
            valueKey="TenantId" :loading="isLoading" placeholder="Select a company..." />

        <div class="actions">
            <BaseButton :disabled="!selected" label="Submit" @onClick="submitTenantList" @onKeyPress="submitTenantList"
                width="100px" classes="jl-button-green" />
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import BaseButton from '../components/BaseButton.vue';
import BaseSelect from '../components/BaseSelect.vue';
import { getCompany } from '../services/company.service';
import { addErrorMessage, addSuccessMessage } from '../utils/notify';
import { STORAGE_KEY } from '../utils/const';

/**
 * Company Selection View Component
 * Allows users to select and switch between different tenant companies
 */

interface CompanyOption {
    GuidId: string;
    TenantId: string;
    CompanyName: string;
    LogoUrl: string;
    IndustryName: string;
    [key: string]: any;
}

interface CompanyApiResponse {
    success: boolean;
    additionalData: CompanyOption[];
    message?: string;
}

// Reactive state
const selected = ref<CompanyOption | null>(null);
const options = ref<CompanyOption[]>([]);
const isLoading = ref(false);
const error = ref<string | null>(null);

// Router instance
const router = useRouter();

// Form submission handler
const submitTenantList = async (): Promise<void> => {
    if (!selected.value?.TenantId) {
        addErrorMessage('Please select a company first');
        return;
    }
    // Check if hasSubscription property exists and is false
    if (selected.value.hasSubscription === false) {
        addErrorMessage('Selected company does not have an active subscription');
        return;
    }
    try {
        // Store the selected tenant ID in sessionStorage
        sessionStorage.setItem(STORAGE_KEY.TENANT_ID, selected.value.TenantId);
        addSuccessMessage('Company selected successfully!');
        
        // Navigate to the project details page
        await router.push('/project');
    } catch (err: any) {
        const errorMessage = err.message || 'Failed to select company';
        addErrorMessage(errorMessage);
        console.error('Company selection error:', err);
    }
};

// Company loading function
const loadCompanies = async (): Promise<void> => {
    isLoading.value = true;
    error.value = null;

    try {
        const result: CompanyApiResponse = await getCompany();

        if (result.success && Array.isArray(result.additionalData)) {
            options.value = result.additionalData;

            // Auto-submit if only one tenant is available
            if (result.additionalData.length === 1) {
                if (!result.additionalData[0]?.hasSubscription) {
                    throw new Error('TenantId does not have an active subscription');
                }
                else {
                    const tenantId = result.additionalData[0].TenantId;
                    if (tenantId) {
                        sessionStorage.setItem(STORAGE_KEY.TENANT_ID, tenantId);
                        addSuccessMessage('Company selected automatically!');
                        await router.push('/project');
                    }
                }
            }
            // If multiple tenants, user must select one manually (no pre-selection)
        } else {
            throw new Error(result.message || 'Invalid response format');
        }
    } catch (err: any) {
        const errorMessage = err.message || 'Failed to load companies';
        error.value = errorMessage;
        addErrorMessage(errorMessage);
        console.error('Error loading companies:', err);
    } finally {
        isLoading.value = false;
    }
};

// Component lifecycle
onMounted(() => {
    loadCompanies();
});
</script>

<style scoped>
.company-container {
    max-width: 500px;
    margin: 60px auto 0;
    padding: 24px;
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.company-container h2 {
    margin: 0 0 24px 0;
    font-size: 24px;
    font-weight: 600;
    color: #1f2937;
    text-align: center;
}

.error-message {
    margin-bottom: 16px;
    padding: 12px;
    background-color: #fee2e2;
    border: 1px solid #fecaca;
    border-radius: 4px;
    color: #dc2626;
}

.error-message p {
    margin: 0;
    font-size: 14px;
}

.actions {
    display: flex;
    justify-content: flex-start;
    margin-top: 16px;
}

/* Loading state styling */
.company-container:has(.loading) {
    opacity: 0.7;
    pointer-events: none;
}

/* Responsive design */
@media (max-width: 576px) {
    .company-container {
        margin: 20px auto 0;
        padding: 16px;
        max-width: calc(100vw - 32px);
    }

    .company-container h2 {
        font-size: 20px;
    }
}
</style>