<template>
    <div class="not-found">
        <div class="not-found__content">
            <h1 class="not-found__title">404</h1>
            <p class="not-found__message">
                The page you're looking for doesn't exist.
            </p>
            <router-link to="/" class="not-found__link">
                Go back home
            </router-link>
        </div>
    </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.not-found {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 50vh;
    padding: 2rem;
}

.not-found__content {
    text-align: center;
    max-width: 400px;
}

.not-found__title {
    font-size: 4rem;
    font-weight: bold;
    color: #374151;
    margin-bottom: 1rem;
}

.not-found__message {
    font-size: 1.125rem;
    color: #6b7280;
    margin-bottom: 2rem;
}

.not-found__link {
    display: inline-block;
    padding: 0.75rem 1.5rem;
    background-color: #3b82f6;
    color: white;
    text-decoration: none;
    border-radius: 0.375rem;
    font-weight: 500;
    transition: background-color 0.2s ease;
}

.not-found__link:hover {
    background-color: #2563eb;
}
</style>