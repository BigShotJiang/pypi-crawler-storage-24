export const oidcSettings = {
    "authority": import.meta.env.VITE_BASE_IDENTITY,
    "client_id": import.meta.env.VITE_BASE_CLIENT_ID,
    "response_type": "code",
    "scope": "openid profile offline_access email",
};