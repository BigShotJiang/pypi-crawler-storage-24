export const STORAGE_KEY = {
    ACCESS_TOKEN: '__jat',
    TENANT_ID: 'temporary.TenantId',
};

export const PRIVATE_ROUTE_PATHS = {
    COMPANY: '/company',
    PROJECT_DETAILS: '/project',
    CALLBACK: '/auth/callback',
};

export const AUTH_NAME = 'MAIN';
