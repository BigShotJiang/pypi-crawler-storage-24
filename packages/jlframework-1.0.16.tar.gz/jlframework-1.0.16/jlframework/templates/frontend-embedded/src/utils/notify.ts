import toastr from 'toastr';

toastr.options = {
    closeButton: true,
    debug: false,
    newestOnTop: true,
    progressBar: false,
    positionClass: "toast-top-right",
    preventDuplicates: true,
    onclick: undefined,
    showDuration: 300,
    hideDuration: 1000,
    timeOut: 4000,
    extendedTimeOut: 1000,
    showEasing: "swing",
    hideEasing: "linear",
    showMethod: "slideDown",
    hideMethod: "slideUp",
    tapToDismiss: true,
    toastClass: "toast",
    iconClasses: {
        error: 'toast-error',
        info: 'toast-info',
        success: 'toast-success',
        warning: 'toast-warning'
    },
    titleClass: "toast-title",
    messageClass: "toast-message",
    target: "body"
}

function addNotificationMessage(message: string, title?: string) {
    toastr.info(message, title);
}
function addWarningMessage(message: string, title?: string) {
    toastr.warning(message, title);
}
function addSuccessMessage(message: string, title?: string) {
    toastr.success(message, title);
}
function addErrorMessage(message: string, title?: string) {
    toastr.error(message, title);
}
function clearMessage() {
    toastr.clear();
}

export {
    addErrorMessage,
    addNotificationMessage,
    addSuccessMessage,
    addWarningMessage,
    clearMessage
}
