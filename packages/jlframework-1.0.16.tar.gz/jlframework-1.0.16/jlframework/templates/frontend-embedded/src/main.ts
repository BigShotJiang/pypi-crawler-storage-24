import { createApp } from 'vue';
import App from './App.vue';
import getRouter from './router';
import idsrvAuth from '@/idsrvAuth';
import 'toastr/build/toastr.min.css';
import './assets/main.css';

idsrvAuth.startup().then((ok: boolean) => {
    if (ok) {
        const app = createApp(App);

        const router = getRouter();
        idsrvAuth.useRouter(router);
        app.use(router);

        app.mount('#app');
    }
});