import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { getTenantId } from './tenant.service';

interface ApiConfig extends AxiosRequestConfig {
  headers?: Record<string, string>;
  params?: Record<string, any>;
  timeout?: number;
}

interface ApiError {
  message: string;
  status?: number;
  code?: string;
  data?: any;
}

const axiosInstance: AxiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosInstance.interceptors.request.use(
  (config) => {
    try {
      const tenantId = getTenantId();
      if (tenantId && config.headers) {
        config.headers['x-jl-tenant-id'] = tenantId;
      }

      return config;
    } catch (error) {
      return Promise.reject(error);
    }
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => {
    return response;
  },
  (error) => {
    const apiError: ApiError = {
      message: error.response?.data?.message || error.message || 'An unexpected error occurred',
      status: error.response?.status,
      code: error.response?.data?.code || error.code,
      data: error.response?.data
    };

    return Promise.reject(apiError);
  }
);

const api = {
  async get<T = any>(url: string, config: ApiConfig = {}): Promise<T> {
    try {
      const response = await axiosInstance.get<T>(url, config);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  async post<T = any>(url: string, data: any = {}, config: ApiConfig = {}): Promise<T> {
    try {
      const response = await axiosInstance.post<T>(url, data, config);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  async put<T = any>(url: string, data: any = {}, config: ApiConfig = {}): Promise<T> {
    try {
      const response = await axiosInstance.put<T>(url, data, config);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  async patch<T = any>(url: string, data: any = {}, config: ApiConfig = {}): Promise<T> {
    try {
      const response = await axiosInstance.patch<T>(url, data, config);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  async delete<T = any>(url: string, config: ApiConfig = {}): Promise<T> {
    try {
      const response = await axiosInstance.delete<T>(url, config);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
};

export default api;
