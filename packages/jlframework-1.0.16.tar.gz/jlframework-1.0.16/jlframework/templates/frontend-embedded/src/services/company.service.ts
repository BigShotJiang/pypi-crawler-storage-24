import axios from 'axios';
import idsrvAuth from "../idsrvAuth";

const BASE_URL = import.meta.env.VITE_API_URL;

export const getCompany = async () => {
  try {
    let currentUserId = idsrvAuth.userProfile?.sub;
    
    // If not found in idsrvAuth, check sessionStorage for OIDC user
    if (!currentUserId) {
      try {
        // Look for any key starting with 'oidc.user:'
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i);
          if (key && key.startsWith('oidc.user:')) {
            const userDataStr = sessionStorage.getItem(key);
            if (userDataStr) {
              const userData = JSON.parse(userDataStr);
              currentUserId = userData.profile?.sub;
              if (currentUserId) {
                break;
              }
            }
          }
        }
      } catch (error) {
        console.warn('Error parsing OIDC session data:', error);
      }
    }
    
    if (!currentUserId) {
      throw new Error('User not authenticated');
    }

    const response = await axios.get(`${BASE_URL}/api/v1/company/user-tenants`, {
      params: {
        current_user: currentUserId
      }
    });

    // Extract the data array from the response
    const responseData = response.data?.data || response.data;
    
    return {
      success: true,
      additionalData: Array.isArray(responseData) ? responseData : []
    };
  } catch (error: any) {
    console.error('Error fetching companies:', error);
    throw error.response?.data || error;
  }
};
