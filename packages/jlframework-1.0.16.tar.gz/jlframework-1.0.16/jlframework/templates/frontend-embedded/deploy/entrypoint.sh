#!/bin/sh
# Replace placeholders with environment variables
echo "Replacing environment variables in .env file..."
for file in $(find /usr/share/nginx/html -type f -name "*.js"); do
  sed -i "s|VITE_BASE_CLIENT_ID_PLACEHOLDER|${VITE_BASE_CLIENT_ID}|g" $file
  sed -i "s|VITE_BASE_IDENTITY_PLACEHOLDER|${VITE_BASE_IDENTITY}|g" $file
  sed -i "s|VITE_API_URL_PLACEHOLDER|${VITE_API_URL}|g" $file
done
echo "Replacing environment variables in .env file done"
# Start the server
exec "$@"