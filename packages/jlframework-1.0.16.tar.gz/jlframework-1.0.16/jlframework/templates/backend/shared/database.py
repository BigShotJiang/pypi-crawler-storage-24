"""Database configuration and session management.

This module initializes the database connection using configuration
loaded from Azure App Configuration and provides session management utilities.
"""

import logging
from typing import Generator, Optional

from fastapi import Request
from sqlalchemy import create_engine, event
from sqlalchemy.engine import URL
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import QueuePool

from configs.azure_config import configurations as AppConfig

# Set up logging
logger = logging.getLogger(__name__)

# Database URL configuration with error handling
try:
    db_config = AppConfig.db_settings
    if not db_config:
        raise ValueError("Database configuration not found")

    required_keys = ["UID", "PWD", "SERVER", "DATABASE"]
    missing_keys = [key for key in required_keys if not db_config.get(key)]
    if missing_keys:
        raise ValueError(
            f"Missing database configuration keys: {missing_keys}")

    # Extract server and port if specified
    server_parts = db_config.get("SERVER", "").split(",")
    server_host = server_parts[0]
    server_port = int(server_parts[1]) if len(server_parts) > 1 else None

    SQLALCHEMY_DATABASE_URL = URL.create(
        "mssql+pyodbc",
        username=db_config.get("UID"),
        password=db_config.get("PWD"),
        host=server_host,
        port=server_port,
        database=db_config.get("DATABASE"),
        query={
            "driver": "ODBC Driver 17 for SQL Server",
            "TrustServerCertificate": "yes",
        },
    )

    logger.info("Database URL configured for server: %s", server_host)

except Exception as e:
    logger.error("Failed to configure database URL: %s", e)
    raise


# Database engine with connection pooling and error handling
try:
    engine = create_engine(
        SQLALCHEMY_DATABASE_URL,
        poolclass=QueuePool,
        pool_size=20,
        max_overflow=10,
        pool_pre_ping=True,  # Enable connection health checks
        pool_recycle=3600,  # Recycle connections every hour
        echo=False,  # Set to True for SQL query logging in development
    )

    # Add connection event listeners for better monitoring
    @event.listens_for(engine, "connect")
    def set_connection_settings(dbapi_connection, connection_record):
        """Set connection-specific settings for SQL Server."""
        logger.debug("New database connection established")

    @event.listens_for(engine, "checkout")
    def receive_checkout(dbapi_connection, connection_record, connection_proxy):
        """Log connection checkout events."""
        logger.debug("Database connection checked out from pool")

    logger.info("Database engine configured successfully")

except Exception as e:
    logger.error("Failed to create database engine: %s", e)
    raise


# Session factory with proper configuration
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    expire_on_commit=False,  # Prevent issues with accessing attributes after commit
)


def get_db_session() -> Session:
    """Create a new database session for the current request.

    Returns:
        New SQLAlchemy session instance.

    Raises:
        SQLAlchemyError: If session creation fails.
    """
    try:
        session = SessionLocal()
        logger.debug("New database session created")
        return session
    except SQLAlchemyError as e:
        logger.error("Failed to create database session: %s", e)
        raise


def close_db_session(session: Optional[Session]) -> None:
    """Close the provided database session safely.

    Args:
        session: SQLAlchemy session to close.
    """
    if session:
        try:
            session.close()
            logger.debug("Database session closed")
        except Exception as e:
            logger.error("Error while closing DB session: %s", e)


# FastAPI dependency for database session
def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that provides a database session.

    Automatically handles session creation and cleanup.
    This is the recommended way to get database sessions in FastAPI endpoints.

    Yields:
        Database session for the request.

    Raises:
        SQLAlchemyError: If database operations fail.
    """
    db = SessionLocal()
    try:
        logger.debug("Database session created for request")
        yield db
    except SQLAlchemyError as e:
        logger.error("Database session error: %s", e)
        db.rollback()
        raise
    except Exception as e:
        logger.error("Unexpected error in database session: %s", e)
        db.rollback()
        raise
    finally:
        db.close()
        logger.debug("Database session closed for request")


def get_request_db(request: Request) -> Optional[Session]:
    """Get database session from request state.

    Equivalent to Flask's g.db pattern.

    Args:
        request: FastAPI request object.

    Returns:
        Database session from request state, or None if not found.
    """
    return getattr(request.state, "db", None)


async def database_middleware(request: Request, call_next):
    """Database middleware that handles session lifecycle for each request.

    This middleware creates a database session at the start of each request
    and ensures it's properly closed at the end, equivalent to Flask's
    @app.before_request and @app.teardown_request decorators.

    Args:
        request: FastAPI request object.
        call_next: Next middleware/handler in the chain.

    Returns:
        Response from the next handler.
    """
    # Before request - create database session
    try:
        db_session = get_db_session()
        request.state.db = db_session
        logger.debug("Database session attached to request")

        # Process the request
        response = await call_next(request)
        return response

    except SQLAlchemyError as e:
        logger.error("Database error during request processing: %s", e)
        if hasattr(request.state, "db"):
            request.state.db.rollback()
        raise
    except Exception as e:
        logger.error("Unexpected error during request processing: %s", e)
        if hasattr(request.state, "db"):
            request.state.db.rollback()
        raise
    finally:
        # After request - close database session
        if hasattr(request.state, "db"):
            close_db_session(request.state.db)
            logger.debug("Database session cleaned up for request")
