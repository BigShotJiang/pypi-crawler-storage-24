"""API route aggregation for the application."""

from fastapi import APIRouter

from domains.company.routers import router as company_router

# Create main API router
api_router = APIRouter(prefix="/api/v1")

# Include domain routers
api_router.include_router(company_router, prefix="/company", tags=["Company"])
