"""Templates for jlframework."""
