import axios from 'axios';
import idsrvAuth from "../idsrvAuth";

const BASE_URL = import.meta.env.VITE_API_BASE_URL || import.meta.env.VITE_API_URL;

export const getCompany = async () => {
  try {
    const currentUserId = idsrvAuth.userProfile?.sub;
    
    if (!currentUserId) {
      throw new Error('User not authenticated');
    }
    const response = await axios.get(`${BASE_URL}/api/v1/company/user-tenants`, {
      params: {
        current_user: currentUserId
      }
    });

    // Extract the data array from the response
    const responseData = response.data?.data || response.data;
    
    return {
      success: true,
      additionalData: Array.isArray(responseData) ? responseData : []
    };
  } catch (error: any) {
    console.error('Error fetching companies:', error);
    throw error.response?.data || error;
  }
};
