"""Version information for jlframework."""

__version__ = "1.0.16"
