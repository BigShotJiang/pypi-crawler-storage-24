"""Utility functions and decorators for jlframework."""

from functools import wraps
from typing import Callable
from warnings import warn


def deprecated(message: str) -> Callable:
    """Decorator to mark functions as deprecated with a custom warning message.

    This decorator issues a DeprecationWarning when the decorated function is called,
    helping developers identify and migrate away from legacy functionality.

    Args:
        message (str): Custom deprecation message to display.

    Returns:
        Callable: Decorator function that wraps the target function.

    Example:
        @deprecated("This function will be removed in v2.0. Use new_function() instead.")
        async def old_function():
            pass
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            warn(message, DeprecationWarning, stacklevel=2)
            return await func(*args, **kwargs)
        return wrapper
    return decorator
