"""Core utilities module for jlframework."""
