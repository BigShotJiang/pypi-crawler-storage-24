"""Middleware components for FastAPI applications.

This module provides middleware for multi-tenant access control, ensuring
that all API requests include a valid tenant identifier for proper data isolation.
"""

import logging
from typing import Callable, Optional

from fastapi import Request, status
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)

# Constants for tenant validation
TENANT_HEADER_NAME = "x-jl-tenant-id"  # HTTP header name for tenant ID
API_PREFIX = "/api"  # URL prefix for API endpoints requiring tenant validation
# Paths that bypass tenant validation
IGNORE_PATHS = ["/api/v1/company/user-tenants"]


async def restrict_access_middleware(
    request: Request, call_next: Callable
) -> JSONResponse:
    """FastAPI middleware for multi-tenant access control.

    This middleware enforces tenant-based access control by:
    1. Validating that API requests include the 'x-jl-tenant-id' header
    2. Checking the tenant ID format is valid (UUID)
    3. Storing the tenant ID in request.state for downstream use
    4. Bypassing validation for CORS preflight and whitelisted paths

    The middleware ensures data isolation in multi-tenant applications by
    requiring every API request to specify which tenant's data to access.

    Args:
        request (Request): FastAPI Request object containing headers and path info.
        call_next (Callable): Next middleware or route handler in the chain.

    Returns:
        JSONResponse: Either the response from the next handler, or an error response:
            - 400 Bad Request: If tenant ID format is invalid
            - 401 Unauthorized: If tenant ID header is missing

    Example:
        ```python
        # In main.py
        from jlframework import restrict_access_middleware

        app.middleware("http")(restrict_access_middleware)

        # In route handler
        @router.get("/items")
        async def get_items(request: Request):
            tenant_id = request.state.tenant_id  # Available after middleware
            # ... fetch tenant-specific data
        ```

    Note:
        - CORS preflight (OPTIONS) requests bypass validation
        - Paths in IGNORE_PATHS bypass validation (e.g., user-tenants endpoint)
        - Non-API paths (not starting with /api) bypass validation
        - Tenant ID is trimmed of whitespace before storage
    """
    # Handle CORS preflight requests
    if request.method == "OPTIONS":
        logger.debug("CORS preflight request, bypassing tenant validation")
        response = await call_next(request)
        return response

    # Bypass tenant validation for ignored paths
    if request.url.path in IGNORE_PATHS:
        logger.debug("Ignoring tenant validation for path: %s",
                     request.url.path)
        response = await call_next(request)
        return response

    # Check if this is an API endpoint that requires tenant validation
    if request.url.path.startswith(API_PREFIX):
        tenant_id = request.headers.get(TENANT_HEADER_NAME)

        if tenant_id:
            # Validate tenant ID format (basic validation)
            if not _is_valid_tenant_id(tenant_id):
                logger.warning(
                    "Invalid tenant ID format: %s from IP: %s",
                    tenant_id,
                    _get_client_ip(request),
                )
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content={
                        "error": "Bad Request",
                        "message": "Invalid tenant ID format.",
                    },
                )

            # Store tenant_id in request state (equivalent to Flask's g)
            request.state.tenant_id = tenant_id.strip()

            logger.debug("Tenant ID validated: %s", tenant_id)
            response = await call_next(request)
            return response
        else:
            logger.warning(
                "Tenant ID not provided in API request from IP: %s, Path: %s",
                _get_client_ip(request),
                request.url.path,
            )
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={
                    "error": "Unauthorized",
                    "message": f"Tenant ID is required. Please provide '{TENANT_HEADER_NAME}' header.",
                },
            )

    # Allow request to continue for non-API endpoints
    logger.debug(
        "Non-API request, bypassing tenant validation: %s", request.url.path)
    response = await call_next(request)
    return response


def get_tenant_id(request: Request) -> Optional[str]:
    """Retrieve tenant ID from request state.

    This is a convenience function to safely extract the tenant ID that was
    stored by the restrict_access_middleware.

    Args:
        request (Request): FastAPI Request object with state populated by middleware.

    Returns:
        Optional[str]: Tenant ID string if present in request.state, None otherwise.

    Example:
        ```python
        @router.get("/items")
        async def get_items(request: Request):
            tenant_id = get_tenant_id(request)
            if tenant_id:
                # Process with tenant context
                pass
        ```

    Note:
        Returns None if:
        - Middleware hasn't run yet
        - Request bypassed middleware (non-API path)
        - Tenant ID wasn't provided in headers
    """
    tenant_id = getattr(request.state, "tenant_id", None)
    if tenant_id:
        logger.debug("Retrieved tenant ID from request state: %s", tenant_id)
    return tenant_id


def _is_valid_tenant_id(tenant_id: str) -> bool:
    """Validate tenant ID format.

    Basic validation to ensure tenant ID meets minimum requirements.

    Args:
        tenant_id: Tenant identifier to validate.

    Returns:
        True if tenant ID format is valid, False otherwise.
    """
    if not tenant_id or not isinstance(tenant_id, str):
        return False

    # Basic validation rules
    tenant_id = tenant_id.strip()
    if len(tenant_id) < 1 or len(tenant_id) > 100:
        return False

    # Check for obviously invalid characters
    invalid_chars = ["\n", "\r", "\t", "\0"]
    if any(char in tenant_id for char in invalid_chars):
        return False

    return True


def _get_client_ip(request: Request) -> str:
    """Get client IP address from request.

    Attempts to get the real client IP considering proxy headers.

    Args:
        request: FastAPI Request object.

    Returns:
        Client IP address.
    """
    # Check for forwarded IP headers (common in load balancer setups)
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        # X-Forwarded-For can contain multiple IPs, take the first one
        return forwarded_for.split(",")[0].strip()

    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip.strip()

    # Fallback to direct client IP
    if hasattr(request, "client") and request.client:
        return request.client.host

    return "unknown"
