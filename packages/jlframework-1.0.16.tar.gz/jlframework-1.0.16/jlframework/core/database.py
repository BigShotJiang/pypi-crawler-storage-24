"""Database utilities for jlframework."""

import logging
from typing import Callable, Generator, Optional

from fastapi import Request
from sqlalchemy import create_engine, event
from sqlalchemy.engine import URL
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import QueuePool

# Set up logging
logger = logging.getLogger(__name__)

# Global variables for engine and session
engine = None
SessionLocal = None


def initialize_database(
    database_url: str = None,
    pool_size: int = 20,
    max_overflow: int = 10,
    pool_recycle: int = 3600,
    echo: bool = False,
):
    """Initialize database engine and session factory.

    Args:
        database_url: Database connection URL
        pool_size: Connection pool size
        max_overflow: Maximum overflow connections
        pool_recycle: Recycle connections after this many seconds
        echo: Enable SQL query logging
    """
    global engine, SessionLocal

    if not database_url:
        logger.warning(
            "No database URL provided. Database features will be disabled.")
        return

    try:
        engine = create_engine(
            database_url,
            poolclass=QueuePool,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_pre_ping=True,
            pool_recycle=pool_recycle,
            echo=echo,
        )

        # Add connection event listeners
        @event.listens_for(engine, "connect")
        def set_connection_settings(dbapi_connection, connection_record):
            """Set connection-specific settings."""
            logger.debug("New database connection established")

        @event.listens_for(engine, "checkout")
        def receive_checkout(dbapi_connection, connection_record, connection_proxy):
            """Log connection checkout events."""
            logger.debug("Database connection checked out from pool")

        SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=engine,
            expire_on_commit=False,
        )

        logger.info("Database engine configured successfully")

    except Exception as e:
        logger.error("Failed to create database engine: %s", e)
        raise


def get_db_session() -> Session:
    """Create a new database session.

    Returns:
        New SQLAlchemy session instance.

    Raises:
        SQLAlchemyError: If session creation fails.
    """
    if not SessionLocal:
        raise RuntimeError(
            "Database not initialized. Call initialize_database() first.")

    try:
        session = SessionLocal()
        logger.debug("New database session created")
        return session
    except SQLAlchemyError as e:
        logger.error("Failed to create database session: %s", e)
        raise


def close_db_session(session: Optional[Session]) -> None:
    """Close the provided database session safely.

    Args:
        session: SQLAlchemy session to close.
    """
    if session:
        try:
            session.close()
            logger.debug("Database session closed")
        except Exception as e:
            logger.error("Error while closing DB session: %s", e)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that provides a database session.

    Automatically handles session creation and cleanup.

    Yields:
        Database session for the request.

    Raises:
        SQLAlchemyError: If database operations fail.
    """
    if not SessionLocal:
        raise RuntimeError(
            "Database not initialized. Call initialize_database() first.")

    db = SessionLocal()
    try:
        logger.debug("Database session created for request")
        yield db
    except SQLAlchemyError as e:
        logger.error("Database session error: %s", e)
        db.rollback()
        raise
    except Exception as e:
        logger.error("Unexpected error in database session: %s", e)
        db.rollback()
        raise
    finally:
        db.close()
        logger.debug("Database session closed for request")


def get_request_db(request: Request) -> Optional[Session]:
    """Get database session from request state.

    Args:
        request: FastAPI request object.

    Returns:
        Database session from request state, or None if not found.
    """
    return getattr(request.state, "db", None)


async def database_middleware(request: Request, call_next):
    """Database middleware that handles session lifecycle for each request.

    This middleware automatically attaches a database session to each request,
    handles errors with automatic rollback, and ensures proper cleanup.

    The middleware is designed to work with module-level database initialization
    where SessionLocal is created during application startup.

    Args:
        request (Request): FastAPI request object containing request state.
        call_next (Callable): Next middleware or route handler in the chain.

    Returns:
        Response: Response from the next handler in the chain.

    Raises:
        SQLAlchemyError: If a database error occurs during request processing.
        Exception: If any unexpected error occurs during request processing.

    Example:
        ```python
        # In main.py
        from shared.database import database_middleware

        app.middleware("http")(database_middleware)
        ```

    Note:
        - Session is automatically rolled back on errors
        - Session is always closed in the finally block
        - If SessionLocal is not initialized, requests proceed without DB session
    """
    if not SessionLocal:
        # If database is not configured, continue without DB session
        logger.warning(
            "Database not initialized, proceeding without DB session")
        response = await call_next(request)
        return response

    try:
        # Create new database session for this request
        db_session = get_db_session()
        request.state.db = db_session
        logger.debug("Database session attached to request")

        # Process the request
        response = await call_next(request)
        return response

    except SQLAlchemyError as e:
        # Handle database-specific errors
        logger.error("Database error during request processing: %s", e)
        if hasattr(request.state, "db"):
            request.state.db.rollback()
            logger.debug("Database session rolled back due to error")
        raise

    except Exception as e:
        # Handle any other unexpected errors
        logger.error("Unexpected error during request processing: %s", e)
        if hasattr(request.state, "db"):
            request.state.db.rollback()
            logger.debug(
                "Database session rolled back due to unexpected error")
        raise

    finally:
        # Always clean up the session
        if hasattr(request.state, "db"):
            close_db_session(request.state.db)
            logger.debug("Database session cleaned up for request")
