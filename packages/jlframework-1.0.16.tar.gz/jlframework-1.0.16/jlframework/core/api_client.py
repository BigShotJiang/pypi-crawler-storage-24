"""API client for making HTTP requests with retry logic."""

import asyncio
import logging
from enum import Enum
from functools import lru_cache, wraps
from threading import local
from typing import Any, Dict, Optional

import aiohttp
from aiohttp import ClientResponse

logger = logging.getLogger(__name__)


class RequestType(Enum):
    """Enumeration for HTTP request methods.

    This enum defines the supported HTTP methods for API operations,
    providing type safety and consistency across the application.
    """

    GET = "GET"  # Retrieve data from the server
    POST = "POST"  # Create new resources
    PUT = "PUT"  # Update existing resources (full update)
    DELETE = "DELETE"  # Remove resources
    PATCH = "PATCH"  # Partial update of existing resources


class ApiError(Exception):
    """Custom exception class for API-related errors.

    This exception is raised when API operations fail, providing
    detailed error information including HTTP status codes when available.

    Attributes:
        message (str): Human-readable error message.
        status_code (Optional[int]): HTTP status code if available.
    """

    def __init__(self, message: str, status_code: Optional[int] = None) -> None:
        """Initialize the ApiError with message and optional status code.

        Args:
            message (str): Error message describing what went wrong.
            status_code (Optional[int]): HTTP status code if available.
        """
        self.message: str = message
        self.status_code: Optional[int] = status_code
        super().__init__(self.message)


def retry_with_backoff(retries: int = 3, backoff_in_seconds: int = 1):
    """Decorator that implements retry logic with exponential backoff.

    This decorator retries failed API operations with increasing
    delay between attempts. It catches transient network errors and connection
    issues that might be resolved with a retry.

    Args:
        retries (int): Maximum number of retry attempts. Defaults to 3.
        backoff_in_seconds (int): Base delay in seconds, doubled with each retry. Defaults to 1.

    Returns:
        Callable: Decorator function that wraps the target method.

    Example:
        @retry_with_backoff(retries=5, backoff_in_seconds=2)
        async def api_call(self):
            # This will retry up to 5 times with delays: 2s, 4s, 8s, 16s, 32s
            pass
    """

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            max_retries = retries
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except (
                    aiohttp.ClientError,
                    aiohttp.ServerTimeoutError,
                    aiohttp.ConnectionTimeoutError,
                    ConnectionResetError,
                    asyncio.TimeoutError,
                ) as e:
                    if attempt == max_retries - 1:
                        raise ApiError(f"Max retries reached: {str(e)}")
                    wait_time = backoff_in_seconds * 2**attempt
                    logging.warning(
                        f"Attempt {attempt + 1} failed, retrying in {wait_time}s: {str(e)}"
                    )
                    await asyncio.sleep(wait_time)
            return None

        return wrapper

    return decorator


class MainSubSysApiManager:
    """Main SubSystem API Manager for handling HTTP operations.

    This class provides a centralized interface for making HTTP requests to the
    JL Main SubSystem API. It includes retry logic, connection management,
    and support for both tenant-specific and tenantless operations.

    The class implements thread-local instance caching to ensure efficient resource
    usage while maintaining thread safety in concurrent environments.

    Attributes:
        tenant_id (str): Tenant identifier for API operations.
        header (str): Header key name for authentication.
        url (str): Base URL for the Main SubSystem API.
        header_key (str): Authentication header value.
        client (Optional[aiohttp.ClientSession]): HTTP client session.
        _closed (bool): Flag indicating if the client has been closed.

    Class Attributes:
        _thread_local (threading.local): Thread-local storage for instances.
    """

    _thread_local = local()

    def __init__(self, tenant_id: str, base_url: str, header_key: str) -> None:
        """Initialize the MainSubSysApiManager with tenant and configuration details.

        Args:
            tenant_id (str): Tenant identifier for multi-tenancy support.
            base_url (str): Base URL for the Main SubSystem API.
            header_key (str): Authentication header value.
        """
        self.tenant_id: str = tenant_id
        self.header: str = "jl-x-header-token-key"
        self.url: str = base_url
        self.header_key: str = header_key
        self.client: Optional[aiohttp.ClientSession] = None
        self._closed: bool = False

    async def _ensure_client(self) -> None:
        """Ensure that the HTTP client session is available and not closed.

        This method creates a new client session if one doesn't exist or if the
        current session has been closed.
        """
        if not self.client or self.client.closed:
            self.client = aiohttp.ClientSession()

    @classmethod
    @lru_cache(maxsize=100)
    def get_instance(
        cls, tenant_id: str, base_url: str, header_key: str
    ) -> "MainSubSysApiManager":
        """Get or create a cached instance for the specified tenant.

        This method implements thread-local caching to ensure that each tenant
        gets a dedicated API manager instance while maintaining thread safety.

        Args:
            tenant_id (str): Tenant identifier.
            base_url (str): Base URL for the Main SubSystem API.
            header_key (str): Authentication header value.

        Returns:
            MainSubSysApiManager: Cached or new instance for the tenant.
        """
        if not hasattr(cls._thread_local, "instances"):
            cls._thread_local.instances = {}

        if tenant_id not in cls._thread_local.instances:
            cls._thread_local.instances[tenant_id] = cls(
                tenant_id, base_url, header_key)

        return cls._thread_local.instances[tenant_id]

    @retry_with_backoff()
    async def base_method_async(
        self,
        api_url: str,
        method: RequestType,
        payload: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        tenant_id: Optional[str] = None,
    ) -> ClientResponse:
        """Make tenant-specific API request and return raw ClientResponse.

        This method constructs and executes HTTP requests to tenant-specific API endpoints
        with automatic retry logic and error handling. The raw response is returned
        for flexible handling by the caller.

        Args:
            api_url (str): API endpoint path (without base URL).
            method (RequestType): HTTP method to use for the request.
            payload (Optional[Dict[str, Any]]): JSON payload for POST/PUT requests.
            params (Optional[Dict[str, Any]]): Query parameters for the request.
            tenant_id (Optional[str]): Override tenant ID (uses instance default if None).

        Returns:
            ClientResponse: Raw aiohttp response object for flexible handling.

        Raises:
            ApiError: If the API request fails after all retry attempts.

        Example:
            response = await api.base_method_async("customers", RequestType.GET)
            if response.status == 200:
                data = await response.json()
            else:
                error_text = await response.text()
                logging.error(f"API error: {error_text}")
        """
        await self._ensure_client()
        tenant_id = tenant_id or self.tenant_id

        headers = {"Content-Type": "application/json",
                   self.header: self.header_key}

        url = f"{self.url}/tenancy/{tenant_id}/{api_url}"

        try:
            return await self.client.request(
                method.value, url=url, headers=headers, json=payload, params=params
            )

        except aiohttp.ClientError as e:
            logging.error(f"API error: {str(e)}")
            raise ApiError(str(e))

    @retry_with_backoff()
    async def base_method_tenantless_async(
        self,
        api_url: str,
        method: RequestType,
        payload: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> ClientResponse:
        """Make tenantless API request and return raw ClientResponse.

        This method constructs and executes HTTP requests to tenantless API endpoints
        (typically for system-wide operations) with automatic retry logic and error handling.

        Args:
            api_url (str): API endpoint path (without base URL).
            method (RequestType): HTTP method to use for the request.
            payload (Optional[Dict[str, Any]]): JSON payload for POST/PUT requests.
            params (Optional[Dict[str, Any]]): Query parameters for the request.

        Returns:
            ClientResponse: Raw aiohttp response object for flexible handling.

        Raises:
            ApiError: If the API request fails after all retry attempts.

        Example:
            response = await api.base_method_tenantless_async("health", RequestType.GET)
            health_status = await response.json()
        """
        await self._ensure_client()

        headers = {"Content-Type": "application/json",
                   self.header: self.header_key}

        url = f"{self.url}/tenantless/UK/{api_url}"

        try:
            return await self.client.request(
                method.value, url=url, headers=headers, json=payload, params=params
            )

        except aiohttp.ClientError as e:
            logging.error(f"API error: {str(e)}")
            raise ApiError(str(e))

    async def close(self) -> None:
        """Close the HTTP client session and clean up resources.

        This method ensures proper cleanup of the aiohttp ClientSession
        to prevent resource leaks and connection warnings.
        """
        if self.client and not self.client.closed:
            await self.client.close()
            self._closed = True
            self.client = None

    async def __aenter__(self) -> "MainSubSysApiManager":
        """Async context manager entry.

        Returns:
            MainSubSysApiManager: Self reference for context manager usage.

        Example:
            async with MainSubSysApiManager.get_instance(tenant_id, base_url, header_key) as api:
                response = await api.base_method_async("endpoint", RequestType.GET)
        """
        await self._ensure_client()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit with automatic cleanup.

        Args:
            exc_type: Exception type if an exception occurred.
            exc_val: Exception value if an exception occurred.
            exc_tb: Exception traceback if an exception occurred.
        """
        await self.close()

    def __del__(self) -> None:
        """Ensure resources are cleaned up when the object is destroyed.

        This method schedules cleanup as an asyncio task to handle cases
        where explicit cleanup wasn't performed.
        """
        if self.client and not self.client.closed:
            asyncio.create_task(self.close())

    @classmethod
    async def cleanup_all(cls) -> None:
        """Clean up all cached instances and their resources.

        This method should be called when shutting down the application
        to ensure all API manager instances are properly cleaned up.

        Example:
            # During application shutdown
            await MainSubSysApiManager.cleanup_all()
        """
        if hasattr(cls._thread_local, "instances"):
            cleanup_tasks = [
                instance.close() for instance in cls._thread_local.instances.values()
            ]
            if cleanup_tasks:
                await asyncio.gather(*cleanup_tasks, return_exceptions=True)
            cls._thread_local.instances.clear()
