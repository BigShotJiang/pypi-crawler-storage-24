"""SharePoint and Microsoft Graph API integration module.

This module provides comprehensive SharePoint and Microsoft Graph operations
with credentials loaded from environment variables or Azure App Configuration.
"""

import os
import json
import base64
import aiohttp
import asyncio
import logging
from enum import Enum
from typing import Optional, Union, Any, Dict
from datetime import datetime, timedelta
from functools import wraps

logger = logging.getLogger(__name__)


class GraphMethod(Enum):
    """HTTP methods for Graph API requests."""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class ContentType(Enum):
    """Email content types."""
    Text = "Text"
    HTML = "HTML"


async def graph_request(
    method: GraphMethod,
    url: str,
    token: str,
    headers: Optional[dict] = None,
    **kwargs
) -> dict:
    """Reusable aiohttp wrapper for Microsoft Graph API calls.

    Args:
        method: HTTP method (GET, POST, PUT, PATCH, DELETE)
        url: Full Graph API URL
        token: Access token
        headers: Optional additional headers
        **kwargs: Additional arguments for aiohttp request

    Returns:
        Response JSON data

    Raises:
        aiohttp.ClientError: On HTTP errors
    """
    _method = method.value if isinstance(method, GraphMethod) else method

    default_headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    if headers:
        default_headers.update(headers)

    async def _execute(sess: aiohttp.ClientSession):
        async with sess.request(_method, url, headers=default_headers, **kwargs) as response:
            response.raise_for_status()

            # Handle different response types
            content_type = response.headers.get('Content-Type', '')
            if 'application/json' in content_type:
                return await response.json()
            elif response.status == 204:  # No content
                return {"status": "success", "message": "Operation completed"}
            else:
                return {"status": "success", "data": await response.text()}

    async with aiohttp.ClientSession() as session:
        return await _execute(session)


class SharePointManager:
    """Comprehensive SharePoint and Microsoft Graph integration manager.

    Environment variables required:
    - MICROSOFT_TENANT_ID: Azure AD tenant ID
    - MICROSOFT_CLIENT_ID: Application (client) ID
    - MICROSOFT_CLIENT_SECRET: Client secret
    - SHAREPOINT_SITE_ID: SharePoint site ID
    - SHAREPOINT_DRIVE_ID: SharePoint drive ID
    - AZURE_STORAGE_CONNECTION_STRING: (Optional) For blob storage operations
    - EMAIL_SIGNATURE_BLOB_PATH: (Optional) Path to email signature in blob storage

    Example:
        ```python
        from jlframework import SharePointManager

        # Initialize manager
        sp = SharePointManager()

        # Send email
        await sp.send_email(
            subject="Test Email",
            body="<h1>Hello</h1>",
            recipient="user@example.com",
            content_type=ContentType.HTML
        )

        # Upload file to SharePoint
        await sp.upload_file_to_drive(
            folder_path="/Documents",
            file_name="report.pdf",
            file_path="./local/report.pdf"
        )
        ```
    """

    def __init__(
        self,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        site_id: Optional[str] = None,
        drive_id: Optional[str] = None,
        user_email: Optional[str] = None,
        config: Optional[Any] = None
    ):
        """Initialize SharePoint manager.

        Args:
            tenant_id: Azure AD tenant ID
            client_id: Application client ID
            client_secret: Client secret
            site_id: SharePoint site ID
            drive_id: SharePoint drive ID
            user_email: Default user email for operations
            config: Optional ConfigurationManager instance for loading from Azure App Config
        """
        # Try to load from Azure App Configuration if config is provided
        sharepoint_config = None
        onedrive_path = None

        if config:
            sharepoint_config = self._load_sharepoint_config_from_azure(config)
            if sharepoint_config:
                logger.info(
                    "Loaded SharePoint configuration from Azure App Configuration")

        # Priority: Direct parameters > SharePoint config object > Environment variables
        if sharepoint_config:
            self.tenant_id = tenant_id or sharepoint_config.get("tenant_id")
            self.client_id = client_id or sharepoint_config.get("client_id")
            self.client_secret = client_secret or sharepoint_config.get(
                "client_secret")
            self.user_email = user_email or sharepoint_config.get("user")
            onedrive_path = sharepoint_config.get("onedrive")

            # Extract drive_id from onedrive path if available
            if onedrive_path and not drive_id:
                drive_id = self._extract_drive_id_from_onedrive_path(
                    onedrive_path)
        else:
            self.tenant_id = tenant_id
            self.client_id = client_id
            self.client_secret = client_secret
            self.user_email = user_email

        # Fall back to environment variables if not set
        self.tenant_id = self.tenant_id or os.getenv("MICROSOFT_TENANT_ID")
        self.client_id = self.client_id or os.getenv("MICROSOFT_CLIENT_ID")
        self.client_secret = self.client_secret or os.getenv(
            "MICROSOFT_CLIENT_SECRET")
        self.site_id = site_id or os.getenv("SHAREPOINT_SITE_ID")
        self.drive_id = drive_id or os.getenv("SHAREPOINT_DRIVE_ID")
        self.user_email = self.user_email or os.getenv("MICROSOFT_USER_EMAIL")

        # Store the onedrive path for reference
        self.onedrive_path = onedrive_path

        if not all([self.tenant_id, self.client_id, self.client_secret]):
            raise ValueError(
                "Microsoft Graph credentials not found. Please set MICROSOFT_TENANT_ID, "
                "MICROSOFT_CLIENT_ID, and MICROSOFT_CLIENT_SECRET environment variables, "
                "or provide a 'Sharepoint' or 'Azureconnection' configuration in Azure App Configuration."
            )

        # Token cache
        self._access_token: Optional[str] = None
        self._token_expiry: Optional[datetime] = None

        # Constants
        self.FORMAT = "%Y-%m-%dT%H:%M:%SZ"

    @staticmethod
    def _load_sharepoint_config_from_azure(config: Any) -> Optional[Dict[str, str]]:
        """Load SharePoint configuration from Azure App Configuration.

        Tries to load from 'Sharepoint' or 'Azureconnection' keys.

        Args:
            config: ConfigurationManager instance

        Returns:
            Dictionary with SharePoint configuration or None
        """
        try:
            # Try 'Sharepoint' key first
            sharepoint_json = None
            try:
                sharepoint_json = config.get("Sharepoint")
            except (KeyError, AttributeError):
                pass

            # Try 'Azureconnection' key as fallback
            if not sharepoint_json:
                try:
                    sharepoint_json = config.get("Azureconnection")
                except (KeyError, AttributeError):
                    pass

            if sharepoint_json:
                # Parse JSON if it's a string
                if isinstance(sharepoint_json, str):
                    return json.loads(sharepoint_json)
                elif isinstance(sharepoint_json, dict):
                    return sharepoint_json

            return None

        except json.JSONDecodeError as e:
            logger.warning(
                f"Failed to parse SharePoint configuration JSON: {e}")
            return None
        except Exception as e:
            logger.warning(
                f"Error loading SharePoint configuration from Azure: {e}")
            return None

    @staticmethod
    def _extract_drive_id_from_onedrive_path(onedrive_path: str) -> Optional[str]:
        """Extract drive ID from OneDrive path URL.

        The onedrive path format is typically:
        https://graph.microsoft.com/v1.0/sites/{site-id}/drive/root:/path/

        Args:
            onedrive_path: Full OneDrive path URL

        Returns:
            Extracted drive ID or None
        """
        try:
            # Extract site information from the path
            # Format: https://graph.microsoft.com/v1.0/sites/domain.sharepoint.com,site-id,web-id/drive/root:/path/
            if "/sites/" in onedrive_path and "/drive/" in onedrive_path:
                # For now, we'll store the full path and let users configure drive_id separately
                # This is because the drive ID isn't directly in the URL
                logger.info(
                    "OneDrive path detected. Please configure SHAREPOINT_DRIVE_ID separately if needed.")
                return None
        except Exception as e:
            logger.warning(
                f"Error extracting drive ID from OneDrive path: {e}")
            return None

    async def get_sharepoint_access_token(self) -> str:
        """Get cached or new access token for SharePoint/Graph API.

        Returns:
            Access token string

        Example:
            ```python
            token = await sp.get_sharepoint_access_token()
            ```
        """
        # Return cached token if still valid
        if self._access_token and self._token_expiry:
            if datetime.utcnow() < self._token_expiry - timedelta(minutes=5):
                return self._access_token

        # Request new token
        token_endpoint = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
        token_data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "https://graph.microsoft.com/.default"
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(token_endpoint, data=token_data) as response:
                response.raise_for_status()
                token_response = await response.json()

                self._access_token = token_response["access_token"]
                expires_in = token_response.get("expires_in", 3600)
                self._token_expiry = datetime.utcnow() + timedelta(seconds=expires_in)

                return self._access_token

    async def send_email(
        self,
        subject: str,
        body: str,
        recipient: Union[str, list[str]],
        attachments: Optional[list[str]] = None,
        content_type: ContentType = ContentType.Text,
        custom_signature: Optional[str] = None,
        from_email: Optional[str] = None
    ) -> dict:
        """Send email via Microsoft Graph API.

        Args:
            subject: Email subject
            body: Email body content
            recipient: Single email or list of emails
            attachments: Optional list of file paths to attach
            content_type: ContentType.Text or ContentType.HTML
            custom_signature: Optional custom signature HTML
            from_email: Optional sender email (defaults to user_email)

        Returns:
            Dictionary with success status and message

        Example:
            ```python
            result = await sp.send_email(
                subject="Monthly Report",
                body="<h1>Report</h1><p>See attachment</p>",
                recipient=["user1@example.com", "user2@example.com"],
                attachments=["./report.pdf"],
                content_type=ContentType.HTML
            )
            ```
        """
        access_token = await self.get_sharepoint_access_token()
        sender_email = from_email or self.user_email

        if not sender_email:
            raise ValueError(
                "Sender email not provided. Set from_email or MICROSOFT_USER_EMAIL.")

        # Prepare recipients
        if isinstance(recipient, str):
            recipient = [recipient]

        to_recipients = [{"emailAddress": {"address": email}}
                         for email in recipient]

        # Prepare body with signature
        email_body = body
        if custom_signature:
            email_body += f"<br><br>{custom_signature}"

        # Prepare message
        message = {
            "message": {
                "subject": subject,
                "body": {
                    "contentType": content_type.value,
                    "content": email_body
                },
                "toRecipients": to_recipients,
                "attachments": []
            }
        }

        # Add attachments
        if attachments:
            for attachment_path in attachments:
                with open(attachment_path, "rb") as attachment:
                    file_content = attachment.read()
                    file_name = os.path.basename(attachment_path)

                    message["message"]["attachments"].append({
                        "@odata.type": "#microsoft.graph.fileAttachment",
                        "name": file_name,
                        "contentBytes": base64.b64encode(file_content).decode()
                    })

        # Send email
        url = f"https://graph.microsoft.com/v1.0/users/{sender_email}/sendMail"
        headers = {"Authorization": f"Bearer {access_token}"}

        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=message) as response:
                if response.status == 202:
                    return {"success": True, "message": "Email sent successfully"}
                else:
                    error_text = await response.text()
                    return {"success": False, "error": error_text}

    async def upload_file_to_drive(
        self,
        folder_path: str,
        file_name: str,
        file_path: Optional[str] = None,
        file_content: Optional[bytes] = None
    ) -> dict:
        """Upload file to SharePoint drive.

        Args:
            folder_path: Folder path in SharePoint (e.g., "/Documents/Reports")
            file_name: Name for the uploaded file
            file_path: Local file path to upload
            file_content: Or provide file content directly as bytes

        Returns:
            Response from Graph API

        Example:
            ```python
            # Upload from file path
            result = await sp.upload_file_to_drive(
                folder_path="/Documents",
                file_name="report.pdf",
                file_path="./local/report.pdf"
            )

            # Upload from bytes
            result = await sp.upload_file_to_drive(
                folder_path="/Documents",
                file_name="data.json",
                file_content=json.dumps(data).encode()
            )
            ```
        """
        if not self.drive_id:
            raise ValueError(
                "SharePoint drive ID not configured. Set SHAREPOINT_DRIVE_ID.")

        access_token = await self.get_sharepoint_access_token()

        # Get file content
        if file_path:
            with open(file_path, "rb") as f:
                content = f.read()
        elif file_content:
            content = file_content
        else:
            raise ValueError(
                "Either file_path or file_content must be provided")

        # Upload file
        upload_url = (
            f"https://graph.microsoft.com/v1.0/drives/{self.drive_id}"
            f"/root:{folder_path}/{file_name}:/content"
        )

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/octet-stream"
        }

        async with aiohttp.ClientSession() as session:
            async with session.put(upload_url, headers=headers, data=content) as response:
                response.raise_for_status()
                return await response.json()

    async def get_all_emails_by_user_and_datetime(
        self,
        user_mail: str,
        from_email: str,
        send_date_time: datetime,
        end_date_time: Optional[datetime] = None
    ) -> list:
        """Get emails from specific sender within date range.

        Args:
            user_mail: Mailbox to search
            from_email: Sender email address
            send_date_time: Start datetime
            end_date_time: Optional end datetime

        Returns:
            List of email messages

        Example:
            ```python
            emails = await sp.get_all_emails_by_user_and_datetime(
                user_mail="inbox@example.com",
                from_email="sender@example.com",
                send_date_time=datetime(2024, 1, 1),
                end_date_time=datetime(2024, 1, 31)
            )
            ```
        """
        access_token = await self.get_sharepoint_access_token()
        formatted_date = send_date_time.strftime(self.FORMAT)

        # Build filter
        filter_query = f"from/emailAddress/address eq '{from_email}' and receivedDateTime ge {formatted_date}"
        if end_date_time:
            formatted_end = end_date_time.strftime(self.FORMAT)
            filter_query += f" and receivedDateTime le {formatted_end}"

        url = f"https://graph.microsoft.com/v1.0/users/{user_mail}/messages?$filter={filter_query}"

        return await graph_request(GraphMethod.GET, url, access_token)

    async def get_email_attachments(
        self,
        user_mail: str,
        message_id: str,
        retries: int = 3,
        delay: int = 10
    ) -> list:
        """Get attachments from an email message.

        Args:
            user_mail: Mailbox email
            message_id: Message ID
            retries: Number of retry attempts
            delay: Delay between retries in seconds

        Returns:
            List of attachments

        Example:
            ```python
            attachments = await sp.get_email_attachments(
                user_mail="inbox@example.com",
                message_id="AAMkAGI2..."
            )
            ```
        """
        access_token = await self.get_sharepoint_access_token()
        url = f"https://graph.microsoft.com/v1.0/users/{user_mail}/messages/{message_id}/attachments"

        for attempt in range(retries):
            try:
                return await graph_request(GraphMethod.GET, url, access_token)
            except aiohttp.ClientError as e:
                if attempt < retries - 1:
                    await asyncio.sleep(delay)
                else:
                    raise

    async def download_attachment(
        self,
        user_mail: str,
        message_id: str,
        attachment_id: str
    ) -> bytes:
        """Download email attachment content.

        Args:
            user_mail: Mailbox email
            message_id: Message ID
            attachment_id: Attachment ID

        Returns:
            Attachment content as bytes

        Example:
            ```python
            content = await sp.download_attachment(
                user_mail="inbox@example.com",
                message_id="AAMkAGI2...",
                attachment_id="AAMkAGI2..."
            )

            with open("downloaded_file.pdf", "wb") as f:
                f.write(content)
            ```
        """
        access_token = await self.get_sharepoint_access_token()
        url = (
            f"https://graph.microsoft.com/v1.0/users/{user_mail}"
            f"/messages/{message_id}/attachments/{attachment_id}/$value"
        )

        headers = {"Authorization": f"Bearer {access_token}"}

        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                response.raise_for_status()
                return await response.read()

    async def create_sharing_link(
        self,
        item_id: str,
        link_type: str = "view",
        scope: str = "organization"
    ) -> dict:
        """Create a sharing link for a SharePoint item.

        Args:
            item_id: SharePoint item ID
            link_type: "view" or "edit"
            scope: "anonymous", "organization", or "users"

        Returns:
            Sharing link information

        Example:
            ```python
            link = await sp.create_sharing_link(
                item_id="01ABCDEF...",
                link_type="view",
                scope="organization"
            )
            print(f"Share link: {link['link']['webUrl']}")
            ```
        """
        if not self.drive_id:
            raise ValueError("SharePoint drive ID not configured.")

        access_token = await self.get_sharepoint_access_token()
        url = f"https://graph.microsoft.com/v1.0/drives/{self.drive_id}/items/{item_id}/createLink"

        payload = {
            "type": link_type,
            "scope": scope
        }

        return await graph_request(GraphMethod.POST, url, access_token, json=payload)

    async def search_items_in_drive(
        self,
        query: str,
        folder_path: Optional[str] = None
    ) -> list:
        """Search for items in SharePoint drive.

        Args:
            query: Search query
            folder_path: Optional folder to search within

        Returns:
            List of matching items

        Example:
            ```python
            results = await sp.search_items_in_drive(
                query="report",
                folder_path="/Documents"
            )
            ```
        """
        if not self.drive_id:
            raise ValueError("SharePoint drive ID not configured.")

        access_token = await self.get_sharepoint_access_token()

        if folder_path:
            url = (
                f"https://graph.microsoft.com/v1.0/drives/{self.drive_id}"
                f"/root:{folder_path}:/search(q='{query}')"
            )
        else:
            url = f"https://graph.microsoft.com/v1.0/drives/{self.drive_id}/root/search(q='{query}')"

        return await graph_request(GraphMethod.GET, url, access_token)

    def get_sharepoint_access_token_sync(self) -> str:
        """Synchronous version of get_sharepoint_access_token.

        Returns:
            Access token string
        """
        return asyncio.run(self.get_sharepoint_access_token())

    def send_email_sync(
        self,
        subject: str,
        body: str,
        recipient: Union[str, list[str]],
        **kwargs
    ) -> dict:
        """Synchronous version of send_email.

        See send_email() for parameter details.
        """
        return asyncio.run(self.send_email(subject, body, recipient, **kwargs))
