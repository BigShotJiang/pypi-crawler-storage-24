"""Base Manager Classes for jlframework.

This module provides abstract base classes that implement common patterns
used across all manager classes in the framework. This eliminates code
duplication and ensures consistent behavior.

Key Features:
    - Standardized initialization
    - Common error handling
    - Logging integration
    - Configuration management
    - Resource cleanup patterns

Example:
    ```python
    from jlframework.core.base_manager import BaseManager
    from jlframework.core.config_manager import ConfigurationManager
    
    class MyManager(BaseManager):
        def _initialize(self):
            # Manager-specific initialization
            self.client = SomeClient(self.config.get("API_KEY"))
        
        def _cleanup(self):
            # Manager-specific cleanup
            if self.client:
                self.client.close()
    ```
"""

import logging
from abc import ABC, abstractmethod
from typing import Optional
from jlframework.core.config_manager import ConfigurationManager


class BaseManager(ABC):
    """Abstract base class for all manager classes in jlframework.

    This class provides common functionality that all managers need:
    - Configuration management
    - Logging
    - Initialization lifecycle
    - Error handling
    - Resource cleanup

    Subclasses must implement:
    - _initialize(): Manager-specific initialization logic

    Subclasses may optionally implement:
    - _cleanup(): Manager-specific cleanup logic

    Attributes:
        config (ConfigurationManager): Configuration manager instance
        logger (logging.Logger): Logger for this manager

    Example:
        ```python
        class DatabaseManager(BaseManager):
            def _initialize(self):
                conn_string = self.config.get(ConfigurationManager.Keys.SQL_CONNECTION)
                self.connection = create_connection(conn_string)

            def _cleanup(self):
                if hasattr(self, 'connection'):
                    self.connection.close()
        ```
    """

    def __init__(self, config: Optional[ConfigurationManager] = None):
        """Initialize the base manager.

        Args:
            config: Configuration manager instance. If None, uses singleton.
        """
        self.config = config or ConfigurationManager.get_instance()
        self.logger = logging.getLogger(self.__class__.__name__)
        self._initialized = False

        try:
            self._initialize()
            self._initialized = True
            self.logger.debug(
                f"{self.__class__.__name__} initialized successfully")
        except Exception as e:
            self.logger.error(
                f"Failed to initialize {self.__class__.__name__}: {e}")
            raise

    @abstractmethod
    def _initialize(self):
        """Initialize manager-specific resources.

        This method must be implemented by subclasses to perform
        any initialization logic specific to that manager.

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        pass

    def _cleanup(self):
        """Clean up manager-specific resources.

        This method may be overridden by subclasses to perform
        cleanup logic. Default implementation does nothing.
        """
        pass

    def _handle_error(self, error: Exception, context: str, reraise: bool = True):
        """Standardized error handling.

        Args:
            error: The exception that occurred
            context: Description of what was being done when error occurred
            reraise: Whether to re-raise the exception after logging

        Example:
            ```python
            try:
                result = self.some_operation()
            except Exception as e:
                self._handle_error(e, "performing some operation")
            ```
        """
        error_msg = f"{context}: {str(error)}"
        self.logger.error(error_msg, exc_info=True)

        # Could add telemetry, metrics, etc. here

        if reraise:
            raise

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with cleanup."""
        try:
            self._cleanup()
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")
        return False

    def __del__(self):
        """Destructor to ensure cleanup."""
        if self._initialized:
            try:
                self._cleanup()
            except Exception as e:
                self.logger.error(f"Error in destructor cleanup: {e}")


class BaseAzureManager(BaseManager):
    """Base class for managers that interact with Azure services.

    Extends BaseManager with Azure-specific patterns like:
    - Azure client initialization
    - Retry logic for transient failures
    - Azure-specific error handling

    Attributes:
        config (ConfigurationManager): Configuration manager
        logger (logging.Logger): Logger for this manager

    Example:
        ```python
        class BlobManager(BaseAzureManager):
            def _initialize(self):
                conn_string = self.config.get(ConfigurationManager.Keys.STORAGE_CONNECTION)
                self.blob_client = BlobServiceClient.from_connection_string(conn_string)
        ```
    """

    def _get_azure_credential(self):
        """Get Azure credential for authentication.

        Returns:
            Azure credential object

        Note:
            This can be extended to support different credential types
            (DefaultAzureCredential, ClientSecretCredential, etc.)
        """
        # Placeholder for Azure credential logic
        # Can be extended based on authentication requirements
        pass

    def _handle_azure_error(self, error: Exception, context: str):
        """Handle Azure-specific errors.

        Args:
            error: The Azure exception
            context: Description of the operation
        """
        # Azure-specific error handling
        # Could check for specific Azure error codes, implement retry logic, etc.
        self._handle_error(error, f"Azure operation - {context}")


class BaseAPIManager(BaseManager):
    """Base class for managers that interact with REST APIs.

    Extends BaseManager with API-specific patterns like:
    - HTTP client management
    - Request/response handling
    - Retry logic with exponential backoff
    - Rate limiting

    Attributes:
        config (ConfigurationManager): Configuration manager
        logger (logging.Logger): Logger for this manager
        base_url (str): Base URL for API endpoints

    Example:
        ```python
        class ExternalAPIManager(BaseAPIManager):
            def _initialize(self):
                self.base_url = self.config.get("API_BASE_URL")
                self.api_key = self.config.get("API_KEY")
        ```
    """

    def __init__(self, config: Optional[ConfigurationManager] = None):
        """Initialize API manager.

        Args:
            config: Configuration manager instance
        """
        self.base_url: Optional[str] = None
        super().__init__(config)

    def _build_url(self, endpoint: str) -> str:
        """Build full URL from endpoint.

        Args:
            endpoint: API endpoint path

        Returns:
            Full URL

        Example:
            ```python
            url = self._build_url("/users/123")
            # Returns: "https://api.example.com/users/123"
            ```
        """
        if not self.base_url:
            raise ValueError("base_url not set")

        # Remove leading slash from endpoint if present
        endpoint = endpoint.lstrip('/')

        # Ensure base_url doesn't end with slash
        base = self.base_url.rstrip('/')

        return f"{base}/{endpoint}"

    def _get_default_headers(self) -> dict:
        """Get default headers for API requests.

        Returns:
            Dictionary of default headers

        Note:
            Subclasses can override to add authentication headers, etc.
        """
        return {
            "Content-Type": "application/json",
            "User-Agent": "jlframework/1.0"
        }


class BaseDatabaseManager(BaseManager):
    """Base class for database managers.

    Extends BaseManager with database-specific patterns like:
    - Connection management
    - Transaction handling
    - Query execution patterns
    - Connection pooling

    Attributes:
        config (ConfigurationManager): Configuration manager
        logger (logging.Logger): Logger for this manager
        connection_string (str): Database connection string

    Example:
        ```python
        class PostgresManager(BaseDatabaseManager):
            def _initialize(self):
                self.connection_string = self.config.get("POSTGRES_CONNECTION")
                self.pool = create_pool(self.connection_string)
        ```
    """

    def __init__(self, config: Optional[ConfigurationManager] = None):
        """Initialize database manager.

        Args:
            config: Configuration manager instance
        """
        self.connection_string: Optional[str] = None
        super().__init__(config)

    def _execute_with_retry(self, operation, max_retries: int = 3):
        """Execute database operation with retry logic.

        Args:
            operation: Callable that performs the database operation
            max_retries: Maximum number of retry attempts

        Returns:
            Result of the operation

        Raises:
            Exception: If all retries fail

        Example:
            ```python
            result = self._execute_with_retry(
                lambda: self.connection.execute(query)
            )
            ```
        """
        last_error = None

        for attempt in range(max_retries):
            try:
                return operation()
            except Exception as e:
                last_error = e
                self.logger.warning(
                    f"Database operation failed (attempt {attempt + 1}/{max_retries}): {e}"
                )

                if attempt < max_retries - 1:
                    # Could add exponential backoff here
                    import time
                    time.sleep(2 ** attempt)

        # All retries failed
        self._handle_error(
            last_error,
            f"Database operation failed after {max_retries} attempts"
        )


class SingletonMeta(type):
    """Metaclass for implementing singleton pattern.

    This metaclass ensures that only one instance of a class exists.
    Thread-safe implementation using double-checked locking.

    Example:
        ```python
        class MyManager(metaclass=SingletonMeta):
            def __init__(self):
                self.value = 42

        # Both variables reference the same instance
        manager1 = MyManager()
        manager2 = MyManager()
        assert manager1 is manager2
        ```
    """

    _instances = {}
    _lock = __import__('threading').Lock()

    def __call__(cls, *args, **kwargs):
        """Create or return singleton instance."""
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:
                    instance = super().__call__(*args, **kwargs)
                    cls._instances[cls] = instance
        return cls._instances[cls]

    @classmethod
    def reset_instance(mcs, cls):
        """Reset singleton instance (for testing).

        Args:
            cls: The class to reset
        """
        with mcs._lock:
            if cls in mcs._instances:
                del mcs._instances[cls]
