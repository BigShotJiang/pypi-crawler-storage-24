"""SQL Manager Module with connection pooling and retry logic.

This module provides a singleton SQL database manager with async/sync support,
connection pooling, and automatic retry logic for transient failures.
"""

import os
import asyncio
import pyodbc
import aioodbc
import pandas as pd
from typing import Optional, Any
from contextlib import asynccontextmanager
from urllib.parse import quote_plus


class SqlManager:
    """Singleton SQL database manager with connection pooling and retry logic.

    Environment variables:
    - SQL_SERVER: Database server address
    - SQL_DATABASE: Database name
    - SQL_USERNAME: Database username
    - SQL_PASSWORD: Database password
    - SQL_DRIVER: ODBC driver (default: ODBC Driver 17 for SQL Server)
    - SQL_CONNECTION_STRING: Or provide full connection string
    - SQL_POOL_SIZE: Connection pool size (default: 5)
    - SQL_MAX_RETRIES: Max retry attempts (default: 3)

    Example:
        ```python
        from jlframework import SqlManager

        # Initialize manager (singleton)
        sql = SqlManager()

        # Async query
        df = await sql.get_async(
            query="SELECT * FROM users WHERE status = ?",
            header="user_id,name,email",
            params=("active",)
        )

        # Sync query
        df = sql.get_sync(
            query="SELECT * FROM products",
            header="product_id,name,price"
        )

        # Execute non-query
        await sql.execute_async(
            query="UPDATE users SET last_login = GETDATE() WHERE user_id = ?",
            params=(123,)
        )

        # Health check
        is_healthy = await sql.check_health()

        # Cleanup
        await sql.close()
        ```
    """

    _instances = {}
    _lock = asyncio.Lock()

    def __new__(cls, connection_string: Optional[str] = None):
        """Singleton pattern implementation.

        Args:
            connection_string: Optional connection string (uses env vars if not provided)

        Returns:
            Singleton instance of SqlManager
        """
        # Create key for this configuration
        key = connection_string or "default"

        if key not in cls._instances:
            instance = super(SqlManager, cls).__new__(cls)
            cls._instances[key] = instance

        return cls._instances[key]

    def __init__(self, connection_string: Optional[str] = None):
        """Initialize SQL Manager.

        Args:
            connection_string: Optional connection string
        """
        # Only initialize once
        if hasattr(self, '_initialized'):
            return

        self._initialized = True
        self._pool: Optional[aioodbc.Pool] = None
        self._lock = asyncio.Lock()

        # Build connection string
        if connection_string:
            self.connection_string = connection_string
        elif os.getenv("SQL_CONNECTION_STRING"):
            self.connection_string = os.getenv("SQL_CONNECTION_STRING")
        else:
            # Build from components
            server = os.getenv("SQL_SERVER")
            database = os.getenv("SQL_DATABASE")
            username = os.getenv("SQL_USERNAME")
            password = os.getenv("SQL_PASSWORD")
            driver = os.getenv("SQL_DRIVER", "ODBC Driver 17 for SQL Server")

            if not all([server, database, username, password]):
                raise ValueError(
                    "SQL connection details not found. Please set SQL_SERVER, SQL_DATABASE, "
                    "SQL_USERNAME, and SQL_PASSWORD environment variables, or provide "
                    "SQL_CONNECTION_STRING."
                )

            self.connection_string = (
                f"DRIVER={{{driver}}};"
                f"SERVER={server};"
                f"DATABASE={database};"
                f"UID={username};"
                f"PWD={password};"
                "Encrypt=yes;"
                "TrustServerCertificate=no;"
                "Connection Timeout=30;"
            )

        # Configuration
        self.pool_size = int(os.getenv("SQL_POOL_SIZE", "5"))
        self.max_retries = int(os.getenv("SQL_MAX_RETRIES", "3"))

    async def _get_pool(self) -> aioodbc.Pool:
        """Get or create connection pool.

        Returns:
            Connection pool instance
        """
        if self._pool is None:
            async with self._lock:
                if self._pool is None:
                    try:
                        self._pool = await aioodbc.create_pool(
                            dsn=self.connection_string,
                            minsize=1,
                            maxsize=self.pool_size,
                            echo=False
                        )
                    except Exception as e:
                        raise ConnectionError(
                            f"Failed to create connection pool: {e}")

        return self._pool

    async def _execute_with_retry(self, operation):
        """Execute operation with retry logic.

        Args:
            operation: Async operation to execute

        Returns:
            Operation result

        Raises:
            Exception: If all retries fail
        """
        last_exception = None

        for attempt in range(self.max_retries):
            try:
                return await operation()
            except Exception as e:
                last_exception = e

                # Check if error is retryable
                error_msg = str(e).lower()
                retryable = any(keyword in error_msg for keyword in [
                    "timeout", "connection", "network", "deadlock", "transient"
                ])

                if not retryable or attempt == self.max_retries - 1:
                    raise

                # Wait before retry (exponential backoff)
                wait_time = 2 ** attempt
                await asyncio.sleep(wait_time)

        raise last_exception

    @asynccontextmanager
    async def get_connection(self):
        """Async context manager for getting a connection from the pool.

        Yields:
            Database connection

        Example:
            ```python
            async with sql.get_connection() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute("SELECT * FROM users")
                    rows = await cursor.fetchall()
            ```
        """
        pool = await self._get_pool()
        conn = await pool.acquire()

        try:
            yield conn
        finally:
            await pool.release(conn)

    async def get_async(
        self,
        query: str,
        header: str,
        params: Optional[tuple] = None
    ) -> pd.DataFrame:
        """Execute SELECT query asynchronously and return results as DataFrame.

        Args:
            query: SQL SELECT query
            header: Comma-separated column names
            params: Optional query parameters

        Returns:
            DataFrame with query results

        Example:
            ```python
            df = await sql.get_async(
                query="SELECT user_id, name, email FROM users WHERE status = ?",
                header="user_id,name,email",
                params=("active",)
            )
            ```
        """
        async def _operation():
            async with self.get_connection() as conn:
                async with conn.cursor() as cursor:
                    if params:
                        await cursor.execute(query, params)
                    else:
                        await cursor.execute(query)

                    rows = await cursor.fetchall()
                    columns = [col.strip() for col in header.split(',')]

                    return pd.DataFrame.from_records(rows, columns=columns)

        return await self._execute_with_retry(_operation)

    async def execute_async(
        self,
        query: str,
        params: Optional[tuple] = None
    ) -> None:
        """Execute non-SELECT query asynchronously (INSERT, UPDATE, DELETE).

        Args:
            query: SQL query
            params: Optional query parameters

        Example:
            ```python
            await sql.execute_async(
                query="UPDATE users SET last_login = GETDATE() WHERE user_id = ?",
                params=(123,)
            )
            ```
        """
        async def _operation():
            async with self.get_connection() as conn:
                async with conn.cursor() as cursor:
                    if params:
                        await cursor.execute(query, params)
                    else:
                        await cursor.execute(query)
                    await conn.commit()

        await self._execute_with_retry(_operation)

    def get_sync(
        self,
        query: str,
        header: str,
        params: Optional[tuple] = None
    ) -> pd.DataFrame:
        """Execute SELECT query synchronously and return results as DataFrame.

        Args:
            query: SQL SELECT query
            header: Comma-separated column names
            params: Optional query parameters

        Returns:
            DataFrame with query results

        Example:
            ```python
            df = sql.get_sync(
                query="SELECT * FROM products WHERE category = ?",
                header="product_id,name,price,category",
                params=("Electronics",)
            )
            ```
        """
        with pyodbc.connect(self.connection_string) as conn:
            with conn.cursor() as cursor:
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)

                rows = cursor.fetchall()
                columns = [col.strip() for col in header.split(',')]

                return pd.DataFrame.from_records(rows, columns=columns)

    def execute_sync(
        self,
        query: str,
        params: Optional[tuple] = None
    ) -> None:
        """Execute non-SELECT query synchronously.

        Args:
            query: SQL query
            params: Optional query parameters

        Example:
            ```python
            sql.execute_sync(
                query="DELETE FROM temp_data WHERE created_date < ?",
                params=(cutoff_date,)
            )
            ```
        """
        with pyodbc.connect(self.connection_string) as conn:
            with conn.cursor() as cursor:
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                conn.commit()

    async def check_health(self) -> bool:
        """Check if database connection is healthy.

        Returns:
            True if connection is healthy, False otherwise

        Example:
            ```python
            if await sql.check_health():
                print("Database connection is healthy")
            else:
                print("Database connection failed")
            ```
        """
        try:
            await self.get_async("SELECT 1", "result")
            return True
        except Exception as e:
            print(f"Database health check failed: {e}")
            return False

    async def close(self):
        """Close connection pool and cleanup resources.

        Example:
            ```python
            await sql.close()
            ```
        """
        if self._pool:
            self._pool.close()
            await self._pool.wait_closed()
            self._pool = None

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    def __del__(self):
        """Cleanup on deletion."""
        if self._pool:
            try:
                asyncio.get_event_loop().run_until_complete(self.close())
            except Exception:
                pass

    @classmethod
    async def cleanup_all(cls):
        """Cleanup all singleton instances.

        Example:
            ```python
            # At application shutdown
            await SqlManager.cleanup_all()
            ```
        """
        for instance in cls._instances.values():
            await instance.close()
        cls._instances.clear()
