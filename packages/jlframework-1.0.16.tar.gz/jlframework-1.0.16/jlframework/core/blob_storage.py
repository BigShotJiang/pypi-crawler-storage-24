"""Azure Blob Storage module for jlframework.

This module provides utilities for Azure Blob Storage operations including
file upload, download, listing, and deletion. All credentials are loaded
from environment variables (.env file).

Environment Variables:
    - AZURE_STORAGE_CONNECTION_STRING: Azure Storage connection string
    - AZURE_STORAGE_CONTAINER: Default container name (optional)

Example:
    ```python
    from jlframework import BlobStorageManager
    
    # Initialize manager (loads from .env)
    blob_manager = BlobStorageManager()
    
    # Upload file
    url = await blob_manager.upload_file("local_file.pdf", "folder/remote_file.pdf")
    
    # Download file
    content = await blob_manager.download_file("folder/remote_file.pdf")
    ```
"""

import os
import json
import logging
from typing import Optional, List, Tuple, Union
from io import BytesIO
from datetime import datetime
import pandas as pd
from azure.storage.blob.aio import BlobServiceClient
from azure.storage.blob import BlobServiceClient as SyncBlobServiceClient

logger = logging.getLogger(__name__)


class BlobStorageManager:
    """Manager for Azure Blob Storage operations.

    This class provides a comprehensive interface for Azure Blob Storage operations
    with support for both synchronous and asynchronous methods. It loads credentials
    from environment variables for security.

    Environment Variables:
        AZURE_STORAGE_CONNECTION_STRING: Azure Storage connection string (required)
        AZURE_STORAGE_CONTAINER: Default container name (optional)

    Attributes:
        connection_string (str): Azure Storage connection string.
        default_container (Optional[str]): Default container name.

    Example:
        ```python
        from jlframework import BlobStorageManager

        # Initialize
        blob_manager = BlobStorageManager()

        # Upload file
        url = await blob_manager.upload_file("report.pdf", "reports/2024/report.pdf")

        # Download file
        content = await blob_manager.download_file("reports/2024/report.pdf")
        ```
    """

    def __init__(self, container_name: Optional[str] = None):
        """Initialize the Blob Storage manager.

        Loads configuration from Azure App Configuration (blob_storage_configurations)
        or environment variables (AZURE_STORAGE_CONNECTION_STRING).

        Args:
            container_name: Container name to use. If None, uses container from config
                          or AZURE_STORAGE_CONTAINER environment variable.

        Raises:
            ValueError: If no connection string is found in config or environment.
        """
        # Try to load from Azure App Configuration first
        self.connection_string = None
        self.default_container = container_name

        # Try Azure App Configuration
        try:
            from jlframework.core.config_manager import ConfigurationManager
            config = ConfigurationManager.get_instance()
            blob_config_str = config.get("blob_storage_configurations", None)

            if blob_config_str:
                try:
                    blob_config = json.loads(blob_config_str)
                    self.connection_string = blob_config.get(
                        "connection_string")
                    if not self.default_container:
                        self.default_container = blob_config.get(
                            "container_name")
                    logger.info(
                        "Loaded blob storage configuration from Azure App Configuration")
                except json.JSONDecodeError:
                    # Maybe it's a direct connection string
                    self.connection_string = blob_config_str
                    logger.info(
                        "Loaded blob storage connection string from Azure App Configuration")
        except Exception as e:
            logger.debug("Could not load from Azure App Configuration: %s", e)

        # Fallback to environment variables
        if not self.connection_string:
            self.connection_string = os.getenv(
                "AZURE_STORAGE_CONNECTION_STRING")

        if not self.connection_string:
            raise ValueError(
                "Azure Storage connection string not found. "
                "Please set 'blob_storage_configurations' in Azure App Configuration "
                "or 'AZURE_STORAGE_CONNECTION_STRING' environment variable."
            )

        if not self.default_container:
            self.default_container = os.getenv("AZURE_STORAGE_CONTAINER")

        logger.info(
            "BlobStorageManager initialized with default container: %s",
            self.default_container
        )

    def _get_container_name(self, container_name: Optional[str] = None) -> str:
        """Get container name from parameter or default.

        Args:
            container_name: Container name to use, or None to use default.

        Returns:
            Container name to use.

        Raises:
            ValueError: If no container name is provided and no default is set.
        """
        container = container_name or self.default_container
        if not container:
            raise ValueError(
                "Container name is required. Either pass container_name parameter "
                "or set AZURE_STORAGE_CONTAINER in your .env file."
            )
        return container

    async def upload_file(
        self,
        local_file_path: str,
        blob_name: str,
        container_name: Optional[str] = None,
        overwrite: bool = True
    ) -> str:
        """Upload a file to Azure Blob Storage asynchronously.

        Args:
            local_file_path: Path to the local file to upload.
            blob_name: Name/path for the blob in storage.
            container_name: Container name (uses default if None).
            overwrite: Whether to overwrite existing blob (default: True).

        Returns:
            URL of the uploaded blob.

        Raises:
            FileNotFoundError: If local file doesn't exist.
            Exception: If upload fails.

        Example:
            ```python
            url = await blob_manager.upload_file(
                "local_report.pdf",
                "reports/2024/january.pdf"
            )
            print(f"Uploaded to: {url}")
            ```
        """
        if not os.path.exists(local_file_path):
            raise FileNotFoundError(f"Local file not found: {local_file_path}")

        container = self._get_container_name(container_name)

        try:
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                with open(local_file_path, "rb") as data:
                    await blob_client.upload_blob(data, overwrite=overwrite)

                logger.info(f"Uploaded file to blob: {blob_name}")
                return blob_client.url

        except Exception as e:
            logger.error(f"Failed to upload file to blob storage: {e}")
            raise

    async def upload_stream(
        self,
        file_stream: Union[BytesIO, bytes],
        blob_name: str,
        container_name: Optional[str] = None,
        overwrite: bool = True
    ) -> str:
        """Upload a file stream to Azure Blob Storage asynchronously.

        Args:
            file_stream: File stream or bytes to upload.
            blob_name: Name/path for the blob in storage.
            container_name: Container name (uses default if None).
            overwrite: Whether to overwrite existing blob (default: True).

        Returns:
            URL of the uploaded blob.

        Example:
            ```python
            from io import BytesIO

            # Create file in memory
            buffer = BytesIO()
            buffer.write(b"Hello, World!")
            buffer.seek(0)

            url = await blob_manager.upload_stream(buffer, "test/hello.txt")
            ```
        """
        container = self._get_container_name(container_name)

        try:
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                await blob_client.upload_blob(file_stream, overwrite=overwrite)

                logger.info(f"Uploaded stream to blob: {blob_name}")
                return blob_client.url

        except Exception as e:
            logger.error(f"Failed to upload stream to blob storage: {e}")
            raise

    async def upload_dataframe(
        self,
        df: pd.DataFrame,
        blob_name: str,
        container_name: Optional[str] = None,
        file_format: str = "excel",
        overwrite: bool = True
    ) -> str:
        """Upload a pandas DataFrame to Azure Blob Storage.

        Args:
            df: pandas DataFrame to upload.
            blob_name: Name/path for the blob in storage.
            container_name: Container name (uses default if None).
            file_format: Format to save ("excel" or "csv", default: "excel").
            overwrite: Whether to overwrite existing blob (default: True).

        Returns:
            URL of the uploaded blob.

        Example:
            ```python
            import pandas as pd

            df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})
            url = await blob_manager.upload_dataframe(
                df,
                "data/report.xlsx",
                file_format="excel"
            )
            ```
        """
        container = self._get_container_name(container_name)

        try:
            # Create buffer
            buffer = BytesIO()

            if file_format.lower() == "excel":
                df.to_excel(buffer, index=False, engine="openpyxl")
            elif file_format.lower() == "csv":
                df.to_csv(buffer, index=False)
            else:
                raise ValueError(f"Unsupported file format: {file_format}")

            buffer.seek(0)

            # Upload
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                await blob_client.upload_blob(buffer, overwrite=overwrite)

                logger.info(f"Uploaded DataFrame to blob: {blob_name}")
                return blob_client.url

        except Exception as e:
            logger.error(f"Failed to upload DataFrame to blob storage: {e}")
            raise

    async def download_file(
        self,
        blob_name: str,
        container_name: Optional[str] = None
    ) -> bytes:
        """Download a file from Azure Blob Storage asynchronously.

        Args:
            blob_name: Name/path of the blob to download.
            container_name: Container name (uses default if None).

        Returns:
            File content as bytes.

        Example:
            ```python
            content = await blob_manager.download_file("reports/2024/january.pdf")

            # Save to local file
            with open("local_file.pdf", "wb") as f:
                f.write(content)
            ```
        """
        container = self._get_container_name(container_name)

        try:
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                download_stream = await blob_client.download_blob()
                content = await download_stream.readall()

                logger.info(f"Downloaded blob: {blob_name}")
                return content

        except Exception as e:
            logger.error(f"Failed to download blob: {e}")
            raise

    def download_file_sync(
        self,
        blob_name: str,
        container_name: Optional[str] = None
    ) -> bytes:
        """Download a file from Azure Blob Storage synchronously.

        Args:
            blob_name: Name/path of the blob to download.
            container_name: Container name (uses default if None).

        Returns:
            File content as bytes.

        Example:
            ```python
            content = blob_manager.download_file_sync("reports/2024/january.pdf")
            ```
        """
        container = self._get_container_name(container_name)

        try:
            with SyncBlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                download_stream = blob_client.download_blob()
                content = download_stream.readall()

                logger.info(f"Downloaded blob (sync): {blob_name}")
                return content

        except Exception as e:
            logger.error(f"Failed to download blob (sync): {e}")
            raise

    async def list_blobs(
        self,
        prefix: Optional[str] = None,
        container_name: Optional[str] = None
    ) -> List[str]:
        """List blobs in a container asynchronously.

        Args:
            prefix: Filter blobs by prefix (folder path).
            container_name: Container name (uses default if None).

        Returns:
            List of blob names.

        Example:
            ```python
            # List all blobs
            blobs = await blob_manager.list_blobs()

            # List blobs in a folder
            reports = await blob_manager.list_blobs(prefix="reports/2024/")
            ```
        """
        container = self._get_container_name(container_name)

        try:
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)

                blobs = []
                async for blob in container_client.list_blobs(name_starts_with=prefix):
                    blobs.append(blob.name)

                logger.info(f"Listed {len(blobs)} blobs with prefix: {prefix}")
                return blobs

        except Exception as e:
            logger.error(f"Failed to list blobs: {e}")
            raise

    async def delete_blob(
        self,
        blob_name: str,
        container_name: Optional[str] = None
    ) -> bool:
        """Delete a blob from Azure Blob Storage asynchronously.

        Args:
            blob_name: Name/path of the blob to delete.
            container_name: Container name (uses default if None).

        Returns:
            True if deletion was successful.

        Example:
            ```python
            success = await blob_manager.delete_blob("old_file.pdf")
            if success:
                print("File deleted successfully")
            ```
        """
        container = self._get_container_name(container_name)

        try:
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                await blob_client.delete_blob()

                logger.info(f"Deleted blob: {blob_name}")
                return True

        except Exception as e:
            logger.error(f"Failed to delete blob: {e}")
            return False

    async def blob_exists(
        self,
        blob_name: str,
        container_name: Optional[str] = None
    ) -> bool:
        """Check if a blob exists in Azure Blob Storage.

        Args:
            blob_name: Name/path of the blob to check.
            container_name: Container name (uses default if None).

        Returns:
            True if blob exists, False otherwise.

        Example:
            ```python
            if await blob_manager.blob_exists("reports/2024/january.pdf"):
                print("File exists")
            ```
        """
        container = self._get_container_name(container_name)

        try:
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                exists = await blob_client.exists()
                return exists

        except Exception as e:
            logger.error(f"Failed to check blob existence: {e}")
            return False

    async def get_blob_url(
        self,
        blob_name: str,
        container_name: Optional[str] = None
    ) -> str:
        """Get the URL of a blob.

        Args:
            blob_name: Name/path of the blob.
            container_name: Container name (uses default if None).

        Returns:
            URL of the blob.

        Example:
            ```python
            url = await blob_manager.get_blob_url("reports/2024/january.pdf")
            print(f"Blob URL: {url}")
            ```
        """
        container = self._get_container_name(container_name)

        try:
            async with BlobServiceClient.from_connection_string(
                self.connection_string
            ) as blob_service_client:
                container_client = blob_service_client.get_container_client(
                    container)
                blob_client = container_client.get_blob_client(blob_name)

                return blob_client.url

        except Exception as e:
            logger.error(f"Failed to get blob URL: {e}")
            raise
