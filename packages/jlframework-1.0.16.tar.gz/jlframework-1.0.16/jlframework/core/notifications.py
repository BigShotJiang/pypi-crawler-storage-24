"""Notification decorators for Slack and Microsoft Teams.

This module provides decorators for automatic notifications on function execution,
supporting both synchronous and asynchronous functions.
"""

import os
import json
import asyncio
import functools
import aiohttp
from typing import Callable, Any, Union, Optional
from datetime import datetime
from .common_utils import ExecutionResult


def slack_notification(
    webhook_url: Optional[str] = None,
    success_webhook: Optional[str] = None,
    failure_webhook: Optional[str] = None,
    enabled: bool = True
) -> Callable:
    """Decorator for automatic Slack notifications on automation execution.

    Sends notifications to Slack webhooks based on function execution results.
    Supports both sync and async functions, and handles ExecutionResult objects.

    Environment variables:
    - SLACK_WEBHOOK_URL: Default webhook for all notifications
    - SLACK_SUCCESS_WEBHOOK: Webhook for success notifications
    - SLACK_FAILURE_WEBHOOK: Webhook for failure notifications
    - SLACK_NOTIFICATIONS_ENABLED: Enable/disable notifications (default: true)

    Args:
        webhook_url: Default webhook URL (overrides SLACK_WEBHOOK_URL)
        success_webhook: Success-specific webhook (overrides SLACK_SUCCESS_WEBHOOK)
        failure_webhook: Failure-specific webhook (overrides SLACK_FAILURE_WEBHOOK)
        enabled: Enable/disable notifications

    Returns:
        Decorated function

    Example:
        ```python
        from jlframework import slack_notification, ExecutionResult

        @slack_notification()
        async def process_data():
            # Your automation logic
            return ExecutionResult(
                execution_time="2024-01-01 10:00:00",
                read_count=100,
                create_count=10,
                update_count=5
            )

        # Or with custom webhooks
        @slack_notification(
            success_webhook="https://hooks.slack.com/services/YOUR/SUCCESS/WEBHOOK",
            failure_webhook="https://hooks.slack.com/services/YOUR/FAILURE/WEBHOOK"
        )
        def sync_process():
            return {"status": "completed", "count": 50}
        ```
    """
    # Load from environment if not provided
    default_webhook = webhook_url or os.getenv("SLACK_WEBHOOK_URL")
    success_url = success_webhook or os.getenv(
        "SLACK_SUCCESS_WEBHOOK") or default_webhook
    failure_url = failure_webhook or os.getenv(
        "SLACK_FAILURE_WEBHOOK") or default_webhook

    # Check if enabled
    env_enabled = os.getenv(
        "SLACK_NOTIFICATIONS_ENABLED", "true").lower() == "true"
    notifications_enabled = enabled and env_enabled

    def decorator_start_processing(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper_start_processing(self, *args: Any, **kwargs: Any) -> Union[Any, asyncio.Future]:

            async def send_slack_notification(message: str, alert_type: int) -> None:
                """Send notification to appropriate Slack webhook based on alert type.

                Args:
                    message: Message to send
                    alert_type: 0 for success, 1 for failure
                """
                if not notifications_enabled:
                    return

                webhook = failure_url if alert_type == 1 else success_url

                if not webhook:
                    print("Warning: Slack webhook URL not configured")
                    return

                payload = {"text": message}

                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.post(webhook, json=payload) as response:
                            if response.status != 200:
                                print(
                                    f"Slack notification failed: {response.status}")
                except Exception as e:
                    print(f"Error sending Slack notification: {e}")

            def format_success_message(execution_obj: dict) -> tuple[str, int]:
                """Format success message from dictionary result."""
                function_name = func.__name__
                timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

                message = f"✅ *{function_name}* completed successfully\n"
                message += f"⏰ Time: {timestamp}\n"

                # Add execution details if available
                if "read_count" in execution_obj:
                    message += f"📖 Read: {execution_obj.get('read_count', 0)}\n"
                if "create_count" in execution_obj:
                    message += f"➕ Created: {execution_obj.get('create_count', 0)}\n"
                if "update_count" in execution_obj:
                    message += f"✏️ Updated: {execution_obj.get('update_count', 0)}\n"
                if "delete_count" in execution_obj:
                    message += f"🗑️ Deleted: {execution_obj.get('delete_count', 0)}\n"
                if "failure_count" in execution_obj:
                    message += f"❌ Failed: {execution_obj.get('failure_count', 0)}\n"

                if "custom_message" in execution_obj and execution_obj["custom_message"]:
                    message += f"\n💬 {execution_obj['custom_message']}"

                return message, 0

            def format_success_message_execution_result(execution_obj: ExecutionResult) -> tuple[str, int]:
                """Format success message from ExecutionResult object."""
                function_name = func.__name__

                message = f"✅ *{function_name}* completed successfully\n"
                message += f"⏰ Time: {execution_obj.execution_time}\n"
                message += f"📖 Read: {execution_obj.read_count}\n"
                message += f"➕ Created: {execution_obj.create_count}\n"
                message += f"✏️ Updated: {execution_obj.update_count}\n"
                message += f"🗑️ Deleted: {execution_obj.delete_count}\n"
                message += f"❌ Failed: {execution_obj.failure_count}\n"
                message += f"⏭️ No-op: {execution_obj.no_op_count}\n"

                if execution_obj.custom_message:
                    message += f"\n💬 {execution_obj.custom_message}"

                if execution_obj.azure_blob_storage:
                    message += f"\n📦 Blob: {execution_obj.azure_blob_storage}"

                return message, 0

            def format_failure_message(exception: Exception) -> str:
                """Format failure message from exception."""
                function_name = func.__name__
                timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

                message = f"🚨 *{function_name}* failed\n"
                message += f"⏰ Time: {timestamp}\n"
                message += f"❌ Error: {type(exception).__name__}\n"
                message += f"📝 Message: {str(exception)}"

                return message

            async def execute_async_function() -> Any:
                """Execute async function with error handling and notification sending."""
                try:
                    result = await func(self, *args, **kwargs)

                    # Format and send success notification
                    if isinstance(result, ExecutionResult):
                        message, alert_type = format_success_message_execution_result(
                            result)
                    elif isinstance(result, dict):
                        message, alert_type = format_success_message(result)
                    else:
                        message = f"✅ *{func.__name__}* completed successfully"
                        alert_type = 0

                    await send_slack_notification(message, alert_type)
                    return result

                except Exception as e:
                    # Send failure notification
                    message = format_failure_message(e)
                    await send_slack_notification(message, 1)
                    raise

            def execute_sync_function() -> Any:
                """Execute sync function with error handling and notification sending."""
                try:
                    result = func(self, *args, **kwargs)

                    # Format and send success notification
                    if isinstance(result, ExecutionResult):
                        message, alert_type = format_success_message_execution_result(
                            result)
                    elif isinstance(result, dict):
                        message, alert_type = format_success_message(result)
                    else:
                        message = f"✅ *{func.__name__}* completed successfully"
                        alert_type = 0

                    # Send notification synchronously
                    asyncio.run(send_slack_notification(message, alert_type))
                    return result

                except Exception as e:
                    # Send failure notification
                    message = format_failure_message(e)
                    asyncio.run(send_slack_notification(message, 1))
                    raise

            # Execute based on function type
            if asyncio.iscoroutinefunction(func):
                return execute_async_function()
            else:
                return execute_sync_function()

        return wrapper_start_processing
    return decorator_start_processing


def teams_notification(
    webhook_url: Optional[str] = None,
    enabled: bool = True
) -> Callable:
    """Decorator for automatic Microsoft Teams notifications on automation execution.

    Sends adaptive cards to Teams webhooks based on function execution results.
    Supports both sync and async functions, and handles ExecutionResult objects.

    Environment variables:
    - TEAMS_WEBHOOK_URL: Webhook URL for Teams notifications
    - TEAMS_NOTIFICATIONS_ENABLED: Enable/disable notifications (default: true)

    Args:
        webhook_url: Teams webhook URL (overrides TEAMS_WEBHOOK_URL)
        enabled: Enable/disable notifications

    Returns:
        Decorated function

    Example:
        ```python
        from jlframework import teams_notification, ExecutionResult

        @teams_notification()
        async def process_data():
            # Your automation logic
            return ExecutionResult(
                execution_time="2024-01-01 10:00:00",
                read_count=100,
                create_count=10,
                update_count=5
            )

        # Or with custom webhook
        @teams_notification(
            webhook_url="https://outlook.office.com/webhook/YOUR/WEBHOOK/URL"
        )
        def sync_process():
            return {"status": "completed", "count": 50}
        ```
    """
    # Load from environment if not provided
    teams_webhook = webhook_url or os.getenv("TEAMS_WEBHOOK_URL")

    # Check if enabled
    env_enabled = os.getenv(
        "TEAMS_NOTIFICATIONS_ENABLED", "true").lower() == "true"
    notifications_enabled = enabled and env_enabled

    def decorator_start_processing(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper_start_processing(self, *args: Any, **kwargs: Any) -> Union[Any, asyncio.Future]:

            async def send_teams_notification(message: str, is_success: int) -> None:
                """Send notification to Teams webhook.

                Args:
                    message: Message to send
                    is_success: 0 for success, 1 for failure
                """
                if not notifications_enabled:
                    return

                if not teams_webhook:
                    print("Warning: Teams webhook URL not configured")
                    return

                # Create adaptive card
                color = "Good" if is_success == 0 else "Attention"
                title = "✅ Success" if is_success == 0 else "🚨 Failure"

                card = {
                    "@type": "MessageCard",
                    "@context": "https://schema.org/extensions",
                    "themeColor": "00FF00" if is_success == 0 else "FF0000",
                    "title": title,
                    "text": message
                }

                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.post(teams_webhook, json=card) as response:
                            if response.status != 200:
                                print(
                                    f"Teams notification failed: {response.status}")
                except Exception as e:
                    print(f"Error sending Teams notification: {e}")

            def format_success_message(execution_obj: dict) -> tuple[str, int]:
                """Format success message from dictionary result."""
                function_name = func.__name__
                timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

                message = f"**{function_name}** completed successfully\n\n"
                message += f"⏰ **Time:** {timestamp}\n\n"

                # Add execution details if available
                if "read_count" in execution_obj:
                    message += f"📖 Read: {execution_obj.get('read_count', 0)}\n\n"
                if "create_count" in execution_obj:
                    message += f"➕ Created: {execution_obj.get('create_count', 0)}\n\n"
                if "update_count" in execution_obj:
                    message += f"✏️ Updated: {execution_obj.get('update_count', 0)}\n\n"
                if "delete_count" in execution_obj:
                    message += f"🗑️ Deleted: {execution_obj.get('delete_count', 0)}\n\n"
                if "failure_count" in execution_obj:
                    message += f"❌ Failed: {execution_obj.get('failure_count', 0)}\n\n"

                if "custom_message" in execution_obj and execution_obj["custom_message"]:
                    message += f"\n💬 {execution_obj['custom_message']}"

                return message, 0

            def format_success_message_execution_result(execution_obj: ExecutionResult) -> tuple[str, int]:
                """Format success message from ExecutionResult object."""
                function_name = func.__name__

                message = f"**{function_name}** completed successfully\n\n"
                message += f"⏰ **Time:** {execution_obj.execution_time}\n\n"
                message += f"📖 Read: {execution_obj.read_count}\n\n"
                message += f"➕ Created: {execution_obj.create_count}\n\n"
                message += f"✏️ Updated: {execution_obj.update_count}\n\n"
                message += f"🗑️ Deleted: {execution_obj.delete_count}\n\n"
                message += f"❌ Failed: {execution_obj.failure_count}\n\n"
                message += f"⏭️ No-op: {execution_obj.no_op_count}\n\n"

                if execution_obj.custom_message:
                    message += f"\n💬 {execution_obj.custom_message}"

                if execution_obj.azure_blob_storage:
                    message += f"\n\n📦 Blob: {execution_obj.azure_blob_storage}"

                return message, 0

            def format_failure_message(exception: Exception) -> str:
                """Format failure message from exception."""
                function_name = func.__name__
                timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

                message = f"**{function_name}** failed\n\n"
                message += f"⏰ **Time:** {timestamp}\n\n"
                message += f"❌ **Error:** {type(exception).__name__}\n\n"
                message += f"📝 **Message:** {str(exception)}"

                return message

            async def execute_async_function() -> Any:
                """Execute async function with error handling and notification sending."""
                try:
                    result = await func(self, *args, **kwargs)

                    # Format and send success notification
                    if isinstance(result, ExecutionResult):
                        message, alert_type = format_success_message_execution_result(
                            result)
                    elif isinstance(result, dict):
                        message, alert_type = format_success_message(result)
                    else:
                        message = f"**{func.__name__}** completed successfully"
                        alert_type = 0

                    await send_teams_notification(message, alert_type)
                    return result

                except Exception as e:
                    # Send failure notification
                    message = format_failure_message(e)
                    await send_teams_notification(message, 1)
                    raise

            def execute_sync_function() -> Any:
                """Execute sync function with error handling and notification sending."""
                try:
                    result = func(self, *args, **kwargs)

                    # Format and send success notification
                    if isinstance(result, ExecutionResult):
                        message, alert_type = format_success_message_execution_result(
                            result)
                    elif isinstance(result, dict):
                        message, alert_type = format_success_message(result)
                    else:
                        message = f"**{func.__name__}** completed successfully"
                        alert_type = 0

                    # Send notification synchronously
                    asyncio.run(send_teams_notification(message, alert_type))
                    return result

                except Exception as e:
                    # Send failure notification
                    message = format_failure_message(e)
                    asyncio.run(send_teams_notification(message, 1))
                    raise

            # Execute based on function type
            if asyncio.iscoroutinefunction(func):
                return execute_async_function()
            else:
                return execute_sync_function()

        return wrapper_start_processing
    return decorator_start_processing
