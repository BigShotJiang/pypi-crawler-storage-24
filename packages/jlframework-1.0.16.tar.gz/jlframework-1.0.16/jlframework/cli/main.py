"""Main CLI entry point for jlframework."""

import click
from jlframework.__version__ import __version__
from jlframework.cli.commands import init, add, list_templates


@click.group()
@click.version_option(version=__version__, prog_name="jlframework")
def cli():
    """JLFramework - A complete Python framework for full-stack development.

    Create production-ready FastAPI backends and Vue.js frontends with a single command.
    """
    pass


# Register commands
cli.add_command(init.init_command)
cli.add_command(add.add_command)
cli.add_command(list_templates.list_command)


if __name__ == "__main__":
    cli()
