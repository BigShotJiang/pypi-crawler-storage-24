"""Validation utilities for jlframework CLI."""

import re
from pathlib import Path


def validate_project_name(name: str) -> bool:
    """Validate project name.

    Args:
        name: Project name to validate

    Returns:
        True if valid, False otherwise
    """
    # Must be valid Python package name
    pattern = r'^[a-zA-Z][a-zA-Z0-9_-]*$'
    return bool(re.match(pattern, name))


def validate_jlframework_project() -> bool:
    """Check if current directory is a JLFramework project.

    Returns:
        True if valid JLFramework project, False otherwise
    """
    config_file = Path.cwd() / ".jlframework.json"
    return config_file.exists()
