"""File operation utilities for jlframework CLI."""

import shutil
from pathlib import Path


def create_directory(path: Path) -> None:
    """Create directory if it doesn't exist.

    Args:
        path: Directory path to create
    """
    path.mkdir(parents=True, exist_ok=True)


def copy_file(src: Path, dest: Path) -> None:
    """Copy file from source to destination.

    Args:
        src: Source file path
        dest: Destination file path
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)


def copy_directory(src: Path, dest: Path) -> None:
    """Copy directory recursively.

    Args:
        src: Source directory path
        dest: Destination directory path
    """
    shutil.copytree(src, dest, dirs_exist_ok=True)


def delete_directory(path: Path) -> None:
    """Delete directory and all contents.

    Args:
        path: Directory path to delete
    """
    if path.exists():
        shutil.rmtree(path)
