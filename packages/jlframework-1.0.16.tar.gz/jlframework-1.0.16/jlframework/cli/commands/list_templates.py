"""List command for jlframework CLI."""

import click

from jlframework.cli.utils.template_manager import get_available_templates


@click.command(name="list")
def list_command():
    """List all available templates.

    Shows all templates that can be added to your project with the 'add' command.

    Example:
        jlframework list
    """

    click.echo("\n[TEMPLATES] Available templates:\n")

    templates = get_available_templates()

    for template in templates:
        click.echo(f"  {click.style(template['name'], fg='cyan', bold=True)}")
        click.echo(f"    {template['description']}")
        click.echo()

    click.echo(
        f"[TIP] Add a template with: {click.style('jlframework add <template-name>', fg='green')}")
