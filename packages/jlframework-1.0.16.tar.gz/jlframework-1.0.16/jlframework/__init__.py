"""JLFramework - A comprehensive framework for FastAPI and Vue.js applications.

This package provides:
- CLI tools for project initialization and template management
- Core utilities for database, handlers, middleware, and enums
- Reusable components for multi-tenant applications
- Django-like import patterns for common functionality
- Azure integration (App Configuration, Blob Storage)
- Common utilities for automation workflows
- SMS, SharePoint, Notifications, SQL Manager, GraphQL, and Automation modules
- Unified configuration management and base manager classes (v1.0.11+)
"""

from jlframework.__version__ import __version__

# Configuration Management (v1.0.11+)
from jlframework.core.config_manager import ConfigurationManager, ConfigurationKeys

# Base Manager Classes (v1.0.11+)
from jlframework.core.base_manager import (
    BaseManager,
    BaseAzureManager,
    BaseAPIManager,
    BaseDatabaseManager,
    SingletonMeta,
)

# Database utilities
from jlframework.core.database import (
    close_db_session,
    database_middleware,
    get_db,
    get_db_session,
    get_request_db,
    initialize_database,
)

# Azure database initialization
from jlframework.core.azure_db import initialize_database_from_azure

# Enums (legacy from handlers module)
from jlframework.core.enums import AuditAction as LegacyAuditAction, AuditStatus as LegacyAuditStatus, EntityType as LegacyEntityType

# Handlers (legacy)
from jlframework.core.handlers import AuditData as LegacyAuditData, AuditManager as LegacyAuditManager, CommonManager as LegacyCommonManager

# Middleware
from jlframework.core.middleware import (
    get_tenant_id,
    restrict_access_middleware,
)

# API Client
from jlframework.core.api_client import (
    ApiError,
    MainSubSysApiManager,
    RequestType,
    retry_with_backoff,
)

# Utilities
from jlframework.core.utils import deprecated

# Common utilities
from jlframework.core.common_utils import (
    ExecutionResult,
    ReportStatus,
    ReportRequestError,
    ReportStatusError,
    WINDOWS_TO_IANA,
    get_iana_timezone,
    AuditStatus,
    AuditAction,
    EntityType,
)

# GraphQL Client
from jlframework.core.graphql_client import GraphQLServiceManager, TokenGenerationError

# Common Handler (Automation utilities)
from jlframework.core.common_handler import CommonManager

# Audit Handler
from jlframework.core.audit_handler import AuditManager, AuditData

# Automation Handler
from jlframework.core.automation_handler import AutomationManager, AutomationDetails

# Azure Blob Storage
from jlframework.core.blob_storage import BlobStorageManager

# SMS Handler
from jlframework.core.sms_handler import SMSHandler

# SharePoint Manager
from jlframework.core.sharepoint import (
    SharePointManager,
    ContentType,
    GraphMethod,
    graph_request,
)

# Notification Decorators
from jlframework.core.notifications import (
    slack_notification,
    teams_notification,
)

# SQL Manager
from jlframework.core.sql_manager import SqlManager

# Configuration
from jlframework.core.config import Settings, get_settings

__all__ = [
    # Version
    "__version__",
    # Database
    "initialize_database",
    "initialize_database_from_azure",
    "get_db",
    "get_db_session",
    "close_db_session",
    "get_request_db",
    "database_middleware",
    # Enums (from common_utils - new comprehensive enums)
    "AuditStatus",
    "AuditAction",
    "EntityType",
    # Legacy Enums (from enums module - for backward compatibility)
    "LegacyAuditStatus",
    "LegacyAuditAction",
    "LegacyEntityType",
    # Handlers (new automation handlers)
    "CommonManager",
    "AuditManager",
    "AuditData",
    "AutomationManager",
    "AutomationDetails",
    # Legacy Handlers (for backward compatibility)
    "LegacyCommonManager",
    "LegacyAuditManager",
    "LegacyAuditData",
    # Middleware
    "restrict_access_middleware",
    "get_tenant_id",
    # API Client
    "MainSubSysApiManager",
    "RequestType",
    "ApiError",
    "retry_with_backoff",
    # Utilities
    "deprecated",
    # Common Utilities
    "ExecutionResult",
    "ReportStatus",
    "ReportRequestError",
    "ReportStatusError",
    "WINDOWS_TO_IANA",
    "get_iana_timezone",
    # Azure Blob Storage
    "BlobStorageManager",
    # SMS Handler
    "SMSHandler",
    # SharePoint Manager
    "SharePointManager",
    "ContentType",
    "GraphMethod",
    "graph_request",
    # Notification Decorators
    "slack_notification",
    "teams_notification",
    # SQL Manager
    "SqlManager",
    # GraphQL Client
    "GraphQLServiceManager",
    "TokenGenerationError",
    # Configuration
    "Settings",
    "get_settings",
    # Configuration Management (v1.0.11+)
    "ConfigurationManager",
    "ConfigurationKeys",
    # Base Manager Classes (v1.0.11+)
    "BaseManager",
    "BaseAzureManager",
    "BaseAPIManager",
    "BaseDatabaseManager",
    "SingletonMeta",
]
