import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.colors as mcolors
import matplotlib.figure as mfigure
import matplotlib.axes as maxes
import matplotlib.collections as mcollections
import matplotlib.transforms as mtransforms
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import geopandas as gpd
from . import colorbar as clb

def plot_maps(
    nrows: int = 1,
    ncols: int = 1,
    figsize: tuple[float, float] = (8, 8),
    west: float = 100,
    east: float = 137,
    south: float = 16,
    north: float = 54,
    gridlines: bool = True,
    gridstep: float = 10,
) -> tuple[mfigure.Figure, np.ndarray]:
    """
    Plot subplots.
    Args:
        nrows: The number of rows of the subplots.
        ncols: The number of columns of the subplots.
        figsize: The size of the maps.
        west: The west bound of the maps.
        east: The east bound of the maps.
        south: The south bound of the maps.
        north: The north bound of the maps.
        gridlines: Whether to plot gridlines.
        gridstep: The step of the gridlines.
    Returns:
        A tuple of the figure and the axes.
    """
    fig, axes = plt.subplots(
        nrows = nrows,
        ncols = ncols,
        figsize = (figsize[0] * ncols, figsize[1] * nrows),
        squeeze = False,
        subplot_kw = {'projection': ccrs.PlateCarree(central_longitude = (west + east) / 2)}
    )

    for i in range(nrows):
        for j in range(ncols):
            ax = axes[i, j]
            ax.set_extent([west, east, south, north], crs = ccrs.PlateCarree())
            ax.add_feature(cfeature.COASTLINE, linewidth = 0.8)
            ax.add_feature(cfeature.BORDERS, linestyle = ':', linewidth = 0.8)
            if gridlines:
                gl = ax.gridlines(crs = ccrs.PlateCarree(), draw_labels = True, linewidth = 1, color = 'gray', alpha = 0.5, linestyle = '--')
                gl.top_labels = False
                gl.right_labels = False
                gl.xlocator = mticker.FixedLocator(np.arange(np.ceil(west / gridstep) * gridstep, np.floor(east / gridstep) * gridstep + gridstep, gridstep))
                gl.ylocator = mticker.FixedLocator(np.arange(np.ceil(south / gridstep) * gridstep, np.floor(north / gridstep) * gridstep + gridstep, gridstep))
                gl.xlabel_style = {'size': 10}
                gl.ylabel_style = {'size': 10}

    return fig, axes.flatten()

def plot_map(
    figsize: tuple[float, float] = (8, 8),
    west: float = 100,
    east: float = 137,
    south: float = 16,
    north: float = 54,
    gridlines: bool = True,
) -> tuple[mfigure.Figure, maxes.Axes]:
    """
    Plot a map.
    Args:
        figsize: The size of the figure.
        west: The west bound of the map.
        east: The east bound of the map.
        south: The south bound of the map.
        north: The north bound of the map.
        gridlines: Whether to plot gridlines.
    Returns:
        A tuple of the figure and the axes.
    """
    fig, axes = plot_maps(1, 1, figsize, west, east, south, north, gridlines)
    return fig, axes[0]

def plot_provinces(axes: maxes.Axes | np.ndarray, file: str = 'JSON/china_provinces.json') -> None:
    """
    Plot the provinces of China on the map.
    Args:
        axes: The axes to plot on.
        file: The file to read the provinces from.
    Returns:
        None.
    """
    provinces = gpd.read_file(file)
    if isinstance(axes, maxes.Axes):
        axes = np.array([axes])
    for ax in axes:
        provinces.boundary.plot(ax = ax, edgecolor = 'gray', linewidth = 0.5, transform = ccrs.PlateCarree())

def get_colorbar(
    bounds: list[float] | str = 'O3',
    colors: list[str] | str = 'AQI'
) -> tuple[mcolors.ListedColormap, mcolors.BoundaryNorm]:
    """
    Get the color map and the norm for the colorbar.
    Args:
        bounds: The bounds of the colorbar.
        colors: The colors of the colorbar.
    Returns:
        A tuple of the color map and the norm.
    """
    if isinstance(bounds, str):
        if bounds in clb.bounds:
            bounds = clb.bounds[bounds]
        else:
            raise ValueError(f"Invalid bounds: {bounds}")
    if isinstance(colors, str):
        if colors in clb.colors:
            colors = clb.colors[colors]
        else:
            raise ValueError(f"Invalid colors: {colors}")

    cmap = mcolors.ListedColormap(colors)
    norm = mcolors.BoundaryNorm(bounds, cmap.N)

    return cmap, norm

def plot_colorbar(
    sc: mcollections.PathCollection,
    ax: maxes.Axes = None,
    cax: maxes.Axes = None,
    orientation: str = 'vertical',
    extend: str = 'neither',
    pad: float = 0.02,
    aspect: float = 30,
    fraction: float = 0.02,
    label: str = 'MDA8 (μg $\\cdot$ m$^{-3}$)',
    fontsize: float = 12,
    labelsize: float = 10,
) -> None:
    """
    Plot a colorbar.
    Args:
        sc: The scatter plot.
        ax: The axes to plot on.
        cax: The axes to plot the colorbar on.
        orientation: The orientation of the colorbar.
        pad: The padding of the colorbar.
        aspect: The aspect ratio of the colorbar.
        fraction: The fraction of the colorbar.
        label: The label of the colorbar.
        fontsize: The fontsize of the label.
        labelsize: The fontsize of the tick labels.
    Returns:
        None.
    """
    cbar = plt.colorbar(sc, ax = ax, cax = cax, orientation = orientation, extend = extend, pad = pad, aspect = aspect, fraction = fraction)
    cbar.set_label(label, fontsize = fontsize)
    cbar.ax.tick_params(labelsize = labelsize)

def save_fig(filename: str, dpi: float = 300, bbox_inches: None | mtransforms.Bbox | str = 'tight') -> None:
    """
    Save the figure.
    Args:
        filename: The filename of the figure.
        dpi: The DPI of the figure.
        bbox_inches: The bounding box inches of the figure.
    Returns:
        None.
    """
    plt.savefig(filename, dpi = dpi, bbox_inches = bbox_inches)
    plt.close()