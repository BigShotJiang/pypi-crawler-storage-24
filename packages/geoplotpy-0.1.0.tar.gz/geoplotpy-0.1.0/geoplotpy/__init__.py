"""
geoplotpy is a library for plotting geography maps.

Example:
    >>> import geoplotpy as gpp
    >>> fig, ax = gpp.plot_map()
    >>> gpp.save_fig('map.png')

Version:
    0.1.0
"""

__version__ = '0.1.0'

from .plot import (
    plot_maps,
    plot_map,
    plot_provinces,
    get_colorbar,
    plot_colorbar,
    save_fig
)

__all__ = [
    'plot_maps',
    'plot_map',
    'plot_provinces',
    'get_colorbar',
    'plot_colorbar',
    'save_fig',
    '__version__'
]