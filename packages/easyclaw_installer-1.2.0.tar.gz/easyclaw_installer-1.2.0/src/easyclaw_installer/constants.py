"""Shared constants for the EasyClaw installer."""

# OpenRouter API
OPENROUTER_BASE = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL = "minimax/minimax-m2.5"

# Built-in agent key — MiniMax 2.5 via OpenRouter (used when no --api-key given)
BUILTIN_API_KEY = "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"

# Free key for OpenClaw's own LLM config (not the installer agent)
OPENCLAW_FREE_KEY = "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"

# Agent limits
MAX_TOOL_ITERATIONS = 150  # generous for long troubleshooting sessions
AGENT_HTTP_TIMEOUT = 300   # seconds for streaming response (5 minutes)
AGENT_MAX_RETRIES = 3      # retry on 5xx / timeout / connection error

# Conversation history cap (keep recent, always regenerate system prompt)
MAX_CONVERSATION_MESSAGES = 100

# MCP Knowledge Base
DEFAULT_MCP_URL = "https://mcp.easyclaw.help"
MCP_HTTP_TIMEOUT = 60  # seconds for MCP JSON-RPC calls

# Install steps (used for progress tracking and system prompt)
INSTALL_STEPS = [
    "Preflight Checks",
    "Install Node.js 22",
    "Install @openclaw/cli",
    "Config Init & Write",
    "Token Generate",
    "Environment Setup",
    "Workspace Init",
    "Gateway Install & Configure",
    "Service Install",
    "Health Check",
]
