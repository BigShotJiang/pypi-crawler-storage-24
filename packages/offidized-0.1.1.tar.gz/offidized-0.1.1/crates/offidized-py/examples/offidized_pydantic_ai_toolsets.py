"""Minimal end-to-end PydanticAI example for offidized.

Run from the offidized-py crate directory:
    cd crates/offidized-py && uv run python examples/offidized_pydantic_ai_toolsets.py
"""

from pathlib import Path

from pydantic_ai import Agent

from offidized.pydantic_ai import all_toolsets

root = Path(__file__).resolve().parents[1]
gallery = root / "examples" / "gallery" / "output"
out = root / "examples" / "pydantic_ai_output"
out.mkdir(parents=True, exist_ok=True)

agent = Agent(
    "openai:gpt-5.4",
    system_prompt="Read existing Office files with offidized tools, then save edits to the requested output paths.",
    toolsets=[all_toolsets()],
)

result = agent.run_sync(
    f"""
Use the tools for these existing files:

- XLSX: {gallery / "12_ir_source.xlsx"}
  Read the workbook, then save {out / "agent_updated.xlsx"} with B2 = "Updated by PydanticAI".

- DOCX: {gallery / "01_styled_document.docx"}
  Preview the document, then save {out / "agent_updated.docx"} with a new paragraph: "Added by PydanticAI".

- PPTX: {gallery / "01_styled_shapes.pptx"}
  List the slides, then save {out / "agent_updated.pptx"} with a new slide titled "Agent Update".

Keep the final answer short and include what you read plus the three output paths.
"""
)

print(result.output)
