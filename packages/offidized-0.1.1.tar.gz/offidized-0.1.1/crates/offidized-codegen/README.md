# offidized-codegen

Code generator that transforms XSD/JSON schema definitions into Rust structs for OOXML elements.

Part of [offidized](../../README.md).

## Overview

Reads vendored schema data from `crates/offidized-schema/data/` and generates the typed structs used by `offidized-schema`. Runs at build time (via `build.rs`), not as a proc macro, to keep CI fast.
