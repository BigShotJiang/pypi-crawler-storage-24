from ._openai_api import OpenAIAPIProvider
import os

# Model list: https://www.alibabacloud.com/help/en/model-studio/getting-started/models


class Fireworks(OpenAIAPIProvider):
    def __init__(self, model: str, api_key: str | None = None):
        api_key = api_key or os.environ.get("FIREWORKS_API_KEY")
        if not api_key:
            raise ValueError("FIREWORKS_API_KEY environment variable not set")
        base_url = "https://api.fireworks.ai/inference/v1"
        super().__init__(
            name="fireworks", model=model, api_key=api_key, base_url=base_url
        )
