// RUN: XDSL_ROUNDTRIP
// RUN: XDSL_GENERIC_ROUNDTRIP
// RUN: JAX_ROUNDTRIP
// RUN: JAX_GENERIC_ROUNDTRIP
// RUN: XDSL_JAX_ROUNDTRIP
// RUN: XDSL_JAX_GENERIC_ROUNDTRIP

// CHECK: %[[REDUCE_INPUT0:[^ ]+]] = "test.op"() : () -> tensor<2x3xi64>
// CHECK-GENERIC: %[[REDUCE_INPUT0:[^ ]+]] = "test.op"() : () -> tensor<2x3xi64>
%reduce_input0 = "test.op"() : () -> tensor<2x3xi64>
// CHECK: %[[REDUCE_INPUT1:[^ ]+]] = "test.op"() : () -> tensor<2x3xi64>
// CHECK-GENERIC: %[[REDUCE_INPUT1:[^ ]+]] = "test.op"() : () -> tensor<2x3xi64>
%reduce_input1 = "test.op"() : () -> tensor<2x3xi64>
// CHECK: %[[REDUCE_INIT0:[^ ]+]] = "test.op"() : () -> tensor<i64>
// CHECK-GENERIC: %[[REDUCE_INIT0:[^ ]+]] = "test.op"() : () -> tensor<i64>
%reduce_init0 = "test.op"() : () -> tensor<i64>
// CHECK: %[[REDUCE_INIT1:[^ ]+]] = "test.op"() : () -> tensor<i64>
// CHECK-GENERIC: %[[REDUCE_INIT1:[^ ]+]] = "test.op"() : () -> tensor<i64>
%reduce_init1 = "test.op"() : () -> tensor<i64>

// CHECK: %[[REDUCE_MULTI:[^ ]+]] = stablehlo.reduce(%[[REDUCE_INPUT0:[^ )]+]] init: %[[REDUCE_INIT0:[^ )]+]]), (%[[REDUCE_INPUT1:[^ )]+]] init: %[[REDUCE_INIT1:[^ )]+]])
// CHECK-SAME: across dimensions = [1] : (tensor<2x3xi64>, tensor<2x3xi64>, tensor<i64>, tensor<i64>) -> (tensor<2xi64>, tensor<2xi64>)
// CHECK-NEXT: reducer(%[[REDUCE_ARG0:.*]]: tensor<i64>, %[[REDUCE_ARG2:.*]]: tensor<i64>) (%[[REDUCE_ARG1:.*]]: tensor<i64>, %[[REDUCE_ARG3:.*]]: tensor<i64>) {
// CHECK:   stablehlo.return %[[REDUCE_RET0:.*]], %[[REDUCE_RET1:.*]] : tensor<i64>, tensor<i64>
// CHECK: }
// CHECK-GENERIC: %[[REDUCE_MULTI:[^ ]+]] = "stablehlo.reduce"(%[[REDUCE_INPUT0]], %[[REDUCE_INPUT1]], %[[REDUCE_INIT0]], %[[REDUCE_INIT1]]) <{dimensions = array<i64: 1>}> ({
// CHECK-GENERIC:   ^bb[[REDUCE_MULTI_BB:[0-9]+]](%[[REDUCE_GEN_ARG0:.*]]: tensor<i64>, %[[REDUCE_GEN_ARG1:.*]]: tensor<i64>, %[[REDUCE_GEN_ARG2:.*]]: tensor<i64>, %[[REDUCE_GEN_ARG3:.*]]: tensor<i64>):
// CHECK-GENERIC:     "stablehlo.return"(%[[REDUCE_GEN_RET0:.*]], %[[REDUCE_GEN_RET1:.*]]) : (tensor<i64>, tensor<i64>) -> ()
// CHECK-GENERIC: }) : (tensor<2x3xi64>, tensor<2x3xi64>, tensor<i64>, tensor<i64>) -> (tensor<2xi64>, tensor<2xi64>)
%reduce_multi_0, %reduce_multi_1 = stablehlo.reduce (%reduce_input0 init: %reduce_init0), (%reduce_input1 init: %reduce_init1) across dimensions = [1] : (tensor<2x3xi64>, tensor<2x3xi64>, tensor<i64>, tensor<i64>) -> (tensor<2xi64>, tensor<2xi64>)
reducer (%reduce_arg0 : tensor<i64>, %reduce_arg1 : tensor<i64>) (%reduce_arg2 : tensor<i64>, %reduce_arg3 : tensor<i64>) {
  stablehlo.return %reduce_arg0, %reduce_arg2 : tensor<i64>, tensor<i64>
}

%dot_lhs = "test.op"() : () -> tensor<2x3xi32>
%dot_rhs = "test.op"() : () -> tensor<3x4xi32>
// CHECK: %[[DOT_NO_ALGORITHM:[^ ]+]] = stablehlo.dot_general %[[DOT_LHS:[^,]+]], %[[DOT_RHS:[^,]+]], contracting_dims = [1] x [0] : (tensor<2x3xi32>, tensor<3x4xi32>) -> tensor<2x4xi32>
// CHECK-GENERIC: %[[DOT_NO_ALGORITHM_GEN:[^ ]+]] = "stablehlo.dot_general"(%[[DOT_LHS_GEN:[^,]+]], %[[DOT_RHS_GEN:[^)]+]])
// CHECK-GENERIC-DAG: dot_dimension_numbers = #stablehlo.dot<lhs_contracting_dimensions = [1], rhs_contracting_dimensions = [0]>
// CHECK-GENERIC: : (tensor<2x3xi32>, tensor<3x4xi32>) -> tensor<2x4xi32>
%dot_no_algorithm = stablehlo.dot_general %dot_lhs, %dot_rhs, batching_dims = [] x [], contracting_dims = [1] x [0] : (tensor<2x3xi32>, tensor<3x4xi32>) -> tensor<2x4xi32>

// CHECK: %[[DOT_WITH_ALGORITHM:[^ ]+]] = stablehlo.dot_general %[[DOT_LHS]], %[[DOT_RHS]], contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT],
// CHECK-SAME: algorithm = <lhs_precision_type = f32, rhs_precision_type = f32, accumulation_type = f32, lhs_component_count = 1, rhs_component_count = 1, num_primitive_operations = 1, allow_imprecise_accumulation = false>
// CHECK-SAME: : (tensor<2x3xi32>, tensor<3x4xi32>) -> tensor<2x4xi32>
// CHECK-GENERIC: %[[DOT_WITH_ALGORITHM_GEN:[^ ]+]] = "stablehlo.dot_general"(%[[DOT_LHS_GEN]], %[[DOT_RHS_GEN]])
// CHECK-GENERIC-DAG: dot_dimension_numbers = #stablehlo.dot<lhs_contracting_dimensions = [1], rhs_contracting_dimensions = [0]>
// CHECK-GENERIC-DAG: precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]
// CHECK-GENERIC-DAG: algorithm = #stablehlo.dot_algorithm<lhs_precision_type = f32, rhs_precision_type = f32, accumulation_type = f32, lhs_component_count = 1, rhs_component_count = 1, num_primitive_operations = 1, allow_imprecise_accumulation = false>
// CHECK-GENERIC: : (tensor<2x3xi32>, tensor<3x4xi32>) -> tensor<2x4xi32>
%dot = stablehlo.dot_general %dot_lhs, %dot_rhs, batching_dims = [] x [], contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT], algorithm = <lhs_precision_type = f32, rhs_precision_type = f32, accumulation_type = f32, lhs_component_count = 1, rhs_component_count = 1, num_primitive_operations = 1, allow_imprecise_accumulation = false> : (tensor<2x3xi32>, tensor<3x4xi32>) -> tensor<2x4xi32>

%dot_batch_lhs = "test.op"() : () -> tensor<2x3x4xi32>
%dot_batch_rhs = "test.op"() : () -> tensor<2x4x5xi32>
// CHECK-GENERIC: %[[DOT_BATCHED_GEN:[^ ]+]] = "stablehlo.dot_general"(%[[DOT_BATCH_LHS_GEN:[^,]*]], %[[DOT_BATCH_RHS_GEN:[^)]*]])
// CHECK-GENERIC-DAG: dot_dimension_numbers = #stablehlo.dot<lhs_batching_dimensions = [0], rhs_batching_dimensions = [0], lhs_contracting_dimensions = [2], rhs_contracting_dimensions = [1]>
// CHECK-GENERIC-DAG: algorithm = #stablehlo.dot_algorithm<lhs_precision_type = f32, rhs_precision_type = f32, accumulation_type = f32, lhs_component_count = 1, rhs_component_count = 1, num_primitive_operations = 1, allow_imprecise_accumulation = false>
// CHECK-GENERIC: : (tensor<2x3x4xi32>, tensor<2x4x5xi32>) -> tensor<2x3x5xi32>
%dot_with_batching_and_algorithm = stablehlo.dot_general %dot_batch_lhs, %dot_batch_rhs, batching_dims = [0] x [0], contracting_dims = [2] x [1], algorithm = <lhs_precision_type = f32, rhs_precision_type = f32, accumulation_type = f32, lhs_component_count = 1, rhs_component_count = 1, num_primitive_operations = 1, allow_imprecise_accumulation = false> : (tensor<2x3x4xi32>, tensor<2x4x5xi32>) -> tensor<2x3x5xi32>
