
# auto-generated; do not edit

commits = {
    "ROCm/xla": "6277a39fecc451f7cc759a0bbc314f4b2947a482",
    "ROCm/rocm-jax": "01e6a1d401cf46e2ceb4788b0668f06b4bba5f9e",
    "jax": "32ba3e9524b0089eed8fe309468de523e4157023",
}
