# SPDX-FileCopyrightText: 2024 Idiap Research Institute <contact@idiap.ch>
# SPDX-FileContributor: Amir Mohammadi  <amir.mohammadi@idiap.ch>
#
# SPDX-License-Identifier: GPL-3.0-or-later

import json
import pydoc
import shutil
import tempfile

from collections import defaultdict
from pathlib import Path
from typing import Optional

import click


class CustomGroup(click.Group):
    """Custom command group that does not sort commands."""

    def list_commands(self, ctx: click.Context) -> list[str]:
        # do not sort the commands
        return self.commands

    def get_command(self, ctx, cmd_name):
        """get_command with prefix aliasing and name aliases."""
        cmd_name = {
            "sbatch": "submit",
            "ls": "list",
            "rm": "delete",
            "remove": "delete",
        }.get(cmd_name, cmd_name)
        rv = click.Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv
        matches = [x for x in self.list_commands(ctx) if x.startswith(cmd_name)]
        if not matches:
            return None

        if len(matches) == 1:
            return click.Group.get_command(self, ctx, matches[0])

        ctx.fail(f"Too many matches: {', '.join(sorted(matches))}")  # noqa: RET503


def parse_job_ids(job_ids: str) -> list[int]:
    """Parse the job ids."""
    if not job_ids:
        return []
    try:
        if "," in job_ids:
            final_job_ids = []
            for job_id in job_ids.split(","):
                final_job_ids.extend(parse_job_ids(job_id))
            return final_job_ids
        if "-" in job_ids:
            start, end_str = job_ids.split("-")
            return list(range(int(start), int(end_str) + 1))
        if "+" in job_ids:
            start, length = job_ids.split("+")
            end = int(start) + int(length)
            return list(range(int(start), end + 1))
        return [int(job_ids)]
    except ValueError as e:
        raise click.BadParameter(f"Invalid job id {job_ids}") from e


def parse_states(states: str) -> list[str]:
    """Normalize a list of comma-separated states to their long name format."""
    from .models import JOB_STATES_MAPPING

    if not states:
        return []
    states = states.upper()
    if states == "ALL":
        return list(JOB_STATES_MAPPING.values())
    final_states = []
    for state in states.split(","):
        state = JOB_STATES_MAPPING.get(state, state)
        if state not in JOB_STATES_MAPPING.values():
            raise click.BadParameter(
                f"Invalid state: {state}\nValid values are: ALL {' '.join(list(JOB_STATES_MAPPING.keys())+list(JOB_STATES_MAPPING.values()))} or a comma (,) separated list of them."
            )
        final_states.append(state)
    return final_states


def job_ids_callback(ctx, param, value):
    """Implement a callback for the job ids option."""
    return parse_job_ids(value)


def states_callback(ctx, param, value):
    """Implement a callback for the states option."""
    return parse_states(value)


def no_jobs_message(
    action: str,
    *,
    default_states: bool = False,
) -> str:
    """Build a helpful message when no jobs match the given filters."""
    msg = f"No jobs were {action}."
    if default_states:
        msg += (
            " Note: the default state filter is active."
            " Use --state all to include all jobs."
        )
    return msg


def job_filters(f_py=None, default_states=None):
    """Filter jobs based on the provided function and default states."""
    assert callable(f_py) or f_py is None
    from .models import JOB_STATES_MAPPING

    def _job_filters_decorator(function):
        function = click.option(
            "--name",
            "names",
            multiple=True,
            help="Selects jobs based on their name. For multiple names, repeat this option.",
        )(function)
        function = click.option(
            "-s",
            "--state",
            "states",
            default=default_states,
            help="Selects jobs based on their states separated by comma. Possible values are "
            + ", ".join([f"{v} ({k})" for k, v in JOB_STATES_MAPPING.items()])
            + " and ALL.",
            callback=states_callback,
        )(function)
        function = click.option(
            "-j",
            "--jobs",
            "job_ids",
            help=(
                "Selects only these job ids, separated by comma. A range can also be "
                "specified in the form 'start-end' ('-j 3-5' is equivalent to "
                "'-j 3,4,5') or in the form 'start+length' ('-j 4+3' is equivalent to "
                "'-j 4,5,6,7')."
            ),
            callback=job_ids_callback,
        )(function)
        function = click.option(
            "--dependents/--no-dependents",
            default=False,
            help="Select dependents jobs (jobs that depend on selected jobs) as well.",
        )(function)
        return function  # noqa: RET504

    return _job_filters_decorator(f_py) if callable(f_py) else _job_filters_decorator


@click.group(
    cls=CustomGroup,
    context_settings={
        "show_default": True,
        "help_option_names": ["--help", "-h"],
        "auto_envvar_prefix": "GRIDTK",
    },
)
@click.option(
    "-d",
    "--database",
    help="Path to the database file.",
    default=Path("jobs.sql3"),
    type=click.Path(path_type=Path, file_okay=True, dir_okay=False),
)
@click.option(
    "-l",
    "--logs-dir",
    help="Path to the logs directory.",
    default=Path("logs"),
    type=click.Path(path_type=Path, file_okay=False, dir_okay=True),
)
@click.pass_context
def cli(ctx, database, logs_dir):
    """GridTK command line interface."""
    from .manager import JobManager

    ctx.meta["job_manager"] = JobManager(database=database, logs_dir=logs_dir)


@cli.result_callback()
def process_result(result, **kwargs):
    """Clean up empty databases and dispose the job manager."""
    ctx = click.get_current_context()
    job_manager = ctx.meta.pop("job_manager")
    job_manager.cleanup_empty_database()


@cli.command(
    epilog="""\b
Example:
gridtk submit my_script.sh
gridtk submit --- python my_code.py
""",
    context_settings=dict(
        ignore_unknown_options=True,
        # allow_extra_args=True,
        allow_interspersed_args=False,
    ),
)
@click.option(
    "-J",
    "--job-name",
    default="gridtk",
    help="Specify a name for the job allocation. The specified name will appear along with the job id number when querying running jobs on the system.",
)
@click.option(
    "-a",
    "--array",
    help='Submit a job array, multiple jobs to be executed with identical parameters. The indexes specification identifies what array index values should be used. Multiple values may be specified using a comma separated list and/or a range of values with a "-" separator. For example, "--array=0-15" or "--array=0,6,16-32". A step function can also be specified with a suffix containing a colon and number. For example, "--array=0-15:4" is equivalent to "--array=0,4,8,12". A maximum number of simultaneously running tasks from the job array may be specified using a "%" separator. For example "--array=0-15%4" will limit the number of simultaneously running tasks from this job array to 4. The minimum index value is 0. the maximum value is one less than the configuration parameter MaxArraySize. NOTE: Currently, federated job arrays only run on the local cluster.',
)
@click.option(
    "-d",
    "--dependency",
    "dependencies",
    help="Depend on other jobs that are already in the list of gridtk.",
)
@click.option(
    "--repeat",
    default=1,
    type=click.INT,
    help="Submits the job N times. Each job will depend on the job before.",
)
# sbatch options
@click.option("-A", "--account", hidden=True)
@click.option("--acctg-freq", hidden=True)
@click.option("--batch", hidden=True)
@click.option("--bb", hidden=True)
@click.option("--bbf", hidden=True)
@click.option("-b", "--begin", hidden=True)
@click.option("-D", "--chdir", hidden=True)
@click.option("--cluster-constraint", hidden=True)
@click.option("-M", "--clusters", hidden=True)
@click.option("--comment", hidden=True)
@click.option("-C", "--constraint", hidden=True)
@click.option("--container", hidden=True)
@click.option("--container-id", hidden=True)
@click.option("--contiguous", is_flag=True, hidden=True)
@click.option("-S", "--core-spec", hidden=True)
@click.option("--cores-per-socket", hidden=True)
@click.option("--cpu-freq", hidden=True)
@click.option("--cpus-per-gpu", hidden=True)
@click.option("-c", "--cpus-per-task", hidden=True)
@click.option("--deadline", hidden=True)
@click.option("--delay-boot", hidden=True)
@click.option("-m", "--distribution", hidden=True)
@click.option("-e", "--error", hidden=True)
@click.option("-x", "--exclude", hidden=True)
@click.option("--exclusive", hidden=True)
@click.option("--export", hidden=True)
@click.option("--export-file", hidden=True)
@click.option("--extra", hidden=True)
@click.option("-B", "--extra-node-info", hidden=True)
@click.option("--get-user-env", hidden=True)
@click.option("--gid", hidden=True)
@click.option("--gpu-bind", hidden=True)
@click.option("--gpu-freq", hidden=True)
@click.option("-G", "--gpus", hidden=True)
@click.option("--gpus-per-node", hidden=True)
@click.option("--gpus-per-socket", hidden=True)
@click.option("--gpus-per-task", hidden=True)
@click.option("--gres", hidden=True)
@click.option("--gres-flags", hidden=True)
@click.option("--hint", hidden=True)
@click.option("-H", "--hold", is_flag=True, hidden=True)
@click.option("--ignore-pbs", is_flag=True, hidden=True)
@click.option("-i", "--input", hidden=True)
@click.option("--kill-on-invalid-dep", hidden=True)
@click.option("-L", "--licenses", hidden=True)
@click.option("--mail-type", hidden=True)
@click.option("--mail-user", hidden=True)
@click.option("--mcs-label", hidden=True)
@click.option("--mem", hidden=True)
@click.option("--mem-bind", hidden=True)
@click.option("--mem-per-cpu", hidden=True)
@click.option("--mem-per-gpu", hidden=True)
@click.option("--mincpus", hidden=True)
@click.option("--network", hidden=True)
@click.option("--nice", hidden=True)
@click.option("-k", "--no-kill", is_flag=True, hidden=True)
@click.option("--no-requeue", is_flag=True, hidden=True)
@click.option("-F", "--nodefile", hidden=True)
@click.option("-w", "--nodelist", hidden=True)
@click.option("-N", "--nodes", hidden=True)
@click.option("-n", "--ntasks", hidden=True)
@click.option("--ntasks-per-core", hidden=True)
@click.option("--ntasks-per-gpu", hidden=True)
@click.option("--ntasks-per-node", hidden=True)
@click.option("--ntasks-per-socket", hidden=True)
@click.option("--open-mode", hidden=True)
@click.option("-o", "--output", hidden=True)
@click.option("-O", "--overcommit", is_flag=True, hidden=True)
@click.option("-s", "--oversubscribe", is_flag=True, hidden=True)
@click.option("--parsable", is_flag=True, hidden=True)
@click.option("-p", "--partition", hidden=True)
@click.option("--prefer", hidden=True)
@click.option("--priority", hidden=True)
@click.option("--profile", hidden=True)
@click.option("--propagate", hidden=True)
@click.option("-q", "--qos", hidden=True)
@click.option("-Q", "--quiet", is_flag=True, hidden=True)
@click.option("--reboot", is_flag=True, hidden=True)
@click.option("--requeue", is_flag=True, hidden=True)
@click.option("--reservation", hidden=True)
@click.option("--resv-ports", hidden=True)
@click.option("--segment", hidden=True)
@click.option("--signal", hidden=True)
@click.option("--sockets-per-node", hidden=True)
@click.option("--spread-job", is_flag=True, hidden=True)
@click.option("--stepmgr", is_flag=True, hidden=True)
@click.option("--switches", hidden=True)
@click.option("--test-only", is_flag=True, hidden=True)
@click.option("--thread-spec", hidden=True)
@click.option("--threads-per-core", hidden=True)
@click.option("-t", "--time", hidden=True)
@click.option("--time-min", hidden=True)
@click.option("--tmp", hidden=True)
@click.option("--tres-bind", hidden=True)
@click.option("--tres-per-task", hidden=True)
@click.option("--uid", hidden=True)
@click.option("--usage", is_flag=True, hidden=True)
@click.option("--use-min-nodes", is_flag=True, hidden=True)
@click.option("-v", "--verbose", is_flag=True, multiple=True, hidden=True)
@click.option("-V", "--version", is_flag=True, hidden=True)
@click.option("-W", "--wait", is_flag=True, hidden=True)
@click.option("--wait-all-nodes", hidden=True)
@click.option("--wckey", hidden=True)
@click.option("--wrap", hidden=True)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output in JSON format",
)
@click.argument("script", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def submit(
    ctx: click.Context,
    job_name: str,
    array: str,
    dependencies: str,
    repeat: int,
    output_json: bool,
    script: str,
    **kwargs,
):
    """Submit a job to the queue."""
    from .manager import JobManager

    job_manager: JobManager = ctx.meta["job_manager"]
    # reconstruct the command with kwargs and script
    command = []
    for k, v in kwargs.items():
        if v in (None, False):
            # option was not provided
            continue
        if k in ("output", "error"):
            # we ignore output and error options
            continue
        k = k.replace("_", "-")
        if isinstance(v, str):
            command.extend([f"--{k}", f"{v}"])
        elif isinstance(v, bool):
            command.append(f"--{k}")

    command.extend(script)

    with job_manager as session:
        if repeat > 1:
            if dependencies is not None and (
                "," in dependencies or "?" in dependencies
            ):
                raise click.UsageError(
                    f"Repeated jobs can only have one dependency type (no `,` or `?` in --dependency) but got {dependencies}"
                )
        for _ in range(repeat):
            job = job_manager.submit_job(
                name=job_name,
                command=command,
                array=array,
                dependencies=dependencies,
            )
            if output_json:
                click.echo(
                    json.dumps(
                        {
                            "job_id": job.id,
                            "slurm_id": job.grid_id,
                            "name": job.name,
                        }
                    )
                )
            else:
                click.echo(job.id)
            deps = (dependencies or "").split(",")
            deps[-1] = f"{deps[-1]}:{job.id}" if deps[-1] else str(job.id)
            dependencies = ",".join(deps)
        session.commit()


@cli.command()
@job_filters(default_states="BF,CA,F,NF,OOM,TO")
@click.pass_context
def resubmit(
    ctx: click.Context,
    job_ids: list[int],
    states: list[str],
    names: list[str],
    dependents: bool,
):
    """Resubmit a job to the queue."""
    from .manager import JobManager

    job_manager: JobManager = ctx.meta["job_manager"]
    with job_manager as session:
        jobs = job_manager.resubmit_jobs(
            job_ids=job_ids, states=states, names=names, dependents=dependents
        )
        if not jobs:
            click.echo(
                no_jobs_message(
                    "resubmitted",
                    default_states=True,
                )
            )
        for job in jobs:
            click.echo(f"Resubmitted job {job.id}")
        session.commit()


@cli.command(name="list")
@job_filters
@click.option(
    "-w",
    "--wrap",
    is_flag=True,
    default=False,
    help="Wrap the output to the terminal width",
)
@click.option(
    "-t",
    "--truncate",
    is_flag=True,
    default=False,
    help="Truncate the output to the terminal width",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output in JSON format",
)
@click.pass_context
def list_jobs(
    ctx: click.Context,
    job_ids: list[int],
    states: list[str],
    names: list[str],
    dependents: bool,
    wrap: bool,
    truncate: bool,
    output_json: bool,
):
    """List jobs in the queue, similar to sacct and squeue."""
    from .manager import JobManager

    if output_json and (wrap or truncate):
        raise click.UsageError(
            "--json is mutually exclusive with --wrap and --truncate"
        )

    def truncate_str(content: str, max_width: int) -> str:
        if len(content) > max_width:
            return content[: max_width - 3] + ".."
        return content

    job_manager: JobManager = ctx.meta["job_manager"]
    with job_manager as session:
        jobs = job_manager.list_jobs(
            job_ids=job_ids, states=states, names=names, dependents=dependents
        )

        if output_json:
            jobs_list = []
            for job in jobs:
                output = job.output_files[0].resolve()
                try:
                    output = output.relative_to(Path.cwd().resolve())
                except ValueError:
                    pass
                jobs_list.append(
                    {
                        "job_id": job.id,
                        "slurm_id": job.grid_id,
                        "nodes": job.nodes,
                        "state": job.state,
                        "exit_code": job.exit_code,
                        "name": job.name,
                        "output": str(output),
                        "dependencies": [dep_job for dep_job in job.dependencies_ids],
                        "command": "gridtk submit " + " ".join(job.command),
                    }
                )
            click.echo(json.dumps(jobs_list, indent=2))
            session.commit()
            return

        from tabulate import tabulate

        table: dict[str, list[str]] = defaultdict(list)
        for job in jobs:
            table["job-id"].append(job.id)
            table["slurm-id"].append(job.grid_id)
            table["nodes"].append(str(job.nodes))
            table["state"].append(f"{job.state} ({job.exit_code})")
            table["job-name"].append(job.name)
            output = job.output_files[0].resolve()
            try:
                output = output.relative_to(Path.cwd().resolve())
            except ValueError:
                pass

            table["output"].append(output)
            table["dependencies"].append(
                ",".join([str(dep_job) for dep_job in job.dependencies_ids])
            )
            table["command"].append("gridtk submit " + " ".join(job.command))

        maxcolwidths = None
        full_output = not wrap and not truncate
        if not full_output and table:
            minimum_column_width = 7
            width_of_spaces = (len(table) - 1) * 2
            terminal_width = max(
                len(table) * minimum_column_width + width_of_spaces,
                shutil.get_terminal_size().columns,
            )
            max_widths = {
                "job-id": minimum_column_width,
                "slurm-id": minimum_column_width,
                "nodes": 0.1,
                "state": 0.15,
                "job-name": 0.2,
                "output": 0.3,
                "dependencies": minimum_column_width,
                "command": 0.25,
            }
            left_over_width = (
                terminal_width
                - width_of_spaces
                - sum(v for v in max_widths.values() if isinstance(v, int))
            )
            for key, value in max_widths.items():
                if isinstance(value, float):
                    max_widths[key] = int(left_over_width * value)
            maxcolwidths = [int(max_widths[key]) for key in table]
            if truncate:
                for key, rows in table.items():
                    table[key] = [
                        truncate_str(str(row), int(max_widths[key])) for row in rows
                    ]
                # truncate column names
                table = {
                    truncate_str(key, int(max_widths[key])): value
                    for key, value in table.items()
                }

        if table:
            click.echo(
                tabulate(
                    table,
                    headers="keys",
                    maxcolwidths=maxcolwidths,
                    maxheadercolwidths=maxcolwidths,
                )
            )
        else:
            click.echo(no_jobs_message("found"))
        session.commit()


@cli.command()
@job_filters
@click.pass_context
def stop(
    ctx: click.Context,
    job_ids: list[int],
    states: list[str],
    names: list[str],
    dependents: bool,
):
    """Stop a job from running."""
    from .manager import JobManager

    job_manager: JobManager = ctx.meta["job_manager"]
    with job_manager as session:
        jobs = job_manager.stop_jobs(
            job_ids=job_ids, states=states, names=names, dependents=dependents
        )
        if not jobs:
            click.echo(no_jobs_message("stopped"))
        for job in jobs:
            click.echo(f"Stopped job {job.id} with slurm id {job.grid_id}")
        session.commit()


@cli.command()
@job_filters
@click.pass_context
def delete(
    ctx: click.Context,
    job_ids: list[int],
    states: list[str],
    names: list[str],
    dependents: bool,
):
    """Delete a job from the queue."""
    from .manager import JobManager

    job_manager: JobManager = ctx.meta["job_manager"]
    with job_manager as session:
        jobs = job_manager.delete_jobs(
            job_ids=job_ids, states=states, names=names, dependents=dependents
        )
        if not jobs:
            click.echo(no_jobs_message("deleted"))
        for job in jobs:
            click.echo(f"Deleted job {job.id} with slurm id {job.grid_id}")
        session.commit()


@cli.command()
@job_filters
@click.option(
    "--interval",
    default=10,
    type=click.INT,
    help="Polling interval in seconds.",
)
@click.pass_context
def wait(ctx, job_ids, states, names, dependents, interval):
    """Wait for jobs to finish. Exits with code 1 if any job failed."""
    import time

    from .manager import JobManager

    job_manager: JobManager = ctx.meta["job_manager"]
    # Terminal states - jobs in these states won't change
    terminal_states = {
        "BOOT_FAIL",
        "CANCELLED",
        "COMPLETED",
        "DEADLINE",
        "FAILED",
        "NODE_FAIL",
        "OUT_OF_MEMORY",
        "PREEMPTED",
        "REVOKED",
        "SPECIAL_EXIT",
        "TIMEOUT",
    }
    # Failed states - if any job ends in these, exit code 1
    failed_states = {
        "BOOT_FAIL",
        "CANCELLED",
        "DEADLINE",
        "FAILED",
        "NODE_FAIL",
        "OUT_OF_MEMORY",
        "PREEMPTED",
        "REVOKED",
        "SPECIAL_EXIT",
        "TIMEOUT",
    }

    while True:
        with job_manager as session:
            jobs = job_manager.list_jobs(
                job_ids=job_ids, states=states, names=names, dependents=dependents
            )
            if not jobs:
                click.echo("No jobs found.")
                return

            all_terminal = all(job.state in terminal_states for job in jobs)
            if all_terminal:
                any_failed = any(job.state in failed_states for job in jobs)
                for job in jobs:
                    click.echo(f"Job {job.id}: {job.state} ({job.exit_code})")
                session.commit()
                if any_failed:
                    raise SystemExit(1)
                return

            # Show progress with state breakdown
            from collections import Counter

            active = [j for j in jobs if j.state not in terminal_states]
            counts = Counter(j.state for j in active)
            breakdown = ", ".join(f"{n} {s.lower()}" for s, n in sorted(counts.items()))
            click.echo(
                f"Waiting for {len(active)} job(s): {breakdown}"
                f" (checking every {interval}s)"
            )
            session.commit()

        time.sleep(interval)


@cli.command()
@job_filters
@click.option(
    "-a",
    "--array",
    "array_idx",
    help="Array index to see the logs for only one item of an array job.",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output in JSON format",
)
@click.pass_context
def report(
    ctx: click.Context,
    job_ids: list[int],
    states: list[str],
    names: list[str],
    dependents: bool,
    array_idx: Optional[str],
    output_json: bool,
):
    """Report on jobs in the queue."""
    from .manager import JobManager

    job_manager: JobManager = ctx.meta["job_manager"]
    with job_manager as session:
        jobs = job_manager.list_jobs(
            job_ids=job_ids, states=states, names=names, dependents=dependents
        )
        if not jobs:
            if output_json:
                click.echo(json.dumps([]))
            else:
                click.echo(no_jobs_message("found"))
            session.commit()
            return

        if output_json:
            report_list = []
            for job in jobs:
                with tempfile.NamedTemporaryFile(mode="w+t", suffix=".sh") as tmpfile:
                    command = job.submitted_command(tmpfile, session=session)
                output_files_list = []
                files = job.output_files
                error_files = job.error_files
                if array_idx is not None:
                    real_array_idx = job.array_task_ids.index(int(array_idx))
                    files = files[real_array_idx : real_array_idx + 1]
                    error_files = error_files[real_array_idx : real_array_idx + 1]
                for out_file, err_file in zip(files, error_files):
                    if out_file.exists():
                        output_files_list.append(
                            {
                                "path": str(out_file),
                                "content": out_file.open().read(),
                            }
                        )
                    else:
                        output_files_list.append(
                            {"path": str(out_file), "content": None}
                        )
                    if err_file != out_file:
                        if err_file.exists():
                            output_files_list.append(
                                {
                                    "path": str(err_file),
                                    "content": err_file.open().read(),
                                }
                            )
                        else:
                            output_files_list.append(
                                {"path": str(err_file), "content": None}
                            )
                report_list.append(
                    {
                        "job_id": job.id,
                        "name": job.name,
                        "state": job.state,
                        "exit_code": job.exit_code,
                        "nodes": job.nodes,
                        "command": command,
                        "output_files": output_files_list,
                    }
                )
            click.echo(json.dumps(report_list, indent=2))
            session.commit()
            return

        for job in jobs:
            report_text = ""
            report_text += f"Job ID: {job.id}\n"
            report_text += f"Name: {job.name}\n"
            report_text += f"State: {job.state} ({job.exit_code})\n"
            report_text += f"Nodes: {job.nodes}\n"
            with tempfile.NamedTemporaryFile(mode="w+t", suffix=".sh") as tmpfile:
                report_text += f"Submitted command: {job.submitted_command(tmpfile, session=session)}\n"
                if job.command_in_bash:
                    report_text += (
                        f"Content of the temporary script:\n{job.command_in_bash}\n"
                    )
            output_files, error_files = job.output_files, job.error_files
            if array_idx is not None:
                real_array_idx = job.array_task_ids.index(int(array_idx))
                output_files = output_files[real_array_idx : real_array_idx + 1]
                error_files = error_files[real_array_idx : real_array_idx + 1]
            for output, error in zip(output_files, error_files):
                report_text += f"Output file: {output}\n"
                if output.exists():
                    report_text += output.open().read() + "\n\n"
                if error != output:
                    report_text += f"Error file: {error}\n"
                    if error.exists():
                        report_text += error.open().read() + "\n\n"
            pydoc.pager(report_text)
        session.commit()


if __name__ == "__main__":
    cli()
