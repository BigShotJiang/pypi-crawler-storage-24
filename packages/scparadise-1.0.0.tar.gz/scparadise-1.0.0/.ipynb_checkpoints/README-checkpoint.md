# scParadize
Tunable, highly accurate multi-class cell type annotation with unknown cell type identification and modality prediction in single-cell RNA-seq data.
