"""Public decorator surface."""

from __future__ import annotations

import asyncio
import functools
import inspect
from typing import Any, Callable, Dict, Optional, Sequence, TypeVar, cast

from .exceptions import PluginNotInitializedError
from .governance import GovernanceDirective
from .instrumentation import InstrumentationOptions, TranscriptCollector
from .kpi import KPIConfig
from .plugin import TuringPulsePlugin, get_plugin
from .trigger_state import queue_trigger

F = TypeVar("F", bound=Callable[..., Any])


def instrument(
    *,
    name: Optional[str] = None,
    agent_id: Optional[str] = None,  # DEPRECATED: Use `name` instead
    operation: Optional[str] = None,
    labels: Optional[Dict[str, str]] = None,
    trace: Optional[bool] = None,
    governance: GovernanceDirective | None = None,
    kpis: Sequence[KPIConfig] | None = None,
    trigger_key: Optional[str] = None,
    trigger_description: Optional[str] = None,
    hidden_entrypoint: bool = False,
    metadata: Optional[Dict[str, str]] = None,
    transcript_collector: Optional[TranscriptCollector] = None,
    agentic_pattern: Optional[str] = None,
) -> Callable[[F], F]:
    """Instruments a function for observability, governance, and KPI mapping.

    Args:
        name: Display name for the workflow (e.g., "Order Processing Agent").
              This is the preferred parameter. The backend will auto-register
              workflows based on this name and assign a UUID.
        agent_id: DEPRECATED - Use ``name`` instead. Kept for backward compatibility.
        operation: Optional operation name for the span.
        labels: Optional key-value labels for the span.
        trace: Override tracing enabled/disabled.
        governance: Governance directive for policy enforcement.
        kpis: KPI configurations for metrics collection.
        trigger_key: Key for trigger registration.
        trigger_description: Description for trigger.
        hidden_entrypoint: If True, don't mark as workflow entrypoint.
        metadata: Additional metadata to attach to spans.
        transcript_collector: Optional callback for transcript collection.

    Examples:
        @instrument(name="Order Processing Agent")
        async def process_order(order_id: str):
            ...
    """

    options = InstrumentationOptions(
        name=name,
        agent_id=agent_id,
        operation=operation,
        labels=labels or {},
        trace=trace,
        governance=governance,
        kpis=tuple(kpis or ()),
        trigger_key=trigger_key,
        trigger_description=trigger_description,
        hidden_entrypoint=hidden_entrypoint,
        metadata=metadata or {},
        transcript_collector=transcript_collector,
        agentic_pattern=agentic_pattern,
    )

    def decorator(func: F) -> F:
        if inspect.isasyncgenfunction(func):

            @functools.wraps(func)
            async def async_gen_wrapper(*args, **kwargs):
                plugin = _get_plugin()
                _ensure_trigger_registration(plugin, options, async_gen_wrapper)
                async for item in plugin.execute_async_gen(func, args, kwargs, options):
                    yield item

            _maybe_register_trigger(options, async_gen_wrapper)
            return cast(F, async_gen_wrapper)

        if asyncio.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                plugin = _get_plugin()
                _ensure_trigger_registration(plugin, options, async_wrapper)
                return await plugin.execute_async(func, args, kwargs, options)

            _maybe_register_trigger(options, async_wrapper)
            return cast(F, async_wrapper)

        if inspect.isgeneratorfunction(func):

            @functools.wraps(func)
            def gen_wrapper(*args, **kwargs):
                plugin = _get_plugin()
                _ensure_trigger_registration(plugin, options, gen_wrapper)
                yield from plugin.execute_sync_gen(func, args, kwargs, options)

            _maybe_register_trigger(options, gen_wrapper)
            return cast(F, gen_wrapper)

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            plugin = _get_plugin()
            _ensure_trigger_registration(plugin, options, sync_wrapper)
            return plugin.execute_sync(func, args, kwargs, options)

        _maybe_register_trigger(options, sync_wrapper)
        return cast(F, sync_wrapper)

    return decorator


def _maybe_register_trigger(options: InstrumentationOptions, wrapper: Callable) -> None:
    if not options.trigger_key:
        return
    try:
        plugin = get_plugin()
    except PluginNotInitializedError:
        queue_trigger(options.trigger_key, wrapper, options.trigger_description)
    else:
        plugin.register_trigger(options.trigger_key, wrapper, options.trigger_description)
        setattr(wrapper, "_tp_trigger_registered", True)


def _ensure_trigger_registration(plugin: TuringPulsePlugin, options: InstrumentationOptions, wrapper: Callable) -> None:
    if not options.trigger_key:
        return
    if getattr(wrapper, "_tp_trigger_registered", False):
        return
    plugin.register_trigger(options.trigger_key, wrapper, options.trigger_description)
    setattr(wrapper, "_tp_trigger_registered", True)


def _get_plugin() -> TuringPulsePlugin:
    return get_plugin()
