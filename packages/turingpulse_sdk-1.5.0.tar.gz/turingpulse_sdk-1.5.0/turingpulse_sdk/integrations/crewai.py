"""CrewAI 1.6.x instrumentation for TuringPulse SDK.

Wraps ``crew.kickoff()`` to capture:

- Aggregate token counts from ``CrewOutput.token_usage`` (a Pydantic
  ``UsageMetrics`` model, **not** a plain dict).
- Per-task child spans with distributed token estimates.
- Agent role, goal, backstory as metadata and system prompt.
- Tool lists from agent tool definitions.

**Known shortfalls (CrewAI 1.6.x)**

1. CrewAI only exposes *aggregate* token counts at the crew level.
   Per-agent / per-task breakdowns are **not available** — we divide
   totals evenly across tasks as an approximation.
2. Internal tool executions are opaque — the SDK sees the crew-level
   result only, not individual tool-call timings.
3. ``token_usage`` is a Pydantic ``UsageMetrics`` model (not a dict);
   code must use attribute access or ``.model_dump()``.

Usage::

    from turingpulse_sdk.integrations.crewai import instrument_crewai
    from crewai import Crew

    crew = Crew(agents=[...], tasks=[...])
    run_workflow = instrument_crewai(crew, name="my-crewai-workflow")
    result = run_workflow(inputs={"query": "..."})
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Sequence

if TYPE_CHECKING:
    from ..kpi import KPIConfig

from ..config import MAX_FIELD_SIZE
from ..context import current_context
from ..decorators import instrument
from .base import emit_child_spans

logger = logging.getLogger("turingpulse.sdk.integrations.crewai")

# Framework constants
FRAMEWORK_NAME = "crewai"
FRAMEWORK_VERSION = "1.6.1"


def instrument_crewai(
    crew: Any,
    *,
    name: str,
    model: str = "gpt-4o-mini",
    provider: str = "openai",
    kpis: Optional[Sequence["KPIConfig"]] = None,
    metadata: Optional[Dict[str, str]] = None,
) -> Callable[..., Any]:
    """Instrument a CrewAI ``Crew`` for TuringPulse observability.

    Returns a callable that, when invoked, runs ``crew.kickoff()`` and
    emits a root workflow span plus per-task child spans.

    Args:
        crew: A ``crewai.Crew`` instance.
        name: Workflow display name for TuringPulse.
        model: LLM model name (default ``gpt-4o-mini``).
        provider: LLM provider (default ``openai``).

    Returns:
        A callable ``run(inputs=None) -> CrewOutput``.
    """

    # Collect tool call records via CrewAI hooks when available.
    # CrewAI >= 0.65 exposes register_after_tool_call_hook; older
    # versions do not, so we guard with try/except ImportError.
    import threading
    _captured_tool_calls_lock = threading.Lock()
    _captured_tool_calls: List[Dict[str, Any]] = []

    def _tool_call_hook(tool_call_result: Any) -> None:
        """After-tool-call hook registered on the Crew instance."""
        tc_name = getattr(tool_call_result, "tool_name", None) or "unknown"
        tc_result = getattr(tool_call_result, "result", None)
        tc_error = getattr(tool_call_result, "error", None)
        success = tc_error is None
        with _captured_tool_calls_lock:
            _captured_tool_calls.append({
                "tool_name": str(tc_name),
                "tool_args": {},
                "tool_result": str(tc_result)[:MAX_FIELD_SIZE] if tc_result else "",
                "tool_id": "",
                "success": success,
                "error_message": str(tc_error)[:MAX_FIELD_SIZE] if tc_error else None,
            })

    try:
        if hasattr(crew, "register_after_tool_call_hook"):
            crew.register_after_tool_call_hook(_tool_call_hook)
    except Exception as e:
        logger.debug("CrewAI tool hook registration failed: %s", e)

    @instrument(name=name, kpis=kpis, metadata=metadata or {})
    def run(inputs: Optional[Dict[str, Any]] = None) -> Any:
        with _captured_tool_calls_lock:
            _captured_tool_calls.clear()
        t0 = time.time()
        result = crew.kickoff(inputs=inputs)
        total_duration_ms = int((time.time() - t0) * 1000)

        ctx = current_context()
        if ctx is None:
            logger.warning("instrument_crewai: no active context")
            return result

        # ── Extract aggregate token usage ──
        token_usage = _extract_token_usage(result)
        total_prompt = token_usage.get("prompt_tokens", 0) or token_usage.get("input_tokens", 0) or 0
        total_completion = token_usage.get("completion_tokens", 0) or token_usage.get("output_tokens", 0) or 0
        total_cost = 0  # Backend calculates cost based on model pricing

        # Enrich root span context
        ctx.set_tokens(total_prompt, total_completion)
        ctx.set_cost(total_cost)
        ctx.set_model(model, provider)
        ctx.framework = FRAMEWORK_NAME
        ctx.node_type = "workflow"

        final_output = result.raw if hasattr(result, "raw") else str(result)
        ctx.set_io(
            input_data=str(inputs)[:MAX_FIELD_SIZE] if inputs else None,
            output_data=final_output[:MAX_FIELD_SIZE],
        )

        # ── Build child spans (one per task) ──
        child_spans = _build_task_spans(
            result, crew, total_duration_ms,
            total_prompt, total_completion,
            model, provider, inputs,
            captured_tool_calls=list(_captured_tool_calls),
        )
        emit_child_spans(
            child_spans,
            run_id=ctx.run_id,
            parent_span_id=ctx.span_id,
            workflow_name=name,
            framework=FRAMEWORK_NAME,
        )

        return result

    return run


# ── Helpers ──────────────────────────────────────────────────────────────


def _extract_token_usage(crew_output: Any) -> Dict[str, int]:
    """Extract token usage from ``CrewOutput.token_usage``.

    CrewAI 1.6.x returns a Pydantic ``UsageMetrics`` object, not a dict.
    We normalise to a plain dict for downstream consumption.
    """
    raw = getattr(crew_output, "token_usage", None)
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return raw
    if hasattr(raw, "model_dump"):
        return raw.model_dump()
    if hasattr(raw, "__dict__"):
        return vars(raw)
    return {}


def _build_task_spans(
    crew_output: Any,
    crew: Any,
    total_duration_ms: int,
    total_prompt_tokens: int,
    total_completion_tokens: int,
    model: str,
    provider: str,
    inputs: Optional[Dict[str, Any]] = None,
    captured_tool_calls: Optional[List[Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """Create one child span dict per CrewAI task."""
    spans: List[Dict[str, Any]] = []

    tasks_output = getattr(crew_output, "tasks_output", []) or []
    tasks = getattr(crew, "tasks", []) or []
    num_tasks = max(len(tasks), 1)
    per_task_dur = total_duration_ms // num_tasks
    per_task_prompt = total_prompt_tokens // num_tasks
    per_task_completion = total_completion_tokens // num_tasks
    per_task_cost = 0  # Backend calculates cost based on model pricing

    for i, task in enumerate(tasks):
        task_output = tasks_output[i] if i < len(tasks_output) else None
        agent = getattr(task, "agent", None)

        raw_output = ""
        if task_output:
            raw_output = task_output.raw if hasattr(task_output, "raw") else str(task_output)

        agent_role = agent.role if agent else f"task_{i}"
        node_name = agent_role.lower().replace(" ", "_")[:30]

        # Build system prompt from agent config
        system_prompt = ""
        if agent:
            system_prompt = (
                f"Role: {agent.role}\n"
                f"Goal: {agent.goal}\n"
                f"Backstory: {getattr(agent, 'backstory', '') or ''}"
            )[:MAX_FIELD_SIZE]

        span: Dict[str, Any] = {
            "node": node_name,
            "node_type": "llm",
            "duration_ms": per_task_dur,
            "status": "success",
            "prompt": (task.description[:MAX_FIELD_SIZE] if task.description else ""),
            "system_prompt": system_prompt,
            "input": {
                "task_description": (task.description[:MAX_FIELD_SIZE] if task.description else ""),
                "expected_output": (task.expected_output[:MAX_FIELD_SIZE] if task.expected_output else ""),
            },
            "output": {"result": raw_output[:MAX_FIELD_SIZE]},
            "model": model,
            "provider": provider,
            "tokens": {"prompt": per_task_prompt, "completion": per_task_completion},
            "cost_usd": round(per_task_cost, 6),
            "metadata": {
                "crewai_agent_role": agent.role if agent else "unknown",
                "crewai_agent_goal": agent.goal if agent else "unknown",
                "crewai_process": "sequential",
                "crewai_task_index": str(i),
                "crewai_version": FRAMEWORK_VERSION,
            },
        }

        # Attach tool info if agent has tools
        if agent and getattr(agent, "tools", None):
            tool_names = [t.name for t in agent.tools]
            span["available_tools"] = tool_names

            # Distribute captured tool calls to matching task spans.
            # If tool_name matches an agent's tool list, attach it.
            if captured_tool_calls:
                task_tc = [
                    tc for tc in captured_tool_calls
                    if tc.get("tool_name") in tool_names
                ]
                if task_tc:
                    span["tool_calls"] = task_tc

        spans.append(span)

    return spans
