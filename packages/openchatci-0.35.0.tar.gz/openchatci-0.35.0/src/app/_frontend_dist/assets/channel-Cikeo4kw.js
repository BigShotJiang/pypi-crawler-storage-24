import{aq as o,ar as n}from"./index-C6ww0Vpj.js";const t=(r,a)=>o.lang.round(n.parse(r)[a]);export{t as c};
