"""
Image generation proxy handler module.

Forwards image generation requests to the remote backend.
"""

from .image_generation_handler import ImageGenerationProxyHandler

__all__ = ["ImageGenerationProxyHandler"]
