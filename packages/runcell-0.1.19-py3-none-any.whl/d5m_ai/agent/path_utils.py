"""
Path helpers for resolving Jupyter contents paths safely.
"""

from __future__ import annotations

import os
import re
from typing import Tuple


def _normalize_relative_path(file_path: str) -> str:
    normalized = file_path.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    normalized = normalized.lstrip("/")
    normalized = re.sub(r"/+", "/", normalized)
    return normalized


def _resolve_absolute_to_contents_path(
    abs_path: str,
    root_dir: str,
    original_file_path: str,
) -> Tuple[str, str | None]:
    try:
        common = os.path.commonpath([root_dir, abs_path])
    except ValueError:
        return abs_path.replace("\\", "/"), _outside_root_message(original_file_path)

    if common != root_dir:
        return abs_path.replace("\\", "/"), _outside_root_message(original_file_path)

    rel_path = os.path.relpath(abs_path, root_dir)
    return rel_path.replace(os.sep, "/"), None


def resolve_contents_path(
    file_path: str,
    root_dir: str,
    cwd: str | None = None,
) -> Tuple[str, str | None]:
    """
    Convert filesystem paths to Jupyter contents paths when possible.

    Returns:
        (resolved_path, error_message)
    """
    normalized = file_path.replace("\\", "/")
    is_absolute = normalized.startswith("/") or re.match(r"^[A-Za-z]:/", normalized)

    root_dir = os.path.realpath(os.path.abspath(str(root_dir)))
    if is_absolute:
        abs_path = os.path.realpath(os.path.abspath(file_path))
        return _resolve_absolute_to_contents_path(abs_path, root_dir, file_path)

    normalized_relative = _normalize_relative_path(file_path)
    if not normalized_relative:
        return normalized_relative, None

    base_cwd = cwd or os.getcwd()
    relative_abs_path = os.path.realpath(
        os.path.abspath(os.path.join(base_cwd, normalized_relative))
    )
    if os.path.exists(relative_abs_path):
        resolved_from_cwd, cwd_error = _resolve_absolute_to_contents_path(
            relative_abs_path,
            root_dir,
            file_path,
        )
        if cwd_error is None:
            return resolved_from_cwd, None

        root_relative_abs_path = os.path.realpath(
            os.path.abspath(os.path.join(root_dir, normalized_relative))
        )
        if os.path.exists(root_relative_abs_path):
            return _resolve_absolute_to_contents_path(
                root_relative_abs_path,
                root_dir,
                file_path,
            )

        return resolved_from_cwd, cwd_error

    return normalized_relative, None


def _outside_root_message(file_path: str) -> str:
    return (
        f"Error: File path '{file_path}' is outside the Jupyter server working directory "
        "and cannot be accessed for safety. Use a path under the working directory or open the file in Jupyter first."
    )
