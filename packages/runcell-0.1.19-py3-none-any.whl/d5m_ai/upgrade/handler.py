import asyncio
import json
import logging
import os
import shlex
import subprocess
import sys
import sysconfig
import time
import uuid
from importlib import metadata
from typing import Any, Dict, List, Optional
from functools import partial

import tornado.web
from jupyter_server.base.handlers import APIHandler
from tornado.ioloop import IOLoop


PACKAGE_NAME = "runcell"
UPGRADE_TIMEOUT_SECONDS = 300  # 5 minutes timeout for pip install
ALLOWED_UPGRADE_PACKAGES = {PACKAGE_NAME}
RESTART_STRATEGY = "execv"
RESTART_DELAY_SECONDS = 0.4
RESTART_REQUEST_ENV = "D5M_RESTART_REQUEST_ID"
RESTART_REQUEST_AT_ENV = "D5M_RESTART_REQUESTED_AT"
RESTART_REQUEST_FROM_PID_ENV = "D5M_RESTART_REQUESTED_FROM_PID"

logger = logging.getLogger(__name__)
_RESTART_IN_PROGRESS = False
_CURRENT_RESTART_REQUEST_ID: Optional[str] = None


def _log_restart_boot_event_once() -> None:
    request_id = os.environ.pop(RESTART_REQUEST_ENV, None)
    if not request_id:
        return
    requested_at = os.environ.pop(RESTART_REQUEST_AT_ENV, "unknown")
    previous_pid = os.environ.pop(RESTART_REQUEST_FROM_PID_ENV, "unknown")
    logger.warning(
        "Jupyter process booted after in-process restart request_id=%s previous_pid=%s requested_at=%s current_pid=%s",
        request_id,
        previous_pid,
        requested_at,
        os.getpid(),
    )


_log_restart_boot_event_once()


def _is_homebrew_path(path: str) -> bool:
    if not path:
        return False
    lower_path = os.path.realpath(path).lower()
    markers = (
        "/homebrew/",
        "/opt/homebrew/",
        "/usr/local/cellar/",
        "/usr/local/homebrew/",
        "/usr/local/opt/homebrew/",
        "/usr/local/opt/python",
    )
    return any(marker in lower_path for marker in markers)


def _collect_install_targets(prefix: str, python_executable: str) -> List[str]:
    targets: List[str] = []

    try:
        paths = sysconfig.get_paths()
        targets.extend([paths.get("purelib"), paths.get("platlib")])
    except Exception:
        pass

    try:
        import site

        targets.extend(site.getsitepackages() or [])
        user_site = site.getusersitepackages()
        if user_site:
            targets.append(user_site)
    except Exception:
        pass

    targets.extend([prefix, os.path.dirname(python_executable)])

    normalized: List[str] = []
    seen = set()
    for path in filter(None, targets):
        normalized_path = os.path.realpath(path)
        if normalized_path not in seen:
            seen.add(normalized_path)
            normalized.append(normalized_path)
    return normalized


def _is_path_writable(path: str) -> bool:
    candidate = os.path.realpath(path)
    while candidate and not os.path.exists(candidate):
        parent = os.path.dirname(candidate)
        if parent == candidate:
            return False
        candidate = parent
    return bool(candidate and os.access(candidate, os.W_OK))


def _is_install_writable(paths: List[str]) -> bool:
    return any(_is_path_writable(path) for path in paths)


def _build_restart_argv() -> List[str]:
    return [sys.executable, *sys.argv]


def _build_restart_preview() -> str:
    return shlex.join(_build_restart_argv())


def _execv_restart(request_id: str) -> None:
    argv = _build_restart_argv()
    os.environ[RESTART_REQUEST_ENV] = request_id
    os.environ[RESTART_REQUEST_AT_ENV] = str(int(time.time()))
    os.environ[RESTART_REQUEST_FROM_PID_ENV] = str(os.getpid())
    logger.warning(
        "Restarting Jupyter server via execv request_id=%s pid=%s command=%s",
        request_id,
        os.getpid(),
        shlex.join(argv),
    )
    os.execv(sys.executable, argv)
    # execv should not return on success.
    raise RuntimeError("os.execv returned unexpectedly")


def _perform_scheduled_restart(request_id: str) -> None:
    global _RESTART_IN_PROGRESS, _CURRENT_RESTART_REQUEST_ID
    try:
        logger.warning(
            "Executing scheduled Jupyter restart request_id=%s pid=%s",
            request_id,
            os.getpid(),
        )
        _execv_restart(request_id)
    except Exception:
        _RESTART_IN_PROGRESS = False
        _CURRENT_RESTART_REQUEST_ID = None
        logger.exception("Scheduled Jupyter restart failed request_id=%s.", request_id)


def _detect_environment() -> Dict[str, Any]:
    """Collect information about the Python environment running Jupyter."""
    prefix = sys.prefix
    python_executable = sys.executable

    pip_path: Optional[str] = None
    for candidate in (
        os.path.join(os.path.dirname(python_executable), "pip"),
        os.path.join(os.path.dirname(python_executable), "pip3"),
    ):
        if os.path.exists(candidate):
            pip_path = candidate
            break

    pip_command = pip_path or f"{python_executable} -m pip"

    try:
        current_version = metadata.version(PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        current_version = "unknown"

    install_targets = _collect_install_targets(prefix, python_executable)
    site_packages = next((path for path in install_targets if "site-packages" in path.lower()), None)
    if site_packages is None and install_targets:
        site_packages = install_targets[0]
    install_writable = _is_install_writable(install_targets)

    is_conda = os.path.exists(os.path.join(prefix, "conda-meta"))
    is_venv = hasattr(sys, "real_prefix") or (hasattr(sys, "base_prefix") and sys.base_prefix != prefix)
    homebrew_prefix = os.environ.get("HOMEBREW_PREFIX", "")
    is_homebrew = (
        _is_homebrew_path(python_executable)
        or _is_homebrew_path(prefix)
        or any(_is_homebrew_path(path) for path in install_targets)
        or (homebrew_prefix and (prefix.startswith(homebrew_prefix) or python_executable.startswith(homebrew_prefix)))
    )

    return {
        "python_executable": python_executable,
        "python_version": sys.version,
        "prefix": prefix,
        "pip_command": pip_command,
        "current_version": current_version,
        "is_conda": is_conda,
        "is_venv": is_venv,
        "is_homebrew": is_homebrew,
        "site_packages": site_packages,
        "install_writable": install_writable,
    }


class UpgradeEnvironmentHandler(APIHandler):
    """Return environment details for safe upgrades."""

    @tornado.web.authenticated
    async def get(self):
        try:
            env_info = _detect_environment()
            self.finish(json.dumps({"success": True, "environment": env_info}))
        except Exception as exc:  # pragma: no cover - defensive
            self.set_status(500)
            self.finish(json.dumps({"success": False, "error": str(exc)}))


class UpgradeHandler(APIHandler):
    """Run pip upgrade using the Python environment powering Jupyter."""

    @tornado.web.authenticated
    async def post(self):
        body = self.get_json_body() or {}
        requested_package_name = body.get("package_name", PACKAGE_NAME)
        if requested_package_name not in ALLOWED_UPGRADE_PACKAGES:
            self.set_status(400)
            self.finish(
                json.dumps(
                    {
                        "success": False,
                        "error": f"Unsupported package_name '{requested_package_name}'. Only '{PACKAGE_NAME}' is allowed.",
                    }
                )
            )
            return

        package_name = PACKAGE_NAME
        dry_run = bool(body.get("dry_run")) or os.environ.get("D5M_UPGRADE_DRY_RUN") == "1"
        allow_pre = bool(body.get("pre", False))
        env_info = _detect_environment()

        if env_info.get("is_homebrew"):
            self.finish(
                json.dumps(
                    {
                        "success": False,
                        "error": "Jupyter appears to be running from a Homebrew environment. Please upgrade using Homebrew.",
                        "environment": env_info,
                        "needs_brew": True,
                        "dry_run": dry_run,
                    }
                )
            )
            return

        command = [sys.executable, "-m", "pip", "install", "--upgrade", "--no-cache-dir"]
        if allow_pre:
            command.append("--pre")
        command.append(package_name)

        if dry_run:
            self.finish(
                json.dumps(
                    {
                        "success": True,
                        "returncode": 0,
                        "stdout": "[dry-run] Would run: " + " ".join(command),
                        "stderr": "",
                        "command": " ".join(command),
                        "environment": env_info,
                        "dry_run": True,
                    }
                )
            )
            return

        try:
            # Use subprocess.run in a thread pool for better Windows compatibility
            # asyncio.create_subprocess_exec can have issues on Windows
            loop = asyncio.get_event_loop()

            # On Windows, avoid creating a console window
            # CREATE_NO_WINDOW = 0x08000000
            extra_kwargs = {}
            if sys.platform == "win32":
                extra_kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW

            result = await loop.run_in_executor(
                None,
                lambda: subprocess.run(
                    command,
                    capture_output=True,
                    timeout=UPGRADE_TIMEOUT_SECONDS,
                    **extra_kwargs,
                ),
            )

            stdout = result.stdout.decode("utf-8", errors="replace")
            stderr = result.stderr.decode("utf-8", errors="replace")

            self.finish(
                json.dumps(
                    {
                        "success": result.returncode == 0,
                        "returncode": result.returncode,
                        "stdout": stdout,
                        "stderr": stderr,
                        "command": " ".join(command),
                        "environment": env_info,
                        "dry_run": False,
                    }
                )
            )
        except subprocess.TimeoutExpired:
            logger.error(f"Upgrade command timed out after {UPGRADE_TIMEOUT_SECONDS}s: {command}")
            self.set_status(500)
            self.finish(
                json.dumps(
                    {
                        "success": False,
                        "error": f"Upgrade timed out after {UPGRADE_TIMEOUT_SECONDS} seconds. The pip install may still be running in the background.",
                        "command": " ".join(command),
                        "environment": env_info,
                        "dry_run": False,
                    }
                )
            )
        except Exception as exc:  # pragma: no cover - defensive
            error_type = type(exc).__name__
            error_msg = str(exc) or repr(exc)
            full_error = f"{error_type}: {error_msg}" if error_msg else error_type
            logger.error(f"Upgrade failed with {error_type}: {error_msg}", exc_info=True)
            self.set_status(500)
            self.finish(
                json.dumps(
                    {
                        "success": False,
                        "error": full_error,
                        "command": " ".join(command),
                        "environment": env_info,
                        "dry_run": False,
                    }
                )
            )


class UpgradeRestartHandler(APIHandler):
    """Restart Jupyter using the current process executable and argv."""

    @tornado.web.authenticated
    async def post(self):
        global _RESTART_IN_PROGRESS, _CURRENT_RESTART_REQUEST_ID

        body = self.get_json_body() or {}
        dry_run = bool(body.get("dry_run")) or os.environ.get("D5M_RESTART_DRY_RUN") == "1"
        command_preview = _build_restart_preview()
        request_id = str(uuid.uuid4())
        logger.warning(
            "Restart request received request_id=%s dry_run=%s in_progress=%s pid=%s",
            request_id,
            dry_run,
            _RESTART_IN_PROGRESS,
            os.getpid(),
        )

        if _RESTART_IN_PROGRESS:
            self.finish(
                json.dumps(
                    {
                        "success": False,
                        "accepted": False,
                        "strategy": RESTART_STRATEGY,
                        "command_preview": command_preview,
                        "dry_run": dry_run,
                        "request_id": request_id,
                        "message": "Restart already in progress.",
                    }
                )
            )
            logger.warning(
                "Restart request rejected request_id=%s active_request_id=%s",
                request_id,
                _CURRENT_RESTART_REQUEST_ID,
            )
            return

        if dry_run:
            self.finish(
                json.dumps(
                    {
                        "success": True,
                        "accepted": True,
                        "strategy": RESTART_STRATEGY,
                        "command_preview": command_preview,
                        "dry_run": True,
                        "request_id": request_id,
                        "message": "Dry run enabled. No restart executed.",
                    }
                )
            )
            logger.warning("Restart dry-run request_id=%s command=%s", request_id, command_preview)
            return

        _RESTART_IN_PROGRESS = True
        _CURRENT_RESTART_REQUEST_ID = request_id
        IOLoop.current().call_later(RESTART_DELAY_SECONDS, partial(_perform_scheduled_restart, request_id))
        self.finish(
            json.dumps(
                {
                    "success": True,
                    "accepted": True,
                    "strategy": RESTART_STRATEGY,
                    "command_preview": command_preview,
                    "dry_run": False,
                    "request_id": request_id,
                    "message": "Restart scheduled. JupyterLab should reconnect shortly.",
                }
            )
        )
        logger.warning(
            "Restart scheduled request_id=%s delay=%.2fs command=%s",
            request_id,
            RESTART_DELAY_SECONDS,
            command_preview,
        )
