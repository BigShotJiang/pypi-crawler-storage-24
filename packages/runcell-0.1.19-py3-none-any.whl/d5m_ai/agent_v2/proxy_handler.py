"""
Agent V2 HTTP/SSE proxy handler.

MVP design:
- Frontend <-> proxy may still use a local-only WebSocket for notebook tools.
- Proxy <-> remote backend is strictly HTTP/SSE.
- Tool execution uses an agent-v2-specific local registry.
"""

from __future__ import annotations

import aiohttp
import json
import logging
import ssl
from typing import Any, Dict

import certifi

from .._version import __version__ as client_version
from ..chat.chat_proxy_handler import AIChatProxyHandler
from ..tools.registry import run_agent_v2_tool
from tornado import web


class AIAgentV2ProxyHandler(AIChatProxyHandler):
    """
    Versioned agent proxy that routes to `/v2/agent/chat` on the remote backend.

    This intentionally subclasses the ask-mode proxy so we can validate the
    HTTP tool loop end-to-end before migrating agent-specific tools/prompts.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        logging.info(
            f"[AGENT-V2-PROXY] Initialized with remote backend: {self.remote_backend_url}"
        )
        # NOTE: v2 local tool execution (run_agent_v2_tool) uses infinity timeout
        # by default. Timeouts are centrally configurable in tool_timeout_config.

    async def _run_local_tool(
        self, tool_name: str, tool_args: Dict[str, Any]
    ) -> Dict[str, Any] | None:
        """Execute local tools using the agent-v2 tool registry."""
        return await run_agent_v2_tool(tool_name, tool_args)

    async def _forward_to_remote_backend(
        self, body_data: Dict[str, Any], stream: bool, user_token: str
    ):
        """Forward request to the versioned remote backend and handle response."""
        try:
            remote_url = f"{self.remote_backend_url}/v2/agent/chat"

            if not hasattr(self, "_unified_content_index"):
                starting_index = body_data.get("starting_content_index")
                if starting_index is None:
                    starting_index = body_data.get("last_content_index")
                if starting_index is not None:
                    try:
                        self._unified_content_index = max(0, int(starting_index))
                    except (TypeError, ValueError):
                        self._unified_content_index = 0

            if hasattr(self, "_unified_content_index") and self._unified_content_index > 0:
                body_data["starting_content_index"] = self._unified_content_index
                logging.info(
                    "[AGENT-V2-PROXY] Continuing conversation with starting_content_index: "
                    f"{self._unified_content_index}"
                )

            body_data["client_version"] = client_version

            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {user_token}",
            }

            try:
                ssl_context = ssl.create_default_context(cafile=certifi.where())
            except Exception as exc:
                logging.warning(
                    f"[AGENT-V2-PROXY] Failed to create SSL context with certifi: {exc}"
                )
                ssl_context = ssl.create_default_context()

            connector = aiohttp.TCPConnector(ssl=ssl_context)

            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(remote_url, json=body_data, headers=headers) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        logging.error(
                            f"[AGENT-V2-PROXY] Remote backend error {response.status}: {error_text}"
                        )

                        try:
                            error_data = json.loads(error_text)
                            error_status = error_data.get("status", "error")
                            error_message = error_data.get("error", error_text)

                            if response.status == 401:
                                self.set_status(401)
                                self.finish(
                                    json.dumps(
                                        {
                                            "error": "Authentication failed. Please log in again.",
                                            "status": "auth_error",
                                        }
                                    )
                                )
                            elif response.status == 402:
                                self.set_status(402)
                                self.finish(
                                    json.dumps(
                                        {
                                            "error": error_message,
                                            "status": "insufficient_credits",
                                        }
                                    )
                                )
                            else:
                                self.set_status(response.status)
                                self.finish(
                                    json.dumps(
                                        {"error": error_message, "status": error_status}
                                    )
                                )
                        except json.JSONDecodeError:
                            self.set_status(response.status)
                            self.finish(
                                json.dumps(
                                    {
                                        "error": f"Remote backend error: {error_text}",
                                        "status": "error",
                                    }
                                )
                            )
                        return

                    if stream:
                        if not hasattr(self, "_unified_content_index"):
                            self._unified_content_index = 0

                        pending_tool_data = await self._handle_streaming_response(
                            response, self._unified_content_index
                        )
                        if pending_tool_data:
                            self._unified_content_index = pending_tool_data.get(
                                "max_content_index", self._unified_content_index
                            )
                            await self._handle_pending_tool_call(
                                pending_tool_data, body_data, user_token
                            )
                    else:
                        response_data = await response.json()
                        self.finish(json.dumps(response_data))

        except aiohttp.ClientConnectorError as exc:
            logging.error(
                "[AGENT-V2-PROXY] Cannot connect to remote backend at "
                f"{self.remote_backend_url}: {exc}"
            )
            self.set_status(503)
            self.finish(
                json.dumps(
                    {
                        "error": (
                            "Cannot connect to agent v2 remote backend. "
                            f"Please ensure the remote backend server is running at {self.remote_backend_url}"
                        ),
                        "status": "error",
                    }
                )
            )
        except Exception as exc:
            logging.error(f"[AGENT-V2-PROXY] Error forwarding to remote backend: {exc}")
            self.set_status(500)
            self.finish(json.dumps({"error": str(exc), "status": "error"}))


class AIAgentV2SessionProxyHandler(AIChatProxyHandler):
    """Proxy handler for agent v2 session endpoints."""

    @web.authenticated
    async def get(self):
        user_token = await self.get_user_token() or self.get_test_token_from_env()
        if not user_token:
            self.set_status(401)
            self.finish(
                json.dumps(
                    {
                        "error": "Authentication required. Please log in again.",
                        "status": "auth_required",
                    }
                )
            )
            return

        remote_url = f"{self.remote_backend_url}/v2/agent/session"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {user_token}",
        }

        try:
            ssl_context = ssl.create_default_context(cafile=certifi.where())
        except Exception as exc:
            logging.warning(
                f"[AGENT-V2-PROXY] Failed to create SSL context with certifi: {exc}"
            )
            ssl_context = ssl.create_default_context()

        connector = aiohttp.TCPConnector(ssl=ssl_context)
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get(remote_url, params=self.request.query, headers=headers) as response:
                payload_text = await response.text()
                if response.status != 200:
                    self.set_status(response.status)
                    self.finish(payload_text)
                    return
                self.finish(payload_text)

    @web.authenticated
    async def post(self):
        user_token = await self.get_user_token() or self.get_test_token_from_env()
        if not user_token:
            self.set_status(401)
            self.finish(
                json.dumps(
                    {
                        "error": "Authentication required. Please log in again.",
                        "status": "auth_required",
                    }
                )
            )
            return

        try:
            body_data = json.loads(self.request.body.decode("utf-8")) if self.request.body else {}
        except Exception:
            body_data = {}

        remote_url = f"{self.remote_backend_url}/v2/agent/session"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {user_token}",
        }

        try:
            ssl_context = ssl.create_default_context(cafile=certifi.where())
        except Exception as exc:
            logging.warning(
                f"[AGENT-V2-PROXY] Failed to create SSL context with certifi: {exc}"
            )
            ssl_context = ssl.create_default_context()

        connector = aiohttp.TCPConnector(ssl=ssl_context)
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.post(remote_url, json=body_data, headers=headers) as response:
                payload_text = await response.text()
                if response.status != 200:
                    self.set_status(response.status)
                    self.finish(payload_text)
                    return
                self.finish(payload_text)

    async def options(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-User-Token")
        self.set_status(200)
