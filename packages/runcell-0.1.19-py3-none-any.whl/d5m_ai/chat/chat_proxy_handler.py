"""
Proxy handler for AI chat functionality.

This handler acts as a proxy between the frontend and the remote backend server.
It forwards chat requests to the remote backend and streams responses back to the frontend.

The remote backend handles all AI processing, while this proxy handles:
- User token-based authentication (replaces access key system)
- Request forwarding with user authentication
- Response streaming 
- CORS handling
- Error handling
- Credit-related error messaging
"""

import asyncio
import aiohttp
import logging
import json
import os
import re
import ssl
import certifi
from copy import deepcopy
from typing import Dict, Any, Optional
from jupyter_server.base.handlers import APIHandler
from tornado import web

from ..utils import build_remote_backend_url, get_server_url_from_handler
from ..auth.token_handler import get_current_user_token_string
from ..tools.registry import run_ask_tool
from ..tools.permission_gate import (
    GLOBAL_MODE_ASK_EVERY_TIME,
    DECISION_SKIP_ONCE,
    PERMISSION_CHANNEL_ERROR_OUTPUT,
    PERMISSION_INTERRUPTED_OUTPUT,
    apply_permission_response,
    build_permission_denied_output,
    build_permission_request_event,
    decision_allows_execution,
    get_permission_context,
    normalize_permission_preferences,
    should_auto_allow,
    wait_for_permission_response,
)
from .._version import __version__ as client_version
from ..agent.image_processor import ImageProcessor

logging.basicConfig(level=logging.INFO)

FRONTEND_NOTEBOOK_TOOLS = {
    "cell_execute",
    "edit_cell",
    "edit_markdown_cell",
    "insert_markdown_cell",
    "insert_cell",
    "run_cell",
    "delete_cell",
    "open_tab",
    "rerun_all_cells",
}

NOTEBOOK_TOOL_ERROR_PREFIX = "[NOTEBOOK_TOOL_ERROR]"
NOTEBOOK_TOOL_ERROR_GUARD_MESSAGE = (
    "One or more notebook operations returned "
    f"{NOTEBOOK_TOOL_ERROR_PREFIX}. "
    "You may continue with additional tool calls to recover, but do not claim the task is complete "
    "unless later tool outputs clearly show success. If recovery is not possible, explicitly report "
    "what remains blocked."
)
NOTEBOOK_TOOL_FAILURE_PREFIX_PATTERNS = (
    re.compile(r"^\s*error\b", re.IGNORECASE),
    re.compile(r"^\s*exception\b", re.IGNORECASE),
    re.compile(r"^\s*traceback\b", re.IGNORECASE),
    re.compile(r"^\s*cell execution failed\b", re.IGNORECASE),
    re.compile(r"^\s*execution failed\b", re.IGNORECASE),
    re.compile(r"^\s*failed\b", re.IGNORECASE),
)
DATA_IMAGE_URL_PATTERN = re.compile(r"^data:image/[a-z0-9.+-]+;base64,", re.IGNORECASE)
DATA_IMAGE_URL_INLINE_PATTERN = re.compile(
    r"data:image/[a-z0-9.+-]+;base64,[a-z0-9+/=\s]+",
    re.IGNORECASE,
)
REDACTED_CONTENT = "[content omitted]"


def _parse_tool_arguments(value: Any) -> Dict[str, Any]:
    """Parse tool arguments with tolerant handling for double-encoded JSON."""
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    if not isinstance(value, str):
        return {"raw_arguments": value}

    raw = value.strip()
    if not raw:
        return {}

    try:
        parsed: Any = json.loads(raw)
    except json.JSONDecodeError:
        return {"raw_arguments": value}

    if isinstance(parsed, str):
        try:
            parsed = json.loads(parsed)
        except json.JSONDecodeError:
            return {"raw_arguments": value}

    if isinstance(parsed, dict):
        return parsed

    return {"raw_arguments": value}


class AIChatProxyHandler(APIHandler):
    """Proxy handler for AI chat requests that forwards to remote backend."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Get remote backend URL using unified URL builder
        self.remote_backend_url = build_remote_backend_url("chat").replace("/chat", "")
        
        logging.info(f"[CHAT-PROXY] Initialized with remote backend: {self.remote_backend_url}")
        logging.info("[CHAT-PROXY] Token authentication enabled - will forward tokens to remote backend")

        # Lazily initialized when we first need to process cell images.
        self._image_processor: ImageProcessor | None = None
        self._image_processor_connection_id: str | None = None
    
    async def get_user_token(self) -> Optional[str]:
        """
        Extract user token from local file or request.
        
        Priority order:
        1. Local file token (saved when OAuth succeeds)
        2. Request headers/cookies (fallback for compatibility)
        
        Returns:
            User token if found, None otherwise
        """
        # **PRIORITY 1: Check local file token (saved when OAuth succeeds)**
        local_token = get_current_user_token_string()
        if local_token:
            logging.info(f"[CHAT-PROXY] ✅ Found token in local file (length: {len(local_token)})")
            return local_token
        
        logging.info("[CHAT-PROXY] No token found in local file, checking request headers/cookies...")
        
        # Debug: Log all available headers and cookies for troubleshooting
        logging.info(f"[CHAT-PROXY] DEBUG - Request headers: {dict(self.request.headers)}")
        logging.info(f"[CHAT-PROXY] DEBUG - Available cookies: {list(self.cookies.keys())}")
        
        # Check for plugin auth token specifically
        plugin_token = self.get_cookie("plugin_auth_token_v2")
        if plugin_token:
            logging.info(f"[CHAT-PROXY] DEBUG - Found plugin_auth_token_v2: {plugin_token[:20]}...")
        else:
            logging.info("[CHAT-PROXY] DEBUG - No plugin_auth_token_v2 cookie found")
            
        # Check each Supabase token type
        for cookie_name in self.cookies.keys():
            if cookie_name.startswith("sb-") and "auth-token" in cookie_name:
                cookie_value = self.cookies[cookie_name]
                token_value = cookie_value.value if hasattr(cookie_value, 'value') else str(cookie_value)
                logging.info(f"[CHAT-PROXY] DEBUG - {cookie_name}: {token_value[:20]}...")
        
        # Check Authorization header
        auth_header = self.request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]  # Remove "Bearer " prefix
            logging.info("[CHAT-PROXY] Found token in Authorization header")
            return token
        
        # Check X-User-Token header
        user_token = self.request.headers.get("X-User-Token", "")
        if user_token:
            logging.info("[CHAT-PROXY] Found token in X-User-Token header")
            return user_token
        
        # Look for actual Supabase auth tokens that are present in the cookies
        supabase_token_patterns = [
            "sb-",  # Supabase tokens start with sb-
            "plugin_auth_token_v2",
            "auth_token", 
            "user_token",
            "jwt_token"
        ]
        
        # **PRIORITY 1: Plugin Auth Token (JWT format expected by localhost:3000)**
        plugin_token = self.get_cookie("plugin_auth_token_v2")
        if plugin_token and plugin_token.startswith("eyJ") and plugin_token.count('.') == 2:
            logging.info(f"[CHAT-PROXY] ✅ Found valid JWT plugin_auth_token_v2 (length: {len(plugin_token)})")
            return plugin_token
        elif plugin_token:
            logging.warning(f"[CHAT-PROXY] ⚠️ plugin_auth_token_v2 exists but doesn't look like JWT: {plugin_token[:20]}...")
        
        # **PRIORITY 2: Other JWT tokens in cookies**
        for cookie_name in ["auth_token", "user_token", "jwt_token"]:
            token_cookie = self.get_cookie(cookie_name)
            if token_cookie and token_cookie.startswith("eyJ") and token_cookie.count('.') == 2:
                logging.info(f"[CHAT-PROXY] ✅ Found JWT token in cookie: {cookie_name} (length: {len(token_cookie)})")
                return token_cookie
            elif token_cookie:
                logging.warning(f"[CHAT-PROXY] ⚠️ {cookie_name} exists but not JWT format: {token_cookie[:20]}...")
        
        # **FALLBACK: Supabase tokens (likely incompatible with localhost:3000)**
        for cookie_name, cookie_value in self.cookies.items():
            if (cookie_name.startswith("sb-") and 
                "auth-token" in cookie_name and 
                "code-verifier" not in cookie_name):
                token_value = cookie_value.value if hasattr(cookie_value, 'value') else str(cookie_value)
                logging.warning(f"[CHAT-PROXY] ⚠️ Using Supabase token as fallback: {cookie_name} - likely incompatible with localhost:3000")
                logging.warning(f"[CHAT-PROXY] Consider setting D5M_TEST_USER_TOKEN environment variable with a valid JWT")
                return token_value
        
        # Check for token in query parameters (fallback, not recommended for production)
        token_param = self.get_argument("token", None)
        if token_param:
            logging.info("[CHAT-PROXY] Found token in query parameters")
            return token_param
        
        # Check request body for token (in case frontend sends it in the body)
        try:
            body_data = json.loads(self.request.body.decode("utf-8"))
            if "user_token" in body_data:
                logging.info("[CHAT-PROXY] Found token in request body")
                return body_data["user_token"]
        except (json.JSONDecodeError, UnicodeDecodeError):
            pass
        
        # Log detailed debugging information
        logging.warning("[CHAT-PROXY] No user token found in request")
        logging.warning(f"[CHAT-PROXY] Available Supabase cookies: {[name for name in self.cookies.keys() if name.startswith('sb-')]}")
        
        return None
    
    def get_test_token_from_env(self) -> Optional[str]:
        """
        Get test token from environment variable for development/testing.
        
        This is a temporary method to facilitate testing without frontend integration.
        Remove this in production.
        
        Returns:
            Test token if available
        """
        test_token = os.environ.get("D5M_TEST_USER_TOKEN")
        if test_token:
            # Validate that test token is a JWT
            if test_token.startswith("eyJ") and test_token.count('.') == 2:
                logging.warning("[CHAT-PROXY] ✅ Using valid JWT test token from D5M_TEST_USER_TOKEN")
                logging.warning("[CHAT-PROXY] This should only be used for testing!")
                return test_token
            else:
                logging.error(f"[CHAT-PROXY] ❌ D5M_TEST_USER_TOKEN is not a valid JWT format: {test_token[:20]}...")
                logging.error("[CHAT-PROXY] JWT should start with 'eyJ' and have exactly 2 dots")
                return None
        return None
    

        
    @web.authenticated
    async def post(self):
        """Handle POST requests by forwarding to remote backend with user authentication."""
        try:
            # Step 1: Get user token (no verification - let remote backend handle that)
            user_token = await self.get_user_token()
            
            # Fallback to test token if no token found (for development/testing)
            if not user_token:
                user_token = self.get_test_token_from_env()
            
            if not user_token:
                self.set_status(401)
                self.finish(json.dumps({
                    "error": "Authentication required. You may not be signed in or there may be an issue with your authentication. Please try signing in again.",
                    "status": "auth_required",
                    "debug_info": {
                        "frontend_integration_needed": True,
                        "suggestions": [
                            "Save the plugin_auth_token_v2 to the server via /api/d5m_ai/auth/token",
                            "Frontend should send token in Authorization header: 'Bearer <token>'",
                            "Frontend should send token in X-User-Token header",
                            "Check if Supabase auth tokens are available in cookies"
                        ]
                    }
                }))
                return
            
            logging.info(f"[CHAT-PROXY] Found user token, forwarding to remote backend")
            
            # Step 2: Parse request body
            body_data = json.loads(self.request.body.decode("utf-8"))
            messages = body_data.get("messages", [])
            code_cells = body_data.get("code_cells", [])
            stream = body_data.get("stream", True)
            model = body_data.get("model", "anthropic/claude-haiku-4-5")
            
            logging.info(f"[CHAT-PROXY] Forwarding chat request: model={model}, stream={stream}")
            
            if not messages:
                self.set_status(400)
                self.finish(json.dumps({"error": "No messages provided"}))
                return

            # Step 3: Forward request to remote backend with user token
            await self._forward_to_remote_backend(body_data, stream, user_token)
            
        except Exception as e:
            logging.error(f"[CHAT-PROXY] Error handling chat request: {e}")
            self.set_status(500)
            self.finish(json.dumps({
                "error": str(e),
                "status": "error"
            }))

    async def _forward_to_remote_backend(self, body_data: Dict[str, Any], stream: bool, user_token: str):
        """Forward request to remote backend and handle response."""
        try:
            remote_url = f"{self.remote_backend_url}/chat"
            remote_body_data = dict(body_data)
            # permission_preferences are consumed by the local proxy permission gate only.
            remote_body_data.pop("permission_preferences", None)

            # Add starting content_index to body for conversation continuations
            if hasattr(self, '_unified_content_index') and self._unified_content_index > 0:
                body_data['starting_content_index'] = self._unified_content_index
                remote_body_data['starting_content_index'] = self._unified_content_index
                logging.info(f"[CHAT-PROXY] Continuing conversation with starting_content_index: {self._unified_content_index}")

            # Inject client version
            body_data['client_version'] = client_version
            remote_body_data['client_version'] = client_version

            # Prepare headers with user authentication
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {user_token}'
            }
            logging.debug("[CHAT-PROXY] Adding user token to remote backend request")
            
            # Create SSL context with proper certificate verification
            try:
                ssl_context = ssl.create_default_context(cafile=certifi.where())
                logging.debug("[CHAT-PROXY] Using certifi certificate bundle for SSL verification")
            except Exception as e:
                logging.warning(f"[CHAT-PROXY] Failed to create SSL context with certifi: {e}")
                # Fallback to default SSL context
                ssl_context = ssl.create_default_context()
            
            # Create connector with SSL context
            connector = aiohttp.TCPConnector(ssl=ssl_context)
            
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(
                    remote_url,
                    json=remote_body_data,
                    headers=headers
                ) as response:
                    
                    if response.status != 200:
                        # Handle error response
                        error_text = await response.text()
                        logging.error(f"[CHAT-PROXY] Remote backend error {response.status}: {error_text}")
                        
                        # Try to parse error as JSON for better error handling
                        try:
                            error_data = json.loads(error_text)
                            error_status = error_data.get("status", "error")
                            error_message = error_data.get("error", error_text)
                            error_request_id = error_data.get("request_id")
                            
                            # Handle specific error types
                            if response.status == 401:
                                await self._handle_remote_error_response(
                                    status_code=401,
                                    error_message="Authentication failed. Please log in again.",
                                    error_status="auth_error",
                                    error_request_id=error_request_id,
                                    stream=stream,
                                )
                            elif response.status == 402:
                                await self._handle_remote_error_response(
                                    status_code=402,
                                    error_message=error_message,
                                    error_status="insufficient_credits",
                                    error_request_id=error_request_id,
                                    stream=stream,
                                )
                            else:
                                await self._handle_remote_error_response(
                                    status_code=response.status,
                                    error_message=error_message,
                                    error_status=error_status,
                                    error_request_id=error_request_id,
                                    stream=stream,
                                )
                        except json.JSONDecodeError:
                            # Fallback for non-JSON error responses
                            await self._handle_remote_error_response(
                                status_code=response.status,
                                error_message=f"Remote backend error: {error_text}",
                                error_status="error",
                                stream=stream,
                            )
                        return
                    
                    if stream:
                        # Handle streaming response
                        # Track unified content index across all streaming calls for this request
                        if not hasattr(self, '_unified_content_index'):
                            self._unified_content_index = 0
                        
                        pending_tool_data = await self._handle_streaming_response(response, self._unified_content_index)
                        if pending_tool_data:
                            # Update the unified content index for the next continuation
                            self._unified_content_index = pending_tool_data.get('max_content_index', self._unified_content_index)
                            await self._handle_pending_tool_call(pending_tool_data, body_data, user_token)
                    else:
                        # Handle non-streaming response
                        response_data = await response.json()
                        self.finish(json.dumps(response_data))

        except aiohttp.ClientConnectorError as e:
            logging.error(f"[CHAT-PROXY] Cannot connect to remote backend at {self.remote_backend_url}: {e}")
            self.set_status(503)
            self.finish(json.dumps({
                "error": f"Cannot connect to chat remote backend. Please ensure the remote backend server is running at {self.remote_backend_url}",
                "status": "error"
            }))
        except Exception as e:
            logging.error(f"[CHAT-PROXY] Error forwarding to remote backend: {e}")
            self.set_status(500)
            self.finish(json.dumps({
                "error": str(e),
                "status": "error"
            }))

    async def _handle_streaming_response(self, response: aiohttp.ClientResponse, unified_content_index: int = 0) -> Optional[Dict[str, Any]]:
        """Handle streaming response from remote backend.

        Args:
            response: The aiohttp response to stream
            unified_content_index: The current unified content index (for tracking message order across continuations)

        Returns a tuple of (pending_tool_payload, last_content_index) if the conversation should continue,
        or (None, last_content_index) when streaming completes.
        """
        try:
            # Set up streaming response headers (exactly like original handler)
            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")

            logging.info(f"[CHAT-PROXY] Starting to stream response from remote backend (starting content_index: {unified_content_index})")

            buffer = ""
            assistant_text = ""
            max_content_index = unified_content_index

            # Read response content as chunks and forward after processing
            async for chunk in response.content.iter_chunks():
                if not chunk[0]:
                    continue

                chunk_text = chunk[0].decode('utf-8', errors='ignore')
                buffer += chunk_text

                while '\n\n' in buffer:
                    event_text, buffer = buffer.split('\n\n', 1)
                    if not event_text.startswith('data: '):
                        continue

                    payload_text = event_text[6:]

                    try:
                        payload = json.loads(payload_text)
                    except json.JSONDecodeError:
                        logging.error(f"[CHAT-PROXY] Failed to parse SSE payload: {payload_text}")
                        continue

                    status = payload.get('status')
                    payload_type = payload.get('type')

                    # Track the maximum content_index seen
                    if 'content_index' in payload:
                        content_idx = payload['content_index']
                        if content_idx > max_content_index:
                            max_content_index = content_idx

                    if status == 'streaming' and payload.get('chunk'):
                        assistant_text += payload['chunk']
                        # Ensure content_index is present for proper ordering
                        if 'content_index' not in payload:
                            logging.warning("[CHAT-PROXY] Chunk without content_index - this should not happen with updated backend")
                        await self._write_sse_event(payload)
                    elif payload_type in {
                        'reasoning',
                        'reasoning_done',
                        'tool_call',
                        'tool_call_args_update',
                        'tool_call_output'
                    }:
                        payload = self._sanitize_streaming_tool_payload(payload)
                        await self._write_sse_event(payload)
                    elif status == 'pending_tool':
                        payload.setdefault('assistant_text', assistant_text)
                        payload['max_content_index'] = max_content_index
                        logging.info(f"[CHAT-PROXY] Pending tool call detected (max_content_index: {max_content_index})")
                        return payload
                    elif status == 'done':
                        await self._write_sse_event(payload)
                        logging.info("[CHAT-PROXY] Streaming completed")
                        return None
                    else:
                        await self._write_sse_event(payload)

        except Exception as e:
            logging.error(f"[CHAT-PROXY] Error during streaming: {e}")
            # Send error event to frontend
            error_data = json.dumps({'error': str(e), 'status': 'error'})
            self.write(f"data: {error_data}\n\n")
            await self.flush()
        return None

    async def _write_sse_event(self, payload: Dict[str, Any]):
        """Write a single SSE event to the frontend."""
        event_text = json.dumps(payload)
        self.write(f"data: {event_text}\n\n")
        await self.flush()

    async def _handle_remote_error_response(
        self,
        *,
        status_code: int,
        error_message: str,
        error_status: str,
        stream: bool,
        error_request_id: Optional[str] = None,
    ) -> None:
        """
        Return remote-backend errors either as SSE events (if stream already started)
        or as normal HTTP JSON errors.
        """
        response_payload: Dict[str, Any] = {
            "error": error_message,
            "status": error_status,
        }
        if error_request_id:
            response_payload["request_id"] = error_request_id

        headers_already_sent = bool(getattr(self, "_headers_written", False))
        if stream and headers_already_sent:
            sse_payload = {
                "status": "error",
                "error": error_message,
            }
            if error_request_id:
                sse_payload["request_id"] = error_request_id
            try:
                await self._write_sse_event(sse_payload)
            except Exception as exc:
                logging.warning(
                    "[CHAT-PROXY] Failed to emit SSE error event after remote failure: %s",
                    exc,
                )
            return

        self.set_status(status_code)
        self.finish(json.dumps(response_payload))

    def _normalize_frontend_tool_args(
        self, tool_name: str, tool_args: Dict[str, Any]
    ) -> tuple[Dict[str, Any], str | None]:
        """Normalize frontend tool args so Jupyter contents paths are used."""
        if not tool_args:
            return tool_args, None

        normalized = dict(tool_args)
        if tool_name in FRONTEND_NOTEBOOK_TOOLS:
            file_path = normalized.get("file_path")
            if file_path:
                resolved_path, error_message = self._resolve_contents_path(file_path)
                if error_message:
                    return {}, error_message
                normalized["file_path"] = resolved_path
        elif tool_name == "read_file":
            file_path = normalized.get("file_path")
            if file_path:
                normalized["file_path"] = self._resolve_read_file_path(file_path)
        return normalized, None

    def _get_contents_root_dir(self) -> str:
        root_dir = getattr(getattr(self, "contents_manager", None), "root_dir", None)
        if not root_dir:
            contents_manager = self.settings.get("contents_manager")
            root_dir = getattr(contents_manager, "root_dir", None) if contents_manager else None
        if not root_dir:
            root_dir = (
                self.settings.get("server_root_dir")
                or self.settings.get("root_dir")
                or os.getcwd()
            )
        return root_dir

    def _resolve_contents_path(self, file_path: str) -> tuple[str, str | None]:
        """Convert absolute filesystem paths to Jupyter contents paths when possible."""
        from ..agent.path_utils import resolve_contents_path

        root_dir = self._get_contents_root_dir()
        return resolve_contents_path(file_path, root_dir, cwd=os.getcwd())

    def _resolve_read_file_path(self, file_path: str) -> str:
        """Resolve read_file paths relative to Jupyter root when cwd-relative lookup misses."""
        if not isinstance(file_path, str) or not file_path:
            return file_path
        if os.path.isabs(file_path) or os.path.exists(file_path):
            return file_path

        normalized = file_path.replace("\\", os.sep).replace("/", os.sep)
        while normalized.startswith(f".{os.sep}"):
            normalized = normalized[2:]
        normalized = normalized.lstrip(os.sep)

        candidate = os.path.join(self._get_contents_root_dir(), normalized)
        if os.path.exists(candidate):
            return candidate
        return file_path

    @staticmethod
    def _is_notebook_tool_failure_output(output: Any) -> bool:
        if not isinstance(output, str):
            return False
        stripped = output.strip()
        if not stripped:
            return False

        if stripped.startswith(NOTEBOOK_TOOL_ERROR_PREFIX):
            return True

        first_line = next((line.strip() for line in stripped.splitlines() if line.strip()), "")
        if not first_line:
            return False

        for pattern in NOTEBOOK_TOOL_FAILURE_PREFIX_PATTERNS:
            if pattern.search(first_line):
                return True

        lowered_line = first_line.lower()
        if " but failed to " in lowered_line:
            return True
        if " traceback (most recent call last):" in f" {lowered_line}":
            return True
        return False

    @staticmethod
    def _ensure_notebook_error_prefix(output: Any) -> Any:
        if not isinstance(output, str):
            return output
        if output.startswith(NOTEBOOK_TOOL_ERROR_PREFIX):
            return output
        return f"{NOTEBOOK_TOOL_ERROR_PREFIX} {output}"

    def _annotate_notebook_tool_failure(
        self,
        tool_name: str,
        tool_result: Any,
        sse_output: Any,
    ) -> tuple[Any, Any, bool]:
        if tool_name not in FRONTEND_NOTEBOOK_TOOLS:
            return tool_result, sse_output, False

        has_failure = (
            self._is_notebook_tool_failure_output(tool_result)
            or self._is_notebook_tool_failure_output(sse_output)
        )
        if not has_failure:
            return tool_result, sse_output, False

        return (
            self._ensure_notebook_error_prefix(tool_result),
            self._ensure_notebook_error_prefix(sse_output),
            True,
        )

    def _get_image_processor(self, connection_id: str | None) -> ImageProcessor:
        """Create/reuse an ImageProcessor for replacing base64 image outputs."""
        if not self._image_processor or self._image_processor_connection_id != connection_id:
            server_url = get_server_url_from_handler(
                self,
                fallback=os.environ.get("SERVER_URL", "http://localhost:8888"),
            )
            self._image_processor = ImageProcessor(connection_id or "unknown", server_url)
            self._image_processor_connection_id = connection_id
        return self._image_processor

    @staticmethod
    def _is_data_image_url(value: Any) -> bool:
        if not isinstance(value, str):
            return False
        return bool(DATA_IMAGE_URL_PATTERN.match(value.strip()))

    @staticmethod
    def _redact_data_urls(value: Any) -> Any:
        if isinstance(value, str):
            if DATA_IMAGE_URL_PATTERN.match(value.strip()):
                return REDACTED_CONTENT
            return DATA_IMAGE_URL_INLINE_PATTERN.sub(REDACTED_CONTENT, value)
        if isinstance(value, list):
            return [AIChatProxyHandler._redact_data_urls(item) for item in value]
        if isinstance(value, dict):
            return {
                key: AIChatProxyHandler._redact_data_urls(item)
                for key, item in value.items()
            }
        return value

    async def _prepare_interpret_image_args(
        self,
        tool_args: Dict[str, Any],
        connection_id: str | None,
    ) -> Dict[str, Any]:
        """Convert data URLs into local image-service URLs before tool execution."""
        normalized = dict(tool_args)
        image_url = normalized.get("image_url")
        if not self._is_data_image_url(image_url):
            return normalized

        try:
            processor = self._get_image_processor(connection_id)
            replacement = await processor.save_image_directly(str(image_url))
            if replacement:
                normalized["image_url"] = replacement
            else:
                normalized["image_url"] = ""
        except Exception as exc:
            logging.warning(
                "[CHAT-PROXY] Failed to convert interpret_image data URL: %s",
                exc,
            )
            normalized["image_url"] = ""
        return normalized

    @staticmethod
    def _sanitize_tool_args_for_history(
        tool_name: str,
        tool_args: Dict[str, Any],
    ) -> Dict[str, Any]:
        if not isinstance(tool_args, dict):
            return {}

        sanitized: Dict[str, Any] = {}
        for key, value in tool_args.items():
            if key.startswith("_"):
                continue
            sanitized[key] = AIChatProxyHandler._redact_data_urls(value)

        if tool_name == "interpret_image":
            image_url = sanitized.get("image_url")
            if isinstance(image_url, str) and AIChatProxyHandler._is_data_image_url(image_url):
                sanitized["image_url"] = REDACTED_CONTENT

        return sanitized

    def _sanitize_streaming_tool_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        payload_type = payload.get("type")
        if payload_type not in {"tool_call", "tool_call_args_update"}:
            return payload
        if payload.get("tool") != "interpret_image":
            return payload

        args = payload.get("args")
        if not isinstance(args, dict):
            return payload

        sanitized_payload = dict(payload)
        sanitized_payload["args"] = self._sanitize_tool_args_for_history(
            "interpret_image", args
        )
        return sanitized_payload

    def _sanitize_interpret_image_output(self, value: Any) -> Any:
        return self._redact_data_urls(value)

    async def _run_local_tool(
        self, tool_name: str, tool_args: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Execute a proxy-local ask-mode tool."""
        return await run_ask_tool(tool_name, tool_args)

    async def _replace_base64_images(
        self,
        tool_name: str,
        tool_result: Any,
        sse_output: Any,
        connection_id: str | None,
    ) -> tuple[Any, Any]:
        """Replace base64 image payloads with URLs for notebook tool outputs."""
        if tool_name not in FRONTEND_NOTEBOOK_TOOLS:
            return tool_result, sse_output

        processor = None

        if isinstance(tool_result, str) and '"image/png"' in tool_result:
            processor = self._get_image_processor(connection_id)
            tool_result = await processor.replace_base64_with_urls(tool_result)

        if isinstance(sse_output, str) and '"image/png"' in sse_output:
            if processor is None:
                processor = self._get_image_processor(connection_id)
            sse_output = await processor.replace_base64_with_urls(sse_output)

        return tool_result, sse_output

    async def _handle_pending_tool_call(self, pending_data: Dict[str, Any], body_data: Dict[str, Any], user_token: str):
        """Execute local tools and continue the conversation with the remote backend."""
        client_tool_calls = pending_data.get('tool_calls', []) or []
        server_tool_calls = pending_data.get('server_tool_calls', []) or []
        server_tool_results = pending_data.get('server_tool_results', []) or []
        if not client_tool_calls and not server_tool_calls:
            logging.warning("[CHAT-PROXY] Pending tool payload without tool_calls")
            return

        messages = body_data.get('messages')
        if not isinstance(messages, list):
            logging.error("[CHAT-PROXY] Messages payload missing or invalid, resetting to list")
            messages = []
            body_data['messages'] = messages

        assistant_text = pending_data.get('assistant_text', '') or ''
        thinking_blocks = pending_data.get('thinking_blocks')
        if thinking_blocks:
            thinking_blocks = deepcopy(thinking_blocks)

        assistant_tool_calls = []
        assistant_tool_call_by_id: Dict[str, Dict[str, Any]] = {}
        for idx, tool_call in enumerate(server_tool_calls + client_tool_calls):
            function_info = tool_call.get('function', {}) or {}
            call_id = tool_call.get('id') or f'tool_call_{idx}'
            entry = {
                'id': call_id,
                'type': tool_call.get('type', 'function'),
                'function': {
                    'name': function_info.get('name', ''),
                    'arguments': function_info.get('arguments', '') or ''
                }
            }
            assistant_tool_calls.append(entry)
            assistant_tool_call_by_id[call_id] = entry

        assistant_message: Dict[str, Any] = {
            'role': 'assistant',
            'tool_calls': assistant_tool_calls
        }

        if thinking_blocks:
            content_array = list(thinking_blocks)
            if assistant_text:
                content_array.append({
                    'type': 'text',
                    'text': assistant_text
                })
            assistant_message['content'] = content_array
        else:
            assistant_message['content'] = assistant_text if assistant_text else None

        messages.append(assistant_message)

        if server_tool_results:
            for idx, tool_result in enumerate(server_tool_results):
                call_id = tool_result.get('tool_call_id') or tool_result.get('call_id') or f'server_tool_call_{idx}'
                messages.append({
                    'role': 'tool',
                    'tool_call_id': call_id,
                    'content': tool_result.get('content', '')
                })

        permission_preferences = normalize_permission_preferences(
            body_data.get("permission_preferences")
        )
        body_data["permission_preferences"] = permission_preferences
        notebook_tool_error_seen = False

        for idx, tool_call in enumerate(client_tool_calls):
            function_info = tool_call.get('function', {}) or {}
            tool_name = function_info.get('name', '')
            raw_arguments = function_info.get('arguments', '') or ''
            call_id = tool_call.get('id') or f'tool_call_{idx}'
            content_index = tool_call.get('content_index')

            parsed_args = _parse_tool_arguments(raw_arguments)
            if isinstance(parsed_args, dict) and "raw_arguments" in parsed_args:
                logging.warning(
                    f"[CHAT-PROXY] Failed to parse tool arguments for {tool_name}: {raw_arguments}"
                )
            # Inject connection_id for tools that require frontend WebSocket (e.g., cell_execute).
            if 'connection_id' not in parsed_args:
                # This comes from the ask-mode local-only WS established by the frontend.
                parsed_args['connection_id'] = body_data.get('connection_id')

            normalized_args, error_message = self._normalize_frontend_tool_args(
                tool_name, parsed_args
            )
            if tool_name == "interpret_image" and isinstance(normalized_args, dict):
                normalized_args = await self._prepare_interpret_image_args(
                    normalized_args,
                    body_data.get("connection_id"),
                )
                # Internal auth propagation for proxy-side interpret_image remote API calls.
                normalized_args["_user_token"] = user_token

            if isinstance(normalized_args, dict):
                assistant_entry = assistant_tool_call_by_id.get(call_id)
                if assistant_entry is not None:
                    safe_args = self._sanitize_tool_args_for_history(
                        tool_name,
                        normalized_args,
                    )
                    assistant_entry["function"]["arguments"] = json.dumps(
                        safe_args, ensure_ascii=False
                    )
            if error_message:
                logging.warning(
                    f"[CHAT-PROXY] Path resolution error for {tool_name}: {error_message}"
                )
                tool_result = error_message
                sse_output = tool_result
            else:
                async def _execute_local_tool_with_error_capture() -> tuple[str, Any]:
                    try:
                        tool_run = await self._run_local_tool(tool_name, normalized_args)
                    except Exception as exc:
                        logging.exception(
                            "[CHAT-PROXY] Local tool execution failed: tool=%s call_id=%s connection_id=%s",
                            tool_name,
                            call_id,
                            body_data.get("connection_id"),
                        )
                        error_output = f"Error: Tool '{tool_name}' failed: {exc}"
                        return error_output, error_output

                    if tool_run is None:
                        unsupported_output = (
                            f"Error: Unsupported tool '{tool_name}' in ask mode"
                        )
                        return unsupported_output, unsupported_output

                    return tool_run["llm_output"], tool_run["sse_output"]

                permission_context = get_permission_context(tool_name, normalized_args)
                should_request_permission = bool(
                    permission_context
                    and not should_auto_allow(permission_context, permission_preferences)
                )

                if should_request_permission:
                    permission_skip_output: str | None = None
                    permission_event = build_permission_request_event(
                        call_id=call_id,
                        tool_name=tool_name,
                        tool_args=normalized_args,
                        permission_context=permission_context,
                        permission_preferences=permission_preferences,
                        content_index=content_index,
                    )
                    await self._write_sse_event(permission_event)

                    permission_response: Dict[str, Any] = {
                        "decision": DECISION_SKIP_ONCE,
                        "global_mode": permission_preferences.get(
                            "global_mode", GLOBAL_MODE_ASK_EVERY_TIME
                        ),
                    }
                    try:
                        permission_response = await wait_for_permission_response(
                            body_data.get("connection_id"),
                            permission_event,
                        )
                    except asyncio.CancelledError:
                        logging.warning(
                            f"[CHAT-PROXY] Permission request cancelled while waiting for {tool_name}"
                        )
                        permission_skip_output = PERMISSION_INTERRUPTED_OUTPUT
                    except Exception as exc:
                        logging.warning(
                            f"[CHAT-PROXY] Permission request failed for {tool_name}: {exc}"
                        )
                        permission_skip_output = PERMISSION_CHANNEL_ERROR_OUTPUT

                    permission_preferences = apply_permission_response(
                        permission_preferences,
                        permission_context,
                        permission_response,
                    )
                    body_data["permission_preferences"] = permission_preferences

                    if permission_skip_output is None:
                        if decision_allows_execution(permission_response.get("decision", "")):
                            tool_result, sse_output = (
                                await _execute_local_tool_with_error_capture()
                            )
                        else:
                            permission_skip_output = build_permission_denied_output(
                                tool_name, normalized_args
                            )

                    if permission_skip_output is not None:
                        tool_result = permission_skip_output
                        sse_output = permission_skip_output
                else:
                    tool_result, sse_output = await _execute_local_tool_with_error_capture()

            if tool_name == "interpret_image":
                tool_result = self._sanitize_interpret_image_output(tool_result)
                sse_output = self._sanitize_interpret_image_output(sse_output)

            tool_result, sse_output = await self._replace_base64_images(
                tool_name,
                tool_result,
                sse_output,
                body_data.get("connection_id"),
            )
            tool_result, sse_output, has_notebook_tool_error = (
                self._annotate_notebook_tool_failure(
                    tool_name,
                    tool_result,
                    sse_output,
                )
            )
            notebook_tool_error_seen = notebook_tool_error_seen or has_notebook_tool_error

            messages.append({
                'role': 'tool',
                'tool_call_id': call_id,
                'content': tool_result
            })

            # Increment unified content index for tool output
            self._unified_content_index += 1
            
            await self._write_sse_event({
                'type': 'tool_call_output',
                'call_id': call_id,
                'output': sse_output,
                'content_index': self._unified_content_index,
                'status': 'streaming'
            })

        if notebook_tool_error_seen:
            messages.append({
                'role': 'system',
                'content': NOTEBOOK_TOOL_ERROR_GUARD_MESSAGE
            })

        # Continue the conversation with updated messages
        await self._forward_to_remote_backend(body_data, True, user_token)

    async def options(self):
        """Handle CORS preflight requests."""
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.set_header("Access-Control-Allow-Headers", "Content-Type")
        self.set_status(200)


# For backward compatibility, also export as AIChatHandler
AIChatHandler = AIChatProxyHandler 
