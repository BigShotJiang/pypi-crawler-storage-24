"""Standalone create_notebook tool for proxy-local execution."""

from __future__ import annotations

import asyncio
import json
import os
from typing import Any, Dict

from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds


def _resolve_notebook_path(file_path: str) -> str:
    path = file_path if os.path.isabs(file_path) else os.path.abspath(file_path)
    return path if path.endswith(".ipynb") else f"{path}.ipynb"


def _execute_create_notebook_tool_sync(args: Dict[str, Any]) -> str:
    """Create a minimal empty .ipynb notebook file."""
    file_path = args.get("file_path")
    if not file_path:
        return "Error: file_path is required"

    resolved_path = _resolve_notebook_path(file_path)
    if os.path.exists(resolved_path):
        return (
            f"Error: notebook '{resolved_path}' already exists. "
            "Choose a different path or delete the existing file first."
        )

    parent_dir = os.path.dirname(resolved_path)
    if parent_dir and not os.path.exists(parent_dir):
        try:
            os.makedirs(parent_dir, exist_ok=True)
        except Exception as exc:
            return f"Error: failed to create parent directory '{parent_dir}': {exc}"

    notebook = {
        "cells": [],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 5,
    }

    try:
        with open(resolved_path, "w", encoding="utf-8") as fh:
            json.dump(notebook, fh, indent=1)
    except PermissionError:
        return f"Error: permission denied creating '{resolved_path}'"
    except IsADirectoryError:
        return f"Error: '{resolved_path}' is a directory, not a file"
    except Exception as exc:
        return f"Error creating notebook '{resolved_path}': {exc}"

    return f"Created notebook: {resolved_path}\nThe notebook is empty and ready for use."


async def execute_create_notebook_tool(args: Dict[str, Any]) -> str:
    timeout_seconds = get_tool_timeout_seconds("create_notebook")
    try:
        task = asyncio.to_thread(_execute_create_notebook_tool_sync, args)
        if timeout_seconds is None:
            return await task
        return await asyncio.wait_for(task, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        if timeout_seconds is None:
            return "Error: create_notebook timed out"
        return f"Error: create_notebook timed out after {timeout_seconds:g} seconds"
