"""
Registry for ask-mode proxy tools.

ARCHITECTURE NOTE - Ask Mode Tool Execution:
============================================
Ask mode has a 3-layer architecture:

    Browser Frontend  -->  Proxy (JupyterLab extension)  -->  Remote Backend (d5m_ai_server)
         |                        |                                   |
    (displays UI)         (executes local tools)            (AI completion + web_search)

Tool execution flow:
1. Frontend sends chat request to Proxy (chat_proxy_handler.py)
2. Proxy forwards to Remote Backend for AI completion
3. When AI calls a tool, Remote Backend returns 'pending_tool' event
4. Proxy intercepts 'pending_tool', executes tool LOCALLY on user's machine
5. Proxy sends tool results back to Remote Backend to continue conversation
6. Frontend receives streamed response (tool outputs + AI continuation)

Why tools run on the PROXY (not browser frontend):
- read_file, list_dir, grep, glob: Need access to user's local filesystem
- edit, apply_patch: Need to modify files on user's machine
- web_search: Runs on Remote Backend (not here) because it needs API keys

IMPORTANT: The browser frontend correctly ignores 'pending_tool' events in chat.ts.
This is NOT a bug - the Proxy handles tool execution, not the frontend.
The comment "Proxy handles tool execution" in chat.ts is accurate.
"""

from __future__ import annotations

import json
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple

from .read_file import execute_read_file_tool
from .list_dir import execute_list_dir_tool
from .grep import execute_grep_tool
from .cell_execute import execute_cell_execute_tool
from .shell_execute import execute_shell_execute_tool
from .write_file import execute_write_file_tool
from .create_notebook import execute_create_notebook_tool
from .edit import execute_edit_tool
from .frontend_ws import (
    execute_delete_cell_tool,
    execute_edit_cell_tool,
    execute_edit_markdown_cell_tool,
    execute_insert_cell_tool,
    execute_insert_markdown_cell_tool,
    execute_open_tab_tool,
    execute_rerun_all_cells_tool,
    execute_run_cell_tool,
    execute_run_long_terminal_tool,
)
from .apply_patch import execute_apply_patch_tool
from .glob_search import execute_glob_tool
from .interpret_image import execute_interpret_image_tool


ToolExecutor = Callable[[Dict[str, Any]], Awaitable[Any]]
PostProcessor = Callable[[Any], Tuple[str, Any]]


def _default_postprocess(result: Any) -> Tuple[str, Any]:
    return str(result), result


def _list_dir_postprocess(result: Any) -> Tuple[str, Any]:
    """Return JSON string for LLM, structured list for SSE."""
    try:
        return json.dumps(result), result
    except Exception:
        return str(result), result


def _grep_postprocess(result: Any) -> Tuple[str, Any]:
    """
    Grep already returns JSON string; keep it for LLM, try to parse for SSE.
    """
    llm_output = result if isinstance(result, str) else str(result)
    try:
        sse_output = json.loads(llm_output)
    except Exception:
        sse_output = llm_output
    return llm_output, sse_output


def _glob_postprocess(result: Any) -> Tuple[str, Any]:
    """
    Return JSON string for LLM and structured list for SSE.
    """
    if isinstance(result, list):
        try:
            return json.dumps(result), result
        except Exception:
            pass
    return str(result), result


def _interpret_image_postprocess(result: Any) -> Tuple[str, Any]:
    """
    Keep LLM payload compact (analysis text only), while preserving structured
    fields like image_url/visual_ref for UI rendering in SSE.
    """
    if isinstance(result, dict):
        analysis = str(result.get("analysis") or "").strip()
        if analysis:
            return analysis, result
        try:
            return json.dumps(result), result
        except Exception:
            return str(result), result
    return str(result), result


_SHARED_LOCAL_TOOL_REGISTRY: Dict[str, Tuple[ToolExecutor, PostProcessor]] = {
    "read_file": (execute_read_file_tool, _default_postprocess),
    "list_dir": (execute_list_dir_tool, _list_dir_postprocess),
    "grep": (execute_grep_tool, _grep_postprocess),
    "shell_execute": (execute_shell_execute_tool, _default_postprocess),
    "write_file": (execute_write_file_tool, _default_postprocess),
    "edit": (execute_edit_tool, _default_postprocess),
    "create_notebook": (execute_create_notebook_tool, _default_postprocess),
    # Frontend/Jupyter tools via local-only WS bridge
    "edit_cell": (execute_edit_cell_tool, _default_postprocess),
    "edit_markdown_cell": (execute_edit_markdown_cell_tool, _default_postprocess),
    "insert_markdown_cell": (execute_insert_markdown_cell_tool, _default_postprocess),
    "insert_cell": (execute_insert_cell_tool, _default_postprocess),
    "run_cell": (execute_run_cell_tool, _default_postprocess),
    "delete_cell": (execute_delete_cell_tool, _default_postprocess),
    "open_tab": (execute_open_tab_tool, _default_postprocess),
    "run_long_terminal": (execute_run_long_terminal_tool, _default_postprocess),
    "rerun_all_cells": (execute_rerun_all_cells_tool, _default_postprocess),
    # NOTE: apply_patch is intentionally excluded from the shared registry so
    # ask mode remains read-only. It is enabled only in AGENT_V2_TOOL_REGISTRY.
    "glob": (execute_glob_tool, _glob_postprocess),
}


ASK_TOOL_REGISTRY: Dict[str, Tuple[ToolExecutor, PostProcessor]] = {
    **_SHARED_LOCAL_TOOL_REGISTRY,
}

AGENT_V2_TOOL_REGISTRY: Dict[str, Tuple[ToolExecutor, PostProcessor]] = {
    # Agent v2 tool execution path. Tool timeouts default to infinity (None)
    # and can be customized via d5m_ai.tools.tool_timeout_config.
    **_SHARED_LOCAL_TOOL_REGISTRY,
    "cell_execute": (execute_cell_execute_tool, _default_postprocess),
    "apply_patch": (execute_apply_patch_tool, _default_postprocess),
    "interpret_image": (execute_interpret_image_tool, _interpret_image_postprocess),
}


async def _run_tool_from_registry(
    registry: Dict[str, Tuple[ToolExecutor, PostProcessor]],
    tool_name: str,
    args: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    entry = registry.get(tool_name)
    if not entry:
        return None

    executor, postprocess = entry
    raw_result = await executor(args)
    llm_output, sse_output = postprocess(raw_result)

    return {
        "llm_output": llm_output,
        "sse_output": sse_output,
    }


async def run_ask_tool(tool_name: str, args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Execute a registered ask-mode tool.

    Returns:
        dict with llm_output (str) and sse_output (Any) or None if unsupported.
    """
    return await _run_tool_from_registry(ASK_TOOL_REGISTRY, tool_name, args)


async def run_agent_v2_tool(tool_name: str, args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Execute a registered agent-v2 proxy tool.

    This is intentionally separate from ask mode so ask can stay read-only.
    """
    return await _run_tool_from_registry(AGENT_V2_TOOL_REGISTRY, tool_name, args)
