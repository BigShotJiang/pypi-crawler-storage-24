"""
Central timeout configuration for proxy-local tools.

Default behavior is infinity timeout (represented as None), with optional
global and per-tool environment overrides.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT_ENV = "D5M_TOOL_TIMEOUT_DEFAULT_SECONDS"
OVERRIDES_ENV = "D5M_TOOL_TIMEOUT_OVERRIDES_JSON"

_INFINITY_STRINGS = {"", "none", "null", "inf", "infinity"}


def _coerce_timeout_seconds(raw_value: Any, source: str) -> tuple[float | None, bool]:
    """
    Convert an env value into timeout seconds.

    Returns (value, is_valid):
    - value None means infinity timeout.
    - is_valid False means caller should ignore this value and use fallback.
    """
    if raw_value is None:
        return None, True

    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in _INFINITY_STRINGS or normalized == "-1":
            return None, True
        try:
            numeric = float(normalized)
        except ValueError:
            logger.warning(
                "[TOOL-TIMEOUT] Invalid timeout %r from %s; expected positive seconds or infinity.",
                raw_value,
                source,
            )
            return None, False
    elif isinstance(raw_value, (int, float)):
        numeric = float(raw_value)
        if numeric == -1:
            return None, True
    else:
        logger.warning(
            "[TOOL-TIMEOUT] Unsupported timeout type %s from %s.",
            type(raw_value).__name__,
            source,
        )
        return None, False

    if numeric > 0:
        return numeric, True

    logger.warning(
        "[TOOL-TIMEOUT] Invalid timeout %.3f from %s; expected positive seconds or infinity.",
        numeric,
        source,
    )
    return None, False


def get_default_timeout_seconds() -> float | None:
    """
    Read the global timeout default.

    Returns:
    - None for infinity timeout (default when env is unset).
    - Positive float seconds when configured.
    """
    raw_default = os.environ.get(DEFAULT_TIMEOUT_ENV)
    if raw_default is None:
        return None

    timeout, is_valid = _coerce_timeout_seconds(raw_default, DEFAULT_TIMEOUT_ENV)
    if not is_valid:
        return None
    return timeout


def get_tool_timeout_seconds(tool_name: str) -> float | None:
    """
    Resolve timeout seconds for a specific tool.

    Precedence:
    1) Tool-specific value in D5M_TOOL_TIMEOUT_OVERRIDES_JSON
    2) Global default in D5M_TOOL_TIMEOUT_DEFAULT_SECONDS
    3) Infinity (None)
    """
    default_timeout = get_default_timeout_seconds()
    raw_overrides = os.environ.get(OVERRIDES_ENV)
    if not raw_overrides:
        return default_timeout

    try:
        parsed = json.loads(raw_overrides)
    except json.JSONDecodeError:
        logger.warning(
            "[TOOL-TIMEOUT] Invalid JSON in %s. Falling back to default timeout.",
            OVERRIDES_ENV,
        )
        return default_timeout

    if not isinstance(parsed, dict):
        logger.warning(
            "[TOOL-TIMEOUT] %s must be a JSON object. Falling back to default timeout.",
            OVERRIDES_ENV,
        )
        return default_timeout

    if tool_name not in parsed:
        return default_timeout

    timeout, is_valid = _coerce_timeout_seconds(
        parsed.get(tool_name), f"{OVERRIDES_ENV}.{tool_name}"
    )
    if not is_valid:
        return default_timeout
    return timeout
