"""
Standalone Glob Search Tool

Find files by glob pattern, sorted by modification time (newest first).
"""

import asyncio
import glob
import json
import os
from typing import Any, Dict, List, Union

from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds

MAX_GLOB_RESULTS = 300
MAX_GLOB_TOTAL_CONTENT_SIZE = 32 * 1024  # 32KB
MAX_GLOB_PATH_LENGTH = 220
PATH_TRUNCATION_SUFFIX = "... [path truncated]"


def _truncate_path_for_output(path: str) -> str:
    if len(path) <= MAX_GLOB_PATH_LENGTH:
        return path
    return path[:MAX_GLOB_PATH_LENGTH] + PATH_TRUNCATION_SUFFIX


def _apply_glob_limits(file_matches: List[str]) -> List[str]:
    """
    Limit glob output volume to keep tool results context-safe.
    """
    limited_matches: List[str] = []
    total_size = 0
    was_truncated = False
    original_count = len(file_matches)
    if original_count == 0:
        return []

    for match in file_matches:
        normalized_match = _truncate_path_for_output(match)

        # Rough JSON payload size estimate for each entry.
        entry_size = len(json.dumps(normalized_match))

        if len(limited_matches) >= MAX_GLOB_RESULTS:
            was_truncated = True
            break
        if total_size + entry_size > MAX_GLOB_TOTAL_CONTENT_SIZE:
            was_truncated = True
            break

        limited_matches.append(normalized_match)
        total_size += entry_size

    returned_count = len(limited_matches)
    summary = (
        f"... [summary] total_lines={original_count}; "
        f"returned_lines={returned_count}; truncated={'true' if was_truncated else 'false'}"
    )
    if was_truncated:
        summary += "; hint=narrow pattern/path"
    limited_matches.append(summary)

    return limited_matches


def _safe_get_mtime(path: str) -> float:
    """Return modification time for sorting, or 0 on failure."""
    try:
        return os.path.getmtime(path)
    except OSError:
        return 0.0


def _execute_glob_tool_sync(args: Dict[str, Any]) -> Union[List[str], str]:
    """
    Execute glob search.

    Args:
        args: Dictionary containing:
            - pattern: Glob pattern (required), e.g., "**/*.py"
            - path: Base directory to search (optional, defaults to ".")

    Returns:
        List of matching file paths sorted by modification time (newest first),
        or an error message string.
    """
    pattern = args.get("pattern")
    base_path = args.get("path") or "."

    if not pattern or not isinstance(pattern, str):
        return "Error: 'pattern' is required for glob tool"

    try:
        if not os.path.exists(base_path):
            return f"Error: Path '{base_path}' does not exist"
        if not os.path.isdir(base_path):
            return f"Error: '{base_path}' is not a directory"

        # Build a full pattern rooted at base_path unless an absolute pattern is provided
        search_pattern = pattern if os.path.isabs(pattern) else os.path.join(base_path, pattern)

        # Use recursive glob to support ** patterns
        matches = glob.glob(search_pattern, recursive=True)

        # Filter to files only and sort by mtime (newest first)
        file_matches = [path for path in matches if os.path.isfile(path)]
        file_matches = sorted(set(file_matches), key=_safe_get_mtime, reverse=True)

        return _apply_glob_limits(file_matches)
    except Exception as e:
        return f"Error executing glob search: {str(e)}"


async def execute_glob_tool(args: Dict[str, Any]) -> Union[List[str], str]:
    timeout_seconds = get_tool_timeout_seconds("glob")
    try:
        task = asyncio.to_thread(_execute_glob_tool_sync, args)
        if timeout_seconds is None:
            return await task
        return await asyncio.wait_for(task, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        if timeout_seconds is None:
            return "Error: glob timed out"
        return f"Error: glob timed out after {timeout_seconds:g} seconds"
