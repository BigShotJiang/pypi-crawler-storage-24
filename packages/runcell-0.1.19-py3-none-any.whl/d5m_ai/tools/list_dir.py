"""
Standalone List Directory Tool

A lightweight directory listing implementation that provides directory contents.
Returns file and folder information with proper error handling.
"""

import asyncio
import json
import logging
import os
from typing import Dict, Any, List

from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds

MAX_LIST_DIR_ENTRIES = 400
MAX_LIST_DIR_TOTAL_CONTENT_SIZE = 32 * 1024  # 32KB
MAX_LIST_DIR_NAME_LENGTH = 220
PATH_TRUNCATION_SUFFIX = "... [path truncated]"


def _truncate_name_for_output(name: str) -> str:
    if len(name) <= MAX_LIST_DIR_NAME_LENGTH:
        return name
    return name[:MAX_LIST_DIR_NAME_LENGTH] + PATH_TRUNCATION_SUFFIX


def _apply_list_dir_limits(entries: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    Limit list_dir output so a very large folder cannot overflow model context.
    """
    limited_entries: List[Dict[str, str]] = []
    total_size = 0
    was_truncated = False
    original_count = len(entries)

    for entry in entries:
        normalized_entry = {
            "name": _truncate_name_for_output(entry.get("name", "")),
            "type": entry.get("type", "file"),
        }
        entry_size = len(json.dumps(normalized_entry))

        if len(limited_entries) >= MAX_LIST_DIR_ENTRIES:
            was_truncated = True
            break
        if total_size + entry_size > MAX_LIST_DIR_TOTAL_CONTENT_SIZE:
            was_truncated = True
            break

        limited_entries.append(normalized_entry)
        total_size += entry_size

    returned_count = len(limited_entries)
    summary = (
        f"... [summary] total_lines={original_count}; "
        f"returned_lines={returned_count}; truncated={'true' if was_truncated else 'false'}"
    )
    if was_truncated:
        summary += "; hint=narrow directory path"
    limited_entries.append({"name": summary, "type": "info"})

    return limited_entries


def _execute_list_dir_tool_sync(args: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Execute the list_dir tool to list directory contents.

    Args:
        args: Dictionary containing:
            - dir: Path to the directory to list (optional, defaults to current working directory)

    Returns:
        List of dictionaries with 'name' and 'type' fields, or error dict
    """
    dir_path = args.get('dir', '.')
    
    # Handle empty string as current directory
    if not dir_path or dir_path.strip() == '':
        dir_path = '.'

    try:
        if not os.path.exists(dir_path):
            logging.error(f"[LIST-DIR] Directory does not exist: {dir_path}")
            return [{"name": f"Error: Directory '{dir_path}' does not exist", "type": "error"}]

        if not os.path.isdir(dir_path):
            logging.error(f"[LIST-DIR] Path is not a directory: {dir_path}")
            return [{"name": f"Error: '{dir_path}' is not a directory", "type": "error"}]

        # List directory contents
        entries = []
        
        try:
            items = os.listdir(dir_path)
        except PermissionError:
            logging.error(f"[LIST-DIR] Permission denied: {dir_path}")
            return [{"name": f"Error: Permission denied for directory '{dir_path}'", "type": "error"}]
        
        # Sort items: directories first, then files, both alphabetically
        dirs = []
        files = []
        
        for item in items:
            item_path = os.path.join(dir_path, item)
            try:
                if os.path.isdir(item_path):
                    dirs.append(item)
                else:
                    files.append(item)
            except (OSError, PermissionError):
                # Skip items we can't access
                continue
        
        # Sort both lists
        dirs.sort()
        files.sort()
        
        # Normalize directory path for display
        display_dir = dir_path if dir_path != '.' else ''
        
        # Build result list with full paths
        for dir_name in dirs:
            full_path = os.path.join(display_dir, dir_name) if display_dir else dir_name
            entries.append({
                "name": full_path,
                "type": "folder"
            })
        
        for file_name in files:
            full_path = os.path.join(display_dir, file_name) if display_dir else file_name
            entries.append({
                "name": full_path,
                "type": "file"
            })
        
        if not entries:
            return [
                {"name": "Directory is empty", "type": "info"},
                {
                    "name": "... [summary] total_lines=0; returned_lines=0; truncated=false",
                    "type": "info",
                },
            ]

        return _apply_list_dir_limits(entries)
        
    except Exception as e:
        logging.error(f"[LIST-DIR] Error executing list_dir tool: {e}")
        return [{"name": f"Error listing directory '{dir_path}': {str(e)}", "type": "error"}]


async def execute_list_dir_tool(args: Dict[str, Any]) -> List[Dict[str, str]]:
    timeout_seconds = get_tool_timeout_seconds("list_dir")
    try:
        task = asyncio.to_thread(_execute_list_dir_tool_sync, args)
        if timeout_seconds is None:
            return await task
        return await asyncio.wait_for(task, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        if timeout_seconds is None:
            timeout_message = "Error: list_dir timed out"
        else:
            timeout_message = f"Error: list_dir timed out after {timeout_seconds:g} seconds"
        return [{"name": timeout_message, "type": "error"}]
