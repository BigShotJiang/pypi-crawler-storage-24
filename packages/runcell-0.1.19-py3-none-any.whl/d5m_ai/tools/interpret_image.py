"""Proxy-local interpret_image tool for agent v2."""

from __future__ import annotations

import asyncio
import base64
import binascii
import json
import ssl
from typing import Any, Tuple
from urllib.parse import urlparse

import aiohttp
import certifi

from d5m_ai.agent.config import handler_registry
from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds
from d5m_ai.utils import build_remote_backend_url

MAX_INTERPRET_IMAGE_BYTES = 10 * 1024 * 1024
DEFAULT_MEDIA_TYPE = "image/png"


def _normalize_media_type(media_type: Any) -> str:
    if not isinstance(media_type, str):
        return DEFAULT_MEDIA_TYPE
    normalized = media_type.split(";")[0].strip().lower()
    if "/" not in normalized:
        return DEFAULT_MEDIA_TYPE
    return normalized


def _extract_data_url_parts(data_url: str) -> Tuple[str, str | None]:
    if not data_url.startswith("data:"):
        return DEFAULT_MEDIA_TYPE, None
    header, sep, payload = data_url.partition(",")
    if not sep or not payload:
        return DEFAULT_MEDIA_TYPE, None
    media_type = header.replace("data:", "").split(";")[0]
    return _normalize_media_type(media_type), payload


def _decode_base64_payload(payload: str) -> bytes:
    try:
        return base64.b64decode(payload, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("Invalid base64 image payload") from exc


def _validate_image_size(image_bytes: bytes) -> None:
    if len(image_bytes) > MAX_INTERPRET_IMAGE_BYTES:
        raise ValueError(
            f"Image too large: decoded payload exceeds {MAX_INTERPRET_IMAGE_BYTES} bytes"
        )


async def _download_image_bytes(image_url: str) -> Tuple[bytes, str]:
    parsed = urlparse(image_url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError(
            "Unsupported image URL scheme. Only data/http/https URLs are allowed."
        )
    if not parsed.netloc:
        raise ValueError("Invalid image URL: missing hostname")

    async with aiohttp.ClientSession() as session:
        async with session.get(image_url, allow_redirects=True) as response:
            if response.status >= 400:
                raise RuntimeError(
                    f"HTTP {response.status} while downloading image: {image_url}"
                )
            image_bytes = await response.read()
            media_type = _normalize_media_type(response.headers.get("Content-Type"))
    return image_bytes, media_type


async def _extract_image_payload(image_url: str) -> Tuple[str, str]:
    if image_url.startswith("data:"):
        media_type, payload = _extract_data_url_parts(image_url)
        if not payload:
            raise ValueError("Invalid data URL format for interpret_image")
        image_bytes = _decode_base64_payload(payload)
        _validate_image_size(image_bytes)
        return media_type, base64.b64encode(image_bytes).decode("utf-8")

    image_bytes, media_type = await _download_image_bytes(image_url)
    if not image_bytes:
        raise ValueError("Downloaded image is empty")
    _validate_image_size(image_bytes)
    return media_type, base64.b64encode(image_bytes).decode("utf-8")


def _normalize_visual_ref(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    normalized = value.strip()
    if normalized.startswith("visual_ref:"):
        normalized = normalized.split(":", 1)[1].strip()
    return normalized


def _is_data_image_url(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    normalized = value.strip().lower()
    return normalized.startswith("data:image/") and ";base64," in normalized


def _resolve_visual_ref_image_url(args: dict[str, Any]) -> tuple[str, str]:
    visual_ref = _normalize_visual_ref(args.get("visual_ref"))
    if not visual_ref:
        return "", ""

    connection_id = str(args.get("connection_id") or "").strip()
    if not connection_id:
        raise ValueError("connection_id is required when using visual_ref")

    handler = handler_registry.get(connection_id)
    if not handler:
        raise ValueError(f"No active frontend connection for connection_id {connection_id}")

    ref_store = getattr(handler, "visual_artifact_refs", None)
    if not isinstance(ref_store, dict):
        raise ValueError("No visual artifacts available for this connection")

    payload = ref_store.get(visual_ref)
    if isinstance(payload, str):
        image_url = payload
    elif isinstance(payload, dict):
        image_url = str(payload.get("image_url") or "").strip()
    else:
        image_url = ""

    if not image_url:
        raise ValueError(f"Unknown visual_ref: {visual_ref}")

    return image_url, visual_ref


def _build_remote_interpret_image_url() -> str:
    remote_base = build_remote_backend_url("chat").removesuffix("/chat")
    return f"{remote_base}/v2/agent/interpret_image"


def _build_ssl_context() -> ssl.SSLContext:
    try:
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


async def _call_remote_interpret_image(
    image_base64: str,
    media_type: str,
    user_token: str,
) -> str:
    remote_url = _build_remote_interpret_image_url()
    ssl_context = _build_ssl_context()
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {user_token}",
    }
    payload = {
        "image_data": image_base64,
        "media_type": _normalize_media_type(media_type),
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            remote_url,
            data=json.dumps(payload),
            headers=headers,
            ssl=ssl_context,
        ) as response:
            response_text = await response.text()
            try:
                response_json = json.loads(response_text)
            except json.JSONDecodeError:
                response_json = None

            if response.status != 200:
                error_message = response_text
                if isinstance(response_json, dict):
                    error_message = str(response_json.get("error") or error_message)
                raise RuntimeError(
                    f"interpret_image remote API failed ({response.status}): {error_message}"
                )

            if not isinstance(response_json, dict):
                raise RuntimeError("interpret_image remote API returned invalid JSON")
            analysis = response_json.get("analysis")
            if not isinstance(analysis, str) or not analysis.strip():
                raise RuntimeError("interpret_image remote API returned empty analysis")
            return analysis


async def _execute_interpret_image_tool_impl(args: dict[str, Any]) -> dict[str, str] | str:
    image_url = (args.get("image_url") or "").strip()
    visual_ref = ""
    if not image_url:
        image_url, visual_ref = _resolve_visual_ref_image_url(args)
    if not image_url:
        return "Error: image_url or visual_ref is required"

    user_token = (args.get("_user_token") or "").strip()
    if not user_token:
        return "Error: Missing authentication token for interpret_image"

    try:
        media_type, image_base64 = await _extract_image_payload(image_url)
        analysis = await _call_remote_interpret_image(image_base64, media_type, user_token)
        safe_image_url = image_url if not _is_data_image_url(image_url) else ""
        result_payload: dict[str, str] = {
            "analysis": analysis,
            "image_url": safe_image_url,
        }
        if visual_ref:
            result_payload["visual_ref"] = visual_ref
        return result_payload
    except Exception as exc:
        return f"Error: {exc}"


async def execute_interpret_image_tool(args: dict[str, Any]) -> dict[str, str] | str:
    timeout_seconds = get_tool_timeout_seconds("interpret_image")
    try:
        task = _execute_interpret_image_tool_impl(args)
        if timeout_seconds is None:
            return await task
        return await asyncio.wait_for(task, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        if timeout_seconds is None:
            return "Error: interpret_image timed out"
        return f"Error: interpret_image timed out after {timeout_seconds:g} seconds"
