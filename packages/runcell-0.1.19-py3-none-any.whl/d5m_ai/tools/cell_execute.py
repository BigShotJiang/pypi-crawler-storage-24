"""
Ask-mode cell_execute tool handler.

Routes execution to the local JupyterLab frontend via the proxy WebSocket.
"""

from typing import Any, Dict

from d5m_ai.agent.config import handler_registry
from d5m_ai.agent.tools.frontend.helpers import send_and_wait
from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds


async def execute_cell_execute_tool(args: Dict[str, Any]) -> str:
    """
    Execute a code cell via the local JupyterLab frontend.

    Expected args:
        - code (str): Python code to execute
        - file_path (str, optional): Notebook path
        - insert_position (int, optional): Cell index to insert at
        - connection_id (str): WebSocket connection identifier
    """
    if not isinstance(args, dict):
        args = {}

    connection_id = args.get("connection_id")
    if not connection_id:
        return "Error: Missing connection_id for cell_execute. Ensure local tool WebSocket is connected."

    handler = handler_registry.get(connection_id)
    if not handler:
        return f"Error: No active frontend connection for connection_id {connection_id}"

    code = args.get("code", "")
    if not isinstance(code, str) or not code.strip():
        return "Error: No code provided to execute."

    payload = {
        "code": code,
        "file_path": args.get("file_path"),
        "insert_position": args.get("insert_position"),
    }

    try:
        timeout = get_tool_timeout_seconds("cell_execute")
        # Reuse the same frontend tool path as agent mode, but scoped to the local-only WS handler.
        return await send_and_wait(
            handler,
            message_type="cell_execute",
            payload=payload,
            timeout=timeout,
            error_message="Error: No response from frontend for cell_execute (timeout)",
        )
    except Exception as exc:
        return f"Error: Failed to execute cell: {exc}"
