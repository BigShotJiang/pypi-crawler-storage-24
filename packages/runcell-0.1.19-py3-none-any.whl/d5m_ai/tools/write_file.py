"""Standalone write_file tool for proxy-local execution."""

from __future__ import annotations

import asyncio
import os
from typing import Any, Dict

from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds


def _resolve_path(file_path: str) -> str:
    return file_path if os.path.isabs(file_path) else os.path.abspath(file_path)


def _execute_write_file_tool_sync(args: Dict[str, Any]) -> str:
    """Write content to a file, creating parent directories as needed."""
    file_path = args.get("file_path")
    content = args.get("content")

    if not file_path:
        return "Error: file_path is required"
    if content is None:
        return "Error: content is required"

    resolved_path = _resolve_path(file_path)
    parent_dir = os.path.dirname(resolved_path)
    if parent_dir and not os.path.exists(parent_dir):
        try:
            os.makedirs(parent_dir, exist_ok=True)
        except Exception as exc:
            return f"Error: failed to create parent directory '{parent_dir}': {exc}"

    try:
        existed_before = os.path.exists(resolved_path)
        with open(resolved_path, "w", encoding="utf-8") as fh:
            fh.write(str(content))
    except PermissionError:
        return f"Error: permission denied writing to '{resolved_path}'"
    except IsADirectoryError:
        return f"Error: '{resolved_path}' is a directory, not a file"
    except Exception as exc:
        return f"Error writing to '{resolved_path}': {exc}"

    content_str = str(content)
    lines_count = len(content_str.splitlines())
    bytes_count = len(content_str.encode("utf-8"))
    action = "Updated" if existed_before else "Created"
    return (
        f"{action} file: {resolved_path}\n"
        f"Lines written: {lines_count}\n"
        f"Bytes written: {bytes_count}"
    )


async def execute_write_file_tool(args: Dict[str, Any]) -> str:
    timeout_seconds = get_tool_timeout_seconds("write_file")
    try:
        task = asyncio.to_thread(_execute_write_file_tool_sync, args)
        if timeout_seconds is None:
            return await task
        return await asyncio.wait_for(task, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        if timeout_seconds is None:
            return "Error: write_file timed out"
        return f"Error: write_file timed out after {timeout_seconds:g} seconds"
