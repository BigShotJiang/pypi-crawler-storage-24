import os
import mysql.connector
from mysql.connector.pooling import MySQLConnectionPool

_pool = None

def get_pool():
    global _pool
    if _pool is None:
        _pool = MySQLConnectionPool(
            pool_name="rcm_pool",
            pool_size=5,
            host=os.getenv("RCM_DB_HOST"),
            user=os.getenv("RCM_DB_USER"),
            password=os.getenv("RCM_DB_PASSWORD"),
            database=os.getenv("RCM_DB_NAME"),
        )
    return _pool

def get_connection():
    return get_pool().get_connection()