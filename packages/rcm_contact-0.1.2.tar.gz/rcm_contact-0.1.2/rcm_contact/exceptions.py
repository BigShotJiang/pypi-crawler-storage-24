class RCMError(Exception):
    pass

class DatabaseError(RCMError):
    pass