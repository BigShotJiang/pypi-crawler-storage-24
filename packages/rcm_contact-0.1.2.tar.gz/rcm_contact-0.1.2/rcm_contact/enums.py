from enum import IntEnum

class ChannelType(IntEnum):
    FAX = 1
    PHONE = 2
    EMAIL = 3

class ChannelPurpose(IntEnum):
    GENERAL = 0
    CLAIM_STATUS = 10


# CONTACT_TYPE
# 1 = Payor
# 2 = Hospital
# 3 = MedicalPractice
# 4 = Lab
# 5 = ImagingCenter
# 6 = Pharmacy
# 7 = BillingVendor
# 8 = Other

# CHANNEL_TYPE
# 1 = Fax
# 2 = Phone
# 3 = Email
# 4 = PortalURL