import re
from typing import Optional, Tuple

from .db import get_connection
from .models import ContactCreate, ContactChannelCreate, ContactUpdate, ContactChannelUpdate

def normalize_value(channel_type: int, value: str) -> Tuple[str, Optional[str]]:
    value = (value or "").strip()
    extension = None
    if channel_type in (1, 2):  # phone/fax
        # Extract extension if present (e.g., ext 123, x123, extension 123)
        ext_match = re.search(r'(?i)(?:ext|x|extension)\s*[:.]?\s*(\d+)', value)
        if ext_match:
            extension = ext_match.group(1)
            # Remove extension part from value before extracting digits
            value = value[:ext_match.start()]
        
        normalized = re.sub(r"\D", "", value)
        return normalized, extension
    return value.lower(), None

def get_preferred_channel(contact_id: int, channel_type: int, purpose: Optional[int] = None):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    query = """
    SELECT cc.*
    FROM CONTACT_CHANNEL cc
    JOIN CONTACT c ON cc.CONTACT_ID = c.CONTACT_ID
    WHERE cc.CONTACT_ID = %s
    AND cc.CHANNEL_TYPE = %s
    AND cc.IS_ACTIVE = 1
    AND cc.IS_DELETED = 0
    AND c.IS_ACTIVE = 1
    AND c.IS_DELETED = 0
    ORDER BY
        CASE
            WHEN %s IS NOT NULL AND cc.CHANNEL_PURPOSE = %s AND cc.IS_PRIMARY = 1 THEN 1
            WHEN %s IS NOT NULL AND cc.CHANNEL_PURPOSE = %s THEN 2
            WHEN cc.CHANNEL_PURPOSE = 0 AND cc.IS_PRIMARY = 1 THEN 3
            WHEN cc.CHANNEL_PURPOSE = 0 THEN 4
            ELSE 5
        END ASC,
        cc.UPDATED_AT DESC
    LIMIT 1
    """

    cursor.execute(query, (
        contact_id, channel_type,
        purpose, purpose,
        purpose, purpose
    ))

    result = cursor.fetchone()
    cursor.close()
    conn.close()

    return result

def search_contact_channels(search_text: str, limit: int = 25):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    search_text = (search_text or "").strip()
    if not search_text:
        return []

    is_email = "@" in search_text
    digits_only = re.sub(r"\D", "", search_text)
    is_phone = len(digits_only) >= 7 and not is_email

    query = """
        SELECT c.CONTACT_ID, c.NAME,
               cc.CONTACT_CHANNEL_ID, cc.CHANNEL_TYPE,
               cc.VALUE_RAW, cc.VALUE_NORMALIZED
        FROM CONTACT c
        JOIN CONTACT_CHANNEL cc ON c.CONTACT_ID = cc.CONTACT_ID
        WHERE c.IS_ACTIVE = 1 AND c.IS_DELETED = 0
        AND cc.IS_ACTIVE = 1 AND cc.IS_DELETED = 0
    """

    params = []

    if is_email:
        query += " AND (c.NAME LIKE %s OR cc.VALUE_NORMALIZED LIKE %s)"
        params.extend([f"%{search_text}%", f"%{search_text.lower()}%"])
    elif is_phone:
        query += " AND (c.NAME LIKE %s OR cc.VALUE_NORMALIZED LIKE %s)"
        params.extend([f"%{search_text}%", f"%{digits_only}%"])
    else:
        # General text search (name or raw value)
        query += " AND (c.NAME LIKE %s OR cc.VALUE_RAW LIKE %s OR cc.VALUE_NORMALIZED LIKE %s)"
        params.extend([f"%{search_text}%", f"%{search_text}%", f"%{search_text.lower()}%"])

    query += " LIMIT %s"
    params.append(limit)

    cursor.execute(query, tuple(params))
    results = cursor.fetchall()

    cursor.close()
    conn.close()

    return results

def get_contact_channels(contact_id: int, active_only: bool = True):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    
    query = "SELECT * FROM CONTACT_CHANNEL WHERE CONTACT_ID = %s"
    if active_only:
        query += " AND IS_ACTIVE = 1 AND IS_DELETED = 0"
        
    cursor.execute(query, (contact_id,))
    results = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return results

def add_contact_channel(payload: ContactChannelCreate) -> int:
    conn = get_connection()
    cursor = conn.cursor()

    normalized, extracted_ext = normalize_value(payload.channel_type, payload.value_raw)
    final_ext = payload.extension or extracted_ext

    query = """
        INSERT INTO CONTACT_CHANNEL
        (CONTACT_ID, CHANNEL_TYPE, CHANNEL_PURPOSE, VALUE_RAW, VALUE_NORMALIZED, 
         CHANNEL_LABEL, EXTENSION, CONTACT_PERSON_NAME, HOURS_OF_OPERATION, 
         LANGUAGE, NOTES, IS_PRIMARY, IS_VERIFIED, CREATED_BY)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    cursor.execute(query, (
        payload.contact_id,
        payload.channel_type,
        payload.channel_purpose,
        payload.value_raw,
        normalized,
        payload.channel_label,
        final_ext,
        payload.contact_person_name,
        payload.hours_of_operation,
        payload.language,
        payload.notes,
        int(payload.is_primary),
        int(payload.is_verified),
        payload.created_by
    ))

    conn.commit()
    channel_id = cursor.lastrowid
    cursor.close()
    conn.close()

    return channel_id

def update_contact_channel(channel_id: int, payload: ContactChannelUpdate) -> bool:
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT CHANNEL_TYPE FROM CONTACT_CHANNEL WHERE CONTACT_CHANNEL_ID = %s AND IS_DELETED = 0", (channel_id,))
    row = cursor.fetchone()
    if not row:
        cursor.close()
        conn.close()
        return False
        
    current_type = row['CHANNEL_TYPE']
    new_type = payload.channel_type if payload.channel_type is not None else current_type
    
    updates = []
    params = []
    
    for field, value in payload.__dict__.items():
        if value is not None:
            if field == 'value_raw':
                updates.append("VALUE_RAW = %s")
                params.append(value)
                norm_val, extracted_ext = normalize_value(new_type, value)
                updates.append("VALUE_NORMALIZED = %s")
                params.append(norm_val)
                if extracted_ext and payload.extension is None:
                    updates.append("EXTENSION = %s")
                    params.append(extracted_ext)
            elif field in ['is_primary', 'is_verified', 'is_active']:
                updates.append(f"{field.upper()} = %s")
                params.append(int(value))
            elif field != 'channel_type':
                updates.append(f"{field.upper()} = %s")
                params.append(value)

    if payload.channel_type is not None:
        updates.append("CHANNEL_TYPE = %s")
        params.append(payload.channel_type)
                
    if not updates:
        cursor.close()
        conn.close()
        return False
        
    query = f"UPDATE CONTACT_CHANNEL SET {', '.join(updates)} WHERE CONTACT_CHANNEL_ID = %s"
    params.append(channel_id)
    
    cursor.execute(query, tuple(params))
    conn.commit()
    affected = cursor.rowcount > 0
    cursor.close()
    conn.close()
    
    return affected

def delete_contact_channel(channel_id: int) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE CONTACT_CHANNEL SET IS_DELETED = 1, IS_ACTIVE = 0 WHERE CONTACT_CHANNEL_ID = %s", (channel_id,))
    conn.commit()
    affected = cursor.rowcount > 0
    cursor.close()
    conn.close()
    return affected

def create_contact(payload: ContactCreate) -> int:
    conn = get_connection()
    cursor = conn.cursor()

    query = """
        INSERT INTO CONTACT (
            CONTACT_TYPE, NAME, CLINIC_ID, DISPLAY_NAME, ORGANIZATION_NAME,
            DEPARTMENT, EXTERNAL_REF_TYPE, EXTERNAL_REF_ID, TAX_ID, NPI,
            ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, NOTES, CREATED_BY
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (
        payload.contact_type,
        payload.name,
        payload.clinic_id,
        payload.display_name,
        payload.organization_name,
        payload.department,
        payload.external_ref_type,
        payload.external_ref_id,
        payload.tax_id,
        payload.npi,
        payload.address1,
        payload.address2,
        payload.city,
        payload.state,
        payload.zip,
        payload.country,
        payload.notes,
        payload.created_by
    ))

    conn.commit()
    contact_id = cursor.lastrowid
    cursor.close()
    conn.close()

    return contact_id

def update_contact(contact_id: int, payload: ContactUpdate) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    
    updates = []
    params = []
    
    for field, value in payload.__dict__.items():
        if value is not None:
            if field == 'is_active':
                updates.append(f"{field.upper()} = %s")
                params.append(int(value))
            else:
                updates.append(f"{field.upper()} = %s")
                params.append(value)
            
    if not updates:
        cursor.close()
        conn.close()
        return False
        
    query = f"UPDATE CONTACT SET {', '.join(updates)} WHERE CONTACT_ID = %s"
    params.append(contact_id)
    
    cursor.execute(query, tuple(params))
    conn.commit()
    affected = cursor.rowcount > 0
    cursor.close()
    conn.close()
    
    return affected

def delete_contact(contact_id: int) -> bool:
    conn = get_connection()
    cursor = conn.cursor()
    
    # Soft delete contact
    cursor.execute("UPDATE CONTACT SET IS_DELETED = 1, IS_ACTIVE = 0 WHERE CONTACT_ID = %s", (contact_id,))
    affected = cursor.rowcount > 0
    
    # Cascade to channels
    cursor.execute("UPDATE CONTACT_CHANNEL SET IS_DELETED = 1, IS_ACTIVE = 0 WHERE CONTACT_ID = %s", (contact_id,))
    
    conn.commit()
    cursor.close()
    conn.close()
    return affected