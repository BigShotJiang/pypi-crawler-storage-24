from dataclasses import dataclass
from typing import Optional
from datetime import datetime

@dataclass
class ContactCreate:
    contact_type: int
    name: str
    clinic_id: Optional[int] = None
    display_name: Optional[str] = None
    organization_name: Optional[str] = None
    department: Optional[str] = None
    external_ref_type: Optional[str] = None
    external_ref_id: Optional[str] = None
    tax_id: Optional[str] = None
    npi: Optional[str] = None
    address1: Optional[str] = None
    address2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip: Optional[str] = None
    country: Optional[str] = "USA"
    notes: Optional[str] = None
    created_by: Optional[int] = None

@dataclass
class ContactUpdate:
    contact_type: Optional[int] = None
    name: Optional[str] = None
    clinic_id: Optional[int] = None
    display_name: Optional[str] = None
    organization_name: Optional[str] = None
    department: Optional[str] = None
    external_ref_type: Optional[str] = None
    external_ref_id: Optional[str] = None
    tax_id: Optional[str] = None
    npi: Optional[str] = None
    address1: Optional[str] = None
    address2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip: Optional[str] = None
    country: Optional[str] = None
    notes: Optional[str] = None
    is_active: Optional[bool] = None
    updated_by: Optional[int] = None

@dataclass
class ContactChannelCreate:
    contact_id: int
    channel_type: int
    value_raw: str
    channel_purpose: int = 0
    channel_label: Optional[str] = None
    extension: Optional[str] = None
    contact_person_name: Optional[str] = None
    hours_of_operation: Optional[str] = None
    language: Optional[str] = None
    notes: Optional[str] = None
    is_primary: bool = False
    is_verified: bool = False
    created_by: Optional[int] = None

@dataclass
class ContactChannelUpdate:
    channel_type: Optional[int] = None
    channel_purpose: Optional[int] = None
    channel_label: Optional[str] = None
    value_raw: Optional[str] = None
    extension: Optional[str] = None
    contact_person_name: Optional[str] = None
    hours_of_operation: Optional[str] = None
    language: Optional[str] = None
    notes: Optional[str] = None
    is_primary: Optional[bool] = None
    is_verified: Optional[bool] = None
    is_active: Optional[bool] = None
    updated_by: Optional[int] = None