# RCM Contact Connector

A reusable Python library for managing non-patient contacts and their communication channels (fax, phone, email, etc.) for RCM workflows.

---

## Features

- Create and manage contacts (payors, hospitals, labs, etc.)
- Support multiple communication channels per contact
- Smart search by:
  - name
  - phone/fax
  - email
- Automatic normalization of values
- Retrieve preferred contact method based on purpose and priority

---

## Installation

pip install rcm-contact

---

## Requirements

- Python 3.8+
- MySQL database
- Environment variables:

export RCM_DB_HOST=localhost  
export RCM_DB_USER=root  
export RCM_DB_PASSWORD=vipin2002  
export RCM_DB_NAME=rcm_contact  

---

## Usage

```python
from rcm_contact import (
    create_contact,
    add_contact_channel,
    search_contact_channels,
    get_preferred_channel
)

from rcm_contact.models import ContactCreate, ContactChannelCreate

# Create contact
contact_id = create_contact(ContactCreate(
    contact_type=1,
    name="Aetna"
))

# Add channel
add_contact_channel(ContactChannelCreate(
    contact_id=contact_id,
    channel_type=1,
    value_raw="800-555-1111",
    is_primary=True
))

# Search
results = search_contact_channels("Aetna")
print(results)

# Get preferred channel
preferred = get_preferred_channel(contact_id, 1)
print(preferred)