"""
Recipes for migrating from the deprecated aifc module.

The aifc module was deprecated in Python 3.11 (PEP 594) and removed
in Python 3.13.

Alternatives:
- Use third-party libraries like `soundfile` or `pydub` for audio file handling
- Use `wave` module for simpler WAV file operations

See: https://peps.python.org/pep-0594/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import Identifier, FieldAccess
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.13
_Python313 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.13"),
]


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python313)
class FindAifcModule(Recipe):
    """
    Find imports of the deprecated `aifc` module.

    The `aifc` module (AIFF audio file support) was deprecated in Python 3.11
    and removed in Python 3.13 as part of PEP 594 ("Removing dead batteries").

    Alternatives:
    - Use third-party libraries like `soundfile` or `pydub`
    - Use the `wave` module for simpler WAV operations

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindAifcModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `aifc` module usage"

    @property
    def description(self) -> str:
        return (
            "The `aifc` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use third-party audio libraries instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "aifc":
                        return mark_deprecated(
                            multi,
                            "The `aifc` module was removed in Python 3.13. "
                            "Use third-party audio libraries instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "aifc":
                            return mark_deprecated(
                                multi,
                                "The `aifc` module was removed in Python 3.13. "
                                "Use third-party audio libraries instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "aifc":
                    return mark_deprecated(
                        import_stmt,
                        "The `aifc` module was removed in Python 3.13. "
                        "Use third-party audio libraries instead."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindAudioopModule(Recipe):
    """
    Find imports of the deprecated `audioop` module.

    The `audioop` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    Alternatives:
    - Use third-party libraries like `pydub`, `numpy`, or `scipy.signal`

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindAudioopModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `audioop` module usage"

    @property
    def description(self) -> str:
        return (
            "The `audioop` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use pydub, numpy, or scipy for audio operations."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "audioop":
                        return mark_deprecated(
                            multi,
                            "The `audioop` module was removed in Python 3.13. "
                            "Use pydub, numpy, or scipy instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "audioop":
                            return mark_deprecated(
                                multi,
                                "The `audioop` module was removed in Python 3.13. "
                                "Use pydub, numpy, or scipy instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "audioop":
                    return mark_deprecated(
                        import_stmt,
                        "The `audioop` module was removed in Python 3.13. "
                        "Use pydub, numpy, or scipy instead."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindChunkModule(Recipe):
    """
    Find imports of the deprecated `chunk` module.

    The `chunk` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindChunkModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `chunk` module usage"

    @property
    def description(self) -> str:
        return (
            "The `chunk` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Implement IFF chunk reading manually or use specialized libraries."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "chunk":
                        return mark_deprecated(
                            multi,
                            "The `chunk` module was removed in Python 3.13."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "chunk":
                            return mark_deprecated(
                                multi,
                                "The `chunk` module was removed in Python 3.13."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "chunk":
                    return mark_deprecated(
                        import_stmt,
                        "The `chunk` module was removed in Python 3.13."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindImghdrModule(Recipe):
    """
    Find imports of the deprecated `imghdr` module.

    The `imghdr` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    Alternatives:
    - Use `filetype` library (pip install filetype)
    - Use `python-magic` library
    - Use `Pillow` (PIL) for image handling

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindImghdrModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `imghdr` module usage"

    @property
    def description(self) -> str:
        return (
            "The `imghdr` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use `filetype`, `python-magic`, or `Pillow` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "imghdr":
                        return mark_deprecated(
                            multi,
                            "The `imghdr` module was removed in Python 3.13. "
                            "Use `filetype`, `python-magic`, or `Pillow` instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "imghdr":
                            return mark_deprecated(
                                multi,
                                "The `imghdr` module was removed in Python 3.13. "
                                "Use `filetype`, `python-magic`, or `Pillow` instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "imghdr":
                    return mark_deprecated(
                        import_stmt,
                        "The `imghdr` module was removed in Python 3.13. "
                        "Use `filetype`, `python-magic`, or `Pillow` instead."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindSndhdrModule(Recipe):
    """
    Find imports of the deprecated `sndhdr` module.

    The `sndhdr` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    Alternatives:
    - Use `filetype` library for file type detection
    - Use `pydub` or `soundfile` for audio handling

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindSndhdrModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `sndhdr` module usage"

    @property
    def description(self) -> str:
        return (
            "The `sndhdr` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use `filetype` or audio libraries like `pydub` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "sndhdr":
                        return mark_deprecated(
                            multi,
                            "The `sndhdr` module was removed in Python 3.13. "
                            "Use `filetype` or audio libraries instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "sndhdr":
                            return mark_deprecated(
                                multi,
                                "The `sndhdr` module was removed in Python 3.13. "
                                "Use `filetype` or audio libraries instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "sndhdr":
                    return mark_deprecated(
                        import_stmt,
                        "The `sndhdr` module was removed in Python 3.13. "
                        "Use `filetype` or audio libraries instead."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindSunauModule(Recipe):
    """
    Find imports of the deprecated `sunau` module.

    The `sunau` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    Alternatives:
    - Use `soundfile` library for Sun AU file support
    - Use `pydub` for general audio handling

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindSunauModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `sunau` module usage"

    @property
    def description(self) -> str:
        return (
            "The `sunau` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use `soundfile` or `pydub` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "sunau":
                        return mark_deprecated(
                            multi,
                            "The `sunau` module was removed in Python 3.13. "
                            "Use `soundfile` or `pydub` instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "sunau":
                            return mark_deprecated(
                                multi,
                                "The `sunau` module was removed in Python 3.13. "
                                "Use `soundfile` or `pydub` instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "sunau":
                    return mark_deprecated(
                        import_stmt,
                        "The `sunau` module was removed in Python 3.13. "
                        "Use `soundfile` or `pydub` instead."
                    )
                return import_stmt

        return Visitor()
