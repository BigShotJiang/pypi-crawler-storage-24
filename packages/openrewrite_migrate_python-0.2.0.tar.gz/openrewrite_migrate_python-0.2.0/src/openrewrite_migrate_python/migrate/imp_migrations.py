"""
Recipes for migrating deprecated imp module usage.

The imp module was deprecated in Python 3.4 and removed in Python 3.12.
Users should migrate to importlib.

Common migrations:
- imp.reload() -> importlib.reload()
- imp.find_module() -> importlib.util.find_spec()
- imp.load_module() -> importlib.util.module_from_spec() + loader.exec_module()
- imp.NullImporter -> use importlib.abc.MetaPathFinder
- imp.acquire_lock() / imp.release_lock() -> importlib._bootstrap._lock_unlock_module()

See: https://docs.python.org/3/library/imp.html
See: https://peps.python.org/pep-3121/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import FieldAccess, Identifier
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python312)
class FindImpUsage(Recipe):
    """
    Find imports of the deprecated imp module.

    The imp module was deprecated in Python 3.4 (PEP 3121) and removed
    in Python 3.12. Projects should migrate to importlib.

    Common migrations:
    - imp.reload() -> importlib.reload()
    - imp.find_module() -> importlib.util.find_spec()
    - imp.load_module() -> Use importlib.util.module_from_spec() with loader.exec_module()

    Note: For simple imp.reload() calls, use ReplaceImpReload for auto-fix.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindImpUsage"

    @property
    def display_name(self) -> str:
        return "Find deprecated imp module usage"

    @property
    def description(self) -> str:
        return (
            "Find imports of the deprecated `imp` module which was removed "
            "in Python 3.12. Migrate to `importlib`."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == 'imp':
                        return mark_deprecated(
                            multi,
                            "imp module is deprecated",
                            "Migrate to importlib (removed in Python 3.12)"
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == 'imp':
                            return mark_deprecated(
                                multi,
                                "imp module is deprecated",
                                "Migrate to importlib (removed in Python 3.12)"
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == 'imp':
                    return mark_deprecated(
                        import_stmt,
                        "imp module is deprecated",
                        "Migrate to importlib (removed in Python 3.12)"
                    )
                return import_stmt

        return Visitor()
