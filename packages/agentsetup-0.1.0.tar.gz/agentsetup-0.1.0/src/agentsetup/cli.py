import argparse

from agentsetup import __version__


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentsetup",
        description="Official Python package for Agentsetup.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def main() -> int:
    parser = build_parser()
    parser.parse_args()

    print("Agentsetup")
    print(f"Version: {__version__}")
    print("Status: bootstrap release")
    print("This is the official Agentsetup package on PyPI.")
    print("Future releases will distribute the official Agentsetup CLI and related binaries.")
    return 0
