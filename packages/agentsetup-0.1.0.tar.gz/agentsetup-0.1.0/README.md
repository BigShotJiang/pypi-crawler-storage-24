# agentsetup

Official Python package for Agentsetup.

## Status

`agentsetup` is currently a bootstrap release.

This package is published as the official Python entry for Agentsetup on PyPI.
It is intentionally minimal at this stage.

Future releases are expected to distribute the official Agentsetup CLI and related binaries.

## Installation

```bash
pip install agentsetup
```

## Usage

```bash
agentsetup
agentsetup --version
python -m agentsetup
```

## Notes

- This is the official `agentsetup` package on PyPI.
- This package is currently minimal by design.
- Source code for Agentsetup is not published at this time.

## Links

- Homepage: https://agentable.ai

## License

Proprietary.
