#!/usr/bin/env bash
# carta-stop-hook.sh — Stop hook
# Plan 1: graceful stub. Plan 2 adds session save logic.
set -euo pipefail

CONFIG="$(git rev-parse --show-toplevel 2>/dev/null)/.carta/config.yaml"
if [ ! -f "$CONFIG" ]; then
  exit 0
fi

ENABLED=$(grep -A1 'session_memory' "$CONFIG" 2>/dev/null | grep -q 'true' && echo "true" || echo "false")

if [ "$ENABLED" != "true" ]; then
  exit 0
fi

# Plan 2: session save logic goes here.
exit 0
