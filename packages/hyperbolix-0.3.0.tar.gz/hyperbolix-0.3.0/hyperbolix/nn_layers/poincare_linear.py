"""Poincaré ball linear layers for JAX/Flax NNX.

Dimension key:
  B: batch size       I: input dimension
  O: output dimension
"""

import jax
import jax.numpy as jnp
from flax import nnx
from jaxtyping import Array, Float

from hyperbolix.manifolds import Manifold
from hyperbolix.manifolds.poincare import Poincare

from ..optim import mark_manifold_param
from ..utils.math_utils import sinh
from ._helpers import validate_poincare_manifold


class HypLinearPoincare(nnx.Module):
    """
    Hyperbolic Neural Networks fully connected layer (Poincaré ball model).

    Computation steps:
        0) Project the input tensor to the tangent space (optional)
        1) Perform matrix vector multiplication in the tangent space at the origin.
        2) Map the result to the manifold.
        3) Add the manifold bias to the result.

    Parameters
    ----------
    manifold_module : object
        Class-based Poincare manifold instance
    in_dim : int
        Dimension of the input space
    out_dim : int
        Dimension of the output space
    rngs : nnx.Rngs
        Random number generators for parameter initialization
    input_space : str
        Type of the input tensor, either 'tangent' or 'manifold' (default: 'manifold').
        Note: This is a static configuration - changing it after initialization requires recompilation.
    Notes
    -----
    JIT Compatibility:
        This layer is designed to work with nnx.jit. Configuration parameters (input_space)
        are treated as static and will be baked into the compiled function. Changing these values after
        JIT compilation will trigger automatic recompilation.

    References
    ----------
    Ganea Octavian, Gary Bécigneul, and Thomas Hofmann. "Hyperbolic neural networks."
        Advances in neural information processing systems 31 (2018).
    """

    def __init__(
        self,
        manifold_module: Manifold,
        in_dim: int,
        out_dim: int,
        *,
        rngs: nnx.Rngs,
        input_space: str = "manifold",
    ):
        if input_space not in ["tangent", "manifold"]:
            raise ValueError(f"input_space must be either 'tangent' or 'manifold', got '{input_space}'")

        # Static configuration (treated as compile-time constants for JIT)
        validate_poincare_manifold(
            manifold_module,
            required_methods=("proj", "addition", "expmap_0", "logmap_0", "compute_mlr_pp"),
        )
        self.manifold = manifold_module
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.input_space = input_space

        # Trainable parameters
        # Tangent space weight (Euclidean) - initialized with std = 1/sqrt(fan_in)
        # to prevent outputs from saturating at the Poincaré ball boundary
        std = 1.0 / jnp.sqrt(in_dim)
        self.weight = nnx.Param(jax.random.normal(rngs.params(), (out_dim, in_dim)) * std)
        # Manifold bias (initialized to small random values to avoid gradient issues at origin)
        # Mark as manifold parameter for Riemannian optimization
        self.bias = mark_manifold_param(
            nnx.Param(jax.random.normal(rngs.params(), (1, out_dim)) * 0.01),
            manifold=self.manifold,
            curvature=1.0,  # Default curvature, will be overridden by c parameter in forward pass
        )

    def __call__(
        self,
        x: Float[Array, "batch in_dim"],
        c: float = 1.0,
    ) -> Float[Array, "batch out_dim"]:
        """
        Forward pass through the hyperbolic linear layer.

        Parameters
        ----------
        x : Array of shape (batch, in_dim)
            Input tensor where the hyperbolic_axis is last
        c : float
            Manifold curvature (default: 1.0)

        Returns
        -------
        res : Array of shape (batch, out_dim)
            Output on the Poincaré ball manifold
        """
        # Project bias to manifold (bias is (1, O), squeeze to (O,))
        bias_O = self.manifold.proj(self.bias.squeeze(0), c)

        # Map to tangent space if needed (static branch - JIT friendly)
        if self.input_space == "manifold":
            x_BI = jax.vmap(self.manifold.logmap_0, in_axes=(0, None), out_axes=0)(x, c)
        else:
            x_BI = x

        # Matrix-vector multiplication in tangent space at origin
        x_BO = jnp.einsum("bi,oi->bo", x_BI, self.weight)  # (B, I) @ (I, O) -> (B, O)

        # Map back to manifold
        x_BO = jax.vmap(self.manifold.expmap_0, in_axes=(0, None), out_axes=0)(x_BO, c)

        # Manifold bias addition (Möbius addition for Poincaré)
        res_BO = jax.vmap(self.manifold.addition, in_axes=(0, None, None), out_axes=0)(x_BO, bias_O, c)
        return res_BO


class HypLinearPoincarePP(nnx.Module):
    """
    Hyperbolic Neural Networks ++ fully connected layer (Poincaré ball model).

    Computation steps:
        0) Project the input tensor onto the manifold (optional)
        1) Compute the multinomial linear regression score(s)
        2) Calculate the generalized linear transformation from the regression score(s)

    Parameters
    ----------
    manifold_module : object
        Class-based Poincare manifold instance
    in_dim : int
        Dimension of the input space
    out_dim : int
        Dimension of the output space
    rngs : nnx.Rngs
        Random number generators for parameter initialization
    input_space : str
        Type of the input tensor, either 'tangent' or 'manifold' (default: 'manifold').
        Note: This is a static configuration - changing it after initialization requires recompilation.
    clamping_factor : float
        Clamping factor for the multinomial linear regression output (default: 1.0)
    smoothing_factor : float
        Smoothing factor for the multinomial linear regression output (default: 50.0)
    Notes
    -----
    JIT Compatibility:
        This layer is designed to work with nnx.jit. Configuration parameters (input_space,
        clamping_factor, smoothing_factor) are treated as static and will be baked into the compiled function.

    References
    ----------
    Shimizu Ryohei, Yusuke Mukuta, and Tatsuya Harada. "Hyperbolic neural networks++."
        arXiv preprint arXiv:2006.08210 (2020).
    """

    def __init__(
        self,
        manifold_module: Poincare,
        in_dim: int,
        out_dim: int,
        *,
        rngs: nnx.Rngs,
        input_space: str = "manifold",
        clamping_factor: float = 1.0,
        smoothing_factor: float = 50.0,
    ):
        if input_space not in ["tangent", "manifold"]:
            raise ValueError(f"input_space must be either 'tangent' or 'manifold', got '{input_space}'")

        # Static configuration (treated as compile-time constants for JIT)
        validate_poincare_manifold(
            manifold_module,
            required_methods=("proj", "addition", "expmap_0", "logmap_0", "compute_mlr_pp"),
        )
        self.manifold = manifold_module
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.input_space = input_space
        self.clamping_factor = clamping_factor
        self.smoothing_factor = smoothing_factor

        # Trainable parameters
        # Tangent space weight - initialized with std = 1/sqrt(fan_in)
        # to prevent outputs from saturating at the Poincaré ball boundary
        std = 1.0 / jnp.sqrt(in_dim)
        self.weight = nnx.Param(jax.random.normal(rngs.params(), (out_dim, in_dim)) * std)
        # Scalar bias
        self.bias = nnx.Param(jnp.zeros((out_dim, 1)))

    def __call__(
        self,
        x: Float[Array, "batch in_dim"],
        c: float = 1.0,
    ) -> Float[Array, "batch out_dim"]:
        """
        Forward pass through the HNN++ hyperbolic linear layer.

        Parameters
        ----------
        x : Array of shape (batch, in_dim)
            Input tensor where the hyperbolic_axis is last
        c : float
            Manifold curvature (default: 1.0)

        Returns
        -------
        res : Array of shape (batch, out_dim)
            Output on the Poincaré ball manifold
        """
        # Map to manifold if needed (static branch - JIT friendly)
        if self.input_space == "tangent":
            x = jax.vmap(self.manifold.expmap_0, in_axes=(0, None), out_axes=0)(x, c)

        # Compute multinomial linear regression
        v = self.manifold.compute_mlr_pp(
            x,
            self.weight[...],
            self.bias[...],
            c,
            self.clamping_factor,
            self.smoothing_factor,
        )

        # Generalized linear transformation
        sqrt_c = jnp.sqrt(c)
        w_BO = sinh(sqrt_c * v) / sqrt_c
        w2_B1 = jnp.sum(w_BO**2, axis=-1, keepdims=True)
        denom_B1 = 1 + jnp.sqrt(1 + c * w2_B1)
        res_BO = w_BO / denom_B1  # (B, 1) broadcasts over (B, O)

        # Project results to the manifold
        res_BO = jax.vmap(self.manifold.proj, in_axes=(0, None), out_axes=0)(res_BO, c)

        return res_BO
