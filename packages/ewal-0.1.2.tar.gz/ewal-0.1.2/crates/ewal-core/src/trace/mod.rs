pub mod vcd;
pub mod virtual_trace;
#[cfg(feature = "csv_format")]
pub mod csv;

use crate::signal::SignalValue;

pub type SignalId = usize;

pub trait Trace: Send + Sync {
    fn signal_names(&self) -> &[String];
    fn scopes(&self) -> &[String];
    fn max_index(&self) -> usize;
    fn timestamp(&self, index: usize) -> u64;
    fn signal_value(&self, name: &str, index: usize) -> SignalValue;
    fn signal_width(&self, name: &str) -> u32;
    fn signal_id(&self, name: &str) -> Option<SignalId>;
    fn signal_values_range(&self, name: &str, start: usize, end: usize) -> Vec<SignalValue>;

    /// Direct access by SignalId — bypasses name resolution.
    /// This is the hot-path method used by the eval engine.
    fn signal_value_by_id(&self, id: SignalId, index: usize) -> SignalValue;
}
