//! Virtual signal evaluation and caching.
//!
//! Virtual signals are computed on demand and cached per timestep.
//! This module provides the caching layer used by VirtualTrace.

use std::collections::HashMap;
use super::SignalValue;

/// Cache for virtual signal evaluations, keyed by (signal_name, index).
pub struct VirtualSignalCache {
    cache: HashMap<(String, usize), SignalValue>,
}

impl VirtualSignalCache {
    pub fn new() -> Self {
        Self {
            cache: HashMap::new(),
        }
    }

    pub fn get(&self, name: &str, index: usize) -> Option<&SignalValue> {
        self.cache.get(&(name.to_string(), index))
    }

    pub fn insert(&mut self, name: String, index: usize, value: SignalValue) {
        self.cache.insert((name, index), value);
    }

    pub fn clear(&mut self) {
        self.cache.clear();
    }

    pub fn clear_index(&mut self, index: usize) {
        self.cache.retain(|k, _| k.1 != index);
    }
}

impl Default for VirtualSignalCache {
    fn default() -> Self {
        Self::new()
    }
}
