"""Standard library functions for eWAL.

Provides convenience functions like rising(), falling(), stable(), etc.
These are also available as methods on SignalRef objects.
"""

from ewal.signal import SignalRef, SignalExpr


def rising(sig: SignalRef) -> SignalExpr:
    """Detect rising edge: was 0, now 1."""
    return sig.rising()


def falling(sig: SignalRef) -> SignalExpr:
    """Detect falling edge: was 1, now 0."""
    return sig.falling()


def stable(sig: SignalRef) -> SignalExpr:
    """Signal unchanged from previous timestep."""
    return sig.stable()


def unstable(sig: SignalRef) -> SignalExpr:
    """Signal changed from previous timestep."""
    return sig.unstable()


def changed(sig: SignalRef) -> SignalExpr:
    """Alias for unstable()."""
    return sig.unstable()


def past(sig: SignalRef, n: int = 1) -> SignalExpr:
    """Value of signal n steps ago."""
    return sig[-n]
