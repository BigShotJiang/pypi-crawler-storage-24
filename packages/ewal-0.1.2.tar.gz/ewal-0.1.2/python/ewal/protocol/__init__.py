"""Protocol decoders for transaction-level extraction.

Provides built-in decoders for AXI4, AXI4-Stream, APB, Wishbone, Avalon,
and a framework for custom protocol decoders.
"""

from ewal.protocol.base import Protocol, Channel, Handshake, Transaction
from ewal.protocol.axi4 import AXI4, AXI4WriteTxn, AXI4ReadTxn, AXI4Violation, OKAY, EXOKAY, SLVERR, DECERR
from ewal.protocol.axi4_stream import AXI4Stream
from ewal.protocol.apb import APB
from ewal.protocol.wishbone import Wishbone
from ewal.protocol.avalon import Avalon

# Convenience aliases
axi4 = AXI4
axi4_stream = AXI4Stream
apb = APB
wishbone = Wishbone
avalon = Avalon

__all__ = [
    "Protocol", "Channel", "Handshake", "Transaction",
    "AXI4", "AXI4WriteTxn", "AXI4ReadTxn", "AXI4Violation",
    "AXI4Stream", "APB", "Wishbone", "Avalon",
    "axi4", "axi4_stream", "apb", "wishbone", "avalon",
    "OKAY", "EXOKAY", "SLVERR", "DECERR",
]
