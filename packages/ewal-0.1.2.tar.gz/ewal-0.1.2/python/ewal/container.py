"""Multi-trace container for managing multiple loaded traces."""

from __future__ import annotations
from typing import Optional

from ewal.trace import Trace


class TraceContainer:
    """Container for multiple traces, supporting coordinated stepping."""

    def __init__(self):
        self.traces: dict[str, Trace] = {}

    def add(self, tid: str, trace: Trace):
        self.traces[tid] = trace

    def get(self, tid: str) -> Optional[Trace]:
        return self.traces.get(tid)

    def step_all(self, n: int = 1):
        for t in self.traces.values():
            t.step(n)

    def max_common_index(self) -> int:
        if not self.traces:
            return 0
        return min(t.max_index for t in self.traces.values())

    def __getitem__(self, tid: str) -> Trace:
        return self.traces[tid]

    def __contains__(self, tid: str) -> bool:
        return tid in self.traces

    def __len__(self) -> int:
        return len(self.traces)
