"""IPython/REPL integration for eWAL.

Provides enhanced REPL experience with auto-loaded trace variables
and tab completion for signal names.
"""

from __future__ import annotations


def start_repl(trace_path: str = None):
    """Start an interactive eWAL REPL session."""
    from ewal.cli import _start_repl
    _start_repl(trace_path)
