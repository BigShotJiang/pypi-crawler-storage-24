"""WAWK-style API — condition-action pairs with BEGIN/END blocks.

Provides a WAWK-compatible programming model on top of eWAL's
whenever/begin/end system.

Usage:
    from ewal.wawk import WawkProgram

    prog = WawkProgram("counter.fst")
    prog.alias(clk="tb.dut.clk", overflow="tb.dut.overflow")

    @prog.begin
    def setup():
        prog.var("count", 0)

    @prog.rule(prog.t.clk & prog.t.overflow)
    def on_overflow():
        prog.vars["count"] += 1
        print(f"Overflow at {prog.t.index}")

    @prog.end
    def summary():
        print(f"Total overflows: {prog.vars['count']}")

    prog.run()
"""

from __future__ import annotations
from typing import Callable

import ewal
from ewal.trace import Trace


class WawkProgram:
    """WAWK-style condition-action program."""

    def __init__(self, path: str):
        self.t = ewal.load(path)
        self.vars: dict = {}

    def alias(self, **kwargs):
        self.t.alias(**kwargs)

    def var(self, name: str, default=0):
        self.vars[name] = default

    def begin(self, fn):
        self.t.begin(fn)
        return fn

    def end(self, fn):
        self.t.end(fn)
        return fn

    def rule(self, condition):
        """Decorator: register a condition-action rule."""
        return self.t.whenever(condition)

    def run(self):
        self.t.run()
