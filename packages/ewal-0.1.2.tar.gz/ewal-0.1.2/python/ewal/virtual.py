"""Virtual signal definitions.

Virtual signals are defined via Trace.defsig() and evaluated lazily.
This module provides additional utilities for working with virtual signals.
"""

from __future__ import annotations
from typing import Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from ewal.trace import Trace


def defsig(trace: "Trace", name: str, expr_or_callable):
    """Define a virtual signal on a trace. See Trace.defsig()."""
    trace.defsig(name, expr_or_callable)
