"""Scope and Group context managers.

These are used via Trace.scope() and Trace.group() — this module
provides the implementation.
"""

# The scope/group context managers are implemented directly in trace.py
# as _ScopeContext and _GroupContext. This module is kept for the
# project structure specified in the design doc.

from ewal.trace import _ScopeContext as ScopeContext
from ewal.trace import _GroupContext as GroupContext

__all__ = ["ScopeContext", "GroupContext"]
