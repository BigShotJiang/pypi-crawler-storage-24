"""DSL helpers: whenever, find, on, begin, end.

These are re-exported from the Trace class. This module provides
standalone function versions for convenience.
"""

from __future__ import annotations
from typing import Callable

from ewal.signal import SignalExpr, SignalRef


def whenever(trace, condition, callback=None):
    """Register a handler. See Trace.whenever()."""
    return trace.whenever(condition, callback)


def find(trace, condition) -> list[int]:
    """Find matching indices. See Trace.find()."""
    return trace.find(condition)
