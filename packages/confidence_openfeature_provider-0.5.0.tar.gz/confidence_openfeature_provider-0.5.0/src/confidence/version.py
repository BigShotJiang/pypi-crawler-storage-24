"""Version information for the Confidence OpenFeature provider."""

__version__ = "0.5.0"  # x-release-please-version
