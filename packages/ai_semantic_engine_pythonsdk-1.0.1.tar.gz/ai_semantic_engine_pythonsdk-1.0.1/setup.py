import os
from setuptools import setup, find_packages

with open(os.path.join(os.path.dirname(__file__), "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="ai-semantic-engine-pythonsdk",
    version="1.0.1",
    description="Official Python SDK for the AI Semantic Engine",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Olaiwola Akeem Salau",
    author_email="olaiwolaakeem@gmail.com",
    url="https://github.com/obrainwave/ai-semantic-engine-pythonsdk",
    packages=find_packages(),
    install_requires=[
        "requests>=2.0.0",
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
