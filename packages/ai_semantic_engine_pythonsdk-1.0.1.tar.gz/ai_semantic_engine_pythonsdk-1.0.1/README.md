# AI Semantic Engine Python SDK

The official Python client for the AI Semantic Engine.

## Installation

```bash
pip install ai-semantic-engine-pythonsdk
```

## Usage

```python
from ai_semantic_engine.client import AiSemanticEngineClient

# Initialize the client
client = AiSemanticEngineClient(base_url="http://localhost:8200", api_key="YOUR_API_KEY")

# 1. Embed Text
embeddings = client.embed("Hello world", model="fast")

# 2. Compute Similarity
score = client.similarity("Apple", "Orange")
print(f"Similarity: {score}%")

# 3. Store Knowledge
client.store_item(text="Machine learning is fascinating.", metadata={"topic": "AI", "source": "wiki"})

# 4. Search Knowledge
results = client.search(query="Tell me about AI", top_k=3, filters={"topic": "AI"})
for r in results:
    print(r["score"], r["text"])
```

## Endpoints Supported

- `embed` and `embed-batch`
- `similarity`
- `store_item` (items endpoint)
- `search`
- `detect_duplicates` (detect-duplicates endpoint)
