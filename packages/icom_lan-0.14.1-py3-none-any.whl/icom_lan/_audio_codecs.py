"""Pure-Python audio codec utilities.

This module provides codec implementations for audio formats not in the standard library.
Current implementations:
- ulaw (mu-law): 8-bit logarithmic compression → 16-bit linear PCM
"""

from __future__ import annotations

__all__ = [
    "decode_ulaw_to_pcm16",
]


def decode_ulaw_to_pcm16(ulaw_data: bytes | bytearray | memoryview) -> bytes:
    """Decode 8-bit ulaw (mu-law) audio to 16-bit signed linear PCM.

    Ulaw is a logarithmic compression format used in telephony and some radio systems.
    Each byte represents one 16-bit PCM sample.

    Args:
        ulaw_data: Audio data in ulaw format (one byte per sample)

    Returns:
        PCM16 (16-bit signed little-endian) audio data
    """
    # Standard ulaw decoding lookup table (256 entries)
    # Converts 8-bit ulaw values to 16-bit signed PCM
    _ULAW_DECODE_TABLE = (
        -32124, -31100, -30076, -29052, -28028, -27004, -25980, -24956,
        -23932, -22908, -21884, -20860, -19836, -18812, -17788, -16764,
        -15996, -15484, -14972, -14460, -13948, -13436, -12924, -12412,
        -11900, -11388, -10876, -10364, -9852, -9340, -8828, -8316,
        -7932, -7676, -7420, -7164, -6908, -6652, -6396, -6140,
        -5884, -5628, -5372, -5116, -4860, -4604, -4348, -4092,
        -3908, -3772, -3636, -3500, -3364, -3228, -3092, -2956,
        -2820, -2684, -2548, -2412, -2276, -2140, -2004, -1868,
        -1820, -1756, -1692, -1628, -1564, -1500, -1436, -1372,
        -1308, -1244, -1180, -1116, -1052, -988, -924, -860,
        -820, -756, -692, -628, -564, -500, -436, -372,
        -308, -244, -180, -116, -52, 12, 76, 140,
        32124, 31100, 30076, 29052, 28028, 27004, 25980, 24956,
        23932, 22908, 21884, 20860, 19836, 18812, 17788, 16764,
        15996, 15484, 14972, 14460, 13948, 13436, 12924, 12412,
        11900, 11388, 10876, 10364, 9852, 9340, 8828, 8316,
        7932, 7676, 7420, 7164, 6908, 6652, 6396, 6140,
        5884, 5628, 5372, 5116, 4860, 4604, 4348, 4092,
        3908, 3772, 3636, 3500, 3364, 3228, 3092, 2956,
        2820, 2684, 2548, 2412, 2276, 2140, 2004, 1868,
        1820, 1756, 1692, 1628, 1564, 1500, 1436, 1372,
        1308, 1244, 1180, 1116, 1052, 988, 924, 860,
        820, 756, 692, 628, 564, 500, 436, 372,
        308, 244, 180, 116, 52, -12, -76, -140,
        -32124, -31100, -30076, -29052, -28028, -27004, -25980, -24956,
        -23932, -22908, -21884, -20860, -19836, -18812, -17788, -16764,
        -15996, -15484, -14972, -14460, -13948, -13436, -12924, -12412,
        -11900, -11388, -10876, -10364, -9852, -9340, -8828, -8316,
        -7932, -7676, -7420, -7164, -6908, -6652, -6396, -6140,
        -5884, -5628, -5372, -5116, -4860, -4604, -4348, -4092,
        -3908, -3772, -3636, -3500, -3364, -3228, -3092, -2956,
        -2820, -2684, -2548, -2412, -2276, -2140, -2004, -1868,
        -1820, -1756, -1692, -1628, -1564, -1500, -1436, -1372,
        -1308, -1244, -1180, -1116, -1052, -988, -924, -860,
        -820, -756, -692, -628, -564, -500, -436, -372,
        -308, -244, -180, -116, -52, 12, 76, 140,
    )

    if not isinstance(ulaw_data, (bytes, bytearray, memoryview)):
        raise TypeError("ulaw_data must be bytes-like")

    ulaw_bytes = bytes(ulaw_data)
    pcm_samples = []

    for byte_val in ulaw_bytes:
        # Decode the ulaw byte using the lookup table
        pcm_val = _ULAW_DECODE_TABLE[byte_val & 0xFF]
        pcm_samples.append(pcm_val)

    # Convert list of 16-bit signed integers to little-endian bytes
    pcm_bytes = bytearray()
    for sample in pcm_samples:
        # Convert to 16-bit signed little-endian
        pcm_bytes.extend(sample.to_bytes(2, byteorder="little", signed=True))

    return bytes(pcm_bytes)
