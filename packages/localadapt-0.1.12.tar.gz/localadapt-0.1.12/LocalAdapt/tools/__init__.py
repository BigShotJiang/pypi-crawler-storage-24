from .registry import registry
from tools.math_tools import calculator

registry.register("Calculator", calculator, "Performs mathematical calculations")