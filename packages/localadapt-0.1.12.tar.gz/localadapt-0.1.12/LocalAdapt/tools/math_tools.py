def calculator(input_text: str):
    try:
        return str(eval(input_text))
    except Exception as e:
        return str(e)