# anusara/_mutation/execution_runner.py

from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.execution_scenario import ExecutionScenario
from anusara._contracts.graph_definition import GraphDefinition
from anusara._contracts.json_types import JSONValue
from anusara._core.execution_engine import ExecutionEngine
from anusara._core.execution_policy import ExecutionPolicy, FailureMode
from anusara._mutation.event import (
    GraphMutationExecuted,
    GraphMutationExecutionFailed,
)
from anusara._mutation.in_memory_event_log import InMemoryMutationEventLog
from anusara._registry.agents_registry import AgentRegistry
from anusara.api.errors import SimulatedHardKillError


class MutationExecutionRunner:
    """
    Executes a mutation-derived execution request.

    Responsibilities:
    - translate mutation execution event into ExecutionRequest
    - invoke execution engine
    - capture execution failures as mutation events

    Design principles:
    - execution is explicit (no implicit triggering)
    - mutation and execution concerns remain decoupled
    - all failures are recorded via mutation event log

    This class bridges:
        mutation lifecycle → execution lifecycle
    """

    def __init__(
        self,
        mutation_log: InMemoryMutationEventLog,
        execution_engine: ExecutionEngine,
    ) -> None:
        self._log = mutation_log
        self._engine = execution_engine

    async def execute(
        self,
        event: GraphMutationExecuted,
        registry: AgentRegistry,
        graph_definition: GraphDefinition | None,
        entry_nodes: list[str],
        payload: dict[str, JSONValue] | None = None,  # ✅ tightened
        scenario: ExecutionScenario | None = None,
    ) -> None:

        # -------------------------------------------------
        # Payload normalization (strict + clean)
        # -------------------------------------------------
        clean_payload: dict[str, JSONValue] = payload or {}

        # -------------------------------------------------
        # Build execution request
        # -------------------------------------------------
        request = ExecutionRequest(
            request_id=event.new_request_id,
            entry_nodes=entry_nodes,
            graph_definition=graph_definition,
            payload=clean_payload,
            scenario=scenario or ExecutionScenario(name="default"),
            policy=ExecutionPolicy(failure_mode=FailureMode.FAIL_FAST),
        )

        # -------------------------------------------------
        # Execute
        # -------------------------------------------------
        try:
            result, _ = await self._engine.execute(request, registry)

        except SimulatedHardKillError:
            # Explicitly propagate (system-level signal)
            raise

        except Exception as e:
            # Engine-level unexpected failure
            self._log.append(
                GraphMutationExecutionFailed(
                    request_id=event.new_request_id,
                    base_request_id=event.base_request_id,
                    evaluation_id=event.evaluation_id,
                    observer_id=event.observer_id,
                    proposal_id=event.proposal_id,
                    error_message=str(e),
                )
            )
            raise

        # -------------------------------------------------
        # Logical execution failure (explicitly escalated)
        # -------------------------------------------------
        if not result.success:
            self._log.append(
                GraphMutationExecutionFailed(
                    request_id=event.new_request_id,
                    base_request_id=event.base_request_id,
                    evaluation_id=event.evaluation_id,
                    observer_id=event.observer_id,
                    proposal_id=event.proposal_id,
                    error_message="Execution failed",
                )
            )
            raise RuntimeError("Execution failed")
