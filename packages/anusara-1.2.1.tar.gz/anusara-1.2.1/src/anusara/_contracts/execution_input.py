from __future__ import annotations

from dataclasses import dataclass

from anusara._contracts.execution_scenario import ExecutionScenario
from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class ExecutionInput:
    request_id: str
    payload: dict[str, JSONValue]
    metadata: dict[str, JSONValue]
    scenario: ExecutionScenario

    def scenario_name(self) -> str:
        return self.scenario.name

    def flag(self, key: str, default: bool = False) -> bool:
        return self.scenario.flags.get(key, default)

    # ---------------------------------------------------------
    # Data
    # ---------------------------------------------------------

    @property
    def data(self) -> dict[str, JSONValue]:
        raw = self.payload.get("data")

        if isinstance(raw, dict):
            return raw

        return self.payload
