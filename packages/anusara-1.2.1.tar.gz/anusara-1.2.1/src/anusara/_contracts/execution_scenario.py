from __future__ import annotations

from dataclasses import dataclass, field

from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class ExecutionScenario:
    """
    Represents execution-time behavioral controls.

    This is part of the control plane and must remain:
    - deterministic
    - serializable
    - replay-safe
    """

    name: str
    flags: dict[str, bool] = field(default_factory=dict)
    parameters: dict[str, JSONValue] = field(default_factory=dict)

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------

    def flag(self, name: str) -> bool:
        """
        Check if a boolean flag is enabled.
        """
        return self.flags.get(name, False)

    def param(self, name: str, default: JSONValue | None = None) -> JSONValue | None:
        """
        Retrieve a parameter value with optional default.
        """
        return self.parameters.get(name, default)

    def to_dict(self) -> dict[str, JSONValue]:
        return {
            "name": self.name,
            "flags": {k: v for k, v in self.flags.items()},
            "parameters": {k: v for k, v in self.parameters.items()},
        }
