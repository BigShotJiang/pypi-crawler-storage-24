from __future__ import annotations

import time

from anusara import Agent, AgentResult
from anusara._contracts.execution_input import ExecutionInput


class EchoAgent(Agent):
    """
    Built-in system agent.

    Purpose:
    - Provide a safe default agent for runtime
    - Validate execution pipeline end-to-end
    - Help debugging and observability

    Behavior:
    - Returns input payload as output
    - Adds metadata for traceability
    """

    async def execute(self, execution_input: ExecutionInput) -> AgentResult:
        return AgentResult(
            success=True,
            output={
                "agent": "echo",
                "message": "EchoAgent executed successfully",
                # 🔍 Structured visibility
                "request_id": execution_input.request_id,
                "scenario_name": execution_input.scenario_name(),
                # 📦 Inputs
                "data": execution_input.data,
                "raw_payload": execution_input.payload,
                # 🧪 Scenario control
                "scenario": execution_input.scenario.to_dict(),
                # ⏱️ Observability
                "timestamp": time.time(),
            },
            confidence=1.0,
        )
