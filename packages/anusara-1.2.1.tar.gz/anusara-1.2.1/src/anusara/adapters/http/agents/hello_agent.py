from anusara import Agent, AgentResult
from anusara._contracts.execution_input import ExecutionInput


class HelloAgent(Agent):
    """
    A minimal agent that returns a greeting message.
    """

    async def execute(self, execution_input: ExecutionInput) -> AgentResult:
        if execution_input.flag("force_fail"):
            return AgentResult(
                success=False,
                output={
                    "error": "Forced failure",
                    "scenario": execution_input.scenario_name(),
                    "request_id": execution_input.request_id,
                },
                confidence=0.0,
            )

        return AgentResult(
            success=True,
            output={
                "message": "Hello from Anusara 👋",
                "scenario": execution_input.scenario_name(),
                "request_id": execution_input.request_id,
                "data": execution_input.data,
            },
            confidence=1.0,
        )
