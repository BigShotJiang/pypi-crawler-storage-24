# anusara/_adapters/http/runtime.py

from __future__ import annotations

from collections.abc import Callable

from anusara._contracts.agent import Agent
from anusara._core.execution_engine import ExecutionEngine
from anusara._observability.file_event_log import FileExecutionEventLog
from anusara._registry.agents_registry import AgentRegistry

# ---------------------------------------------------------
# Runtime Container
# ---------------------------------------------------------


class RuntimeContainer:
    """
    Holds long-lived runtime dependencies.

    Responsibilities:
    - Own execution engine
    - Own event log
    - Own agent registry

    This acts as a lightweight dependency container
    for HTTP adapters.
    """

    def __init__(self, event_log_path: str = "events.jsonl") -> None:
        self.event_log = FileExecutionEventLog(event_log_path)
        self.engine = ExecutionEngine(event_log=self.event_log)
        self.registry = AgentRegistry()

        # 🔥 NEW: controlled agent factory
        self._agent_factories: dict[str, Callable[[], Agent]] = {}

    def register_factory(self, name: str, factory: Callable[[], Agent]) -> None:
        if name in self._agent_factories:
            raise ValueError(f"Factory already registered for '{name}'")

        self._agent_factories[name] = factory

    def create_and_register(self, name: str) -> None:
        if name not in self._agent_factories:
            raise ValueError(f"No factory registered for agent '{name}'")

        if self.registry.exists(name):
            raise ValueError(f"Agent '{name}' is already registered")

        agent = self._agent_factories[name]()
        self.registry.register(name, agent)

    def list_factories(self) -> list[str]:
        return list(self._agent_factories.keys())


# ---------------------------------------------------------
# Singleton Runtime
# ---------------------------------------------------------

_container: RuntimeContainer | None = None


def initialize_runtime(
    event_log_path: str = "events.jsonl",
    *,
    reset: bool = False,
) -> RuntimeContainer:
    """
    Initialize (or reset) the global runtime container.

    Must be called before accessing engine/registry.
    """

    global _container

    if _container is None or reset:
        _container = RuntimeContainer(event_log_path)

    return _container


def _require_container() -> RuntimeContainer:
    if _container is None:
        raise RuntimeError(
            "Runtime not initialized. Call initialize_runtime() during app startup."
        )
    return _container


def get_engine() -> ExecutionEngine:
    """
    Dependency provider for ExecutionEngine.
    """
    return _require_container().engine


def get_registry() -> AgentRegistry:
    """
    Dependency provider for AgentRegistry.
    """
    return _require_container().registry


def get_container() -> RuntimeContainer:
    return _require_container()
