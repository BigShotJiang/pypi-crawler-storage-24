import asyncio
import inspect
import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import cast

from anusara._contracts.agent import Agent
from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import (
    NodeExecutionCompleted,
    NodeExecutionFailed,
    NodeExecutionRetried,
    NodeExecutionStarted,
)
from anusara._contracts.execution_input import ExecutionInput
from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.json_types import JSONValue
from anusara._core.errors import ApprovalRequiredError, SimulatedHardKillError
from anusara._core.execute_node_command import ExecuteNodeCommand
from anusara._core.middleware.retry_middleware import RetryMiddleware
from anusara._core.orchestration_event_emitter import OrchestrationEventEmitter
from anusara._registry.agents_registry import AgentRegistry
from anusara._registry.errors import AgentNotFoundError
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState
from anusara._runtime.retry_policy import RetryPolicy


# -----------------------------------------------------------------------------
# ARCHITECTURAL INVARIANT
#
# NodeExecutor is responsible ONLY for:
#   - invoking agents
#   - emitting execution lifecycle events
#
# NodeExecutor MUST NOT:
#   - create ExecutionRecord
#   - mutate ExecutionState
#
# ExecutionState mutations are owned by ExecutionEngine.
# -----------------------------------------------------------------------------
class NodeExecutor:
    """
    Responsible for executing a single orchestration node.

    Invariant:
    - Emits events only.
    - Does NOT mutate ExecutionState directly.
    - Must return deterministic execution record.
    """

    def __init__(
        self,
        registry: AgentRegistry,
        retry_policy: RetryPolicy,
        event_emitter: OrchestrationEventEmitter,
        graph: ExecutionGraph,
    ) -> None:
        self._registry = registry
        self._retry = RetryMiddleware(retry_policy)
        self._emitter = event_emitter
        self._graph = graph  # read-only reference

    # ---------------------------------------------------------
    # PUBLIC ENTRY
    # ---------------------------------------------------------

    async def execute(
        self,
        node_id: str,
        agent_name: str,
        request: ExecutionRequest,
        state: ExecutionState,
    ) -> ExecutionRecord:
        previous_attempts = len(state.records_for(node_id))
        attempt = previous_attempts + 1

        command = ExecuteNodeCommand(
            request_id=request.request_id,
            node_id=node_id,
            agent=agent_name,
            attempt=attempt,
            payload=request.payload,  # ✅ now matches JSONValue contract
        )

        return await self._execute_command(command, request, state)

    # ---------------------------------------------------------
    # COMMAND EXECUTION
    # ---------------------------------------------------------

    async def _execute_command(
        self,
        command: ExecuteNodeCommand,
        request: ExecutionRequest,
        state: ExecutionState,
    ) -> ExecutionRecord:
        agent = self._resolve_agent(command.agent)
        base_attempt = command.attempt

        max_attempts = self._retry.max_attempts()

        for retry_offset in range(max_attempts):
            attempt = base_attempt + retry_offset

            try:
                # START
                if self._emitter:
                    self._emitter.emit(
                        NodeExecutionStarted(
                            request_id=request.request_id,
                            timestamp=datetime.now(UTC),
                            node_id=command.node_id,
                            agent=command.agent,
                            attempt=attempt,
                        )
                    )

                # INVOKE
                result = await self._invoke(
                    node_id=command.node_id,
                    agent=agent,
                    request=request,
                    state=state,
                    attempt=attempt,
                )

                if not result.success:
                    # Treat as logical failure, not exception
                    pass

                # COMPLETED SUCCESS
                if self._emitter:
                    self._emitter.emit(
                        NodeExecutionCompleted(
                            request_id=request.request_id,
                            timestamp=datetime.now(UTC),
                            node_id=command.node_id,
                            agent=command.agent,
                            attempt=attempt,
                            success=result.success,
                            confidence=result.confidence,
                            metadata=result.metadata,
                            output=(
                                result.output
                                if isinstance(result.output, dict)
                                else None
                            ),
                        )
                    )

                record = state.latest_record(command.node_id)
                if record is None:
                    raise RuntimeError(
                        f"No execution record found for node {command.node_id}"
                    )
                return record

            except SimulatedHardKillError:
                raise

            except ApprovalRequiredError:
                raise

            except Exception as e:
                # FAILED
                if self._emitter:
                    self._emitter.emit(
                        NodeExecutionFailed(
                            request_id=request.request_id,
                            timestamp=datetime.now(UTC),
                            node_id=command.node_id,
                            agent=command.agent,
                            attempt=attempt,
                            error=str(e),
                        )
                    )

                    self._emitter.emit(
                        NodeExecutionCompleted(
                            request_id=request.request_id,
                            timestamp=datetime.now(UTC),
                            node_id=command.node_id,
                            agent=command.agent,
                            attempt=attempt,
                            success=False,
                            confidence=0.0,
                            metadata=None,
                            output=None,
                        )
                    )

                # RETRY
                if retry_offset < max_attempts - 1:
                    delay = self._retry.compute_delay(attempt)

                    if self._emitter:
                        self._emitter.emit(
                            NodeExecutionRetried(
                                request_id=request.request_id,
                                timestamp=datetime.now(UTC),
                                node_id=command.node_id,
                                agent=command.agent,
                                attempt=attempt,
                                delay_seconds=delay,
                            )
                        )

                    time.sleep(delay)
                    continue

                record = state.latest_record(command.node_id)
                if record is None:
                    raise RuntimeError(
                        f"No execution record found for node {command.node_id}"
                    ) from e
                return record

        raise RuntimeError("Unexpected retry loop exit")

    # ---------------------------------------------------------
    # AGENT RESOLUTION
    # ---------------------------------------------------------

    def _resolve_agent(self, agent_name: str) -> Agent:
        try:
            return self._registry.get(agent_name)
        except KeyError as e:
            raise AgentNotFoundError(agent_name) from e

    # ---------------------------------------------------------
    # INVOCATION CORE
    # ---------------------------------------------------------

    async def _invoke(
        self,
        node_id: str,
        agent: Agent,
        request: ExecutionRequest,
        state: ExecutionState,
        attempt: int,
    ) -> AgentResult:

        payload: dict[str, JSONValue] = {}

        deps = self._graph.dependencies_of(node_id)

        for dep in deps:
            dep_record = state.latest_record(dep)

            if not dep_record:
                continue

            output = dep_record.result.output

            # ✅ No cast needed anymore — mypy understands narrowing
            if isinstance(output, dict):
                payload.update(output)

        # Fallback
        if not payload:
            payload = request.payload

        execution_input = ExecutionInput(
            request_id=request.request_id,
            payload=payload,
            metadata=request.metadata,
            scenario=request.resolve_scenario(),
        )

        # Invoke agent
        if inspect.iscoroutinefunction(agent.execute):
            result = await agent.execute(execution_input)
        else:
            result = await asyncio.to_thread(
                cast(Callable[[ExecutionInput], AgentResult], agent.execute),
                execution_input,
            )

        if not isinstance(result, AgentResult):
            raise TypeError(
                f"Agent '{type(agent).__name__}' returned invalid result type: "
                f"{type(result).__name__}"
            )

        return result
