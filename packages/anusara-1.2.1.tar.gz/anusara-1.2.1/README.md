# Anusara

**Deterministic execution runtime for agent workflows.**

![CI](https://github.com/Nataraj-Narayana/anusara/actions/workflows/ci.yml/badge.svg)
![PyPI](https://img.shields.io/pypi/v/anusara)
![Python](https://img.shields.io/pypi/pyversions/anusara)
![License](https://img.shields.io/github/license/Nataraj-Narayana/anusara)
![Architecture](https://img.shields.io/badge/architecture-event--sourced--runtime-blue)

---

## What is Anusara?

**Anusara is a deterministic runtime for executing agent workflows.**

It executes graphs of agents using:

- deterministic scheduling  
- event-sourced execution history  
- replay-driven state reconstruction  

Every execution becomes:

- replayable  
- inspectable  
- debuggable  
- reproducible  

Anusara treats workflow execution as a **runtime system problem**, not a
collection of loosely connected function calls.

---

## 🚀 Quickstart (2 minutes)

### Install

```bash
pip install anusara[api]
```

### Run the server

```bash
PYTHONPATH=src python -m uvicorn anusara.adapters.http.app:create_app --factory --reload
```

### Register agent

```bash
curl -X POST http://127.0.0.1:8000/agents/register \
  -H "Content-Type: application/json" \
  -d '{"name": "hello"}'
```

### Execute

```bash
curl -X POST http://127.0.0.1:8000/executions \
  -H "Content-Type: application/json" \
  -d '{"entry_nodes": ["hello"]}'
```

👉 You just ran your first deterministic workflow.

➡️ Full guide: `docs/guides/http-api-quickstart.md`

---

## The Mental Model

```text
Agent Graph
     ↓
Deterministic Execution Engine
     ↓
Event Log (source of truth)
     ↓
Replay • Debug • Observability
```

Execution is not hidden state.

It is a **recorded, replayable system**.

---

## Why Anusara?

Most agent orchestration systems rely on implicit runtime behavior.

This leads to:

- nondeterministic execution  
- difficult debugging  
- hidden state transitions  
- unreliable retries  
- poor reproducibility  

Anusara solves this by enforcing:

- deterministic execution  
- event log authority  
- replay-based debugging  
- explicit lifecycle guarantees  

---

## Architecture Overview

```mermaid
flowchart LR

Client[Client / API / CLI]
Client --> Runtime

Runtime[Execution Runtime]

Runtime --> Graph[Graph Compiler]
Runtime --> Registry[Agent Registry]
Runtime --> Router[Router]
Runtime --> Mutation[Mutation Engine]

Runtime --> EventLog[(Event Log)]

EventLog --> Replay[Replay Engine]
EventLog --> Debugger[Debugger / Analysis]

Runtime --> Observability[Observability]
```

---

## Core Responsibilities

| Layer | Responsibility |
|------|----------------|
| Runtime | deterministic execution of workflows |
| Event Log | authoritative execution history |
| Registry | agent lifecycle & resolution |
| Router | execution decision logic |
| Mutation Engine | controlled graph evolution |
| Observability | debugging, metrics, visualization |

---

## Local Python Example

```python
import asyncio
from anusara import ExecutionEngine, ExecutionRequest, AgentRegistry

engine = ExecutionEngine()

registry = AgentRegistry()
registry.register("hello", HelloAgent())

request = ExecutionRequest(
    request_id="demo",
    entry_nodes=["hello"],
    payload={},
    metadata={},
)

asyncio.run(engine.execute(request, registry))
```

---

## Key Features

- deterministic execution  
- event-sourced execution history  
- replayable workflows  
- HTTP + CLI + Python runtime  
- agent lifecycle management  
- built-in observability  
- controlled workflow mutation  

---

## Documentation

### 🚀 Getting Started

- `docs/guides/http-api-quickstart.md`
- `docs/guides/running-anusara-locally.md`
- `docs/guides/creating-your-first-agent.md`

### 📚 Concepts

- agents  
- deterministic execution  
- event sourcing  
- replay  

### 🏗 Architecture

- execution model  
- runtime architecture  
- event log  
- mutation model  

### 📖 Reference

- HTTP API  
- agent registry  
- execution engine  

---

## Project Status

Anusara is under active development.

Current focus:

- developer experience (HTTP API & usability)  
- onboarding and documentation  
- production readiness  

---

## Contributing

Contributions and discussions are welcome.

- CONTRIBUTING.md  
- CODE_OF_CONDUCT.md  
- SECURITY.md  

---

## Security

Anusara Docker images are built on `python:3.12-slim-bookworm`
and regularly updated to minimize vulnerabilities.

We prioritize:
- eliminating high/critical vulnerabilities
- maintaining minimal runtime footprint
- reproducible builds

Low-severity base image CVEs are tracked but not always actionable.

---

## License

MIT License
