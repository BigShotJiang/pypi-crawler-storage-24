"""
omie.errors — Exceções tipadas para a API Omie.

A Omie usa SOAP 1.1 retornando JSON. O status HTTP é inconsistente —
erros de negócio chegam tanto como 200 quanto 500, sempre com
faultcode/faultstring no body. Este módulo normaliza isso.

Hierarquia:
    OmieError
    ├── OmieClientError          faultcode: SOAP-ENV:Client*
    │   ├── OmieAuthError
    │   ├── OmieValidationError      .field → tag com problema
    │   ├── OmieDuplicateError       .omie_id → ID do registro existente
    │   ├── OmieNotFoundError        .field → tag com problema
    │   └── OmieRateLimitError       .retry_after → segundos para aguardar
    └── OmieServerError          faultcode: SOAP-ENV:Server*
        └── OmieUnavailableError
"""

from __future__ import annotations

import re
from typing import Optional

# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------


class OmieError(Exception):
    def __init__(self, faultcode: str, faultstring: str) -> None:
        super().__init__(faultstring)
        self.faultcode = faultcode
        self.faultstring = faultstring

    def __repr__(self) -> str:
        return f"{type(self).__name__}(faultcode={self.faultcode!r}, faultstring={self.faultstring!r})"


# ---------------------------------------------------------------------------
# Erros do caller  (SOAP-ENV:Client*)
# ---------------------------------------------------------------------------


class OmieClientError(OmieError):
    """Erro originado em dados ou comportamento incorreto do caller."""


class OmieAuthError(OmieClientError):
    """Credenciais inválidas ou API não habilitada."""


class OmieValidationError(OmieClientError):
    """Campo obrigatório ausente, formato inválido ou limite de caracteres excedido."""

    @property
    def field(self) -> Optional[str]:
        m = re.search(r"\[([^\]]+)\]", self.faultstring)
        return m.group(1) if m else None


class OmieDuplicateError(OmieClientError):
    """Registro já cadastrado para o código de integração enviado."""

    @property
    def omie_id(self) -> Optional[str]:
        m = re.search(r"\[(\d+)\]", self.faultstring)
        return m.group(1) if m else None


class OmieNotFoundError(OmieClientError):
    """Código informado não existe no sistema."""

    @property
    def field(self) -> Optional[str]:
        matches = re.findall(r"\[([^\]]+)\]", self.faultstring)
        return matches[-1] if matches else None


class OmieRateLimitError(OmieClientError):
    """Limite de consumo atingido (redundante, too many, ou bloqueio)."""

    @property
    def retry_after(self) -> Optional[int]:
        m = re.search(r"(\d+)\s*segundo", self.faultstring, re.IGNORECASE)
        return int(m.group(1)) if m else None


# ---------------------------------------------------------------------------
# Erros do servidor  (SOAP-ENV:Server*)
# ---------------------------------------------------------------------------


class OmieServerError(OmieError):
    """Erro interno na infraestrutura da Omie. Geralmente transitório."""


class OmieUnavailableError(OmieServerError):
    """Instabilidade ou broken response no servidor Omie."""


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

_CLIENT_PREFIX = ("SOAP-ENV:Client", "SOAP-ENV:Client-")
_SERVER_PREFIX = ("SOAP-ENV:Server", "SOAP-ENV:Server-")

_AUTH_PATTERNS = (
    "api is not enabled",
    "app_key",
    "app_secret",
    "credencial",
    "autenticação",
    "unauthorized",
)
_DUPLICATE_PATTERNS = (
    "já cadastrad",
    "já exist",
    "código de integração já",
)
_NOT_FOUND_PATTERNS = (
    "não cadastrad",
    "não encontrad",
    "não exist",
    "não existem registros",
)
_VALIDATION_PATTERNS = (
    "é obrigatório",
    "obrigatório o preenchimento",
    "número máximo de caracteres",
    "inválid",
    "invalid json",
    "syntaxerror",
    "json request",
    "campo em branco",
    "consumo indevido [get]",
)
_RATE_LIMIT_PATTERNS = (
    "redundante",
    "redundant",
    "too many",
    "muitas requisições",
    "limite de consumo",
    "bloqueio",
    "bloqueada por consumo",
    "bloqueado",
    "aguarde",
    "429",
    "425",
)
_UNAVAILABLE_PATTERNS = (
    "broken response",
    "application service",
    "erro interno",
    "internal server",
    "instabilidade",
    "servidor indisponível",
)


def parse_omie_response(data: dict) -> dict:
    """
    Inspeciona o body JSON de uma resposta Omie e levanta a exceção
    correta se houver faultcode. Retorna o dict original se não houver erro.

    Deve ser chamado após response.json(), independentemente do status HTTP.
    """
    if "faultcode" not in data:
        return data

    faultcode: str = data.get("faultcode", "")
    faultstring: str = data.get("faultstring", "")
    lower = faultstring.lower()

    if any(faultcode.startswith(p) for p in _SERVER_PREFIX):
        if any(p in lower for p in _UNAVAILABLE_PATTERNS):
            raise OmieUnavailableError(faultcode, faultstring)
        raise OmieServerError(faultcode, faultstring)

    if any(faultcode.startswith(p) for p in _CLIENT_PREFIX):
        if any(p in lower for p in _RATE_LIMIT_PATTERNS):
            raise OmieRateLimitError(faultcode, faultstring)
        if any(p in lower for p in _AUTH_PATTERNS):
            raise OmieAuthError(faultcode, faultstring)
        if any(p in lower for p in _DUPLICATE_PATTERNS):
            raise OmieDuplicateError(faultcode, faultstring)
        if any(p in lower for p in _NOT_FOUND_PATTERNS):
            raise OmieNotFoundError(faultcode, faultstring)
        if any(p in lower for p in _VALIDATION_PATTERNS):
            raise OmieValidationError(faultcode, faultstring)
        raise OmieClientError(faultcode, faultstring)

    if any(p in lower for p in _RATE_LIMIT_PATTERNS):
        raise OmieRateLimitError(faultcode, faultstring)
    if any(p in lower for p in _DUPLICATE_PATTERNS):
        raise OmieDuplicateError(faultcode, faultstring)

    raise OmieError(faultcode, faultstring)
