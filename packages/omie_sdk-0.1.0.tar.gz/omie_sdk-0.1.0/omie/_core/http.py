"""Cliente HTTP base — autenticação, serialização e parsing de erros."""

from __future__ import annotations

import json
from typing import Any

import requests

from omie.errors import parse_omie_response


class OmieHttp:
    """Executa chamadas autenticadas à API Omie."""

    BASE_URL = "https://app.omie.com.br/api/v1"
    HEADERS = {"Content-Type": "application/json"}
    TIMEOUT = 30

    def __init__(self, app_key: str, app_secret: str) -> None:
        if not app_key or not app_secret:
            raise ValueError("app_key e app_secret são obrigatórios")

        self._app_key = app_key
        self._app_secret = app_secret

    def post(self, path: str, call: str, param: list[dict[str, Any]]) -> dict:
        """
        Envia uma chamada à API Omie e retorna o body deserializado.
        Levanta exceções tipadas de omie.errors quando a Omie retorna faultcode.
        """
        url = f"{self.BASE_URL}/{path.strip('/')}/"

        payload = json.dumps(
            {
                "app_key": self._app_key,
                "app_secret": self._app_secret,
                "call": call,
                "param": param,
            }
        )

        response = requests.post(
            url,
            headers=self.HEADERS,
            data=payload,
            timeout=self.TIMEOUT,
        )

        try:
            data = response.json()
        except requests.exceptions.JSONDecodeError:
            response.raise_for_status()
            return {}

        return parse_omie_response(data)
