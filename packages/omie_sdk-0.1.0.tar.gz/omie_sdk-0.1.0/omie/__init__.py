"""
omie-sdk — SDK Python para a API Omie, organizado por contexto.

Contextos disponíveis:
    omie.financas   Contas a Receber e Contas a Pagar
    omie.errors     Exceções tipadas e parse_omie_response
"""

__version__ = "0.1.0"
