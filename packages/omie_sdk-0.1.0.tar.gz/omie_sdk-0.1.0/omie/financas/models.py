"""
Models Pydantic para o contexto financeiro da Omie.

Todos os campos seguem a nomenclatura oficial da API Omie.
Datas devem estar no formato DD/MM/YYYY.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, field_validator, model_validator

# ---------------------------------------------------------------------------
# Base compartilhada
# ---------------------------------------------------------------------------


class _OmieFinancaBase(BaseModel):
    """Campos comuns entre contas a receber e a pagar."""

    model_config = {"frozen": True}

    codigo_lancamento_integracao: str
    codigo_cliente_fornecedor: int
    data_vencimento: str
    valor_documento: float
    codigo_categoria: str
    data_previsao: str
    id_conta_corrente: str
    data_emissao: str
    observacao: str = ""

    @field_validator("data_vencimento", "data_previsao", "data_emissao")
    @classmethod
    def _validar_data(cls, v: str) -> str:
        from datetime import datetime

        try:
            datetime.strptime(v, "%d/%m/%Y")
        except ValueError:
            raise ValueError(f"Data deve estar no formato DD/MM/YYYY, recebido: {v!r}")
        return v

    @field_validator("valor_documento")
    @classmethod
    def _validar_valor(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"valor_documento deve ser positivo, recebido: {v}")
        return v

    @field_validator("codigo_lancamento_integracao")
    @classmethod
    def _validar_integracao(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("codigo_lancamento_integracao não pode ser vazio")
        return v

    def to_omie_dict(self) -> dict:
        return self.model_dump(exclude_none=True)


# ---------------------------------------------------------------------------
# Conta a Receber
# ---------------------------------------------------------------------------


class ContaReceberParam(_OmieFinancaBase):
    """
    Parâmetros para IncluirContaReceber / AlterarContaReceber.

    Uso:
        param = ContaReceberParam(
            codigo_lancamento_integracao="meu-sistema-123",
            codigo_cliente_fornecedor=98765,
            data_vencimento="30/06/2025",
            valor_documento=1500.00,
            codigo_categoria="1.01.02",
            data_previsao="30/06/2025",
            id_conta_corrente="12345678",
            data_emissao="01/06/2025",
            nsu="NSU-001",
            observacao="Fatura junho",
        )
        financas.incluir_conta_receber(param)
    """

    nsu: str = ""

    # codigo_lancamento_omie é opcional — usado em alterações via ID Omie
    codigo_lancamento_omie: Optional[int] = None

    @model_validator(mode="after")
    def _validar_identificador(self) -> ContaReceberParam:
        """Em alterações, exige ao menos um dos identificadores."""
        # na inclusão o integracao já é obrigatório pelo tipo str
        return self


class ConsultarContaReceberParam(BaseModel):
    """
    Parâmetros para ConsultarContaReceber.
    Ao menos um dos dois campos é obrigatório.
    """

    model_config = {"frozen": True}

    codigo_lancamento_integracao: Optional[str] = None
    codigo_lancamento_omie: Optional[int] = None

    @model_validator(mode="after")
    def _exige_um(self) -> ConsultarContaReceberParam:
        if not self.codigo_lancamento_integracao and not self.codigo_lancamento_omie:
            raise ValueError(
                "Informe codigo_lancamento_integracao ou codigo_lancamento_omie"
            )
        return self

    def to_omie_dict(self) -> dict:
        return self.model_dump(exclude_none=True)


class ListarContasReceberParam(BaseModel):
    """
    Parâmetros para ListarContasReceber.

    Filtros opcionais:
        data_vencimento_de / data_vencimento_ate   DD/MM/YYYY
        data_emissao_de / data_emissao_ate          DD/MM/YYYY
        codigo_cliente                              int
        status_titulo                               "ABERTO" | "RECEBIDO" | "ATRASADO"
    """

    model_config = {"frozen": True}

    pagina: int = 1
    registros_por_pagina: int = 50

    data_vencimento_de: Optional[str] = None
    data_vencimento_ate: Optional[str] = None
    data_emissao_de: Optional[str] = None
    data_emissao_ate: Optional[str] = None
    codigo_cliente: Optional[int] = None
    status_titulo: Optional[str] = None

    @field_validator(
        "data_vencimento_de",
        "data_vencimento_ate",
        "data_emissao_de",
        "data_emissao_ate",
        mode="before",
    )
    @classmethod
    def _validar_datas_filtro(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        from datetime import datetime

        try:
            datetime.strptime(v, "%d/%m/%Y")
        except ValueError:
            raise ValueError(f"Data deve estar no formato DD/MM/YYYY, recebido: {v!r}")
        return v

    @field_validator("pagina", "registros_por_pagina")
    @classmethod
    def _validar_positivo(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Deve ser >= 1, recebido: {v}")
        return v

    @field_validator("registros_por_pagina")
    @classmethod
    def _validar_limite(cls, v: int) -> int:
        if v > 100:
            raise ValueError("registros_por_pagina máximo é 100 (limite da Omie)")
        return v

    def to_omie_dict(self) -> dict:
        return self.model_dump(exclude_none=True)


# ---------------------------------------------------------------------------
# Conta a Pagar
# ---------------------------------------------------------------------------


class ContaPagarParam(_OmieFinancaBase):
    """
    Parâmetros para IncluirContaPagar.

    Uso:
        param = ContaPagarParam(
            codigo_lancamento_integracao="fornecedor-456",
            codigo_cliente_fornecedor=11111,
            data_vencimento="15/07/2025",
            valor_documento=800.00,
            codigo_categoria="2.01.01",
            data_previsao="15/07/2025",
            id_conta_corrente="12345678",
            data_emissao="01/07/2025",
        )
        financas.incluir_conta_pagar(param)
    """

    codigo_lancamento_omie: Optional[int] = None
