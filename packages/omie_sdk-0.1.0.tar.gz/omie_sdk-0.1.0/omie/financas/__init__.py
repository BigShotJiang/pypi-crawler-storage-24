"""
omie.financas — Contas a Receber e Contas a Pagar.

Uso:
    from omie.financas import OmieFinancas
    from omie.financas.models import (
        ContaReceberParam,
        ContaPagarParam,
        ConsultarContaReceberParam,
        ListarContasReceberParam,
    )

    financas = OmieFinancas(app_key="...", app_secret="...")

    financas.incluir_conta_receber(ContaReceberParam(...))
    financas.alterar_conta_receber(ContaReceberParam(...))
    financas.consultar_conta_receber(ConsultarContaReceberParam(...))
    financas.listar_contas_receber(ListarContasReceberParam(...))
    financas.incluir_conta_pagar(ContaPagarParam(...))
"""

from __future__ import annotations

from omie._core import OmieHttp
from omie.financas.models import (
    ContaPagarParam,
    ContaReceberParam,
    ConsultarContaReceberParam,
    ListarContasReceberParam,
)

_PATH_RECEBER = "financas/contareceber"
_PATH_PAGAR   = "financas/contapagar"


class OmieFinancas:
    """
    Contexto financeiro da API Omie.
    Agrupa Contas a Receber e Contas a Pagar.
    """

    def __init__(self, app_key: str, app_secret: str) -> None:
        self._http = OmieHttp(app_key, app_secret)

    # ------------------------------------------------------------------
    # Contas a Receber
    # ------------------------------------------------------------------

    def incluir_conta_receber(self, param: ContaReceberParam) -> dict:
        """
        Inclui uma conta a receber.

        Raises:
            OmieDuplicateError   código de integração já existe → e.omie_id
            OmieAuthError        credenciais inválidas
            OmieRateLimitError   rate limit → e.retry_after
        """
        return self._http.post(_PATH_RECEBER, "IncluirContaReceber", [param.to_omie_dict()])

    def alterar_conta_receber(self, param: ContaReceberParam) -> dict:
        """
        Altera uma conta a receber existente.

        Raises:
            OmieNotFoundError    código não encontrado
            OmieAuthError        credenciais inválidas
        """
        return self._http.post(_PATH_RECEBER, "AlterarContaReceber", [param.to_omie_dict()])

    def consultar_conta_receber(self, param: ConsultarContaReceberParam) -> dict:
        """
        Consulta uma conta a receber pelo código de integração ou código Omie.

        Raises:
            OmieNotFoundError    código não encontrado
        """
        return self._http.post(_PATH_RECEBER, "ConsultarContaReceber", [param.to_omie_dict()])

    def listar_contas_receber(self, param: ListarContasReceberParam | None = None) -> dict:
        """
        Lista contas a receber de forma paginada.

        Retorna:
            pagina, total_de_paginas, registros,
            total_de_registros, conta_receber_cadastro

        Raises:
            OmieNotFoundError    página informada não existe
        """
        p = param or ListarContasReceberParam()
        return self._http.post(_PATH_RECEBER, "ListarContasReceber", [p.to_omie_dict()])

    # ------------------------------------------------------------------
    # Contas a Pagar
    # ------------------------------------------------------------------

    def incluir_conta_pagar(self, param: ContaPagarParam) -> dict:
        """
        Inclui uma conta a pagar.

        Raises:
            OmieDuplicateError   código de integração já existe → e.omie_id
            OmieAuthError        credenciais inválidas
            OmieRateLimitError   rate limit → e.retry_after
        """
        return self._http.post(_PATH_PAGAR, "IncluirContaPagar", [param.to_omie_dict()])
