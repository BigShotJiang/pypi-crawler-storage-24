"""
Testes de omie-sdk — sem HTTP real (monkey-patch em OmieHttp.post).
"""

import sys
sys.path.insert(0, ".")

from pydantic import ValidationError

from omie.errors import (
    OmieError, OmieClientError, OmieServerError,
    OmieAuthError, OmieValidationError, OmieDuplicateError,
    OmieNotFoundError, OmieRateLimitError, OmieUnavailableError,
    parse_omie_response,
)
from omie.financas import OmieFinancas
from omie.financas.models import (
    ContaReceberParam,
    ContaPagarParam,
    ConsultarContaReceberParam,
    ListarContasReceberParam,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

passed = failed = 0

def ok(name):
    global passed; passed += 1
    print(f"  PASS  {name}")

def fail(name, reason):
    global failed; failed += 1
    print(f"  FAIL  {name}: {reason}")

def check(name, fn):
    try:
        fn()
        ok(name)
    except AssertionError as e:
        fail(name, str(e))
    except Exception as e:
        fail(name, f"unexpected {type(e).__name__}: {e}")

def expect_exc(name, exc_cls, fn):
    try:
        fn()
        fail(name, f"esperava {exc_cls.__name__}, não levantou")
    except exc_cls:
        ok(name)
    except Exception as e:
        fail(name, f"esperava {exc_cls.__name__}, got {type(e).__name__}: {e}")

_VALID_RECEBER = dict(
    codigo_lancamento_integracao="abc-1",
    codigo_cliente_fornecedor=99,
    data_vencimento="30/06/2025",
    valor_documento=100.0,
    codigo_categoria="1.01",
    data_previsao="30/06/2025",
    id_conta_corrente="12345",
    data_emissao="01/06/2025",
)

# ---------------------------------------------------------------------------
# ContaReceberParam — validações
# ---------------------------------------------------------------------------

check("ContaReceberParam cria com dados válidos", lambda:
    ContaReceberParam(**_VALID_RECEBER))

expect_exc("ContaReceberParam rejeita data inválida", ValidationError, lambda:
    ContaReceberParam(**{**_VALID_RECEBER, "data_vencimento": "2025-06-30"}))

expect_exc("ContaReceberParam rejeita valor zero", ValidationError, lambda:
    ContaReceberParam(**{**_VALID_RECEBER, "valor_documento": 0}))

expect_exc("ContaReceberParam rejeita valor negativo", ValidationError, lambda:
    ContaReceberParam(**{**_VALID_RECEBER, "valor_documento": -1}))

expect_exc("ContaReceberParam rejeita integracao vazio", ValidationError, lambda:
    ContaReceberParam(**{**_VALID_RECEBER, "codigo_lancamento_integracao": ""}))

check("ContaReceberParam.to_omie_dict exclui None", lambda: (
    p := ContaReceberParam(**_VALID_RECEBER),
    None if "codigo_lancamento_omie" not in p.to_omie_dict()
    else (_ for _ in ()).throw(AssertionError("omie_id não deveria aparecer"))
))

check("ContaReceberParam é imutável (frozen)", lambda: (
    p := ContaReceberParam(**_VALID_RECEBER),
    expect_exc("frozen", TypeError, lambda: setattr(p, "valor_documento", 999))
) or None)
try:
    p = ContaReceberParam(**_VALID_RECEBER)
    p.valor_documento = 999
    fail("ContaReceberParam é imutável (frozen)", "permitiu mutação")
except Exception:
    ok("ContaReceberParam é imutável (frozen)")

# ---------------------------------------------------------------------------
# ConsultarContaReceberParam
# ---------------------------------------------------------------------------

check("ConsultarContaReceberParam aceita integracao", lambda:
    ConsultarContaReceberParam(codigo_lancamento_integracao="abc-1"))

check("ConsultarContaReceberParam aceita omie_id", lambda:
    ConsultarContaReceberParam(codigo_lancamento_omie=123))

expect_exc("ConsultarContaReceberParam rejeita sem nenhum campo", ValidationError, lambda:
    ConsultarContaReceberParam())

check("ConsultarContaReceberParam.to_omie_dict exclui None", lambda: (
    p := ConsultarContaReceberParam(codigo_lancamento_integracao="abc"),
    None if "codigo_lancamento_omie" not in p.to_omie_dict()
    else (_ for _ in ()).throw(AssertionError())
))

# ---------------------------------------------------------------------------
# ListarContasReceberParam
# ---------------------------------------------------------------------------

check("ListarContasReceberParam defaults pagina=1 registros=50", lambda: (
    p := ListarContasReceberParam(),
    None if p.pagina == 1 and p.registros_por_pagina == 50
    else (_ for _ in ()).throw(AssertionError(f"{p.pagina}, {p.registros_por_pagina}"))
))

expect_exc("ListarContasReceberParam rejeita registros > 100", ValidationError, lambda:
    ListarContasReceberParam(registros_por_pagina=101))

expect_exc("ListarContasReceberParam rejeita pagina < 1", ValidationError, lambda:
    ListarContasReceberParam(pagina=0))

expect_exc("ListarContasReceberParam rejeita data filtro inválida", ValidationError, lambda:
    ListarContasReceberParam(data_vencimento_de="2025-01-01"))

check("ListarContasReceberParam.to_omie_dict exclui filtros None", lambda: (
    p := ListarContasReceberParam(),
    d := p.to_omie_dict(),
    None if "data_vencimento_de" not in d
    else (_ for _ in ()).throw(AssertionError("filtro None não deveria aparecer"))
))

# ---------------------------------------------------------------------------
# ContaPagarParam
# ---------------------------------------------------------------------------

check("ContaPagarParam cria com dados válidos", lambda:
    ContaPagarParam(**_VALID_RECEBER))

expect_exc("ContaPagarParam rejeita valor negativo", ValidationError, lambda:
    ContaPagarParam(**{**_VALID_RECEBER, "valor_documento": -50}))

# ---------------------------------------------------------------------------
# OmieFinancas — client (monkey-patch em _http.post)
# ---------------------------------------------------------------------------

financas = OmieFinancas(app_key="key", app_secret="secret")

def patch(return_value):
    financas._http.post = lambda path, call, param: return_value

def patch_raises(exc):
    def _raise(*_): raise exc
    financas._http.post = _raise

check("incluir_conta_receber repassa param correto", lambda: (
    patch({"codigo_lancamento_omie": 1}),
    r := financas.incluir_conta_receber(ContaReceberParam(**_VALID_RECEBER)),
    None if r == {"codigo_lancamento_omie": 1}
    else (_ for _ in ()).throw(AssertionError(r))
))

check("alterar_conta_receber repassa param correto", lambda: (
    patch({"codigo_lancamento_omie": 1}),
    r := financas.alterar_conta_receber(ContaReceberParam(**_VALID_RECEBER)),
    None if r == {"codigo_lancamento_omie": 1}
    else (_ for _ in ()).throw(AssertionError(r))
))

check("consultar_conta_receber repassa param correto", lambda: (
    patch({"codigo_lancamento_integracao": "abc-1"}),
    r := financas.consultar_conta_receber(
        ConsultarContaReceberParam(codigo_lancamento_integracao="abc-1")
    ),
    None if r == {"codigo_lancamento_integracao": "abc-1"}
    else (_ for _ in ()).throw(AssertionError(r))
))

check("listar sem param usa defaults", lambda: (
    captured := {},
    setattr(financas._http, 'post', lambda path, call, param: captured.update({"p": param[0]}) or {}),
    financas.listar_contas_receber(),
    None if captured["p"]["pagina"] == 1 and captured["p"]["registros_por_pagina"] == 50
    else (_ for _ in ()).throw(AssertionError(captured))
))

check("listar com param personalizado", lambda: (
    captured := {},
    setattr(financas._http, 'post', lambda path, call, param: captured.update({"p": param[0]}) or {}),
    financas.listar_contas_receber(ListarContasReceberParam(pagina=3, registros_por_pagina=100)),
    None if captured["p"]["pagina"] == 3 and captured["p"]["registros_por_pagina"] == 100
    else (_ for _ in ()).throw(AssertionError(captured))
))

check("incluir_conta_pagar usa path correto", lambda: (
    paths := [],
    setattr(financas._http, 'post', lambda path, call, param: paths.append(path) or {}),
    financas.incluir_conta_pagar(ContaPagarParam(**_VALID_RECEBER)),
    None if paths[0] == "financas/contapagar"
    else (_ for _ in ()).throw(AssertionError(paths))
))

# erros tipados propagam corretamente
expect_exc("OmieDuplicateError sobe do client", OmieDuplicateError, lambda: (
    patch_raises(OmieDuplicateError("SOAP-ENV:Client-6", "já cadastrada [99]")),
    financas.incluir_conta_receber(ContaReceberParam(**_VALID_RECEBER))
))

expect_exc("OmieRateLimitError sobe do client", OmieRateLimitError, lambda: (
    patch_raises(OmieRateLimitError("SOAP-ENV:Client-6", "Aguarde 54 segundos")),
    financas.incluir_conta_receber(ContaReceberParam(**_VALID_RECEBER))
))

# ---------------------------------------------------------------------------
# parse_omie_response (smoke tests — suite completa está em omie.errors)
# ---------------------------------------------------------------------------

check("parse_omie_response retorna dict sem faultcode", lambda:
    None if parse_omie_response({"x": 1}) == {"x": 1}
    else (_ for _ in ()).throw(AssertionError()))

expect_exc("parse_omie_response levanta OmieAuthError", OmieAuthError, lambda:
    parse_omie_response({"faultcode": "SOAP-ENV:Client", "faultstring": "app_key inválida"}))

expect_exc("parse_omie_response levanta OmieDuplicateError", OmieDuplicateError, lambda:
    parse_omie_response({"faultcode": "SOAP-ENV:Client-6", "faultstring": "já cadastrada"}))

expect_exc("parse_omie_response levanta OmieRateLimitError", OmieRateLimitError, lambda:
    parse_omie_response({"faultcode": "SOAP-ENV:Client-6", "faultstring": "Consumo redundante. Aguarde 54 segundos (REDUNDANT)."}))

# ---------------------------------------------------------------------------
# Resultado
# ---------------------------------------------------------------------------

print(f"\n{passed + failed} testes — {passed} passaram, {failed} falharam")
sys.exit(failed)
