from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="cursofiap_package_maunaoki",
    version="0.1.0",
    packages=find_packages(),
    description="A simple Python package for demonstration",
    author="Naoki",
    author_email="naokimau@gmail.com",
    url="https://github.com/mauricio071/cursofiap_package",
    licence="MIT",
    long_description=long_description,
    long_description_content_type="text/markdown",
)