"""Simple schema migration helpers.

Uses a version table to track applied migrations.
Each migration is a SQL string applied in order.
"""

from __future__ import annotations

from sqlmodel import SQLModel, Field, Session as DBSession, select, text, col
from sqlalchemy.engine import Engine

from openclose.log import get_logger

log = get_logger(__name__)


class SchemaMigration(SQLModel, table=True):
    """Tracks applied schema migrations."""

    __tablename__ = "schema_migrations"

    version: int = Field(primary_key=True)
    description: str = ""


# Ordered list of migrations. Each is (version, description, sql).
MIGRATIONS: list[tuple[int, str, str]] = [
    # Version 1 is the initial schema created by SQLModel.metadata.create_all.
    # Future migrations go here:
    # (2, "add foo column to sessions", "ALTER TABLE sessions ADD COLUMN foo TEXT DEFAULT '';"),
]


def get_current_version(engine: Engine) -> int:
    """Get the highest applied migration version, or 0 if none."""
    # Ensure migration table exists
    SchemaMigration.metadata.create_all(engine, tables=[SchemaMigration.__table__])  # type: ignore[attr-defined]
    with DBSession(engine) as session:
        result = session.exec(
            select(SchemaMigration.version).order_by(
                col(SchemaMigration.version).desc()
            )
        ).first()
        return result if result is not None else 0


def apply_migrations(engine: Engine) -> int:
    """Apply all pending migrations. Returns number of migrations applied."""
    current = get_current_version(engine)
    applied = 0
    last_version = current

    for version, description, sql in MIGRATIONS:
        if version <= current:
            continue
        log.info("Applying migration %d: %s", version, description)
        with DBSession(engine) as session:
            session.exec(text(sql))  # type: ignore[call-overload]
            session.add(SchemaMigration(version=version, description=description))
            session.commit()
        applied += 1
        last_version = version

    if applied:
        log.info("Applied %d migration(s), now at version %d", applied, last_version)
    return applied
