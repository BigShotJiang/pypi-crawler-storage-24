"""Agents configuration loader.

Loads agent definitions from built-in defaults and ``[[agents]]`` sections
in ``config.toml``, resolves inheritance via ``extends``, and returns
ready-to-use ``AgentConfig`` instances.

Priority (highest wins):
1. ``[[agents]]`` in config.toml (user-level and project-level, merged)
2. Built-in defaults (hardcoded below)
"""

from __future__ import annotations

from string import Template
from typing import Any

from openclose.config.schema import AgentConfig
from openclose.log import get_logger

log = get_logger(__name__)

_MAX_EXTENDS_DEPTH = 3

# ── Built-in defaults ────────────────────────────────────────────────

_BUILTIN_AGENT_DEFAULTS: dict[str, dict[str, Any]] = {
    "build": {
        "name": "build",
        "description": "Primary agent with full tool access for code writing and execution.",
        "mode": "primary",
        "denied_tools": [],
    },
    "plan": {
        "name": "plan",
        "description": "Read-only analysis agent. Cannot modify files.",
        "mode": "primary",
        "extends": "build",
        "traits": ["readonly"],
        "denied_tools": ["write", "edit", "bash", "patch"],
    },
}


# ── Inheritance resolution ───────────────────────────────────────────

_INHERITABLE_FIELDS = (
    "description",
    "model",
    "temperature",
    "max_steps",
    "mode",
    "system_prompt",
    "traits",
    "allowed_tools",
    "denied_tools",
)


def _resolve_extends(
    name: str,
    agents_raw: dict[str, dict[str, Any]],
    resolved_cache: dict[str, dict[str, Any]],
    depth: int = 0,
) -> dict[str, Any]:
    """Recursively resolve ``extends`` chains up to *_MAX_EXTENDS_DEPTH*."""
    if name in resolved_cache:
        return resolved_cache[name]

    raw = agents_raw.get(name)
    if raw is None:
        raise ValueError(f"Agent '{name}' referenced by extends does not exist")

    if depth > _MAX_EXTENDS_DEPTH:
        raise ValueError(
            f"Agent extends chain exceeds max depth ({_MAX_EXTENDS_DEPTH}): "
            f"check for cycles near '{name}'"
        )

    parent_name = raw.get("extends", "")
    if parent_name:
        parent = _resolve_extends(parent_name, agents_raw, resolved_cache, depth + 1)
        # Start from parent, override with child's explicit values
        merged: dict[str, Any] = {"name": name}
        for field in _INHERITABLE_FIELDS:
            if field in raw:
                merged[field] = raw[field]
            elif field in parent:
                merged[field] = parent[field]
        resolved_cache[name] = merged
        return merged

    # No extends — just use the raw values
    resolved_cache[name] = raw
    return raw


# ── Template variable substitution ───────────────────────────────────

def render_prompt_template(
    prompt: str,
    variables: dict[str, str],
) -> str:
    """Substitute ``$var`` or ``${var}`` placeholders using `string.Template`.

    Unknown placeholders are left as-is (safe_substitute).
    """
    if not prompt or "$" not in prompt:
        return prompt
    return Template(prompt).safe_substitute(variables)


# ── Public API ───────────────────────────────────────────────────────

def load_agents() -> dict[str, AgentConfig]:
    """Load and resolve all agent definitions.

    Returns a dict of ``name → AgentConfig``, ready for consumption by
    ``agent.agent.get_agent()``.
    """
    # Avoid circular import — config imports schema, we import config here
    from openclose.config.config import get_config

    # Collect raw agent dicts — start with built-in defaults
    agents_raw: dict[str, dict[str, Any]] = {
        name: dict(data) for name, data in _BUILTIN_AGENT_DEFAULTS.items()
    }

    # Overlay agents from config.toml [[agents]] sections.
    # Use exclude_unset so that default values don't shadow parent
    # fields during inheritance resolution.
    config = get_config()
    for agent_cfg in config.agents:
        dumped = agent_cfg.model_dump(exclude_unset=True)
        dumped["name"] = agent_cfg.name  # always include name
        agents_raw[agent_cfg.name] = dumped

    # Resolve inheritance
    resolved_cache: dict[str, dict[str, Any]] = {}
    for name in list(agents_raw.keys()):
        try:
            _resolve_extends(name, agents_raw, resolved_cache)
        except ValueError as e:
            log.error("Failed to resolve agent '%s': %s", name, e)

    # Build AgentConfig instances
    result: dict[str, AgentConfig] = {}
    for name, agent_dict in resolved_cache.items():
        try:
            result[name] = AgentConfig.model_validate(agent_dict)
        except Exception as e:
            log.error("Invalid agent config for '%s': %s", name, e)

    return result


# ── Singleton cache ──────────────────────────────────────────────────

_agents_cache: dict[str, AgentConfig] | None = None


def get_agents() -> dict[str, AgentConfig]:
    """Get the cached agents dict, loading on first call."""
    global _agents_cache
    if _agents_cache is None:
        _agents_cache = load_agents()
    return _agents_cache


def reload_agents() -> dict[str, AgentConfig]:
    """Force-reload agents from disk."""
    global _agents_cache
    _agents_cache = load_agents()
    return _agents_cache
