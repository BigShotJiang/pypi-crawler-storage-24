"""Pydantic v2 configuration schemas."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator


class ProviderConfig(BaseModel):
    """Configuration for an OpenAI-compatible provider."""

    name: str = "default"
    base_url: str = "http://localhost:8000/v1"
    api_key: str = ""
    default_model: str = ""


class AgentConfig(BaseModel):
    """Configuration for an agent (built-in override or custom).

    Supports inheritance via ``extends`` and semantic behaviour flags
    via ``traits``.
    """

    name: str
    description: str = ""
    model: str = ""
    temperature: float = 0.0
    max_steps: int = 100
    mode: str = "primary"
    extends: str = ""  # inherit from another agent by name
    system_prompt: str = ""
    traits: list[str] = Field(default_factory=list)  # e.g. ["readonly"]
    allowed_tools: list[str] = Field(default_factory=list)
    denied_tools: list[str] = Field(default_factory=list)

    @field_validator("temperature")
    @classmethod
    def _check_temperature(cls, v: float) -> float:
        if not (0.0 <= v <= 2.0):
            raise ValueError("temperature must be between 0.0 and 2.0")
        return v

    @field_validator("max_steps")
    @classmethod
    def _check_max_steps(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("max_steps must be positive")
        return v


class PermissionRuleConfig(BaseModel):
    """A single permission rule."""

    tool: str = "*"
    path: str = "*"
    action: Literal["allow", "deny", "ask"] = "ask"


class OpenCloseConfig(BaseModel):
    """Root configuration model."""

    # Provider
    providers: list[ProviderConfig] = Field(
        default_factory=lambda: [ProviderConfig()]
    )

    # Agents
    agents: list[AgentConfig] = Field(default_factory=list)
    default_agent: str = "build"

    # Permissions
    permissions: list[PermissionRuleConfig] = Field(default_factory=list)

    # Session
    max_context_tokens: int = 128_000
    compaction_threshold: float = 0.9
    compaction_summary_max_tokens: int = 2000

    # Misc
    project_dir: str = "."

    @field_validator("compaction_threshold")
    @classmethod
    def _check_compaction_threshold(cls, v: float) -> float:
        if not (0.0 < v <= 1.0):
            raise ValueError("compaction_threshold must be in (0.0, 1.0]")
        return v

    @field_validator("max_context_tokens")
    @classmethod
    def _check_max_context_tokens(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("max_context_tokens must be positive")
        return v
