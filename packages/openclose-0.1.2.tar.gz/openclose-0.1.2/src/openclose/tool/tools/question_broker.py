"""Question broker — manages pending user questions via asyncio Futures.

Mirrors the PermissionBroker pattern: the question tool suspends on a
Future that is resolved when the user answers via the API.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

from openclose.id import generate_id
from openclose.log import get_logger

log = get_logger(__name__)


@dataclass
class PendingQuestion:
    """A question awaiting user reply."""

    request_id: str
    question: str
    session_id: str
    future: asyncio.Future[str]


class QuestionBroker:
    """Manages pending questions with asyncio Futures.

    When the agent invokes the question tool, it calls ``ask()`` which
    suspends until the user replies via ``reply()``.
    """

    def __init__(self) -> None:
        self._pending: dict[str, PendingQuestion] = {}

    async def ask(
        self,
        question: str,
        session_id: str = "",
    ) -> tuple[str, str]:
        """Create a pending question and wait for the user's answer.

        Returns ``(request_id, answer)`` — the request_id is needed so
        the caller can emit the SSE event before awaiting.
        """
        request_id = generate_id()
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()

        pending = PendingQuestion(
            request_id=request_id,
            question=question,
            session_id=session_id,
            future=future,
        )
        self._pending[request_id] = pending
        log.info("Question %s: %s (session %s)", request_id, question[:80], session_id)

        try:
            answer = await future
        finally:
            self._pending.pop(request_id, None)

        return request_id, answer

    def get_request_id(self, question: str, session_id: str = "") -> str:
        """Pre-generate a request_id so the caller can emit SSE before awaiting."""
        request_id = generate_id()
        return request_id

    async def ask_with_id(
        self,
        request_id: str,
        question: str,
        session_id: str = "",
    ) -> str:
        """Like ask(), but uses a pre-generated request_id.

        The caller emits the SSE event with this ID, then awaits the answer.
        """
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()

        pending = PendingQuestion(
            request_id=request_id,
            question=question,
            session_id=session_id,
            future=future,
        )
        self._pending[request_id] = pending
        log.info("Question %s: %s (session %s)", request_id, question[:80], session_id)

        try:
            return await future
        finally:
            self._pending.pop(request_id, None)

    def reply(self, request_id: str, answer: str) -> bool:
        """Resolve a pending question with the user's answer.

        Returns True if the question was found and resolved.
        """
        pending = self._pending.get(request_id)
        if pending is None:
            log.warning("Question reply for unknown request: %s", request_id)
            return False

        if not pending.future.done():
            pending.future.set_result(answer)
            log.info("Question reply %s: %s", request_id, answer[:80])
        return True

    def cancel_session(self, session_id: str) -> None:
        """Cancel all pending questions for a session."""
        to_cancel = [
            p for p in self._pending.values() if p.session_id == session_id
        ]
        for pending in to_cancel:
            if not pending.future.done():
                pending.future.set_result("")
            self._pending.pop(pending.request_id, None)
        if to_cancel:
            log.info(
                "Cancelled %d pending questions for session %s",
                len(to_cancel), session_id,
            )

    def list_pending(self) -> list[dict[str, str]]:
        """List all pending questions."""
        return [
            {
                "request_id": p.request_id,
                "question": p.question,
                "session_id": p.session_id,
            }
            for p in self._pending.values()
        ]


# Singleton
_question_broker: QuestionBroker | None = None


def get_question_broker() -> QuestionBroker:
    """Get the global QuestionBroker singleton."""
    global _question_broker
    if _question_broker is None:
        _question_broker = QuestionBroker()
    return _question_broker
