"""Todo list management tool."""

from __future__ import annotations


from openclose.tool.tool import Tool, ToolResult, ToolParameter

# In-memory todo list (per session)
_todos: list[dict[str, str]] = []


def make_todo_tool() -> Tool:
    """Create the todo list tool."""

    async def execute(
        action: str = "list",
        text: str = "",
        index: int = -1,
        **kwargs: object,
    ) -> ToolResult:
        if action == "add":
            if not text:
                return ToolResult(error="Text is required for 'add' action")
            _todos.append({"text": text, "status": "pending"})
            return ToolResult(
                output=f"Added todo #{len(_todos)}: {text}"
            )

        if action == "list":
            if not _todos:
                return ToolResult(output="No todos.")
            lines = []
            for i, t in enumerate(_todos, 1):
                marker = "x" if t["status"] == "done" else " "
                lines.append(f"[{marker}] {i}. {t['text']}")
            return ToolResult(output="\n".join(lines))

        if action == "done":
            if index < 1 or index > len(_todos):
                return ToolResult(error=f"Invalid index: {index}")
            _todos[index - 1]["status"] = "done"
            return ToolResult(output=f"Marked todo #{index} as done")

        if action == "remove":
            if index < 1 or index > len(_todos):
                return ToolResult(error=f"Invalid index: {index}")
            removed = _todos.pop(index - 1)
            return ToolResult(output=f"Removed: {removed['text']}")

        if action == "clear":
            _todos.clear()
            return ToolResult(output="All todos cleared")

        return ToolResult(error=f"Unknown action: {action}")

    return Tool(
        name="todo",
        description="Manage a todo list (add, list, done, remove, clear).",
        parameters=[
            ToolParameter(
                name="action",
                description="Action to perform",
                enum=["add", "list", "done", "remove", "clear"],
            ),
            ToolParameter(
                name="text",
                description="Todo text (for 'add' action)",
                required=False,
            ),
            ToolParameter(
                name="index",
                type="integer",
                description="Todo index (for 'done' and 'remove' actions)",
                required=False,
                default=-1,
            ),
        ],
        execute_fn=execute,
    )
