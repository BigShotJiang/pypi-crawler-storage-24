"""User question prompt tool — allows agent to ask for clarification."""

from __future__ import annotations

from openclose.tool.tool import Tool, ToolResult, ToolParameter


def make_question_tool() -> Tool:
    """Create the question tool.

    The actual user interaction is handled by the agent loop, which
    detects the ``awaiting_response`` metadata and delegates to the
    QuestionBroker.  The tool itself just validates and returns the
    marker so the loop knows to suspend.
    """

    async def execute(
        question: str = "",
        **kwargs: object,
    ) -> ToolResult:
        if not question:
            return ToolResult(error="Question text is required")

        # Return a marker; the agent loop intercepts this and
        # replaces the result with the user's actual answer.
        return ToolResult(
            output="",
            metadata={"question": question, "awaiting_response": True},
        )

    return Tool(
        name="question",
        description="Ask the user a question for clarification. The response will contain their answer.",
        parameters=[
            ToolParameter(
                name="question",
                description="The question to ask the user",
            ),
        ],
        execute_fn=execute,
    )
