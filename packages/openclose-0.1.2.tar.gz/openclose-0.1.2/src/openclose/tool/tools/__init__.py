"""Built-in tools."""

from openclose.tool.tools.read import make_read_tool
from openclose.tool.tools.write import make_write_tool
from openclose.tool.tools.edit import make_edit_tool
from openclose.tool.tools.glob import make_glob_tool
from openclose.tool.tools.grep import make_grep_tool
from openclose.tool.tools.ls import make_ls_tool
from openclose.tool.tools.bash import make_bash_tool
from openclose.tool.tools.patch import make_patch_tool
from openclose.tool.tools.webfetch import make_webfetch_tool
from openclose.tool.tools.todo import make_todo_tool
from openclose.tool.tools.question import make_question_tool
from openclose.tool.tools.lint import make_lint_tool
from openclose.tool.tools.multiedit import make_multiedit_tool
from openclose.tool.registry import ToolRegistry


def register_all_tools(registry: ToolRegistry, project_dir: str = ".") -> None:
    """Register all built-in tools."""
    registry.register(make_read_tool(project_dir))
    registry.register(make_write_tool(project_dir))
    registry.register(make_edit_tool(project_dir))
    registry.register(make_glob_tool(project_dir))
    registry.register(make_grep_tool(project_dir))
    registry.register(make_ls_tool(project_dir))
    registry.register(make_bash_tool(project_dir))
    registry.register(make_patch_tool(project_dir))
    registry.register(make_webfetch_tool())
    registry.register(make_todo_tool())
    registry.register(make_question_tool())
    registry.register(make_lint_tool(project_dir))
    registry.register(make_multiedit_tool(project_dir))
