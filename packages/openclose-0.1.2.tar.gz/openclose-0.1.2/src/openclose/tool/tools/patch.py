"""Unified diff application tool."""

from __future__ import annotations

from pathlib import Path

from openclose.tool.tool import Tool, ToolResult, ToolParameter


def make_patch_tool(project_dir: str = ".") -> Tool:
    """Create the patch application tool."""

    async def execute(
        file_path: str = "",
        diff: str = "",
        **kwargs: object,
    ) -> ToolResult:
        p = Path(file_path)
        if not p.is_absolute():
            p = Path(project_dir) / p

        p = p.resolve()
        project = Path(project_dir).resolve()
        if not str(p).startswith(str(project)):
            return ToolResult(error=f"Cannot patch outside project directory: {p}")

        if not p.is_file():
            return ToolResult(error=f"File not found: {p}")

        try:
            original = p.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return ToolResult(error=f"Failed to read {p}: {e}")

        # Parse and apply the unified diff
        try:
            patched = _apply_patch(original, diff)
        except ValueError as e:
            return ToolResult(error=str(e))

        try:
            p.write_text(patched, encoding="utf-8")
        except Exception as e:
            return ToolResult(error=f"Failed to write {p}: {e}")

        return ToolResult(
            output=f"Patch applied to {p}",
            metadata={"file_path": str(p)},
        )

    return Tool(
        name="patch",
        description="Apply a unified diff to a file.",
        parameters=[
            ToolParameter(
                name="file_path",
                description="Path to the file to patch",
            ),
            ToolParameter(
                name="diff",
                description="Unified diff content to apply",
            ),
        ],
        execute_fn=execute,
    )


def _apply_patch(original: str, diff: str) -> str:
    """Apply a unified diff to the original text.

    Simple implementation: parse hunks and apply line-by-line.
    """
    orig_lines = original.splitlines(keepends=True)
    diff_lines = diff.splitlines(keepends=True)

    result: list[str] = []
    orig_idx = 0

    i = 0
    while i < len(diff_lines):
        line = diff_lines[i]

        # Skip headers
        if line.startswith("---") or line.startswith("+++"):
            i += 1
            continue

        # Parse hunk header
        if line.startswith("@@"):
            # Extract @@ -start,count +start,count @@
            parts = line.split()
            old_spec = parts[1]  # -start,count
            old_start = int(old_spec.split(",")[0].lstrip("-"))

            # Copy lines before this hunk
            while orig_idx < old_start - 1 and orig_idx < len(orig_lines):
                result.append(orig_lines[orig_idx])
                orig_idx += 1

            i += 1
            # Process hunk lines
            while i < len(diff_lines) and not diff_lines[i].startswith("@@"):
                hline = diff_lines[i]
                if hline.startswith("-"):
                    # Remove line from original
                    orig_idx += 1
                elif hline.startswith("+"):
                    # Add new line
                    result.append(hline[1:])
                elif hline.startswith(" "):
                    # Context line — verify it matches the original
                    expected = hline[1:]
                    if orig_idx < len(orig_lines):
                        actual = orig_lines[orig_idx]
                        if actual.rstrip("\n") != expected.rstrip("\n"):
                            raise ValueError(
                                f"Context mismatch at line {orig_idx + 1}: "
                                f"expected {expected.rstrip()!r}, "
                                f"got {actual.rstrip()!r}"
                            )
                    result.append(hline[1:])
                    orig_idx += 1
                else:
                    # End of diff
                    break
                i += 1
            continue

        i += 1

    # Copy remaining original lines
    while orig_idx < len(orig_lines):
        result.append(orig_lines[orig_idx])
        orig_idx += 1

    return "".join(result)
