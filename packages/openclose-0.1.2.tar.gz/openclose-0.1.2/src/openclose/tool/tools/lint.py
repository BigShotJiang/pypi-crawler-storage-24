"""Lint tool — exposes the linter registry to the agent."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from openclose.lint import get_linter_registry
from openclose.tool.tool import Tool, ToolParameter, ToolResult
from openclose.tool.truncation import truncate_output


def make_lint_tool(project_dir: str = ".") -> Tool:
    """Create a lint tool bound to *project_dir*."""

    async def execute(
        path: str = "",
        **kwargs: Any,
    ) -> ToolResult:
        if not path:
            return ToolResult(error="path is required")

        p = Path(path)
        if not p.is_absolute():
            p = Path(project_dir) / p

        if not p.exists():
            return ToolResult(error=f"Path not found: {p}")

        registry = get_linter_registry()

        if p.is_file():
            result = await registry.lint_file(p)
            if result is None:
                return ToolResult(
                    output=f"No linter available for {p.suffix} files.",
                )
            body = truncate_output(result.output) if result.output else "No issues found."
            if not result.ok:
                body = f"Linter {result.linter_name} reported issues:\n\n{body}"
            return ToolResult(
                output=body,
                metadata={"linter": result.linter_name, "ok": result.ok},
            )

        # Directory
        results = await registry.lint_directory(p)
        if not results:
            return ToolResult(output="No linters available for this directory.")

        parts: list[str] = []
        all_ok = True
        for r in results:
            header = f"--- {r.linter_name} ---"
            body = r.output if r.output else "No issues found."
            parts.append(f"{header}\n{body}")
            if not r.ok:
                all_ok = False

        body = truncate_output("\n\n".join(parts))
        if not all_ok:
            body = f"One or more linters reported issues:\n\n{body}"
        return ToolResult(
            output=body,
            metadata={
                "linters": [r.linter_name for r in results],
                "all_ok": all_ok,
            },
        )

    return Tool(
        name="lint",
        description="Run linters on a file or directory. Supports Python (ruff, mypy), JavaScript/TypeScript (eslint), Go (golangci-lint), Rust (clippy), and C/C++ (clang-tidy, cppcheck).",
        parameters=[
            ToolParameter(
                name="path",
                description="File or directory to lint (relative to project root or absolute)",
            ),
        ],
        execute_fn=execute,
    )
