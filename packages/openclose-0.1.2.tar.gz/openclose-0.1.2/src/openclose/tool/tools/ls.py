"""Directory listing tool."""

from __future__ import annotations

from pathlib import Path

from openclose.tool.tool import Tool, ToolResult, ToolParameter
from openclose.tool.truncation import truncate_output


def make_ls_tool(project_dir: str = ".") -> Tool:
    """Create the directory listing tool."""

    async def execute(
        path: str = "",
        **kwargs: object,
    ) -> ToolResult:
        p = Path(path) if path else Path(project_dir)
        if not p.is_absolute():
            p = Path(project_dir) / p

        if not p.is_dir():
            return ToolResult(error=f"Not a directory: {p}")

        try:
            entries = sorted(p.iterdir(), key=lambda e: (not e.is_dir(), e.name))
        except Exception as e:
            return ToolResult(error=f"Failed to list {p}: {e}")

        lines: list[str] = []
        for entry in entries:
            suffix = "/" if entry.is_dir() else ""
            lines.append(f"{entry.name}{suffix}")

        return ToolResult(
            output=truncate_output("\n".join(lines)) if lines else "(empty directory)",
            metadata={"count": len(lines)},
        )

    return Tool(
        name="ls",
        description="List files and directories. Directories end with /.",
        parameters=[
            ToolParameter(
                name="path",
                description="Directory to list",
                required=False,
            ),
        ],
        execute_fn=execute,
    )
