"""Shell command execution tool."""

from __future__ import annotations

import re

from openclose.tool.tool import Tool, ToolResult, ToolParameter
from openclose.tool.truncation import truncate_output
from openclose.util.process import run
from openclose import flag

# Patterns for dangerous bash commands (best-effort heuristics).
_DANGEROUS_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\brm\s+-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+/"), "rm -rf on root paths is blocked"),
    (re.compile(r"\brm\s+-[a-zA-Z]*f[a-zA-Z]*r[a-zA-Z]*\s+/"), "rm -rf on root paths is blocked"),
    (re.compile(r"\bsudo\b"), "sudo commands are blocked"),
    (re.compile(r"^\s*su\s"), "su commands are blocked"),
    (re.compile(r"\bcurl\b.*\|\s*(ba)?sh\b"), "piping curl to shell is blocked"),
    (re.compile(r"\bwget\b.*\|\s*(ba)?sh\b"), "piping wget to shell is blocked"),
    (re.compile(r":\(\)\{.*\|.*\};:"), "fork bomb is blocked"),
    (re.compile(r">\s*/dev/[sh]da"), "writing to raw disk device is blocked"),
    (re.compile(r"\bmkfs\b"), "mkfs commands are blocked"),
    (re.compile(r"\bdd\b.*\bof=/dev/"), "dd to device is blocked"),
]


def _check_command(command: str) -> str | None:
    """Check if a command matches dangerous patterns.

    Returns an error message if blocked, None otherwise.
    This is best-effort — the real security boundary is the permission engine.
    """
    for pattern, reason in _DANGEROUS_PATTERNS:
        if pattern.search(command):
            return reason
    return None


def make_bash_tool(project_dir: str = ".") -> Tool:
    """Create the bash execution tool."""

    async def execute(
        command: str = "",
        timeout: int = 0,
        **kwargs: object,
    ) -> ToolResult:
        if not command.strip():
            return ToolResult(error="Empty command")

        blocked = _check_command(command)
        if blocked:
            return ToolResult(error=f"Blocked: {blocked}")

        timeout_ms = timeout if timeout > 0 else flag.BASH_DEFAULT_TIMEOUT_MS
        timeout_s = timeout_ms / 1000.0

        result = await run(
            "bash", "-c", command,
            cwd=project_dir,
            timeout=timeout_s,
        )

        output_parts: list[str] = []
        if result.stdout:
            output_parts.append(result.stdout)
        if result.stderr:
            output_parts.append(f"[stderr]\n{result.stderr}")
        if result.returncode != 0:
            output_parts.append(f"[exit code: {result.returncode}]")

        output = "\n".join(output_parts)
        return ToolResult(
            output=truncate_output(output),
            error="" if result.ok else f"Command failed with exit code {result.returncode}",
            metadata={"returncode": result.returncode},
        )

    return Tool(
        name="bash",
        description="Execute a bash command and return its output.",
        parameters=[
            ToolParameter(
                name="command",
                description="The bash command to execute",
            ),
            ToolParameter(
                name="timeout",
                type="integer",
                description="Timeout in milliseconds",
                required=False,
                default=0,
            ),
        ],
        execute_fn=execute,
    )
