"""OpenAI-compatible provider — wraps the openai SDK for any compatible endpoint."""

from __future__ import annotations

from typing import Any, AsyncIterator

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionChunk

from openclose.config.config import get_config
from openclose.provider.auth import load_api_key
from openclose.log import get_logger

log = get_logger(__name__)


class Provider:
    """OpenAI-compatible LLM provider.

    Works with OpenAI, vLLM, llama.cpp, Ollama, and any endpoint
    implementing the OpenAI chat completions API.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000/v1",
        api_key: str = "",
        provider_name: str = "default",
    ) -> None:
        resolved_key = api_key or load_api_key(provider_name)
        self._client = AsyncOpenAI(
            base_url=base_url,
            api_key=resolved_key or "no-key",
        )
        self._provider_name = provider_name
        log.debug("Provider initialized: %s @ %s", provider_name, base_url)

    @property
    def client(self) -> AsyncOpenAI:
        return self._client

    async def detect_model(self) -> str | None:
        """Auto-detect the first available model from the endpoint."""
        try:
            models = await self._client.models.list()
            for m in models.data:
                log.info("Auto-detected model: %s", m.id)
                return m.id
        except Exception as e:
            log.warning("Failed to auto-detect model: %s", e)
        return None

    @staticmethod
    def _wrap_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Wrap flat tool schemas into OpenAI function-calling format."""
        return [{"type": "function", "function": t} for t in tools]

    async def chat(
        self,
        messages: list[ChatCompletionMessageParam],
        model: str,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> AsyncIterator[ChatCompletionChunk]:
        """Send a chat completion request and stream the response."""
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }
        if tools:
            kwargs["tools"] = self._wrap_tools(tools)
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        response = await self._client.chat.completions.create(**kwargs)
        async for chunk in response:
            yield chunk

    async def chat_sync(
        self,
        messages: list[ChatCompletionMessageParam],
        model: str,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> Any:
        """Non-streaming chat completion."""
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": False,
        }
        if tools:
            kwargs["tools"] = self._wrap_tools(tools)
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        return await self._client.chat.completions.create(**kwargs)


_provider: Provider | None = None


def get_provider(provider_name: str = "default") -> Provider:
    """Get or create a provider from config."""
    global _provider
    if _provider is not None:
        return _provider

    config = get_config()
    provider_cfg = None
    for p in config.providers:
        if p.name == provider_name:
            provider_cfg = p
            break

    if provider_cfg is None:
        provider_cfg = config.providers[0] if config.providers else None

    if provider_cfg:
        _provider = Provider(
            base_url=provider_cfg.base_url,
            api_key=provider_cfg.api_key,
            provider_name=provider_cfg.name,
        )
    else:
        _provider = Provider()

    return _provider
