"""API key loading from environment and config."""

from __future__ import annotations

import os

from openclose.config.config import get_config
from openclose.log import get_logger

log = get_logger(__name__)


def load_api_key(provider_name: str = "default") -> str:
    """Load API key for a provider.

    Priority:
    1. OPENCLOSE_API_KEY environment variable
    2. OPENAI_API_KEY environment variable
    3. Provider-specific config
    """
    # Env vars first
    env_key = os.environ.get("OPENCLOSE_API_KEY", "")
    if env_key:
        return env_key

    openai_key = os.environ.get("OPENAI_API_KEY", "")
    if openai_key:
        return openai_key

    # Config
    config = get_config()
    for provider in config.providers:
        if provider.name == provider_name and provider.api_key:
            return provider.api_key

    log.warning("No API key found for provider %r", provider_name)
    return ""
