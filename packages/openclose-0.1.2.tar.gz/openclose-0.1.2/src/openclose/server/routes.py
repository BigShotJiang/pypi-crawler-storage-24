"""API routes — sessions, messages, tools, config."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from starlette.responses import StreamingResponse
from pydantic import BaseModel

from openclose.server.sse import stream_events
from openclose.session.session import SessionManager
from openclose.session.processor import SessionProcessor
from openclose.session.compaction import (
    estimate_messages_tokens,
    estimate_tool_schemas_tokens,
)
from openclose.permission.permission import PermissionEngine
from openclose.permission.broker import get_broker
from openclose.tool.tools.question_broker import get_question_broker
from openclose.storage.db import get_db
from openclose.config.config import get_config
from openclose.session.cancel import get_cancel_registry
from openclose.tool.registry import ToolRegistry
from openclose.tool.tools import register_all_tools

router = APIRouter()


# --- Static API routes (must be before any {session_id} path params) ---

@router.get("/api/files")
async def search_files(q: str = "", limit: int = 20) -> JSONResponse:
    """Search files/folders in the project directory."""
    import os
    from pathlib import Path
    from openclose.file.ignore import IgnoreManager

    config = get_config()
    root = Path(config.project_dir).resolve()
    ignore = IgnoreManager(root)
    query = q.lower()
    results: list[dict[str, str]] = []

    for dirpath, dirnames, filenames in os.walk(root):
        dp = Path(dirpath)
        dirnames[:] = [
            d for d in dirnames
            if not ignore.is_ignored(dp / d) and not d.startswith(".")
        ]
        rel_dir = dp.relative_to(root)

        if str(rel_dir) != ".":
            rel_str = str(rel_dir)
            if query in rel_str.lower():
                results.append({"path": rel_str + "/", "type": "dir"})

        for fname in filenames:
            fp = dp / fname
            if ignore.is_ignored(fp):
                continue
            rel = str(fp.relative_to(root))
            if query in rel.lower():
                results.append({"path": rel, "type": "file"})
            if len(results) >= limit:
                break
        if len(results) >= limit:
            break

    return JSONResponse(results)


class BashRequest(BaseModel):
    command: str


@router.post("/api/bash")
async def run_bash(req: BashRequest) -> JSONResponse:
    """Execute a bash command in the project directory."""
    from openclose.util.process import run

    config = get_config()
    result = await run("bash", "-c", req.command, cwd=config.project_dir, timeout=120.0)
    return JSONResponse({
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode,
    })


def _get_templates() -> Any:
    from openclose.server.app import templates
    return templates


# --- HTML pages ---

@router.get("/")
async def index() -> RedirectResponse:
    """Resume the most recent session, or create a new one if none exist."""
    db = get_db()
    mgr = SessionManager(db)
    sessions = mgr.list_sessions()
    config = get_config()
    if sessions:
        session = sessions[0]
        # Clean up stale empty sessions from previous runs
        mgr.cleanup_empty_sessions(keep_session_id=session.id)
    else:
        # Reuse an existing empty session if available
        agent = config.default_agent
        empty = mgr.get_empty_session(agent=agent)
        session = empty if empty else mgr.create_session(title="", agent=agent)
    return RedirectResponse(url=f"/session/{session.id}", status_code=302)



@router.get("/session/{session_id}", response_class=HTMLResponse)
async def session_page(request: Request, session_id: str) -> HTMLResponse:
    """Chat session page."""
    db = get_db()
    mgr = SessionManager(db)
    session = mgr.get_session(session_id)
    raw_messages = mgr.get_messages(session_id) if session else []
    # Attach parts to each message for template rendering
    messages = []
    for m in raw_messages:
        parts = mgr.get_message_parts(m.id)
        messages.append({
            "id": m.id,
            "role": m.role,
            "content": m.content,
            "created_at": m.created_at,
            "parts": [
                {"part_type": p.part_type, "content": p.content,
                 "tool_name": p.tool_name, "tool_call_id": p.tool_call_id}
                for p in parts
            ],
        })
    # Compute initial context usage for the context bar
    config = get_config()
    if session and raw_messages:
        messages_with_parts = mgr.get_messages_with_parts(session_id)
        llm_messages = SessionProcessor._reconstruct_llm_messages(
            messages_with_parts
        )
        registry = ToolRegistry()
        register_all_tools(registry, config.project_dir)
        tool_schemas = registry.get_schemas()
        msg_tokens = estimate_messages_tokens(llm_messages)
        tools_tokens = estimate_tool_schemas_tokens(tool_schemas)
        context_info: dict[str, object] = {
            "used": msg_tokens + tools_tokens,
            "max": config.max_context_tokens,
            "messages_tokens": msg_tokens,
            "tools_tokens": tools_tokens,
        }
    else:
        context_info = {
            "used": 0,
            "max": config.max_context_tokens,
            "messages_tokens": 0,
            "tools_tokens": 0,
        }

    resp: HTMLResponse = _get_templates().TemplateResponse(
        request, "session.html",
        {"session": session, "messages": messages, "context_info": context_info},
    )
    return resp


# --- API endpoints ---

class CreateSessionRequest(BaseModel):
    title: str = ""
    agent: str = ""


class SendMessageRequest(BaseModel):
    content: str


@router.post("/api/sessions")
async def create_session(req: CreateSessionRequest) -> JSONResponse:
    """Create a new session, reusing an existing empty one if available."""
    db = get_db()
    mgr = SessionManager(db)
    agent = req.agent or get_config().default_agent
    existing = mgr.get_empty_session(agent=agent)
    if existing:
        if req.title and req.title != existing.title:
            mgr.update_title(existing.id, req.title)
            existing.title = req.title
        session = existing
    else:
        session = mgr.create_session(title=req.title, agent=agent)
    return JSONResponse({"id": session.id, "title": session.title})


class ForkSessionRequest(BaseModel):
    agent: str = ""


@router.post("/api/sessions/{session_id}/fork")
async def fork_session(session_id: str, req: ForkSessionRequest) -> JSONResponse:
    """Fork a session with a different agent, preserving message history."""
    db = get_db()
    mgr = SessionManager(db)
    agent = req.agent or get_config().default_agent
    new_session = mgr.fork_session(session_id, agent=agent)
    if new_session is None:
        return JSONResponse({"error": "Source session not found"}, status_code=404)
    return JSONResponse({"id": new_session.id, "title": new_session.title})


@router.get("/api/sessions")
async def list_sessions() -> JSONResponse:
    """List all sessions."""
    db = get_db()
    mgr = SessionManager(db)
    sessions = mgr.list_sessions()
    return JSONResponse([
        {"id": s.id, "title": s.title, "agent": s.agent, "updated_at": str(s.updated_at)}
        for s in sessions
    ])


@router.get("/api/sessions/{session_id}/messages")
async def get_messages(session_id: str) -> JSONResponse:
    """Get messages for a session."""
    db = get_db()
    mgr = SessionManager(db)
    messages = mgr.get_messages(session_id)
    result = []
    for m in messages:
        parts = mgr.get_message_parts(m.id)
        result.append({
            "id": m.id, "role": m.role, "content": m.content,
            "created_at": str(m.created_at),
            "parts": [
                {"part_type": p.part_type, "content": p.content,
                 "tool_name": p.tool_name, "tool_call_id": p.tool_call_id}
                for p in parts
            ],
        })
    return JSONResponse(result)


@router.post("/api/sessions/{session_id}/messages")
async def send_message(session_id: str, req: SendMessageRequest) -> StreamingResponse:
    """Send a message and stream the response via SSE."""
    db = get_db()
    config = get_config()

    # Set up tool registry
    registry = ToolRegistry()
    register_all_tools(registry, config.project_dir)

    # Look up the session's agent
    mgr = SessionManager(db)
    session = mgr.get_session(session_id)
    agent_name = session.agent if session else config.default_agent

    permission_engine = PermissionEngine.for_session(session_id)
    permission_broker = get_broker()
    question_broker = get_question_broker()

    cancel_registry = get_cancel_registry()
    cancel_event = cancel_registry.register(session_id)

    processor = SessionProcessor(
        db=db,
        session_id=session_id,
        agent_name=agent_name,
        tool_executor=registry.execute,
        tool_schemas=registry.get_schemas(),
        project_dir=config.project_dir,
        permission_engine=permission_engine,
        permission_broker=permission_broker,
        question_broker=question_broker,
        cancel_event=cancel_event,
    )

    async def _stream_with_cleanup() -> AsyncIterator[str]:
        try:
            async for chunk in stream_events(processor.process(req.content)):
                yield chunk
        finally:
            cancel_registry.unregister(session_id)

    return StreamingResponse(
        _stream_with_cleanup(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/api/sessions/{session_id}/interrupt")
async def interrupt_session(session_id: str) -> JSONResponse:
    """Interrupt an active LLM generation for a session."""
    cancel_registry = get_cancel_registry()
    permission_broker = get_broker()
    permission_broker.cancel_session(session_id)
    question_broker = get_question_broker()
    question_broker.cancel_session(session_id)
    found = cancel_registry.cancel(session_id)
    return JSONResponse({"ok": found, "interrupted": found})


class PermissionReplyRequest(BaseModel):
    reply: str  # "once", "always", "reject"


@router.post("/api/permissions/{request_id}/reply")
async def permission_reply(request_id: str, req: PermissionReplyRequest) -> JSONResponse:
    """Reply to a pending permission request."""
    if req.reply not in ("once", "always", "reject"):
        return JSONResponse({"error": "Invalid reply; must be once, always, or reject"}, status_code=400)
    broker = get_broker()
    found = broker.reply(request_id, req.reply)  # type: ignore[arg-type]
    if not found:
        return JSONResponse({"error": "Permission request not found or already resolved"}, status_code=404)
    return JSONResponse({"ok": True})


@router.post("/api/sessions/{session_id}/skip-permissions")
async def toggle_skip_permissions(session_id: str) -> JSONResponse:
    """Toggle skip-all permissions mode for a session."""
    engine = PermissionEngine.for_session(session_id)
    engine.set_skip_all(not engine.skip_all)
    return JSONResponse({"skip_all": engine.skip_all})


@router.get("/api/sessions/{session_id}/skip-permissions")
async def get_skip_permissions(session_id: str) -> JSONResponse:
    """Get current skip-all permissions status."""
    engine = PermissionEngine.for_session(session_id)
    return JSONResponse({"skip_all": engine.skip_all})


class QuestionReplyRequest(BaseModel):
    answer: str


@router.post("/api/questions/{request_id}/reply")
async def question_reply(request_id: str, req: QuestionReplyRequest) -> JSONResponse:
    """Reply to a pending question from the agent."""
    broker = get_question_broker()
    found = broker.reply(request_id, req.answer)
    if not found:
        return JSONResponse({"error": "Question not found or already answered"}, status_code=404)
    return JSONResponse({"ok": True})


@router.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str) -> JSONResponse:
    """Delete a session."""
    db = get_db()
    mgr = SessionManager(db)
    success = mgr.delete_session(session_id)
    PermissionEngine.remove_session(session_id)
    return JSONResponse({"deleted": success})


class RenameRequest(BaseModel):
    title: str


@router.patch("/api/sessions/{session_id}/rename")
async def rename_session(session_id: str, req: RenameRequest) -> JSONResponse:
    """Rename a session."""
    db = get_db()
    mgr = SessionManager(db)
    success = mgr.update_title(session_id, req.title)
    return JSONResponse({"ok": success, "title": req.title})


@router.post("/api/sessions/{session_id}/undo")
async def undo_message(session_id: str) -> JSONResponse:
    """Remove the last user+assistant message pair."""
    db = get_db()
    mgr = SessionManager(db)
    messages = mgr.get_messages(session_id)
    removed = 0
    # Remove from the end: assistant then user
    for msg in reversed(messages):
        if removed >= 2:
            break
        with db.get_session() as s:
            from openclose.storage.schema import Message, MessagePart
            from sqlmodel import select
            parts = s.exec(select(MessagePart).where(MessagePart.message_id == msg.id)).all()
            for p in parts:
                s.delete(p)
            loaded = s.get(Message, msg.id)
            if loaded:
                s.delete(loaded)
            s.commit()
        removed += 1
    return JSONResponse({"ok": True, "removed": removed})


@router.get("/api/sessions/{session_id}/export")
async def export_session(session_id: str) -> JSONResponse:
    """Export session as structured data."""
    db = get_db()
    mgr = SessionManager(db)
    session = mgr.get_session(session_id)
    if not session:
        return JSONResponse({"error": "Session not found"}, status_code=404)
    messages = mgr.get_messages(session_id)
    return JSONResponse({
        "session": {"id": session.id, "title": session.title, "agent": session.agent},
        "messages": [
            {"role": m.role, "content": m.content, "created_at": str(m.created_at)}
            for m in messages
        ],
    })


@router.post("/api/sessions/{session_id}/compact")
async def compact_session(session_id: str) -> JSONResponse:
    """Trigger context compaction on a session."""
    db = get_db()
    mgr = SessionManager(db)
    messages = mgr.get_messages(session_id)
    from openclose.session.compaction import compact_messages
    msg_dicts = [{"role": m.role, "content": m.content} for m in messages]
    config = get_config()
    _, compacted, _ = compact_messages(
        msg_dicts,
        max_tokens=config.max_context_tokens,
    )
    return JSONResponse({"ok": True, "compacted": compacted, "message_count": len(messages)})


@router.get("/api/agents")
async def list_agents() -> JSONResponse:
    """List available agents."""
    from openclose.agent.agent import list_agents as _list_agents
    agents = _list_agents()
    return JSONResponse([
        {"name": a.name, "description": a.description}
        for a in agents
    ])


@router.get("/api/config")
async def get_config_endpoint() -> JSONResponse:
    """Get current configuration."""
    config = get_config()
    return JSONResponse(config.model_dump())
