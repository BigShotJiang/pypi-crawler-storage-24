function updateContextBar(info) {
    if (!info || !info.max) return;
    var pct = Math.min(100, Math.round((info.used / info.max) * 100));
    var fill = document.getElementById('context-bar-fill');
    var usedEl = document.getElementById('context-tokens-used');
    var maxEl = document.getElementById('context-tokens-max');
    var pctEl = document.getElementById('context-bar-pct');
    if (fill) {
        fill.style.width = pct + '%';
        fill.className = 'context-bar-fill' + (
            pct >= 90 ? ' level-critical' :
            pct >= 80 ? ' level-high' :
            pct >= 60 ? ' level-medium' :
            ' level-low'
        );
    }
    if (usedEl) usedEl.textContent = info.used.toLocaleString();
    if (maxEl) maxEl.textContent = info.max.toLocaleString();
    if (pctEl) pctEl.textContent = pct + '%';
}

function initChat(sessionId) {
    const messagesDiv = document.getElementById('messages');
    const input = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');

    // --- Slash commands ---
    const COMMANDS = [
        {name: '/new',      description: 'Start a new session'},
        {name: '/sessions', description: 'Switch to another session'},
        {name: '/rename',   description: 'Rename this session'},
        {name: '/agents',   description: 'Switch agent (build/plan)'},
        {name: '/compact',  description: 'Compress context window'},
        {name: '/undo',     description: 'Remove last message pair'},
        {name: '/export',   description: 'Export session transcript'},
        {name: '/copy',     description: 'Copy last response to clipboard'},
        {name: '/skip',     description: 'Toggle auto-approve permissions'},
        {name: '/help',     description: 'Show available commands'},
    ];

    const cmdBar = document.getElementById('command-bar');

    function showCommandBar(filter) {
        const q = filter.toLowerCase();
        const matches = COMMANDS.filter(c => c.name.includes(q));
        if (matches.length === 0) { hideCommandBar(); return; }
        cmdBar.innerHTML = '';
        matches.forEach((cmd, i) => {
            const div = document.createElement('div');
            div.className = 'cmd-item' + (i === 0 ? ' active' : '');
            div.innerHTML = '<span class="cmd-name">' + cmd.name + '</span><span class="cmd-desc">' + cmd.description + '</span>';
            div.addEventListener('click', () => { executeCommand(cmd.name); });
            cmdBar.appendChild(div);
        });
        cmdBar.style.display = 'block';
    }

    function hideCommandBar() {
        cmdBar.style.display = 'none';
        cmdBar.innerHTML = '';
    }

    function getActiveCommand() {
        const active = cmdBar.querySelector('.cmd-item.active');
        if (!active) return null;
        return active.querySelector('.cmd-name').textContent;
    }

    function moveCommandSelection(dir) {
        const items = cmdBar.querySelectorAll('.cmd-item');
        if (items.length === 0) return;
        let idx = -1;
        items.forEach((el, i) => { if (el.classList.contains('active')) idx = i; });
        items.forEach(el => el.classList.remove('active'));
        idx = (idx + dir + items.length) % items.length;
        items[idx].classList.add('active');
    }

    async function executeCommand(name) {
        hideCommandBar();
        input.value = '';

        switch (name) {
        case '/new': {
            const res = await fetch('/api/sessions', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({title: ''})
            });
            const data = await res.json();
            window.location.href = '/session/' + data.id;
            break;
        }
        case '/sessions': {
            const res = await fetch('/api/sessions');
            const sessions = await res.json();
            showSessionPicker(sessions);
            break;
        }
        case '/rename': {
            const title = prompt('New session title:');
            if (title) {
                await fetch('/api/sessions/' + sessionId + '/rename', {
                    method: 'PATCH',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({title: title})
                });
                document.getElementById('session-title').textContent = title;
            }
            break;
        }
        case '/agents': {
            const res = await fetch('/api/agents');
            const agents = await res.json();
            showAgentPicker(agents);
            break;
        }
        case '/compact': {
            const res = await fetch('/api/sessions/' + sessionId + '/compact', {method: 'POST'});
            const data = await res.json();
            addMessage('system', data.compacted ? 'Context compacted.' : 'No compaction needed.', false);
            break;
        }
        case '/undo': {
            await fetch('/api/sessions/' + sessionId + '/undo', {method: 'POST'});
            window.location.reload();
            break;
        }
        case '/export': {
            const res = await fetch('/api/sessions/' + sessionId + '/export');
            const data = await res.json();
            const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'session-' + sessionId + '.json';
            a.click();
            URL.revokeObjectURL(url);
            break;
        }
        case '/copy': {
            const msgs = document.querySelectorAll('.message.assistant .content');
            if (msgs.length > 0) {
                const last = msgs[msgs.length - 1].textContent;
                await navigator.clipboard.writeText(last);
                addMessage('system', 'Copied to clipboard.', false);
            }
            break;
        }
        case '/skip': {
            const res = await fetch('/api/sessions/' + sessionId + '/skip-permissions', {method: 'POST'});
            const data = await res.json();
            addMessage('system', data.skip_all ? 'Skip permissions: ON (auto-approving tool calls)' : 'Skip permissions: OFF', false);
            updateSkipButton(data.skip_all);
            break;
        }
        case '/help':
            showHelp();
            break;
        }
        input.focus();
    }

    function updateSkipButton(active) {
        var btn = document.getElementById('info-skip-btn');
        if (btn) {
            btn.textContent = active ? 'Skip Perms: ON' : 'Skip Perms: OFF';
            if (active) { btn.classList.add('btn-active'); } else { btn.classList.remove('btn-active'); }
        }
    }

    function showHelp() {
        let text = 'Available commands:\n';
        COMMANDS.forEach(c => { text += '  ' + c.name.padEnd(12) + ' — ' + c.description + '\n'; });
        addMessage('system', text, false);
    }

    function showSessionPicker(sessions) {
        const overlay = document.createElement('div');
        overlay.className = 'picker-overlay';
        const picker = document.createElement('div');
        picker.className = 'picker';
        picker.innerHTML = '<div class="picker-title">Sessions</div>';
        sessions.forEach(s => {
            const row = document.createElement('a');
            row.className = 'picker-item';
            row.href = '/session/' + s.id;
            row.textContent = (s.title || 'Untitled') + '  [' + s.agent + ']';
            picker.appendChild(row);
        });
        overlay.appendChild(picker);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
        document.body.appendChild(overlay);
    }

    function showAgentPicker(agents) {
        const overlay = document.createElement('div');
        overlay.className = 'picker-overlay';
        const picker = document.createElement('div');
        picker.className = 'picker';
        picker.innerHTML = '<div class="picker-title">Agents</div>';
        agents.forEach(a => {
            const row = document.createElement('div');
            row.className = 'picker-item';
            row.textContent = a.name + (a.description ? ' — ' + a.description : '');
            row.addEventListener('click', async () => {
                // Fork current session with selected agent, preserving history
                const res = await fetch('/api/sessions/' + sessionId + '/fork', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({agent: a.name})
                });
                const data = await res.json();
                window.location.href = '/session/' + data.id;
            });
            picker.appendChild(row);
        });
        overlay.appendChild(picker);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
        document.body.appendChild(overlay);
    }

    // --- Markdown rendering ---
    function renderMarkdown(text) {
        if (typeof marked !== 'undefined') {
            return marked.parse(text);
        }
        return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
    }

    function addMessage(role, content, useMarkdown) {
        const div = document.createElement('div');
        div.className = 'message ' + role;
        div.innerHTML = '<div class="role">' + role + '</div><div class="content"></div>';
        const contentEl = div.querySelector('.content');
        if (useMarkdown) {
            contentEl.innerHTML = renderMarkdown(content);
        } else {
            contentEl.textContent = content;
        }
        messagesDiv.appendChild(div);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
        return div;
    }

    function addToolDetails(parentDiv, toolName, toolArgs) {
        const details = document.createElement('details');
        details.className = 'tool-details';
        const summary = document.createElement('summary');
        summary.textContent = toolName;
        details.appendChild(summary);
        const body = document.createElement('div');
        body.className = 'tool-body';
        if (toolArgs && Object.keys(toolArgs).length > 0) {
            const argsDiv = document.createElement('div');
            argsDiv.className = 'tool-args';
            argsDiv.textContent = JSON.stringify(toolArgs, null, 2);
            body.appendChild(argsDiv);
        }
        details.appendChild(body);
        parentDiv.appendChild(details);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
        return details;
    }

    // --- Permission dialog ---
    function showPermissionDialog(data) {
        var info;
        try { info = JSON.parse(data.content); } catch (e) { info = data; }
        var requestId = info.request_id || '';
        var toolName = info.tool_name || 'unknown';
        var path = info.path || '';
        var toolArgs = info.tool_args || {};

        var overlay = document.createElement('div');
        overlay.className = 'permission-overlay';

        var dialog = document.createElement('div');
        dialog.className = 'permission-dialog';

        var title = document.createElement('div');
        title.className = 'permission-title';
        title.textContent = toolName === 'doom_loop'
            ? 'Repeated tool call detected'
            : 'Permission Required';
        dialog.appendChild(title);

        var desc = document.createElement('div');
        desc.className = 'permission-desc';
        if (toolName === 'doom_loop') {
            desc.textContent = 'The same tool call has been repeated 3 times with identical arguments. Continue?';
        } else {
            desc.innerHTML = '<strong>Tool:</strong> ' + toolName
                + (path && path !== '*' ? '<br><strong>Path:</strong> ' + path : '')
                + '<br><strong>Args:</strong> <code>' + JSON.stringify(toolArgs, null, 2) + '</code>';
        }
        dialog.appendChild(desc);

        var actions = document.createElement('div');
        actions.className = 'permission-actions';

        function makeBtn(label, reply, cls) {
            var btn = document.createElement('button');
            btn.className = 'btn ' + cls;
            btn.textContent = label;
            btn.addEventListener('click', function() {
                fetch('/api/permissions/' + requestId + '/reply', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({reply: reply})
                });
                overlay.remove();
            });
            return btn;
        }

        actions.appendChild(makeBtn('Allow once', 'once', 'btn-primary'));
        actions.appendChild(makeBtn('Allow always', 'always', 'btn-outline'));
        actions.appendChild(makeBtn('Reject', 'reject', 'btn-danger'));
        dialog.appendChild(actions);

        overlay.appendChild(dialog);
        document.body.appendChild(overlay);
    }

    // --- Question dialog ---
    function showQuestionDialog(data) {
        var info;
        try { info = JSON.parse(data.content); } catch (e) { info = data; }
        var requestId = info.request_id || '';
        var questionText = info.question || '';

        var overlay = document.createElement('div');
        overlay.className = 'permission-overlay';

        var dialog = document.createElement('div');
        dialog.className = 'permission-dialog';

        var title = document.createElement('div');
        title.className = 'permission-title';
        title.textContent = 'Question from Agent';
        dialog.appendChild(title);

        var desc = document.createElement('div');
        desc.className = 'permission-desc question-text';
        desc.textContent = questionText;
        dialog.appendChild(desc);

        var textarea = document.createElement('textarea');
        textarea.className = 'question-textarea';
        textarea.placeholder = 'Type your answer…';
        textarea.rows = 3;
        dialog.appendChild(textarea);

        var actions = document.createElement('div');
        actions.className = 'permission-actions';

        var submitBtn = document.createElement('button');
        submitBtn.className = 'btn btn-primary';
        submitBtn.textContent = 'Submit';
        submitBtn.addEventListener('click', function() {
            var answer = textarea.value.trim() || '(no answer)';
            fetch('/api/questions/' + requestId + '/reply', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({answer: answer})
            });
            overlay.remove();
        });

        var skipBtn = document.createElement('button');
        skipBtn.className = 'btn btn-outline';
        skipBtn.textContent = 'Skip';
        skipBtn.addEventListener('click', function() {
            fetch('/api/questions/' + requestId + '/reply', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({answer: '(no answer)'})
            });
            overlay.remove();
        });

        actions.appendChild(submitBtn);
        actions.appendChild(skipBtn);
        dialog.appendChild(actions);

        overlay.appendChild(dialog);
        document.body.appendChild(overlay);
        textarea.focus();
    }

    // --- Interrupt / button state ---
    let currentAbort = null;

    function showInterruptButton() {
        sendBtn.textContent = 'Stop';
        sendBtn.classList.remove('btn-primary');
        sendBtn.classList.add('btn-danger');
        sendBtn.disabled = false;
        sendBtn.removeEventListener('click', sendMessage);
        sendBtn.addEventListener('click', interruptGeneration);
    }

    function showSendButton() {
        sendBtn.textContent = 'Send';
        sendBtn.classList.remove('btn-danger');
        sendBtn.classList.add('btn-primary');
        sendBtn.disabled = false;
        sendBtn.removeEventListener('click', interruptGeneration);
        sendBtn.addEventListener('click', sendMessage);
    }

    async function interruptGeneration() {
        if (currentAbort) {
            currentAbort.abort();
            currentAbort = null;
        }
        try {
            await fetch('/api/sessions/' + sessionId + '/interrupt', {method: 'POST'});
        } catch (e) { /* ignore */ }
        showSendButton();
    }

    // --- Send message / stream ---
    async function sendMessage() {
        const text = input.value.trim();
        if (!text) return;

        // Handle ! bash commands
        if (text.startsWith('!')) {
            const cmd = text.substring(1).trim();
            if (cmd) {
                input.value = '';
                addMessage('user', text, false);
                const bashDiv = addMessage('system', 'Running...', false);
                bashDiv.querySelector('.content').className = 'content bash-output';
                try {
                    const res = await fetch('/api/bash', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({command: cmd})
                    });
                    const data = await res.json();
                    let output = data.stdout || '';
                    if (data.stderr) output += (output ? '\n' : '') + data.stderr;
                    if (data.returncode !== 0) output += '\n[exit code: ' + data.returncode + ']';
                    bashDiv.querySelector('.content').textContent = output || '(no output)';
                } catch (err) {
                    bashDiv.querySelector('.content').textContent = 'Error: ' + err.message;
                }
                input.focus();
                return;
            }
        }

        // Handle slash commands
        if (text.startsWith('/')) {
            const cmd = COMMANDS.find(c => c.name === text.split(' ')[0]);
            if (cmd) {
                await executeCommand(cmd.name);
                return;
            }
        }

        input.value = '';
        showInterruptButton();
        addMessage('user', text, false);

        let assistantDiv = null;
        let contentDiv = null;
        let rawText = '';
        let pendingTool = null;

        function ensureAssistantDiv() {
            if (!assistantDiv || assistantDiv.dataset.closed === '1') {
                assistantDiv = document.createElement('div');
                assistantDiv.className = 'message assistant streaming';
                assistantDiv.innerHTML = '<div class="role">assistant</div><div class="content"></div>';
                contentDiv = assistantDiv.querySelector('.content');
                rawText = '';
                messagesDiv.appendChild(assistantDiv);
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }
        }

        function finalizeAssistant() {
            if (assistantDiv && contentDiv && rawText) {
                contentDiv.innerHTML = renderMarkdown(rawText);
            }
            if (assistantDiv) {
                assistantDiv.classList.remove('streaming');
            }
        }

        try {
            currentAbort = new AbortController();
            const response = await fetch('/api/sessions/' + sessionId + '/messages', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({content: text}),
                signal: currentAbort.signal,
            });

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const {done, value} = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, {stream: true});
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';

                for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;
                    try {
                        const data = JSON.parse(line.slice(6));

                        if (data.type === 'text') {
                            ensureAssistantDiv();
                            rawText += data.content;
                            contentDiv.textContent = rawText;
                            messagesDiv.scrollTop = messagesDiv.scrollHeight;

                        } else if (data.type === 'tool_call') {
                            if (rawText && contentDiv) {
                                contentDiv.innerHTML = renderMarkdown(rawText);
                            }
                            ensureAssistantDiv();
                            pendingTool = addToolDetails(
                                assistantDiv,
                                data.tool_name,
                                data.tool_args
                            );
                            // Track file changes for sidebar
                            trackFileChange(data.tool_name, data.tool_args);

                        } else if (data.type === 'tool_result') {
                            if (pendingTool) {
                                const body = pendingTool.querySelector('.tool-body');
                                const resultDiv = document.createElement('div');
                                resultDiv.className = 'tool-result-text';
                                resultDiv.textContent = data.tool_result;
                                body.appendChild(resultDiv);
                                pendingTool = null;
                            }
                            if (assistantDiv) {
                                assistantDiv.classList.remove('streaming');
                                assistantDiv.dataset.closed = '1';
                            }

                        } else if (data.type === 'permission_request') {
                            showPermissionDialog(data);

                        } else if (data.type === 'question_request') {
                            showQuestionDialog(data);

                        } else if (data.type === 'error') {
                            const errDiv = addMessage('system', 'Error: ' + data.error, false);
                            errDiv.classList.add('error');

                        } else if (data.type === 'context_update' && data.context_info) {
                            updateContextBar(data.context_info);

                        } else if (data.done) {
                            finalizeAssistant();
                        }
                    } catch (e) { /* ignore parse errors */ }
                }
            }
        } catch (err) {
            if (err.name !== 'AbortError') {
                const errDiv = addMessage('system', 'Connection error: ' + err.message, false);
                errDiv.classList.add('error');
            }
        }

        finalizeAssistant();
        currentAbort = null;
        showSendButton();
        input.focus();
    }

    // --- @ file mention ---
    let fileMode = false;   // true when we're in @... completion
    let fileAtPos = -1;     // cursor position of the @ that started it
    let fileFetchTimer = null;

    function getFileMentionQuery() {
        const val = input.value;
        const cursor = input.selectionStart;
        // Walk back from cursor to find the @
        let i = cursor - 1;
        while (i >= 0 && val[i] !== '@' && val[i] !== ' ' && val[i] !== '\n') i--;
        if (i >= 0 && val[i] === '@') {
            fileAtPos = i;
            return val.substring(i + 1, cursor);
        }
        return null;
    }

    async function fetchFiles(query) {
        const res = await fetch('/api/files?q=' + encodeURIComponent(query) + '&limit=15');
        return await res.json();
    }

    function showFileBar(files) {
        if (files.length === 0) { hideCommandBar(); return; }
        cmdBar.innerHTML = '';
        files.forEach((f, i) => {
            const div = document.createElement('div');
            div.className = 'cmd-item' + (i === 0 ? ' active' : '');
            const icon = f.type === 'dir' ? '\uD83D\uDCC1' : '\uD83D\uDCC4';
            div.innerHTML = '<span class="cmd-name">' + icon + ' ' + f.path + '</span>';
            div.addEventListener('click', () => { insertFileMention(f.path); });
            cmdBar.appendChild(div);
        });
        cmdBar.style.display = 'block';
    }

    function insertFileMention(filePath) {
        const val = input.value;
        const cursor = input.selectionStart;
        // Replace from @ to cursor with the file path
        const before = val.substring(0, fileAtPos);
        const after = val.substring(cursor);
        input.value = before + '@' + filePath + ' ' + after;
        const newPos = fileAtPos + 1 + filePath.length + 1;
        input.selectionStart = input.selectionEnd = newPos;
        fileMode = false;
        fileAtPos = -1;
        hideCommandBar();
        input.focus();
    }

    function checkFileMention() {
        const query = getFileMentionQuery();
        if (query !== null) {
            fileMode = true;
            // Debounce the fetch
            clearTimeout(fileFetchTimer);
            fileFetchTimer = setTimeout(async () => {
                const files = await fetchFiles(query);
                if (fileMode) showFileBar(files);
            }, 150);
        } else {
            fileMode = false;
            fileAtPos = -1;
        }
    }

    // --- Input event handling ---
    input.addEventListener('input', () => {
        const val = input.value;

        // Check for / commands (only at start of input)
        if (val.startsWith('/') && !fileMode) {
            showCommandBar(val);
            return;
        }

        // Check for @ file mentions
        // Look back from cursor for an @
        const query = getFileMentionQuery();
        if (query !== null) {
            checkFileMention();
            return;
        }

        // Nothing active
        if (!fileMode) hideCommandBar();
    });

    input.addEventListener('keydown', (e) => {
        if (cmdBar.style.display === 'block') {
            if (e.key === 'ArrowDown') { e.preventDefault(); moveCommandSelection(1); return; }
            if (e.key === 'ArrowUp') { e.preventDefault(); moveCommandSelection(-1); return; }
            if (e.key === 'Tab' || (e.key === 'Enter' && !e.shiftKey)) {
                e.preventDefault();
                if (fileMode) {
                    // Pick the active file
                    const active = cmdBar.querySelector('.cmd-item.active .cmd-name');
                    if (active) {
                        // Strip the icon emoji prefix
                        const text = active.textContent.substring(3);
                        insertFileMention(text);
                    }
                } else {
                    const cmd = getActiveCommand();
                    if (cmd) executeCommand(cmd);
                }
                return;
            }
            if (e.key === 'Escape') {
                fileMode = false;
                fileAtPos = -1;
                hideCommandBar();
                return;
            }
        }
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    sendBtn.addEventListener('click', sendMessage);

    // --- Track file changes for right sidebar ---
    const _changedFiles = new Map(); // path -> {tool, action}

    function trackFileChange(toolName, toolArgs) {
        const filePath = toolArgs && (toolArgs.file_path || toolArgs.path || '');
        if (!filePath) return;
        const writeTools = ['write', 'edit', 'patch'];
        if (writeTools.includes(toolName)) {
            _changedFiles.set(filePath, {tool: toolName, action: 'modified'});
        } else if (toolName === 'read' || toolName === 'grep' || toolName === 'glob') {
            if (!_changedFiles.has(filePath)) {
                _changedFiles.set(filePath, {tool: toolName, action: 'read'});
            }
        }
        updateFilesPanel();
    }

    function updateFilesPanel() {
        const list = document.getElementById('files-changed-list');
        if (!list) return;
        if (_changedFiles.size === 0) {
            list.innerHTML = '<p class="empty-sidebar">No files changed yet.</p>';
            return;
        }
        list.innerHTML = '';
        for (const [path, info] of _changedFiles) {
            const div = document.createElement('div');
            div.className = 'file-change-item';
            const badge = info.action === 'modified' ? '<span class="file-badge modified">M</span>' : '<span class="file-badge read">R</span>';
            div.innerHTML = badge + '<span class="file-path">' + path + '</span>';
            list.appendChild(div);
        }
    }

    // Expose for sidebar
    window._openclose = window._openclose || {};
    window._openclose.changedFiles = _changedFiles;

    // Initialize context bar from server-rendered data
    if (typeof INITIAL_CONTEXT !== 'undefined') {
        updateContextBar(INITIAL_CONTEXT);
    }

    // Render markdown for existing messages loaded from DB
    document.querySelectorAll('.message.assistant .content').forEach(el => {
        const raw = el.textContent;
        if (raw) el.innerHTML = renderMarkdown(raw);
    });

    messagesDiv.scrollTop = messagesDiv.scrollHeight;
    input.focus();
}

// --- Sidebar logic (separate from chat) ---
function initSidebars(sessionId) {
    // Load session list into left sidebar
    async function loadSessionList() {
        const res = await fetch('/api/sessions');
        const sessions = await res.json();
        const list = document.getElementById('sidebar-session-list');
        list.innerHTML = '';
        sessions.forEach(s => {
            const item = document.createElement('div');
            item.className = 'sidebar-session-item' + (s.id === sessionId ? ' active' : '');
            item.dataset.sid = s.id;
            item.innerHTML = '<div class="sidebar-session-text">'
                + '<div class="sidebar-session-title">' + (s.title || 'Untitled') + '</div>'
                + '<div class="sidebar-session-meta">' + s.agent + '</div>'
                + '</div>'
                + '<button class="sidebar-session-delete" data-delete="' + s.id + '" title="Delete session">&times;</button>';
            list.appendChild(item);
        });
    }
    loadSessionList();

    // Delegated click handler for session list (navigation + delete)
    document.getElementById('sidebar-session-list').addEventListener('click', async (e) => {
        const delBtn = e.target.closest('[data-delete]');
        if (delBtn) {
            e.preventDefault();
            e.stopPropagation();
            const sid = delBtn.dataset.delete;
            if (!confirm('Delete this session?')) return;
            await fetch('/api/sessions/' + sid, {method: 'DELETE'});
            if (sid === sessionId) {
                // Fetch remaining sessions and navigate to the most recent one
                const res = await fetch('/api/sessions');
                const remaining = await res.json();
                if (remaining.length > 0) {
                    window.location.href = '/session/' + remaining[0].id;
                } else {
                    // No sessions left — create a new one
                    const newRes = await fetch('/api/sessions', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({title: ''})
                    });
                    const newSession = await newRes.json();
                    window.location.href = '/session/' + newSession.id;
                }
            } else {
                loadSessionList();
            }
            return;
        }
        const item = e.target.closest('.sidebar-session-item');
        if (item && item.dataset.sid) {
            window.location.href = '/session/' + item.dataset.sid;
        }
    });

    // New session button
    document.getElementById('sidebar-new-btn').addEventListener('click', async () => {
        const res = await fetch('/api/sessions', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({title: ''})
        });
        const data = await res.json();
        window.location.href = '/session/' + data.id;
    });

    // Delete all sessions button
    document.getElementById('sidebar-delete-all-btn').addEventListener('click', async () => {
        const res = await fetch('/api/sessions');
        const sessions = await res.json();
        if (sessions.length === 0) return;
        if (!confirm('Delete all ' + sessions.length + ' session(s)?')) return;
        for (const s of sessions) {
            await fetch('/api/sessions/' + s.id, {method: 'DELETE'});
        }
        const newRes = await fetch('/api/sessions', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({title: ''})
        });
        const newSession = await newRes.json();
        window.location.href = '/session/' + newSession.id;
    });

    // Sidebar toggle buttons
    document.getElementById('toggle-left').addEventListener('click', () => {
        document.getElementById('sidebar-left').classList.toggle('collapsed');
    });
    document.getElementById('toggle-right').addEventListener('click', () => {
        document.getElementById('sidebar-right').classList.toggle('collapsed');
    });

    // Tab switching
    document.querySelectorAll('.sidebar-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.sidebar-tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.sidebar-panel').forEach(p => p.style.display = 'none');
            tab.classList.add('active');
            document.getElementById('panel-' + tab.dataset.tab).style.display = '';
        });
    });

    // Info actions
    document.getElementById('info-rename-btn').addEventListener('click', async () => {
        const title = prompt('New session title:');
        if (title) {
            await fetch('/api/sessions/' + sessionId + '/rename', {
                method: 'PATCH',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({title: title})
            });
            document.getElementById('session-title').textContent = title;
            loadSessionList();
        }
    });

    document.getElementById('info-export-btn').addEventListener('click', async () => {
        const res = await fetch('/api/sessions/' + sessionId + '/export');
        const data = await res.json();
        const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'session-' + sessionId + '.json';
        a.click();
        URL.revokeObjectURL(url);
    });

    document.getElementById('info-compact-btn').addEventListener('click', async () => {
        const res = await fetch('/api/sessions/' + sessionId + '/compact', {method: 'POST'});
        const data = await res.json();
        alert(data.compacted ? 'Context compacted.' : 'No compaction needed.');
    });

    // Skip permissions toggle button
    var skipBtn = document.getElementById('info-skip-btn');
    if (skipBtn) {
        // Load initial state
        fetch('/api/sessions/' + sessionId + '/skip-permissions')
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.skip_all) {
                    skipBtn.textContent = 'Skip Perms: ON';
                    skipBtn.classList.add('btn-active');
                }
            });
        skipBtn.addEventListener('click', async () => {
            const res = await fetch('/api/sessions/' + sessionId + '/skip-permissions', {method: 'POST'});
            const data = await res.json();
            skipBtn.textContent = data.skip_all ? 'Skip Perms: ON' : 'Skip Perms: OFF';
            if (data.skip_all) { skipBtn.classList.add('btn-active'); } else { skipBtn.classList.remove('btn-active'); }
        });
    }
}
