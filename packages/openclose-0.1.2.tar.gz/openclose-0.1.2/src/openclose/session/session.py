"""Session CRUD operations."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone

from sqlmodel import select, col

from openclose.storage.db import Database
from openclose.storage.schema import Session, Message, MessagePart
from openclose.id import new_session_id, new_message_id, new_part_id
from openclose.session.message import MessageRole, MessagePartType
from openclose.log import get_logger

log = get_logger(__name__)


class SessionManager:
    """Manages session lifecycle and message persistence."""

    def __init__(self, db: Database) -> None:
        self._db = db

    def create_session(
        self,
        title: str = "",
        agent: str = "build",
        model: str = "",
        project_id: str = "",
    ) -> Session:
        """Create a new session."""
        session = Session(
            id=new_session_id(),
            title=title,
            agent=agent,
            model=model,
            project_id=project_id,
        )
        with self._db.get_session() as db:
            db.add(session)
            db.commit()
            db.refresh(session)
        log.info("Created session %s", session.id)
        return session

    def fork_session(
        self,
        source_session_id: str,
        agent: str = "build",
    ) -> Session | None:
        """Fork a session: create a new session with a different agent,
        copying all messages and message parts from the source."""
        with self._db.get_session() as db:
            source = db.get(Session, source_session_id)
            if source is None:
                return None

            new_session = Session(
                id=new_session_id(),
                title=source.title,
                agent=agent,
                model=source.model,
                project_id=source.project_id,
            )
            db.add(new_session)
            db.flush()

            # Copy messages
            old_messages = list(
                db.exec(
                    select(Message)
                    .where(Message.session_id == source_session_id)
                    .order_by(col(Message.created_at))
                ).all()
            )
            msg_id_map: dict[str, str] = {}
            for old_msg in old_messages:
                new_mid = new_message_id()
                msg_id_map[old_msg.id] = new_mid
                db.add(Message(
                    id=new_mid,
                    session_id=new_session.id,
                    role=old_msg.role,
                    content=old_msg.content,
                    model=old_msg.model,
                    token_count=old_msg.token_count,
                ))

            # Copy message parts
            if msg_id_map:
                old_parts = list(
                    db.exec(
                        select(MessagePart)
                        .where(col(MessagePart.message_id).in_(list(msg_id_map.keys())))
                        .order_by(col(MessagePart.created_at))
                    ).all()
                )
                for old_part in old_parts:
                    db.add(MessagePart(
                        id=new_part_id(),
                        message_id=msg_id_map[old_part.message_id],
                        part_type=old_part.part_type,
                        content=old_part.content,
                        tool_name=old_part.tool_name,
                        tool_call_id=old_part.tool_call_id,
                        metadata_json=old_part.metadata_json,
                    ))

            db.commit()
            db.refresh(new_session)
        log.info("Forked session %s → %s (agent=%s)", source_session_id, new_session.id, agent)
        return new_session

    def get_session(self, session_id: str) -> Session | None:
        """Get a session by ID."""
        with self._db.get_session() as db:
            return db.get(Session, session_id)

    def list_sessions(self, include_archived: bool = False) -> list[Session]:
        """List all sessions, optionally including archived ones."""
        with self._db.get_session() as db:
            stmt = select(Session).order_by(col(Session.updated_at).desc())
            if not include_archived:
                stmt = stmt.where(Session.archived == False)  # noqa: E712
            return list(db.exec(stmt).all())

    def archive_session(self, session_id: str) -> bool:
        """Archive a session."""
        with self._db.get_session() as db:
            session = db.get(Session, session_id)
            if session is None:
                return False
            session.archived = True
            session.updated_at = datetime.now(timezone.utc)
            db.add(session)
            db.commit()
        return True

    def update_title(self, session_id: str, title: str) -> bool:
        """Update session title."""
        with self._db.get_session() as db:
            session = db.get(Session, session_id)
            if session is None:
                return False
            session.title = title
            session.updated_at = datetime.now(timezone.utc)
            db.add(session)
            db.commit()
        return True

    def add_message(
        self,
        session_id: str,
        role: MessageRole,
        content: str = "",
        model: str = "",
        token_count: int = 0,
    ) -> Message:
        """Add a message to a session."""
        msg = Message(
            id=new_message_id(),
            session_id=session_id,
            role=role.value,
            content=content,
            model=model,
            token_count=token_count,
        )
        with self._db.get_session() as db:
            db.add(msg)
            # Update session timestamp
            session = db.get(Session, session_id)
            if session:
                session.updated_at = datetime.now(timezone.utc)
                db.add(session)
            db.commit()
            db.refresh(msg)
        return msg

    def add_message_part(
        self,
        message_id: str,
        part_type: MessagePartType,
        content: str = "",
        tool_name: str | None = None,
        tool_call_id: str | None = None,
        metadata_json: str = "{}",
    ) -> MessagePart:
        """Add a part to a message."""
        part = MessagePart(
            id=new_part_id(),
            message_id=message_id,
            part_type=part_type.value,
            content=content,
            tool_name=tool_name,
            tool_call_id=tool_call_id,
            metadata_json=metadata_json,
        )
        with self._db.get_session() as db:
            db.add(part)
            db.commit()
            db.refresh(part)
        return part

    def get_messages(self, session_id: str) -> list[Message]:
        """Get all messages for a session, ordered by creation time."""
        with self._db.get_session() as db:
            return list(
                db.exec(
                    select(Message)
                    .where(Message.session_id == session_id)
                    .order_by(col(Message.created_at))
                ).all()
            )

    def get_messages_with_parts(
        self, session_id: str
    ) -> list[tuple[Message, list[MessagePart]]]:
        """Get all messages for a session with their parts (two queries, no N+1)."""
        with self._db.get_session() as db:
            messages = list(
                db.exec(
                    select(Message)
                    .where(Message.session_id == session_id)
                    .order_by(col(Message.created_at))
                ).all()
            )
            if not messages:
                return []
            msg_ids = [m.id for m in messages]
            parts = list(
                db.exec(
                    select(MessagePart)
                    .where(col(MessagePart.message_id).in_(msg_ids))
                    .order_by(col(MessagePart.created_at))
                ).all()
            )
        parts_by_msg: defaultdict[str, list[MessagePart]] = defaultdict(list)
        for p in parts:
            parts_by_msg[p.message_id].append(p)
        return [(m, parts_by_msg.get(m.id, [])) for m in messages]

    def get_message_parts(self, message_id: str) -> list[MessagePart]:
        """Get all parts for a message."""
        with self._db.get_session() as db:
            return list(
                db.exec(
                    select(MessagePart)
                    .where(MessagePart.message_id == message_id)
                    .order_by(col(MessagePart.created_at))
                ).all()
            )

    def get_empty_session(self, agent: str = "build") -> Session | None:
        """Find the most recent non-archived session with zero messages."""
        with self._db.get_session() as db:
            stmt = (
                select(Session)
                .where(
                    Session.agent == agent,
                    Session.archived == False,  # noqa: E712
                    ~select(Message.id)
                    .where(Message.session_id == Session.id)
                    .correlate(Session)
                    .exists(),
                )
                .order_by(col(Session.updated_at).desc())
                .limit(1)
            )
            return db.exec(stmt).first()

    def cleanup_empty_sessions(
        self, keep_session_id: str | None = None
    ) -> int:
        """Delete all empty sessions (0 messages), optionally keeping one.

        Returns the number of deleted sessions.
        """
        with self._db.get_session() as db:
            stmt = select(Session).where(
                Session.archived == False,  # noqa: E712
                ~select(Message.id)
                .where(Message.session_id == Session.id)
                .correlate(Session)
                .exists(),
            )
            if keep_session_id is not None:
                stmt = stmt.where(Session.id != keep_session_id)
            empties = list(db.exec(stmt).all())
            for s in empties:
                db.delete(s)
            if empties:
                db.commit()
            count = len(empties)
        if count:
            log.info("Cleaned up %d empty session(s)", count)
        return count

    def delete_session(self, session_id: str) -> bool:
        """Delete a session and all its messages."""
        with self._db.get_session() as db:
            # Delete parts
            messages = db.exec(
                select(Message).where(Message.session_id == session_id)
            ).all()
            for msg in messages:
                parts = db.exec(
                    select(MessagePart).where(MessagePart.message_id == msg.id)
                ).all()
                for part in parts:
                    db.delete(part)
                db.delete(msg)

            session = db.get(Session, session_id)
            if session is None:
                return False
            db.delete(session)
            db.commit()
        return True
