"""LLM request debug dumper — writes every LLM payload to llm_debug.jsonl.

Activated by setting OPENCLOSE_DEBUG_LLM=1.  To remove this feature:
1. Delete this file.
2. Remove the DEBUG_LLM line from flag.py.
3. Remove the dump_llm_request() calls (grep for 'dump_llm_request').
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from openclose import flag


def dump_llm_request(
    *,
    step: int,
    source: str,
    model: str,
    temperature: float,
    messages: list[Any],
    tools: list[Any] | None,
    project_dir: str,
) -> None:
    """Append one JSON line to ``<project_dir>/llm_debug.jsonl``.

    No-op when ``flag.DEBUG_LLM`` is ``False``.
    """
    if not flag.DEBUG_LLM:
        return

    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "step": step,
        "source": source,
        "model": model,
        "temperature": temperature,
        "messages": messages,
        "tools": tools,
    }

    path = Path(project_dir) / "llm_debug.jsonl"
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, default=str) + "\n")
