"""Linter integration."""

from openclose.lint.linter import LinterRegistry, Linter, get_linter_registry

__all__ = ["LinterRegistry", "Linter", "get_linter_registry"]
