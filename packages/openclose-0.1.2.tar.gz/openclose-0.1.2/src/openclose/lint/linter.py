"""Linter registry and execution."""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from openclose.util.process import run
from openclose.log import get_logger

log = get_logger(__name__)


@dataclass
class LintResult:
    """Result of running a linter."""

    linter_name: str
    output: str
    ok: bool


@dataclass
class Linter:
    """A linter configuration."""

    name: str
    command: list[str]
    extensions: list[str]

    def supports(self, path: Path) -> bool:
        return path.suffix.lower() in self.extensions

    def is_available(self) -> bool:
        return shutil.which(self.command[0]) is not None


_BUILTIN_LINTERS = [
    Linter("ruff-check", ["ruff", "check"], [".py"]),
    Linter("mypy", ["mypy"], [".py"]),
    Linter("eslint", ["eslint"], [".js", ".jsx", ".ts", ".tsx"]),
    Linter("golangci-lint", ["golangci-lint", "run"], [".go"]),
    Linter("clippy", ["cargo", "clippy"], [".rs"]),
    Linter("clang-tidy", ["clang-tidy"], [".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".hxx"]),
    Linter("cppcheck", ["cppcheck", "--enable=warning,style"], [".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".hxx"]),
]


class LinterRegistry:
    """Registry and executor for linters."""

    def __init__(self) -> None:
        self._linters: list[Linter] = list(_BUILTIN_LINTERS)

    def add(self, linter: Linter) -> None:
        self._linters.insert(0, linter)

    def get_linter(self, path: Path) -> Linter | None:
        for linter in self._linters:
            if linter.supports(path) and linter.is_available():
                return linter
        return None

    async def lint_file(self, path: Path) -> LintResult | None:
        """Run linter on a file. Returns None if no linter available."""
        linter = self.get_linter(path)
        if linter is None:
            return None

        result = await run(*linter.command, str(path), timeout=60.0)
        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr

        return LintResult(
            linter_name=linter.name,
            output=output.strip(),
            ok=result.ok,
        )

    async def lint_directory(self, directory: Path) -> list[LintResult]:
        """Run available linters on a directory."""
        results: list[LintResult] = []
        seen_linters: set[str] = set()

        for linter in self._linters:
            if linter.name in seen_linters or not linter.is_available():
                continue

            result = await run(*linter.command, str(directory), timeout=120.0)
            output = result.stdout
            if result.stderr:
                output += "\n" + result.stderr

            results.append(LintResult(
                linter_name=linter.name,
                output=output.strip(),
                ok=result.ok,
            ))
            seen_linters.add(linter.name)

        return results


_registry: LinterRegistry | None = None


def get_linter_registry() -> LinterRegistry:
    global _registry
    if _registry is None:
        _registry = LinterRegistry()
    return _registry
