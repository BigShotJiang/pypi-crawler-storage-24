"""Tests for the agent loop."""

from __future__ import annotations

from openclose.agent.loop import ToolCall, StreamEvent


def test_tool_call_arguments_parsing() -> None:
    """ToolCall should parse JSON arguments."""
    tc = ToolCall()
    tc.id = "call_1"
    tc.name = "read"
    tc.append_arguments('{"path": "/tmp/test.py"}')
    assert tc.arguments == {"path": "/tmp/test.py"}
    assert tc.arguments_raw == '{"path": "/tmp/test.py"}'


def test_tool_call_invalid_json() -> None:
    """ToolCall should return empty dict for invalid JSON."""
    tc = ToolCall()
    tc.append_arguments("not json")
    assert tc.arguments == {}


def test_tool_call_empty() -> None:
    """ToolCall with no arguments should return empty dict."""
    tc = ToolCall()
    assert tc.arguments == {}


def test_stream_event_types() -> None:
    """StreamEvent should hold correct data."""
    text_event = StreamEvent("text", content="hello")
    assert text_event.type == "text"
    assert text_event.content == "hello"
    assert not text_event.done

    done_event = StreamEvent("done", done=True)
    assert done_event.done

    error_event = StreamEvent("error", error="fail")
    assert error_event.error == "fail"

    tc = ToolCall()
    tc.name = "bash"
    tool_event = StreamEvent("tool_call", tool_call=tc)
    assert tool_event.tool_call is not None
    assert tool_event.tool_call.name == "bash"
