"""Tests for the linter system."""

from __future__ import annotations

from pathlib import Path

from openclose.lint.linter import LinterRegistry, Linter


def test_linter_supports() -> None:
    linter = Linter("ruff", ["ruff", "check"], [".py"])
    assert linter.supports(Path("code.py"))
    assert not linter.supports(Path("code.js"))


def test_registry_get_linter() -> None:
    registry = LinterRegistry()
    linter = registry.get_linter(Path("test.py"))
    # ruff may or may not be installed
    if linter is not None:
        assert linter.name == "ruff-check"


def test_registry_no_linter_for_unknown() -> None:
    registry = LinterRegistry()
    linter = registry.get_linter(Path("test.xyz"))
    assert linter is None
