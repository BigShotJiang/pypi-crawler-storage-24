"""Extended linter tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from openclose.lint.linter import LinterRegistry, Linter, LintResult


@pytest.mark.asyncio
async def test_lint_file_python(tmp_path: Path) -> None:
    """Should lint a Python file if ruff is available."""
    f = tmp_path / "code.py"
    f.write_text("import os\n")  # unused import
    registry = LinterRegistry()
    result = await registry.lint_file(f)
    if result is not None:
        assert isinstance(result, LintResult)
        assert result.linter_name == "ruff-check"


@pytest.mark.asyncio
async def test_lint_file_no_linter(tmp_path: Path) -> None:
    """Should return None for unknown extensions."""
    f = tmp_path / "data.xyz"
    f.write_text("data")
    registry = LinterRegistry()
    result = await registry.lint_file(f)
    assert result is None


@pytest.mark.asyncio
async def test_lint_directory(tmp_path: Path) -> None:
    """Should run available linters on a directory."""
    (tmp_path / "code.py").write_text("x = 1\n")
    registry = LinterRegistry()
    results = await registry.lint_directory(tmp_path)
    # May have results if ruff is installed
    assert isinstance(results, list)


def test_linter_add_custom() -> None:
    registry = LinterRegistry()
    custom = Linter("custom", ["custom-lint"], [".cst"])
    registry.add(custom)
    linter = registry.get_linter(Path("file.cst"))
    # Won't be available (no binary), but lookup should work
    assert linter is None or linter.name == "custom"
