"""Extended route tests for coverage of server/routes.py."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from openclose.server.app import create_app
from openclose.config.config import load_config


@pytest.fixture()
def client(tmp_path: object) -> TestClient:
    load_config()
    app = create_app()
    return TestClient(app)


def _create_session(client: TestClient, title: str = "Test") -> str:
    resp = client.post("/api/sessions", json={"title": title, "agent": "build"})
    result: str = resp.json()["id"]
    return result


# ── search files ────────────────────────────────────────────────────────────

def test_search_files_api(client: TestClient) -> None:
    resp = client.get("/api/files?q=&limit=5")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)


def test_search_files_with_query(client: TestClient) -> None:
    resp = client.get("/api/files?q=py&limit=3")
    assert resp.status_code == 200


# ── bash ────────────────────────────────────────────────────────────────────

def test_run_bash(client: TestClient) -> None:
    resp = client.post("/api/bash", json={"command": "echo hello"})
    assert resp.status_code == 200
    data = resp.json()
    assert "stdout" in data
    assert "hello" in data["stdout"]
    assert "returncode" in data


# ── interrupt ───────────────────────────────────────────────────────────────

def test_interrupt_session(client: TestClient) -> None:
    sid = _create_session(client)
    resp = client.post(f"/api/sessions/{sid}/interrupt")
    assert resp.status_code == 200
    data = resp.json()
    assert "ok" in data


# ── permissions ─────────────────────────────────────────────────────────────

def test_permission_reply_invalid(client: TestClient) -> None:
    resp = client.post("/api/permissions/fake-id/reply", json={"reply": "invalid"})
    assert resp.status_code == 400


def test_permission_reply_not_found(client: TestClient) -> None:
    resp = client.post("/api/permissions/fake-id/reply", json={"reply": "once"})
    assert resp.status_code == 404


def test_toggle_skip_permissions(client: TestClient) -> None:
    sid = _create_session(client)
    resp = client.post(f"/api/sessions/{sid}/skip-permissions")
    assert resp.status_code == 200
    data = resp.json()
    assert "skip_all" in data


def test_get_skip_permissions(client: TestClient) -> None:
    sid = _create_session(client)
    resp = client.get(f"/api/sessions/{sid}/skip-permissions")
    assert resp.status_code == 200
    assert "skip_all" in resp.json()


# ── question reply ──────────────────────────────────────────────────────────

def test_question_reply_not_found(client: TestClient) -> None:
    resp = client.post("/api/questions/fake-id/reply", json={"answer": "yes"})
    assert resp.status_code == 404


# ── rename session ──────────────────────────────────────────────────────────

def test_rename_session(client: TestClient) -> None:
    sid = _create_session(client, "Old Name")
    resp = client.patch(f"/api/sessions/{sid}/rename", json={"title": "New Name"})
    assert resp.status_code == 200
    assert resp.json()["ok"] is True
    assert resp.json()["title"] == "New Name"


# ── fork session ────────────────────────────────────────────────────────────

def test_fork_session(client: TestClient) -> None:
    sid = _create_session(client, "Original")
    resp = client.post(f"/api/sessions/{sid}/fork", json={"agent": "build"})
    assert resp.status_code == 200
    data = resp.json()
    assert "id" in data
    assert data["id"] != sid


def test_fork_session_not_found(client: TestClient) -> None:
    resp = client.post("/api/sessions/nonexistent/fork", json={"agent": "build"})
    assert resp.status_code == 404


# ── undo message ────────────────────────────────────────────────────────────

def test_undo_message(client: TestClient) -> None:
    sid = _create_session(client)
    # Add messages directly via session manager
    from openclose.storage.db import get_db
    from openclose.session.session import SessionManager
    from openclose.session.message import MessageRole

    db = get_db()
    mgr = SessionManager(db)
    mgr.add_message(sid, MessageRole.USER, content="hello")
    mgr.add_message(sid, MessageRole.ASSISTANT, content="hi")

    resp = client.post(f"/api/sessions/{sid}/undo")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["removed"] == 2


def test_undo_message_empty(client: TestClient) -> None:
    sid = _create_session(client)
    resp = client.post(f"/api/sessions/{sid}/undo")
    assert resp.status_code == 200
    assert resp.json()["removed"] == 0


# ── export session ──────────────────────────────────────────────────────────

def test_export_session(client: TestClient) -> None:
    sid = _create_session(client, "Export Test")
    resp = client.get(f"/api/sessions/{sid}/export")
    assert resp.status_code == 200
    data = resp.json()
    assert data["session"]["id"] == sid
    assert data["session"]["title"] == "Export Test"
    assert isinstance(data["messages"], list)


def test_export_session_not_found(client: TestClient) -> None:
    resp = client.get("/api/sessions/nonexistent/export")
    assert resp.status_code == 404


# ── compact session ─────────────────────────────────────────────────────────

def test_compact_session(client: TestClient) -> None:
    sid = _create_session(client)
    resp = client.post(f"/api/sessions/{sid}/compact")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert "compacted" in data


# ── list agents ─────────────────────────────────────────────────────────────

def test_list_agents(client: TestClient) -> None:
    resp = client.get("/api/agents")
    assert resp.status_code == 200
    agents = resp.json()
    assert isinstance(agents, list)
    assert any(a["name"] for a in agents)
