"""Tests for the provider system."""

from __future__ import annotations

import os

from openclose.provider.auth import load_api_key
from openclose.provider.models import ModelInfo, ModelRegistry
from openclose.provider.provider import Provider


def test_load_api_key_from_env() -> None:
    """Should load API key from environment."""
    os.environ["OPENCLOSE_API_KEY"] = "test-key-123"
    try:
        key = load_api_key()
        assert key == "test-key-123"
    finally:
        del os.environ["OPENCLOSE_API_KEY"]


def test_load_api_key_fallback_openai() -> None:
    """Should fall back to OPENAI_API_KEY."""
    # Clear OPENCLOSE_API_KEY if set
    os.environ.pop("OPENCLOSE_API_KEY", None)
    os.environ["OPENAI_API_KEY"] = "openai-key-456"
    try:
        key = load_api_key()
        assert key == "openai-key-456"
    finally:
        del os.environ["OPENAI_API_KEY"]


def test_provider_creation() -> None:
    """Provider should initialize with given params."""
    provider = Provider(
        base_url="http://localhost:8080/v1",
        api_key="test-key",
        provider_name="test",
    )
    assert provider.client is not None
    assert provider.client.base_url == "http://localhost:8080/v1/"


def test_model_registry() -> None:
    """ModelRegistry should register and retrieve models."""
    registry = ModelRegistry()
    model = ModelInfo(id="test-model", name="Test Model", context_window=32_000)
    registry.register(model)

    assert registry.get("test-model") is model
    assert registry.get("nonexistent") is None
    assert len(registry.list_models()) == 1


def test_model_registry_get_or_default() -> None:
    """get_or_default should create a default entry for unknown models."""
    registry = ModelRegistry()
    model = registry.get_or_default("unknown-model")
    assert model.id == "unknown-model"
    assert model.context_window == 128_000  # default
