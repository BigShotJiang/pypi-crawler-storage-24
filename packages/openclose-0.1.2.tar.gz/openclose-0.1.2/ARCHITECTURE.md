# Architecture — OpenClose

## Overview

OpenClose is a local-first Python AI coding assistant that uses OpenAI-compatible APIs (vLLM, llama.cpp, Ollama, OpenAI). All data stays local in SQLite. The UI is a simple HTML interface served by FastAPI.

## Package Structure

```
src/openclose/
├── __init__.py          # Version
├── __main__.py          # python -m openclose entry
├── id.py                # ULID-based ID generation
├── flag.py              # Feature flags from environment
├── log.py               # Structured logging (rich)
│
├── config/              # Multi-layer config (TOML + env + defaults)
│   ├── config.py        # Load/merge/reload
│   ├── paths.py         # Platform-specific directories
│   ├── schema.py        # Pydantic v2 settings models
│   └── agents.py        # Agent definitions + inheritance resolution
│
├── storage/             # SQLite persistence
│   ├── db.py            # Engine + Database class
│   ├── schema.py        # SQLModel tables (Session, Message, MessagePart, Project)
│   └── migrations.py    # Schema versioning
│
├── bus/                 # Async event bus (pub/sub)
│   └── bus.py
│
├── provider/            # OpenAI-compatible LLM provider
│   ├── provider.py      # AsyncOpenAI wrapper, streaming
│   ├── models.py        # Model registry
│   └── auth.py          # API key resolution
│
├── agent/               # Agent definitions and orchestration
│   ├── agent.py         # Build/Plan/General agents, custom agents
│   ├── prompt.py        # System prompt assembly
│   └── loop.py          # Main agent loop (stream → tool calls → repeat)
│
├── session/             # Conversation management
│   ├── session.py       # CRUD operations
│   ├── message.py       # Role/PartType enums
│   ├── processor.py     # Orchestrates agent loop + persistence
│   ├── compaction.py    # Context window management
│   ├── prompt.py        # Message history builder
│   └── cancel.py        # Session cancellation
│
├── tool/                # Tool system
│   ├── tool.py          # Tool base class, OpenAI schema generation
│   ├── registry.py      # Tool registry + executor
│   ├── truncation.py    # Output truncation
│   └── tools/           # Built-in tools (13)
│       ├── read.py, write.py, edit.py   # File operations
│       ├── glob.py, grep.py, ls.py      # Search/listing
│       ├── bash.py                       # Shell execution
│       ├── patch.py                      # Unified diff application
│       ├── webfetch.py                   # HTTP fetch
│       ├── todo.py                       # Todo list
│       ├── question.py                   # User clarification
│       ├── question_broker.py            # Async question broker
│       ├── lint.py                       # Lint tool
│       └── multiedit.py                  # Multi-file edits
│
├── permission/          # Tool access control
│   ├── permission.py    # Evaluation engine
│   ├── rules.py         # Allow/deny/ask rules
│   ├── schema.py        # Request/response types
│   ├── broker.py        # Async permission request broker
│   └── extract.py       # Path extraction + sandbox checking
│
├── file/                # File system utilities
│   ├── binary.py        # Binary file detection
│   ├── ignore.py        # .gitignore pattern handling
│   ├── diff.py          # Change tracking
│   └── watcher.py       # File watching (watchfiles)
│
├── format/              # Auto-formatters (ruff, black, gofmt, etc.)
│   └── formatter.py
│
├── lint/                # Linter integration (ruff, mypy, eslint, etc.)
│   └── linter.py
│
├── project/             # Project/VCS management
│   ├── project.py       # Detection and metadata
│   ├── worktree.py      # Git worktree management
│   └── snapshot.py      # Git GC and snapshots
│
├── patch/               # Unified diff engine
│   └── patch.py
│
├── scheduler/           # Background task scheduling
│   └── scheduler.py
│
├── server/              # FastAPI + HTML UI
│   ├── app.py           # FastAPI app creation
│   ├── routes.py        # API + HTML routes
│   ├── sse.py           # Server-Sent Events streaming
│   └── templates/       # Jinja2 HTML templates + static assets
│
├── cli/                 # Command-line interface
│   └── cli.py           # serve, run -p, sessions commands
│
└── util/                # Shared utilities
    ├── process.py       # Async subprocess
    ├── git.py           # Git command wrapper
    └── fs.py            # File system helpers
```

## Key Design Decisions

### 1. OpenAI-compatible API only
**Decision:** Use the `openai` Python SDK targeting any OpenAI-compatible endpoint.
**Why:** Covers vLLM, llama.cpp, Ollama, and OpenAI with a single client. No need for 75+ provider adapters.

### 2. Local-only, no cloud
**Decision:** All data in local SQLite. No sharing, no remote auth, no cloud infra.
**Why:** User requirement for data sovereignty and simplicity.

### 3. HTML UI via FastAPI (not TUI)
**Decision:** Replace the original Bubble Tea TUI with a simple HTML UI served by FastAPI + Jinja2 + vanilla JS.
**Why:** Easier to customize and modify than a terminal UI framework. SSE provides real-time streaming.

### 4. Synchronous SQLite via SQLModel
**Decision:** Use SQLModel (SQLAlchemy under the hood) with synchronous access, not async.
**Why:** SQLite is inherently single-writer. The overhead of async wrappers adds complexity without benefit for local-only usage. The main async work is in LLM streaming and tool execution.

### 5. dict[str, Any] for LLM messages
**Decision:** Use plain dicts internally for message passing to/from the LLM, not OpenAI typed dicts.
**Why:** The OpenAI type system for `ChatCompletionMessageParam` is a complex union that creates unnecessary friction with mypy. We cast at the boundary when calling the API.

### 6. Tool system with function callbacks
**Decision:** Tools are defined as `Tool` objects with `ToolParameter` metadata and an async execute function.
**Why:** Simple, composable, and generates OpenAI function-calling schemas automatically. No metaclass magic.

### 7. Permission engine with last-match-wins
**Decision:** Permission rules are evaluated in order; last matching rule determines the action.
**Why:** Matches the OpenCode original and allows general rules early with specific overrides later.

### 8. Agent loop as iterator
**Decision:** `AgentLoop.run()` is an async iterator yielding `StreamEvent` objects.
**Why:** Enables both SSE streaming (server) and direct consumption (CLI). The caller decides how to handle events.

## Data Flow

```
User Input
  → CLI (-p flag) or HTML UI (POST /api/sessions/{id}/messages)
    → SessionProcessor
      → Persists user message to SQLite
      → Creates AgentLoop with tool schemas
      → AgentLoop streams from Provider (OpenAI-compatible)
        → Text chunks → StreamEvent("text")
        → Tool calls → ToolRegistry.execute() → StreamEvent("tool_result")
        → Loop continues until done or max_steps
      → Persists assistant response to SQLite
    → Response streamed via SSE (server) or printed (CLI)
```

## Configuration Priority

1. Environment variables (`OPENCLOSE_*`)
2. Project config (`.openclose/config.toml`)
3. User config (`~/.config/openclose/config.toml`)
4. Defaults (Pydantic model defaults)

## Dependencies

| Package | Purpose |
|---|---|
| pydantic / pydantic-settings | Config and data models |
| sqlmodel | SQLite ORM |
| openai | LLM API client |
| tiktoken | Token counting |
| fastapi / uvicorn / jinja2 | HTML UI server |
| sse-starlette | Server-Sent Events |
| httpx | HTTP client (webfetch tool) |
| beautifulsoup4 | HTML parsing (webfetch tool) |
| rich | Terminal output and logging |
| watchfiles | File system monitoring |
| pathspec | Gitignore pattern matching |
| python-ulid | ID generation |
| aiosqlite | Async SQLite adapter |
| aiofiles | Async file I/O |
