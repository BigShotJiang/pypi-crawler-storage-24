# Guide de personnalisation des agents

## Vue d'ensemble

OpenClose utilise des sections `[[agents]]` dans `config.toml` pour definir, personnaliser et etendre tous les agents, y compris ceux integres par defaut (`build`, `plan`). Cela controle :

- Le modele utilise par chaque agent
- Le prompt systeme transmis a l'agent
- Les outils visibles et appelables par l'agent
- L'heritage entre agents (creer des variantes sans dupliquer la configuration)
- Les traits semantiques qui pilotent le comportement a l'execution

## Agents par defaut

En l'absence de sections `[[agents]]`, deux agents sont disponibles :

| Agent | Mode | Description | Restrictions d'outils |
|-------|------|-------------|----------------------|
| `build` | primary | Acces complet aux outils pour ecriture et execution de code | Aucune |
| `plan` | primary | Analyse en lecture seule | Refuses : write, edit, bash, patch |

Chacun de ces agents peut etre redefini dans votre `config.toml`.

## Format de configuration

Les agents sont definis comme sections `[[agents]]` dans `config.toml` :

```toml
[[agents]]
name = "build"
description = "Agent principal de developpement"
model = "qwen3-30b-a3b"
temperature = 0.0
max_steps = 100
```

### Champs disponibles

| Champ | Type | Defaut | Description |
|-------|------|--------|-------------|
| `name` | string | *(requis)* | Nom unique de l'agent |
| `description` | string | `""` | Description courte du role de l'agent |
| `model` | string | `""` | Identifiant du modele. Vide = detection automatique depuis le fournisseur |
| `temperature` | float | `0.0` | Temperature d'echantillonnage (0.0–2.0) |
| `max_steps` | int | `100` | Nombre maximum d'iterations de la boucle d'appels d'outils (doit etre > 0) |
| `mode` | string | `"primary"` | Seul `"primary"` est actuellement supporte |
| `extends` | string | `""` | Nom d'un agent parent dont heriter |
| `system_prompt` | string | `""` | Prompt systeme en ligne |
| `traits` | liste de strings | `[]` | Indicateurs de comportement semantique (ex. `["readonly"]`) |
| `allowed_tools` | liste de strings | `[]` | Liste blanche : si non vide, seuls ces outils sont accessibles |
| `denied_tools` | liste de strings | `[]` | Liste noire : ces outils sont masques a l'agent |

## Exemples de demarrage rapide

### 1. Changer le modele de l'agent build

```toml
# ~/.config/openclose/config.toml (ou .openclose/config.toml)

[[agents]]
name = "build"
model = "qwen3-30b-a3b"
```

C'est tout. Le reste (description, outils, prompt) conserve ses valeurs par defaut.

### 2. Creer un agent de revue de code en lecture seule

```toml
[[agents]]
name = "reviewer"
description = "Revue de code axee sur la qualite et la securite"
model = "qwen3-30b-a3b"
temperature = 0.3
traits = ["readonly"]
allowed_tools = ["read", "grep", "glob", "ls"]
system_prompt = """Tu es un relecteur de code senior. Concentre-toi sur :
- La correction et les cas limites
- Les vulnerabilites de securite (OWASP Top 10)
- La clarte et la maintenabilite du code
Ne propose PAS de changements stylistiques sauf s'ils affectent la lisibilite."""
```

### 3. Creer un agent de recherche etendant plan

```toml
[[agents]]
name = "researcher"
description = "Agent de recherche approfondie pour l'analyse du code"
extends = "plan"
max_steps = 50
system_prompt = """Tu es $agent_name, tu travailles dans $project_dir.
Nous sommes le $date.

Ton role :
- Explorer le code en profondeur avant de repondre
- Citer les chemins de fichiers et numeros de ligne precis
- Fournir des syntheses structurees

Tu as acces aux outils suivants : $tool_names"""
```

## Heritage avec `extends`

Le champ `extends` permet a un agent d'heriter de tous les champs d'un parent, en ne redefinissant que ce qu'il souhaite modifier.

```toml
# Parent : agent avec acces complet et prompt personnalise
[[agents]]
name = "base"
model = "qwen3-30b-a3b"
temperature = 0.0
max_steps = 200
system_prompt = "Tu es un assistant de developpement polyvalent."

# Enfant : meme modele et prompt, mais en lecture seule et moins d'etapes
[[agents]]
name = "analyzer"
extends = "base"
traits = ["readonly"]
denied_tools = ["write", "edit", "bash", "patch"]
max_steps = 50

# Petit-enfant : herite de analyzer, ajoute un prompt specifique
[[agents]]
name = "security-auditor"
extends = "analyzer"
description = "Auditeur de securite du code"
system_prompt = "Tu es un auditeur de securite. Concentre-toi sur les vulnerabilites OWASP Top 10."
```

**Regles de resolution :**
- Les champs de l'enfant ecrasent ceux du parent
- Si l'enfant ne specifie pas un champ, la valeur du parent est utilisee
- Les chaines d'heritage sont limitees a 3 niveaux de profondeur (pour rester debuggable)
- Les references circulaires sont detectees et produisent une erreur

**Champs heritables :** `description`, `model`, `temperature`, `max_steps`, `mode`, `system_prompt`, `traits`, `allowed_tools`, `denied_tools`.

## Systeme de prompts

Les prompts des agents sont definis en ligne via le champ `system_prompt` :

```toml
[[agents]]
name = "myagent"
system_prompt = "Tu es un assistant de developpement."
```

### Variables de template

Les prompts acceptent les marqueurs `$variable` ou `${variable}` :

| Variable | Valeur |
|----------|--------|
| `$project_dir` | Repertoire de travail |
| `$date` | Date du jour (AAAA-MM-JJ) |
| `$agent_name` | Nom de l'agent |
| `$agent_description` | Description de l'agent |
| `$tool_names` | Liste des outils accessibles, separee par des virgules |

Les variables inconnues sont laissees telles quelles (substitution securisee).

**Exemple :**

```toml
[[agents]]
name = "myagent"
system_prompt = """Tu es $agent_name, tu travailles dans $project_dir.
Nous sommes le $date.

Tu as acces aux outils suivants : $tool_names

$agent_description"""
```

## Traits

Les traits sont des indicateurs semantiques qui pilotent le comportement a l'execution, sans etre lies au nom de l'agent.

Traits actuellement reconnus :

| Trait | Effet |
|-------|-------|
| `readonly` | Ajoute une restriction de lecture seule au prompt systeme : "You are in read-only mode. You CANNOT modify files, execute shell commands, or make any changes." |

Les traits sont herites via `extends`. Vous pouvez definir n'importe quel nom de trait : les traits personnalises sont stockes et accessibles via `agent.has_trait("nom")` pour les extensions futures.

```toml
[[agents]]
name = "plan"
extends = "build"
traits = ["readonly"]
denied_tools = ["write", "edit", "bash", "patch"]
```

## Visibilite des outils

**C'est une amelioration critique.** Auparavant, le LLM voyait les 11 schemas d'outils quel que soit l'agent, et les restrictions n'etaient appliquees qu'apres que le LLM avait deja choisi un outil bloque (gaspillant une etape). Desormais :

1. `allowed_tools` / `denied_tools` **filtrent les schemas d'outils** avant qu'ils n'atteignent le LLM
2. Le prompt systeme inclut une ligne `Available tools:` listant exactement ce qui est accessible
3. Le LLM ne voit jamais les outils qu'il ne peut pas utiliser : plus d'etapes gaspillees

### `allowed_tools` (liste blanche)

Si non vide, **seuls** ces outils sont visibles :

```toml
[[agents]]
name = "researcher"
allowed_tools = ["read", "grep", "glob", "ls", "webfetch"]
# L'agent ne peut ni voir ni appeler write, edit, bash, patch, etc.
```

### `denied_tools` (liste noire)

Ces outils sont masques :

```toml
[[agents]]
name = "plan"
denied_tools = ["write", "edit", "bash", "patch"]
# L'agent peut voir et appeler read, grep, glob, ls, webfetch, todo, question
```

### Aucune restriction

Si les deux listes sont vides, l'agent voit tous les outils enregistres :

```toml
[[agents]]
name = "build"
allowed_tools = []
denied_tools = []
# Acces complet aux 11 outils integres
```

### Outils integres disponibles

| Outil | Description |
|-------|-------------|
| `read` | Lire le contenu d'un fichier |
| `write` | Creer ou ecraser un fichier |
| `edit` | Modifications structurees de code (par lignes) |
| `glob` | Recherche de fichiers par motifs |
| `grep` | Recherche de contenu (ripgrep) |
| `ls` | Listing de repertoire |
| `bash` | Execution de commandes shell |
| `patch` | Appliquer des diffs unifies |
| `webfetch` | Recuperation HTTP + conversion en markdown |
| `todo` | Gestion de liste de taches |
| `question` | Demander une clarification a l'utilisateur |

## Exemple complet

```toml
# config.toml

# ── Redefinir l'agent build integre ──────────────────────────
[[agents]]
name = "build"
description = "Agent de developpement full-stack"
model = "qwen3-30b-a3b"
temperature = 0.0
max_steps = 150
system_prompt = """Tu es un agent de developpement travaillant dans $project_dir.
Ecris du code propre et teste. Suis les conventions du projet."""

# ── Redefinir l'agent plan integre ───────────────────────────
[[agents]]
name = "plan"
extends = "build"
traits = ["readonly"]
denied_tools = ["write", "edit", "bash", "patch"]

# ── Agent de revue personnalise ──────────────────────────────
[[agents]]
name = "reviewer"
description = "Agent de revue de code"
extends = "build"
temperature = 0.3
traits = ["readonly"]
allowed_tools = ["read", "grep", "glob", "ls"]
system_prompt = """Tu es un relecteur de code. Concentre-toi sur la correction, la securite et la clarte."""

# ── Agent hotfix avec limites strictes ───────────────────────
[[agents]]
name = "hotfix"
description = "Corrections minimales et ciblees uniquement"
extends = "build"
max_steps = 20
system_prompt = """Tu es un agent de correction urgente. Effectue le changement
LE PLUS PETIT possible pour corriger le probleme signale. Ne refactorise pas,
n'ajoute pas de tests, n'ameliore pas le code environnant. Une seule
modification chirurgicale."""
```

## Depannage

**Agent introuvable**
Verifiez que le nom correspond exactement (sensible a la casse). Utilisez `GET /api/agents` pour voir tous les agents charges.

**Cycle d'heritage**
Si l'agent A etend B et B etend A, vous verrez une erreur : "extends chain exceeds max depth". Brisez le cycle.

**Un outil est encore visible apres ajout dans denied_tools**
Assurez-vous de modifier le bon `config.toml` (le niveau projet est prioritaire sur le niveau utilisateur). Redemarrez le serveur apres vos modifications.
