# Agent Customization Guide

## Overview

OpenClose uses `[[agents]]` sections in `config.toml` to define, customize, and extend all agents — including the built-in ones (`build`, `plan`). This controls:

- Which model each agent uses
- What system prompt the agent receives
- Which tools the agent can see and call
- Inheritance between agents (create variants without repeating config)
- Semantic traits that drive runtime behaviour

## Built-in Defaults

When no `[[agents]]` sections are present, two agents are available:

| Agent | Mode | Description | Tool restrictions |
|-------|------|-------------|-------------------|
| `build` | primary | Full tool access for coding | None |
| `plan` | primary | Read-only analysis | Denied: write, edit, bash, patch |

You can override any of these in your `config.toml`.

## Configuration Format

Agents are defined as `[[agents]]` sections in `config.toml`:

```toml
[[agents]]
name = "build"
description = "Primary coding agent"
model = "qwen3-30b-a3b"
temperature = 0.0
max_steps = 100
```

### All Available Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `name` | string | *(required)* | Unique agent name |
| `description` | string | `""` | Short description of the agent's purpose |
| `model` | string | `""` | Model ID to use. Empty = auto-detect from provider |
| `temperature` | float | `0.0` | Sampling temperature (0.0–2.0) |
| `max_steps` | int | `100` | Maximum tool-call loop iterations (must be > 0) |
| `mode` | string | `"primary"` | Currently only `"primary"` is supported |
| `extends` | string | `""` | Name of a parent agent to inherit from |
| `system_prompt` | string | `""` | Inline system prompt |
| `traits` | list of strings | `[]` | Semantic behaviour flags (e.g. `["readonly"]`) |
| `allowed_tools` | list of strings | `[]` | Allowlist: if non-empty, only these tools are available |
| `denied_tools` | list of strings | `[]` | Denylist: these tools are hidden from the agent |

## Quick Start Examples

### 1. Override the default build agent's model

```toml
# ~/.config/openclose/config.toml (or .openclose/config.toml)

[[agents]]
name = "build"
model = "qwen3-30b-a3b"
```

That's it. Everything else (description, tools, prompt) keeps its default.

### 2. Create a read-only reviewer agent

```toml
[[agents]]
name = "reviewer"
description = "Reviews code for correctness and security"
model = "qwen3-30b-a3b"
temperature = 0.3
traits = ["readonly"]
allowed_tools = ["read", "grep", "glob", "ls"]
system_prompt = """You are a senior code reviewer. Focus on:
- Correctness and edge cases
- Security vulnerabilities (OWASP Top 10)
- Code clarity and maintainability
Do NOT suggest stylistic changes unless they affect readability."""
```

### 3. Create a research agent extending plan

```toml
[[agents]]
name = "researcher"
description = "Deep research agent for codebase analysis"
extends = "plan"
max_steps = 50
system_prompt = """You are a research agent specializing in codebase analysis.
You are working in $project_dir.

Your job:
- Explore the codebase thoroughly before answering
- Cite specific file paths and line numbers
- Provide structured summaries

You have access to: $tool_names"""
```

## Inheritance with `extends`

The `extends` field lets an agent inherit all fields from a parent, overriding only what it specifies.

```toml
# Parent: full-access agent with a custom prompt
[[agents]]
name = "base"
model = "qwen3-30b-a3b"
temperature = 0.0
max_steps = 200
system_prompt = "You are a versatile coding assistant."

# Child: same model and prompt, but read-only and fewer steps
[[agents]]
name = "analyzer"
extends = "base"
traits = ["readonly"]
denied_tools = ["write", "edit", "bash", "patch"]
max_steps = 50

# Grandchild: inherits from analyzer, adds a specific prompt
[[agents]]
name = "security-auditor"
extends = "analyzer"
description = "Security-focused code auditor"
system_prompt = "You are a security auditor. Focus on OWASP Top 10 vulnerabilities."
```

**Resolution rules:**
- Child fields override parent fields
- If the child doesn't specify a field, the parent's value is used
- Chains can go up to 3 levels deep (to stay debuggable)
- Circular references are detected and produce an error

**Inheritable fields:** `description`, `model`, `temperature`, `max_steps`, `mode`, `system_prompt`, `traits`, `allowed_tools`, `denied_tools`.

## Prompt System

Agent prompts are set inline via the `system_prompt` field:

```toml
[[agents]]
name = "myagent"
system_prompt = "You are a helpful coding assistant."
```

### Template Variables

Prompts support `$variable` or `${variable}` placeholders:

| Variable | Value |
|----------|-------|
| `$project_dir` | Working directory |
| `$date` | Current date (YYYY-MM-DD) |
| `$agent_name` | Agent name |
| `$agent_description` | Agent description |
| `$tool_names` | Comma-separated list of available tools |

Unknown variables are left as-is (safe substitution).

**Example:**

```toml
[[agents]]
name = "myagent"
system_prompt = """You are $agent_name, working in $project_dir.
Today is $date.

You have access to: $tool_names

$agent_description"""
```

## Traits

Traits are semantic flags that drive runtime behaviour without being tied to agent names.

Currently recognized traits:

| Trait | Effect |
|-------|--------|
| `readonly` | Appends a read-only restriction to the system prompt: "You are in read-only mode. You CANNOT modify files, execute shell commands, or make any changes." |

Traits are inherited via `extends`. You can define any trait name — custom traits are stored and accessible via `agent.has_trait("name")` for future extensions.

```toml
[[agents]]
name = "plan"
extends = "build"
traits = ["readonly"]
denied_tools = ["write", "edit", "bash", "patch"]
```

## Tool Visibility

**This is a critical improvement.** Previously, the LLM saw all 11 tool schemas regardless of the agent, and restrictions were enforced after the LLM had already chosen a blocked tool (wasting a step). Now:

1. `allowed_tools` / `denied_tools` **filter the tool schemas** before they reach the LLM
2. The system prompt includes an `Available tools:` line listing exactly what's accessible
3. The LLM never sees tools it can't use — no wasted steps

### `allowed_tools` (allowlist)

If non-empty, **only** these tools are visible:

```toml
[[agents]]
name = "researcher"
allowed_tools = ["read", "grep", "glob", "ls", "webfetch"]
# The agent cannot see or call write, edit, bash, patch, etc.
```

### `denied_tools` (denylist)

These tools are hidden:

```toml
[[agents]]
name = "plan"
denied_tools = ["write", "edit", "bash", "patch"]
# The agent can see and call read, grep, glob, ls, webfetch, todo, question
```

### No restrictions

If both lists are empty, the agent sees all registered tools:

```toml
[[agents]]
name = "build"
allowed_tools = []
denied_tools = []
# Full access to all 11 built-in tools
```

### Available Built-in Tools

| Tool | Description |
|------|-------------|
| `read` | Read file contents |
| `write` | Create or overwrite files |
| `edit` | Structured line-based code edits |
| `glob` | File pattern matching |
| `grep` | Content search (ripgrep) |
| `ls` | Directory listing |
| `bash` | Shell command execution |
| `patch` | Apply unified diffs |
| `webfetch` | HTTP fetch + markdown conversion |
| `todo` | Todo list management |
| `question` | Ask user for clarification |

## Complete Example

```toml
# config.toml

# ── Override built-in build agent ────────────────────────────
[[agents]]
name = "build"
description = "Full-stack dev agent"
model = "qwen3-30b-a3b"
temperature = 0.0
max_steps = 150
system_prompt = """You are a coding agent working in $project_dir.
Write clean, tested code. Follow the project's conventions."""

# ── Override built-in plan agent ─────────────────────────────
[[agents]]
name = "plan"
extends = "build"
traits = ["readonly"]
denied_tools = ["write", "edit", "bash", "patch"]

# ── Custom reviewer ──────────────────────────────────────────
[[agents]]
name = "reviewer"
description = "Code review agent"
extends = "build"
temperature = 0.3
traits = ["readonly"]
allowed_tools = ["read", "grep", "glob", "ls"]
system_prompt = """You are a code reviewer. Focus on correctness, security, and clarity."""

# ── Quick-fix agent with tight limits ────────────────────────
[[agents]]
name = "hotfix"
description = "Minimal targeted fixes only"
extends = "build"
max_steps = 20
system_prompt = """You are a hotfix agent. Make the SMALLEST possible change
to fix the reported issue. Do not refactor, do not add tests, do not improve
surrounding code. One surgical edit only."""
```

## Troubleshooting

**Agent not found**
Check that the name matches exactly (case-sensitive). Run `GET /api/agents` to see all loaded agents.

**Inheritance cycle**
If agent A extends B and B extends A, you'll see an error: "extends chain exceeds max depth". Break the cycle.

**Tool still visible after adding to denied_tools**
Make sure you're editing the correct `config.toml` (project-level overrides user-level). Restart the server after changes.
