"""Conformal Tights test suite."""
