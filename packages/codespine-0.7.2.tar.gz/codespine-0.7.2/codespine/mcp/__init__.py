"""MCP server layer."""
