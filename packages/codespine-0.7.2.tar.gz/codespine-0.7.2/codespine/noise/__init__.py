"""Noise filtering rules."""
