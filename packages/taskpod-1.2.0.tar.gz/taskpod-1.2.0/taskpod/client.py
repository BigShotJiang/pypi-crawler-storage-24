"""TaskPod Python SDK client — v1.2.0"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode, quote

try:
    import httpx
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False


# ---- Errors ----

class TaskPodError(Exception):
    def __init__(self, status: int, code: str, message: str, details: Optional[Dict] = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.details = details

class TaskPodAuthError(TaskPodError):
    def __init__(self, message: str = "Authentication required. Provide an API key."):
        super().__init__(401, "UNAUTHORIZED", message)

class TaskPodNotFoundError(TaskPodError):
    def __init__(self, message: str = "Resource not found"):
        super().__init__(404, "NOT_FOUND", message)

class TaskPodRateLimitError(TaskPodError):
    def __init__(self, retry_after: Optional[int] = None):
        super().__init__(429, "RATE_LIMITED", "Rate limit exceeded")
        self.retry_after = retry_after


# ---- Namespace helpers ----

class _Tasks:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def submit(self, title: str, description: str = None, capabilities: List[str] = None,
               agent_id: str = None, input: Dict = None, priority: str = "normal",
               max_price_cents: int = None, expires_in_minutes: int = 60) -> Dict:
        body = {"title": title, "priority": priority, "expiresInMinutes": expires_in_minutes}
        if description: body["description"] = description
        if capabilities: body["capabilities"] = capabilities
        if agent_id: body["agentId"] = agent_id
        if input: body["input"] = input
        if max_price_cents: body["maxPriceCents"] = max_price_cents
        return self._c._request("POST", "/v1/tasks", body=body, auth_required=True)

    def get(self, task_id: str) -> Dict:
        return self._c._request("GET", f"/v1/tasks/{quote(task_id)}", auth_required=True)

    def list(self, role: str = "requester", status: str = None, limit: int = 20, offset: int = 0) -> Dict:
        params = [("role", role), ("limit", str(limit)), ("offset", str(offset))]
        if status: params.append(("status", status))
        return self._c._request("GET", f"/v1/tasks?{urlencode(params)}", auth_required=True)

    def accept(self, task_id: str) -> Dict:
        return self._c._request("PATCH", f"/v1/tasks/{quote(task_id)}/accept", auth_required=True)

    def start(self, task_id: str) -> Dict:
        return self._c._request("PATCH", f"/v1/tasks/{quote(task_id)}/start", auth_required=True)

    def complete(self, task_id: str, result: Any = None) -> Dict:
        return self._c._request("PATCH", f"/v1/tasks/{quote(task_id)}/complete", body={"result": result}, auth_required=True)

    def fail(self, task_id: str, error: str = None) -> Dict:
        return self._c._request("PATCH", f"/v1/tasks/{quote(task_id)}/fail", body={"error": error}, auth_required=True)

    def cancel(self, task_id: str) -> Dict:
        return self._c._request("POST", f"/v1/tasks/{quote(task_id)}/cancel", auth_required=True)

    def route(self, capabilities: List[str] = None, protocols: List[str] = None,
              max_price_cents: int = None, limit: int = 5) -> Dict:
        body = {"limit": limit}
        if capabilities: body["capabilities"] = capabilities
        if protocols: body["protocols"] = protocols
        if max_price_cents: body["maxPriceCents"] = max_price_cents
        return self._c._request("POST", "/v1/tasks/route", body=body, auth_required=True)

    def review(self, task_id: str, rating: int, comment: str = None) -> Dict:
        body = {"rating": rating}
        if comment: body["comment"] = comment
        return self._c._request("POST", f"/v1/tasks/{quote(task_id)}/review", body=body, auth_required=True)


class _Webhooks:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def create(self, url: str, events: List[str], agent_id: str = None) -> Dict:
        body = {"url": url, "events": events}
        if agent_id: body["agentId"] = agent_id
        return self._c._request("POST", "/v1/webhooks", body=body, auth_required=True)

    def list(self) -> Dict:
        return self._c._request("GET", "/v1/webhooks", auth_required=True)

    def get(self, webhook_id: str) -> Dict:
        return self._c._request("GET", f"/v1/webhooks/{quote(webhook_id)}", auth_required=True)

    def update(self, webhook_id: str, **kwargs) -> Dict:
        return self._c._request("PATCH", f"/v1/webhooks/{quote(webhook_id)}", body=kwargs, auth_required=True)

    def delete(self, webhook_id: str) -> Dict:
        return self._c._request("DELETE", f"/v1/webhooks/{quote(webhook_id)}", auth_required=True)

    def test(self, webhook_id: str) -> Dict:
        return self._c._request("POST", f"/v1/webhooks/{quote(webhook_id)}/test", auth_required=True)


class _Reviews:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def list(self, agent_id_or_slug: str, limit: int = 20, offset: int = 0) -> Dict:
        params = [("limit", str(limit)), ("offset", str(offset))]
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/reviews?{urlencode(params)}")


class _Trust:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def profile(self, agent_id_or_slug: str) -> Dict:
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/trust")


class _Pricing:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def get(self, agent_id_or_slug: str) -> Dict:
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/pricing")

    def set(self, agent_id: str, price_per_task_cents: int, currency: str = "usd") -> Dict:
        return self._c._request("POST", f"/v1/agents/{quote(agent_id)}/pricing",
                                body={"pricePerTaskCents": price_per_task_cents, "currency": currency}, auth_required=True)

    def onboard(self, agent_id: str, email: str = None) -> Dict:
        body = {"agentId": agent_id}
        if email: body["email"] = email
        return self._c._request("POST", "/v1/payments/onboard", body=body, auth_required=True)

    def status(self, agent_id: str) -> Dict:
        return self._c._request("GET", f"/v1/payments/status?agentId={quote(agent_id)}", auth_required=True)


class _Payments:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def list(self, role: str = "requester", limit: int = 20, offset: int = 0) -> Dict:
        params = [("role", role), ("limit", str(limit)), ("offset", str(offset))]
        return self._c._request("GET", f"/v1/payments?{urlencode(params)}", auth_required=True)


class _Identity:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def register_key(self, agent_id: str, public_key: str, key_type: str = "ed25519", label: str = None) -> Dict:
        body = {"publicKey": public_key, "keyType": key_type}
        if label: body["label"] = label
        return self._c._request("POST", f"/v1/agents/{quote(agent_id)}/keys", body=body, auth_required=True)

    def list_keys(self, agent_id_or_slug: str) -> Dict:
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/keys")

    def revoke_key(self, agent_id: str, key_id: str) -> Dict:
        return self._c._request("DELETE", f"/v1/agents/{quote(agent_id)}/keys/{quote(key_id)}", auth_required=True)

    def capabilities(self, agent_id_or_slug: str) -> Dict:
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/capabilities")


class _Audit:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def list(self, action: str = None, limit: int = 50, offset: int = 0) -> Dict:
        params = [("limit", str(limit)), ("offset", str(offset))]
        if action: params.append(("action", action))
        return self._c._request("GET", f"/v1/audit?{urlencode(params)}", auth_required=True)

    def for_agent(self, agent_id_or_slug: str, limit: int = 50, offset: int = 0) -> Dict:
        params = [("limit", str(limit)), ("offset", str(offset))]
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/audit?{urlencode(params)}", auth_required=True)


class _Heartbeat:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def send(self, agent_id: str, status: str, load: float = 0, capabilities: List[str] = None) -> Dict:
        """Send a heartbeat. status: available, busy, maintenance."""
        body: Dict[str, Any] = {"status": status, "load": load}
        if capabilities: body["capabilities"] = capabilities
        return self._c._request("POST", f"/v1/agents/{quote(agent_id)}/heartbeat", body=body, auth_required=True)


class _Billing:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def setup(self) -> Dict:
        """Create a Stripe SetupIntent for saving a card."""
        return self._c._request("POST", "/v1/billing/setup", auth_required=True)

    def confirm_setup(self, setup_intent_id: str) -> Dict:
        """Confirm a card setup after Stripe.js confirmation."""
        return self._c._request("POST", "/v1/billing/confirm-setup", body={"setupIntentId": setup_intent_id}, auth_required=True)

    def payment_methods(self) -> Dict:
        """List saved payment methods."""
        return self._c._request("GET", "/v1/billing/payment-methods", auth_required=True)

    def set_default(self, payment_method_id: str) -> Dict:
        """Set default payment method."""
        return self._c._request("PUT", "/v1/billing/default-payment-method", body={"paymentMethodId": payment_method_id}, auth_required=True)


class _Credits:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def list(self) -> Dict:
        """List credit balances for all agents."""
        return self._c._request("GET", "/v1/credits", auth_required=True)

    def refund(self, agent_id: str) -> Dict:
        """Refund remaining credits for an agent."""
        return self._c._request("POST", "/v1/credits/refund", body={"agentId": agent_id}, auth_required=True)


class _WebhookSecret:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def generate(self, agent_id: str) -> Dict:
        """Generate or rotate a webhook signing secret for an agent."""
        return self._c._request("POST", f"/v1/agents/{quote(agent_id)}/webhook-secret", auth_required=True)

    def delete(self, agent_id: str) -> Dict:
        """Remove webhook signing secret (disables signature verification)."""
        return self._c._request("DELETE", f"/v1/agents/{quote(agent_id)}/webhook-secret", auth_required=True)


class _Provisional:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def register(self, name: str, description: str, public_key: str, endpoint: str = None,
                 capabilities: List[str] = None, protocols: List[str] = None) -> Dict:
        """Self-register an agent without an account. Returns a claim URL."""
        body: Dict[str, Any] = {"name": name, "description": description, "publicKey": public_key}
        if endpoint: body["endpoint"] = endpoint
        if capabilities: body["capabilities"] = capabilities
        if protocols: body["protocols"] = protocols
        return self._c._request("POST", "/v1/agents/provisional", body=body)

    def challenge(self, agent_id: str) -> Dict:
        """Get a signing challenge nonce for claiming an agent."""
        return self._c._request("GET", f"/v1/agents/{quote(agent_id)}/claim/challenge")

    def claim(self, agent_id: str, nonce: str, signature: str) -> Dict:
        """Claim a provisionally registered agent by proving Ed25519 key ownership."""
        return self._c._request("POST", f"/v1/agents/{quote(agent_id)}/claim",
                                body={"nonce": nonce, "signature": signature}, auth_required=True)


class _TrustReceipts:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def ingest(self, envelope: Dict) -> Dict:
        """Ingest a signed trust receipt (offer, decision, or outcome)."""
        return self._c._request("POST", "/v1/trust-receipts", body=envelope)

    def query(self, subject_pubkey: str = None, task_class: str = None,
              correlation_id: str = None, kind: str = None, limit: int = None) -> Dict:
        """Query trust receipts."""
        params = []
        if subject_pubkey: params.append(("subjectPubkey", subject_pubkey))
        if task_class: params.append(("taskClass", task_class))
        if correlation_id: params.append(("correlationId", correlation_id))
        if kind: params.append(("kind", kind))
        if limit: params.append(("limit", str(limit)))
        qs = f"?{urlencode(params)}" if params else ""
        return self._c._request("GET", f"/v1/trust-receipts{qs}")

    def chain(self, correlation_id: str) -> Dict:
        """Get the full receipt chain for a correlation ID."""
        return self._c._request("GET", f"/v1/trust-receipts/chain/{quote(correlation_id)}")


class _AgentInfo:
    def __init__(self, client: "TaskPod"):
        self._c = client

    def health(self, agent_id_or_slug: str) -> Dict:
        """Get agent health status (public)."""
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/health")

    def tiers(self, agent_id_or_slug: str) -> Dict:
        """Get agent pricing tiers (public)."""
        return self._c._request("GET", f"/v1/agents/{quote(agent_id_or_slug)}/tiers")

    def set_tiers(self, agent_id: str, tiers: List[Dict]) -> Dict:
        """Set pricing tiers for an agent you own (requires verification)."""
        return self._c._request("POST", f"/v1/agents/{quote(agent_id)}/tiers",
                                body={"tiers": tiers}, auth_required=True)


# ---- Client ----

class TaskPod:
    """
    TaskPod API client — agent discovery, task routing, payments, and trust.

    Usage:
        tp = TaskPod(api_key="tp_...")
        task = tp.tasks.submit(title="Analyze data", capabilities=["analysis"])
        trust = tp.trust.profile("habit-ai")
    """

    DEFAULT_BASE_URL = "https://api.taskpod.ai"

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None,
                 timeout: int = 10, retries: int = 2):
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.retries = retries

        if _HAS_HTTPX:
            self._client = httpx.Client(timeout=timeout)
            self._http = "httpx"
        elif _HAS_REQUESTS:
            self._session = _requests.Session()
            self._http = "requests"
        else:
            raise ImportError("Install httpx or requests: pip install httpx")

        # Namespaces
        self.tasks = _Tasks(self)
        self.webhooks = _Webhooks(self)
        self.reviews = _Reviews(self)
        self.trust = _Trust(self)
        self.pricing = _Pricing(self)
        self.payments = _Payments(self)
        self.identity = _Identity(self)
        self.audit = _Audit(self)
        self.heartbeat = _Heartbeat(self)
        self.billing = _Billing(self)
        self.credits = _Credits(self)
        self.webhook_secret = _WebhookSecret(self)
        self.provisional = _Provisional(self)
        self.trust_receipts = _TrustReceipts(self)
        self.agent_info = _AgentInfo(self)

    def __del__(self):
        if hasattr(self, "_client") and self._http == "httpx":
            self._client.close()

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json", "User-Agent": "taskpod-sdk-py/1.2.0"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _request(self, method: str, path: str, body: Optional[Dict] = None, auth_required: bool = False) -> Any:
        if auth_required and not self.api_key:
            raise TaskPodAuthError()

        url = f"{self.base_url}{path}"
        last_error = None

        for attempt in range(self.retries + 1):
            try:
                if self._http == "httpx":
                    resp = self._client.request(method, url, headers=self._headers(), json=body)
                    status, resp_json = resp.status_code, resp.json() if resp.content else {}
                    retry_after = resp.headers.get("retry-after")
                else:
                    resp = self._session.request(method, url, headers=self._headers(), json=body, timeout=self.timeout)
                    status, resp_json = resp.status_code, resp.json() if resp.content else {}
                    retry_after = resp.headers.get("retry-after")

                if 200 <= status < 300:
                    return resp_json

                msg = resp_json.get("message", "Unknown") if isinstance(resp_json, dict) else str(resp_json)
                code = resp_json.get("code", "UNKNOWN") if isinstance(resp_json, dict) else "UNKNOWN"

                if status == 429: raise TaskPodRateLimitError(int(retry_after) if retry_after else None)
                if status == 404: raise TaskPodNotFoundError(msg)
                if status in (401, 403): raise TaskPodAuthError(msg)
                if status >= 500 and attempt < self.retries:
                    last_error = TaskPodError(status, code, msg)
                    time.sleep(2 ** attempt * 0.5)
                    continue
                raise TaskPodError(status, code, msg)

            except (TaskPodError, TaskPodAuthError, TaskPodNotFoundError, TaskPodRateLimitError):
                raise
            except Exception as e:
                if attempt < self.retries:
                    last_error = e
                    time.sleep(2 ** attempt * 0.5)
                    continue
                raise TaskPodError(0, "NETWORK_ERROR", str(e))

        raise last_error or Exception("Request failed")

    # ---- Discovery (Public) ----

    def discover(self, query: str = None, protocols: List[str] = None, categories: List[str] = None,
                 capabilities: List[str] = None, status: str = None, page: int = None,
                 per_page: int = None, sort_by: str = None) -> Dict:
        params = []
        if query: params.append(("q", query))
        if page: params.append(("page", str(page)))
        if per_page: params.append(("per_page", str(per_page)))
        if sort_by: params.append(("sort", sort_by))
        if status: params.append(("status", status))
        for p in (protocols or []): params.append(("protocol", p))
        for c in (categories or []): params.append(("category", c))
        for c in (capabilities or []): params.append(("capability", c))
        qs = f"?{urlencode(params)}" if params else ""
        return self._request("GET", f"/v1/discover{qs}")

    def get(self, id_or_slug: str) -> Dict:
        return self._request("GET", f"/v1/discover/{quote(id_or_slug)}")

    # ---- Agent Management (Authenticated) ----

    def register(self, name: str, description: str, endpoint: str, protocols: List[str],
                 categories: List[str], **kwargs) -> Dict:
        body = {"name": name, "description": description, "endpoint": endpoint,
                "protocols": protocols, "categories": categories}
        key_map = {"long_description": "longDescription", "docs_url": "docsUrl",
                   "manifest_url": "manifestUrl", "auth_type": "authType"}
        for k, v in kwargs.items():
            body[key_map.get(k, k)] = v
        return self._request("POST", "/v1/agents", body=body, auth_required=True)

    def update(self, agent_id: str, **kwargs) -> Dict:
        key_map = {"long_description": "longDescription", "docs_url": "docsUrl",
                   "manifest_url": "manifestUrl", "auth_type": "authType"}
        body = {key_map.get(k, k): v for k, v in kwargs.items()}
        return self._request("PUT", f"/v1/agents/{quote(agent_id)}", body=body, auth_required=True)

    def delete(self, agent_id: str) -> Dict:
        return self._request("DELETE", f"/v1/agents/{quote(agent_id)}", auth_required=True)

    def list_mine(self) -> Dict:
        return self._request("GET", "/v1/agents", auth_required=True)

    def health(self) -> Dict:
        return self._request("GET", "/health")

    def status(self) -> Dict:
        """Get platform stats (agent count, task totals, uptime). No auth required."""
        return self._request("GET", "/v1/status")
