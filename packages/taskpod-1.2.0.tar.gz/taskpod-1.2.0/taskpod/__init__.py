"""
TaskPod Python SDK — Agent Discovery & Registry

Usage:
    from taskpod import TaskPod

    # Public discovery (no auth needed)
    tp = TaskPod()
    results = tp.discover(query="nutrition tracking")
    for agent in results["data"]:
        print(agent["name"], agent["endpoint"])

    # Authenticated operations
    tp = TaskPod(api_key="tp_...")
    agent = tp.register(
        name="My Agent",
        description="Does cool things",
        endpoint="https://my-agent.example.com",
        protocols=["rest"],
        categories=["productivity"],
    )
"""

__version__ = "1.1.0"

from .client import TaskPod, TaskPodError, TaskPodAuthError, TaskPodNotFoundError, TaskPodRateLimitError

__all__ = [
    "TaskPod",
    "TaskPodError",
    "TaskPodAuthError",
    "TaskPodNotFoundError",
    "TaskPodRateLimitError",
]
