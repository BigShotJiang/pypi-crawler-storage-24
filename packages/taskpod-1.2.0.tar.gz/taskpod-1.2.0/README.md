# TaskPod Python SDK

Agent discovery and registry client for [TaskPod](https://taskpod.ai).

## Install

```bash
pip install taskpod[httpx]    # recommended
# or
pip install taskpod[requests] # if you prefer requests
```

## Quick Start

```python
from taskpod import TaskPod

# Discovery is public — no auth needed
tp = TaskPod()

# Search for agents
results = tp.discover(query="nutrition tracking")
for agent in results["data"]:
    print(f"{agent['name']} — {agent['endpoint']}")

# Get a specific agent
agent = tp.get("habit-ai")
print(agent["data"]["capabilities"])

# Filter by protocol and category
results = tp.discover(protocols=["rest"], categories=["health"])
```

## Authenticated Operations

```python
tp = TaskPod(api_key="tp_your_api_key")

# Register an agent
agent = tp.register(
    name="My Agent",
    description="Does cool things",
    endpoint="https://my-agent.example.com/api",
    protocols=["rest"],
    categories=["productivity"],
    capabilities=["task-management", "scheduling"],
    tags=["free", "open-source"],
)
print(agent["data"]["id"])  # => "abc123..."

# Update
tp.update(agent["data"]["id"], description="Updated description")

# List your agents
my_agents = tp.list_mine()

# Delete
tp.delete(agent["data"]["id"])
```

## Error Handling

```python
from taskpod import TaskPod, TaskPodNotFoundError, TaskPodAuthError, TaskPodRateLimitError

tp = TaskPod()

try:
    agent = tp.get("nonexistent-agent")
except TaskPodNotFoundError:
    print("Agent not found")
except TaskPodAuthError:
    print("Need an API key for this operation")
except TaskPodRateLimitError as e:
    print(f"Rate limited, retry after {e.retry_after}s")
```

## Configuration

```python
tp = TaskPod(
    api_key="tp_...",                          # optional for discovery
    base_url="https://api.taskpod.ai",         # default
    timeout=10,                                 # seconds
    retries=2,                                  # on 5xx/network errors
)
```
