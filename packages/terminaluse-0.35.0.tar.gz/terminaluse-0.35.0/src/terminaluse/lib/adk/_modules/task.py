"""
Task system folder sync module for the Agent Development Kit (ADK).

This module provides high-level async methods for task system folder sync operations:
- sync_down_system_folder: Download a task system folder from GCS if changed
- sync_up_system_folder: Upload a task system folder to GCS if changed

System folders are task-scoped (unique per task) and synced to/from GCS at runtime.
"""

from __future__ import annotations

import asyncio
import json
import os
import uuid
from pathlib import Path
from typing import Literal

import httpx
from opentelemetry import trace
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from terminaluse.lib.adk.utils._modules.client import create_async_terminaluse_client
from terminaluse.lib.client import AsyncTerminalUse
from terminaluse.lib.types.system_folders import SyncDownResult, SyncUpResult
from terminaluse.lib.utils.file_utils import atomic_json_write
from terminaluse.lib.utils.filesystem_archive import (
    ArchiveResult,
    CorruptArchiveError,
    FilesystemNotFoundError,
    FilesystemSyncError,
    create_archive,
    download_from_presigned_url,
    extract_archive,
    upload_to_presigned_url,
)
from terminaluse.lib.utils.logging import make_logger

logger = make_logger(__name__)
tracer = trace.get_tracer(__name__)

# Data root from environment, defaults to /bucket_data
DATA_ROOT_PATH = os.environ.get("TERMINALUSE_DATA_ROOT_PATH", "/bucket_data")

# Supported system folder types
DOT_CLAUDE_CONFIG = {
    "type": "dot_claude",
    "host_path": ".claude",
    "sandbox_mount_path": "/root/.claude",
}
DOT_CODEX_CONFIG = {
    "type": "dot_codex",
    "host_path": ".codex",
    "sandbox_mount_path": "/root/.codex",
}
SystemFolderTypeLiteral = Literal["dot_claude", "dot_codex"]
SYSTEM_FOLDER_CONFIGS: dict[SystemFolderTypeLiteral, dict[str, str]] = {
    "dot_claude": DOT_CLAUDE_CONFIG,
    "dot_codex": DOT_CODEX_CONFIG,
}
DEFAULT_SYSTEM_FOLDER_TYPES: tuple[SystemFolderTypeLiteral, ...] = ("dot_claude", "dot_codex")

# HTTP retry configuration for sync-complete API calls
SYNC_COMPLETE_RETRY_CONFIG = {
    "stop": stop_after_attempt(2),  # Initial attempt + 1 retry
    "wait": wait_exponential(multiplier=1, min=1, max=10),
    "retry": retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError)),
}

# Skip patterns for task system folders
SYSTEM_FOLDER_SKIP_PATTERNS = [
    ".DS_Store",
    "__pycache__",
    ".sync_cache.json",  # Our own cache file
]


class TaskModule:
    """
    Module for task system folder sync operations in TerminalUse.

    Provides high-level async methods for syncing task-scoped system folders
    (for example .claude and .codex) used by agent runtimes.
    """

    def __init__(
        self,
        client: AsyncTerminalUse | None = None,
    ):
        """
        Initialize task module.

        Args:
            client: Optional TerminalUse client (creates new if not provided)
        """
        self._client = client

    def _get_client(self) -> AsyncTerminalUse:
        """Get or create the TerminalUse client lazily."""
        if self._client is None:
            self._client = create_async_terminaluse_client()
        return self._client

    def _get_local_path(self, task_id: str, folder_type: SystemFolderTypeLiteral) -> Path:
        """Get local path for a task system folder."""
        return Path(DATA_ROOT_PATH) / "tasks" / task_id / SYSTEM_FOLDER_CONFIGS[folder_type]["host_path"]

    def _get_cache_path(self, task_id: str) -> str:
        """Get cache file path for task."""
        return f"{DATA_ROOT_PATH}/tasks/{task_id}/.sync_cache.json"

    def _load_cache(self, task_id: str) -> dict:
        """Load cache with atomic read."""
        path = self._get_cache_path(task_id)
        if not os.path.exists(path):
            return {"version": 1, "system_folders": {}}
        try:
            with open(path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to load task sync cache: {e}")
            return {"version": 1, "system_folders": {}}

    def _save_cache(self, task_id: str, cache: dict) -> None:
        """Save cache with atomic write."""
        atomic_json_write(self._get_cache_path(task_id), cache)

    def _get_cached_checksum(self, task_id: str, folder_type: SystemFolderTypeLiteral) -> str | None:
        """Get cached checksum for a folder type."""
        cache = self._load_cache(task_id)
        folder_cache = cache.get("system_folders", {}).get(folder_type, {})
        return folder_cache.get("checksum")

    def _set_cached_checksum(self, task_id: str, folder_type: str, checksum: str | None) -> None:
        """Set cached checksum for a folder type."""
        from datetime import datetime, timezone

        cache = self._load_cache(task_id)
        if "system_folders" not in cache:
            cache["system_folders"] = {}
        cache["system_folders"][folder_type] = {
            "checksum": checksum,
            "last_synced_at": datetime.now(timezone.utc).isoformat(),
        }
        self._save_cache(task_id, cache)

    async def sync_down_system_folder(
        self,
        task_id: str,
        folder_type: SystemFolderTypeLiteral | None = None,
    ) -> SyncDownResult | list[SyncDownResult]:
        """
        Sync one task system folder from GCS to local.

        1. Create local directory if needed (required for mount even if GCS empty)
        2. Get remote checksum from GET /tasks/{task_id}/system-folders/{folder_type}
        3. Compare with local cache checksum (from internal cache)
        4. If different, get download URL and fetch archive
        5. Extract to local path (or leave empty if GCS has no content)
        6. Update internal cache with new checksum

        Args:
            task_id: ID of the task
            folder_type: Type of system folder. If omitted, sync all supported folders.

        Returns:
            SyncDownResult with sync status, or list of results when syncing all folders.
        """
        if folder_type is None:
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.all",
                attributes={"task.id": task_id, "sync.direction": "down"},
            ) as all_span:
                results = await self.sync_down_system_folders(task_id)
                all_span.set_attribute("system_folder.result_count", len(results))
                all_span.set_attribute(
                    "system_folder.synced_count",
                    sum(1 for result in results if result.synced),
                )
                return results

        span_attributes = {
            "task.id": task_id,
            "sync.direction": "down",
            "system_folder.type": folder_type,
        }
        with tracer.start_as_current_span(
            "task.system_folder.sync_down",
            attributes=span_attributes,
        ) as sync_span:
            local_path = self._get_local_path(task_id, folder_type)

            # Always create local directory for mount (even if GCS is empty)
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.ensure_local_dir",
                attributes=span_attributes,
            ):
                try:
                    local_path.mkdir(parents=True, exist_ok=True)
                except OSError as e:
                    raise FilesystemSyncError(f"Failed to create system folder directory {local_path}: {e}") from e

            client = self._get_client()

            # 1. Get local cached checksum
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.read_cached_checksum",
                attributes=span_attributes,
            ):
                local_checksum = self._get_cached_checksum(task_id, folder_type)

            # 2. Get remote system folder state
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.fetch_remote_state",
                attributes=span_attributes,
            ) as remote_state_span:
                try:
                    system_folder = await client.tasks.get_system_folder(task_id, folder_type)
                    if system_folder is None:
                        logger.info(f"System folder {folder_type} returned None for task {task_id} - treating as empty")
                        sync_span.set_attribute("system_folder.synced", False)
                        sync_span.set_attribute("system_folder.skip_reason", "empty_remote")
                        return SyncDownResult(folder_type=folder_type, checksum=None, synced=False)
                    remote_checksum: str | None = system_folder.archive_checksum
                    remote_state_span.set_attribute(
                        "system_folder.remote_checksum.present", remote_checksum is not None
                    )
                except httpx.HTTPStatusError as e:
                    if e.response.status_code == 404:
                        # System folder doesn't exist yet (new task) - continue with empty
                        logger.info(f"System folder {folder_type} not found for task {task_id} - treating as empty")
                        sync_span.set_attribute("system_folder.synced", False)
                        sync_span.set_attribute("system_folder.skip_reason", "not_found")
                        return SyncDownResult(folder_type=folder_type, checksum=None, synced=False)
                    raise

            # 3. Fast path: unchanged (only skip if we have checksums to compare)
            if remote_checksum is not None and local_checksum == remote_checksum:
                logger.debug(f"System folder {folder_type} for task {task_id} unchanged, skipping download")
                sync_span.set_attribute("system_folder.synced", False)
                sync_span.set_attribute("system_folder.skip_reason", "unchanged")
                return SyncDownResult(folder_type=folder_type, checksum=remote_checksum, synced=False)

            # 4. Get presigned URL
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.get_download_url",
                attributes=span_attributes,
            ):
                url_response = await client.tasks.get_system_folder_download_url(task_id, folder_type)
            if url_response is None or not url_response.url:
                logger.warning(f"No download URL for system folder {folder_type} task {task_id} - treating as empty")
                sync_span.set_attribute("system_folder.synced", False)
                sync_span.set_attribute("system_folder.skip_reason", "missing_download_url")
                return SyncDownResult(folder_type=folder_type, checksum=None, synced=False)

            # 5. Download archive - handle 404 as empty folder
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.download_archive",
                attributes=span_attributes,
            ) as download_span:
                try:
                    logger.info(f"Downloading system folder {folder_type} for task {task_id}")
                    archive_data = await download_from_presigned_url(url_response.url)
                    download_span.set_attribute("archive.bytes", len(archive_data))
                except FilesystemNotFoundError:
                    logger.info(f"System folder {folder_type} archive not found for task {task_id} - treating as empty")
                    sync_span.set_attribute("system_folder.synced", False)
                    sync_span.set_attribute("system_folder.skip_reason", "archive_not_found")
                    return SyncDownResult(folder_type=folder_type, checksum=None, synced=False)

            # 6. Extract to local path
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.extract_archive",
                attributes=span_attributes,
            ) as extract_span:
                try:
                    result = await extract_archive(archive_data, local_path)
                    logger.info(f"Extracted {result.files_count} files to {local_path}")
                    extract_span.set_attribute("archive.files_count", result.files_count)
                    extract_span.set_attribute("archive.size_bytes", result.size_bytes)
                except CorruptArchiveError as e:
                    logger.error(f"Corrupt archive for system folder {folder_type} task {task_id}: {e}")
                    raise

            # 7. Update cache with new checksum
            with tracer.start_as_current_span(
                "task.system_folder.sync_down.update_cache",
                attributes=span_attributes,
            ):
                self._set_cached_checksum(task_id, folder_type, remote_checksum)

            sync_span.set_attribute("system_folder.synced", True)
            sync_span.set_attribute("archive.files_count", result.files_count)
            sync_span.set_attribute("archive.size_bytes", result.size_bytes)
            return SyncDownResult(
                folder_type=folder_type,
                checksum=remote_checksum,
                synced=True,
            )

    async def sync_up_system_folder(
        self,
        task_id: str,
        folder_type: SystemFolderTypeLiteral | None = None,
    ) -> SyncUpResult | list[SyncUpResult]:
        """
        Sync one task system folder from local to GCS.

        1. Check if local folder exists (skip if not)
        2. Build local archive with checksum
        3. Compare with cached checksum (from internal cache)
        4. If different, get upload URL and push archive
        5. Call sync-complete endpoint
        6. Update internal cache with new checksum

        Args:
            task_id: ID of the task
            folder_type: Type of system folder. If omitted, sync all supported folders.

        Returns:
            SyncUpResult with sync status, or list of results when syncing all folders.
        """
        if folder_type is None:
            with tracer.start_as_current_span(
                "task.system_folder.sync_up.all",
                attributes={"task.id": task_id, "sync.direction": "up"},
            ) as all_span:
                results = await self.sync_up_system_folders(task_id)
                all_span.set_attribute("system_folder.result_count", len(results))
                all_span.set_attribute(
                    "system_folder.uploaded_count",
                    sum(1 for result in results if result.size_bytes > 0),
                )
                return results

        span_attributes = {
            "task.id": task_id,
            "sync.direction": "up",
            "system_folder.type": folder_type,
        }
        with tracer.start_as_current_span(
            "task.system_folder.sync_up",
            attributes=span_attributes,
        ) as sync_span:
            local_path = self._get_local_path(task_id, folder_type)

            # Check if local folder exists
            if not local_path.exists():
                logger.debug(f"System folder {folder_type} for task {task_id} does not exist locally, skipping upload")
                sync_span.set_attribute("system_folder.synced", False)
                sync_span.set_attribute("system_folder.skip_reason", "missing_local_folder")
                return SyncUpResult(folder_type=folder_type, checksum="", size_bytes=0)

            # Check if folder is empty
            if not any(local_path.iterdir()):
                logger.debug(f"System folder {folder_type} for task {task_id} is empty, skipping upload")
                sync_span.set_attribute("system_folder.synced", False)
                sync_span.set_attribute("system_folder.skip_reason", "empty_local_folder")
                return SyncUpResult(folder_type=folder_type, checksum="", size_bytes=0)

            client = self._get_client()

            # 1. Create archive
            with tracer.start_as_current_span(
                "task.system_folder.sync_up.create_archive",
                attributes=span_attributes,
            ):
                logger.info(f"Creating archive for system folder {folder_type} task {task_id}")
                archive_result: ArchiveResult = await create_archive(local_path, SYSTEM_FOLDER_SKIP_PATTERNS)

            # 2. Check if checksum changed
            with tracer.start_as_current_span(
                "task.system_folder.sync_up.read_cached_checksum",
                attributes=span_attributes,
            ):
                local_cached_checksum = self._get_cached_checksum(task_id, folder_type)
            if archive_result.checksum == local_cached_checksum:
                logger.debug(f"System folder {folder_type} for task {task_id} unchanged, skipping upload")
                sync_span.set_attribute("system_folder.synced", False)
                sync_span.set_attribute("system_folder.skip_reason", "unchanged")
                sync_span.set_attribute("archive.size_bytes", archive_result.size_bytes)
                return SyncUpResult(
                    folder_type=folder_type,
                    checksum=archive_result.checksum,
                    size_bytes=archive_result.size_bytes,
                )

            # 3. Get presigned URL
            with tracer.start_as_current_span(
                "task.system_folder.sync_up.get_upload_url",
                attributes=span_attributes,
            ):
                url_response = await client.tasks.get_system_folder_upload_url(task_id, folder_type)

            # 4. Upload archive
            with tracer.start_as_current_span(
                "task.system_folder.sync_up.upload_archive",
                attributes={
                    **span_attributes,
                    "archive.size_bytes": archive_result.size_bytes,
                },
            ):
                logger.info(f"Uploading {archive_result.size_bytes} bytes to GCS for system folder {folder_type}")
                await upload_to_presigned_url(url_response.url, archive_result.data)

            # 5. Complete sync
            sync_id = str(uuid.uuid4())
            with tracer.start_as_current_span(
                "task.system_folder.sync_up.sync_complete",
                attributes={
                    **span_attributes,
                    "sync.id": sync_id,
                    "archive.checksum": archive_result.checksum,
                },
            ):
                await self._call_sync_complete(
                    task_id=task_id,
                    folder_type=folder_type,
                    sync_id=sync_id,
                    direction="UP",
                    status="SUCCESS",
                    archive_size_bytes=archive_result.size_bytes,
                    archive_checksum=archive_result.checksum,
                )

            # 6. Update cache
            with tracer.start_as_current_span(
                "task.system_folder.sync_up.update_cache",
                attributes=span_attributes,
            ):
                self._set_cached_checksum(task_id, folder_type, archive_result.checksum)

            sync_span.set_attribute("system_folder.synced", True)
            sync_span.set_attribute("archive.size_bytes", archive_result.size_bytes)
            return SyncUpResult(
                folder_type=folder_type,
                checksum=archive_result.checksum,
                size_bytes=archive_result.size_bytes,
            )

    @retry(**SYNC_COMPLETE_RETRY_CONFIG)
    async def _call_sync_complete(
        self,
        task_id: str,
        folder_type: SystemFolderTypeLiteral,
        sync_id: str,
        direction: str,
        status: str,
        archive_size_bytes: int | None,
        archive_checksum: str | None,
    ) -> None:
        """
        Call POST /tasks/{task_id}/system-folders/{folder_type}/sync-complete via generated SDK with retry.

        Retries once on transient network failures (TimeoutException, ConnectError).
        """
        client = self._get_client()

        await client.tasks.system_folder_sync_complete(
            task_id,
            folder_type,
            sync_id=sync_id,
            direction=direction,
            status=status,
            archive_size_bytes=archive_size_bytes,
            archive_checksum=archive_checksum,
        )

    async def sync_down_system_folders(
        self,
        task_id: str,
        folder_types: tuple[SystemFolderTypeLiteral, ...] = DEFAULT_SYSTEM_FOLDER_TYPES,
    ) -> list[SyncDownResult]:
        """Sync all requested task system folders from GCS to local."""
        with tracer.start_as_current_span(
            "task.system_folder.sync_down.batch",
            attributes={
                "task.id": task_id,
                "sync.direction": "down",
                "system_folder.requested_count": len(folder_types),
            },
        ) as batch_span:
            results = await asyncio.gather(
                *(self.sync_down_system_folder(task_id, folder_type=t) for t in folder_types),
                return_exceptions=True,
            )
            synced: list[SyncDownResult] = []
            failed_count = 0
            for folder_type, result in zip(folder_types, results, strict=False):
                if isinstance(result, Exception):
                    logger.warning(f"Failed to sync down {folder_type} for task {task_id}: {result}")
                    failed_count += 1
                    continue
                if isinstance(result, SyncDownResult):
                    synced.append(result)
            batch_span.set_attribute("system_folder.success_count", len(synced))
            batch_span.set_attribute("system_folder.failed_count", failed_count)
            return synced

    async def sync_up_system_folders(
        self,
        task_id: str,
        folder_types: tuple[SystemFolderTypeLiteral, ...] = DEFAULT_SYSTEM_FOLDER_TYPES,
    ) -> list[SyncUpResult]:
        """Sync all requested task system folders from local to GCS."""
        with tracer.start_as_current_span(
            "task.system_folder.sync_up.batch",
            attributes={
                "task.id": task_id,
                "sync.direction": "up",
                "system_folder.requested_count": len(folder_types),
            },
        ) as batch_span:
            results = await asyncio.gather(
                *(self.sync_up_system_folder(task_id, folder_type=t) for t in folder_types),
                return_exceptions=True,
            )
            synced: list[SyncUpResult] = []
            failed_count = 0
            for folder_type, result in zip(folder_types, results, strict=False):
                if isinstance(result, Exception):
                    logger.warning(f"Failed to sync up {folder_type} for task {task_id}: {result}")
                    failed_count += 1
                    continue
                if isinstance(result, SyncUpResult):
                    synced.append(result)
            batch_span.set_attribute("system_folder.success_count", len(synced))
            batch_span.set_attribute("system_folder.failed_count", failed_count)
            return synced


# Singleton instance for ADK usage
task = TaskModule()
