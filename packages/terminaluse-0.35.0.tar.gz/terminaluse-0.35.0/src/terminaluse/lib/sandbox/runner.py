"""Subprocess spawning and bubblewrap invocation for sandboxed handlers."""

from __future__ import annotations

import asyncio
import json
import os
import select
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from opentelemetry import trace
from pydantic import BaseModel

from terminaluse.lib.sandbox.config import SandboxConfig, get_sandbox_config
from terminaluse.lib.sandbox.handler_ref import HandlerRef
from terminaluse.lib.sandbox.mounts import Mount, configure_bwrap_mounts
from terminaluse.lib.utils.logging import make_logger

logger = make_logger(__name__)
TRACE_CONTEXT_HEADERS = {"traceparent", "tracestate", "baggage"}
SANDBOX_SPAWN_TIME_KEY = "sandbox_spawn_time_ns"
tracer = trace.get_tracer(__name__)

# Keep this in one place so startup diagnostics and sandbox env stay in sync.
SANDBOX_SYSTEM_PATH = "/usr/local/bin:/usr/bin:/bin"


@dataclass
class SandboxResult:
    """Result of a sandboxed handler invocation."""

    success: bool
    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool = False

    @property
    def status_json(self) -> dict[str, Any] | None:
        """Parse stdout as JSON status, or None if invalid."""
        if not self.stdout.strip():
            return None
        try:
            return json.loads(self.stdout)
        except json.JSONDecodeError:
            return None


class SandboxRunner:
    """Runs handlers in bubblewrap sandboxes.

    bubblewrap is used instead of nsjail because nsjail requires prctl(PR_SET_SECUREBITS)
    which gVisor hasn't implemented. bubblewrap provides equivalent filesystem isolation
    and works correctly inside gVisor (GKE Sandbox).
    """

    def __init__(self, config: SandboxConfig | None = None):
        self.config = config or get_sandbox_config()

    def _build_bwrap_command(self, mounts: list[Mount] | None = None) -> list[str]:
        """Build the bubblewrap command with all arguments.

        Args:
            mounts: Pre-assembled list of mounts (filesystem, system folders, baked).
                   If None, creates ephemeral tmpfs at /workspace.

        Note: bubblewrap doesn't have a built-in timeout like nsjail's --time_limit.
        We intentionally do not enforce a wall-clock timeout at this layer.
        """
        config = self.config

        cmd = [config.bwrap_path]

        # Namespace isolation
        # --unshare-user: Create new user namespace (unprivileged isolation)
        # --unshare-pid: Create new PID namespace (process isolation)
        # --unshare-ipc: Create new IPC namespace (shared memory isolation)
        # --unshare-uts: Create new UTS namespace (hostname isolation)
        # Note: We keep network shared (--share-net) for LLM API calls
        cmd.extend(
            [
                "--unshare-user",
                "--unshare-pid",
                "--unshare-ipc",
                "--unshare-uts",
                "--hostname",
                "sandbox",  # Prevent leaking host hostname
                "--share-net",  # Keep network for LLM API calls
            ]
        )

        # Process lifecycle
        cmd.extend(
            [
                "--die-with-parent",  # Kill sandbox when parent dies
            ]
        )

        # /proc access: Use bind-mount instead of fresh procfs
        # Fresh procfs (--proc /proc) fails in Docker because it requires
        # additional privileges. Bind-mounting works like nsjail did.
        # Note: In gVisor this is fine since gVisor handles all syscalls.
        cmd.extend(["--ro-bind", "/proc", "/proc"])

        # /dev: Create minimal /dev with essential devices
        cmd.extend(["--dev", "/dev"])

        # Read-only system mounts
        cmd.extend(
            [
                "--ro-bind",
                "/usr",
                "/usr",
                "--ro-bind",
                "/lib",
                "/lib",
                "--ro-bind",
                "/bin",
                "/bin",
            ]
        )

        # DNS, SSL, and hostname resolution
        cmd.extend(
            [
                "--ro-bind",
                "/etc/resolv.conf",
                "/etc/resolv.conf",
                "--ro-bind",
                "/etc/ssl",
                "/etc/ssl",
                "--ro-bind",
                "/etc/hosts",
                "/etc/hosts",
            ]
        )

        # glibc name resolution order (not present on musl-based systems like Alpine)
        if Path("/etc/nsswitch.conf").exists():
            cmd.extend(["--ro-bind", "/etc/nsswitch.conf", "/etc/nsswitch.conf"])

        # Timezone (often a symlink to /usr/share/zoneinfo/..., which is already mounted)
        if Path("/etc/localtime").exists():
            cmd.extend(["--ro-bind", "/etc/localtime", "/etc/localtime"])

        # Dynamic linker configuration (needed for Python shared libs)
        if Path("/etc/ld.so.cache").exists():
            cmd.extend(["--ro-bind", "/etc/ld.so.cache", "/etc/ld.so.cache"])

        # Agent code (read-only)
        # Mount code subdir (e.g., "project") to /agent/<subdir>
        cmd.extend(
            [
                "--ro-bind",
                f"{config.agent_dir}/{config.code_subdir}",
                f"/agent/{config.code_subdir}",
            ]
        )

        # Ephemeral /tmp (cleared after each task)
        cmd.extend(["--tmpfs", "/tmp"])

        # Writable home directory for subprocesses.
        # Must come before any /root/.claude or /root/.codex mounts so they overlay correctly.
        cmd.extend(["--tmpfs", "/root"])

        # Dynamic mounts: filesystem, system folders, and baked mounts
        if mounts:
            # Use configure_bwrap_mounts to generate mount args in correct order
            cmd.extend(configure_bwrap_mounts(mounts))
        else:
            # No mounts provided: create ephemeral tmpfs at /workspace
            cmd.extend(["--tmpfs", "/workspace"])

        # Add /lib64 if it exists (varies by distro)
        if Path("/lib64").exists():
            cmd.extend(["--ro-bind", "/lib64", "/lib64"])

        # Add /sbin if it exists
        if Path("/sbin").exists():
            cmd.extend(["--ro-bind", "/sbin", "/sbin"])

        # Mount /app/src if it exists (for editable/development installs of terminaluse)
        if Path("/app/src").exists():
            cmd.extend(["--ro-bind", "/app/src", "/app/src"])

        return cmd

    def _build_env_args(self, extra_env: dict[str, str] | None = None) -> list[str]:
        """Build environment variable arguments for bubblewrap.

        Environment variables are applied in order, with later values overriding earlier:
        1. Parent process env vars (includes user-defined vars from `tu env`)
        2. System env vars (PYTHONPATH, PATH, etc.)
        3. Platform env vars from EnvironmentVariables
        4. Invocation-specific extra_env

        Note: bubblewrap uses --clearenv to start with empty environment,
        then --setenv to add specific variables (unlike nsjail's --env KEY=VALUE).
        """
        env_args = ["--clearenv"]  # Start with clean environment

        # Collect all env vars in order (later values override earlier)
        all_env: dict[str, str] = {}

        # 1. Pass through all env vars from parent process
        # This includes user-defined vars set via `tu env add`
        for key, value in os.environ.items():
            all_env[key] = value

        # 2. System env vars (override parent values)
        # Uses system Python (installed via uv pip install --system in Dockerfile)
        system_env = {
            "PYTHONNOUSERSITE": "1",
            "PYTHONPATH": "/agent:/usr/local/lib/python3.12/site-packages",
            "PATH": SANDBOX_SYSTEM_PATH,
            "LD_LIBRARY_PATH": "/usr/local/lib:/usr/lib:/lib",
            "HOME": "/root",  # Needed for subprocesses with home-relative state
            # Disable io_uring to avoid hangs on certain kernel versions (6.6.57-6.6.59)
            # See: https://github.com/nodejs/node/issues/51875
            "UV_USE_IO_URING": "0",
            # Limit Node.js/V8 heap size to reduce memory usage for Claude CLI
            # Default V8 heap can grow to 1.5GB+; limit to 512MB to fit in constrained pods
            "NODE_OPTIONS": "--max-old-space-size=512",
            # Tell Claude CLI we're running inside a sandbox, allowing --dangerously-skip-permissions
            # to work even as root. This is the official escape hatch for sandboxed environments.
            # See: https://github.com/anthropics/claude-code/issues/9184
            "IS_SANDBOX": "1",
            # Claude Agent SDK: in streaming mode with hooks or SDK MCP servers, stdin is kept
            # open until the first `result` message is observed, to allow the bidirectional
            # control protocol (tool permissions + hooks). The SDK defaults this wait to 60s
            # and then closes stdin, which can break long-running sessions.
            #
            # Setting to infinity disables the timeout without preventing users/platform
            # from overriding it via env vars.
            "CLAUDE_CODE_STREAM_CLOSE_TIMEOUT": "300000",
        }
        all_env.update(system_env)

        # 3. Platform env vars from EnvironmentVariables (override parent values)
        from terminaluse.lib.environment_variables import EnvironmentVariables

        env_vars = EnvironmentVariables.refresh()
        for field_name, value in env_vars.model_dump().items():
            if value is not None:
                all_env[field_name] = str(value)  # Ensure string for bwrap --setenv

        # 4. Extra env vars for this specific invocation
        if extra_env:
            all_env.update(extra_env)

        # Convert to bubblewrap format: --setenv KEY VALUE
        for key, value in all_env.items():
            env_args.extend(["--setenv", key, value])

        return env_args

    def run(
        self,
        method: str,
        handler_ref: HandlerRef,
        params: BaseModel,
        mounts: list[Mount] | None = None,
        extra_env: dict[str, str] | None = None,
    ) -> SandboxResult:
        """
        Run a handler in a bubblewrap sandbox.

        Args:
            method: The JSON-RPC method name (e.g., "event/send")
            handler_ref: Reference to the handler to run
            params: The Pydantic params model to pass to the handler
            mounts: Pre-assembled list of mounts (filesystem, system folders, baked)
            extra_env: Additional environment variables for this invocation

        Returns:
            SandboxResult with execution outcome
        """
        config = self.config

        handler_name = f"{handler_ref.module}.{handler_ref.function}"
        mounts_count = len(mounts) if mounts else 0
        task_id = getattr(getattr(params, "task", None), "id", None)

        base_span_attributes: dict[str, Any] = {
            "sandbox.method": method,
            "sandbox.handler": handler_name,
            "sandbox.mounts_count": mounts_count,
        }
        if task_id:
            base_span_attributes["task.id"] = task_id

        with tracer.start_as_current_span(
            "sandbox.runner.prepare_payload",
            attributes=base_span_attributes,
        ) as prepare_payload_span:
            # Capture current W3C trace context for sandbox boundary propagation.
            trace_context: dict[str, str] = {}
            try:
                from opentelemetry.propagate import inject

                inject(trace_context)
                trace_context = {
                    key.lower(): value for key, value in trace_context.items() if key.lower() in TRACE_CONTEXT_HEADERS
                }
            except Exception:
                trace_context = {}

            payload = {
                "method": method,
                "params_type": type(params).__name__,
                "handler": handler_ref.to_dict(),
                "params": params.model_dump(mode="json"),
                "trace_context": trace_context,
            }
            prepare_payload_span.set_attribute("sandbox.payload.bytes", len(json.dumps(payload)))
            prepare_payload_span.set_attribute("sandbox.trace_context.headers", len(trace_context))

        with tracer.start_as_current_span(
            "sandbox.runner.build_command",
            attributes=base_span_attributes,
        ) as build_command_span:
            # Build the bubblewrap command
            bwrap_cmd = self._build_bwrap_command(mounts=mounts)
            bwrap_cmd.extend(self._build_env_args(extra_env))
            bwrap_cmd.extend(["--", "/usr/local/bin/python", "-m", "terminaluse.lib.sandbox.entrypoint"])

            # Note: Do not wrap with `timeout`. The sandboxed handler may run for
            # arbitrarily long (e.g., long-running Claude Code sessions).
            cmd = bwrap_cmd
            build_command_span.set_attribute("sandbox.command.arg_count", len(cmd))

        if config.verbose:
            logger.info(f"[SANDBOX VERBOSE] Running: {handler_ref.module}.{handler_ref.function}")
            logger.info(f"[SANDBOX VERBOSE] mounts: {len(mounts) if mounts else 0}")
            logger.info(f"[SANDBOX VERBOSE] Full command: {' '.join(cmd)}")
        else:
            logger.debug(f"Running sandboxed handler: {handler_ref.module}.{handler_ref.function}")
            logger.debug(f"Sandbox command: {' '.join(cmd)}")

        try:
            with tracer.start_as_current_span(
                "sandbox.runner.subprocess",
                attributes=base_span_attributes,
            ) as subprocess_span:
                t_start = time.perf_counter()
                process: subprocess.Popen[bytes] | None = None
                spawn_time_ns: int | None = None
                first_stdout_bytes = b""
                first_stderr_bytes = b""
                first_output_stream = ""
                first_output_wait_start = time.perf_counter()
                first_output_poll_iterations = 0
                first_output_select_timeouts = 0

                with tracer.start_as_current_span(
                    "sandbox.runner.subprocess_spawn",
                    attributes=base_span_attributes,
                ):
                    process = subprocess.Popen(
                        cmd,
                        stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                    )
                    spawn_time_ns = time.time_ns()

                with tracer.start_as_current_span(
                    "sandbox.runner.stdin_write",
                    attributes={
                        **base_span_attributes,
                        "sandbox.spawn_time_ns": spawn_time_ns or 0,
                    },
                ) as stdin_span:
                    if spawn_time_ns is not None:
                        payload[SANDBOX_SPAWN_TIME_KEY] = spawn_time_ns
                    payload_json = json.dumps(payload)
                    payload_bytes = payload_json.encode("utf-8")
                    stdin_span.set_attribute("sandbox.payload.bytes", len(payload_bytes))
                    if process.stdin is not None:
                        try:
                            bytes_written = process.stdin.write(payload_bytes)
                            process.stdin.flush()
                            stdin_span.set_attribute("sandbox.stdin.bytes_written", bytes_written or 0)
                        except BrokenPipeError:
                            stdin_span.set_attribute("sandbox.stdin.broken_pipe", True)
                        finally:
                            process.stdin.close()
                            # communicate() flushes stdin when present; avoid flushing a closed pipe.
                            process.stdin = None

                with tracer.start_as_current_span(
                    "sandbox.runner.wait_first_stdout",
                    attributes=base_span_attributes,
                ) as first_output_span:
                    streams = [stream for stream in (process.stdout, process.stderr) if stream is not None]
                    if streams:
                        while process.poll() is None:
                            first_output_poll_iterations += 1
                            readable, _, _ = select.select(streams, [], [], 0.05)
                            if not readable:
                                first_output_select_timeouts += 1
                                continue

                            for stream in readable:
                                try:
                                    first_chunk = os.read(stream.fileno(), 1)
                                except OSError:
                                    first_chunk = b""

                                if not first_chunk:
                                    try:
                                        streams.remove(stream)
                                    except ValueError:
                                        pass
                                    continue

                                if stream is process.stdout:
                                    first_stdout_bytes = first_chunk
                                    first_output_stream = "stdout"
                                else:
                                    first_stderr_bytes = first_chunk
                                    first_output_stream = "stderr"
                                break

                            if first_output_stream:
                                break

                            if not streams:
                                break

                    first_output_span.set_attribute("sandbox.first_output.received", bool(first_output_stream))
                    if first_output_stream:
                        first_output_span.set_attribute("sandbox.first_output.stream", first_output_stream)
                    first_output_span.set_attribute(
                        "sandbox.first_output.poll_iterations",
                        first_output_poll_iterations,
                    )
                    first_output_span.set_attribute(
                        "sandbox.first_output.select_timeouts",
                        first_output_select_timeouts,
                    )
                    first_output_span.set_attribute(
                        "sandbox.first_output.exited_before_output",
                        not first_output_stream and process.poll() is not None,
                    )
                    first_output_span.set_attribute(
                        "wait_ms",
                        int((time.perf_counter() - first_output_wait_start) * 1000),
                    )

                wait_exit_poll_iterations = 0
                wait_exit_select_timeouts = 0
                pre_exit_stdout_chunks: list[bytes] = []
                pre_exit_stderr_chunks: list[bytes] = []
                with tracer.start_as_current_span(
                    "sandbox.runner.wait_exit",
                    attributes=base_span_attributes,
                ) as wait_exit_span:
                    wait_for_process_start = time.perf_counter()
                    with tracer.start_as_current_span(
                        "sandbox.runner.wait_exit.wait_for_process",
                        attributes=base_span_attributes,
                    ) as wait_for_process_span:
                        while process.poll() is None:
                            wait_exit_poll_iterations += 1
                            readable_streams = [
                                stream
                                for stream in (process.stdout, process.stderr)
                                if stream is not None and not stream.closed
                            ]
                            if not readable_streams:
                                time.sleep(0.01)
                                continue

                            readable, _, _ = select.select(readable_streams, [], [], 0.05)
                            if not readable:
                                wait_exit_select_timeouts += 1
                                continue

                            for stream in readable:
                                try:
                                    chunk = os.read(stream.fileno(), 65536)
                                except OSError:
                                    chunk = b""

                                if not chunk:
                                    continue

                                if stream is process.stdout:
                                    pre_exit_stdout_chunks.append(chunk)
                                else:
                                    pre_exit_stderr_chunks.append(chunk)

                        wait_for_process_span.set_attribute(
                            "wait_ms",
                            int((time.perf_counter() - wait_for_process_start) * 1000),
                        )
                        wait_for_process_span.set_attribute(
                            "sandbox.wait_exit.poll_iterations",
                            wait_exit_poll_iterations,
                        )
                        wait_for_process_span.set_attribute(
                            "sandbox.wait_exit.select_timeouts",
                            wait_exit_select_timeouts,
                        )
                        wait_for_process_span.set_attribute(
                            "sandbox.wait_exit.pre_exit.stdout_bytes",
                            sum(len(chunk) for chunk in pre_exit_stdout_chunks),
                        )
                        wait_for_process_span.set_attribute(
                            "sandbox.wait_exit.pre_exit.stderr_bytes",
                            sum(len(chunk) for chunk in pre_exit_stderr_chunks),
                        )

                    with tracer.start_as_current_span(
                        "sandbox.runner.wait_exit.drain_after_exit",
                        attributes=base_span_attributes,
                    ) as drain_after_exit_span:
                        remaining_stdout, remaining_stderr = process.communicate()
                        drain_after_exit_span.set_attribute(
                            "sandbox.wait_exit.post_exit.stdout_bytes",
                            len(remaining_stdout or b""),
                        )
                        drain_after_exit_span.set_attribute(
                            "sandbox.wait_exit.post_exit.stderr_bytes",
                            len(remaining_stderr or b""),
                        )

                    wait_exit_span.set_attribute(
                        "sandbox.wait_exit.pre_exit.stdout_bytes",
                        sum(len(chunk) for chunk in pre_exit_stdout_chunks),
                    )
                    wait_exit_span.set_attribute(
                        "sandbox.wait_exit.pre_exit.stderr_bytes",
                        sum(len(chunk) for chunk in pre_exit_stderr_chunks),
                    )
                    wait_exit_span.set_attribute(
                        "sandbox.wait_exit.post_exit.stdout_bytes",
                        len(remaining_stdout or b""),
                    )
                    wait_exit_span.set_attribute(
                        "sandbox.wait_exit.post_exit.stderr_bytes",
                        len(remaining_stderr or b""),
                    )

                stdout_bytes = first_stdout_bytes + b"".join(pre_exit_stdout_chunks) + (remaining_stdout or b"")
                stderr_bytes = first_stderr_bytes + b"".join(pre_exit_stderr_chunks) + (remaining_stderr or b"")
                stdout_text = stdout_bytes.decode("utf-8", errors="replace")
                stderr_text = stderr_bytes.decode("utf-8", errors="replace")
                result = subprocess.CompletedProcess(
                    args=cmd,
                    returncode=process.returncode or 0,
                    stdout=stdout_text,
                    stderr=stderr_text,
                )

                t_end = time.perf_counter()
                duration = t_end - t_start
                logger.info(
                    f"[TIMING] subprocess_total: {duration * 1000:.0f}ms for {handler_ref.module}.{handler_ref.function}"
                )
                subprocess_span.set_attribute("sandbox.duration_ms", int(duration * 1000))
                subprocess_span.set_attribute("sandbox.exit_code", result.returncode)
                subprocess_span.set_attribute("sandbox.stdout_bytes", len(result.stdout.encode("utf-8")))
                subprocess_span.set_attribute("sandbox.stderr_bytes", len(result.stderr.encode("utf-8")))

            # Record metrics as OTEL span attributes
            status = "success" if result.returncode == 0 else "error"

            # Add attributes to current span for observability
            span = trace.get_current_span()
            if span.is_recording():
                span.set_attribute("sandbox.handler", handler_name)
                span.set_attribute("sandbox.method", method)
                span.set_attribute("sandbox.status", status)
                span.set_attribute("sandbox.duration_seconds", duration)
                span.set_attribute("sandbox.exit_code", result.returncode)
                if result.returncode != 0:
                    span.set_attribute("sandbox.error_type", "crash")

            # Log detailed info on failure
            if result.returncode != 0:
                signal_info = ""
                if result.returncode < 0:
                    import signal

                    try:
                        sig = signal.Signals(-result.returncode)
                        signal_info = f" (signal: {sig.name})"
                    except ValueError:
                        signal_info = f" (signal: {-result.returncode})"

                logger.error(f"Sandbox process failed: exit_code={result.returncode}{signal_info}")
                logger.error(f"Sandbox command was: {' '.join(cmd[:10])}...")  # First 10 args
                if result.stderr:
                    logger.error(f"Sandbox stderr: {result.stderr[:4000]}")
                if result.stdout:
                    logger.error(f"Sandbox stdout: {result.stdout[:1000]}")
            elif config.verbose:
                # Verbose logging even on success
                logger.info("[SANDBOX VERBOSE] Success, exit_code=0")
                if result.stderr:
                    logger.info(f"[SANDBOX VERBOSE] stderr: {result.stderr[:4000]}")
                if result.stdout:
                    logger.info(f"[SANDBOX VERBOSE] stdout: {result.stdout[:1000]}")

            return SandboxResult(
                success=result.returncode == 0,
                exit_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
                timed_out=False,
            )

        except Exception as e:
            logger.error(f"Error running sandboxed handler: {e}", exc_info=True)
            return SandboxResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr=str(e),
                timed_out=False,
            )


# Global runner instance
_runner: SandboxRunner | None = None


def get_sandbox_runner() -> SandboxRunner:
    """Get the global sandbox runner."""
    global _runner
    if _runner is None:
        _runner = SandboxRunner()
    return _runner


def reset_sandbox_runner() -> None:
    """Reset the global sandbox runner (primarily for testing)."""
    global _runner
    _runner = None


async def run_handler_sandboxed(
    method: str,
    handler_ref: HandlerRef,
    params: BaseModel,
    mounts: list[Mount] | None = None,
    extra_env: dict[str, str] | None = None,
    task_id: str | None = None,
) -> SandboxResult:
    """
    Async wrapper for running a handler in a bubblewrap sandbox.

    Uses asyncio.to_thread to avoid blocking the event loop.

    Args:
        method: The JSON-RPC method name (e.g., "event/send")
        handler_ref: Reference to the handler to run
        params: The Pydantic params model to pass to the handler
        mounts: Pre-assembled list of mounts (filesystem, system folders, baked)
        extra_env: Additional environment variables for this invocation
        task_id: Optional task ID for log correlation
    """
    runner = get_sandbox_runner()
    span_attributes: dict[str, Any] = {
        "sandbox.method": method,
    }
    if task_id:
        span_attributes["task.id"] = task_id

    with tracer.start_as_current_span(
        "sandbox.runner.execute_thread",
        attributes=span_attributes,
    ):
        result = await asyncio.to_thread(
            runner.run,
            method,
            handler_ref,
            params,
            mounts,
            extra_env,
        )

    # Send logs to Nucleus (fire-and-forget, don't block on errors)
    with tracer.start_as_current_span(
        "sandbox.runner.send_logs",
        attributes=span_attributes,
    ):
        await _send_logs_to_nucleus(method, result, task_id)

    return result


async def _send_logs_to_nucleus(
    method: str,
    result: SandboxResult,
    task_id: str | None,
) -> None:
    """
    Send captured stdout/stderr to Nucleus for log ingestion.

    This is a fire-and-forget operation - errors are logged but don't
    affect the handler result.
    """
    if not result.stdout and not result.stderr:
        return

    span_attributes: dict[str, Any] = {
        "sandbox.method": method,
        "sandbox.logs.stdout_bytes": len(result.stdout.encode("utf-8")),
        "sandbox.logs.stderr_bytes": len(result.stderr.encode("utf-8")),
    }
    if task_id:
        span_attributes["task.id"] = task_id

    with tracer.start_as_current_span(
        "sandbox.logs.send_to_nucleus",
        attributes=span_attributes,
    ) as span:
        try:
            from terminaluse.lib.logging import get_log_sender

            with tracer.start_as_current_span(
                "sandbox.logs.resolve_sender",
                attributes=span_attributes,
            ):
                log_sender = get_log_sender()

            span.set_attribute("sandbox.logs.sender_present", log_sender is not None)
            if log_sender:
                with tracer.start_as_current_span(
                    "sandbox.logs.transport_send",
                    attributes=span_attributes,
                ):
                    await log_sender.send_logs(
                        method=method,
                        stdout=result.stdout,
                        stderr=result.stderr,
                        task_id=task_id,
                    )
        except Exception as e:
            span.set_attribute("sandbox.logs.failed", True)
            logger.warning(f"Failed to send logs to Nucleus: {e}")
