# setup.py
from setuptools import setup

if __name__ == "__main__":
    # All configuration lives in setup.cfg
    setup()
