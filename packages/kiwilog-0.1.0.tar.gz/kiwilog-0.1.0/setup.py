from setuptools import setup, find_packages

setup(
    name="kiwi-log",
    version="0.1.0",
    description="Colored logging utility for Python",
    author="cCocoa",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)