from setuptools import setup, find_packages
import os

# Read the README file from the python-package directory
with open(os.path.join(os.path.dirname(__file__), "README.md"), "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements from the python-package requirements.txt
with open(os.path.join(os.path.dirname(__file__), "requirements.txt"), "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="sdui-python",
    version="1.0.7",
    author="leetao",
    author_email="leetao94cn@gmail.com",
    description="Python bindings for the SDUI Components Library",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/SuperKnowledge/sdui-components-library",
    packages=find_packages(),
    package_data={
        'sdui_python': [
            'bin/*.js',
            'dist/*.js',
            'dist/*.css',
            'dist/*.d.ts',
            'dist/refactor/*.d.ts',
        ],
    },
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'component-cli=sdui_python.cli:run_component_cli',
            'serialize-cli=sdui_python.cli:run_serialize_cli',
            'type-check-cli=sdui_python.cli:run_type_check_cli',
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: JavaScript",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    setup_requires=['wheel'],
)
