"""Text-to-speech CLI, MCP server, and Claude Code plugin."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "1.6.0"
