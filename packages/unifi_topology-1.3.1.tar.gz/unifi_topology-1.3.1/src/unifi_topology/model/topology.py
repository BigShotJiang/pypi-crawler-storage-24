"""Topology data classes and type definitions.

This module contains the core data structures for representing network topology.
The data classes themselves live in ``_topology_types`` (a cycle-free module) and
are re-exported here for public use.

For functions, see:
- classify: Device/client type classification
- edges: Edge building and topology construction
- clients: Client handling
- wan: WAN interface extraction
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ._topology_types import (  # noqa: F401
    ClientPortMap,
    Device,
    DeviceSource,
    Edge,
    PoeMap,
    PortInfo,
    PortMap,
    SpeedMap,
    TopologyResult,
    UplinkInfo,
    VlanMap,
    VpnTunnel,
    WanInfo,
    WanInterface,
)
from .helpers import normalize_mac

if TYPE_CHECKING:
    from .diff import TopologyDiff


def build_device_index(devices: Iterable[Device]) -> dict[str, str]:
    """Build MAC to name index for devices."""
    index: dict[str, str] = {}
    for device in devices:
        index[normalize_mac(device.mac)] = device.name
    return index


# --- Topology class for serialization and diff ---


@dataclass
class Topology:
    """A complete network topology snapshot for serialization and comparison."""

    devices: list[Device] = field(default_factory=list)
    clients: list[dict[str, object]] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    timestamp: str | None = None

    def to_dict(self) -> dict[str, object]:
        """Serialize topology to a JSON-compatible dictionary."""
        from .snapshot import client_to_dict, device_to_dict, edge_to_dict

        return {
            "version": 1,
            "timestamp": self.timestamp,
            "devices": [device_to_dict(d) for d in self.devices],
            "clients": [client_to_dict(c) for c in self.clients],  # type: ignore[arg-type]
            "edges": [edge_to_dict(e) for e in self.edges],
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> Topology:
        """Deserialize topology from a dictionary."""
        from .snapshot import client_from_dict, device_from_dict, edge_from_dict

        devices_data = data.get("devices", [])
        clients_data = data.get("clients", [])
        edges_data = data.get("edges", [])

        devices = [device_from_dict(d) for d in devices_data]  # type: ignore[arg-type]
        clients = [client_from_dict(c) for c in clients_data]  # type: ignore[arg-type]
        edges = [edge_from_dict(e) for e in edges_data]  # type: ignore[arg-type]

        timestamp = data.get("timestamp")
        return cls(
            devices=devices,
            clients=clients,
            edges=edges,
            timestamp=timestamp if isinstance(timestamp, str) else None,
        )

    def diff(self, other: Topology) -> TopologyDiff:
        """Compare this topology with another and return differences."""
        from .diff import compare_topologies

        return compare_topologies(
            old_devices=self.devices,
            new_devices=other.devices,
            old_clients=self.clients,  # type: ignore[arg-type]
            new_clients=other.clients,  # type: ignore[arg-type]
            old_edges=self.edges,
            new_edges=other.edges,
            old_timestamp=self.timestamp,
            new_timestamp=other.timestamp,
        )


__all__ = [
    # Data classes
    "Device",
    "Edge",
    "PortInfo",
    "TopologyResult",
    "Topology",
    "UplinkInfo",
    "VpnTunnel",
    "WanInfo",
    "WanInterface",
    # Type aliases
    "ClientPortMap",
    "DeviceSource",
    "PoeMap",
    "PortMap",
    "SpeedMap",
    "VlanMap",
    # Functions
    "build_device_index",
]
