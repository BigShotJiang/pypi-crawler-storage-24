import re
import sys
import traceback

def extract_variables_from_traceback(tb_list):
    """
    Analyzes a traceback list and returns a set of potential variable names 
    involved in the error.
    """
    variables = set()
    # Regex to find identifiers in code lines from traceback
    # Matches words that look like variables
    identifier_pattern = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")
    
    for item in tb_list:
        if isinstance(item, str):
            # It's a string line
            matches = identifier_pattern.findall(item)
            # Filter keywords or common generic words could be improved
            for m in matches:
                if len(m) > 1 and not m.startswith('_'): # Heuristic
                    variables.add(m)
    return list(variables)

# Enhanced inspection for pagination
_context_engine_slice_code = """
def _context_engine_slice(var_name, start=0, end=10):
    import json
    import pandas as pd
    try:
        # Support both simple names and expressions (e.g. df.columns, data['key'])
        if var_name in globals():
            obj = globals()[var_name]
        else:
            try:
                obj = eval(var_name)
            except Exception:
                return json.dumps({"error": f"Variable or expression '{var_name}' not found"})
        
        result = {"type": type(obj).__name__}
        
        if isinstance(obj, pd.DataFrame):
            # Safe slicing
            max_rows = len(obj)
            safe_end = min(end, max_rows)
            safe_start = min(start, safe_end)
            sliced = obj.iloc[safe_start:safe_end]
            result["data"] = sliced.to_dict(orient='records')
            result["pagination"] = {"total": max_rows, "start": safe_start, "end": safe_end}
            
        elif isinstance(obj, list):
            result["data"] = obj[start:end]
            result["pagination"] = {"total": len(obj), "start": start, "end": end}
            
        elif isinstance(obj, dict):
            keys = list(obj.keys())[start:end]
            result["data"] = {k: obj[k] for k in keys}
            result["pagination"] = {"total": len(obj), "start": start, "end": end}

        elif hasattr(obj, '__len__') and hasattr(obj, '__getitem__'):
            # numpy arrays, pandas Index, Series, etc.
            total = len(obj)
            safe_end = min(end, total)
            safe_start = min(start, safe_end)
            sliced = obj[safe_start:safe_end]
            result["data"] = list(sliced) if hasattr(sliced, '__iter__') else str(sliced)
            result["pagination"] = {"total": total, "start": safe_start, "end": safe_end}

        else:
            result["data"] = str(obj)[:2000]
             
        return json.dumps(result, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})

print(_context_engine_slice('{var_name}', {start}, {end}))
"""
