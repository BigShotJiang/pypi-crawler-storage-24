# Easybase

<div align="center">
  <img src="easybase.png" alt="easybase logo" width="350">
</div>

Easybase generates C bindings for Python projects. 

You can also add Easybase to your Makefile to have bindings generate automatically on every build. An example Makefile is included in this repository.
