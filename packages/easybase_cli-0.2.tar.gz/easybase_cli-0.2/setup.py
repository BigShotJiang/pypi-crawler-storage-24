from setuptools import find_packages, setup

setup(
    name="easybase_cli",
    version="0.2",
    packages=find_packages(),
    install_requires=[
        # Add dependencies here.
        # e.g. 'numpy>=1.11.1'
    ],
    entry_points={
        "console_scripts": [
            "eb=easybase.main:hello",
        ],
    },
)
