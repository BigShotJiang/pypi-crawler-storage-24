def hello():
    print("Hello from Easybase CLI!")
