pub mod openai;

use anyhow::Result;
use async_trait::async_trait;

use cangjie_core::config::{EmbeddingType, Settings};

// -- Embedder trait ----------------------------------------------------------

/// Distinguish query embedding from document embedding for asymmetric retrieval models.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EmbedKind {
    /// User query
    Query,
    /// Indexed document content
    Document,
}

/// Async embedding trait.
#[async_trait]
pub trait Embedder: Send + Sync {
    async fn embed(&self, texts: &[&str], kind: EmbedKind) -> Result<Vec<Vec<f32>>>;
    fn model_name(&self) -> &str;
}

// -- Factory -----------------------------------------------------------------

/// Create an embedder based on settings.
///
/// Returns `None` if embedding is disabled (`EmbeddingType::None`).
pub async fn create_embedder(settings: &Settings) -> Result<Option<Box<dyn Embedder>>> {
    match settings.embedding_type {
        EmbeddingType::None => Ok(None),
        EmbeddingType::OpenAI => {
            let api_key = settings
                .openai_api_key
                .as_deref()
                .ok_or_else(|| anyhow::anyhow!("OpenAI API key required for openai embedding"))?;
            Ok(Some(Box::new(openai::OpenAIEmbedder::new(
                settings,
                api_key,
                &settings.openai_model,
                &settings.openai_base_url,
            )?)))
        }
        EmbeddingType::Local => {
            #[cfg(feature = "local")]
            {
                let embedder = local::LocalEmbedder::new(&settings.local_model).await?;
                Ok(Some(Box::new(embedder)))
            }
            #[cfg(not(feature = "local"))]
            {
                anyhow::bail!("Local embedding requires the 'local' feature")
            }
        }
    }
}

#[cfg(feature = "local")]
pub mod local;

#[cfg(test)]
mod tests {
    use super::*;

    fn test_settings(embedding_type: EmbeddingType) -> Settings {
        Settings {
            embedding_type,
            local_model: "test-model".to_string(),
            data_dir: std::path::PathBuf::from("/tmp"),
            openai_base_url: "https://api.example.com".to_string(),
            openai_model: "test".to_string(),
            ..Settings::default()
        }
    }

    #[tokio::test]
    async fn test_create_embedder_none() {
        let settings = test_settings(EmbeddingType::None);
        let embedder = create_embedder(&settings).await.unwrap();
        assert!(embedder.is_none());
    }

    #[tokio::test]
    async fn test_create_embedder_openai_no_key() {
        let settings = test_settings(EmbeddingType::OpenAI);
        let result = create_embedder(&settings).await;
        assert!(result.is_err());
    }
}
