use crate::types::{
    CallHierarchyIncomingCall, CallHierarchyItem, CallHierarchyOutgoingCall, Diagnostic,
    DiagnosticSeverity, DocumentSymbol, DocumentSymbolResponse, GotoDefinitionResponse, Hover,
    HoverContents, Location, LocationLink, MarkedString, NumberOrString, SymbolKind,
    TypeHierarchyItem, WorkspaceEdit,
};
use crate::types::{CompletionItem, CompletionResponse};
use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::utils::uri_to_path;

// -- Output types ------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct LocationResult {
    pub file_path: String,
    pub line: u32,
    pub character: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub end_line: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub end_character: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DefinitionResult {
    pub locations: Vec<LocationResult>,
    pub count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ReferencesResult {
    pub locations: Vec<LocationResult>,
    pub count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct HoverOutput {
    pub content: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub range: Option<LocationResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CompletionItemOutput {
    pub label: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub kind: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub detail: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub documentation: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub insert_text: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CompletionResult {
    pub items: Vec<CompletionItemOutput>,
    pub count: usize,
    pub is_incomplete: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SymbolOutput {
    pub name: String,
    pub kind: String,
    pub line: u32,
    pub character: u32,
    pub end_line: u32,
    pub end_character: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub children: Option<Vec<SymbolOutput>>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SymbolsResult {
    pub symbols: Vec<SymbolOutput>,
    pub count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DiagnosticOutput {
    pub message: String,
    pub severity: String,
    pub line: u32,
    pub character: u32,
    pub end_line: u32,
    pub end_character: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub code: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub source: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DiagnosticsResult {
    pub diagnostics: Vec<DiagnosticOutput>,
    pub error_count: usize,
    pub warning_count: usize,
    pub info_count: usize,
    pub hint_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct WorkspaceSymbolOutput {
    pub name: String,
    pub kind: String,
    pub file_path: String,
    pub line: u32,
    pub character: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub container_name: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct WorkspaceSymbolResult {
    pub symbols: Vec<WorkspaceSymbolOutput>,
    pub count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CallHierarchyItemOutput {
    pub name: String,
    pub kind: String,
    pub file_path: String,
    pub line: u32,
    pub character: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub detail: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct IncomingCallOutput {
    pub from: CallHierarchyItemOutput,
    pub call_sites: Vec<LocationResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct IncomingCallsResult {
    pub calls: Vec<IncomingCallOutput>,
    pub count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct OutgoingCallOutput {
    pub to: CallHierarchyItemOutput,
    pub call_sites: Vec<LocationResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct OutgoingCallsResult {
    pub calls: Vec<OutgoingCallOutput>,
    pub count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TypeHierarchyItemOutput {
    pub name: String,
    pub kind: String,
    pub file_path: String,
    pub line: u32,
    pub character: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub detail: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TypeHierarchyResult {
    pub items: Vec<TypeHierarchyItemOutput>,
    pub count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct FileEdit {
    pub file_path: String,
    pub edits: Vec<TextEditOutput>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TextEditOutput {
    pub line: u32,
    pub character: u32,
    pub end_line: u32,
    pub end_character: u32,
    pub new_text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RenameResult {
    pub files: Vec<FileEdit>,
    pub file_count: usize,
    pub edit_count: usize,
}

// -- Helpers -----------------------------------------------------------------

fn severity_name(severity: Option<DiagnosticSeverity>) -> &'static str {
    match severity {
        Some(DiagnosticSeverity::ERROR) => "error",
        Some(DiagnosticSeverity::WARNING) => "warning",
        Some(DiagnosticSeverity::INFORMATION) => "information",
        Some(DiagnosticSeverity::HINT) => "hint",
        _ => "unknown",
    }
}

fn symbol_kind_name(kind: SymbolKind) -> &'static str {
    match kind {
        SymbolKind::FILE => "file",
        SymbolKind::MODULE => "module",
        SymbolKind::NAMESPACE => "namespace",
        SymbolKind::PACKAGE => "package",
        SymbolKind::CLASS => "class",
        SymbolKind::METHOD => "method",
        SymbolKind::PROPERTY => "property",
        SymbolKind::FIELD => "field",
        SymbolKind::CONSTRUCTOR => "constructor",
        SymbolKind::ENUM => "enum",
        SymbolKind::INTERFACE => "interface",
        SymbolKind::FUNCTION => "function",
        SymbolKind::VARIABLE => "variable",
        SymbolKind::CONSTANT => "constant",
        SymbolKind::STRING => "string",
        SymbolKind::NUMBER => "number",
        SymbolKind::BOOLEAN => "boolean",
        SymbolKind::ARRAY => "array",
        SymbolKind::OBJECT => "object",
        SymbolKind::KEY => "key",
        SymbolKind::NULL => "null",
        SymbolKind::ENUM_MEMBER => "enum member",
        SymbolKind::STRUCT => "struct",
        SymbolKind::EVENT => "event",
        SymbolKind::OPERATOR => "operator",
        SymbolKind::TYPE_PARAMETER => "type parameter",
        _ => "unknown",
    }
}

fn symbol_kind_name_by_number(kind: u32) -> &'static str {
    match kind {
        1 => "file",
        2 => "module",
        3 => "namespace",
        4 => "package",
        5 => "class",
        6 => "method",
        7 => "property",
        8 => "field",
        9 => "constructor",
        10 => "enum",
        11 => "interface",
        12 => "function",
        13 => "variable",
        14 => "constant",
        15 => "string",
        16 => "number",
        17 => "boolean",
        18 => "array",
        19 => "object",
        20 => "key",
        21 => "null",
        22 => "enum member",
        23 => "struct",
        24 => "event",
        25 => "operator",
        26 => "type parameter",
        _ => "unknown",
    }
}

fn validate_file_path(file_path: &str) -> Option<String> {
    let path = std::path::Path::new(file_path);
    if !path.exists() {
        return Some(format!("File not found: {file_path}"));
    }
    if !path.is_file() {
        return Some(format!("Not a file: {file_path}"));
    }
    if path.extension().and_then(|e| e.to_str()) != Some("cj") {
        return Some(format!(
            "Not a Cangjie file (expected .cj extension): {file_path}"
        ));
    }
    None
}

// -- Conversion helpers ------------------------------------------------------

fn location_to_result(loc: &Location) -> LocationResult {
    LocationResult {
        file_path: uri_to_path(loc.uri.as_str()).to_string_lossy().to_string(),
        line: loc.range.start.line + 1,
        character: loc.range.start.character + 1,
        end_line: Some(loc.range.end.line + 1),
        end_character: Some(loc.range.end.character + 1),
    }
}

fn location_link_to_result(link: &LocationLink) -> LocationResult {
    LocationResult {
        file_path: uri_to_path(link.target_uri.as_str())
            .to_string_lossy()
            .to_string(),
        line: link.target_selection_range.start.line + 1,
        character: link.target_selection_range.start.character + 1,
        end_line: Some(link.target_range.end.line + 1),
        end_character: Some(link.target_range.end.character + 1),
    }
}

fn convert_document_symbol(sym: &DocumentSymbol) -> SymbolOutput {
    let children = sym
        .children
        .as_ref()
        .map(|kids| kids.iter().map(convert_document_symbol).collect());

    SymbolOutput {
        name: sym.name.clone(),
        kind: symbol_kind_name(sym.kind).to_string(),
        line: sym.selection_range.start.line + 1,
        character: sym.selection_range.start.character + 1,
        end_line: sym.range.end.line + 1,
        end_character: sym.range.end.character + 1,
        children,
    }
}

fn extract_diagnostic_code(code: &NumberOrString) -> String {
    match code {
        NumberOrString::Number(n) => n.to_string(),
        NumberOrString::String(s) => s.clone(),
    }
}

fn completion_kind_name(kind: lsp_types::CompletionItemKind) -> &'static str {
    match kind {
        lsp_types::CompletionItemKind::TEXT => "text",
        lsp_types::CompletionItemKind::METHOD => "method",
        lsp_types::CompletionItemKind::FUNCTION => "function",
        lsp_types::CompletionItemKind::CONSTRUCTOR => "constructor",
        lsp_types::CompletionItemKind::FIELD => "field",
        lsp_types::CompletionItemKind::VARIABLE => "variable",
        lsp_types::CompletionItemKind::CLASS => "class",
        lsp_types::CompletionItemKind::INTERFACE => "interface",
        lsp_types::CompletionItemKind::MODULE => "module",
        lsp_types::CompletionItemKind::PROPERTY => "property",
        lsp_types::CompletionItemKind::UNIT => "unit",
        lsp_types::CompletionItemKind::VALUE => "value",
        lsp_types::CompletionItemKind::ENUM => "enum",
        lsp_types::CompletionItemKind::KEYWORD => "keyword",
        lsp_types::CompletionItemKind::SNIPPET => "snippet",
        lsp_types::CompletionItemKind::COLOR => "color",
        lsp_types::CompletionItemKind::FILE => "file",
        lsp_types::CompletionItemKind::REFERENCE => "reference",
        lsp_types::CompletionItemKind::FOLDER => "folder",
        lsp_types::CompletionItemKind::ENUM_MEMBER => "enum_member",
        lsp_types::CompletionItemKind::CONSTANT => "constant",
        lsp_types::CompletionItemKind::STRUCT => "struct",
        lsp_types::CompletionItemKind::EVENT => "event",
        lsp_types::CompletionItemKind::OPERATOR => "operator",
        lsp_types::CompletionItemKind::TYPE_PARAMETER => "type_parameter",
        _ => "unknown",
    }
}

// -- Tool execution functions ------------------------------------------------

pub fn process_definition(result: &Value) -> DefinitionResult {
    let response: Option<GotoDefinitionResponse> = serde_json::from_value(result.clone()).ok();

    let locations = match response {
        Some(GotoDefinitionResponse::Scalar(loc)) => vec![location_to_result(&loc)],
        Some(GotoDefinitionResponse::Array(locs)) => locs.iter().map(location_to_result).collect(),
        Some(GotoDefinitionResponse::Link(links)) => {
            links.iter().map(location_link_to_result).collect()
        }
        None => Vec::new(),
    };

    let count = locations.len();
    DefinitionResult { locations, count }
}

pub fn process_references(result: &Value) -> ReferencesResult {
    let locations: Vec<Location> = serde_json::from_value(result.clone()).unwrap_or_default();
    let locations: Vec<LocationResult> = locations.iter().map(location_to_result).collect();
    let count = locations.len();
    ReferencesResult { locations, count }
}

pub fn parse_hover(result: &Value, file_path: &str) -> Option<HoverOutput> {
    let hover: Hover = serde_json::from_value(result.clone()).ok()?;

    let content = match hover.contents {
        HoverContents::Scalar(marked) => match marked {
            MarkedString::String(s) => s,
            MarkedString::LanguageString(ls) => ls.value,
        },
        HoverContents::Markup(mc) => mc.value,
        HoverContents::Array(arr) => {
            let parts: Vec<String> = arr
                .into_iter()
                .map(|item| match item {
                    MarkedString::String(s) => s,
                    MarkedString::LanguageString(ls) => ls.value,
                })
                .collect();
            parts.join("\n\n")
        }
    };

    let range = hover.range.map(|r| LocationResult {
        file_path: file_path.to_string(),
        line: r.start.line + 1,
        character: r.start.character + 1,
        end_line: Some(r.end.line + 1),
        end_character: Some(r.end.character + 1),
    });

    Some(HoverOutput { content, range })
}

pub fn process_hover(result: &Value, file_path: &str) -> String {
    let output = parse_hover(result, file_path).unwrap_or_else(|| HoverOutput {
        content: "No hover information available".to_string(),
        range: None,
    });
    serde_json::to_string_pretty(&output).unwrap_or_else(|e| format!("Serialization error: {e}"))
}

pub fn process_symbols(result: &Value, _file_path: &str) -> SymbolsResult {
    let response: Option<DocumentSymbolResponse> = serde_json::from_value(result.clone()).ok();

    let symbols = match response {
        Some(DocumentSymbolResponse::Flat(sym_infos)) => sym_infos
            .iter()
            .map(|si| SymbolOutput {
                name: si.name.clone(),
                kind: symbol_kind_name(si.kind).to_string(),
                line: si.location.range.start.line + 1,
                character: si.location.range.start.character + 1,
                end_line: si.location.range.end.line + 1,
                end_character: si.location.range.end.character + 1,
                children: None,
            })
            .collect(),
        Some(DocumentSymbolResponse::Nested(doc_syms)) => {
            doc_syms.iter().map(convert_document_symbol).collect()
        }
        None => Vec::new(),
    };

    let count = symbols.len();
    SymbolsResult { symbols, count }
}

pub fn process_diagnostics(diags: &[Value]) -> DiagnosticsResult {
    let typed_diags: Vec<Diagnostic> = diags
        .iter()
        .filter_map(|v| serde_json::from_value(v.clone()).ok())
        .collect();

    let mut diagnostics = Vec::new();
    let mut error_count = 0;
    let mut warning_count = 0;
    let mut info_count = 0;
    let mut hint_count = 0;

    for diag in &typed_diags {
        match diag.severity {
            Some(DiagnosticSeverity::ERROR) => error_count += 1,
            Some(DiagnosticSeverity::WARNING) => warning_count += 1,
            Some(DiagnosticSeverity::INFORMATION) => info_count += 1,
            Some(DiagnosticSeverity::HINT) => hint_count += 1,
            _ => {}
        }

        diagnostics.push(DiagnosticOutput {
            message: diag.message.clone(),
            severity: severity_name(diag.severity).to_string(),
            line: diag.range.start.line + 1,
            character: diag.range.start.character + 1,
            end_line: diag.range.end.line + 1,
            end_character: diag.range.end.character + 1,
            code: diag.code.as_ref().map(extract_diagnostic_code),
            source: diag.source.clone(),
        });
    }

    DiagnosticsResult {
        diagnostics,
        error_count,
        warning_count,
        info_count,
        hint_count,
    }
}

pub fn process_workspace_symbols(result: &Value) -> WorkspaceSymbolResult {
    // workspace/symbol can return SymbolInformation[] or WorkspaceSymbol[]
    let empty = [];
    let arr: &[Value] = result.as_array().map(Vec::as_slice).unwrap_or(&empty);
    let symbols: Vec<WorkspaceSymbolOutput> = arr
        .iter()
        .filter_map(|item| {
            let name = item.get("name")?.as_str()?.to_string();
            let kind_num = item.get("kind")?.as_u64()? as u32;
            let kind = symbol_kind_name_by_number(kind_num).to_string();
            let container_name = item
                .get("containerName")
                .and_then(|v| v.as_str())
                .map(String::from);

            // SymbolInformation has location.uri + location.range
            let (file_path, line, character) = if let Some(loc) = item.get("location") {
                let uri = loc.get("uri")?.as_str()?;
                let range = loc.get("range")?;
                let start = range.get("start")?;
                (
                    uri_to_path(uri).to_string_lossy().to_string(),
                    start.get("line")?.as_u64()? as u32 + 1,
                    start.get("character")?.as_u64()? as u32 + 1,
                )
            } else {
                // WorkspaceSymbol has uri + range directly
                let uri = item.get("uri")?.as_str()?;
                let range = item.get("range")?;
                let start = range.get("start")?;
                (
                    uri_to_path(uri).to_string_lossy().to_string(),
                    start.get("line")?.as_u64()? as u32 + 1,
                    start.get("character")?.as_u64()? as u32 + 1,
                )
            };

            Some(WorkspaceSymbolOutput {
                name,
                kind,
                file_path,
                line,
                character,
                container_name,
            })
        })
        .collect();

    let count = symbols.len();
    WorkspaceSymbolResult { symbols, count }
}

fn convert_call_hierarchy_item(item: &CallHierarchyItem) -> CallHierarchyItemOutput {
    CallHierarchyItemOutput {
        name: item.name.clone(),
        kind: symbol_kind_name(item.kind).to_string(),
        file_path: uri_to_path(item.uri.as_str()).to_string_lossy().to_string(),
        line: item.selection_range.start.line + 1,
        character: item.selection_range.start.character + 1,
        detail: item.detail.clone(),
    }
}

pub fn process_incoming_calls(result: &Value) -> IncomingCallsResult {
    let calls: Vec<CallHierarchyIncomingCall> =
        serde_json::from_value(result.clone()).unwrap_or_default();
    let calls: Vec<IncomingCallOutput> = calls
        .iter()
        .map(|call| {
            let call_sites = call
                .from_ranges
                .iter()
                .map(|range| LocationResult {
                    file_path: uri_to_path(call.from.uri.as_str())
                        .to_string_lossy()
                        .to_string(),
                    line: range.start.line + 1,
                    character: range.start.character + 1,
                    end_line: Some(range.end.line + 1),
                    end_character: Some(range.end.character + 1),
                })
                .collect();
            IncomingCallOutput {
                from: convert_call_hierarchy_item(&call.from),
                call_sites,
            }
        })
        .collect();
    let count = calls.len();
    IncomingCallsResult { calls, count }
}

pub fn process_outgoing_calls(result: &Value) -> OutgoingCallsResult {
    let calls: Vec<CallHierarchyOutgoingCall> =
        serde_json::from_value(result.clone()).unwrap_or_default();
    let calls: Vec<OutgoingCallOutput> = calls
        .iter()
        .map(|call| {
            let call_sites = call
                .from_ranges
                .iter()
                .map(|range| LocationResult {
                    file_path: uri_to_path(call.to.uri.as_str())
                        .to_string_lossy()
                        .to_string(),
                    line: range.start.line + 1,
                    character: range.start.character + 1,
                    end_line: Some(range.end.line + 1),
                    end_character: Some(range.end.character + 1),
                })
                .collect();
            OutgoingCallOutput {
                to: convert_call_hierarchy_item(&call.to),
                call_sites,
            }
        })
        .collect();
    let count = calls.len();
    OutgoingCallsResult { calls, count }
}

fn convert_type_hierarchy_item(item: &TypeHierarchyItem) -> TypeHierarchyItemOutput {
    TypeHierarchyItemOutput {
        name: item.name.clone(),
        kind: symbol_kind_name(item.kind).to_string(),
        file_path: uri_to_path(item.uri.as_str()).to_string_lossy().to_string(),
        line: item.selection_range.start.line + 1,
        character: item.selection_range.start.character + 1,
        detail: item.detail.clone(),
    }
}

pub fn process_type_hierarchy(result: &Value) -> TypeHierarchyResult {
    let items: Vec<TypeHierarchyItem> = serde_json::from_value(result.clone()).unwrap_or_default();
    let items: Vec<TypeHierarchyItemOutput> =
        items.iter().map(convert_type_hierarchy_item).collect();
    let count = items.len();
    TypeHierarchyResult { items, count }
}

pub fn process_rename(result: &Value) -> RenameResult {
    let edit: Option<WorkspaceEdit> = serde_json::from_value(result.clone()).ok();
    let edit = match edit {
        Some(e) => e,
        None => return RenameResult::default(),
    };

    let mut files = Vec::new();
    let mut total_edits = 0;

    if let Some(changes) = edit.changes {
        for (uri, text_edits) in changes {
            let file_path = uri_to_path(uri.as_str()).to_string_lossy().to_string();
            let edits: Vec<TextEditOutput> = text_edits
                .iter()
                .map(|te| TextEditOutput {
                    line: te.range.start.line + 1,
                    character: te.range.start.character + 1,
                    end_line: te.range.end.line + 1,
                    end_character: te.range.end.character + 1,
                    new_text: te.new_text.clone(),
                })
                .collect();
            total_edits += edits.len();
            files.push(FileEdit { file_path, edits });
        }
    }

    let file_count = files.len();
    RenameResult {
        files,
        file_count,
        edit_count: total_edits,
    }
}

fn completion_item_to_output(item: &CompletionItem) -> CompletionItemOutput {
    let documentation = item.documentation.as_ref().map(|docs| match docs {
        lsp_types::Documentation::String(text) => text.clone(),
        lsp_types::Documentation::MarkupContent(content) => content.value.clone(),
    });

    CompletionItemOutput {
        label: item.label.clone(),
        kind: item.kind.map(completion_kind_name).map(str::to_string),
        detail: item.detail.clone(),
        documentation,
        insert_text: item.insert_text.clone(),
    }
}

pub fn process_completion(result: &Value) -> CompletionResult {
    let response: Option<CompletionResponse> = serde_json::from_value(result.clone()).ok();

    match response {
        Some(CompletionResponse::Array(items)) => CompletionResult {
            count: items.len(),
            items: items.iter().map(completion_item_to_output).collect(),
            is_incomplete: false,
        },
        Some(CompletionResponse::List(list)) => CompletionResult {
            count: list.items.len(),
            items: list.items.iter().map(completion_item_to_output).collect(),
            is_incomplete: list.is_incomplete,
        },
        None => CompletionResult::default(),
    }
}

pub fn get_validate_error(file_path: &str) -> Option<String> {
    validate_file_path(file_path)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn test_process_definition_array() {
        let result = json!([{
            "uri": "file:///test/main.cj",
            "range": {
                "start": {"line": 10, "character": 5},
                "end": {"line": 10, "character": 15}
            }
        }]);
        let def = process_definition(&result);
        assert_eq!(def.count, 1);
        assert_eq!(def.locations[0].line, 11);
        assert_eq!(def.locations[0].character, 6);
    }

    #[test]
    fn test_process_definition_single_object() {
        let result = json!({
            "uri": "file:///test/main.cj",
            "range": {
                "start": {"line": 0, "character": 0},
                "end": {"line": 0, "character": 10}
            }
        });
        let def = process_definition(&result);
        assert_eq!(def.count, 1);
    }

    #[test]
    fn test_process_definition_location_link() {
        let result = json!([{
            "targetUri": "file:///test/lib.cj",
            "targetRange": {
                "start": {"line": 5, "character": 0},
                "end": {"line": 5, "character": 20}
            },
            "targetSelectionRange": {
                "start": {"line": 5, "character": 0},
                "end": {"line": 5, "character": 20}
            }
        }]);
        let def = process_definition(&result);
        assert_eq!(def.count, 1);
        assert_eq!(def.locations[0].line, 6);
    }

    #[test]
    fn test_process_definition_empty() {
        let def = process_definition(&json!(null));
        assert_eq!(def.count, 0);
    }

    #[test]
    fn test_process_references() {
        let result = json!([
            {
                "uri": "file:///a.cj",
                "range": {"start": {"line": 1, "character": 0}, "end": {"line": 1, "character": 5}}
            },
            {
                "uri": "file:///b.cj",
                "range": {"start": {"line": 2, "character": 0}, "end": {"line": 2, "character": 5}}
            }
        ]);
        let refs = process_references(&result);
        assert_eq!(refs.count, 2);
    }

    #[test]
    fn test_process_hover_with_content() {
        let result = json!({
            "contents": {"kind": "markdown", "value": "func main()"},
            "range": {
                "start": {"line": 0, "character": 0},
                "end": {"line": 0, "character": 10}
            }
        });
        let output = process_hover(&result, "test.cj");
        let parsed: serde_json::Value = serde_json::from_str(&output).unwrap();
        assert_eq!(parsed["content"], "func main()");
    }

    #[test]
    fn test_process_hover_null() {
        let output = process_hover(&json!(null), "test.cj");
        let parsed: serde_json::Value = serde_json::from_str(&output).unwrap();
        assert!(parsed["content"].as_str().unwrap().contains("No hover"));
    }

    #[test]
    fn test_process_hover_string_contents() {
        let result = json!({"contents": "Simple hover text"});
        let output = process_hover(&result, "test.cj");
        let parsed: serde_json::Value = serde_json::from_str(&output).unwrap();
        assert_eq!(parsed["content"], "Simple hover text");
    }

    #[test]
    fn test_process_symbols() {
        let result = json!([{
            "name": "main",
            "kind": 12,
            "range": {
                "start": {"line": 0, "character": 0},
                "end": {"line": 5, "character": 1}
            },
            "selectionRange": {
                "start": {"line": 0, "character": 0},
                "end": {"line": 0, "character": 4}
            }
        }]);
        let syms = process_symbols(&result, "test.cj");
        assert_eq!(syms.count, 1);
        assert_eq!(syms.symbols[0].name, "main");
        assert_eq!(syms.symbols[0].kind, "function");
    }

    #[test]
    fn test_process_symbols_with_children() {
        let result = json!([{
            "name": "MyClass",
            "kind": 5,
            "range": {
                "start": {"line": 0, "character": 0},
                "end": {"line": 10, "character": 1}
            },
            "selectionRange": {
                "start": {"line": 0, "character": 6},
                "end": {"line": 0, "character": 13}
            },
            "children": [{
                "name": "method",
                "kind": 6,
                "range": {
                    "start": {"line": 2, "character": 4},
                    "end": {"line": 4, "character": 5}
                },
                "selectionRange": {
                    "start": {"line": 2, "character": 4},
                    "end": {"line": 2, "character": 10}
                }
            }]
        }]);
        let syms = process_symbols(&result, "test.cj");
        assert_eq!(syms.symbols[0].name, "MyClass");
        assert_eq!(syms.symbols[0].kind, "class");
        let children = syms.symbols[0].children.as_ref().unwrap();
        assert_eq!(children[0].name, "method");
        assert_eq!(children[0].kind, "method");
    }

    #[test]
    fn test_process_diagnostics() {
        let diags = vec![
            json!({
                "message": "Type mismatch",
                "severity": 1,
                "range": {
                    "start": {"line": 5, "character": 10},
                    "end": {"line": 5, "character": 20}
                },
                "code": "E001",
                "source": "cangjie"
            }),
            json!({
                "message": "Unused variable",
                "severity": 2,
                "range": {
                    "start": {"line": 3, "character": 0},
                    "end": {"line": 3, "character": 5}
                }
            }),
        ];
        let result = process_diagnostics(&diags);
        assert_eq!(result.error_count, 1);
        assert_eq!(result.warning_count, 1);
        assert_eq!(result.diagnostics.len(), 2);
        assert_eq!(result.diagnostics[0].severity, "error");
        assert_eq!(result.diagnostics[0].code, Some("E001".to_string()));
        assert_eq!(result.diagnostics[1].severity, "warning");
    }

    #[test]
    fn test_validate_file_path_nonexistent() {
        let result = validate_file_path("/nonexistent/path/file.cj");
        assert!(result.is_some());
        assert!(result.unwrap().contains("File not found"));
    }

    #[test]
    fn test_validate_file_path_not_cj_extension() {
        // Use a file that exists but isn't .cj
        let result = validate_file_path(env!("CARGO_MANIFEST_DIR"));
        assert!(result.is_some());
        // A directory is "not a file"
        assert!(result.unwrap().contains("Not a file"));
    }

    #[test]
    fn test_process_hover_array_contents() {
        let result = json!({
            "contents": [
                "First part",
                {"language": "cangjie", "value": "func foo()"}
            ]
        });
        let output = process_hover(&result, "test.cj");
        let parsed: serde_json::Value = serde_json::from_str(&output).unwrap();
        let content = parsed["content"].as_str().unwrap();
        assert!(content.contains("First part"));
        assert!(content.contains("func foo()"));
    }

    #[test]
    fn test_process_diagnostics_info_and_hint() {
        let diags = vec![
            json!({
                "message": "Info diagnostic",
                "severity": 3,
                "range": {
                    "start": {"line": 0, "character": 0},
                    "end": {"line": 0, "character": 5}
                }
            }),
            json!({
                "message": "Hint diagnostic",
                "severity": 4,
                "range": {
                    "start": {"line": 1, "character": 0},
                    "end": {"line": 1, "character": 5}
                }
            }),
        ];
        let result = process_diagnostics(&diags);
        assert_eq!(result.info_count, 1);
        assert_eq!(result.hint_count, 1);
        assert_eq!(result.diagnostics[0].severity, "information");
        assert_eq!(result.diagnostics[1].severity, "hint");
    }

    #[test]
    fn test_process_diagnostics_with_number_code() {
        let diags = vec![json!({
            "message": "Error",
            "severity": 1,
            "range": {
                "start": {"line": 0, "character": 0},
                "end": {"line": 0, "character": 1}
            },
            "code": 42
        })];
        let result = process_diagnostics(&diags);
        assert_eq!(result.diagnostics[0].code, Some("42".to_string()));
    }

    #[test]
    fn test_process_completion_list() {
        let result = json!({
            "isIncomplete": false,
            "items": [
                {
                    "label": "println",
                    "kind": 3,
                    "detail": "func println(value: String)",
                    "insertText": "println"
                }
            ]
        });
        let completion = process_completion(&result);
        assert_eq!(completion.count, 1);
        assert_eq!(completion.items[0].label, "println");
        assert_eq!(completion.items[0].kind.as_deref(), Some("function"));
    }

    #[test]
    fn test_process_symbols_flat_response() {
        let result = json!([{
            "name": "globalVar",
            "kind": 13,
            "location": {
                "uri": "file:///test.cj",
                "range": {
                    "start": {"line": 0, "character": 0},
                    "end": {"line": 0, "character": 10}
                }
            }
        }]);
        let syms = process_symbols(&result, "test.cj");
        // SymbolInformation has a `location` field → Flat variant
        assert_eq!(syms.count, 1);
        assert_eq!(syms.symbols[0].name, "globalVar");
        assert_eq!(syms.symbols[0].kind, "variable");
    }
}
