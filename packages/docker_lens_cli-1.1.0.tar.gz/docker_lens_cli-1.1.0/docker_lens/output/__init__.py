"""Docker Lens output module."""
