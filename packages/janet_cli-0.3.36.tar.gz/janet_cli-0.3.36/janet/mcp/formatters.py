"""Format API responses into human-readable text for LLM consumption."""

from typing import Dict, List


def format_workspace_context(
    user_email: str,
    org_name: str,
    org_id: str,
    projects: List[Dict],
    projects_columns: Dict[str, List[Dict]],
    projects_members: Dict[str, List[Dict]],
    user_name: str = "",
) -> str:
    """Format workspace context as readable text."""
    user_display = f"{user_name} ({user_email})" if user_name else user_email
    lines = [
        f"# Janet.ai Workspace",
        f"- User: {user_display}",
        f"- Organization: {org_name} ({org_id})",
        f"- Projects: {len(projects)}",
        "",
    ]

    for p in projects:
        pid = p["id"]
        key = p.get("project_identifier", "?")
        name = p.get("project_name", "?")
        count = p.get("ticket_count", 0)

        lines.append(f"## {key}: {name} ({count} tickets)")

        columns = projects_columns.get(pid, [])
        if columns:
            statuses = [c.get("status_value", "?") for c in columns]
            lines.append(f"  Statuses: {', '.join(statuses)}")

        members = projects_members.get(pid, [])
        active = [m for m in members if m.get("status") == "active"]
        if active:
            member_strs = [
                f"{m.get('fullName', '?')} ({m.get('userEmail', '?')})"
                for m in active[:20]
            ]
            lines.append(f"  Members: {', '.join(member_strs)}")
            if len(active) > 20:
                lines.append(f"  ... and {len(active) - 20} more")

        lines.append("")

    return "\n".join(lines)


def format_ticket(ticket: Dict) -> str:
    """Format a single ticket with full details."""
    key = ticket.get("ticket_key", "")
    if not key:
        proj = ticket.get("project_identifier", "?")
        num = ticket.get("ticket_identifier", "?")
        key = f"{proj}-{num}"

    lines = [f"# {key}: {ticket.get('title', 'Untitled')}"]

    status = ticket.get("status", "?")
    priority = ticket.get("priority", "?")
    issue_type = ticket.get("issue_type", "?")
    lines.append(f"- Status: {status}")
    lines.append(f"- Priority: {priority}")
    lines.append(f"- Type: {issue_type}")

    assignees = ticket.get("assignees", [])
    if assignees:
        if isinstance(assignees[0], dict):
            emails = [a.get("email", a.get("userEmail", "?")) for a in assignees]
        else:
            emails = assignees
        lines.append(f"- Assignees: {', '.join(emails)}")

    labels = ticket.get("labels", []) or ticket.get("tags", [])
    if labels:
        if isinstance(labels[0], dict):
            label_names = [l.get("name", "?") for l in labels]
        else:
            label_names = labels
        lines.append(f"- Labels: {', '.join(label_names)}")

    due = ticket.get("due_date")
    if due:
        lines.append(f"- Due: {due}")

    sprint = ticket.get("sprint")
    if sprint:
        sname = sprint.get("sprint_name", "?") if isinstance(sprint, dict) else sprint
        lines.append(f"- Sprint: {sname}")

    desc = ticket.get("description", "")
    if desc:
        lines.append(f"\n## Description\n{desc}")

    # Child tasks
    child_tasks = ticket.get("childTasks", []) or ticket.get("child_tasks", [])
    if child_tasks:
        lines.append(f"\n## Child Tasks ({len(child_tasks)})")
        for ct in child_tasks:
            ct_id = ct.get("fullIdentifier", "?")
            ct_title = ct.get("title", "?")
            ct_status = ct.get("status", "?")
            ct_assignee = ct.get("assignee", "")
            assignee_str = f" @{ct_assignee}" if ct_assignee else ""
            lines.append(f"- {ct_id}: {ct_title} [{ct_status}]{assignee_str}")

    # Comments
    comments = ticket.get("comments", [])
    if comments:
        lines.append(f"\n## Comments ({len(comments)})")
        for c in comments:
            author = c.get("created_by", c.get("author_email", c.get("author", "?")))
            created = c.get("created_at", "")[:10]
            content = c.get("content", "")
            lines.append(f"- {author} ({created}): {content}")

    return "\n".join(lines)


def format_ticket_list(
    tickets: List[Dict],
    total_count: int = 0,
    all_tickets: List[Dict] = None,
) -> str:
    """Format a list of tickets as a concise table."""
    if not tickets:
        return "No tickets found."

    # Status breakdown from ALL tickets (not just displayed page)
    count_source = all_tickets if all_tickets else tickets
    status_counts: Dict[str, int] = {}
    for t in count_source:
        s = t.get("status", "Unknown")
        status_counts[s] = status_counts.get(s, 0) + 1
    breakdown = ", ".join(f"{count} {status}" for status, count in status_counts.items())

    total = total_count or len(count_source)
    if total > len(tickets):
        header = f"{total} total ticket(s) ({breakdown}), showing {len(tickets)} most recent:"
    else:
        header = f"Found {len(tickets)} ticket(s) ({breakdown}):"

    lines = [header, ""]
    for t in tickets:
        key = t.get("ticket_key", "")
        if not key:
            proj = t.get("project_identifier", "?")
            num = t.get("ticket_identifier", "?")
            key = f"{proj}-{num}"

        title = t.get("title", "Untitled")
        status = t.get("status", "?")
        priority = t.get("priority", "?")

        assignees = t.get("assignees", [])
        if assignees:
            if isinstance(assignees[0], dict):
                assignee_str = ", ".join(a.get("email", a.get("userEmail", "?")) for a in assignees)
            else:
                assignee_str = ", ".join(assignees)
        else:
            assignee_str = "unassigned"

        lines.append(f"- {key}: {title} [{status}] P:{priority} @{assignee_str}")

    return "\n".join(lines)


def format_sprint_list(sprints: List[Dict]) -> str:
    """Format a list of sprints."""
    if not sprints:
        return "No sprints found."

    lines = [f"Found {len(sprints)} sprint(s):\n"]
    for s in sprints:
        name = s.get("sprint_name", "?")
        status = s.get("status", "?")
        start = (s.get("start_date") or "")[:10]
        end = (s.get("end_date") or "")[:10]
        lines.append(f"- {name} [{status}] {start} to {end}")

    return "\n".join(lines)


def format_child_tasks(child_tasks: List[Dict]) -> str:
    """Format a list of child tasks."""
    if not child_tasks:
        return "No child tasks found."

    lines = [f"Found {len(child_tasks)} child task(s):\n"]
    for ct in child_tasks:
        ct_id = ct.get("fullIdentifier", "?")
        title = ct.get("title", "?")
        status = ct.get("status", "?")
        priority = ct.get("priority", "")
        assignee = ct.get("assignee", "")
        p_str = f" P:{priority}" if priority else ""
        a_str = f" @{assignee}" if assignee else ""
        lines.append(f"- {ct_id}: {title} [{status}]{p_str}{a_str}")

        # Sub-tasks
        sub_tasks = ct.get("subTasks", []) or ct.get("sub_tasks", [])
        for st in sub_tasks:
            st_id = st.get("fullIdentifier", "?")
            st_title = st.get("title", "?")
            st_status = st.get("status", "?")
            lines.append(f"  - {st_id}: {st_title} [{st_status}]")

    return "\n".join(lines)


def format_comments(comments: List[Dict]) -> str:
    """Format a list of comments."""
    if not comments:
        return "No comments found."

    lines = [f"Found {len(comments)} comment(s):\n"]
    for c in comments:
        cid = c.get("id", "?")
        author = c.get("created_by", c.get("author_email", c.get("author", "?")))
        created = (c.get("created_at") or "")[:10]
        content = c.get("content", "")
        lines.append(f"- [{cid[:8]}] {author} ({created}): {content}")

    return "\n".join(lines)
