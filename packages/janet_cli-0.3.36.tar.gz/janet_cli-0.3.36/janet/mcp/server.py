"""Janet AI MCP Server — exposes Janet.ai actions via Model Context Protocol."""

import asyncio
import json
import os
from datetime import date, timedelta
from typing import Any, Dict, List

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from janet.config.manager import ConfigManager
from janet.mcp.resolve import (
    ResolutionError,
    resolve_assignees,
    resolve_child_task_key,
    resolve_project,
    resolve_sprint,
    resolve_status,
    resolve_sub_task_key,
    resolve_ticket_key,
    resolve_ticket_keys_batch,
)
from janet.mcp import formatters
from janet.utils.errors import AuthenticationError, NetworkError

server = Server("janet-ai")


_cached_config = None


def _get_config() -> ConfigManager:
    global _cached_config
    if _cached_config is not None:
        return _cached_config

    # API key mode — no config file or OAuth needed
    api_key = os.environ.get("JANET_API_KEY")
    if api_key:
        from janet.mcp.auth import ApiKeyConfig
        config = ApiKeyConfig(api_key)
        if not config.has_organization():
            raise AuthenticationError(
                "API key is invalid or has no organization access. "
                "Generate a new key at janet.ai → MCP settings."
            )
        _cached_config = config
        return config

    # OAuth mode — requires janet login
    cm = ConfigManager()
    if not cm.is_authenticated():
        raise AuthenticationError("Not authenticated. Run `janet login` in your terminal first.")
    if not cm.has_organization():
        raise AuthenticationError(
            "No organization selected. Run `janet login` or `janet org select <org_id>` first."
        )
    _cached_config = cm
    return cm


# ── Tool definitions ────────────────────────────────────────────────────────

TOOLS: List[Tool] = [
    Tool(
        name="get_workspace_context",
        description=(
            "Get the current Janet.ai workspace context: authenticated user (name + email), "
            "organization, and all projects with their valid statuses and members. "
            "ALWAYS call this first before any other tool — you need project keys and valid "
            "status names to use the other tools."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="list_tickets",
        description=(
            "Search and list tickets in a project. This is your primary tool for finding tickets. "
            "Use 'keyword' to search by text across titles, descriptions, and comments. "
            "Use 'assignees' to filter by who's working on them (use ['me'] for the current user). "
            "Combine filters to narrow results. If the user asks about a ticket but doesn't give "
            "a ticket key, search here first, then use get_ticket for full details."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_key": {
                    "type": "string",
                    "description": "Project identifier like 'PROJ' or 'MAIN'",
                },
                "status": {
                    "type": "string",
                    "description": "Filter to a specific status column (e.g. 'In Progress')",
                },
                "assignees": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by assignee emails, names, or 'me' for current user",
                },
                "keyword": {
                    "type": "string",
                    "description": "Search text across ticket title, description, and comments",
                },
                "priorities": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Low", "Medium", "High", "Critical"]},
                    "description": "Filter by priority levels",
                },
                "issue_types": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Task", "Bug", "Story", "Epic"]},
                    "description": "Filter by issue types",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by tag labels",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max tickets to return (default 100)",
                    "default": 100,
                },
            },
            "required": ["project_key"],
        },
    ),
    Tool(
        name="get_ticket",
        description=(
            "Get full details of a specific ticket by its key (e.g. PROJ-123). "
            "Returns description, comments, child tasks, assignees, and all metadata. "
            "Use this after finding a ticket via list_tickets, or when the user provides "
            "a specific ticket key."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {
                    "type": "string",
                    "description": "Ticket key like 'PROJ-123' or a UUID",
                },
            },
            "required": ["ticket_key"],
        },
    ),
    Tool(
        name="create_ticket",
        description=(
            "Create a new ticket. Requires project_key and title at minimum. "
            "Status defaults to the first column if not specified. "
            "You can assign to the current user with assignees=['me']. "
            "Call get_workspace_context first to know valid project keys and statuses."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_key": {
                    "type": "string",
                    "description": "Project identifier like 'PROJ'",
                },
                "title": {"type": "string", "description": "Ticket title"},
                "description": {"type": "string", "description": "Ticket description (markdown)"},
                "status": {
                    "type": "string",
                    "description": "Status column (validated against project statuses)",
                },
                "priority": {
                    "type": "string",
                    "enum": ["Low", "Medium", "High", "Critical"],
                    "description": "Ticket priority",
                },
                "issue_type": {
                    "type": "string",
                    "enum": ["Task", "Bug", "Story", "Epic"],
                    "description": "Ticket type",
                },
                "assignees": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Assignee emails, names, or 'me'",
                },
                "labels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Tag labels",
                },
                "sprint": {
                    "type": "string",
                    "description": "Sprint name to add the ticket to",
                },
            },
            "required": ["project_key", "title"],
        },
    ),
    Tool(
        name="update_tickets",
        description=(
            "Update one or more tickets. Pass an array of updates — each specifies a ticket_key "
            "and the fields to change. Use this for status changes, reassignment, priority changes, "
            "etc. Accepts batch updates in a single call for efficiency."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "updates": {
                    "type": "array",
                    "description": "Array of updates to apply",
                    "items": {
                        "type": "object",
                        "properties": {
                            "ticket_key": {
                                "type": "string",
                                "description": "Ticket key like 'PROJ-123'",
                            },
                            "title": {"type": "string"},
                            "description": {"type": "string"},
                            "status": {"type": "string"},
                            "priority": {
                                "type": "string",
                                "enum": ["Low", "Medium", "High", "Critical"],
                            },
                            "issue_type": {
                                "type": "string",
                                "enum": ["Task", "Bug", "Story", "Epic"],
                            },
                            "assignees": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "labels": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "due_date": {
                                "type": "string",
                                "description": "ISO date (YYYY-MM-DD)",
                            },
                        },
                        "required": ["ticket_key"],
                    },
                },
            },
            "required": ["updates"],
        },
    ),
    Tool(
        name="move_ticket",
        description=(
            "Reposition a ticket within its status column or move it to a different column. "
            "Supports: 'top', 'bottom', 'before:<KEY>', 'after:<KEY>'. "
            "Can also reorder multiple tickets or sort a column by a field. "
            "Add 'sprint' to position within a sprint column instead of the kanban column."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {
                    "type": "string",
                    "description": "Ticket key like 'PROJ-123' (for top/bottom/before/after)",
                },
                "position": {
                    "type": "string",
                    "description": (
                        "One of: 'top', 'bottom', 'before:PROJ-456', 'after:PROJ-456', "
                        "'reorder', 'sort'"
                    ),
                },
                "status": {
                    "type": "string",
                    "description": "Target status column. Required for reorder/sort.",
                },
                "sprint": {
                    "type": "string",
                    "description": "Sprint name. If provided, positions within this sprint's column instead of the kanban column.",
                },
                "ticket_keys": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ticket keys in desired order (for 'reorder' position only)",
                },
                "sort_by": {
                    "type": "string",
                    "enum": ["priority", "assignee", "type", "created", "updated", "due_date"],
                    "description": "Field to sort by (for 'sort' position only)",
                },
                "reverse": {
                    "type": "boolean",
                    "description": "Reverse sort order (for 'sort' position only)",
                },
                "project_key": {
                    "type": "string",
                    "description": "Project key (required for reorder/sort)",
                },
            },
            "required": ["position"],
        },
    ),
    Tool(
        name="manage_child_task",
        description="Create, update, or delete a child task on a ticket. Use list_child_tasks first to see existing child tasks.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "update", "delete"],
                    "description": "Action to perform",
                },
                "ticket_key": {
                    "type": "string",
                    "description": "Parent ticket key like 'PROJ-123' (required for create)",
                },
                "child_task_key": {
                    "type": "string",
                    "description": "Child task key like 'PROJ-123A' (required for update/delete)",
                },
                "title": {"type": "string", "description": "Title (required for create)"},
                "description": {"type": "string"},
                "status": {"type": "string"},
                "priority": {
                    "type": "string",
                    "enum": ["Low", "Medium", "High", "Critical"],
                },
                "assignee": {"type": "string", "description": "Assignee email or name"},
                "due_date": {"type": "string", "description": "ISO date (YYYY-MM-DD)"},
            },
            "required": ["action"],
        },
    ),
    Tool(
        name="manage_sub_task",
        description="Create, update, or delete a sub-task on a child task. Use list_child_tasks first to see existing sub-tasks.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "update", "delete"],
                    "description": "Action to perform",
                },
                "child_task_key": {
                    "type": "string",
                    "description": "Parent child task key like 'PROJ-123A' (required for create)",
                },
                "sub_task_key": {
                    "type": "string",
                    "description": "Sub-task key like 'PROJ-123A-1' (required for update/delete)",
                },
                "title": {"type": "string", "description": "Title (required for create)"},
                "status": {"type": "string"},
                "priority": {
                    "type": "string",
                    "enum": ["Low", "Medium", "High", "Critical"],
                },
                "assignee": {"type": "string", "description": "Assignee email or name"},
            },
            "required": ["action"],
        },
    ),
    Tool(
        name="manage_comment",
        description="Add, edit, or delete a comment on a ticket. Use list_comments first to see existing comments and get comment IDs for edit/delete.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "edit", "delete"],
                    "description": "Action to perform",
                },
                "ticket_key": {"type": "string", "description": "Ticket key like 'PROJ-123'"},
                "text": {
                    "type": "string",
                    "description": "Comment content (required for add/edit)",
                },
                "comment_id": {
                    "type": "string",
                    "description": "Comment UUID (required for edit/delete)",
                },
            },
            "required": ["action", "ticket_key"],
        },
    ),
    Tool(
        name="list_sprints",
        description="List sprints for a project with their status, dates, and ticket counts.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_key": {
                    "type": "string",
                    "description": "Project identifier like 'PROJ'",
                },
            },
            "required": ["project_key"],
        },
    ),
    Tool(
        name="manage_sprint",
        description=(
            "Create or update a sprint. When creating, start date defaults to today "
            "and end date defaults to start + 14 days."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "update"],
                    "description": "Action to perform",
                },
                "project_key": {"type": "string", "description": "Project identifier"},
                "sprint_name": {"type": "string", "description": "Sprint name"},
                "new_name": {"type": "string", "description": "New name (for rename on update)"},
                "start_date": {"type": "string", "description": "Start date (YYYY-MM-DD)"},
                "end_date": {"type": "string", "description": "End date (YYYY-MM-DD)"},
                "description": {"type": "string"},
                "status": {
                    "type": "string",
                    "enum": ["planned", "active", "completed"],
                    "description": "Sprint status (update only)",
                },
            },
            "required": ["action", "project_key", "sprint_name"],
        },
    ),
    Tool(
        name="manage_sprint_tickets",
        description="Add, remove, or reorder tickets in a sprint. For reorder, pass ticket_keys in the desired order and specify the status column.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "remove", "reorder"],
                    "description": "Action to perform",
                },
                "sprint_name": {"type": "string", "description": "Sprint name"},
                "project_key": {"type": "string", "description": "Project identifier"},
                "ticket_keys": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ticket keys in desired order (for reorder) or to add/remove",
                },
                "status": {
                    "type": "string",
                    "description": "Status column to reorder within (required for reorder)",
                },
            },
            "required": ["action", "sprint_name", "project_key", "ticket_keys"],
        },
    ),
    Tool(
        name="list_child_tasks",
        description="List all child tasks and their sub-tasks for a ticket. Shows status, priority, and assignee for each. Use this before managing child tasks or sub-tasks.",
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {"type": "string", "description": "Ticket key like 'PROJ-123'"},
            },
            "required": ["ticket_key"],
        },
    ),
    Tool(
        name="list_comments",
        description="List all comments on a ticket with author, date, and content. Returns comment IDs needed for edit/delete operations.",
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {"type": "string", "description": "Ticket key like 'PROJ-123'"},
            },
            "required": ["ticket_key"],
        },
    ),
    Tool(
        name="list_sprint_tickets",
        description="List all tickets in a specific sprint. Use list_sprints first to find the sprint name.",
        inputSchema={
            "type": "object",
            "properties": {
                "sprint_name": {"type": "string", "description": "Sprint name"},
                "project_key": {"type": "string", "description": "Project identifier"},
            },
            "required": ["sprint_name", "project_key"],
        },
    ),
]


@server.list_tools()
async def list_tools() -> List[Tool]:
    return TOOLS


# ── Tool handlers ───────────────────────────────────────────────────────────


def _resolve_user_email(cm: ConfigManager) -> str:
    """Get the current user's email, falling back to API if not in config."""
    config = cm.get()
    email = config.auth.user_email if config.auth else None
    if email:
        return email
    profile = _fetch_user_profile(cm)
    return profile["email"]


def _resolve_assignee_filter(
    assignees: List[str], project_id: str, cm: ConfigManager
) -> List[str]:
    """Resolve assignee filter values — handles 'me' and name lookups."""
    resolved = []
    for a in assignees:
        if a.strip().lower() in ("me", "myself"):
            email = _resolve_user_email(cm)
            if not email:
                raise ResolutionError("Cannot resolve 'me' - user email not found.")
            resolved.append(email)
        else:
            resolved.append(a)
    # For non-"me" values, try to resolve names to emails
    needs_resolve = [r for r in resolved if "@" not in r and r.lower() != "unassigned"]
    if needs_resolve:
        resolved_all = resolve_assignees(resolved, project_id, cm)
        return resolved_all
    return resolved


def _text(content: str) -> List[TextContent]:
    return [TextContent(type="text", text=content)]


def _fetch_user_profile(cm: ConfigManager) -> Dict:
    """Fetch user profile from API. Returns dict with email and name."""
    from janet.api.client import APIClient

    try:
        client = APIClient(cm)
        profile = client.get("/api/v1/user/profile", include_org=True)
        user = profile.get("user", {})
        return {
            "email": user.get("email", ""),
            "name": user.get("name", user.get("fullName", "")),
        }
    except Exception:
        return {"email": "", "name": ""}


_workspace_cache: Dict[str, Any] | None = None


def _handle_get_workspace_context(args: Dict) -> str:
    global _workspace_cache
    if _workspace_cache is not None:
        return _workspace_cache

    from janet.api.projects import ProjectAPI
    from concurrent.futures import ThreadPoolExecutor

    cm = _get_config()
    config = cm.get()
    user_email = config.auth.user_email or ""
    user_name = ""

    # Fallback: fetch from API if not in stored config
    if not user_email:
        profile = _fetch_user_profile(cm)
        user_email = profile["email"] or "unknown"
        user_name = profile["name"]

    org = config.selected_organization
    org_name = org.name if org else "unknown"
    org_id = org.id if org else "unknown"

    project_api = ProjectAPI(cm)
    projects = project_api.list_projects()

    # Fetch columns + members in parallel (2 calls per project, all at once)
    projects_columns: Dict[str, list] = {}
    projects_members: Dict[str, list] = {}

    def fetch_columns(pid: str):
        try:
            return pid, project_api.get_project_columns(pid)
        except Exception:
            return pid, []

    def fetch_members(pid: str):
        try:
            return pid, project_api.list_project_members(pid)
        except Exception:
            return pid, []

    pids = [p["id"] for p in projects]
    with ThreadPoolExecutor(max_workers=10) as pool:
        col_futures = pool.map(fetch_columns, pids)
        mem_futures = pool.map(fetch_members, pids)
        for pid, cols in col_futures:
            projects_columns[pid] = cols
        for pid, mems in mem_futures:
            projects_members[pid] = mems

    result = formatters.format_workspace_context(
        user_email, org_name, org_id, projects, projects_columns, projects_members,
        user_name=user_name,
    )
    _workspace_cache = result
    return result


def _handle_list_tickets(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]

    statuses = [args["status"]] if args.get("status") else None
    limit = args.get("limit", 100)

    # Resolve assignee filter — handle "me"
    assignees = args.get("assignees")
    if assignees:
        assignees = _resolve_assignee_filter(assignees, project_id, cm)

    ticket_api = TicketAPI(cm)
    # Default to sorting by last_updated when any filter is active
    has_filter = any([assignees, args.get("keyword"), args.get("priorities"),
                      args.get("issue_types"), args.get("tags"), statuses])
    filter_kwargs = dict(
        statuses=statuses,
        assignees=assignees,
        keyword=args.get("keyword"),
        priorities=args.get("priorities"),
        issue_types=args.get("issue_types"),
        tags=args.get("tags"),
        order_by="last_updated" if has_filter else None,
    )

    # Fetch display page
    result = ticket_api.list_tickets(project_id, limit=limit, **filter_kwargs)
    tickets = result.get("items", []) or result.get("tickets", [])
    total = result.get("total_tickets", len(tickets))

    # If there are more tickets than returned, paginate to get full status counts
    all_tickets = list(tickets)
    if result.get("has_more") and has_filter:
        offset = result.get("next_offset", len(tickets))
        while offset < total:
            page = ticket_api.list_tickets(project_id, limit=500, offset=offset, **filter_kwargs)
            page_items = page.get("items", []) or page.get("tickets", [])
            if not page_items:
                break
            all_tickets.extend(page_items)
            if not page.get("has_more"):
                break
            offset = page.get("next_offset", offset + len(page_items))

    # Inject project key for formatting
    proj_key = project.get("project_identifier", "?")
    for t in all_tickets:
        if not t.get("ticket_key"):
            tid = t.get("ticket_identifier", "?")
            if isinstance(tid, str) and tid.upper().startswith(proj_key.upper()):
                t["ticket_key"] = tid
            else:
                t["ticket_key"] = f"{proj_key}-{tid}"

    # Count statuses from ALL matching tickets, display first `limit`
    display_tickets = all_tickets[:limit]
    output = formatters.format_ticket_list(display_tickets, total_count=total, all_tickets=all_tickets)
    return output


def _handle_get_ticket(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    info = resolve_ticket_key(args["ticket_key"], cm)
    ticket_api = TicketAPI(cm)
    ticket = ticket_api.get_ticket(info["ticket_id"])

    if info.get("project_key") and info.get("ticket_identifier"):
        ticket["ticket_key"] = f"{info['project_key']}-{info['ticket_identifier']}"

    return formatters.format_ticket(ticket)


def _handle_create_ticket(args: Dict) -> str:
    from janet.api.tickets import TicketAPI
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]

    status = resolve_status(args.get("status"), project_id, cm)

    assignees = args.get("assignees")
    if assignees:
        assignees = resolve_assignees(assignees, project_id, cm)

    ticket_api = TicketAPI(cm)
    result = ticket_api.create_ticket(
        project_id=project_id,
        title=args["title"],
        description=args.get("description"),
        status=status,
        priority=args.get("priority"),
        issue_type=args.get("issue_type"),
        assignees=assignees,
        labels=args.get("labels"),
    )

    ticket = result.get("ticket", result)
    proj_key = project.get("project_identifier", "?")
    ticket_num = ticket.get("ticket_identifier", "?")
    ticket_key = f"{proj_key}-{ticket_num}"

    # Add to sprint if specified
    sprint_name = args.get("sprint")
    if sprint_name:
        sprint = resolve_sprint(sprint_name, project_id, cm)
        sprint_api = SprintAPI(cm)
        sprint_api.add_ticket(ticket["id"], sprint["id"], project_id)
        return f"Created {ticket_key}: {args['title']} and added to sprint '{sprint_name}'."

    return f"Created {ticket_key}: {args['title']}"


def _handle_update_tickets(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    ticket_api = TicketAPI(cm)
    updates = args["updates"]
    results = []

    for upd in updates:
        info = resolve_ticket_key(upd["ticket_key"], cm)
        ticket_id = info["ticket_id"]
        project_id = info.get("project_id")

        # Resolve assignees if provided
        assignees = upd.get("assignees")
        if assignees and project_id:
            assignees = resolve_assignees(assignees, project_id, cm)

        # Resolve status if provided
        status = upd.get("status")
        if status and project_id:
            status = resolve_status(status, project_id, cm)

        ticket_api.update_ticket(
            ticket_id=ticket_id,
            title=upd.get("title"),
            description=upd.get("description"),
            status=status,
            priority=upd.get("priority"),
            issue_type=upd.get("issue_type"),
            assignees=assignees,
            labels=upd.get("labels"),
            due_date=upd.get("due_date"),
        )
        results.append(f"Updated {upd['ticket_key']}")

    return "\n".join(results)


def _handle_move_ticket(args: Dict) -> str:
    from janet.api.tickets import TicketAPI
    from janet.utils.lexo_position import generate_between, generate_evenly_spaced

    cm = _get_config()
    ticket_api = TicketAPI(cm)
    position = args["position"]

    # ── Sort entire column ──
    if position == "sort":
        project_key = args.get("project_key")
        status = args.get("status")
        if not project_key or not status:
            raise ResolutionError("project_key and status are required for sort")
        project = resolve_project(project_key, cm)
        sort_by = args.get("sort_by", "priority")
        sort_map = {"due-date": "due_date"}
        result = ticket_api.sort_column(
            project["id"], status, sort_map.get(sort_by, sort_by), args.get("reverse", False)
        )
        return f"Sorted {result.get('count', '?')} tickets in '{status}' by {sort_by}"

    # ── Reorder multiple tickets ──
    if position == "reorder":
        ticket_keys = args.get("ticket_keys")
        status = args.get("status")
        if not ticket_keys or not status:
            raise ResolutionError("ticket_keys and status are required for reorder")
        resolved = resolve_ticket_keys_batch(ticket_keys, cm)
        positions = generate_evenly_spaced(len(resolved))
        bulk_data = [
            {"ticket_id": r["ticket_id"], "position": pos, "status": status}
            for r, pos in zip(resolved, positions)
        ]
        ticket_api.bulk_set_positions(bulk_data)
        return f"Reordered {len(ticket_keys)} tickets in '{status}'"

    # ── Single ticket positioning (top/bottom/before/after) ──
    ticket_key = args.get("ticket_key")
    if not ticket_key:
        raise ResolutionError("ticket_key is required for top/bottom/before/after")

    info = resolve_ticket_key(ticket_key, cm)
    ticket_id = info["ticket_id"]

    # Resolve target status
    status = args.get("status")
    if status and info.get("project_id"):
        status = resolve_status(status, info["project_id"], cm)
    elif not status:
        ticket = ticket_api.get_ticket(ticket_id)
        status = ticket.get("status", "")

    # ── Sprint positioning path ──
    sprint_name = args.get("sprint")
    if sprint_name and info.get("project_id"):
        from janet.api.sprints import SprintAPI
        sprint_api = SprintAPI(cm)
        sprint = resolve_sprint(sprint_name, info["project_id"], cm)
        sprint_id = sprint["id"]

        # Get current ordered positions in this sprint column
        sprint_positions = sprint_api.get_positions(sprint_id, status=status)
        # Filter to just this status
        sprint_positions = [p for p in sprint_positions if p.get("status") == status]

        if position == "top":
            neighbor_above = None
            neighbor_below = sprint_positions[0]["ticket_id"] if sprint_positions else None
        elif position == "bottom":
            neighbor_above = sprint_positions[-1]["ticket_id"] if sprint_positions else None
            neighbor_below = None
        elif position.startswith("before:") or position.startswith("after:"):
            is_before = position.startswith("before:")
            target_key = position.split(":", 1)[1]
            target_info = resolve_ticket_key(target_key, cm)
            target_id = target_info["ticket_id"]
            ids = [p["ticket_id"] for p in sprint_positions]
            try:
                idx = ids.index(target_id)
            except ValueError:
                raise ResolutionError(f"Ticket '{target_key}' not found in sprint '{sprint_name}' ({status})")
            if is_before:
                neighbor_above = ids[idx - 1] if idx > 0 else None
                neighbor_below = target_id
            else:
                neighbor_above = target_id
                neighbor_below = ids[idx + 1] if idx < len(ids) - 1 else None
        else:
            raise ResolutionError(f"Unsupported position '{position}' for sprint. Use top, bottom, before:KEY, or after:KEY.")

        sprint_api.set_ticket_position(
            sprint_id, ticket_id, neighbor_above, neighbor_below, status, info["project_id"]
        )
        return f"Moved {ticket_key} to {position} in sprint '{sprint_name}' ({status})"

    if position == "top":
        ticket_api.move_to_top(ticket_id, status)
        return f"Moved {ticket_key} to top of '{status}'"

    if position == "bottom":
        ticket_api.set_position(ticket_id, "zzzzz", status)
        return f"Moved {ticket_key} to bottom of '{status}'"

    # before:KEY or after:KEY
    if position.startswith("before:") or position.startswith("after:"):
        is_before = position.startswith("before:")
        target_key = position.split(":", 1)[1]
        target_info = resolve_ticket_key(target_key, cm)
        target_ticket = ticket_api.get_ticket(target_info["ticket_id"])
        target_status = target_ticket.get("status", status)
        target_pos = target_ticket.get("position")

        # Get ordered tickets in that column
        positions_list = ticket_api.get_positions(info["project_id"], status=target_status)

        if is_before:
            above_pos = None
            for i, t in enumerate(positions_list):
                if t.get("ticket_id") == target_info["ticket_id"] and i > 0:
                    above_pos = positions_list[i - 1].get("position")
                    break
            new_pos = generate_between(above_pos, target_pos)
        else:
            below_pos = None
            for i, t in enumerate(positions_list):
                if t.get("ticket_id") == target_info["ticket_id"] and i < len(positions_list) - 1:
                    below_pos = positions_list[i + 1].get("position")
                    break
            new_pos = generate_between(target_pos, below_pos)

        ticket_api.set_position(ticket_id, new_pos, target_status)
        direction = "before" if is_before else "after"
        return f"Moved {ticket_key} {direction} {target_key} in '{target_status}'"

    raise ResolutionError(f"Unknown position: {position}. Use top, bottom, before:KEY, after:KEY, reorder, or sort.")


def _handle_manage_child_task(args: Dict) -> str:
    from janet.api.child_tasks import ChildTaskAPI

    cm = _get_config()
    action = args["action"]

    if action == "create":
        ticket_key = args.get("ticket_key")
        if not ticket_key:
            raise ResolutionError("ticket_key is required for create action")
        title = args.get("title")
        if not title:
            raise ResolutionError("title is required for create action")

        info = resolve_ticket_key(ticket_key, cm)
        status = resolve_status(args.get("status"), info["project_id"], cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        child_api = ChildTaskAPI(cm)
        result = child_api.create_child_task(
            ticket_id=info["ticket_id"],
            project_id=info["project_id"],
            ticket_identifier=info["ticket_identifier"],
            project_identifier=info["project_key"],
            title=title,
            status=status,
            description=args.get("description"),
            priority=args.get("priority"),
            assignee=assignee,
            due_date=args.get("due_date"),
        )
        ct_id = result.get("fullIdentifier", result.get("id", "?"))
        return f"Created child task {ct_id}: {title}"

    elif action == "update":
        ct_key = args.get("child_task_key")
        if not ct_key:
            raise ResolutionError("child_task_key is required for update action")

        ct_info = resolve_child_task_key(ct_key, cm)
        child_api = ChildTaskAPI(cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], ct_info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        child_api.update_child_task(
            child_task_id=ct_info["child_task_id"],
            title=args.get("title"),
            description=args.get("description"),
            status=args.get("status"),
            priority=args.get("priority"),
            assignee=assignee,
            due_date=args.get("due_date"),
        )
        return f"Updated child task {ct_key}"

    elif action == "delete":
        ct_key = args.get("child_task_key")
        if not ct_key:
            raise ResolutionError("child_task_key is required for delete action")

        ct_info = resolve_child_task_key(ct_key, cm)
        child_api = ChildTaskAPI(cm)
        child_api.delete_child_task(ct_info["child_task_id"])
        return f"Deleted child task {ct_key}"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_manage_sub_task(args: Dict) -> str:
    from janet.api.child_tasks import ChildTaskAPI

    cm = _get_config()
    action = args["action"]

    if action == "create":
        ct_key = args.get("child_task_key")
        if not ct_key:
            raise ResolutionError("child_task_key is required for create action")
        title = args.get("title")
        if not title:
            raise ResolutionError("title is required for create action")

        ct_info = resolve_child_task_key(ct_key, cm)
        child_api = ChildTaskAPI(cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], ct_info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        result = child_api.create_sub_task(
            child_task_id=ct_info["child_task_id"],
            title=title,
            status=args.get("status", "To Do"),
            priority=args.get("priority"),
            assignee=assignee,
        )
        sub = result.get("sub_task", result)
        st_id = sub.get("fullIdentifier", sub.get("id", "?"))
        return f"Created sub-task {st_id}: {title}"

    elif action == "update":
        st_key = args.get("sub_task_key")
        if not st_key:
            raise ResolutionError("sub_task_key is required for update action")

        st_info = resolve_sub_task_key(st_key, cm)
        child_api = ChildTaskAPI(cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], st_info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        child_api.update_sub_task(
            sub_task_id=st_info["sub_task_id"],
            title=args.get("title"),
            status=args.get("status"),
            priority=args.get("priority"),
            assignee=assignee,
        )
        return f"Updated sub-task {st_key}"

    elif action == "delete":
        st_key = args.get("sub_task_key")
        if not st_key:
            raise ResolutionError("sub_task_key is required for delete action")

        st_info = resolve_sub_task_key(st_key, cm)
        child_api = ChildTaskAPI(cm)
        child_api.delete_sub_task(st_info["sub_task_id"])
        return f"Deleted sub-task {st_key}"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_manage_comment(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    action = args["action"]
    info = resolve_ticket_key(args["ticket_key"], cm)
    ticket_api = TicketAPI(cm)

    if action == "add":
        text = args.get("text")
        if not text:
            raise ResolutionError("text is required for add action")
        ticket_api.add_comment(info["ticket_id"], text)
        return f"Added comment to {args['ticket_key']}"

    elif action == "edit":
        comment_id = args.get("comment_id")
        text = args.get("text")
        if not comment_id:
            raise ResolutionError("comment_id is required for edit action")
        if not text:
            raise ResolutionError("text is required for edit action")
        ticket_api.edit_comment(info["ticket_id"], comment_id, text)
        return f"Edited comment on {args['ticket_key']}"

    elif action == "delete":
        comment_id = args.get("comment_id")
        if not comment_id:
            raise ResolutionError("comment_id is required for delete action")
        ticket_api.delete_comment(info["ticket_id"], comment_id)
        return f"Deleted comment from {args['ticket_key']}"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_list_sprints(args: Dict) -> str:
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    sprint_api = SprintAPI(cm)
    sprints = sprint_api.list_sprints(project["id"])
    return formatters.format_sprint_list(sprints)


def _handle_manage_sprint(args: Dict) -> str:
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    action = args["action"]
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]

    sprint_api = SprintAPI(cm)

    if action == "create":
        start = args.get("start_date") or date.today().isoformat()
        end = args.get("end_date") or (date.today() + timedelta(days=14)).isoformat()

        sprint_api.create_sprint(
            project_id=project_id,
            name=args["sprint_name"],
            start_date=start,
            end_date=end,
            description=args.get("description"),
        )
        return f"Created sprint '{args['sprint_name']}' ({start} to {end})"

    elif action == "update":
        sprint = resolve_sprint(args["sprint_name"], project_id, cm)
        sprint_api.update_sprint(
            sprint_id=sprint["id"],
            name=args.get("new_name"),
            start_date=args.get("start_date"),
            end_date=args.get("end_date"),
            description=args.get("description"),
            status=args.get("status"),
        )
        return f"Updated sprint '{args['sprint_name']}'"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_manage_sprint_tickets(args: Dict) -> str:
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    action = args["action"]
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]

    sprint = resolve_sprint(args["sprint_name"], project_id, cm)
    sprint_id = sprint["id"]

    ticket_infos = resolve_ticket_keys_batch(args["ticket_keys"], cm)
    ticket_ids = [t["ticket_id"] for t in ticket_infos]

    sprint_api = SprintAPI(cm)

    if action == "add":
        sprint_api.bulk_add_tickets(sprint_id, ticket_ids, project_id)
        return f"Added {len(ticket_ids)} ticket(s) to sprint '{args['sprint_name']}'"

    elif action == "remove":
        sprint_api.bulk_remove_tickets(sprint_id, ticket_ids)
        return f"Removed {len(ticket_ids)} ticket(s) from sprint '{args['sprint_name']}'"

    elif action == "reorder":
        status = args.get("status")
        if not status:
            raise ResolutionError("status is required for reorder action")
        sprint_api.reorder_tickets(sprint_id, ticket_ids, status)
        return f"Reordered {len(ticket_ids)} ticket(s) in sprint '{args['sprint_name']}' ({status})"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_list_child_tasks(args: Dict) -> str:
    from janet.api.child_tasks import ChildTaskAPI

    cm = _get_config()
    info = resolve_ticket_key(args["ticket_key"], cm)
    child_api = ChildTaskAPI(cm)

    child_tasks = child_api.list_child_tasks_with_subtasks(info["ticket_id"])

    return formatters.format_child_tasks(child_tasks)


def _handle_list_comments(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    info = resolve_ticket_key(args["ticket_key"], cm)
    ticket_api = TicketAPI(cm)
    comments = ticket_api.get_ticket_comments(info["ticket_id"])
    return formatters.format_comments(comments)


def _handle_list_sprint_tickets(args: Dict) -> str:
    from janet.api.sprints import SprintAPI
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    sprint = resolve_sprint(args["sprint_name"], project["id"], cm)

    sprint_api = SprintAPI(cm)

    # Use positions endpoint to get tickets in correct sprint order
    positions = sprint_api.get_positions(sprint["id"])
    ticket_ids = [p["ticket_id"] for p in positions] if positions else sprint_api.list_tickets(sprint["id"])

    if not ticket_ids:
        return f"No tickets in sprint '{args['sprint_name']}'."

    ticket_api = TicketAPI(cm)
    tickets_raw = ticket_api.batch_fetch(ticket_ids)

    # Re-order tickets to match sprint position order
    ticket_map = {t["id"]: t for t in tickets_raw}
    tickets = [ticket_map[tid] for tid in ticket_ids if tid in ticket_map]

    proj_key = project.get("project_identifier", "?")
    for t in tickets:
        if not t.get("ticket_key"):
            tid = t.get("ticket_identifier", "?")
            if isinstance(tid, str) and tid.upper().startswith(proj_key.upper()):
                t["ticket_key"] = tid
            else:
                t["ticket_key"] = f"{proj_key}-{tid}"

    return formatters.format_ticket_list(tickets)


# ── Router ──────────────────────────────────────────────────────────────────

HANDLERS = {
    "get_workspace_context": _handle_get_workspace_context,
    "list_tickets": _handle_list_tickets,
    "get_ticket": _handle_get_ticket,
    "create_ticket": _handle_create_ticket,
    "update_tickets": _handle_update_tickets,
    "move_ticket": _handle_move_ticket,
    "manage_child_task": _handle_manage_child_task,
    "manage_sub_task": _handle_manage_sub_task,
    "manage_comment": _handle_manage_comment,
    "list_sprints": _handle_list_sprints,
    "manage_sprint": _handle_manage_sprint,
    "manage_sprint_tickets": _handle_manage_sprint_tickets,
    "list_child_tasks": _handle_list_child_tasks,
    "list_comments": _handle_list_comments,
    "list_sprint_tickets": _handle_list_sprint_tickets,
}


async def _log_tool_call(tool_name: str, arguments: Dict, status: str, error_message: str | None, duration_ms: int, result_preview: str | None = None):
    """Fire-and-forget: POST tool call log to backend."""
    api_key = os.environ.get("JANET_API_KEY")
    if not api_key:
        return
    try:
        import httpx
        config = _get_config()
        base_url = config.get().api.base_url
        sanitized_args = {k: v for k, v in (arguments or {}).items() if "key" not in k.lower() and "token" not in k.lower()}
        config_obj = config.get()
        org_id = config_obj.selected_organization.id if config_obj.selected_organization else ""
        await asyncio.to_thread(
            lambda: httpx.post(
                f"{base_url}/api/v1/mcp-activity",
                headers={
                    "X-API-Key": api_key,
                    "Content-Type": "application/json",
                    "X-Organization-ID": org_id,
                },
                json={
                    "tool_name": tool_name,
                    "arguments": sanitized_args,
                    "status": status,
                    "error_message": error_message,
                    "duration_ms": duration_ms,
                    "result_preview": result_preview,
                },
                timeout=5,
            )
        )
    except Exception:
        pass  # Non-blocking, never fail the tool call


@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    handler = HANDLERS.get(name)
    if not handler:
        return _text(f"Unknown tool: {name}")

    import time
    start = time.time()
    status = "success"
    error_msg = None

    try:
        result = await asyncio.to_thread(handler, arguments)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, None, duration_ms, result))
        return _text(result)
    except AuthenticationError as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        hint = (
            "Ask the user to check their API key at janet.ai → MCP settings."
            if os.environ.get("JANET_API_KEY")
            else "Ask the user to run `janet login` in their terminal."
        )
        return _text(
            f"Authentication error: {e}\n\n{hint}"
        )
    except ResolutionError as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        return _text(f"Resolution error: {e}")
    except NetworkError as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        return _text(f"API request failed: {e}. The Janet API may be temporarily unavailable.")
    except Exception as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        return _text(f"Error: {e}")


# ── Entry point ─────────────────────────────────────────────────────────────


def main():
    """Run the Janet AI MCP server over stdio."""
    import asyncio

    asyncio.run(_run())


async def _run():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )
