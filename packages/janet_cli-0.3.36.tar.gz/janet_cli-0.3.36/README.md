# Janet AI MCP Server & CLI

> Give AI coding agents full access to your Janet.ai organization, create tickets, manage sprints, search across projects, and more.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

## What is Janet AI?

[Janet AI](https://janet.ai) is an AI-native project management platform for modern software teams. This package provides two ways for AI agents and developers to interact with Janet:

- **MCP Server** — Connect Claude Desktop, Claude Code, or any MCP-compatible assistant directly to your workspace. The AI can autonomously create tickets, update statuses, manage sprints, and search across all your projects.
- **CLI** — Sync tickets to local markdown files and manage your workspace from the terminal.

## Quick Setup

One command installs, authenticates, and configures all detected clients automatically:

```bash
pip install "janet-cli[mcp]" && janet-mcp-setup
```

The wizard auto-detects and configures Claude Code, Claude Desktop, Cursor, VS Code, Windsurf, and Codex.

### Manual Setup

If you prefer to configure manually:

**1. Install**

```bash
pip install "janet-cli[mcp]"
```

**2. Generate an API key** in your Janet.ai dashboard → **Organization Settings** → **API Keys**.

**3. Configure your client:**

<details>
<summary>Claude Code</summary>

```bash
claude mcp add janet-ai -e JANET_API_KEY=jnt_your_key_here -- janet-mcp
```
</details>

<details>
<summary>Claude Desktop</summary>

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "janet-ai": {
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  }
}
```
</details>

<details>
<summary>Cursor</summary>

Add to `~/.cursor/mcp.json`:
```json
{
  "mcpServers": {
    "janet-ai": {
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  }
}
```
</details>

<details>
<summary>VS Code</summary>

Add to `.vscode/mcp.json`:
```json
{
  "servers": {
    "janet-ai": {
      "type": "stdio",
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  }
}
```
</details>

<details>
<summary>Windsurf</summary>

Add to `~/.codeium/windsurf/mcp_config.json`:
```json
{
  "servers": [
    {
      "name": "janet-ai",
      "type": "stdio",
      "command": "janet-mcp",
      "env": { "JANET_API_KEY": "jnt_your_key_here" }
    }
  ]
}
```
</details>

<details>
<summary>Codex</summary>

```bash
codex mcp add janet-ai -- janet-mcp -e JANET_API_KEY=jnt_your_key_here
```
</details>

## What the MCP Server Can Do

Talk to Claude naturally:

- "Show me my assigned tickets in MAIN"
- "Create a bug ticket for the login redirect issue, assign it to me"
- "Move MAIN-452 to In Progress"
- "Search for tickets about authentication"
- "Add a comment to MAIN-100 saying the fix is deployed"
- "List all high-priority bugs in the current sprint"
- "Sort the To Do column by priority"
- "Break MAIN-200 into child tasks for each component"

### 15 Tools

| Tool | What it does |
|------|-------------|
| `get_workspace_context` | Lists your projects, statuses, and team members. Called automatically first. |
| `list_tickets` | Search and filter tickets by assignee, status, keyword, priority, type, or tags. |
| `get_ticket` | Get full ticket details — description, comments, child tasks. |
| `create_ticket` | Create a ticket with title, description, status, priority, assignees, labels, sprint. |
| `update_tickets` | Batch update tickets. Change status, priority, assignees, etc. |
| `move_ticket` | Reposition tickets — top, bottom, before/after another ticket, bulk reorder, or sort. |
| `manage_child_task` | Create, update, or delete child tasks. |
| `manage_sub_task` | Create, update, or delete sub-tasks on child tasks. |
| `manage_comment` | Add, edit, or delete comments. |
| `list_sprints` | List sprints with status and dates. |
| `manage_sprint` | Create or update sprints. |
| `manage_sprint_tickets` | Add or remove tickets from a sprint. |
| `list_child_tasks` | List child tasks and sub-tasks for a ticket. |
| `list_comments` | List comments on a ticket. |
| `list_sprint_tickets` | List tickets in a sprint. |

### Filtering & Search

`list_tickets` supports: `assignees` (use `["me"]`), `status`, `keyword` (full-text search), `priorities`, `issue_types`, `tags`. Results include full status breakdown across all matching tickets.

### Activity Log

Every MCP tool call is logged and visible in the **MCP** page → **Calls** tab in your dashboard. Click any row to see the full tool response.

### Scope

- **Org-scoped**: each key only accesses one organization
- **Auto-expiration**: keys expire after 1 year
- **Revocable**: instant revocation from the dashboard

## CLI

The CLI provides direct terminal access to Janet.ai and syncs tickets to local markdown files for AI agents that work with files (Claude, Cursor, etc.).

### Install & Login

```bash
pip install janet-cli
janet login
```

### Sync Tickets

```bash
janet sync                    # Sync and watch for real-time updates
janet sync --all              # Sync all projects
janet sync --no-watch         # Sync once and exit
```

Tickets are saved as markdown files:

```
janet-tickets/
└── My Organization/
    ├── Backend/
    │   ├── BACK-1.md
    │   └── BACK-42.md
    └── Frontend/
        └── FRONT-15.md
```

### Using with Cursor / File-Based Agents

```bash
janet sync
```

Add to `.cursorrules`:
```
Project tickets are in ./janet-tickets/ as markdown files.
Use `janet ticket create` to create new tickets.
Use `janet ticket update` to update ticket status.
Use `janet context --json` to see available projects.
```

### CLI Commands

#### Tickets

```bash
janet ticket list -p PROJ                           # List tickets
janet ticket list -p PROJ -s "In Progress"          # Filter by status
janet ticket create "Title" -p PROJ --priority High # Create
janet ticket update PROJ-123 --status "Done"        # Update
```

#### Child Tasks & Sub-Tasks

```bash
janet ticket child-task create BACK-42 "Write tests" -s "To Do"
janet ticket child-task list BACK-42
janet ticket child-task update BACK-42A --status "Done"
janet ticket sub-task create BACK-42A "Unit tests" -s "To Do"
```

#### Comments

```bash
janet ticket comment add BACK-42 "Started working on this"
janet ticket comment list BACK-42
```

#### Sprints

```bash
janet sprint list -p PROJ
janet sprint create "Sprint 3" -p PROJ
janet sprint add-ticket "Sprint 3" PROJ-1 -p PROJ
janet sprint tickets "Sprint 3" -p PROJ
```

#### Positioning

```bash
# Kanban column positioning
janet ticket position top PROJ-1
janet ticket position after PROJ-1 PROJ-2
janet ticket position sort -s "To Do" -p PROJ --by priority

# Sprint column positioning (add --sprint flag)
janet ticket position top PROJ-1 --status "In Progress" --sprint "Sprint 3"
janet ticket position bottom PROJ-1 --status "In Progress" --sprint "Sprint 3"
janet ticket position after PROJ-1 PROJ-2 --sprint "Sprint 3"
janet ticket position before PROJ-1 PROJ-2 --sprint "Sprint 3"
```

#### Organization & Config

```bash
janet org list                  # List organizations
janet org select <org-id>       # Switch organization
janet project list              # List projects
janet context --json            # Workspace context for AI agents
janet config show               # Show config
janet --version                 # Version
janet update                    # Update CLI
```

## Requirements

- Python 3.8+
- Janet AI account ([sign up](https://janet.ai))

## Documentation

- [Janet AI](https://janet.ai) — Platform
- [Documentation](https://docs.janet.ai) — Full docs

## License

MIT License - see [LICENSE](LICENSE) file for details.
