# Extremes
# Forcing Frequency Extremes
cdef double d_MIN_FREQUENCY
cdef double d_MAX_FREQUENCY

# Minimum difference between spin and orbital frequency before it is treated as zero.
cdef double d_MIN_SPIN_ORBITAL_DIFF

# Shear/Bulk Modulus Extremes
cdef double d_MIN_VISCOSITY
cdef double d_MIN_MODULUS

# Thickness
cdef double d_MIN_THICKNESS

# Mathematics
cdef double d_ppm
cdef double d_ppb

cdef double d_PI
cdef double d_DBL_MAX
cdef double d_DBL_MIN
cdef double d_DBL_MANT_DIG
cdef double d_INF
cdef double d_EPS_10
cdef double d_EPS_100
cdef double d_EPS
cdef double d_NAN

# Sun
cdef double d_mass_solar
cdef double d_radius_solar
cdef double d_luminosity_solar

# TRAPPIST-1
cdef double d_mass_trap1
cdef double d_radius_trap1
cdef double d_luminosity_trap1

# Earth
cdef double d_mass_earth
cdef double d_radius_earth

# Jupiter
cdef double d_mass_jupiter
cdef double d_radius_jupiter

# Pluto
cdef double d_mass_pluto
cdef double d_radius_pluto

# Io
cdef double d_mass_io
cdef double d_radius_io

# Alias Names
cdef double d_G
cdef double d_R
cdef double d_Au
cdef double d_sbc
cdef double d_SBC
cdef double d_newtons_constant

cdef double d_M_sol
cdef double d_M_earth
cdef double d_M_jup
cdef double d_M_pluto

cdef double d_R_sol
cdef double d_R_earth
cdef double d_R_jup
cdef double d_R_pluto

cdef double d_L_sol
