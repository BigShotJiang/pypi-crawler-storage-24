from .experiments import (
    ex1,
    ex2,
    ex3,
    ex4,
    ex5a,
    ex5b,
    ex6a,
    ex6b,
    ex6c,
    ex7,
    ex8,
    ex9
)