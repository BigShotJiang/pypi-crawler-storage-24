"""atrophy CLI package."""
