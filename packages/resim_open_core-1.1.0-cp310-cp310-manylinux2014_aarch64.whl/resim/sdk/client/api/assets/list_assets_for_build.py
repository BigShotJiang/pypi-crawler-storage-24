from http import HTTPStatus
from typing import Any, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.build_asset_link import BuildAssetLink
from typing import cast



def _get_kwargs(
    project_id: str,
    build_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/projects/{project_id}/builds/{build_id}/assets".format(project_id=project_id,build_id=build_id,),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | list[BuildAssetLink] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for componentsschemaslist_build_assets_output_item_data in (_response_200):
            componentsschemaslist_build_assets_output_item = BuildAssetLink.from_dict(componentsschemaslist_build_assets_output_item_data)



            response_200.append(componentsschemaslist_build_assets_output_item)

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | list[BuildAssetLink]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    build_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[Any | list[BuildAssetLink]]:
    """  Lists the assets attached to a build.

    Args:
        project_id (str):
        build_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | list[BuildAssetLink]]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
build_id=build_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    project_id: str,
    build_id: str,
    *,
    client: AuthenticatedClient,

) -> Any | list[BuildAssetLink] | None:
    """  Lists the assets attached to a build.

    Args:
        project_id (str):
        build_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | list[BuildAssetLink]
     """


    return sync_detailed(
        project_id=project_id,
build_id=build_id,
client=client,

    ).parsed

async def asyncio_detailed(
    project_id: str,
    build_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[Any | list[BuildAssetLink]]:
    """  Lists the assets attached to a build.

    Args:
        project_id (str):
        build_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | list[BuildAssetLink]]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
build_id=build_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    project_id: str,
    build_id: str,
    *,
    client: AuthenticatedClient,

) -> Any | list[BuildAssetLink] | None:
    """  Lists the assets attached to a build.

    Args:
        project_id (str):
        build_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | list[BuildAssetLink]
     """


    return (await asyncio_detailed(
        project_id=project_id,
build_id=build_id,
client=client,

    )).parsed
