from http import HTTPStatus
from typing import Any, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.custom_field_value_type import CustomFieldValueType
from ...models.list_experience_custom_fields_output import ListExperienceCustomFieldsOutput
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    project_id: str,
    *,
    type_: list[CustomFieldValueType] | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_type_: list[str] | Unset = UNSET
    if not isinstance(type_, Unset):
        json_type_ = []
        for type_item_data in type_:
            type_item = type_item_data.value
            json_type_.append(type_item)


    params["type"] = json_type_


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/projects/{project_id}/experiences/customfields".format(project_id=project_id,),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | ListExperienceCustomFieldsOutput | None:
    if response.status_code == 200:
        response_200 = ListExperienceCustomFieldsOutput.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | ListExperienceCustomFieldsOutput]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    type_: list[CustomFieldValueType] | Unset = UNSET,

) -> Response[Any | ListExperienceCustomFieldsOutput]:
    """  Returns all custom field definitions with unique values for the project. Useful for populating
    filter dropdowns.

    Args:
        project_id (str):
        type_ (list[CustomFieldValueType] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ListExperienceCustomFieldsOutput]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
type_=type_,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    type_: list[CustomFieldValueType] | Unset = UNSET,

) -> Any | ListExperienceCustomFieldsOutput | None:
    """  Returns all custom field definitions with unique values for the project. Useful for populating
    filter dropdowns.

    Args:
        project_id (str):
        type_ (list[CustomFieldValueType] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ListExperienceCustomFieldsOutput
     """


    return sync_detailed(
        project_id=project_id,
client=client,
type_=type_,

    ).parsed

async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    type_: list[CustomFieldValueType] | Unset = UNSET,

) -> Response[Any | ListExperienceCustomFieldsOutput]:
    """  Returns all custom field definitions with unique values for the project. Useful for populating
    filter dropdowns.

    Args:
        project_id (str):
        type_ (list[CustomFieldValueType] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ListExperienceCustomFieldsOutput]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
type_=type_,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    type_: list[CustomFieldValueType] | Unset = UNSET,

) -> Any | ListExperienceCustomFieldsOutput | None:
    """  Returns all custom field definitions with unique values for the project. Useful for populating
    filter dropdowns.

    Args:
        project_id (str):
        type_ (list[CustomFieldValueType] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ListExperienceCustomFieldsOutput
     """


    return (await asyncio_detailed(
        project_id=project_id,
client=client,
type_=type_,

    )).parsed
