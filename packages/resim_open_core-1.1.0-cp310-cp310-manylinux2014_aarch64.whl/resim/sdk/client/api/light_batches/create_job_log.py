from http import HTTPStatus
from typing import Any, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_job_log_input import CreateJobLogInput
from ...models.create_job_log_output import CreateJobLogOutput
from typing import cast



def _get_kwargs(
    project_id: str,
    batch_id: str,
    job_id: str,
    *,
    body: CreateJobLogInput,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/projects/{project_id}/batches/{batch_id}/jobs/{job_id}/logs".format(project_id=project_id,batch_id=batch_id,job_id=job_id,),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | CreateJobLogOutput | None:
    if response.status_code == 201:
        response_201 = CreateJobLogOutput.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | CreateJobLogOutput]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
    body: CreateJobLogInput,

) -> Response[Any | CreateJobLogOutput]:
    """  Creates a log entry for a job and returns a presigned S3 upload URL. The batch must be of type LIGHT
    and the job must be in EXPERIENCE_RUNNING status.

    Args:
        project_id (str):
        batch_id (str):
        job_id (str):
        body (CreateJobLogInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateJobLogOutput]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
batch_id=batch_id,
job_id=job_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    project_id: str,
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
    body: CreateJobLogInput,

) -> Any | CreateJobLogOutput | None:
    """  Creates a log entry for a job and returns a presigned S3 upload URL. The batch must be of type LIGHT
    and the job must be in EXPERIENCE_RUNNING status.

    Args:
        project_id (str):
        batch_id (str):
        job_id (str):
        body (CreateJobLogInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateJobLogOutput
     """


    return sync_detailed(
        project_id=project_id,
batch_id=batch_id,
job_id=job_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    project_id: str,
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
    body: CreateJobLogInput,

) -> Response[Any | CreateJobLogOutput]:
    """  Creates a log entry for a job and returns a presigned S3 upload URL. The batch must be of type LIGHT
    and the job must be in EXPERIENCE_RUNNING status.

    Args:
        project_id (str):
        batch_id (str):
        job_id (str):
        body (CreateJobLogInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateJobLogOutput]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
batch_id=batch_id,
job_id=job_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    project_id: str,
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
    body: CreateJobLogInput,

) -> Any | CreateJobLogOutput | None:
    """  Creates a log entry for a job and returns a presigned S3 upload URL. The batch must be of type LIGHT
    and the job must be in EXPERIENCE_RUNNING status.

    Args:
        project_id (str):
        batch_id (str):
        job_id (str):
        body (CreateJobLogInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateJobLogOutput
     """


    return (await asyncio_detailed(
        project_id=project_id,
batch_id=batch_id,
job_id=job_id,
client=client,
body=body,

    )).parsed
