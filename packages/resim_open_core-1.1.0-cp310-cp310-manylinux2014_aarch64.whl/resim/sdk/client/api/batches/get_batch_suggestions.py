from http import HTTPStatus
from typing import Any, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.batch_suggestions_output import BatchSuggestionsOutput
from typing import cast



def _get_kwargs(
    project_id: str,
    batch_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/projects/{project_id}/batches/{batch_id}/suggestions".format(project_id=project_id,batch_id=batch_id,),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | BatchSuggestionsOutput | None:
    if response.status_code == 200:
        response_200 = BatchSuggestionsOutput.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | BatchSuggestionsOutput]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    batch_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[Any | BatchSuggestionsOutput]:
    """  Returns a list of suggested batches to A/B compare against

    Args:
        project_id (str):
        batch_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | BatchSuggestionsOutput]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
batch_id=batch_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    project_id: str,
    batch_id: str,
    *,
    client: AuthenticatedClient,

) -> Any | BatchSuggestionsOutput | None:
    """  Returns a list of suggested batches to A/B compare against

    Args:
        project_id (str):
        batch_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | BatchSuggestionsOutput
     """


    return sync_detailed(
        project_id=project_id,
batch_id=batch_id,
client=client,

    ).parsed

async def asyncio_detailed(
    project_id: str,
    batch_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[Any | BatchSuggestionsOutput]:
    """  Returns a list of suggested batches to A/B compare against

    Args:
        project_id (str):
        batch_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | BatchSuggestionsOutput]
     """


    kwargs = _get_kwargs(
        project_id=project_id,
batch_id=batch_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    project_id: str,
    batch_id: str,
    *,
    client: AuthenticatedClient,

) -> Any | BatchSuggestionsOutput | None:
    """  Returns a list of suggested batches to A/B compare against

    Args:
        project_id (str):
        batch_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | BatchSuggestionsOutput
     """


    return (await asyncio_detailed(
        project_id=project_id,
batch_id=batch_id,
client=client,

    )).parsed
