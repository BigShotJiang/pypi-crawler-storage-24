from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.custom_field_value_type import CustomFieldValueType
from typing import cast






T = TypeVar("T", bound="CustomFieldDefinition")



@_attrs_define
class CustomFieldDefinition:
    """ 
        Attributes:
            name (str):
            values (list[str]): Array of field values. For 'text' type, use plain strings. For 'number' type, use string
                representations of numbers (e.g., "32"). For 'timestamp' type, use ISO 8601 format strings. For 'json' type, use
                JSON string representations of objects or arrays.
            type_ (CustomFieldValueType):
     """

    name: str
    values: list[str]
    type_: CustomFieldValueType
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        values = self.values



        type_ = self.type_.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "values": values,
            "type": type_,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        values = cast(list[str], d.pop("values"))


        type_ = CustomFieldValueType(d.pop("type"))




        custom_field_definition = cls(
            name=name,
            values=values,
            type_=type_,
        )


        custom_field_definition.additional_properties = d
        return custom_field_definition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
