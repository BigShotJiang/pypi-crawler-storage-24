from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="LightBatchInput")



@_attrs_define
class LightBatchInput:
    """ 
        Attributes:
            branch_id (str):
            metrics_set_name (None | str | Unset):
            batch_name (str | Unset):
            version (str | Unset): A version string representing your build. For example, this could be a commit sha or
                semver number
     """

    branch_id: str
    metrics_set_name: None | str | Unset = UNSET
    batch_name: str | Unset = UNSET
    version: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        branch_id = self.branch_id

        metrics_set_name: None | str | Unset
        if isinstance(self.metrics_set_name, Unset):
            metrics_set_name = UNSET
        else:
            metrics_set_name = self.metrics_set_name

        batch_name = self.batch_name

        version = self.version


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "branchID": branch_id,
        })
        if metrics_set_name is not UNSET:
            field_dict["metricsSetName"] = metrics_set_name
        if batch_name is not UNSET:
            field_dict["batchName"] = batch_name
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        branch_id = d.pop("branchID")

        def _parse_metrics_set_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        metrics_set_name = _parse_metrics_set_name(d.pop("metricsSetName", UNSET))


        batch_name = d.pop("batchName", UNSET)

        version = d.pop("version", UNSET)

        light_batch_input = cls(
            branch_id=branch_id,
            metrics_set_name=metrics_set_name,
            batch_name=batch_name,
            version=version,
        )


        light_batch_input.additional_properties = d
        return light_batch_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
