from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.required_headers import RequiredHeaders





T = TypeVar("T", bound="CreateJobLogOutput")



@_attrs_define
class CreateJobLogOutput:
    """ 
        Attributes:
            log_id (str):
            upload_url (str): Presigned S3 URL for uploading the log file via HTTP PUT.
            required_headers (RequiredHeaders | Unset): Headers the client MUST include when uploading. Includes x-amz-
                tagging when tags were provided.
     """

    log_id: str
    upload_url: str
    required_headers: RequiredHeaders | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.required_headers import RequiredHeaders
        log_id = self.log_id

        upload_url = self.upload_url

        required_headers: dict[str, Any] | Unset = UNSET
        if not isinstance(self.required_headers, Unset):
            required_headers = self.required_headers.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "logID": log_id,
            "uploadURL": upload_url,
        })
        if required_headers is not UNSET:
            field_dict["requiredHeaders"] = required_headers

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.required_headers import RequiredHeaders
        d = dict(src_dict)
        log_id = d.pop("logID")

        upload_url = d.pop("uploadURL")

        _required_headers = d.pop("requiredHeaders", UNSET)
        required_headers: RequiredHeaders | Unset
        if isinstance(_required_headers,  Unset):
            required_headers = UNSET
        else:
            required_headers = RequiredHeaders.from_dict(_required_headers)




        create_job_log_output = cls(
            log_id=log_id,
            upload_url=upload_url,
            required_headers=required_headers,
        )


        create_job_log_output.additional_properties = d
        return create_job_log_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
