from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="LogStream")



@_attrs_define
class LogStream:
    """ 
        Attributes:
            batch_id (str):
            log_name (str):
            job_id (str | Unset):
     """

    batch_id: str
    log_name: str
    job_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        batch_id = self.batch_id

        log_name = self.log_name

        job_id = self.job_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "batchID": batch_id,
            "logName": log_name,
        })
        if job_id is not UNSET:
            field_dict["jobID"] = job_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        batch_id = d.pop("batchID")

        log_name = d.pop("logName")

        job_id = d.pop("jobID", UNSET)

        log_stream = cls(
            batch_id=batch_id,
            log_name=log_name,
            job_id=job_id,
        )


        log_stream.additional_properties = d
        return log_stream

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
