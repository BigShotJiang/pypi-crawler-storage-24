from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.asset import Asset





T = TypeVar("T", bound="BuildAssetLink")



@_attrs_define
class BuildAssetLink:
    """ 
        Attributes:
            asset (Asset):
            build_id (str):
            link_creation_timestamp (datetime.datetime):
     """

    asset: Asset
    build_id: str
    link_creation_timestamp: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.asset import Asset
        asset = self.asset.to_dict()

        build_id = self.build_id

        link_creation_timestamp = self.link_creation_timestamp.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "asset": asset,
            "buildID": build_id,
            "linkCreationTimestamp": link_creation_timestamp,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.asset import Asset
        d = dict(src_dict)
        asset = Asset.from_dict(d.pop("asset"))




        build_id = d.pop("buildID")

        link_creation_timestamp = isoparse(d.pop("linkCreationTimestamp"))




        build_asset_link = cls(
            asset=asset,
            build_id=build_id,
            link_creation_timestamp=link_creation_timestamp,
        )


        build_asset_link.additional_properties = d
        return build_asset_link

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
