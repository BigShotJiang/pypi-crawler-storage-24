from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.custom_field_definition import CustomFieldDefinition





T = TypeVar("T", bound="ListExperienceCustomFieldsOutput")



@_attrs_define
class ListExperienceCustomFieldsOutput:
    """ 
        Attributes:
            custom_fields (list[CustomFieldDefinition]):
     """

    custom_fields: list[CustomFieldDefinition]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.custom_field_definition import CustomFieldDefinition
        custom_fields = []
        for custom_fields_item_data in self.custom_fields:
            custom_fields_item = custom_fields_item_data.to_dict()
            custom_fields.append(custom_fields_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "customFields": custom_fields,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.custom_field_definition import CustomFieldDefinition
        d = dict(src_dict)
        custom_fields = []
        _custom_fields = d.pop("customFields")
        for custom_fields_item_data in (_custom_fields):
            custom_fields_item = CustomFieldDefinition.from_dict(custom_fields_item_data)



            custom_fields.append(custom_fields_item)


        list_experience_custom_fields_output = cls(
            custom_fields=custom_fields,
        )


        list_experience_custom_fields_output.additional_properties = d
        return list_experience_custom_fields_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
