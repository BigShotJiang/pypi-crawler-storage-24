from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CreateJobForBatchInput")



@_attrs_define
class CreateJobForBatchInput:
    """ 
        Attributes:
            name (str | Unset): Name for the experience. Either name or experienceID must be provided, but not both.
            experience_id (str | Unset):
            description (str | Unset): Optional description for the job and experience.
     """

    name: str | Unset = UNSET
    experience_id: str | Unset = UNSET
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        experience_id = self.experience_id

        description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if experience_id is not UNSET:
            field_dict["experienceID"] = experience_id
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        experience_id = d.pop("experienceID", UNSET)

        description = d.pop("description", UNSET)

        create_job_for_batch_input = cls(
            name=name,
            experience_id=experience_id,
            description=description,
        )


        create_job_for_batch_input.additional_properties = d
        return create_job_for_batch_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
