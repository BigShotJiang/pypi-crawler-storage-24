from enum import Enum

class LightJobStatus(str, Enum):
    ERROR = "ERROR"
    SUCCEEDED = "SUCCEEDED"

    def __str__(self) -> str:
        return str(self.value)
