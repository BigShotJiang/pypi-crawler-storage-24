from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="ContainerStatusLine")



@_attrs_define
class ContainerStatusLine:
    """ 
        Attributes:
            container_name (str):
            status (str):
            status_changed_timestamp (datetime.datetime):
            exit_code (int | Unset):
     """

    container_name: str
    status: str
    status_changed_timestamp: datetime.datetime
    exit_code: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        container_name = self.container_name

        status = self.status

        status_changed_timestamp = self.status_changed_timestamp.isoformat()

        exit_code = self.exit_code


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "containerName": container_name,
            "status": status,
            "statusChangedTimestamp": status_changed_timestamp,
        })
        if exit_code is not UNSET:
            field_dict["exitCode"] = exit_code

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        container_name = d.pop("containerName")

        status = d.pop("status")

        status_changed_timestamp = isoparse(d.pop("statusChangedTimestamp"))




        exit_code = d.pop("exitCode", UNSET)

        container_status_line = cls(
            container_name=container_name,
            status=status,
            status_changed_timestamp=status_changed_timestamp,
            exit_code=exit_code,
        )


        container_status_line.additional_properties = d
        return container_status_line

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
