from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.asset_build_link_input import AssetBuildLinkInput





T = TypeVar("T", bound="AddAssetsToBuildInput")



@_attrs_define
class AddAssetsToBuildInput:
    """ 
        Attributes:
            assets (list[AssetBuildLinkInput]):
     """

    assets: list[AssetBuildLinkInput]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.asset_build_link_input import AssetBuildLinkInput
        assets = []
        for assets_item_data in self.assets:
            assets_item = assets_item_data.to_dict()
            assets.append(assets_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "assets": assets,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.asset_build_link_input import AssetBuildLinkInput
        d = dict(src_dict)
        assets = []
        _assets = d.pop("assets")
        for assets_item_data in (_assets):
            assets_item = AssetBuildLinkInput.from_dict(assets_item_data)



            assets.append(assets_item)


        add_assets_to_build_input = cls(
            assets=assets,
        )


        add_assets_to_build_input.additional_properties = d
        return add_assets_to_build_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
