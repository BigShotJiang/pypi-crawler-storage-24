from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.log_type import LogType






T = TypeVar("T", bound="CreateJobLogInput")



@_attrs_define
class CreateJobLogInput:
    """ 
        Attributes:
            file_name (str):
            file_size (int):
            checksum (str):
            log_type (LogType):
     """

    file_name: str
    file_size: int
    checksum: str
    log_type: LogType
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        file_name = self.file_name

        file_size = self.file_size

        checksum = self.checksum

        log_type = self.log_type.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "fileName": file_name,
            "fileSize": file_size,
            "checksum": checksum,
            "logType": log_type,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        file_name = d.pop("fileName")

        file_size = d.pop("fileSize")

        checksum = d.pop("checksum")

        log_type = LogType(d.pop("logType"))




        create_job_log_input = cls(
            file_name=file_name,
            file_size=file_size,
            checksum=checksum,
            log_type=log_type,
        )


        create_job_log_input.additional_properties = d
        return create_job_log_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
