from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.light_job_status import LightJobStatus
from ..types import UNSET, Unset






T = TypeVar("T", bound="CloseJobInput")



@_attrs_define
class CloseJobInput:
    """ 
        Attributes:
            status (LightJobStatus):
            error_message (str | Unset): Optional user-provided error message for the job. Only used when status is ERROR.
     """

    status: LightJobStatus
    error_message: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        error_message = self.error_message


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
        })
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = LightJobStatus(d.pop("status"))




        error_message = d.pop("errorMessage", UNSET)

        close_job_input = cls(
            status=status,
            error_message=error_message,
        )


        close_job_input.additional_properties = d
        return close_job_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
