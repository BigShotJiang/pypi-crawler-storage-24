from enum import Enum

class CustomFieldValueType(str, Enum):
    JSON = "json"
    NUMBER = "number"
    TEXT = "text"
    TIMESTAMP = "timestamp"

    def __str__(self) -> str:
        return str(self.value)
