from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="Asset")



@_attrs_define
class Asset:
    """ 
        Attributes:
            asset_id (str):
            asset_revision (int):
            name (str):
            description (str):
            mount_folder (str):
            locations (list[str]):
            version (str):
            project_id (str):
            user_id (str):
            org_id (str):
            creation_timestamp (datetime.datetime):
            update_timestamp (datetime.datetime):
            update_user_id (str):
            archived (bool):
            cache_exempt (bool): If true, the asset will not be cached.
            num_builds (int): Number of builds this asset revision is linked to.
     """

    asset_id: str
    asset_revision: int
    name: str
    description: str
    mount_folder: str
    locations: list[str]
    version: str
    project_id: str
    user_id: str
    org_id: str
    creation_timestamp: datetime.datetime
    update_timestamp: datetime.datetime
    update_user_id: str
    archived: bool
    cache_exempt: bool
    num_builds: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        asset_id = self.asset_id

        asset_revision = self.asset_revision

        name = self.name

        description = self.description

        mount_folder = self.mount_folder

        locations = self.locations



        version = self.version

        project_id = self.project_id

        user_id = self.user_id

        org_id = self.org_id

        creation_timestamp = self.creation_timestamp.isoformat()

        update_timestamp = self.update_timestamp.isoformat()

        update_user_id = self.update_user_id

        archived = self.archived

        cache_exempt = self.cache_exempt

        num_builds = self.num_builds


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "assetID": asset_id,
            "assetRevision": asset_revision,
            "name": name,
            "description": description,
            "mountFolder": mount_folder,
            "locations": locations,
            "version": version,
            "projectID": project_id,
            "userID": user_id,
            "orgID": org_id,
            "creationTimestamp": creation_timestamp,
            "updateTimestamp": update_timestamp,
            "updateUserID": update_user_id,
            "archived": archived,
            "cacheExempt": cache_exempt,
            "numBuilds": num_builds,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        asset_id = d.pop("assetID")

        asset_revision = d.pop("assetRevision")

        name = d.pop("name")

        description = d.pop("description")

        mount_folder = d.pop("mountFolder")

        locations = cast(list[str], d.pop("locations"))


        version = d.pop("version")

        project_id = d.pop("projectID")

        user_id = d.pop("userID")

        org_id = d.pop("orgID")

        creation_timestamp = isoparse(d.pop("creationTimestamp"))




        update_timestamp = isoparse(d.pop("updateTimestamp"))




        update_user_id = d.pop("updateUserID")

        archived = d.pop("archived")

        cache_exempt = d.pop("cacheExempt")

        num_builds = d.pop("numBuilds")

        asset = cls(
            asset_id=asset_id,
            asset_revision=asset_revision,
            name=name,
            description=description,
            mount_folder=mount_folder,
            locations=locations,
            version=version,
            project_id=project_id,
            user_id=user_id,
            org_id=org_id,
            creation_timestamp=creation_timestamp,
            update_timestamp=update_timestamp,
            update_user_id=update_user_id,
            archived=archived,
            cache_exempt=cache_exempt,
            num_builds=num_builds,
        )


        asset.additional_properties = d
        return asset

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
