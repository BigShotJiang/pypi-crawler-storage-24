from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateAssetInput")



@_attrs_define
class CreateAssetInput:
    """ 
        Attributes:
            name (str):
            description (str):
            mount_folder (str):
            locations (list[str]):
            version (str):
            cache_exempt (bool | Unset): If true, the asset will not be cached.
     """

    name: str
    description: str
    mount_folder: str
    locations: list[str]
    version: str
    cache_exempt: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description = self.description

        mount_folder = self.mount_folder

        locations = self.locations



        version = self.version

        cache_exempt = self.cache_exempt


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "description": description,
            "mountFolder": mount_folder,
            "locations": locations,
            "version": version,
        })
        if cache_exempt is not UNSET:
            field_dict["cacheExempt"] = cache_exempt

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        description = d.pop("description")

        mount_folder = d.pop("mountFolder")

        locations = cast(list[str], d.pop("locations"))


        version = d.pop("version")

        cache_exempt = d.pop("cacheExempt", UNSET)

        create_asset_input = cls(
            name=name,
            description=description,
            mount_folder=mount_folder,
            locations=locations,
            version=version,
            cache_exempt=cache_exempt,
        )


        create_asset_input.additional_properties = d
        return create_asset_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
