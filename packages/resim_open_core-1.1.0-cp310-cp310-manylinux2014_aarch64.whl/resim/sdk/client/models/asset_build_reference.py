from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="AssetBuildReference")



@_attrs_define
class AssetBuildReference:
    """ 
        Attributes:
            build_id (str | Unset):
            asset_revision (int | Unset):
     """

    build_id: str | Unset = UNSET
    asset_revision: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        build_id = self.build_id

        asset_revision = self.asset_revision


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if build_id is not UNSET:
            field_dict["buildID"] = build_id
        if asset_revision is not UNSET:
            field_dict["assetRevision"] = asset_revision

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        build_id = d.pop("buildID", UNSET)

        asset_revision = d.pop("assetRevision", UNSET)

        asset_build_reference = cls(
            build_id=build_id,
            asset_revision=asset_revision,
        )


        asset_build_reference.additional_properties = d
        return asset_build_reference

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
