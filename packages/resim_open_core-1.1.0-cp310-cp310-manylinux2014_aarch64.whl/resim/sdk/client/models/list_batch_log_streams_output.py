from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.log_stream import LogStream





T = TypeVar("T", bound="ListBatchLogStreamsOutput")



@_attrs_define
class ListBatchLogStreamsOutput:
    """ 
        Attributes:
            log_streams (list[LogStream]):
     """

    log_streams: list[LogStream]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.log_stream import LogStream
        log_streams = []
        for log_streams_item_data in self.log_streams:
            log_streams_item = log_streams_item_data.to_dict()
            log_streams.append(log_streams_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "logStreams": log_streams,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.log_stream import LogStream
        d = dict(src_dict)
        log_streams = []
        _log_streams = d.pop("logStreams")
        for log_streams_item_data in (_log_streams):
            log_streams_item = LogStream.from_dict(log_streams_item_data)



            log_streams.append(log_streams_item)


        list_batch_log_streams_output = cls(
            log_streams=log_streams,
        )


        list_batch_log_streams_output.additional_properties = d
        return list_batch_log_streams_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
