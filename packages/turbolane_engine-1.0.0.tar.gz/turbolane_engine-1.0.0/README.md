# TurboLane Engine

`turbolane-engine` is a standalone Python package containing the TurboLane
optimization engine.

## Install

```bash
pip install turbolane-engine
```

## Quick Start

```python
from turbolane import TurboLaneEngine

engine = TurboLaneEngine(mode="client", algorithm="qlearning")

streams = engine.decide(throughput_mbps=45.0, rtt_ms=35.0, loss_pct=0.2)
engine.learn(throughput_mbps=48.0, rtt_ms=34.0, loss_pct=0.2)
engine.save()
```

## Model Storage

If `model_dir` is not provided, TurboLane stores models in the OS user data
location using `platformdirs`, for example:

- Windows: `%APPDATA%/TurboLane/models/<profile>`
- Linux: `~/.local/share/TurboLane/models/<profile>`
- macOS: `~/Library/Application Support/TurboLane/models/<profile>`

## Build Locally

```bash
python -m pip install -U build
python -m build
```
