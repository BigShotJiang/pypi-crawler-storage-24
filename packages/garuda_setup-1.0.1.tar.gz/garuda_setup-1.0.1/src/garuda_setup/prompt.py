"""Terminal prompt helpers — colors, input, choices."""

from __future__ import annotations

import getpass
import os
import secrets
from pathlib import Path


# ── ANSI colors ──────────────────────────────────────────────────

def _color(text: str, code: str) -> str:
    if os.name == "nt" and not os.environ.get("WT_SESSION"):
        return text
    return f"\033[{code}m{text}\033[0m"


def green(t: str) -> str:
    return _color(t, "32")


def cyan(t: str) -> str:
    return _color(t, "36")


def yellow(t: str) -> str:
    return _color(t, "33")


def red(t: str) -> str:
    return _color(t, "31")


def bold(t: str) -> str:
    return _color(t, "1")


def dim(t: str) -> str:
    return _color(t, "2")


# ── Section header ───────────────────────────────────────────────

def header(title: str) -> None:
    width = 60
    print()
    print(cyan("─" * width))
    print(cyan(f"  {title}"))
    print(cyan("─" * width))
    print()


# ── Input helpers ────────────────────────────────────────────────

def ask(prompt: str, default: str = "", secret: bool = False) -> str:
    suffix = f" [{dim(default)}]" if default else ""
    full = f"  {prompt}{suffix}: "
    if secret:
        val = getpass.getpass(full)
    else:
        val = input(full)
    return val.strip() or default


def ask_yes_no(prompt: str, default: bool = True) -> bool:
    hint = "Y/n" if default else "y/N"
    val = ask(f"{prompt} ({hint})")
    if not val:
        return default
    return val.lower() in ("y", "yes", "1", "true")


def ask_choice(prompt: str, choices: list[str], default: int = 0) -> int:
    print(f"  {prompt}")
    for i, c in enumerate(choices):
        marker = green("▸") if i == default else " "
        tag = dim("(default)") if i == default else ""
        print(f"    {marker} {i + 1}) {c} {tag}")
    val = ask("Choice", str(default + 1))
    try:
        idx = int(val) - 1
        if 0 <= idx < len(choices):
            return idx
    except ValueError:
        pass
    return default


def ask_path(prompt: str, default: str = "", must_exist: bool = False) -> str:
    while True:
        val = ask(prompt, default)
        if not val:
            return default
        p = Path(val).expanduser().resolve()
        if must_exist and not p.exists():
            print(red(f"    ✗ Path does not exist: {p}"))
            continue
        return str(p)


def generate_api_key() -> str:
    """Generate a secure random API key with ``gk_`` prefix."""
    return "gk_" + secrets.token_urlsafe(32)
