"""Shared constants for Garuda setup."""

IMAGE = "docker.nxs.solutions/garuda/garuda-system:latest"
COMPOSE_FILE = "docker-compose.yml"

DEFAULT_PORT = 7331
DEFAULT_OLLAMA_MODEL = "granite3.1-dense:8b"
DEFAULT_EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
DEFAULT_QDRANT_COLLECTION = "pages"
DEFAULT_VNC_RES = "1920x1080"

DATA_SUBDIRS = ["garuda", "qdrant", "postgres", "ollama"]

BANNER = r"""
   ██████╗  █████╗ ██████╗ ██╗   ██╗██████╗  █████╗
  ██╔════╝ ██╔══██╗██╔══██╗██║   ██║██╔══██╗██╔══██╗
  ██║  ███╗███████║██████╔╝██║   ██║██║  ██║███████║
  ██║   ██║██╔══██║██╔══██╗██║   ██║██║  ██║██╔══██║
  ╚██████╔╝██║  ██║██║  ██║╚██████╔╝██████╔╝██║  ██║
   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝
                System Setup Wizard
"""
