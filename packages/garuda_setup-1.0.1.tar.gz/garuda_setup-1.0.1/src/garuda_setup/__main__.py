"""Allow running as ``python -m garuda_setup``."""

from garuda_setup.cli import main

main()
