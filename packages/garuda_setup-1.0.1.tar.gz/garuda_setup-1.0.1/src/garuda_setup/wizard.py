"""Wizard orchestrator — runs all steps and generates output files."""

from __future__ import annotations

from pathlib import Path

from .config import SetupConfig
from .generators import (
    create_directories,
    write_docker_compose,
    write_env_file,
    write_launcher_linux,
    write_launcher_macos,
    write_launcher_windows,
    write_readme,
)
from .prompt import bold, cyan, green, header, yellow
from .steps import (
    step_cloud,
    step_credentials_and_mounts,
    step_data_watch,
    step_external_services,
    step_install_dir,
    step_models,
    step_ports,
    step_security,
    step_services,
    step_welcome,
)


def run_wizard() -> None:
    """Run the full interactive setup wizard."""
    cfg = SetupConfig()

    if not step_welcome(cfg):
        print("\n  Aborted.\n")
        return

    step_install_dir(cfg)
    step_security(cfg)
    step_ports(cfg)
    step_services(cfg)
    step_external_services(cfg)
    step_models(cfg)
    step_data_watch(cfg)
    step_cloud(cfg)
    step_credentials_and_mounts(cfg)

    _confirm_and_generate(cfg)


def _confirm_and_generate(cfg: SetupConfig) -> None:
    """Show summary, confirm, generate all files."""
    header("Summary")
    out = Path(cfg.install_dir)

    print(f"  Install directory:  {bold(str(out))}")
    print(f"  Port:               {cfg.port}")
    print(f"  API key:            {cfg.api_key or '(none)'}")
    print(f"  IDE:                {_yn(cfg.enable_ide)}")
    print(f"  Ollama (local LLM): {_yn(cfg.enable_ollama)}")
    print(f"  GPU passthrough:    {_yn(cfg.enable_gpu)}")
    print(f"  Shell access:       {_yn(cfg.enable_shell)}")
    print(f"  VNC desktop:        {_yn(cfg.enable_vnc)}")
    print(f"  Data watch:         {_yn(cfg.data_watch_enabled)}")
    if cfg.server_url:
        print(f"  Cloud server:       {cfg.server_url}")
    if cfg.extra_host_mounts:
        print(f"  Extra mounts:       {len(cfg.extra_host_mounts)}")
    print()

    from .prompt import ask_yes_no

    if not ask_yes_no("Generate files?", True):
        print("\n  Aborted.\n")
        return

    # ── Generate everything ──────────────────────────────────────
    header("Generating Files")

    create_directories(cfg)
    print(green("  ✓ Created directories"))

    write_env_file(cfg, out)
    print(green("  ✓ Written .env"))

    write_docker_compose(cfg, out)
    print(green("  ✓ Written docker-compose.yml"))

    write_launcher_linux(cfg, out)
    print(green("  ✓ Written garuda.sh"))

    if cfg.os_type == "macos":
        write_launcher_macos(cfg, out)
        print(green("  ✓ Written Garuda.command (double-click in Finder)"))

    write_launcher_windows(cfg, out)
    print(green("  ✓ Written garuda.ps1, garuda.bat"))

    write_readme(cfg, out)
    print(green("  ✓ Written README.md"))

    # ── Done ─────────────────────────────────────────────────────
    header("Setup Complete!")
    print(f"  All files written to: {bold(str(out))}")
    print()
    if cfg.os_type == "macos":
        print(cyan(f"    cd {out}"))
        print(cyan("    ./garuda.sh up"))
        print()
        print(dim("  Or double-click Garuda.command in Finder to start & open browser."))
    elif cfg.os_type == "windows":
        print(cyan(f"    cd {out}"))
        print(cyan("    .\\garuda.bat up"))
    else:
        print(cyan(f"    cd {out}"))
        print(cyan("    ./garuda.sh up"))
    print()
    print(f"  Then open {bold(f'http://localhost:{cfg.port}')} in your browser.")
    if cfg.api_key:
        print(f"  API key: {yellow(cfg.api_key)}")
    print()


def _yn(val: bool) -> str:
    return green("yes") if val else "no"
