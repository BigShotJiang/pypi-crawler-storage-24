"""CLI entry point for garuda-setup."""

from __future__ import annotations

from .constants import BANNER


def main() -> None:
    """Entry point for ``garuda-setup`` and ``python -m garuda_setup``."""
    print(BANNER)

    from .wizard import run_wizard

    run_wizard()
