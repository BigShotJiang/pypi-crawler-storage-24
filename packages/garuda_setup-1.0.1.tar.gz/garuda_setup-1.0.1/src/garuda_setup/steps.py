"""Interactive wizard step functions.

Each ``step_*`` function takes a :class:`SetupConfig` and mutates it
based on user responses.
"""

from __future__ import annotations

import os
from pathlib import Path

from .config import SetupConfig
from .constants import (
    DEFAULT_EMBED_MODEL,
    DEFAULT_OLLAMA_MODEL,
    DEFAULT_PORT,
    DEFAULT_QDRANT_COLLECTION,
    DEFAULT_VNC_RES,
)
from .detect import detect_docker, detect_gpu, detect_apple_silicon
from .prompt import (
    ask,
    ask_choice,
    ask_path,
    ask_yes_no,
    bold,
    cyan,
    dim,
    generate_api_key,
    green,
    header,
    red,
    yellow,
)


# ── 1. Welcome / Prerequisites ──────────────────────────────────


def step_welcome(cfg: SetupConfig) -> bool:
    """Display welcome, check prerequisites.  Returns False to abort."""
    header("Welcome")
    print("  This wizard creates a self-contained Garuda System directory.")
    print("  It will generate docker-compose.yml, .env, and launcher scripts.")
    print()

    docker = detect_docker()
    if docker:
        print(green(f"  ✓ Container runtime: {docker}"))
    else:
        if cfg.os_type == "macos":
            print(yellow("  ⚠ Docker not found — install Docker Desktop or Colima:"))
            print(dim("      brew install --cask docker"))
            print(dim("      # or: brew install colima && colima start"))
        elif cfg.os_type == "windows":
            print(yellow("  ⚠ Docker not found — install Docker Desktop for Windows."))
        else:
            print(yellow("  ⚠ Docker/Podman not found — you'll need it to run the container."))

    gpu = detect_gpu()
    if gpu:
        print(green("  ✓ NVIDIA GPU detected"))
    elif cfg.os_type == "macos":
        if detect_apple_silicon():
            print(green("  ✓ Apple Silicon detected"))
            print(dim("    ℹ GPU passthrough is not available in Docker on macOS."))
            print(dim("      Ollama runs in CPU mode; connect a remote GPU via Cloud."))
        else:
            print(dim("  ℹ Intel Mac — CPU-only mode"))
    else:
        print(dim("  ℹ No NVIDIA GPU detected (CPU-only mode)"))

    print(f"  ℹ Operating system: {bold(cfg.os_type)}")
    print()
    return ask_yes_no("Continue?", True)


# ── 2. Install Directory ────────────────────────────────────────


def step_install_dir(cfg: SetupConfig) -> None:
    header("Install Directory")
    default = _default_install_dir(cfg.os_type)
    print(f"  All files will be created inside this directory.")
    cfg.install_dir = ask_path("Install directory", default)


def _default_install_dir(os_type: str) -> str:
    home = Path.home()
    if os_type == "windows":
        return str(home / "Garuda")
    return str(home / "garuda")


# ── 3. Security ─────────────────────────────────────────────────


def step_security(cfg: SetupConfig) -> None:
    header("Security")

    choice = ask_choice(
        "API key protects the web interface:",
        ["Auto-generate a key (recommended)", "Enter my own key", "No key (open access)"],
        default=0,
    )
    if choice == 0:
        cfg.api_key = generate_api_key()
        print(green(f"  ✓ Generated: {cfg.api_key}"))
    elif choice == 1:
        cfg.api_key = ask("API key")
    else:
        cfg.api_key = ""
        print(yellow("  ⚠ No API key — the web UI will be open to anyone who can reach it."))


# ── 4. Ports ────────────────────────────────────────────────────


def step_ports(cfg: SetupConfig) -> None:
    header("Network")
    val = ask("Web UI port", str(DEFAULT_PORT))
    try:
        cfg.port = int(val)
    except ValueError:
        cfg.port = DEFAULT_PORT
        print(yellow(f"  Using default port {DEFAULT_PORT}"))


# ── 5. Services ─────────────────────────────────────────────────


def step_services(cfg: SetupConfig) -> None:
    header("Services")

    cfg.enable_ide = ask_yes_no("Enable IDE / App Designer?", True)
    cfg.enable_ollama = ask_yes_no("Enable built-in Ollama (local LLM)?", False)

    if cfg.os_type == "macos":
        cfg.enable_gpu = False
        if detect_gpu():
            print(dim("  ℹ GPU passthrough is not supported in Docker on macOS."))
    elif detect_gpu():
        cfg.enable_gpu = ask_yes_no("Enable GPU passthrough?", True)
    else:
        cfg.enable_gpu = False

    cfg.enable_shell = ask_yes_no("Enable terminal/shell access?", False)
    cfg.enable_vnc = ask_yes_no("Enable VNC desktop?", False)

    if cfg.enable_vnc:
        cfg.vnc_password = ask("VNC password", "garuda", secret=True)
        cfg.vnc_resolution = ask("VNC resolution", DEFAULT_VNC_RES)


# ── 6. External Services ────────────────────────────────────────


def step_external_services(cfg: SetupConfig) -> None:
    header("External Services (Optional)")
    print("  Leave blank to use the built-in bundled services.")
    print()

    cfg.external_db_url = ask("PostgreSQL URL")
    cfg.external_qdrant_url = ask("Qdrant URL")
    if not cfg.enable_ollama:
        cfg.external_ollama_url = ask("Ollama URL (remote LLM)")


# ── 7. Models ───────────────────────────────────────────────────


def step_models(cfg: SetupConfig) -> None:
    header("AI Models")

    cfg.ollama_model = ask("LLM model", DEFAULT_OLLAMA_MODEL)
    cfg.embed_model = ask("Embedding model", DEFAULT_EMBED_MODEL)
    cfg.qdrant_collection = ask("Qdrant collection name", DEFAULT_QDRANT_COLLECTION)


# ── 8. Data Watch ───────────────────────────────────────────────


def step_data_watch(cfg: SetupConfig) -> None:
    header("Data Watch")
    print("  Automatically ingest files dropped into the watch/ directory.")
    cfg.data_watch_enabled = ask_yes_no("Enable data watch?", True)


# ── 9. Cloud / Server ───────────────────────────────────────────


def step_cloud(cfg: SetupConfig) -> None:
    header("Cloud / Garuda Server (Optional)")
    print("  Connect to a Garuda Cloud server for team features & GPU cloud.")
    cfg.server_url = ask("Server URL (leave blank to skip)")
    cfg.cors_origins = ask("CORS origins", "*")


# ── 10. Credential Mounts ───────────────────────────────────────


def step_credentials_and_mounts(cfg: SetupConfig) -> None:
    header("Host Mounts")

    _check_credential_mount(
        cfg,
        "GitHub Copilot",
        _copilot_host_path(cfg.os_type),
        "/home/user/.config/github-copilot",
        lambda v: setattr(cfg, "mount_github_copilot", v),
    )
    _check_credential_mount(
        cfg,
        "GitHub CLI",
        _gh_cli_host_path(cfg.os_type),
        "/home/user/.config/gh",
        lambda v: setattr(cfg, "mount_gh_cli", v),
    )

    ssh_path = _ssh_host_path()
    if Path(ssh_path).exists():
        print(green(f"  ✓ Found SSH keys: {ssh_path}"))
        if ask_yes_no("  Mount SSH keys into container? (read-only)", False):
            cfg.extra_host_mounts.append((ssh_path, "/home/user/.ssh:ro"))

    print()
    if ask_yes_no("Mount additional host directories?", False):
        while True:
            host = ask_path("Host path (empty to stop)")
            if not host:
                break
            cont = ask("Container path", f"/mnt/{Path(host).name}")
            cfg.extra_host_mounts.append((host, cont))
            print(green(f"  ✓ {host} → {cont}"))


# ── Helpers ──────────────────────────────────────────────────────


def _copilot_host_path(os_type: str) -> str:
    home = str(Path.home())
    if os_type == "windows":
        return os.path.join(home, "AppData", "Local", "github-copilot")
    if os_type == "macos":
        # Some macOS installs use Library/Application Support
        lib_path = os.path.join(home, "Library", "Application Support", "github-copilot")
        if os.path.exists(lib_path):
            return lib_path
        return os.path.join(home, ".config", "github-copilot")
    return os.path.join(home, ".config", "github-copilot")


def _gh_cli_host_path(os_type: str) -> str:
    home = str(Path.home())
    if os_type == "windows":
        return os.path.join(home, "AppData", "Roaming", "GitHub CLI")
    return os.path.join(home, ".config", "gh")


def _ssh_host_path() -> str:
    return os.path.join(str(Path.home()), ".ssh")


def _check_credential_mount(
    cfg: SetupConfig,
    name: str,
    host_path: str,
    container_path: str,
    setter: object,
) -> None:
    if Path(host_path).exists():
        print(green(f"  ✓ Found {name} config: {host_path}"))
        if ask_yes_no(f"  Mount {name} into container?", True):
            setter(True)  # type: ignore[operator]
            cfg.extra_host_mounts.append((host_path, container_path))
            return
    else:
        print(dim(f"  ℹ {name} config not found at {host_path}"))
    setter(False)  # type: ignore[operator]
