"""Environment detection utilities (Docker, GPU, OS, Apple Silicon)."""

from __future__ import annotations

import platform
import shutil
import subprocess
from typing import List, Optional


def detect_os() -> str:
    """Return 'linux', 'macos', or 'windows'."""
    s = platform.system().lower()
    if s == "darwin":
        return "macos"
    return s


def detect_docker() -> Optional[str]:
    """Return the docker/podman command name, or None."""
    for cmd in ("docker", "podman"):
        if shutil.which(cmd):
            return cmd
    return None


def detect_docker_compose(docker_cmd: str) -> Optional[List[str]]:
    """Return the compose command as a list, or None."""
    try:
        subprocess.run(
            [docker_cmd, "compose", "version"],
            capture_output=True,
            timeout=10,
        )
        return [docker_cmd, "compose"]
    except Exception:
        pass
    if shutil.which("docker-compose"):
        return ["docker-compose"]
    return None


def detect_gpu() -> bool:
    """Return True if an NVIDIA GPU is detected (Linux only)."""
    if detect_os() != "linux":
        return False
    if not shutil.which("nvidia-smi"):
        return False
    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return r.returncode == 0 and bool(r.stdout.strip())
    except Exception:
        return False


def detect_apple_silicon() -> bool:
    """Return True if running on Apple Silicon (M-series)."""
    if platform.system() != "Darwin":
        return False
    return platform.machine() in ("arm64", "aarch64")


def detect_docker_desktop() -> bool:
    """Return True if Docker Desktop is the active Docker context (macOS/Windows)."""
    docker = detect_docker()
    if not docker:
        return False
    try:
        r = subprocess.run(
            [docker, "info", "--format", "{{.Name}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        name = r.stdout.strip().lower()
        return "desktop" in name or "docker-desktop" in name
    except Exception:
        return False


def detect_colima() -> bool:
    """Return True if Colima is available (popular Docker alternative on macOS)."""
    return shutil.which("colima") is not None
