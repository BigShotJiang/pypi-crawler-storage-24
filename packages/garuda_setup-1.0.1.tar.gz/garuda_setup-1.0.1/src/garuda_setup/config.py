"""Setup configuration dataclass."""

from __future__ import annotations

import os
from typing import Dict, List, Tuple

from .constants import (
    DEFAULT_EMBED_MODEL,
    DEFAULT_OLLAMA_MODEL,
    DEFAULT_PORT,
    DEFAULT_QDRANT_COLLECTION,
    DEFAULT_VNC_RES,
)
from .detect import detect_os


class SetupConfig:
    """Collects all user choices during the setup wizard."""

    def __init__(self) -> None:
        self.os_type = detect_os()

        # Install directory — root of the self-contained deployment
        self.install_dir: str = ""

        # Credential mounts
        self.mount_github_copilot: bool = False
        self.mount_gh_cli: bool = False
        self.extra_host_mounts: List[Tuple[str, str]] = []

        # Ports
        self.port: int = DEFAULT_PORT

        # Services
        self.enable_ide: bool = True
        self.enable_ollama: bool = False
        self.enable_gpu: bool = False
        self.enable_shell: bool = False
        self.enable_vnc: bool = False

        # External services
        self.external_db_url: str = ""
        self.external_qdrant_url: str = ""
        self.external_ollama_url: str = ""

        # Models
        self.ollama_model: str = DEFAULT_OLLAMA_MODEL
        self.embed_model: str = DEFAULT_EMBED_MODEL

        # Security
        self.api_key: str = ""

        # Qdrant
        self.qdrant_collection: str = DEFAULT_QDRANT_COLLECTION

        # VNC
        self.vnc_password: str = "garuda"
        self.vnc_resolution: str = DEFAULT_VNC_RES

        # Data watch
        self.data_watch_enabled: bool = True

        # Cloud / Server
        self.server_url: str = ""
        self.cors_origins: str = "*"

        # Advanced
        self.custom_env: Dict[str, str] = {}

    # ── Derived paths inside install_dir ─────────────────────────

    @property
    def data_dir(self) -> str:
        return os.path.join(self.install_dir, "data")

    @property
    def home_dir(self) -> str:
        return os.path.join(self.install_dir, "home")

    @property
    def watch_dir(self) -> str:
        return os.path.join(self.install_dir, "watch")

    # ── Serialize to env dict ────────────────────────────────────

    def to_env_dict(self) -> Dict[str, str]:
        env: Dict[str, str] = {}

        env["GARUDA_PORT"] = str(self.port)

        if self.api_key:
            env["GARUDA_API_KEY"] = self.api_key
            env["GARUDA_UI_API_KEY"] = self.api_key

        env["GARUDA_DISABLE_IDE"] = "true" if not self.enable_ide else "false"
        env["GARUDA_ENABLE_OLLAMA"] = "true" if self.enable_ollama else "false"
        env["GARUDA_ENABLE_SHELL"] = "true" if self.enable_shell else "false"
        env["GARUDA_ENABLE_VNC"] = "true" if self.enable_vnc else "false"

        if self.external_db_url:
            env["GARUDA_DB_URL"] = self.external_db_url
        if self.external_qdrant_url:
            env["GARUDA_QDRANT_URL"] = self.external_qdrant_url
        if self.external_ollama_url:
            env["GARUDA_OLLAMA_URL"] = self.external_ollama_url

        env["GARUDA_OLLAMA_MODEL"] = self.ollama_model
        env["GARUDA_EMBED_MODEL"] = self.embed_model
        env["GARUDA_QDRANT_COLLECTION"] = self.qdrant_collection

        env["GARUDA_UI_CORS_ORIGINS"] = self.cors_origins
        env["GARUDA_LOCAL_DATA_WATCH_ENABLED"] = (
            "true" if self.data_watch_enabled else "false"
        )

        if self.enable_vnc:
            env["VNC_PASSWORD"] = self.vnc_password
            env["VNC_RESOLUTION"] = self.vnc_resolution

        if self.server_url:
            env["GARUDA_SERVER_URL"] = self.server_url

        env.update(self.custom_env)
        return env
