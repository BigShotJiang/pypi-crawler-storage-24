"""
garuda_setup — Interactive setup wizard for Garuda System.

Creates a self-contained install directory with docker-compose.yml,
.env, data directories, and launcher scripts.
"""

__version__ = "1.0.1"
