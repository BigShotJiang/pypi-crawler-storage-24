# Garuda Setup

Interactive cross-platform setup wizard for **Garuda System**.

Creates a self-contained install directory with `docker-compose.yml`,
`.env`, data directories, and launcher scripts — no source checkout needed.

## Quick Start

```bash
# Install from PyPI
pip install garuda-setup

# Or install from source
pip install .

# Run the wizard
garuda-setup
```

Or run directly without installing:

```bash
python -m garuda_setup
```

### macOS Prerequisites

Install Docker Desktop or Colima:

```bash
brew install --cask docker
# or
brew install colima && colima start
```

> **Note**: GPU passthrough is not available in Docker on macOS.
> Ollama runs in CPU mode; connect a remote GPU via Garuda Cloud.

## What It Does

1. Asks for an install directory (e.g. `~/garuda`)
2. Creates the directory tree:
   ```
   ~/garuda/
   ├── docker-compose.yml   # pulls docker.nxs.solutions/garuda/garuda-system:latest
   ├── .env                 # all configuration
   ├── garuda.sh            # launcher (Linux/macOS)
   ├── garuda.ps1           # launcher (Windows PowerShell)
   ├── garuda.bat            # launcher (Windows CMD)
   ├── README.md
   ├── data/
   │   ├── garuda/          # databases & indexes
   │   ├── qdrant/          # vector search
   │   ├── postgres/        # PostgreSQL
   │   └── ollama/          # LLM models
   ├── home/                # container home directory
   └── watch/               # drop files here for auto-ingestion
   ```
3. Optionally pulls the image and starts the container

On **macOS**, a `Garuda.command` file is also generated — double-click it in
Finder to start the container and open your browser automatically.

## Configuration Options

The wizard walks through:

- **Install directory** — where everything lives
- **API key** — auto-generate, provide your own, or skip
- **Port** — default 7331
- **Services** — IDE, Ollama, GPU passthrough, shell access, VNC desktop
- **External services** — connect to existing PostgreSQL, Qdrant, or Ollama
- **AI models** — LLM model and embedding model selection
- **Cloud** — connect to Garuda Cloud server
- **Credential mounts** — GitHub Copilot, GH CLI
- **Extra host mounts** — mount host directories for observation

## Launcher Commands

After setup, use the generated launcher:

```bash
cd ~/garuda
./garuda.sh up        # start
./garuda.sh down      # stop
./garuda.sh logs      # follow logs
./garuda.sh update    # pull latest image & restart
./garuda.sh status    # show container status
./garuda.sh shell     # bash into container
./garuda.sh config    # show current config
```

Windows: use `garuda.bat` or `garuda.ps1` instead.
