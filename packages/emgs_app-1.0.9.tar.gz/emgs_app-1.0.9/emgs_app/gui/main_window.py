from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from PyQt6 import QtCore, QtGui, QtWidgets

from .. import config
from ..controller import EmgsController
from .mixins.connect_actions import ConnectActionsMixin
from .mixins.runtime import MainWindowRuntimeMixin
from .mixins.session_controls import SignalsScenarioSessionMixin
from .mixins.signals_plotting import SignalsPlotMixin
from .mixins.settings_profiles import SettingsProfilesMixin
from .tabs.connect_tab import build_connect_tab
from .tabs.scenario_tab import build_scenario_tab
from .tabs.settings_tab import build_settings_tab
from .tabs.signals_tab import build_signals_tab
from .widgets import (
    ScenarioControlTile,
)

if TYPE_CHECKING:
    from ..recording import RecordingSession


class MainWindow(
    QtWidgets.QMainWindow,
    SettingsProfilesMixin,
    ConnectActionsMixin,
    SignalsScenarioSessionMixin,
    SignalsPlotMixin,
    MainWindowRuntimeMixin,
):
    def __init__(self, controller: EmgsController) -> None:
        super().__init__()
        self.controller = controller
        self._ui_settings = QtCore.QSettings("emgs", "emgs_app")
        self._init_state()

        self.setWindowTitle(config.APP_TITLE)
        self.resize(1200, 800)

        self._build_actions()
        self._build_ui()
        self._wire_signals()
        self._restore_last_profile()

        self._plot_timer = QtCore.QTimer(self)
        self._plot_timer.setInterval(config.PLOT_REFRESH_MS)
        self._plot_timer.timeout.connect(self._refresh_plots)
        self._plot_timer.start()

        # Periodic lightweight polling to keep table state fresh for connected devices.
        self._poll_timer = QtCore.QTimer(self)
        self._poll_timer.setInterval(int(config.DEVICE_POLL_INTERVAL_S * 1000))
        self._poll_timer.timeout.connect(self._poll_connected_devices)
        self._poll_timer.start()

        # Slow cadence "all info" refresh (heavier than A3 poll). Skip streaming devices by default.
        self._full_update_timer = QtCore.QTimer(self)
        self._full_update_timer.setInterval(int(config.DEVICE_FULL_UPDATE_INTERVAL_S * 1000))
        self._full_update_timer.timeout.connect(self._full_update_connected_devices)
        self._full_update_timer.start()

        # Global quick-exit shortcut (works even when dialogs have focus).
        # This avoids confusion where Esc closes a dialog but leaves devices connected.
        try:
            self._esc_shortcut = QtGui.QShortcut(QtGui.QKeySequence(QtCore.Qt.Key.Key_Escape), self)
            self._esc_shortcut.setContext(QtCore.Qt.ShortcutContext.ApplicationShortcut)
            self._esc_shortcut.activated.connect(self.close)
        except Exception:
            self._esc_shortcut = None

    def _init_state(self) -> None:
        """Initialize internal state (kept out of `__init__` for readability)."""
        self._closing: bool = False
        self._plot_frozen: bool = False
        self._plot_refresh_tick: int = 0
        # Legacy: keep internal plot budget string for debugging/perf; no longer shown in UI label.
        self._plot_budget_status: str = ""
        self._plot_dyn_every: int = 1
        self._plot_last_refresh_ms: float = 0.0
        self._plot_last_tick_monotonic_s: float = 0.0
        self._plot_loop_lag_ms: float = 0.0
        self._plot_fast_rendering: bool = True

        self._recorder: RecordingSession | None = None
        self._recording: bool = False
        self._signals_session_start_monotonic_s: float | None = None
        self._recording_start_monotonic_s: float | None = None
        self._last_recording_duration_s: float | None = None

        # Recording settings (UI-controlled).
        self._rec_out_dir: str = str(Path.home() / str(getattr(config, "DEFAULT_REC_OUT_DIRNAME", "rr_data")))
        self._rec_emg_fields_all: tuple[str, ...] = tuple(getattr(config, "REC_EMG_FIELDS_ALL", ()))
        self._rec_imu_fields_all: tuple[str, ...] = tuple(getattr(config, "REC_IMU_FIELDS_ALL", ()))
        self._rec_robot_fields_all: tuple[str, ...] = tuple(getattr(config, "REC_ROBOT_FIELDS_ALL", ()))
        # Default: select none (user chooses).
        self._rec_emg_fields_selected: set[str] = set()
        self._rec_imu_fields_selected: set[str] = set()
        self._rec_robot_fields_selected: set[str] = set()

        # Per-device plot origin (latched on first EMG/IMU data packet after Start Stream).
        self._device_origin_s: dict[str, float | None] = {}
        self._device_origin_armed_addrs: set[str] = set()
        self._device_origin_arm_monotonic_s: float = 0.0

        # Scenario page state.
        self._scenario_active_key: str | None = None
        self._scenario_controls: dict[str, ScenarioControlTile] = {}

    # ---------- UI ----------
    def _build_actions(self) -> None:
        self.action_scan = QtGui.QAction("Scan", self)
        self.action_select_all = QtGui.QAction("Select All", self)
        self.action_select_none = QtGui.QAction("Select None", self)
        self.action_connect = QtGui.QAction("Connect", self)
        self.action_disconnect = QtGui.QAction("Disconnect", self)
        self.action_update = QtGui.QAction("Update Info", self)
        self.action_settings = QtGui.QAction("Settings…", self)
        self.action_time_sync = QtGui.QAction("Time Sync", self)
        self.action_bulk_modes = QtGui.QAction("Bulk Mode Settings…", self)
        # Streaming is controlled from the Signals tab only (not from Connect tab).
        self.action_stream_start = QtGui.QAction("Start Stream", self)
        self.action_stream_stop = QtGui.QAction("Stop Stream", self)

    def _build_ui(self) -> None:
        # Main tabs
        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)

        build_connect_tab(self)
        build_signals_tab(self)
        build_scenario_tab(self)
        build_settings_tab(self)

        # Tab-changed behavior is owned by MainWindow (affects LED selection).
        self.tabs.currentChanged.connect(self._on_tab_changed)

        # Status bar
        self.status = QtWidgets.QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage(f"Backend: {self.controller.backend_kind}")

        self._trace_colors = ["#4ea1ff", "#2ed573", "#ffa502", "#ff4757", "#9b59ff", "#00d2d3", "#e67e22"]
        self._trace_color_i = 0
        self._refresh_signal_device_list()
        self._refresh_scenario_device_list()
        self._sync_scenario_controls()
        self._update_signal_rx_status()
        # Per-cluster default palettes (rotate when creating new clusters).
        self._sig_group_palette: dict[str, dict[str, str]] = {}
        self._sig_palette_sets: list[dict[str, str]] = [
            {"X": "#ff4757", "Y": "#2ed573", "Z": "#4ea1ff", "W": "#c8d6e5"},  # red/green/blue (+W grey)
            {"X": "#9b59ff", "Y": "#00d2d3", "Z": "#e67e22", "W": "#d7e1ff"},  # purple/cyan/orange (+W light)
            {"X": "#f368e0", "Y": "#10ac84", "Z": "#54a0ff", "W": "#c8d6e5"},  # pink/teal/blue (+W grey)
            {"X": "#ee5253", "Y": "#c8d6e5", "Z": "#feca57", "W": "#d7e1ff"},  # red/grey/yellow (+W light)
        ]

