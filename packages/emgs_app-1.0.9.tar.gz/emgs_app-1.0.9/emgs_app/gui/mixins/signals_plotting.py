from __future__ import annotations

import numpy as np
from PyQt6 import QtCore

from ..widgets import SignalGroupControl


class SignalsPlotMixin:
    def _signals_apply_preset_for_selected_device(self, preset_id: int = 1) -> None:
        """Clear plot and add recommended curves for the selected device kind (EMGS vs AKR)."""
        addr = self.combo_sig_device.currentData()
        if not isinstance(addr, str) or not addr:
            self.log_view.append_line("Signals: no device selected")
            return
        addr = str(addr)

        dev = self.controller.manager.devices.get(addr)
        kind = str(getattr(getattr(dev, "params", None), "kind", "EMGS")).upper() if dev else "EMGS"

        if kind == "AKR":
            if int(preset_id) == 2:
                # Fixed AKR preset bundle.
                presets = [
                    ("Robot: Walk", "IMU Gyr", "XYZ"),
                    ("Robot: Walk", "Model", "out"),
                    ("Robot: Walk", "Model", "state"),
                    ("Robot: Motor", "Motor", "pos_rad"),
                    ("Robot: Motor", "Motor", "tq_nm"),
                    ("Robot: Motor", "Motor", "temp_c"),
                    ("Robot: Motor", "Motor", "vbus_v"),
                ]
                akr_mode = "preset2"
            else:
                # Preset1: require explicit signal selection from the Signal combo.
                sel_signal = self.combo_sig_type.currentData()
                akr_mode_map = {
                    "robot: motor": "motor",
                    "robot: walk": "walk",
                    "robot: cpm": "cpm",
                    "robot: measure": "measure",
                    "robot: test": "test",
                    "motor": "motor",
                    "walk": "walk",
                    "cpm": "cpm",
                    "measure": "measure",
                    "test": "test",
                }
                akr_mode = akr_mode_map.get(str(sel_signal or "").strip().lower())
                if akr_mode is None:
                    # Make Preset1 usable immediately when entering Signals tab.
                    akr_mode = "motor"
                    try:
                        for i in range(self.combo_sig_type.count()):
                            if str(self.combo_sig_type.itemData(i) or "").strip().lower() == "robot: motor":
                                self.combo_sig_type.setCurrentIndex(i)
                                break
                    except Exception:
                        pass
                    self.log_view.append_line("Signals: Preset1 defaulted to Robot: Motor (no signal selected)")
                if akr_mode == "motor":
                    presets = [
                        ("Robot: Motor", "Motor", "pos_rad"),
                        ("Robot: Motor", "Motor", "vel_rad_s"),
                        ("Robot: Motor", "Motor", "tq_nm"),
                        ("Robot: Motor", "Motor", "temp_c"),
                        ("Robot: Motor", "Motor", "vbus_v"),
                    ]
                elif akr_mode == "cpm":
                    presets = [
                        ("Robot: CPM", "State", "cpm_state"),
                        ("Robot: CPM", "Motor", "pos_rad"),
                        ("Robot: CPM", "Motor", "vel_rad_s"),
                        ("Robot: CPM", "Motor", "tq_nm"),
                        ("Robot: CPM", "Motor", "temp_c"),
                        ("Robot: CPM", "Motor", "vbus_v"),
                    ]
                elif akr_mode in {"measure", "test"}:
                    # Firmware currently publishes MEASURE/TEST-style telemetry via the same test packet family.
                    presets = [
                        ("Robot: Measure", "State", "measure_state"),
                        ("Robot: Measure", "Motor", "pos_rad"),
                        ("Robot: Measure", "Motor", "vel_rad_s"),
                        ("Robot: Measure", "Motor", "tq_nm"),
                        ("Robot: Measure", "Motor", "temp_c"),
                        ("Robot: Measure", "Motor", "vbus_v"),
                    ]
                else:
                    presets = [
                        ("Robot: Walk", "Model", "state"),
                        ("Robot: Walk", "Motor", "pos_rad"),
                        ("Robot: Walk", "Motor", "vel_rad_s"),
                        ("Robot: Walk", "Motor", "tq_nm"),
                        ("Robot: Walk", "Motor", "temp_c"),
                        ("Robot: Walk", "Motor", "vbus_v"),
                    ]
        else:
            if int(preset_id) == 2:
                presets = [
                    ("Processed Data", "EMG RMS Envelope", "Raw EMG + RMS Envelope Overlay"),
                    ("Processed Data", "EMG Frequency Features", "Mean Frequency (MNF)"),
                ]
            else:
                presets = [
                    ("Accelerometer (ACC)", "Calibrated", "XYZ"),
                    ("Gyroscope (GYR)", "Calibrated", "XYZ"),
                    ("Magnetometer (MAG)", "Calibrated", "XYZ"),
                    ("Processed Data", "EMG RMS Envelope", "Raw EMG + RMS Envelope Overlay"),
                ]

        # Clear only after a valid preset set is resolved.
        self._remove_all_traces()

        ok = 0
        for type_label, mode_label, axis_label in presets:
            if self._signals_add_trace_by_labels(addr, type_label, mode_label, axis_label):
                ok += 1

        if kind == "AKR":
            ptxt = "Preset2" if int(preset_id) == 2 else "Preset1"
            self.log_view.append_line(f"Signals: {ptxt} applied for {kind}/{akr_mode} ({ok}/{len(presets)} items)")
        else:
            ptxt = "Preset2" if int(preset_id) == 2 else "Preset1"
            self.log_view.append_line(f"Signals: {ptxt} applied for {kind} ({ok}/{len(presets)} items)")

    def _signals_add_trace_by_labels(self, addr: str, type_label: str, mode_label: str, axis_label: str) -> bool:
        """Drive the existing combobox UI + `_add_trace_from_ui()` using text labels.

        Returns True if a trace/group was added (best-effort), False if selection failed.
        """

        def _set_combo_by_data(combo, want) -> bool:
            for i in range(combo.count()):
                if combo.itemData(i) == want:
                    combo.setCurrentIndex(i)
                    return True
            return False

        def _set_combo_by_text(combo, want: str) -> bool:
            want = str(want)
            for i in range(combo.count()):
                if str(combo.itemText(i)) == want:
                    combo.setCurrentIndex(i)
                    return True
            return False

        def _set_combo_by_data_str_ci(combo, want: str) -> bool:
            want = str(want).strip().lower()
            for i in range(combo.count()):
                v = combo.itemData(i)
                if isinstance(v, str) and v.strip().lower() == want:
                    combo.setCurrentIndex(i)
                    return True
            return False

        # Select device (if needed).
        try:
            if str(self.combo_sig_device.currentData() or "") != str(addr):
                # Prefer matching on itemData (address stored as data).
                if not _set_combo_by_data(self.combo_sig_device, str(addr)):
                    # Fallback: match visible text if needed.
                    _set_combo_by_text(self.combo_sig_device, str(addr))
        except Exception:
            pass

        # Type is stored as itemData (type label string).
        if not _set_combo_by_data(self.combo_sig_type, type_label):
            # Some items may have data==label but with different object identity; try case-insensitive match.
            if not _set_combo_by_data_str_ci(self.combo_sig_type, type_label):
                return False

        # Mode combo items are dicts in itemData; use visible text.
        if not _set_combo_by_text(self.combo_sig_mode, mode_label):
            return False

        # Axis items use axis label as both text and data; match text.
        if axis_label:
            if not _set_combo_by_text(self.combo_sig_axis, axis_label):
                # Case-insensitive fallback for axes like "state" / "STATE".
                want = str(axis_label).strip().lower()
                for i in range(self.combo_sig_axis.count()):
                    if str(self.combo_sig_axis.itemText(i)).strip().lower() == want:
                        self.combo_sig_axis.setCurrentIndex(i)
                        break

        try:
            self._add_trace_from_ui()
            return True
        except Exception:
            return False

    def _init_signal_presets_map(self) -> None:
        self._signal_presets_map = {
            "Electromyography (EMG)": {
                "group": "EMG",
                "modes": [
                    {
                        "label": "Raw",
                        "data": {"mode": "raw"},
                        "axes": [
                            "Raw only",
                            "Raw + Packet RMS overlay",
                        ],
                    },
                    {"label": "Packet RMS (10 Hz)", "data": {"mode": "pkt_rms"}},
                    {"label": "SNR", "data": {"mode": "snr"}},
                ]
            },
            "Accelerometer (ACC)": {
                "group": "ACC",
                "modes": [
                    {"label": "Raw", "data": {"mode": "raw"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Calibrated", "data": {"mode": "cal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Linear", "data": {"mode": "linear"}, "axes": ["XYZ", "X", "Y", "Z"]},
                ]
            },
            "Gyroscope (GYR)": {
                "group": "GYR",
                "modes": [
                    {"label": "Raw", "data": {"mode": "raw"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Calibrated", "data": {"mode": "cal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                ]
            },
            "Magnetometer (MAG)": {
                "group": "MAG",
                "modes": [
                    {"label": "Uncalibrated", "data": {"mode": "uncal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Calibrated", "data": {"mode": "cal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                ]
            },
            "Quaternion": {
                "group": "QUAT",
                "modes": [
                    {"label": "Game rotation vector", "data": {"mode": "game"}, "axes": ["WXYZ", "W", "X", "Y", "Z"]},
                    {"label": "Geomag rotation vector", "data": {"mode": "geomag"}, "axes": ["WXYZ", "W", "X", "Y", "Z"]},
                ]
            },
            "Processed Data": {
                "group": "PROCESSED",
                "modes": [
                    {
                        "label": "EMG RMS Envelope",
                        "data": {"mode": "emg_env"},
                        "axes": [
                            "RMS Envelope only",
                            "Raw EMG + RMS Envelope Overlay",
                        ],
                    },
                    {
                        "label": "EMG Frequency Features",
                        "data": {"mode": "emg_freq"},
                        "axes": [
                            "Median Frequency (MDF)",
                            "Mean Frequency (MNF)",
                        ],
                    },
                    {
                        "label": "EMG Spectrum (PSD)",
                        "data": {"mode": "emg_psd"},
                        "axes": [
                            "0–500 Hz mapped to 0–3 s",
                        ],
                    },
                    {
                        "label": "EMG Spectrum (relative power)",
                        "data": {"mode": "emg_psd_lin"},
                        "axes": [
                            "0–500 Hz mapped to 0–3 s",
                        ],
                    },
                    {
                        "label": "Fatigue (unsupervised)",
                        "data": {"mode": "emg_fatigue"},
                        "axes": [
                            "Score (0–1)",
                            "Confidence (0–1)",
                            "Score + Confidence overlay",
                        ],
                    },
                ]
            },
            "Robot: Walk": {
                "group": "ROBOT_WALK",
                "modes": [
                    {"label": "Timing", "data": {"mode": "timing"}, "axes": ["exec_ms"]},
                    {"label": "Model", "data": {"mode": "model"}, "axes": ["out", "state"]},
                    {"label": "IMU Acc", "data": {"mode": "acc"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "IMU Gyr", "data": {"mode": "gyr"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "IMU Mag", "data": {"mode": "mag"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
            "Robot: Motor": {
                "group": "ROBOT_MOTOR",
                "modes": [
                    {"label": "Timing", "data": {"mode": "timing"}, "axes": ["dt_ms", "fid"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
            "Robot: CPM": {
                "group": "ROBOT_CPM",
                "modes": [
                    {"label": "State", "data": {"mode": "state"}, "axes": ["cpm_state", "dir", "blocked_event", "blocked_consecutive"]},
                    {"label": "Command", "data": {"mode": "cmd"}, "axes": ["cmd_spd_rad_s"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Limits", "data": {"mode": "limits"}, "axes": ["df_limit_rad", "pf_limit_rad"]},
                    {"label": "Progress", "data": {"mode": "progress"}, "axes": ["elapsed_s", "repetition_count"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
            "Robot: Measure": {
                "group": "ROBOT_MEASURE",
                "modes": [
                    {"label": "State", "data": {"mode": "state"}, "axes": ["measure_state", "dir", "blocked", "result_flags"]},
                    {"label": "Flags", "data": {"mode": "flags"}, "axes": ["prom_df_valid", "prom_pf_valid", "arom_valid", "seq_active", "arom_running"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Results", "data": {"mode": "results"}, "axes": ["prom_df_end_rad", "prom_pf_end_rad", "arom_df_max_rad", "arom_pf_min_rad"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
        }

    def _populate_signal_type_combo(self) -> None:
        def _sig_dev_kind() -> str:
            try:
                addr = self.combo_sig_device.currentData()
                if not isinstance(addr, str) or not addr:
                    return "EMGS"
                dev = self.controller.manager.devices.get(str(addr))
                return str(getattr(dev.params, "kind", "EMGS")).upper() if dev else "EMGS"
            except Exception:
                return "EMGS"

        kind = _sig_dev_kind()
        self.combo_sig_type.blockSignals(True)
        self.combo_sig_type.clear()
        self.combo_sig_type.addItem("Select Type...", None)
        labels = list(self._signal_presets_map.keys())
        # AKR devices: keep the selector minimal (no EMG/QUAT).
        if kind == "AKR":
            labels = [
                "Robot: Motor",
                "Robot: Walk",
                "Robot: CPM",
                "Robot: Measure",
            ]
        else:
            # Robot telemetry is AKR-specific; hide these for EMGS devices to reduce confusion.
            labels = [l for l in labels if not str(l).startswith("Robot:")]
        for label in labels:
            if label in self._signal_presets_map:
                self.combo_sig_type.addItem(label, label)
        self.combo_sig_type.blockSignals(False)
        # Reset dependents
        self._on_signal_type_changed()

    def _on_signal_type_changed(self) -> None:
        type_label = self.combo_sig_type.currentData()

        self.combo_sig_mode.blockSignals(True)
        self.combo_sig_mode.clear()
        self.combo_sig_mode.setEnabled(False)

        self.combo_sig_axis.blockSignals(True)
        self.combo_sig_axis.clear()
        self.combo_sig_axis.setEnabled(False)

        if not type_label:
            self.combo_sig_mode.blockSignals(False)
            self.combo_sig_axis.blockSignals(False)
            return

        group_info = self._signal_presets_map.get(type_label)
        if not group_info:
            self.combo_sig_mode.blockSignals(False)
            self.combo_sig_axis.blockSignals(False)
            return
        modes = group_info.get("modes", [])
        # If AKR device is selected, hide duplicate/unsupported modes to reduce clutter.
        try:
            addr = self.combo_sig_device.currentData()
            dev = self.controller.manager.devices.get(str(addr)) if isinstance(addr, str) else None
            kind = str(getattr(dev.params, "kind", "EMGS")).upper() if dev else "EMGS"
        except Exception:
            kind = "EMGS"
        if kind == "AKR":
            grp = str(group_info.get("group") or "").upper()
            if grp in {"ACC", "GYR", "MAG"}:
                # Keep only the calibrated flavor for AKR (raw/uncal/linear are duplicates or unsupported).
                modes = [m for m in modes if str(m.get("data", {}).get("mode", "")).lower() == "cal"]
        if modes:
            self.combo_sig_mode.setEnabled(True)
            for m in modes:
                self.combo_sig_mode.addItem(m["label"], m)

            # Select first item by default if appropriate
            if self.combo_sig_mode.count() > 0:
                self.combo_sig_mode.setCurrentIndex(0)
                # Manually trigger mode update since we blocked signals or want to force update
                self._on_signal_mode_changed()

        self.combo_sig_mode.blockSignals(False)
        self.combo_sig_axis.blockSignals(False)

    def _on_signal_mode_changed(self) -> None:
        mode_info = self.combo_sig_mode.currentData()

        self.combo_sig_axis.blockSignals(True)
        self.combo_sig_axis.clear()
        self.combo_sig_axis.setEnabled(False)

        if not mode_info:
            self.combo_sig_axis.blockSignals(False)
            return

        axes = mode_info.get("axes", [])
        if axes:
            self.combo_sig_axis.setEnabled(True)
            for ax in axes:
                self.combo_sig_axis.addItem(ax, ax)
            if self.combo_sig_axis.count() > 0:
                self.combo_sig_axis.setCurrentIndex(0)

        self.combo_sig_axis.blockSignals(False)

    def _default_group_config_for_preset(self, preset: object) -> tuple[float, float, float]:
        # Defaults are per-cluster; user can override in the right panel.
        if isinstance(preset, dict):
            grp = (preset.get("group") or "").upper()
            mode = (preset.get("mode") or "").lower()
            axis = (preset.get("axis") or "").lower()
            if grp == "EMG":
                if mode == "pkt_rms":
                    # DSP encodes packet RMS as 0..3 V.
                    return 0.0, 3.0, 1.0
                if mode == "snr":
                    return 0.0, 255.0, 1.0
                return -2.0, 2.0, 1.0
            if grp == "ACC":
                if mode == "raw":
                    return -2000.0, 2000.0, 1.0
                return -2.0, 2.0, 100.0
            if grp == "GYR":
                if mode == "raw":
                    return -2000.0, 2000.0, 1.0
                return -200.0, 200.0, 1.0
            if grp == "MAG":
                return -100.0, 100.0, 10.0
            if grp == "QUAT":
                return -1.0, 1.0, 1.0
            if grp == "PROCESSED":
                # Processed EMG envelope shares EMG scale.
                if mode == "emg_env":
                    return -2.0, 2.0, 1.0
                if mode == "emg_freq":
                    return 0.0, 250.0, 1.0
                if mode == "emg_psd":
                    return -80.0, 0.0, 1.0
                if mode == "emg_psd_lin":
                    return 0.0, 1.0, 1.0
                if mode == "emg_fatigue":
                    return 0.0, 1.0, 1.0
            if grp in {"ROBOT_WALK", "ROBOT_CPM", "ROBOT_TEST", "ROBOT_MEASURE"}:
                if mode in {"timing", "model", "health"}:
                    return 0.0, 5.0, 10.0
                if mode == "state":
                    if axis in {"dir"}:
                        return -1.0, 1.0, 1.0
                    if axis in {"blocked"}:
                        return 0.0, 1.0, 1.0
                    if axis in {"blocked_event"}:
                        return 0.0, 1.0, 1.0
                    if axis in {"blocked_consecutive"}:
                        return 0.0, 16.0, 1.0
                    if axis in {"result_flags"}:
                        return 0.0, 31.0, 1.0
                    if axis in {"test_state", "measure_state", "cpm_state", "out", "state"}:
                        return -1.0, 8.0, 1.0
                    return 0.0, 5.0, 10.0
                if mode == "flags":
                    return 0.0, 1.0, 1.0
                if mode in {"acc"}:
                    return -2.0, 2.0, 100.0
                if mode in {"gyr"}:
                    return -200.0, 200.0, 1.0
                if mode in {"mag"}:
                    return -100.0, 100.0, 10.0
                if mode in {"motor", "cmd", "limits", "results", "progress"}:
                    if axis in {"pos_rad", "prom_df_end_rad", "prom_pf_end_rad", "arom_df_max_rad", "arom_pf_min_rad"}:
                        return -0.6, 0.6, 50.0
                    if axis in {"vel_rad_s"}:
                        return -10.0, 10.0, 5.0
                    if axis in {"tq_nm"}:
                        return -3.0, 3.0, 5.0
                    if axis in {"temp_c"}:
                        return 0.0, 50.0, 1.0
                    if axis in {"vbus_v"}:
                        return 0.0, 80.0, 1.0
                    if axis in {"elapsed_s"}:
                        return 0.0, 120.0, 1.0
                    if axis in {"repetition_count"}:
                        return 0.0, 50.0, 1.0
                    return -50.0, 50.0, 1.0
            if grp == "ROBOT_MOTOR":
                if mode in {"health", "timing"}:
                    return 0.0, 5.0, 10.0
                if mode in {"motor"}:
                    if axis in {"pos_rad"}:
                        return -0.6, 0.6, 50.0
                    if axis in {"vel_rad_s"}:
                        return -10.0, 10.0, 5.0
                    if axis in {"tq_nm"}:
                        return -3.0, 3.0, 5.0
                    if axis in {"temp_c"}:
                        return 0.0, 50.0, 1.0
                    if axis in {"vbus_v"}:
                        return 0.0, 80.0, 1.0
                    return -50.0, 50.0, 1.0
        
        return -1.0, 1.0, 1.0

    def _add_trace_from_ui(self) -> None:
        addr = self.combo_sig_device.currentData()
        if not isinstance(addr, str) or not addr:
            self.log_view.append_line("Signals: no device selected")
            return

        type_label = self.combo_sig_type.currentData()
        mode_info = self.combo_sig_mode.currentData()
        axis_label = self.combo_sig_axis.currentData()

        if not type_label or not mode_info:
            self.log_view.append_line("Signals: please select a valid signal type and mode")
            return

        # Reconstruct the equivalent of the old preset_data
        group_info = self._signal_presets_map.get(type_label, {})
        group_name = group_info.get("group", "")

        preset_data = dict(mode_info.get("data", {}))
        preset_data["group"] = group_name

        full_label_parts = [group_name]
        full_label_parts.append(mode_info["label"])

        if axis_label:
            preset_data["axis"] = axis_label
            full_label_parts.append(axis_label)

        preset_label = " • ".join(full_label_parts)
        preset_data["label"] = preset_label

        y_min, y_max, group_scale = self._default_group_config_for_preset(preset_data)

        # The rest is mostly the same, just using the new preset_label
        group = f"{addr}:{preset_label}"
        label = f"{preset_label}\n{addr}"
        is_new_group = group not in self.multi_plot.list_groups()
        if is_new_group and group not in self._sig_group_palette:
            pal = self._sig_palette_sets[len(self._sig_group_palette) % len(self._sig_palette_sets)]
            self._sig_group_palette[group] = dict(pal)

        def points_from_deque(buf, idx: int, window_s: float, *, origin_s: float | None = None) -> tuple[np.ndarray, np.ndarray] | None:
            if not buf:
                return None
            t_end = float(buf[-1][0])
            t_min = t_end - float(window_s)
            pts: list[tuple[float, float]] = []
            for ts, samples in reversed(buf):
                if ts < t_min:
                    break
                if samples and idx < len(samples):
                    pts.append((float(ts), float(samples[idx])))
            if not pts:
                return None
            pts.reverse()
            t = np.fromiter((p[0] for p in pts), dtype=float, count=len(pts))
            y = np.fromiter((p[1] for p in pts), dtype=float, count=len(pts))
            if origin_s is not None and t.size:
                t = t - float(origin_s)
            return t, y

        axis_map = {"X": 0, "Y": 1, "Z": 2}
        axis_colors = self._sig_group_palette.get(group, {"X": "#ff4757", "Y": "#2ed573", "Z": "#4ea1ff"})

        def dev_or_none():
            return self.controller.manager.devices.get(addr)

        def prov_emg_raw() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.emg_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_emg_pkt_rms() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_packet_rms_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_packet_rms_buffer else None

        def prov_emg_snr() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_snr_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_snr_buffer else None

        def prov_emg_env() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_rms_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_rms_buffer else None

        def prov_emg_mdf() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_median_freq_buffer, 0, 6.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_median_freq_buffer else None

        def prov_emg_mnf() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_mean_freq_buffer, 0, 6.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_mean_freq_buffer else None

        def _map_spectrum_to_time_axis(
            dev: object, f: np.ndarray, y: np.ndarray, *, f_max: float = 500.0, win_s: float = 3.0
        ) -> tuple[np.ndarray, np.ndarray] | None:
            if f is None or y is None or len(f) == 0:
                return None
            f = np.asarray(f, dtype=float)
            y = np.asarray(y, dtype=float)
            # Shift spectrum into the current rolling x-window so it stays visible.
            origin_s = self._device_time_origin_s(addr)
            t_end = None
            buf = getattr(dev, "emg_buffer", None)
            if buf:
                t_end = float(buf[-1][0])
                if origin_s is not None:
                    t_end = t_end - float(origin_s)
            if t_end is None:
                t_end = float(win_s)
            x0 = float(t_end) - float(win_s)
            t = x0 + (f / float(f_max)) * float(win_s)
            return t, y

        def prov_emg_psd_db() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            spec = getattr(dev, "emg_spectrum_last", None)
            if not spec:
                return None
            f, p_db = spec
            return _map_spectrum_to_time_axis(dev, f, p_db)

        def prov_emg_psd_lin() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            spec = getattr(dev, "emg_spectrum_last_linear", None)
            if not spec:
                return None
            f, p_rel = spec
            return _map_spectrum_to_time_axis(dev, f, p_rel)

        def prov_emg_fatigue_score() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return (
                points_from_deque(dev.emg_fatigue_score_buffer, 0, 12.0, origin_s=self._device_time_origin_s(addr))
                if getattr(dev, "emg_fatigue_score_buffer", None)
                else None
            )

        def prov_emg_fatigue_conf() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return (
                points_from_deque(dev.emg_fatigue_conf_buffer, 0, 12.0, origin_s=self._device_time_origin_s(addr))
                if getattr(dev, "emg_fatigue_conf_buffer", None)
                else None
            )

        def prov_acc(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.acc_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_raw_acc(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.raw_acc_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_lin_acc(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.lin_acc_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_gyr(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.gyr_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_raw_gyr(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.raw_gyr_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_mag(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.mag_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_uncal_mag(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.uncal_mag_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_quat(buf_name: str, i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            buf = getattr(dev, buf_name, None)
            return points_from_deque(buf, i, 3.0, origin_s=self._device_time_origin_s(addr)) if buf is not None else None

        def prov_akr_scalar(buf_name: str) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            buf = getattr(dev, buf_name, None)
            return points_from_deque(buf, 0, 6.0, origin_s=None) if buf is not None else None

        def prov_akr_scalar_any(buf_names: tuple[str, ...]) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            best_name = None
            best_ts = float("-inf")
            for bn in buf_names:
                buf = getattr(dev, bn, None)
                if not buf:
                    continue
                try:
                    ts = float(buf[-1][0])
                except Exception:
                    continue
                if ts > best_ts:
                    best_ts = ts
                    best_name = bn
            if best_name is None:
                return None
            buf = getattr(dev, best_name, None)
            return points_from_deque(buf, 0, 6.0, origin_s=None) if buf is not None else None

        def prov_akr_vec3(buf_name: str, i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            buf = getattr(dev, buf_name, None)
            return points_from_deque(buf, int(i), 6.0, origin_s=None) if buf is not None else None

        dev = dev_or_none()

        # Interpret preset selection via metadata.
        if not isinstance(preset_data, dict):
            preset_data = {}
        grp = (preset_data.get("group") or "").upper()
        mode = (preset_data.get("mode") or "").lower()
        ax = (preset_data.get("axis") or "").upper()

        if grp == "EMG":
            color = axis_colors.get("X", "#4ea1ff")
            if mode == "raw":
                variant = (preset_data.get("axis") or "").strip().lower()
                self.multi_plot.add_trace(
                    key=f"{group}:RAW",
                    label=label,
                    group=group,
                    color=color,
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov_emg_raw,
                    pen_width=1.2,
                    scale=group_scale,
                )
                if "packet rms" in variant:
                    # Packet RMS may be empty until streaming starts; still allow adding the curve.
                    self.multi_plot.add_trace(
                        key=f"{group}:RMS",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_pkt_rms,
                        pen_width=2.0,
                        pen_style=QtCore.Qt.PenStyle.DashLine,
                    )
            elif mode == "pkt_rms":
                # Allow adding even if buffer is empty; it will draw once data arrives.
                self.multi_plot.add_trace(key=f"{group}:RMS", label=label, group=group, color="#ffa502", y_min=y_min, y_max=y_max, data_provider=prov_emg_pkt_rms, pen_width=2.0, scale=group_scale)
            elif mode == "snr":
                # SNR is packet-based; allow adding even if buffer is empty.
                self.multi_plot.add_trace(key=f"{group}:SNR", label=label, group=group, color="#9b59b6", y_min=y_min, y_max=y_max, data_provider=prov_emg_snr, pen_width=2.0, scale=group_scale)
            else:
                self.log_view.append_line(f"Signals: unknown EMG mode: {mode}")

        elif grp == "PROCESSED":
            # Processed Data -> EMG RMS Envelope
            if mode == "emg_env":
                variant = (preset_data.get("axis") or "").strip().lower()
                if variant.startswith("raw"):
                    self.multi_plot.add_trace(
                        key=f"{group}:RAW",
                        label=label,
                        group=group,
                        color=axis_colors.get("X", "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_raw,
                        pen_width=1.2,
                        scale=group_scale,
                    )
                    self.multi_plot.add_trace(
                        key=f"{group}:ENV",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_env,
                        pen_width=2.0,
                        pen_style=QtCore.Qt.PenStyle.DashLine,
                        scale=group_scale,
                        show_value_label=True,
                    )
                else:
                    self.multi_plot.add_trace(
                        key=f"{group}:ENV",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_env,
                        pen_width=2.0,
                        scale=group_scale,
                        show_value_label=True,
                    )
            elif mode == "emg_freq":
                variant = (preset_data.get("axis") or "").strip().lower()
                prov = prov_emg_mdf
                key = "MDF"
                if "mean frequency" in variant and "power" not in variant:
                    prov = prov_emg_mnf
                    key = "MNF"
                self.multi_plot.add_trace(
                    key=f"{group}:{key}",
                    label=label,
                    group=group,
                    color="#54a0ff",
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov,
                    pen_width=2.0,
                    scale=group_scale,
                    show_value_label=True,
                )
            elif mode == "emg_psd":
                # Map frequency axis (0..500Hz) into our 0..3s x-axis window.
                self.multi_plot.set_group_x_markers(group, [(float(hz) / 500.0) * 3.0 for hz in range(50, 501, 50)])
                self.multi_plot.add_trace(
                    key=f"{group}:PSD",
                    label=label,
                    group=group,
                    color="#c8d6e5",
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov_emg_psd_db,
                    pen_width=2.0,
                    scale=1.0,
                )
            elif mode == "emg_psd_lin":
                # Map frequency axis (0..500Hz) into our 0..3s x-axis window.
                self.multi_plot.set_group_x_markers(group, [(float(hz) / 500.0) * 3.0 for hz in range(50, 501, 50)])
                self.multi_plot.add_trace(
                    key=f"{group}:PSD_REL",
                    label=label,
                    group=group,
                    color="#2ed573",
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov_emg_psd_lin,
                    pen_width=2.0,
                    scale=1.0,
                    show_value_label=True,
                )
            elif mode == "emg_fatigue":
                variant = (preset_data.get("axis") or "").strip().lower()
                if "overlay" in variant:
                    self.multi_plot.add_trace(
                        key=f"{group}:FATIGUE",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_score,
                        pen_width=2.0,
                        scale=1.0,
                        show_value_label=True,
                    )
                    self.multi_plot.add_trace(
                        key=f"{group}:CONF",
                        label=label,
                        group=group,
                        color="#54a0ff",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_conf,
                        pen_width=2.0,
                        pen_style=QtCore.Qt.PenStyle.DashLine,
                        scale=1.0,
                        show_value_label=False,
                    )
                elif "conf" in variant:
                    self.multi_plot.add_trace(
                        key=f"{group}:CONF",
                        label=label,
                        group=group,
                        color="#54a0ff",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_conf,
                        pen_width=2.0,
                        scale=1.0,
                        show_value_label=True,
                    )
                else:
                    self.multi_plot.add_trace(
                        key=f"{group}:FATIGUE",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_score,
                        pen_width=2.0,
                        scale=1.0,
                        show_value_label=True,
                    )
            else:
                self.log_view.append_line(f"Signals: unknown PROCESSED mode: {mode}")

        elif grp == "ROBOT_WALK":
            axis = (preset_data.get("axis") or "").strip().lower()
            if mode == "acc":
                buf_name = "akr_walk_acc_buffer"
                if ax == "XYZ":
                    for a in ("X", "Y", "Z"):
                        i = axis_map[a]
                        self.multi_plot.add_trace(
                            key=f"{group}:{a}",
                            label=label,
                            group=group,
                            color=axis_colors.get(a, "#4ea1ff"),
                            y_min=y_min,
                            y_max=y_max,
                            data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                            scale=group_scale,
                        )
                else:
                    i = axis_map.get(ax, 0)
                    self.multi_plot.add_trace(
                        key=f"{group}:{ax}",
                        label=label,
                        group=group,
                        color=axis_colors.get(ax, "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                        scale=group_scale,
                    )
                # IMPORTANT: keep right-panel tiles in sync even on early-return paths.
                self._sync_signal_group_controls()
                return
            if mode == "gyr":
                buf_name = "akr_walk_gyr_buffer"
                if ax == "XYZ":
                    for a in ("X", "Y", "Z"):
                        i = axis_map[a]
                        self.multi_plot.add_trace(
                            key=f"{group}:{a}",
                            label=label,
                            group=group,
                            color=axis_colors.get(a, "#4ea1ff"),
                            y_min=y_min,
                            y_max=y_max,
                            data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                            scale=group_scale,
                        )
                else:
                    i = axis_map.get(ax, 0)
                    self.multi_plot.add_trace(
                        key=f"{group}:{ax}",
                        label=label,
                        group=group,
                        color=axis_colors.get(ax, "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                        scale=group_scale,
                    )
                # IMPORTANT: keep right-panel tiles in sync even on early-return paths.
                self._sync_signal_group_controls()
                return
            if mode == "mag":
                buf_name = "akr_walk_mag_buffer"
                if ax == "XYZ":
                    for a in ("X", "Y", "Z"):
                        i = axis_map[a]
                        self.multi_plot.add_trace(
                            key=f"{group}:{a}",
                            label=label,
                            group=group,
                            color=axis_colors.get(a, "#4ea1ff"),
                            y_min=y_min,
                            y_max=y_max,
                            data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                            scale=group_scale,
                        )
                else:
                    i = axis_map.get(ax, 0)
                    self.multi_plot.add_trace(
                        key=f"{group}:{ax}",
                        label=label,
                        group=group,
                        color=axis_colors.get(ax, "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                        scale=group_scale,
                    )
                # IMPORTANT: keep right-panel tiles in sync even on early-return paths.
                self._sync_signal_group_controls()
                return

            scalar_map: dict[str, str] = {
                "dt_ms": "akr_walk_dt_ms_buffer",
                "exec_ms": "akr_walk_exec_ms_buffer",
                "fid": "akr_walk_fid_buffer",
                "out": "akr_walk_out_buffer",
                "state": "akr_walk_state_buffer",
                "pos_rad": "akr_walk_pos_rad_buffer",
                "vel_rad_s": "akr_walk_vel_rad_s_buffer",
                "tq_nm": "akr_walk_tq_nm_buffer",
                "temp_c": "akr_walk_temp_c_buffer",
                "vbus_v": "akr_walk_vbus_v_buffer",
                "pattern": "akr_walk_pattern_buffer",
                "err_code": "akr_walk_err_code_buffer",
                "fb_age_ms": "akr_walk_fb_age_ms_buffer",
            }
            buf = scalar_map.get(axis)
            if not buf:
                self.log_view.append_line("Signals: unknown Robot: Walk axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bn=buf: prov_akr_scalar(bn)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ROBOT_CPM":
            axis = (preset_data.get("axis") or "").strip().lower()
            scalar_map: dict[str, str] = {
                "dt_ms": "akr_cpm_dt_ms_buffer",
                "fid": "akr_cpm_fid_buffer",
                "cpm_state": "akr_cpm_state_buffer",
                "dir": "akr_cpm_dir_buffer",
                "blocked_event": "akr_cpm_blocked_event_buffer",
                "blocked_consecutive": "akr_cpm_blocked_consecutive_buffer",
                "cmd_spd_rad_s": "akr_cpm_cmd_spd_rad_s_buffer",
                "pos_rad": "akr_cpm_pos_rad_buffer",
                "vel_rad_s": "akr_cpm_vel_rad_s_buffer",
                "tq_nm": "akr_cpm_tq_nm_buffer",
                "temp_c": "akr_cpm_temp_c_buffer",
                "vbus_v": "akr_cpm_vbus_v_buffer",
                "pattern": "akr_cpm_pattern_buffer",
                "err_code": "akr_cpm_err_code_buffer",
                "fb_age_ms": "akr_cpm_fb_age_ms_buffer",
                "df_limit_rad": "akr_cpm_df_limit_rad_buffer",
                "pf_limit_rad": "akr_cpm_pf_limit_rad_buffer",
                "elapsed_s": "akr_cpm_elapsed_s_buffer",
                "repetition_count": "akr_cpm_repetition_count_buffer",
            }
            buf = scalar_map.get(axis)
            if not buf:
                self.log_view.append_line("Signals: unknown Robot: CPM axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bn=buf: prov_akr_scalar(bn)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ROBOT_MOTOR":
            axis = (preset_data.get("axis") or "").strip().lower()
            scalar_map: dict[str, tuple[str, ...]] = {
                "dt_ms": ("akr_walk_dt_ms_buffer", "akr_cpm_dt_ms_buffer", "akr_test_dt_ms_buffer"),
                "fid": ("akr_walk_fid_buffer", "akr_cpm_fid_buffer", "akr_test_fid_buffer"),
                "pos_rad": ("akr_walk_pos_rad_buffer", "akr_cpm_pos_rad_buffer", "akr_test_pos_rad_buffer"),
                "vel_rad_s": ("akr_walk_vel_rad_s_buffer", "akr_cpm_vel_rad_s_buffer", "akr_test_vel_rad_s_buffer"),
                "tq_nm": ("akr_walk_tq_nm_buffer", "akr_cpm_tq_nm_buffer", "akr_test_tq_nm_buffer"),
                "temp_c": ("akr_walk_temp_c_buffer", "akr_cpm_temp_c_buffer", "akr_test_temp_c_buffer"),
                "vbus_v": ("akr_walk_vbus_v_buffer", "akr_cpm_vbus_v_buffer", "akr_test_vbus_v_buffer"),
                "pattern": ("akr_walk_pattern_buffer", "akr_cpm_pattern_buffer", "akr_test_pattern_buffer"),
                "err_code": ("akr_walk_err_code_buffer", "akr_cpm_err_code_buffer", "akr_test_err_code_buffer"),
                "fb_age_ms": ("akr_walk_fb_age_ms_buffer", "akr_cpm_fb_age_ms_buffer", "akr_test_fb_age_ms_buffer"),
            }
            buf_names = scalar_map.get(axis)
            if not buf_names:
                self.log_view.append_line("Signals: unknown Robot: Motor axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bns=buf_names: prov_akr_scalar_any(bns)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp in {"ROBOT_TEST", "ROBOT_MEASURE"}:
            axis = (preset_data.get("axis") or "").strip().lower()
            scalar_map: dict[str, str] = {
                "dt_ms": "akr_test_dt_ms_buffer",
                "fid": "akr_test_fid_buffer",
                "measure_state": "akr_test_state_buffer",
                "test_state": "akr_test_state_buffer",
                "dir": "akr_test_dir_buffer",
                "blocked": "akr_test_blocked_buffer",
                "result_flags": "akr_test_result_flags_buffer",
                "pos_rad": "akr_test_pos_rad_buffer",
                "vel_rad_s": "akr_test_vel_rad_s_buffer",
                "tq_nm": "akr_test_tq_nm_buffer",
                "temp_c": "akr_test_temp_c_buffer",
                "vbus_v": "akr_test_vbus_v_buffer",
                "pattern": "akr_test_pattern_buffer",
                "err_code": "akr_test_err_code_buffer",
                "fb_age_ms": "akr_test_fb_age_ms_buffer",
                "prom_df_end_rad": "akr_test_prom_df_end_rad_buffer",
                "prom_pf_end_rad": "akr_test_prom_pf_end_rad_buffer",
                "arom_df_max_rad": "akr_test_arom_df_max_rad_buffer",
                "arom_pf_min_rad": "akr_test_arom_pf_min_rad_buffer",
                "prom_df_valid": "akr_test_flag_prom_df_valid_buffer",
                "prom_pf_valid": "akr_test_flag_prom_pf_valid_buffer",
                "arom_valid": "akr_test_flag_arom_valid_buffer",
                "seq_active": "akr_test_flag_seq_active_buffer",
                "arom_running": "akr_test_flag_arom_running_buffer",
            }
            buf = scalar_map.get(axis)
            if not buf:
                self.log_view.append_line("Signals: unknown Robot: Measure axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bn=buf: prov_akr_scalar(bn)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ACC":
            prov = {"raw": prov_raw_acc, "cal": prov_acc, "linear": prov_lin_acc}.get(mode)
            if prov is None:
                self.log_view.append_line(f"Signals: unknown ACC mode: {mode}")
            elif ax == "XYZ":
                for a in ("X", "Y", "Z"):
                    i = axis_map[a]
                    self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)
            else:
                i = axis_map.get(ax, 0)
                self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)

        elif grp == "GYR":
            prov = {"raw": prov_raw_gyr, "cal": prov_gyr}.get(mode)
            if prov is None:
                self.log_view.append_line(f"Signals: unknown GYR mode: {mode}")
            elif ax == "XYZ":
                for a in ("X", "Y", "Z"):
                    i = axis_map[a]
                    self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)
            else:
                i = axis_map.get(ax, 0)
                self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)

        elif grp == "MAG":
            prov = {"uncal": prov_uncal_mag, "cal": prov_mag}.get(mode)
            if prov is None:
                self.log_view.append_line(f"Signals: unknown MAG mode: {mode}")
            elif ax == "XYZ":
                for a in ("X", "Y", "Z"):
                    i = axis_map[a]
                    self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)
            else:
                i = axis_map.get(ax, 0)
                self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)

        elif grp == "QUAT":
            buf_name = "quat_game_buffer" if mode == "game" else ("quat_geomag_buffer" if mode == "geomag" else "")
            if not buf_name:
                self.log_view.append_line(f"Signals: unknown QUAT mode: {mode}")
            else:
                # Quaternion axis order matches device decoder (<4f) as [w, x, y, z].
                q_map = {"W": 0, "X": 1, "Y": 2, "Z": 3}
                if ax == "WXYZ":
                    for a in ("W", "X", "Y", "Z"):
                        i = q_map[a]
                        self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#d7e1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, bn=buf_name: prov_quat(bn, ii)), scale=group_scale)
                else:
                    i = q_map.get(ax, 0)
                    self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#d7e1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, bn=buf_name: prov_quat(bn, ii)), scale=group_scale)

        else:
            self.log_view.append_line(f"Signals: unhandled signal group '{grp}' or mode '{mode}'")
        self._sync_signal_group_controls()

    def _remove_all_traces(self) -> None:
        self.multi_plot.clear()
        self._sync_signal_group_controls()

    def _sync_signal_group_controls(self) -> None:
        """Ensure right-panel control widgets match the plotted groups."""
        groups = self.multi_plot.list_groups()

        # Remove widgets for groups that no longer exist.
        for g in list(self._sig_group_controls.keys()):
            if g in groups:
                continue
            w = self._sig_group_controls.pop(g)
            w.setParent(None)

        # Create/update widgets in plot group order.
        for g in groups:
            if g not in self._sig_group_controls:
                w = SignalGroupControl(group=g, title=self.multi_plot.group_label(g), parent=self.sig_group_panel_inner)
                w.remove_requested.connect(self._remove_signal_group)
                w.config_changed.connect(self._on_signal_group_config_changed)
                w.color_changed.connect(self._on_signal_group_color_changed)
                w.move_up_requested.connect(self._move_signal_group_up)
                w.move_down_requested.connect(self._move_signal_group_down)
                # Insert before the stretch spacer at the end.
                self.sig_group_panel_layout.insertWidget(self.sig_group_panel_layout.count() - 1, w)
                self._sig_group_controls[g] = w

        # Physically reorder tiles in the layout to match `groups`.
        # (Move up/down must visibly move the tile in the right panel.)
        for i in reversed(range(self.sig_group_panel_layout.count())):
            item = self.sig_group_panel_layout.itemAt(i)
            w = item.widget() if item else None
            if isinstance(w, SignalGroupControl):
                self.sig_group_panel_layout.takeAt(i)

        for g in groups:
            self.sig_group_panel_layout.insertWidget(self.sig_group_panel_layout.count() - 1, self._sig_group_controls[g])

        for idx, g in enumerate(groups):
            w = self._sig_group_controls[g]
            w.set_title(self.multi_plot.group_label(g))
            w.set_move_enabled(up=(idx > 0), down=(idx < len(groups) - 1))
            cfg = self.multi_plot.get_group_config(g)
            if cfg:
                w.set_values(y_min=cfg.y_min_raw, y_max=cfg.y_max_raw, scale=cfg.scale)

            traces = []
            for tr in self.multi_plot.traces_in_group(g):
                short = tr.key.split(":")[-1] if ":" in tr.key else tr.key
                traces.append((tr.key, short, tr.color))
            w.set_traces(traces)
        # Immediately refresh streaming control enable state after plot composition changes.
        self._update_signal_rx_status()

    def _remove_signal_group(self, group: str) -> None:
        self.multi_plot.remove_group(group)
        self._sig_group_palette.pop(group, None)
        self._sync_signal_group_controls()

    def _move_signal_group_up(self, group: str) -> None:
        self.multi_plot.move_group(group, -1)
        self._sync_signal_group_controls()

    def _move_signal_group_down(self, group: str) -> None:
        self.multi_plot.move_group(group, +1)
        self._sync_signal_group_controls()

    def _on_signal_group_config_changed(self, group: str, y_min: float, y_max: float, scale: float) -> None:
        self.multi_plot.set_group_config(group, y_min=y_min, y_max=y_max, scale=scale)

    def _on_signal_group_color_changed(self, trace_key: str, color_hex: str) -> None:
        self.multi_plot.set_trace_color(trace_key, color_hex)

