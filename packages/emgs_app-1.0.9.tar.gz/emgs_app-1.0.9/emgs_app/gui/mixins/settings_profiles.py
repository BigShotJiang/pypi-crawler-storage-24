from __future__ import annotations

import json
import time
from pathlib import Path

from PyQt6 import QtWidgets

from ... import config


class SettingsProfilesMixin:
    _ROBOT_FIELD_RENAMES: dict[str, str] = {
        "test_fid": "measure_fid",
        "test_dt_ms": "measure_dt_ms",
        "test_state": "measure_state",
        "test_dir": "measure_dir",
        "test_blocked": "measure_blocked",
        "test_result_flags": "measure_result_flags",
        "test_pos_rad": "measure_pos_rad",
        "test_vel_rad_s": "measure_vel_rad_s",
        "test_tq_nm": "measure_tq_nm",
        "test_temp_c": "measure_temp_c",
        "test_vbus_v": "measure_vbus_v",
        "test_pattern": "measure_pattern",
        "test_err_code": "measure_err_code",
        "test_fb_age_ms": "measure_fb_age_ms",
        "test_prom_df_end_rad": "measure_prom_df_end_rad",
        "test_prom_pf_end_rad": "measure_prom_pf_end_rad",
        "test_arom_df_max_rad": "measure_arom_df_max_rad",
        "test_arom_pf_min_rad": "measure_arom_pf_min_rad",
        "test_flag_prom_df_valid": "measure_flag_prom_df_valid",
        "test_flag_prom_pf_valid": "measure_flag_prom_pf_valid",
        "test_flag_arom_valid": "measure_flag_arom_valid",
        "test_flag_seq_active": "measure_flag_seq_active",
        "test_flag_arom_running": "measure_flag_arom_running",
    }

    # ---------- Settings: Profiles ----------
    @staticmethod
    def _default_recording_dir() -> str:
        base = Path.home() / str(getattr(config, "DEFAULT_REC_OUT_DIRNAME", "rr_data"))
        try:
            base.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return str(base)

    def _profile_to_dict(self) -> dict:
        """Collect Settings-page configuration into a JSON-serializable dict."""
        prof: dict = {"version": 1}
        prof["processed"] = {
            "enable_emg_env": bool(self.chk_proc_emg_env.isChecked()),
            "emg_env_win_n": int(self.spin_proc_emg_env_win.value()),
            "enable_emg_freq": bool(self.chk_proc_emg_freq.isChecked()),
            "emg_spec_win_n": int(self.spin_proc_emg_spec_win.value()),
            "enable_fatigue": bool(self.chk_proc_emg_fatigue.isChecked()),
            "fatigue_baseline_s": float(self.spin_proc_emg_fatigue_baseline_s.value()),
            "fatigue_w_mdf_pct": float(self.spin_proc_emg_fatigue_w_mdf.value()),
            "fatigue_w_rms_pct": float(self.spin_proc_emg_fatigue_w_rms.value()),
            "fatigue_conf_n": int(self.spin_proc_emg_fatigue_conf_n.value()),
        }
        prof["recording"] = {
            "output_dir": str(getattr(self, "_rec_out_dir", "")),
            "emg_fields": sorted(list(getattr(self, "_rec_emg_fields_selected", set()))),
            "imu_fields": sorted(list(getattr(self, "_rec_imu_fields_selected", set()))),
            "robot_fields": sorted(list(getattr(self, "_rec_robot_fields_selected", set()))),
        }
        return prof

    def _apply_profile_dict(self, prof: dict) -> None:
        """Apply a profile dict to Settings-page widgets."""
        p = (prof or {}).get("processed", {}) if isinstance(prof, dict) else {}
        r = (prof or {}).get("recording", {}) if isinstance(prof, dict) else {}

        # Block signals to avoid intermediate inconsistent manager state.
        widgets = [
            self.chk_proc_emg_env,
            self.spin_proc_emg_env_win,
            self.chk_proc_emg_freq,
            self.spin_proc_emg_spec_win,
            self.chk_proc_emg_fatigue,
            self.spin_proc_emg_fatigue_baseline_s,
            self.spin_proc_emg_fatigue_w_mdf,
            self.spin_proc_emg_fatigue_w_rms,
            self.spin_proc_emg_fatigue_conf_n,
        ]
        for w in [x for x in widgets if x is not None]:
            w.blockSignals(True)
        try:
            self.chk_proc_emg_env.setChecked(bool(p.get("enable_emg_env", self.chk_proc_emg_env.isChecked())))
            self.spin_proc_emg_env_win.setValue(int(p.get("emg_env_win_n", int(self.spin_proc_emg_env_win.value()))))
            self.chk_proc_emg_freq.setChecked(bool(p.get("enable_emg_freq", self.chk_proc_emg_freq.isChecked())))
            self.spin_proc_emg_spec_win.setValue(int(p.get("emg_spec_win_n", int(self.spin_proc_emg_spec_win.value()))))

            self.chk_proc_emg_fatigue.setChecked(bool(p.get("enable_fatigue", self.chk_proc_emg_fatigue.isChecked())))
            self.spin_proc_emg_fatigue_baseline_s.setValue(float(p.get("fatigue_baseline_s", float(self.spin_proc_emg_fatigue_baseline_s.value()))))
            self.spin_proc_emg_fatigue_w_mdf.setValue(float(p.get("fatigue_w_mdf_pct", float(self.spin_proc_emg_fatigue_w_mdf.value()))))
            self.spin_proc_emg_fatigue_w_rms.setValue(float(p.get("fatigue_w_rms_pct", float(self.spin_proc_emg_fatigue_w_rms.value()))))
            self.spin_proc_emg_fatigue_conf_n.setValue(int(p.get("fatigue_conf_n", int(self.spin_proc_emg_fatigue_conf_n.value()))))
        finally:
            for w in [x for x in widgets if x is not None]:
                w.blockSignals(False)

        # Apply manager “next session” state from widgets.
        self._on_proc_settings_changed()

        # Recording directory + columns
        out_dir = str(r.get("output_dir", getattr(self, "_rec_out_dir", "")))
        if out_dir:
            self._rec_out_dir = out_dir
            try:
                self.edit_rec_out_dir.setText(str(out_dir))
            except Exception:
                pass

        emg_fields = set(str(x) for x in (r.get("emg_fields") or []))
        imu_fields = set(str(x) for x in (r.get("imu_fields") or []))
        robot_fields_raw = set(str(x) for x in (r.get("robot_fields") or []))
        # Backward compatibility: accept legacy `test_*` robot fields and map to `measure_*`.
        robot_fields = set(self._ROBOT_FIELD_RENAMES.get(x, x) for x in robot_fields_raw)
        if emg_fields:
            self._rec_emg_fields_selected = set(emg_fields)
        if imu_fields:
            self._rec_imu_fields_selected = set(imu_fields)
        if robot_fields:
            self._rec_robot_fields_selected = set(robot_fields)

        # Sync checkboxes from internal selections.
        for k, cb in getattr(self, "_rec_emg_chk", {}).items():
            cb.blockSignals(True)
            try:
                cb.setChecked(k in self._rec_emg_fields_selected)
            finally:
                cb.blockSignals(False)
        for k, cb in getattr(self, "_rec_imu_chk", {}).items():
            cb.blockSignals(True)
            try:
                cb.setChecked(k in self._rec_imu_fields_selected)
            finally:
                cb.blockSignals(False)
        for k, cb in getattr(self, "_rec_robot_chk", {}).items():
            cb.blockSignals(True)
            try:
                cb.setChecked(k in self._rec_robot_fields_selected)
            finally:
                cb.blockSignals(False)
        try:
            ref = getattr(self, "_refresh_robot_common_checks", None)
            if callable(ref):
                ref()
        except Exception:
            pass

    def _profile_load_clicked(self) -> None:
        # Always allow user to pick a (new) profile file.
        current = self.edit_profile_path.text().strip()
        start_dir = ""
        try:
            if current:
                p = Path(current)
                start_dir = str(p.parent if p.suffix else p)
        except Exception:
            start_dir = ""
        if not start_dir:
            start_dir = str(getattr(self, "_rec_out_dir", "") or self._default_recording_dir())
        start_dir = self._safe_existing_dir(start_dir)

        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Load Settings Profile",
            start_dir,
            "JSON (*.json);;All files (*)",
        )
        if not path:
            return
        self.edit_profile_path.setText(str(path))
        try:
            raw = Path(path).read_text(encoding="utf-8")
            prof = json.loads(raw)
        except Exception as e:
            self.log_view.append_line(f"Profile: failed to load: {e}")
            return
        try:
            self._apply_profile_dict(prof if isinstance(prof, dict) else {})
        except Exception as e:
            self.log_view.append_line(f"Profile: failed to apply: {e}")
            return
        self._remember_profile_path(path)
        self.log_view.append_line(f"Profile: loaded {path}")

    def _profile_save_clicked(self) -> None:
        # Always allow "Save As" so user can create a new profile file.
        current = self.edit_profile_path.text().strip()
        default_name = f"profile_{time.strftime('%Y%m%d_%H%M%S')}.json"
        start_path = ""
        try:
            if current:
                p = Path(current)
                # If current is a directory-like path, propose a new file inside it.
                if p.exists() and p.is_dir():
                    start_path = str(p / default_name)
                else:
                    start_path = str(p)
        except Exception:
            start_path = ""
        if not start_path:
            base = self._safe_existing_dir(str(getattr(self, "_rec_out_dir", "") or self._default_recording_dir()))
            start_path = str(Path(base) / default_name)
        else:
            # If the suggested folder doesn't exist, fall back to home.
            base = self._safe_existing_dir(str(Path(start_path).parent))
            start_path = str(Path(base) / str(Path(start_path).name))

        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save Settings Profile",
            start_path,
            "JSON (*.json);;All files (*)",
        )
        if not path:
            return
        if not path.lower().endswith(".json"):
            path = path + ".json"
        self.edit_profile_path.setText(str(path))
        try:
            prof = self._profile_to_dict()
            Path(path).write_text(json.dumps(prof, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        except Exception as e:
            self.log_view.append_line(f"Profile: failed to save: {e}")
            return
        self._remember_profile_path(path)
        self.log_view.append_line(f"Profile: saved {path}")

    def _profile_reset_clicked(self) -> None:
        self._reset_settings_to_defaults()
        # Also clear the profile path so "Save…" doesn't overwrite an old JSON.
        try:
            if getattr(self, "edit_profile_path", None):
                self.edit_profile_path.setText("")
        except Exception:
            pass
        try:
            self._ui_settings.setValue("profiles/last_path", "")
        except Exception:
            pass
        self.log_view.append_line("Profile: reset to defaults")

    def _remember_profile_path(self, path: str) -> None:
        try:
            self._ui_settings.setValue("profiles/last_path", str(path))
        except Exception:
            pass

    def _restore_last_profile(self) -> None:
        """Restore last loaded profile path (and auto-load if exists)."""
        try:
            p = str(self._ui_settings.value("profiles/last_path", "") or "").strip()
        except Exception:
            p = ""
        if not p:
            return
        try:
            self.edit_profile_path.setText(p)
        except Exception:
            pass
        # Best-effort auto-load at startup for convenience.
        try:
            if Path(p).exists():
                raw = Path(p).read_text(encoding="utf-8")
                prof = json.loads(raw)
                if isinstance(prof, dict):
                    self._apply_profile_dict(prof)
        except Exception:
            pass

    def _reset_settings_to_defaults(self) -> None:
        """Reset Settings-page widgets to initial defaults."""
        # Processed data defaults mirror manager 'next session' defaults / config.
        try:
            self.chk_proc_emg_env.setChecked(False)
            self.spin_proc_emg_env_win.setValue(int(getattr(config, "EMG_RMS_WINDOW_N", 100)))
            self.chk_proc_emg_freq.setChecked(False)
            self.spin_proc_emg_spec_win.setValue(int(getattr(config, "EMG_SPEC_WINDOW_N", 1000)))
            self.chk_proc_emg_fatigue.setChecked(bool(getattr(config, "EMG_FATIGUE_ENABLE_DEFAULT", False)))
            self.spin_proc_emg_fatigue_baseline_s.setValue(float(getattr(config, "EMG_FATIGUE_BASELINE_S", 10.0)))
            self.spin_proc_emg_fatigue_w_mdf.setValue(float(getattr(config, "EMG_FATIGUE_WEIGHT_MDF_PCT", 70.0)))
            self.spin_proc_emg_fatigue_w_rms.setValue(float(getattr(config, "EMG_FATIGUE_WEIGHT_RMS_PCT", 30.0)))
            self.spin_proc_emg_fatigue_conf_n.setValue(int(getattr(config, "EMG_FATIGUE_CONF_RECENT_N", 60)))
            self._on_proc_settings_changed()
        except Exception:
            pass

        # Recording defaults
        try:
            self._rec_out_dir = self._default_recording_dir()
            if getattr(self, "edit_rec_out_dir", None):
                self.edit_rec_out_dir.setText(self._rec_out_dir)
        except Exception:
            pass
        try:
            # Select none by default.
            for cb in getattr(self, "_rec_emg_chk", {}).values():
                cb.blockSignals(True)
                cb.setChecked(False)
                cb.blockSignals(False)
            for cb in getattr(self, "_rec_imu_chk", {}).values():
                cb.blockSignals(True)
                cb.setChecked(False)
                cb.blockSignals(False)
            for cb in getattr(self, "_rec_robot_chk", {}).values():
                cb.blockSignals(True)
                cb.setChecked(False)
                cb.blockSignals(False)
            self._rec_emg_fields_selected = set()
            self._rec_imu_fields_selected = set()
            self._rec_robot_fields_selected = set()
            ref = getattr(self, "_refresh_robot_common_checks", None)
            if callable(ref):
                ref()
        except Exception:
            pass

    def _on_proc_settings_changed(self, *_args) -> None:
        """Processed-data settings (applies on next stream start)."""
        try:
            # Fatigue score requires MDF; keep settings consistent (intuitive rule):
            # - If user disables frequency features, fatigue is auto-disabled.
            # - If user enables fatigue, frequency features are auto-enabled.
            if getattr(self, "chk_proc_emg_fatigue", None) and getattr(self, "chk_proc_emg_freq", None):
                sender = self.sender()
                if sender is self.chk_proc_emg_freq and (not bool(self.chk_proc_emg_freq.isChecked())):
                    self.chk_proc_emg_fatigue.blockSignals(True)
                    try:
                        self.chk_proc_emg_fatigue.setChecked(False)
                    finally:
                        self.chk_proc_emg_fatigue.blockSignals(False)
                elif sender is self.chk_proc_emg_fatigue and bool(self.chk_proc_emg_fatigue.isChecked()) and (not bool(self.chk_proc_emg_freq.isChecked())):
                    self.chk_proc_emg_freq.blockSignals(True)
                    try:
                        self.chk_proc_emg_freq.setChecked(True)
                    finally:
                        self.chk_proc_emg_freq.blockSignals(False)
                # Safety net: fatigue must never be enabled while freq is disabled.
                if bool(self.chk_proc_emg_fatigue.isChecked()) and (not bool(self.chk_proc_emg_freq.isChecked())):
                    self.chk_proc_emg_fatigue.blockSignals(True)
                    try:
                        self.chk_proc_emg_fatigue.setChecked(False)
                    finally:
                        self.chk_proc_emg_fatigue.blockSignals(False)

            self.controller.manager.proc_enable_emg_rms_envelope_next = bool(self.chk_proc_emg_env.isChecked())
            self.controller.manager.proc_emg_rms_window_n_next = int(self.spin_proc_emg_env_win.value())
            self.controller.manager.proc_enable_emg_freq_features_next = bool(self.chk_proc_emg_freq.isChecked())
            self.controller.manager.proc_emg_spec_window_n_next = int(self.spin_proc_emg_spec_win.value())

            if getattr(self, "chk_proc_emg_fatigue", None):
                self.controller.manager.proc_enable_emg_fatigue_next = bool(self.chk_proc_emg_fatigue.isChecked())
                self.controller.manager.proc_emg_fatigue_baseline_s_next = float(self.spin_proc_emg_fatigue_baseline_s.value())
                self.controller.manager.proc_emg_fatigue_weight_mdf_pct_next = float(self.spin_proc_emg_fatigue_w_mdf.value())
                self.controller.manager.proc_emg_fatigue_weight_rms_pct_next = float(self.spin_proc_emg_fatigue_w_rms.value())
                self.controller.manager.proc_emg_fatigue_conf_recent_n_next = int(self.spin_proc_emg_fatigue_conf_n.value())
        except Exception:
            pass

