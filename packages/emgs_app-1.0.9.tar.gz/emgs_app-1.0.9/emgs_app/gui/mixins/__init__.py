"""Mixins used by `MainWindow` to keep the file small.

Each mixin holds a cohesive set of `MainWindow` methods (settings profiles,
signals plotting, scenario controls, etc.). `MainWindow` composes them via
multiple inheritance.
"""

