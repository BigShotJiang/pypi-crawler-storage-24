from __future__ import annotations

import asyncio
import time

from PyQt6 import QtCore, QtGui, QtWidgets

from ... import config


class MainWindowRuntimeMixin:
    # ---------- Dashboard utilities ----------
    def _clear_layout(self, layout: QtWidgets.QLayout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)

    # Note: Signals plot uses per-device origins (see `_device_time_origin_s`).

    def _refresh_scenario_view(self) -> None:
        """Refresh Scenario page plot + tiles (best-effort)."""
        if not getattr(self, "scenario_page", None):
            return
        try:
            if self.tabs.currentWidget() is not self.scenario_page:
                return
        except Exception:
            pass
        # Scenario plot placeholder (no trajectory source currently).
        try:
            self.scn_plot.clear()
        except Exception:
            pass
        return

    def _refresh_plots(self) -> None:
        # Keep the plot responsive; most signals are updated in bursts (EMG packets),
        # so a short rolling window + capped points keeps UI smooth.
        # Freeze pauses redraw only (stream continues).
        if not self._plot_frozen:
            # Measure event-loop lag (captures heavy painting / UI stalls better than measuring setData() time).
            now = time.monotonic()
            if self._plot_last_tick_monotonic_s > 0.0:
                dt_ms = (now - self._plot_last_tick_monotonic_s) * 1000.0
                lag_ms = dt_ms - float(config.PLOT_REFRESH_MS)
                self._plot_loop_lag_ms = float(max(0.0, lag_ms))
            self._plot_last_tick_monotonic_s = now

            n_tr = max(1, int(self.multi_plot.trace_count()))
            # Total draw budget (points across all traces per refresh). Used points are shown in UI.
            total_point_budget = 3000
            max_points = max(120, min(1500, int(total_point_budget // n_tr)))

            # Base timer is config.PLOT_REFRESH_MS. With many traces, redraw every 2-3 ticks.
            if n_tr <= 18:
                every = 1
            elif n_tr <= 45:
                every = 2
            else:
                every = 3

            # Feedback-based adaptive throttling: if a refresh takes too long, increase the interval.
            base_every = every
            self._plot_dyn_every = max(int(self._plot_dyn_every or 1), base_every)

            self._plot_refresh_tick = (self._plot_refresh_tick + 1) % int(self._plot_dyn_every)
            did_refresh = (self._plot_refresh_tick == 0)

            used_pts, _with_data = self.multi_plot.last_refresh_stats()
            # Keep the status current even on skipped ticks.
            effective_budget = int(max_points) * int(n_tr)
            aa = "fast" if self._plot_fast_rendering else "hq"
            self._plot_budget_status = (
                f"tr={n_tr} • used={used_pts}/{effective_budget} (target {total_point_budget}) • "
                f"max={max_points} • win=3s • every={self._plot_dyn_every}(base {base_every})×{config.PLOT_REFRESH_MS}ms • "
                f"last={self._plot_last_refresh_ms:0.1f}ms • lag={self._plot_loop_lag_ms:0.0f}ms • {aa}"
            )

            if did_refresh:
                t0 = time.perf_counter()
                self.multi_plot.refresh(max_points=max_points, window_s=3.0)
                self._plot_last_refresh_ms = (time.perf_counter() - t0) * 1000.0

                # Adjust dyn_every based on measured render+data cost.
                if self._plot_last_refresh_ms > 45.0:
                    self._plot_dyn_every = min(6, int(self._plot_dyn_every) + 1)
                elif self._plot_last_refresh_ms < 20.0 and int(self._plot_dyn_every) > base_every:
                    self._plot_dyn_every = max(base_every, int(self._plot_dyn_every) - 1)

                # If the event loop is lagging badly, increase dyn_every even if setData() itself is fast.
                if float(self._plot_loop_lag_ms) > 120.0:
                    self._plot_dyn_every = min(8, max(int(self._plot_dyn_every), base_every + 1))

                # Auto-toggle fast rendering when overloaded.
                want_fast = (float(self._plot_loop_lag_ms) > 80.0) or (int(self._plot_dyn_every) >= 3) or (n_tr >= 25)
                if bool(want_fast) != bool(self._plot_fast_rendering):
                    self._plot_fast_rendering = bool(want_fast)
                    try:
                        self.multi_plot.set_fast_rendering(self._plot_fast_rendering)
                    except Exception:
                        pass
                # Scenario page refresh (lighter; do it on the same cadence as plot refresh).
                self._refresh_scenario_view()
        self._update_signal_rx_status()

    def resizeEvent(self, event: QtGui.QResizeEvent) -> None:  # noqa: N802 (Qt naming)
        # NOTE: This mixin is last in the MainWindow MRO, so `super()` would resolve to `object`
        # here and fail. Call the Qt base explicitly.
        QtWidgets.QMainWindow.resizeEvent(self, event)

    def keyPressEvent(self, event: QtGui.QKeyEvent) -> None:  # noqa: N802 (Qt naming)
        # Quick exit shortcut (requested): Esc closes the app.
        if event.key() == QtCore.Qt.Key.Key_Escape:
            self.close()
            return
        # See note in resizeEvent(): call Qt base explicitly.
        QtWidgets.QMainWindow.keyPressEvent(self, event)

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:  # noqa: N802 (Qt naming)
        # Ensure we disconnect devices before exiting the Qt+asyncio event loop.
        if self._closing:
            event.accept()
            return

        self._closing = True
        event.ignore()

        # Best-effort: close any active recorder to flush files.
        try:
            if getattr(self, "_recording", False):
                self._signals_stop_record()
        except Exception:
            pass

        # Stop timers to avoid scheduling more BLE work during shutdown.
        for t in (getattr(self, "_plot_timer", None), getattr(self, "_poll_timer", None), getattr(self, "_full_update_timer", None)):
            try:
                if t:
                    t.stop()
            except Exception:
                pass

        try:
            self.setEnabled(False)
            self.status.showMessage("Shutting down: disconnecting devices…")
        except Exception:
            pass

        async def _shutdown_then_quit() -> None:
            try:
                await self.controller.manager.shutdown()
            except Exception:
                pass
            try:
                QtWidgets.QApplication.instance().quit()
            except Exception:
                pass

        asyncio.create_task(_shutdown_then_quit())

