from __future__ import annotations

import time

from PyQt6 import QtCore, QtWidgets

from ..widgets import AkrDeviceSettingsDialog, BulkModeSettingsDialog, DeviceSettingsDialog


class ConnectActionsMixin:
    # ---------- Signals / actions ----------
    def _wire_signals(self) -> None:
        self.action_scan.triggered.connect(self.controller.scan)
        self.action_select_all.triggered.connect(self._select_all_rows)
        self.action_select_none.triggered.connect(self._select_none_rows)
        self.action_connect.triggered.connect(self._connect_selected)
        self.action_disconnect.triggered.connect(self._disconnect_selected)
        self.action_update.triggered.connect(self._update_selected)
        self.action_settings.triggered.connect(self._open_settings_for_selected)
        self.action_time_sync.triggered.connect(self._time_sync_selected)
        self.action_bulk_modes.triggered.connect(self._open_bulk_mode_settings)
        # Stream actions are not exposed on the Connect tab anymore.

        self.controller.signal_log.connect(self.log_view.append_line)
        self.controller.signal_device_list_changed.connect(self._on_device_list_changed)
        self.controller.signal_device_updated.connect(self._on_device_updated)

        self.table.selectionModel().selectionChanged.connect(self._on_table_selection_changed)
        self._update_action_enabled()

        self.table.customContextMenuRequested.connect(self._open_table_context_menu)

    def _on_table_selection_changed(self, *_args) -> None:
        self._update_action_enabled()
        # Selection-driven LED UX: selected connected devices glow purple.
        addrs = [
            a
            for a in self._selected_addresses()
            if (self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected)
        ]
        self.controller.set_table_selected_devices(addrs)

    def _update_action_enabled(self) -> None:
        # Scan is always available.
        self.action_scan.setEnabled(True)

        def _is_emgs(dev) -> bool:
            try:
                return str(getattr(dev.params, "kind", "EMGS")).upper() == "EMGS"
            except Exception:
                return True

        def _is_akr(dev) -> bool:
            try:
                return str(getattr(dev.params, "kind", "EMGS")).upper() == "AKR"
            except Exception:
                return False

        # Bulk modes applies to EMGS devices only.
        any_connected_emgs = any(d.is_connected and _is_emgs(d) for d in self.controller.manager.devices.values())
        any_streaming_emgs = any(d.is_streaming and _is_emgs(d) for d in self.controller.manager.devices.values())

        addrs = self._selected_addresses()
        if not addrs:
            # No selection: only allow the global EMGS-only action (Bulk Modes) if applicable.
            self.action_bulk_modes.setEnabled(bool(any_connected_emgs) and (not bool(any_streaming_emgs)))
            for a in [self.action_connect, self.action_disconnect, self.action_update, self.action_settings, self.action_time_sync]:
                a.setEnabled(False)
            return

        devs = [self.controller.manager.devices.get(a) for a in addrs]
        devs = [d for d in devs if d is not None]
        if not devs:
            return
        all_emgs_selected = all(_is_emgs(d) for d in devs)
        all_akr_selected = all(_is_akr(d) for d in devs)
        single_kind_selected = bool(all_emgs_selected or all_akr_selected)

        connected = [d.is_connected for d in devs]
        streaming = [d.is_streaming for d in devs]

        any_connected = any(connected)
        all_connected = all(connected)
        any_disconnected = any(not c for c in connected)

        any_streaming = any(streaming)
        _ = any_streaming
        any_not_streaming = any(not s for s in streaming)
        all_not_streaming = all(not s for s in streaming)

        # Connect is meaningful only when at least one selected device is NOT connected.
        self.action_connect.setEnabled(any_disconnected)
        # Disconnect is meaningful only when at least one selected device IS connected.
        self.action_disconnect.setEnabled(any_connected)

        # While a device is streaming, disable other commands for that selection
        # (Update Info / Settings / Time Sync) to avoid BLE congestion and inconsistent state.
        self.action_update.setEnabled(all_connected and all_not_streaming and all_emgs_selected)
        # Settings is available for both EMGS and AKR (different dialogs).
        # AKR devices may stream continuously; keep Settings enabled for AKR even while streaming.
        self.action_settings.setEnabled(all_connected and single_kind_selected and (all_not_streaming or all_akr_selected))
        self.action_time_sync.setEnabled(all_connected and all_not_streaming and all_emgs_selected)

        # Bulk Mode Settings is EMGS-only; if a AKR device is selected, gray it out.
        self.action_bulk_modes.setEnabled(
            bool(any_connected_emgs)
            and (not bool(any_streaming_emgs))
            and bool(all_emgs_selected)
        )

        # Streaming controls are on the Signals tab.
        self.action_stream_start.setEnabled(False)
        self.action_stream_stop.setEnabled(False)

    def _select_all_rows(self) -> None:
        self.table.selectAll()

    def _select_none_rows(self) -> None:
        self.table.clearSelection()

    def _poll_connected_devices(self) -> None:
        # Poll connected devices even if user is not selecting them.
        #
        # While streaming, avoid sending TIME_SYNC polls ("heartbeat") so the device can
        # focus on data packets and the UI doesn't look like it's only receiving A3 replies.
        poll_addrs = [
            a
            for a, d in self.controller.manager.devices.items()
            if d.is_connected
            and (not d.is_streaming)
            and str(getattr(d.params, "kind", "EMGS")).upper() == "EMGS"
        ]
        if poll_addrs:
            self.controller.poll_many(poll_addrs)

        # For streaming devices, only do a local health check (no BLE traffic).
        stream_addrs = [
            a
            for a, d in self.controller.manager.devices.items()
            if d.is_connected
            and d.is_streaming
            and str(getattr(d.params, "kind", "EMGS")).upper() == "EMGS"
        ]
        if stream_addrs:
            self.controller.check_health_many(stream_addrs)

    def _full_update_connected_devices(self) -> None:
        # Heavier refresh: query full info set. Avoid while streaming to reduce BLE congestion.
        addrs = [
            a
            for a, d in self.controller.manager.devices.items()
            if d.is_connected
            and (not d.is_streaming)
            and str(getattr(d.params, "kind", "EMGS")).upper() == "EMGS"
        ]
        if addrs:
            self.controller.update_many(addrs)

    def _selected_addresses(self) -> list[str]:
        selected = self.table.selectionModel().selectedRows()
        addrs: list[str] = []
        for idx in selected:
            src = self.device_proxy.mapToSource(idx)
            addr = self.device_model.address_at(src.row())
            if addr:
                addrs.append(addr)
        return addrs

    @QtCore.pyqtSlot()
    def _connect_selected(self) -> None:
        addrs = self._selected_addresses()
        # Connect only those not already connected
        to_connect = [a for a in addrs if not self.controller.manager.devices[a].is_connected]
        if to_connect:
            self.controller.connect_many(to_connect)
        else:
            self.log_view.append_line("Connect: nothing to do (already connected?)")

    @QtCore.pyqtSlot()
    def _disconnect_selected(self) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if addrs:
            self.controller.disconnect_many(addrs)

    @QtCore.pyqtSlot()
    def _update_selected(self) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if addrs:
            self.controller.update_many(addrs)

    @QtCore.pyqtSlot()
    def _time_sync_selected(self) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if not addrs:
            return
        self.controller.time_sync_one(addrs[0])

    @QtCore.pyqtSlot()
    def _open_settings_for_selected(self) -> None:
        addrs = self._selected_addresses()
        if not addrs:
            return
        self._open_settings_for_address(str(addrs[0]))

    def _open_settings_for_address(self, addr: str) -> None:
        addr = str(addr)
        dev = self.controller.manager.devices.get(addr)
        if not dev:
            return
        if not dev.is_connected:
            self.log_view.append_line("Settings: device not connected")
            return
        kind = str(getattr(dev.params, "kind", "EMGS")).upper()
        if kind == "AKR":
            dlg = AkrDeviceSettingsDialog(controller=self.controller, address=str(addr), device_name=str(dev.params.name), parent=self)
            dlg.exec()
            return

        dlg = DeviceSettingsDialog(dev, parent=self)
        if dlg.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            settings = dlg.get_values()
            self.controller.apply_settings_dict(addr, settings)

    def _stream_selected(self, enable: bool) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if addrs:
            self.controller.stream_many(addrs, enable)

    def _open_table_context_menu(self, pos: QtCore.QPoint) -> None:
        # Only show context menu when right-clicking on an actual device row.
        idx = self.table.indexAt(pos)
        if not idx.isValid():
            return

        # If user right-clicks a different row, select it first so actions apply intuitively.
        sel = self.table.selectionModel()
        if sel and not sel.isSelected(idx):
            sel.select(
                idx,
                QtCore.QItemSelectionModel.SelectionFlag.ClearAndSelect
                | QtCore.QItemSelectionModel.SelectionFlag.Rows,
            )
            self.table.setCurrentIndex(idx)

        menu = QtWidgets.QMenu(self)
        menu.addAction(self.action_scan)
        menu.addAction(self.action_select_all)
        menu.addAction(self.action_select_none)
        menu.addSeparator()
        menu.addAction(self.action_connect)
        menu.addAction(self.action_disconnect)
        menu.addSeparator()
        menu.addAction(self.action_update)
        menu.addAction(self.action_time_sync)
        menu.addAction(self.action_settings)
        menu.addAction(self.action_bulk_modes)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    @QtCore.pyqtSlot()
    def _open_bulk_mode_settings(self) -> None:
        # Apply to all connected devices; avoid applying while any is streaming.
        devs = {a: d for a, d in self.controller.manager.devices.items() if d.is_connected}
        if not devs:
            self.log_view.append_line("Bulk Mode Settings: no connected devices")
            return
        if any(d.is_streaming for d in devs.values()):
            self.log_view.append_line("Bulk Mode Settings: stop streaming before applying")
            return

        dlg = BulkModeSettingsDialog(parent=self)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        icm_enabled, emg_mode = dlg.get_values()
        addrs = list(devs.keys())
        self.controller.apply_modes_many(addrs, icm_enabled, int(emg_mode))
        self.log_view.append_line(f"Bulk Mode Settings: applied to {len(addrs)} device(s)")

    @QtCore.pyqtSlot()
    def _on_device_list_changed(self) -> None:
        self.device_model.refresh_all()
        self._refresh_signal_device_list()
        self._refresh_scenario_device_list()
        self._sync_scenario_controls()
        self._update_action_enabled()

    @QtCore.pyqtSlot(str)
    def _on_device_updated(self, address: str) -> None:
        self.device_model.refresh_row_by_address(address)
        # Scenario tiles: update subtitle if this device is present.
        try:
            for k, tile in getattr(self, "_scenario_controls", {}).items():
                if f"::{address}" in str(k):
                    tile.set_subtitle(self._scenario_tile_subtitle_for_device(str(address)))
        except Exception:
            pass
        # Recording: capture new samples on each device update.
        if getattr(self, "_recording", False) and getattr(self, "_recorder", None) is not None:
            try:
                dev = self.controller.manager.devices.get(address)
                if dev is not None:
                    self._recorder.capture_device(addr=str(address), dev=dev)
            except Exception:
                pass
        # If a new streaming session was armed, latch per-device origin to the first EMG/IMU data packet we see.
        if address in getattr(self, "_device_origin_armed_addrs", set()):
            dev = self.controller.manager.devices.get(address)
            if dev and self._device_origin_s.get(address) is None:
                arm = float(getattr(self, "_device_origin_arm_monotonic_s", 0.0))
                ts_ms: int | None = None
                # Prefer EMG packet timestamp; fall back to IMU.
                if dev.last_emg_time_s is not None and float(dev.last_emg_time_s) >= arm and dev.last_emg_packet_ts_ms is not None:
                    ts_ms = int(dev.last_emg_packet_ts_ms)
                elif dev.last_imu_time_s is not None and float(dev.last_imu_time_s) >= arm and getattr(dev, "last_imu_packet_ts_ms", None) is not None:
                    ts_ms = int(getattr(dev, "last_imu_packet_ts_ms"))
                if ts_ms is not None:
                    self._device_origin_s[address] = float(ts_ms) / 1000.0
                    self._device_origin_armed_addrs.discard(address)
                    try:
                        self.status.showMessage(f"Plot origin latched for {address}: {self._device_origin_s[address]:0.3f}s")
                    except Exception:
                        pass
        self._update_action_enabled()
        self._update_signal_rx_status()

