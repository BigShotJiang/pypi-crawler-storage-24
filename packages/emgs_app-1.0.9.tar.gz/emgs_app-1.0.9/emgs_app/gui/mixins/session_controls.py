from __future__ import annotations

import time
from pathlib import Path

from PyQt6 import QtWidgets

from ... import config
from ...recording import (
    DeviceWideRecorder,
    RecordingSession,
    default_recording_session_paths,
    device_recording_paths,
)
from ..widgets import ScenarioControlTile


class SignalsScenarioSessionMixin:
    # ---------- Signals (charts): session controls ----------
    def _refresh_signal_device_list(self) -> None:
        # Keep current selection if possible.
        prev = self.combo_sig_device.currentData()
        self.combo_sig_device.blockSignals(True)
        self.combo_sig_device.clear()
        self.combo_sig_device.addItem("Select device...", None)
        for addr, dev in self.controller.manager.devices.items():
            name = dev.params.name if dev.params.name and dev.params.name != "/" else "EMGS"
            self.combo_sig_device.addItem(f"{name}  ({addr})", addr)
        self.combo_sig_device.blockSignals(False)
        if prev:
            idx = self.combo_sig_device.findData(prev)
            if idx >= 0:
                self.combo_sig_device.setCurrentIndex(idx)
            else:
                self.combo_sig_device.setCurrentIndex(0)
        else:
            self.combo_sig_device.setCurrentIndex(0)
        self._update_signal_rx_status()

    def _refresh_scenario_device_list(self) -> None:
        # Keep current selection if possible.
        # NOTE: In PyQt, `bool(QComboBox)` can be False when it has 0 items
        # (because `__len__` maps to `count()`), so don't use truthiness here.
        if getattr(self, "combo_scn_device", None) is None:
            return
        prev = self.combo_scn_device.currentData()
        self.combo_scn_device.blockSignals(True)
        self.combo_scn_device.clear()
        self.combo_scn_device.addItem("Select device...", None)
        for addr, dev in self.controller.manager.devices.items():
            name = dev.params.name if dev.params.name and dev.params.name != "/" else "EMGS"
            self.combo_scn_device.addItem(f"{name}  ({addr})", addr)
        self.combo_scn_device.blockSignals(False)
        if prev:
            idx = self.combo_scn_device.findData(prev)
            if idx >= 0:
                self.combo_scn_device.setCurrentIndex(idx)
            else:
                self.combo_scn_device.setCurrentIndex(0)
        else:
            self.combo_scn_device.setCurrentIndex(0)

        # If the active scenario device disappeared, clear it.
        try:
            if self._scenario_active_key:
                # If active device vanished, clear active key.
                if "::" in str(self._scenario_active_key):
                    addr = str(self._scenario_active_key).split("::", 1)[1]
                    if addr not in self.controller.manager.devices:
                        self._scenario_active_key = None
                        if getattr(self, "scn_plot", None):
                            self.scn_plot.clear()
        except Exception:
            pass

    def _scenario_tile_subtitle_for_device(self, addr: str) -> str:
        dev = self.controller.manager.devices.get(str(addr))
        if not dev:
            return str(addr)
        name = dev.params.name if dev.params.name and dev.params.name != "/" else "EMGS"
        status = dev.params.status
        streaming = " • streaming" if bool(getattr(dev, "is_streaming", False)) else ""
        return f"{name} ({addr}) • {status}{streaming}"

    def _sync_scenario_controls(self) -> None:
        """Remove stale Scenario tiles and keep active highlight consistent."""
        # Drop tiles for devices that no longer exist.
        for k in list(getattr(self, "_scenario_controls", {}).keys()):
            if "::" not in str(k):
                continue
            addr = str(k).split("::", 1)[1]
            if addr in self.controller.manager.devices:
                continue
            tile = self._scenario_controls.pop(k, None)
            if tile is not None:
                try:
                    tile.setParent(None)
                except Exception:
                    pass
            if self._scenario_active_key == k:
                self._scenario_active_key = None
                try:
                    self.scn_plot.clear()
                except Exception:
                    pass
        self._scenario_update_active_highlight()
        self._scenario_apply_plot_bounds()

    def _scenario_update_active_highlight(self) -> None:
        for k, tile in getattr(self, "_scenario_controls", {}).items():
            try:
                tile.set_active(bool(self._scenario_active_key == k))
            except Exception:
                pass

    def _scenario_global_plot_bounds(self) -> tuple[float, float, float, float] | None:
        """Global plot bounds across all Scenario tiles.

        Rule: if multiple tiles exist, use the largest max for x/y respectively.
        (For mins, use the smallest min so the view covers all configured ranges.)
        """
        xs0: list[float] = []
        xs1: list[float] = []
        ys0: list[float] = []
        ys1: list[float] = []
        for tile in self._scenario_controls.values():
            try:
                x0, x1, y0, y1 = tile.get_bounds()
                x0, x1 = float(x0), float(x1)
                y0, y1 = float(y0), float(y1)
                if x1 < x0:
                    x0, x1 = x1, x0
                if y1 < y0:
                    y0, y1 = y1, y0
                xs0.append(x0)
                xs1.append(x1)
                ys0.append(y0)
                ys1.append(y1)
            except Exception:
                continue
        if not xs0:
            return None
        return (min(xs0), max(xs1), min(ys0), max(ys1))

    def _scenario_apply_plot_bounds(self) -> None:
        if getattr(self, "scn_plot", None) is None:
            return
        b = self._scenario_global_plot_bounds()
        try:
            if b is None:
                x0, x1, y0, y1 = (-1.0, 1.0, -1.0, 1.0)
            else:
                x0, x1, y0, y1 = b
            self.scn_plot.set_bounds(x_min=float(x0), x_max=float(x1), y_min=float(y0), y_max=float(y1))
        except Exception:
            pass

    @staticmethod
    def _fmt_dur(s: float) -> str:
        s = float(max(0.0, s))
        sec = int(s + 0.5)
        h = sec // 3600
        m = (sec % 3600) // 60
        ss = sec % 60
        if h > 0:
            return f"{h:d}:{m:02d}:{ss:02d}"
        return f"{m:02d}:{ss:02d}"

    @staticmethod
    def _safe_existing_dir(path: str) -> str:
        """Return an existing directory, else fall back to default recording dir."""
        try:
            p = Path(str(path)).expanduser()
            if p.exists():
                if p.is_dir():
                    return str(p)
                if p.parent.exists() and p.parent.is_dir():
                    return str(p.parent)
        except Exception:
            pass
        # Keep file dialogs anchored to the app default recording base.
        fallback = Path.home() / str(getattr(config, "DEFAULT_REC_OUT_DIRNAME", "rr_data"))
        try:
            fallback.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return str(fallback if fallback.exists() else Path.home())

    def _on_signal_device_changed_for_led(self, *_args) -> None:
        """Signals-page device selection → LED (purple), suppressed while streaming."""
        addr = self.combo_sig_device.currentData()
        if isinstance(addr, str) and addr:
            self.controller.set_signals_selected_devices([addr])
        else:
            self.controller.set_signals_selected_devices([])
        self._update_signal_rx_status()

    def _identify_selected_signal_device(self) -> None:
        """Flash purple LED for the currently selected Signals-page device."""
        addr = self.combo_sig_device.currentData()
        if isinstance(addr, str) and addr:
            self.controller.identify_device(addr)

    def _open_settings_for_signal_device(self) -> None:
        """Open device Settings for the currently selected Signals-page device."""
        addr = self.combo_sig_device.currentData()
        if not (isinstance(addr, str) and addr):
            self.log_view.append_line("Settings: no device selected on Signals page")
            return
        self._open_settings_for_address(str(addr))

    def _identify_selected_scenario_device(self) -> None:
        """Flash purple LED for the currently selected Scenario-page device."""
        addr = self.combo_scn_device.currentData() if getattr(self, "combo_scn_device", None) is not None else None
        if isinstance(addr, str) and addr:
            self.controller.identify_device(addr)

    def _scenario_add_from_ui(self) -> None:
        """Add a Scenario tile (right panel) from UI selection."""
        addr = self.combo_scn_device.currentData() if getattr(self, "combo_scn_device", None) is not None else None
        if not (isinstance(addr, str) and addr):
            return
        addr = str(addr)

        scenario_label = str(self.combo_scn_scenario.currentText() if getattr(self, "combo_scn_scenario", None) is not None else "Scenario")
        scenario_key = "mouse"  # only scenario implemented right now
        key = f"{scenario_key}::{addr}"

        # Create tile if missing.
        if key not in self._scenario_controls:
            tile = ScenarioControlTile(
                key=key,
                title=scenario_label,
                subtitle=self._scenario_tile_subtitle_for_device(addr),
                parent=self,
            )
            tile.remove_requested.connect(self._scenario_remove_by_key)
            tile.activate_requested.connect(self._scenario_set_active_key)
            try:
                tile.bounds_changed.connect(self._on_scenario_tile_bounds_changed)
            except Exception:
                pass
            # Insert before the stretch at the end.
            try:
                self.scn_group_panel_layout.insertWidget(self.scn_group_panel_layout.count() - 1, tile)
            except Exception:
                self.scn_group_panel_layout.addWidget(tile)
            self._scenario_controls[key] = tile

        self._scenario_set_active_key(key)
        self._scenario_apply_plot_bounds()
        try:
            self.status.showMessage(f"Scenario: added/selected {addr}")
        except Exception:
            pass

    def _scenario_remove_active(self) -> None:
        """Remove the active Scenario tile (or the selected device's tile)."""
        key = self._scenario_active_key
        if not key:
            addr = self.combo_scn_device.currentData() if getattr(self, "combo_scn_device", None) is not None else None
            if isinstance(addr, str) and addr:
                key = f"mouse::{addr}"
        if key:
            self._scenario_remove_by_key(str(key))

    def _scenario_set_active_key(self, key: str) -> None:
        key = str(key)
        if key not in getattr(self, "_scenario_controls", {}):
            return
        self._scenario_active_key = key
        self._scenario_update_active_highlight()

    def _scenario_remove_by_key(self, key: str) -> None:
        key = str(key)
        tile = self._scenario_controls.pop(key, None)
        if tile is not None:
            try:
                tile.setParent(None)
            except Exception:
                pass
        if self._scenario_active_key == key:
            self._scenario_active_key = None
            try:
                self.scn_plot.clear()
            except Exception:
                pass
        self._scenario_update_active_highlight()
        self._scenario_apply_plot_bounds()

    def _on_scenario_tile_bounds_changed(self, *_args) -> None:
        # Recompute the global bounds and apply (largest max among tiles).
        self._scenario_apply_plot_bounds()

    def _scenario_stream_selected(self, enable: bool) -> None:
        """Start/stop streaming for the Scenario page.

        For now: streams all connected devices (Scenario right panel is per-device tiles).
        """
        target_addrs = [a for a, d in self.controller.manager.devices.items() if d.is_connected]

        if not target_addrs:
            self.log_view.append_line("Scenario: no connected devices")
            return

        eligible_devs = {a: d for a in target_addrs if (d := self.controller.manager.devices.get(a)) and d.is_connected}
        if not eligible_devs:
            self.log_view.append_line("Scenario: no connected devices")
            return

        if enable:
            to_start = [a for a, d in eligible_devs.items() if not d.is_streaming]
            if not to_start:
                self.log_view.append_line("Scenario: devices already streaming")
                return
            self._signals_session_start_monotonic_s = time.monotonic()
            self._device_origin_arm_monotonic_s = time.monotonic()
            for a in to_start:
                self._device_origin_s[a] = None
            self._device_origin_armed_addrs = set(to_start)
            self.controller.stream_many(to_start, enable=True)
        else:
            to_stop = [a for a, d in eligible_devs.items() if d.is_streaming]
            if not to_stop:
                self.log_view.append_line("Scenario: no devices are streaming")
                return
            self.controller.stream_many(to_stop, enable=False)

    def _on_tab_changed(self, index: int) -> None:
        # Only keep Signals-page LED selection active while Signals tab is visible.
        try:
            w = self.tabs.widget(index)
        except Exception:
            return
        if w is self.signals_page:
            self._on_signal_device_changed_for_led()
        else:
            self.controller.set_signals_selected_devices([])

    def _signal_plot_addresses(self) -> list[str]:
        """Return device addresses that are currently 'enlisted' in the plot."""
        addrs: list[str] = []
        for g in self.multi_plot.list_groups():
            # Group keys are built as f"{addr}:{preset_label}".
            if ":" not in g:
                continue
            addr = g.split(":", 1)[0].strip()
            if addr:
                addrs.append(addr)
        # Preserve order, unique.
        return list(dict.fromkeys(addrs))

    def _device_time_origin_s(self, address: str) -> float | None:
        """Per-device plot origin (seconds), latched at stream start."""
        return self._device_origin_s.get(str(address))

    def _signals_stream_plotted(self, enable: bool) -> None:
        # Streaming session is driven by what's plotted. If nothing is plotted, allow
        # streaming all connected devices (useful for "record-only" workflows).
        plot_addrs = self._signal_plot_addresses()
        if plot_addrs:
            target_addrs = list(plot_addrs)
        else:
            target_addrs = [a for a, d in self.controller.manager.devices.items() if d.is_connected]
        if not target_addrs:
            self.log_view.append_line("Signals: no connected devices")
            return

        eligible_devs = {a: d for a in target_addrs if (d := self.controller.manager.devices.get(a)) and d.is_connected}
        if not eligible_devs:
            self.log_view.append_line("Signals: no connected devices")
            return

        if enable:
            to_start = [a for a, d in eligible_devs.items() if not d.is_streaming]
            if not to_start:
                self.log_view.append_line("Signals: devices already streaming")
                return
            # Session elapsed timer starts now (reset when stream starts).
            self._signals_session_start_monotonic_s = time.monotonic()
            # Arm per-device plot origins: each device latches t0 on its first EMG/IMU data packet
            # received after stream start. (Not shared across devices.)
            self._device_origin_arm_monotonic_s = time.monotonic()
            for a in to_start:
                self._device_origin_s[a] = None
            self._device_origin_armed_addrs = set(to_start)
            self.controller.stream_many(to_start, enable=True)
        else:
            to_stop = [a for a, d in eligible_devs.items() if d.is_streaming]
            if not to_stop:
                self.log_view.append_line("Signals: no devices are streaming")
                return
            self.controller.stream_many(to_stop, enable=False)

    def _update_signal_rx_status(self) -> None:
        # Session status: show if ANY device is currently streaming (even if no plotted curves).
        any_streaming_global = any(d.is_streaming for d in self.controller.manager.devices.values())
        any_streaming_emgs = any(
            d.is_streaming and str(getattr(d.params, "kind", "EMGS")).upper() == "EMGS"
            for d in self.controller.manager.devices.values()
        )
        # Update both Signals and Scenario session labels (same underlying stream/record state).
        for lbl in (getattr(self, "lbl_sig_session", None), getattr(self, "lbl_scn_session", None)):
            if not lbl:
                continue
            if any_streaming_global:
                now = time.monotonic()
                t0 = float(self._signals_session_start_monotonic_s) if self._signals_session_start_monotonic_s is not None else now
                elapsed = self._fmt_dur(now - t0)
                parts = [f"Session: STREAMING • {elapsed}"]
                if bool(getattr(self, "_recording", False)) and getattr(self, "_recording_start_monotonic_s", None) is not None:
                    rec_elapsed = self._fmt_dur(now - float(self._recording_start_monotonic_s))
                    parts.append(f"REC • {rec_elapsed}")
                elif getattr(self, "_last_recording_duration_s", None) is not None:
                    parts.append(f"Last REC • {self._fmt_dur(float(self._last_recording_duration_s))}")
                lbl.setText("  |  ".join(parts))
                lbl.setStyleSheet("color: #2ed573; font-weight: 700;")
            else:
                parts = ["Session: IDLE"]
                if getattr(self, "_last_recording_duration_s", None) is not None:
                    parts.append(f"Last REC • {self._fmt_dur(float(self._last_recording_duration_s))}")
                lbl.setText("  |  ".join(parts))
                lbl.setStyleSheet("color: #9fb2e8; font-weight: 600;")

        # Settings page: processed-data toggles are not allowed to change mid-session.
        if getattr(self, "chk_proc_emg_env", None):
            # Lock EMG processed-data settings only when EMGS devices are streaming.
            locked = bool(any_streaming_emgs)
            for w in (
                self.chk_proc_emg_env,
                getattr(self, "spin_proc_emg_env_win", None),
                getattr(self, "chk_proc_emg_freq", None),
                getattr(self, "spin_proc_emg_spec_win", None),
                getattr(self, "chk_proc_emg_fatigue", None),
                getattr(self, "spin_proc_emg_fatigue_baseline_s", None),
                getattr(self, "spin_proc_emg_fatigue_w_mdf", None),
                getattr(self, "spin_proc_emg_fatigue_w_rms", None),
                getattr(self, "spin_proc_emg_fatigue_conf_n", None),
            ):
                if w is None:
                    continue
                try:
                    w.setEnabled(not locked)
                except Exception:
                    pass
            # When not locked, disable fatigue parameter spins unless fatigue is enabled.
            if not locked and getattr(self, "chk_proc_emg_fatigue", None):
                enabled = bool(self.chk_proc_emg_fatigue.isChecked())
                for w in (
                    getattr(self, "spin_proc_emg_fatigue_baseline_s", None),
                    getattr(self, "spin_proc_emg_fatigue_w_mdf", None),
                    getattr(self, "spin_proc_emg_fatigue_w_rms", None),
                    getattr(self, "spin_proc_emg_fatigue_conf_n", None),
                ):
                    if w is None:
                        continue
                    try:
                        w.setEnabled(bool(enabled))
                    except Exception:
                        pass
        # Enable streaming controls (Signals tab) based on whether there are any plotted curves/devices.
        plot_addrs = self._signal_plot_addresses()
        if not plot_addrs:
            # When nothing is plotted, enable stream controls based on all connected devices.
            devs_all = [d for d in self.controller.manager.devices.values() if d.is_connected]
            sig_any_connected = bool(devs_all)
            sig_any_streaming = any(d.is_streaming for d in devs_all)
            sig_any_not_streaming = any((not d.is_streaming) for d in devs_all)
        else:
            devs = [self.controller.manager.devices.get(a) for a in plot_addrs]
            devs = [d for d in devs if d is not None]
            connected = [d for d in devs if d.is_connected]
            sig_any_connected = bool(connected)
            sig_any_streaming = any(d.is_streaming for d in connected)
            sig_any_not_streaming = any((not d.is_streaming) for d in connected)

        try:
            self.btn_sig_stream_start.setEnabled(bool(sig_any_connected) and bool(sig_any_not_streaming))
            self.btn_sig_stream_stop.setEnabled(bool(sig_any_connected) and bool(sig_any_streaming))
            self.btn_sig_record_start.setEnabled(bool(any_streaming_global) and not bool(self._recording))
            self.btn_sig_record_stop.setEnabled(bool(self._recording))
            self.btn_sig_reset.setEnabled(bool(any_streaming_global))
            selected_addr = self.combo_sig_device.currentData() if getattr(self, "combo_sig_device", None) is not None else None
            selected_dev = self.controller.manager.devices.get(str(selected_addr)) if isinstance(selected_addr, str) and selected_addr else None
            if selected_dev is None or not bool(getattr(selected_dev, "is_connected", False)):
                self.btn_sig_settings.setEnabled(False)
            else:
                kind = str(getattr(selected_dev.params, "kind", "EMGS")).upper()
                # Mirror Connect-tab Settings rule: AKR can stay configurable while streaming.
                self.btn_sig_settings.setEnabled((not bool(getattr(selected_dev, "is_streaming", False))) or kind == "AKR")
        except Exception:
            pass

        # Scenario tab stream/record/reset controls (currently global/session-level like Signals).
        try:
            any_connected_global = any(d.is_connected for d in self.controller.manager.devices.values())
            any_not_streaming_global = any(d.is_connected and (not d.is_streaming) for d in self.controller.manager.devices.values())
            self.btn_scn_stream_start.setEnabled(bool(any_connected_global) and bool(any_not_streaming_global))
            self.btn_scn_stream_stop.setEnabled(bool(any_connected_global) and bool(any_streaming_global))
            self.btn_scn_record_start.setEnabled(bool(any_streaming_global) and not bool(self._recording))
            self.btn_scn_record_stop.setEnabled(bool(self._recording))
            self.btn_scn_reset.setEnabled(bool(any_streaming_global))
        except Exception:
            pass

    def _signals_reset_processed(self) -> None:
        # Reset processed buffers for currently streaming devices (prefer those enlisted in plot).
        plot_addrs = self._signal_plot_addresses()
        addrs = [a for a in plot_addrs if (self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_streaming)]
        if not addrs:
            addrs = [a for a, d in self.controller.manager.devices.items() if d.is_streaming]
        if not addrs:
            self.log_view.append_line("Reset: no streaming devices")
            return
        self.controller.reset_processed_state_many(addrs)
        # Reset session elapsed timer as requested (acts like a "reset stream" marker).
        self._signals_session_start_monotonic_s = time.monotonic()
        self.log_view.append_line(f"Reset: processed state cleared for {len(addrs)} device(s)")
        self._update_signal_rx_status()

    def _signals_start_record(self) -> None:
        if self._recording:
            return
        # Record all currently streaming devices (even if not plotted).
        addrs = [a for a, d in self.controller.manager.devices.items() if d.is_streaming]
        if not addrs:
            self.log_view.append_line("Record: no streaming devices (start streaming first)")
            return
        # Use configured output folder (Settings → Recording Data). If missing, ask once.
        out_base = str(getattr(self, "_rec_out_dir", "") or "").strip()
        if not out_base:
            out_base = QtWidgets.QFileDialog.getExistingDirectory(self, "Select recording output folder")
            if not out_base:
                return
            try:
                self._rec_out_dir = str(out_base)
                if getattr(self, "edit_rec_out_dir", None):
                    self.edit_rec_out_dir.setText(str(out_base))
            except Exception:
                pass

        # Column selection from Settings (does not depend on sensor enable state).
        emg_fields = [f for f in self._rec_emg_fields_all if f in self._rec_emg_fields_selected]
        imu_fields = [f for f in self._rec_imu_fields_all if f in self._rec_imu_fields_selected]
        robot_fields = [f for f in self._rec_robot_fields_all if f in self._rec_robot_fields_selected]
        include_emg = bool(emg_fields)
        include_imu = bool(imu_fields)
        include_robot = bool(robot_fields)
        if not include_emg and not include_imu and not include_robot:
            self.log_view.append_line("Record: no columns selected (enable at least one column in Settings → Recording Data)")
            return

        # Create session folder emgs_<timestamp>/ and per-device files.
        session_paths = default_recording_session_paths(out_base, prefix="emgs")
        recorders: dict[str, DeviceWideRecorder] = {}
        for a in addrs:
            dev = self.controller.manager.devices.get(a)
            if not dev:
                continue
            # Use device plot origin if latched; otherwise fall back to earliest available sample.
            origin_s = self._device_time_origin_s(a)
            if origin_s is None:
                guess: float | None = None
                try:
                    if dev.emg_buffer:
                        guess = float(dev.emg_buffer[0][0])
                    elif dev.acc_buffer:
                        guess = float(dev.acc_buffer[0][0])
                    elif getattr(dev, "raw_acc_buffer", None):
                        if dev.raw_acc_buffer:
                            guess = float(dev.raw_acc_buffer[0][0])
                    elif getattr(dev, "akr_step_dt_ms_buffer", None):
                        if dev.akr_step_dt_ms_buffer:
                            guess = float(dev.akr_step_dt_ms_buffer[0][0])
                except Exception:
                    guess = None
                origin_s = float(guess) if guess is not None else 0.0

            paths = device_recording_paths(
                session_paths,
                addr=str(a),
                include_emg=include_emg,
                include_imu=include_imu,
                include_robot=include_robot,
                prefix="emgs",
            )
            try:
                recorders[str(a)] = DeviceWideRecorder(
                    addr=str(a),
                    paths=paths,
                    origin_s=float(origin_s),
                    emg_fields=emg_fields,
                    imu_fields=imu_fields,
                    robot_fields=robot_fields,
                    on_log=self.log_view.append_line,
                )
            except Exception as e:
                self.log_view.append_line(f"Record: failed to open files for {a}: {e}")

        if not recorders:
            self.log_view.append_line("Record: failed to start (no recorders created)")
            return

        self._recorder = RecordingSession(session_paths=session_paths, recorders=recorders, on_log=self.log_view.append_line)
        self._recording = True
        self._recording_start_monotonic_s = time.monotonic()
        self._last_recording_duration_s = None
        self.log_view.append_line(f"Record: started ({len(recorders)} device(s))")
        self._update_signal_rx_status()

    def _signals_stop_record(self) -> None:
        if not self._recording:
            return
        t0 = float(self._recording_start_monotonic_s) if self._recording_start_monotonic_s is not None else None
        try:
            if self._recorder is not None:
                self._recorder.close()
        except Exception:
            pass
        self._recorder = None
        self._recording = False
        self._recording_start_monotonic_s = None
        if t0 is not None:
            self._last_recording_duration_s = float(max(0.0, time.monotonic() - t0))
        self.log_view.append_line("Record: stopped")
        self._update_signal_rx_status()

    def _set_plot_frozen(self, frozen: bool) -> None:
        self._plot_frozen = bool(frozen)
        for btn in (getattr(self, "btn_sig_freeze", None), getattr(self, "btn_scn_freeze", None)):
            if not btn:
                continue
            try:
                btn.blockSignals(True)
                btn.setChecked(bool(self._plot_frozen))
                btn.setText("Frozen" if self._plot_frozen else "Freeze")
            except Exception:
                pass
            finally:
                try:
                    btn.blockSignals(False)
                except Exception:
                    pass
        # Keep a subtle hint in the status bar.
        try:
            if self._plot_frozen:
                self.status.showMessage("Plot frozen (stream continues).")
            else:
                self.status.showMessage(f"Backend: {self.controller.backend_kind}")
        except Exception:
            pass

