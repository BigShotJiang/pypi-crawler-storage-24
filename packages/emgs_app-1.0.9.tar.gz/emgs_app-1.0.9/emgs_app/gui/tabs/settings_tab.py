from __future__ import annotations

from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets

from ... import config


def build_settings_tab(self) -> None:
    """Build the Settings tab UI onto an existing `MainWindow` instance."""
    # --- Settings tab ---
    self.settings_page = QtWidgets.QWidget()
    settings_layout = QtWidgets.QVBoxLayout(self.settings_page)
    settings_layout.setContentsMargins(12, 12, 12, 12)
    settings_layout.setSpacing(12)

    # Info paragraph removed (was mainly developer-facing).
    self.lbl_settings_info = QtWidgets.QLabel("")

    # --- Save / Load Profile (top of Settings page) ---
    grp_profile = QtWidgets.QGroupBox("Save / Load Profile")
    prof_l = QtWidgets.QHBoxLayout(grp_profile)
    prof_l.setContentsMargins(10, 10, 10, 10)
    prof_l.setSpacing(8)
    self.edit_profile_path = QtWidgets.QLineEdit()
    self.edit_profile_path.setPlaceholderText("Profile file path (.json)")
    self.btn_profile_load = QtWidgets.QPushButton("Load…")
    self.btn_profile_save = QtWidgets.QPushButton("Save…")
    self.btn_profile_reset = QtWidgets.QPushButton("Reset")
    prof_l.addWidget(self.edit_profile_path, 1)
    prof_l.addWidget(self.btn_profile_load)
    prof_l.addWidget(self.btn_profile_save)
    prof_l.addWidget(self.btn_profile_reset)

    self.btn_profile_load.clicked.connect(self._profile_load_clicked)
    self.btn_profile_save.clicked.connect(self._profile_save_clicked)
    self.btn_profile_reset.clicked.connect(self._profile_reset_clicked)

    grp_processed = QtWidgets.QGroupBox("Processed Data")
    grp_layout = QtWidgets.QVBoxLayout(grp_processed)
    grp_layout.setContentsMargins(10, 10, 10, 10)
    grp_layout.setSpacing(8)

    form = QtWidgets.QFormLayout()
    form.setContentsMargins(0, 0, 0, 0)
    form.setHorizontalSpacing(12)
    form.setVerticalSpacing(8)
    # Let the right/field column actually grow with available width.
    # Without this, word-wrapped hint labels can get a narrow width and wrap early.
    form.setFieldGrowthPolicy(QtWidgets.QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)

    def _hint(txt: str) -> QtWidgets.QLabel:
        lab = QtWidgets.QLabel(txt)
        lab.setWordWrap(True)
        lab.setStyleSheet("color: #9fb2e8; font-size: 11px;")
        lab.setMinimumWidth(0)
        lab.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Preferred)
        return lab

    def _heading(txt: str) -> QtWidgets.QLabel:
        lab = QtWidgets.QLabel(txt)
        f = QtGui.QFont(lab.font())
        f.setBold(True)
        # Make headings visually distinct without being huge.
        f.setPointSize(max(12, int(f.pointSize() if f.pointSize() > 0 else 11) + 2))
        lab.setFont(f)
        lab.setStyleSheet("color: #d7e1ff;")
        lab.setWordWrap(True)
        return lab

    def _req(txt: str) -> QtWidgets.QLabel:
        """Important requirements (shown in red) for enabling processed signals."""
        lab = QtWidgets.QLabel(txt)
        lab.setWordWrap(True)
        lab.setStyleSheet("color: #ff4757; font-weight: 800; font-size: 11px;")
        lab.setMinimumWidth(0)
        lab.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Preferred)
        return lab

    def _row_with_hint(w: QtWidgets.QWidget, hint_txt: str) -> QtWidgets.QWidget:
        wrap = QtWidgets.QWidget()
        wrap.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Preferred)
        # Stack hint below the control so the hint can use the full field width
        # (prevents early wrapping caused by long control text, e.g. checkboxes).
        l = QtWidgets.QVBoxLayout(wrap)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(2)
        l.addWidget(w)
        l.addWidget(_hint(hint_txt))
        return wrap

    form.addRow(_heading("— EMG Analysis —"))
    form.addRow(_req("Requires: EMG RAW streaming enabled on the device (processed EMG is computed from raw EMG samples)."))

    self.chk_proc_emg_env = QtWidgets.QCheckBox("Enable EMG RMS Envelope")
    self.chk_proc_emg_env.setToolTip("When enabled, the next streaming session will compute EMG RMS envelope data.")
    self.chk_proc_emg_env.setChecked(bool(getattr(self.controller.manager, "proc_enable_emg_rms_envelope_next", False)))
    self.chk_proc_emg_env.toggled.connect(self._on_proc_settings_changed)
    form.addRow("", _row_with_hint(self.chk_proc_emg_env, "Computes a smoothed RMS envelope over raw EMG samples (next session)."))

    self.spin_proc_emg_env_win = QtWidgets.QSpinBox()
    self.spin_proc_emg_env_win.setRange(10, 5000)
    self.spin_proc_emg_env_win.setSingleStep(10)
    self.spin_proc_emg_env_win.setSuffix(" samples")
    self.spin_proc_emg_env_win.setToolTip("RMS envelope window length in samples (latched next session).")
    self.spin_proc_emg_env_win.setValue(int(getattr(self.controller.manager, "proc_emg_rms_window_n_next", config.EMG_RMS_WINDOW_N)))
    self.spin_proc_emg_env_win.valueChanged.connect(self._on_proc_settings_changed)
    form.addRow("RMS window", _row_with_hint(self.spin_proc_emg_env_win, "Number of samples used in RMS envelope. Larger = smoother but slower response."))

    self.chk_proc_emg_freq = QtWidgets.QCheckBox("Enable EMG Frequency Features (MDF/MNF)")
    self.chk_proc_emg_freq.setToolTip("When enabled, the next streaming session will compute median/mean frequency and spectra.")
    self.chk_proc_emg_freq.setChecked(bool(getattr(self.controller.manager, "proc_enable_emg_freq_features_next", False)))
    self.chk_proc_emg_freq.toggled.connect(self._on_proc_settings_changed)
    form.addRow("", _row_with_hint(self.chk_proc_emg_freq, "Computes MDF/MNF from a windowed FFT over the last N raw EMG samples (next session)."))

    self.spin_proc_emg_spec_win = QtWidgets.QSpinBox()
    self.spin_proc_emg_spec_win.setRange(128, 10000)
    self.spin_proc_emg_spec_win.setSingleStep(100)
    self.spin_proc_emg_spec_win.setSuffix(" samples")
    self.spin_proc_emg_spec_win.setToolTip("Spectral window length in samples (latched next session).")
    self.spin_proc_emg_spec_win.setValue(int(getattr(self.controller.manager, "proc_emg_spec_window_n_next", getattr(config, "EMG_SPEC_WINDOW_N", 1000))))
    self.spin_proc_emg_spec_win.valueChanged.connect(self._on_proc_settings_changed)
    form.addRow("FFT window", _row_with_hint(self.spin_proc_emg_spec_win, "FFT window length in samples. Larger = better frequency resolution, slower updates."))

    # --- Fatigue (unsupervised) ---
    form.addRow(_heading("— Fatigue (unsupervised) —"))
    form.addRow(_req("Requires: Enable “EMG Frequency Features (MDF/MNF)” + EMG RAW streaming (fatigue uses MDF + RMS trend)."))

    self.chk_proc_emg_fatigue = QtWidgets.QCheckBox("Enable fatigue score (heuristic)")
    self.chk_proc_emg_fatigue.setToolTip(
        "Computes a 0..1 fatigue score from MDF drop + RMS rise (requires EMG Frequency Features). "
        "This is NOT a calibrated probability."
    )
    self.chk_proc_emg_fatigue.setChecked(bool(getattr(self.controller.manager, "proc_enable_emg_fatigue_next", getattr(config, "EMG_FATIGUE_ENABLE_DEFAULT", False))))
    self.chk_proc_emg_fatigue.toggled.connect(self._on_proc_settings_changed)
    form.addRow("", _row_with_hint(self.chk_proc_emg_fatigue, "Heuristic fatigue score from MDF drop + RMS rise (not a calibrated probability)."))

    self.spin_proc_emg_fatigue_baseline_s = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_fatigue_baseline_s.setDecimals(1)
    self.spin_proc_emg_fatigue_baseline_s.setRange(1.0, 120.0)
    self.spin_proc_emg_fatigue_baseline_s.setSingleStep(1.0)
    self.spin_proc_emg_fatigue_baseline_s.setSuffix(" s")
    self.spin_proc_emg_fatigue_baseline_s.setToolTip("Baseline duration (first N seconds) used to estimate non-fatigued MDF/RMS.")
    self.spin_proc_emg_fatigue_baseline_s.setValue(float(getattr(self.controller.manager, "proc_emg_fatigue_baseline_s_next", getattr(config, "EMG_FATIGUE_BASELINE_S", 10.0))))
    self.spin_proc_emg_fatigue_baseline_s.valueChanged.connect(self._on_proc_settings_changed)
    form.addRow("Baseline", _row_with_hint(self.spin_proc_emg_fatigue_baseline_s, "First N seconds used to define the non-fatigued reference level."))

    self.spin_proc_emg_fatigue_w_mdf = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_fatigue_w_mdf.setDecimals(1)
    self.spin_proc_emg_fatigue_w_mdf.setRange(0.0, 100.0)
    self.spin_proc_emg_fatigue_w_mdf.setSingleStep(5.0)
    self.spin_proc_emg_fatigue_w_mdf.setSuffix(" %")
    self.spin_proc_emg_fatigue_w_mdf.setToolTip("Weight for MDF drop contribution (percent; weights are normalized internally).")
    self.spin_proc_emg_fatigue_w_mdf.setValue(float(getattr(self.controller.manager, "proc_emg_fatigue_weight_mdf_pct_next", getattr(config, "EMG_FATIGUE_WEIGHT_MDF_PCT", 70.0))))
    self.spin_proc_emg_fatigue_w_mdf.valueChanged.connect(self._on_proc_settings_changed)
    form.addRow("Weight MDF", _row_with_hint(self.spin_proc_emg_fatigue_w_mdf, "Relative weight of MDF drop in the fatigue score."))

    self.spin_proc_emg_fatigue_w_rms = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_fatigue_w_rms.setDecimals(1)
    self.spin_proc_emg_fatigue_w_rms.setRange(0.0, 100.0)
    self.spin_proc_emg_fatigue_w_rms.setSingleStep(5.0)
    self.spin_proc_emg_fatigue_w_rms.setSuffix(" %")
    self.spin_proc_emg_fatigue_w_rms.setToolTip("Weight for RMS rise contribution (percent; weights are normalized internally).")
    self.spin_proc_emg_fatigue_w_rms.setValue(float(getattr(self.controller.manager, "proc_emg_fatigue_weight_rms_pct_next", getattr(config, "EMG_FATIGUE_WEIGHT_RMS_PCT", 30.0))))
    self.spin_proc_emg_fatigue_w_rms.valueChanged.connect(self._on_proc_settings_changed)
    form.addRow("Weight RMS", _row_with_hint(self.spin_proc_emg_fatigue_w_rms, "Relative weight of RMS rise in the fatigue score."))

    self.spin_proc_emg_fatigue_conf_n = QtWidgets.QSpinBox()
    self.spin_proc_emg_fatigue_conf_n.setRange(5, 500)
    self.spin_proc_emg_fatigue_conf_n.setSingleStep(5)
    self.spin_proc_emg_fatigue_conf_n.setSuffix(" updates")
    self.spin_proc_emg_fatigue_conf_n.setToolTip("Confidence uses MDF monotonicity over the last N feature updates.")
    self.spin_proc_emg_fatigue_conf_n.setValue(int(getattr(self.controller.manager, "proc_emg_fatigue_conf_recent_n_next", getattr(config, "EMG_FATIGUE_CONF_RECENT_N", 60))))
    self.spin_proc_emg_fatigue_conf_n.valueChanged.connect(self._on_proc_settings_changed)
    form.addRow("Confidence window", _row_with_hint(self.spin_proc_emg_fatigue_conf_n, "N most recent feature updates used to compute confidence."))
    # Wrap the long processed-data panel in a scroll area so the Settings page doesn't grow taller.
    self.lbl_proc_note = QtWidgets.QLabel("Note: changes apply next session; stop streaming to change.")
    self.lbl_proc_note.setStyleSheet("color: #9fb2e8;")

    proc_scroll = QtWidgets.QScrollArea()
    proc_scroll.setWidgetResizable(True)
    proc_scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)

    proc_inner = QtWidgets.QWidget()
    proc_inner_l = QtWidgets.QVBoxLayout(proc_inner)
    proc_inner_l.setContentsMargins(0, 0, 0, 0)
    proc_inner_l.setSpacing(8)
    proc_inner_l.addLayout(form)
    proc_inner_l.addWidget(self.lbl_proc_note)
    proc_inner_l.addStretch(1)
    proc_scroll.setWidget(proc_inner)

    grp_layout.addWidget(proc_scroll, 1)

    # --- Recording Data (right panel on Settings page) ---
    grp_recording = QtWidgets.QGroupBox("Recording Data")
    rec_layout = QtWidgets.QVBoxLayout(grp_recording)
    rec_layout.setContentsMargins(10, 10, 10, 10)
    rec_layout.setSpacing(8)

    # Target folder row
    row_dir = QtWidgets.QWidget()
    row_dir_l = QtWidgets.QHBoxLayout(row_dir)
    row_dir_l.setContentsMargins(0, 0, 0, 0)
    row_dir_l.setSpacing(6)
    self.edit_rec_out_dir = QtWidgets.QLineEdit()
    self.edit_rec_out_dir.setPlaceholderText("Recording output folder (base directory)")
    self.edit_rec_out_dir.setText(str(getattr(self, "_rec_out_dir", "")))
    btn_browse = QtWidgets.QToolButton()
    btn_browse.setText("Browse…")
    btn_browse.setToolTip("Choose recording output folder")
    row_dir_l.addWidget(self.edit_rec_out_dir, 1)
    row_dir_l.addWidget(btn_browse, 0)

    def _browse_rec_dir() -> None:
        default_out = str(
            getattr(self, "_rec_out_dir", "")
            or (Path.home() / str(getattr(config, "DEFAULT_REC_OUT_DIRNAME", "rr_data")))
        )
        start = self._safe_existing_dir(self.edit_rec_out_dir.text().strip() or default_out)
        d = QtWidgets.QFileDialog.getExistingDirectory(self, "Select recording output folder", start)
        if d:
            self.edit_rec_out_dir.setText(str(d))

    btn_browse.clicked.connect(_browse_rec_dir)

    def _sync_rec_dir(*_args) -> None:
        self._rec_out_dir = self.edit_rec_out_dir.text().strip()

    self.edit_rec_out_dir.textChanged.connect(_sync_rec_dir)
    rec_layout.addWidget(QtWidgets.QLabel("Output folder"))
    rec_layout.addWidget(row_dir)

    # Column selection
    lbl_cols = QtWidgets.QLabel("Columns to include (not dependent on sensor enable state)")
    lbl_cols.setStyleSheet("color: #9fb2e8;")
    rec_layout.addWidget(lbl_cols)

    cols_scroll = QtWidgets.QScrollArea()
    cols_scroll.setWidgetResizable(True)
    cols_scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
    cols_inner = QtWidgets.QWidget()
    cols_scroll.setWidget(cols_inner)
    cols_l = QtWidgets.QVBoxLayout(cols_inner)
    cols_l.setContentsMargins(0, 0, 0, 0)
    cols_l.setSpacing(10)

    # EMG columns
    grp_emg_cols = QtWidgets.QGroupBox("EMG columns (1 ms)")
    g1_wrap = QtWidgets.QVBoxLayout(grp_emg_cols)
    g1_wrap.setContentsMargins(8, 8, 8, 8)
    g1_wrap.setSpacing(8)
    g1_btns = QtWidgets.QHBoxLayout()
    g1_btns.setContentsMargins(0, 0, 0, 0)
    g1_btns.setSpacing(6)
    btn_emg_all = QtWidgets.QToolButton()
    btn_emg_all.setText("Select All")
    btn_emg_none = QtWidgets.QToolButton()
    btn_emg_none.setText("Select None")
    g1_btns.addWidget(btn_emg_all)
    g1_btns.addWidget(btn_emg_none)
    g1_btns.addStretch(1)
    g1_wrap.addLayout(g1_btns)
    g1 = QtWidgets.QGridLayout()
    g1.setContentsMargins(0, 0, 0, 0)
    g1.setHorizontalSpacing(10)
    g1.setVerticalSpacing(6)
    g1_wrap.addLayout(g1)
    self._rec_emg_chk: dict[str, QtWidgets.QCheckBox] = {}
    for i, f in enumerate(self._rec_emg_fields_all):
        cb = QtWidgets.QCheckBox(f)
        cb.setChecked(f in self._rec_emg_fields_selected)
        self._rec_emg_chk[f] = cb
        g1.addWidget(cb, i // 2, i % 2)

    # IMU columns
    grp_imu_cols = QtWidgets.QGroupBox("IMU columns (10 ms)")
    g2_wrap = QtWidgets.QVBoxLayout(grp_imu_cols)
    g2_wrap.setContentsMargins(8, 8, 8, 8)
    g2_wrap.setSpacing(8)
    g2_btns = QtWidgets.QHBoxLayout()
    g2_btns.setContentsMargins(0, 0, 0, 0)
    g2_btns.setSpacing(6)
    btn_imu_all = QtWidgets.QToolButton()
    btn_imu_all.setText("Select All")
    btn_imu_none = QtWidgets.QToolButton()
    btn_imu_none.setText("Select None")
    g2_btns.addWidget(btn_imu_all)
    g2_btns.addWidget(btn_imu_none)
    g2_btns.addStretch(1)
    g2_wrap.addLayout(g2_btns)
    g2 = QtWidgets.QGridLayout()
    g2.setContentsMargins(0, 0, 0, 0)
    g2.setHorizontalSpacing(10)
    g2.setVerticalSpacing(6)
    g2_wrap.addLayout(g2)
    self._rec_imu_chk: dict[str, QtWidgets.QCheckBox] = {}
    for i, f in enumerate(self._rec_imu_fields_all):
        cb = QtWidgets.QCheckBox(f)
        cb.setChecked(f in self._rec_imu_fields_selected)
        self._rec_imu_chk[f] = cb
        g2.addWidget(cb, i // 3, i % 3)

    # Robot motor common columns (virtual helper controls mapped to walk/cpm/measure fields).
    self._rec_robot_motor_common_map: dict[str, tuple[str, str, str]] = {
        # Shared Motor + Health fields across walk/cpm/measure. State is intentionally excluded.
        "fid": ("walk_fid", "cpm_fid", "measure_fid"),
        "dt_ms": ("walk_dt_ms", "cpm_dt_ms", "measure_dt_ms"),
        "pos_rad": ("walk_pos_rad", "cpm_pos_rad", "measure_pos_rad"),
        "vel_rad_s": ("walk_vel_rad_s", "cpm_vel_rad_s", "measure_vel_rad_s"),
        "tq_nm": ("walk_tq_nm", "cpm_tq_nm", "measure_tq_nm"),
        "temp_c": ("walk_temp_c", "cpm_temp_c", "measure_temp_c"),
        "vbus_v": ("walk_vbus_v", "cpm_vbus_v", "measure_vbus_v"),
        "pattern": ("walk_pattern", "cpm_pattern", "measure_pattern"),
        "err_code": ("walk_err_code", "cpm_err_code", "measure_err_code"),
        "fb_age_ms": ("walk_fb_age_ms", "cpm_fb_age_ms", "measure_fb_age_ms"),
    }
    _robot_motor_common_fields = {
        str(f)
        for fields in self._rec_robot_motor_common_map.values()
        for f in fields
    }

    # Robot columns (AKR / RR telemetry)
    def _build_robot_group(
        title: str,
        prefixes: tuple[str, ...],
        *,
        exclude_fields: set[str] | None = None,
    ) -> tuple[QtWidgets.QGroupBox, dict[str, QtWidgets.QCheckBox], QtWidgets.QToolButton, QtWidgets.QToolButton]:
        grp = QtWidgets.QGroupBox(title)
        wrap = QtWidgets.QVBoxLayout(grp)
        wrap.setContentsMargins(8, 8, 8, 8)
        wrap.setSpacing(8)

        btns = QtWidgets.QHBoxLayout()
        btns.setContentsMargins(0, 0, 0, 0)
        btns.setSpacing(6)
        btn_all = QtWidgets.QToolButton()
        btn_all.setText("Select All")
        btn_none = QtWidgets.QToolButton()
        btn_none.setText("Select None")
        btns.addWidget(btn_all)
        btns.addWidget(btn_none)
        btns.addStretch(1)
        wrap.addLayout(btns)

        grid = QtWidgets.QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)
        wrap.addLayout(grid)

        items: dict[str, QtWidgets.QCheckBox] = {}
        excluded = set(exclude_fields or ())
        fields = [f for f in self._rec_robot_fields_all if str(f).startswith(prefixes) and str(f) not in excluded]
        for i, f in enumerate(fields):
            cb = QtWidgets.QCheckBox(f)
            cb.setChecked(f in self._rec_robot_fields_selected)
            items[f] = cb
            grid.addWidget(cb, i // 2, i % 2)
        return grp, items, btn_all, btn_none

    grp_robot_walk_cols, self._rec_robot_walk_chk, btn_robot_walk_all, btn_robot_walk_none = _build_robot_group(
        "Robot Walk columns (20 ms)",
        ("walk_",),
        exclude_fields=_robot_motor_common_fields,
    )
    grp_robot_cpm_cols, self._rec_robot_cpm_chk, btn_robot_cpm_all, btn_robot_cpm_none = _build_robot_group(
        "Robot CPM columns (20 ms)",
        ("cpm_",),
        exclude_fields=_robot_motor_common_fields,
    )
    grp_robot_measure_cols, self._rec_robot_measure_chk, btn_robot_measure_all, btn_robot_measure_none = _build_robot_group(
        "Robot Measure columns (20 ms)",
        ("measure_",),
        exclude_fields=_robot_motor_common_fields,
    )

    # Backing checkboxes for common motor fields.
    # These fields are controlled via the virtual "Robot Motor common" group
    # and intentionally hidden from per-mode groups to avoid duplicate UI rows.
    self._rec_robot_motor_common_backing_chk: dict[str, QtWidgets.QCheckBox] = {}
    for f in sorted(_robot_motor_common_fields):
        cb = QtWidgets.QCheckBox(str(f), self.settings_page)
        cb.setVisible(False)
        cb.setChecked(str(f) in self._rec_robot_fields_selected)
        self._rec_robot_motor_common_backing_chk[str(f)] = cb

    grp_robot_motor_common_cols = QtWidgets.QGroupBox("Robot Motor common columns (20 ms)")
    gmc_wrap = QtWidgets.QVBoxLayout(grp_robot_motor_common_cols)
    gmc_wrap.setContentsMargins(8, 8, 8, 8)
    gmc_wrap.setSpacing(8)
    gmc_btns = QtWidgets.QHBoxLayout()
    gmc_btns.setContentsMargins(0, 0, 0, 0)
    gmc_btns.setSpacing(6)
    btn_robot_motor_common_all = QtWidgets.QToolButton()
    btn_robot_motor_common_all.setText("Select All")
    btn_robot_motor_common_none = QtWidgets.QToolButton()
    btn_robot_motor_common_none.setText("Select None")
    gmc_btns.addWidget(btn_robot_motor_common_all)
    gmc_btns.addWidget(btn_robot_motor_common_none)
    gmc_btns.addStretch(1)
    gmc_wrap.addLayout(gmc_btns)
    gmc_grid = QtWidgets.QGridLayout()
    gmc_grid.setContentsMargins(0, 0, 0, 0)
    gmc_grid.setHorizontalSpacing(10)
    gmc_grid.setVerticalSpacing(6)
    gmc_wrap.addLayout(gmc_grid)

    self._rec_robot_motor_common_chk: dict[str, QtWidgets.QCheckBox] = {}
    for i, key in enumerate(self._rec_robot_motor_common_map.keys()):
        cb = QtWidgets.QCheckBox(str(key))
        cb.setTristate(True)
        cb.setToolTip("Controls Walk + CPM + Measure for this field")
        self._rec_robot_motor_common_chk[str(key)] = cb
        gmc_grid.addWidget(cb, i // 2, i % 2)

    # Backward-compatible aggregate used by profile/load/reset logic.
    self._rec_robot_chk: dict[str, QtWidgets.QCheckBox] = {}
    self._rec_robot_chk.update(self._rec_robot_walk_chk)
    self._rec_robot_chk.update(self._rec_robot_cpm_chk)
    self._rec_robot_chk.update(self._rec_robot_measure_chk)
    self._rec_robot_chk.update(self._rec_robot_motor_common_backing_chk)

    self._rec_robot_common_syncing = False

    def _sync_rec_columns(*_args) -> None:
        self._rec_emg_fields_selected = {k for k, cb in self._rec_emg_chk.items() if cb.isChecked()}
        self._rec_imu_fields_selected = {k for k, cb in self._rec_imu_chk.items() if cb.isChecked()}
        self._rec_robot_fields_selected = {k for k, cb in getattr(self, "_rec_robot_chk", {}).items() if cb.isChecked()}

    def _refresh_robot_common_checks() -> None:
        if bool(getattr(self, "_rec_robot_common_syncing", False)):
            return
        self._rec_robot_common_syncing = True
        try:
            for key, fields in getattr(self, "_rec_robot_motor_common_map", {}).items():
                cb = getattr(self, "_rec_robot_motor_common_chk", {}).get(key)
                if cb is None:
                    continue
                vals = [bool(getattr(self, "_rec_robot_chk", {}).get(f).isChecked()) for f in fields if getattr(self, "_rec_robot_chk", {}).get(f) is not None]
                if not vals:
                    state = QtCore.Qt.CheckState.Unchecked
                elif all(vals):
                    state = QtCore.Qt.CheckState.Checked
                elif any(vals):
                    state = QtCore.Qt.CheckState.PartiallyChecked
                else:
                    state = QtCore.Qt.CheckState.Unchecked
                cb.blockSignals(True)
                try:
                    cb.setCheckState(state)
                finally:
                    cb.blockSignals(False)
        finally:
            self._rec_robot_common_syncing = False

    def _apply_robot_common_check(key: str, state_int: int) -> None:
        if bool(getattr(self, "_rec_robot_common_syncing", False)):
            return
        fields = getattr(self, "_rec_robot_motor_common_map", {}).get(str(key), ())
        if not fields:
            return
        state = QtCore.Qt.CheckState(state_int)
        target = (state == QtCore.Qt.CheckState.Checked) or (state == QtCore.Qt.CheckState.PartiallyChecked)
        self._rec_robot_common_syncing = True
        try:
            for f in fields:
                cb = getattr(self, "_rec_robot_chk", {}).get(str(f))
                if cb is None:
                    continue
                cb.blockSignals(True)
                try:
                    cb.setChecked(bool(target))
                finally:
                    cb.blockSignals(False)
        finally:
            self._rec_robot_common_syncing = False
        _sync_rec_columns()
        _refresh_robot_common_checks()

    def _set_robot_common_group_checked(checked: bool) -> None:
        state = (QtCore.Qt.CheckState.Checked if checked else QtCore.Qt.CheckState.Unchecked).value
        for k in getattr(self, "_rec_robot_motor_common_chk", {}).keys():
            _apply_robot_common_check(str(k), state)

    # Expose helper so profile load/reset code can refresh this virtual group.
    self._refresh_robot_common_checks = _refresh_robot_common_checks

    for cb in list(self._rec_emg_chk.values()) + list(self._rec_imu_chk.values()) + list(getattr(self, "_rec_robot_chk", {}).values()):
        cb.toggled.connect(_sync_rec_columns)
    for cb in list(getattr(self, "_rec_robot_chk", {}).values()):
        cb.toggled.connect(_refresh_robot_common_checks)
    for key, cb in getattr(self, "_rec_robot_motor_common_chk", {}).items():
        cb.stateChanged.connect(lambda state, k=key: _apply_robot_common_check(k, state))

    def _set_group_checked(items: dict[str, QtWidgets.QCheckBox], checked: bool) -> None:
        for cb in items.values():
            cb.blockSignals(True)
            try:
                cb.setChecked(bool(checked))
            finally:
                cb.blockSignals(False)
        _sync_rec_columns()

    btn_emg_all.clicked.connect(lambda: _set_group_checked(self._rec_emg_chk, True))
    btn_emg_none.clicked.connect(lambda: _set_group_checked(self._rec_emg_chk, False))
    btn_imu_all.clicked.connect(lambda: _set_group_checked(self._rec_imu_chk, True))
    btn_imu_none.clicked.connect(lambda: _set_group_checked(self._rec_imu_chk, False))
    btn_robot_walk_all.clicked.connect(lambda: _set_group_checked(self._rec_robot_walk_chk, True))
    btn_robot_walk_none.clicked.connect(lambda: _set_group_checked(self._rec_robot_walk_chk, False))
    btn_robot_cpm_all.clicked.connect(lambda: _set_group_checked(self._rec_robot_cpm_chk, True))
    btn_robot_cpm_none.clicked.connect(lambda: _set_group_checked(self._rec_robot_cpm_chk, False))
    btn_robot_measure_all.clicked.connect(lambda: _set_group_checked(self._rec_robot_measure_chk, True))
    btn_robot_measure_none.clicked.connect(lambda: _set_group_checked(self._rec_robot_measure_chk, False))
    btn_robot_motor_common_all.clicked.connect(lambda: _set_robot_common_group_checked(True))
    btn_robot_motor_common_none.clicked.connect(lambda: _set_robot_common_group_checked(False))

    cols_l.addWidget(grp_emg_cols)
    cols_l.addWidget(grp_imu_cols)
    cols_l.addWidget(grp_robot_motor_common_cols)
    cols_l.addWidget(grp_robot_walk_cols)
    cols_l.addWidget(grp_robot_cpm_cols)
    cols_l.addWidget(grp_robot_measure_cols)
    cols_l.addStretch(1)
    _refresh_robot_common_checks()
    rec_layout.addWidget(cols_scroll, 1)

    # Controls at top, info at bottom. Recording panel sits to the right.
    top_row = QtWidgets.QHBoxLayout()
    top_row.setContentsMargins(0, 0, 0, 0)
    top_row.setSpacing(12)
    top_row.addWidget(grp_processed, 2)
    top_row.addWidget(grp_recording, 1)
    settings_layout.addWidget(grp_profile)
    settings_layout.addLayout(top_row)
    settings_layout.addStretch(1)
    self.tabs.addTab(self.settings_page, "Settings")

