from __future__ import annotations

from PyQt6 import QtCore, QtWidgets

from ..models import DeviceTableModel
from ..widgets import BatteryDelegate, LogView


def build_connect_tab(self) -> None:
    """Build the Connect tab UI onto an existing `MainWindow` instance."""
    # --- Connect tab ---
    self.connect_page = QtWidgets.QWidget()
    connect_layout = QtWidgets.QVBoxLayout(self.connect_page)
    connect_layout.setContentsMargins(12, 12, 12, 12)
    connect_layout.setSpacing(10)

    # Controls belong to the Connect tab (contextual to the device table).
    self.connect_toolbar = QtWidgets.QToolBar("Connect controls")
    self.connect_toolbar.setMovable(False)
    self.connect_toolbar.setFloatable(False)
    self.connect_toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
    self.connect_toolbar.addAction(self.action_scan)
    self.connect_toolbar.addAction(self.action_select_all)
    self.connect_toolbar.addAction(self.action_select_none)
    self.connect_toolbar.addSeparator()
    self.connect_toolbar.addAction(self.action_connect)
    self.connect_toolbar.addAction(self.action_disconnect)
    self.connect_toolbar.addSeparator()
    self.connect_toolbar.addAction(self.action_update)
    self.connect_toolbar.addAction(self.action_time_sync)
    self.connect_toolbar.addAction(self.action_settings)
    self.connect_toolbar.addAction(self.action_bulk_modes)
    connect_layout.addWidget(self.connect_toolbar)

    self.device_model = DeviceTableModel(self.controller)
    self.device_proxy = QtCore.QSortFilterProxyModel(self)
    self.device_proxy.setSourceModel(self.device_model)
    self.device_proxy.setSortCaseSensitivity(QtCore.Qt.CaseSensitivity.CaseInsensitive)

    self.table = QtWidgets.QTableView()
    self.table.setModel(self.device_proxy)
    self.table.setSortingEnabled(True)
    self.table.sortByColumn(0, QtCore.Qt.SortOrder.AscendingOrder)
    self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
    self.table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
    self.table.setAlternatingRowColors(True)
    header = self.table.horizontalHeader()
    # We control column widths explicitly; don't auto-stretch the last column (ConnInt).
    header.setStretchLastSection(False)
    header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
    # Name: fixed width (stable), Address: stretch with a reasonable minimum for UUIDs.
    name_col = 0
    header.setSectionResizeMode(name_col, QtWidgets.QHeaderView.ResizeMode.Fixed)
    self.table.setColumnWidth(name_col, 100)

    addr_col = 1
    header.setSectionResizeMode(addr_col, QtWidgets.QHeaderView.ResizeMode.Stretch)
    # Default/minimum visible width; Address will stretch on wider windows.
    self.table.setColumnWidth(addr_col, 360)
    self.table.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.CustomContextMenu)
    # Battery column: paint a gauge.
    battery_col = 3
    self.table.setItemDelegateForColumn(battery_col, BatteryDelegate())
    # Delegate draws a bar + "% ⚡" suffix; give it a stable width so the bolt isn't clipped
    # by ResizeToContents (which only considers the model's DisplayRole text).
    header.setSectionResizeMode(battery_col, QtWidgets.QHeaderView.ResizeMode.Fixed)
    self.table.setColumnWidth(battery_col, 140)

    # Make the “metadata” columns tidy: Firmware..ConnInt same width.
    # Column indices from DeviceTableModel.COLUMNS:
    # 7 Firmware, 8 Hardware, 9 DSP, 10 ConnInt
    meta_cols = [7, 8, 9, 10]
    meta_w = 75
    for c in meta_cols:
        header.setSectionResizeMode(c, QtWidgets.QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(c, meta_w)

    # Sensors column: fixed, stable width (avoid resizing when modes change).
    sensors_col = 6
    header.setSectionResizeMode(sensors_col, QtWidgets.QHeaderView.ResizeMode.Fixed)
    self.table.setColumnWidth(sensors_col, 220)

    self.log_view = LogView()

    connect_layout.addWidget(self.table, 3)
    connect_layout.addWidget(self.log_view, 2)
    self.tabs.addTab(self.connect_page, "Connect")

