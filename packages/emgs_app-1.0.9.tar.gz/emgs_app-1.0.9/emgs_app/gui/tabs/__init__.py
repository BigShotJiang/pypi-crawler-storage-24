"""UI tab builders for `MainWindow`.

This package holds the UI construction for each top-level tab (Connect, Signals,
Scenario, Settings). The goal is to keep `main_window.py` readable by moving
large UI-building blocks into per-tab modules.
"""

