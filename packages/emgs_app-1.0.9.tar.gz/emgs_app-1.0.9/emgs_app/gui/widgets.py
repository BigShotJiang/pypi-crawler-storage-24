from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
import pyqtgraph as pg
from PyQt6 import QtCore, QtGui, QtWidgets

from ..ble.device import EmgsDevice
from ..controller import EmgsController


class LogView(QtWidgets.QPlainTextEdit):
    def __init__(self) -> None:
        super().__init__()
        self.setReadOnly(True)
        self.setMaximumBlockCount(2000)

    @QtCore.pyqtSlot(str)
    def append_line(self, msg: str) -> None:
        self.appendPlainText(msg)
        self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())


class DevicePlotTile(QtWidgets.QWidget):
    """A small, scalable tile showing a single device EMG preview + a quality hint."""

    def __init__(self, device: EmgsDevice, time_origin_s_provider: Optional[Callable[[], Optional[float]]] = None) -> None:
        super().__init__()
        self.device = device
        self._time_origin_s_provider = time_origin_s_provider
        self._fps_last_ts = time.monotonic()
        self._fps_last_emg_total = device.emg_frames_total

        self.title = QtWidgets.QLabel()
        self.subtitle = QtWidgets.QLabel()
        self.subtitle.setStyleSheet("color: #9fb2e8;")

        pg.setConfigOptions(antialias=True)
        self.plot = pg.PlotWidget()
        self.plot.setBackground("#070b16")
        self.plot.showGrid(x=True, y=True, alpha=0.15)
        self.plot.setMenuEnabled(False)
        self.plot.setMouseEnabled(x=False, y=False)
        self.plot.hideButtons()
        self.curve = self.plot.plot(pen=pg.mkPen("#4ea1ff", width=2))

        header = QtWidgets.QVBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(2)
        header.addWidget(self.title)
        header.addWidget(self.subtitle)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        layout.addLayout(header)
        layout.addWidget(self.plot, 1)

        self.setMinimumHeight(180)
        self._update_title()

    def _update_title(self) -> None:
        p = self.device.params
        self.title.setText(f"{p.name}   [{p.status}]")

    def refresh(self) -> None:
        self._update_title()

        # Use EMG channel 0 as preview
        if not self.device.emg_buffer:
            age_txt = ""
            if self.device.last_emg_time_s is not None:
                age = time.monotonic() - self.device.last_emg_time_s
                age_txt = f" • last {age:0.1f}s ago"
            self.subtitle.setText(f"No EMG frames yet{age_txt}")
            self.curve.setData([], [])
            return

        # Performance: only walk the most recent window instead of converting the entire ring buffer.
        t_end = float(self.device.emg_buffer[-1][0])
        t_min = t_end - 2.0
        pts: list[tuple[float, float]] = []
        for ts, samples in reversed(self.device.emg_buffer):
            if ts < t_min:
                break
            if samples:
                pts.append((float(ts), float(samples[0])))
        pts.reverse()
        if not pts:
            self.subtitle.setText("No EMG frames yet")
            self.curve.setData([], [])
            return
        t = np.fromiter((p[0] for p in pts), dtype=float, count=len(pts))
        y = np.fromiter((p[1] for p in pts), dtype=float, count=len(pts))

        if t.size == 0:
            self.subtitle.setText("No EMG frames yet")
            self.curve.setData([], [])
            return

        # Use a global origin (shared across devices) so x-axis is comparable.
        origin = self._time_origin_s_provider() if self._time_origin_s_provider else None
        if origin is not None:
            t = t - origin
        self.curve.setData(t, y)

        # Simple quality heuristic: recent RMS magnitude
        recent = y[-min(len(y), 200):]
        rms = float(math.sqrt(float(np.mean(recent * recent)))) if recent.size else 0.0

        # Rough EMG FPS (host-side) based on total frame counter
        now = time.monotonic()
        dt = max(1e-3, now - self._fps_last_ts)
        dframes = self.device.emg_frames_total - self._fps_last_emg_total
        fps = dframes / dt
        # Update tracker ~2 Hz to reduce jitter
        if dt >= 0.5:
            self._fps_last_ts = now
            self._fps_last_emg_total = self.device.emg_frames_total

        age_txt = ""
        if self.device.last_emg_time_s is not None:
            age = now - self.device.last_emg_time_s
            age_txt = f" • last {age:0.1f}s ago"

        if self.device.is_streaming:
            qual = "OK" if rms > 50 else "LOW"
            diag = ""
            if self.device.emg_missing_samples_est:
                diag += f" • miss≈{self.device.emg_missing_samples_est}"
            if self.device.imu_anomaly_count:
                diag += f" • imuAnom={self.device.imu_anomaly_count}"
            self.subtitle.setText(f"Streaming • ~{fps:0.0f} fps{age_txt}{diag} • EMG ch0 RMS≈{rms:0.0f} • {qual}")
        else:
            self.subtitle.setText(f"Connected • {age_txt.strip(' •')} • EMG ch0 RMS≈{rms:0.0f} (start stream to verify)")


class SignalPlotTile(QtWidgets.QWidget):
    """A configurable plot tile (device + signal + axis), removable by the user."""

    remove_requested = QtCore.pyqtSignal(object)  # self

    def __init__(
        self,
        *,
        title: str,
        data_provider: Callable[[], tuple[np.ndarray, np.ndarray] | None],
        time_origin_s_provider: Optional[Callable[[], Optional[float]]] = None,
        parent: QtWidgets.QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._title_txt = title
        self._data_provider = data_provider
        self._time_origin_s_provider = time_origin_s_provider

        self.title = QtWidgets.QLabel(self._title_txt)
        self.title.setStyleSheet("font-weight: 600;")
        self.btn_remove = QtWidgets.QToolButton()
        self.btn_remove.setText("✕")
        self.btn_remove.setToolTip("Remove chart")
        self.btn_remove.clicked.connect(lambda: self.remove_requested.emit(self))

        header = QtWidgets.QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.addWidget(self.title, 1)
        header.addWidget(self.btn_remove, 0)

        pg.setConfigOptions(antialias=True)
        self.plot = pg.PlotWidget()
        self.plot.setBackground("#070b16")
        self.plot.showGrid(x=True, y=True, alpha=0.15)
        self.plot.setMenuEnabled(False)
        self.plot.setMouseEnabled(x=False, y=False)
        self.plot.hideButtons()
        self.curve = self.plot.plot(pen=pg.mkPen("#4ea1ff", width=2))

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        layout.addLayout(header)
        layout.addWidget(self.plot, 1)
        self.setMinimumHeight(180)

    def refresh(self) -> None:
        xy = self._data_provider()
        if not xy:
            self.curve.setData([], [])
            return
        t, y = xy
        origin = self._time_origin_s_provider() if self._time_origin_s_provider else None
        if origin is not None and t.size:
            t = t - float(origin)
        self.curve.setData(t, y)


class XYTrajectoryPlot(QtWidgets.QWidget):
    """Simple 2D XY trajectory plot (e.g., IMU relative position X vs Y)."""

    def __init__(self, *, title: str = "Trajectory", parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self._title_txt = str(title)
        self._bounds: tuple[float, float, float, float] | None = None  # (x_min, x_max, y_min, y_max)

        self.title = QtWidgets.QLabel(self._title_txt)
        self.title.setStyleSheet("font-weight: 600;")

        pg.setConfigOptions(antialias=True)
        self.plot = pg.PlotWidget()
        self.plot.setBackground("#070b16")
        self.plot.showGrid(x=True, y=True, alpha=0.15)
        self.plot.setMenuEnabled(False)
        self.plot.hideButtons()
        # 2D interaction is useful here (pan/zoom).
        self.plot.setMouseEnabled(x=True, y=True)
        try:
            # Respect explicit x/y bounds from ScenarioControlTile; don't force a 1:1 aspect.
            self.plot.setAspectLocked(False)
        except Exception:
            pass
        try:
            self.plot.setLabel("bottom", "X", units="m")
            self.plot.setLabel("left", "Y", units="m")
        except Exception:
            pass

        self.curve = self.plot.plot(pen=pg.mkPen("#4ea1ff", width=2))
        # Latest point marker (helps see current cursor position).
        try:
            self._dot = pg.ScatterPlotItem(size=10, brush=pg.mkBrush("#2ed573"), pen=pg.mkPen("#2ed573"))
            self.plot.addItem(self._dot)
        except Exception:
            self._dot = None

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        layout.addWidget(self.title, 0)
        layout.addWidget(self.plot, 1)

        # Scenario page request: don't auto-scale on incoming data.
        # We'll explicitly apply bounds from ScenarioControlTile(s) instead.
        try:
            vb = self.plot.getViewBox()
            try:
                vb.enableAutoRange(axis=pg.ViewBox.XYAxes, enable=False)
            except Exception:
                try:
                    vb.enableAutoRange(axis="xy", enable=False)
                except Exception:
                    vb.enableAutoRange(enable=False)
        except Exception:
            pass

        # Sensible default until tiles provide explicit bounds.
        self.set_bounds(x_min=-1.0, x_max=1.0, y_min=-1.0, y_max=1.0)

    def set_points(self, x: np.ndarray, y: np.ndarray) -> None:
        try:
            self.curve.setData(x, y)
        except Exception:
            self.curve.setData([], [])
        if getattr(self, "_dot", None) is not None:
            try:
                if x.size and y.size:
                    self._dot.setData([{"pos": (float(x[-1]), float(y[-1]))}])
                else:
                    self._dot.setData([])
            except Exception:
                pass
        # Re-apply the configured bounds so pyqtgraph doesn't auto-range on setData().
        if self._bounds is not None:
            self._apply_bounds()

    def clear(self) -> None:
        self.set_points(np.asarray([], dtype=float), np.asarray([], dtype=float))

    def set_bounds(self, *, x_min: float, x_max: float, y_min: float, y_max: float) -> None:
        # Normalize (avoid inverted ranges).
        x0, x1 = float(x_min), float(x_max)
        y0, y1 = float(y_min), float(y_max)
        if x1 < x0:
            x0, x1 = x1, x0
        if y1 < y0:
            y0, y1 = y1, y0
        # Avoid zero-width ranges which can break view transforms.
        if abs(x1 - x0) < 1e-12:
            x1 = x0 + 1e-3
        if abs(y1 - y0) < 1e-12:
            y1 = y0 + 1e-3
        self._bounds = (x0, x1, y0, y1)
        self._apply_bounds()

    def _apply_bounds(self) -> None:
        if self._bounds is None:
            return
        x0, x1, y0, y1 = self._bounds
        try:
            vb = self.plot.getViewBox()
            # Keep the plot locked to explicit bounds (no padding).
            vb.setRange(xRange=(float(x0), float(x1)), yRange=(float(y0), float(y1)), padding=0.0)
        except Exception:
            try:
                self.plot.setRange(xRange=(float(x0), float(x1)), yRange=(float(y0), float(y1)), padding=0.0)
            except Exception:
                pass


class MultiSignalPlot(QtWidgets.QWidget):
    """Single large plot with multiple stacked traces (EEG-style)."""

    @dataclass(slots=True)
    class Trace:
        key: str
        label: str
        group: str
        curve: object
        color: str
        data_provider: Callable[[], tuple[np.ndarray, np.ndarray] | None]
        pen_width: float = 1.5
        pen_style: QtCore.Qt.PenStyle = QtCore.Qt.PenStyle.SolidLine
        show_value_label: bool = False

    @dataclass(slots=True)
    class GroupConfig:
        label: str
        y_min_raw: float
        y_max_raw: float
        scale: float
        offset_raw: float

    def __init__(
        self,
        *,
        time_origin_s_provider: Optional[Callable[[], Optional[float]]] = None,
        parent: QtWidgets.QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._time_origin_s_provider = time_origin_s_provider
        self._traces: list[MultiSignalPlot.Trace] = []
        self._group_cfg: dict[str, MultiSignalPlot.GroupConfig] = {}
        self._group_order: list[str] = []  # explicit lane order (matches tile order)
        self._lane0: dict[str, float] = {}  # group -> displayed lane base offset
        self._lane_gap_factor: float = 1.25  # legacy; replaced by explicit gap in _recompute_layout
        self._zero_lines: dict[str, object] = {}  # group -> pg.InfiniteLine (y=0 for that cluster)
        self._sec_grid_lines: dict[int, object] = {}  # integer second -> pg.InfiniteLine
        self._value_labels: dict[str, object] = {}  # trace_key -> pg.TextItem
        # Per-group x markers that are defined in "relative window seconds" [0..window_s]
        # and shifted to the current view window on each refresh.
        self._group_x_markers: dict[str, list[tuple[float, object]]] = {}  # group -> [(x_rel_s, pg.PlotCurveItem)]
        self._last_refresh_used_points: int = 0
        self._last_refresh_traces_with_data: int = 0

        # Avoid forcing global antialias on; we may toggle antialiasing dynamically for performance.
        # (Other widgets may still enable it globally.)
        self.plot = pg.PlotWidget()
        self.plot.setBackground("#070b16")
        # Grid is a key aid for multi-lane signals.
        self.plot.showGrid(x=True, y=True, alpha=0.22)
        self.plot.setMenuEnabled(False)
        self.plot.setMouseEnabled(x=True, y=False)
        self.plot.hideButtons()
        self.plot.setLabel("bottom", "Time", units="s")
        # Default to non-antialiased rendering for performance with many traces.
        try:
            self.plot.setAntialiasing(False)
        except Exception:
            pass
        # Prefer 1.0s major ticks for readability (also helps the grid).
        try:
            ax = self.plot.getAxis("bottom")
            ax.setTickSpacing(1.0, 0.2)
        except Exception:
            pass
        # We manage ranges ourselves for a smooth rolling display.
        try:
            self.plot.enableAutoRange(x=False, y=False)
        except Exception:
            pass

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.plot, 1)

    def clear(self) -> None:
        # Remove curves and per-group helpers (zero lines)
        for tr in self._traces:
            try:
                self.plot.removeItem(tr.curve)
            except Exception:
                pass
        for ln in self._zero_lines.values():
            try:
                self.plot.removeItem(ln)
            except Exception:
                pass
        for ln in self._sec_grid_lines.values():
            try:
                self.plot.removeItem(ln)
            except Exception:
                pass
        for it in self._value_labels.values():
            try:
                self.plot.removeItem(it)
            except Exception:
                pass
        for items in self._group_x_markers.values():
            for _x, it in items:
                try:
                    self.plot.removeItem(it)
                except Exception:
                    pass
        self._traces.clear()
        self._group_cfg.clear()
        self._group_order.clear()
        self._lane0.clear()
        self._zero_lines.clear()
        self._sec_grid_lines.clear()
        self._value_labels.clear()
        self._group_x_markers.clear()
        try:
            self.plot.getAxis("left").setTicks([])
        except Exception:
            pass

    def list_groups(self) -> list[str]:
        # Explicit lane order (kept stable even if traces are added later).
        return [g for g in self._group_order if g in self._group_cfg]

    def move_group(self, group: str, delta: int) -> None:
        """Move a group's lane order up/down (delta -1/+1)."""
        if group not in self._group_order or delta == 0:
            return
        i = self._group_order.index(group)
        j = i + int(delta)
        if j < 0 or j >= len(self._group_order):
            return
        self._group_order[i], self._group_order[j] = self._group_order[j], self._group_order[i]
        self._recompute_layout()

    def trace_count(self) -> int:
        return int(len(self._traces))

    def set_fast_rendering(self, enabled: bool) -> None:
        """Best-effort toggle for expensive rendering options."""
        try:
            # In pyqtgraph, GraphicsView has setAntialiasing().
            self.plot.setAntialiasing(not bool(enabled))
        except Exception:
            pass

    def set_group_x_markers(self, group: str, xs: list[float]) -> None:
        """Add/update per-group (lane-local) vertical marker line segments.

        xs are expressed in *relative seconds within the visible window* (e.g. 0..3 for a 3s view).
        Markers are shifted to the current rolling x-window during refresh().
        """
        # Remove existing markers
        old = self._group_x_markers.pop(group, None)
        if old:
            for _x, it in old:
                try:
                    self.plot.removeItem(it)
                except Exception:
                    pass
        items: list[tuple[float, object]] = []
        for x in xs:
            try:
                it = pg.PlotCurveItem(pen=pg.mkPen("#7f8c8d", width=1, style=QtCore.Qt.PenStyle.DashLine))
                self.plot.addItem(it)
                items.append((float(x), it))
            except Exception:
                pass
        if items:
            self._group_x_markers[group] = items

    def last_refresh_stats(self) -> tuple[int, int]:
        """Return (used_points_total, traces_with_data) from the last refresh()."""
        return int(self._last_refresh_used_points), int(self._last_refresh_traces_with_data)

    def _update_second_grid(self, x0: float, x1: float) -> None:
        """Draw stronger vertical grid lines at integer seconds within [x0, x1]."""
        try:
            import math as _math
            lo = int(_math.floor(float(x0)))
            hi = int(_math.ceil(float(x1)))
        except Exception:
            return
        desired = set(range(lo, hi + 1))
        # Remove old lines
        for s in list(self._sec_grid_lines.keys()):
            if s in desired:
                continue
            ln = self._sec_grid_lines.pop(s, None)
            if ln is not None:
                try:
                    self.plot.removeItem(ln)
                except Exception:
                    pass
        # Add/update desired lines
        for s in sorted(desired):
            if s in self._sec_grid_lines:
                try:
                    self._sec_grid_lines[s].setPos(float(s))
                except Exception:
                    pass
                continue
            try:
                ln = pg.InfiniteLine(
                    pos=float(s),
                    angle=90,
                    movable=False,
                    pen=pg.mkPen("#22306b", width=1.6),
                )
                self.plot.addItem(ln)
                self._sec_grid_lines[s] = ln
            except Exception:
                pass

    @staticmethod
    def _fmt_value_2sig(v: float) -> str:
        """Format value for overlay labels with meaningful fractional precision.

        Keep a compact representation while avoiding integer-looking labels for
        float telemetry (e.g. vbus/temp).
        """
        try:
            x = float(v)
        except Exception:
            return "?"
        if not math.isfinite(x):
            return "?"
        if x == 0.0:
            return "0.0"

        ax = abs(x)
        # Scientific notation for extreme magnitudes to keep labels compact.
        if ax < 1e-3 or ax >= 1e4:
            return f"{x:.3e}"

        # 4 significant digits preserves useful decimals for common telemetry values.
        s = f"{x:.4g}"
        if "e" not in s and "." not in s:
            # Preserve float intent: show at least one decimal place.
            s = f"{s}.0"
        return s

    def group_label(self, group: str) -> str:
        cfg = self._group_cfg.get(group)
        if cfg:
            return cfg.label
        for t in self._traces:
            if t.group == group:
                return t.label
        return group

    def group_colors(self, group: str) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for t in self._traces:
            if t.group != group:
                continue
            if t.color not in seen:
                seen.add(t.color)
                out.append(t.color)
        return out

    def traces_in_group(self, group: str) -> list[Trace]:
        return [t for t in self._traces if t.group == group]

    def remove_group_by_index(self, idx: int) -> None:
        groups = self.list_groups()
        if idx < 0 or idx >= len(groups):
            return
        self.remove_group(groups[idx])

    def remove_group(self, group: str) -> None:
        keep: list[MultiSignalPlot.Trace] = []
        for tr in self._traces:
            if tr.group == group:
                try:
                    self.plot.removeItem(tr.curve)
                except Exception:
                    pass
                it = self._value_labels.pop(tr.key, None)
                if it is not None:
                    try:
                        self.plot.removeItem(it)
                    except Exception:
                        pass
            else:
                keep.append(tr)
        self._traces = keep
        self._group_cfg.pop(group, None)
        if group in self._group_order:
            try:
                self._group_order.remove(group)
            except ValueError:
                pass
        self._lane0.pop(group, None)
        ln = self._zero_lines.pop(group, None)
        if ln is not None:
            try:
                self.plot.removeItem(ln)
            except Exception:
                pass
        items = self._group_x_markers.pop(group, None)
        if items:
            for _x, it in items:
                try:
                    self.plot.removeItem(it)
                except Exception:
                    pass
        self._recompute_layout()

    def add_trace(
        self,
        *,
        key: str,
        label: str,
        group: str,
        color: str,
        y_min: float,
        y_max: float,
        data_provider: Callable[[], tuple[np.ndarray, np.ndarray] | None],
        scale: float = 1.0,
        pen_width: float = 1.5,
        pen_style: QtCore.Qt.PenStyle = QtCore.Qt.PenStyle.SolidLine,
        show_value_label: bool = False,
    ) -> None:
        # If same key already exists, ignore to prevent duplicates.
        if any(t.key == key for t in self._traces):
            return
        # Initialize per-group config once (per plan: controls are per group).
        if group not in self._group_cfg:
            self._group_cfg[group] = MultiSignalPlot.GroupConfig(
                label=str(label),
                y_min_raw=float(y_min),
                y_max_raw=float(y_max),
                scale=float(scale),
                offset_raw=0.0,
            )
            if group not in self._group_order:
                self._group_order.append(group)
            # Grey horizontal line showing the cluster's zero level.
            try:
                ln = pg.InfiniteLine(
                    angle=0,
                    movable=False,
                    pen=pg.mkPen("#7f8c8d", width=1, style=QtCore.Qt.PenStyle.DashLine),
                )
                self.plot.addItem(ln)
                self._zero_lines[group] = ln
            except Exception:
                pass
        curve = self.plot.plot(pen=pg.mkPen(color, width=float(pen_width), style=pen_style))
        # Performance helpers (best-effort; depends on pyqtgraph version)
        try:
            curve.setClipToView(True)
        except Exception:
            pass
        try:
            curve.setDownsampling(auto=True, method="peak")
        except Exception:
            pass
        tr = MultiSignalPlot.Trace(
            key=key,
            label=label,
            group=group,
            curve=curve,
            color=color,
            data_provider=data_provider,
            pen_width=float(pen_width),
            pen_style=pen_style,
            show_value_label=bool(show_value_label),
        )
        self._traces.append(tr)
        self._recompute_layout()

    def get_group_config(self, group: str) -> GroupConfig | None:
        return self._group_cfg.get(group)

    def set_group_config(
        self,
        group: str,
        *,
        y_min: float | None = None,
        y_max: float | None = None,
        scale: float | None = None,
        offset: float | None = None,
        label: str | None = None,
    ) -> None:
        cfg = self._group_cfg.get(group)
        if not cfg:
            return
        if label is not None:
            cfg.label = str(label)
        if y_min is not None:
            cfg.y_min_raw = float(y_min)
        if y_max is not None:
            cfg.y_max_raw = float(y_max)
        if scale is not None:
            cfg.scale = float(scale)
        if offset is not None:
            cfg.offset_raw = float(offset)
        self._recompute_layout()

    def set_trace_color(self, trace_key: str, color: str) -> None:
        for tr in self._traces:
            if tr.key != trace_key:
                continue
            tr.color = str(color)
            try:
                tr.curve.setPen(pg.mkPen(tr.color, width=float(tr.pen_width), style=tr.pen_style))
            except Exception:
                pass
            break

    def _recompute_layout(self) -> None:
        # Stack by group; traces in the same group share a lane. Y-limits (lane ranges)
        # must never overlap. We add a constant gap (same gap between every adjacent lane).
        groups = self.list_groups()
        self._lane0.clear()
        spans: list[float] = []
        for g in groups:
            cfg = self._group_cfg.get(g)
            if not cfg:
                continue
            span_raw = float(cfg.y_max_raw - cfg.y_min_raw)
            spans.append(max(1e-9, abs(span_raw) * float(cfg.scale)))
        # Constant spacing between lanes: choose a stable value based on current lanes.
        span_ref = float(np.median(np.array(spans))) if spans else 1.0
        gap_disp = max(1e-9, span_ref * 0.20)

        # IMPORTANT: Match tile order visually: first group should be the TOP lane.
        # In pyqtgraph, larger y-values appear higher. So we place the first lane at the
        # highest y-range and stack subsequent lanes downward.
        span_disp_by_group: dict[str, float] = {}
        for g in groups:
            cfg = self._group_cfg.get(g)
            if not cfg:
                continue
            span_disp_by_group[g] = max(1e-9, abs(float(cfg.y_max_raw - cfg.y_min_raw)) * float(cfg.scale))

        total_height = float(sum(span_disp_by_group.get(g, 0.0) for g in groups))
        if len(groups) >= 2:
            total_height += float(gap_disp) * float(len(groups) - 1)

        current_top = total_height
        for g in groups:
            cfg = self._group_cfg.get(g)
            if not cfg:
                continue
            span_disp = float(span_disp_by_group.get(g, 1.0))
            lane_low = current_top - span_disp
            # Define lane base so that the lane's configured low bound (after Offset+Scale)
            # maps to lane_low. This ensures lane y-limits never overlap even when Offset shifts.
            y_lo_disp = min(
                (float(cfg.y_min_raw) - float(cfg.offset_raw)) * float(cfg.scale),
                (float(cfg.y_max_raw) - float(cfg.offset_raw)) * float(cfg.scale),
            )
            self._lane0[g] = float(lane_low) - float(y_lo_disp)
            current_top = float(lane_low) - float(gap_disp)

        # Set y-range to show all stacked lanes (based on displayed positions).
        if groups:
            lo: float | None = None
            hi: float | None = None
            major: list[tuple[float, str]] = []
            minor: list[tuple[float, str]] = []

            def _nice_step(span: float) -> float:
                """Choose a 'nice' step (1/2/5 * 10^n) for tick labels."""
                span = abs(float(span))
                if span <= 0 or not math.isfinite(span):
                    return 1.0
                target = span / 4.0  # aim ~4 intervals
                if target <= 0:
                    return 1.0
                p10 = 10 ** math.floor(math.log10(target))
                for m in (1.0, 2.0, 5.0, 10.0):
                    step = m * p10
                    if target <= step:
                        return float(step)
                return float(10.0 * p10)

            for g in groups:
                cfg = self._group_cfg.get(g)
                if not cfg:
                    continue
                base = float(self._lane0.get(g, 0.0))
                # Lane boundaries are defined by configured y-limits after applying Offset+Scale.
                y0 = (float(cfg.y_min_raw) - float(cfg.offset_raw)) * float(cfg.scale) + base
                y1 = (float(cfg.y_max_raw) - float(cfg.offset_raw)) * float(cfg.scale) + base
                g_lo = min(y0, y1)
                g_hi = max(y0, y1)
                lo = g_lo if lo is None else min(lo, g_lo)
                hi = g_hi if hi is None else max(hi, g_hi)
                # Major ticks: add multiple labeled ticks in raw units (better readability).
                # Positions are transformed by (raw - offset)*scale + lane0.
                raw_lo = float(cfg.y_min_raw)
                raw_hi = float(cfg.y_max_raw)
                raw_min = min(raw_lo, raw_hi)
                raw_max = max(raw_lo, raw_hi)

                # Always include endpoints.
                major.append((float(y0), f"{raw_lo:g}"))
                if float(y1) != float(y0):
                    major.append((float(y1), f"{raw_hi:g}"))

                # Add internal ticks at a nice step.
                step = _nice_step(raw_max - raw_min)
                # Cap label count per lane to avoid clutter; increase step if needed.
                def _count_ticks(step_val: float) -> int:
                    if step_val <= 0:
                        return 0
                    a = math.ceil(raw_min / step_val) * step_val
                    b = math.floor(raw_max / step_val) * step_val
                    if b < a:
                        return 0
                    return int(round((b - a) / step_val)) + 1

                while _count_ticks(step) > 7:
                    step *= 2.0

                if step > 0:
                    v = math.ceil(raw_min / step) * step
                    # Use a set to avoid duplicate labels at endpoints due to rounding.
                    seen_raw: set[int] = set()
                    # Seed with endpoints (rounded to micro for stability).
                    seen_raw.add(int(round(raw_lo * 1e6)))
                    seen_raw.add(int(round(raw_hi * 1e6)))
                    while v <= raw_max + (step * 0.5):
                        key = int(round(v * 1e6))
                        if key not in seen_raw:
                            yv = (float(v) - float(cfg.offset_raw)) * float(cfg.scale) + base
                            major.append((float(yv), f"{float(v):g}"))
                            seen_raw.add(key)
                        v += step

                # Ensure zero is labeled if inside the raw range.
                if raw_min < 0.0 < raw_max:
                    y_zero = (0.0 - float(cfg.offset_raw)) * float(cfg.scale) + base
                    major.append((float(y_zero), "0"))

                # Minor ticks: 25/50/75% (unlabeled) for easier reading + grid lines.
                for frac in (0.25, 0.50, 0.75):
                    ym = float(y0) + (float(y1) - float(y0)) * frac
                    minor.append((float(ym), ""))

                # Update the zero reference line position for this cluster.
                ln = self._zero_lines.get(g)
                if ln is not None:
                    try:
                        # Zero level indicator is raw=0.
                        y_zero = (0.0 - float(cfg.offset_raw)) * float(cfg.scale) + base
                        ln.setPos(float(y_zero))
                    except Exception:
                        pass
            if lo is not None and hi is not None:
                try:
                    self.plot.setYRange(float(lo), float(hi), padding=0.02)
                except Exception:
                    pass
            # Rebuild y-axis ticks only when layout/config changes (this function is called on those events).
            try:
                axis = self.plot.getAxis("left")
                axis.setTicks([major, minor])
            except Exception:
                pass

    def refresh(self, *, max_points: int = 2500, window_s: float = 3.0) -> None:
        origin = self._time_origin_s_provider() if self._time_origin_s_provider else None
        t_end_max: float | None = None
        used_points_total = 0
        traces_with_data = 0
        for tr in self._traces:
            xy = tr.data_provider()
            if not xy:
                tr.curve.setData([], [])
                it = self._value_labels.get(tr.key)
                if it is not None:
                    try:
                        it.setText("")
                    except Exception:
                        pass
                continue
            t, y = xy
            traces_with_data += 1
            y_last_raw = float(y[-1]) if y.size else 0.0
            cfg = self._group_cfg.get(tr.group)
            if cfg:
                # Display transform is per-group: (y_raw - offset_raw)*scale + lane0
                try:
                    y = (y - float(cfg.offset_raw)) * float(cfg.scale)
                except Exception:
                    pass
            if origin is not None and t.size:
                t = t - float(origin)
            if t.size:
                t_end = float(t[-1])
                t_end_max = t_end if t_end_max is None else max(t_end_max, t_end)
            # Stack by group lane base, without clipping.
            y_stack = y + float(self._lane0.get(tr.group, 0.0))
            # Decimate for plotting speed if needed.
            if t.size > max_points:
                step = int(math.ceil(t.size / max_points))
                t = t[::step]
                y_stack = y_stack[::step]
            used_points_total += int(t.size)
            # skipFiniteCheck avoids per-point NaN/Inf checks; our data is controlled.
            try:
                tr.curve.setData(t, y_stack, skipFiniteCheck=True)
            except TypeError:
                tr.curve.setData(t, y_stack)

            # Optional per-trace value label (raw units), anchored at the top-right of the group's y-limits.
            if tr.show_value_label and t.size:
                try:
                    it = self._value_labels.get(tr.key)
                    if it is None:
                        it = pg.TextItem(anchor=(1, 0), color=tr.color)
                        try:
                            fnt = QtGui.QFont()
                            fnt.setPointSize(14)
                            fnt.setBold(True)
                            it.setFont(fnt)
                        except Exception:
                            pass
                        self.plot.addItem(it)
                        self._value_labels[tr.key] = it
                    it.setText(self._fmt_value_2sig(y_last_raw))
                    # Position: right edge of window, top of this lane.
                    x_right = float(t[-1])
                    y_top = float(y_stack[-1])
                    cfg2 = self._group_cfg.get(tr.group)
                    if cfg2 is not None:
                        base = float(self._lane0.get(tr.group, 0.0))
                        y_top = (float(cfg2.y_max_raw) - float(cfg2.offset_raw)) * float(cfg2.scale) + base
                    # Inset so the label isn't clipped by the plot edges.
                    dx, dy = (0.0, 0.0)
                    try:
                        vb = self.plot.getViewBox()
                        dx, dy = vb.viewPixelSize()
                    except Exception:
                        pass
                    inset_px = 8.0
                    x_pos = float(x_right) - float(dx) * inset_px if dx else float(x_right)
                    y_pos = float(y_top) - float(dy) * inset_px if dy else float(y_top)
                    it.setPos(x_pos, y_pos)
                except Exception:
                    pass

        # Keep the x-range tracking the most recent window so curves don't "disappear"
        # when we switch from absolute device timestamps to a shared origin.
        if t_end_max is not None:
            try:
                self.plot.setXRange(t_end_max - float(window_s), t_end_max, padding=0.0)
            except Exception:
                pass
            # Stronger vertical lines at 1.0s spacing.
            self._update_second_grid(float(t_end_max) - float(window_s), float(t_end_max))

        # Update group-local x marker segments (lane-only), shifted into current x window.
        if t_end_max is not None:
            x0 = float(t_end_max) - float(window_s)
            for g, items in self._group_x_markers.items():
                cfgm = self._group_cfg.get(g)
                if not cfgm or not items:
                    continue
                base = float(self._lane0.get(g, 0.0))
                y0 = (float(cfgm.y_min_raw) - float(cfgm.offset_raw)) * float(cfgm.scale) + base
                y1 = (float(cfgm.y_max_raw) - float(cfgm.offset_raw)) * float(cfgm.scale) + base
                for x_rel, it in items:
                    try:
                        x = x0 + float(x_rel)
                        it.setData([float(x), float(x)], [float(y0), float(y1)])
                    except Exception:
                        pass

        self._last_refresh_used_points = int(used_points_total)
        self._last_refresh_traces_with_data = int(traces_with_data)


class SignalGroupControl(QtWidgets.QGroupBox):
    """Right-panel control widget for one plotted signal cluster/group."""

    remove_requested = QtCore.pyqtSignal(str)         # group
    config_changed = QtCore.pyqtSignal(str, float, float, float)  # group, y_min, y_max, scale
    color_changed = QtCore.pyqtSignal(str, str)       # trace_key, color_hex
    move_up_requested = QtCore.pyqtSignal(str)        # group
    move_down_requested = QtCore.pyqtSignal(str)      # group

    def __init__(self, *, group: str, title: str, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self._group = group
        self._trace_btns: dict[str, QtWidgets.QToolButton] = {}  # trace_key -> button
        self._trace_colors: dict[str, str] = {}

        # Compact tile: keep height minimal.
        self.setTitle("")

        self.lbl_title = QtWidgets.QLabel(title)
        self.lbl_title.setStyleSheet("font-weight: 600;")
        self.lbl_title.setWordWrap(True)

        # Top-left menu (replaces old color legend + delete button)
        self.btn_menu = QtWidgets.QToolButton()
        self.btn_menu.setText("⋯")
        self.btn_menu.setToolTip("Cluster actions")
        self.btn_menu.setPopupMode(QtWidgets.QToolButton.ToolButtonPopupMode.InstantPopup)
        self._menu = QtWidgets.QMenu(self)
        self.act_remove = self._menu.addAction("Remove this tile")
        self.act_move_up = self._menu.addAction("Move up")
        self.act_move_down = self._menu.addAction("Move down")
        self.btn_menu.setMenu(self._menu)

        self.act_remove.triggered.connect(lambda: self.remove_requested.emit(self._group))
        self.act_move_up.triggered.connect(lambda: self.move_up_requested.emit(self._group))
        self.act_move_down.triggered.connect(lambda: self.move_down_requested.emit(self._group))

        header = QtWidgets.QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(6)
        header.addWidget(self.btn_menu, 0)
        header.addWidget(self.lbl_title, 1)

        def _mk_spin(decimals: int = 3) -> QtWidgets.QDoubleSpinBox:
            sb = QtWidgets.QDoubleSpinBox()
            sb.setDecimals(decimals)
            sb.setRange(-1e9, 1e9)
            sb.setSingleStep(0.1)
            sb.setMaximumWidth(120)
            return sb

        self.spin_ymin = _mk_spin(3)
        self.spin_ymax = _mk_spin(3)

        self.spin_scale = QtWidgets.QDoubleSpinBox()
        self.spin_scale.setDecimals(6)
        self.spin_scale.setRange(1e-9, 1e9)
        self.spin_scale.setSingleStep(0.1)
        self.spin_scale.setMaximumWidth(120)

        # One-row color strip (up to 3 buttons).
        self.colors_row = QtWidgets.QHBoxLayout()
        self.colors_row.setContentsMargins(0, 0, 0, 0)
        self.colors_row.setSpacing(6)
        self.colors_row.addWidget(QtWidgets.QLabel("Colors"), 0)
        self.colors_row.addStretch(1)

        def _emit_cfg(*_args) -> None:
            self.config_changed.emit(
                self._group,
                float(self.spin_ymin.value()),
                float(self.spin_ymax.value()),
                float(self.spin_scale.value()),
            )

        self.spin_ymin.valueChanged.connect(_emit_cfg)
        self.spin_ymax.valueChanged.connect(_emit_cfg)
        self.spin_scale.valueChanged.connect(_emit_cfg)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        layout.addLayout(header)

        # Compact 2-row config grid:
        # Row1: Ymin | Ymax
        # Row2: Scale | Colors
        grid = QtWidgets.QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(4)
        grid.addWidget(QtWidgets.QLabel("Y min"), 0, 0)
        grid.addWidget(self.spin_ymin, 0, 1)
        grid.addWidget(QtWidgets.QLabel("Y max"), 0, 2)
        grid.addWidget(self.spin_ymax, 0, 3)
        grid.addWidget(QtWidgets.QLabel("Scale"), 1, 0)
        grid.addWidget(self.spin_scale, 1, 1)
        colors_wrap = QtWidgets.QWidget()
        colors_wrap.setLayout(self.colors_row)
        grid.addWidget(colors_wrap, 1, 2, 1, 2)
        grid.setColumnStretch(4, 1)
        layout.addLayout(grid)

    @property
    def group(self) -> str:
        return self._group

    def set_title(self, title: str) -> None:
        self.lbl_title.setText(str(title))

    def set_move_enabled(self, *, up: bool, down: bool) -> None:
        self.act_move_up.setEnabled(bool(up))
        self.act_move_down.setEnabled(bool(down))

    def set_values(self, *, y_min: float, y_max: float, scale: float) -> None:
        # Avoid feedback loops when UI is syncing from plot state.
        for w in (self.spin_ymin, self.spin_ymax, self.spin_scale):
            w.blockSignals(True)
        try:
            self.spin_ymin.setValue(float(y_min))
            self.spin_ymax.setValue(float(y_max))
            self.spin_scale.setValue(float(scale))
        finally:
            for w in (self.spin_ymin, self.spin_ymax, self.spin_scale):
                w.blockSignals(False)

    def set_traces(self, traces: list[tuple[str, str, str]]) -> None:
        """Set per-curve color controls.

        traces: list of (trace_key, short_name, color_hex)
        """
        # Rebuild the color strip (up to 3 traces, single row).
        # Remove existing buttons (leave leading label + stretch).
        while self.colors_row.count() > 2:
            item = self.colors_row.takeAt(1)
            w = item.widget()
            if w:
                w.setParent(None)
        self._trace_btns.clear()
        self._trace_colors = {k: c for (k, _, c) in traces}

        for trace_key, short_name, color_hex in traces[:4]:
            btn = QtWidgets.QToolButton()
            btn.setAutoRaise(False)
            btn.setFixedSize(20, 16)
            btn.setToolTip(f"{short_name} • click to change color")
            btn.setStyleSheet(f"background-color: {color_hex}; border: 1px solid #22306b; border-radius: 3px;")

            def _pick_color(*_args, _k=trace_key):
                initial = QtGui.QColor(self._trace_colors.get(_k, "#d7e1ff"))
                col = QtWidgets.QColorDialog.getColor(initial, self, "Select curve color")
                if not col.isValid():
                    return
                hx = col.name()
                self._trace_colors[_k] = hx
                b = self._trace_btns.get(_k)
                if b:
                    b.setStyleSheet(f"background-color: {hx}; border: 1px solid #22306b; border-radius: 3px;")
                self._update_icon()
                self.color_changed.emit(_k, hx)

            btn.clicked.connect(_pick_color)
            self.colors_row.insertWidget(self.colors_row.count() - 1, btn)
            self._trace_btns[trace_key] = btn

        self._update_icon()

    def _update_icon(self) -> None:
        # No top-left color legend anymore; colors are shown in the row of buttons.
        return


class ScenarioControlTile(QtWidgets.QGroupBox):
    """Right-panel control widget for one Scenario instance (device + scenario)."""

    remove_requested = QtCore.pyqtSignal(str)    # key
    activate_requested = QtCore.pyqtSignal(str)  # key
    bounds_changed = QtCore.pyqtSignal(str, float, float, float, float)  # key, x_min, x_max, y_min, y_max

    def __init__(self, *, key: str, title: str, subtitle: str = "", parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self._key = str(key)
        self.setTitle("")

        self.lbl_title = QtWidgets.QLabel(str(title))
        self.lbl_title.setStyleSheet("font-weight: 600;")
        self.lbl_title.setWordWrap(True)
        self.lbl_title.setToolTip("Click to make this scenario the active one (left plot).")
        try:
            self.lbl_title.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        except Exception:
            pass

        self.lbl_sub = QtWidgets.QLabel(str(subtitle))
        self.lbl_sub.setStyleSheet("color: #9fb2e8;")
        self.lbl_sub.setWordWrap(True)
        self.lbl_sub.setToolTip("Click to make this scenario the active one (left plot).")
        try:
            self.lbl_sub.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        except Exception:
            pass

        # The Scenario page already has "Add" selecting the active tile; when multiple tiles exist,
        # selecting via a dedicated "Use" button is redundant and costs horizontal space.
        # Instead, make the header text clickable to activate.
        self.lbl_title.installEventFilter(self)
        self.lbl_sub.installEventFilter(self)

        self.btn_remove = QtWidgets.QToolButton()
        self.btn_remove.setText("✕")
        self.btn_remove.setToolTip("Remove this scenario tile")
        self.btn_remove.clicked.connect(lambda: self.remove_requested.emit(self._key))

        def _mk_spin(decimals: int = 3) -> QtWidgets.QDoubleSpinBox:
            sb = QtWidgets.QDoubleSpinBox()
            sb.setDecimals(decimals)
            sb.setRange(-1e9, 1e9)
            sb.setSingleStep(0.1)
            sb.setMaximumWidth(120)
            return sb

        self.spin_xmin = _mk_spin(3)
        self.spin_xmax = _mk_spin(3)
        self.spin_ymin = _mk_spin(3)
        self.spin_ymax = _mk_spin(3)

        # Defaults: a stable, symmetric view (meters).
        for w in (self.spin_xmin, self.spin_ymin):
            w.setValue(-1.0)
        for w in (self.spin_xmax, self.spin_ymax):
            w.setValue(1.0)

        def _emit_bounds(*_args) -> None:
            self.bounds_changed.emit(
                self._key,
                float(self.spin_xmin.value()),
                float(self.spin_xmax.value()),
                float(self.spin_ymin.value()),
                float(self.spin_ymax.value()),
            )

        self.spin_xmin.valueChanged.connect(_emit_bounds)
        self.spin_xmax.valueChanged.connect(_emit_bounds)
        self.spin_ymin.valueChanged.connect(_emit_bounds)
        self.spin_ymax.valueChanged.connect(_emit_bounds)

        header = QtWidgets.QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(6)
        header.addWidget(self.lbl_title, 1)
        header.addWidget(self.btn_remove, 0)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(4)
        layout.addLayout(header)
        layout.addWidget(self.lbl_sub, 0)

        # Compact bounds grid (similar density to SignalGroupControl).
        grid = QtWidgets.QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(4)
        grid.addWidget(QtWidgets.QLabel("X min"), 0, 0)
        grid.addWidget(self.spin_xmin, 0, 1)
        grid.addWidget(QtWidgets.QLabel("X max"), 0, 2)
        grid.addWidget(self.spin_xmax, 0, 3)
        grid.addWidget(QtWidgets.QLabel("Y min"), 1, 0)
        grid.addWidget(self.spin_ymin, 1, 1)
        grid.addWidget(QtWidgets.QLabel("Y max"), 1, 2)
        grid.addWidget(self.spin_ymax, 1, 3)
        # Keep the layout compact; avoid introducing an extra empty stretch column.
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        layout.addLayout(grid)

    @property
    def key(self) -> str:
        return self._key

    def eventFilter(self, obj: QtCore.QObject, event: QtCore.QEvent) -> bool:  # noqa: N802 (Qt naming)
        # Activate when clicking the title/subtitle area.
        try:
            if obj in (self.lbl_title, self.lbl_sub) and event.type() == QtCore.QEvent.Type.MouseButtonPress:
                if isinstance(event, QtGui.QMouseEvent) and event.button() == QtCore.Qt.MouseButton.LeftButton:
                    self.activate_requested.emit(self._key)
        except Exception:
            pass
        return super().eventFilter(obj, event)

    def set_active(self, active: bool) -> None:
        # Subtle border highlight when active.
        if active:
            self.setStyleSheet("border: 1px solid #2ed573; border-radius: 6px;")
        else:
            self.setStyleSheet("")

    def set_subtitle(self, subtitle: str) -> None:
        self.lbl_sub.setText(str(subtitle))

    def get_bounds(self) -> tuple[float, float, float, float]:
        return (
            float(self.spin_xmin.value()),
            float(self.spin_xmax.value()),
            float(self.spin_ymin.value()),
            float(self.spin_ymax.value()),
        )

    def set_bounds(self, *, x_min: float, x_max: float, y_min: float, y_max: float) -> None:
        for w in (self.spin_xmin, self.spin_xmax, self.spin_ymin, self.spin_ymax):
            w.blockSignals(True)
        try:
            self.spin_xmin.setValue(float(x_min))
            self.spin_xmax.setValue(float(x_max))
            self.spin_ymin.setValue(float(y_min))
            self.spin_ymax.setValue(float(y_max))
        finally:
            for w in (self.spin_xmin, self.spin_xmax, self.spin_ymin, self.spin_ymax):
                w.blockSignals(False)


class DeviceSettingsDialog(QtWidgets.QDialog):
    """Settings dialog matching EMGS_v4 semantics (simple combos, no magic)."""

    def __init__(self, device: EmgsDevice, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self.setModal(True)
        self.setWindowTitle(f"Settings — {device.params.name} ({device.params.address})")
        self._device = device

        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()

        self.edit_name = QtWidgets.QLineEdit(device.params.name if device.params.name != "/" else "")

        # Conn interval "min,max"
        cmin, cmax = 0, 0
        try:
            if device.params.conn_interval and "," in device.params.conn_interval:
                a, b = device.params.conn_interval.split(",", 1)
                cmin, cmax = int(a), int(b)
        except Exception:
            cmin, cmax = 0, 0
        self.spin_conn_min = QtWidgets.QSpinBox()
        self.spin_conn_min.setRange(0, 4000)
        self.spin_conn_min.setValue(cmin)
        self.spin_conn_max = QtWidgets.QSpinBox()
        self.spin_conn_max.setRange(0, 4000)
        self.spin_conn_max.setValue(cmax)

        # Mode combos (same as EMGS_v4 dialog)
        self.combo_gyr = QtWidgets.QComboBox()
        self.combo_gyr.addItems(["OFF", "RAW", "CALIBRATE"])
        self.combo_gyr.setCurrentIndex((1 if device.icm_enabled[3] else 0) + (2 if device.icm_enabled[4] else 0))

        self.combo_acc = QtWidgets.QComboBox()
        self.combo_acc.addItems(["OFF", "RAW", "CALIBRATE", "LINEAR"])
        # Priority: linear > cal > raw
        acc_idx = 3 if device.icm_enabled[2] else (2 if device.icm_enabled[1] else (1 if device.icm_enabled[0] else 0))
        self.combo_acc.setCurrentIndex(acc_idx)

        self.combo_mag = QtWidgets.QComboBox()
        self.combo_mag.addItems(["OFF", "RAW", "CALIBRATE"])
        self.combo_mag.setCurrentIndex((1 if device.icm_enabled[5] else 0) + (2 if device.icm_enabled[6] else 0))

        self.combo_quat = QtWidgets.QComboBox()
        self.combo_quat.addItems(["OFF", "QUAT VECTOR", "QUAT GEO MAG"])
        self.combo_quat.setCurrentIndex((1 if device.icm_enabled[7] else 0) + (2 if device.icm_enabled[8] else 0))

        self.combo_emg = QtWidgets.QComboBox()
        self.combo_emg.addItems(["OFF", "EMG_RMS", "EMG_RAW"])
        self.combo_emg.setCurrentIndex(int(device.emg_mode) if 0 <= int(device.emg_mode) <= 2 else 0)

        # Advanced (firmware_ref)
        self.spin_emg_threshold = QtWidgets.QSpinBox()
        self.spin_emg_threshold.setRange(0, 65535)
        if device.emg_threshold is not None:
            self.spin_emg_threshold.setValue(int(device.emg_threshold))

        self.spin_power_safe = QtWidgets.QSpinBox()
        self.spin_power_safe.setRange(0, 100)
        if device.power_safe_lvl_percent is not None:
            self.spin_power_safe.setValue(int(device.power_safe_lvl_percent))

        self.spin_storage_threshold = QtWidgets.QSpinBox()
        self.spin_storage_threshold.setRange(0, 100)
        if device.storage_threshold_percent is not None:
            self.spin_storage_threshold.setValue(int(device.storage_threshold_percent))

        # IMU freq/scale common types
        self.spin_acc_freq = QtWidgets.QSpinBox(); self.spin_acc_freq.setRange(1, 255); self.spin_acc_freq.setValue(int(device.icm_freq.get(1, 100)))
        self.spin_gyr_freq = QtWidgets.QSpinBox(); self.spin_gyr_freq.setRange(1, 255); self.spin_gyr_freq.setValue(int(device.icm_freq.get(4, 100)))
        self.spin_mag_freq = QtWidgets.QSpinBox(); self.spin_mag_freq.setRange(1, 255); self.spin_mag_freq.setValue(int(device.icm_freq.get(6, 70)))

        self.spin_acc_scale = QtWidgets.QSpinBox(); self.spin_acc_scale.setRange(0, 10); self.spin_acc_scale.setValue(int(device.icm_scale.get(1, 1)))
        self.spin_gyr_scale = QtWidgets.QSpinBox(); self.spin_gyr_scale.setRange(0, 10); self.spin_gyr_scale.setValue(int(device.icm_scale.get(4, 3)))

        # Bias (int32) and auto-save
        def _mk_bias_row(v: int | None) -> QtWidgets.QSpinBox:
            sb = QtWidgets.QSpinBox()
            sb.setRange(-2147483648, 2147483647)
            if v is not None:
                sb.setValue(int(v))
            return sb

        acc = device.icm_bias_acc or (0, 0, 0)
        gyr = device.icm_bias_gyr or (0, 0, 0)
        mag = device.icm_bias_mag or (0, 0, 0)
        self.bias_acc_x = _mk_bias_row(acc[0]); self.bias_acc_y = _mk_bias_row(acc[1]); self.bias_acc_z = _mk_bias_row(acc[2])
        self.bias_gyr_x = _mk_bias_row(gyr[0]); self.bias_gyr_y = _mk_bias_row(gyr[1]); self.bias_gyr_z = _mk_bias_row(gyr[2])
        self.bias_mag_x = _mk_bias_row(mag[0]); self.bias_mag_y = _mk_bias_row(mag[1]); self.bias_mag_z = _mk_bias_row(mag[2])

        self.chk_auto_save_bias = QtWidgets.QCheckBox("ICM auto-save bias")
        self.chk_auto_save_bias.setChecked(False)

        form.addRow("BLE Name", self.edit_name)
        form.addRow("Conn Interval (min)", self.spin_conn_min)
        form.addRow("Conn Interval (max)", self.spin_conn_max)
        form.addRow("GYR Mode", self.combo_gyr)
        form.addRow("ACC Mode", self.combo_acc)
        form.addRow("MAG Mode", self.combo_mag)
        form.addRow("QUAT Mode", self.combo_quat)
        form.addRow("EMG Mode", self.combo_emg)
        form.addRow(QtWidgets.QLabel("— Advanced —"), QtWidgets.QLabel(""))
        form.addRow("EMG Threshold", self.spin_emg_threshold)
        form.addRow("Power-safe level (%)", self.spin_power_safe)
        form.addRow("Storage threshold (%)", self.spin_storage_threshold)
        form.addRow("ACC Freq (Hz)", self.spin_acc_freq)
        form.addRow("GYR Freq (Hz)", self.spin_gyr_freq)
        form.addRow("MAG Freq (Hz)", self.spin_mag_freq)
        form.addRow("ACC Scale code", self.spin_acc_scale)
        form.addRow("GYR Scale code", self.spin_gyr_scale)
        form.addRow("Bias ACC (x,y,z)", self._triple_widget(self.bias_acc_x, self.bias_acc_y, self.bias_acc_z))
        form.addRow("Bias GYR (x,y,z)", self._triple_widget(self.bias_gyr_x, self.bias_gyr_y, self.bias_gyr_z))
        form.addRow("Bias MAG (x,y,z)", self._triple_widget(self.bias_mag_x, self.bias_mag_y, self.bias_mag_z))
        form.addRow(self.chk_auto_save_bias, QtWidgets.QLabel(""))

        layout.addLayout(form)

        self.button_box = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

    def get_values(self) -> dict:
        """Return a settings dict to apply (forward-compatible)."""
        ble_name = self.edit_name.text().strip() or self._device.params.name
        conn_min = int(self.spin_conn_min.value())
        conn_max = int(self.spin_conn_max.value())

        icm = [False] * 9
        # ACC
        acc_mode = self.combo_acc.currentIndex()
        if acc_mode == 1:
            icm[0] = True
        elif acc_mode == 2:
            icm[1] = True
        elif acc_mode == 3:
            icm[2] = True

        # GYR
        gyr_mode = self.combo_gyr.currentIndex()
        if gyr_mode == 1:
            icm[3] = True
        elif gyr_mode == 2:
            icm[4] = True

        # MAG
        mag_mode = self.combo_mag.currentIndex()
        if mag_mode == 1:
            icm[5] = True
        elif mag_mode == 2:
            icm[6] = True

        # QUAT
        quat_mode = self.combo_quat.currentIndex()
        if quat_mode == 1:
            icm[7] = True
        elif quat_mode == 2:
            icm[8] = True

        emg_mode = int(self.combo_emg.currentIndex())
        return {
            "ble_name": ble_name,
            "conn_min": conn_min,
            "conn_max": conn_max,
            "icm_enabled": icm,
            "emg_mode": emg_mode,
            "emg_threshold": int(self.spin_emg_threshold.value()),
            "power_safe_lvl": int(self.spin_power_safe.value()),
            "storage_threshold": int(self.spin_storage_threshold.value()),
            "icm_freq": {1: int(self.spin_acc_freq.value()), 4: int(self.spin_gyr_freq.value()), 6: int(self.spin_mag_freq.value())},
            "icm_scale": {1: int(self.spin_acc_scale.value()), 4: int(self.spin_gyr_scale.value())},
            "icm_bias": {
                "acc": [int(self.bias_acc_x.value()), int(self.bias_acc_y.value()), int(self.bias_acc_z.value())],
                "gyr": [int(self.bias_gyr_x.value()), int(self.bias_gyr_y.value()), int(self.bias_gyr_z.value())],
                "mag": [int(self.bias_mag_x.value()), int(self.bias_mag_y.value()), int(self.bias_mag_z.value())],
            },
            "icm_auto_save_bias": bool(self.chk_auto_save_bias.isChecked()),
        }

    def _triple_widget(self, a: QtWidgets.QWidget, b: QtWidgets.QWidget, c: QtWidgets.QWidget) -> QtWidgets.QWidget:
        w = QtWidgets.QWidget()
        l = QtWidgets.QHBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(6)
        l.addWidget(a)
        l.addWidget(b)
        l.addWidget(c)
        return w


class BulkModeSettingsDialog(QtWidgets.QDialog):
    """Bulk mode settings (ACC/GYR/MAG/QUAT/EMG) for multiple devices."""

    def __init__(self, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self.setModal(True)
        self.setWindowTitle("Bulk Mode Settings")

        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()

        self.combo_gyr = QtWidgets.QComboBox()
        self.combo_gyr.addItems(["OFF", "RAW", "CALIBRATE"])
        self.combo_gyr.setCurrentIndex(0)

        self.combo_acc = QtWidgets.QComboBox()
        self.combo_acc.addItems(["OFF", "RAW", "CALIBRATE", "LINEAR"])
        self.combo_acc.setCurrentIndex(0)

        self.combo_mag = QtWidgets.QComboBox()
        self.combo_mag.addItems(["OFF", "RAW", "CALIBRATE"])
        self.combo_mag.setCurrentIndex(0)

        self.combo_quat = QtWidgets.QComboBox()
        self.combo_quat.addItems(["OFF", "QUAT VECTOR", "QUAT GEO MAG"])
        self.combo_quat.setCurrentIndex(0)

        self.combo_emg = QtWidgets.QComboBox()
        self.combo_emg.addItems(["OFF", "EMG_RMS", "EMG_RAW"])
        self.combo_emg.setCurrentIndex(0)

        note = QtWidgets.QLabel("Applies to all connected devices. Changes take effect immediately.")
        note.setStyleSheet("color: #9fb2e8;")
        note.setWordWrap(True)

        form.addRow("ACC Mode", self.combo_acc)
        form.addRow("GYR Mode", self.combo_gyr)
        form.addRow("MAG Mode", self.combo_mag)
        form.addRow("QUAT Mode", self.combo_quat)
        form.addRow("EMG Mode", self.combo_emg)

        layout.addWidget(note)
        layout.addLayout(form)

        self.button_box = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

    def get_values(self) -> tuple[list[bool], int]:
        """Return (icm_enabled[9], emg_mode)."""
        icm = [False] * 9
        # ACC
        acc_mode = self.combo_acc.currentIndex()
        if acc_mode == 1:
            icm[0] = True
        elif acc_mode == 2:
            icm[1] = True
        elif acc_mode == 3:
            icm[2] = True

        # GYR
        gyr_mode = self.combo_gyr.currentIndex()
        if gyr_mode == 1:
            icm[3] = True
        elif gyr_mode == 2:
            icm[4] = True

        # MAG
        mag_mode = self.combo_mag.currentIndex()
        if mag_mode == 1:
            icm[5] = True
        elif mag_mode == 2:
            icm[6] = True

        # QUAT
        quat_mode = self.combo_quat.currentIndex()
        if quat_mode == 1:
            icm[7] = True
        elif quat_mode == 2:
            icm[8] = True

        emg_mode = int(self.combo_emg.currentIndex())
        return icm, emg_mode


class BatteryDelegate(QtWidgets.QStyledItemDelegate):
    """Paint a small battery bar with percentage text (works for model-view tables)."""

    def paint(self, painter: QtGui.QPainter, option: QtWidgets.QStyleOptionViewItem, index: QtCore.QModelIndex) -> None:
        text = index.data(QtCore.Qt.ItemDataRole.DisplayRole) or ""
        meta = index.data(QtCore.Qt.ItemDataRole.UserRole) or {}
        is_charging = bool(meta.get("charging")) if isinstance(meta, dict) else False
        # Extract "NN %" -> NN
        pct = None
        try:
            if isinstance(text, str) and "%" in text:
                pct = int(text.split("%", 1)[0].strip())
        except Exception:
            pct = None

        # Default paint (selection, background)
        opt = QtWidgets.QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        opt.text = ""  # we'll draw our own
        style = opt.widget.style() if opt.widget else QtWidgets.QApplication.style()
        style.drawControl(QtWidgets.QStyle.ControlElement.CE_ItemViewItem, opt, painter, opt.widget)

        if pct is None:
            # Fallback: draw plain text
            painter.save()
            painter.setPen(QtGui.QColor("#d7e1ff"))
            painter.drawText(opt.rect.adjusted(8, 0, -8, 0), int(QtCore.Qt.AlignmentFlag.AlignVCenter | QtCore.Qt.AlignmentFlag.AlignLeft), str(text))
            painter.restore()
            return

        pct = max(0, min(100, pct))
        rect = opt.rect.adjusted(8, 6, -8, -6)
        bar_rect = QtCore.QRect(rect.left(), rect.top(), int(rect.width() * 0.62), rect.height())
        txt_rect = QtCore.QRect(bar_rect.right() + 8, rect.top(), rect.width() - bar_rect.width() - 8, rect.height())

        # Colors
        if pct >= 70:
            fill = QtGui.QColor("#2ed573")
        elif pct >= 30:
            # UX: while charging, keep the gauge "good" (green) instead of warning (yellow).
            fill = QtGui.QColor("#2ed573") if is_charging else QtGui.QColor("#ffa502")
        else:
            fill = QtGui.QColor("#ff4757")
        bg = QtGui.QColor("#0f1630")
        border = QtGui.QColor("#22306b")

        # Draw bar
        painter.save()
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        painter.setPen(QtGui.QPen(border))
        painter.setBrush(bg)
        painter.drawRoundedRect(bar_rect, 6, 6)

        fill_w = int((bar_rect.width() - 2) * (pct / 100.0))
        if fill_w > 0:
            fill_rect = QtCore.QRect(bar_rect.left() + 1, bar_rect.top() + 1, fill_w, bar_rect.height() - 2)
            painter.setPen(QtCore.Qt.PenStyle.NoPen)
            painter.setBrush(fill)
            painter.drawRoundedRect(fill_rect, 5, 5)

        # Text
        painter.setPen(QtGui.QColor("#d7e1ff"))
        suffix = " ⚡" if is_charging else ""
        painter.drawText(txt_rect, int(QtCore.Qt.AlignmentFlag.AlignVCenter | QtCore.Qt.AlignmentFlag.AlignLeft), f"{pct}%{suffix}")
        painter.restore()


class AkrDeviceSettingsDialog(QtWidgets.QDialog):
    """AKR device Settings dialog (UART-like CLI over BLE).

    Designed to mirror the command set in `backup/akr_code_v7/Bsp/rr_status.c`.
    """

    _RR_RUNTIME_STATUS_FIELDS: tuple[str, ...] = (
        "fw_name",
        "fw_version_str",
        "is_left",
        "mode",
        "motor_connected",
        "motor_feedback_age_ms",
        "motor_can_id",
        "motor_pattern",
        "motor_error_code",
        "motor_fault_error_code",
        "motor_mode_0x7005",
        "mech_position_rad",
        "speed_rad_s",
        "torque_nm",
        "temp_c",
        "vbus_v",
        "vbus_age_ms",
        "can_find_active",
        "can_find_elapsed_ms",
    )

    _RR_TELEM_ARG_FIELDS: tuple[str, ...] = (
        # RR_Telem_SendAKR(...)
        "fid",
        "dt_ms",
        "exec_ms",
        "out",
        "state",
        "acc_x",
        "acc_y",
        "acc_z",
        "gyr_x",
        "gyr_y",
        "gyr_z",
        "mag_x",
        "mag_y",
        "mag_z",
        "pos_rad",
        "vel_rad_s",
        "tq_nm",
        "temp_c",
        "vbus_v",
        "pattern",
        "err_code",
        "fb_age_ms",
        # RR_Telem_SendCPM(...) unique/additional args
        "cpm_state",
        "dir",
        "blocked_event",
        "blocked_consecutive",
        "cmd_spd_rad_s",
        "df_limit_rad",
        "pf_limit_rad",
        "elapsed_s",
        "repetition_count",
        # RR_Telem_SendTest(...) unique/additional args
        "measure_state",
        "blocked",
        "result_flags",
        "prom_df_end_rad",
        "prom_pf_end_rad",
        "arom_df_max_rad",
        "arom_pf_min_rad",
    )

    _TELEM_BUFFER_SOURCES: dict[str, tuple[tuple[str, int], ...]] = {
        "fid": (("akr_walk_fid_buffer", 0), ("akr_cpm_fid_buffer", 0), ("akr_test_fid_buffer", 0)),
        "dt_ms": (("akr_walk_dt_ms_buffer", 0), ("akr_cpm_dt_ms_buffer", 0), ("akr_test_dt_ms_buffer", 0)),
        "exec_ms": (("akr_walk_exec_ms_buffer", 0),),
        "out": (("akr_walk_out_buffer", 0),),
        "state": (("akr_walk_state_buffer", 0),),
        "acc_x": (("akr_walk_acc_buffer", 0),),
        "acc_y": (("akr_walk_acc_buffer", 1),),
        "acc_z": (("akr_walk_acc_buffer", 2),),
        "gyr_x": (("akr_walk_gyr_buffer", 0),),
        "gyr_y": (("akr_walk_gyr_buffer", 1),),
        "gyr_z": (("akr_walk_gyr_buffer", 2),),
        "mag_x": (("akr_walk_mag_buffer", 0),),
        "mag_y": (("akr_walk_mag_buffer", 1),),
        "mag_z": (("akr_walk_mag_buffer", 2),),
        "pos_rad": (("akr_walk_pos_rad_buffer", 0), ("akr_cpm_pos_rad_buffer", 0), ("akr_test_pos_rad_buffer", 0)),
        "vel_rad_s": (("akr_walk_vel_rad_s_buffer", 0), ("akr_cpm_vel_rad_s_buffer", 0), ("akr_test_vel_rad_s_buffer", 0)),
        "tq_nm": (("akr_walk_tq_nm_buffer", 0), ("akr_cpm_tq_nm_buffer", 0), ("akr_test_tq_nm_buffer", 0)),
        "temp_c": (("akr_walk_temp_c_buffer", 0), ("akr_cpm_temp_c_buffer", 0), ("akr_test_temp_c_buffer", 0)),
        "vbus_v": (("akr_walk_vbus_v_buffer", 0), ("akr_cpm_vbus_v_buffer", 0), ("akr_test_vbus_v_buffer", 0)),
        "pattern": (("akr_walk_pattern_buffer", 0), ("akr_cpm_pattern_buffer", 0), ("akr_test_pattern_buffer", 0)),
        "err_code": (("akr_walk_err_code_buffer", 0), ("akr_cpm_err_code_buffer", 0), ("akr_test_err_code_buffer", 0)),
        "fb_age_ms": (("akr_walk_fb_age_ms_buffer", 0), ("akr_cpm_fb_age_ms_buffer", 0), ("akr_test_fb_age_ms_buffer", 0)),
        "cpm_state": (("akr_cpm_state_buffer", 0),),
        "dir": (("akr_cpm_dir_buffer", 0), ("akr_test_dir_buffer", 0)),
        "blocked_event": (("akr_cpm_blocked_event_buffer", 0),),
        "blocked_consecutive": (("akr_cpm_blocked_consecutive_buffer", 0),),
        "cmd_spd_rad_s": (("akr_cpm_cmd_spd_rad_s_buffer", 0),),
        "df_limit_rad": (("akr_cpm_df_limit_rad_buffer", 0),),
        "pf_limit_rad": (("akr_cpm_pf_limit_rad_buffer", 0),),
        "elapsed_s": (("akr_cpm_elapsed_s_buffer", 0),),
        "repetition_count": (("akr_cpm_repetition_count_buffer", 0),),
        "measure_state": (("akr_test_state_buffer", 0),),
        "blocked": (("akr_test_blocked_buffer", 0),),
        "result_flags": (("akr_test_result_flags_buffer", 0),),
        "prom_df_end_rad": (("akr_test_prom_df_end_rad_buffer", 0),),
        "prom_pf_end_rad": (("akr_test_prom_pf_end_rad_buffer", 0),),
        "arom_df_max_rad": (("akr_test_arom_df_max_rad_buffer", 0),),
        "arom_pf_min_rad": (("akr_test_arom_pf_min_rad_buffer", 0),),
    }

    @classmethod
    def _table_param_fields(cls) -> tuple[str, ...]:
        keys: list[str] = []
        for key in cls._RR_RUNTIME_STATUS_FIELDS:
            if key not in keys:
                keys.append(key)
        for key in cls._RR_TELEM_ARG_FIELDS:
            if key not in keys:
                keys.append(key)
        return tuple(keys)

    def __init__(
        self,
        *,
        controller: EmgsController,
        address: str,
        device_name: str = "AKR",
        parent: QtWidgets.QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setModal(True)
        self._controller = controller
        self._address = str(address)
        self._device_name = str(device_name or "AKR")
        self.setWindowTitle(f"Settings — {self._device_name} ({self._address})")

        self._last_show: dict[str, str] = {}
        self._rx_any: bool = False
        self._opened_maximized: bool = False

        root_layout = QtWidgets.QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        root_layout.addWidget(scroll)
        content = QtWidgets.QWidget()
        scroll.setWidget(content)

        layout = QtWidgets.QVBoxLayout(content)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        info = QtWidgets.QLabel("ANKLE ROBOT SETTINGS")
        info.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        info.setStyleSheet(
            "color: #d7e1ff; font-size: 22px; font-weight: 800; letter-spacing: 1px;"
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        hint = QtWidgets.QLabel(
            "AKR CLI over BLE. The app sends exactly the command you click/type "
            "(no automatic `help` after each command)."
        )
        hint.setStyleSheet("color: #9fb2e8;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        # --- Command helpers (mirrors rr_status.c) ---
        helpers = QtWidgets.QGroupBox("Quick commands")
        hl = QtWidgets.QGridLayout(helpers)
        hl.setHorizontalSpacing(8)
        hl.setVerticalSpacing(6)

        self.btn_help = QtWidgets.QPushButton("help")
        self.btn_show = QtWidgets.QPushButton("show")
        self.btn_stop = QtWidgets.QPushButton("stop")
        self.btn_walk = QtWidgets.QPushButton("walk")
        self.btn_cpm = QtWidgets.QPushButton("cpm")
        self.btn_measure = QtWidgets.QPushButton("measure")
        self.btn_test = QtWidgets.QPushButton("test")
        self.btn_measure_result = QtWidgets.QPushButton("measure result")
        self.btn_set_cpm_prom = QtWidgets.QPushButton("measure df")
        self.btn_measure_prom = QtWidgets.QPushButton("measure pf")
        self.btn_measure_arom = QtWidgets.QPushButton("measure arom")
        self.btn_record_start = QtWidgets.QPushButton("Start Record")
        self.btn_record_stop = QtWidgets.QPushButton("Stop Record")
        self.btn_record_start.setToolTip("Shortcut to Signals -> Start Record.")
        self.btn_record_stop.setToolTip("Shortcut to Signals -> Stop Record.")
        self.btn_load = QtWidgets.QPushButton("load")
        self.btn_save = QtWidgets.QPushButton("save")
        self.btn_defaults = QtWidgets.QPushButton("defaults")
        self.btn_apply_df = QtWidgets.QPushButton("apply df")
        self.btn_apply_pf = QtWidgets.QPushButton("apply pf")
        self.btn_apply_rel = QtWidgets.QPushButton("apply release")
        self.btn_pause = QtWidgets.QPushButton("pause")
        self.btn_set_zero = QtWidgets.QPushButton("set zero")
        self.btn_set_zerosta_1 = QtWidgets.QPushButton("set zerosta 1")
        self.btn_clearerr = QtWidgets.QPushButton("clearerr")
        self.btn_motorsave = QtWidgets.QPushButton("motorsave")
        
        self.btn_walk.setStyleSheet("background-color: #228b22; color: #ffffff; font-weight: 600;")
        self.btn_cpm.setStyleSheet("background-color: #228b22; color: #ffffff; font-weight: 600;")
        self.btn_measure.setStyleSheet("background-color: #228b22; color: #ffffff; font-weight: 600;")
        self.btn_measure_result.setStyleSheet("background-color: #228b22; color: #ffffff; font-weight: 600;")
        self.btn_stop.setStyleSheet("background-color: #b00020; color: #ffffff; font-weight: 600;")

        # Side
        self.btn_side_left = QtWidgets.QPushButton("set side left")
        self.btn_side_right = QtWidgets.QPushButton("set side right")

        def _mk_p() -> QtWidgets.QDoubleSpinBox:
            sb = QtWidgets.QDoubleSpinBox()
            sb.setDecimals(4)
            sb.setRange(-1e6, 1e6)
            sb.setSingleStep(0.1)
            return sb

        self.df_torque = _mk_p(); self.df_torque.setDecimals(3); self.df_torque.setRange(-100.0, 100.0); self.df_torque.setSingleStep(0.1)
        self.df_angle = _mk_p(); self.df_angle.setDecimals(3); self.df_angle.setRange(-1.0, 1.0); self.df_angle.setSingleStep(0.1)
        self.df_speed = _mk_p(); self.df_speed.setDecimals(3); self.df_speed.setRange(-1.0, 1.0); self.df_speed.setSingleStep(0.1)
        self.df_kp = _mk_p(); self.df_kp.setDecimals(3); self.df_kp.setRange(-100.0, 100.0); self.df_kp.setSingleStep(0.1)
        self.df_kd = _mk_p(); self.df_kd.setDecimals(3); self.df_kd.setRange(-100.0, 100.0); self.df_kd.setSingleStep(0.1)
        self.btn_set_df = QtWidgets.QPushButton("set df")
        
        self.pf_torque = _mk_p(); self.pf_torque.setDecimals(3); self.pf_torque.setRange(-100.0, 100.0); self.pf_torque.setSingleStep(0.1) 
        self.pf_angle = _mk_p(); self.pf_angle.setDecimals(3); self.pf_angle.setRange(-1.0, 1.0); self.pf_angle.setSingleStep(0.1) 
        self.pf_speed = _mk_p(); self.pf_speed.setDecimals(3); self.pf_speed.setRange(-1.0, 1.0); self.pf_speed.setSingleStep(0.1) 
        self.pf_kp = _mk_p(); self.pf_kp.setDecimals(3); self.pf_kp.setRange(-100.0, 100.0); self.pf_kp.setSingleStep(0.1) 
        self.pf_kd = _mk_p(); self.pf_kd.setDecimals(3); self.pf_kd.setRange(-100.0, 100.0); self.pf_kd.setSingleStep(0.1)
        self.btn_set_pf = QtWidgets.QPushButton("set pf")

        # CPM setters (rr_status.c: set cpm <df_deg> <pf_deg> <speed_df> <speed_pf> <wait_df_ms> <wait_pf_ms>)
        self.cpm_df_deg = _mk_p(); self.cpm_df_deg.setDecimals(3); self.cpm_df_deg.setRange(-360.0, 360.0); self.cpm_df_deg.setSingleStep(1.0)
        self.cpm_pf_deg = _mk_p(); self.cpm_pf_deg.setDecimals(3); self.cpm_pf_deg.setRange(-360.0, 360.0); self.cpm_pf_deg.setSingleStep(1.0)
        self.cpm_speed_df = _mk_p(); self.cpm_speed_df.setDecimals(4); self.cpm_speed_df.setRange(-1e4, 1e4); self.cpm_speed_df.setSingleStep(0.1)
        self.cpm_speed_pf = _mk_p(); self.cpm_speed_pf.setDecimals(4); self.cpm_speed_pf.setRange(-1e4, 1e4); self.cpm_speed_pf.setSingleStep(0.1)
        self.cpm_wait_df_ms = QtWidgets.QSpinBox(); self.cpm_wait_df_ms.setRange(0, 65535); self.cpm_wait_df_ms.setValue(0)
        self.cpm_wait_pf_ms = QtWidgets.QSpinBox(); self.cpm_wait_pf_ms.setRange(0, 65535); self.cpm_wait_pf_ms.setValue(0)
        self.btn_set_cpm = QtWidgets.QPushButton("set cpm")
        self.edit_reg_idx = QtWidgets.QLineEdit("0x7016")
        self.edit_reg_idx.setPlaceholderText("0x7016")
        self.edit_reg_idx.setClearButtonEnabled(True)
        self.edit_reg_idx.setMaximumWidth(140)
        self.btn_reg_read = QtWidgets.QPushButton("reg read")

        row = 0
        hl.addWidget(self.btn_help, row, 0)
        hl.addWidget(self.btn_show, row, 1)
        hl.addWidget(self.btn_test, row, 2)
        hl.addWidget(self.btn_walk, row, 3)
        hl.addWidget(self.btn_cpm, row, 4)
        hl.addWidget(self.btn_measure, row, 5)
        row += 1
        
        hl.addWidget(self.btn_load, row, 0)
        hl.addWidget(self.btn_save, row, 1)
        hl.addWidget(self.btn_defaults, row, 2)
        hl.addWidget(self.btn_apply_df, row, 3)
        hl.addWidget(self.btn_apply_pf, row, 4)
        hl.addWidget(self.btn_apply_rel, row, 5)
        row += 1

        hl.addWidget(self.btn_clearerr, row, 0)
        hl.addWidget(self.btn_set_zero, row, 1)
        hl.addWidget(self.btn_set_zerosta_1, row, 2)
        hl.addWidget(self.btn_side_left, row, 3)
        hl.addWidget(self.btn_side_right, row, 4)
        hl.addWidget(self.btn_motorsave, row, 5)
        row += 1

        hl.addWidget(self.btn_stop, row, 0)
        hl.addWidget(self.btn_pause, row, 1)
        hl.addWidget(self.btn_set_cpm_prom, row, 2)
        hl.addWidget(self.btn_measure_prom, row, 3)
        hl.addWidget(self.btn_measure_arom, row, 4)
        hl.addWidget(self.btn_measure_result, row, 5)
        row += 1

        hl.addWidget(self.btn_record_start, row, 0)
        hl.addWidget(self.btn_record_stop, row, 1)
        row += 1

        # Register read helper: builds `reg <index_hex>` with validation.
        hl.addWidget(QtWidgets.QLabel("reg <index_hex>"), row, 0)
        regw = QtWidgets.QWidget()
        regl = QtWidgets.QHBoxLayout(regw); regl.setContentsMargins(0, 0, 0, 0); regl.setSpacing(6)
        regl.addWidget(self.edit_reg_idx, 0)
        regl.addWidget(self.btn_reg_read, 0)
        regl.addStretch(1)
        hl.addWidget(regw, row, 1, 1, 5)
        row += 1

        # DF row
        hl.addWidget(QtWidgets.QLabel("DF (t,a,s,kp,kd)"), row, 0)
        dfw = QtWidgets.QWidget()
        dfl = QtWidgets.QHBoxLayout(dfw); dfl.setContentsMargins(0, 0, 0, 0); dfl.setSpacing(6)
        for w in (self.df_torque, self.df_angle, self.df_speed, self.df_kp, self.df_kd):
            w.setMaximumWidth(110)
            dfl.addWidget(w)
        dfl.addWidget(self.btn_set_df)
        hl.addWidget(dfw, row, 1, 1, 5)
        row += 1

        # PF row
        hl.addWidget(QtWidgets.QLabel("PF (t,a,s,kp,kd)"), row, 0)
        pfw = QtWidgets.QWidget()
        pfl = QtWidgets.QHBoxLayout(pfw); pfl.setContentsMargins(0, 0, 0, 0); pfl.setSpacing(6)
        for w in (self.pf_torque, self.pf_angle, self.pf_speed, self.pf_kp, self.pf_kd):
            w.setMaximumWidth(110)
            pfl.addWidget(w)
        pfl.addWidget(self.btn_set_pf)
        hl.addWidget(pfw, row, 1, 1, 5)
        row += 1

        # CPM row
        hl.addWidget(QtWidgets.QLabel("CPM (df_deg,pf_deg,speed_df,speed_pf,wait_df,wait_pf)"), row, 0)
        cpmw = QtWidgets.QWidget()
        cpml = QtWidgets.QHBoxLayout(cpmw); cpml.setContentsMargins(0, 0, 0, 0); cpml.setSpacing(6)
        for w in (self.cpm_df_deg, self.cpm_pf_deg, self.cpm_speed_df, self.cpm_speed_pf):
            w.setMaximumWidth(110)
            cpml.addWidget(w)
        for w in (self.cpm_wait_df_ms, self.cpm_wait_pf_ms):
            w.setMaximumWidth(90)
            cpml.addWidget(w)
        cpml.addWidget(self.btn_set_cpm)
        hl.addWidget(cpmw, row, 1, 1, 5)

        # --- Two-pane content area ---
        body_grid = QtWidgets.QGridLayout()
        body_grid.setHorizontalSpacing(10)
        body_grid.setVerticalSpacing(10)
        body_grid.addWidget(helpers, 0, 0, 1, 2)

        left_grp = QtWidgets.QGroupBox("CLI feedback parameters")
        left_layout = QtWidgets.QVBoxLayout(left_grp)
        left_layout.setContentsMargins(8, 8, 8, 8)
        left_layout.setSpacing(6)

        self.tbl_params = QtWidgets.QTableWidget(0, 2)
        self.tbl_params.setHorizontalHeaderLabels(["Parameter", "Value"])
        self.tbl_params.verticalHeader().setVisible(False)
        self.tbl_params.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl_params.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl_params.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        self.tbl_params.setAlternatingRowColors(True)
        self.tbl_params.setWordWrap(False)
        self.tbl_params.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.tbl_params.setHorizontalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.tbl_params.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)
        self.tbl_params.setSortingEnabled(False)

        hdr = self.tbl_params.horizontalHeader()
        hdr.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.Stretch)

        left_layout.addWidget(self.tbl_params, 1)
        body_grid.addWidget(left_grp, 1, 0)

        right_grp = QtWidgets.QGroupBox("CLI terminal")
        right_layout = QtWidgets.QVBoxLayout(right_grp)
        right_layout.setContentsMargins(8, 8, 8, 8)
        right_layout.setSpacing(6)

        cmd_row = QtWidgets.QHBoxLayout()
        self.edit_cmd = QtWidgets.QLineEdit()
        self.edit_cmd.setPlaceholderText("Type a command (e.g., show, stop, measure result, set df ...) and press Enter…")
        self.btn_send = QtWidgets.QPushButton("Send")
        self.btn_connect = QtWidgets.QPushButton("Connect")
        self.btn_connect.setToolTip("Connect this device without closing the dialog.")
        self.btn_close = QtWidgets.QPushButton("Close")
        cmd_row.addWidget(self.edit_cmd, 1)
        cmd_row.addWidget(self.btn_send, 0)
        cmd_row.addWidget(self.btn_connect, 0)
        cmd_row.addWidget(self.btn_close, 0)
        right_layout.addLayout(cmd_row)

        self.term = QtWidgets.QPlainTextEdit()
        self.term.setReadOnly(True)
        self.term.setMaximumBlockCount(4000)
        # Keep terminal flexible: expand when space is available, but shrink so
        # the manual command row remains visible in tighter/fullscreen layouts.
        self.term.setMinimumHeight(96)
        # self.term.setSizePolicy(
        #     QtWidgets.QSizePolicy.Policy.Expanding,
        #     QtWidgets.QSizePolicy.Policy.Preferred,
        # )
        self.term.setPlaceholderText("TX/RX transcript...")
        right_layout.addWidget(self.term, 1)

        body_grid.addWidget(right_grp, 1, 1)
        body_grid.setColumnStretch(0, 2)
        body_grid.setColumnStretch(1, 3)
        body_grid.setRowStretch(1, 1)
        layout.addLayout(body_grid, 1)

        self._param_row_by_key: dict[str, int] = {}
        self._init_param_table_rows()

        # Prevent Enter/Return from triggering an arbitrary default button (often `help`).
        # Commands should be sent only by explicit click or by Enter in the command box.
        for b in (
            self.btn_help,
            self.btn_show,
            self.btn_stop,
            self.btn_walk,
            self.btn_cpm,
            self.btn_measure,
            self.btn_test,
            self.btn_measure_result,
            self.btn_set_cpm_prom,
            self.btn_measure_prom,
            self.btn_measure_arom,
            self.btn_record_start,
            self.btn_record_stop,
            self.btn_load,
            self.btn_save,
            self.btn_defaults,
            self.btn_apply_df,
            self.btn_apply_pf,
            self.btn_apply_rel,
            self.btn_pause,
            self.btn_set_zero,
            self.btn_set_zerosta_1,
            self.btn_clearerr,
            self.btn_motorsave,
            self.btn_side_left,
            self.btn_side_right,
            self.btn_set_df,
            self.btn_set_pf,
            self.btn_set_cpm,
            self.btn_reg_read,
            self.btn_send,
            self.btn_connect,
            self.btn_close,
        ):
            b.setAutoDefault(False)
            b.setDefault(False)

        # Wire buttons
        self.btn_send.clicked.connect(self._send_manual)
        self.btn_connect.clicked.connect(self._connect_one)
        self.btn_close.clicked.connect(self.accept)
        self.edit_cmd.returnPressed.connect(self._send_manual)

        self.btn_help.clicked.connect(lambda: self._send("help"))
        self.btn_show.clicked.connect(lambda: self._send("show"))
        self.btn_stop.clicked.connect(lambda: self._send("stop"))
        self.btn_walk.clicked.connect(lambda: self._send("walk"))
        self.btn_cpm.clicked.connect(lambda: self._send("cpm"))
        self.btn_measure.clicked.connect(lambda: self._send("measure"))
        self.btn_test.clicked.connect(lambda: self._send("test"))
        self.btn_measure_result.clicked.connect(lambda: self._send("measure result"))
        self.btn_set_cpm_prom.clicked.connect(lambda: self._send("measure df"))
        self.btn_measure_prom.clicked.connect(lambda: self._send("measure pf"))
        self.btn_measure_arom.clicked.connect(lambda: self._send("measure arom"))
        self.btn_record_start.clicked.connect(self._start_record_shortcut)
        self.btn_record_stop.clicked.connect(self._stop_record_shortcut)
        self.btn_load.clicked.connect(lambda: self._send("load"))
        self.btn_save.clicked.connect(lambda: self._send("save"))
        self.btn_defaults.clicked.connect(lambda: self._send("defaults"))
        self.btn_apply_df.clicked.connect(lambda: self._send("apply df"))
        self.btn_apply_pf.clicked.connect(lambda: self._send("apply pf"))
        self.btn_apply_rel.clicked.connect(lambda: self._send("apply release"))
        self.btn_pause.clicked.connect(lambda: self._send("cpm pause"))
        self.btn_set_zero.clicked.connect(lambda: self._send("set zero"))
        self.btn_set_zerosta_1.clicked.connect(lambda: self._send("set zerosta 1"))
        self.btn_clearerr.clicked.connect(lambda: self._send("clearerr"))
        self.btn_motorsave.clicked.connect(lambda: self._send("motorsave"))
        self.btn_reg_read.clicked.connect(self._send_reg_read)
        self.edit_reg_idx.returnPressed.connect(self._send_reg_read)
        self.btn_side_left.clicked.connect(lambda: self._send("set side left"))
        self.btn_side_right.clicked.connect(lambda: self._send("set side right"))
        self.btn_set_df.clicked.connect(
            lambda: self._send(
                "set df "
                f"{float(self.df_torque.value()):g} {float(self.df_angle.value()):g} {float(self.df_speed.value()):g} "
                f"{float(self.df_kp.value()):g} {float(self.df_kd.value()):g}"
            )
        )
        self.btn_set_pf.clicked.connect(
            lambda: self._send(
                "set pf "
                f"{float(self.pf_torque.value()):g} {float(self.pf_angle.value()):g} {float(self.pf_speed.value()):g} "
                f"{float(self.pf_kp.value()):g} {float(self.pf_kd.value()):g}"
            )
        )
        self.btn_set_cpm.clicked.connect(
            lambda: self._send(
                "set cpm "
                f"{float(self.cpm_df_deg.value()):g} {float(self.cpm_pf_deg.value()):g} "
                f"{float(self.cpm_speed_df.value()):g} {float(self.cpm_speed_pf.value()):g} "
                f"{int(self.cpm_wait_df_ms.value())} {int(self.cpm_wait_pf_ms.value())}"
            )
        )

        # Subscribe to AKR lines/device updates.
        self._controller.signal_akr_line.connect(self._on_akr_line)
        self._controller.signal_device_updated.connect(self._on_device_updated)
        self._refresh_connect_button()
        self._refresh_record_buttons()

        # Auto-show after dialog is visible.
        QtCore.QTimer.singleShot(0, self._auto_refresh)

    def showEvent(self, event: QtGui.QShowEvent) -> None:  # noqa: N802 (Qt naming)
        super().showEvent(event)
        if self._opened_maximized:
            return
        self._opened_maximized = True
        # Open this prompt maximized (fill screen) without entering OS full-screen mode.
        self.showMaximized()

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:  # noqa: N802 (Qt naming)
        try:
            self._controller.signal_akr_line.disconnect(self._on_akr_line)
        except Exception:
            pass
        try:
            self._controller.signal_device_updated.disconnect(self._on_device_updated)
        except Exception:
            pass
        super().closeEvent(event)

    def _append(self, txt: str) -> None:
        self.term.appendPlainText(str(txt))
        try:
            self.term.verticalScrollBar().setValue(self.term.verticalScrollBar().maximum())
        except Exception:
            pass

    def _send(self, cmd: str) -> None:
        s = str(cmd or "").strip()
        if not s:
            return
        # Intentionally send only one command per click/entry (no automatic help follow-up).
        self._append(f"TX> {s}")
        self._controller.akr_send_line(self._address, s)

    def _send_manual(self) -> None:
        s = self.edit_cmd.text().strip()
        if not s:
            return
        self.edit_cmd.clear()
        self._send(s)

    def _send_reg_read(self) -> None:
        raw = self.edit_reg_idx.text().strip()
        if not raw:
            raw = "0x7016"
        try:
            idx = int(raw, 0)
        except Exception:
            self._append(f"UI> invalid reg index: {raw!r} (use decimal or 0xHEX)")
            return
        if idx < 0 or idx > 0xFFFF:
            self._append(f"UI> reg index out of range: {idx} (expected 0..65535)")
            return
        idx_hex = f"0x{idx:04X}"
        self.edit_reg_idx.setText(idx_hex)
        self._send(f"reg {idx_hex}")

    def _auto_refresh(self) -> None:
        self._append("Auto: show")
        self._send("show")

    @staticmethod
    def _token_value(line: str, key: str) -> str | None:
        """Extract `key=value` or `key = value` token from a text line."""
        pairs = AkrDeviceSettingsDialog._split_kv_tokens(line)
        return pairs.get(str(key))

    @staticmethod
    def _split_kv_tokens(line: str) -> dict[str, str]:
        pairs: dict[str, str] = {}
        toks = str(line).split()
        i = 0
        while i < len(toks):
            tok = toks[i]
            if "=" in tok:
                key, val = tok.split("=", 1)
                key = key.strip()
                if key:
                    pairs[key] = val.strip()
                i += 1
                continue
            # Accept "key = value" style tokens as emitted by newer firmware.
            if i + 2 < len(toks) and toks[i + 1] == "=":
                key = tok.strip()
                if key:
                    pairs[key] = toks[i + 2].strip()
                i += 3
                continue
            i += 1
        return pairs

    def _init_param_table_rows(self) -> None:
        self.tbl_params.setRowCount(0)
        self._param_row_by_key.clear()
        for key in self._table_param_fields():
            row = int(self.tbl_params.rowCount())
            self.tbl_params.insertRow(row)
            self._param_row_by_key[key] = row

            key_item = QtWidgets.QTableWidgetItem(key)
            key_item.setFlags(key_item.flags() & ~QtCore.Qt.ItemFlag.ItemIsEditable)
            val_item = QtWidgets.QTableWidgetItem("-")
            val_item.setFlags(val_item.flags() & ~QtCore.Qt.ItemFlag.ItemIsEditable)

            self.tbl_params.setItem(row, 0, key_item)
            self.tbl_params.setItem(row, 1, val_item)

    def _set_param_value(self, key: str, value: object) -> None:
        k = str(key).strip()
        if not k:
            return
        v = str(value).strip()
        if not v:
            v = "-"
        row = self._param_row_by_key.get(k)
        if row is None:
            return

        val_item = self.tbl_params.item(row, 1)
        if val_item is None:
            val_item = QtWidgets.QTableWidgetItem("")
            val_item.setFlags(val_item.flags() & ~QtCore.Qt.ItemFlag.ItemIsEditable)
            self.tbl_params.setItem(row, 1, val_item)
        val_item.setText(v)

    @staticmethod
    def _latest_buffer_component_value(
        dev: EmgsDevice,
        buffer_name: str,
        value_index: int,
    ) -> tuple[float, str] | None:
        buf = getattr(dev, buffer_name, None)
        if not buf:
            return None
        try:
            t_rel, values = buf[-1]
            if values is None or len(values) <= value_index:
                return None
            value = float(values[value_index])
        except Exception:
            return None
        if not math.isfinite(value):
            return None
        if float(value).is_integer():
            return float(t_rel), str(int(value))
        return float(t_rel), f"{value:g}"

    def _update_telem_param_values_from_device(self) -> None:
        dev = self._controller.manager.devices.get(self._address)
        if dev is None:
            return
        for key, sources in self._TELEM_BUFFER_SOURCES.items():
            best_ts = float("-inf")
            best_val: str | None = None
            for buffer_name, value_index in sources:
                sample = self._latest_buffer_component_value(dev, buffer_name, value_index)
                if sample is None:
                    continue
                ts, val = sample
                if ts >= best_ts:
                    best_ts = ts
                    best_val = val
            if best_val is not None:
                self._set_param_value(key, best_val)

    @QtCore.pyqtSlot(str, str)
    def _on_akr_line(self, addr: str, line: str) -> None:
        if str(addr) != str(self._address):
            return
        self._rx_any = True
        self._append(f"RX> {line}")
        self._maybe_parse_show_line(str(line))
        self._update_telem_param_values_from_device()

    @QtCore.pyqtSlot(str)
    def _on_device_updated(self, addr: str) -> None:
        if str(addr) != str(self._address):
            return
        self._refresh_connect_button()
        self._refresh_record_buttons()
        self._update_telem_param_values_from_device()

    def _refresh_connect_button(self) -> None:
        dev = self._controller.manager.devices.get(self._address)
        connected = bool(dev and dev.is_connected)
        self.btn_connect.setEnabled(not connected)
        self.btn_connect.setText("Connected" if connected else "Connect")

    def _signals_owner(self) -> object | None:
        p = self.parentWidget()
        while p is not None:
            if hasattr(p, "_signals_start_record") and hasattr(p, "_signals_stop_record"):
                return p
            p = p.parentWidget()
        return None

    def _refresh_record_buttons(self) -> None:
        owner = self._signals_owner()
        any_streaming = any(bool(d and d.is_streaming) for d in self._controller.manager.devices.values())
        recording = bool(getattr(owner, "_recording", False)) if owner is not None else False
        self.btn_record_start.setEnabled(owner is not None and any_streaming and not recording)
        self.btn_record_stop.setEnabled(owner is not None and recording)

    def _start_record_shortcut(self) -> None:
        owner = self._signals_owner()
        if owner is None:
            self._append("UI> Record shortcut unavailable (Signals owner not found)")
            return
        try:
            owner._signals_start_record()
        except Exception as exc:
            self._append(f"UI> failed to start record: {exc}")
        self._refresh_record_buttons()

    def _stop_record_shortcut(self) -> None:
        owner = self._signals_owner()
        if owner is None:
            self._append("UI> Record shortcut unavailable (Signals owner not found)")
            return
        try:
            owner._signals_stop_record()
        except Exception as exc:
            self._append(f"UI> failed to stop record: {exc}")
        self._refresh_record_buttons()

    def _connect_one(self) -> None:
        dev = self._controller.manager.devices.get(self._address)
        if dev and dev.is_connected:
            self._append("UI> already connected")
            self._refresh_connect_button()
            return
        self._append(f"UI> connect {self._address}")
        self._controller.connect_many([self._address])

    def _maybe_parse_show_line(self, line: str) -> None:
        """Parse AKR CLI feedback lines and update relevant status rows."""
        s = str(line).strip()
        if not s or s == ">":
            return
        compact = s.replace(" ", "")
        compact_lower = compact.lower()

        # Keep fw value with spaces intact (`fw=<name> v<version>` / `Robot Firmware=<name> v<version>`).
        if compact_lower.startswith("fw=") or compact_lower.startswith("robotfirmware="):
            payload = s.split("=", 1)[1].strip()
            fw_name = payload
            fw_version = ""
            if " v" in payload:
                fw_name, fw_version = payload.rsplit(" v", 1)
            self._set_param_value("fw_name", fw_name)
            if fw_version:
                self._set_param_value("fw_version_str", fw_version)
            return

        if compact_lower.startswith("side="):
            side = s.split("=", 1)[1].strip().lower()
            if side in {"left", "1", "true", "yes"}:
                self._set_param_value("is_left", "true")
            elif side in {"right", "0", "false", "no"}:
                self._set_param_value("is_left", "false")
            else:
                self._set_param_value("is_left", side)
            return

        if s.lower().startswith("work mode") and "=" in s:
            self._set_param_value("mode", s.split("=", 1)[1].strip())
            return

        if compact_lower.startswith("rr_akr_flag="):
            values = {k.lower(): v for k, v in self._split_kv_tokens(s).items()}
            if "rr_akr_flag" in values:
                self._set_param_value("rr_akr_flag", values["rr_akr_flag"])
            if "rr_cpm_flag" in values:
                self._set_param_value("rr_cpm_flag", values["rr_cpm_flag"])
            if "rr_test_flag" in values:
                self._set_param_value("rr_test_flag", values["rr_test_flag"])
            return

        if s.startswith("DF:"):
            values = self._split_kv_tokens(s.replace("DF:", "", 1))
            try:
                if "torque" in values:
                    self.df_torque.setValue(float(values["torque"]))
                if "angle" in values:
                    self.df_angle.setValue(float(values["angle"]))
                if "speed" in values:
                    self.df_speed.setValue(float(values["speed"]))
                if "kp" in values:
                    self.df_kp.setValue(float(values["kp"]))
                if "kd" in values:
                    self.df_kd.setValue(float(values["kd"]))
            except Exception:
                pass
            return

        if s.startswith("PF:"):
            values = self._split_kv_tokens(s.replace("PF:", "", 1))
            try:
                if "torque" in values:
                    self.pf_torque.setValue(float(values["torque"]))
                if "angle" in values:
                    self.pf_angle.setValue(float(values["angle"]))
                if "speed" in values:
                    self.pf_speed.setValue(float(values["speed"]))
                if "kp" in values:
                    self.pf_kp.setValue(float(values["kp"]))
                if "kd" in values:
                    self.pf_kd.setValue(float(values["kd"]))
            except Exception:
                pass
            return

        if s.startswith("CPM:"):
            values = self._split_kv_tokens(s.replace("CPM:", "", 1))
            try:
                if "df_deg" in values:
                    self.cpm_df_deg.setValue(float(values["df_deg"]))
                if "pf_deg" in values:
                    self.cpm_pf_deg.setValue(float(values["pf_deg"]))
                if "speed_df" in values:
                    self.cpm_speed_df.setValue(float(values["speed_df"]))
                if "speed_pf" in values:
                    self.cpm_speed_pf.setValue(float(values["speed_pf"]))
                if "wait_df_ms" in values:
                    self.cpm_wait_df_ms.setValue(int(float(values["wait_df_ms"])))
                if "wait_pf_ms" in values:
                    self.cpm_wait_pf_ms.setValue(int(float(values["wait_pf_ms"])))
            except Exception:
                pass
            return

        if compact_lower.startswith("motor_connected="):
            values = {k.lower(): v for k, v in self._split_kv_tokens(s).items()}
            if "motor_connected" in values:
                mc = str(values["motor_connected"]).strip().lower()
                if mc in {"yes", "1", "true"}:
                    self._set_param_value("motor_connected", "true")
                elif mc in {"no", "0", "false"}:
                    self._set_param_value("motor_connected", "false")
                else:
                    self._set_param_value("motor_connected", values["motor_connected"])
            if "can_id" in values:
                self._set_param_value("motor_can_id", values["can_id"])
            if "pattern" in values:
                self._set_param_value("motor_pattern", values["pattern"])
            if "err" in values:
                self._set_param_value("motor_error_code", values["err"])
            if "fault_err" in values:
                self._set_param_value("motor_fault_error_code", values["fault_err"])
            if "motor_feedback_age_ms" in values:
                self._set_param_value("motor_feedback_age_ms", values["motor_feedback_age_ms"])
            return

        if compact_lower.startswith("motor_feedback_age_ms="):
            self._set_param_value("motor_feedback_age_ms", s.split("=", 1)[1].strip())
            return

        if s.startswith("Motor Status:"):
            values = {k.lower(): v for k, v in self._split_kv_tokens(s).items()}
            if "mech_pos_rad" in values:
                self._set_param_value("mech_position_rad", values["mech_pos_rad"])
            if "speed_rad_s" in values:
                self._set_param_value("speed_rad_s", values["speed_rad_s"])
            if "torque_nm" in values:
                self._set_param_value("torque_nm", values["torque_nm"])
            if "temp_c" in values:
                self._set_param_value("temp_c", values["temp_c"])
            if "vbus_v" in values:
                self._set_param_value("vbus_v", values["vbus_v"])
            if "vbus_age_ms" in values:
                self._set_param_value("vbus_age_ms", values["vbus_age_ms"])
            if "motor_mode_0x7005" in values:
                self._set_param_value("motor_mode_0x7005", values["motor_mode_0x7005"])
            return

        if compact_lower.startswith("motor_mode_0x7005="):
            self._set_param_value("motor_mode_0x7005", s.split("=", 1)[1].strip())
            return

        if compact_lower.startswith("zero_sta="):
            values = self._split_kv_tokens(s)
            if "zero_sta" in values:
                self._set_param_value("zero_sta", values["zero_sta"])
            if "zero_pos_rad" in values:
                self._set_param_value("zero_position_rad", values["zero_pos_rad"])
            if "mech_pos_rad" in values:
                self._set_param_value("mech_position_rad", values["mech_pos_rad"])
            if "speed_rad_s" in values:
                self._set_param_value("speed_rad_s", values["speed_rad_s"])
            if "torque_nm" in values:
                self._set_param_value("torque_nm", values["torque_nm"])
            if "temp_c" in values:
                self._set_param_value("temp_c", values["temp_c"])
            return

        if compact_lower.startswith("can_find="):
            values = {k.lower(): v for k, v in self._split_kv_tokens(s).items()}
            state = values.get("can_find")
            if state is not None:
                self._set_param_value("can_find_active", "true" if state.upper() == "ACTIVE" else "false")
            if "elapsed_ms" in values:
                self._set_param_value("can_find_elapsed_ms", values["elapsed_ms"])
            elif str(state or "").upper() != "ACTIVE":
                self._set_param_value("can_find_elapsed_ms", "-")
            return

        def _set_rad_from_deg_token(dst: str, raw_deg: str | None) -> None:
            if raw_deg is None:
                return
            txt = str(raw_deg).strip()
            if not txt or txt.upper() == "NA":
                self._set_param_value(dst, "-")
                return
            try:
                self._set_param_value(dst, f"{math.radians(float(txt)):g}")
            except Exception:
                self._set_param_value(dst, txt)

        if compact_lower.startswith("prom_df_end="):
            _set_rad_from_deg_token("prom_df_end_rad", s.split("=", 1)[1].strip())
            return
        if compact_lower.startswith("prom_pf_end="):
            _set_rad_from_deg_token("prom_pf_end_rad", s.split("=", 1)[1].strip())
            return
        if compact_lower.startswith("arom_df_max="):
            _set_rad_from_deg_token("arom_df_max_rad", s.split("=", 1)[1].strip())
            return
        if compact_lower.startswith("arom_pf_min="):
            _set_rad_from_deg_token("arom_pf_min_rad", s.split("=", 1)[1].strip())
            return

        if s.startswith("MEASURE event:") or s.startswith("MEASURE:") or s.startswith("TEST event:") or s.startswith("TEST:"):
            blocked = self._token_value(s, "blocked")
            if blocked is not None:
                self._set_param_value("blocked", blocked)

            end_deg = self._token_value(s, "end_deg")
            if end_deg is not None and "PROM DF" in s:
                _set_rad_from_deg_token("prom_df_end_rad", end_deg)
            if end_deg is not None and "PROM PF" in s:
                _set_rad_from_deg_token("prom_pf_end_rad", end_deg)

            df_max = self._token_value(s, "df_max_deg")
            if df_max is not None:
                _set_rad_from_deg_token("arom_df_max_rad", df_max)
            pf_min = self._token_value(s, "pf_min_deg")
            if pf_min is not None:
                _set_rad_from_deg_token("arom_pf_min_rad", pf_min)
            return


#
# RSSI display intentionally removed for stability on Linux/Python 3.13 BLE stack.
#

