"""Central configuration for the rewrite.

Keep constants here so the rest of the code stays readable.
"""

from __future__ import annotations

from . import __version__

APP_TITLE = f"RR_APP v{__version__}"

# Primary development OS ordering: macOS > Linux > Windows

# UI
PLOT_REFRESH_MS = 50
# BLE scan duration (seconds).
# 1.5s was often too short for some AKR devices to show up reliably.
SCAN_TIMEOUT_S = 2.0
# When a scan returns no devices, automatically retry this many times.
SCAN_EMPTY_RETRY_COUNT = 3
UI_DEVICE_UPDATE_MIN_INTERVAL_S = 0.15  # throttle UI refreshes from high-rate notifications
DEVICE_POLL_INTERVAL_S = 2.0            # periodic lightweight poll for connected devices (seconds)
CLOCK_DRIFT_WARN_MS = 2000             # show clock delta warning if |delta| exceeds this (ms)
DEVICE_FULL_UPDATE_INTERVAL_S = 30.0   # slow cadence "all info" refresh for connected devices (seconds)
DEVICE_UNSTABLE_TIMEOUT_S = 3.5        # mark connected device "Unstable" if no RX seen for this long

# Ring buffers (tuned once real frame rates are confirmed)
RING_BUFFER_SECONDS = 10
EMG_SAMPLE_RATE_HZ = 1000  # placeholder until confirmed
IMU_SAMPLE_RATE_HZ = 100   # placeholder until confirmed

EMG_RING_LEN = EMG_SAMPLE_RATE_HZ * RING_BUFFER_SECONDS
IMU_RING_LEN = IMU_SAMPLE_RATE_HZ * RING_BUFFER_SECONDS

# Device discovery
EMGS_NAME_PREFIX = "EMGS"
# Also discover other BLE devices that this app can connect to (Connect tab).
# Keep these as tuples for fast `startswith(...)` checks.
AKR_NAME_PREFIX = "AKR"
ENABLE_LEGACY_AKR_COMPAT_PREFIX = True
LEGACY_AKR_COMPAT_PREFIX = "BT"
AKR_NAME_PREFIXES = (AKR_NAME_PREFIX, LEGACY_AKR_COMPAT_PREFIX) if ENABLE_LEGACY_AKR_COMPAT_PREFIX else (AKR_NAME_PREFIX,)
DEVICE_NAME_PREFIXES = ("EMGS",) + AKR_NAME_PREFIXES

# Backend selection: "bleak" (default) or "sim"
DEFAULT_BACKEND = "bleak"

# EMG derived signals
# RMS envelope window (sample-count based).
# We compute RMS at the raw sample timestamps using the last N raw samples.
# This keeps the envelope responsive and avoids effectively averaging over the whole ring buffer.
EMG_RMS_WINDOW_N = 100

# Spectral features (MDF/MNF) window, in raw EMG samples.
# Default 1.0s at 1000 Hz.
EMG_SPEC_WINDOW_N = 1000

# Unsupervised fatigue score (heuristic, host-side; computed from MDF trend + RMS trend).
# These are defaults; the UI exposes them under Settings → Processed Data.
EMG_FATIGUE_ENABLE_DEFAULT = False
EMG_FATIGUE_BASELINE_S = 10.0
# Weights are expressed as percentages and normalized internally (sum doesn't need to be 100).
EMG_FATIGUE_WEIGHT_MDF_PCT = 70.0
EMG_FATIGUE_WEIGHT_RMS_PCT = 30.0
# Confidence is based on monotonicity of MDF over a recent window of feature updates.
EMG_FATIGUE_CONF_RECENT_N = 60

# Legacy (older time-based RMS envelope). Kept for reference / backwards compatibility,
# but the rewrite currently uses EMG_RMS_WINDOW_N.
EMG_RMS_WINDOW_S = 0.050
# EMG ADC-to-physical conversion (used for both raw EMG and packet RMS).
# Convert uint16 ADC code -> mV equivalent using:
#   emg_mV = ((r/EMG_ADC_MAX)*EMG_ADC_FULL_SCALE_V - EMG_ADC_MID_V) / EMG_GAIN_V_PER_V * EMG_OUTPUT_SCALE
EMG_ADC_MAX = 65535.0
EMG_ADC_FULL_SCALE_V = 3.0
EMG_ADC_MID_V = 1.5
EMG_GAIN_V_PER_V = 1200.0
EMG_OUTPUT_SCALE = 1000.0

# Recording (UI defaults)
DEFAULT_REC_OUT_DIRNAME = "rr_data"  # created under user home unless overridden

REC_EMG_FIELDS_ALL: tuple[str, ...] = (
    "emg_raw_mV",
    "emg_env_rms",
    "emg_mdf_hz",
    "emg_mnf_hz",
    "emg_pkt_rms_v",
    "emg_snr",
    "fatigue_score",
    "fatigue_conf",
)

_REC_AXES3: tuple[str, str, str] = ("x", "y", "z")
_REC_QUAT: tuple[str, str, str, str] = ("w", "x", "y", "z")
REC_IMU_FIELDS_ALL: tuple[str, ...] = tuple(
    [f"raw_acc_{a}" for a in _REC_AXES3]
    + [f"acc_{a}" for a in _REC_AXES3]
    + [f"lin_acc_{a}" for a in _REC_AXES3]
    + [f"raw_gyr_{a}" for a in _REC_AXES3]
    + [f"gyr_{a}" for a in _REC_AXES3]
    + [f"uncal_mag_{a}" for a in _REC_AXES3]
    + [f"mag_{a}" for a in _REC_AXES3]
    + [f"quat_game_{a}" for a in _REC_QUAT]
    + [f"quat_geomag_{a}" for a in _REC_QUAT]
)

REC_ROBOT_FIELDS_ALL: tuple[str, ...] = tuple(
    # Binary rr_telem fields (Walk/AKR)
    [
        "walk_fid",
        "walk_dt_ms",
        "walk_exec_ms",
        "walk_out",
        "walk_state",
        "walk_pos_rad",
        "walk_vel_rad_s",
        "walk_tq_nm",
        "walk_temp_c",
        "walk_vbus_v",
        "walk_pattern",
        "walk_err_code",
        "walk_fb_age_ms",
    ]
    + [f"walk_acc_{a}" for a in _REC_AXES3]
    + [f"walk_gyr_{a}" for a in _REC_AXES3]
    + [f"walk_mag_{a}" for a in _REC_AXES3]
    # Binary rr_telem fields (CPM)
    + [
        "cpm_fid",
        "cpm_dt_ms",
        "cpm_state",
        "cpm_dir",
        "cpm_blocked_event",
        "cpm_blocked_consecutive",
        "cpm_cmd_spd_rad_s",
        "cpm_pos_rad",
        "cpm_vel_rad_s",
        "cpm_tq_nm",
        "cpm_temp_c",
        "cpm_vbus_v",
        "cpm_pattern",
        "cpm_err_code",
        "cpm_fb_age_ms",
        "cpm_df_limit_rad",
        "cpm_pf_limit_rad",
        "cpm_elapsed_s",
        "cpm_repetition_count",
    ]
    # Binary rr_telem fields (MEASURE)
    + [
        "measure_fid",
        "measure_dt_ms",
        "measure_state",
        "measure_dir",
        "measure_blocked",
        "measure_result_flags",
        "measure_pos_rad",
        "measure_vel_rad_s",
        "measure_tq_nm",
        "measure_temp_c",
        "measure_vbus_v",
        "measure_pattern",
        "measure_err_code",
        "measure_fb_age_ms",
        "measure_prom_df_end_rad",
        "measure_prom_pf_end_rad",
        "measure_arom_df_max_rad",
        "measure_arom_pf_min_rad",
        "measure_flag_prom_df_valid",
        "measure_flag_prom_pf_valid",
        "measure_flag_arom_valid",
        "measure_flag_seq_active",
        "measure_flag_arom_running",
    ]
)
