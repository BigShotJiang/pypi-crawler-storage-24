from __future__ import annotations

from collections.abc import Iterable, Mapping
import logging
import os
from typing import Any, cast

from PyQt6 import QtCore
import qasync

from . import config
from .ble.backend import create_backend
from .ble.manager import EmgsManager


logger = logging.getLogger(__name__)


def _coerce_iterable(value: object) -> list[Any]:
    """Best-effort conversion for Qt 'object' slot args.

    Qt signals frequently pass container-ish values as `object`. We defensively
    accept common iterables but avoid treating strings/bytes/dicts as sequences
    of items.
    """
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return list(value)
    if isinstance(value, (str, bytes, bytearray, dict)):
        return []
    if isinstance(value, Iterable):
        try:
            return list(value)
        except Exception:
            return []
    return []


class EmgsController(QtCore.QObject):
    """Qt-facing controller around the async BLE manager."""

    signal_log = QtCore.pyqtSignal(str)
    signal_device_updated = QtCore.pyqtSignal(str)   # address
    signal_device_list_changed = QtCore.pyqtSignal() # structure changed (scan)
    signal_akr_line = QtCore.pyqtSignal(str, str)     # (address, line)

    def __init__(self, backend_kind: str | None = None) -> None:
        super().__init__()
        kind = backend_kind or os.environ.get("EMGS_BACKEND") or config.DEFAULT_BACKEND
        self._backend_kind = kind
        self.manager = EmgsManager(
            backend=create_backend(kind),
            on_log=self._on_log,
            on_device_updated=self._on_device_updated,
            on_akr_line=self._on_akr_line,
        )

    @property
    def backend_kind(self) -> str:
        return self._backend_kind

    def _on_log(self, msg: str) -> None:
        self.signal_log.emit(msg)

    def _on_device_updated(self, addr: str) -> None:
        self.signal_device_updated.emit(addr)

    def _on_akr_line(self, addr: str, line: str) -> None:
        self.signal_akr_line.emit(str(addr), str(line))

    @qasync.asyncSlot()
    async def scan(self) -> None:
        before = set(self.manager.devices.keys())
        await self.manager.scan(timeout_s=config.SCAN_TIMEOUT_S)
        after = set(self.manager.devices.keys())
        if before != after:
            self.signal_device_list_changed.emit()

    @qasync.asyncSlot()
    async def shutdown(self) -> None:
        await self.manager.shutdown()

    @qasync.asyncSlot(list)
    async def connect_many(self, addresses: list[str]) -> None:
        await self.manager.connect_many(addresses)

    @qasync.asyncSlot(list)
    async def disconnect_many(self, addresses: list[str]) -> None:
        await self.manager.disconnect_many(addresses)

    @qasync.asyncSlot(list)
    async def update_many(self, addresses: list[str]) -> None:
        await self.manager.update_many(addresses)

    @qasync.asyncSlot(list)
    async def poll_many(self, addresses: list[str]) -> None:
        await self.manager.poll_many(addresses)

    @QtCore.pyqtSlot(list)
    def check_health_many(self, addresses: list[str]) -> None:
        """Local health check (no BLE traffic)."""
        self.manager.check_health_many(addresses)

    @QtCore.pyqtSlot(list)
    def reset_processed_state_many(self, addresses: list[str]) -> None:
        """Reset host-side processed buffers/state (no BLE traffic)."""
        self.manager.reset_processed_state_many(addresses)

    @qasync.asyncSlot(list, bool)
    async def stream_many(self, addresses: list[str], enable: bool) -> None:
        await self.manager.stream_many(addresses, enable=enable)

    @qasync.asyncSlot(list)
    async def set_table_selected_devices(self, addresses: list[str]) -> None:
        """UI selection → device indicator LED (purple)."""
        await self.manager.set_table_selected_devices(addresses)

    @qasync.asyncSlot(list)
    async def set_signals_selected_devices(self, addresses: list[str]) -> None:
        """Signals-page selection → device indicator LED (purple)."""
        await self.manager.set_signals_selected_devices(addresses)

    @qasync.asyncSlot(str)
    async def identify_device(self, address: str) -> None:
        """Temporarily light a device to help identify it (works while streaming)."""
        await self.manager.identify_device(address, duration_s=2.0)

    @qasync.asyncSlot(str)
    async def time_sync_one(self, address: str) -> None:
        await self.manager.set_timestamp_now(address)

    @qasync.asyncSlot(str, str)
    async def akr_send_line(self, address: str, line: str) -> None:
        await self.manager.akr_send_line(address, line)

    @qasync.asyncSlot(str, str, int, int, object, int)
    async def apply_settings(
        self,
        address: str,
        ble_name: str,
        conn_interval_min: int,
        conn_interval_max: int,
        icm_enabled: object,
        emg_mode: int,
    ) -> None:
        await self.manager.apply_settings(
            address,
            ble_name=ble_name,
            conn_interval_min=conn_interval_min,
            conn_interval_max=conn_interval_max,
            icm_enabled=[bool(v) for v in _coerce_iterable(icm_enabled)],
            emg_mode=emg_mode,
        )
        # Refresh after apply (best-effort)
        await self.manager.update_one(address)

    @qasync.asyncSlot(str, object)
    async def apply_settings_dict(self, address: str, settings: object) -> None:
        """Apply a flexible settings dict from the UI (forward-compatible)."""
        if isinstance(settings, Mapping):
            s: dict[str, Any] = dict(settings)
        else:
            # Best-effort for list-of-tuples / QVariantMap-like objects.
            try:
                s = dict(cast(Iterable[tuple[Any, Any]], settings))
            except Exception:
                s = {}

        await self.manager.apply_settings(
            address,
            ble_name=s.get("ble_name"),
            conn_interval_min=s.get("conn_min"),
            conn_interval_max=s.get("conn_max"),
            icm_enabled=s.get("icm_enabled"),
            emg_mode=s.get("emg_mode"),
        )
        if "emg_threshold" in s and s["emg_threshold"] is not None:
            await self.manager.set_emg_threshold(address, int(s["emg_threshold"]))
        if "power_safe_lvl" in s and s["power_safe_lvl"] is not None:
            await self.manager.set_power_safe_level(address, int(s["power_safe_lvl"]))
        if "storage_threshold" in s and s["storage_threshold"] is not None:
            await self.manager.set_storage_threshold(address, int(s["storage_threshold"]))

        # Optional ICM freq/scale maps
        icm_freq = s.get("icm_freq") or {}
        if isinstance(icm_freq, Mapping):
            for sensor_type, freq in icm_freq.items():
                await self.manager.set_icm_freq(address, int(sensor_type), int(freq))
        icm_scale = s.get("icm_scale") or {}
        if isinstance(icm_scale, Mapping):
            for sensor_type, scale in icm_scale.items():
                await self.manager.set_icm_scale(address, int(sensor_type), int(scale))
        if s.get("icm_bias") is not None:
            b = s["icm_bias"]
            if isinstance(b, Mapping):
                acc = list(b.get("acc") or [])
                gyr = list(b.get("gyr") or [])
                mag = list(b.get("mag") or [])
                await self.manager.set_icm_bias(address, acc, gyr, mag)
        if "icm_auto_save_bias" in s and s["icm_auto_save_bias"] is not None:
            await self.manager.set_icm_auto_save_bias(address, bool(s["icm_auto_save_bias"]))

        await self.manager.update_one(address)

    @qasync.asyncSlot(list, object, int)
    async def apply_modes_many(self, addresses: list[str], icm_enabled: object, emg_mode: int) -> None:
        """Apply mode settings (ACC/GYR/MAG/QUAT/EMG) to multiple devices."""
        await self.manager.apply_modes_many(
            addresses,
            icm_enabled=[bool(v) for v in _coerce_iterable(icm_enabled)],
            emg_mode=int(emg_mode),
        )
