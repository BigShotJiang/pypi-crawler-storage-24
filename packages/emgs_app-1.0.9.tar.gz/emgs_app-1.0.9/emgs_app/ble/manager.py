from __future__ import annotations

import asyncio
import logging
import os
import re
from dataclasses import dataclass, field
from typing import Callable, Optional

from .. import config
from .backend import Backend, DiscoveredDevice
from .device import DeviceParams, EmgsDevice
from . import protocol
from . import akr_protocol
import struct
import time


logger = logging.getLogger(__name__)

LogFn = Callable[[str], None]
UpdateFn = Callable[[str], None]  # device address updated
AkrLineFn = Callable[[str, str], None]  # (address, line)

_RE_RR_AKR = re.compile(
    r"RR_AKR\s+"
    r".*?step_dt=(?P<step_dt>-?\d+)\s*ms"
    r".*?exec=(?P<exec>-?\d+)\s*ms"
    r".*?out=(?P<out>-?\d+)"
    r".*?state=(?P<state>-?\d+)"
    r".*?acc=\[(?P<accx>[+\-0-9.]+)\s+(?P<accy>[+\-0-9.]+)\s+(?P<accz>[+\-0-9.]+)\]"
    r".*?gyr=\[(?P<gyrx>[+\-0-9.]+)\s+(?P<gyry>[+\-0-9.]+)\s+(?P<gyrz>[+\-0-9.]+)\]"
    r".*?mag=\[(?P<magx>[+\-0-9.]+)\s+(?P<magy>[+\-0-9.]+)\s+(?P<magz>[+\-0-9.]+)\]"
)


@dataclass(slots=True)
class EmgsManager:
    backend: Backend
    on_log: Optional[LogFn] = None
    on_device_updated: Optional[UpdateFn] = None
    on_akr_line: Optional[AkrLineFn] = None

    devices: dict[str, EmgsDevice] = field(default_factory=dict)

    # Internal state (must be declared because dataclass(slots=True) has no __dict__)
    _shutting_down: bool = False
    _debug_rx: bool = False
    _debug_rx_hex: bool = False
    _debug_cmd: bool = False
    _debug_cmd_hex: bool = False
    _rx_stats: dict[str, dict[str, int]] = field(default_factory=dict)
    _rx_last_log_s: dict[str, float] = field(default_factory=dict)
    _rx_last_hex_s: dict[str, float] = field(default_factory=dict)
    _ui_last_emit_s: dict[str, float] = field(default_factory=dict)
    _last_time_sync_send_ms: dict[str, int] = field(default_factory=dict)
    _last_get_ts_send_ms: dict[str, int] = field(default_factory=dict)
    _akr_rx_buf: dict[str, str] = field(default_factory=dict)  # addr -> partial line buffer
    _akr_rx_bin: dict[str, bytearray] = field(default_factory=dict)  # addr -> binary stream buffer (rr_telem framing)
    # Host-side processing configuration (applies on next stream start).
    proc_enable_emg_rms_envelope_next: bool = False
    proc_emg_rms_window_n_next: int = config.EMG_RMS_WINDOW_N
    proc_enable_emg_freq_features_next: bool = False
    proc_emg_spec_window_n_next: int = config.EMG_SPEC_WINDOW_N
    proc_enable_emg_fatigue_next: bool = config.EMG_FATIGUE_ENABLE_DEFAULT
    proc_emg_fatigue_baseline_s_next: float = config.EMG_FATIGUE_BASELINE_S
    proc_emg_fatigue_weight_mdf_pct_next: float = config.EMG_FATIGUE_WEIGHT_MDF_PCT
    proc_emg_fatigue_weight_rms_pct_next: float = config.EMG_FATIGUE_WEIGHT_RMS_PCT
    proc_emg_fatigue_conf_recent_n_next: int = config.EMG_FATIGUE_CONF_RECENT_N
    # Indicator LED UX state (purely for UI affordances like "selected rows").
    _led_state: dict[str, str] = field(default_factory=dict)        # last applied state (e.g. 'purple','off')
    _led_last_ts_s: dict[str, float] = field(default_factory=dict)  # last LED write timestamp (monotonic seconds)
    _led_min_interval_s: float = 0.15                               # minimum seconds between 'purple' writes per device
    _ui_selected_addrs_by_source: dict[str, set[str]] = field(
        default_factory=lambda: {"table": set(), "signals": set(), "identify": set()}
    )
    _led_prev_before_select: dict[str, str] = field(default_factory=dict)  # addr -> prior state before selection override
    _led_override_active: set[str] = field(default_factory=set)            # addr where we've actually applied purple override
    _identify_token: dict[str, float] = field(default_factory=dict)         # addr -> token to cancel stale identify timers
    _selection_led_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    def __post_init__(self) -> None:
        # RX diagnostics / UI throttling (env-controlled)
        self._debug_rx = os.environ.get("EMGS_DEBUG_RX", "").strip().lower() in {"1", "true", "yes"}
        self._debug_rx_hex = os.environ.get("EMGS_DEBUG_RX_HEX", "").strip().lower() in {"1", "true", "yes"}
        self._debug_cmd = os.environ.get("EMGS_DEBUG_CMD", "").strip().lower() in {"1", "true", "yes"}
        self._debug_cmd_hex = os.environ.get("EMGS_DEBUG_CMD_HEX", "").strip().lower() in {"1", "true", "yes"}

    def _log(self, msg: str) -> None:
        logger.info("%s", msg)
        if self.on_log:
            self.on_log(msg)

    def _notify_updated(self, addr: str) -> None:
        if self.on_device_updated:
            self.on_device_updated(addr)

    def _emit_akr_line(self, addr: str, line: str) -> None:
        if self.on_akr_line:
            try:
                self.on_akr_line(str(addr), str(line))
            except Exception:
                pass

    def _emit_akr_text_line(self, address: str, line: str) -> None:
        """Emit one decoded AKR text line and feed line-level parsers.

        AKR UART streams often carry a shell-like prompt (`> `) without a newline.
        Some firmware builds also concatenate prompt + payload in one chunk.
        Split leading prompts safely, but never drop non-prompt text.
        """
        s = str(line).replace("\x00", "")
        if not s:
            return

        while True:
            stripped = s.strip()
            if stripped == ">":
                self._emit_akr_line(address, ">")
                return
            if s.startswith("> "):
                self._emit_akr_line(address, ">")
                s = s[2:]
                if not s:
                    return
                continue
            break

        self._emit_akr_line(address, s)
        self._akr_maybe_parse_runtime_status_line(address, s)
        self._akr_maybe_parse_rr_akr_line(address, s)

    def _akr_maybe_parse_runtime_status_line(self, address: str, line: str) -> None:
        """Parse selected AKR CLI status lines into device params (best-effort)."""
        dev = self.devices.get(address)
        if not dev:
            return
        s = str(line).strip()
        if not s or s == ">":
            return

        # `show` output can be either "Work Mode=<name>" or "Work Mode = <name>".
        # Accept both forms to stay compatible across firmware revisions.
        if s.lower().startswith("work mode") and "=" in s:
            mode = s.split("=", 1)[1].strip()
            if mode:
                mode_new = str(mode)
                if str(getattr(dev.params, "mode", "")) != mode_new:
                    dev.params.mode = mode_new
                    self._notify_updated(address)
            return

    def _handle_akr_rx_text_bytes(self, address: str, data: bytes) -> None:
        """Handle AKR UART-like *text* RX bytes (CLI prints, logs, etc.)."""
        try:
            chunk = bytes(data).decode("utf-8", errors="replace")
        except Exception:
            chunk = ""
        if not chunk:
            return
        chunk = chunk.replace("\r\n", "\n").replace("\r", "\n")
        buf = self._akr_rx_buf.get(address, "")
        buf += chunk
        lines = buf.split("\n")
        for line in lines[:-1]:
            self._emit_akr_text_line(address, line)
        rem = lines[-1]
        # STM32 CLI prints a prompt as "> " without newline.
        # Only consume prompt-only remnants; don't drop arbitrary text that
        # happens to end with "> ".
        if rem.strip() == ">":
            self._emit_akr_line(address, ">")
            rem = ""
        elif rem.startswith("> "):
            self._emit_akr_line(address, ">")
            rem = rem[2:]
        self._akr_rx_buf[address] = rem

    @staticmethod
    def _crc16_ccitt_false(data: bytes, *, init: int = 0xFFFF) -> int:
        """CRC-16/CCITT-FALSE (poly=0x1021 init=0xFFFF refin/refout=false)."""
        crc = int(init) & 0xFFFF
        for b in data:
            crc ^= (int(b) & 0xFF) << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = ((crc << 1) ^ 0x1021) & 0xFFFF
                else:
                    crc = (crc << 1) & 0xFFFF
        return crc & 0xFFFF

    def _akr_parse_telem_frames(self, address: str) -> None:
        """Parse rr_telem framed binary telemetry into numeric buffers.

        See `backup/akr_code_v7/Bsp/rr_telem.{h,c}` for the authoritative framing.
        """
        dev = self.devices.get(address)
        if not dev:
            return
        enabled = bool(getattr(dev, "is_streaming", False))
        buf = self._akr_rx_bin.setdefault(address, bytearray())
        if not buf:
            return

        SYNC = b"\xA5\x5A"
        VER = 0x01
        TYPE_WALK = 0x01  # AKR
        TYPE_CPM = 0x02
        TYPE_TEST = 0x03

        # Scale factors (match rr_telem.h)
        RAD_SCALE = 1000.0
        RAD_S_SCALE = 1000.0
        NM_SCALE = 1000.0
        TEMP_C_SCALE = 10.0
        IMU_SCALE = 100.0
        VBUS_V_SCALE = 100.0

        # Parse loop
        while True:
            i = buf.find(SYNC)
            if i < 0:
                # No full sync found.
                # BLE can split the two sync bytes across notifications, so if the buffer
                # ends with the first sync byte, keep it for the next chunk.
                if buf and buf[-1] == SYNC[0]:
                    prefix = bytes(buf[:-1])
                    if prefix:
                        self._handle_akr_rx_text_bytes(address, prefix)
                    buf[:] = bytearray([SYNC[0]])
                    return
                # Otherwise, treat remaining as text best-effort to avoid unbounded growth.
                if buf:
                    self._handle_akr_rx_text_bytes(address, bytes(buf))
                    buf.clear()
                return
            if i > 0:
                # Prefix before sync may be CLI text; emit it and drop.
                prefix = bytes(buf[:i])
                del buf[:i]
                if prefix:
                    self._handle_akr_rx_text_bytes(address, prefix)
                continue
            if len(buf) < 5:
                return

            ver = int(buf[2])
            pkt_type = int(buf[3])
            payload_len = int(buf[4])
            if ver != VER:
                # Bad version => resync by dropping one byte.
                del buf[:1]
                continue
            frame_len = 5 + payload_len + 2
            if len(buf) < frame_len:
                return

            frame = bytes(buf[:frame_len])
            # CRC over (ver..payload): frame[2 .. 4+payload_len]
            crc_expect = int(struct.unpack_from("<H", frame, 5 + payload_len)[0])
            crc_got = self._crc16_ccitt_false(frame[2 : 5 + payload_len])
            if crc_got != crc_expect:
                # Corrupt frame => resync by dropping sync0 only.
                del buf[:1]
                continue

            payload = frame[5 : 5 + payload_len]
            # Consume the frame only after successful validation.
            del buf[:frame_len]

            if not enabled:
                # Display/stream toggle off: still consume frames to avoid buffer growth,
                # but do not write into time-series buffers.
                continue

            now = time.monotonic()
            if getattr(dev, "akr_origin_monotonic_s", None) is None:
                dev.akr_origin_monotonic_s = float(now)
            t_rel = float(now) - float(dev.akr_origin_monotonic_s or now)

            try:
                if pkt_type == TYPE_WALK:
                    # v6 layout:
                    # <IHHbb + 13h + bBH + h(vbus)
                    fmt = "<IHHbb" + ("h" * 13) + "bBH" + "h"
                    if struct.calcsize(fmt) != payload_len:
                        continue
                    (
                        fid,
                        dt_ms,
                        exec_ms,
                        out_v,
                        state_v,
                        accx,
                        accy,
                        accz,
                        gyrx,
                        gyry,
                        gyrz,
                        magx,
                        magy,
                        magz,
                        pos_i,
                        vel_i,
                        tq_i,
                        temp_i,
                        pattern,
                        err_code,
                        fb_age_ms,
                        _vbus_i,
                    ) = struct.unpack_from(fmt, payload, 0)

                    acc = [float(accx) / IMU_SCALE, float(accy) / IMU_SCALE, float(accz) / IMU_SCALE]
                    gyr = [float(gyrx) / IMU_SCALE, float(gyry) / IMU_SCALE, float(gyrz) / IMU_SCALE]
                    mag = [float(magx) / IMU_SCALE, float(magy) / IMU_SCALE, float(magz) / IMU_SCALE]
                    pos_rad = float(pos_i) / RAD_SCALE
                    vel_rad_s = float(vel_i) / RAD_S_SCALE
                    tq_nm = float(tq_i) / NM_SCALE
                    temp_c = float(temp_i) / TEMP_C_SCALE
                    vbus_v = float(_vbus_i) / VBUS_V_SCALE

                    dev.akr_walk_fid_buffer.append((t_rel, [float(fid)]))
                    dev.akr_walk_dt_ms_buffer.append((t_rel, [float(dt_ms)]))
                    dev.akr_walk_exec_ms_buffer.append((t_rel, [float(exec_ms)]))
                    dev.akr_walk_out_buffer.append((t_rel, [float(out_v)]))
                    dev.akr_walk_state_buffer.append((t_rel, [float(state_v)]))
                    dev.akr_walk_acc_buffer.append((t_rel, list(acc)))
                    dev.akr_walk_gyr_buffer.append((t_rel, list(gyr)))
                    dev.akr_walk_mag_buffer.append((t_rel, list(mag)))
                    dev.akr_walk_pos_rad_buffer.append((t_rel, [float(pos_rad)]))
                    dev.akr_walk_vel_rad_s_buffer.append((t_rel, [float(vel_rad_s)]))
                    dev.akr_walk_tq_nm_buffer.append((t_rel, [float(tq_nm)]))
                    dev.akr_walk_temp_c_buffer.append((t_rel, [float(temp_c)]))
                    dev.akr_walk_vbus_v_buffer.append((t_rel, [float(vbus_v)]))
                    dev.akr_walk_pattern_buffer.append((t_rel, [float(pattern)]))
                    dev.akr_walk_err_code_buffer.append((t_rel, [float(err_code)]))
                    dev.akr_walk_fb_age_ms_buffer.append((t_rel, [float(fb_age_ms)]))

                    # Convenience: also expose as "calibrated" IMU buffers for existing plot/record paths.
                    dev.acc_buffer.append((t_rel, list(acc)))
                    dev.gyr_buffer.append((t_rel, list(gyr)))
                    dev.mag_buffer.append((t_rel, list(mag)))

                    dev.last_imu_time_s = float(now)
                    dev.imu_frames_total += 1

                elif pkt_type == TYPE_CPM:
                    # v7 layout:
                    # <IHBbBB + 5h + bBH + 2h + 2f + h(vbus)
                    fmt = "<IHBbBB" + ("h" * 5) + "bBH" + "hh" + "ff" + "h"
                    if struct.calcsize(fmt) != payload_len:
                        continue
                    (
                        fid,
                        dt_ms,
                        cpm_state,
                        dir_v,
                        blocked_event,
                        blocked_consecutive,
                        cmd_i,
                        pos_i,
                        vel_i,
                        tq_i,
                        temp_i,
                        pattern,
                        err_code,
                        fb_age_ms,
                        df_lim_i,
                        pf_lim_i,
                        elapsed_s,
                        repetition_count,
                        _vbus_i,
                    ) = struct.unpack_from(fmt, payload, 0)

                    cmd_spd = float(cmd_i) / RAD_S_SCALE
                    pos_rad = float(pos_i) / RAD_SCALE
                    vel_rad_s = float(vel_i) / RAD_S_SCALE
                    tq_nm = float(tq_i) / NM_SCALE
                    temp_c = float(temp_i) / TEMP_C_SCALE
                    vbus_v = float(_vbus_i) / VBUS_V_SCALE
                    df_lim = float(df_lim_i) / RAD_SCALE
                    pf_lim = float(pf_lim_i) / RAD_SCALE

                    dev.akr_cpm_fid_buffer.append((t_rel, [float(fid)]))
                    dev.akr_cpm_dt_ms_buffer.append((t_rel, [float(dt_ms)]))
                    dev.akr_cpm_state_buffer.append((t_rel, [float(cpm_state)]))
                    dev.akr_cpm_dir_buffer.append((t_rel, [float(dir_v)]))
                    dev.akr_cpm_blocked_event_buffer.append((t_rel, [float(blocked_event)]))
                    dev.akr_cpm_blocked_consecutive_buffer.append((t_rel, [float(blocked_consecutive)]))
                    dev.akr_cpm_cmd_spd_rad_s_buffer.append((t_rel, [float(cmd_spd)]))
                    dev.akr_cpm_pos_rad_buffer.append((t_rel, [float(pos_rad)]))
                    dev.akr_cpm_vel_rad_s_buffer.append((t_rel, [float(vel_rad_s)]))
                    dev.akr_cpm_tq_nm_buffer.append((t_rel, [float(tq_nm)]))
                    dev.akr_cpm_temp_c_buffer.append((t_rel, [float(temp_c)]))
                    dev.akr_cpm_vbus_v_buffer.append((t_rel, [float(vbus_v)]))
                    dev.akr_cpm_pattern_buffer.append((t_rel, [float(pattern)]))
                    dev.akr_cpm_err_code_buffer.append((t_rel, [float(err_code)]))
                    dev.akr_cpm_fb_age_ms_buffer.append((t_rel, [float(fb_age_ms)]))
                    dev.akr_cpm_df_limit_rad_buffer.append((t_rel, [float(df_lim)]))
                    dev.akr_cpm_pf_limit_rad_buffer.append((t_rel, [float(pf_lim)]))
                    dev.akr_cpm_elapsed_s_buffer.append((t_rel, [float(elapsed_s)]))
                    dev.akr_cpm_repetition_count_buffer.append((t_rel, [float(repetition_count)]))

                    # Treat as "robot" stream activity.
                    dev.last_imu_time_s = float(now)
                    dev.imu_frames_total += 1

                elif pkt_type == TYPE_TEST:
                    # v6 layout:
                    # <IHBbBB + 4h + bBH + 4h + h(vbus)
                    fmt = "<IHBbBB" + ("h" * 4) + "bBH" + ("h" * 4) + "h"
                    if struct.calcsize(fmt) != payload_len:
                        continue
                    (
                        fid,
                        dt_ms,
                        test_state,
                        dir_v,
                        blocked,
                        result_flags,
                        pos_i,
                        vel_i,
                        tq_i,
                        temp_i,
                        pattern,
                        err_code,
                        fb_age_ms,
                        prom_df_i,
                        prom_pf_i,
                        arom_df_i,
                        arom_pf_i,
                        _vbus_i,
                    ) = struct.unpack_from(fmt, payload, 0)

                    pos_rad = float(pos_i) / RAD_SCALE
                    vel_rad_s = float(vel_i) / RAD_S_SCALE
                    tq_nm = float(tq_i) / NM_SCALE
                    temp_c = float(temp_i) / TEMP_C_SCALE
                    vbus_v = float(_vbus_i) / VBUS_V_SCALE
                    prom_df_end_rad = float(prom_df_i) / RAD_SCALE
                    prom_pf_end_rad = float(prom_pf_i) / RAD_SCALE
                    arom_df_max_rad = float(arom_df_i) / RAD_SCALE
                    arom_pf_min_rad = float(arom_pf_i) / RAD_SCALE

                    flags = int(result_flags)
                    prom_df_valid = 1.0 if (flags & (1 << 0)) else 0.0
                    prom_pf_valid = 1.0 if (flags & (1 << 1)) else 0.0
                    arom_valid = 1.0 if (flags & (1 << 2)) else 0.0
                    seq_active = 1.0 if (flags & (1 << 3)) else 0.0
                    arom_running = 1.0 if (flags & (1 << 4)) else 0.0

                    dev.akr_test_fid_buffer.append((t_rel, [float(fid)]))
                    dev.akr_test_dt_ms_buffer.append((t_rel, [float(dt_ms)]))
                    dev.akr_test_state_buffer.append((t_rel, [float(test_state)]))
                    dev.akr_test_dir_buffer.append((t_rel, [float(dir_v)]))
                    dev.akr_test_blocked_buffer.append((t_rel, [float(blocked)]))
                    dev.akr_test_result_flags_buffer.append((t_rel, [float(flags)]))
                    dev.akr_test_pos_rad_buffer.append((t_rel, [float(pos_rad)]))
                    dev.akr_test_vel_rad_s_buffer.append((t_rel, [float(vel_rad_s)]))
                    dev.akr_test_tq_nm_buffer.append((t_rel, [float(tq_nm)]))
                    dev.akr_test_temp_c_buffer.append((t_rel, [float(temp_c)]))
                    dev.akr_test_vbus_v_buffer.append((t_rel, [float(vbus_v)]))
                    dev.akr_test_pattern_buffer.append((t_rel, [float(pattern)]))
                    dev.akr_test_err_code_buffer.append((t_rel, [float(err_code)]))
                    dev.akr_test_fb_age_ms_buffer.append((t_rel, [float(fb_age_ms)]))
                    dev.akr_test_prom_df_end_rad_buffer.append((t_rel, [float(prom_df_end_rad)]))
                    dev.akr_test_prom_pf_end_rad_buffer.append((t_rel, [float(prom_pf_end_rad)]))
                    dev.akr_test_arom_df_max_rad_buffer.append((t_rel, [float(arom_df_max_rad)]))
                    dev.akr_test_arom_pf_min_rad_buffer.append((t_rel, [float(arom_pf_min_rad)]))
                    dev.akr_test_flag_prom_df_valid_buffer.append((t_rel, [prom_df_valid]))
                    dev.akr_test_flag_prom_pf_valid_buffer.append((t_rel, [prom_pf_valid]))
                    dev.akr_test_flag_arom_valid_buffer.append((t_rel, [arom_valid]))
                    dev.akr_test_flag_seq_active_buffer.append((t_rel, [seq_active]))
                    dev.akr_test_flag_arom_running_buffer.append((t_rel, [arom_running]))

                    dev.last_imu_time_s = float(now)
                    dev.imu_frames_total += 1

                else:
                    # Unknown type: ignore.
                    continue
            except Exception:
                # Keep parser robust: any per-frame decode error should not break streaming.
                continue

    def _handle_akr_rx_bytes(self, address: str, data: bytes) -> None:
        """Handle AKR UART-like RX bytes from notifications.

        AKR devices can emit:
        - human-readable CLI text (prompt, 'show', etc.)
        - rr_telem framed binary packets (walk/CPM/test telemetry)
        """
        if not data:
            return
        buf = self._akr_rx_bin.setdefault(address, bytearray())
        buf.extend(bytes(data))
        self._akr_parse_telem_frames(address)

    def _akr_maybe_parse_rr_akr_line(self, address: str, line: str) -> None:
        """Parse RR_AKR status lines into numeric buffers for plotting/recording."""
        dev = self.devices.get(address)
        if not dev:
            return
        # Only parse into buffers when display/stream is enabled.
        if not bool(getattr(dev, "is_streaming", False)):
            return
        s = str(line)
        if "RR_AKR" not in s:
            return
        m = _RE_RR_AKR.search(s)
        if not m:
            return
        try:
            step_dt = float(int(m.group("step_dt")))
            exec_ms = float(int(m.group("exec")))
            out_v = float(int(m.group("out")))
            state_v = float(int(m.group("state")))
            acc = [float(m.group("accx")), float(m.group("accy")), float(m.group("accz"))]
            gyr = [float(m.group("gyrx")), float(m.group("gyry")), float(m.group("gyrz"))]
            mag = [float(m.group("magx")), float(m.group("magy")), float(m.group("magz"))]
        except Exception:
            return

        now = time.monotonic()
        if getattr(dev, "akr_origin_monotonic_s", None) is None:
            dev.akr_origin_monotonic_s = float(now)
        t_rel = float(now) - float(dev.akr_origin_monotonic_s or now)

        # Scalars
        try:
            dev.akr_step_dt_ms_buffer.append((t_rel, [float(step_dt)]))
            dev.akr_exec_ms_buffer.append((t_rel, [float(exec_ms)]))
            dev.akr_out_buffer.append((t_rel, [float(out_v)]))
            dev.akr_state_buffer.append((t_rel, [float(state_v)]))
        except Exception:
            pass

        # Vectors: AKR lines already provide float values; treat them as calibrated.
        try:
            dev.acc_buffer.append((t_rel, list(acc)))
            dev.gyr_buffer.append((t_rel, list(gyr)))
            dev.mag_buffer.append((t_rel, list(mag)))
        except Exception:
            pass

        dev.last_imu_time_s = time.monotonic()
        dev.imu_frames_total += 1

    async def scan(self, timeout_s: float = config.SCAN_TIMEOUT_S) -> list[DiscoveredDevice]:
        retry_count = max(0, int(getattr(config, "SCAN_EMPTY_RETRY_COUNT", 0)))
        max_attempts = 1 + retry_count
        found: list[DiscoveredDevice] = []
        for attempt in range(1, max_attempts + 1):
            if attempt == 1:
                self._log("Scan: discovering devices...")
            else:
                self._log(f"Scan: retry {attempt - 1}/{retry_count} (no devices found).")
            found = await self.backend.scan(timeout_s=timeout_s)
            if found:
                break

        # Keep connected devices; refresh scanned (disconnected) list
        keep_connected = {a: d for a, d in self.devices.items() if d.is_connected}
        self.devices = dict(keep_connected)

        for dd in found:
            if dd.address in self.devices:
                continue
            kind = (
                "AKR"
                if (dd.name or "").startswith(getattr(config, "AKR_NAME_PREFIXES", ("AKR",)))
                else "EMGS"
            )
            params = DeviceParams(name=dd.name, address=dd.address, kind=kind)
            self.devices[dd.address] = EmgsDevice(params=params)

        if found:
            self._log(f"Scan: found {len(found)} device(s).")
        else:
            self._log(f"Scan: found 0 device(s) after {max_attempts} attempt(s).")
        for addr in list(self.devices.keys()):
            self._notify_updated(addr)
        return found

    async def connect_many(self, addresses: list[str]) -> None:
        await asyncio.gather(*(self.connect_one(a) for a in addresses))

    async def connect_one(self, address: str) -> None:
        if self._shutting_down:
            return
        dev = self.devices.get(address)
        if not dev:
            self.devices[address] = EmgsDevice(params=DeviceParams(name="/", address=address))
            dev = self.devices[address]
        if dev.is_connected:
            return

        self._log(f"Connect: {address}")
        try:
            kind = getattr(dev.params, "kind", "EMGS")
            if str(kind).upper() == "AKR":
                # AKR24: TX on FFE2, RX notify on FFE1 (see akr_protocol.py).
                write_uuid = akr_protocol.CHAR_UUID["WRITE"]
                # Enable notify if supported (needed for UART-like responses). Backend treats it as best-effort.
                notify_uuid = akr_protocol.CHAR_UUID["NOTIFY"]
            else:
                write_uuid = protocol.CHAR_UUID["WRITE"]
                notify_uuid = protocol.CHAR_UUID["NOTIFY"]

            await self.backend.connect(
                address,
                on_notify=self._on_notify,
                on_disconnect=self._on_disconnect,
                write_uuid=write_uuid,
                notify_uuid=notify_uuid,
            )
            dev.set_connected(True)
            # AKR devices stream status lines immediately after connect; treat as "streaming/display enabled".
            if str(kind).upper() == "AKR":
                dev.is_streaming = True
            self._notify_updated(address)
            # EMGS: best-effort initialization (timestamp + GET* queries).
            # AKR: connect/disconnect only for now (protocol TBD).
            if str(kind).upper() == "EMGS":
                # Recommended: set device timestamp ASAP so multi-device streams align.
                # This is best-effort; failures are logged but won't break connection.
                await self.set_timestamp_now(address)
                await self.update_one(address)
        except asyncio.CancelledError:
            # App is shutting down; ensure device is reset.
            dev.reset()
            self._notify_updated(address)
            raise
        except Exception as e:
            # Some Bleak exceptions stringify to empty; include class name + repr for debug.
            self._log(f"Connect failed: {address}: {type(e).__name__}: {e!r}")
            dev.reset()
            self._notify_updated(address)

    def _on_disconnect(self, address: str) -> None:
        """Called by backend when a connection drops unexpectedly."""
        dev = self.devices.get(address)
        if not dev:
            return
        # Drop any buffered AKR RX state (text/bin) so a reconnect starts clean.
        self._akr_rx_buf.pop(address, None)
        self._akr_rx_bin.pop(address, None)
        # Reset state immediately so the UI reflects real connection status.
        dev.reset()
        # Clean up any selection/LED bookkeeping for this device.
        self._drop_selection_state_for_address(address)
        self._notify_updated(address)

    async def disconnect_many(self, addresses: list[str]) -> None:
        await asyncio.gather(*(self.disconnect_one(a) for a in addresses))

    async def disconnect_one(self, address: str) -> None:
        dev = self.devices.get(address)
        if not dev:
            return
        if not dev.is_connected:
            dev.reset()
            self._drop_selection_state_for_address(address)
            self._notify_updated(address)
            return
        self._log(f"Disconnect: {address}")
        try:
            await self.backend.disconnect(address)
        finally:
            self._akr_rx_buf.pop(address, None)
            self._akr_rx_bin.pop(address, None)
            dev.reset()
            self._drop_selection_state_for_address(address)
            self._notify_updated(address)

    async def shutdown(self) -> None:
        """Best-effort cleanup for app exit."""
        self._shutting_down = True
        # Stop streaming first (best-effort)
        for addr, dev in list(self.devices.items()):
            if dev.is_connected and dev.is_streaming:
                try:
                    await self.stream_one(addr, enable=False)
                except Exception:
                    pass
        # Disconnect all
        for addr, dev in list(self.devices.items()):
            if dev.is_connected:
                try:
                    await self.disconnect_one(addr)
                except Exception:
                    pass
        # Backend cleanup
        try:
            await self.backend.shutdown()
        except Exception:
            pass

    async def update_many(self, addresses: list[str]) -> None:
        await asyncio.gather(*(self.update_one(a) for a in addresses))

    async def poll_many(self, addresses: list[str]) -> None:
        """Lightweight periodic polling to keep connected device state fresh.

        We intentionally keep this minimal (one command) to avoid BLE congestion.
        """
        await asyncio.gather(*(self.poll_one(a) for a in addresses))

    def check_health_many(self, addresses: list[str]) -> None:
        """Local health check without sending any BLE traffic.

        Useful while streaming: if RX stops, mark device as Unstable.
        """
        now = time.monotonic()
        for a in addresses:
            self.check_health_one(a, now=now)

    def check_health_one(self, address: str, *, now: float | None = None) -> None:
        dev = self.devices.get(address)
        if not dev or not dev.is_connected:
            return
        t_now = time.monotonic() if now is None else now
        last = dev.last_rx_monotonic_s
        if last is None:
            return
        if (t_now - last) >= config.DEVICE_UNSTABLE_TIMEOUT_S:
            if dev.params.status != "Unstable":
                dev.mark_unstable()
                self._notify_updated(address)

    def reset_processed_state_many(self, addresses: list[str]) -> None:
        """Reset host-side *processed* buffers/state without changing streaming state.

        This is useful for restarting derived metrics (envelope, MDF/MNF, fatigue baseline)
        without stopping/restarting the stream.
        """
        for a in addresses:
            self.reset_processed_state_one(a)

    def reset_processed_state_one(self, address: str) -> None:
        dev = self.devices.get(address)
        if not dev:
            return
        # Clear processed buffers only (keep raw EMG/IMU).
        try:
            dev.emg_rms_buffer.clear()
            dev._emg_rms_sq_window.clear()
            dev._emg_rms_sq_sum = 0.0
        except Exception:
            pass
        try:
            dev.emg_median_freq_buffer.clear()
            dev.emg_mean_freq_buffer.clear()
            dev.emg_spectrum_last = None
            dev.emg_spectrum_last_linear = None
        except Exception:
            pass
        try:
            dev.emg_fatigue_score_buffer.clear()
            dev.emg_fatigue_conf_buffer.clear()
            dev._fatigue_t0_s = None
            dev._fatigue_baseline_mdf.clear()
            dev._fatigue_baseline_rms.clear()
            dev._fatigue_recent_mdf.clear()
        except Exception:
            pass
        # Emit update so UI can reflect immediate reset.
        self._notify_updated(address)

    async def poll_one(self, address: str) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        dev = self.devices.get(address)
        if dev and dev.is_connected:
            # Mark "Unstable" if we haven't received any RX from the device recently.
            last = dev.last_rx_monotonic_s
            if last is not None and (time.monotonic() - last) >= config.DEVICE_UNSTABLE_TIMEOUT_S:
                if dev.params.status != "Unstable":
                    dev.mark_unstable()
                    self._notify_updated(address)
        # TIME_SYNC ('A3') returns battery/charge + timestamp on this firmware.
        self._last_time_sync_send_ms[address] = int(time.time() * 1000)
        await self._write(address, protocol.build_payload(protocol.TIME_SYNC.opcode))

    async def update_one(self, address: str) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        # Same sequence as EMGS_v4 (GET*)
        await self._write(address, protocol.build_payload(protocol.GET_VERSION.opcode))
        await self._write(address, protocol.build_payload(protocol.GET_DSP_VERSION.opcode))
        # '3' returns timestamp + batt/charge on this firmware; keep it in the update set.
        self._last_time_sync_send_ms[address] = int(time.time() * 1000)
        await self._write(address, protocol.build_payload(protocol.TIME_SYNC.opcode))
        self._last_get_ts_send_ms[address] = int(time.time() * 1000)
        await self._write(address, protocol.build_payload(protocol.GET_TIMESTAMP.opcode))
        await self._write(address, protocol.build_payload(protocol.GET_BLE_NAME.opcode))
        await self._write(address, protocol.build_payload(protocol.GET_CONN_INTERVAL.opcode))
        for idx in range(9):
            payload = protocol.build_payload("AX", idx)
            await self._write(address, payload)
        await self._write(address, protocol.build_payload(protocol.GET_EMG_ENABLE.opcode))
        await self._write(address, protocol.build_payload(protocol.GET_LOW_BATT_LVL.opcode))
        await self._write(address, protocol.build_payload(protocol.GET_EMG_THRESHOLD.opcode))
        await self._write(address, protocol.build_payload(protocol.GET_OUT_OF_STORAGE_THRESHOLD.opcode))
        # Query IMU freq/scale for common sensor types (acc/gyr/mag/quat/geomag)
        for sensor_type in (1, 4, 6, 7, 8):
            await self._write(address, protocol.build_payload("AZ", sensor_type))
        for sensor_type in (1, 4):
            await self._write(address, protocol.build_payload("AD", sensor_type))
        await self._write(address, protocol.build_payload(protocol.ICM_GET_BIAS.opcode))
        # Notify decode will update device fields

    async def stream_many(self, addresses: list[str], enable: bool) -> None:
        await asyncio.gather(*(self.stream_one(a, enable=enable) for a in addresses))

    async def stream_one(self, address: str, enable: bool) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() == "AKR":
            # AKR: device sends data immediately after connect; "stream" is a local display toggle.
            dev0.is_streaming = bool(enable)
            if enable:
                # Treat as a new local "session": clear buffers and reset origin.
                try:
                    dev0.akr_origin_monotonic_s = None
                    dev0.akr_step_dt_ms_buffer.clear()
                    dev0.akr_exec_ms_buffer.clear()
                    dev0.akr_out_buffer.clear()
                    dev0.akr_state_buffer.clear()
                    dev0.akr_walk_fid_buffer.clear()
                    dev0.akr_walk_dt_ms_buffer.clear()
                    dev0.akr_walk_exec_ms_buffer.clear()
                    dev0.akr_walk_out_buffer.clear()
                    dev0.akr_walk_state_buffer.clear()
                    dev0.akr_walk_acc_buffer.clear()
                    dev0.akr_walk_gyr_buffer.clear()
                    dev0.akr_walk_mag_buffer.clear()
                    dev0.akr_walk_pos_rad_buffer.clear()
                    dev0.akr_walk_vel_rad_s_buffer.clear()
                    dev0.akr_walk_tq_nm_buffer.clear()
                    dev0.akr_walk_temp_c_buffer.clear()
                    dev0.akr_walk_vbus_v_buffer.clear()
                    dev0.akr_walk_pattern_buffer.clear()
                    dev0.akr_walk_err_code_buffer.clear()
                    dev0.akr_walk_fb_age_ms_buffer.clear()
                    dev0.akr_cpm_fid_buffer.clear()
                    dev0.akr_cpm_dt_ms_buffer.clear()
                    dev0.akr_cpm_state_buffer.clear()
                    dev0.akr_cpm_dir_buffer.clear()
                    dev0.akr_cpm_blocked_event_buffer.clear()
                    dev0.akr_cpm_blocked_consecutive_buffer.clear()
                    dev0.akr_cpm_cmd_spd_rad_s_buffer.clear()
                    dev0.akr_cpm_pos_rad_buffer.clear()
                    dev0.akr_cpm_vel_rad_s_buffer.clear()
                    dev0.akr_cpm_tq_nm_buffer.clear()
                    dev0.akr_cpm_temp_c_buffer.clear()
                    dev0.akr_cpm_vbus_v_buffer.clear()
                    dev0.akr_cpm_pattern_buffer.clear()
                    dev0.akr_cpm_err_code_buffer.clear()
                    dev0.akr_cpm_fb_age_ms_buffer.clear()
                    dev0.akr_cpm_df_limit_rad_buffer.clear()
                    dev0.akr_cpm_pf_limit_rad_buffer.clear()
                    dev0.akr_cpm_elapsed_s_buffer.clear()
                    dev0.akr_cpm_repetition_count_buffer.clear()
                    dev0.akr_test_fid_buffer.clear()
                    dev0.akr_test_dt_ms_buffer.clear()
                    dev0.akr_test_state_buffer.clear()
                    dev0.akr_test_dir_buffer.clear()
                    dev0.akr_test_blocked_buffer.clear()
                    dev0.akr_test_result_flags_buffer.clear()
                    dev0.akr_test_pos_rad_buffer.clear()
                    dev0.akr_test_vel_rad_s_buffer.clear()
                    dev0.akr_test_tq_nm_buffer.clear()
                    dev0.akr_test_temp_c_buffer.clear()
                    dev0.akr_test_vbus_v_buffer.clear()
                    dev0.akr_test_pattern_buffer.clear()
                    dev0.akr_test_err_code_buffer.clear()
                    dev0.akr_test_fb_age_ms_buffer.clear()
                    dev0.akr_test_prom_df_end_rad_buffer.clear()
                    dev0.akr_test_prom_pf_end_rad_buffer.clear()
                    dev0.akr_test_arom_df_max_rad_buffer.clear()
                    dev0.akr_test_arom_pf_min_rad_buffer.clear()
                    dev0.akr_test_flag_prom_df_valid_buffer.clear()
                    dev0.akr_test_flag_prom_pf_valid_buffer.clear()
                    dev0.akr_test_flag_arom_valid_buffer.clear()
                    dev0.akr_test_flag_seq_active_buffer.clear()
                    dev0.akr_test_flag_arom_running_buffer.clear()
                except Exception:
                    pass
                try:
                    dev0.acc_buffer.clear()
                    dev0.gyr_buffer.clear()
                    dev0.mag_buffer.clear()
                except Exception:
                    pass
                try:
                    self._akr_rx_buf[address] = ""
                    self._akr_rx_bin[address] = bytearray()
                except Exception:
                    pass
            self._notify_updated(address)
            return
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        cmd = protocol.STREAM_START.opcode if enable else protocol.STREAM_STOP.opcode
        await self._write(address, protocol.build_payload(cmd))
        # Optimistic state update (device will also ACK via notify if firmware does)
        dev = self.devices.get(address)
        if dev:
            if enable:
                # Latch processing settings for this new session.
                dev.proc_enable_emg_rms_envelope = bool(self.proc_enable_emg_rms_envelope_next)
                dev.proc_emg_rms_window_n = int(self.proc_emg_rms_window_n_next)
                dev.proc_enable_emg_freq_features = bool(self.proc_enable_emg_freq_features_next)
                dev.proc_emg_spec_window_n = int(self.proc_emg_spec_window_n_next)
                dev.proc_enable_emg_fatigue = bool(self.proc_enable_emg_fatigue_next)
                dev.proc_emg_fatigue_baseline_s = float(self.proc_emg_fatigue_baseline_s_next)
                dev.proc_emg_fatigue_weight_mdf_pct = float(self.proc_emg_fatigue_weight_mdf_pct_next)
                dev.proc_emg_fatigue_weight_rms_pct = float(self.proc_emg_fatigue_weight_rms_pct_next)
                dev.proc_emg_fatigue_conf_recent_n = int(self.proc_emg_fatigue_conf_recent_n_next)
                # Start the envelope from a clean slate each session (prevents mixing across sessions).
                dev.emg_rms_buffer.clear()
                dev._emg_rms_sq_window.clear()
                dev._emg_rms_sq_sum = 0.0
                # Clear other processed buffers for a fresh session.
                dev.emg_median_freq_buffer.clear()
                dev.emg_mean_freq_buffer.clear()
                dev.emg_spectrum_last = None
                dev.emg_spectrum_last_linear = None
                dev.emg_fatigue_score_buffer.clear()
                dev.emg_fatigue_conf_buffer.clear()
                dev._fatigue_t0_s = None
                dev._fatigue_baseline_mdf.clear()
                dev._fatigue_baseline_rms.clear()
                dev._fatigue_recent_mdf.clear()
            dev.is_streaming = enable
            self._notify_updated(address)
            # Selection LED is suppressed while streaming; refresh if this device is selected.
            async with self._selection_led_lock:
                await self._refresh_selection_leds_locked()

    async def set_indicator_led(self, address: str, state: str) -> None:
        # Optional UX; safe no-op if invalid.
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        rgb_code = {
            "off": protocol.IndicatorRGB.OFF,
            "blue": protocol.IndicatorRGB.BLUE,
            "yellow": protocol.IndicatorRGB.YELLOW,
            "purple": protocol.IndicatorRGB.PURPLE,
        }
        code = rgb_code.get(state)
        if code is None:
            return
        if not self.backend.is_connected(address):
            return

        # Cache + light throttling to avoid BLE congestion on rapid row selection changes.
        prev = self._led_state.get(address)
        if prev == state:
            return
        now = time.monotonic()
        last = self._led_last_ts_s.get(address, 0.0)
        # Only throttle "purple" selection flashes; always allow restoring the prior state.
        if state == "purple" and (now - last) < self._led_min_interval_s:
            return

        self._led_state[address] = state
        if state == "purple":
            self._led_last_ts_s[address] = now
        await self._write(address, protocol.build_payload(protocol.SET_INDICATOR.opcode, 0, code))

    def _drop_selection_state_for_address(self, address: str) -> None:
        """Remove address from all selection/identify bookkeeping (no BLE writes)."""
        for s in self._ui_selected_addrs_by_source.values():
            s.discard(address)
        self._led_override_active.discard(address)
        self._led_prev_before_select.pop(address, None)
        self._identify_token.pop(address, None)

    def _selected_union(self) -> set[str]:
        out: set[str] = set()
        for s in self._ui_selected_addrs_by_source.values():
            out |= set(s)
        return out

    def _should_allow_selection_led(self, address: str) -> bool:
        """Return True if we should show a purple selection LED right now."""
        dev = self.devices.get(address)
        if not dev or not dev.is_connected:
            return False
        # Identify source overrides streaming suppression.
        if address in self._ui_selected_addrs_by_source.get("identify", set()):
            return True
        return not bool(dev.is_streaming)

    async def _refresh_selection_leds_locked(self) -> None:
        """Apply purple selection LEDs for all UI selection sources (lock must be held)."""
        desired = {a for a in self._selected_union() if self.backend.is_connected(a)}

        # Drop bookkeeping for devices no longer selected by ANY source.
        for a in list(self._led_prev_before_select.keys()):
            if a in desired:
                continue
            if a in self._led_override_active:
                prev = self._led_prev_before_select.get(a, "off")
                await self.set_indicator_led(a, prev)
                self._led_override_active.discard(a)
            self._led_prev_before_select.pop(a, None)

        # Ensure we have a previous-state snapshot for all selected devices.
        for a in desired:
            if a not in self._led_prev_before_select:
                self._led_prev_before_select[a] = self._led_state.get(a, "off")

        # Enforce current policy (purple if selected and allowed; otherwise restore).
        for a in desired:
            allow = self._should_allow_selection_led(a)
            if allow and a not in self._led_override_active:
                await self.set_indicator_led(a, "purple")
                self._led_override_active.add(a)
            elif (not allow) and a in self._led_override_active:
                prev = self._led_prev_before_select.get(a, "off")
                await self.set_indicator_led(a, prev)
                self._led_override_active.discard(a)

    async def _set_ui_selected_devices(self, source: str, addresses: list[str]) -> None:
        """Update one selection source and refresh LEDs (purple)."""
        async with self._selection_led_lock:
            desired = {a for a in addresses if self.backend.is_connected(a)}
            if source not in self._ui_selected_addrs_by_source:
                self._ui_selected_addrs_by_source[source] = set()
            self._ui_selected_addrs_by_source[source] = desired
            await self._refresh_selection_leds_locked()

    async def set_table_selected_devices(self, addresses: list[str]) -> None:
        """Connect-page selection → device indicator LED (purple), suppressed while streaming."""
        await self._set_ui_selected_devices("table", addresses)

    async def set_signals_selected_devices(self, addresses: list[str]) -> None:
        """Signals-page device selection → device indicator LED (purple), suppressed while streaming."""
        await self._set_ui_selected_devices("signals", addresses)

    async def identify_device(self, address: str, *, duration_s: float = 2.0) -> None:
        """Temporarily light a device purple to help identify it (allowed even while streaming)."""
        if not self.backend.is_connected(address):
            return
        token = time.monotonic()
        async with self._selection_led_lock:
            self._identify_token[address] = token
            self._ui_selected_addrs_by_source.setdefault("identify", set()).add(address)
            await self._refresh_selection_leds_locked()

        async def _clear_later() -> None:
            try:
                await asyncio.sleep(max(0.1, float(duration_s)))
            except asyncio.CancelledError:
                return
            async with self._selection_led_lock:
                if self._identify_token.get(address) != token:
                    return
                self._identify_token.pop(address, None)
                self._ui_selected_addrs_by_source.get("identify", set()).discard(address)
                await self._refresh_selection_leds_locked()

        asyncio.create_task(_clear_later())

    async def set_timestamp_now(self, address: str) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        # Device timestamp advances in 10ms ticks; align to reduce quantization error.
        now_ms = int(time.time() * 1000)
        now_ms = int(now_ms - (now_ms % 10))
        payload = protocol.build_payload(protocol.SET_TIMESTAMP.opcode, struct.pack("<Q", now_ms))
        # opcode(2) + timestamp(8) = 10 bytes
        await self._write(address, protocol.require_len(payload, 10))
        # Pull a fresh TIME_SYNC reply so UI updates clock delta immediately.
        await self.poll_one(address)

    async def apply_settings(
        self,
        address: str,
        *,
        ble_name: Optional[str] = None,
        conn_interval_min: Optional[int] = None,
        conn_interval_max: Optional[int] = None,
        icm_enabled: Optional[list[bool]] = None,  # len 9
        emg_mode: Optional[int] = None,            # 0/1/2
    ) -> None:
        """Apply device settings (best-effort).

        Keeps individual writes simple and resilient. Caller can follow with update_one().
        """
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return

        if ble_name is not None:
            # Firmware expects exactly 12 bytes (NUL padded). Keep prefix if caller provides it.
            name = ble_name[:12]
            name_bytes = name.encode("ascii", errors="ignore")[:12]
            name_bytes = name_bytes + b"\x00" * (12 - len(name_bytes))
            payload = protocol.build_payload(protocol.SET_BLE_NAME.opcode, name_bytes)
            await self._write(address, protocol.require_len(payload, 14))

        if conn_interval_min is not None and conn_interval_max is not None:
            payload = protocol.build_payload(
                protocol.SET_CONN_INTERVAL.opcode,
                struct.pack("<H", int(conn_interval_min)),
                struct.pack("<H", int(conn_interval_max)),
            )
            await self._write(address, protocol.require_len(payload, 6))

        if icm_enabled is not None:
            if len(icm_enabled) != 9:
                raise ValueError("icm_enabled must have length 9")
            for idx, enabled in enumerate(icm_enabled):
                payload = protocol.build_payload(protocol.SET_ICM_ENABLE.opcode, idx, 1 if enabled else 0)
                await self._write(address, protocol.require_len(payload, 4))

        if emg_mode is not None:
            payload = protocol.build_payload(protocol.SET_EMG_ENABLE.opcode, int(emg_mode))
            await self._write(address, protocol.require_len(payload, 3))

    async def apply_modes_many(self, addresses: list[str], *, icm_enabled: list[bool], emg_mode: int) -> None:
        """Apply only the 5 mode settings across many devices, then refresh."""
        addrs = [
            a
            for a in addresses
            if self.backend.is_connected(a)
            and (self.devices.get(a) is not None)
            and str(getattr(self.devices[a].params, "kind", "EMGS")).upper() == "EMGS"
        ]
        if not addrs:
            return
        await asyncio.gather(*(self.apply_settings(a, icm_enabled=list(icm_enabled), emg_mode=int(emg_mode)) for a in addrs))
        # Pull fresh info so UI shows the updated modes.
        await self.update_many(addrs)

    async def set_emg_threshold(self, address: str, threshold: int) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        payload = protocol.build_payload(protocol.SET_EMG_THRESHOLD.opcode, struct.pack("<H", int(threshold)))
        await self._write(address, protocol.require_len(payload, 4))

    async def set_power_safe_level(self, address: str, level_percent: int) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        payload = protocol.build_payload(protocol.SET_LOW_BATT_LVL.opcode, int(level_percent))
        await self._write(address, protocol.require_len(payload, 3))

    async def set_storage_threshold(self, address: str, level_percent: int) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        payload = protocol.build_payload(protocol.SET_OUT_OF_STORAGE_THRESHOLD.opcode, int(level_percent))
        await self._write(address, protocol.require_len(payload, 3))

    async def set_icm_freq(self, address: str, sensor_type: int, freq: int) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        payload = protocol.build_payload(protocol.ICM_SET_FREQ.opcode, int(sensor_type), int(freq))
        await self._write(address, protocol.require_len(payload, 4))

    async def set_icm_scale(self, address: str, sensor_type: int, scale: int) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        payload = protocol.build_payload(protocol.ICM_SET_SCALE.opcode, int(sensor_type), int(scale))
        await self._write(address, protocol.require_len(payload, 4))

    async def set_icm_bias(self, address: str, bias_acc: list[int], bias_gyr: list[int], bias_mag: list[int]) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        if len(bias_acc) != 3 or len(bias_gyr) != 3 or len(bias_mag) != 3:
            raise ValueError("bias lists must have length 3")
        payload = protocol.build_payload(
            protocol.ICM_SET_BIAS.opcode,
            b"".join(struct.pack("<i", int(x)) for x in bias_acc),
            b"".join(struct.pack("<i", int(x)) for x in bias_gyr),
            b"".join(struct.pack("<i", int(x)) for x in bias_mag),
        )
        # opcode(2) + 36 bytes = 38
        await self._write(address, protocol.require_len(payload, 38))

    async def set_icm_auto_save_bias(self, address: str, enable: bool) -> None:
        if not self.backend.is_connected(address):
            return
        dev0 = self.devices.get(address)
        if dev0 and str(getattr(dev0.params, "kind", "EMGS")).upper() != "EMGS":
            return
        payload = protocol.build_payload(protocol.ICM_SET_AUTO_SAVE_BIAS.opcode, 1 if enable else 0)
        await self._write(address, protocol.require_len(payload, 3))

    async def _write(self, address: str, payload: bytes) -> None:
        if self._debug_cmd:
            # Payload begins with 2 ASCII bytes opcode (e.g. b'A5', b'AX', etc.)
            try:
                op = payload[:2].decode("ascii", errors="replace")
            except Exception:
                op = "??"
            msg = f"TX [{address}] op={op} len={len(payload)}"
            if self._debug_cmd_hex:
                hx = " ".join(f"{b:02X}" for b in payload[:32])
                msg += f" head={hx}"
            self._log(msg)
        try:
            await self.backend.write(address, payload)
        except Exception as e:
            self._log(f"Write failed: {address}: {e}")

    def _on_notify(self, address: str, data: bytes) -> None:
        dev = self.devices.get(address)
        if not dev:
            dev = EmgsDevice(params=DeviceParams(name="/", address=address))
            self.devices[address] = dev
        dev.last_rx_monotonic_s = time.monotonic()
        # Any RX implies the link is healthy again.
        if dev.is_connected and dev.params.status == "Unstable":
            dev.params.status = "Connected"
        kind = str(getattr(dev.params, "kind", "EMGS")).upper()
        is_emgs_frame = bool(data) and len(data) >= 2 and (data[0] == ord("S"))
        pkt_type = chr(data[1]) if is_emgs_frame else "?"
        host_ms = int(time.time() * 1000)

        # AKR devices: treat notifications as UTF-8/ASCII text stream (UART-like).
        if kind == "AKR" and (not is_emgs_frame):
            self._handle_akr_rx_bytes(address, bytes(data))
            # Still notify UI periodically so connection "feels alive".
            now = time.monotonic()
            last_ui = self._ui_last_emit_s.get(address, 0.0)
            if (now - last_ui) >= config.UI_DEVICE_UPDATE_MIN_INTERVAL_S:
                self._ui_last_emit_s[address] = now
                self._notify_updated(address)
            return

        # Command RX debug: decode which command is being ACK'ed / replied to.
        if kind == "EMGS" and self._debug_cmd and pkt_type == "A" and len(data) >= 3:
            cmd = chr(data[2])
            msg = f"RX [{address}] type=A cmd={cmd} len={len(data)}"
            if self._debug_cmd_hex:
                hx = " ".join(f'{b:02X}' for b in data[:32])
                msg += f" head={hx}"
            self._log(msg)

        # Clock delta tracking from 'S''A' replies.
        # - TIME_SYNC cmd '3': timestamp at offset 5 (8 bytes LE)
        # - GET_TIMESTAMP cmd 'G': timestamp at offset 3 (8 bytes LE)
        if kind == "EMGS" and pkt_type == "A" and len(data) >= 11:
            try:
                cmd = chr(data[2])
                ts_ms = None
                if cmd == "3" and len(data) >= 13:
                    ts_ms = int(struct.unpack_from("<Q", data, 5)[0])
                elif cmd == "G" and len(data) >= 11:
                    ts_ms = int(struct.unpack_from("<Q", data, 3)[0])
                if ts_ms is not None:
                    dev.last_device_ts_ms = ts_ms
                    # Midpoint estimate reduces apparent offset from BLE RTT.
                    send_ms = None
                    if cmd == "3":
                        send_ms = self._last_time_sync_send_ms.get(address)
                    elif cmd == "G":
                        send_ms = self._last_get_ts_send_ms.get(address)
                    host_est_ms = int((send_ms + host_ms) / 2) if send_ms is not None else host_ms
                    dev.last_host_ts_ms = host_est_ms
                    dev.clock_delta_ms = ts_ms - host_est_ms
            except Exception:
                pass

        # Diagnostics counters
        st = self._rx_stats.setdefault(address, {})
        st["bytes"] = st.get("bytes", 0) + len(data)
        st[pkt_type] = st.get(pkt_type, 0) + 1

        # Optional occasional hexdump (useful to confirm packet shape without spamming)
        if kind == "EMGS" and self._debug_rx_hex and pkt_type in {"E", "I", "A"}:
            now = time.monotonic()
            last = self._rx_last_hex_s.get(address, 0.0)
            if (now - last) >= 1.0:
                self._rx_last_hex_s[address] = now
                hx = " ".join(f"{b:02X}" for b in data[:32])
                self._log(f"RXHEX [{address}] type={pkt_type} len={len(data)} head={hx}")

        try:
            dev.decode_notification(data)
        except Exception as e:
            hx = " ".join(f"{b:02X}" for b in data[:32])
            self._log(f"RX decode error [{address}] type={pkt_type} len={len(data)} err={e} head={hx}")

        # Throttled periodic RX summary
        if self._debug_rx:
            now = time.monotonic()
            last = self._rx_last_log_s.get(address, 0.0)
            if (now - last) >= 1.0:
                self._rx_last_log_s[address] = now
                self._log(
                    f"RX [{address}] A={st.get('A',0)} E={st.get('E',0)} I={st.get('I',0)} bytes={st.get('bytes',0)}"
                )

        # Throttle UI refresh emissions to avoid UI hangs under high notify rates.
        now = time.monotonic()
        last_ui = self._ui_last_emit_s.get(address, 0.0)
        if (now - last_ui) >= config.UI_DEVICE_UPDATE_MIN_INTERVAL_S:
            self._ui_last_emit_s[address] = now
            self._notify_updated(address)

    async def akr_send_line(self, address: str, line: str) -> None:
        """Send a single ASCII/UTF-8 CLI line to a AKR device (best-effort).

        Uses the per-device WRITE characteristic selected at connect-time.
        """
        dev = self.devices.get(address)
        if not dev or str(getattr(dev.params, "kind", "EMGS")).upper() != "AKR":
            return
        if not self.backend.is_connected(address):
            return
        s = str(line or "").strip()
        if not s:
            return
        # STM32 CLI in `backup/akr_code_v2/Core/Src/cli_uart.c` treats CR as newline and ignores LF after CR,
        # so CRLF is a safe cross-platform terminator.
        payload = (s + "\r\n").encode("utf-8", errors="replace")
        try:
            await self.backend.write(address, payload)
        except Exception as e:
            self._log(f"AKR write failed: {address}: {type(e).__name__}: {e!r}")

