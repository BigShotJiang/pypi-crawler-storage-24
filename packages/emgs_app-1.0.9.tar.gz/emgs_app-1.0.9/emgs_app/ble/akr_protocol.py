"""AKR* device BLE UUIDs and (future) protocol helpers.

Observed device example:
  - name: "AKR24"
  - services: ["0000ffe0-0000-1000-8000-00805f9b34fb"]

AKR24 devices expose two characteristics under Service 0xFFE0:
  - 0xFFE1: read, write, write-no-response, notify  (good for RX via notify)
  - 0xFFE2: write, write-no-response                 (good for TX writes)

This module only defines UUIDs for connect/disconnect wiring today.
Binary/ASCII command protocol is intentionally left TBD.
"""

from __future__ import annotations

from typing import Final


SERVICE_UUID: Final[str] = "0000ffe0-0000-1000-8000-00805f9b34fb"
CHAR_UUID: Final[dict[str, str]] = {
    # Recommended split:
    # - host TX: write to FFE2 (write / write-without-response)
    # - device RX: notify on FFE1
    "WRITE": "0000ffe2-0000-1000-8000-00805f9b34fb",
    "NOTIFY": "0000ffe1-0000-1000-8000-00805f9b34fb",
    # Optional: if firmware expects writes on the notify characteristic.
    "WRITE_FALLBACK": "0000ffe1-0000-1000-8000-00805f9b34fb",
}


__all__ = ["SERVICE_UUID", "CHAR_UUID"]

