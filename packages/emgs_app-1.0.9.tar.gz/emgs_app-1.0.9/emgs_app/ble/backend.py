from __future__ import annotations

import abc
import asyncio
import logging
import math
import os
import random
import time
import warnings
from dataclasses import dataclass
from typing import Callable, Optional

from .. import config
from . import protocol

try:
    import bleak
except Exception:  # pragma: no cover (import-time platform issues)
    bleak = None  # type: ignore


logger = logging.getLogger(__name__)

NotifyCallback = Callable[[str, bytes], None]  # (address, data)
DisconnectCallback = Callable[[str], None]     # (address,)


@dataclass(frozen=True, slots=True)
class DiscoveredDevice:
    name: str
    address: str


class Backend(abc.ABC):
    @abc.abstractmethod
    async def scan(self, timeout_s: float) -> list[DiscoveredDevice]:
        raise NotImplementedError

    @abc.abstractmethod
    async def connect(
        self,
        address: str,
        on_notify: NotifyCallback,
        on_disconnect: Optional[DisconnectCallback] = None,
        *,
        write_uuid: str | None = None,
        notify_uuid: str | None = None,
    ) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    async def disconnect(self, address: str) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    async def write(
        self,
        address: str,
        payload: bytes,
        *,
        write_uuid: str | None = None,
    ) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    def is_connected(self, address: str) -> bool:
        raise NotImplementedError

    async def shutdown(self) -> None:
        """Best-effort cleanup for app exit (optional)."""
        return None


class BleakBackend(Backend):
    def __init__(self) -> None:
        if bleak is None:
            raise RuntimeError("bleak is not available in this environment")
        self._clients: dict[str, "bleak.BleakClient"] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        # Per-device characteristic routing (defaults to EMGS NUS UUIDs if unset).
        self._write_uuid: dict[str, str] = {}
        self._notify_uuid: dict[str, str] = {}
        # Cache discovered BleakDevice objects (important on macOS/CoreBluetooth).
        self._known_devices: dict[str, object] = {}

    async def scan(self, timeout_s: float) -> list[DiscoveredDevice]:
        # RSSI collection intentionally disabled (stability > cosmetics).
        # We also avoid Bleak's adv-return scan path to reduce risk of lower-layer crashes.
        out: list[DiscoveredDevice] = []
        discovered = await bleak.BleakScanner.discover(timeout=timeout_s)
        for dd in discovered:
            if dd.name and dd.name.startswith(tuple(getattr(config, "DEVICE_NAME_PREFIXES", (config.EMGS_NAME_PREFIX,)))):
                # Cache the full BleakDevice; on macOS, connecting via BleakDevice is more reliable
                # than connecting by UUID string alone.
                try:
                    self._known_devices[str(dd.address)] = dd
                except Exception:
                    pass
                out.append(DiscoveredDevice(name=dd.name, address=dd.address))
        return out

    async def connect(
        self,
        address: str,
        on_notify: NotifyCallback,
        on_disconnect: Optional[DisconnectCallback] = None,
        *,
        write_uuid: str | None = None,
        notify_uuid: str | None = None,
    ) -> None:
        if address in self._clients and self._clients[address].is_connected:
            return

        def _disconnected(_client) -> None:
            logger.info("Disconnected: %s", address)
            if on_disconnect:
                try:
                    on_disconnect(address)
                except Exception:
                    pass

        # Prefer using cached BleakDevice (macOS/CoreBluetooth stability).
        dev_obj = self._known_devices.get(str(address))
        if dev_obj is None:
            # Best-effort re-discovery if user clicks Connect without scanning recently.
            try:
                finder = getattr(bleak.BleakScanner, "find_device_by_address", None)
                if finder is not None:
                    dev_obj = await finder(str(address), timeout=5.0)
                    if dev_obj is not None:
                        self._known_devices[str(address)] = dev_obj
            except Exception:
                dev_obj = None

        client = bleak.BleakClient(address_or_ble_device=(dev_obj or address), disconnected_callback=_disconnected)
        # Store early so shutdown can see it even if connect is in-flight.
        self._clients[address] = client
        # Route UUIDs (store before any notify/write so write() can use them immediately after connect()).
        self._write_uuid[address] = str(write_uuid or protocol.CHAR_UUID["WRITE"])
        if notify_uuid is None:
            # Some peripherals don't support notify; allow connect-only usage.
            self._notify_uuid.pop(address, None)
        else:
            self._notify_uuid[address] = str(notify_uuid or protocol.CHAR_UUID["NOTIFY"])
        try:
            await asyncio.wait_for(client.connect(), timeout=10.0)
            # BlueZ backend MTU reporting can be "unknown" unless explicitly acquired.
            # Also, reading `mtu_size` when unset triggers a warning and returns default 23,
            # which is misleading if the stack negotiated a larger MTU automatically.
            mtu = getattr(client, "_mtu_size", None)
            if mtu is None:
                # _acquire_mtu requires services; populate them but suppress deprecation warnings.
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", FutureWarning)
                        await client.get_services()
                except Exception:
                    pass
                try:
                    acquire = getattr(client, "_acquire_mtu", None)
                    if acquire is not None:
                        await acquire()
                except Exception:
                    pass
                mtu = getattr(client, "_mtu_size", None)

            if isinstance(mtu, int):
                logger.info("Connected: %s mtu=%s", address, mtu)
                if mtu <= 23:
                    logger.warning(
                        "MTU is %s (payload %s bytes). Large streaming frames (E/I) may not be deliverable on this link.",
                        mtu,
                        max(0, mtu - 3),
                    )
            else:
                logger.info("Connected: %s mtu=unknown", address)
            nu = self._notify_uuid.get(address)
            if nu:
                await client.start_notify(nu, lambda _sender, data: on_notify(address, bytes(data)))
        except asyncio.CancelledError:
            # Ensure we don't leave half-open clients around.
            try:
                await client.disconnect()
            except Exception:
                pass
            self._clients.pop(address, None)
            self._write_uuid.pop(address, None)
            self._notify_uuid.pop(address, None)
            raise
        except Exception as e:
            # Clean up on connect failure.
            logger.warning("Connect exception for %s: %s: %r", address, type(e).__name__, e)
            try:
                await client.disconnect()
            except Exception:
                pass
            self._clients.pop(address, None)
            self._write_uuid.pop(address, None)
            self._notify_uuid.pop(address, None)
            raise
        self._locks.setdefault(address, asyncio.Lock())

    async def disconnect(self, address: str) -> None:
        client = self._clients.get(address)
        if not client:
            return
        try:
            if client.is_connected:
                try:
                    nu = self._notify_uuid.get(address)
                    if nu:
                        await client.stop_notify(nu)
                except Exception:
                    pass
                await client.disconnect()
        finally:
            self._clients.pop(address, None)
            self._write_uuid.pop(address, None)
            self._notify_uuid.pop(address, None)

    async def write(
        self,
        address: str,
        payload: bytes,
        *,
        write_uuid: str | None = None,
    ) -> None:
        client = self._clients.get(address)
        if not client or not client.is_connected:
            raise RuntimeError(f"Not connected: {address}")
        lock = self._locks.setdefault(address, asyncio.Lock())
        async with lock:
            cu = str(write_uuid or self._write_uuid.get(address) or protocol.CHAR_UUID["WRITE"])
            await client.write_gatt_char(cu, payload)
        await asyncio.sleep(0)

    def is_connected(self, address: str) -> bool:
        c = self._clients.get(address)
        return bool(c and c.is_connected)

    async def shutdown(self) -> None:
        # Disconnect all known clients (including in-flight connect attempts).
        addrs = list(self._clients.keys())
        for a in addrs:
            try:
                await self.disconnect(a)
            except Exception:
                pass


class SimBackend(Backend):
    """Simulation backend for UI development without hardware.

    It fakes:
    - scan results for N devices
    - connect/disconnect state
    - streaming notifications (EMG 'E' frames) once STREAM_START is written
    """

    def __init__(self, n_devices: int = 8) -> None:
        self._n = n_devices
        self._connected: set[str] = set()
        self._notify: dict[str, NotifyCallback] = {}
        self._streaming: set[str] = set()
        self._tasks: dict[str, asyncio.Task] = {}
        self._t0 = time.time()

    async def scan(self, timeout_s: float) -> list[DiscoveredDevice]:
        await asyncio.sleep(min(timeout_s, 0.2))
        out = []
        for i in range(self._n):
            out.append(DiscoveredDevice(name=f"EMGS_SIM_{i+1:02d}", address=f"SIM:{i+1:02d}"))
        # Also add one AKR-like simulated device (connect/disconnect only).
        out.append(DiscoveredDevice(name="AKR_SIM_01", address="SIM:AKR:01"))
        return out

    async def connect(
        self,
        address: str,
        on_notify: NotifyCallback,
        on_disconnect: Optional[DisconnectCallback] = None,
        *,
        write_uuid: str | None = None,
        notify_uuid: str | None = None,
    ) -> None:
        _ = (write_uuid, notify_uuid)  # UUIDs not modeled in sim
        self._connected.add(address)
        self._notify[address] = on_notify
        # Note: sim backend doesn't currently model unexpected disconnects.
        # The manager will still detect "Unstable" via lack of RX.

    async def disconnect(self, address: str) -> None:
        self._connected.discard(address)
        self._streaming.discard(address)
        t = self._tasks.pop(address, None)
        if t:
            t.cancel()

    async def shutdown(self) -> None:
        for a in list(self._connected):
            await self.disconnect(a)

    async def write(
        self,
        address: str,
        payload: bytes,
        *,
        write_uuid: str | None = None,
    ) -> None:
        _ = write_uuid
        if address not in self._connected:
            raise RuntimeError(f"Not connected: {address}")
        # STREAM_START opcode is "A5" (2 bytes)
        if payload == protocol.build_payload(protocol.STREAM_START.opcode):
            self._streaming.add(address)
            if address not in self._tasks:
                self._tasks[address] = asyncio.create_task(self._run_stream(address))
        elif payload == protocol.build_payload(protocol.STREAM_STOP.opcode):
            self._streaming.discard(address)
            t = self._tasks.pop(address, None)
            if t:
                t.cancel()

    def is_connected(self, address: str) -> bool:
        return address in self._connected

    async def read(self, address: str, *, read_uuid: str) -> bytes:
        _ = read_uuid
        if address not in self._connected:
            raise RuntimeError(f"Not connected: {address}")
        return b""

    async def _run_stream(self, address: str) -> None:
        # Local import so "bleak" backend can run even if numpy isn't installed yet.
        import numpy as np

        # Emit EMG+IMU packets following the firmware_ref 'E'/'I' packet layouts.
        # Notes:
        # - Firmware timestamps are 10ms resolution (m_timeSeedApp += 10)
        # - EMG packet uses 216-byte payload (RMS+RAW), raw data = 100x uint16 samples (200 bytes)
        # - IMU packets are batched on device; here we simulate a few samples per packet + occasional drops
        phase = random.random() * math.pi * 2
        imu_packet_id = 0
        emg_packet_id = 0
        ts10 = 0  # ms, multiples of 10
        last_imu_emit = time.monotonic()
        while address in self._connected and address in self._streaming:
            cb = self._notify.get(address)
            if cb:
                # Timestamp in firmware is 10ms tick-based.
                ts10 += 100  # simulate ~10Hz EMG packet cadence (100ms)
                t_ms = int(ts10 - (ts10 % 10))

                # 100 samples (uint16), consistent with REC_EMG_DATA_SIZE structure (RMS+SNR+RAW 200 bytes)
                n_samples = 100
                x = np.linspace(0, 1, n_samples, endpoint=False)
                sig = 32768 + 12000 * np.sin(2 * math.pi * (3.0 * x) + phase)
                noise = 1500 * np.random.randn(n_samples)
                u16 = np.clip(sig + noise, 0, 65535).astype(np.uint16)

                batt_raw = 180  # arbitrary mid value in firmware units
                charge_state = 0
                emg_packet_id = (emg_packet_id + 1) & 0xFFFF
                mode = 0
                snr = 80
                rms_u16 = int(np.sqrt(np.mean((u16.astype(np.float64) - 32768.0) ** 2))) & 0xFFFF
                datalen = 216  # payload length (excluding 'S','E',len)

                frame = bytearray()
                frame.extend(b"S")
                frame.extend(b"E")
                frame.append(datalen)
                frame.append(batt_raw & 0xFF)
                frame.append(charge_state & 0xFF)
                frame.extend(int(emg_packet_id).to_bytes(2, "little"))
                frame.extend(int(t_ms).to_bytes(8, "little"))
                frame.append(mode & 0xFF)
                # data region: RMS (LE), SNR, RAW (uint16 LE)
                frame.extend(int(rms_u16).to_bytes(2, "little"))
                frame.append(snr & 0xFF)
                frame.extend(u16.astype("<u2").tobytes(order="C"))

                cb(address, bytes(frame))
                # Also emit a few IMU packets (acc/gyr/mag) around 100Hz.
                # Sometimes drop or jitter to exercise robustness.
                now = time.monotonic()
                if (now - last_imu_emit) >= 0.01:
                    last_imu_emit = now
                    if random.random() > 0.12:  # ~12% drops
                        # Create packets with 3 samples each (~30ms span at 100Hz)
                        for sensor_type in (1, 4, 6):
                            if random.random() < 0.15:
                                continue
                            imu_packet_id = (imu_packet_id + 1) & 0xFFFF
                            ts_ms = int(t_ms + random.choice([0, -10, 0, 0, 10]))
                            ts_ms = int(ts_ms - (ts_ms % 10))
                            samplingfreq = 100
                            xyz = (np.random.randn(3 * 3) * 0.05).astype(np.float32)  # 3 samples x (x,y,z)
                            payload = xyz.tobytes(order="C")
                            datalen = 15 + len(payload)
                            pkt = bytearray()
                            pkt.extend(b"S")
                            pkt.extend(b"I")
                            pkt.append(datalen & 0xFF)
                            pkt.extend(int(imu_packet_id).to_bytes(2, "little"))
                            pkt.append(sensor_type & 0xFF)
                            pkt.extend(int(ts_ms).to_bytes(8, "little"))
                            pkt.append(samplingfreq & 0xFF)
                            pkt.extend(payload)
                            cb(address, bytes(pkt))
            await asyncio.sleep(0.1)


def create_backend(kind: str) -> Backend:
    kind = (kind or "").strip().lower()
    if kind == "sim":
        return SimBackend()
    return BleakBackend()

