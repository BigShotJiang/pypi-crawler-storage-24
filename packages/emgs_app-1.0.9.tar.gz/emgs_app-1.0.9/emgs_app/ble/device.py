from __future__ import annotations

import collections
import math
import struct
import time
from dataclasses import dataclass, field
from typing import Deque, Optional

import numpy as np

from .. import config
from . import protocol


@dataclass(slots=True)
class DeviceParams:
    name: str = "/"
    address: str = "/"
    # Device kind (used to route BLE UUIDs and to enable/disable UI features).
    # - "EMGS": Nordic UART Service + EMGS protocol
    # - "AKR":   FFE0/FFE1 UART-like device (protocol TBD)
    kind: str = "EMGS"
    status: str = "Disconnected"
    timestamp: str = "/"
    battery: str = "/"
    mode: str = "/"
    firmware: str = "/"
    hardware: str = "/"
    dsp: str = "/"
    conn_interval: str = "/"


@dataclass(slots=True)
class EmgsDevice:
    """Per-device state (UI-friendly) + minimal decode hooks.

    The actual binary frame formats are still evolving; keep decoding isolated here.
    """

    params: DeviceParams
    is_connected: bool = False
    is_streaming: bool = False
    is_charging: bool = False
    # Connection health: updated on any RX notify packet.
    last_rx_monotonic_s: Optional[float] = None

    # Modes (mirrors EMGS_v4 semantics)
    icm_enabled: list[bool] = field(default_factory=lambda: [False] * 9)
    emg_mode: int = 0  # 0 OFF, 1 RMS, 2 RAW

    # Host-side processing toggles (latched at stream start by EmgsManager).
    proc_enable_emg_rms_envelope: bool = False
    proc_emg_rms_window_n: int = config.EMG_RMS_WINDOW_N
    proc_enable_emg_freq_features: bool = False
    proc_emg_spec_window_n: int = config.EMG_SPEC_WINDOW_N
    # Unsupervised fatigue score (heuristic) configuration.
    # NOTE: This requires spectral features (MDF/MNF) to be enabled to produce MDF.
    proc_enable_emg_fatigue: bool = config.EMG_FATIGUE_ENABLE_DEFAULT
    proc_emg_fatigue_baseline_s: float = config.EMG_FATIGUE_BASELINE_S
    proc_emg_fatigue_weight_mdf_pct: float = config.EMG_FATIGUE_WEIGHT_MDF_PCT
    proc_emg_fatigue_weight_rms_pct: float = config.EMG_FATIGUE_WEIGHT_RMS_PCT
    proc_emg_fatigue_conf_recent_n: int = config.EMG_FATIGUE_CONF_RECENT_N

    # Ring buffers: (t_rel_s, samples)
    # EMGS_v1 streams one EMG channel per device; keep samples as list[float] for extensibility.
    emg_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    # Derived EMG: RMS envelope at raw sample timestamps
    emg_rms_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    # Derived EMG (spectral features): computed over a sliding window (updated per packet).
    emg_median_freq_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    emg_mean_freq_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    # Last computed EMG spectrum (relative power, dB): (freq_hz, power_db)
    emg_spectrum_last: Optional[tuple[np.ndarray, np.ndarray]] = None
    # Last computed EMG spectrum (relative linear power): (freq_hz, power_rel)
    # where power_rel is normalized to [0..1] by dividing by max power in the window.
    emg_spectrum_last_linear: Optional[tuple[np.ndarray, np.ndarray]] = None
    # Unsupervised fatigue score/confidence (0..1), updated alongside spectral features.
    emg_fatigue_score_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    emg_fatigue_conf_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    # Packet-provided RMS value (one per EMG packet). This is NOT the computed envelope.
    # Typically ~10 Hz (packet rate), depending on firmware.
    emg_packet_rms_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    # Packet-provided SNR value (one per EMG packet). Typically ~10 Hz (packet rate).
    emg_snr_buffer: Deque[tuple[float, list[float]]] = field(
        default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN)
    )
    # IMU is streamed as separate packets per sensor type; keep separate buffers per meaning
    # so the GUI can offer meaningful "raw/cal/linear/etc." channel choices.
    raw_acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    lin_acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    raw_gyr_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    gyr_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    uncal_mag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    mag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    quat_game_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    quat_geomag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    # --- AKR / RR_AKR text-stream fields ---
    # AKR devices may emit human-readable status lines like:
    #   RR_AKR step_dt=20 ms exec=0 ms out=0 state=0 acc=[...] gyr=[...] mag=[...]
    # We parse these in the manager and store them here as time series for plotting/recording.
    akr_origin_monotonic_s: Optional[float] = None  # origin for AKR time axis (monotonic seconds)
    akr_step_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_exec_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_out_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    # --- AKR / RR telemetry binary stream (rr_telem.*) ---
    # Walk (AKR) packet fields
    akr_walk_fid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_exec_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_out_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))  # x,y,z
    akr_walk_gyr_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))  # x,y,z
    akr_walk_mag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))  # x,y,z
    akr_walk_pos_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_vel_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_tq_nm_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_temp_c_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_vbus_v_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_pattern_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_err_code_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_fb_age_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    # CPM packet fields
    akr_cpm_fid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_dir_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_blocked_event_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_blocked_consecutive_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_cmd_spd_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_pos_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_vel_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_tq_nm_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_temp_c_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_vbus_v_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_pattern_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_err_code_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_fb_age_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_df_limit_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_pf_limit_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_elapsed_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_repetition_count_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    # Test packet fields (rr_telem TYPE_TEST / 0x03)
    akr_test_fid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_dir_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_blocked_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_result_flags_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_pos_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_vel_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_tq_nm_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_temp_c_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_vbus_v_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_pattern_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_err_code_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_fb_age_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_prom_df_end_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_prom_pf_end_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_arom_df_max_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_arom_pf_min_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_prom_df_valid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_prom_pf_valid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_arom_valid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_seq_active_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_arom_running_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    last_emg_time_s: Optional[float] = None
    last_imu_time_s: Optional[float] = None
    emg_frames_total: int = 0
    imu_frames_total: int = 0
    last_emg_snr: Optional[int] = None
    last_emg_rms_raw: Optional[int] = None
    last_emg_rms_u16: Optional[int] = None
    # Advanced settings/telemetry (queried via 'S''A' responses)
    power_safe_lvl_percent: Optional[int] = None
    emg_threshold: Optional[int] = None
    storage_threshold_percent: Optional[int] = None
    icm_freq: dict[int, int] = field(default_factory=dict)   # sensor_type -> Hz
    icm_scale: dict[int, int] = field(default_factory=dict)  # sensor_type -> scale code
    icm_bias_acc: Optional[tuple[int, int, int]] = None
    icm_bias_gyr: Optional[tuple[int, int, int]] = None
    icm_bias_mag: Optional[tuple[int, int, int]] = None
    # Clock health (computed from TIME_SYNC/GET_TIMESTAMP replies in manager)
    last_device_ts_ms: Optional[int] = None
    last_host_ts_ms: Optional[int] = None
    clock_delta_ms: Optional[int] = None  # device_ms - host_ms
    # Gap/jitter diagnostics
    last_emg_packet_id: Optional[int] = None
    last_emg_packet_ts_ms: Optional[int] = None
    last_imu_packet_ts_ms: Optional[int] = None
    emg_missing_samples_est: int = 0

    imu_anomaly_count: int = 0
    # Per IMU sensor type (1=acc,4=gyr,6=mag): last packet timestamp + packet_id + sample timing
    _imu_last_packet_id: dict[int, int] = field(default_factory=dict)
    _imu_last_packet_ts_ms: dict[int, int] = field(default_factory=dict)
    _imu_last_sample_t_ms: dict[int, float] = field(default_factory=dict)
    # Sliding window state for RMS envelope (sample-count based; last N samples)
    _emg_rms_sq_window: Deque[float] = field(default_factory=collections.deque)
    _emg_rms_sq_sum: float = 0.0
    # Unsupervised fatigue baseline + trend trackers (session scoped).
    _fatigue_t0_s: Optional[float] = None
    _fatigue_baseline_mdf: Deque[float] = field(default_factory=collections.deque)
    _fatigue_baseline_rms: Deque[float] = field(default_factory=collections.deque)
    _fatigue_recent_mdf: Deque[float] = field(default_factory=collections.deque)

    def reset(self) -> None:
        self.is_connected = False
        self.is_streaming = False
        self.is_charging = False
        self.last_rx_monotonic_s = None
        self.icm_enabled = [False] * 9
        self.emg_mode = 0
        self.emg_buffer.clear()
        self.emg_rms_buffer.clear()
        self.emg_median_freq_buffer.clear()
        self.emg_mean_freq_buffer.clear()
        self.emg_packet_rms_buffer.clear()
        self.emg_snr_buffer.clear()
        self.emg_spectrum_last = None
        self.emg_spectrum_last_linear = None
        self.emg_fatigue_score_buffer.clear()
        self.emg_fatigue_conf_buffer.clear()
        self.raw_acc_buffer.clear()
        self.acc_buffer.clear()
        self.lin_acc_buffer.clear()
        self.raw_gyr_buffer.clear()
        self.gyr_buffer.clear()
        self.uncal_mag_buffer.clear()
        self.mag_buffer.clear()
        self.quat_game_buffer.clear()
        self.quat_geomag_buffer.clear()
        self.akr_origin_monotonic_s = None
        self.akr_step_dt_ms_buffer.clear()
        self.akr_exec_ms_buffer.clear()
        self.akr_out_buffer.clear()
        self.akr_state_buffer.clear()
        self.akr_walk_fid_buffer.clear()
        self.akr_walk_dt_ms_buffer.clear()
        self.akr_walk_exec_ms_buffer.clear()
        self.akr_walk_out_buffer.clear()
        self.akr_walk_state_buffer.clear()
        self.akr_walk_acc_buffer.clear()
        self.akr_walk_gyr_buffer.clear()
        self.akr_walk_mag_buffer.clear()
        self.akr_walk_pos_rad_buffer.clear()
        self.akr_walk_vel_rad_s_buffer.clear()
        self.akr_walk_tq_nm_buffer.clear()
        self.akr_walk_temp_c_buffer.clear()
        self.akr_walk_vbus_v_buffer.clear()
        self.akr_walk_pattern_buffer.clear()
        self.akr_walk_err_code_buffer.clear()
        self.akr_walk_fb_age_ms_buffer.clear()
        self.akr_cpm_fid_buffer.clear()
        self.akr_cpm_dt_ms_buffer.clear()
        self.akr_cpm_state_buffer.clear()
        self.akr_cpm_dir_buffer.clear()
        self.akr_cpm_blocked_event_buffer.clear()
        self.akr_cpm_blocked_consecutive_buffer.clear()
        self.akr_cpm_cmd_spd_rad_s_buffer.clear()
        self.akr_cpm_pos_rad_buffer.clear()
        self.akr_cpm_vel_rad_s_buffer.clear()
        self.akr_cpm_tq_nm_buffer.clear()
        self.akr_cpm_temp_c_buffer.clear()
        self.akr_cpm_vbus_v_buffer.clear()
        self.akr_cpm_pattern_buffer.clear()
        self.akr_cpm_err_code_buffer.clear()
        self.akr_cpm_fb_age_ms_buffer.clear()
        self.akr_cpm_df_limit_rad_buffer.clear()
        self.akr_cpm_pf_limit_rad_buffer.clear()
        self.akr_cpm_elapsed_s_buffer.clear()
        self.akr_cpm_repetition_count_buffer.clear()
        self.akr_test_fid_buffer.clear()
        self.akr_test_dt_ms_buffer.clear()
        self.akr_test_state_buffer.clear()
        self.akr_test_dir_buffer.clear()
        self.akr_test_blocked_buffer.clear()
        self.akr_test_result_flags_buffer.clear()
        self.akr_test_pos_rad_buffer.clear()
        self.akr_test_vel_rad_s_buffer.clear()
        self.akr_test_tq_nm_buffer.clear()
        self.akr_test_temp_c_buffer.clear()
        self.akr_test_vbus_v_buffer.clear()
        self.akr_test_pattern_buffer.clear()
        self.akr_test_err_code_buffer.clear()
        self.akr_test_fb_age_ms_buffer.clear()
        self.akr_test_prom_df_end_rad_buffer.clear()
        self.akr_test_prom_pf_end_rad_buffer.clear()
        self.akr_test_arom_df_max_rad_buffer.clear()
        self.akr_test_arom_pf_min_rad_buffer.clear()
        self.akr_test_flag_prom_df_valid_buffer.clear()
        self.akr_test_flag_prom_pf_valid_buffer.clear()
        self.akr_test_flag_arom_valid_buffer.clear()
        self.akr_test_flag_seq_active_buffer.clear()
        self.akr_test_flag_arom_running_buffer.clear()
        self.last_emg_time_s = None
        self.last_imu_time_s = None
        self.emg_frames_total = 0
        self.imu_frames_total = 0
        self.last_emg_snr = None
        self.last_emg_rms_raw = None
        self.last_emg_rms_u16 = None
        self.power_safe_lvl_percent = None
        self.emg_threshold = None
        self.storage_threshold_percent = None
        self.icm_freq.clear()
        self.icm_scale.clear()
        self.icm_bias_acc = None
        self.icm_bias_gyr = None
        self.icm_bias_mag = None
        self.last_device_ts_ms = None
        self.last_host_ts_ms = None
        self.clock_delta_ms = None
        self.last_emg_packet_id = None
        self.last_emg_packet_ts_ms = None
        self.last_imu_packet_ts_ms = None
        self.emg_missing_samples_est = 0
        self.imu_anomaly_count = 0
        self._imu_last_packet_id.clear()
        self._imu_last_packet_ts_ms.clear()
        self._imu_last_sample_t_ms.clear()
        self._emg_rms_sq_window.clear()
        self._emg_rms_sq_sum = 0.0
        self._fatigue_t0_s = None
        self._fatigue_baseline_mdf.clear()
        self._fatigue_baseline_rms.clear()
        self._fatigue_recent_mdf.clear()
        # Processing toggles are session-configured; keep default on reset.
        self.proc_enable_emg_rms_envelope = False
        self.proc_emg_rms_window_n = int(getattr(config, "EMG_RMS_WINDOW_N", 100))
        self.proc_enable_emg_freq_features = False
        self.proc_emg_spec_window_n = int(getattr(config, "EMG_SPEC_WINDOW_N", 1000))
        self.proc_enable_emg_fatigue = bool(getattr(config, "EMG_FATIGUE_ENABLE_DEFAULT", False))
        self.proc_emg_fatigue_baseline_s = float(getattr(config, "EMG_FATIGUE_BASELINE_S", 10.0))
        self.proc_emg_fatigue_weight_mdf_pct = float(getattr(config, "EMG_FATIGUE_WEIGHT_MDF_PCT", 70.0))
        self.proc_emg_fatigue_weight_rms_pct = float(getattr(config, "EMG_FATIGUE_WEIGHT_RMS_PCT", 30.0))
        self.proc_emg_fatigue_conf_recent_n = int(getattr(config, "EMG_FATIGUE_CONF_RECENT_N", 60))
        self.params.status = "Disconnected"

    def _push_emg_rms(self, t_s: float, emg: float) -> float:
        """Update RMS envelope using a sliding sample-count window and return current RMS."""
        _ = t_s  # time not used in sample-count RMS
        v2 = float(emg) * float(emg)
        self._emg_rms_sq_window.append(v2)
        self._emg_rms_sq_sum += v2

        # Keep only the last N samples.
        n_max = int(getattr(self, "proc_emg_rms_window_n", getattr(config, "EMG_RMS_WINDOW_N", 100)))
        if n_max <= 0:
            n_max = 1
        while len(self._emg_rms_sq_window) > n_max:
            old_v2 = float(self._emg_rms_sq_window.popleft())
            self._emg_rms_sq_sum -= old_v2

        n = len(self._emg_rms_sq_window)
        if n <= 0:
            return 0.0
        return float(math.sqrt(max(0.0, self._emg_rms_sq_sum / float(n))))

    def _compute_emg_spectral_features(
        self, x: np.ndarray, fs_hz: float
    ) -> tuple[
        float,
        float,
        tuple[np.ndarray, np.ndarray] | None,
        tuple[np.ndarray, np.ndarray] | None,
    ]:
        """Compute (median_freq, mean_freq, spectrum_db, spectrum_linear).

        spectrum_db is 10*log10(relative_power), so values are typically <= 0 dB.
        spectrum_linear is relative linear power in [0..1].
        """
        if x.size < 8:
            return 0.0, 0.0, None, None
        # Remove DC and window to reduce leakage.
        x0 = x.astype(float) - float(np.mean(x))
        w = np.hanning(int(x0.size))
        xw = x0 * w
        X = np.fft.rfft(xw)
        P = (X.real * X.real + X.imag * X.imag)
        f = np.fft.rfftfreq(int(xw.size), d=1.0 / float(fs_hz))
        # Drop DC for these metrics.
        if f.size > 1:
            f = f[1:]
            P = P[1:]
        tot = float(np.sum(P))
        if not math.isfinite(tot) or tot <= 0.0:
            return 0.0, 0.0, None, None
        mean_f = float(np.sum(f * P) / tot)
        c = np.cumsum(P)
        mdf = float(f[int(np.searchsorted(c, 0.5 * c[-1], side="left"))]) if c.size else 0.0
        # Relative (normalized) power for display: stable y-range across sessions.
        p_max = float(np.max(P)) if P.size else 0.0
        if not math.isfinite(p_max) or p_max <= 0.0:
            return mdf, mean_f, None, None
        p_rel = P / (p_max + 1e-12)
        p_db = 10.0 * np.log10(p_rel + 1e-12)
        return mdf, mean_f, (f, p_db), (f, p_rel)

    def _emg_u16_to_mv(self, r_u16: int) -> float:
        """Convert EMG ADC reading (uint16) to mV using config constants."""
        r = float(r_u16)
        v = (r / float(config.EMG_ADC_MAX)) * float(config.EMG_ADC_FULL_SCALE_V) - float(config.EMG_ADC_MID_V)
        return float(v / float(config.EMG_GAIN_V_PER_V) * float(config.EMG_OUTPUT_SCALE))

    def _emg_u16_to_v(self, r_u16: int) -> float:
        """Convert EMG ADC reading (uint16) to volts in [0..Vref]."""
        r = float(r_u16)
        return float((r / float(config.EMG_ADC_MAX)) * float(config.EMG_ADC_FULL_SCALE_V))

    def mark_unstable(self) -> None:
        if self.is_connected:
            self.params.status = "Unstable"

    def set_connected(self, connected: bool) -> None:
        self.is_connected = connected
        self.params.status = "Connected" if connected else "Disconnected"

    def decode_notification(self, data: bytes) -> None:
        """Decode a notify packet from EMGS.

        Current placeholder logic is compatible with EMGS_v4:
        - header: 'S'
        - type: one of protocol.PacketType.*
        """
        if not data or len(data) < 3:
            return
        if chr(data[0]) != "S":
            return

        pkt_type = chr(data[1])
        if pkt_type == protocol.PacketType.CHARGING:
            self.is_charging = (data[2] == 1)
            return

        if pkt_type == protocol.PacketType.APP_HELPER:
            self._decode_app_helper(data)
            return

        if pkt_type == protocol.PacketType.DATA_EMG:
            self._decode_emg_fw(data)
            return

        if pkt_type == protocol.PacketType.DATA_IMU:
            self._decode_imu_fw(data)
            return

    def _decode_app_helper(self, data: bytes) -> None:
        # Firmware_ref: 'S' 'A' <cmd> <payload...>
        cmd = chr(data[2])

        try:
            if cmd == "0":  # get firmware/hardware version + batt/charge
                batt = int(data[3])
                charge = int(data[4])
                self.is_charging = (charge == 1)
                # Firmware uses batt as a raw byte; convert to % with the same scaling used elsewhere.
                batt_lo = int(3.10 * 50.0)
                batt_hi = int(4.15 * 50.0)
                batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
                batt_val = max(0.0, min(100.0, batt_val))
                self.params.battery = f"{batt_val:1.0f} %"

                fw = int(data[5]) << 8 | int(data[6])
                hw = int(data[7]) << 8 | int(data[8])
                self.params.firmware = f"{(fw >> 8) & 0xFF}.{fw & 0xFF}"
                self.params.hardware = f"{(hw >> 8) & 0xFF}.{hw & 0xFF}"
            elif cmd == "3":  # time sync: batt/charge + timestamp (ms, 10ms ticks)
                batt = int(data[3])
                charge = int(data[4])
                self.is_charging = (charge == 1)
                batt_lo = int(3.10 * 50.0)
                batt_hi = int(4.15 * 50.0)
                batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
                batt_val = max(0.0, min(100.0, batt_val))
                self.params.battery = f"{batt_val:1.0f} %"
                ts_ms = int(struct.unpack_from("<Q", data, 5)[0])
                self.params.timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts_ms / 1000.0))
            elif cmd == "K":  # name
                raw = data[3:15]  # 12 bytes
                name = bytes(raw).split(b"\x00", 1)[0].decode("ascii", errors="ignore")
                if name:
                    self.params.name = name
            elif cmd == "n":  # conn interval
                mi = struct.unpack_from("<H", data, 3)[0]
                ma = struct.unpack_from("<H", data, 5)[0]
                self.params.conn_interval = f"{mi},{ma}"
            elif cmd == "X":  # get icm enable: resp[3]=sensor_type, resp[4]=enabled
                idx = int(data[3])
                val = (int(data[4]) == 1)
                if 0 <= idx < len(self.icm_enabled):
                    self.icm_enabled[idx] = val
                    self._update_mode_string()
            elif cmd == "x":  # get emg option: resp[3]=emgOption (0/1/2)
                self.emg_mode = int(data[3])
                self._update_mode_string()
            elif cmd == "s":  # get low batt lvl (power safe)
                self.power_safe_lvl_percent = int(data[3])
            elif cmd == "T":  # get EMG threshold
                self.emg_threshold = int(struct.unpack_from("<H", data, 3)[0])
            elif cmd == "V":  # get out-of-storage threshold
                self.storage_threshold_percent = int(data[3])
            elif cmd == "Z":  # get icm freq: resp[3]=sensor_type resp[4]=freq
                self.icm_freq[int(data[3])] = int(data[4])
            elif cmd == "D":  # get icm scale: resp[3]=sensor_type resp[4]=scale
                self.icm_scale[int(data[3])] = int(data[4])
            elif cmd == "B":  # get bias response (acc/gyr/mag, 3x int32 LE each)
                bias_acc = []
                bias_gyr = []
                bias_mag = []
                for i in range(3):
                    bias_acc.append(int(struct.unpack_from("<i", data, 3 + i * 4)[0]))
                    bias_gyr.append(int(struct.unpack_from("<i", data, 15 + i * 4)[0]))
                    bias_mag.append(int(struct.unpack_from("<i", data, 27 + i * 4)[0]))
                self.icm_bias_acc = tuple(bias_acc)  # type: ignore[assignment]
                self.icm_bias_gyr = tuple(bias_gyr)  # type: ignore[assignment]
                self.icm_bias_mag = tuple(bias_mag)  # type: ignore[assignment]
            elif cmd == "a":  # dsp version reply: batt/charge + 3 bytes
                batt = int(data[3])
                charge = int(data[4])
                self.is_charging = (charge == 1)
                batt_lo = int(3.10 * 50.0)
                batt_hi = int(4.15 * 50.0)
                batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
                batt_val = max(0.0, min(100.0, batt_val))
                self.params.battery = f"{batt_val:1.0f} %"
                # 3 version bytes (keep dotted)
                self.params.dsp = f"{int(data[5])}.{int(data[6])}.{int(data[7])}"
            elif cmd == "G":  # get timestamp (ms ticks)
                ts_ms = int(struct.unpack_from("<Q", data, 3)[0])
                self.params.timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts_ms / 1000.0))
            elif cmd == "5":  # stream start ack
                self.is_streaming = True
            elif cmd == "7":  # stream stop ack
                self.is_streaming = False
        except Exception:
            # Keep decode resilient; detailed logging happens in controller layer
            return

    def _update_mode_string(self) -> None:
        # Firmware_ref sensor types (0..8):
        # 0 raw_acc, 1 acc, 2 linear_acc, 3 raw_gyr, 4 gyr, 5 uncal_mag, 6 mag, 7 quat, 8 geomag quat
        sensors: list[str] = []
        if self.icm_enabled[0]:
            sensors.append("RACC")
        if self.icm_enabled[1]:
            sensors.append("ACC")
        if self.icm_enabled[2]:
            sensors.append("LIN")
        if self.icm_enabled[3]:
            sensors.append("RGYR")
        if self.icm_enabled[4]:
            sensors.append("GYR")
        if self.icm_enabled[5]:
            sensors.append("UMAG")
        if self.icm_enabled[6]:
            sensors.append("MAG")
        if self.icm_enabled[7]:
            sensors.append("QUAT")
        if self.icm_enabled[8]:
            sensors.append("GEOQ")

        emg = {0: "EMG:OFF", 1: "EMG:RMS", 2: "EMG:RMS+RAW"}.get(int(self.emg_mode), "EMG:?")
        txt = " ".join(sensors) if sensors else "-"
        self.params.mode = f"{txt} • {emg}"

    def _decode_emg_fw(self, data: bytes) -> None:
        """Decode EMG packet format from `firmware_ref/.../application.h`.

        Layout:
        - [0] 'S'
        - [1] 'E'
        - [2] payload_len (uint8): 216 (RMS+RAW) or 16 (RMS-only)
        - [3] batt (uint8)
        - [4] chargeState (uint8)
        - [5:7] packet_id (uint16 LE)
        - [7:15] timestamp_ms (uint64 LE)  (10ms resolution in firmware)
        - [15] packet_mode_pos (uint8) (EMGS sensor-side header; e.g. sampling freq hint)
        - [16:] data (payload_len - 13 bytes == 3 or 203):
            - byte0..1: RMS (uint16, **endianness is sensor-side**; DSP sends MSB then LSB)
            - byte2: SNR (uint8)
            - byte3..: raw samples (200 bytes => 100x uint16, **endianness is sensor-side**; EMGS_v1 treats as big-endian)
        """
        if len(data) < 16:
            return
        try:
            payload_len = int(data[2])
            if len(data) < payload_len + 3:
                return
            batt = int(data[3])
            charge_state = int(data[4])
            packet_id = int(struct.unpack_from("<H", data, 5)[0])
            timestamp_ms = int(struct.unpack_from("<Q", data, 7)[0])

            self.is_charging = (charge_state == 1)
            # Battery % scaling (same mapping used in earlier code; matches firmware usage)
            batt_lo = int(3.10 * 50.0)
            batt_hi = int(4.15 * 50.0)
            batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
            batt_val = max(0.0, min(100.0, batt_val))
            self.params.battery = f"{batt_val:1.0f} %"

            # Gap estimation from packet_id (firmware may skip sending when remainingEmgBuf<=0)
            if self.last_emg_packet_id is not None:
                gap = (packet_id - self.last_emg_packet_id) & 0xFFFF
                if gap > 1:
                    # In RMS+RAW mode, each packet typically includes 100 samples.
                    self.emg_missing_samples_est += (gap - 1) * 100

            data_pos = 16
            data_bytes = data[data_pos : 3 + payload_len]
            if len(data_bytes) >= 3:
                # Firmware forwards EMGS sensor bytes without endian conversion.
                # Ground truth (DSP firmware): RMS is MSB/LSB first, then SNR.
                rms_u16 = int(struct.unpack_from(">H", data_bytes, 0)[0])
                snr = int(data_bytes[2])
                self.last_emg_snr = snr
                self.last_emg_rms_u16 = rms_u16
                # Packet SNR: one sample per packet at the packet timestamp.
                self.emg_snr_buffer.append((float(timestamp_ms) / 1000.0, [float(snr)]))
                # Packet RMS: one sample per packet at the packet timestamp (10 Hz-ish).
                # DSP packs RMS as uint16 over 0..Vref (3.0 V), so decode to volts only.
                rms_v = self._emg_u16_to_v(int(rms_u16))
                self.emg_packet_rms_buffer.append((float(timestamp_ms) / 1000.0, [float(rms_v)]))

            # If RAW is present, decode raw samples (assume 100 samples of uint16 LE)
            if payload_len == 216 and len(data_bytes) >= 203:
                raw = data_bytes[3:203]
                if len(raw) == 200:
                    # Endianness is sensor-side; EMGS_v1 treats these as big-endian.
                    readings = struct.unpack_from(">100H", raw, 0)
                    # Approximate per-sample time axis: use packet timestamp + i ms.
                    # NOTE: firmware timestamp is 10ms resolution; this is best-effort.
                    for i, r in enumerate(readings):
                        emg = self._emg_u16_to_mv(int(r))
                        t_s = (float(timestamp_ms) + float(i)) / 1000.0
                        self.emg_buffer.append((t_s, [float(emg)]))
                        if self.proc_enable_emg_rms_envelope:
                            rms = self._push_emg_rms(t_s, float(emg))
                            self.emg_rms_buffer.append((t_s, [float(rms)]))

                    # Spectral features (compute once per packet over the last N samples).
                    if self.proc_enable_emg_freq_features:
                        n_win = int(getattr(self, "proc_emg_spec_window_n", getattr(config, "EMG_SPEC_WINDOW_N", 1000)))
                        if n_win > 0:
                            vals: list[float] = []
                            for _ts, s in reversed(self.emg_buffer):
                                if s:
                                    vals.append(float(s[0]))
                                    if len(vals) >= n_win:
                                        break
                            if len(vals) >= max(8, min(n_win, 64)):
                                vals.reverse()
                                x = np.asarray(vals, dtype=float)
                                fs = float(getattr(config, "EMG_SAMPLE_RATE_HZ", 1000))
                                mdf, mnf, spec_db, spec_lin = self._compute_emg_spectral_features(x, fs)
                                t_feat = float(self.emg_buffer[-1][0]) if self.emg_buffer else (float(timestamp_ms) / 1000.0)
                                self.emg_median_freq_buffer.append((t_feat, [float(mdf)]))
                                self.emg_mean_freq_buffer.append((t_feat, [float(mnf)]))
                                self.emg_spectrum_last = spec_db
                                self.emg_spectrum_last_linear = spec_lin

                                # --- Unsupervised fatigue score (heuristic; optional) ---
                                if self.proc_enable_emg_fatigue:
                                    baseline_s = float(getattr(self, "proc_emg_fatigue_baseline_s", getattr(config, "EMG_FATIGUE_BASELINE_S", 10.0)))
                                    baseline_s = float(max(0.5, min(600.0, baseline_s)))
                                    recent_n = int(getattr(self, "proc_emg_fatigue_conf_recent_n", getattr(config, "EMG_FATIGUE_CONF_RECENT_N", 60)))
                                    recent_n = int(max(4, min(2000, recent_n)))

                                    w_mdf_pct = float(getattr(self, "proc_emg_fatigue_weight_mdf_pct", getattr(config, "EMG_FATIGUE_WEIGHT_MDF_PCT", 70.0)))
                                    w_rms_pct = float(getattr(self, "proc_emg_fatigue_weight_rms_pct", getattr(config, "EMG_FATIGUE_WEIGHT_RMS_PCT", 30.0)))
                                    w_sum = float(max(1e-9, max(0.0, w_mdf_pct) + max(0.0, w_rms_pct)))
                                    w_mdf = float(max(0.0, w_mdf_pct) / w_sum)
                                    w_rms = float(max(0.0, w_rms_pct) / w_sum)

                                    # Baseline: first N seconds of feature updates (session-specific).
                                    if self._fatigue_t0_s is None:
                                        self._fatigue_t0_s = float(t_feat)

                                    # RMS from the same window used for the FFT (robust even if envelope is disabled).
                                    try:
                                        rms_win = float(math.sqrt(max(0.0, float(np.mean(x * x)))))
                                    except Exception:
                                        rms_win = 0.0

                                    # Track baseline (first baseline_s).
                                    if float(t_feat) - float(self._fatigue_t0_s) <= float(baseline_s):
                                        self._fatigue_baseline_mdf.append(float(mdf))
                                        self._fatigue_baseline_rms.append(float(rms_win))
                                        # Cap baseline memory (~1 minute worth of feature updates).
                                        cap = int(max(50, min(2000, baseline_s * 100.0)))
                                        while len(self._fatigue_baseline_mdf) > cap:
                                            self._fatigue_baseline_mdf.popleft()
                                        while len(self._fatigue_baseline_rms) > cap:
                                            self._fatigue_baseline_rms.popleft()

                                    # Recent MDF for confidence (monotonicity).
                                    self._fatigue_recent_mdf.append(float(mdf))
                                    while len(self._fatigue_recent_mdf) > int(recent_n):
                                        self._fatigue_recent_mdf.popleft()

                                    # Compute score when baseline has at least a few points.
                                    base_mdf = float(np.median(np.asarray(self._fatigue_baseline_mdf, dtype=float))) if self._fatigue_baseline_mdf else 0.0
                                    base_rms = float(np.median(np.asarray(self._fatigue_baseline_rms, dtype=float))) if self._fatigue_baseline_rms else 0.0
                                    if base_mdf > 0.0 and base_rms > 0.0:
                                        mdf_drop = (base_mdf - float(mdf)) / (base_mdf + 1e-9)
                                        rms_rise = (float(rms_win) - base_rms) / (base_rms + 1e-9)
                                        score = float(max(0.0, min(1.0, w_mdf * mdf_drop + w_rms * rms_rise)))
                                    else:
                                        score = 0.0

                                    # Confidence heuristic: fraction of recent steps where MDF decreased.
                                    conf = 0.2
                                    try:
                                        arr = np.asarray(self._fatigue_recent_mdf, dtype=float)
                                        if arr.size >= 4:
                                            down = float(np.mean(np.diff(arr) < 0.0))
                                            conf = float(max(0.0, min(1.0, 0.2 + 0.8 * down)))
                                    except Exception:
                                        conf = 0.2

                                    self.emg_fatigue_score_buffer.append((t_feat, [score]))
                                    self.emg_fatigue_conf_buffer.append((t_feat, [conf]))

            self.last_emg_time_s = time.monotonic()
            self.emg_frames_total += 1
            self.last_emg_packet_id = packet_id
            self.last_emg_packet_ts_ms = timestamp_ms
        except Exception:
            return

    def _decode_imu_fw(self, data: bytes) -> None:
        """Decode IMU packet format from `firmware_ref/.../imu.c` and `application.h`.

        Layout:
        - [0] 'S'
        - [1] 'I'
        - [2] payload_len (uint8) == total bytes sent including 'S'..?? (firmware sets to dataLen)
        - [3:5] packet_id (uint16 LE)  (global counter across sensor types)
        - [5] sensor_type (0..8)
        - [6:14] timestamp_ms (uint64 LE) from m_timestamp_imu (10ms resolution)
        - [14] samplingfreq_hz (uint8)
        - [15:] samples (packed by sensor type):
            - RAW ACC (0) / RAW GYR (3): repeated int16 x3 (LE) => 6 bytes per sample
            - ACC (1) / LIN ACC (2) / GYR (4) / UNCAL MAG (5) / MAG (6): repeated float32 x3 (LE) => 12 bytes/sample
            - QUAT (7) / GEO MAG ROT (8): repeated float32 x4 (LE) => 16 bytes/sample
        """
        if len(data) < 15:
            return
        try:
            sensor_type = int(data[5])
            timestamp_ms = int(struct.unpack_from("<Q", data, 6)[0])
            self.last_imu_packet_ts_ms = int(timestamp_ms)
            samplingfreq_hz = int(data[14]) or 100
            dt_ms = 1000.0 / float(samplingfreq_hz)

            raw = data[15:]
            if not raw:
                return

            # Determine per-sample struct based on sensor type
            if sensor_type in (0, 3):
                sample_size = 6
                n = len(raw) // sample_size
                if n <= 0:
                    return
                # Supplier semantics: packet timestamp is the time of the FIRST sample in the packet.
                base_ms = float(timestamp_ms)
                for k in range(n):
                    x, y, z = struct.unpack_from("<3h", raw, k * sample_size)
                    t_s = (base_ms + k * dt_ms) / 1000.0
                    buf = self.raw_acc_buffer if sensor_type == 0 else self.raw_gyr_buffer
                    buf.append((t_s, [float(x), float(y), float(z)]))
                self._imu_last_sample_t_ms[sensor_type] = base_ms + (n - 1) * dt_ms
            elif sensor_type in (7, 8):
                sample_size = 16
                n = len(raw) // sample_size
                if n <= 0:
                    return
                base_ms = float(timestamp_ms)
                for k in range(n):
                    q = struct.unpack_from("<4f", raw, k * sample_size)
                    sample_ms = float(base_ms + k * dt_ms)
                    t_s = sample_ms / 1000.0
                    buf = self.quat_game_buffer if sensor_type == 7 else self.quat_geomag_buffer
                    buf.append((t_s, [float(q[0]), float(q[1]), float(q[2]), float(q[3])]))
                self._imu_last_sample_t_ms[sensor_type] = base_ms + (n - 1) * dt_ms
            else:
                sample_size = 12
                n = len(raw) // sample_size
                if n <= 0:
                    return
                base_ms = float(timestamp_ms)
                for k in range(n):
                    x, y, z = struct.unpack_from("<3f", raw, k * sample_size)
                    t_s = (base_ms + k * dt_ms) / 1000.0
                    if sensor_type in (1, 2):
                        buf = self.acc_buffer if sensor_type == 1 else self.lin_acc_buffer
                        buf.append((t_s, [float(x), float(y), float(z)]))
                    elif sensor_type == 4:
                        self.gyr_buffer.append((t_s, [float(x), float(y), float(z)]))
                    elif sensor_type == 5:
                        self.uncal_mag_buffer.append((t_s, [float(x), float(y), float(z)]))
                    elif sensor_type == 6:
                        self.mag_buffer.append((t_s, [float(x), float(y), float(z)]))
                    else:
                        pass
                self._imu_last_sample_t_ms[sensor_type] = base_ms + (n - 1) * dt_ms

            self.last_imu_time_s = time.monotonic()
            self.imu_frames_total += 1
        except Exception:
            return

