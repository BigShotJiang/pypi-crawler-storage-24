from __future__ import annotations

from datetime import datetime
from pathlib import Path
import subprocess
import sys
import traceback


def _missing_dep_hint(mod: str) -> str:
    return (
        f"Missing dependency: {mod}\n\n"
        "Install from git (recommended):\n"
        '  pip install "emgs-app @ git+https://<REPO_URL>.git"\n\n'
        "Or, from a local checkout:\n"
        "  python -m venv .venv\n"
        "  source .venv/bin/activate   # Windows: .venv\\Scripts\\activate\n"
        "  pip install -e .\n"
    )


def _runtime_log_dir() -> Path:
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Logs" / "emgs-app"
    return Path.home() / ".emgs-app" / "logs"


def _write_startup_log(title: str, message: str, exc: BaseException | None = None) -> Path | None:
    try:
        log_dir = _runtime_log_dir()
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = log_dir / f"startup-{stamp}.log"
        lines = [f"{title}\n", f"{message}\n"]
        if exc is not None:
            lines.append("\nTraceback:\n")
            lines.append("".join(traceback.format_exception(exc)))
        path.write_text("".join(lines), encoding="utf-8")
        return path
    except Exception:
        return None


def _show_startup_alert(title: str, message: str) -> None:
    # For macOS app bundles, there is no terminal, so show a native dialog.
    if sys.platform == "darwin":
        script = f'display alert "{title.replace("\"", "\\\"")}" message "{message.replace("\"", "\\\"")}" as critical'
        try:
            subprocess.run(["osascript", "-e", script], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
    else:
        print(f"{title}: {message}")


def _report_startup_failure(title: str, message: str, exc: BaseException | None = None) -> int:
    log_path = _write_startup_log(title, message, exc)
    tail = f"\n\nDetails saved to:\n{log_path}" if log_path else ""
    _show_startup_alert(title, f"{message}{tail}")
    if exc is not None:
        print("".join(traceback.format_exception(exc)))
    return 1


def _load_gui_main():
    try:
        from .app import main as _gui_main
        return _gui_main
    except ImportError as e:
        # PyInstaller can execute this entry as a script, where package-relative
        # imports have no parent package context.
        if "attempted relative import with no known parent package" not in str(e):
            raise
    from emgs_app.app import main as _gui_main
    return _gui_main


def main() -> int:
    # Safety: never write __pycache__/bytecode into the installed checkout/repo.
    # This keeps the package directory read-only in practice.
    sys.dont_write_bytecode = True

    try:
        _gui_main = _load_gui_main()
    except ModuleNotFoundError as e:
        return _report_startup_failure(
            "EMGS failed to start",
            _missing_dep_hint(e.name or "unknown"),
            e,
        )
    except Exception as e:
        return _report_startup_failure(
            "EMGS failed to initialize",
            "Unexpected startup error before app launch.",
            e,
        )

    try:
        return int(_gui_main() or 0)
    except Exception as e:
        return _report_startup_failure(
            "EMGS crashed on launch",
            "Unexpected error while starting GUI.",
            e,
        )


if __name__ == "__main__":
    raise SystemExit(main())

