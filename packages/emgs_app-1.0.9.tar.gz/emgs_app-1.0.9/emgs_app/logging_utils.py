from __future__ import annotations

import logging


def setup_logging(level: int = logging.INFO) -> None:
    """Configure application logging.

    Uses Rich logging if available (nicer tracebacks in terminal), otherwise
    falls back to a minimal standard formatter.
    """
    handlers = None
    fmt = "[%(levelname)s] %(name)s: %(message)s"
    try:
        from rich.logging import RichHandler  # type: ignore[import-not-found]

        handlers = [RichHandler(rich_tracebacks=True, show_time=False, show_level=False, show_path=False)]
        fmt = "%(message)s"
    except Exception:
        handlers = None

    logging.basicConfig(level=level, format=fmt, handlers=handlers)

