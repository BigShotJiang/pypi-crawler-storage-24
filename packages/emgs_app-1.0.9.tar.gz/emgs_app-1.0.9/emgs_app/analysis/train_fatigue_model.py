from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np

from .emg_features import EmgPreprocessConfig, WelchConfig, WindowConfig, extract_feature_rows
from .fatigue_labels import bin_fatigue_score, fatigue_score_from_force, fatigue_score_from_rpe, fatigue_score_from_time_to_failure
from .fatigue_model import TrainConfig, fit_final_model, groupwise_cv_metrics, save_metrics_json, save_model


def _load_npz(path: Path) -> dict[str, Any]:
    d = np.load(str(path), allow_pickle=True)
    return {k: d[k] for k in d.files}


def _as_1d(x: Any) -> np.ndarray:
    a = np.asarray(x)
    return np.asarray(a, dtype=float).reshape(-1)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Train a weakly-supervised EMG fatigue classifier (multi-level with calibrated probabilities).")
    ap.add_argument("--input", required=True, help="Input .npz containing either (X,y,groups) or raw (emg,fs_hz,...)")
    ap.add_argument("--output-model", required=True, help="Output model path (.joblib)")
    ap.add_argument("--output-metrics", default="", help="Optional metrics JSON output path")

    ap.add_argument("--label-kind", default="time_to_failure", choices=["time_to_failure", "force_drop", "rpe", "provided_score"], help="How to create weak labels")
    ap.add_argument("--t-fail-s", type=float, default=float("nan"), help="Failure time in seconds (for time_to_failure)")

    ap.add_argument("--window-s", type=float, default=0.250, help="Feature window length (seconds)")
    ap.add_argument("--hop-s", type=float, default=0.050, help="Feature hop length (seconds)")
    ap.add_argument("--bandpass", default="20,450", help="Bandpass Hz as 'lo,hi' or empty to skip filtering")
    ap.add_argument("--notch", type=float, default=float("nan"), help="Notch frequency (50 or 60) or NaN to disable")

    ap.add_argument("--model", default="logreg", choices=["logreg", "gbdt"], help="Base model")
    ap.add_argument("--calibrate", default="sigmoid", choices=["sigmoid", "isotonic", "none"], help="Probability calibration")
    ap.add_argument("--random-state", type=int, default=1337)
    ap.add_argument("--edges", default="0.33,0.66", help="Bin edges for 3-level fatigue as 'e0,e1'")

    args = ap.parse_args(argv)

    inp = Path(args.input)
    out_model = Path(args.output_model)
    out_metrics = Path(args.output_metrics) if args.output_metrics else None

    payload = _load_npz(inp)

    # Mode A: precomputed features
    if "X" in payload and "y" in payload:
        X = np.asarray(payload["X"], dtype=float)
        y = np.asarray(payload["y"], dtype=int).reshape(-1)
        groups = np.asarray(payload.get("groups", np.zeros((y.size,), dtype=int))).reshape(-1)
        feature_names = [str(s) for s in payload.get("feature_names", [])] if "feature_names" in payload else [f"f{i}" for i in range(int(X.shape[1]))]
    else:
        # Mode B: raw EMG -> features
        if "emg" not in payload:
            raise SystemExit("Input .npz must contain either (X,y) or 'emg'")

        emg = _as_1d(payload["emg"])
        fs_hz = float(np.asarray(payload.get("fs_hz", 1000.0)).reshape(()))

        bandpass = None
        if str(args.bandpass).strip():
            lo, hi = (s.strip() for s in str(args.bandpass).split(",", 1))
            bandpass = (float(lo), float(hi))

        preprocess = EmgPreprocessConfig(
            fs_hz=fs_hz,
            bandpass_hz=bandpass,
            notch_hz=None if np.isnan(float(args.notch)) else float(args.notch),
        )
        win = WindowConfig(fs_hz=fs_hz, window_s=float(args.window_s), hop_s=float(args.hop_s))
        welch = WelchConfig(fs_hz=fs_hz, nperseg=min(256, win.window_n()), noverlap=min(128, max(0, win.window_n() // 2)))

        X, feature_names, t_center_s = extract_feature_rows(
            emg,
            preprocess=preprocess,
            window=win,
            welch=welch,
        )

        # Weak label per window center time.
        kind = str(args.label_kind)
        if kind == "time_to_failure":
            tf = float(args.t_fail_s)
            if not np.isfinite(tf):
                raise SystemExit("--t-fail-s is required for label-kind=time_to_failure")
            y_score = fatigue_score_from_time_to_failure(t_center_s, t_fail_s=tf)
        elif kind == "force_drop":
            if "force" not in payload:
                raise SystemExit("Input .npz must include 'force' for label-kind=force_drop")
            force = _as_1d(payload["force"])
            # Align force samples to window centers if a time vector is provided; otherwise assume same sampling.
            if "force_t_s" in payload:
                ft = _as_1d(payload["force_t_s"])
                f_at = np.interp(t_center_s, ft, force, left=float(force[0]), right=float(force[-1]))
            else:
                # crude: resample by index ratio
                idx = np.clip((t_center_s * fs_hz).astype(int), 0, force.size - 1)
                f_at = force[idx]
            y_score = fatigue_score_from_force(f_at)
        elif kind == "rpe":
            if "rpe_times_s" not in payload or "rpe_values" not in payload:
                raise SystemExit("Input .npz must include 'rpe_times_s' and 'rpe_values' for label-kind=rpe")
            y_score = fatigue_score_from_rpe(t_center_s, _as_1d(payload["rpe_times_s"]), _as_1d(payload["rpe_values"]))
        elif kind == "provided_score":
            if "y_score" not in payload:
                raise SystemExit("Input .npz must include 'y_score' for label-kind=provided_score")
            ys = _as_1d(payload["y_score"])
            if "y_score_t_s" in payload:
                yt = _as_1d(payload["y_score_t_s"])
                y_score = np.interp(t_center_s, yt, ys, left=float(ys[0]), right=float(ys[-1]))
            else:
                idx = np.clip((t_center_s * fs_hz).astype(int), 0, ys.size - 1)
                y_score = ys[idx]
        else:
            raise SystemExit(f"Unknown label-kind={kind}")

        e0, e1 = (float(s.strip()) for s in str(args.edges).split(",", 1))
        y = bin_fatigue_score(y_score, edges=(e0, e1))

        # Groups (subjects) are needed for subject-wise CV. With a single recording, treat as one group.
        groups = np.asarray(payload.get("groups", np.zeros((y.size,), dtype=int))).reshape(-1)
        if groups.size != y.size:
            groups = np.zeros((y.size,), dtype=int)

    cfg = TrainConfig(model=str(args.model), calibrate=str(args.calibrate), random_state=int(args.random_state))

    metrics: dict[str, float] = {}
    try:
        # Only compute subject-wise metrics if we have >=2 groups.
        if np.unique(groups).size >= 2:
            metrics = groupwise_cv_metrics(X, y, groups, cfg=cfg)
    except Exception as e:
        metrics = {"cv_error": float("nan")}
        print(f"Warning: CV metrics skipped: {e}")

    est = fit_final_model(X, y, cfg=cfg)
    meta = {
        "input": str(inp),
        "label_kind": str(args.label_kind),
        "edges": str(args.edges),
        "n_samples": int(y.size),
        "n_features": int(X.shape[1]) if X.ndim == 2 else 0,
    }
    save_model(out_model, estimator=est, cfg=cfg, feature_names=feature_names, meta=meta)

    if out_metrics:
        save_metrics_json(out_metrics, metrics)
    else:
        # Print metrics for convenience.
        print(json.dumps(metrics, indent=2, sort_keys=True))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

