from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Iterator

import numpy as np


def _require_scipy() -> "object":
    try:
        import scipy.signal  # type: ignore
    except ModuleNotFoundError as e:  # pragma: no cover
        raise ModuleNotFoundError(
            "scipy is required for EMG filtering/PSD. Install with: pip install -r requirements.txt"
        ) from e
    return scipy.signal


@dataclass(frozen=True, slots=True)
class EmgPreprocessConfig:
    fs_hz: float = 1000.0
    bandpass_hz: tuple[float, float] | None = (20.0, 450.0)
    notch_hz: float | None = None  # e.g. 50 or 60
    notch_q: float = 30.0
    detrend: bool = True


def preprocess_emg(x: np.ndarray, cfg: EmgPreprocessConfig) -> np.ndarray:
    """Basic EMG preprocessing (typical surface EMG defaults).

    Notes:
    - Keep this conservative: the goal is repeatable features, not maximal denoising.
    - If you already have a clean pipeline, you can skip this and only use feature extraction.
    """
    scipy_signal = _require_scipy()

    x = np.asarray(x, dtype=float).copy()
    if x.ndim != 1:
        raise ValueError(f"preprocess_emg expects 1D signal, got shape={x.shape}")

    if cfg.detrend:
        x = x - float(np.mean(x))

    fs = float(cfg.fs_hz)

    if cfg.notch_hz is not None:
        w0 = float(cfg.notch_hz) / (fs / 2.0)
        if 0.0 < w0 < 1.0:
            b, a = scipy_signal.iirnotch(w0=w0, Q=float(cfg.notch_q))
            x = scipy_signal.filtfilt(b, a, x, method="pad")

    if cfg.bandpass_hz is not None:
        lo, hi = cfg.bandpass_hz
        lo = float(lo)
        hi = float(hi)
        if lo <= 0.0 or hi <= 0.0 or hi <= lo:
            raise ValueError(f"Invalid bandpass_hz={cfg.bandpass_hz}")
        wn = (lo / (fs / 2.0), hi / (fs / 2.0))
        b, a = scipy_signal.butter(4, wn, btype="bandpass")
        x = scipy_signal.filtfilt(b, a, x, method="pad")

    return x


@dataclass(frozen=True, slots=True)
class WindowConfig:
    fs_hz: float = 1000.0
    window_s: float = 0.250
    hop_s: float = 0.050

    def window_n(self) -> int:
        return max(8, int(round(float(self.window_s) * float(self.fs_hz))))

    def hop_n(self) -> int:
        return max(1, int(round(float(self.hop_s) * float(self.fs_hz))))


def iterate_windows(x: np.ndarray, cfg: WindowConfig) -> Iterator[tuple[int, int, np.ndarray]]:
    """Yield (start_idx, end_idx, window_signal)."""
    x = np.asarray(x, dtype=float)
    if x.ndim != 1:
        raise ValueError(f"iterate_windows expects 1D signal, got shape={x.shape}")

    n = int(x.size)
    w = int(cfg.window_n())
    hop = int(cfg.hop_n())
    if n < w:
        return
    for start in range(0, n - w + 1, hop):
        end = start + w
        yield start, end, x[start:end]


def _zc(x: np.ndarray, *, threshold: float = 0.0) -> float:
    """Zero crossings count with dead-zone threshold."""
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return 0.0
    # Apply dead-zone
    x1 = np.where(np.abs(x) < float(threshold), 0.0, x)
    s = np.sign(x1)
    return float(np.sum((s[1:] * s[:-1]) < 0))


def _wamp(x: np.ndarray, *, threshold: float) -> float:
    """Willison amplitude: count of |x[n]-x[n-1]| >= threshold."""
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return 0.0
    d = np.abs(np.diff(x))
    return float(np.sum(d >= float(threshold)))


def _waveform_length(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return 0.0
    return float(np.sum(np.abs(np.diff(x))))


@dataclass(frozen=True, slots=True)
class WelchConfig:
    fs_hz: float = 1000.0
    nperseg: int = 256
    noverlap: int = 128
    window: str = "hann"


def welch_psd(x: np.ndarray, cfg: WelchConfig) -> tuple[np.ndarray, np.ndarray]:
    """Welch PSD estimate (nonnegative) in units of power/Hz."""
    scipy_signal = _require_scipy()
    x = np.asarray(x, dtype=float)
    if x.ndim != 1:
        raise ValueError(f"welch_psd expects 1D signal, got shape={x.shape}")
    f, pxx = scipy_signal.welch(
        x,
        fs=float(cfg.fs_hz),
        window=str(cfg.window),
        nperseg=int(cfg.nperseg),
        noverlap=int(cfg.noverlap),
        detrend=False,
        scaling="density",
        return_onesided=True,
    )
    return np.asarray(f, dtype=float), np.asarray(pxx, dtype=float)


def spectral_features_from_psd(f_hz: np.ndarray, pxx: np.ndarray) -> dict[str, float]:
    """Compute common fatigue-related spectral features from a PSD."""
    f = np.asarray(f_hz, dtype=float)
    p = np.asarray(pxx, dtype=float)
    if f.size == 0 or p.size == 0 or f.size != p.size:
        return {"mnf_hz": 0.0, "mdf_hz": 0.0, "tot_power": 0.0}

    # Drop DC for fatigue features (EMG often has DC/artifact content).
    if f.size > 1:
        f = f[1:]
        p = p[1:]

    p = np.maximum(p, 0.0)
    tot = float(np.trapezoid(p, f))
    if not math.isfinite(tot) or tot <= 0.0:
        return {"mnf_hz": 0.0, "mdf_hz": 0.0, "tot_power": 0.0}

    # Mean frequency (MNF): first moment / total power.
    mnf = float(np.trapezoid(f * p, f) / tot)

    # Median frequency (MDF): frequency where cumulative power reaches 50%.
    # Use cumulative trapezoid integration for robustness.
    c = np.cumsum((p[1:] + p[:-1]) * (f[1:] - f[:-1]) * 0.5)
    if c.size == 0:
        mdf = float(f[0])
    else:
        idx = int(np.searchsorted(c, 0.5 * float(c[-1]), side="left"))
        idx = max(0, min(idx, int(f.size - 2)))
        mdf = float(f[idx + 1])

    return {
        "mnf_hz": float(mnf),
        "mdf_hz": float(mdf),
        "tot_power": float(tot),
    }


def bandpower(f_hz: np.ndarray, pxx: np.ndarray, band_hz: tuple[float, float]) -> float:
    f = np.asarray(f_hz, dtype=float)
    p = np.asarray(pxx, dtype=float)
    lo, hi = float(band_hz[0]), float(band_hz[1])
    if f.size == 0 or p.size == 0:
        return 0.0
    m = (f >= lo) & (f <= hi)
    if not np.any(m):
        return 0.0
    return float(np.trapezoid(np.maximum(p[m], 0.0), f[m]))


def time_features(x: np.ndarray, *, wamp_thresh: float | None = None, zc_thresh: float = 0.0) -> dict[str, float]:
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return {"rms": 0.0, "iemg": 0.0, "wl": 0.0, "zc": 0.0, "wamp": 0.0}

    rms = float(math.sqrt(max(0.0, float(np.mean(x * x)))))
    iemg = float(np.sum(np.abs(x)))
    wl = _waveform_length(x)
    zc = _zc(x, threshold=float(zc_thresh))

    if wamp_thresh is None:
        # Common heuristic: threshold relative to signal scale (10% of RMS).
        wamp_thresh = 0.1 * rms
    wamp = _wamp(x, threshold=float(wamp_thresh))

    return {"rms": rms, "iemg": iemg, "wl": wl, "zc": zc, "wamp": wamp}


def extract_feature_rows(
    x: np.ndarray,
    *,
    preprocess: EmgPreprocessConfig | None = None,
    window: WindowConfig,
    welch: WelchConfig | None = None,
    bandpowers_hz: Iterable[tuple[str, tuple[float, float]]] = (("bp_20_60", (20.0, 60.0)), ("bp_60_150", (60.0, 150.0)), ("bp_150_300", (150.0, 300.0))),
) -> tuple[np.ndarray, list[str], np.ndarray]:
    """Return (X, feature_names, t_center_s) for a single recording.

    X rows correspond to windows. t_center_s is window center time in seconds.
    """
    x_in = np.asarray(x, dtype=float)
    if x_in.ndim != 1:
        raise ValueError(f"extract_feature_rows expects 1D signal, got shape={x_in.shape}")

    cfg_p = preprocess or EmgPreprocessConfig(fs_hz=float(window.fs_hz))
    x0 = preprocess_emg(x_in, cfg_p) if preprocess is not None else x_in.astype(float)

    cfg_welch = welch or WelchConfig(fs_hz=float(window.fs_hz), nperseg=min(256, window.window_n()), noverlap=min(128, max(0, window.window_n() // 2)))
    names: list[str] = []
    rows: list[list[float]] = []
    t_centers: list[float] = []

    for start, end, seg in iterate_windows(x0, window):
        tf = time_features(seg)
        f, pxx = welch_psd(seg, cfg_welch)
        sf = spectral_features_from_psd(f, pxx)
        bp: dict[str, float] = {name: bandpower(f, pxx, band) for name, band in bandpowers_hz}

        feat: dict[str, float] = {}
        feat.update(tf)
        feat.update(sf)
        feat.update(bp)

        if not names:
            names = list(feat.keys())
        rows.append([float(feat[k]) for k in names])

        t_center = (float(start) + float(end)) * 0.5 / float(window.fs_hz)
        t_centers.append(float(t_center))

    if not rows:
        return np.zeros((0, 0), dtype=float), [], np.zeros((0,), dtype=float)
    return np.asarray(rows, dtype=float), names, np.asarray(t_centers, dtype=float)

