"""Signal processing and modeling utilities (offline).

This package is intentionally GUI-agnostic so it can be used for:
- offline feature extraction / training
- lightweight runtime inference (optional)
"""

from __future__ import annotations

