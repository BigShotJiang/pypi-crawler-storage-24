from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


def _clip01(x: np.ndarray) -> np.ndarray:
    return np.clip(np.asarray(x, dtype=float), 0.0, 1.0)


def fatigue_score_from_time_to_failure(t_s: np.ndarray, *, t_fail_s: float, t_start_s: float | None = None) -> np.ndarray:
    """Weak label: normalize time into a fatigue score in [0..1].

    - 0.0 at t_start_s (default: min(t_s))
    - 1.0 at t_fail_s
    """
    t = np.asarray(t_s, dtype=float)
    if t.size == 0:
        return np.zeros((0,), dtype=float)
    tf = float(t_fail_s)
    if not math.isfinite(tf) or tf <= 0:
        raise ValueError(f"Invalid t_fail_s={t_fail_s}")
    t0 = float(np.min(t)) if t_start_s is None else float(t_start_s)
    denom = max(1e-9, tf - t0)
    y = (t - t0) / denom
    return _clip01(y)


def fatigue_score_from_force(force: np.ndarray, *, baseline_force: float | None = None) -> np.ndarray:
    """Weak label: map force drop into fatigue score in [0..1].

    score(t) = (baseline - force(t)) / baseline, clipped to [0..1]
    """
    f = np.asarray(force, dtype=float)
    if f.size == 0:
        return np.zeros((0,), dtype=float)
    base = float(np.nanmedian(f[: max(1, min(200, f.size))])) if baseline_force is None else float(baseline_force)
    if not math.isfinite(base) or base <= 0:
        raise ValueError(f"Invalid baseline_force={baseline_force}")
    y = (base - f) / base
    y = np.nan_to_num(y, nan=0.0, posinf=1.0, neginf=0.0)
    return _clip01(y)


def fatigue_score_from_rpe(t_s: np.ndarray, rpe_times_s: np.ndarray, rpe_values: np.ndarray, *, rpe_min: float = 6.0, rpe_max: float = 20.0) -> np.ndarray:
    """Weak label: interpolate RPE (Borg 6–20) into a continuous fatigue score in [0..1]."""
    t = np.asarray(t_s, dtype=float)
    rt = np.asarray(rpe_times_s, dtype=float)
    rv = np.asarray(rpe_values, dtype=float)
    if t.size == 0:
        return np.zeros((0,), dtype=float)
    if rt.size == 0 or rv.size == 0 or rt.size != rv.size:
        raise ValueError("rpe_times_s and rpe_values must be same nonzero length")
    # Sort RPE points by time.
    order = np.argsort(rt)
    rt = rt[order]
    rv = rv[order]
    # Interpolate with flat extrapolation.
    v = np.interp(t, rt, rv, left=float(rv[0]), right=float(rv[-1]))
    denom = max(1e-9, float(rpe_max) - float(rpe_min))
    y = (v - float(rpe_min)) / denom
    return _clip01(y)


def bin_fatigue_score(y01: np.ndarray, *, edges: tuple[float, float] = (0.33, 0.66)) -> np.ndarray:
    """Convert continuous [0..1] score to 3 ordinal levels: 0/1/2."""
    y = _clip01(y01)
    e0, e1 = float(edges[0]), float(edges[1])
    if not (0.0 < e0 < e1 < 1.0):
        raise ValueError(f"Invalid edges={edges}")
    out = np.zeros_like(y, dtype=int)
    out[y >= e0] = 1
    out[y >= e1] = 2
    return out


@dataclass(frozen=True, slots=True)
class FatigueLabelSpec:
    """Configuration for weak labels."""

    kind: str  # "time_to_failure" | "force_drop" | "rpe" | "provided_score"
    edges: tuple[float, float] = (0.33, 0.66)

