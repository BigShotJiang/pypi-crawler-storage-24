from __future__ import annotations

import asyncio
from contextlib import suppress
import logging
import sys
from pathlib import Path

import qasync
from PyQt6 import QtWidgets

from . import config
from .controller import EmgsController
from .gui.main_window import MainWindow
from .logging_utils import setup_logging


logger = logging.getLogger(__name__)


def _resource_path(rel: str) -> Path:
    return Path(__file__).resolve().parent / rel


def main() -> int:
    setup_logging(logging.INFO)

    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName(config.APP_TITLE)

    # Dark theme stylesheet
    qss_path = _resource_path("resources/style.qss")
    if qss_path.exists():
        app.setStyleSheet(qss_path.read_text(encoding="utf-8"))
    else:
        logger.warning("Stylesheet missing: %s", qss_path)

    # Qt + asyncio integration
    loop = qasync.QEventLoop(app)
    asyncio.set_event_loop(loop)

    # Pick backend from env (optional): EMGS_BACKEND=sim
    controller = EmgsController()
    win = MainWindow(controller)
    win.show()

    with loop:
        # Best-effort cleanup on unexpected top-level exceptions.
        def _excepthook(exc_type, exc, tb) -> None:
            with suppress(Exception):
                logger.exception("Unhandled exception", exc_info=(exc_type, exc, tb))
            with suppress(Exception):
                asyncio.create_task(controller.manager.shutdown())
            with suppress(Exception):
                QtWidgets.QApplication.instance().quit()

        sys.excepthook = _excepthook
        loop.run_forever()
    return 0

