from __future__ import annotations


if __name__ == "__main__":
    try:
        from .cli import main
    except ImportError:
        from emgs_app.cli import main

    raise SystemExit(main())

