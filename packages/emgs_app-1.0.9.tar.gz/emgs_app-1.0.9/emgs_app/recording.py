from __future__ import annotations

import csv
import datetime as _dt
import math
from dataclasses import dataclass
from pathlib import Path
import heapq
from typing import Any, Callable, Deque, Optional


_ROBOT_MEASURE_FIELD_ALIASES: dict[str, str] = {
    # Canonical (v5+) -> legacy (v4)
    "measure_fid": "test_fid",
    "measure_dt_ms": "test_dt_ms",
    "measure_state": "test_state",
    "measure_dir": "test_dir",
    "measure_blocked": "test_blocked",
    "measure_result_flags": "test_result_flags",
    "measure_pos_rad": "test_pos_rad",
    "measure_vel_rad_s": "test_vel_rad_s",
    "measure_tq_nm": "test_tq_nm",
    "measure_temp_c": "test_temp_c",
    "measure_vbus_v": "test_vbus_v",
    "measure_pattern": "test_pattern",
    "measure_err_code": "test_err_code",
    "measure_fb_age_ms": "test_fb_age_ms",
    "measure_prom_df_end_rad": "test_prom_df_end_rad",
    "measure_prom_pf_end_rad": "test_prom_pf_end_rad",
    "measure_arom_df_max_rad": "test_arom_df_max_rad",
    "measure_arom_pf_min_rad": "test_arom_pf_min_rad",
    "measure_flag_prom_df_valid": "test_flag_prom_df_valid",
    "measure_flag_prom_pf_valid": "test_flag_prom_pf_valid",
    "measure_flag_arom_valid": "test_flag_arom_valid",
    "measure_flag_seq_active": "test_flag_seq_active",
    "measure_flag_arom_running": "test_flag_arom_running",
}

# Also support reverse lookup for legacy-selected columns.
_ROBOT_MEASURE_FIELD_ALIASES.update({v: k for k, v in list(_ROBOT_MEASURE_FIELD_ALIASES.items())})
_ROBOT_MEASURE_LEGACY_TO_CANON: dict[str, str] = {
    k: v for k, v in _ROBOT_MEASURE_FIELD_ALIASES.items() if str(k).startswith("test_")
}

# Collapse mode-specific motor/health fields into one shared CSV column.
_ROBOT_MOTOR_COMMON_FIELD_ALIASES: dict[str, str] = {
    "walk_fid": "fid",
    "cpm_fid": "fid",
    "measure_fid": "fid",
    "walk_dt_ms": "dt_ms",
    "cpm_dt_ms": "dt_ms",
    "measure_dt_ms": "dt_ms",
    "walk_pos_rad": "pos_rad",
    "cpm_pos_rad": "pos_rad",
    "measure_pos_rad": "pos_rad",
    "walk_vel_rad_s": "vel_rad_s",
    "cpm_vel_rad_s": "vel_rad_s",
    "measure_vel_rad_s": "vel_rad_s",
    "walk_tq_nm": "tq_nm",
    "cpm_tq_nm": "tq_nm",
    "measure_tq_nm": "tq_nm",
    "walk_temp_c": "temp_c",
    "cpm_temp_c": "temp_c",
    "measure_temp_c": "temp_c",
    "walk_vbus_v": "vbus_v",
    "cpm_vbus_v": "vbus_v",
    "measure_vbus_v": "vbus_v",
    "walk_pattern": "pattern",
    "cpm_pattern": "pattern",
    "measure_pattern": "pattern",
    "walk_err_code": "err_code",
    "cpm_err_code": "err_code",
    "measure_err_code": "err_code",
    "walk_fb_age_ms": "fb_age_ms",
    "cpm_fb_age_ms": "fb_age_ms",
    "measure_fb_age_ms": "fb_age_ms",
}


@dataclass(slots=True)
class RecordingPaths:
    emg_csv: Path | None
    imu_csv: Path | None
    robot_csv: Path | None


def default_recording_paths(
    out_dir: str | Path,
    *,
    prefix: str = "recording",
    include_emg: bool = True,
    include_imu: bool = True,
    include_robot: bool = False,
) -> RecordingPaths:
    # Backwards-compatible helper (single device). Prefer using RecordingSessionPaths below.
    ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    return RecordingPaths(
        emg_csv=(out / f"{prefix}_{ts}_emg.csv") if include_emg else None,
        imu_csv=(out / f"{prefix}_{ts}_imu.csv") if include_imu else None,
        robot_csv=(out / f"{prefix}_{ts}_robot.csv") if include_robot else None,
    )


@dataclass(slots=True)
class RecordingSessionPaths:
    """Folder + timestamp used for a recording session."""

    root_dir: Path
    timestamp: str  # YYYYMMDD_HHMMSS


def default_recording_session_paths(base_dir: str | Path, *, prefix: str = "emgs") -> RecordingSessionPaths:
    ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    root = Path(base_dir) / f"{prefix}_{ts}"
    root.mkdir(parents=True, exist_ok=True)
    return RecordingSessionPaths(root_dir=root, timestamp=ts)


def _sanitize_addr(addr: str) -> str:
    return str(addr).replace(":", "").replace("-", "").strip() or "addr"


def device_recording_paths(
    session: RecordingSessionPaths,
    *,
    addr: str,
    include_emg: bool,
    include_imu: bool,
    include_robot: bool,
    prefix: str = "emgs",
) -> RecordingPaths:
    a = _sanitize_addr(addr)
    ts = str(session.timestamp)
    out = Path(session.root_dir)
    return RecordingPaths(
        emg_csv=(out / f"{prefix}_emg_{a}_{ts}.csv") if include_emg else None,
        imu_csv=(out / f"{prefix}_imu_{a}_{ts}.csv") if include_imu else None,
        robot_csv=(out / f"{prefix}_robot_{a}_{ts}.csv") if include_robot else None,
    )


class DeviceWideRecorder:
    """Per-device recorder producing wide CSVs.

    - EMG: 1 ms alignment
    - IMU: 10 ms alignment
    - Robot (AKR/RR_AKR): 20 ms alignment
    """

    def __init__(
        self,
        *,
        addr: str,
        paths: RecordingPaths,
        origin_s: float,
        emg_fields: list[str],
        imu_fields: list[str],
        robot_fields: list[str] | None = None,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.addr = str(addr)
        self.paths = paths
        self.origin_s = float(origin_s)
        self.emg_fields = list(emg_fields)
        self.imu_fields = list(imu_fields)
        self.robot_fields = self._normalize_robot_fields_for_csv(list(robot_fields or []))
        self._on_log = on_log

        # (addr, buf_name) -> last_ts_s captured
        self._last_ts: dict[str, float] = {}

        # Pending rows (t_ms -> row list)
        self._emg_rows: dict[int, list[Any]] = {}
        self._imu_rows: dict[int, list[Any]] = {}
        self._robot_rows: dict[int, list[Any]] = {}
        self._emg_max_ms: int = -10**18
        self._imu_max_ms: int = -10**18
        self._robot_max_ms: int = -10**18
        self._emg_heap: list[int] = []
        self._imu_heap: list[int] = []
        self._robot_heap: list[int] = []
        self._emg_heap_set: set[int] = set()
        self._imu_heap_set: set[int] = set()
        self._robot_heap_set: set[int] = set()

        self._emg_f = None
        self._emg_w = None
        self._emg_header: list[str] = []
        self._emg_idx: dict[str, int] = {}
        self._emg_state_i: int | None = None
        self._emg_collide_n: int = 0
        if self.paths.emg_csv is not None:
            self._emg_header, self._emg_idx = self._build_emg_header(self.emg_fields)
            self._emg_state_i = self._emg_idx.get("state")
            self._emg_f = open(self.paths.emg_csv, "w", newline="", encoding="utf-8")
            self._emg_w = csv.writer(self._emg_f)
            self._emg_w.writerow(self._emg_header)

        self._imu_f = None
        self._imu_w = None
        self._imu_header: list[str] = []
        self._imu_idx: dict[str, int] = {}
        self._imu_state_i: int | None = None
        self._imu_collide_n: int = 0
        if self.paths.imu_csv is not None:
            self._imu_header, self._imu_idx = self._build_imu_header(self.imu_fields)
            self._imu_state_i = self._imu_idx.get("state")
            self._imu_f = open(self.paths.imu_csv, "w", newline="", encoding="utf-8")
            self._imu_w = csv.writer(self._imu_f)
            self._imu_w.writerow(self._imu_header)

        self._robot_f = None
        self._robot_w = None
        self._robot_header: list[str] = []
        self._robot_idx: dict[str, int] = {}
        self._robot_note_i: int | None = None
        self._robot_collide_n: int = 0
        if self.paths.robot_csv is not None:
            self._robot_header, self._robot_idx = self._build_robot_header(self.robot_fields)
            self._robot_note_i = self._robot_idx.get("note")
            self._robot_f = open(self.paths.robot_csv, "w", newline="", encoding="utf-8")
            self._robot_w = csv.writer(self._robot_f)
            self._robot_w.writerow(self._robot_header)

        if self.paths.emg_csv is not None:
            self._log(f"Recording: EMG -> {self.paths.emg_csv}")
        if self.paths.imu_csv is not None:
            self._log(f"Recording: IMU -> {self.paths.imu_csv}")
        if self.paths.robot_csv is not None:
            self._log(f"Recording: Robot -> {self.paths.robot_csv}")

    def _log(self, msg: str) -> None:
        if self._on_log:
            self._on_log(msg)

    def close(self) -> None:
        # Flush all pending rows before closing files.
        self._flush_emg(final=True)
        self._flush_imu(final=True)
        self._flush_robot(final=True)
        if self._emg_f is not None:
            try:
                self._emg_f.flush()
            except Exception:
                pass
            try:
                self._emg_f.close()
            except Exception:
                pass
        if self._emg_collide_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): EMG collisions={self._emg_collide_n} (multiple samples mapped to same t_ms; last wins)")
        if self._imu_f is not None:
            try:
                self._imu_f.flush()
            except Exception:
                pass
        if self._imu_collide_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): IMU collisions={self._imu_collide_n} (multiple samples mapped to same t_ms; last wins)")
            try:
                self._imu_f.close()
            except Exception:
                pass
        if self._robot_f is not None:
            try:
                self._robot_f.flush()
            except Exception:
                pass
            try:
                self._robot_f.close()
            except Exception:
                pass
        if self._robot_collide_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): Robot collisions={self._robot_collide_n} (multiple samples mapped to same t_ms; last wins)")

    @staticmethod
    def _build_emg_header(fields: list[str]) -> tuple[list[str], dict[str, int]]:
        cols = ["t_ms", "state"] + [str(f) for f in fields]
        return cols, {c: i for i, c in enumerate(cols)}

    @staticmethod
    def _build_imu_header(fields: list[str]) -> tuple[list[str], dict[str, int]]:
        cols = ["t_ms", "state"] + [str(f) for f in fields]
        return cols, {c: i for i, c in enumerate(cols)}

    @staticmethod
    def _build_robot_header(fields: list[str]) -> tuple[list[str], dict[str, int]]:
        # Use "note" (not "state") so the robot field "state" can be recorded as data.
        cols = ["t_ms", "note"] + [str(f) for f in fields]
        return cols, {c: i for i, c in enumerate(cols)}

    @staticmethod
    def _normalize_robot_fields_for_csv(fields: list[str]) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for raw in fields:
            key = str(raw)
            # Accept legacy test_* selections first.
            key = _ROBOT_MEASURE_LEGACY_TO_CANON.get(key, key)
            # Collapse walk/cpm/measure motor+health to shared columns.
            key = _ROBOT_MOTOR_COMMON_FIELD_ALIASES.get(key, key)
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
        return out

    @staticmethod
    def _round_ms_1(ts_s: float) -> int:
        return int(round(float(ts_s) * 1000.0))

    @staticmethod
    def _round_ms_10(ts_s: float) -> int:
        # 10 ms = 0.01 s
        return int(round(float(ts_s) * 100.0)) * 10

    @staticmethod
    def _round_ms_20(ts_s: float) -> int:
        # 20 ms = 0.02 s
        return int(round(float(ts_s) * 50.0)) * 20

    def _iter_new_from_deque(self, buf_key: str, buf: Deque[tuple[float, list[float]]]) -> list[tuple[float, list[float]]]:
        """Return new samples strictly newer than last captured timestamp for this buffer."""
        key = str(buf_key)
        last = float(self._last_ts.get(key, -1e18))
        out_rev: list[tuple[float, list[float]]] = []
        for ts, samples in reversed(buf):
            if float(ts) <= last:
                break
            out_rev.append((float(ts), list(samples)))
        if not out_rev:
            return []
        out_rev.reverse()
        self._last_ts[key] = float(out_rev[-1][0])
        return out_rev

    def _row_emg(self, t_ms: int) -> list[Any]:
        row = self._emg_rows.get(int(t_ms))
        if row is None:
            row = ["" for _ in range(len(self._emg_header))]
            row[0] = int(t_ms)
            self._emg_rows[int(t_ms)] = row
            if t_ms not in self._emg_heap_set:
                heapq.heappush(self._emg_heap, int(t_ms))
                self._emg_heap_set.add(int(t_ms))
        return row

    def _row_imu(self, t_ms: int) -> list[Any]:
        row = self._imu_rows.get(int(t_ms))
        if row is None:
            row = ["" for _ in range(len(self._imu_header))]
            row[0] = int(t_ms)
            self._imu_rows[int(t_ms)] = row
            if t_ms not in self._imu_heap_set:
                heapq.heappush(self._imu_heap, int(t_ms))
                self._imu_heap_set.add(int(t_ms))
        return row

    def _row_robot(self, t_ms: int) -> list[Any]:
        row = self._robot_rows.get(int(t_ms))
        if row is None:
            row = ["" for _ in range(len(self._robot_header))]
            row[0] = int(t_ms)
            self._robot_rows[int(t_ms)] = row
            if t_ms not in self._robot_heap_set:
                heapq.heappush(self._robot_heap, int(t_ms))
                self._robot_heap_set.add(int(t_ms))
        return row

    @staticmethod
    def _is_empty(v: Any) -> bool:
        return v is None or v == ""

    @staticmethod
    def _collide_tag_for_imu_signal(sig: str) -> str:
        s = str(sig).lower()
        if s.startswith("acc") or s.startswith("raw_acc") or s.startswith("lin_acc"):
            return "ACC"
        if s.startswith("gyr") or s.startswith("raw_gyr"):
            return "GYR"
        if s.startswith("mag") or s.startswith("uncal_mag"):
            return "MAG"
        if s.startswith("quat"):
            return "QUAT"
        return "IMU"

    def _mark_collide(self, row: list[Any], *, state_i: int | None, tag: str, is_emg: bool) -> None:
        if state_i is None:
            return
        # Collision flag: multiple samples fell into same rounded timestamp bucket.
        # We intentionally keep the last value (aggregation='last').
        tag = str(tag).strip().upper() or ("EMG" if is_emg else "IMU")
        cur = str(row[state_i] or "").strip()
        if not cur:
            row[state_i] = f"COLLIDE:{tag}"
        else:
            # Merge tags: COLLIDE:ACC,GYR
            if cur.startswith("COLLIDE:"):
                existing = [t.strip().upper() for t in cur.split(":", 1)[1].split(",") if t.strip()]
            elif cur == "COLLIDE":
                existing = []
            else:
                # Unknown legacy marker, keep it but append collide info.
                existing = []
            if tag not in existing:
                existing.append(tag)
            row[state_i] = "COLLIDE:" + ",".join(existing) if existing else "COLLIDE"
        if is_emg:
            self._emg_collide_n += 1
        else:
            self._imu_collide_n += 1

    def _mark_robot_collide(self, row: list[Any], *, note_i: int | None, tag: str) -> None:
        """Collision marker for Robot CSV (does NOT affect IMU/EMG counters)."""
        if note_i is None:
            return
        tag = str(tag).strip().upper() or "ROBOT"
        cur = str(row[note_i] or "").strip()
        if not cur:
            row[note_i] = f"COLLIDE:{tag}"
        else:
            if cur.startswith("COLLIDE:"):
                existing = [t.strip().upper() for t in cur.split(":", 1)[1].split(",") if t.strip()]
            elif cur == "COLLIDE":
                existing = []
            else:
                existing = []
            if tag not in existing:
                existing.append(tag)
            row[note_i] = "COLLIDE:" + ",".join(existing) if existing else "COLLIDE"
        self._robot_collide_n += 1

    def _flush_emg(self, *, final: bool = False) -> None:
        if self._emg_w is None:
            return
        lag_ms = 50
        thr = self._emg_max_ms if final else (self._emg_max_ms - lag_ms)
        while self._emg_heap and int(self._emg_heap[0]) <= int(thr):
            t = int(heapq.heappop(self._emg_heap))
            self._emg_heap_set.discard(t)
            row = self._emg_rows.pop(t, None)
            if row is not None:
                self._emg_w.writerow(row)

    def _flush_imu(self, *, final: bool = False) -> None:
        if self._imu_w is None:
            return
        lag_ms = 200
        thr = self._imu_max_ms if final else (self._imu_max_ms - lag_ms)
        while self._imu_heap and int(self._imu_heap[0]) <= int(thr):
            t = int(heapq.heappop(self._imu_heap))
            self._imu_heap_set.discard(t)
            row = self._imu_rows.pop(t, None)
            if row is not None:
                self._imu_w.writerow(row)

    def _flush_robot(self, *, final: bool = False) -> None:
        if self._robot_w is None:
            return
        lag_ms = 250
        thr = self._robot_max_ms if final else (self._robot_max_ms - lag_ms)
        while self._robot_heap and int(self._robot_heap[0]) <= int(thr):
            t = int(heapq.heappop(self._robot_heap))
            self._robot_heap_set.discard(t)
            row = self._robot_rows.pop(t, None)
            if row is not None:
                self._robot_w.writerow(row)

    def _set_emg(self, field: str, t_ms: int, value: Any) -> None:
        if self._emg_w is None:
            return
        idx = self._emg_idx.get(str(field))
        if idx is None:
            return
        row = self._row_emg(int(t_ms))
        # Collision: we already wrote this cell for this t_ms and now we overwrite it (last wins).
        if (not self._is_empty(row[idx])) and (not self._is_empty(value)):
            self._mark_collide(row, state_i=self._emg_state_i, tag="EMG", is_emg=True)
        row[idx] = value

    def _set_imu_vec3(self, sig: str, t_ms: int, vals: list[float]) -> None:
        if self._imu_w is None:
            return
        tag = self._collide_tag_for_imu_signal(sig)
        for comp, v in zip(("x", "y", "z"), (vals + [None, None, None])[:3]):
            key = f"{sig}_{comp}"
            idx = self._imu_idx.get(key)
            if idx is None:
                continue
            row = self._row_imu(int(t_ms))
            if (not self._is_empty(row[idx])) and (not self._is_empty(v)):
                self._mark_collide(row, state_i=self._imu_state_i, tag=tag, is_emg=False)
            row[idx] = v

    def _set_imu_vec4(self, sig: str, t_ms: int, vals: list[float]) -> None:
        if self._imu_w is None:
            return
        tag = self._collide_tag_for_imu_signal(sig)
        for comp, v in zip(("w", "x", "y", "z"), (vals + [None, None, None, None])[:4]):
            key = f"{sig}_{comp}"
            idx = self._imu_idx.get(key)
            if idx is None:
                continue
            row = self._row_imu(int(t_ms))
            if (not self._is_empty(row[idx])) and (not self._is_empty(v)):
                self._mark_collide(row, state_i=self._imu_state_i, tag=tag, is_emg=False)
            row[idx] = v

    def _set_imu_scalar(self, field: str, t_ms: int, value: Any) -> None:
        """Set a scalar IMU field (exact column name, no _x/_y/_z expansion)."""
        if self._imu_w is None:
            return
        idx = self._imu_idx.get(str(field))
        if idx is None:
            return
        row = self._row_imu(int(t_ms))
        if (not self._is_empty(row[idx])) and (not self._is_empty(value)):
            self._mark_collide(row, state_i=self._imu_state_i, tag="IMU", is_emg=False)
        row[idx] = value

    def _set_robot_scalar(self, field: str, t_ms: int, value: Any) -> None:
        if self._robot_w is None:
            return
        key = str(field)
        # Canonicalize legacy/variant names to the active header key.
        key = _ROBOT_MEASURE_LEGACY_TO_CANON.get(key, key)
        key = _ROBOT_MOTOR_COMMON_FIELD_ALIASES.get(key, key)
        idx = self._robot_idx.get(key)
        if idx is None:
            # Extra fallback: if a caller passed pre-canonical key.
            alt = _ROBOT_MEASURE_LEGACY_TO_CANON.get(str(field))
            if alt is not None:
                alt = _ROBOT_MOTOR_COMMON_FIELD_ALIASES.get(str(alt), str(alt))
                idx = self._robot_idx.get(str(alt))
        if idx is None:
            return
        row = self._row_robot(int(t_ms))
        if (not self._is_empty(row[idx])) and (not self._is_empty(value)):
            self._mark_robot_collide(row, note_i=self._robot_note_i, tag="ROBOT")
        row[idx] = value

    def _set_robot_vec3(self, sig: str, t_ms: int, vals: list[float]) -> None:
        if self._robot_w is None:
            return
        tag = str(sig).strip().upper() or "ROBOT"
        for comp, v in zip(("x", "y", "z"), (vals + [None, None, None])[:3]):
            key = f"{sig}_{comp}"
            idx = self._robot_idx.get(key)
            if idx is None:
                continue
            row = self._row_robot(int(t_ms))
            if (not self._is_empty(row[idx])) and (not self._is_empty(v)):
                self._mark_robot_collide(row, note_i=self._robot_note_i, tag=tag)
            row[idx] = v

    def capture(self, dev: object) -> None:
        """Capture new samples from this device into CSV."""
        origin = float(self.origin_s)

        # EMG raw (mV)
        buf = getattr(dev, "emg_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("emg_raw_mV", t_ms, (vals[0] if vals else ""))

        # Processed EMG signals (only if enabled; but we also write if buffer has data).
        buf = getattr(dev, "emg_rms_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_rms_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("emg_env_rms", t_ms, (vals[0] if vals else ""))

        buf = getattr(dev, "emg_median_freq_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_median_freq_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("emg_mdf_hz", t_ms, (vals[0] if vals else ""))

        buf = getattr(dev, "emg_mean_freq_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_mean_freq_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("emg_mnf_hz", t_ms, (vals[0] if vals else ""))

        buf = getattr(dev, "emg_packet_rms_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_packet_rms_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("emg_pkt_rms_v", t_ms, (vals[0] if vals else ""))

        buf = getattr(dev, "emg_snr_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_snr_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("emg_snr", t_ms, (vals[0] if vals else ""))

        buf = getattr(dev, "emg_fatigue_score_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_fatigue_score_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("fatigue_score", t_ms, (vals[0] if vals else ""))

        buf = getattr(dev, "emg_fatigue_conf_buffer", None)
        if self._emg_w is not None and buf:
            rows = self._iter_new_from_deque("emg_fatigue_conf_buffer", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_1(float(ts) - origin)
                    self._emg_max_ms = max(self._emg_max_ms, int(t_ms))
                    self._set_emg("fatigue_conf", t_ms, (vals[0] if vals else ""))

        # IMU buffers (10 ms alignment)
        imu_specs = [
            ("raw_acc_buffer", "raw_acc", 3),
            ("acc_buffer", "acc", 3),
            ("lin_acc_buffer", "lin_acc", 3),
            ("raw_gyr_buffer", "raw_gyr", 3),
            ("gyr_buffer", "gyr", 3),
            ("uncal_mag_buffer", "uncal_mag", 3),
            ("mag_buffer", "mag", 3),
            ("quat_game_buffer", "quat_game", 4),
            ("quat_geomag_buffer", "quat_geomag", 4),
        ]
        for buf_name, sig, dim in imu_specs:
            buf = getattr(dev, buf_name, None)
            if self._imu_w is None or not buf:
                continue
            rows = self._iter_new_from_deque(str(buf_name), buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_10(float(ts) - origin)
                    self._imu_max_ms = max(self._imu_max_ms, int(t_ms))
                    if int(dim) == 4:
                        self._set_imu_vec4(str(sig), t_ms, vals)
                    elif int(dim) == 1:
                        self._set_imu_scalar(str(sig), t_ms, (vals[0] if vals else ""))
                    else:
                        self._set_imu_vec3(str(sig), t_ms, vals)

        # Robot buffers (20 ms alignment) — primarily for AKR RR_AKR status lines.
        # Scalars
        robot_scalar_specs = [
            ("akr_step_dt_ms_buffer", "step_dt_ms"),
            ("akr_exec_ms_buffer", "exec_ms"),
            ("akr_out_buffer", "out"),
            ("akr_state_buffer", "state"),
            # Binary rr_telem (Walk/AKR)
            ("akr_walk_fid_buffer", "walk_fid"),
            ("akr_walk_dt_ms_buffer", "walk_dt_ms"),
            ("akr_walk_exec_ms_buffer", "walk_exec_ms"),
            ("akr_walk_out_buffer", "walk_out"),
            ("akr_walk_state_buffer", "walk_state"),
            ("akr_walk_pos_rad_buffer", "walk_pos_rad"),
            ("akr_walk_vel_rad_s_buffer", "walk_vel_rad_s"),
            ("akr_walk_tq_nm_buffer", "walk_tq_nm"),
            ("akr_walk_temp_c_buffer", "walk_temp_c"),
            ("akr_walk_vbus_v_buffer", "walk_vbus_v"),
            ("akr_walk_pattern_buffer", "walk_pattern"),
            ("akr_walk_err_code_buffer", "walk_err_code"),
            ("akr_walk_fb_age_ms_buffer", "walk_fb_age_ms"),
            # Binary rr_telem (CPM)
            ("akr_cpm_fid_buffer", "cpm_fid"),
            ("akr_cpm_dt_ms_buffer", "cpm_dt_ms"),
            ("akr_cpm_state_buffer", "cpm_state"),
            ("akr_cpm_dir_buffer", "cpm_dir"),
            ("akr_cpm_blocked_event_buffer", "cpm_blocked_event"),
            ("akr_cpm_blocked_consecutive_buffer", "cpm_blocked_consecutive"),
            ("akr_cpm_cmd_spd_rad_s_buffer", "cpm_cmd_spd_rad_s"),
            ("akr_cpm_pos_rad_buffer", "cpm_pos_rad"),
            ("akr_cpm_vel_rad_s_buffer", "cpm_vel_rad_s"),
            ("akr_cpm_tq_nm_buffer", "cpm_tq_nm"),
            ("akr_cpm_temp_c_buffer", "cpm_temp_c"),
            ("akr_cpm_vbus_v_buffer", "cpm_vbus_v"),
            ("akr_cpm_pattern_buffer", "cpm_pattern"),
            ("akr_cpm_err_code_buffer", "cpm_err_code"),
            ("akr_cpm_fb_age_ms_buffer", "cpm_fb_age_ms"),
            ("akr_cpm_df_limit_rad_buffer", "cpm_df_limit_rad"),
            ("akr_cpm_pf_limit_rad_buffer", "cpm_pf_limit_rad"),
            ("akr_cpm_elapsed_s_buffer", "cpm_elapsed_s"),
            ("akr_cpm_repetition_count_buffer", "cpm_repetition_count"),
            # Binary rr_telem (MEASURE) - sourced from akr_test_* buffers in device state.
            ("akr_test_fid_buffer", "measure_fid"),
            ("akr_test_dt_ms_buffer", "measure_dt_ms"),
            ("akr_test_state_buffer", "measure_state"),
            ("akr_test_dir_buffer", "measure_dir"),
            ("akr_test_blocked_buffer", "measure_blocked"),
            ("akr_test_result_flags_buffer", "measure_result_flags"),
            ("akr_test_pos_rad_buffer", "measure_pos_rad"),
            ("akr_test_vel_rad_s_buffer", "measure_vel_rad_s"),
            ("akr_test_tq_nm_buffer", "measure_tq_nm"),
            ("akr_test_temp_c_buffer", "measure_temp_c"),
            ("akr_test_vbus_v_buffer", "measure_vbus_v"),
            ("akr_test_pattern_buffer", "measure_pattern"),
            ("akr_test_err_code_buffer", "measure_err_code"),
            ("akr_test_fb_age_ms_buffer", "measure_fb_age_ms"),
            ("akr_test_prom_df_end_rad_buffer", "measure_prom_df_end_rad"),
            ("akr_test_prom_pf_end_rad_buffer", "measure_prom_pf_end_rad"),
            ("akr_test_arom_df_max_rad_buffer", "measure_arom_df_max_rad"),
            ("akr_test_arom_pf_min_rad_buffer", "measure_arom_pf_min_rad"),
            ("akr_test_flag_prom_df_valid_buffer", "measure_flag_prom_df_valid"),
            ("akr_test_flag_prom_pf_valid_buffer", "measure_flag_prom_pf_valid"),
            ("akr_test_flag_arom_valid_buffer", "measure_flag_arom_valid"),
            ("akr_test_flag_seq_active_buffer", "measure_flag_seq_active"),
            ("akr_test_flag_arom_running_buffer", "measure_flag_arom_running"),
        ]
        for buf_name, field in robot_scalar_specs:
            buf = getattr(dev, buf_name, None)
            if self._robot_w is None or not buf:
                continue
            rows = self._iter_new_from_deque(str(buf_name), buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_20(float(ts) - origin)
                    self._robot_max_ms = max(self._robot_max_ms, int(t_ms))
                    self._set_robot_scalar(str(field), t_ms, (vals[0] if vals else ""))

        # Vectors (acc/gyr/mag) — use calibrated buffers for AKR.
        robot_vec_specs = [
            ("acc_buffer", "acc"),
            ("gyr_buffer", "gyr"),
            ("mag_buffer", "mag"),
            # Binary rr_telem walk IMU vectors (kept separate so channel selection can distinguish them).
            ("akr_walk_acc_buffer", "walk_acc"),
            ("akr_walk_gyr_buffer", "walk_gyr"),
            ("akr_walk_mag_buffer", "walk_mag"),
        ]
        for buf_name, sig in robot_vec_specs:
            buf = getattr(dev, buf_name, None)
            if self._robot_w is None or not buf:
                continue
            rows = self._iter_new_from_deque(str(buf_name) + ":robot", buf)
            if rows:
                for ts, vals in rows:
                    t_ms = self._round_ms_20(float(ts) - origin)
                    self._robot_max_ms = max(self._robot_max_ms, int(t_ms))
                    self._set_robot_vec3(str(sig), t_ms, list(vals))

        # Flush periodically to reduce loss on crash (best-effort).
        if self._emg_f is not None:
            try:
                self._emg_f.flush()
            except Exception:
                pass
        if self._imu_f is not None:
            try:
                self._imu_f.flush()
            except Exception:
                pass
        if self._robot_f is not None:
            try:
                self._robot_f.flush()
            except Exception:
                pass
        self._flush_emg()
        self._flush_imu()
        self._flush_robot()


class RecordingSession:
    """A multi-device recording session producing per-device files."""

    def __init__(
        self,
        *,
        session_paths: RecordingSessionPaths,
        recorders: dict[str, DeviceWideRecorder],
        on_log: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.session_paths = session_paths
        self.recorders = dict(recorders)
        self._on_log = on_log
        if self._on_log:
            self._on_log(f"Recording: folder -> {self.session_paths.root_dir}")

    def close(self) -> None:
        for r in list(self.recorders.values()):
            try:
                r.close()
            except Exception:
                pass
        self.recorders.clear()

    def capture_device(self, *, addr: str, dev: object) -> None:
        r = self.recorders.get(str(addr))
        if r is None:
            return
        r.capture(dev)

