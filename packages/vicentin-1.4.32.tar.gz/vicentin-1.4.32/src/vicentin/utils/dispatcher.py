from typing import Any, Callable, Dict, List, Optional, Tuple

SUPPORTED_BACKENDS = {
    "np": "np",
    "numpy": "np",
    "torch": "torch",
    "pytorch": "torch",
    "jax": "jax",
}


class Dispatcher:
    def __init__(self):
        self._registry: Dict[str, Tuple[Callable, Optional[Callable]]] = {}

        self.backend = None
        self.dtype = None
        self.device = None

    def register(
        self,
        backend_name: str,
        func: Callable,
        transformer: Optional[Callable] = None,
    ):
        if backend_name.lower() in SUPPORTED_BACKENDS:
            self._registry[SUPPORTED_BACKENDS[backend_name.lower()]] = (
                func,
                transformer,
            )

    def detect_backend(self, arg: Any, backend: Optional[str] = None):
        if backend is not None and backend.lower() in SUPPORTED_BACKENDS:
            self.backend = SUPPORTED_BACKENDS[backend.lower()]
        else:
            module = (
                getattr(arg.__class__, "__module__", "").split(".")[0].lower()
            )
            self.backend = SUPPORTED_BACKENDS.get(module, "np")

        if self.backend not in self._registry and self._registry:
            self.backend = next(iter(self._registry.keys()))

        self.dtype = getattr(arg, "dtype", None)
        self.device = getattr(arg, "device", None)

    def _cast_value(self, value: Any, target_backend: str) -> Any:
        if value is None:
            return None

        if isinstance(value, (list, tuple)):
            return [self._cast_value(v, target_backend) for v in value]

        if target_backend == "torch":
            import torch
            import numpy as np

            if not torch.is_tensor(value):
                try:
                    return torch.as_tensor(
                        value, dtype=self.dtype, device=self.device
                    )
                except Exception:
                    tensor = torch.as_tensor(np.copy(value))
                    if self.device is not None:
                        tensor = tensor.to(self.device)
                    return tensor

            return value

        elif target_backend == "jax":
            import jax.numpy as jnp

            return jnp.array(value, dtype=self.dtype)

        elif target_backend == "np":
            import numpy as np

            return np.array(value, dtype=self.dtype)

        return value

    def cast_values(self, *args) -> List[Any]:
        if self.backend is None:
            raise TypeError(
                "Dispatcher did not detect any backends. Please call `detect_backend` first."
            )

        casted_args = []

        for arg in args:
            casted_args.append(self._cast_value(arg, self.backend))

        if len(args) == 1:
            return casted_args[0]

        return casted_args

    def __call__(self, *args, **kwargs):
        if self.backend is None:
            raise TypeError(
                "Dispatcher did not detect any backends. Please call `detect_backend` first."
            )

        try:
            func, transformer = self._registry[self.backend]
        except KeyError as ke:
            print(
                f"Backend `{self.backend}` not found. Registered backends: {list(self._registry.keys())}."
            )

            raise ke

        if transformer:
            args, kwargs = transformer(*args, **kwargs)

        return func(*args, **kwargs)
