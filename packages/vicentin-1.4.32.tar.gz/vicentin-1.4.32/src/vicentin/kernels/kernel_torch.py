from typing import Callable, Optional
from abc import ABC

import torch
import torch.nn as nn


class KernelBackendTorch(nn.Module, ABC):
    def __init__(
        self,
        func: Callable,
        X: Optional[torch.Tensor] = None,
        chunk_size: Optional[int] = None,
    ):
        super().__init__()

        if X is None:
            X = torch.empty((0, 0))

        self.register_buffer("_X", X)
        self._N = int(self.X.shape[0])

        self.func = func
        self.chunk_size = chunk_size

        self._full_K = None

    @property
    def X(self) -> torch.Tensor:
        if isinstance(self._X, torch.Tensor):
            return self._X
        raise RuntimeError()

    @property
    def N(self) -> int:
        return self._N

    def _get_full_matrix(self) -> torch.Tensor:
        if self._full_K is None:
            self._full_K = self.func(self.X, self.X)

        return self._full_K

    def forward(
        self, x: torch.Tensor, y: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        return self.func(x, y)

    def __getitem__(self, key):
        with torch.no_grad():
            if self.chunk_size is None:
                return self._get_full_matrix()[key]

            if isinstance(key, tuple):
                row_idx, col_idx = key
            else:
                row_idx, col_idx = key, slice(None)

            return self.forward(self.X[row_idx], self.X[col_idx])

    def __matmul__(self, v: torch.Tensor) -> torch.Tensor:
        if self.chunk_size is None:
            return torch.matmul(self._get_full_matrix(), v)

        N, D = self.N, v.shape[1] if v.ndim > 1 else 1

        v = v.view(N, D)
        result = torch.zeros((N, D), device=self.X.device, dtype=self.X.dtype)

        for i in range(0, N, self.chunk_size):
            end_i = min(i + self.chunk_size, N)
            K_i = self.forward(self.X[i:end_i], self.X)

            result[i:end_i] = torch.mm(K_i, v)

        return result.squeeze()

    def apply_v(self, X: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        N = X.shape[0]
        D_v = v.shape[1] if v.ndim > 1 else 1

        v = v.view(self.N, D_v)
        result = torch.zeros((N, D_v), device=X.device, dtype=X.dtype)

        chunk = self.chunk_size if self.chunk_size is not None else N

        for i in range(0, N, chunk):
            end_i = min(i + chunk, N)
            K_chunk = self.func(X[i:end_i], self.X)
            result[i:end_i] = torch.mm(K_chunk, v)

        return result.squeeze()

    def trace(self):
        if self.chunk_size is None:
            return float(torch.trace(self._get_full_matrix()).item())

        trace_val = 0

        for i in range(0, self.N, self.chunk_size):
            end = min(i + self.chunk_size, self.N)
            x_chunk = self.X[i:end]

            K_chunk = self(x_chunk, x_chunk)

            trace_val += torch.trace(K_chunk).item()

        return float(trace_val)
