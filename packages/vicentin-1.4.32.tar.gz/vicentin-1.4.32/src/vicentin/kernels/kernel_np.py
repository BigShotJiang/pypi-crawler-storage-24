from typing import Callable, Optional
from abc import ABC
import numpy as np


class KernelBackendNumpy(ABC):
    def __init__(
        self,
        func: Callable,
        X: Optional[np.ndarray] = None,
        chunk_size: Optional[int] = None,
    ):
        super().__init__()

        if X is None:
            X = np.empty((0, 0))

        self._X = X
        self.func = func
        self.chunk_size = chunk_size

        self._full_K = None

    @property
    def X(self) -> np.ndarray:
        return self._X

    @property
    def N(self) -> int:
        return self.X.shape[0]

    def _get_full_matrix(self):
        if self._full_K is None:
            self._full_K = self.func(self.X, self.X)

        return self._full_K

    def __call__(self, x: np.ndarray, y: Optional[np.ndarray] = None):
        return self.func(x, y)

    def __getitem__(self, key):
        if self.chunk_size is None:
            return self._get_full_matrix()[key]

        if isinstance(key, tuple):
            row_key, col_key = key
        else:
            row_key, col_key = key, slice(None)

        rows = self._normalize_idx(row_key, self.N)
        cols = self._normalize_idx(col_key, self.N)

        x_eval = self.X[rows]
        K_rows = self.func(x_eval, self.X)

        return K_rows[:, cols].squeeze()

    def __matmul__(self, v):
        v = np.asanyarray(v)

        if self.chunk_size is None:
            return self._get_full_matrix() @ v

        v_reshaped = v.reshape(self.N, -1)
        result = np.zeros((self.N, v_reshaped.shape[1]))

        for i in range(0, self.N, self.chunk_size):
            end = min(i + self.chunk_size, self.N)
            K_block = self.func(self.X[i:end], self.X)
            result[i:end] = K_block @ v_reshaped

        return result.reshape(v.shape)

    def apply_v(self, X: np.ndarray, v: np.ndarray) -> np.ndarray:
        v = np.asanyarray(v)
        n_new = X.shape[0]

        D_v = v.shape[1] if v.ndim > 1 else 1
        v_reshaped = v.reshape(self.N, D_v)

        result = np.zeros((n_new, D_v))

        chunk = self.chunk_size if self.chunk_size is not None else n_new

        for i in range(0, n_new, chunk):
            end = min(i + chunk, n_new)
            K_chunk = self.func(X[i:end], self.X)

            result[i:end] = K_chunk @ v_reshaped

        return result.squeeze()

    def trace(self):
        if self.chunk_size is None:
            return float(np.trace(self._get_full_matrix()))

        trace_val = 0

        for i in range(0, self.N, self.chunk_size):
            end = min(i + self.chunk_size, self.N)
            x_chunk = self.X[i:end]

            K_chunk = self(x_chunk, x_chunk)

            trace_val += np.trace(K_chunk)

        return float(trace_val)

    def _normalize_idx(self, key, limit) -> np.ndarray:
        if isinstance(key, slice):
            return np.arange(*key.indices(limit))
        if isinstance(key, (int, np.integer)):
            return np.array([key if key >= 0 else limit + key])
        return np.asanyarray(key)
