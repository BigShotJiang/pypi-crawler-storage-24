from typing import Any, Optional
from vicentin.kernels import Kernel


class LinearKernel(Kernel):
    def _compute(self, x: Any, y: Optional[Any] = None):

        if y is None:
            y = self.X

        if getattr(x, "ndim", 1) == 1:
            x = x[None, :]
        if getattr(y, "ndim", 1) == 1:
            y = y[None, :]  # pyright: ignore[reportOptionalSubscript]

        return (x @ y.T).squeeze()

    def apply(self, X: Any, v: Any) -> Any:
        return X @ (self.X.T @ v)
