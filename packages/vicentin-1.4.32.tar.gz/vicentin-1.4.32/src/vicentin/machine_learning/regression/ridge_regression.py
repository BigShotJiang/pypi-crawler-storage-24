from typing import Any, Optional

from vicentin.machine_learning.predictor import Predictor, LinearPredictor
from vicentin.kernels import (
    Kernel,
    RKHSFunction,
    LinearKernel,
)
from vicentin.optimization.minimization import conjugate_gradient

from vicentin.utils import Dispatcher

disp_ones = Dispatcher()
disp_solve = Dispatcher()
disp_eye = Dispatcher()

try:
    import numpy as np

    disp_ones.register("numpy", lambda k, x: np.ones(k, dtype=x.dtype))
    disp_solve.register("numpy", np.linalg.solve)
    disp_eye.register("numpy", lambda k, x: np.eye(k, dtype=x.dtype))
except ImportError:
    pass

try:
    import torch

    disp_ones.register(
        "torch", lambda k, x: torch.ones(k, dtype=x.dtype, device=x.device)
    )
    disp_solve.register("torch", torch.linalg.solve)
    disp_eye.register(
        "torch", lambda k, x: torch.eye(k, dtype=x.dtype, device=x.device)
    )
except ImportError:
    pass


def _kernel_ridge_regression(
    kernel: Kernel,
    y: Any,
    W: Any,
    lambda_reg: float,
):
    y = y.reshape(-1, 1) if y.ndim == 1 else y
    W = W.reshape(-1, 1) if W.ndim == 1 else W

    if kernel.N < 10_000:
        K = kernel[:, :]
        A = (W * K) + lambda_reg * disp_eye(kernel.N, y)
        alpha = disp_solve(A, W * y)
    else:
        A_op = lambda v: W * (kernel @ v) + lambda_reg * v
        alpha = conjugate_gradient(A_op, W * y, max_iter=kernel.N)

    return RKHSFunction(kernel, alpha)


def _ridge_regression(X: Any, y: Any, W: Any, lambda_reg: float):
    _, d = X.shape

    y = y.reshape(-1, 1) if y.ndim == 1 else y
    W = W.reshape(-1, 1) if W.ndim == 1 else W

    b = X.T @ (W * y)

    if d < 10_000:
        A = X.T @ (W * X) + lambda_reg * disp_eye(d, X)
        w = disp_solve(A, b)
    else:
        A_op = lambda v: (X.T @ (W * (X @ v))) + lambda_reg * v
        w = conjugate_gradient(A_op, b, max_iter=d)

    return LinearPredictor(w)


def ridge_regression(
    X: Any | Kernel,
    y: Any,
    lambda_: float = 0,
    W: Optional[Any] = None,
) -> Predictor:
    """
    Solves the Ridge Regression problem in either Primal or Dual (Kernel) space.

    This function implements a generalized version of Ridge Regression that
    automatically selects the most computationally efficient solver based on
    the input dimensions $(n, d)$ and the provided kernel, following the
    Matrix Inversion Lemma. It also supports
    Weighted Least Squares for handling heteroscedastic noise.

    The objective function minimized is:
    $J(f) = \\frac{1}{n} \\sum_{i=1}^n W_i (y_i - f(x_i))^2 + \\lambda \\|f\\|^2_{\\mathcal{H}}$

    Optimization Strategy:
    ----------------------
    - **Primal Space (RR):** Used when $d < n$ and the kernel is Linear.
      Solves for weights $w \\in \\mathbb{R}^d$ in $O(d^3)$ or $O(I \\cdot d^2)$
      time.
    - **Dual Space (KRR):** Used when $n < d$ or for non-linear kernels.
      Solves for coefficients $\\alpha \\in \\mathbb{R}^n$ in $O(n^3)$ or
      $O(I \\cdot n^2)$ time.



    Complexity Analysis:
    -------------------
    - **Small Datasets (< 10,000):** Uses direct Cholesky/LU solvers via
      `disp_solve` for maximum precision ($O(\\min(n, d)^3)$).
    - **Large Datasets (>= 10,000):** Uses the Linear Conjugate Gradient
      solver to avoid $O(N^2)$ memory allocation, utilizing chunked
      matrix-vector products.

    Parameters:
    -----------
    X : Any (Array-like) or Kernel
        If not using kernel, X is the training inputs of shape (n, d).
        The type determines the computational backend (NumPy vs. PyTorch).
        If using a kernel, X is the kernel.
    y : Any (Array-like)
        Training targets of shape (n,).
    lambda_ : float, optional (default=0)
        Regularization parameter. Internally scaled by $n$ to maintain
        consistency across dataset sizes: $\\lambda_{reg} = \\lambda \\cdot n$.
    W : Any (Array-like), optional (default=None)
        Weight vector of shape (n,) representing the diagonal of the
        weight matrix $\\mathbf{W}$. If None,
        defaults to uniform weights (identity).

    Returns:
    --------
    f : Predictor
        A callable object representing the learned function $f \\in \\mathcal{H}$.
        Supports evaluation `f(x)` and RKHS norm calculation `f.squared_norm()`.
    """

    if isinstance(X, Kernel):
        kernel = X
        X = kernel.X
    else:
        kernel = LinearKernel(X)

    n, d = X.shape
    lambda_reg = lambda_ * n

    disp_ones.detect_backend(X)
    disp_eye.detect_backend(X)
    disp_solve.detect_backend(X)

    if W is None:
        W = disp_ones(n, X)

    if d < n and isinstance(kernel, LinearKernel):
        return _ridge_regression(X, y, W, lambda_reg)
    else:
        return _kernel_ridge_regression(kernel, y, W, lambda_reg)
