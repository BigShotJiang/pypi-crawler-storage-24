from typing import Any

from vicentin.machine_learning.predictor import Predictor
from vicentin.utils import Dispatcher
from vicentin.kernels import Kernel, RKHSFunction, LinearKernel
from vicentin.machine_learning.regression import ridge_regression

disp_exp = Dispatcher()
disp_zeros = Dispatcher()
disp_diff = Dispatcher()

try:
    import numpy as np

    disp_exp.register("numpy", np.exp)
    disp_zeros.register("numpy", lambda k, x: np.zeros(k, dtype=x.dtype))
    disp_diff.register("numpy", lambda x, y: float(np.max(np.abs(x - y))))
except ImportError:
    pass

try:
    import torch

    disp_exp.register("torch", torch.exp)
    disp_zeros.register(
        "torch", lambda k, x: torch.zeros(k, dtype=x.dtype, device=x.device)
    )
    disp_diff.register("torch", lambda x, y: float((x - y).abs().max()))
except ImportError:
    pass


def _sigmoid(u: Any):
    return 1 / (1 + disp_exp(-u))


def logistic_regression(
    X: Any | Kernel,
    y: Any,
    lambda_: float = 0,
    max_iter: int = 20,
    tol: float = 1e-5,
) -> Predictor:

    if isinstance(X, Kernel):
        kernel = X
        X = kernel.X
    else:
        kernel = LinearKernel(X)

    disp_exp.detect_backend(X)
    disp_zeros.detect_backend(X)
    disp_diff.detect_backend(X)

    n, _ = X.shape

    alpha = disp_zeros(n, X)
    m = disp_zeros(n, X)

    f = RKHSFunction(kernel, alpha)

    for _ in range(max_iter):
        m_prev = m

        m = f(X).reshape(-1)

        W = _sigmoid(m) * _sigmoid(-m)
        z = m + y / _sigmoid(y * m)

        f = ridge_regression(kernel, z, lambda_, W)

        if disp_diff(m, m_prev) < tol:
            break

    return f
