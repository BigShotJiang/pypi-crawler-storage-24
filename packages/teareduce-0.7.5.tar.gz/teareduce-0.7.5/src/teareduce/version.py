# -*- coding: utf-8 -*-
#
# Copyright 2023-2026 Universidad Complutense de Madrid
#
# This file is part of teareduce
#
# SPDX-License-Identifier: GPL-3.0-or-later
# License-Filename: LICENSE.txt
#
"""Module to define the version of the teareduce package."""

VERSION = "0.7.5"


def main():
    """Prints the version of the teareduce package."""
    print("Version: " + VERSION)


if __name__ == "__main__":
    main()
