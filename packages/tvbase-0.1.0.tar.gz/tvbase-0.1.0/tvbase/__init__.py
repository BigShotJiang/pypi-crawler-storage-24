#  __init__.py
#
# Copyright © 2023-2026 Charité Universitätsmedizin Berlin
# Author: Leon K. Martin
# Licensed under the European Union Public Licence (EUPL) v1.2 or later.
#
"""TVBase — The Virtual Brain knowledge base adapter."""

__all__ = ["__version__"]
__version__ = "0.1.0"
