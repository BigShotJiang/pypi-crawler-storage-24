# tvbase

TVBase — The Virtual Brain knowledge base adapter.

## License

Copyright © 2023-2026 Charité Universitätsmedizin Berlin. This software is licensed under the terms of the European Union Public Licence (EUPL) version 1.2 or later.
