import sys
from rich.console import Console
from rich.table import Table

console = Console()

def check_all(provider="ollama", model="llama3.1:8b", ollama_url="http://localhost:11434"):
    results = {
        "ok": True,
        "python": _check_python(),
        "torch": _check_torch(),
        "whisper": _check_whisper(),
        "sentence_transformers": _check_st(),
        "sounddevice": _check_sd(),
        "lancedb": _check_lancedb(),
        "ollama": None,
    }
    if provider == "ollama":
        results["ollama"] = _check_ollama(ollama_url, model)
        if not results["ollama"]["ok"]:
            results["ok"] = False
    for k in ["python","torch","whisper","sentence_transformers","sounddevice","lancedb"]:
        if results[k] and not results[k].get("ok"):
            results["ok"] = False
    return results

def _check_python():
    v = sys.version_info
    ok = v.major==3 and v.minor==11
    return {"ok":ok,"version":f"{v.major}.{v.minor}.{v.micro}","message":"OK" if ok else f"Python 3.11 required"}

def _check_torch():
    try:
        import torch
        ok = torch.__version__.startswith("2.2")
        return {"ok":ok,"version":torch.__version__,"message":"OK" if ok else "torch 2.2.x recommended"}
    except ImportError:
        return {"ok":False,"version":None,"message":"not installed — pip install torch==2.2.2"}

def _check_whisper():
    try:
        import whisper
        return {"ok":True,"version":"installed","message":"OK"}
    except ImportError:
        return {"ok":False,"version":None,"message":"not installed — pip install openai-whisper"}

def _check_st():
    try:
        from sentence_transformers import SentenceTransformer
        m = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
        out = m.encode(["test"])
        return {"ok":out.shape==(1,384),"version":"installed","message":"OK"}
    except Exception as e:
        return {"ok":False,"version":None,"message":str(e)}

def _check_sd():
    try:
        import sounddevice as sd
        sd.query_devices()
        return {"ok":True,"version":"installed","message":"OK"}
    except Exception as e:
        return {"ok":True,"version":"installed","message":f"installed ({e})"}

def _check_lancedb():
    try:
        import lancedb
        return {"ok":True,"version":"installed","message":"OK"}
    except ImportError:
        return {"ok":False,"version":None,"message":"not installed — pip install lancedb"}

def _check_ollama(base_url, model):
    try:
        import requests
        resp = requests.get(f"{base_url}/api/tags", timeout=5)
        models = [m["name"] for m in resp.json().get("models",[])]
        ok = any(model in m for m in models)
        return {"ok":ok,"running":True,"message":"OK" if ok else f"run: ollama pull {model}"}
    except:
        return {"ok":False,"running":False,"message":"Ollama not running — run: ollama serve"}

def print_results(results):
    table = Table(title="DevMind Pro — pre-flight checks", header_style="bold purple")
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")
    labels = {"python":"Python","torch":"PyTorch","whisper":"Whisper",
              "sentence_transformers":"Sentence Transformers","sounddevice":"Sounddevice",
              "lancedb":"LanceDB","ollama":"Ollama"}
    for key, label in labels.items():
        r = results.get(key)
        if r is None: continue
        ok = r.get("ok",False)
        status = "[green]✓ OK[/green]" if ok else "[red]✗ FAIL[/red]"
        v = r.get("version","")
        msg = r.get("message","")
        detail = f"{v} — {msg}" if v and v!="installed" else msg
        table.add_row(label, status, detail)
    console.print(table)
