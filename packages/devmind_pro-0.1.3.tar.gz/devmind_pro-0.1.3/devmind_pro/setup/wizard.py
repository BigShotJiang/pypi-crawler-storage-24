import os, subprocess, platform
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm

console = Console()

def _ask(prompt, default=""):
    return Prompt.ask(prompt, default=default)

def _confirm(prompt, default=True):
    return Confirm.ask(prompt, default=default)

def run_wizard(interactive=True):
    console.print("\n[bold purple]DevMind Pro Setup Wizard[/bold purple]\n")
    config = {}

    console.print("[bold]Step 1/5[/bold] — Your name")
    config["MY_NAME"] = _ask("  Your name", "")

    console.print("\n[bold]Step 2/5[/bold] — AI provider")
    console.print("  1. Ollama (local, free)\n  2. OpenAI\n  3. Gemini\n  4. Groq")
    choice = _ask("  Choose [1/2/3/4]", "1") if interactive else "1"
    config["AI_PROVIDER"] = {"1":"ollama","2":"openai","3":"gemini","4":"groq"}.get(choice,"ollama")

    console.print(f"\n[bold]Step 3/5[/bold] — {config['AI_PROVIDER'].title()} config")
    if config["AI_PROVIDER"] == "ollama":
        config["OLLAMA_MODEL"] = _ask("  Model", "llama3.1:8b")
        config["OLLAMA_BASE_URL"] = _ask("  Ollama URL", "http://localhost:11434")
        config["AI_MODEL"] = config["OLLAMA_MODEL"]
    elif config["AI_PROVIDER"] == "openai":
        config["OPENAI_API_KEY"] = _ask("  OpenAI API key")
        config["AI_MODEL"] = _ask("  Model", "gpt-4o-mini")
    elif config["AI_PROVIDER"] == "gemini":
        config["GEMINI_API_KEY"] = _ask("  Gemini API key")
        config["AI_MODEL"] = "gemini-1.5-flash"
    elif config["AI_PROVIDER"] == "groq":
        config["GROQ_API_KEY"] = _ask("  Groq API key")
        config["GROQ_MODEL"] = _ask("  Model", "llama3-70b-8192")
        config["AI_MODEL"] = config["GROQ_MODEL"]

    console.print("\n[bold]Step 4/5[/bold] — Whisper")
    config["WHISPER_MODEL"] = _ask("  Model (tiny/small/medium/large)", "small")
    config["WHISPER_LANG"] = _ask("  Language", "en")

    console.print("\n[bold]Step 5/5[/bold] — Folders")
    config["DOCS_FOLDER"] = _ask("  Docs folder", "./docs")
    config["CODEBASE_FOLDER"] = _ask("  Codebase folder (optional)", "")
    config["SUMMARY_OUTPUT_DIR"] = _ask("  Summaries folder", "./summaries")
    config["ANALYSIS_INTERVAL"] = _ask("  Analysis interval (seconds)", "60")
    config["ALERT_KEYWORDS"] = _ask("  Alert keywords", "deadline,blocked,urgent,action item,critical")
    config["TEAMS_CONTACTS"] = _ask("  Teams contacts (Name:url,Name2:url2)", "")
    config["TOKENIZERS_PARALLELISM"] = "false"
    config["AUDIO_DEVICE"] = ""

    _write_env(Path(".env"), config)
    Path(config["DOCS_FOLDER"]).mkdir(parents=True, exist_ok=True)
    Path(config["SUMMARY_OUTPUT_DIR"]).mkdir(parents=True, exist_ok=True)
    console.print("\n[bold green]✓ Setup complete![/bold green] Run: [bold]devmind start[/bold]\n")

def _write_env(path, config):
    lines = ["# DevMind Pro Configuration"]
    for k, v in config.items():
        lines.append(f"{k}={v or ''}")
    path.write_text("\n".join(lines) + "\n")
    console.print(f"[green]✓[/green] Config written to {path}")
