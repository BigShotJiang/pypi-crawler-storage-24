from importlib.metadata import version, PackageNotFoundError
try:
    __version__ = version("devmind-pro")
except PackageNotFoundError:
    __version__ = "0.1.0-dev"
from devmind_pro.sdk import DevMind, configure, start
__all__ = ["__version__", "DevMind", "configure", "start"]
