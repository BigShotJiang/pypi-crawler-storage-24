"""
ai_engine.py  -  Universal AI engine for DevMind.

Set AI_PROVIDER in .env:
  AI_PROVIDER=ollama     (default, free, local)
  AI_PROVIDER=gemini     (needs GEMINI_API_KEY)
  AI_PROVIDER=openai     (needs OPENAI_API_KEY)
  AI_PROVIDER=groq       (needs GROQ_API_KEY)
"""

import os
import re
import json
import requests
from dotenv import load_dotenv

load_dotenv()

AI_PROVIDER = os.getenv("AI_PROVIDER", "ollama").lower()
AI_MODEL    = os.getenv("AI_MODEL", "llama3.1:8b")
OLLAMA_URL  = "http://localhost:11434/api/generate"


def _ask_ollama(prompt: str, max_tokens: int = 800) -> str:
    try:
        resp = requests.post(
            OLLAMA_URL,
            json={
                "model": AI_MODEL,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": 0.3, "num_predict": max_tokens, "num_ctx": 2048},
            },
            timeout=90,
        )
        if resp.status_code == 200:
            return resp.json().get("response", "").strip()
        print(f"[AI] Ollama error {resp.status_code}")
        return ""
    except requests.exceptions.ConnectionError:
        print("[AI] Ollama not running! Run: ollama serve")
        return ""
    except Exception as e:
        print(f"[AI] Ollama error: {e}")
        return ""


def _ask_gemini(prompt: str, max_tokens: int = 800) -> str:
    try:
        import google.generativeai as genai
        api_key = os.getenv("GEMINI_API_KEY", "")
        if not api_key:
            print("[AI] GEMINI_API_KEY not set in .env")
            return ""
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel(model_name=AI_MODEL)
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        print(f"[AI] Gemini error: {e}")
        return ""


def _ask_openai(prompt: str, max_tokens: int = 800) -> str:
    try:
        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            print("[AI] OPENAI_API_KEY not set in .env")
            return ""
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "model": AI_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": 0.3,
            },
            timeout=30,
        )
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"].strip()
        print(f"[AI] OpenAI error {resp.status_code}: {resp.text[:200]}")
        return ""
    except Exception as e:
        print(f"[AI] OpenAI error: {e}")
        return ""


def _ask_groq(prompt: str, max_tokens: int = 800) -> str:
    try:
        api_key = os.getenv("GROQ_API_KEY", "")
        if not api_key:
            print("[AI] GROQ_API_KEY not set in .env")
            return ""
        resp = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "model": AI_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": 0.3,
            },
            timeout=30,
        )
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"].strip()
        print(f"[AI] Groq error {resp.status_code}: {resp.text[:200]}")
        return ""
    except Exception as e:
        print(f"[AI] Groq error: {e}")
        return ""


def ask_ai(prompt: str, max_tokens: int = 800) -> str:
    if AI_PROVIDER == "ollama":
        return _ask_ollama(prompt, max_tokens)
    elif AI_PROVIDER == "gemini":
        return _ask_gemini(prompt, max_tokens)
    elif AI_PROVIDER == "openai":
        return _ask_openai(prompt, max_tokens)
    elif AI_PROVIDER == "groq":
        return _ask_groq(prompt, max_tokens)
    else:
        print(f"[AI] Unknown provider: {AI_PROVIDER}. Using ollama.")
        return _ask_ollama(prompt, max_tokens)


def _parse_json(text: str, fallback):
    try:
        clean = re.sub(r"```json|```", "", text, flags=re.MULTILINE).strip()
        match = re.search(r"(\[.*\]|\{.*\})", clean, re.DOTALL)
        if match:
            return json.loads(match.group(1))
    except Exception as e:
        print(f"[AI] JSON parse error: {e}")
    return fallback


class AIEngine:
    def __init__(self, api_key: str = "", rag_engine=None, codebase_rag=None):
        self._rag      = rag_engine
        self._code_rag = codebase_rag
        self._check_provider()
        print(f"[AI] Provider: {AI_PROVIDER.upper()} | Model: {AI_MODEL}")

    def _check_provider(self):
        if AI_PROVIDER == "ollama":
            try:
                requests.get("http://localhost:11434", timeout=3)
                print("[AI] Ollama is running OK")
            except Exception:
                print("[AI] WARNING: Ollama not running! Run: ollama serve")
        else:
            print(f"[AI] Using {AI_PROVIDER} API")

    def _get_context(self, query: str, include_code: bool = False) -> str:
        parts = []
        if self._rag:
            doc_ctx = self._rag.query(query, n_results=2)
            if doc_ctx and "No relevant" not in doc_ctx:
                parts.append(f"PROJECT DOCS:\n{doc_ctx}")
        if include_code and self._code_rag:
            code_ctx = self._code_rag.query(query, n_results=2)
            if code_ctx and "No relevant" not in code_ctx:
                parts.append(f"CODEBASE:\n{code_ctx}")
        return "\n\n".join(parts) or "No context available."

    def analyse_transcript(self, transcript: str, recent_only: str = "") -> list:
        if not transcript.strip():
            return []
        context = self._get_context(transcript, include_code=True)
        prompt = f"""You are a meeting assistant helping a developer.

RECENT TRANSCRIPT:
{recent_only or transcript[-1500:]}

PROJECT CONTEXT:
{context}

Find 1-3 important gaps or questions to raise RIGHT NOW.
Only flag genuinely important things.
If nothing important, return empty array.

Respond ONLY with JSON array:
[{{"doubt": "specific question", "why": "one sentence reason", "priority": "high|medium|low"}}]"""

        raw = ask_ai(prompt)
        result = _parse_json(raw, [])
        return result if isinstance(result, list) else []

    def suggest_reply(self, question_asked: str, full_transcript: str) -> dict:
        context = self._get_context(question_asked, include_code=True)
        prompt = f"""Help a developer answer this question in a meeting.

QUESTION: "{question_asked}"

MEETING CONTEXT:
{full_transcript[-400:] if full_transcript else "N/A"}

PROJECT CONTEXT:
{context}

Write a confident reply (2-3 sentences).
If answer is in docs/code, cite the source.

Respond ONLY with JSON:
{{"reply": "the reply", "confidence": "high|medium|low", "source": "filename or not in docs"}}"""

        raw = ask_ai(prompt)
        result = _parse_json(raw, None)
        if isinstance(result, dict) and "reply" in result:
            return result
        if raw and len(raw) > 10:
            return {"reply": raw[:300], "confidence": "medium", "source": f"{AI_PROVIDER} response"}
        return {"reply": "I'll need to check and get back to you.", "confidence": "low", "source": "error"}

    def detect_question_directed_at_me(self, transcript_chunk: str, my_name: str = ""):
        if not transcript_chunk.strip() or "?" not in transcript_chunk:
            return None
        name_hint = f"Developer's name: {my_name}." if my_name else "Look for 'you' or name mentions."
        prompt = f"""Meeting chunk: "{transcript_chunk}"
{name_hint}
Is there a question directed at a specific person?
If YES: {{"question": "the question", "asked_by": "name or unknown"}}
If NO: null"""

        raw = ask_ai(prompt, max_tokens=150)
        if not raw or raw.strip().lower() == "null":
            return None
        result = _parse_json(raw, None)
        return result if isinstance(result, dict) else None

    def what_did_i_miss(self, recent_transcript: str) -> str:
        if not recent_transcript.strip():
            return "Nothing transcribed yet."
        prompt = f"""Summarise the last few minutes of this meeting.

TRANSCRIPT:
{recent_transcript[-2000:]}

Write exactly 3-5 bullet points.
Each bullet = one sentence max.
Start each with "•"
No headers, no JSON."""

        return ask_ai(prompt, max_tokens=400) or "Could not generate summary."


if __name__ == "__main__":
    print(f"AI Provider: {AI_PROVIDER}")
    print(f"AI Model: {AI_MODEL}")
    engine = AIEngine()
    print("\nTest reply:")
    r = engine.suggest_reply("What is the onboarding process?", "")
    print(r)