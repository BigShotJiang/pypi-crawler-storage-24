"""
platform_utils.py — DevMind Pro
Cross-platform utilities for audio capture, clipboard, paths,
process management, and system tray integration.
Abstracts Mac/Windows/Linux differences so other modules stay clean.
"""

import os
import platform
import queue
import subprocess
import sys
import threading
import time
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

SYSTEM = platform.system()   # "Darwin" | "Windows" | "Linux"
IS_MAC = SYSTEM == "Darwin"
IS_WIN = SYSTEM == "Windows"
IS_LINUX = SYSTEM == "Linux"

SAMPLE_RATE = int(os.getenv("SAMPLE_RATE", "16000"))
CHUNK_SECONDS = int(os.getenv("CHUNK_SECONDS", "5"))


# ---------------------------------------------------------------------------
# Suppress ChromaDB telemetry noise
# ---------------------------------------------------------------------------
# ChromaDB ≥ 0.4 changed its internal telemetry API; older builds emit
# "capture() takes 1 positional argument but 3 were given" on every call.
# Setting the env var and monkey-patching the client both silence it.

os.environ.setdefault("ANONYMIZED_TELEMETRY", "False")
os.environ.setdefault("CHROMA_TELEMETRY", "False")


def suppress_chromadb_telemetry():
    """Monkey-patch ChromaDB's telemetry client to be a no-op."""
    try:
        import chromadb.telemetry.product as _ct  # type: ignore[import]

        class _NoOpTelemetry:
            def capture(self, *a, **kw): pass
            def identify_user(self, *a, **kw): pass
            def alias(self, *a, **kw): pass

        _ct.ProductTelemetryClient = _NoOpTelemetry  # type: ignore[attr-defined]
    except Exception:
        pass  # older/newer chromadb layout — env var alone is enough

    # Also silence the logger chromadb uses for telemetry errors
    logging.getLogger("chromadb.telemetry").setLevel(logging.CRITICAL)
    logging.getLogger("chromadb").setLevel(logging.WARNING)


# Run at import time so any module that does `from platform_utils import ...`
# gets telemetry suppressed automatically.
suppress_chromadb_telemetry()


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class PlatformError(Exception):
    """Raised when a platform-specific operation fails or isn't supported."""


# ---------------------------------------------------------------------------
# Data dirs
# ---------------------------------------------------------------------------

def get_app_data_dir(app_name: str = "DevMindPro") -> Path:
    """Return the platform-appropriate application data directory."""
    if IS_WIN:
        base = Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif IS_MAC:
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.getenv("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    app_dir = base / app_name
    app_dir.mkdir(parents=True, exist_ok=True)
    return app_dir


def get_cache_dir(app_name: str = "DevMindPro") -> Path:
    if IS_WIN:
        base = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif IS_MAC:
        base = Path.home() / "Library" / "Caches"
    else:
        base = Path(os.getenv("XDG_CACHE_HOME", Path.home() / ".cache"))
    cache_dir = base / app_name
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_log_dir(app_name: str = "DevMindPro") -> Path:
    if IS_WIN:
        base = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        log_dir = base / app_name / "Logs"
    elif IS_MAC:
        log_dir = Path.home() / "Library" / "Logs" / app_name
    else:
        log_dir = Path(os.getenv("XDG_STATE_HOME", Path.home() / ".local" / "state")) / app_name / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir


# ---------------------------------------------------------------------------
# Audio capture backends
# ---------------------------------------------------------------------------

class _AudioBackendBase:
    """Abstract base for platform audio capture."""

    def capture(
        self,
        q: queue.Queue,
        stop_event: threading.Event,
        sample_rate: int,
        chunk_seconds: int,
        source: str = "default",
    ):
        raise NotImplementedError


class _PyAudioBackend(_AudioBackendBase):
    """PyAudio-based capture — works on all platforms as a fallback."""

    def capture(self, q, stop_event, sample_rate, chunk_seconds, source="default"):
        try:
            import pyaudio  # type: ignore[import]
        except ImportError as exc:
            raise PlatformError(
                "PyAudio not installed. Run: pip install pyaudio"
            ) from exc

        pa = pyaudio.PyAudio()
        chunk_frames = sample_rate * chunk_seconds

        device_index = None
        if source == "system":
            device_index = self._find_loopback_device(pa)

        stream = pa.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=sample_rate,
            input=True,
            input_device_index=device_index,
            frames_per_buffer=1024,
        )
        logger.info("PyAudio capture started (device=%s)", device_index)

        try:
            while not stop_event.is_set():
                frames = []
                for _ in range(0, int(sample_rate / 1024 * chunk_seconds)):
                    if stop_event.is_set():
                        break
                    data = stream.read(1024, exception_on_overflow=False)
                    frames.append(data)
                if frames:
                    q.put(b"".join(frames))
        finally:
            stream.stop_stream()
            stream.close()
            pa.terminate()
            logger.info("PyAudio capture stopped.")

    @staticmethod
    def _find_loopback_device(pa) -> Optional[int]:
        """Try to find a loopback/monitor device for system audio capture."""
        for i in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(i)
            name = info.get("name", "").lower()
            if "loopback" in name or "stereo mix" in name or "monitor" in name:
                return i
        return None


class _MacOSCoreAudioBackend(_AudioBackendBase):
    """
    macOS audio capture.

    Priority order:
      1. sounddevice  — mic capture (already installed, no extra deps)
      2. BlackHole/Soundflower via PyAudio — system audio (requires BlackHole)
      3. PyAudio mic  — last resort fallback
    """

    def capture(self, q, stop_event, sample_rate, chunk_seconds, source="default"):
        if source == "system":
            # System audio requires BlackHole virtual device
            try:
                return self._capture_blackhole(q, stop_event, sample_rate, chunk_seconds)
            except PlatformError as e:
                logger.warning("System audio unavailable (%s); falling back to mic.", e)

        # Mic capture — prefer sounddevice (already in requirements.txt)
        try:
            return self._capture_sounddevice(q, stop_event, sample_rate, chunk_seconds)
        except ImportError:
            logger.warning("sounddevice not available; trying PyAudio.")

        # Last resort: PyAudio
        return _PyAudioBackend().capture(q, stop_event, sample_rate, chunk_seconds, source)

    # ------------------------------------------------------------------

    def _capture_sounddevice(self, q, stop_event, sample_rate, chunk_seconds):
        """Capture mic audio via sounddevice — the preferred macOS path."""
        import sounddevice as sd  # already installed
        import numpy as np

        num_frames = sample_rate * chunk_seconds
        logger.info("macOS: capturing via sounddevice (mic, %d Hz, %ds chunks)",
                    sample_rate, chunk_seconds)

        while not stop_event.is_set():
            try:
                recording = sd.rec(
                    num_frames,
                    samplerate=sample_rate,
                    channels=1,
                    dtype="int16",
                )
                sd.wait()
                if not stop_event.is_set():
                    q.put(recording.tobytes())
            except Exception as exc:
                logger.error("sounddevice capture error: %s", exc)
                stop_event.set()

    def _capture_blackhole(self, q, stop_event, sample_rate, chunk_seconds):
        """Capture system audio via BlackHole/Soundflower virtual device."""
        # Try sounddevice first (no PyAudio needed)
        try:
            import sounddevice as sd
            import numpy as np

            devices = sd.query_devices()
            bh_index = next(
                (i for i, d in enumerate(devices)
                 if any(kw in d["name"] for kw in ("BlackHole", "Soundflower", "Multi-Output"))),
                None,
            )
            if bh_index is not None:
                num_frames = sample_rate * chunk_seconds
                logger.info("macOS: capturing system audio via %s (sounddevice index=%d)",
                            devices[bh_index]["name"], bh_index)
                while not stop_event.is_set():
                    rec = sd.rec(num_frames, samplerate=sample_rate, channels=1,
                                 dtype="int16", device=bh_index)
                    sd.wait()
                    if not stop_event.is_set():
                        q.put(rec.tobytes())
                return
        except Exception:
            pass

        # Fallback: PyAudio + BlackHole
        try:
            import pyaudio  # type: ignore[import]
        except ImportError as exc:
            raise PlatformError(
                "System audio capture requires BlackHole (https://existential.audio/blackhole/) "
                "and either sounddevice or pyaudio."
            ) from exc

        pa = pyaudio.PyAudio()
        bh_index = None
        for i in range(pa.get_device_count()):
            name = pa.get_device_info_by_index(i).get("name", "")
            if any(kw in name for kw in ("BlackHole", "Soundflower")):
                bh_index = i
                break

        if bh_index is None:
            pa.terminate()
            raise PlatformError(
                "BlackHole not found. Install from https://existential.audio/blackhole/ "
                "or set AUDIO_DEVICE=default in .env to use the mic instead."
            )

        logger.info("macOS: capturing system audio via BlackHole (PyAudio index=%d)", bh_index)
        stream = pa.open(
            format=pyaudio.paInt16, channels=1, rate=sample_rate,
            input=True, input_device_index=bh_index, frames_per_buffer=1024,
        )
        try:
            while not stop_event.is_set():
                frames = [stream.read(1024, exception_on_overflow=False)
                          for _ in range(int(sample_rate / 1024 * chunk_seconds))]
                q.put(b"".join(frames))
        finally:
            stream.stop_stream()
            stream.close()
            pa.terminate()


class _WindowsWASAPIBackend(_AudioBackendBase):
    """Windows WASAPI loopback for system audio capture."""

    def capture(self, q, stop_event, sample_rate, chunk_seconds, source="default"):
        try:
            import soundcard as sc  # type: ignore[import]
        except ImportError:
            logger.warning("soundcard not installed; falling back to PyAudio.")
            return _PyAudioBackend().capture(q, stop_event, sample_rate, chunk_seconds, source)

        if source == "system":
            try:
                mic = sc.get_microphone(id=str(sc.default_speaker().name), include_loopback=True)
            except Exception:
                mic = sc.default_microphone()
        else:
            mic = sc.default_microphone()

        num_frames = sample_rate * chunk_seconds
        logger.info("Windows WASAPI capture: %s", mic.name)

        with mic.recorder(samplerate=sample_rate, channels=1) as rec:
            while not stop_event.is_set():
                data = rec.record(numframes=num_frames)
                # Convert float32 → int16
                import numpy as np
                pcm = (data * 32767).astype(np.int16).tobytes()
                q.put(pcm)


class _LinuxPulseAudioBackend(_AudioBackendBase):
    """Linux PulseAudio capture via sounddevice."""

    def capture(self, q, stop_event, sample_rate, chunk_seconds, source="default"):
        try:
            import sounddevice as sd
            import numpy as np
        except ImportError:
            logger.warning("sounddevice not installed; falling back to PyAudio.")
            return _PyAudioBackend().capture(q, stop_event, sample_rate, chunk_seconds, source)

        device = None
        if source == "system":
            # Try to find a monitor source
            devices = sd.query_devices()
            for i, d in enumerate(devices):
                if "monitor" in str(d.get("name", "")).lower():
                    device = i
                    break

        logger.info("Linux sounddevice capture (device=%s)", device)
        num_frames = sample_rate * chunk_seconds

        while not stop_event.is_set():
            recording = sd.rec(
                num_frames,
                samplerate=sample_rate,
                channels=1,
                dtype="int16",
                device=device,
            )
            sd.wait()
            if not stop_event.is_set():
                q.put(recording.tobytes())


def get_audio_backend() -> _AudioBackendBase:
    """Return the appropriate audio capture backend for this platform."""
    if IS_MAC:
        return _MacOSCoreAudioBackend()
    elif IS_WIN:
        return _WindowsWASAPIBackend()
    else:
        return _LinuxPulseAudioBackend()


# ---------------------------------------------------------------------------
# Clipboard
# ---------------------------------------------------------------------------

def copy_to_clipboard(text: str) -> bool:
    """Copy text to the system clipboard. Returns True on success."""
    try:
        if IS_MAC:
            subprocess.run(["pbcopy"], input=text.encode(), check=True)
        elif IS_WIN:
            subprocess.run(["clip"], input=text.encode(), check=True)
        else:
            try:
                subprocess.run(["xclip", "-selection", "clipboard"],
                               input=text.encode(), check=True)
            except FileNotFoundError:
                subprocess.run(["xsel", "--clipboard", "--input"],
                               input=text.encode(), check=True)
        return True
    except Exception as exc:
        logger.warning("Clipboard copy failed: %s", exc)
        return False


def paste_from_clipboard() -> Optional[str]:
    """Read text from the system clipboard."""
    try:
        if IS_MAC:
            return subprocess.check_output(["pbpaste"]).decode("utf-8", errors="replace")
        elif IS_WIN:
            import ctypes
            CF_TEXT = 1
            ctypes.windll.user32.OpenClipboard(0)
            handle = ctypes.windll.user32.GetClipboardData(CF_TEXT)
            text = ctypes.c_char_p(handle).value
            ctypes.windll.user32.CloseClipboard()
            return text.decode("utf-8", errors="replace") if text else None
        else:
            try:
                return subprocess.check_output(
                    ["xclip", "-selection", "clipboard", "-o"]
                ).decode("utf-8", errors="replace")
            except FileNotFoundError:
                return subprocess.check_output(
                    ["xsel", "--clipboard", "--output"]
                ).decode("utf-8", errors="replace")
    except Exception as exc:
        logger.warning("Clipboard read failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Open URL / file in default app
# ---------------------------------------------------------------------------

def open_url(url: str):
    """Open a URL in the default browser."""
    import webbrowser
    webbrowser.open(url)


def open_file(path: str):
    """Open a file with the system's default application."""
    try:
        if IS_MAC:
            subprocess.run(["open", path], check=True)
        elif IS_WIN:
            os.startfile(path)
        else:
            subprocess.run(["xdg-open", path], check=True)
    except Exception as exc:
        logger.error("Failed to open file %s: %s", path, exc)


# ---------------------------------------------------------------------------
# System tray (optional)
# ---------------------------------------------------------------------------

def show_system_tray(icon_path: Optional[str], title: str, menu_items: dict):
    """
    Show a minimal system tray icon. Requires 'pystray' and 'Pillow'.
    menu_items: {label: callback_fn}
    Runs in a background thread.
    """
    try:
        from pystray import Icon, Menu, MenuItem  # type: ignore[import]
        from PIL import Image

        image = Image.open(icon_path) if icon_path and Path(icon_path).exists() else _default_icon()

        def make_item(label, fn):
            return MenuItem(label, fn)

        menu = Menu(*[make_item(lbl, fn) for lbl, fn in menu_items.items()])
        icon = Icon(title, image, title, menu)

        t = threading.Thread(target=icon.run, daemon=True)
        t.start()
        logger.info("System tray icon started.")
        return icon
    except ImportError:
        logger.warning("pystray/Pillow not installed; system tray unavailable.")
        return None


def _default_icon():
    """Generate a simple 64x64 placeholder icon."""
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (64, 64), color=(30, 30, 30))
    draw = ImageDraw.Draw(img)
    draw.ellipse([8, 8, 56, 56], fill=(0, 180, 120))
    return img


# ---------------------------------------------------------------------------
# Notification toast
# ---------------------------------------------------------------------------

def show_toast(title: str, message: str, duration: int = 5):
    """Show a desktop toast notification."""
    try:
        if IS_MAC:
            script = f'display notification "{message}" with title "{title}"'
            subprocess.run(["osascript", "-e", script], check=True)
        elif IS_WIN:
            try:
                from win10toast import ToastNotifier  # type: ignore[import]
                ToastNotifier().show_toast(title, message, duration=duration, threaded=True)
            except ImportError:
                # Use PowerShell fallback
                ps = (
                    f"[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] | Out-Null; "
                    f"$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02); "
                    f"$template.SelectSingleNode('//text[@id=1]').InnerText = '{title}'; "
                    f"$template.SelectSingleNode('//text[@id=2]').InnerText = '{message}'; "
                    f"[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('DevMindPro').Show([Windows.UI.Notifications.ToastNotification]::new($template))"
                )
                subprocess.run(["powershell", "-Command", ps], check=True)
        else:
            subprocess.run(
                ["notify-send", "-t", str(duration * 1000), title, message],
                check=True,
            )
    except Exception as exc:
        logger.warning("Toast notification failed: %s", exc)


# ---------------------------------------------------------------------------
# Process guard (single instance)
# ---------------------------------------------------------------------------

def ensure_single_instance(lock_file: Optional[str] = None) -> bool:
    """
    Ensure only one DevMind Pro instance runs.
    Returns True if this is the only instance, False if another is running.
    """
    lock_path = lock_file or str(get_cache_dir() / "devmind.lock")

    if IS_WIN:
        try:
            import msvcrt
            lf = open(lock_path, "w")
            msvcrt.locking(lf.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False
    else:
        import fcntl
        try:
            lf = open(lock_path, "w")
            fcntl.flock(lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
            # Keep file handle alive
            ensure_single_instance._lock_handle = lf
            return True
        except OSError:
            return False


# ---------------------------------------------------------------------------
# Environment summary
# ---------------------------------------------------------------------------

def get_platform_info() -> dict:
    """Return a dict of platform diagnostics for logging/debug."""
    return {
        "system": SYSTEM,
        "machine": platform.machine(),
        "python": sys.version,
        "app_data_dir": str(get_app_data_dir()),
        "cache_dir": str(get_cache_dir()),
        "log_dir": str(get_log_dir()),
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import pprint
    logging.basicConfig(level=logging.INFO)
    info = get_platform_info()
    print("\n=== DevMind Pro — Platform Info ===")
    pprint.pprint(info)
    print("\nClipboard test:")
    copy_to_clipboard("DevMind Pro clipboard test ✓")
    print("  Copied 'DevMind Pro clipboard test ✓' to clipboard.")
    show_toast("DevMind Pro", "Platform utils loaded successfully!")