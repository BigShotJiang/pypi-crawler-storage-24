"""
teams_sender.py — DevMind Pro
Sends messages to Teams contacts via deep links (no webhook/API needed).

How it works:
- Clicking "Send to Rajiv" opens Teams directly in a chat with Rajiv
- The suggested reply is copied to clipboard automatically
- You just press Ctrl+V and Enter in Teams

No Azure, no webhooks, no admin permissions needed.
Just add contact emails to TEAMS_CONTACTS in .env:

    TEAMS_CONTACTS=Rajiv:rajiv@company.com,Arif:arif@company.com
"""

import os
import re
import subprocess
import platform
import json
import requests
from datetime import datetime
from urllib.parse import quote


def _parse_contacts(contacts_env: str) -> dict[str, str]:
    """
    Parse TEAMS_CONTACTS env var.
    Supports both webhook URLs and email addresses.
    Format: "Name1:email_or_url1,Name2:email_or_url2"
    """
    contacts = {}
    if not contacts_env or not contacts_env.strip():
        return contacts
    for entry in contacts_env.split(","):
        entry = entry.strip()
        if ":" not in entry:
            continue
        name, _, value = entry.partition(":")
        name  = name.strip()
        value = value.strip()
        if name and value:
            contacts[name] = value
    return contacts


def load_contacts_from_env() -> dict[str, str]:
    raw = os.getenv("TEAMS_CONTACTS", "")
    contacts = _parse_contacts(raw)
    if contacts:
        print(f"[Teams] Loaded {len(contacts)} contact(s): {', '.join(contacts.keys())}")
    else:
        print("[Teams] No contacts configured. Add TEAMS_CONTACTS to your .env file.")
    return contacts


def _is_email(value: str) -> bool:
    return bool(re.match(r"[^@]+@[^@]+\.[^@]+", value))


def _is_webhook(value: str) -> bool:
    return value.startswith("http")


def _open_teams_chat(email: str, message: str = "") -> bool:
    """
    Open Teams directly to a chat with the given email.
    Copies message to clipboard so user can paste and send.
    """
    try:
        # Copy message to clipboard first
        if message:
            _copy_to_clipboard(message)

        # Teams deep link — opens chat with the person
        deep_link = f"msteams://teams.microsoft.com/l/chat/0/0?users={quote(email)}"

        system = platform.system()
        if system == "Darwin":
            subprocess.Popen(["open", deep_link])
        elif system == "Windows":
            subprocess.Popen(["cmd", "/c", "start", deep_link], shell=True)
        else:
            subprocess.Popen(["xdg-open", deep_link])

        print(f"[Teams] Opened chat with {email} — message copied to clipboard")
        # Show macOS notification so user knows to paste
        import subprocess as _sp
        _sp.run([
            "osascript", "-e",
            f'display notification "Message copied — press Cmd+V then Enter to send" with title "DevMind Pro" subtitle "Chat opened with {email}"'
        ])
        return True
    except Exception as e:
        print(f"[Teams] Error opening Teams: {e}")
        return False


def _send_webhook(webhook_url: str, message: str, title: str = "DevMind Alert") -> bool:
    """Send via webhook if URL is provided."""
    payload = {
        "type": "message",
        "attachments": [{
            "contentType": "application/vnd.microsoft.card.adaptive",
            "content": {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.4",
                "body": [
                    {"type": "TextBlock", "text": title,
                     "weight": "Bolder", "size": "Medium", "color": "Accent"},
                    {"type": "TextBlock", "text": message,
                     "wrap": True},
                    {"type": "TextBlock",
                     "text": datetime.now().strftime("%H:%M"),
                     "isSubtle": True, "size": "Small"},
                ],
            },
        }],
    }
    try:
        resp = requests.post(webhook_url, json=payload, timeout=10)
        ok = resp.status_code == 200
        if ok:
            print(f"[Teams] ✓ Sent via webhook")
        else:
            print(f"[Teams] ✗ Webhook failed ({resp.status_code})")
        return ok
    except Exception as e:
        print(f"[Teams] Webhook error: {e}")
        return False


def _copy_to_clipboard(text: str):
    """Copy text to system clipboard."""
    system = platform.system()
    try:
        if system == "Darwin":
            subprocess.run(["pbcopy"], input=text.encode(), check=True)
        elif system == "Windows":
            subprocess.run(["clip"], input=text.encode(), check=True)
        else:
            try:
                subprocess.run(["xclip", "-selection", "clipboard"],
                               input=text.encode(), check=True)
            except FileNotFoundError:
                subprocess.run(["xdotool", "type", text], check=True)
    except Exception as e:
        print(f"[Teams] Clipboard error: {e}")


class TeamsSender:
    def __init__(self, contacts: dict[str, str] = None):
        self.contacts = contacts or load_contacts_from_env()

    def get_contact_names(self) -> list[str]:
        return list(self.contacts.keys())

    def send_doubt(self, contact_name: str, doubt: str, why: str = "") -> bool:
        """Send a doubt to a contact — via webhook or deep link."""
        value = self.contacts.get(contact_name)
        if not value:
            print(f"[Teams] Contact '{contact_name}' not found.")
            return False

        message = doubt
        if why:
            message += f"\n\nContext: {why}"

        if _is_webhook(value):
            return _send_webhook(value, message, title="📋 Meeting Doubt")
        elif _is_email(value):
            return _open_teams_chat(value, message)
        else:
            print(f"[Teams] Unknown contact format for {contact_name}: {value}")
            return False

    def send_reply(self, contact_name: str, message: str) -> bool:
        """Send a suggested reply to a contact."""
        value = self.contacts.get(contact_name)
        if not value:
            return False

        if _is_webhook(value):
            return _send_webhook(value, message, title="💬 Suggested Reply")
        elif _is_email(value):
            return _open_teams_chat(value, message)
        return False

    def send_simple_message(self, contact_name: str, message: str) -> bool:
        """Send a plain message."""
        return self.send_reply(contact_name, message)


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    sender = TeamsSender()
    print("Contacts:", sender.get_contact_names())