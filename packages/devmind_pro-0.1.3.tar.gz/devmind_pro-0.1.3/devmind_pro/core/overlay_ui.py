"""
overlay_ui.py  -  DevMind Pro floating window.

Tabs:
  1. Transcript     - live scrolling with speaker labels
  2. Doubts         - AI gaps + contradiction alerts
  3. Reply          - suggested replies
  4. Commitments    - tracked promises
  5. Briefing       - pre-meeting prep
"""

import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

C = {
    "bg":           "#0f0f1a",
    "panel":        "#1a1a2e",
    "card":         "#1e1e35",
    "accent":       "#6c63ff",
    "accent2":      "#00d4aa",
    "text":         "#e8e8f0",
    "text2":        "#a0a0c0",
    "text3":        "#606080",
    "high":         "#ff5f7e",
    "medium":       "#ffbe76",
    "low":          "#6bcb77",
    "contra":       "#ff4757",
    "commit":       "#00d4aa",
    "border":       "#2a2a4a",
    "btn":          "#252545",
    "btn_hover":    "#353565",
    "send":         "#1a6b4a",
    "send_hover":   "#2a8b5a",
}

PRIORITY_COLOUR = {
    "high":   C["high"],
    "medium": C["medium"],
    "low":    C["low"],
}


class OverlayUI:
    def __init__(self, teams_sender=None):
        self._sender = teams_sender
        self._event_queue = queue.Queue()
        self._build_window()

    def _build_window(self):
        self.root = tk.Tk()
        self.root.title("DevMind Pro")
        self.root.geometry("520x860")
        self.root.configure(bg=C["bg"])
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", 0.97)
        self.root.resizable(True, True)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Dark.Vertical.TScrollbar",
            background=C["panel"], troughcolor=C["bg"],
            bordercolor=C["bg"], arrowcolor=C["text3"],
            relief="flat", borderwidth=0)

        tk.Frame(self.root, bg=C["accent"], height=3).pack(fill="x")

        header = tk.Frame(self.root, bg=C["bg"], pady=10)
        header.pack(fill="x", padx=16)

        title_frame = tk.Frame(header, bg=C["bg"])
        title_frame.pack(side="left")
        tk.Label(title_frame, text="DevMind",
            font=("SF Pro Display", 15, "bold"),
            fg=C["text"], bg=C["bg"]).pack(side="left")
        tk.Label(title_frame, text=" Pro",
            font=("SF Pro Display", 15, "bold"),
            fg=C["accent"], bg=C["bg"]).pack(side="left")

        status_frame = tk.Frame(header, bg=C["bg"])
        status_frame.pack(side="right")
        self._status_dot = tk.Label(status_frame, text="●",
            font=("SF Pro Display", 10), fg=C["low"], bg=C["bg"])
        self._status_dot.pack(side="left")
        self._status_label = tk.Label(status_frame, text=" idle",
            font=("SF Pro Display", 9), fg=C["text2"], bg=C["bg"])
        self._status_label.pack(side="left")

        tk.Frame(self.root, bg=C["border"], height=1).pack(fill="x")

        self._tab_bar = tk.Frame(self.root, bg=C["bg"], pady=6)
        self._tab_bar.pack(fill="x", padx=12)

        self._tab_btns = {}
        self._current_tab = 0
        tab_names = [
            ("Transcript", "📝"),
            ("Doubts", "💡"),
            ("Reply", "💬"),
            ("Commitments", "📌"),
            ("Briefing", "🎯"),
        ]
        for i, (name, icon) in enumerate(tab_names):
            btn = tk.Label(self._tab_bar,
                text=f"{icon} {name}",
                font=("SF Pro Display", 9),
                fg=C["text2"], bg=C["btn"],
                padx=12, pady=5, cursor="hand2", relief="flat")
            btn.pack(side="left", padx=(0, 4))
            btn.bind("<Button-1>", lambda e, idx=i: self._switch_tab(idx))
            btn.bind("<Enter>", lambda e, b=btn, idx=i: b.configure(
                bg=C["btn_hover"]) if idx != self._current_tab else None)
            btn.bind("<Leave>", lambda e, b=btn, idx=i: b.configure(
                bg=C["accent"] if idx == self._current_tab else C["btn"]))
            self._tab_btns[i] = btn

        self._content = tk.Frame(self.root, bg=C["bg"])
        self._content.pack(fill="both", expand=True, padx=8, pady=(4, 8))

        self._tab_frames = {}
        self._build_transcript_tab()
        self._build_doubts_tab()
        self._build_reply_tab()
        self._build_commitments_tab()
        self._build_briefing_tab()
        self._switch_tab(0)

        self.root.after(100, self._process_events)

    def _switch_tab(self, idx: int):
        for frame in self._tab_frames.values():
            frame.pack_forget()
        for i, btn in self._tab_btns.items():
            btn.configure(bg=C["accent"] if i == idx else C["btn"],
                          fg=C["text"] if i == idx else C["text2"])
        self._tab_frames[idx].pack(fill="both", expand=True)
        self._current_tab = idx

    def _build_transcript_tab(self):
        frame = tk.Frame(self._content, bg=C["bg"])
        self._tab_frames[0] = frame

        toolbar = tk.Frame(frame, bg=C["bg"], pady=4)
        toolbar.pack(fill="x")
        self._make_pill_btn(toolbar, "What did I miss?",
            self._ask_what_missed, C["accent"]).pack(side="left", padx=(0, 6))
        self._make_pill_btn(toolbar, "Clear",
            self._clear_transcript, C["btn"], small=True).pack(side="right")

        self._transcript_box = tk.Text(frame, wrap=tk.WORD,
            font=("SF Mono", 10), bg=C["panel"], fg=C["text"],
            insertbackground=C["text"], relief="flat", borderwidth=0,
            padx=12, pady=10, selectbackground=C["accent"])
        scroll = ttk.Scrollbar(frame, style="Dark.Vertical.TScrollbar",
            command=self._transcript_box.yview)
        self._transcript_box.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self._transcript_box.pack(fill="both", expand=True)
        self._transcript_box.configure(state="disabled")
        self._transcript_box.tag_config("speaker", foreground=C["accent2"])
        self._transcript_box.tag_config("time", foreground=C["text3"])
        self._transcript_box.tag_config("text", foreground=C["text"])

    def _build_doubts_tab(self):
        frame = tk.Frame(self._content, bg=C["bg"])
        self._tab_frames[1] = frame

        tk.Label(frame,
            text="AI-detected gaps, questions and contradictions",
            font=("SF Pro Display", 9), fg=C["text3"],
            bg=C["bg"]).pack(anchor="w", pady=(4, 6))

        container = tk.Frame(frame, bg=C["bg"])
        container.pack(fill="both", expand=True)
        canvas = tk.Canvas(container, bg=C["bg"], highlightthickness=0)
        scroll = ttk.Scrollbar(container, style="Dark.Vertical.TScrollbar",
            command=canvas.yview)
        self._doubts_inner = tk.Frame(canvas, bg=C["bg"])
        self._doubts_inner.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self._doubts_inner,
            anchor="nw", width=480)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True)

        self._no_doubts_lbl = tk.Label(self._doubts_inner,
            text="Listening for gaps and contradictions...",
            font=("SF Pro Display", 10), fg=C["text3"],
            bg=C["bg"], justify="center")
        self._no_doubts_lbl.pack(pady=50)

    def _build_reply_tab(self):
        frame = tk.Frame(self._content, bg=C["bg"])
        self._tab_frames[2] = frame

        tk.Label(frame, text="QUESTION ASKED",
            font=("SF Pro Display", 8), fg=C["text3"],
            bg=C["bg"]).pack(anchor="w", pady=(4, 3))
        self._question_box = tk.Text(frame, wrap=tk.WORD, height=3,
            font=("SF Pro Display", 10), bg=C["panel"], fg=C["accent2"],
            relief="flat", borderwidth=0, padx=10, pady=8,
            insertbackground=C["text"])
        self._question_box.pack(fill="x")
        self._question_box.configure(state="disabled")

        tk.Frame(frame, bg=C["border"], height=1).pack(fill="x", pady=8)

        tk.Label(frame, text="SUGGESTED REPLY",
            font=("SF Pro Display", 8), fg=C["text3"],
            bg=C["bg"]).pack(anchor="w", pady=(0, 3))
        self._reply_box = tk.Text(frame, wrap=tk.WORD,
            font=("SF Pro Display", 11), bg=C["panel"], fg=C["text"],
            relief="flat", borderwidth=0, padx=12, pady=10,
            insertbackground=C["text"], selectbackground=C["accent"])
        scroll_r = ttk.Scrollbar(frame, style="Dark.Vertical.TScrollbar",
            command=self._reply_box.yview)
        self._reply_box.configure(yscrollcommand=scroll_r.set)
        scroll_r.pack(side="right", fill="y")
        self._reply_box.pack(fill="both", expand=True)
        self._reply_box.configure(state="disabled")

        self._reply_meta = tk.Label(frame, text="",
            font=("SF Pro Display", 9), fg=C["text3"], bg=C["bg"])
        self._reply_meta.pack(anchor="w", pady=(6, 4))

        btn_row = tk.Frame(frame, bg=C["bg"])
        btn_row.pack(fill="x", pady=(0, 4))
        self._make_pill_btn(btn_row, "Copy reply",
            self._copy_reply, C["accent"]).pack(side="left", padx=(0, 8))
        self._make_pill_btn(btn_row, "Ask AI manually",
            self._ask_ai_manually, C["btn"]).pack(side="left")

    def _build_commitments_tab(self):
        frame = tk.Frame(self._content, bg=C["bg"])
        self._tab_frames[3] = frame

        tk.Label(frame,
            text="Promises: \"I will...\", \"We need to...\", \"By Friday...\"",
            font=("SF Pro Display", 9), fg=C["text3"],
            bg=C["bg"]).pack(anchor="w", pady=(4, 6))

        container = tk.Frame(frame, bg=C["bg"])
        container.pack(fill="both", expand=True)
        canvas = tk.Canvas(container, bg=C["bg"], highlightthickness=0)
        scroll = ttk.Scrollbar(container, style="Dark.Vertical.TScrollbar",
            command=canvas.yview)
        self._commit_inner = tk.Frame(canvas, bg=C["bg"])
        self._commit_inner.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self._commit_inner,
            anchor="nw", width=480)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True)

        tk.Label(self._commit_inner,
            text="Listening for commitments...",
            font=("SF Pro Display", 10), fg=C["text3"],
            bg=C["bg"], justify="center").pack(pady=50)

    def _build_briefing_tab(self):
        frame = tk.Frame(self._content, bg=C["bg"])
        self._tab_frames[4] = frame

        tk.Label(frame,
            text="Pre-meeting AI briefing from past summaries + docs",
            font=("SF Pro Display", 9), fg=C["text3"],
            bg=C["bg"]).pack(anchor="w", pady=(4, 6))

        self._briefing_box = tk.Text(frame, wrap=tk.WORD,
            font=("SF Pro Display", 10), bg=C["panel"], fg=C["text"],
            relief="flat", borderwidth=0, padx=12, pady=10,
            insertbackground=C["text"])
        scroll_b = ttk.Scrollbar(frame, style="Dark.Vertical.TScrollbar",
            command=self._briefing_box.yview)
        self._briefing_box.configure(yscrollcommand=scroll_b.set)
        scroll_b.pack(side="right", fill="y")
        self._briefing_box.pack(fill="both", expand=True)
        self._briefing_box.configure(state="disabled")

        btn_row = tk.Frame(frame, bg=C["bg"], pady=8)
        btn_row.pack(fill="x")
        self._make_pill_btn(btn_row, "Generate briefing",
            self._generate_briefing, C["accent"]).pack(side="left", padx=(0, 8))
        self._topic_entry = tk.Entry(btn_row,
            bg=C["panel"], fg=C["text2"],
            font=("SF Pro Display", 10), relief="flat",
            insertbackground=C["text"], width=22)
        self._topic_entry.insert(0, "meeting topic (optional)")
        self._topic_entry.pack(side="left", ipady=5)
        self._topic_entry.bind("<FocusIn>", lambda e: (
            self._topic_entry.delete(0, "end")
            if self._topic_entry.get() == "meeting topic (optional)" else None))

    def _make_pill_btn(self, parent, text, cmd, bg=None, small=False):
        bg = bg or C["btn"]
        btn = tk.Label(parent, text=text,
            font=("SF Pro Display", 9 if small else 10),
            fg=C["text"], bg=bg, padx=14, pady=6,
            cursor="hand2", relief="flat")
        btn.bind("<Button-1>", lambda e: cmd())
        btn.bind("<Enter>", lambda e: btn.configure(bg=C["btn_hover"]))
        btn.bind("<Leave>", lambda e: btn.configure(bg=bg))
        return btn

    def _make_send_btn(self, parent, text, cmd):
        btn = tk.Label(parent, text=text,
            font=("SF Pro Display", 9), fg=C["text"],
            bg=C["send"], padx=10, pady=4,
            cursor="hand2", relief="flat")
        btn.pack(side="left", padx=(0, 4))
        btn.bind("<Button-1>", lambda e: cmd())
        btn.bind("<Enter>", lambda e: btn.configure(bg=C["send_hover"]))
        btn.bind("<Leave>", lambda e: btn.configure(bg=C["send"]))
        return btn

    def _process_events(self):
        try:
            while True:
                event, data = self._event_queue.get_nowait()
                if event == "transcript":   self._append_transcript(data)
                elif event == "doubts":     self._show_doubts(data)
                elif event == "reply":      self._show_reply(data)
                elif event == "status":     self._set_status(data)
                elif event == "commitment": self._add_commitment_card(data)
                elif event == "briefing":   self._show_briefing(data)
        except queue.Empty:
            pass
        self.root.after(100, self._process_events)

    def add_transcript(self, text):
        self._event_queue.put(("transcript", text))

    def show_doubts(self, doubts):
        self._event_queue.put(("doubts", doubts))

    def show_reply(self, question, reply_data):
        self._event_queue.put(("reply", {"question": question, "data": reply_data}))

    def set_status(self, text, colour=None):
        self._event_queue.put(("status", {"text": text, "colour": colour}))

    def add_commitment(self, data):
        self._event_queue.put(("commitment", data))

    def show_briefing(self, text):
        self._event_queue.put(("briefing", text))

    def set_manual_question_handler(self, handler):
        self._on_manual_question = handler

    def set_briefing_handler(self, handler):
        self._on_generate_briefing = handler

    def set_what_missed_handler(self, handler):
        self._on_what_missed = handler

    def _append_transcript(self, text):
        self._transcript_box.configure(state="normal")
        ts = datetime.now().strftime("%H:%M")
        import re
        m = re.match(r"\[(Speaker \d+)\]\s*(.*)", text, re.DOTALL)
        if m:
            speaker, content = m.group(1), m.group(2)
            self._transcript_box.insert("end", f"[{ts}] ", "time")
            self._transcript_box.insert("end", f"{speaker}: ", "speaker")
            self._transcript_box.insert("end", f"{content}\n", "text")
        else:
            self._transcript_box.insert("end", f"[{ts}] {text}\n", "text")
        self._transcript_box.see("end")
        self._transcript_box.configure(state="disabled")

    def _show_doubts(self, doubts):
        for w in self._doubts_inner.winfo_children():
            w.destroy()
        if not doubts:
            tk.Label(self._doubts_inner,
                text="No gaps detected in this segment",
                font=("SF Pro Display", 10),
                fg=C["low"], bg=C["bg"]).pack(pady=20)
            return
        self._switch_tab(1)
        for doubt in doubts:
            self._add_doubt_card(doubt)

    def _add_doubt_card(self, doubt):
        priority = doubt.get("priority", "medium")
        is_contra = "Contradiction" in doubt.get("doubt", "")
        accent = C["contra"] if is_contra else PRIORITY_COLOUR.get(priority, C["medium"])

        card = tk.Frame(self._doubts_inner, bg=C["card"])
        card.pack(fill="x", pady=(0, 8))
        tk.Frame(card, bg=accent, width=3).pack(side="left", fill="y")

        inner = tk.Frame(card, bg=C["card"], padx=12, pady=10)
        inner.pack(side="left", fill="both", expand=True)

        badge_text = "CONTRADICTION" if is_contra else priority.upper()
        tk.Label(inner, text=f" {badge_text} ",
            font=("SF Pro Display", 8, "bold"),
            fg=accent, bg=C["card"]).pack(anchor="w")

        tk.Label(inner, text=doubt.get("doubt", ""),
            font=("SF Pro Display", 11, "bold"),
            fg=C["text"], bg=C["card"],
            wraplength=420, justify="left").pack(anchor="w", pady=(6, 2))

        if doubt.get("why"):
            tk.Label(inner, text=doubt["why"],
                font=("SF Pro Display", 9),
                fg=C["text2"], bg=C["card"],
                wraplength=420, justify="left").pack(anchor="w")

        btn_row = tk.Frame(inner, bg=C["card"])
        btn_row.pack(anchor="w", pady=(8, 0))
        contacts = self._sender.get_contact_names() if self._sender else []
        if contacts:
            tk.Label(btn_row, text="Send →",
                font=("SF Pro Display", 9),
                fg=C["text3"], bg=C["card"]).pack(side="left", padx=(0, 6))
            for contact in contacts:
                self._make_send_btn(btn_row, contact,
                    lambda c=contact, d=doubt: self._send_doubt_to_teams(c, d))
        else:
            tk.Label(btn_row,
                text="Add TEAMS_CONTACTS in .env to send",
                font=("SF Pro Display", 8),
                fg=C["text3"], bg=C["card"]).pack(side="left")

    def _show_reply(self, payload):
        question = payload["question"]
        data     = payload["data"]

        self._question_box.configure(state="normal")
        self._question_box.delete("1.0", "end")
        self._question_box.insert("end", question)
        self._question_box.configure(state="disabled")

        self._reply_box.configure(state="normal")
        self._reply_box.delete("1.0", "end")
        self._reply_box.insert("end", data.get("reply", ""))
        self._reply_box.configure(state="disabled")

        conf = data.get("confidence", "?")
        src  = data.get("source", "?")
        conf_col = {"high": C["low"], "medium": C["medium"],
                    "low": C["high"]}.get(conf, C["text3"])
        self._reply_meta.configure(
            text=f"Confidence: {conf}   ·   Source: {src}",
            fg=conf_col)
        self._switch_tab(2)

    def _add_commitment_card(self, data):
        for w in self._commit_inner.winfo_children():
            if isinstance(w, tk.Label) and "Listening" in str(w.cget("text")):
                w.destroy()

        card = tk.Frame(self._commit_inner, bg=C["card"])
        card.pack(fill="x", pady=(0, 6))
        tk.Frame(card, bg=C["commit"], width=3).pack(side="left", fill="y")

        inner = tk.Frame(card, bg=C["card"], padx=12, pady=8)
        inner.pack(side="left", fill="both", expand=True)

        meta = tk.Frame(inner, bg=C["card"])
        meta.pack(fill="x")
        tk.Label(meta, text=f"{data.get('speaker','?')}",
            font=("SF Pro Display", 9, "bold"),
            fg=C["accent2"], bg=C["card"]).pack(side="left")
        tk.Label(meta, text=f"  {data.get('time','')}",
            font=("SF Pro Display", 8),
            fg=C["text3"], bg=C["card"]).pack(side="left")

        tk.Label(inner, text=data.get("text", ""),
            font=("SF Pro Display", 10),
            fg=C["text"], bg=C["card"],
            wraplength=420, justify="left").pack(anchor="w", pady=(4, 0))

    def _show_briefing(self, text):
        self._briefing_box.configure(state="normal")
        self._briefing_box.delete("1.0", "end")
        self._briefing_box.insert("end", text)
        self._briefing_box.configure(state="disabled")
        self._switch_tab(4)

    def _set_status(self, data):
        text   = data.get("text", "")
        colour = data.get("colour") or C["text2"]
        dot_col = C["low"]
        if any(w in text for w in ["analysing", "thinking", "generating", "summarising"]):
            dot_col = C["accent"]
        elif any(w in text for w in ["error", "failed", "Contradiction"]):
            dot_col = C["high"]
        elif any(w in text for w in ["Teams", "keyword", "Commitment"]):
            dot_col = C["medium"]
        self._status_dot.configure(fg=dot_col)
        self._status_label.configure(text=f" {text}", fg=colour)

    def _clear_transcript(self):
        self._transcript_box.configure(state="normal")
        self._transcript_box.delete("1.0", "end")
        self._transcript_box.configure(state="disabled")

    def _copy_reply(self):
        reply = self._reply_box.get("1.0", "end").strip()
        if reply:
            self.root.clipboard_clear()
            self.root.clipboard_append(reply)
            self.set_status("Copied to clipboard", C["low"])

    def _ask_what_missed(self):
        if hasattr(self, "_on_what_missed"):
            self._on_what_missed()

    def _generate_briefing(self):
        topic = self._topic_entry.get().strip()
        if topic == "meeting topic (optional)":
            topic = ""
        if hasattr(self, "_on_generate_briefing"):
            self._on_generate_briefing(topic)

    def _ask_ai_manually(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Ask AI")
        dialog.geometry("440x160")
        dialog.configure(bg=C["bg"])
        dialog.attributes("-topmost", True)

        tk.Label(dialog, text="Type your question:",
            fg=C["text2"], bg=C["bg"],
            font=("SF Pro Display", 11)).pack(padx=16, pady=(16, 6), anchor="w")

        entry = tk.Entry(dialog, bg=C["panel"], fg=C["text"],
            font=("SF Pro Display", 11), relief="flat",
            insertbackground=C["text"])
        entry.pack(fill="x", padx=16, pady=4, ipady=6)
        entry.focus()

        def submit():
            q = entry.get().strip()
            if q and hasattr(self, "_on_manual_question"):
                self._on_manual_question(q)
            dialog.destroy()

        entry.bind("<Return>", lambda e: submit())
        self._make_pill_btn(dialog, "Ask", submit, C["accent"]).pack(pady=8)

    def _send_doubt_to_teams(self, contact, doubt):
        if not self._sender:
            messagebox.showwarning("Teams", "Teams sender not configured.")
            return
        success = self._sender.send_doubt(
            contact, doubt.get("doubt", ""), doubt.get("why", ""))
        self.set_status(
            f"Sent to {contact}" if success else f"Failed to send to {contact}",
            C["low"] if success else C["high"])

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    ui = OverlayUI(teams_sender=None)

    def demo():
        time.sleep(1)
        ui.add_transcript("[Speaker 1] We need to deploy the API by Friday.")
        time.sleep(1)
        ui.show_doubts([{
            "doubt": "Contradiction: Deploy on Friday",
            "why": "Docs say: Friday deployments are blocked",
            "priority": "high"}])
        time.sleep(1)
        ui.add_commitment({"speaker": "Speaker 1", "time": "14:32",
            "text": "I will send the API docs by tomorrow"})
        time.sleep(1)
        ui.show_reply("Can you handle the auth module?",
            {"reply": "Yes, auth uses JWT as defined in auth_service.py.",
             "confidence": "high", "source": "auth_service.py"})

    threading.Thread(target=demo, daemon=True).start()
    ui.run()