"""
main.py  -  DevMind Pro orchestrator
"""

import os
import sys
import threading
import time
from pathlib import Path
from dotenv import load_dotenv

_CORE = Path(__file__).parent
if str(_CORE) not in sys.path:
    sys.path.insert(0, str(_CORE))

load_dotenv()

WHISPER_MODEL     = os.getenv("WHISPER_MODEL", "small")
DOCS_FOLDER       = os.getenv("DOCS_FOLDER", "./docs")
CODEBASE_FOLDER   = os.getenv("CODEBASE_FOLDER", "./docs")
ANALYSIS_INTERVAL = int(os.getenv("ANALYSIS_INTERVAL", "60"))
AUDIO_DEVICE      = os.getenv("AUDIO_DEVICE", "")
MY_NAME           = os.getenv("MY_NAME", "")


class MeetingAssistant:
    def __init__(self):
        print("\n" + "="*55)
        print("  DevMind Pro  -  Starting up")
        print("="*55)

        from rag_engine             import RAGEngine
        from codebase_rag           import CodebaseRAG
        from ai_engine              import AIEngine, AI_PROVIDER, AI_MODEL
        from teams_sender           import TeamsSender
        from overlay_ui             import OverlayUI
        from transcriber            import Transcriber
        from notification_watcher   import NotificationWatcher
        from meeting_summary        import MeetingSummary
        from keyword_alerts         import KeywordAlerter
        from commitment_tracker     import CommitmentTracker
        from contradiction_detector import ContradictionDetector
        from followup_email         import FollowupEmailGenerator

        print("\n[1/9] Loading project documents...")
        self._rag = RAGEngine(docs_folder=DOCS_FOLDER)
        self._rag.ingest_docs()

        print("\n[2/9] Indexing codebase...")
        self._code_rag = CodebaseRAG(codebase_path=CODEBASE_FOLDER)
        self._code_rag.ingest_codebase()

        print("\n[3/9] Initialising AI engine...")
        self._ai = AIEngine(rag_engine=self._rag, codebase_rag=self._code_rag)

        print("\n[4/9] Loading Teams contacts...")
        self._teams = TeamsSender()

        print("\n[5/9] Building overlay UI...")
        self._ui = OverlayUI(teams_sender=self._teams)
        self._ui.set_manual_question_handler(self._on_manual_question)
        self._ui.set_briefing_handler(self._on_generate_briefing)
        self._ui.set_what_missed_handler(self._on_what_missed)

        print("\n[6/9] Loading Whisper model...")
        self._transcriber = Transcriber(
            model_size=WHISPER_MODEL,
            device_name=AUDIO_DEVICE,
            on_transcript=self._on_new_transcript,
        )

        print("\n[7/9] Setting up Teams notification watcher...")
        self._notif_watcher = NotificationWatcher(
            on_message=self._on_teams_message,
            ai_engine=self._ai,
            get_transcript=self._transcriber.get_full_transcript,
            poll_interval=2,
        )

        print("\n[8/9] Setting up trackers...")
        self._summary     = MeetingSummary(ai_engine=self._ai)
        self._alerter     = KeywordAlerter(my_name=MY_NAME, on_alert=self._on_keyword_alert)
        self._commitments = CommitmentTracker(on_commitment=self._on_commitment)
        self._contra      = ContradictionDetector(
            rag_engine=self._rag,
            on_contradiction=self._on_contradiction,
        )

        print("\n[9/9] Setting up follow-up email generator...")
        self._email_gen = FollowupEmailGenerator()

        self._last_analysis_time = 0

        print("\n" + "="*55)
        print(f"  + Docs:          {len(self._rag.get_all_doc_names())} file(s)")
        print(f"  + Codebase:      {self._code_rag.get_stats()['total_chunks']} chunks")
        print(f"  + AI:            {AI_PROVIDER.upper()} / {AI_MODEL}")
        print(f"  + Whisper:       {WHISPER_MODEL}")
        print(f"  + Teams watcher: active")
        print("="*55 + "\n")

    def _on_new_transcript(self, text: str):
        self._ui.add_transcript(text)
        self._ui.set_status("listening", "#5bc4a8")
        self._summary.add_transcript(text)
        self._alerter.check_transcript(text)
        self._commitments.check_transcript(text)
        self._contra.add_transcript(text)
        threading.Thread(target=self._check_for_question, args=(text,), daemon=True).start()
        now = time.time()
        if now - self._last_analysis_time >= ANALYSIS_INTERVAL:
            self._last_analysis_time = now
            threading.Thread(target=self._run_gap_analysis, daemon=True).start()

    def _on_teams_message(self, data: dict):
        sender  = data["sender"]
        message = data["message"]
        reply   = data["reply_data"]
        from keyword_alerts import _is_greeting
        if _is_greeting(message):
            self._ui.show_reply(
                f"[Teams] {sender}: {message}",
                {"reply": "Greeting — reply manually!", "confidence": "high", "source": "greeting filter"},
            )
            return
        self._ui.show_reply(f"[Teams] {sender}: {message}", reply)
        self._ui.set_status(f"Teams message from {sender}", "#fdd663")

    def _on_keyword_alert(self, data: dict):
        if data.get("is_greeting"):
            return
        self._ui.set_status(f"Keyword: '{data['keyword']}' in {data['source']}", "#fdd663")

    def _on_commitment(self, data: dict):
        print(f"[Main] Commitment: {data['speaker']}: {data['text']}")
        self._ui.add_commitment(data)
        self._ui.set_status(f"Commitment: {data['text'][:40]}", "#5bc4a8")

    def _on_contradiction(self, data: dict):
        print(f"[Main] Contradiction: {data['claim']}")
        self._ui.show_doubts([{
            "doubt": f"Contradiction: {data['claim']}",
            "why": f"Docs say: {data['contradiction']} (Source: {data.get('source','')})",
            "priority": "high",
        }])
        self._ui.set_status("Contradiction detected!", "#E24B4A")

    def _check_for_question(self, chunk: str):
        detected = self._ai.detect_question_directed_at_me(chunk, my_name=MY_NAME)
        if detected:
            question = detected.get("question", chunk)
            reply_data = self._ai.suggest_reply(
                question_asked=question,
                full_transcript=self._transcriber.get_full_transcript(),
            )
            self._ui.show_reply(question, reply_data)
            self._ui.set_status("Someone asked you something", "#fdd663")

    def _run_gap_analysis(self):
        recent = self._transcriber.get_recent_transcript(last_n_chunks=8)
        full   = self._transcriber.get_full_transcript()
        if len(recent) < 50:
            return
        self._ui.set_status("analysing...", "#7c6af5")
        doubts = self._ai.analyse_transcript(transcript=full, recent_only=recent)
        for d in doubts:
            self._summary.add_doubt(d)
        self._ui.show_doubts(doubts)
        self._ui.set_status("listening", "#5bc4a8")

    def _on_what_missed(self):
        self._ui.set_status("summarising last few minutes...", "#7c6af5")
        def _run():
            recent = self._transcriber.get_recent_transcript(last_n_chunks=12)
            summary = self._ai.what_did_i_miss(recent)
            self._ui.show_reply("What did I miss?", {
                "reply": summary,
                "confidence": "high",
                "source": "last 5 minutes",
            })
            self._ui.set_status("listening", "#5bc4a8")
        threading.Thread(target=_run, daemon=True).start()

    def _on_generate_briefing(self, topic_hint: str = ""):
        self._ui.set_status("generating briefing...", "#7c6af5")
        def _run():
            from pre_meeting_predictor import PreMeetingPredictor
            predictor = PreMeetingPredictor(
                rag_engine=self._rag,
                summaries_folder="./summaries",
            )
            briefing = predictor.generate_briefing(topic_hint=topic_hint)
            predictor.save_briefing(briefing)
            lines = []
            likely = briefing.get("likely_questions", [])
            if likely:
                lines.append("LIKELY QUESTIONS:")
                for q in likely:
                    lines.append(f"  Q: {q}")
                lines.append("")
            unresolved = briefing.get("unresolved_from_last", [])
            if unresolved:
                lines.append("UNRESOLVED FROM LAST MEETING:")
                for u in unresolved:
                    lines.append(f"  - {u}")
                lines.append("")
            prepare = briefing.get("prepare_to_explain", [])
            if prepare:
                lines.append("BE PREPARED TO EXPLAIN:")
                for p in prepare:
                    lines.append(f"  - {p}")
            text = "\n".join(lines) if lines else briefing.get("raw_briefing", "No briefing generated.")
            self._ui.show_briefing(text)
            self._ui.set_status("briefing ready", "#5bc4a8")
        threading.Thread(target=_run, daemon=True).start()

    def _on_manual_question(self, question: str):
        if "miss" in question.lower():
            self._on_what_missed()
            return
        self._ui.set_status("thinking...", "#7c6af5")
        def _run():
            reply_data = self._ai.suggest_reply(
                question_asked=question,
                full_transcript=self._transcriber.get_full_transcript(),
            )
            self._ui.show_reply(question, reply_data)
            self._ui.set_status("listening", "#5bc4a8")
        threading.Thread(target=_run, daemon=True).start()

    def run(self):
        self._transcriber.start()
        self._notif_watcher.start()
        self._summary.start_auto_save()
        self._ui.set_status("listening", "#5bc4a8")
        print("DevMind Pro is running!")
        print("Tip: Click 'What did I miss?' to catch up anytime\n")
        self._ui.run()
        self._transcriber.stop()
        self._notif_watcher.stop()
        self._summary.stop()
        print("\nSaving meeting summary...")
        self._summary.generate_and_save()
        print("Generating follow-up email...")
        self._email_gen.save_and_copy(
            transcript=self._transcriber.get_full_transcript(),
            commitments=self._commitments.get_all(),
            doubts=[],
        )
        print("\nAll commitments this meeting:")
        print(self._commitments.get_formatted())
        print("\nDevMind Pro stopped.")


if __name__ == "__main__":
    assistant = MeetingAssistant()
    assistant.run()