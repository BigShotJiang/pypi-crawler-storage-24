"""
rag_engine.py  —  DevMind Pro
Local vector store using LanceDB (no ChromaDB, no telemetry conflicts).
Drop-in replacement: identical public API to the ChromaDB version.
"""

import os
import hashlib
import json
from pathlib import Path

# ── File readers ─────────────────────────────────────────────────────────────

def _read_pdf(path: str) -> str:
    try:
        import PyPDF2
        text = []
        with open(path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                t = page.extract_text()
                if t:
                    text.append(t)
        return "\n".join(text)
    except Exception as e:
        print(f"[RAG] Could not read PDF {path}: {e}")
        return ""

def _read_docx(path: str) -> str:
    try:
        from docx import Document
        doc = Document(path)
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    except Exception as e:
        print(f"[RAG] Could not read DOCX {path}: {e}")
        return ""

def _read_text(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        print(f"[RAG] Could not read file {path}: {e}")
        return ""

READERS = {
    ".pdf":      _read_pdf,
    ".docx":     _read_docx,
    ".doc":      _read_docx,
    ".txt":      _read_text,
    ".md":       _read_text,
    ".markdown": _read_text,
}

# ── Chunking ──────────────────────────────────────────────────────────────────

def _chunk_text(text: str, chunk_size: int = 500, overlap: int = 80) -> list:
    words = text.split()
    chunks, i = [], 0
    while i < len(words):
        chunks.append(" ".join(words[i: i + chunk_size]))
        i += chunk_size - overlap
    return [c for c in chunks if len(c.strip()) > 50]

# ── Embedding ─────────────────────────────────────────────────────────────────

_embedder = None

def _get_embedder():
    global _embedder
    if _embedder is None:
        from sentence_transformers import SentenceTransformer
        # Explicitly set device=cpu — prevents meta tensor error on Apple Silicon
        # when sentence-transformers tries to auto-detect MPS and fails
        _embedder = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
    return _embedder

def _embed(texts: list) -> list:
    return _get_embedder().encode(texts, show_progress_bar=False).tolist()

# ── RAG Engine ────────────────────────────────────────────────────────────────

class RAGEngine:
    """
    LanceDB-backed RAG engine. Same public API as the ChromaDB version —
    main.py, codebase_rag.py, and ai_engine.py need zero changes.
    """

    def __init__(self, docs_folder: str = "./docs", db_path: str = "./lance_db"):
        self.docs_folder = Path(docs_folder)
        self.db_path     = db_path
        self._index_file = Path(db_path) / "_indexed.json"

        print("[RAG] Initialising local vector store...")

        import lancedb
        Path(db_path).mkdir(parents=True, exist_ok=True)
        self._db    = lancedb.connect(db_path)
        self._table = None

        if "project_docs" in self._db.table_names():
            self._table = self._db.open_table("project_docs")

        self._indexed: dict = {}
        if self._index_file.exists():
            self._indexed = json.loads(self._index_file.read_text())

        print("[RAG] Ready.")

    # ── Ingestion ─────────────────────────────────────────────────────────────

    def ingest_docs(self):
        if not self.docs_folder.exists():
            print(f"[RAG] Docs folder not found: {self.docs_folder}. Creating it.")
            self.docs_folder.mkdir(parents=True)
            return

        files = [
            f for f in self.docs_folder.rglob("*")
            if f.suffix.lower() in READERS and f.is_file()
        ]

        if not files:
            print("[RAG] No documents found. Add files to the docs folder.")
            return

        print(f"[RAG] Found {len(files)} document(s). Ingesting...")
        for fp in files:
            self._ingest_file(fp)

        count = len(self._table) if self._table is not None else 0
        print(f"[RAG] Ingestion complete. {count} chunks in vector store.")

    def _ingest_file(self, file_path: Path):
        reader    = READERS[file_path.suffix.lower()]
        text      = reader(str(file_path))
        if not text.strip():
            return

        file_hash = hashlib.md5(text.encode()).hexdigest()
        if self._indexed.get(str(file_path)) == file_hash:
            print(f"[RAG]   Skipping (already indexed): {file_path.name}")
            return

        chunks = _chunk_text(text)
        if not chunks:
            return

        embeddings = _embed(chunks)
        rows = [
            {
                "id":     f"{file_path.stem}_{file_hash}_{i}",
                "text":   chunk,
                "source": file_path.name,
                "chunk":  i,
                "vector": emb,
            }
            for i, (chunk, emb) in enumerate(zip(chunks, embeddings))
        ]

        if self._table is None:
            self._table = self._db.create_table("project_docs", data=rows)
        else:
            self._table.add(rows)

        self._indexed[str(file_path)] = file_hash
        self._index_file.write_text(json.dumps(self._indexed))
        print(f"[RAG]   Indexed {len(chunks)} chunks from: {file_path.name}")

    # ── Query ─────────────────────────────────────────────────────────────────

    def query(self, question: str, n_results: int = 5) -> str:
        if self._table is None or len(self._table) == 0:
            return "No project documents loaded yet."

        q_emb   = _embed([question])[0]
        results = self._table.search(q_emb).limit(n_results).to_list()

        if not results:
            return "No relevant context found in project documents."

        return "\n\n---\n\n".join(
            f"[From: {r['source']}]\n{r['text']}" for r in results
        )

    def get_all_doc_names(self) -> list:
        if self._table is None or len(self._table) == 0:
            return []
        df = self._table.to_pandas()
        return sorted(df["source"].unique().tolist())


if __name__ == "__main__":
    rag = RAGEngine()
    rag.ingest_docs()
    print("\nDocs loaded:", rag.get_all_doc_names())
    print("\nTest query:")
    print(rag.query("what is the main goal of this project?"))