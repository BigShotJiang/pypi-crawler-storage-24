"""
notification_watcher.py — DevMind Pro
Cross-platform notification watcher for Microsoft Teams, Slack, Zoom, Meet.

macOS:   Reads directly from the usernoted SQLite DB (works on all modern macOS)
Windows: winrt toast notifications + PowerShell fallback  
Linux:   D-Bus org.freedesktop.Notifications

main.py API:
    NotificationWatcher(
        on_message=self._on_teams_message,
        ai_engine=self._ai,
        get_transcript=self._transcriber.get_full_transcript,
        poll_interval=5,
    )
on_message receives: {"sender": str, "message": str, "reply_data": dict}
"""

import os
import re
import platform
import threading
import time
import logging
import sqlite3
import plistlib
from dataclasses import dataclass, field
from typing import Callable, Optional
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

logger = logging.getLogger(__name__)

POLL_INTERVAL = float(os.getenv("NOTIFICATION_POLL_INTERVAL", "2.0"))
SYSTEM        = platform.system()


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Notification:
    source:    str
    sender:    str
    message:   str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {"source": self.source, "sender": self.sender,
                "message": self.message, "timestamp": self.timestamp}


# ---------------------------------------------------------------------------
# macOS reader — reads usernoted SQLite DB directly
# ---------------------------------------------------------------------------

class _MacReader:
    """
    Reads from ~/Library/Group Containers/group.com.apple.usernoted/db2/db
    which contains all notification center records including Teams messages.
    Works on macOS Ventura, Sonoma, Sequoia without any permissions needed.
    """

    DB_PATH = Path.home() / "Library/Group Containers/group.com.apple.usernoted/db2/db"

    def __init__(self):
        self._last_rowid = self._get_max_rowid()  # start from now, only catch NEW messages

    def _get_max_rowid(self) -> int:
        try:
            with sqlite3.connect(f"file:{self.DB_PATH}?mode=ro", uri=True, timeout=2) as conn:
                cur = conn.execute("SELECT MAX(rowid) FROM record")
                row = cur.fetchone()
                return row[0] or 0
        except Exception:
            return 0

    def read(self) -> list[dict]:
        if not self.DB_PATH.exists():
            return []
        results = []
        try:
            conn = sqlite3.connect(f"file:{self.DB_PATH}?mode=ro", uri=True, timeout=2)
            cur = conn.execute(
                "SELECT rowid, data FROM record WHERE rowid > ? ORDER BY rowid ASC",
                (self._last_rowid,)
            )
            rows = cur.fetchall()
            conn.close()

            for rowid, data in rows:
                self._last_rowid = max(self._last_rowid, rowid)
                parsed = self._parse_record(data)
                if parsed:
                    results.append(parsed)
        except Exception as e:
            logger.debug("macOS DB read error: %s", e)
        return results

    def _parse_record(self, data: bytes) -> dict | None:
        """Parse binary plist notification record."""
        if not data:
            return None
        try:
            idx = data.find(b"bplist00")
            if idx == -1:
                return None
            parsed = plistlib.loads(data[idx:])

            app = str(parsed.get("app", "")).strip()

            # Message content is inside the req dict
            req = parsed.get("req", {})
            if isinstance(req, dict):
                body  = str(req.get("body", "")).strip()
                # subt is "Chat with Name" — extract sender name
                subt  = str(req.get("subt", "")).strip()
                titl  = str(req.get("titl", "")).strip()
                # sender is in subt like "Chat with Prathibha"
                if subt:
                    sender = re.sub(r"^Chat with\s+", "", subt).strip()
                else:
                    # Try extracting "Name: message" from body
                    m = re.match(r"^([A-Z][a-zA-Z ]{2,30}):\s+(.+)", body)
                    if m:
                        sender = m.group(1).strip()
                        body   = m.group(2).strip()
                    else:
                        sender = titl or "Teams"
                if body:
                    return {"title": sender, "body": body, "app": app}

            # Fallback to top-level fields
            title = str(parsed.get("titl", "")).strip()
            body  = str(parsed.get("body", "")).strip()
            if body or title:
                return {"title": title, "body": body, "app": app}

        except Exception:
            pass
        return self._extract_raw(data)

    def _extract_raw(self, data: bytes) -> dict | None:
        """Fallback: extract readable strings from binary plist."""
        try:
            text = data.decode("utf-8", errors="ignore")
            # Look for Teams message patterns like "Name: message"
            m = re.search(r"([A-Z][a-zA-Z ]{2,30}):\s+([^\x00-\x1f]{5,200})", text)
            if m:
                return {
                    "title": "Microsoft Teams",
                    "body":  f"{m.group(1)}: {m.group(2)}",
                    "app":   "com.microsoft.teams2",
                }
            # Just grab any readable chunk > 10 chars
            chunks = re.findall(r"[A-Za-z0-9 .,!?'\"]{10,100}", text)
            if chunks:
                return {"title": "", "body": chunks[0], "app": ""}
        except Exception:
            pass
        return None


# ---------------------------------------------------------------------------
# Windows reader
# ---------------------------------------------------------------------------

class _WindowsReader:
    def read(self) -> list[dict]:
        results = self._read_winrt()
        return results if results else self._read_powershell()

    def _read_winrt(self) -> list[dict]:
        try:
            import winrt.windows.ui.notifications.management as mgmt  # type: ignore
            import winrt.windows.ui.notifications as notif             # type: ignore
            listener = mgmt.UserNotificationListener.current
            if "ALLOWED" not in str(listener.get_access_status()):
                return []
            items = []
            for n in listener.get_notifications_async(notif.NotificationKinds.TOAST).get():
                try:
                    binding = n.notification.visual.get_binding(
                        notif.KnownNotificationBindings.toast_generic())
                    texts = [t.text for t in binding.get_text_elements()]
                    items.append({"title": texts[0] if texts else "",
                                  "body": " ".join(texts[1:]), "app": ""})
                except Exception:
                    pass
            return items
        except Exception as e:
            logger.debug("winrt error: %s", e)
            return []

    def _read_powershell(self) -> list[dict]:
        import subprocess
        try:
            r = subprocess.run(
                ["powershell", "-Command",
                 "[Windows.UI.Notifications.ToastNotificationManager,"
                 "Windows.UI.Notifications,ContentType=WindowsRuntime]|Out-Null;"
                 "$h=[Windows.UI.Notifications.ToastNotificationManager]::History;"
                 "$h.GetHistory()|Select -First 10|%{$_.Content.GetXml()}"],
                capture_output=True, text=True, timeout=8)
            texts = re.findall(r"<text[^>]*>([^<]+)</text>", r.stdout)
            if texts:
                return [{"title": texts[0], "body": " ".join(texts[1:3]), "app": ""}]
        except Exception as e:
            logger.debug("PowerShell error: %s", e)
        return []


# ---------------------------------------------------------------------------
# Linux reader
# ---------------------------------------------------------------------------

class _LinuxReader:
    def __init__(self):
        self._buf: list[dict] = []
        self._lock = threading.Lock()
        self._started = False

    def _start(self):
        try:
            import dbus                    # type: ignore
            import dbus.mainloop.glib      # type: ignore
            from gi.repository import GLib # type: ignore
            dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
            bus = dbus.SessionBus()
            def _handler(bus_name, obj, iface, sig, args):
                if len(args) >= 5:
                    with self._lock:
                        self._buf.append({
                            "title": str(args[3]),
                            "body":  str(args[4]),
                            "app":   str(args[0]),
                        })
            bus.add_signal_receiver(_handler, dbus_interface="org.freedesktop.Notifications")
            GLib.MainLoop().run()
        except Exception as e:
            logger.debug("Linux D-Bus error: %s", e)

    def read(self) -> list[dict]:
        if not self._started:
            self._started = True
            threading.Thread(target=self._start, daemon=True).start()
        with self._lock:
            items, self._buf = self._buf[:], []
        return items


# ---------------------------------------------------------------------------
# Source classifier + sender extractor
# ---------------------------------------------------------------------------

_PATTERNS = {
    "teams": re.compile(r"microsoft.?teams|teams2|com\.microsoft\.teams", re.I),
    "slack": re.compile(r"slack", re.I),
    "zoom":  re.compile(r"zoom", re.I),
    "meet":  re.compile(r"google.?meet|meet\.google", re.I),
}

def _classify(title: str, body: str, app: str) -> str:
    combined = f"{app} {title} {body}"
    for src, pat in _PATTERNS.items():
        if pat.search(combined):
            return src
    return "generic"

def _extract_sender(title: str, body: str) -> str:
    # "Name: message" pattern — most common in Teams
    m = re.match(r"^([A-Z][a-zA-Z'\- ]{1,30}):\s+", body)
    if m:
        return m.group(1).strip()
    # Title is the sender in Teams notifications
    if title and title not in ("Microsoft Teams", "Teams", "Slack", "Zoom", "Google Meet"):
        return title
    return "Someone"


# ---------------------------------------------------------------------------
# Core watcher
# ---------------------------------------------------------------------------

class _CoreWatcher:
    def __init__(self, on_notification: Callable[[Notification], None]):
        self._callback = on_notification
        self._seen: set[str] = set()
        self._stop  = threading.Event()
        self._thread: Optional[threading.Thread] = None

        self._poll_interval = POLL_INTERVAL
        if SYSTEM == "Darwin":
            self._reader = _MacReader()
        elif SYSTEM == "Windows":
            self._reader = _WindowsReader()
        else:
            self._reader = _LinuxReader()

        logger.info("NotificationWatcher ready (platform=%s)", SYSTEM)

    def start(self):
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self):
        while not self._stop.is_set():
            try:
                for raw in self._reader.read():
                    self._process(raw)
            except Exception as e:
                logger.debug("Watcher loop error: %s", e)
            time.sleep(self._poll_interval)

    def _process(self, raw: dict):
        title = str(raw.get("title", "")).strip()
        body  = str(raw.get("body",  "")).strip()
        app   = str(raw.get("app",   "")).strip()

        if not body and not title:
            return

        key = f"{title}:{body[:80]}"
        if key in self._seen:
            return
        self._seen.add(key)

        # if app empty but title looks like a person name, assume teams
        if not app and title and title not in ("Microsoft Teams","Teams","Slack","Zoom"):
            app = "com.microsoft.teams2"
        source = _classify(title, body, app)
        sender = _extract_sender(title, body)

        notif = Notification(source=source, sender=sender, message=body or title)
        logger.info("[%s] %s: %s", source, sender, (body or title)[:80])
        self._callback(notif)


# ---------------------------------------------------------------------------
# main.py-compatible adapter
# ---------------------------------------------------------------------------

class NotificationWatcher(_CoreWatcher):
    """
    Matches the API expected by main.py:

        NotificationWatcher(
            on_message=self._on_teams_message,
            ai_engine=self._ai,
            get_transcript=self._transcriber.get_full_transcript,
            poll_interval=5,
        )
    """

    def __init__(
        self,
        on_message: Optional[Callable[[dict], None]] = None,
        ai_engine=None,
        get_transcript: Optional[Callable[[], str]] = None,
        poll_interval: int = 5,
        on_notification: Optional[Callable] = None,
    ):
        self._on_message_cb  = on_message
        self._ai_engine      = ai_engine
        self._get_transcript = get_transcript

        def _bridge(notif: Notification):
            # Show message immediately with empty reply
            msg = {
                "sender":     notif.sender,
                "message":    notif.message,
                "reply_data": {"reply": "Generating reply...", "confidence": "low", "source": notif.source},
            }
            if self._on_message_cb:
                self._on_message_cb(msg)
            if on_notification:
                on_notification(notif)

            # Generate AI reply in background and update
            def _generate():
                if self._ai_engine and self._get_transcript:
                    try:
                        reply_data = self._ai_engine.suggest_reply(
                            question_asked=notif.message,
                            full_transcript=self._get_transcript(),
                        )
                        msg["reply_data"] = reply_data
                        if self._on_message_cb:
                            self._on_message_cb(msg)
                    except Exception:
                        pass

            import threading
            threading.Thread(target=_generate, daemon=True).start()

        super().__init__(on_notification=_bridge)
        self._poll_interval = float(poll_interval)


# ---------------------------------------------------------------------------
# CLI test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    def _print(n: Notification):
        print(f"[{n.source}] {n.sender}: {n.message[:120]}")

    w = NotificationWatcher(on_notification=_print)
    w.start()
    print(f"Watching notifications on {SYSTEM}… send a Teams message then watch here. Ctrl-C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        w.stop()