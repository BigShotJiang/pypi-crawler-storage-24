"""
followup_email.py — DevMind Pro
Generates professional follow-up emails from meeting transcripts,
commitments, and decisions using the configured AI provider.
Supports sending via SMTP or copying to clipboard.
"""

import os
import smtplib
import logging
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dataclasses import dataclass
from typing import Optional
from datetime import datetime

from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

AI_PROVIDER = os.getenv("AI_PROVIDER", "ollama").lower()
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama3-70b-8192")

SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
EMAIL_FROM = os.getenv("EMAIL_FROM", SMTP_USER)
EMAIL_SIGNATURE = os.getenv("EMAIL_SIGNATURE", "Best regards,\nDevMind Pro")


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class EmailDraft:
    subject: str
    body_plain: str
    body_html: str
    recipients: list[str]
    cc: list[str]
    generated_at: str = ""

    def __post_init__(self):
        if not self.generated_at:
            self.generated_at = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "subject": self.subject,
            "body_plain": self.body_plain,
            "recipients": self.recipients,
            "cc": self.cc,
            "generated_at": self.generated_at,
        }


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def _build_prompt(
    transcript: str,
    commitments: list[dict],
    decisions: list[str],
    meeting_title: str,
    attendees: list[str],
    tone: str = "professional",
) -> str:
    commitments_text = "\n".join(
        f"- {c.get('who','?')}: {c.get('action','?')}"
        + (f" (due: {c['deadline']})" if c.get("deadline") else "")
        for c in commitments
    ) or "None recorded."

    decisions_text = "\n".join(f"- {d}" for d in decisions) or "None recorded."
    attendees_text = ", ".join(attendees) if attendees else "Not specified."

    today = datetime.now().strftime("%B %d, %Y")

    return f"""You are an expert executive assistant. Write a {tone} follow-up email for the meeting described below.

MEETING: {meeting_title}
DATE: {today}
ATTENDEES: {attendees_text}

--- TRANSCRIPT EXCERPT (first 3000 chars) ---
{transcript[:3000]}
--- END TRANSCRIPT ---

KEY DECISIONS:
{decisions_text}

ACTION ITEMS / COMMITMENTS:
{commitments_text}

INSTRUCTIONS:
1. Write a clear subject line starting with "Meeting Follow-Up: "
2. Open with a brief thank-you sentence
3. Summarize key decisions in 2-4 bullet points
4. List all action items with owner and deadline (if known)
5. Suggest a next meeting or check-in if appropriate
6. Close professionally
7. Use plain English, avoid jargon
8. Output format: first line = subject, blank line, then body

Do NOT include any meta-commentary. Output only the email text."""


# ---------------------------------------------------------------------------
# AI provider backends
# ---------------------------------------------------------------------------

def _call_ollama(prompt: str) -> str:
    import requests, json

    resp = requests.post(
        f"{OLLAMA_BASE_URL}/api/generate",
        json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": True},
        timeout=120,
        stream=True,
    )
    resp.raise_for_status()
    parts = []
    for line in resp.iter_lines():
        if line:
            try:
                obj = json.loads(line)
                parts.append(obj.get("response", ""))
                if obj.get("done"):
                    break
            except json.JSONDecodeError:
                pass
    return "".join(parts).strip()


def _call_openai(prompt: str) -> str:
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY not set.")
    import requests

    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
        json={
            "model": OPENAI_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 1000,
            "temperature": 0.4,
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"].strip()


def _call_gemini(prompt: str) -> str:
    if not GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY not set.")
    import requests

    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"
    )
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"maxOutputTokens": 1000, "temperature": 0.4},
    }
    resp = requests.post(url, json=payload, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    return data["candidates"][0]["content"]["parts"][0]["text"].strip()


def _call_groq(prompt: str) -> str:
    if not GROQ_API_KEY:
        raise ValueError("GROQ_API_KEY not set.")
    import requests

    resp = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
        json={
            "model": GROQ_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 1000,
            "temperature": 0.4,
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"].strip()


_PROVIDER_MAP = {
    "ollama": _call_ollama,
    "openai": _call_openai,
    "gemini": _call_gemini,
    "groq": _call_groq,
}


def _call_ai(prompt: str) -> str:
    fn = _PROVIDER_MAP.get(AI_PROVIDER)
    if fn is None:
        raise ValueError(f"Unknown AI_PROVIDER: {AI_PROVIDER}")
    return fn(prompt)


# ---------------------------------------------------------------------------
# Core generation
# ---------------------------------------------------------------------------

def _plain_to_html(plain: str) -> str:
    """Convert plain text email to simple HTML."""
    html_body = ""
    for line in plain.splitlines():
        stripped = line.strip()
        if stripped.startswith("- ") or stripped.startswith("• "):
            html_body += f"<li>{stripped[2:]}</li>\n"
        elif stripped == "":
            html_body += "<br/>\n"
        else:
            html_body += f"<p>{stripped}</p>\n"

    return f"""<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; font-size: 14px; color: #333; max-width: 700px; margin: auto;">
{html_body}
</body>
</html>"""


def generate_followup_email(
    transcript: str,
    commitments: Optional[list[dict]] = None,
    decisions: Optional[list[str]] = None,
    meeting_title: str = "Team Meeting",
    attendees: Optional[list[str]] = None,
    recipients: Optional[list[str]] = None,
    cc: Optional[list[str]] = None,
    tone: str = "professional",
) -> EmailDraft:
    """
    Generate a follow-up email draft using the configured AI provider.

    Args:
        transcript: Full meeting transcript text.
        commitments: List of commitment dicts from keyword_alerts.
        decisions: List of decision strings.
        meeting_title: Title of the meeting.
        attendees: List of attendee names.
        recipients: Email recipients (To:).
        cc: CC recipients.
        tone: "professional" | "friendly" | "concise"

    Returns:
        EmailDraft object.
    """
    commitments = commitments or []
    decisions = decisions or []
    attendees = attendees or []
    recipients = recipients or []
    cc = cc or []

    prompt = _build_prompt(transcript, commitments, decisions, meeting_title, attendees, tone)

    logger.info("Generating follow-up email via %s…", AI_PROVIDER)
    raw_output = _call_ai(prompt)

    # Parse subject line from first line
    lines = raw_output.strip().splitlines()
    subject = lines[0] if lines else f"Meeting Follow-Up: {meeting_title}"
    if subject.lower().startswith("subject:"):
        subject = subject[8:].strip()

    body_plain = "\n".join(lines[1:]).strip() if len(lines) > 1 else raw_output

    # Append signature
    if EMAIL_SIGNATURE:
        body_plain += f"\n\n{EMAIL_SIGNATURE}"

    body_html = _plain_to_html(body_plain)

    return EmailDraft(
        subject=subject,
        body_plain=body_plain,
        body_html=body_html,
        recipients=recipients,
        cc=cc,
    )


# ---------------------------------------------------------------------------
# Email dispatch
# ---------------------------------------------------------------------------

def send_email(draft: EmailDraft, use_html: bool = True) -> bool:
    """
    Send an EmailDraft via SMTP.
    Returns True on success, False on failure.
    """
    if not SMTP_USER or not SMTP_PASSWORD:
        logger.error("SMTP credentials not configured (SMTP_USER / SMTP_PASSWORD).")
        return False

    if not draft.recipients:
        logger.error("No recipients specified.")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = draft.subject
    msg["From"] = EMAIL_FROM
    msg["To"] = ", ".join(draft.recipients)
    if draft.cc:
        msg["Cc"] = ", ".join(draft.cc)

    msg.attach(MIMEText(draft.body_plain, "plain"))
    if use_html:
        msg.attach(MIMEText(draft.body_html, "html"))

    all_recipients = draft.recipients + draft.cc

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(EMAIL_FROM, all_recipients, msg.as_string())
        logger.info("Follow-up email sent to %s", all_recipients)
        return True
    except Exception as exc:
        logger.error("Failed to send email: %s", exc)
        return False


def copy_to_clipboard(draft: EmailDraft) -> bool:
    """Copy the email body to the system clipboard."""
    content = f"Subject: {draft.subject}\n\n{draft.body_plain}"
    try:
        import platform
        system = platform.system()
        if system == "Darwin":
            import subprocess
            proc = subprocess.run(["pbcopy"], input=content.encode(), check=True)
        elif system == "Windows":
            import subprocess
            proc = subprocess.run(["clip"], input=content.encode(), check=True)
        else:
            try:
                import subprocess
                proc = subprocess.run(["xclip", "-selection", "clipboard"],
                                      input=content.encode(), check=True)
            except FileNotFoundError:
                import subprocess
                subprocess.run(["xsel", "--clipboard", "--input"],
                               input=content.encode(), check=True)
        logger.info("Email copied to clipboard.")
        return True
    except Exception as exc:
        logger.warning("Clipboard copy failed: %s", exc)
        return False


def save_email_to_file(draft: EmailDraft, path: str = "followup_email.txt") -> str:
    """Save the draft to a text file."""
    content = f"Subject: {draft.subject}\nTo: {', '.join(draft.recipients)}\n\n{draft.body_plain}"
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    logger.info("Email saved to %s", path)
    return path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys, json
    logging.basicConfig(level=logging.INFO)

    sample_transcript = """
    Alice: Let's kick off. We need to decide on the Q3 roadmap by EOD today.
    Bob: I'll handle the backend API changes and have them ready by Wednesday.
    Alice: Great. I will coordinate with design and send the mockups by Friday.
    Carol: The budget was approved — $50k for this quarter.
    Bob: We should also follow up with the client about the revised timeline.
    Alice: Agreed. Action item: Bob to send the client update by Monday.
    """

    commitments = [
        {"who": "Bob", "action": "handle the backend API changes", "deadline": "Wednesday"},
        {"who": "Alice", "action": "send the mockups", "deadline": "Friday"},
        {"who": "Bob", "action": "send the client update", "deadline": "Monday"},
    ]

    decisions = [
        "Q3 roadmap to be finalized by EOD today",
        "Budget of $50k approved for Q3",
    ]

    draft = generate_followup_email(
        transcript=sample_transcript,
        commitments=commitments,
        decisions=decisions,
        meeting_title="Q3 Planning Session",
        attendees=["Alice", "Bob", "Carol"],
        recipients=["team@example.com"],
    )

    print(f"\nSubject: {draft.subject}\n")
    print(draft.body_plain)

    output_path = "followup_email.txt"
    save_email_to_file(draft, output_path)
    print(f"\nSaved to {output_path}")


# ---------------------------------------------------------------------------
# main.py-compatible adapter
# ---------------------------------------------------------------------------

class FollowupEmailGenerator:
    """
    Matches the API expected by main.py:

        FollowupEmailGenerator()
        .save_and_copy(transcript, commitments, doubts)

    Generates the email, saves it to disk, and copies the body to clipboard.
    """

    def save_and_copy(
        self,
        transcript: str,
        commitments: list,
        doubts: list,
        meeting_title: str = "Meeting Follow-Up",
        attendees: Optional[list] = None,
    ) -> Optional[str]:
        """
        Generate a follow-up email from raw transcript + commitment list,
        save to disk, and copy to clipboard.

        commitments: list of dicts with keys {who/speaker, action, deadline}
        doubts:      list of dicts with keys {doubt/insight}
        """
        # Normalise commitment dicts (main.py uses CommitmentTracker output)
        normalised = []
        for c in commitments:
            normalised.append({
                "who":      c.get("who") or c.get("speaker") or c.get("owner", "TBD"),
                "action":   c.get("action") or c.get("text", ""),
                "deadline": c.get("deadline", ""),
            })

        # Weave doubts into the transcript as annotations
        if doubts:
            doubt_lines = "\n".join(
                f"[NOTE: {d.get('doubt') or d.get('insight') or str(d)}]"
                for d in doubts
            )
            transcript = transcript + "\n\n" + doubt_lines

        try:
            draft = generate_followup_email(
                transcript=transcript,
                commitments=normalised,
                decisions=[],
                meeting_title=meeting_title,
                attendees=attendees or [],
            )
            path = save_email_to_file(draft)

            # Try to copy to clipboard (platform_utils)
            try:
                from platform_utils import copy_to_clipboard
                copy_to_clipboard(draft.body_plain)
                logger.info("Follow-up email copied to clipboard.")
            except Exception:
                pass

            logger.info("Follow-up email saved: %s", path)
            return path

        except Exception as e:
            logger.error("Failed to generate follow-up email: %s", e)
            return None