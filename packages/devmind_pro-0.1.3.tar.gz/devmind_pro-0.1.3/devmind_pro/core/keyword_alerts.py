"""
keyword_alerts.py — DevMind Pro
Real-time keyword alerting, commitment tracking, gap detection,
and contradiction detection over the live transcript stream.
"""

import os
import re
import logging
from dataclasses import dataclass, field
from typing import Callable, Optional
from datetime import datetime
from collections import defaultdict

from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_raw_keywords = os.getenv(
    "ALERT_KEYWORDS",
    "action item,deadline,blocker,decision,risk,budget,milestone,approve,escalate,follow up"
)
USER_KEYWORDS: list[str] = [k.strip().lower() for k in _raw_keywords.split(",") if k.strip()]

COMMITMENT_PHRASES = [
    r"i('ll| will)\s+(?P<action>.{5,80})",
    r"we('ll| will)\s+(?P<action>.{5,80})",
    r"(?P<who>\w+)\s+will\s+(?P<action>.{5,80})",
    r"(?:action item|todo|task)[\s:]+(?P<action>.{5,80})",
    r"(?:by|before|due)\s+(?P<deadline>(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|eod|eow|\d{1,2}[\/\-]\d{1,2}))",
]

CONTRADICTION_PAIRS = [
    (r"\bapproved\b", r"\brejected\b"),
    (r"\bwe (are|will) (do|build|ship)\b", r"\bwe (are|will) not (do|build|ship)\b"),
    (r"\bdeadline is (\w+)\b", r"\bno deadline\b"),
    (r"\bbudget (is|was) (\w+)\b", r"\bno budget\b"),
    (r"\bin scope\b", r"\bout of scope\b"),
    (r"\bsupport(?:ed)?\b", r"\bdo(?:n't| not) support\b"),
]

GAP_SILENCE_THRESHOLD_S = float(os.getenv("GAP_SILENCE_THRESHOLD_S", "15.0"))


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class Alert:
    kind: str           # "keyword" | "commitment" | "contradiction" | "gap"
    message: str
    speaker: Optional[str]
    segment_text: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "message": self.message,
            "speaker": self.speaker,
            "segment_text": self.segment_text[:200],
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


@dataclass
class Commitment:
    who: str
    action: str
    deadline: Optional[str]
    segment_text: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    fulfilled: bool = False

    def to_dict(self) -> dict:
        return {
            "who": self.who,
            "action": self.action,
            "deadline": self.deadline,
            "segment_text": self.segment_text[:200],
            "timestamp": self.timestamp,
            "fulfilled": self.fulfilled,
        }


# ---------------------------------------------------------------------------
# Detectors
# ---------------------------------------------------------------------------

def detect_keywords(text: str, keywords: list[str] = USER_KEYWORDS) -> list[str]:
    """Return matched keywords found in text."""
    text_lower = text.lower()
    return [kw for kw in keywords if kw in text_lower]


def extract_commitments(text: str, speaker: Optional[str] = None) -> list[Commitment]:
    """Extract commitment statements from a transcript segment."""
    commitments = []
    deadline_match = None

    # First pass: find any deadline mentioned anywhere in the text
    dl_pattern = re.compile(
        r"(?:by|before|due)\s+(?P<deadline>eod|eow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d{1,2}[\/\-]\d{1,2})",
        re.I,
    )
    dl_m = dl_pattern.search(text)
    if dl_m:
        deadline_match = dl_m.group("deadline")

    for pattern_str in COMMITMENT_PHRASES:
        for m in re.finditer(pattern_str, text, re.I):
            action = m.groupdict().get("action", "").strip(" .,;")
            who = m.groupdict().get("who", speaker or "someone").strip()
            deadline = m.groupdict().get("deadline") or deadline_match

            if len(action) < 5:
                continue

            commitments.append(
                Commitment(
                    who=who,
                    action=action,
                    deadline=deadline,
                    segment_text=text,
                )
            )

    # Deduplicate by action text similarity
    seen_actions: list[str] = []
    unique = []
    for c in commitments:
        if not any(c.action[:30] in s for s in seen_actions):
            unique.append(c)
            seen_actions.append(c.action[:30])
    return unique


def detect_contradictions(
    current_text: str, history: list[str]
) -> list[tuple[str, str]]:
    """
    Compare current segment against history for contradictory statements.
    Returns list of (current_phrase, conflicting_history_phrase) pairs.
    """
    conflicts = []
    for pos_pat, neg_pat in CONTRADICTION_PAIRS:
        if re.search(pos_pat, current_text, re.I):
            for hist_seg in history[-50:]:  # look back up to 50 segments
                if re.search(neg_pat, hist_seg, re.I):
                    conflicts.append((current_text[:120], hist_seg[:120]))
                    break
        if re.search(neg_pat, current_text, re.I):
            for hist_seg in history[-50:]:
                if re.search(pos_pat, hist_seg, re.I):
                    conflicts.append((current_text[:120], hist_seg[:120]))
                    break
    return conflicts


def detect_gap(
    last_end_time: float,
    current_start_time: float,
    threshold: float = GAP_SILENCE_THRESHOLD_S,
) -> Optional[float]:
    """Return gap duration if it exceeds threshold, else None."""
    gap = current_start_time - last_end_time
    return gap if gap >= threshold else None


# ---------------------------------------------------------------------------
# AlertEngine — stateful, wired into the transcript stream
# ---------------------------------------------------------------------------

class AlertEngine:
    """
    Consumes TranscriptSegment objects and fires Alert callbacks
    for keywords, commitments, contradictions, and silence gaps.
    """

    def __init__(self, on_alert: Callable[[Alert], None]):
        self.on_alert = on_alert
        self._history: list[str] = []          # raw segment texts
        self._commitments: list[Commitment] = []
        self._last_segment_end: float = 0.0
        self._speaker_word_counts: dict[str, int] = defaultdict(int)

    # ------------------------------------------------------------------
    def process_segment(self, segment) -> list[Alert]:
        """
        Accept a TranscriptSegment (duck-typed: .text, .speaker,
        .start_time, .end_time) and return fired alerts.
        """
        text = segment.text.strip()
        speaker = getattr(segment, "speaker", None)
        start_time = getattr(segment, "start_time", 0.0)
        end_time = getattr(segment, "end_time", 0.0)

        fired: list[Alert] = []

        # --- Gap detection ---
        if self._last_segment_end > 0:
            gap = detect_gap(self._last_segment_end, start_time)
            if gap is not None:
                alert = Alert(
                    kind="gap",
                    message=f"Silence gap of {gap:.1f}s detected — possible missed content.",
                    speaker=None,
                    segment_text="",
                    metadata={"gap_seconds": round(gap, 2)},
                )
                fired.append(alert)
                self.on_alert(alert)
                logger.info("GAP alert: %.1fs", gap)

        self._last_segment_end = end_time

        # --- Keyword alerts ---
        matched_kws = detect_keywords(text)
        for kw in matched_kws:
            alert = Alert(
                kind="keyword",
                message=f'Keyword detected: "{kw}"',
                speaker=speaker,
                segment_text=text,
                metadata={"keyword": kw},
            )
            fired.append(alert)
            self.on_alert(alert)
            logger.info("KEYWORD alert: %s | %s", kw, speaker)

        # --- Commitment extraction ---
        new_commitments = extract_commitments(text, speaker)
        for c in new_commitments:
            self._commitments.append(c)
            alert = Alert(
                kind="commitment",
                message=f'Commitment by {c.who}: "{c.action}"'
                + (f" (due: {c.deadline})" if c.deadline else ""),
                speaker=speaker,
                segment_text=text,
                metadata=c.to_dict(),
            )
            fired.append(alert)
            self.on_alert(alert)
            logger.info("COMMITMENT alert: %s → %s", c.who, c.action[:60])

        # --- Contradiction detection ---
        conflicts = detect_contradictions(text, self._history)
        for curr, prev in conflicts:
            alert = Alert(
                kind="contradiction",
                message=f"Potential contradiction: '{curr[:80]}' vs earlier '{prev[:80]}'",
                speaker=speaker,
                segment_text=text,
                metadata={"current": curr, "previous": prev},
            )
            fired.append(alert)
            self.on_alert(alert)
            logger.warning("CONTRADICTION alert: %s", curr[:60])

        # --- Speaker tracking ---
        if speaker:
            word_count = len(text.split())
            self._speaker_word_counts[speaker] += word_count

        self._history.append(text)
        return fired

    # ------------------------------------------------------------------
    def get_commitments(self) -> list[Commitment]:
        return list(self._commitments)

    def get_speaker_balance(self) -> dict[str, float]:
        """Return each speaker's share of total words spoken."""
        total = sum(self._speaker_word_counts.values()) or 1
        return {
            spk: round(count / total * 100, 1)
            for spk, count in self._speaker_word_counts.items()
        }

    def get_summary_stats(self) -> dict:
        return {
            "total_segments": len(self._history),
            "commitments": len(self._commitments),
            "speaker_balance": self.get_speaker_balance(),
        }


# ---------------------------------------------------------------------------
# CLI test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO)

    class _FakeSeg:
        def __init__(self, text, speaker="Alice", start=0.0, end=5.0):
            self.text = text
            self.speaker = speaker
            self.start_time = start
            self.end_time = end

    def printer(alert: Alert):
        print(f"  [{alert.kind.upper()}] {alert.message}")

    engine = AlertEngine(on_alert=printer)

    samples = [
        "We will ship the feature by EOD Friday. There's a budget risk we need to discuss.",
        "Actually we will NOT ship the feature this week due to blockers.",
        "I'll create a follow-up ticket and send the action item list by Monday.",
        "The decision has been approved by the board.",
        "The project has been rejected — we're moving on.",
    ]

    t = 0.0
    for i, s in enumerate(samples):
        seg = _FakeSeg(s, speaker="Alice" if i % 2 == 0 else "Bob", start=t, end=t + 4)
        print(f"\nSegment: {s[:60]}")
        engine.process_segment(seg)
        t += 4 if i < 2 else 20  # simulate a gap after the 2nd segment

    print("\n--- Commitments ---")
    for c in engine.get_commitments():
        print(f"  {c.who}: {c.action} | deadline={c.deadline}")

    print("\n--- Speaker balance ---")
    print(engine.get_speaker_balance())


# ---------------------------------------------------------------------------
# main.py-compatible adapter
# ---------------------------------------------------------------------------

_GREETING_WORDS = {
    "hi", "hello", "hey", "good morning", "good afternoon",
    "good evening", "howdy", "greetings", "sup", "yo",
}


def _is_greeting(text: str) -> bool:
    """Return True if the text is just a greeting with no actionable content."""
    stripped = text.strip().lower().rstrip("!.,")
    return stripped in _GREETING_WORDS or any(
        stripped.startswith(g + " ") for g in _GREETING_WORDS
    )


class KeywordAlerter:
    """
    Matches the API expected by main.py:

        KeywordAlerter(my_name=MY_NAME, on_alert=self._on_keyword_alert)
        .check_transcript(text)

    on_alert receives:
        {"keyword": str, "source": str, "is_greeting": bool, "text": str}
    """

    def __init__(
        self,
        my_name: str = "",
        on_alert: Optional[Callable[[dict], None]] = None,
    ):
        self._my_name = my_name.lower() if my_name else ""
        self._on_alert = on_alert

        def _bridge(alert: Alert):
            if self._on_alert:
                self._on_alert({
                    "keyword":     alert.message,
                    "source":      "transcript",
                    "is_greeting": False,
                    "text":        alert.segment_text,
                    "speaker":     alert.speaker,
                    "kind":        alert.kind,
                })

        self._engine = AlertEngine(on_alert=_bridge)
        self._chunk_index = 0

    def check_transcript(self, text: str):
        """Process a new transcript chunk. Called by main.py on every chunk."""
        if not text.strip():
            return

        # Detect if someone addressed the user by name
        if self._my_name and self._my_name in text.lower():
            if self._on_alert:
                self._on_alert({
                    "keyword":     f"name mention: {self._my_name}",
                    "source":      "transcript",
                    "is_greeting": _is_greeting(text),
                    "text":        text,
                    "speaker":     None,
                    "kind":        "mention",
                })

        class _FakeSeg:
            def __init__(self, t, idx):
                self.text = t
                self.speaker = "Speaker"
                self.start_time = float(idx * 5)
                self.end_time   = float(idx * 5 + 5)

        self._chunk_index += 1
        self._engine.process_segment(_FakeSeg(text, self._chunk_index))