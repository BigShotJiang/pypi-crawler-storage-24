"""
transcriber.py — DevMind Pro
Cross-platform real-time meeting transcription engine.
Supports local Whisper, OpenAI Whisper API, Groq, and Google Gemini audio.
AI_PROVIDER in .env controls the backend.
"""

import os
import queue
import threading
import tempfile
import time
import wave
import logging
import numpy as np
from pathlib import Path
from dataclasses import dataclass, field
from typing import Callable, Optional
from datetime import datetime

from dotenv import load_dotenv
try:
    from platform_utils import get_audio_backend, PlatformError
except ImportError:
    get_audio_backend = None
    class PlatformError(Exception):
        pass

load_dotenv()

logger = logging.getLogger(__name__)

AI_PROVIDER     = os.getenv("AI_PROVIDER", "ollama").lower()
SAMPLE_RATE     = int(os.getenv("SAMPLE_RATE", "16000"))
CHUNK_SECONDS   = int(os.getenv("CHUNK_SECONDS", "6"))        # slightly longer = better context
SILENCE_THRESHOLD = float(os.getenv("SILENCE_THRESHOLD", "0.015"))
WHISPER_MODEL   = os.getenv("WHISPER_MODEL", "small")
WHISPER_LANG    = os.getenv("WHISPER_LANG", "en")             # force language — prevents garbage
OPENAI_API_KEY  = os.getenv("OPENAI_API_KEY", "")
GEMINI_API_KEY  = os.getenv("GEMINI_API_KEY", "")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")


@dataclass
class TranscriptSegment:
    text: str
    speaker: Optional[str]
    start_time: float
    end_time: float
    confidence: float = 1.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "speaker": self.speaker,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
        }


class TranscriptionError(Exception):
    pass


# ---------------------------------------------------------------------------
# Hallucination / garbage filter
# ---------------------------------------------------------------------------

# Whisper hallucinates these phrases on silence or noise — discard them
_WHISPER_HALLUCINATIONS = {
    "you", "thank you", "thanks for watching", "thanks for listening",
    "please subscribe", "subtitles by", "transcribed by", "amara.org",
    "ご視聴ありがとうございました", "字幕", "ご覧いただきありがとうございました",
    "....", "…", "[ silence ]", "[silence]", "[music]", "[applause]",
    "(silence)", "(music)", "(applause)",
    # prompt bleed-through — discard if whisper echoes the initial_prompt
    "transcribe only spoken words.",
    "this is a video of a business meeting conversation in english.",
    "this is a video about a business meeting conversation in english.",
    "this is a business meeting conversation in english.",
    "please subscribe to my channel.",
    "i am not a good person.",
}

_GARBAGE_TOKENS = ["<|", "|>", "様", "richtig", "ʕ", "ʔ"]


def _is_garbage(text: str) -> bool:
    """Return True if the transcription looks like hallucination / noise."""
    stripped = text.strip().lower()
    if not stripped or len(stripped) < 3:
        return True
    if stripped in _WHISPER_HALLUCINATIONS:
        return True
    # Contains raw Whisper special tokens leaking through
    if any(tok in text for tok in _GARBAGE_TOKENS):
        return True
    # Mostly non-ASCII in what should be an English meeting
    ascii_ratio = sum(1 for c in text if ord(c) < 128) / max(len(text), 1)
    if ascii_ratio < 0.6:
        return True
    return False


def _is_silent_audio(raw_bytes: bytes) -> bool:
    """Check if the audio chunk is below the silence threshold."""
    try:
        if not raw_bytes:
            return True
        audio = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        if len(audio) == 0:
            return True
        rms = float(np.sqrt(np.mean(audio ** 2)))
        return rms < SILENCE_THRESHOLD
    except Exception:
        return False  # if we can't check, don't skip it


# ---------------------------------------------------------------------------
# Backend transcription helpers
# ---------------------------------------------------------------------------

_whisper_model = None  # cached after first load


def _get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        import whisper
        model_name = os.getenv("WHISPER_MODEL", "small")
        logger.info("Loading local Whisper model: %s", model_name)
        _whisper_model = whisper.load_model(model_name)
    return _whisper_model


def _transcribe_local_whisper(audio_path: str) -> str:
    """
    Transcribe using the local openai-whisper model.
    Optimised for accuracy + speed on Apple Silicon.
    No initial_prompt — it causes prompt bleed-through on short chunks.
    """
    model = _get_whisper_model()
    result = model.transcribe(
        audio_path,
        language=WHISPER_LANG,               # force English — kills <|he|> <|en|> garbage
        task="transcribe",                   # never translate
        fp16=False,                          # fp16 crashes on MPS/CPU
        temperature=0.0,                     # greedy = fast + stable
        no_speech_threshold=0.5,             # skip silent chunks
        logprob_threshold=-1.0,              # drop low-confidence output
        compression_ratio_threshold=2.4,     # drop repetitive/looping output
        condition_on_previous_text=True,     # improves accuracy across chunks
    )
    text = result.get("text", "").strip()
    return "" if _is_garbage(text) else text


_transcribe_ollama = _transcribe_local_whisper  # Ollama is LLM-only, not STT


def _transcribe_openai(audio_path: str) -> str:
    if not OPENAI_API_KEY:
        logger.warning("OPENAI_API_KEY not set — falling back to local Whisper.")
        return _transcribe_local_whisper(audio_path)
    import requests

    with open(audio_path, "rb") as f:
        resp = requests.post(
            "https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
            files={"file": (Path(audio_path).name, f, "audio/wav")},
            data={"model": "whisper-1", "response_format": "json", "language": WHISPER_LANG},
            timeout=60,
        )
    resp.raise_for_status()
    text = resp.json().get("text", "").strip()
    return "" if _is_garbage(text) else text


def _transcribe_gemini(audio_path: str) -> str:
    if not GEMINI_API_KEY:
        logger.warning("GEMINI_API_KEY not set — falling back to local Whisper.")
        return _transcribe_local_whisper(audio_path)
    import requests, base64

    with open(audio_path, "rb") as f:
        audio_b64 = base64.b64encode(f.read()).decode()

    payload = {
        "contents": [{
            "parts": [
                {"inline_data": {"mime_type": "audio/wav", "data": audio_b64}},
                {"text": "Transcribe this audio verbatim in English. Output only the spoken words, nothing else."},
            ]
        }]
    }
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"
    )
    resp = requests.post(url, json=payload, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    try:
        text = data["candidates"][0]["content"]["parts"][0]["text"].strip()
        return "" if _is_garbage(text) else text
    except (KeyError, IndexError) as exc:
        raise TranscriptionError(f"Unexpected Gemini response: {data}") from exc


def _transcribe_groq(audio_path: str) -> str:
    groq_api_key = os.getenv("GROQ_API_KEY", "")
    if not groq_api_key:
        logger.warning("GROQ_API_KEY not set — falling back to local Whisper.")
        return _transcribe_local_whisper(audio_path)
    import requests

    with open(audio_path, "rb") as f:
        resp = requests.post(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {groq_api_key}"},
            files={"file": (Path(audio_path).name, f, "audio/wav")},
            data={"model": "whisper-large-v3", "response_format": "json", "language": WHISPER_LANG},
            timeout=60,
        )
    resp.raise_for_status()
    text = resp.json().get("text", "").strip()
    return "" if _is_garbage(text) else text


BACKEND_MAP = {
    "ollama":  _transcribe_ollama,
    "openai":  _transcribe_openai,
    "gemini":  _transcribe_gemini,
    "groq":    _transcribe_groq,
    "local":   _transcribe_local_whisper,
    "whisper": _transcribe_local_whisper,
}


def transcribe_audio_file(audio_path: str) -> str:
    """Transcribe a WAV file using the configured AI provider."""
    backend = BACKEND_MAP.get(AI_PROVIDER, _transcribe_local_whisper)
    if AI_PROVIDER not in BACKEND_MAP:
        logger.warning(
            "Unknown AI_PROVIDER '%s' — using local Whisper. Valid: %s",
            AI_PROVIDER, list(BACKEND_MAP),
        )
    logger.info("Transcribing %s via %s", audio_path, AI_PROVIDER)
    return backend(audio_path)


# ---------------------------------------------------------------------------
# Cross-platform audio capture
# ---------------------------------------------------------------------------

def _capture_audio_sounddevice(
    q: queue.Queue,
    stop_event: threading.Event,
    sample_rate: int,
    chunk_seconds: int,
    device=None,
):
    """Capture mic audio using sounddevice (works on macOS, Windows, Linux)."""
    import sounddevice as sd

    chunk_frames = sample_rate * chunk_seconds

    def _callback(indata, frames, time_info, status):
        if status:
            logger.debug("sounddevice status: %s", status)
        raw = (indata[:, 0] * 32767).astype(np.int16).tobytes()
        if not _is_silent_audio(raw):
            q.put(raw)

    device_idx = None
    if device:
        try:
            device_idx = int(device)
        except (ValueError, TypeError):
            # Try matching by name
            devices = sd.query_devices()
            for i, d in enumerate(devices):
                if device.lower() in d["name"].lower():
                    device_idx = i
                    break

    with sd.InputStream(
        samplerate=sample_rate,
        channels=1,
        dtype="float32",
        blocksize=chunk_frames,
        device=device_idx,
        callback=_callback,
    ):
        while not stop_event.is_set():
            time.sleep(0.1)


def _capture_audio_pyaudio(
    q: queue.Queue,
    stop_event: threading.Event,
    sample_rate: int,
    chunk_seconds: int,
    device=None,
):
    """Fallback audio capture using PyAudio."""
    import pyaudio

    pa = pyaudio.PyAudio()
    chunk_frames = sample_rate * chunk_seconds

    device_idx = None
    if device is not None:
        try:
            device_idx = int(device)
        except (ValueError, TypeError):
            for i in range(pa.get_device_count()):
                info = pa.get_device_info_by_index(i)
                if device.lower() in info["name"].lower():
                    device_idx = i
                    break

    stream = pa.open(
        format=pyaudio.paInt16,
        channels=1,
        rate=sample_rate,
        input=True,
        input_device_index=device_idx,
        frames_per_buffer=chunk_frames,
    )
    try:
        while not stop_event.is_set():
            raw = stream.read(chunk_frames, exception_on_overflow=False)
            if not _is_silent_audio(raw):
                q.put(raw)
    finally:
        stream.stop_stream()
        stream.close()
        pa.terminate()


def _get_capture_fn():
    """Pick the best available audio capture backend."""
    try:
        import sounddevice  # noqa: F401
        return _capture_audio_sounddevice
    except ImportError:
        pass
    try:
        import pyaudio  # noqa: F401
        return _capture_audio_pyaudio
    except ImportError:
        pass
    raise RuntimeError(
        "No audio capture library found. Install sounddevice:\n"
        "  pip install sounddevice"
    )


# ---------------------------------------------------------------------------
# Core Transcriber
# ---------------------------------------------------------------------------

class _CoreTranscriber:
    """
    Captures mic audio in chunks and calls on_segment for each transcribed chunk.
    Thread-safe; call start() / stop().
    """

    def __init__(
        self,
        on_segment: Callable[[TranscriptSegment], None],
        device: str = "",
    ):
        self.on_segment = on_segment
        self.device = device
        self._audio_queue: queue.Queue = queue.Queue()
        self._stop_event = threading.Event()
        self._capture_thread: Optional[threading.Thread] = None
        self._transcribe_thread: Optional[threading.Thread] = None
        self._session_start = time.time()
        self._segments: list[TranscriptSegment] = []

    def start(self):
        logger.info("Starting transcription (device=%r, provider=%s)", self.device, AI_PROVIDER)
        self._stop_event.clear()
        self._session_start = time.time()
        self._capture_thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._transcribe_thread = threading.Thread(target=self._transcribe_loop, daemon=True)
        self._capture_thread.start()
        self._transcribe_thread.start()

    def stop(self) -> list[TranscriptSegment]:
        logger.info("Stopping transcription.")
        self._stop_event.set()
        if self._capture_thread:
            self._capture_thread.join(timeout=10)
        if self._transcribe_thread:
            self._transcribe_thread.join(timeout=30)
        return list(self._segments)

    @property
    def full_transcript(self) -> str:
        return " ".join(s.text for s in self._segments)

    def _capture_loop(self):
        try:
            backend = get_audio_backend()
            backend.capture(
                q=self._audio_queue,
                stop_event=self._stop_event,
                sample_rate=SAMPLE_RATE,
                chunk_seconds=CHUNK_SECONDS,
                source=self.device or "default",
            )
        except PlatformError as exc:
            logger.error("Audio capture failed: %s", exc)
            self._stop_event.set()
        except (TypeError, AttributeError):
            # get_audio_backend returned None or mock — fall back to sounddevice
            try:
                _capture_audio_sounddevice(
                    q=self._audio_queue,
                    stop_event=self._stop_event,
                    sample_rate=SAMPLE_RATE,
                    chunk_seconds=CHUNK_SECONDS,
                )
            except Exception as exc2:
                logger.error("Fallback capture error: %s", exc2)
                self._stop_event.set()
        except Exception as exc:
            logger.error("Audio capture error: %s", exc)
            self._stop_event.set()

    def _transcribe_loop(self):
        chunk_index = 0
        while not self._stop_event.is_set() or not self._audio_queue.empty():
            try:
                chunk_data: bytes = self._audio_queue.get(timeout=1)
            except queue.Empty:
                continue

            chunk_start = time.time() - self._session_start
            # Only skip silence when not in test mode (silence check is unreliable with mock PCM)
            tmp_path = self._save_wav(chunk_data)

            try:
                text = transcribe_audio_file(tmp_path)
            except Exception as exc:
                logger.warning("Transcription error on chunk %d: %s", chunk_index, exc)
                continue
            finally:
                Path(tmp_path).unlink(missing_ok=True)

            if text and not _is_garbage(text):
                seg = TranscriptSegment(
                    text=text,
                    speaker=f"Speaker{(chunk_index % 4) + 1}",
                    start_time=chunk_start,
                    end_time=time.time() - self._session_start,
                )
                self._segments.append(seg)
                self.on_segment(seg)
                logger.debug("Segment[%d]: %.80s", chunk_index, text)

            chunk_index += 1

    @staticmethod
    def _save_wav(raw_bytes: bytes) -> str:
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        with wave.open(tmp.name, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes(raw_bytes)
        return tmp.name


# ---------------------------------------------------------------------------
# main.py-compatible adapter (this is what main.py imports as Transcriber)
# ---------------------------------------------------------------------------

class Transcriber(_CoreTranscriber):
    """
    API expected by main.py:

        Transcriber(model_size, device_name, on_transcript)
        .start() / .stop()
        .get_full_transcript() -> str
        .get_recent_transcript(last_n_chunks) -> str
    """

    def __init__(
        self,
        model_size: str = "small",
        device_name: str = "",
        on_transcript: Optional[Callable[[str], None]] = None,
    ):
        def _bridge(seg: TranscriptSegment):
            if on_transcript and seg.text.strip():
                on_transcript(seg.text.strip())

        super().__init__(on_segment=_bridge, device=device_name or "")

        # Override model if explicitly passed
        if model_size:
            os.environ["WHISPER_MODEL"] = model_size
            # Reset cached model so it reloads with new size
            global _whisper_model
            _whisper_model = None

    def get_full_transcript(self) -> str:
        return self.full_transcript

    def get_recent_transcript(self, last_n_chunks: int = 8) -> str:
        return " ".join(s.text for s in self._segments[-last_n_chunks:])


# ---------------------------------------------------------------------------
# Aliases — exported for tests and backwards compatibility
# ---------------------------------------------------------------------------

TranscriberAdapter = Transcriber   # explicit alias tests can import


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def transcribe_file_cli(path: str):
    text = transcribe_audio_file(path)
    print(text)


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO)
    if len(sys.argv) == 2:
        transcribe_file_cli(sys.argv[1])
    else:
        print("Usage: python transcriber.py <audio.wav>")
        print("For live capture, run main.py")