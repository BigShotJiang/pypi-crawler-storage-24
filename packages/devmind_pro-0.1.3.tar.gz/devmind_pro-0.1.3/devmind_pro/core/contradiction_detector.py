"""
contradiction_detector.py  -  Detects when meeting discussion contradicts
                               your project documentation in real time.
"""

import re
import json
import time
import warnings
import threading
import requests

# Suppress huggingface_hub FutureWarning about resume_download
warnings.filterwarnings("ignore", category=FutureWarning, module="huggingface_hub")

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.1:8b"


def _parse_json_safe(raw: str) -> dict | None:
    """
    Robustly extract the first valid JSON object from Ollama's response.
    Handles: extra text, multiple objects, markdown fences, trailing data.
    """
    if not raw:
        return None

    # Strip markdown fences
    clean = re.sub(r"```(?:json)?", "", raw).strip()

    # Try direct parse first
    try:
        obj = json.loads(clean)
        if isinstance(obj, dict):
            return obj
    except json.JSONDecodeError:
        pass

    # Find the first { and match its closing }
    start = clean.find("{")
    if start == -1:
        return None

    depth = 0
    for i, ch in enumerate(clean[start:], start):
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    obj = json.loads(clean[start : i + 1])
                    if isinstance(obj, dict):
                        return obj
                except json.JSONDecodeError:
                    pass
                break

    return None


class ContradictionDetector:
    def __init__(
        self,
        rag_engine=None,
        on_contradiction: callable = None,
        check_interval: int = 120,
    ):
        self._rag              = rag_engine
        self._on_contradiction = on_contradiction or print
        self._check_interval   = check_interval
        self._recent_chunks    = []
        self._lock             = threading.Lock()
        self._last_check_time  = 0
        print("[Contradiction] Detector ready.")

    def add_transcript(self, text: str):
        with self._lock:
            self._recent_chunks.append(text)
            if len(self._recent_chunks) > 10:
                self._recent_chunks.pop(0)

        now = time.time()
        if now - self._last_check_time >= self._check_interval:
            self._last_check_time = now
            threading.Thread(target=self._check, daemon=True).start()

    def _check(self):
        with self._lock:
            recent = " ".join(self._recent_chunks[-5:])

        if not recent.strip() or not self._rag:
            return

        context = self._rag.query(recent, n_results=4)
        if not context or "No relevant" in context:
            return

        prompt = f"""You are checking if a meeting discussion contradicts project documentation.

MEETING (last few minutes):
{recent[-1500:]}

PROJECT DOCUMENTATION:
{context}

TASK: Find any DIRECT contradictions where the meeting claims something 
that clearly conflicts with the documentation.

Only flag CLEAR, SPECIFIC contradictions — not vague differences.
Examples of real contradictions:
- Meeting: "deploy on Friday" vs Docs: "Friday deployments are prohibited"
- Meeting: "rate limit is 100" vs Docs: "rate limit is configured at 50"
- Meeting: "use JWT tokens" vs Docs: "authentication uses session cookies"

If NO clear contradiction exists, respond with exactly: null

If contradiction found, respond ONLY with this JSON and nothing else:
{{"claim": "what was said in meeting", "contradiction": "what docs say instead", "source": "doc name or section"}}"""

        try:
            resp = requests.post(
                OLLAMA_URL,
                json={
                    "model": OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False,
                    "options": {"temperature": 0.1, "num_predict": 200},
                },
                timeout=60,
            )
            if resp.status_code != 200:
                return

            raw = resp.json().get("response", "").strip()

            if not raw or raw.lower().startswith("null"):
                return

            result = _parse_json_safe(raw)
            if result and "claim" in result and "contradiction" in result:
                print(f"[Contradiction] Found: '{result['claim']}' vs docs")
                self._on_contradiction(result)

        except Exception as e:
            print(f"[Contradiction] Check error: {e}")


if __name__ == "__main__":
    print("Contradiction detector ready.")
    print("Needs RAGEngine + running meeting to test.")
    