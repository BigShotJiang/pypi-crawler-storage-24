"""
commitment_tracker.py  -  Detects and logs commitments made during meetings.

Detects phrases like:
  "I will...", "We need to...", "By Friday...", "I'll handle...",
  "Someone needs to...", "Action item:", "TODO:", "Let's make sure..."

Shows a running list in the UI and saves to the meeting summary.
"""

import re
import threading
from datetime import datetime


COMMITMENT_PATTERNS = [
    r"\b(I will|I'll|I am going to|I'm going to)\b.{5,80}",
    r"\b(we will|we'll|we are going to|we're going to)\b.{5,80}",
    r"\b(you will|you'll|you need to|you should)\b.{5,80}",
    r"\b(someone needs to|someone should|somebody needs to)\b.{5,80}",
    r"\b(action item|TODO|follow up|follow-up|next step)\b.{0,80}",
    r"\b(by (monday|tuesday|wednesday|thursday|friday|saturday|sunday))\b.{0,60}",
    r"\b(by (tomorrow|next week|end of day|eod|eow|end of week))\b.{0,60}",
    r"\b(let's make sure|make sure|don't forget|remember to)\b.{5,80}",
    r"\b(going to (check|fix|update|review|send|share|create|build|test))\b.{0,60}",
]

COMPILED_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in COMMITMENT_PATTERNS
]


def _extract_commitments(text: str) -> list[str]:
    """Extract commitment phrases from transcript text."""
    found = []
    for pattern in COMPILED_PATTERNS:
        for match in pattern.finditer(text):
            commitment = match.group(0).strip()
            if len(commitment) > 8:
                found.append(commitment)
    return list(set(found))


class CommitmentTracker:
    def __init__(self, on_commitment: callable = None):
        """
        on_commitment: callback({"text": str, "speaker": str, "time": str})
        """
        self._on_commitment = on_commitment or print
        self._commitments = []
        self._lock = threading.Lock()
        print("[Commitments] Tracker started.")

    def check_transcript(self, text: str):
        """Check a transcript chunk for commitments."""
        # Extract speaker if labeled
        speaker = "Unknown"
        clean_text = text
        speaker_match = re.match(r"\[(Speaker \d+)\]\s*(.*)", text, re.DOTALL)
        if speaker_match:
            speaker = speaker_match.group(1)
            clean_text = speaker_match.group(2)

        commitments = _extract_commitments(clean_text)

        for commitment in commitments:
            entry = {
                "text": commitment,
                "speaker": speaker,
                "time": datetime.now().strftime("%H:%M"),
                "full_context": clean_text[:200],
            }

            # Avoid duplicates
            with self._lock:
                existing_texts = [c["text"].lower() for c in self._commitments]
                if commitment.lower() not in existing_texts:
                    self._commitments.append(entry)
                    print(f"[Commitments] {speaker}: '{commitment}'")
                    self._on_commitment(entry)

    def get_all(self) -> list[dict]:
        with self._lock:
            return self._commitments.copy()

    def get_formatted(self) -> str:
        """Return formatted list of all commitments for summary."""
        with self._lock:
            if not self._commitments:
                return "No commitments detected."
            lines = []
            for c in self._commitments:
                lines.append(f"- [{c['time']}] {c['speaker']}: {c['text']}")
            return "\n".join(lines)

    def clear(self):
        with self._lock:
            self._commitments.clear()


if __name__ == "__main__":
    def show(c):
        print(f"  COMMITMENT: [{c['speaker']}] {c['text']}")

    tracker = CommitmentTracker(on_commitment=show)

    test_lines = [
        "[Speaker 1] I will send the API docs by tomorrow.",
        "[Speaker 2] We need to fix the auth bug before Friday.",
        "[Speaker 3] Let me check the database schema.",
        "[Speaker 1] Action item: update the onboarding flow.",
        "[Speaker 4] I'll handle the payment integration.",
        "[Speaker 2] Someone needs to write the test cases.",
    ]

    print("Testing commitment tracker...\n")
    for line in test_lines:
        tracker.check_transcript(line)

    print("\nAll commitments:")
    print(tracker.get_formatted())