"""
codebase_rag.py  —  DevMind Pro
Indexes your actual code files into a local LanceDB vector store.
No ChromaDB. No telemetry. Works on macOS / Windows / Linux.
Supports Ollama (llama) and all other AI_PROVIDER options.

Supported: .py .js .ts .jsx .tsx .java .go .rb .php .cs .cpp .h .swift .kt .vue .html .css .sql .sh
"""

import os
import hashlib
import json
import re
from pathlib import Path

SUPPORTED_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx",
    ".java", ".go", ".rb", ".php", ".cs",
    ".cpp", ".h", ".swift", ".kt", ".vue",
    ".html", ".css", ".sql", ".sh",
}

IGNORE_DIRS = {
    "node_modules", ".git", "__pycache__", ".venv",
    "venv", "dist", "build", ".next", ".nuxt",
    "coverage", ".pytest_cache", "migrations",
    "lance_db", "chroma_db", "__MACOSX",
}


# ── Code chunker ──────────────────────────────────────────────────────────────

def _extract_code_chunks(content: str, filepath: str, chunk_size: int = 60) -> list:
    """
    Split code into meaningful chunks at function/class boundaries.
    Falls back to line-based chunking when no boundary is found.
    """
    lines = content.split("\n")
    chunks = []
    current_chunk: list = []
    current_start = 1

    BOUNDARY = re.compile(
        r"^(def |class |async def |function |const |export |"
        r"public |private |protected |static )"
    )

    for i, line in enumerate(lines, 1):
        is_boundary = bool(BOUNDARY.match(line.strip()))

        if is_boundary and len(current_chunk) >= 10:
            text = "\n".join(current_chunk)
            if text.strip():
                chunks.append({"text": text, "start_line": current_start, "end_line": i - 1})
            current_chunk = [line]
            current_start = i
        else:
            current_chunk.append(line)

        if len(current_chunk) >= chunk_size:
            text = "\n".join(current_chunk)
            if text.strip():
                chunks.append({"text": text, "start_line": current_start, "end_line": i})
            current_chunk = []
            current_start = i + 1

    if current_chunk:
        text = "\n".join(current_chunk)
        if text.strip():
            chunks.append({"text": text, "start_line": current_start, "end_line": len(lines)})

    return chunks


# ── Embedding ─────────────────────────────────────────────────────────────────

_embedder = None

def _get_embedder():
    global _embedder
    if _embedder is None:
        from sentence_transformers import SentenceTransformer
        # Explicitly set device=cpu — prevents meta tensor error on Apple Silicon
        # when sentence-transformers tries to auto-detect MPS and fails
        _embedder = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
    return _embedder

def _embed(texts: list) -> list:
    return _get_embedder().encode(texts, show_progress_bar=False).tolist()


# ── CodebaseRAG ───────────────────────────────────────────────────────────────

class CodebaseRAG:
    """
    LanceDB-backed codebase indexer.
    Public API is identical to the ChromaDB version — main.py needs no changes.
    """

    def __init__(self, codebase_path: str = ".", db_path: str = "./lance_db"):
        self.codebase_path = Path(codebase_path)
        self._db_path      = db_path
        self._index_file   = Path(db_path) / "_code_indexed.json"

        import lancedb
        Path(db_path).mkdir(parents=True, exist_ok=True)
        self._db    = lancedb.connect(db_path)
        self._table = None

        if "codebase" in self._db.table_names():
            self._table = self._db.open_table("codebase")

        self._indexed: dict = {}
        if self._index_file.exists():
            self._indexed = json.loads(self._index_file.read_text())

        print(f"[CodeRAG] Initialised. Codebase: {codebase_path}")

    # ── Ingestion ─────────────────────────────────────────────────────────────

    def ingest_codebase(self):
        files = [
            f for f in self.codebase_path.rglob("*")
            if f.is_file()
            and f.suffix.lower() in SUPPORTED_EXTENSIONS
            and not any(part in IGNORE_DIRS for part in f.parts)
        ]

        if not files:
            print("[CodeRAG] No code files found.")
            return

        print(f"[CodeRAG] Found {len(files)} code file(s). Indexing...")
        indexed = 0

        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                if not content.strip() or len(content) < 50:
                    continue

                file_hash = hashlib.md5(content.encode()).hexdigest()
                key       = str(file_path)

                if self._indexed.get(key) == file_hash:
                    continue  # unchanged — skip silently

                rel_path = str(file_path.relative_to(self.codebase_path))
                chunks   = _extract_code_chunks(content, rel_path)
                if not chunks:
                    continue

                documents = [
                    f"File: {rel_path} (lines {c['start_line']}-{c['end_line']})\n\n{c['text']}"
                    for c in chunks
                ]
                embeddings = _embed(documents)

                rows = [
                    {
                        "id":         f"code_{file_hash}_{i}",
                        "text":       doc,
                        "filepath":   rel_path,
                        "start_line": chunks[i]["start_line"],
                        "end_line":   chunks[i]["end_line"],
                        "extension":  file_path.suffix,
                        "vector":     emb,
                    }
                    for i, (doc, emb) in enumerate(zip(documents, embeddings))
                ]

                if self._table is None:
                    self._table = self._db.create_table("codebase", data=rows)
                else:
                    self._table.add(rows)

                self._indexed[key] = file_hash
                self._index_file.write_text(json.dumps(self._indexed))
                indexed += 1

            except Exception as e:
                print(f"[CodeRAG] Error indexing {file_path}: {e}")

        total = len(self._table) if self._table is not None else 0
        print(f"[CodeRAG] Done. {indexed} new file(s) indexed. {total} total chunks.")

    # ── Query ─────────────────────────────────────────────────────────────────

    def query(self, question: str, n_results: int = 4) -> str:
        if self._table is None or len(self._table) == 0:
            return "No codebase indexed yet."

        q_emb   = _embed([question])[0]
        results = self._table.search(q_emb).limit(n_results).to_list()

        if not results:
            return "No relevant code found."

        parts = [
            f"[{r['filepath']} lines {r['start_line']}-{r['end_line']}]\n```\n{r['text']}\n```"
            for r in results
        ]
        return "\n\n".join(parts)

    def get_stats(self) -> dict:
        count = len(self._table) if self._table is not None else 0
        return {"total_chunks": count}


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "."
    rag  = CodebaseRAG(codebase_path=path)
    rag.ingest_codebase()
    print("\nTest query: 'authentication'")
    print(rag.query("authentication"))