from __future__ import annotations
import os
from pathlib import Path
from typing import Optional

_instance = None

class DevMind:
    def __init__(self, provider="ollama", model="llama3.1:8b",
                 docs_folder="./docs", codebase_folder="",
                 whisper_model="small", whisper_lang="en",
                 my_name="", audio_device="",
                 summaries_folder="./summaries", analysis_interval=60,
                 ollama_base_url="http://localhost:11434"):
        self.provider=provider; self.model=model
        self.docs_folder=docs_folder; self.codebase_folder=codebase_folder
        self.whisper_model=whisper_model; self.whisper_lang=whisper_lang
        self.my_name=my_name; self.audio_device=audio_device
        self.summaries_folder=summaries_folder
        self.analysis_interval=analysis_interval
        self.ollama_base_url=ollama_base_url

    def _apply_env(self):
        os.environ["AI_PROVIDER"]=self.provider
        os.environ["AI_MODEL"]=self.model
        os.environ["OLLAMA_MODEL"]=self.model
        os.environ["OLLAMA_BASE_URL"]=self.ollama_base_url
        os.environ["DOCS_FOLDER"]=self.docs_folder
        os.environ["CODEBASE_FOLDER"]=self.codebase_folder or self.docs_folder
        os.environ["WHISPER_MODEL"]=self.whisper_model
        os.environ["WHISPER_LANG"]=self.whisper_lang
        os.environ["MY_NAME"]=self.my_name
        os.environ["AUDIO_DEVICE"]=self.audio_device
        os.environ["SUMMARY_OUTPUT_DIR"]=self.summaries_folder
        os.environ["ANALYSIS_INTERVAL"]=str(self.analysis_interval)
        os.environ["TOKENIZERS_PARALLELISM"]="false"

    def start(self):
        self._apply_env()
        Path(self.docs_folder).mkdir(parents=True, exist_ok=True)
        Path(self.summaries_folder).mkdir(parents=True, exist_ok=True)
        from devmind_pro.core.assistant import MeetingAssistant
        MeetingAssistant().run()

    def check_dependencies(self):
        from devmind_pro.setup.checker import check_all
        return check_all(self.provider, self.model, self.ollama_base_url)

def configure(provider="ollama", model="llama3.1:8b", docs_folder="./docs", **kwargs):
    global _instance
    _instance = DevMind(provider=provider, model=model, docs_folder=docs_folder, **kwargs)
    return _instance

def start():
    global _instance
    if _instance is None:
        _instance = DevMind()
    _instance.start()
