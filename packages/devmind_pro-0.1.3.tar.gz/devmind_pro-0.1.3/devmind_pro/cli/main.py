import os, sys, click
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

def _banner():
    console.print(Panel.fit("[bold purple]DevMind Pro[/bold purple] — AI Meeting Assistant", border_style="purple"))

@click.group()
@click.version_option(package_name="devmind-pro")
def cli():
    """DevMind Pro — real-time AI meeting assistant."""
    pass

@cli.command()
@click.option("--non-interactive", is_flag=True)
def setup(non_interactive):
    """Interactive setup wizard."""
    _banner()
    from devmind_pro.setup.wizard import run_wizard
    run_wizard(interactive=not non_interactive)

@cli.command()
@click.option("--provider", default=None)
@click.option("--model", default=None)
@click.option("--docs", default=None)
@click.option("--whisper", default=None)
@click.option("--name", default=None)
@click.option("--env", default=".env", show_default=True)
def start(provider, model, docs, whisper, name, env):
    """Launch the meeting assistant."""
    _banner()
    env_path = Path(env)
    if env_path.exists():
        from dotenv import load_dotenv
        load_dotenv(env_path)
        console.print(f"[green]✓[/green] Loaded {env_path}")
    else:
        console.print(f"[yellow]⚠[/yellow] No .env found. Run [bold]devmind setup[/bold] first.")

    if provider: os.environ["AI_PROVIDER"] = provider
    if model:    os.environ["OLLAMA_MODEL"] = model
    if docs:     os.environ["DOCS_FOLDER"] = docs
    if whisper:  os.environ["WHISPER_MODEL"] = whisper
    if name:     os.environ["MY_NAME"] = name
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    from devmind_pro.setup.checker import check_all, print_results
    results = check_all(
        provider=os.getenv("AI_PROVIDER", "ollama"),
        model=os.getenv("OLLAMA_MODEL", "llama3.1:8b"),
        ollama_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
    )
    print_results(results)
    if not results["ok"]:
        console.print("\n[red]✗ Pre-flight failed. Run:[/red] devmind check")
        sys.exit(1)

    console.print("\n[green]✓ Starting DevMind Pro...[/green]\n")
    
    # Change working directory to where .env is so all relative paths work
    env_dir = str(Path(env).resolve().parent)
    os.chdir(env_dir)
    
    from devmind_pro.core.assistant import MeetingAssistant
    MeetingAssistant().run()

@cli.command()
@click.option("--env", default=".env", show_default=True)
def check(env):
    """Check dependencies and services."""
    _banner()
    if Path(env).exists():
        from dotenv import load_dotenv
        load_dotenv(env)
    from devmind_pro.setup.checker import check_all, print_results
    results = check_all(
        provider=os.getenv("AI_PROVIDER", "ollama"),
        model=os.getenv("OLLAMA_MODEL", "llama3.1:8b"),
        ollama_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
    )
    print_results(results)
    if not results["ok"]:
        sys.exit(1)

@cli.command()
@click.option("--env", default=".env", show_default=True)
def config(env):
    """Show current configuration."""
    _banner()
    env_path = Path(env)
    if not env_path.exists():
        console.print(f"[yellow]No .env at {env_path}[/yellow]. Run devmind setup.")
        return
    from dotenv import dotenv_values
    values = dotenv_values(env_path)
    table = Table(title=f"Config: {env_path}", header_style="bold purple")
    table.add_column("Key", style="bold")
    table.add_column("Value")
    for k, v in values.items():
        display = (v[:6]+"..."+v[-4:] if len(v or "")>10 else "***") if "KEY" in k and v else (v or "[dim]not set[/dim]")
        table.add_row(k, display)
    console.print(table)

if __name__ == "__main__":
    cli()
