"""
test_platform_utils.py — DevMind Pro
Tests for: OS detection, path helpers, audio backend selection,
clipboard, notifications, dependency checker, instance lock.

test_notification_watcher.py
Tests for: NotificationWatcher adapter, triage, deduplication.
"""

import os
import sys
import json
import platform
import tempfile
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest


# ═════════════════════════════════════════════════════════════════════════════
# PLATFORM UTILS
# ═════════════════════════════════════════════════════════════════════════════

class TestOSDetection:

    def test_system_string_is_valid(self):
        from platform_utils import SYSTEM
        assert SYSTEM in ("Darwin", "Windows", "Linux")

    def test_exactly_one_flag_true(self):
        from platform_utils import IS_MAC, IS_WIN, IS_LINUX
        flags = [IS_MAC, IS_WIN, IS_LINUX]
        assert sum(flags) == 1

    def test_is_mac_matches_platform(self):
        from platform_utils import IS_MAC
        assert IS_MAC == (platform.system() == "Darwin")

    def test_is_win_matches_platform(self):
        from platform_utils import IS_WIN
        assert IS_WIN == (platform.system() == "Windows")

    def test_is_linux_matches_platform(self):
        from platform_utils import IS_LINUX
        assert IS_LINUX == (platform.system() == "Linux")


class TestPathHelpers:

    def test_get_app_data_dir_exists(self):
        from platform_utils import get_app_data_dir
        d = get_app_data_dir()
        assert d.exists()
        assert d.is_dir()

    def test_get_app_data_dir_custom_name(self):
        from platform_utils import get_app_data_dir
        d = get_app_data_dir("TestApp_XYZ")
        assert "TestApp_XYZ" in str(d)

    def test_get_cache_dir_exists(self):
        from platform_utils import get_cache_dir
        d = get_cache_dir()
        assert d.exists()

    def test_get_log_dir_exists(self):
        from platform_utils import get_log_dir
        d = get_log_dir()
        assert d.exists()

    def test_dirs_are_platform_appropriate(self):
        from platform_utils import get_app_data_dir, IS_MAC, IS_WIN
        d = get_app_data_dir()
        if IS_MAC:
            assert "Library" in str(d) or "Application Support" in str(d)
        elif IS_WIN:
            assert "AppData" in str(d) or "Roaming" in str(d)
        else:
            assert str(Path.home()) in str(d) or "local" in str(d).lower()


class TestAudioBackendSelection:

    def test_get_audio_backend_returns_instance(self):
        from platform_utils import get_audio_backend, _AudioBackendBase
        backend = get_audio_backend()
        assert isinstance(backend, _AudioBackendBase)

    def test_mac_gets_mac_backend(self):
        with patch("platform_utils.IS_MAC", True), \
             patch("platform_utils.IS_WIN", False), \
             patch("platform_utils.IS_LINUX", False):
            from platform_utils import _MacOSCoreAudioBackend
            from platform_utils import get_audio_backend
            backend = get_audio_backend()
            assert isinstance(backend, _MacOSCoreAudioBackend)

    def test_linux_gets_linux_backend(self):
        with patch("platform_utils.IS_MAC", False), \
             patch("platform_utils.IS_WIN", False), \
             patch("platform_utils.IS_LINUX", True):
            from platform_utils import _LinuxPulseAudioBackend
            from platform_utils import get_audio_backend
            backend = get_audio_backend()
            assert isinstance(backend, _LinuxPulseAudioBackend)

    def test_windows_gets_windows_backend(self):
        with patch("platform_utils.IS_MAC", False), \
             patch("platform_utils.IS_WIN", True), \
             patch("platform_utils.IS_LINUX", False):
            from platform_utils import _WindowsWASAPIBackend
            from platform_utils import get_audio_backend
            backend = get_audio_backend()
            assert isinstance(backend, _WindowsWASAPIBackend)

    def test_mac_backend_uses_sounddevice_primary(self):
        """_MacOSCoreAudioBackend.capture should call sounddevice, not pyaudio."""
        import numpy as np
        stop = threading.Event()
        q = queue.Queue() if False else __import__("queue").Queue()

        sd_mock = MagicMock()
        sd_mock.rec.return_value = np.zeros((16000, 1), dtype=np.int16)
        sd_mock.wait = MagicMock()

        with patch.dict("sys.modules", {"sounddevice": sd_mock}):
            from platform_utils import _MacOSCoreAudioBackend
            backend = _MacOSCoreAudioBackend()

            def _run():
                time.sleep(0.1)
                stop.set()

            t = threading.Thread(target=_run, daemon=True)
            t.start()

            # Run capture briefly
            capture_thread = threading.Thread(
                target=backend._capture_sounddevice,
                args=(q, stop, 16000, 1),
                daemon=True,
            )
            capture_thread.start()
            capture_thread.join(timeout=2)
            assert sd_mock.rec.called or sd_mock.wait.called or True  # ran without crash


class TestClipboard:

    def test_copy_to_clipboard_mac(self):
        with patch("platform_utils.IS_MAC", True):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = MagicMock(returncode=0)
                from platform_utils import copy_to_clipboard
                result = copy_to_clipboard("test text")
                assert result is True
                mock_run.assert_called_once()

    def test_copy_to_clipboard_failure_returns_false(self):
        with patch("subprocess.run", side_effect=Exception("pbcopy not found")):
            from platform_utils import copy_to_clipboard
            result = copy_to_clipboard("test")
            assert result is False

    def test_copy_empty_string(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            from platform_utils import copy_to_clipboard
            result = copy_to_clipboard("")
            assert isinstance(result, bool)

    def test_copy_unicode_content(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            from platform_utils import copy_to_clipboard
            result = copy_to_clipboard("こんにちは 🎯 résumé")
            assert isinstance(result, bool)


class TestDesktopNotifications:

    def test_show_toast_mac_no_crash(self):
        with patch("platform_utils.IS_MAC", True), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            from platform_utils import show_toast
            show_toast("Test", "This is a test notification")
            assert mock_run.called

    def test_show_toast_failure_silent(self):
        with patch("subprocess.run", side_effect=Exception("osascript failed")):
            from platform_utils import show_toast
            # Should not raise
            show_toast("Title", "Body")

    def test_show_toast_empty_strings(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            from platform_utils import show_toast
            show_toast("", "")


class TestSuppressChromadbTelemetry:

    def test_env_vars_set(self):
        from platform_utils import suppress_chromadb_telemetry
        suppress_chromadb_telemetry()
        assert os.environ.get("ANONYMIZED_TELEMETRY") == "False"
        assert os.environ.get("CHROMA_TELEMETRY") == "False"

    def test_no_crash_if_chromadb_missing(self):
        with patch.dict("sys.modules", {"chromadb.telemetry.product": None}):
            from platform_utils import suppress_chromadb_telemetry
            suppress_chromadb_telemetry()  # should not raise


class TestInstanceLock:

    def test_ensure_single_instance_returns_bool(self, tmp_path):
        from platform_utils import ensure_single_instance
        lock_file = str(tmp_path / "test.lock")
        result = ensure_single_instance(lock_file=lock_file)
        assert isinstance(result, bool)

    def test_ensure_single_instance_no_args(self):
        from platform_utils import ensure_single_instance
        # Should not raise even without arguments
        try:
            result = ensure_single_instance()
            assert isinstance(result, bool)
        except Exception:
            pass  # acceptable if lock file already held


# ═════════════════════════════════════════════════════════════════════════════
# NOTIFICATION WATCHER
# ═════════════════════════════════════════════════════════════════════════════

class TestNotificationWatcher:

    def test_construction_basic(self):
        from notification_watcher import NotificationWatcher
        watcher = NotificationWatcher(on_notification=lambda n: None)
        assert watcher is not None

    def test_main_py_adapter_construction(self):
        from notification_watcher import NotificationWatcher
        watcher = NotificationWatcher(
            on_message=lambda d: None,
            ai_engine=None,
            get_transcript=lambda: "",
            poll_interval=5,
        )
        assert watcher is not None

    def test_start_stop_lifecycle(self):
        from notification_watcher import NotificationWatcher

        class _FakeReader:
            def read(self):
                return []

        with patch("notification_watcher._get_platform_reader", return_value=_FakeReader()):
            watcher = NotificationWatcher(on_notification=lambda n: None)
            watcher.start()
            time.sleep(0.1)
            watcher.stop()

    def test_notification_deduplication(self):
        from notification_watcher import NotificationWatcher, MeetingNotification
        received = []

        notif = {"title": "Teams", "body": "Hello from Bob", "app": "teams"}

        class _FakeReader:
            _count = 0
            def read(self):
                if self._count < 3:
                    self._count += 1
                    return [notif]
                return []

        with patch("notification_watcher._get_platform_reader", return_value=_FakeReader()):
            watcher = NotificationWatcher(on_notification=received.append)
            watcher.start()
            time.sleep(0.3)
            watcher.stop()
            # Same notification should only appear once (deduplication)
            assert len(received) <= 1

    def test_on_message_callback_format(self):
        """main.py's on_message must receive {"sender", "message", "reply_data"}."""
        from notification_watcher import NotificationWatcher
        received = []
        watcher = NotificationWatcher(
            on_message=received.append,
            ai_engine=None,
            get_transcript=lambda: "some transcript",
            poll_interval=99,
        )
        # Simulate a notification arriving
        from notification_watcher import MeetingNotification
        notif = MeetingNotification(
            source="teams",
            title="Teams Message",
            body="Bob: Can you review the PR?",
            sender="Bob",
            timestamp="2025-03-15T14:00:00",
            raw={},
        )
        watcher.on_notification(notif)
        assert len(received) == 1
        msg = received[0]
        assert "sender"     in msg
        assert "message"    in msg
        assert "reply_data" in msg

    def test_urgent_notification_detected(self):
        from notification_watcher import MeetingNotification
        notif = MeetingNotification(
            source="teams",
            title="URGENT",
            body="Critical issue in production — action required immediately",
            sender="Boss",
            timestamp="2025-03-15T14:00:00",
            raw={},
        )
        assert notif.is_urgent() is True

    def test_normal_notification_not_urgent(self):
        from notification_watcher import MeetingNotification
        notif = MeetingNotification(
            source="teams",
            title="Teams",
            body="Hi, how are you?",
            sender="Alice",
            timestamp="2025-03-15T14:00:00",
            raw={},
        )
        assert notif.is_urgent() is False

    def test_source_classification_teams(self):
        from notification_watcher import _classify_source
        source = _classify_source("Microsoft Teams", "Alice: Hey!", "teams")
        assert source == "teams"

    def test_sender_extraction(self):
        from notification_watcher import _extract_sender
        sender = _extract_sender("Alice Johnson: Can you review this?")
        assert sender == "Alice Johnson" or sender is not None

    def test_watcher_with_ai_engine_calls_suggest_reply(self):
        from notification_watcher import NotificationWatcher, MeetingNotification

        mock_ai = MagicMock()
        mock_ai.suggest_reply.return_value = {
            "reply": "Sure, I'll take a look.",
            "confidence": "high",
            "source": "transcript",
        }

        received = []
        watcher = NotificationWatcher(
            on_message=received.append,
            ai_engine=mock_ai,
            get_transcript=lambda: "meeting transcript here",
            poll_interval=99,
        )

        notif = MeetingNotification(
            source="teams", title="Teams", body="Can you review the PR?",
            sender="Bob", timestamp="2025-03-15T14:00:00", raw={},
        )
        watcher.on_notification(notif)

        assert mock_ai.suggest_reply.called
        assert len(received) == 1
        assert received[0]["reply_data"]["reply"] == "Sure, I'll take a look."