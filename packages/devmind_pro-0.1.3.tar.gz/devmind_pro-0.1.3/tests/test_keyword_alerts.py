"""
test_keyword_alerts.py — DevMind Pro
Tests for: keyword matching, commitment detection, contradiction detection,
speaker balance, _is_greeting, KeywordAlerter adapter, gap detection.
"""

import threading
from unittest.mock import MagicMock
import pytest

from keyword_alerts import (
    _is_greeting, AlertEngine, Alert, KeywordAlerter,
    detect_keywords, USER_KEYWORDS,
)


# ─────────────────────────────────────────────────────────────────────────────
# Helper: fake segment duck-typed to match AlertEngine expectations
# ─────────────────────────────────────────────────────────────────────────────

def _seg(text, speaker="Alice", start=0.0, end=5.0):
    class Seg:
        pass
    s = Seg()
    s.text, s.speaker, s.start_time, s.end_time = text, speaker, start, end
    return s


# ─────────────────────────────────────────────────────────────────────────────
# 1. _is_greeting
# ─────────────────────────────────────────────────────────────────────────────

class TestIsGreeting:
    def test_hello(self):          assert _is_greeting("hello") is True
    def test_hi(self):             assert _is_greeting("hi") is True
    def test_hey(self):            assert _is_greeting("hey") is True
    def test_good_morning(self):   assert _is_greeting("good morning") is True
    def test_good_afternoon(self): assert _is_greeting("good afternoon") is True
    def test_with_punctuation(self): assert _is_greeting("hi!") is True
    def test_hi_with_name(self):   assert _is_greeting("hi Alice") is True

    def test_not_greeting_action(self):
        assert _is_greeting("hi, I have a blocker on the API") is False

    def test_not_greeting_sentence(self):
        assert _is_greeting("there is a critical bug in production") is False

    def test_empty_string(self):   assert _is_greeting("") is False
    def test_case_insensitive(self): assert _is_greeting("HELLO") is True
    def test_whitespace_only(self): assert _is_greeting("   ") is False


# ─────────────────────────────────────────────────────────────────────────────
# 2. detect_keywords
# ─────────────────────────────────────────────────────────────────────────────

class TestDetectKeywords:

    def test_blocker_detected(self):
        result = detect_keywords("We have a deadline on the project.")
        assert "deadline" in result

    def test_deadline_detected(self):
        result = detect_keywords("The deadline is Friday.")
        assert "deadline" in result

    def test_no_match_normal_text(self):
        result = detect_keywords("The weather is nice today.")
        assert result == []

    def test_case_insensitive(self):
        result = detect_keywords("DEADLINE on the API.")
        assert "deadline" in result

    def test_multiple_keywords(self):
        result = detect_keywords("There is a deadline and a blocked here.")
        assert len(result) >= 2

    def test_returns_list(self):
        result = detect_keywords("anything")
        assert isinstance(result, list)


# ─────────────────────────────────────────────────────────────────────────────
# 3. AlertEngine — keyword alerts
# ─────────────────────────────────────────────────────────────────────────────

class TestAlertEngineKeywords:

    def test_blocker_fires_alert(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("We have a deadline on the project."))
        assert any("deadline" in a.message.lower() for a in alerts)

    def test_action_item_fires_alert(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("Action item: Alice to update the docs."))
        assert len(alerts) > 0

    def test_no_alert_on_normal_text(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("The weather is nice today."))
        keyword_alerts = [a for a in alerts if a.kind == "keyword"]
        assert len(keyword_alerts) == 0

    def test_multiple_keywords_in_one_segment(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(
            _seg("There is a deadline and a blocked here.")
        )
        keyword_alerts = [a for a in alerts if a.kind == "keyword"]
        assert len(keyword_alerts) >= 1

    def test_case_insensitive_matching(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("BLOCKER on the DEADLINE."))
        assert len(alerts) > 0

    def test_alert_has_kind_and_message(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("We have a blocker."))
        kw_alerts = [a for a in alerts if a.kind == "keyword"]
        if kw_alerts:
            assert hasattr(kw_alerts[0], "kind")
            assert hasattr(kw_alerts[0], "message")

    def test_no_cooldown_fires_every_time(self):
        """AlertEngine has no cooldown — same keyword fires on every segment."""
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("We have a deadline.", start=0.0, end=5.0))
        engine.process_segment(_seg("Another deadline.", start=5.0, end=10.0))
        kw_alerts = [a for a in alerts if a.kind == "keyword"]
        assert len(kw_alerts) >= 2


# ─────────────────────────────────────────────────────────────────────────────
# 4. Commitment detection
# ─────────────────────────────────────────────────────────────────────────────

class TestCommitmentDetection:

    def test_i_will_detected(self):
        engine = AlertEngine(on_alert=lambda a: None)
        engine.process_segment(_seg("I will send the report by Friday."))
        assert len(engine.get_commitments()) > 0

    def test_ill_detected(self):
        engine = AlertEngine(on_alert=lambda a: None)
        engine.process_segment(_seg("I'll update the Jira ticket."))
        assert len(engine.get_commitments()) > 0

    def test_action_item_detected(self):
        engine = AlertEngine(on_alert=lambda a: None)
        engine.process_segment(_seg("Action item: Bob to fix the bug."))
        commits = engine.get_commitments()
        assert len(commits) > 0

    def test_deadline_extracted(self):
        engine = AlertEngine(on_alert=lambda a: None)
        engine.process_segment(_seg("I'll finish this by Friday."))
        commits = engine.get_commitments()
        if commits:
            assert any(c.deadline for c in commits)

    def test_no_commitment_normal_text(self):
        engine = AlertEngine(on_alert=lambda a: None)
        engine.process_segment(_seg("The sky is blue today."))
        assert engine.get_commitments() == []

    def test_multiple_commitments(self):
        engine = AlertEngine(on_alert=lambda a: None)
        engine.process_segment(_seg("I will handle the deployment.", "Alice", 0, 5))
        engine.process_segment(_seg("I'll review the PR.", "Bob", 5, 10))
        assert len(engine.get_commitments()) >= 2


# ─────────────────────────────────────────────────────────────────────────────
# 5. Contradiction detection
# ─────────────────────────────────────────────────────────────────────────────

class TestContradictionDetection:

    def test_approved_then_rejected(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("The feature has been approved.", "Alice", 0, 5))
        engine.process_segment(_seg("Actually the feature has been rejected.", "Bob", 5, 10))
        contra = [a for a in alerts if a.kind == "contradiction"]
        assert len(contra) > 0

    def test_no_contradiction_consistent(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("We are shipping Friday.", "Alice", 0, 5))
        engine.process_segment(_seg("Good, Friday works.", "Bob", 5, 10))
        contra = [a for a in alerts if a.kind == "contradiction"]
        assert len(contra) == 0


# ─────────────────────────────────────────────────────────────────────────────
# 6. Speaker balance
# ─────────────────────────────────────────────────────────────────────────────

class TestSpeakerBalance:

    def test_speaker_balance_returns_dict(self):
        engine = AlertEngine(on_alert=lambda a: None)
        engine.process_segment(_seg("Hello", "Alice", 0, 3))
        engine.process_segment(_seg("Hi there", "Bob", 3, 5))
        balance = engine.get_speaker_balance()
        assert isinstance(balance, dict)

    def test_dominant_speaker_detected(self):
        engine = AlertEngine(on_alert=lambda a: None)
        for i in range(5):
            engine.process_segment(_seg("talking talking talking", "Alice", i*5, i*5+4))
        engine.process_segment(_seg("one", "Bob", 30, 31))
        balance = engine.get_speaker_balance()
        assert balance.get("Alice", 0) > balance.get("Bob", 0)


# ─────────────────────────────────────────────────────────────────────────────
# 7. KeywordAlerter adapter (main.py API)
# ─────────────────────────────────────────────────────────────────────────────

class TestKeywordAlerterAdapter:

    def test_construction(self):
        alerter = KeywordAlerter(my_name="Alice", on_alert=lambda a: None)
        assert alerter is not None

    def test_check_transcript_fires_callback(self):
        fired = []
        alerter = KeywordAlerter(my_name="Alice", on_alert=fired.append)
        alerter.check_transcript("We have a critical blocker on the API.")
        assert len(fired) > 0

    def test_name_mention_detected(self):
        fired = []
        alerter = KeywordAlerter(my_name="Alice", on_alert=fired.append)
        alerter.check_transcript("Alice, can you handle this?")
        mention = [a for a in fired if "mention" in a.get("kind", "")]
        assert len(mention) > 0

    def test_name_mention_case_insensitive(self):
        fired = []
        alerter = KeywordAlerter(my_name="alice", on_alert=fired.append)
        alerter.check_transcript("ALICE please review the PR.")
        mention = [a for a in fired if "mention" in a.get("kind", "")]
        assert len(mention) > 0

    def test_empty_transcript_no_crash(self):
        alerter = KeywordAlerter(my_name="Alice", on_alert=lambda a: None)
        alerter.check_transcript("")
        alerter.check_transcript("   ")

    def test_no_name_no_mention_alert(self):
        fired = []
        alerter = KeywordAlerter(my_name="", on_alert=fired.append)
        alerter.check_transcript("The budget is at risk.")
        mention = [a for a in fired if "mention" in a.get("kind", "")]
        assert len(mention) == 0

    def test_callback_dict_has_required_keys(self):
        fired = []
        alerter = KeywordAlerter(my_name="", on_alert=fired.append)
        alerter.check_transcript("There is a blocker here.")
        if fired:
            for key in ("keyword", "source", "is_greeting"):
                assert key in fired[0], f"Missing key: {key}"

    def test_greeting_flagged_correctly(self):
        fired = []
        alerter = KeywordAlerter(my_name="Alice", on_alert=fired.append)
        alerter.check_transcript("hello Alice")
        if fired:
            assert fired[0].get("is_greeting") is True

    def test_concurrent_check_transcript(self):
        errors = []
        alerter = KeywordAlerter(my_name="Alice", on_alert=lambda a: None)

        def _call(i):
            try:
                alerter.check_transcript(f"chunk {i} with a blocker")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=_call, args=(i,)) for i in range(20)]
        for t in threads: t.start()
        for t in threads: t.join()
        assert errors == []


# ─────────────────────────────────────────────────────────────────────────────
# 8. Gap detection
# ─────────────────────────────────────────────────────────────────────────────

class TestGapDetection:

    def test_gap_fires_alert(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("first", 0.0, 5.0))
        engine.process_segment(_seg("second", 30.0, 35.0))  # 25s gap
        gap_alerts = [a for a in alerts if a.kind == "gap"]
        assert len(gap_alerts) > 0

    def test_no_gap_for_short_silence(self):
        alerts = []
        engine = AlertEngine(on_alert=alerts.append)
        engine.process_segment(_seg("first",  0.0, 5.0))
        engine.process_segment(_seg("second", 8.0, 13.0))  # 3s gap
        gap_alerts = [a for a in alerts if a.kind == "gap"]
        assert len(gap_alerts) == 0