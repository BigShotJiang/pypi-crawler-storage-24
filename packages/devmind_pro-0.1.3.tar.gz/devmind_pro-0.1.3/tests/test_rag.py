"""
test_rag.py — DevMind Pro
Tests for: LanceDB vector store, document ingestion, chunking,
query retrieval, incremental indexing, edge cases, codebase RAG.
"""

import json
import hashlib
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest
import numpy as np

# Top-level imports — required so autouse fixtures don't block name resolution
from rag_engine import RAGEngine, _chunk_text, _read_text, _read_pdf
from codebase_rag import CodebaseRAG, _extract_code_chunks


# ─────────────────────────────────────────────────────────────────────────────
# Shared embedding mock — injected per-test via monkeypatch
# ─────────────────────────────────────────────────────────────────────────────

def _mock_encoder(n_texts=1):
    m = MagicMock()
    m.encode.side_effect = lambda texts, **kw: np.ones(
        (len(texts) if isinstance(texts, list) else 1, 384), dtype="float32"
    ) * 0.5
    return m


# ─────────────────────────────────────────────────────────────────────────────
# 1. Text chunking
# ─────────────────────────────────────────────────────────────────────────────

class TestChunkText:

    def test_short_text_single_chunk(self):
        # Need enough words to pass the 50-char minimum filter
        text = "hello world " * 10   # 120 chars, well above 50
        result = _chunk_text(text, chunk_size=500)
        assert len(result) == 1

    def test_long_text_multiple_chunks(self):
        text = " ".join([f"word{i}" for i in range(1000)])
        result = _chunk_text(text, chunk_size=100, overlap=20)
        assert len(result) > 1

    def test_overlap_creates_shared_content(self):
        text = " ".join([f"w{i}" for i in range(200)])
        chunks = _chunk_text(text, chunk_size=50, overlap=10)
        if len(chunks) >= 2:
            words0 = set(chunks[0].split())
            words1 = set(chunks[1].split())
            assert len(words0 & words1) > 0

    def test_empty_text_returns_empty(self):
        assert _chunk_text("", chunk_size=100) == []

    def test_whitespace_only_returns_empty(self):
        assert _chunk_text("   \n\n  ", chunk_size=100) == []

    def test_chunks_meet_min_length(self):
        text = " ".join([f"word{i}" for i in range(500)])
        for chunk in _chunk_text(text):
            assert len(chunk.strip()) > 50

    def test_single_word_below_min_filtered(self):
        assert _chunk_text("hi", chunk_size=500) == []

    def test_unicode_text(self):
        text = "hello world content " * 20
        result = _chunk_text(text, chunk_size=500)
        assert isinstance(result, list)


# ─────────────────────────────────────────────────────────────────────────────
# 2. File readers
# ─────────────────────────────────────────────────────────────────────────────

class TestFileReaders:

    def test_read_text_md(self, tmp_path):
        f = tmp_path / "test.md"
        f.write_text("# Title\nSome content here.")
        result = _read_text(str(f))
        assert "Title" in result

    def test_read_text_nonexistent_returns_empty(self):
        result = _read_text("/nonexistent/path/file.txt")
        assert result == ""

    def test_read_text_utf8(self, tmp_path):
        f = tmp_path / "utf8.txt"
        f.write_text("Héllo wörld — unicode ✓", encoding="utf-8")
        result = _read_text(str(f))
        assert "unicode" in result

    def test_read_pdf_invalid_returns_empty(self, tmp_path):
        f = tmp_path / "fake.pdf"
        f.write_bytes(b"not a real pdf")
        result = _read_pdf(str(f))
        assert isinstance(result, str)


# ─────────────────────────────────────────────────────────────────────────────
# 3. RAGEngine — ingestion and query
# ─────────────────────────────────────────────────────────────────────────────

class TestRAGEngineIngestion:

    def test_init_creates_db(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        engine = RAGEngine(docs_folder=str(tmp_path / "docs"),
                           db_path=str(tmp_path / "ldb"))
        assert Path(tmp_path / "ldb").exists()

    def test_ingest_markdown_file(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "readme.md").write_text("# Project\n" + "Important content. " * 60)
        engine = RAGEngine(docs_folder=str(docs), db_path=str(tmp_path / "ldb"))
        engine.ingest_docs()
        assert engine._table is not None
        assert len(engine._table) > 0

    def test_skip_already_indexed(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "file.md").write_text("Content here " * 60)
        db = str(tmp_path / "ldb2")
        engine = RAGEngine(docs_folder=str(docs), db_path=db)
        engine.ingest_docs()
        count1 = len(engine._table)
        engine2 = RAGEngine(docs_folder=str(docs), db_path=db)
        engine2.ingest_docs()
        assert len(engine2._table) == count1

    def test_no_docs_folder_handled(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        engine = RAGEngine(docs_folder=str(tmp_path / "nonexistent"),
                           db_path=str(tmp_path / "ldb3"))
        engine.ingest_docs()   # should not raise

    def test_get_all_doc_names_empty(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        engine = RAGEngine(docs_folder=str(tmp_path),
                           db_path=str(tmp_path / "ldb4"))
        assert engine.get_all_doc_names() == []

    def test_get_all_doc_names_returns_filenames(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        docs = tmp_path / "docs5"
        docs.mkdir()
        (docs / "alpha.md").write_text("Alpha content " * 60)
        (docs / "beta.txt").write_text("Beta content " * 60)
        engine = RAGEngine(docs_folder=str(docs), db_path=str(tmp_path / "ldb5"))
        engine.ingest_docs()
        names = engine.get_all_doc_names()
        assert "alpha.md" in names
        assert "beta.txt" in names

    def test_query_empty_db(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        engine = RAGEngine(docs_folder=str(tmp_path),
                           db_path=str(tmp_path / "ldb6"))
        result = engine.query("what is this project?")
        assert "No" in result or result == ""

    def test_query_returns_relevant_text(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        docs = tmp_path / "docs7"
        docs.mkdir()
        (docs / "auth.md").write_text("Authentication uses JWT tokens. " * 40)
        engine = RAGEngine(docs_folder=str(docs), db_path=str(tmp_path / "ldb7"))
        engine.ingest_docs()
        result = engine.query("how does authentication work?")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_unsupported_file_type_ignored(self, tmp_path, monkeypatch):
        monkeypatch.setattr("rag_engine._embedder", _mock_encoder())
        docs = tmp_path / "docs8"
        docs.mkdir()
        (docs / "image.png").write_bytes(b"\x89PNG\r\n")
        engine = RAGEngine(docs_folder=str(docs), db_path=str(tmp_path / "ldb8"))
        engine.ingest_docs()
        assert engine._table is None or len(engine._table) == 0


# ─────────────────────────────────────────────────────────────────────────────
# 4. CodebaseRAG
# ─────────────────────────────────────────────────────────────────────────────

class TestCodebaseRAG:

    def test_init(self, tmp_path, monkeypatch):
        monkeypatch.setattr("codebase_rag._embedder", _mock_encoder())
        rag = CodebaseRAG(codebase_path=str(tmp_path),
                          db_path=str(tmp_path / "ldb"))
        assert rag is not None

    def test_ingest_python_file(self, tmp_path, monkeypatch):
        monkeypatch.setattr("codebase_rag._embedder", _mock_encoder())
        code = tmp_path / "src"
        code.mkdir()
        (code / "main.py").write_text(
            "def hello():\n    print('hello')\n\n"
            "class Manager:\n    def __init__(self):\n        pass\n" * 5
        )
        rag = CodebaseRAG(codebase_path=str(code), db_path=str(tmp_path / "ldb"))
        rag.ingest_codebase()
        assert rag._table is not None

    def test_ignores_node_modules(self, tmp_path, monkeypatch):
        monkeypatch.setattr("codebase_rag._embedder", _mock_encoder())
        code = tmp_path / "project"
        code.mkdir()
        nm = code / "node_modules" / "pkg"
        nm.mkdir(parents=True)
        (nm / "index.js").write_text("var x = 1;\n" * 30)
        (code / "app.py").write_text("def main():\n    pass\n" * 10)
        rag = CodebaseRAG(codebase_path=str(code), db_path=str(tmp_path / "ldb"))
        rag.ingest_codebase()
        if rag._table:
            import pandas as pd
            df = rag._table.to_pandas()
            assert not any("node_modules" in fp for fp in df["filepath"].tolist())

    def test_get_stats_returns_dict(self, tmp_path, monkeypatch):
        monkeypatch.setattr("codebase_rag._embedder", _mock_encoder())
        rag = CodebaseRAG(codebase_path=str(tmp_path),
                          db_path=str(tmp_path / "ldb"))
        stats = rag.get_stats()
        assert "total_chunks" in stats
        assert isinstance(stats["total_chunks"], int)

    def test_query_empty_db(self, tmp_path, monkeypatch):
        monkeypatch.setattr("codebase_rag._embedder", _mock_encoder())
        rag = CodebaseRAG(codebase_path=str(tmp_path),
                          db_path=str(tmp_path / "ldb"))
        result = rag.query("authentication")
        assert "No" in result or result == ""

    def test_skip_unchanged_files(self, tmp_path, monkeypatch):
        monkeypatch.setattr("codebase_rag._embedder", _mock_encoder())
        code = tmp_path / "src2"
        code.mkdir()
        (code / "utils.py").write_text("def util():\n    pass\n" * 10)
        db = str(tmp_path / "ldb2")
        rag = CodebaseRAG(codebase_path=str(code), db_path=db)
        rag.ingest_codebase()
        count1 = len(rag._table)
        rag2 = CodebaseRAG(codebase_path=str(code), db_path=db)
        rag2.ingest_codebase()
        assert len(rag2._table) == count1


# ─────────────────────────────────────────────────────────────────────────────
# 5. Code chunker
# ─────────────────────────────────────────────────────────────────────────────

class TestCodeChunker:

    def test_splits_at_def(self):
        code = "\n".join([
            "import os", "",
            "def function_one():", "    pass", "",
            "def function_two():", "    return 42",
        ] * 3)
        chunks = _extract_code_chunks(code, "test.py")
        assert len(chunks) >= 1

    def test_chunk_has_required_keys(self):
        code = "def foo():\n    pass\n" * 20
        chunks = _extract_code_chunks(code, "test.py")
        for c in chunks:
            assert "text" in c
            assert "start_line" in c
            assert "end_line" in c

    def test_empty_code_returns_empty(self):
        assert _extract_code_chunks("", "test.py") == []

    def test_large_file_chunked(self):
        code = "x = 1\n" * 500
        chunks = _extract_code_chunks(code, "big.py", chunk_size=60)
        assert len(chunks) > 1