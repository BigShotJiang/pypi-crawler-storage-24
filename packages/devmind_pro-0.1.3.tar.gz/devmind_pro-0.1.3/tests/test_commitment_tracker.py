"""
test_commitment_tracker.py — DevMind Pro
Tests for: _extract_commitments, CommitmentTracker lifecycle,
speaker detection, deduplication, thread safety, edge cases.
"""

import threading
from unittest.mock import MagicMock, patch
import pytest

from commitment_tracker import _extract_commitments, CommitmentTracker


# ─────────────────────────────────────────────────────────────────────────────
# 1. _extract_commitments — regex extraction
# ─────────────────────────────────────────────────────────────────────────────

class TestExtractCommitments:

    def test_i_will_detected(self):
        result = _extract_commitments("I will send the report by tomorrow.")
        assert len(result) > 0

    def test_ill_detected(self):
        result = _extract_commitments("I will handle the deployment.")
        assert len(result) > 0

    def test_we_will_detected(self):
        result = _extract_commitments("we will fix this before the release.")
        assert len(result) > 0

    def test_action_item_detected(self):
        result = _extract_commitments("Action item: update the onboarding docs.")
        assert len(result) > 0

    def test_by_friday_detected(self):
        result = _extract_commitments("We need to ship by Friday.")
        assert len(result) > 0

    def test_by_tomorrow_detected(self):
        result = _extract_commitments("I'll finish this by tomorrow.")
        assert len(result) > 0

    def test_lets_make_sure_detected(self):
        result = _extract_commitments("Let's make sure this is tested before release.")
        assert len(result) > 0

    def test_going_to_fix_detected(self):
        result = _extract_commitments("I'm going to fix the auth bug today.")
        assert len(result) > 0

    def test_someone_needs_to_detected(self):
        result = _extract_commitments("Someone needs to review the PR before merging.")
        assert len(result) > 0

    def test_no_commitment_normal_text(self):
        result = _extract_commitments("The weather is nice today.")
        assert result == []

    def test_empty_string(self):
        result = _extract_commitments("")
        assert result == []

    def test_returns_list(self):
        result = _extract_commitments("I will do this.")
        assert isinstance(result, list)

    def test_deduplication(self):
        # Same pattern appearing twice should not produce duplicates
        text = "I will send it. I will send it."
        result = _extract_commitments(text)
        assert len(result) == len(set(result))

    def test_case_insensitive(self):
        result = _extract_commitments("ACTION ITEM: fix the bug.")
        assert len(result) > 0

    def test_multiple_patterns_same_text(self):
        text = "I will fix the auth bug by Friday. Action item: review the docs."
        result = _extract_commitments(text)
        assert len(result) >= 1

    def test_short_match_filtered(self):
        # Matches shorter than 8 chars should be filtered
        result = _extract_commitments("I'll do")  # too short
        # Either empty or contains only items >8 chars
        for r in result:
            assert len(r.strip()) > 8


# ─────────────────────────────────────────────────────────────────────────────
# 2. CommitmentTracker — lifecycle
# ─────────────────────────────────────────────────────────────────────────────

class TestCommitmentTrackerLifecycle:

    def test_construction_default_callback(self):
        tracker = CommitmentTracker()
        assert tracker is not None

    def test_construction_custom_callback(self):
        cb = MagicMock()
        tracker = CommitmentTracker(on_commitment=cb)
        assert tracker is not None

    def test_get_all_empty_initially(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        assert tracker.get_all() == []

    def test_get_formatted_empty(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        result = tracker.get_formatted()
        assert "No commitments" in result

    def test_clear_empties_list(self):
        fired = []
        tracker = CommitmentTracker(on_commitment=fired.append)
        tracker.check_transcript("I will send the report tomorrow.")
        tracker.clear()
        assert tracker.get_all() == []

    def test_check_transcript_fires_callback(self):
        fired = []
        tracker = CommitmentTracker(on_commitment=fired.append)
        tracker.check_transcript("I will send the API docs by tomorrow.")
        assert len(fired) > 0

    def test_callback_dict_has_required_keys(self):
        fired = []
        tracker = CommitmentTracker(on_commitment=fired.append)
        tracker.check_transcript("I will update the onboarding flow by Friday.")
        if fired:
            for key in ("text", "speaker", "time", "full_context"):
                assert key in fired[0], f"Missing key: {key}"

    def test_commitment_stored_in_list(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will handle the payment integration.")
        assert len(tracker.get_all()) > 0

    def test_get_all_returns_copy(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will fix the auth bug by Friday.")
        result = tracker.get_all()
        original_len = len(result)
        result.clear()
        assert len(tracker.get_all()) == original_len  # original not affected


# ─────────────────────────────────────────────────────────────────────────────
# 3. Speaker detection
# ─────────────────────────────────────────────────────────────────────────────

class TestSpeakerDetection:

    def test_labeled_speaker_extracted(self):
        fired = []
        tracker = CommitmentTracker(on_commitment=fired.append)
        tracker.check_transcript("[Speaker 1] I will send the docs by tomorrow.")
        if fired:
            assert fired[0]["speaker"] == "Speaker 1"

    def test_unlabeled_defaults_to_unknown(self):
        fired = []
        tracker = CommitmentTracker(on_commitment=fired.append)
        tracker.check_transcript("I will send the docs by tomorrow.")
        if fired:
            assert fired[0]["speaker"] == "Unknown"

    def test_speaker_2_extracted(self):
        fired = []
        tracker = CommitmentTracker(on_commitment=fired.append)
        tracker.check_transcript("[Speaker 2] We need to fix the auth bug before Friday.")
        if fired:
            assert fired[0]["speaker"] == "Speaker 2"

    def test_full_context_stored(self):
        fired = []
        tracker = CommitmentTracker(on_commitment=fired.append)
        tracker.check_transcript("[Speaker 1] I will review the PR and then update the docs.")
        if fired:
            assert len(fired[0]["full_context"]) > 0


# ─────────────────────────────────────────────────────────────────────────────
# 4. Deduplication
# ─────────────────────────────────────────────────────────────────────────────

class TestDeduplication:

    def test_same_commitment_not_added_twice(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will send the report by tomorrow.")
        tracker.check_transcript("I will send the report by tomorrow.")
        texts = [c["text"].lower() for c in tracker.get_all()]
        # Each unique text should appear only once
        assert len(texts) == len(set(texts))

    def test_different_commitments_both_stored(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will fix the auth bug.")
        tracker.check_transcript("We will deploy by Friday.")
        assert len(tracker.get_all()) >= 1  # at least one stored

    def test_case_insensitive_dedup(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will send the report.")
        count_before = len(tracker.get_all())
        tracker.check_transcript("I WILL SEND THE REPORT.")
        # Should not add a duplicate
        assert len(tracker.get_all()) == count_before


# ─────────────────────────────────────────────────────────────────────────────
# 5. get_formatted output
# ─────────────────────────────────────────────────────────────────────────────

class TestGetFormatted:

    def test_formatted_contains_speaker(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("[Speaker 1] I will send the docs by tomorrow.")
        formatted = tracker.get_formatted()
        if tracker.get_all():
            assert "Speaker 1" in formatted

    def test_formatted_contains_time(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will send the docs by tomorrow.")
        formatted = tracker.get_formatted()
        if tracker.get_all():
            assert ":" in formatted  # HH:MM format

    def test_formatted_multiline_for_multiple(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will fix bug A.")
        tracker.check_transcript("I'll review PR B.")
        formatted = tracker.get_formatted()
        if len(tracker.get_all()) > 1:
            assert "\n" in formatted


# ─────────────────────────────────────────────────────────────────────────────
# 6. Thread safety
# ─────────────────────────────────────────────────────────────────────────────

class TestThreadSafety:

    def test_concurrent_check_transcript(self):
        errors = []
        tracker = CommitmentTracker(on_commitment=lambda c: None)

        sentences = [
            "I will fix the auth bug by Friday.",
            "We'll deploy to production tomorrow.",
            "Action item: update the onboarding docs.",
            "Someone needs to review the PR.",
            "I'm going to check the database schema.",
        ]

        def _run(i):
            try:
                tracker.check_transcript(sentences[i % len(sentences)])
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=_run, args=(i,)) for i in range(30)]
        for t in threads: t.start()
        for t in threads: t.join()

        assert errors == [], f"Thread errors: {errors}"

    def test_concurrent_get_all(self):
        errors = []
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will send the docs.")

        def _read():
            try:
                _ = tracker.get_all()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=_read) for _ in range(20)]
        for t in threads: t.start()
        for t in threads: t.join()
        assert errors == []


# ─────────────────────────────────────────────────────────────────────────────
# 7. Edge cases
# ─────────────────────────────────────────────────────────────────────────────

class TestEdgeCases:

    def test_empty_transcript(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("")
        assert tracker.get_all() == []

    def test_whitespace_only(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("   \n  ")
        assert tracker.get_all() == []

    def test_very_long_transcript(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        long_text = "I will fix the critical bug by Friday."
        tracker.check_transcript(long_text)  # should not crash

    def test_unicode_transcript(self):
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I'll review the résumé and こんにちは docs.")
        # should not crash

    def test_no_question_mark_needed(self):
        """Commitments don't need question marks — just action phrases."""
        tracker = CommitmentTracker(on_commitment=lambda c: None)
        tracker.check_transcript("I will send you the updated API documentation.")
        assert isinstance(tracker.get_all(), list)