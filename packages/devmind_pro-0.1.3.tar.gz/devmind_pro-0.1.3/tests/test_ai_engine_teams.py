"""
test_ai_engine_teams.py — DevMind Pro
Tests for: ai_engine.py (all 4 providers, _parse_json, AIEngine methods)
           teams_sender.py (_parse_contacts, TeamsSender send/receive)
"""

import json
import os
from unittest.mock import MagicMock, patch
import pytest


# ═════════════════════════════════════════════════════════════════════════════
# AI ENGINE
# ═════════════════════════════════════════════════════════════════════════════

from ai_engine import (
    _parse_json, ask_ai,
    _ask_ollama, _ask_openai, _ask_groq, _ask_gemini,
    AIEngine,
)


# ─────────────────────────────────────────────────────────────────────────────
# 1. _parse_json
# ─────────────────────────────────────────────────────────────────────────────

class TestParseJson:

    def test_clean_list(self):
        result = _parse_json('[{"doubt": "x", "why": "y", "priority": "high"}]', [])
        assert isinstance(result, list)
        assert result[0]["doubt"] == "x"

    def test_clean_dict(self):
        result = _parse_json('{"reply": "hello", "confidence": "high", "source": "docs"}', None)
        assert isinstance(result, dict)
        assert result["reply"] == "hello"

    def test_json_with_markdown_fences(self):
        raw = '```json\n[{"doubt": "x", "why": "y", "priority": "low"}]\n```'
        result = _parse_json(raw, [])
        assert isinstance(result, list)

    def test_json_embedded_in_text(self):
        raw = 'Here is my answer:\n{"reply": "test", "confidence": "medium", "source": "none"}'
        result = _parse_json(raw, None)
        assert result is not None
        assert result["reply"] == "test"

    def test_invalid_json_returns_fallback_list(self):
        result = _parse_json("not json at all", [])
        assert result == []

    def test_invalid_json_returns_fallback_none(self):
        result = _parse_json("not json", None)
        assert result is None

    def test_empty_string_returns_fallback(self):
        result = _parse_json("", [])
        assert result == []

    def test_nested_array(self):
        raw = '[{"doubt": "a"}, {"doubt": "b"}]'
        result = _parse_json(raw, [])
        assert len(result) == 2


# ─────────────────────────────────────────────────────────────────────────────
# 2. Provider functions
# ─────────────────────────────────────────────────────────────────────────────

class TestProviderFunctions:

    def test_ask_ollama_success(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"response": "Ollama response"}
        with patch("ai_engine.requests.post", return_value=mock_resp):
            result = _ask_ollama("test prompt")
            assert result == "Ollama response"

    def test_ask_ollama_connection_error(self):
        import requests as req
        with patch("ai_engine.requests.post", side_effect=req.exceptions.ConnectionError()):
            result = _ask_ollama("test")
            assert result == ""

    def test_ask_ollama_non_200(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        with patch("ai_engine.requests.post", return_value=mock_resp):
            result = _ask_ollama("test")
            assert result == ""

    def test_ask_openai_success(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "choices": [{"message": {"content": "OpenAI response"}}]
        }
        with patch("ai_engine.requests.post", return_value=mock_resp):
            with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
                result = _ask_openai("test prompt")
                assert result == "OpenAI response"

    def test_ask_openai_no_key_returns_empty(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": ""}):
            result = _ask_openai("test")
            assert result == ""

    def test_ask_groq_success(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "choices": [{"message": {"content": "Groq response"}}]
        }
        with patch("ai_engine.requests.post", return_value=mock_resp):
            with patch.dict(os.environ, {"GROQ_API_KEY": "gsk-test"}):
                result = _ask_groq("test prompt")
                assert result == "Groq response"

    def test_ask_groq_no_key_returns_empty(self):
        with patch.dict(os.environ, {"GROQ_API_KEY": ""}):
            result = _ask_groq("test")
            assert result == ""

    def test_ask_gemini_no_key_returns_empty(self):
        with patch.dict(os.environ, {"GEMINI_API_KEY": ""}):
            result = _ask_gemini("test")
            assert result == ""

    def test_ask_ai_routes_ollama(self):
        with patch("ai_engine.AI_PROVIDER", "ollama"):
            with patch("ai_engine._ask_ollama", return_value="ollama") as mock:
                from ai_engine import ask_ai as _ask
                # Call directly via module
                import ai_engine
                old = ai_engine.AI_PROVIDER
                ai_engine.AI_PROVIDER = "ollama"
                try:
                    result = ai_engine.ask_ai("prompt")
                finally:
                    ai_engine.AI_PROVIDER = old

    def test_ask_ai_unknown_provider_falls_back(self):
        import ai_engine
        old = ai_engine.AI_PROVIDER
        ai_engine.AI_PROVIDER = "unknown_xyz"
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"response": "fallback"}
        try:
            with patch("ai_engine.requests.post", return_value=mock_resp):
                result = ai_engine.ask_ai("test")
                assert isinstance(result, str)
        finally:
            ai_engine.AI_PROVIDER = old


# ─────────────────────────────────────────────────────────────────────────────
# 3. AIEngine class
# ─────────────────────────────────────────────────────────────────────────────

class TestAIEngine:

    @pytest.fixture
    def engine(self):
        mock_rag      = MagicMock()
        mock_code_rag = MagicMock()
        mock_rag.query.return_value      = "JWT tokens are used for authentication."
        mock_code_rag.query.return_value = "def authenticate(): return jwt.encode(...)"
        with patch("ai_engine.requests.get"):   # suppress Ollama health check
            return AIEngine(rag_engine=mock_rag, codebase_rag=mock_code_rag)

    def test_construction(self):
        with patch("ai_engine.requests.get"):
            e = AIEngine()
            assert e is not None

    def test_construction_with_rag(self, engine):
        assert engine._rag is not None
        assert engine._code_rag is not None

    def test_suggest_reply_returns_dict(self, engine):
        response = {"reply": "JWT is used.", "confidence": "high", "source": "auth.md"}
        with patch("ai_engine.ask_ai", return_value=json.dumps(response)):
            result = engine.suggest_reply("How does auth work?", "transcript here")
            assert isinstance(result, dict)
            assert "reply" in result

    def test_suggest_reply_has_required_keys(self, engine):
        response = {"reply": "Use JWT.", "confidence": "high", "source": "docs"}
        with patch("ai_engine.ask_ai", return_value=json.dumps(response)):
            result = engine.suggest_reply("auth question", "transcript")
            for key in ("reply", "confidence", "source"):
                assert key in result

    def test_suggest_reply_fallback_on_empty_ai(self, engine):
        with patch("ai_engine.ask_ai", return_value=""):
            result = engine.suggest_reply("What is auth?", "")
            assert isinstance(result, dict)
            assert "reply" in result

    def test_suggest_reply_fallback_on_plain_text(self, engine):
        with patch("ai_engine.ask_ai", return_value="I'll need to check on that."):
            result = engine.suggest_reply("Question?", "")
            assert "reply" in result

    def test_analyse_transcript_returns_list(self, engine):
        doubts = [{"doubt": "gap?", "why": "not clear", "priority": "high"}]
        with patch("ai_engine.ask_ai", return_value=json.dumps(doubts)):
            result = engine.analyse_transcript("Some transcript here")
            assert isinstance(result, list)

    def test_analyse_transcript_empty_returns_empty(self, engine):
        result = engine.analyse_transcript("")
        assert result == []

    def test_analyse_transcript_invalid_json_returns_empty(self, engine):
        with patch("ai_engine.ask_ai", return_value="not json"):
            result = engine.analyse_transcript("transcript text here")
            assert isinstance(result, list)

    def test_detect_question_no_question_mark(self, engine):
        result = engine.detect_question_directed_at_me("No question here", "Alice")
        assert result is None

    def test_detect_question_empty_returns_none(self, engine):
        result = engine.detect_question_directed_at_me("", "Alice")
        assert result is None

    def test_detect_question_null_response(self, engine):
        with patch("ai_engine.ask_ai", return_value="null"):
            result = engine.detect_question_directed_at_me("Alice, can you help?", "Alice")
            assert result is None

    def test_detect_question_valid_response(self, engine):
        response = {"question": "Can you help?", "asked_by": "Bob"}
        with patch("ai_engine.ask_ai", return_value=json.dumps(response)):
            result = engine.detect_question_directed_at_me("Alice, can you help?", "Alice")
            assert result is not None
            assert "question" in result

    def test_what_did_i_miss_empty_returns_message(self, engine):
        result = engine.what_did_i_miss("")
        assert "Nothing" in result or isinstance(result, str)

    def test_what_did_i_miss_returns_string(self, engine):
        with patch("ai_engine.ask_ai", return_value="• Point one\n• Point two\n• Point three"):
            result = engine.what_did_i_miss("Some transcript here")
            assert isinstance(result, str)
            assert len(result) > 0

    def test_what_did_i_miss_ai_error_returns_fallback(self, engine):
        with patch("ai_engine.ask_ai", return_value=""):
            result = engine.what_did_i_miss("some transcript")
            assert isinstance(result, str)

    def test_get_context_uses_rag(self, engine):
        ctx = engine._get_context("authentication")
        assert "JWT" in ctx or "PROJECT DOCS" in ctx

    def test_get_context_includes_code_when_requested(self, engine):
        ctx = engine._get_context("authentication", include_code=True)
        assert len(ctx) > 0

    def test_get_context_no_rag_returns_fallback(self):
        with patch("ai_engine.requests.get"):
            e = AIEngine(rag_engine=None, codebase_rag=None)
        ctx = e._get_context("anything")
        assert "No context" in ctx


# ═════════════════════════════════════════════════════════════════════════════
# TEAMS SENDER
# ═════════════════════════════════════════════════════════════════════════════

from teams_sender import _parse_contacts, TeamsSender, load_contacts_from_env


# ─────────────────────────────────────────────────────────────────────────────
# 4. _parse_contacts
# ─────────────────────────────────────────────────────────────────────────────

class TestParseContacts:

    def test_single_contact(self):
        result = _parse_contacts("Alice:https://hooks.example.com/alice")
        assert "Alice" in result
        assert result["Alice"] == "https://hooks.example.com/alice"

    def test_multiple_contacts(self):
        result = _parse_contacts("Alice:https://a.com,Bob:https://b.com")
        assert "Alice" in result
        assert "Bob" in result

    def test_empty_string(self):
        result = _parse_contacts("")
        assert result == {}

    def test_none_like_empty(self):
        result = _parse_contacts("")
        assert isinstance(result, dict)

    def test_url_with_colons_preserved(self):
        # URLs contain colons — only first colon is split point
        result = _parse_contacts("Rajiv:https://outlook.office.com/webhook/abc:def")
        assert "Rajiv" in result
        assert result["Rajiv"].startswith("https://")

    def test_whitespace_stripped(self):
        result = _parse_contacts("  Alice : https://a.com  ")
        assert "Alice" in result

    def test_contact_names_preserved(self):
        result = _parse_contacts("Team Lead:https://a.com")
        assert "Team Lead" in result


# ─────────────────────────────────────────────────────────────────────────────
# 5. TeamsSender
# ─────────────────────────────────────────────────────────────────────────────

class TestTeamsSender:

    @pytest.fixture
    def sender(self):
        contacts = {
            "Alice": "https://hooks.example.com/alice",
            "Bob":   "https://hooks.example.com/bob",
        }
        return TeamsSender(contacts=contacts)

    def test_construction_with_contacts(self, sender):
        assert "Alice" in sender.contacts
        assert "Bob"   in sender.contacts

    def test_construction_from_env(self):
        with patch.dict(os.environ, {"TEAMS_CONTACTS": "TestUser:https://example.com/hook"}):
            s = TeamsSender()
            assert "TestUser" in s.contacts

    def test_get_contact_names(self, sender):
        names = sender.get_contact_names()
        assert "Alice" in names
        assert "Bob"   in names

    def test_get_contact_names_returns_list(self, sender):
        assert isinstance(sender.get_contact_names(), list)

    def test_send_doubt_success(self, sender):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("teams_sender.requests.post", return_value=mock_resp):
            result = sender.send_doubt("Alice", "What is the rate limit?", "Not in docs")
            assert result is True

    def test_send_doubt_unknown_contact(self, sender):
        result = sender.send_doubt("Unknown Person", "question")
        assert result is False

    def test_send_doubt_http_error(self, sender):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.text = "Internal Server Error"
        with patch("teams_sender.requests.post", return_value=mock_resp):
            result = sender.send_doubt("Alice", "question")
            assert result is False

    def test_send_doubt_network_error(self, sender):
        import requests as req
        with patch("teams_sender.requests.post",
                   side_effect=req.exceptions.ConnectionError("refused")):
            result = sender.send_doubt("Alice", "question")
            assert result is False

    def test_send_doubt_with_why(self, sender):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("teams_sender.requests.post", return_value=mock_resp) as mock_post:
            sender.send_doubt("Alice", "What is the deadline?", why="Not mentioned in docs")
            call_args = mock_post.call_args
            payload = json.loads(call_args[1]["data"])
            # why text should be in the adaptive card body
            card_body = str(payload)
            assert "Not mentioned in docs" in card_body

    def test_send_doubt_without_why(self, sender):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("teams_sender.requests.post", return_value=mock_resp):
            result = sender.send_doubt("Alice", "What is the deadline?")
            assert result is True

    def test_send_simple_message_success(self, sender):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("teams_sender.requests.post", return_value=mock_resp):
            result = sender.send_simple_message("Bob", "Quick update!")
            assert result is True

    def test_send_simple_message_unknown_contact(self, sender):
        result = sender.send_simple_message("NoOne", "hi")
        assert result is False

    def test_send_simple_message_network_error(self, sender):
        import requests as req
        with patch("teams_sender.requests.post",
                   side_effect=req.exceptions.Timeout()):
            result = sender.send_simple_message("Alice", "hi")
            assert result is False

    def test_adaptive_card_format_correct(self, sender):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("teams_sender.requests.post", return_value=mock_resp) as mock_post:
            sender.send_doubt("Alice", "Test doubt")
            payload = json.loads(mock_post.call_args[1]["data"])
            assert payload["type"] == "message"
            assert "attachments" in payload
            card = payload["attachments"][0]["content"]
            assert card["type"] == "AdaptiveCard"

    def test_empty_contacts_no_crash(self):
        sender = TeamsSender(contacts={})
        result = sender.send_doubt("Alice", "question")
        assert result is False

    def test_load_contacts_from_env_empty(self):
        with patch.dict(os.environ, {"TEAMS_CONTACTS": ""}):
            contacts = load_contacts_from_env()
            assert contacts == {}