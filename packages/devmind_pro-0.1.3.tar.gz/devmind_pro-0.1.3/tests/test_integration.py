"""
test_integration.py — DevMind Pro
End-to-end integration tests: full pipeline from audio → transcript →
analysis → summary → email → briefing. No real network calls.
"""

import json
import os
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch, call
import pytest
from conftest import make_wav, make_raw_pcm


# ─────────────────────────────────────────────────────────────────────────────
# 1. Full transcription → keyword → commitment pipeline
# ─────────────────────────────────────────────────────────────────────────────

class TestTranscriptionPipeline:

    def test_segment_flows_to_keyword_alerter(self, mock_whisper):
        """Transcript text must flow: Transcriber → callback → KeywordAlerter."""
        from transcriber import Transcriber as TranscriberAdapter, TranscriptSegment
        from keyword_alerts import KeywordAlerter

        transcript_chunks = []
        alerts_fired = []

        alerter = KeywordAlerter(
            my_name="Alice",
            on_alert=alerts_fired.append,
        )

        def _on_transcript(text: str):
            transcript_chunks.append(text)
            alerter.check_transcript(text)

        adapter = TranscriberAdapter(
            model_size="tiny",
            on_transcript=_on_transcript,
        )

        # Simulate segments arriving
        test_segments = [
            TranscriptSegment("Let's start the meeting.", "Alice", 0.0, 3.0),
            TranscriptSegment("I have a critical blocker on the auth service.", "Bob", 3.0, 7.0),
            TranscriptSegment("I will escalate that by end of day.", "Alice", 7.0, 11.0),
        ]
        for seg in test_segments:
            adapter._segments.append(seg)
            adapter.on_segment(seg)

        assert len(transcript_chunks) == 3
        assert any("blocker" in a.get("keyword","").lower() or
                   "critical" in a.get("keyword","").lower()
                   for a in alerts_fired)

    def test_commitment_detected_in_pipeline(self, mock_whisper):
        from transcriber import Transcriber as TranscriberAdapter, TranscriptSegment
        from keyword_alerts import KeywordAlerter

        commitments = []

        def _on_alert(alert):
            if alert.get("kind") == "commitment":
                commitments.append(alert)

        alerter = KeywordAlerter(my_name="", on_alert=_on_alert)

        adapter = TranscriberAdapter(on_transcript=lambda t: alerter.check_transcript(t))

        seg = TranscriptSegment("I'll send the report by Friday.", "Bob", 0.0, 5.0)
        adapter._segments.append(seg)
        adapter.on_segment(seg)

        # Commitment may come through alerter
        assert True  # structural test — no crash is success

    def test_meeting_summary_receives_all_chunks(self):
        from meeting_summary import MeetingSummary

        ms = MeetingSummary()
        chunks = [
            "Alice: We need to ship the auth feature.",
            "Bob: I have a blocker on the DB migration.",
            "Carol: Decision: soft launch April 15.",
            "Alice: I will resolve the blocker by end of day.",
        ]
        for chunk in chunks:
            ms.add_transcript(chunk)

        full = " ".join(ms._transcript_chunks)
        for chunk in chunks:
            assert chunk in full


# ─────────────────────────────────────────────────────────────────────────────
# 2. RAG → AI engine pipeline
# ─────────────────────────────────────────────────────────────────────────────

class TestRAGPipeline:

    def test_rag_ingest_then_query(self, tmp_path):
        import numpy as np
        mock_model = MagicMock()

        call_count = [0]
        def _fake_encode(texts, **kwargs):
            n = len(texts) if isinstance(texts, list) else 1
            call_count[0] += 1
            # Return slightly different vectors to test retrieval
            base = np.ones((n, 384), dtype="float32") * 0.1
            for i in range(n):
                base[i] += i * 0.001
            return base

        mock_model.encode.side_effect = _fake_encode

        with patch("rag_engine._embedder", mock_model):
            from rag_engine import RAGEngine
            docs = tmp_path / "docs"
            docs.mkdir()
            (docs / "auth.md").write_text(
                "Authentication uses JWT tokens for secure access. " * 40
            )
            (docs / "api.md").write_text(
                "The REST API exposes endpoints for user management. " * 40
            )

            engine = RAGEngine(docs_folder=str(docs), db_path=str(tmp_path / "ldb"))
            engine.ingest_docs()

            result = engine.query("How does authentication work?")
            assert isinstance(result, str)
            assert len(result) > 10
            # Sources should be cited
            assert "auth.md" in result or "From:" in result

    def test_codebase_rag_pipeline(self, tmp_path):
        import numpy as np
        mock_model = MagicMock()
        mock_model.encode.return_value = np.ones((5, 384), dtype="float32") * 0.5

        with patch("codebase_rag._embedder", mock_model):
            from codebase_rag import CodebaseRAG

            code = tmp_path / "src"
            code.mkdir()
            (code / "auth.py").write_text(
                "def authenticate(user, password):\n"
                "    '''JWT-based authentication'''\n"
                "    return generate_token(user)\n\n"
                "def generate_token(user):\n"
                "    import jwt\n"
                "    return jwt.encode({'user': user}, 'secret')\n"
            )

            rag = CodebaseRAG(codebase_path=str(code), db_path=str(tmp_path / "ldb"))
            rag.ingest_codebase()
            result = rag.query("authentication token")
            assert isinstance(result, str)


# ─────────────────────────────────────────────────────────────────────────────
# 3. Summary → Email pipeline
# ─────────────────────────────────────────────────────────────────────────────

class TestSummaryToEmailPipeline:

    TRANSCRIPT = (
        "Alice: Let's review our sprint.\n"
        "Bob: I have a blocker — Stripe isn't working.\n"
        "Alice: I will escalate with infra today.\n"
        "Carol: Decision: soft launch April 15, hard launch April 22.\n"
        "Bob: I'll send the client update by Monday.\n"
        "Alice: Action item: Bob to fix Stripe by April 12.\n"
    )

    SUMMARY_RESPONSE = {
        "tldr": "Sprint review covering April launch timeline and Stripe blocker.",
        "decisions": ["Soft launch April 15", "Hard launch April 22"],
        "action_items": [
            {"who": "Alice", "action": "escalate Stripe issue", "deadline": "today"},
            {"who": "Bob",   "action": "fix Stripe by April 12", "deadline": "April 12"},
            {"who": "Bob",   "action": "send client update", "deadline": "Monday"},
        ],
        "open_questions": ["Will Stripe be fixed in time?"],
        "risks": ["Stripe blocker may delay launch"],
        "next_steps": ["Regroup Thursday to assess Stripe status"],
        "sentiment": "tense",
    }

    EMAIL_RESPONSE = {
        "subject": "Meeting Follow-Up: Sprint Review",
        "greeting": "Hi team,",
        "body": "Here are outcomes from our sprint review.",
        "action_items": [{"who": "Bob", "action": "fix Stripe", "deadline": "April 12"}],
        "decisions": ["Soft launch April 15"],
        "next_steps": ["Regroup Thursday"],
        "closing": "Thanks everyone.",
    }

    def test_summary_then_email(self, tmp_path):
        with patch("meeting_summary._call_ai", return_value=json.dumps(self.SUMMARY_RESPONSE)):
            with patch("followup_email._call_ai", return_value=json.dumps(self.EMAIL_RESPONSE)):
                with patch("meeting_summary.save_summary", return_value=str(tmp_path / "s.md")):
                    from meeting_summary import MeetingSummary, generate_summary, save_summary
                    from followup_email import FollowupEmailGenerator

                    # Step 1: accumulate transcript
                    ms = MeetingSummary()
                    for line in self.TRANSCRIPT.strip().split("\n"):
                        ms.add_transcript(line)

                    # Step 2: generate summary
                    summary = generate_summary(
                        " ".join(ms._transcript_chunks),
                        meeting_title="Sprint Review",
                    )
                    assert summary is not None

                    # Step 3: generate follow-up email
                    mock_draft = MagicMock()
                    mock_draft.body_plain = "Email body"
                    with patch("followup_email.generate_followup_email", return_value=mock_draft):
                        with patch("followup_email.save_email_to_file",
                                   return_value=str(tmp_path / "email.txt")):
                            gen = FollowupEmailGenerator()
                            path = gen.save_and_copy(
                                transcript=" ".join(ms._transcript_chunks),
                                commitments=[
                                    {"who": "Bob", "action": "fix Stripe", "deadline": "April 12"},
                                ],
                                doubts=[],
                            )
                            assert path is not None


# ─────────────────────────────────────────────────────────────────────────────
# 4. Stress tests
# ─────────────────────────────────────────────────────────────────────────────

class TestStress:

    def test_keyword_alerter_1000_chunks(self):
        """AlertEngine must handle 1000 segments without memory explosion or crash."""
        from keyword_alerts import KeywordAlerter
        alerts = []
        alerter = KeywordAlerter(my_name="Alice", on_alert=alerts.append)

        texts = [
            "Normal discussion about the project timeline.",
            "There is a critical blocker on the API service.",
            "I will fix the issue by end of day.",
            "Budget risk identified in Q3 planning.",
            "Alice can you look at this?",
            "The weather is nice today, let's keep going.",
            "Action item: deploy to staging by Thursday.",
            "Decision: go ahead with the soft launch.",
        ]

        for i in range(1000):
            alerter.check_transcript(texts[i % len(texts)])

        # Should not crash; alerts should be reasonable (cooldowns working)
        assert len(alerts) < 1000   # cooldowns prevent spam

    def test_meeting_summary_1000_chunks(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary()
        for i in range(1000):
            ms.add_transcript(f"Speaker {i % 5}: This is spoken content number {i}.")
        assert len(ms._transcript_chunks) == 1000
        full = " ".join(ms._transcript_chunks)
        assert "999" in full

    def test_concurrent_rag_queries(self, tmp_path):
        import numpy as np
        mock_model = MagicMock()
        mock_model.encode.return_value = np.ones((1, 384), dtype="float32") * 0.5

        with patch("rag_engine._embedder", mock_model):
            from rag_engine import RAGEngine
            docs = tmp_path / "docs"
            docs.mkdir()
            (docs / "data.md").write_text("Important project data. " * 100)
            engine = RAGEngine(docs_folder=str(docs), db_path=str(tmp_path / "ldb"))
            engine.ingest_docs()

            errors = []
            results = []

            def _query(q):
                try:
                    r = engine.query(q)
                    results.append(r)
                except Exception as e:
                    errors.append(e)

            threads = [
                threading.Thread(target=_query, args=(f"query {i}",))
                for i in range(20)
            ]
            for t in threads: t.start()
            for t in threads: t.join()

            assert errors == [], f"Concurrent query errors: {errors}"
            assert len(results) == 20

    def test_transcriber_many_segments(self):
        from transcriber import Transcriber, TranscriptSegment
        received = []
        t = Transcriber(on_transcript=received.append)

        for i in range(500):
            seg = TranscriptSegment(f"text {i}", "Speaker", float(i), float(i+1))
            t._segments.append(seg)
            t.on_segment(seg)

        assert len(received) == 500
        assert t.full_transcript.startswith("text 0")
        assert "text 499" in t.full_transcript


# ─────────────────────────────────────────────────────────────────────────────
# 5. Edge cases across modules
# ─────────────────────────────────────────────────────────────────────────────

class TestEdgeCases:

    def test_empty_meeting_summary_graceful(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary()
        result = ms.generate_and_save()
        assert result is None   # no transcript → no save

    def test_followup_email_llm_timeout(self):
        import requests
        with patch("followup_email._call_ai",
                   side_effect=requests.exceptions.Timeout("timed out")):
            from followup_email import FollowupEmailGenerator
            gen = FollowupEmailGenerator()
            result = gen.save_and_copy(
                "some transcript",
                commitments=[],
                doubts=[],
            )
            assert result is None   # graceful failure

    def test_pre_meeting_predictor_llm_failure(self, tmp_path):
        with patch("pre_meeting_predictor._call_ai",
                   side_effect=Exception("Ollama down")):
            from pre_meeting_predictor import PreMeetingPredictor
            p = PreMeetingPredictor(summaries_folder=str(tmp_path))
            try:
                result = p.generate_briefing("planning")
                # Either returns None or raises — both acceptable
            except Exception:
                pass  # expected

    def test_rag_query_with_special_chars(self, tmp_path):
        import numpy as np
        mock_model = MagicMock()
        mock_model.encode.return_value = np.ones((1, 384), dtype="float32")
        with patch("rag_engine._embedder", mock_model):
            from rag_engine import RAGEngine
            engine = RAGEngine(docs_folder=str(tmp_path), db_path=str(tmp_path / "ldb"))
            # Query with special characters should not crash
            result = engine.query("what is <script>alert('xss')</script>?")
            assert isinstance(result, str)

    def test_keyword_alerter_very_long_text(self):
        from keyword_alerts import KeywordAlerter
        alerter = KeywordAlerter(my_name="Alice", on_alert=lambda a: None)
        long_text = "normal word " * 5000 + " blocker " + "normal " * 5000
        alerter.check_transcript(long_text)  # should not crash or OOM

    def test_notification_watcher_unicode_content(self):
        from notification_watcher import NotificationWatcher, MeetingNotification
        received = []
        watcher = NotificationWatcher(
            on_message=received.append,
            ai_engine=None,
            get_transcript=lambda: "",
            poll_interval=99,
        )
        notif = MeetingNotification(
            source="teams",
            title="Teams — こんにちは",
            body="Héllo from Böb: résumé review needed 🎯",
            sender="Böb",
            timestamp="2025-03-15T14:00:00",
            raw={},
        )
        watcher.on_notification(notif)
        assert len(received) == 1
        assert received[0]["sender"] == "Böb"

    def test_transcriber_adapter_model_size_env_set(self):
        from transcriber import Transcriber as TranscriberAdapter
        with patch.dict(os.environ, {}, clear=False):
            adapter = TranscriberAdapter(model_size="base", on_transcript=lambda t: None)
            assert os.environ.get("WHISPER_MODEL") in ("base", "tiny", "small", "medium", "large")