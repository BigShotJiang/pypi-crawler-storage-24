"""
test_meeting_summary_followup_predictor.py — DevMind Pro
Tests for: MeetingSummary adapter, follow-up email generation,
pre-meeting predictor, edge cases, LLM response parsing.
"""

import json
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest


# ─────────────────────────────────────────────────────────────────────────────
# 1. MeetingSummary stateful adapter
# ─────────────────────────────────────────────────────────────────────────────

class TestMeetingSummaryAdapter:

    def test_construction_no_ai_engine(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary(ai_engine=None)
        assert ms is not None

    def test_add_transcript_accumulates(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary()
        ms.add_transcript("First chunk.")
        ms.add_transcript("Second chunk.")
        assert len(ms._transcript_chunks) == 2

    def test_add_empty_transcript_ignored(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary()
        ms.add_transcript("")
        ms.add_transcript("   ")
        assert ms._transcript_chunks == []

    def test_add_doubt_accumulates(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary()
        ms.add_doubt({"doubt": "Is the deadline realistic?"})
        ms.add_doubt({"insight": "Budget risk mentioned twice."})
        assert len(ms._doubts) == 2

    def test_start_stop_auto_save(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary(auto_save_interval=9999)
        ms.start_auto_save()
        assert ms._auto_save_thread is not None
        assert ms._auto_save_thread.is_alive()
        ms.stop()
        ms._auto_save_thread.join(timeout=2)
        assert not ms._auto_save_thread.is_alive()

    def test_generate_and_save_empty_transcript(self, tmp_path):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary()
        result = ms.generate_and_save()
        assert result is None   # nothing to save

    def test_generate_and_save_calls_llm(self, tmp_path):
        mock_summary = MagicMock()
        mock_summary.to_markdown.return_value = "# Summary"
        mock_summary.insights = []

        with patch("meeting_summary.generate_summary", return_value=mock_summary) as mock_gen:
            with patch("meeting_summary.save_summary", return_value=str(tmp_path / "s.md")):
                from meeting_summary import MeetingSummary
                ms = MeetingSummary()
                ms.add_transcript("Alice said we need to ship the feature.")
                result = ms.generate_and_save()
                assert result is not None
                mock_gen.assert_called_once()

    def test_doubts_merged_into_summary(self):
        mock_summary = MagicMock()
        # insights is a MagicMock list — check .append was called with the doubt text
        with patch("meeting_summary.generate_summary", return_value=mock_summary):
            with patch("meeting_summary.save_summary", return_value="/tmp/s.md"):
                from meeting_summary import MeetingSummary
                ms = MeetingSummary()
                ms.add_transcript("some text here")
                ms.add_doubt({"doubt": "risk of delay"})
                # Verify doubt was stored before generate_and_save
                assert len(ms._doubts) == 1
                assert ms._doubts[0]["doubt"] == "risk of delay"
                ms.generate_and_save()

    def test_thread_safe_add_transcript(self):
        from meeting_summary import MeetingSummary
        ms = MeetingSummary()
        errors = []

        def _add(i):
            try:
                ms.add_transcript(f"chunk {i}")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=_add, args=(i,)) for i in range(50)]
        for t in threads: t.start()
        for t in threads: t.join()
        assert errors == []
        assert len(ms._transcript_chunks) == 50


# ─────────────────────────────────────────────────────────────────────────────
# 2. generate_summary function
# ─────────────────────────────────────────────────────────────────────────────

class TestGenerateSummary:

    SAMPLE_TRANSCRIPT = (
        "Alice: We need to ship the auth feature.\n"
        "Bob: I have a blocker on the DB migration.\n"
        "Alice: I will resolve the blocker by end of day.\n"
        "Carol: Decision: soft launch April 15.\n"
    )

    MOCK_LLM_RESPONSE = {
        "tldr": "Sprint planning meeting focused on April launch.",
        "decisions": ["Soft launch April 15"],
        "action_items": [{"who": "Alice", "action": "resolve DB blocker", "deadline": "EOD"}],
        "open_questions": ["Is the migration safe?"],
        "risks": ["DB migration may delay launch"],
        "next_steps": ["Reconvene Thursday"],
        "sentiment": "neutral",
    }

    def test_returns_summary_object(self):
        with patch("meeting_summary._call_ai", return_value=json.dumps(self.MOCK_LLM_RESPONSE)):
            from meeting_summary import generate_summary
            result = generate_summary(self.SAMPLE_TRANSCRIPT)
            assert result is not None

    def test_summary_has_tldr(self):
        with patch("meeting_summary._call_ai", return_value=json.dumps(self.MOCK_LLM_RESPONSE)):
            from meeting_summary import generate_summary
            result = generate_summary(self.SAMPLE_TRANSCRIPT)
            assert hasattr(result, "tldr") or hasattr(result, "executive_summary")

    def test_summary_to_dict(self):
        with patch("meeting_summary._call_ai", return_value=json.dumps(self.MOCK_LLM_RESPONSE)):
            from meeting_summary import generate_summary
            result = generate_summary(self.SAMPLE_TRANSCRIPT)
            d = result.to_dict()
            assert isinstance(d, dict)

    def test_summary_to_markdown(self):
        with patch("meeting_summary._call_ai", return_value=json.dumps(self.MOCK_LLM_RESPONSE)):
            from meeting_summary import generate_summary
            result = generate_summary(self.SAMPLE_TRANSCRIPT)
            md = result.to_markdown()
            assert isinstance(md, str)
            assert "#" in md   # has markdown headers

    def test_malformed_llm_response_handled(self):
        with patch("meeting_summary._call_ai", return_value="not json at all {{{{"):
            from meeting_summary import generate_summary
            # Should not raise — should return a default/empty summary
            try:
                result = generate_summary(self.SAMPLE_TRANSCRIPT)
                assert result is not None
            except Exception as e:
                pytest.fail(f"Malformed LLM response raised: {e}")

    def test_llm_with_markdown_fences_stripped(self):
        fenced = "```json\n" + json.dumps(self.MOCK_LLM_RESPONSE) + "\n```"
        with patch("meeting_summary._call_ai", return_value=fenced):
            from meeting_summary import generate_summary
            result = generate_summary(self.SAMPLE_TRANSCRIPT)
            assert result is not None

    def test_save_summary_markdown(self, tmp_path):
        with patch("meeting_summary._call_ai", return_value=json.dumps(self.MOCK_LLM_RESPONSE)):
            with patch.dict("os.environ", {"SUMMARY_OUTPUT_DIR": str(tmp_path)}):
                from meeting_summary import generate_summary, save_summary
                result = generate_summary(self.SAMPLE_TRANSCRIPT)
                path = save_summary(result, fmt="markdown")
                assert Path(path).exists()
                content = Path(path).read_text()
                assert len(content) > 10

    def test_save_summary_json(self, tmp_path):
        with patch("meeting_summary._call_ai", return_value=json.dumps(self.MOCK_LLM_RESPONSE)):
            with patch.dict("os.environ", {"SUMMARY_OUTPUT_DIR": str(tmp_path)}):
                from meeting_summary import generate_summary, save_summary
                result = generate_summary(self.SAMPLE_TRANSCRIPT)
                path = save_summary(result, fmt="json")
                assert Path(path).exists()
                data = json.loads(Path(path).read_text())
                assert isinstance(data, dict)


# ─────────────────────────────────────────────────────────────────────────────
# 3. FollowupEmailGenerator adapter
# ─────────────────────────────────────────────────────────────────────────────

class TestFollowupEmailGenerator:

    MOCK_EMAIL_RESPONSE = {
        "subject": "Meeting Follow-Up: Sprint Planning",
        "greeting": "Hi team,",
        "body": "Here are the key outcomes from today's meeting.",
        "action_items": [{"who": "Alice", "action": "resolve blocker", "deadline": "EOD"}],
        "decisions": ["Soft launch April 15"],
        "next_steps": ["Regroup Thursday"],
        "closing": "Please reach out with any questions.",
    }

    def test_construction(self):
        from followup_email import FollowupEmailGenerator
        gen = FollowupEmailGenerator()
        assert gen is not None

    def test_save_and_copy_returns_path(self, tmp_path):
        mock_draft = MagicMock()
        mock_draft.body_plain = "Email body text"
        mock_draft.subject    = "Test Subject"

        with patch("followup_email.generate_followup_email", return_value=mock_draft):
            with patch("followup_email.save_email_to_file", return_value=str(tmp_path / "email.txt")):
                from followup_email import FollowupEmailGenerator
                gen = FollowupEmailGenerator()
                result = gen.save_and_copy(
                    transcript="Alice: We need to ship.",
                    commitments=[{"who": "Alice", "action": "ship feature", "deadline": "EOD"}],
                    doubts=[],
                )
                assert result is not None

    def test_save_and_copy_empty_transcript(self, tmp_path):
        """Empty transcript should still attempt email generation gracefully."""
        mock_draft = MagicMock()
        mock_draft.body_plain = ""
        with patch("followup_email.generate_followup_email", return_value=mock_draft):
            with patch("followup_email.save_email_to_file", return_value=str(tmp_path / "e.txt")):
                from followup_email import FollowupEmailGenerator
                gen = FollowupEmailGenerator()
                result = gen.save_and_copy("", [], [])
                # Should not crash — may return None or path
                assert result is None or isinstance(result, str)

    def test_commitments_normalised(self, tmp_path):
        """Various commitment dict formats should all be accepted."""
        mock_draft = MagicMock()
        mock_draft.body_plain = "body"
        captured = []

        def _fake_generate(transcript, commitments, **kwargs):
            captured.extend(commitments)
            return mock_draft

        with patch("followup_email.generate_followup_email", side_effect=_fake_generate):
            with patch("followup_email.save_email_to_file", return_value="/tmp/e.txt"):
                from followup_email import FollowupEmailGenerator
                gen = FollowupEmailGenerator()
                gen.save_and_copy(
                    "text",
                    commitments=[
                        {"speaker": "Alice",  "action": "do A", "deadline": "Monday"},
                        {"owner": "Bob",      "action": "do B"},
                        {"who": "Carol",      "action": "do C", "deadline": "EOD"},
                    ],
                    doubts=[],
                )
                for c in captured:
                    assert "who" in c
                    assert "action" in c


# ─────────────────────────────────────────────────────────────────────────────
# 4. generate_followup_email function
# ─────────────────────────────────────────────────────────────────────────────

class TestGenerateFollowupEmail:

    MOCK_RESPONSE = {
        "subject": "Follow-Up: Sprint Planning",
        "greeting": "Hi team,",
        "body": "Great meeting today.",
        "action_items": [],
        "decisions": [],
        "next_steps": [],
        "closing": "Thanks!",
    }

    def test_returns_email_object(self):
        with patch("followup_email._call_ai", return_value=json.dumps(self.MOCK_RESPONSE)):
            from followup_email import generate_followup_email
            result = generate_followup_email(
                transcript="Alice: Let's ship this.",
                commitments=[],
                decisions=[],
            )
            assert result is not None

    def test_email_has_subject(self):
        with patch("followup_email._call_ai", return_value=json.dumps(self.MOCK_RESPONSE)):
            from followup_email import generate_followup_email
            result = generate_followup_email("transcript text", [], [])
            assert hasattr(result, "subject")
            assert "Sprint Planning" in result.subject

    def test_plain_text_output(self):
        with patch("followup_email._call_ai", return_value=json.dumps(self.MOCK_RESPONSE)):
            from followup_email import generate_followup_email
            result = generate_followup_email("transcript", [], [])
            text = result.body_plain
            assert isinstance(text, str)
            assert len(text) > 0

    def test_html_output(self):
        with patch("followup_email._call_ai", return_value=json.dumps(self.MOCK_RESPONSE)):
            from followup_email import generate_followup_email
            result = generate_followup_email("transcript", [], [])
            if hasattr(result, "body_html"):
                html = result.body_html
                assert "<" in html

    def test_with_action_items(self):
        response = dict(self.MOCK_RESPONSE)
        response["action_items"] = [
            {"who": "Alice", "action": "fix bug", "deadline": "Friday"}
        ]
        with patch("followup_email._call_ai", return_value=json.dumps(response)):
            from followup_email import generate_followup_email
            result = generate_followup_email("transcript", [{"who":"Alice","action":"fix bug"}], [])
            assert result is not None


# ─────────────────────────────────────────────────────────────────────────────
# 5. PreMeetingPredictor adapter
# ─────────────────────────────────────────────────────────────────────────────

class TestPreMeetingPredictor:

    MOCK_BRIEFING_RESPONSE = {
        "executive_summary": "Sprint review focusing on April launch.",
        "predicted_topics": ["Stripe blocker", "April launch timeline", "Budget"],
        "open_action_items": [],
        "potential_blockers": ["Stripe integration not complete"],
        "suggested_questions": ["Is the DB migration safe?"],
        "key_decisions_needed": ["Go/no-go for April 15"],
        "background_context": "Team has been working on launch prep for 3 weeks.",
        "recommended_prep": ["Review Stripe docs", "Check migration logs"],
    }

    def test_construction(self, tmp_path):
        from pre_meeting_predictor import PreMeetingPredictor
        p = PreMeetingPredictor(summaries_folder=str(tmp_path))
        assert p is not None

    def test_generate_briefing_returns_dict(self, tmp_path):
        with patch("pre_meeting_predictor._call_ai",
                   return_value=json.dumps(self.MOCK_BRIEFING_RESPONSE)):
            from pre_meeting_predictor import PreMeetingPredictor
            p = PreMeetingPredictor(summaries_folder=str(tmp_path))
            result = p.generate_briefing(topic_hint="Sprint Review")
            assert isinstance(result, dict)

    def test_briefing_has_required_keys(self, tmp_path):
        with patch("pre_meeting_predictor._call_ai",
                   return_value=json.dumps(self.MOCK_BRIEFING_RESPONSE)):
            from pre_meeting_predictor import PreMeetingPredictor
            p = PreMeetingPredictor(summaries_folder=str(tmp_path))
            result = p.generate_briefing()
            for key in ("likely_questions", "unresolved_from_last",
                        "prepare_to_explain", "raw_briefing"):
                assert key in result, f"Missing key: {key}"

    def test_save_briefing_from_dict(self, tmp_path):
        with patch("pre_meeting_predictor._call_ai",
                   return_value=json.dumps(self.MOCK_BRIEFING_RESPONSE)):
            from pre_meeting_predictor import PreMeetingPredictor
            p = PreMeetingPredictor(summaries_folder=str(tmp_path))
            briefing = p.generate_briefing()
            path = p.save_briefing(briefing)
            assert Path(path).exists()

    def test_loads_past_summaries(self, tmp_path):
        """Past summary JSONs in the folder should be loaded."""
        summary = {
            "meeting_title": "Last Sprint",
            "date": "2025-03-01",
            "tldr": "Team shipped auth.",
            "decisions": ["Ship auth by March"],
            "action_items": [{"who": "Bob", "action": "fix tests", "deadline": "March 5"}],
            "risks": [],
        }
        (tmp_path / "summary_20250301.json").write_text(json.dumps(summary))

        with patch("pre_meeting_predictor._call_ai",
                   return_value=json.dumps(self.MOCK_BRIEFING_RESPONSE)) as mock_ai:
            from pre_meeting_predictor import PreMeetingPredictor
            p = PreMeetingPredictor(summaries_folder=str(tmp_path))
            p.generate_briefing()
            # LLM should have been called with the past summary in the prompt
            assert mock_ai.called

    def test_empty_summaries_folder(self, tmp_path):
        """No past summaries → should still generate a briefing."""
        with patch("pre_meeting_predictor._call_ai",
                   return_value=json.dumps(self.MOCK_BRIEFING_RESPONSE)):
            from pre_meeting_predictor import PreMeetingPredictor
            p = PreMeetingPredictor(summaries_folder=str(tmp_path))
            result = p.generate_briefing("Q4 Planning")
            assert isinstance(result, dict)

    def test_rag_engine_doc_names_used(self, tmp_path):
        """If rag_engine provided, its doc names appear in context."""
        mock_rag = MagicMock()
        mock_rag.get_all_doc_names.return_value = ["sprint_notes.md", "roadmap.pdf"]

        with patch("pre_meeting_predictor._call_ai",
                   return_value=json.dumps(self.MOCK_BRIEFING_RESPONSE)) as mock_ai:
            from pre_meeting_predictor import PreMeetingPredictor
            p = PreMeetingPredictor(rag_engine=mock_rag, summaries_folder=str(tmp_path))
            p.generate_briefing("planning")
            call_prompt = mock_ai.call_args[0][0]
            assert "sprint_notes.md" in call_prompt or mock_rag.get_all_doc_names.called