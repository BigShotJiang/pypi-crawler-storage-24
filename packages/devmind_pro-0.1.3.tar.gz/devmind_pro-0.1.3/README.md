# DevMind Pro

Real-time AI meeting assistant — transcription, contradiction detection, RAG-powered replies, Teams integration.

[![PyPI version](https://badge.fury.io/py/devmind-pro.svg)](https://badge.fury.io/py/devmind-pro)
[![Python 3.11](https://img.shields.io/badge/python-3.11-blue.svg)](https://www.python.org/downloads/)

---

## Quick Install

```bash
pip install devmind-pro
devmind setup      # interactive wizard — configures everything
devmind start      # launch the assistant
```

---

## What it does

| Feature | Description |
|---------|-------------|
| 🎙️ Live transcription | Whisper-powered, works offline |
| 🔍 Contradiction detection | Flags when meeting discussion contradicts your docs |
| 💬 AI reply suggestions | Suggests answers to questions directed at you |
| 📱 Teams integration | Catches incoming Teams messages, suggests replies |
| 📋 Commitments tracker | Tracks "I will..." promises made in the meeting |
| 🎯 Pre-meeting briefing | Generates briefing from past summaries + docs |
| 📝 Auto summary | Saves meeting summary as markdown + JSON |

---

## Requirements

| Component | Version |
|-----------|---------|
| Python | **3.11.x** (not 3.12+) |
| macOS | Ventura 13+ (Apple Silicon M1/M2/M3) |
| Ollama | Latest |
| RAM | 16 GB recommended |

> **Windows / Linux**: Core functionality works. Replace `brew` commands with your package manager.

---

## Full Setup Guide

### Step 1 — System dependencies

**macOS:**
```bash
brew install portaudio python@3.11
# Install Ollama from https://ollama.com/download
```

**Windows:**
```powershell
# Python 3.11: https://www.python.org/downloads/release/python-3119/
# Ollama: https://ollama.com/download
pip install pipwin && pipwin install pyaudio
```

**Linux:**
```bash
sudo apt install python3.11 python3.11-venv portaudio19-dev
curl -fsSL https://ollama.com/install.sh | sh
```

### Step 2 — Pull AI model

```bash
ollama serve                    # start Ollama (separate terminal)
ollama pull llama3.1:8b         # 4.9GB — do this once
```

### Step 3 — Install DevMind Pro

```bash
python3.11 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install torch first (prevents version conflicts)
pip install torch==2.2.2 torchaudio==2.2.2
pip install sentence-transformers==3.0.1 transformers==4.41.2 \
            tokenizers==0.19.1 huggingface-hub==0.23.4
pip install devmind-pro
pip uninstall torchvision -y    # remove if pulled in
```

### Step 4 — Setup and run

```bash
devmind setup      # interactive wizard — creates .env, checks everything
devmind check      # verify all dependencies
devmind start      # launch!
```

---

## CLI Commands

```bash
devmind setup              # first-time interactive setup wizard
devmind start              # launch the meeting assistant
devmind start --env /path/to/.env   # use specific config file
devmind check              # pre-flight dependency check
devmind config             # show current configuration
devmind --version          # show version
```

---

## AI Provider Options

Change `AI_PROVIDER` in `.env` to switch:

| Provider | Value | Notes |
|----------|-------|-------|
| Ollama (default) | `ollama` | Free, local, private |
| OpenAI | `openai` | Fast, needs API key |
| Gemini | `gemini` | Free tier available |
| Groq | `groq` | Very fast, free tier |

```properties
# Groq (fastest free option)
AI_PROVIDER=groq
GROQ_API_KEY=your_key
GROQ_MODEL=llama3-70b-8192

# OpenAI
AI_PROVIDER=openai
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4o-mini

# Any Ollama model
OLLAMA_MODEL=llama3.2:1b    # smallest/coolest
OLLAMA_MODEL=phi3:mini       # Microsoft efficient model
OLLAMA_MODEL=mistral:7b      # fast
```

---

## Teams Integration

DevMind reads incoming Teams notifications automatically (macOS).

To enable sending replies to teammates, add their emails to `.env`:
```properties
TEAMS_CONTACTS=Rajiv:rajiv@company.com,Arif:arif@company.com
```

Clicking "Send to Rajiv" opens Teams in their chat with the message copied to clipboard — just press `Cmd+V` + `Enter`.

---

## Whisper Models

| Model | Size | Speed | Use for |
|-------|------|-------|---------|
| `tiny` | 75MB | Fastest | Testing |
| `small` | 250MB | Fast | Daily use (default) |
| `medium` | 750MB | Medium | Accented speech |
| `large` | 1.5GB | Slow | Critical meetings |

```properties
WHISPER_MODEL=small
WHISPER_LANG=en
```

---

## Project Docs (RAG)

Put your project documents in `./docs/`. Supported: `.md`, `.txt`, `.pdf`, `.docx`

DevMind uses these for:
- Contradiction detection (flags when meeting discussion conflicts with docs)
- Context-aware reply suggestions
- Pre-meeting briefings

---

## SDK Usage

```python
import devmind_pro as dm

dm.configure(
    provider="ollama",
    model="llama3.1:8b",
    docs_folder="./my_docs",
    my_name="Jai",
)
dm.start()
```

---

## Troubleshooting

**`404 Not Found` on Ollama**
```bash
ollama serve          # start Ollama
ollama list           # check model name matches OLLAMA_MODEL in .env
```

**`Cannot copy out of meta tensor`**
```bash
pip install sentence-transformers==3.0.1 transformers==4.41.2 \
            tokenizers==0.19.1 huggingface-hub==0.23.4 --force-reinstall
pip uninstall torchvision -y
```

**Garbage transcription** — add to `.env`:
```properties
WHISPER_LANG=en
TOKENIZERS_PARALLELISM=false
```

**Teams messages not appearing** — ensure macOS permission:
System Settings → Privacy & Security → Automation → Terminal → System Events ✓
systen Settings - privacy & security _ all discs - terminal or vs code 

---

## License

MIT