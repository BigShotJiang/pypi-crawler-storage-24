"""
🤖 ClawBot - Interactive Browser Automation CLI
Powered by browser-use + Your AI of Choice

Install: pip install clawbot
Run: clawbot
"""

import asyncio
import os
import subprocess
import sys
import time
from pathlib import Path
import logging
from rich.live import Live
from rich.panel import Panel

# Hide background timeout errors from browser-use/bubus frameworks
logging.getLogger('bubus').setLevel(logging.FATAL)
logging.getLogger('bubus.service').setLevel(logging.FATAL)
logging.getLogger('browser_use.browser').setLevel(logging.FATAL)
logging.getLogger('browser_use.browser.session').setLevel(logging.FATAL)
logging.getLogger('BrowserSession').setLevel(logging.FATAL)

class PanelLogHandler(logging.Handler):
    def __init__(self, max_lines=10):
        super().__init__()
        self.max_lines = max_lines
        self.logs = [""] * max_lines  # Pre-fill to keep height fixed
        self.live = None
        self.setFormatter(logging.Formatter('%(message)s'))

    def emit(self, record):
        try:
            msg = self.format(record)
            if not msg.strip(): return
            
            # Clean up the output to look prettier
            if "EVAL:" in msg.upper() or "EVALUATE:" in msg.upper():
                msg = f"[bold green]{msg}[/bold green]"
            elif "MEMORY:" in msg.upper():
                msg = f"[bold magenta]{msg}[/bold magenta]"
            elif "NEXT GOAL:" in msg.upper():
                msg = f"[bold yellow]{msg}[/bold yellow]"
            elif "ACTION:" in msg.upper() or "CLICK:" in msg.upper() or "NAVIGATE:" in msg.upper():
                msg = f"[bold cyan]{msg}[/bold cyan]"

            # Split multi-line messages so they don't break the height limit
            for line in msg.split('\n'):
                # Trim overly long lines to prevent text wrapping from expanding the box height
                if len(line) > 110:
                    line = line[:107] + "..."
                self.logs.append(line)
            
            # Keep exactly max_lines
            self.logs = self.logs[-self.max_lines:]
            
            if self.live:
                content = "\n".join(self.logs)
                self.live.update(Panel(content, title="🧠 Agent", border_style="cyan", subtitle="[dim]Live Logs[/dim]", width=115))
        except Exception:
            pass


def _get_env_file() -> Path:
    """Get the .env file path in user's home directory."""
    env_dir = Path.home() / '.clawbot'
    env_dir.mkdir(exist_ok=True)
    return env_dir / '.env'


def _load_env():
    """Load environment variables from .env file."""
    from dotenv import load_dotenv
    env_file = _get_env_file()
    if env_file.exists():
        load_dotenv(env_file)


def _get_style():
    """Get InquirerPy style."""
    from InquirerPy.utils import InquirerPyStyle
    return InquirerPyStyle({
        'pointer': '#00d4ff bold',
        'highlighted': '#00d4ff bold',
        'question': 'bold',
        'answer': '#00d4ff bold',
        'questionmark': '#ff6b35 bold',
    })


# ─── AI Providers & Models ────────────────────────────────────────────
PROVIDERS = {
    '🟢 Google Gemini': {
        'class': 'ChatGoogle',
        'env_key': 'GOOGLE_API_KEY',
        'models': [
            'gemini-2.5-flash',
            'gemini-2.5-pro',
            'gemini-2.0-flash',
            'gemini-flash-lite-latest',
        ],
    },
    '🔵 OpenAI (ChatGPT)': {
        'class': 'ChatOpenAI',
        'env_key': 'OPENAI_API_KEY',
        'models': [
            'gpt-4o',
            'gpt-4o-mini',
            'o3-mini',
            'o4-mini',
            'gpt-4.1-mini',
        ],
    },
    '🌙 Kimi (Moonshot AI)': {
        'class': 'ChatOpenAI',
        'env_key': 'MOONSHOT_API_KEY',
        'base_url': 'https://api.moonshot.cn/v1',
        'models': [
            'moonshot-v1-8k',
            'moonshot-v1-32k',
            'moonshot-v1-128k',
            'moonshot-v1-auto',
        ],
    },
    '🟠 Anthropic (Claude)': {
        'class': 'ChatAnthropic',
        'env_key': 'ANTHROPIC_API_KEY',
        'models': [
            'claude-sonnet-4-20250514',
            'claude-3-5-haiku-latest',
            'claude-3-5-sonnet-latest',
        ],
    },
    '⚡ Groq (Fast)': {
        'class': 'ChatGroq',
        'env_key': 'GROQ_API_KEY',
        'models': [
            'llama-3.3-70b-versatile',
            'mixtral-8x7b-32768',
            'gemma2-9b-it',
        ],
    },
    '🐋 DeepSeek': {
        'class': 'ChatDeepSeek',
        'env_key': 'DEEPSEEK_API_KEY',
        'models': [
            'deepseek-chat',
            'deepseek-reasoner',
        ],
    },
    '🟩 NVIDIA NIM': {
        'class': 'ChatOpenAI',
        'env_key': 'NVIDIA_API_KEY',
        'base_url': 'https://integrate.api.nvidia.com/v1',
        'models': [
            'meta/llama-3.2-90b-vision-instruct',
            'meta/llama-3.2-11b-vision-instruct',
            'meta/llama-3.1-405b-instruct',
            'meta/llama-3.1-70b-instruct',
            'meta/llama-3.3-70b-instruct',
            'nvidia/llama-3.1-nemotron-70b-instruct',
            'mistralai/mistral-large-2-instruct',
        ],
    },
    '🦙 Ollama (Local - Free)': {
        'class': 'ChatOllama',
        'env_key': None,
        'models': [
            'qwen3.5:cloud',
            'qwen3.5:397b-cloud',
            'llama3.3',
            'llama3.2',
            'llama3.1',
            'llama3',
            'deepseek-r1',
            'kimi-k2.5:cloud',
            'qwen3-coder:480b-cloud',
            'qwen2.5',
            'mistral',
            'mixtral',
            'gemma2',
            'phi3',
        ],
    },
    '☁️ Ollama (Cloud / Custom Host)': {
        'class': 'ChatOllama',
        'env_key': 'OLLAMA_BASE_URL',
        'is_base_url_only': True,
        'models': [
            'qwen3.5:cloud',
            'qwen3.5:397b-cloud',
            'llama3.3',
            'llama3.2',
            'llama3.1',
            'llama3',
            'deepseek-r1',
            'kimi-k2.5:cloud',
            'qwen3-coder:480b-cloud',
            'qwen2.5',
            'mistral',
            'mixtral',
            'gemma2',
            'phi3',
        ],
    },
}


def show_banner():
    """Show the ClawBot banner with ASCII art logo."""
    import io
    from rich.console import Console
    from rich.panel import Panel

    # Fix Windows terminal encoding for Unicode block characters
    if os.name == 'nt':
        os.system('chcp 65001 > nul 2>&1')  # Switch console to UTF-8
        if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

    console = Console(force_terminal=True)

    logo = (
        "[bold cyan]                                                            [/]\n"
        "[bold cyan]           .:--=--:....................:---::.               [/]\n"
        "[bold cyan]         :=*#%%%%#+:.................:=*#%%##*-.            [/]\n"
        "[bold cyan]        :*%%@@%*=:.....................:-+#@@%%+.           [/]\n"
        "[bold cyan]        -%%@%+:...........................:=#%%#:           [/]\n"
        "[bold cyan]        .+%+:..:::::...::::::::::::::::::::.:=#=.           [/]\n"
        "[bold cyan]         .-:::::::::----:::::::::--=--:::::::::.            [/]\n"
        "[bold cyan]        .::::::::-+*####*=:::::-*#####*+-:::::::.          [/]\n"
        "[bold cyan]       .:::::::-+*####%###-----+%%%%#####+-::::::.         [/]\n"
        "[bold cyan]       .::::::-*#####@@%%+-----=#%%@%%%%##+------:         [/]\n"
        "[bold cyan]       .::::::-*###%%%%*=--+**+-=*%%%%%%%%*-------          [/]\n"
        "[bold cyan]       .:::::::-+##%##+---=+%#+===+*%%%%%*=====--:         [/]\n"
        "[bold cyan]       .:::::::::-===----=++++++====++*++=======-.         [/]\n"
        "[bold cyan]        :-::::----------=======+++++++++++++====+.         [/]\n"
        "[bold cyan]       :*#=:----------=======+++++++****++++==+#%=.        [/]\n"
        "[bold cyan]       =%%%+--------=======+++++********+++++*%@%#.        [/]\n"
        "[bold cyan]       :#%@@*-----======+++++*************++*@@@%+.        [/]\n"
        "[bold cyan]        .:-:...:-=====+++++*****####****+=:..:--:          [/]\n"
        "[bold cyan]                ..:+*+++***###########=:.                  [/]\n"
        "[bold cyan]                   #@%%%%+-====-%@@@@@:                    [/]\n"
        "[bold cyan]                   =%@@@@:      *@@@@#.                    [/]\n"
        "[bold cyan]                   .:---:       .:--:.                     [/]\n"
        "\n"
        "[bold #00d4ff]  ██████╗██╗      █████╗ ██╗    ██╗██████╗  ██████╗ ████████╗[/]\n"
        "[bold #00d4ff] ██╔════╝██║     ██╔══██╗██║    ██║██╔══██╗██╔═══██╗╚══██╔══╝[/]\n"
        "[bold #00d4ff] ██║     ██║     ███████║██║ █╗ ██║██████╔╝██║   ██║   ██║   [/]\n"
        "[bold #00d4ff] ██║     ██║     ██╔══██║██║███╗██║██╔══██╗██║   ██║   ██║   [/]\n"
        "[bold #00d4ff] ╚██████╗███████╗██║  ██║╚███╔███╔╝██████╔╝╚██████╔╝   ██║   [/]\n"
        "[bold #00d4ff]  ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝ ╚═════╝  ╚═════╝    ╚═╝   [/]\n"
        "\n"
        "[dim italic]        🤖 AI-Powered Browser & Computer Automation[/]\n"
        "[dim]                    v1.0 • pip install clawbot[/]"
    )

    console.print(Panel(
        logo,
        border_style='#00d4ff',
        padding=(1, 2),
    ))
    console.print()


def select_provider() -> tuple[str, dict]:
    """Let user pick an AI provider."""
    from InquirerPy import inquirer
    from InquirerPy.base.control import Choice

    choices = [Choice(name=name, value=name) for name in PROVIDERS]

    provider_name = inquirer.select(
        message='🧠 AI Provider choose karo:',
        choices=choices,
        style=_get_style(),
    ).execute()

    if provider_name is None:
        sys.exit(0)

    return provider_name, PROVIDERS[provider_name]


def select_model(provider_info: dict) -> str:
    """Let user pick a model from the selected provider."""
    from InquirerPy import inquirer
    from InquirerPy.base.control import Choice

    choices = [Choice(name=m, value=m) for m in provider_info['models']]

    model = inquirer.select(
        message='📦 Model choose karo:',
        choices=choices,
        style=_get_style(),
    ).execute()

    if model is None:
        sys.exit(0)

    return model


def get_api_key(provider_info: dict) -> str | None:
    """Get API key — load from saved config or ask user."""
    from InquirerPy import inquirer
    from rich.console import Console

    console = Console()
    env_key = provider_info.get('env_key')

    if env_key is None:
        console.print('[green]✅ Ollama local hai — API key ki zaroorat nahi![/green]')
        return None

    # Check if already set
    existing_key = os.getenv(env_key)
    if existing_key and existing_key != 'your-api-key-here':
        masked = existing_key[:8] + '...' + existing_key[-4:]
        console.print(f'[green]✅ {env_key} found:[/green] {masked}')

        use_existing = inquirer.confirm(
            message='Yahi key use karni hai?',
            default=True,
            style=_get_style(),
        ).execute()

        if use_existing:
            return existing_key

    # Ask for new key
    is_base_url = provider_info.get('is_base_url_only', False)
    prompt_msg = f'🌐 {env_key} enter karo (e.g. http://192.168.1.100:11434):' if is_base_url else f'🔑 {env_key} enter karo:'
    
    api_key_input = inquirer.secret(
        message=prompt_msg,
        style=_get_style(),
    ).execute() if not is_base_url else inquirer.text(
        message=prompt_msg,
        style=_get_style(),
    ).execute()

    if not api_key_input:
        console.print('[red]❌ Required hai![/red]')
        sys.exit(1)

    # Save to config file (~/.clawbot/.env)
    from dotenv import set_key
    env_file = _get_env_file()
    env_file.touch(exist_ok=True)
    set_key(str(env_file), env_key, api_key_input)
    os.environ[env_key] = api_key_input
    console.print(f'[green]✅ {env_key} saved to ~/.clawbot/.env[/green]')

    return api_key_input


def create_llm(provider_info: dict, model: str, api_key: str | None):
    """Create the LLM instance."""
    class_name = provider_info['class']
    from browser_use import llm as llm_module
    chat_class = getattr(llm_module, class_name)

    kwargs = {'model': model}
    
    url_param = 'host' if class_name == 'ChatOllama' else 'base_url'
    
    if api_key:
        if provider_info.get('is_base_url_only'):
            kwargs[url_param] = api_key
        else:
            kwargs['api_key'] = api_key
            
    if 'base_url' in provider_info and not provider_info.get('is_base_url_only'):
        kwargs[url_param] = provider_info['base_url']

    return chat_class(**kwargs)


def ensure_chrome_running() -> bool:
    """Make sure Chrome is running with debugging port."""
    import httpx
    from InquirerPy import inquirer
    from rich.console import Console

    console = Console()

    is_running = False
    try:
        resp = httpx.get('http://127.0.0.1:9222/json/version', timeout=1.0)
        if resp.status_code == 200:
            is_running = True
            console.print('[yellow]⚠️  Ek purani Chrome session abhi bhi chal rahi hai.[/yellow]')
    except Exception:
        console.print('[yellow]⚠️  Chrome debugging mode mein nahi chal raha[/yellow]')

    prompt_msg = 'Chrome ko refresh/restart karein (recommended)?' if is_running else 'Chrome auto-launch karein port 9222 par?'
    launch = inquirer.confirm(
        message=prompt_msg,
        default=True,
        style=_get_style(),
    ).execute()

    if not launch:
        console.print('[red]❌ Chrome ke bina agent nahi chalega![/red]')
        console.print('[dim]Manual: chrome --remote-debugging-port=9222[/dim]')
        return False

    console.print('[dim]Chrome restart ho raha hai...[/dim]')

    if sys.platform == 'win32':
        subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'],
                       capture_output=True, text=True, encoding='utf-8', errors='ignore')
        time.sleep(2)
        chrome_paths = [
            r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
            os.path.expandvars(r'%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe'),
        ]
        chrome_exe = next((p for p in chrome_paths if os.path.exists(p)), None)
        if not chrome_exe:
            console.print('[red]❌ Chrome nahi mila![/red]')
            return False
        temp_profile = os.path.join(os.environ.get('TEMP', '/tmp'), 'clawbot-chrome')
        subprocess.Popen([chrome_exe, '--remote-debugging-port=9222',
                          f'--user-data-dir={temp_profile}'])
    elif sys.platform == 'darwin':
        subprocess.run(['pkill', '-f', 'Google Chrome'], capture_output=True)
        time.sleep(2)
        temp_profile = '/tmp/clawbot-chrome'
        subprocess.Popen(['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
                          '--remote-debugging-port=9222', f'--user-data-dir={temp_profile}'])
    else:
        subprocess.run(['pkill', '-f', 'chrome'], capture_output=True)
        time.sleep(2)
        temp_profile = '/tmp/clawbot-chrome'
        subprocess.Popen(['google-chrome', '--remote-debugging-port=9222',
                          f'--user-data-dir={temp_profile}'])

    console.print('[dim]Chrome start ho raha hai...[/dim]')
    for _ in range(10):
        time.sleep(1)
        try:
            resp = httpx.get('http://127.0.0.1:9222/json/version', timeout=2.0)
            if resp.status_code == 200:
                data = resp.json()
                browser = data.get('Browser', 'Unknown')
                console.print(f'[green]✅ Chrome launched:[/green] {browser}')
                return True
        except Exception:
            pass

    console.print('[red]❌ Chrome start nahi hua 10 seconds mein[/red]')
    return False


async def run_task(llm, task: str):
    """Run a single browser task."""
    from browser_use import Agent, BrowserSession
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    session = BrowserSession.from_existing_browser(port=9222)

    # Determine Vision compatibility
    # Vision-capable models get live screen watching (like Google Assistant)
    # for faster, more accurate task completion
    use_vision = True
    provider_name = getattr(llm, '__module__', '')
    model_name = getattr(llm, 'model_name', '') or str(getattr(llm, 'model', ''))
    
    # Vision-first models: always keep vision ON for best accuracy
    # qwen3.5, gemini, gpt-4o, claude etc. are all vision-capable
    vision_first_models = ['qwen3.5', 'qwen3', 'gemini', 'gpt-4o', 'claude', 'kimi']
    is_vision_model = any(vm in model_name.lower() for vm in vision_first_models)
    
    if not is_vision_model:
        # Only forcefully disable for known text-only models
        if 'vision' not in model_name.lower():
            if 'nvidia' in provider_name.lower() or ('llama' in model_name.lower() and 'ollama' not in provider_name.lower()):
                use_vision = False

    agent = Agent(task=task, llm=llm, browser_session=session, use_vision=use_vision)
    
    vision_msg = "" if use_vision else " [dim](vision disabled)[/dim]"
    console.print(f'\n[bold #00d4ff]🚀 Running:[/bold #00d4ff] {task}{vision_msg}\n')

    # Intercept agent logs for the UI Panel
    agent_logger = logging.getLogger('browser_use')
    handler = PanelLogHandler(max_lines=12)
    old_handlers = agent_logger.handlers.copy()
    old_propagate = agent_logger.propagate
    
    for h in old_handlers:
        agent_logger.removeHandler(h)
    agent_logger.addHandler(handler)
    agent_logger.propagate = False

    try:
        with Live(Panel("Initializing...", title="🧠 Agent Thinking...", border_style="cyan", subtitle="[dim]Live Logs[/dim]"), refresh_per_second=4) as live:
            handler.live = live
            result = await agent.run()
            
        console.print(f'\n[green]✅ Done![/green]')
        if result and hasattr(result, 'all_results'):
            for r in result.all_results:
                if r.extracted_content:
                    console.print(Panel(str(r.extracted_content),
                                        title='📋 Result', border_style='green'))
    except KeyboardInterrupt:
        console.print('\n[yellow]⏹️  Task cancelled[/yellow]')
    except Exception as e:
        error_msg = str(e)
        console.print(f'\n[bold red]❌ Task Error:[/bold red] [red]{error_msg}[/red]\n')
        
        # Smart Error Interpreter for User-Friendly Tips
        if '429' in error_msg or 'RESOURCE_EXHAUSTED' in error_msg.upper() or 'rate limit' in error_msg.lower():
            console.print(Panel(
                "[bold yellow]TIPS TO FIX:[/bold yellow]\n\n"
                "• Aapka free API quota (limit) khatam ho gaya hai ya aapne bohut saari requests ek sath bhej di hain.\n"
                "• **Solution:** 5-10 minute wait karein aur wapas try karein, YA naya free provider select karein (jaise NVIDIA NIM ya Kimi).",
                title="⚠️ Rate Limit Exceeded (429)", border_style="yellow"
            ))
        elif '401' in error_msg or 'unauthorized' in error_msg.lower() or 'invalid_api_key' in error_msg.lower():
            console.print(Panel(
                "[bold yellow]TIPS TO FIX:[/bold yellow]\n\n"
                "• Aapki API key galat hai ya expire ho chuki hai.\n"
                "• **Solution:** Aapki key `~/.clawbot/.env` me save stithi me hai. Usko manual delete karke naya setup karein ya dusra API key daalein.",
                title="🔑 Authentication Error (401)", border_style="yellow"
            ))
        elif '404' in error_msg or 'not found' in error_msg.lower():
            console.print(Panel(
                "[bold yellow]TIPS TO FIX:[/bold yellow]\n\n"
                "• Jo Model aapne select kiya hai, wo provider ke paas available nahi hai ya uska server down hai.\n"
                "• **Solution:** List me se koi dusra Model select karein.",
                title="🔍 Model/Endpoint Not Found (404)", border_style="yellow"
            ))
    finally:
        # Restore original loggers
        agent_logger.removeHandler(handler)
        for h in old_handlers:
            agent_logger.addHandler(h)
        agent_logger.propagate = old_propagate
        await session.stop()


def main():
    """Main CLI entry point — this is what runs when you type 'clawbot'."""
    import atexit
    import logging as _logging
    atexit.register(_logging.shutdown)

    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    # Load saved config
    _load_env()

    show_banner()

    telegram_bot_running = False

    try:
        from InquirerPy import inquirer
        from InquirerPy.base.control import Choice

        # ── Step 0: Connect Menu ──
        env_file = _get_env_file()
        has_token = bool(os.environ.get('TELEGRAM_BOT_TOKEN', ''))

        # First ask: Telegram ya Continue?
        first_choice = inquirer.select(
            message='Kya karna chahte hain?',
            choices=[
                Choice(value='telegram', name='📱 Telegram Connect'),
                Choice(value='continue', name='⏭️  Continue (skip)'),
            ],
            style=_get_style(),
        ).execute()

        if first_choice == 'telegram':
            # Show Telegram sub-menu with connection status
            if has_token:
                console.print(f'\n[green]✅ Telegram Bot connected[/green] (Token saved in .env)\n')

            connect_choice = inquirer.select(
                message='Telegram Bot connect karna chahte hain?',
                choices=[
                    Choice(value='skip', name='⏭️  Continue (skip)' + (' — already connected' if has_token else '')),
                    Choice(value='connect', name='📱 Connect Telegram Bot' + (' — update credentials' if has_token else '')),
                ],
                style=_get_style(),
            ).execute()

            if connect_choice == 'connect':
                console.print('\n[bold cyan]📱 Telegram Bot Setup[/bold cyan]')
                console.print('[dim]Step 1: @BotFather ko /newbot bhejo → Token milega[/dim]')
                console.print('[dim]Step 2: @userinfobot ko message bhejo → Chat ID milega[/dim]\n')

                import httpx
                
                while True:
                    bot_token = inquirer.text(
                        message='Telegram Bot Token paste karo:',
                        style=_get_style(),
                    ).execute().strip()
                    
                    if not bot_token:
                        break
                        
                    # Validate the token
                    console.print('[dim]⏳ Token verify kar rahe hain...[/dim]')
                    try:
                        resp = httpx.get(f"https://api.telegram.org/bot{bot_token}/getMe", timeout=5.0)
                        if resp.status_code == 200:
                            bot_info = resp.json().get('result', {})
                            console.print(f"[green]✅ Token Valid! Bot Name: @{bot_info.get('username')}[/green]\n")
                            break
                        else:
                            console.print(f"[red]❌ Invalid Token! Telegram ne reject kar diya.[/red]")
                            console.print("[dim]Token kuch is tarah dikhta hai: 123456789:ABCDefghIJKLmnop...[/dim]\n")
                    except Exception as e:
                        console.print(f"[red]⚠️ Network error while validating: {e}[/red]\n")
                        break

                chat_id = inquirer.text(
                    message='Telegram Chat ID paste karo:',
                    style=_get_style(),
                ).execute().strip()

                if bot_token:
                    # Save to .env
                    existing = ''
                    if env_file.exists():
                        existing = env_file.read_text()
                    
                    # Remove old telegram keys if present
                    lines = existing.splitlines()
                    lines = [l for l in lines if not l.startswith('TELEGRAM_BOT_TOKEN') and not l.startswith('TELEGRAM_CHAT_ID')]
                    lines.append(f"TELEGRAM_BOT_TOKEN='{bot_token}'")
                    if chat_id:
                        lines.append(f"TELEGRAM_CHAT_ID='{chat_id}'")
                    
                    env_file.write_text('\n'.join(lines) + '\n')
                    os.environ['TELEGRAM_BOT_TOKEN'] = bot_token
                    if chat_id:
                        os.environ['TELEGRAM_CHAT_ID'] = chat_id
                    has_token = True
                    console.print(f'[green]✅ Telegram credentials saved to {env_file}[/green]\n')
                else:
                    console.print('[yellow]⚠️ Token empty tha, skip kar rahe hain[/yellow]\n')

        # ── Step 1: Scope Selection ──
        scope = inquirer.select(
            message='Kisko control karna hai aaj?',
            choices=[
                Choice(value='browser', name='🌐 Browser (Web Automation)'), 
                Choice(value='computer', name='💻 Computer (Windows OS Control)'),
                Choice(value='both', name='🔄 Both Control (Computer + Telegram Bot)'),
            ],
            style=_get_style(),
        ).execute()

        is_computer = scope in ('computer', 'both')

        # If 'Both Control', start Telegram bot in background
        if scope == 'both':
            if not has_token:
                console.print('[bold red]❌ Pehle Telegram Bot connect karo! Token set nahi hai.[/bold red]')
                console.print('[dim]ClawBot restart karo aur "Connect Telegram Bot" select karo.[/dim]')
                sys.exit(1)
            
            bot_path = Path(__file__).parent / "computer" / "telegram_bot.py"
            if not bot_path.exists():
                console.print(f'[bold red]❌ telegram_bot.py not found at: {bot_path}[/bold red]')
                sys.exit(1)
            
            subprocess.Popen(
                [sys.executable, str(bot_path)], 
                cwd=str(bot_path.parent),
                creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0
            )
            telegram_bot_running = True
            console.print('[bold green]✅ Telegram Bot background mein chalu ho gaya![/bold green]')
            console.print('[dim]Ab phone se bhi task de sakte hain, aur yahan CLI se bhi.[/dim]\n')

        mode_label = 'Both (Computer + browser)' if scope == 'both' else ('Computer' if is_computer else 'Browser')
        console.print(f'[#00d4ff]Mode:[/#00d4ff] {mode_label}\n')

        # ── Step 2: Select AI Provider ──
        provider_name, provider_info = select_provider()
        console.print(f'[#00d4ff]Selected:[/#00d4ff] {provider_name}\n')

        # ── Step 3: Select Model ──
        model = select_model(provider_info)
        console.print(f'[#00d4ff]Model:[/#00d4ff] {model}\n')

        # ── Step 4: API Key ──
        api_key = get_api_key(provider_info)
        console.print()

        # ── Step 4.5: Ollama Web Search API Key (for Computer mode) ──
        if is_computer and 'Ollama' in provider_name:
            ollama_api_key = os.getenv('OLLAMA_API_KEY', '')
            if ollama_api_key:
                console.print(f'[green]✅ Ollama Web Search API Key found[/green] (web_search enabled)\n')
            else:
                setup_web = inquirer.confirm(
                    message='🔍 Ollama Web Search enable karna hai? (free account se key milegi)',
                    default=True,
                    style=_get_style(),
                ).execute()
                if setup_web:
                    ollama_key_input = inquirer.text(
                        message='🔑 Ollama API Key paste karo (ollama.com se):',
                        style=_get_style(),
                    ).execute().strip()
                    if ollama_key_input:
                        from dotenv import set_key
                        set_key(str(env_file), 'OLLAMA_API_KEY', ollama_key_input)
                        os.environ['OLLAMA_API_KEY'] = ollama_key_input
                        console.print(f'[green]✅ OLLAMA_API_KEY saved! Web search enabled.[/green]\n')
                    else:
                        console.print('[yellow]⚠️ Key empty — web search disabled[/yellow]\n')
                else:
                    console.print('[dim]Web search skipped. Agent browser se search karega.[/dim]\n')

        # ── Step 5: Create LLM ──
        try:
            llm = create_llm(provider_info, model, api_key)
            console.print(f'[green]✅ AI ready![/green] {provider_info["class"]}({model})\n')
        except Exception as e:
            console.print(f'[red]❌ LLM create nahi hua: {e}[/red]')
            sys.exit(1)

        # ── Step 6: Ensure Chrome is running (Only for Browser) ──
        if not is_computer:
            if not ensure_chrome_running():
                sys.exit(1)
            
    except KeyboardInterrupt:
        console.print('\n[yellow]⏹️  ClawBot setup cancelled[/yellow]')
        sys.exit(0)

    console.print()

    # Step 7: Interactive Task Loop
    tg_status = ' | [bold green]📱 Telegram Bot Active[/bold green]' if telegram_bot_running else ''
    console.print(Panel(
        '[bold]Commands:[/bold]\n'
        '  • Task type karo aur Enter dabaao\n'
        '  • [bold yellow]Ctrl+C[/bold yellow] — sirf current task rok do (ClawBot chal ta rahega!)\n'
        '  • [dim]quit[/dim] / [dim]exit[/dim] — ClawBot poora band karo\n'
        '  • [dim]switch[/dim] — AI provider/model badlo\n'
        '  • [dim]chrome[/dim] — Chrome restart karo',
        title=f'[bold #00d4ff]🤖 ClawBot ({mode_label}) Ready!{tg_status}[/bold #00d4ff]',
        border_style='#00d4ff',
        padding=(1, 2),
    ))
    console.print()

    while True:
        try:
            task = console.input('[bold #ff6b35]🤖 Task > [/bold #ff6b35]').strip()

            if not task:
                continue

            if task.lower() in ('quit', 'exit', 'q', 'band karo'):
                console.print('\n[dim]👋 Bye! Browser open rahega.[/dim]')
                break

            if task.lower() == 'switch':
                provider_name, provider_info = select_provider()
                model = select_model(provider_info)
                api_key = get_api_key(provider_info)
                llm = create_llm(provider_info, model, api_key)
                console.print(f'[green]✅ Switched to {model}[/green]\n')
                continue

            if task.lower() == 'chrome':
                if not is_computer:
                    ensure_chrome_running()
                else:
                    console.print('\n[yellow]⚠️ Aap Computer OS mode me hain, Chrome ki zarurat nahi![/yellow]\n')
                continue

            try:
                if is_computer:
                    computer_dir = str(Path(__file__).parent / "computer")
                    if computer_dir not in sys.path:
                        sys.path.insert(0, computer_dir)
                    from agent import run_computer_task
                    asyncio.run(run_computer_task(llm, task))
                else:
                    asyncio.run(run_task(llm, task))
            except KeyboardInterrupt:
                # Stop ONLY the current task — keep ClawBot running!
                console.print('\n\n[bold yellow]⏹️ Task roka gaya! ClawBot ab bhi chal raha hai.[/bold yellow]')
                console.print('[dim]Naya task likhein, ya quit/exit karein band karne ke liye.[/dim]\n')
            console.print()

        except KeyboardInterrupt:
            # Ctrl+C at the input prompt — ask before exiting
            console.print('\n[yellow]Kya aap ClawBot band karna chahte hain? (quit/exit type karein)[/yellow]')
        except EOFError:
            break


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
