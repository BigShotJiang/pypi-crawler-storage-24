import joblib
import os

# Use the directory where the server is started
PROJECT_ROOT = os.getcwd()

MODEL_PATH = os.path.join(PROJECT_ROOT, "backend", "model.pkl")
VECTORIZER_PATH = os.path.join(PROJECT_ROOT, "backend", "vectorizer.pkl")

print("MODEL PATH:", MODEL_PATH)
print("FILE EXISTS:", os.path.exists(MODEL_PATH))

model = joblib.load(MODEL_PATH)
vectorizer = joblib.load(VECTORIZER_PATH)

def check_email(email):
    domain = email.split("@")[-1]

    features = vectorizer.transform([domain])
    prediction = model.predict(features)[0]

    if prediction == 1:
        return "Temporary Email"
    else:
        return "Legitimate Email"