#!/usr/bin/env python3 
from __future__ import annotations

from jarvishep.base import Base
from abc import ABCMeta, abstractmethod
from jarvishep.Sampling.variables import Variable
import sympy as sp 
from jarvishep.inner_func import update_const, update_funcs
import numpy as np 
import sys, os 
from typing import Any, Dict, Tuple
from copy import deepcopy

class BoolConversionError(Exception):
    """Nothing but raise bool error"""
    pass
class SamplingVirtial(Base):
    __metaclass__ = ABCMeta
    def __init__(self) -> None:
        super().__init__()
        self.schema                     = None
        self.info: Dict[str, Any]       = {}
        self.vars: Tuple[Variable]      = None
        self.method                     = None
        self.max_workers                = 4
        self._selectionexp              = None
        self._loglike                   = None 
        self.nuisance_sampler           = None 
        self._with_nuisance             = False 
        self.bucket_alloc               = None 
        self.sample_archive_manager     = None
        self.total_core                 = os.cpu_count()
        
    def load_nuisance_sampler(self): 
        nui_config = (self.config.get('Sampling', {}) or {}).get('Nuisance', None)
        if nui_config: 
            if nui_config['Method'] == "Profile1D": 
                from jarvishep.Sampling.Source.Nuisance.profile1d import Profile1D
                self.nuisance_sampler = Profile1D()
                self.nuisance_sampler.set_logger(self.logger)
                self.nuisance_sampler.set_config(nui_config)
                self.info['sample']['nuisance'] = self.nuisance_sampler.get_info_card()
                self._with_nuisance = True

    @property
    def loglike(self):
        return self._loglike

    def set_max_workers(self, nn):
        self.max_workers = nn 

    @abstractmethod
    def load_schema_file(self) -> None:
        pass 

    @abstractmethod
    def set_config(self, config_info) -> None:
        pass 

    @abstractmethod
    def set_bucket_alloc(self) -> None: 
        limit = 200 
        width = 6 
        ba_config = None
        scan_cfg = self.config.get("Scan", {}) if isinstance(self.config, dict) else {}
        if isinstance(scan_cfg, dict):
            ba_config = scan_cfg.get("sample_directory", None)
        if not isinstance(ba_config, dict):
            ba_config = self.config.get("Directory_Setting", None)
        if isinstance(ba_config, dict):
            limit = ba_config.get("limit", 200)
            width = ba_config.get("width", 6)

        from jarvishep.Sampling.bucketallocator import BucketAllocator
        self.bucket_alloc = BucketAllocator(
            base_path=self.info['sample']['sample_dirs'],
            limit=limit,
            width=width,
            start_bucket=1,
            on_bucket_sealed=self._on_bucket_sealed if self._archive_enabled() else None,
        )
        self.bucket_alloc.check_and_update()
        if self._archive_enabled():
            self._ensure_archive_manager()
        
        
    @abstractmethod
    def init_generator(self) -> None:
        pass 
         

    @abstractmethod
    def set_factory(self) -> None: 
        pass 

    @abstractmethod
    def load_variable(self) -> None:
        variables = []
        for var_config in self.config['Sampling'].get("Variables", []):  # 使用get以防'Variables'键不存在
            var = Variable(
                name=var_config['name'],
                description=var_config['description'],
                distribution=var_config['distribution']['type'],
                parameters=var_config['distribution']['parameters']
            )
            variables.append(var)
        self.vars = tuple(variables)

    @abstractmethod
    def set_logger(self, logger) -> None:
        self.logger = logger 

    @abstractmethod 
    def combine_data(self, df_full) -> None:
        pass 
        

    
    @abstractmethod
    def set_likelihood(self, loglike):
        self._loglike = loglike
        self._loglike.logger = self.logger 
    
    @abstractmethod
    def logo_at_pos(self, pos, ax):
        from PIL import Image
        image_path = self.decode_path("&SRC/icons/JarvisHEP.png")
        with Image.open(image_path) as image:
            image = np.array(image.convert("RGBA"))
            ax.axes("off")
            ax.imshow(image, extent=[pos[0]-0.25, pos[0]+0.25, pos[1]-0.25, pos[1]+0.25], zorder=100)
            ax.text(pos[0]+0.27, pos[1]+0.15, "Jarvis-HEP", ha="left", va='top', color="#0F66C3", fontfamily="sans-serif", fontsize="small", fontstyle="normal", fontweight="bold")

    def evaluate_selection(self, expression, variables):
        """Evaluate selection expression and return a strict bool."""
        if expression is None:
            return True
        if not isinstance(variables, dict):
            raise BoolConversionError("Selection variables must be a dict.")

        custom_functions = update_funcs({})
        custom_constants = update_const({})
        symbols = {name: sp.symbols(name) for name in variables.keys()}
        locals_context = {**custom_functions, **custom_constants, **symbols}

        try:
            expr = sp.sympify(expression, locals=locals_context)
            evaluated = expr.subs(variables)
            return bool(evaluated)
        except Exception as exc:
            raise BoolConversionError(
                f"Cannot evaluate selection expression '{expression}' as boolean."
            ) from exc

    def check_evaluation(self):
        """Smoke-check selection evaluation on a deterministic probe point."""
        if not getattr(self, "_selectionexp", None):
            return True

        probe_values = {}
        for var in self.vars or []:
            name = getattr(var, "name", getattr(var, "_name", None))
            if not name:
                continue
            try:
                probe_values[name] = var.map_standard_random_to_distribution(0.5)
            except Exception:
                probe_values[name] = 0.5

        self.evaluate_selection(self._selectionexp, probe_values)
        return True

    def build_sample_config(self, base_sample_cfg: Dict[str, Any], save_dir: str | None = None) -> Dict[str, Any]:
        """Build per-sample config with minimal safe copying.

        Only deep-copy fields that are mutated downstream (e.g. ``nuisance``),
        while keeping read-only large fields shared to avoid hot-path deepcopy cost.
        """
        cfg = dict(base_sample_cfg or {})
        if save_dir is not None:
            cfg["save_dir"] = save_dir

        nuisance = cfg.get("nuisance")
        if isinstance(nuisance, dict):
            cfg["nuisance"] = deepcopy(nuisance)
        return cfg

    def _archive_enabled(self) -> bool:
        sample_cfg = self.info.get("sample", {}) if isinstance(self.info, dict) else {}
        if "archive_samples" not in sample_cfg:
            # Keep backward compatibility for legacy/manual test setups that
            # do not carry the normalized runtime flag from Core.
            return False
        return bool(sample_cfg.get("archive_samples"))

    def _ensure_archive_manager(self):
        if not self._archive_enabled():
            return None
        if self.sample_archive_manager is None:
            from jarvishep.Sampling.sample_archive import SampleArchiveManager

            self.sample_archive_manager = SampleArchiveManager(
                sample_root=self.info["sample"]["sample_dirs"],
                logger=self.logger,
                enabled=True,
            )
            self.sample_archive_manager.start()
        return self.sample_archive_manager

    def _on_bucket_sealed(self, bucket_dir: str):
        manager = self._ensure_archive_manager()
        if manager is None:
            return
        manager.enqueue_bucket_dir(bucket_dir, blocking=True, timeout=30.0)

    def _next_bucket_dir_for_sample(self) -> str | None:
        if getattr(self, "bucket_alloc", None) is None:
            return None
        return self.bucket_alloc.next_bucket_dir()

    def _on_sample_completed(self, sample_info: Dict[str, Any] | None) -> None:
        if getattr(self, "bucket_alloc", None) is None:
            return
        if not isinstance(sample_info, dict):
            return
        save_dir = sample_info.get("save_dir")
        if not save_dir:
            return
        bucket_dir = os.path.dirname(str(save_dir).rstrip(os.sep))
        try:
            self.bucket_alloc.mark_sample_finished(bucket_dir)
        except Exception:
            # Never break sampling cleanup on archive-accounting errors.
            pass

    def finalize_sample_archive(self):
        if not self._archive_enabled():
            return
        manager = self._ensure_archive_manager()
        if manager is None:
            return
        if self.bucket_alloc is not None:
            try:
                self.bucket_alloc.seal_current_bucket()
            except Exception:
                pass
        if self.bucket_alloc is not None:
            try:
                manager.enqueue_bucket_dir(
                    self.bucket_alloc.current_bucket_dir(),
                    blocking=True,
                    timeout=30.0,
                    force=True,
                )
            except Exception:
                pass
        manager.enqueue_all_existing_buckets()
        manager.shutdown(wait=True, timeout=300.0)
        self.sample_archive_manager = None
