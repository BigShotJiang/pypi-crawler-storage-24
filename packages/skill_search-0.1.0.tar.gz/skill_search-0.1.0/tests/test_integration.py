"""実際の .agent/skills/ ディレクトリを使った統合テスト.

このテストは ../../.agent/skills/ に実際のスキルが存在する場合のみ実行される。
"""

import json
from pathlib import Path

import pytest

from skill_search import SkillSearch

SKILLS_DIR = Path(__file__).parent.parent.parent / ".agent" / "skills"


@pytest.mark.skipif(
    not SKILLS_DIR.is_dir(), reason=".agent/skills/ directory not found"
)
class TestIntegration:
    """実際のスキルディレクトリを使った統合テスト."""

    def test_discover_real_skills(self):
        ss = SkillSearch(skills_dirs=[SKILLS_DIR])
        assert len(ss.skills) > 0

    def test_list_real_skills(self):
        ss = SkillSearch(skills_dirs=[SKILLS_DIR])
        result = ss.call_tool("list_skills")
        data = json.loads(result)
        assert len(data["skills"]) > 0

    def test_search_real_skills(self):
        ss = SkillSearch(skills_dirs=[SKILLS_DIR])
        result = ss.call_tool("search_skills", {"query": "API", "top_k": 3})
        data = json.loads(result)
        assert "results" in data

    def test_read_real_skill(self):
        ss = SkillSearch(skills_dirs=[SKILLS_DIR])
        # 最初のスキルを読む
        first_skill = next(iter(ss.skills.keys()))
        result = ss.call_tool("read_skill", {"skill_name": first_skill})
        data = json.loads(result)
        assert data["name"] == first_skill
        assert "content" in data

    def test_system_prompt(self):
        ss = SkillSearch(skills_dirs=[SKILLS_DIR])
        prompt = ss.get_system_prompt()
        assert len(prompt) > 0
        assert "Available Skills" in prompt
