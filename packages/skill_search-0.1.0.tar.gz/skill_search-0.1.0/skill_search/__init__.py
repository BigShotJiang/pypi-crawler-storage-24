"""skill-search: LLM フレームワーク非依存のスキル検索ライブラリ.

skills/ ディレクトリを走査し、SKILL.md を解析して全文検索インデックスを構築。
LLM に渡すためのツール定義と、ツール呼び出しの実行ハンドラを提供する。

Usage:
    ```python
    from skill_search import SkillSearch

    ss = SkillSearch(skills_dirs=["./skills"])

    # LLM に渡すツール定義を取得 (OpenAI function calling 形式)
    tools = ss.get_tool_definitions()

    # ツール呼び出しを実行
    result = ss.call_tool("search_skills", {"query": "figma api"})
    ```
"""

from .discovery import discover_skills, parse_skill_md
from .indexer import SkillIndex, build_index
from .tools import SkillSearch
from .types import SearchResult, SkillMeta, SkillResource

__all__ = [
    "SkillSearch",
    "SkillIndex",
    "SkillMeta",
    "SkillResource",
    "SearchResult",
    "discover_skills",
    "parse_skill_md",
    "build_index",
]
