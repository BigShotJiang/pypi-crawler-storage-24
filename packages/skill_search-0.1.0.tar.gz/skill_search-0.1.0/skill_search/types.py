"""skill-search のデータ型定義."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SkillMeta:
    """スキルのメタデータ."""

    name: str
    description: str
    path: str  # スキルディレクトリの絶対パス
    content: str = ""  # SKILL.md の Markdown 本文
    resources: list[SkillResource] = field(default_factory=list)


@dataclass
class SkillResource:
    """スキル内のリソースファイル."""

    name: str
    path: str  # ファイルの絶対パス
    description: str | None = None


@dataclass
class SearchResult:
    """検索結果."""

    skill_name: str
    file_path: str
    section: str
    score: float
    snippet: str
