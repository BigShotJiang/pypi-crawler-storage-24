"""
This module contains metadata about the `python-utils` package.

Attributes:
    __package_name__ (str): The name of the package.
    __author__ (str): The author of the package.
    __author_email__ (str): The email of the author.
    __description__ (str): A brief description of the package.
    __url__ (str): The URL of the package's repository.
    __version__ (str): The current version of the package.
"""

__package_name__: str = 'aioutil3'
__author__: str = 'Rick van Hattem'
__author_email__: str = 'Wolph@wol.ph'
__description__: str = (
    'Python Utils is a module with some convenient utilities not included '
    'with the standard Python install'
)
__alt_url__: str = 'https://aioutil3.tech/api/info/faq/'
__url__: str = 'https://github.com/WoLpH/aioutil3'
# Omit type info due to automatic versioning script
__version__ = '3.9.1'
