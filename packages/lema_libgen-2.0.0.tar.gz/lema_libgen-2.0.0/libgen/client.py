import asyncio
import os
import re
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin

import aiofiles
import aiohttp
from aiohttp_socks import ProxyConnector
from bs4 import BeautifulSoup

from libgen.downloaders import (
    LibGenDownloader,
    LibGenPwDownloader,
    MirrorDownloader,
    RandomBookDownloader,
)
from libgen.models import Book
from libgen.proxy import ProxyManager
from libgen.utils import (
    DEFAULT_MIRROR,
    dedupe_mirrors_by_domain,
    extract_mirrors_from_html,
    parse_authors,
    sanitize_filename,
)


class LibGen:
    def __init__(
        self,
        main_url: str = "https://librarygenesis.net/",
        proxy: Optional[str] = None,
        proxy_pool: Optional[List[str]] = None,
        timeout: int = 15,
    ):
        self.main_url = main_url
        self.timeout = timeout
        self.proxy_manager = ProxyManager(proxy_pool)
        self.default_proxy = proxy
        self.downloaders: List[MirrorDownloader] = [
            LibGenDownloader(),
            RandomBookDownloader(),
            LibGenPwDownloader(),
        ]

    def _get_proxy(self, proxy: Optional[str]) -> Optional[str]:
        if proxy == "":
            return None
        if proxy is not None:
            return proxy
        if self.default_proxy:
            return self.default_proxy
        return self.proxy_manager.get_random()

    def _create_session(self, proxy: Optional[str] = None) -> aiohttp.ClientSession:
        if proxy and ProxyManager.is_socks_url(proxy):
            connector = ProxyConnector.from_url(proxy)
            return aiohttp.ClientSession(connector=connector)
        return aiohttp.ClientSession()

    def _get_downloader(self, url: str) -> Optional[MirrorDownloader]:
        for downloader in self.downloaders:
            if downloader.can_handle(url):
                return downloader
        return None

    async def get_download_url(
        self,
        mirror_url: str,
        proxy: Optional[str] = None,
    ) -> Optional[str]:
        downloader = self._get_downloader(mirror_url)
        if not downloader:
            return None

        resolved_proxy = self._get_proxy(proxy)
        session = self._create_session(resolved_proxy)

        try:
            return await downloader.get_download_url(
                session, mirror_url, self.timeout, resolved_proxy
            )
        finally:
            await session.close()

    async def get_download_urls(
        self,
        book: Book,
        proxy: Optional[str] = None,
    ) -> Dict[str, Optional[str]]:
        results: Dict[str, Optional[str]] = {}
        for mirror in book.mirrors:
            url = await self.get_download_url(mirror, proxy)
            results[mirror] = url
        return results

    async def download(
        self,
        book: Book,
        output_dir: str = ".",
        preferred_mirrors: Optional[List[str]] = None,
        proxy: Optional[str] = None,
    ) -> Optional[str]:
        os.makedirs(output_dir, exist_ok=True)

        mirrors = book.mirrors.copy()
        if preferred_mirrors:
            mirrors.sort(
                key=lambda m: 0 if any(p in m for p in preferred_mirrors) else 1
            )

        resolved_proxy = self._get_proxy(proxy)
        session = self._create_session(resolved_proxy)

        try:
            for mirror in mirrors:
                print(f"Trying mirror: {mirror}")
                download_url = await self.get_download_url(mirror, proxy)

                if not download_url:
                    print(f"  Could not get download URL from {mirror}")
                    continue

                print(f"  Download URL: {download_url}")

                try:
                    result = await self._download_file(
                        session, download_url, book, output_dir, resolved_proxy
                    )
                    if result:
                        return result
                except Exception as e:
                    print(f"  Error downloading: {e}")
                    continue
        finally:
            await session.close()

        return None

    async def _download_file(
        self,
        session: aiohttp.ClientSession,
        url: str,
        book: Book,
        output_dir: str,
        proxy: Optional[str] = None,
    ) -> Optional[str]:
        safe_title = sanitize_filename(book.title)
        ext = book.extension or "pdf"
        filename = f"{safe_title}.{ext}"
        filepath = os.path.join(output_dir, filename)

        proxy_arg = proxy if proxy else None

        try:
            async with session.get(
                url,
                timeout=aiohttp.ClientTimeout(total=300),
                proxy=proxy_arg,
            ) as response:
                if response.status != 200:
                    print(f"  HTTP {response.status}")
                    return None

                total_size = response.content_length or 0
                downloaded = 0

                async with aiofiles.open(filepath, "wb") as f:
                    async for chunk in response.content.iter_chunked(8192):
                        await f.write(chunk)
                        downloaded += len(chunk)
                        if total_size:
                            percent = (downloaded / total_size) * 100
                            print(
                                f"\r  Progress: {percent:.1f}% ({downloaded}/{total_size} bytes)",
                                end="",
                            )

                print()
                print(f"  Saved to: {filepath}")
                return filepath

        except asyncio.TimeoutError:
            print("  Timeout")
            return None
        except aiohttp.ClientError as e:
            print(f"  Network error: {e}")
            return None
        except Exception as e:
            print(f"  Error: {e}")
            return None

    async def get_mirrors(self, proxy: Optional[str] = None) -> List[str]:
        resolved_proxy = self._get_proxy(proxy)
        session = self._create_session(resolved_proxy)

        try:
            proxy_arg = resolved_proxy if resolved_proxy else None
            async with session.get(
                self.main_url,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                proxy=proxy_arg,
            ) as response:
                if response.status != 200:
                    print(f"Error fetching {self.main_url}: HTTP {response.status}")
                    return []
                html = await response.text()
        except Exception as e:
            print(f"Error fetching {self.main_url}: {e}")
            return []
        finally:
            await session.close()

        mirrors = extract_mirrors_from_html(html)
        return dedupe_mirrors_by_domain(mirrors)

    async def _check_single_mirror(
        self,
        mirror: str,
        proxy: Optional[str] = None,
    ) -> Tuple[str, bool, str]:
        resolved_proxy = self._get_proxy(proxy)
        session = self._create_session(resolved_proxy)

        try:
            proxy_arg = resolved_proxy if resolved_proxy else None
            async with session.get(
                mirror,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                proxy=proxy_arg,
            ) as response:
                is_working = response.status == 200
                status = f"HTTP {response.status}"
                return (mirror, is_working, status)
        except asyncio.TimeoutError:
            return (mirror, False, "Timeout")
        except aiohttp.ClientError as e:
            return (mirror, False, f"Connection Error: {type(e).__name__}")
        except Exception as e:
            return (mirror, False, str(e))
        finally:
            await session.close()

    async def check_mirrors(
        self,
        mirrors: Optional[List[str]] = None,
        proxy: Optional[str] = None,
    ) -> Dict[str, Dict[str, bool | str]]:
        if mirrors is None:
            mirrors = await self.get_mirrors(proxy)

        if not mirrors:
            print("No mirrors to check")
            return {}

        tasks = [self._check_single_mirror(mirror, proxy) for mirror in mirrors]
        results_list = await asyncio.gather(*tasks)

        results: Dict[str, Dict[str, bool | str]] = {}
        for mirror, is_working, status in results_list:
            results[mirror] = {"working": is_working, "status": status}

        return results

    async def search(
        self,
        query: str,
        mirror: str = DEFAULT_MIRROR,
        results: int = 25,
        covers: bool = False,
        page: int = 1,
        proxy: Optional[str] = None,
    ) -> List[Book]:
        url = f"{mirror.rstrip('/')}/index.php?req={query}&res={results}&page={page}"
        if covers:
            url += "&covers=on"

        resolved_proxy = self._get_proxy(proxy)
        session = self._create_session(resolved_proxy)

        try:
            proxy_arg = resolved_proxy if resolved_proxy else None
            async with session.get(
                url,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                proxy=proxy_arg,
            ) as response:
                if response.status != 200:
                    print(f"Error searching: HTTP {response.status}")
                    return []
                html = await response.text()
        except Exception as e:
            print(f"Error searching: {e}")
            return []
        finally:
            await session.close()

        return self._parse_results(html, mirror, covers)

    async def search_pages(
        self,
        query: str,
        mirror: str = DEFAULT_MIRROR,
        results: int = 25,
        covers: bool = False,
        start_page: int = 1,
        end_page: int = 1,
        proxy: Optional[str] = None,
    ) -> List[Book]:
        tasks = [
            self.search(query, mirror, results, covers, page, proxy)
            for page in range(start_page, end_page + 1)
        ]
        results_list = await asyncio.gather(*tasks)

        all_books: List[Book] = []
        for books in results_list:
            all_books.extend(books)
        return all_books

    def _parse_results(
        self,
        html: str,
        base_url: str,
        covers: bool = False,
    ) -> List[Book]:
        soup = BeautifulSoup(html, "html.parser")
        books: List[Book] = []

        tables = soup.find_all("table")
        if len(tables) < 2:
            return books

        table = tables[1]
        rows = table.find_all("tr")

        for row in rows:
            try:
                book = self._parse_row(row, base_url, covers)
                if book:
                    books.append(book)
            except Exception:
                continue

        return books

    def _parse_row(
        self,
        row,
        base_url: str,
        covers: bool = False,
    ) -> Optional[Book]:
        cells = row.find_all("td")

        min_cells = 10 if covers else 9
        if len(cells) < min_cells:
            return None

        offset = 1 if covers else 0

        cover_url = None
        if covers:
            cover_cell = cells[0]
            cover_img = cover_cell.find("img", src=True)
            if cover_img:
                cover_src = cover_img.get("src", "")
                if cover_src.startswith("http"):
                    cover_url = cover_src
                elif cover_src.startswith("/"):
                    cover_url = urljoin(base_url, cover_src)

        title_cell = cells[0 + offset]
        authors_cell = cells[1 + offset]
        publisher_cell = cells[2 + offset]
        year_cell = cells[3 + offset]
        language_cell = cells[4 + offset]
        pages_cell = cells[5 + offset]
        size_cell = cells[6 + offset]
        extension_cell = cells[7 + offset]
        mirrors_cell = cells[8 + offset]

        title_parts = []
        for b in title_cell.find_all("b"):
            text = b.get_text(strip=True)
            if text:
                title_parts.append(text)

        title_link = title_cell.find("a", href=True)
        subtitle = ""
        if title_link:
            link_text = title_link.get_text(strip=True)
            if link_text and link_text not in title_parts:
                subtitle = link_text

        if title_parts and subtitle:
            title = f"{title_parts[0]}: {subtitle}"
        elif title_parts:
            title = title_parts[0]
        elif subtitle:
            title = subtitle
        else:
            title = ""

        edition_id = ""
        timeadd = ""
        file_id = ""

        title_attr_links = title_cell.find_all("a", attrs={"title": True})
        if title_attr_links:
            title_attr = title_attr_links[0].get("title", "")
            time_match = re.search(r"Add/Edit\s*:\s*(\d{4}-\d{2}-\d{2})", title_attr)
            if time_match:
                timeadd = time_match.group(1)

            id_match = re.search(r"ID:\s*(\d+)", title_attr)
            if id_match:
                file_id = id_match.group(1)

        if title_link:
            edition_match = re.search(
                r"edition\.php\?id=(\d+)", title_link.get("href", "")
            )
            if edition_match:
                edition_id = edition_match.group(1)

        final_id = file_id or edition_id

        series = ""
        for i_tag in title_cell.find_all("i"):
            parent = i_tag.parent
            if parent and parent.name == "a":
                continue
            series_text = i_tag.get_text(strip=True)
            if (
                series_text
                and not series_text.startswith("978")
                and not series_text.startswith("0")
            ):
                series = series_text
                break

        authors = parse_authors(authors_cell.get_text(strip=True))

        publisher = publisher_cell.get_text(strip=True)

        year = year_cell.get_text(strip=True)
        language = language_cell.get_text(strip=True)
        pages = pages_cell.get_text(strip=True)

        size = ""
        size_link = size_cell.find("a", href=True)
        if size_link:
            size = size_link.get_text(strip=True)
            file_id_match = re.search(r"file\.php\?id=(\d+)", size_link.get("href", ""))
            if file_id_match:
                final_id = file_id_match.group(1)
        else:
            size = size_cell.get_text(strip=True)

        extension = extension_cell.get_text(strip=True)

        mirrors = []
        for link in mirrors_cell.find_all("a", href=True):
            href = link.get("href", "")
            if href.startswith("http"):
                mirrors.append(href)
            elif href.startswith("/"):
                mirrors.append(urljoin(base_url, href))

        return Book(
            id=final_id,
            timeadd=timeadd,
            title=title,
            series=series if series else None,
            authors=authors,
            publisher=publisher if publisher else None,
            year=year if year else None,
            language=language if language else None,
            pages=pages if pages else None,
            size=size if size else None,
            extension=extension if extension else None,
            mirrors=mirrors,
            cover=cover_url,
        )
