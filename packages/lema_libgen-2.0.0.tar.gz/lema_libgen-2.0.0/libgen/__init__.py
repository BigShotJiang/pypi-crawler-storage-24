from libgen.client import LibGen
from libgen.downloaders import (
    LibGenDownloader,
    LibGenPwDownloader,
    MirrorDownloader,
    RandomBookDownloader,
)
from libgen.models import Book
from libgen.proxy import ProxyManager, ProxyConfig
from libgen.utils import (
    BOOK_EXTENSIONS_ALL,
    BOOK_EXTENSIONS_BY_FORMAT,
    BOOK_EXTENSIONS_COMMON,
    BOOK_EXTENSIONS_COMICS,
    BOOK_EXTENSIONS_DOCS,
    BOOK_EXTENSIONS_RARE,
    BOOK_EXTENSIONS_TUPLE,
    DEFAULT_MIRROR,
)

__version__ = "2.0.0"

__all__ = [
    "LibGen",
    "Book",
    "MirrorDownloader",
    "LibGenDownloader",
    "RandomBookDownloader",
    "LibGenPwDownloader",
    "ProxyManager",
    "ProxyConfig",
    "BOOK_EXTENSIONS_ALL",
    "BOOK_EXTENSIONS_COMMON",
    "BOOK_EXTENSIONS_COMICS",
    "BOOK_EXTENSIONS_DOCS",
    "BOOK_EXTENSIONS_RARE",
    "BOOK_EXTENSIONS_TUPLE",
    "BOOK_EXTENSIONS_BY_FORMAT",
    "DEFAULT_MIRROR",
]
