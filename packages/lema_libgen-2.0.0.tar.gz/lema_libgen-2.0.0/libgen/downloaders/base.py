from abc import ABC, abstractmethod
from typing import Optional

import aiohttp


class MirrorDownloader(ABC):
    @abstractmethod
    def can_handle(self, url: str) -> bool:
        pass

    @abstractmethod
    async def get_download_url(
        self,
        session: aiohttp.ClientSession,
        url: str,
        timeout: int = 15,
        proxy: Optional[str] = None,
    ) -> Optional[str]:
        pass
