import re
from typing import Optional
from urllib.parse import urljoin

import aiohttp
from bs4 import BeautifulSoup

from libgen.downloaders.base import MirrorDownloader


class LibGenDownloader(MirrorDownloader):
    LIBGEN_PATTERN = re.compile(r"https?://([a-zA-Z0-9.-]*libgen\.[a-zA-Z]{2,})")

    def can_handle(self, url: str) -> bool:
        return bool(self.LIBGEN_PATTERN.match(url))

    async def get_download_url(
        self,
        session: aiohttp.ClientSession,
        url: str,
        timeout: int = 15,
        proxy: Optional[str] = None,
    ) -> Optional[str]:
        try:
            proxy_arg = proxy if proxy else None
            async with session.get(
                url,
                timeout=aiohttp.ClientTimeout(total=timeout),
                proxy=proxy_arg,
            ) as response:
                if response.status != 200:
                    return None
                html = await response.text()
        except Exception:
            return None

        soup = BeautifulSoup(html, "html.parser")

        get_link = soup.find("a", href=re.compile(r"get\.php\?md5="))
        if get_link:
            href = get_link.get("href", "")
            if isinstance(href, str):
                if href.startswith("http"):
                    return href
                match = self.LIBGEN_PATTERN.match(url)
                if match:
                    base_url = f"https://{match.group(1)}"
                    return urljoin(base_url, href)

        return None
