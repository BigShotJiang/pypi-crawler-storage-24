from typing import Optional

import aiohttp
from bs4 import BeautifulSoup

from libgen.downloaders.base import MirrorDownloader
from libgen.utils import BOOK_EXTENSIONS_TUPLE


class RandomBookDownloader(MirrorDownloader):
    def can_handle(self, url: str) -> bool:
        return "randombook.org" in url

    async def get_download_url(
        self,
        session: aiohttp.ClientSession,
        url: str,
        timeout: int = 15,
        proxy: Optional[str] = None,
    ) -> Optional[str]:
        try:
            proxy_arg = proxy if proxy else None
            async with session.get(
                url,
                timeout=aiohttp.ClientTimeout(total=timeout),
                proxy=proxy_arg,
            ) as response:
                if response.status != 200:
                    return None
                html = await response.text()
        except Exception:
            return None

        soup = BeautifulSoup(html, "html.parser")

        for link in soup.find_all("a", href=True):
            href = link.get("href", "")
            text = link.get_text(strip=True).lower()
            if isinstance(href, str):
                if "download" in text or "get" in text:
                    return href
                if href.endswith(BOOK_EXTENSIONS_TUPLE):
                    return href

        return None
