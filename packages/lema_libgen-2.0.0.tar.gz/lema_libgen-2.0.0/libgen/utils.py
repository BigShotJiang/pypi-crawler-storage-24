import re
from typing import FrozenSet, List, Optional, Tuple
from urllib.parse import urljoin


BOOK_EXTENSIONS_COMMON: FrozenSet[str] = frozenset(
    {
        "pdf",
        "epub",
        "mobi",
        "djvu",
        "fb2",
        "azw3",
        "txt",
        "rtf",
    }
)

BOOK_EXTENSIONS_COMICS: FrozenSet[str] = frozenset(
    {
        "cbr",
        "cbz",
        "cb7",
        "cbt",
    }
)

BOOK_EXTENSIONS_DOCS: FrozenSet[str] = frozenset(
    {
        "doc",
        "docx",
    }
)

BOOK_EXTENSIONS_RARE: FrozenSet[str] = frozenset(
    {
        "lit",
        "oeb",
        "prc",
        "pdb",
        "tcr",
        "chm",
        "html",
        "htm",
    }
)

BOOK_EXTENSIONS_ALL: FrozenSet[str] = (
    BOOK_EXTENSIONS_COMMON
    | BOOK_EXTENSIONS_COMICS
    | BOOK_EXTENSIONS_DOCS
    | BOOK_EXTENSIONS_RARE
)

BOOK_EXTENSIONS_TUPLE: Tuple[str, ...] = tuple(sorted(BOOK_EXTENSIONS_ALL))

BOOK_EXTENSIONS_BY_FORMAT = {
    "ebook": {"epub", "mobi", "azw3", "fb2", "lit", "oeb", "prc", "pdb", "tcr"},
    "document": {"pdf", "djvu", "txt", "rtf", "doc", "docx", "chm", "html", "htm"},
    "comics": {"cbr", "cbz", "cb7", "cbt"},
}


def is_book_extension(filename_or_url: str) -> bool:
    ext = filename_or_url.rsplit(".", 1)[-1].lower()
    return ext in BOOK_EXTENSIONS_ALL


def get_extension_category(ext: str) -> Optional[str]:
    ext = ext.lower().lstrip(".")
    for category, extensions in BOOK_EXTENSIONS_BY_FORMAT.items():
        if ext in extensions:
            return category
    return None


def sanitize_filename(filename: str, max_length: int = 100) -> str:
    sanitized = re.sub(r'[<>:"/\\|?*]', "", filename)
    return sanitized[:max_length]


def extract_domain(url: str) -> Optional[str]:
    match = re.search(r"https?://([a-zA-Z0-9.-]+)", url)
    if match:
        return match.group(1).lower()
    return None


def normalize_url(url: str) -> str:
    clean_url = re.sub(r"[,/]+$", "", url).rstrip("/")
    return clean_url


def resolve_url(base_url: str, relative_path: str) -> str:
    return urljoin(base_url, relative_path)


def extract_mirrors_from_html(html: str) -> List[str]:
    pattern = r'https?://[a-zA-Z0-9.-]*libgen\.[a-zA-Z]{2,}(?:/[^\s<>"\)\,]*)?'
    mirrors = re.findall(pattern, html, re.IGNORECASE)
    return list(set(mirrors))


def dedupe_mirrors_by_domain(mirrors: List[str]) -> List[str]:
    unique_mirrors: List[str] = []
    seen_domains: set = set()

    for mirror in mirrors:
        clean_url = normalize_url(mirror)
        domain = extract_domain(clean_url)
        if domain and domain not in seen_domains:
            seen_domains.add(domain)
            unique_mirrors.append(clean_url)

    return unique_mirrors


def parse_authors(authors_text: str) -> List[str]:
    if not authors_text:
        return []
    return [a.strip() for a in re.split(r"[,;]", authors_text) if a.strip()]


def parse_size_and_file_id(size_cell_html: str) -> Tuple[str, str]:
    size = ""
    file_id = ""
    size_match = re.search(r">([^<]+)<", size_cell_html)
    if size_match:
        size = size_match.group(1).strip()
    file_id_match = re.search(r"file\.php\?id=(\d+)", size_cell_html)
    if file_id_match:
        file_id = file_id_match.group(1)
    return size, file_id


LIBGEN_MIRROR_PATTERN = re.compile(
    r"https?://[a-zA-Z0-9.-]*libgen\.[a-zA-Z]{2,}", re.IGNORECASE
)

DEFAULT_MIRROR = "https://libgen.li"
