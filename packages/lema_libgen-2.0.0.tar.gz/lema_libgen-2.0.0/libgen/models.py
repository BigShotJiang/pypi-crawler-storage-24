from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Book:
    id: str
    timeadd: Optional[str]
    title: str
    series: Optional[str]
    authors: List[str]
    publisher: Optional[str]
    year: Optional[str]
    language: Optional[str]
    pages: Optional[str]
    size: Optional[str]
    extension: Optional[str]
    mirrors: List[str]
    cover: Optional[str] = None

    def __repr__(self) -> str:
        authors_str = ", ".join(self.authors[:3])
        if len(self.authors) > 3:
            authors_str += "..."
        return f"Book(id={self.id!r}, title={self.title!r}, authors=[{authors_str}])"
