import random
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class ProxyConfig:
    url: str

    @property
    def proxy_type(self) -> str:
        if self.url.startswith("socks5://") or self.url.startswith("socks4://"):
            return "socks"
        return "http"

    @property
    def is_socks(self) -> bool:
        return self.proxy_type == "socks"


class ProxyManager:
    def __init__(self, proxies: Optional[List[str]] = None):
        self._proxies: List[ProxyConfig] = []
        if proxies:
            for proxy in proxies:
                if proxy and proxy.strip():
                    self._proxies.append(ProxyConfig(url=proxy.strip()))

    def add_proxy(self, proxy: str) -> None:
        if proxy and proxy.strip():
            self._proxies.append(ProxyConfig(url=proxy.strip()))

    def add_proxies(self, proxies: List[str]) -> None:
        for proxy in proxies:
            self.add_proxy(proxy)

    def get_random(self) -> Optional[str]:
        if not self._proxies:
            return None
        config = random.choice(self._proxies)
        return config.url

    def get_all(self) -> List[str]:
        return [p.url for p in self._proxies]

    def count(self) -> int:
        return len(self._proxies)

    def is_empty(self) -> bool:
        return len(self._proxies) == 0

    @staticmethod
    def is_socks_url(url: str) -> bool:
        return url.startswith("socks5://") or url.startswith("socks4://")

    def __repr__(self) -> str:
        return f"ProxyManager(proxies={self.count()})"
