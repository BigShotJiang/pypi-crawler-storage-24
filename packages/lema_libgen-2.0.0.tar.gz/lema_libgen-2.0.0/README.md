<p align="center">
  <h1 align="center">📚 lema-libgen</h1>
  <p align="center">
    <em>A powerful Library Genesis scraper and downloader with async support, mirror management, and extensive book metadata extraction</em>
  </p>
  <p align="center">
    <a href="https://pypi.org/project/lema-libgen/"><img alt="PyPI" src="https://img.shields.io/pypi/v/lema-libgen?color=blue"></a>
    <a href="https://pypi.org/project/lema-libgen/"><img alt="Python" src="https://img.shields.io/pypi/pyversions/lema-libgen"></a>
    <img alt="License" src="https://img.shields.io/badge/license-MIT-green">
  </p>
</p>

---

## ✨ Features

- 🔍 **Full-text search** with pagination support
- 📥 **Async & sync downloads** with automatic mirror fallback
- 🪞 **Mirror management** - discover, check availability, and prioritize mirrors
- 📊 **Rich metadata extraction** - title, authors, series, publisher, year, language, pages, size, extension, and cover images
- 🖼️ **Cover image support** - optionally fetch book covers during search
- 🔄 **Custom downloaders** - extensible downloader system for different mirror types
- ⚡ **Parallel mirror checking** - concurrent health checks with configurable workers

---

## 📦 Installation

```bash
pip install lema-libgen
```

---

## 🚀 Quick Start

```python
from libgen import LibGen

lg = LibGen()

# Search for books
books = lg.search("python programming", results=25)

for book in books[:5]:
    print(f"📖 {book.title}")
    print(f"   Authors: {', '.join(book.authors)}")
    print(f"   Size: {book.size} | Format: {book.extension}")
    print()

# Download the first book
if books:
    filepath = lg.download(books[0], output_dir="./downloads")
    print(f"✅ Downloaded to: {filepath}")
```

---

## 📖 API Reference

### Class: `LibGen`

Main client for interacting with Library Genesis.

#### Constructor

```python
LibGen(main_url: str = "https://librarygenesis.net/")
```

---

### Search Methods

#### `search()`

Search for books on a single page.

```python
def search(
    query: str,
    mirror: str = "https://libgen.li",
    results: int = 25,
    covers: bool = False,
    page: int = 1,
) -> List[Book]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `query` | `str` | required | Search query |
| `mirror` | `str` | `"https://libgen.li"` | Mirror URL to search on |
| `results` | `int` | `25` | Results per page (25, 50, or 100) |
| `covers` | `bool` | `False` | Include book cover URLs |
| `page` | `int` | `1` | Page number |

**Example:**

```python
# Basic search
books = lg.search("machine learning")

# Search with covers
books = lg.search("data science", covers=True)

# Search on specific mirror
books = lg.search("algorithms", mirror="https://libgen.is")
```

---

#### `search_pages()`

Search across multiple pages synchronously.

```python
def search_pages(
    query: str,
    mirror: str = "https://libgen.li",
    results: int = 25,
    covers: bool = False,
    start_page: int = 1,
    end_page: int = 1,
) -> List[Book]
```

**Example:**

```python
# Get results from pages 1-5
books = lg.search_pages("python", start_page=1, end_page=5)
print(f"Found {len(books)} books across 5 pages")
```

---

#### `search_pages_async()`

Asynchronously search across multiple pages for faster results.

```python
async def search_pages_async(
    query: str,
    mirror: str = "https://libgen.li",
    results: int = 25,
    covers: bool = False,
    start_page: int = 1,
    end_page: int = 1,
) -> List[Book]
```

**Example:**

```python
import asyncio

async def main():
    books = await lg.search_pages_async("rust programming", start_page=1, end_page=10)
    print(f"Found {len(books)} books")

asyncio.run(main())
```

---

### Download Methods

#### `download()`

Download a book synchronously with automatic mirror fallback.

```python
def download(
    book: Book,
    output_dir: str = ".",
    preferred_mirrors: Optional[List[str]] = None,
) -> Optional[str]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `book` | `Book` | required | Book object to download |
| `output_dir` | `str` | `"."` | Directory to save the file |
| `preferred_mirrors` | `List[str]` | `None` | Mirror domains to prioritize |

**Returns:** Path to downloaded file or `None` on failure.

**Example:**

```python
books = lg.search("clean code")

if books:
    # Download with preferred mirrors
    filepath = lg.download(
        books[0],
        output_dir="./books",
        preferred_mirrors=["libgen.li", "libgen.is"]
    )
```

---

#### `download_async()`

Download a book asynchronously.

```python
async def download_async(
    book: Book,
    output_dir: str = ".",
    preferred_mirrors: Optional[List[str]] = None,
) -> Optional[str]
```

**Example:**

```python
import asyncio

async def main():
    books = lg.search("design patterns")
    if books:
        filepath = await lg.download_async(books[0], output_dir="./downloads")
        print(f"Saved: {filepath}")

asyncio.run(main())
```

---

#### `get_download_url()`

Get the direct download URL from a mirror page.

```python
def get_download_url(mirror_url: str) -> Optional[str]
```

**Example:**

```python
books = lg.search("refactoring")
if books and books[0].mirrors:
    direct_url = lg.get_download_url(books[0].mirrors[0])
    print(f"Direct link: {direct_url}")
```

---

#### `get_download_urls()`

Get all direct download URLs for all mirrors of a book.

```python
def get_download_urls(book: Book) -> Dict[str, Optional[str]]
```

**Returns:** Dictionary mapping mirror URLs to direct download URLs.

**Example:**

```python
books = lg.search("functional programming")
if books:
    urls = lg.get_download_urls(books[0])
    for mirror, direct_url in urls.items():
        print(f"{mirror} -> {direct_url}")
```

---

### Mirror Methods

#### `get_mirrors()`

Discover available LibGen mirrors from the main page.

```python
def get_mirrors() -> List[str]
```

**Example:**

```python
mirrors = lg.get_mirrors()
print(f"Found {len(mirrors)} mirrors:")
for m in mirrors:
    print(f"  - {m}")
```

---

#### `check_mirrors()`

Check availability of mirrors with parallel requests.

```python
def check_mirrors(
    mirrors: Optional[List[str]] = None,
    max_workers: int = 10,
) -> Dict[str, Dict[str, bool | str]]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mirrors` | `List[str]` | `None` | Mirrors to check (auto-discovers if `None`) |
| `max_workers` | `int` | `10` | Concurrent workers |

**Returns:** Dictionary with mirror status:
```python
{
    "https://libgen.li": {"working": True, "status": "HTTP 200"},
    "https://libgen.is": {"working": False, "status": "Timeout"},
}
```

**Example:**

```python
status = lg.check_mirrors()

working = [m for m, info in status.items() if info["working"]]
failed = [m for m, info in status.items() if not info["working"]]

print(f"✅ Working: {len(working)}")
print(f"❌ Failed: {len(failed)}")
```

---

### Data Class: `Book`

```python
@dataclass
class Book:
    id: str                      # Book identifier
    title: str                   # Book title
    authors: List[str]           # List of authors
    mirrors: List[str]           # Download mirror URLs
    timeadd: Optional[str]       # Date added (YYYY-MM-DD)
    series: Optional[str]        # Series name
    publisher: Optional[str]     # Publisher name
    year: Optional[str]          # Publication year
    language: Optional[str]      # Language code
    pages: Optional[str]         # Number of pages
    size: Optional[str]          # File size
    extension: Optional[str]     # File extension (pdf, epub, etc.)
    cover: Optional[str]         # Cover image URL
```

**Example:**

```python
book = books[0]

print(f"Title: {book.title}")
print(f"Authors: {', '.join(book.authors)}")
print(f"Series: {book.series or 'N/A'}")
print(f"Publisher: {book.publisher}")
print(f"Year: {book.year}")
print(f"Language: {book.language}")
print(f"Pages: {book.pages}")
print(f"Size: {book.size}")
print(f"Format: {book.extension}")
print(f"Cover: {book.cover}")
print(f"Mirrors: {len(book.mirrors)} available")
```

---

## 🔧 Advanced Usage

### Async Bulk Download

```python
import asyncio
from libgen import LibGen

async def download_multiple(books, output_dir):
    lg = LibGen()
    tasks = [lg.download_async(book, output_dir) for book in books]
    return await asyncio.gather(*tasks)

async def main():
    lg = LibGen()
    books = lg.search_pages("python", start_page=1, end_page=3)[:5]
    
    results = await download_multiple(books, "./library")
    successful = [r for r in results if r]
    print(f"Downloaded {len(successful)}/{len(books)} books")

asyncio.run(main())
```

### Custom Mirror Priority

```python
# Prioritize specific mirrors for faster downloads
filepath = lg.download(
    book,
    output_dir="./books",
    preferred_mirrors=["libgen.li", "libgen.is", "library.lol"]
)
```

### Filter by Format

```python
books = lg.search("javascript")

# Get only PDF books
pdf_books = [b for b in books if b.extension == "pdf"]

# Get only EPUB books
epub_books = [b for b in books if b.extension == "epub"]

# Get ebooks (epub, mobi, azw3, fb2)
ebook_exts = {"epub", "mobi", "azw3", "fb2"}
ebooks = [b for b in books if b.extension in ebook_exts]
```

### Working with Covers

```python
# Enable covers in search
books = lg.search("art history", covers=True)

for book in books:
    if book.cover:
        print(f"📖 {book.title}")
        print(f"   Cover: {book.cover}")
```

---

## 🛠️ Extending with Custom Downloaders

Create custom downloaders for new mirror types:

```python
from libgen.downloaders import MirrorDownloader

class CustomDownloader(MirrorDownloader):
    def can_handle(self, url: str) -> bool:
        return "custom-mirror.com" in url
    
    def get_download_url(self, url: str, timeout: int = 15) -> Optional[str]:
        # Implement custom logic
        return direct_download_url

# Register the downloader
lg = LibGen()
lg.downloaders.append(CustomDownloader())
```

---

## 📋 Utility Functions

Available in `libgen.utils`:

| Function | Description |
|----------|-------------|
| `sanitize_filename(name)` | Remove invalid characters from filenames |
| `parse_authors(text)` | Parse author string into list |
| `extract_domain(url)` | Extract domain from URL |
| `is_book_extension(filename)` | Check if file is a book format |
| `get_extension_category(ext)` | Get category (ebook/document/comics) |
| `dedupe_mirrors_by_domain(mirrors)` | Remove duplicate mirrors by domain |

---

## 📝 Supported File Formats

| Category | Extensions |
|----------|------------|
| **Ebooks** | epub, mobi, azw3, fb2, lit, oeb, prc, pdb, tcr |
| **Documents** | pdf, djvu, txt, rtf, doc, docx, chm, html, htm |
| **Comics** | cbr, cbz, cb7, cbt |

---

## ⚠️ Disclaimer

This library is for educational purposes only. Always respect copyright laws and the terms of service of the websites you access.

---

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

<p align="center">
  Made with ❤️ by <a href="https://github.com/lemantorus">lemantorus</a>
</p>
