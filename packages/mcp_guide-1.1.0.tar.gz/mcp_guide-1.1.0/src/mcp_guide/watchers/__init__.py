"""Configuration-specific watcher functionality."""
