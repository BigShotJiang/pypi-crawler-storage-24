# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

…

### Changed

…

### Removed

…

## [3000.4.0] - 2026-03-24

### Added

- chore: add publish recipe ([03c114f])

### Changed

- chore: update .gitignore for IDE and agent directories ([d88b173])
- chore: update dependencies ([147834f])
- ci: add skylos workflow ([6269c0b])
- ci: harden zizmor config, add SHA pins ([76d4594])
- feat: allow onepassword-sdk-0.4 in dependencies ([01b9485])
- fix: include failed secret reference URI in resolution error message ([d5b1eda])
- fix: resolve Skylos quality and danger findings ([b3def03])
- fix: update test fixture for onepassword-sdk 0.4 compatibility ([7880b48])

## [3000.3.0] - 2026-02-13

### Added

- chore: add build recipe ([4de6b3e])
- ci: add zizmor action ([e5a453a])

### Changed

- chore: format test files ([f723cf2])
- fix: sort out package renaming for good … ([973cbc0])
- fix: tweak setuptools config after rename ([579567d])

## [3000.2.2] - 2026-02-13

**Release retracted** due to a defect rendering it non-functional.

## [3000.2.1] - 2026-02-12

**Release retracted** due to a defect rendering it non-functional.

### Changed

- chore: rename package to fix name collision ([2fbb13e])
- chore: use modern generics syntax ([bd2994a])
- chore(deps): update dependencies ([ed45385])
- chore(deps): bump actions/checkout from 5 to 6 ([94d14ec])
- ci: fix zizmor findings ([fccaa88])

## [3000.2.0] - 2025-11-24

### Added

- feat: make logging configurable by library users ([6df3acd])
- chore: add license file, headers and info in pyproject.toml ([f18dfe9])

## [3000.1.1] - 2025-11-20

### Added

- chore: add pypi classifiers and license marker to pyproject.toml ([9688a7c])

## [3000.1.0] - 2025-11-19

### Added

- feat: add support for other PostgreSQL connection schemes ([50b4692])

## [3000.0.2] - 2025-11-19

### Added

- feat: add `py.typed` marker file ([981fc8f])

### Changed

- fix: do not log a warning if dev mode is disabled ([0ddc16a])

## [3000.0.1] - 2025-11-17

### Added

- feat: export `ConfigatorSettings` at top level through `__init__.py` ([7569cb8])

### Removed

- fix: remove `print` debug statements from `core._hydrate_field` ([5ddbe83])

## [3000.0.0] - 2025-11-16

Initial release.

<!-- markdownlint-disable-file MD024 -->

[Unreleased]: https://github.com/Utiligize/configator-op/compare/v3000.4.0...HEAD
[3000.4.0]: https://github.com/Utiligize/configator-op/compare/v3000.3.0...v3000.4.0
[3000.3.0]: https://github.com/Utiligize/configator-op/compare/v3000.2.0...v3000.3.0
[3000.2.0]: https://github.com/Utiligize/configator-op/compare/v3000.1.1...v3000.2.0
[3000.1.1]: https://github.com/Utiligize/configator-op/compare/v3000.1.0...v3000.1.1
[3000.1.0]: https://github.com/Utiligize/configator-op/compare/v3000.0.2...v3000.1.0
[3000.0.2]: https://github.com/Utiligize/configator-op/compare/v3000.0.1...v3000.0.2
[3000.0.1]: https://github.com/Utiligize/configator-op/compare/v3000.0.0...v3000.0.1
[3000.0.0]: https://github.com/Utiligize/configator-op/releases/tag/v3000.0.0

<!-- only slugs below here -->
[01b9485]: https://github.com/Utiligize/configator-op/commit/01b9485654832e82861cc8c7a390cc190f38daf4
[03c114f]: https://github.com/Utiligize/configator-op/commit/03c114f08b5d0249bf2dfa4ad068871c43e89afb
[0ddc16a]: https://github.com/Utiligize/configator-op/commit/0ddc16ac3e8e0637137bf93146630198215d6546
[147834f]: https://github.com/Utiligize/configator-op/commit/147834f243868ecfe27152aad4251982b4755dbd
[2fbb13e]: https://github.com/Utiligize/configator-op/commit/2fbb13e9ab59dd72fce7f8d70cde51398d75f814
[4de6b3e]: https://github.com/Utiligize/configator-op/commit/4de6b3e5bcc06d921f3c263dd692c5ecdf95762c
[50b4692]: https://github.com/Utiligize/configator-op/commit/50b469283ea63937d8993c8b70aa1a164f32b55f
[579567d]: https://github.com/Utiligize/configator-op/commit/579567d6bd872896f25d8f0b8f9e2773407bcb59
[5ddbe83]: https://github.com/Utiligize/configator-op/commit/5ddbe839ddbb42fe72c1d5acffa2751ced5f967c
[6269c0b]: https://github.com/Utiligize/configator-op/commit/6269c0bbedd9819b672c0df25698e1544b23196e
[6df3acd]: https://github.com/Utiligize/configator-op/commit/6df3acdef891c6b60b90ea96c128b317956b1671
[7569cb8]: https://github.com/Utiligize/configator-op/commit/7569cb8540028800570513411a5ab5291ab45cc6
[76d4594]: https://github.com/Utiligize/configator-op/commit/76d459490bc57f3261ca5561b60dfb8768eb3c7c
[7880b48]: https://github.com/Utiligize/configator-op/commit/7880b4823ff164718a2bc86627af810ac00daf82
[94d14ec]: https://github.com/Utiligize/configator-op/commit/94d14eccdec1257c717d4becae2b8e7f39a4add2
[9688a7c]: https://github.com/Utiligize/configator-op/commit/9688a7c1da90d13ce2d54bd270ab6a7e3f3e5de1
[973cbc0]: https://github.com/Utiligize/configator-op/commit/973cbc0a9a8b055c20a48c8992f15b7c7eed0fb6
[981fc8f]: https://github.com/Utiligize/configator-op/commit/981fc8f4087cef661888e93bf8d147a085f04dc6
[b3def03]: https://github.com/Utiligize/configator-op/commit/b3def038d61c38f7e14cc33334da9293c64ed168
[bd2994a]: https://github.com/Utiligize/configator-op/commit/bd2994a26c44b0036d96ea0b1b28be0862a2597d
[d5b1eda]: https://github.com/Utiligize/configator-op/commit/d5b1eda3e53373bb3e69b46a3603ac1dff0f677c
[d88b173]: https://github.com/Utiligize/configator-op/commit/d88b173b1f7bb130b5d6e9a4c908328517562953
[e5a453a]: https://github.com/Utiligize/configator-op/commit/e5a453ac59fe11fbea083b9168289ef111424dc4
[ed45385]: https://github.com/Utiligize/configator-op/commit/ed45385e514b42f2d0e86391cff416086e175ea4
[f18dfe9]: https://github.com/Utiligize/configator-op/commit/f18dfe9db79c03fe90cc27535b764e2b55af5942
[f723cf2]: https://github.com/Utiligize/configator-op/commit/f723cf265a17cbbede4d65ca9eb9c408b3b66940
[fccaa88]: https://github.com/Utiligize/configator-op/commit/fccaa88d0f869a204fcc0af0a0340b8cc1577dc7
