## Backio Extensions
## Use static methods only
## All methods arguments: (jsondata, access_token)

import json

class ExtHello:
  def hello(jsondata: str, access_token: str) -> dict:
    name = json.loads(jsondata)['name']
    return {'greeting': f'Hi I am {name}'}

class ExtMath:
  def add(jsondata: str, access_token: str) -> int:
    args = json.loads(jsondata)['args']
    return {'result': f'{sum(args)}'}
