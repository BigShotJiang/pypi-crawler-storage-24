Detailed tips, tricks, and examples, can be found at project's repository
https://github.com/asinerum/backio

(C) 2026 Asinerum Conlang Project