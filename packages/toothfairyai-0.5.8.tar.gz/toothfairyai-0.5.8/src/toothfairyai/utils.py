"""Shared utilities for field name conversion."""

from typing import Dict, Any, Set


def to_camel_case(key: str) -> str:
    """Standard snake_case → camelCase conversion.
    
    Does NOT handle exceptions - use field_mappings for that.
    Keys without underscores pass through unchanged.
    
    Args:
        key: snake_case field name
        
    Returns:
        camelCase field name
    """
    if '_' not in key:
        return key
    parts = key.split('_')
    return parts[0] + ''.join(word.capitalize() for word in parts[1:])


def convert_kwargs_to_api(
    kwargs: Dict[str, Any], 
    field_mappings: Dict[str, str],
    explicit_params: Set[str] = None
) -> Dict[str, Any]:
    """Convert SDK kwargs to API field names.
    
    Args:
        kwargs: User-provided keyword arguments (snake_case keys)
        field_mappings: Per-manager field mapping dictionary for exceptions
        explicit_params: Set of params already handled explicitly (skip these)
    
    Returns:
        Dictionary with API field names (camelCase keys)
    
    Example:
        >>> convert_kwargs_to_api(
        ...     {"json_output_structure": {}, "has_ner": True},
        ...     AGENT_FIELD_MAPPINGS,
        ...     {"label", "description"}
        ... )
        {"jsonOutputStructure": {}, "hasNER": True}
    """
    explicit_params = explicit_params or set()
    result = {}
    
    for key, value in kwargs.items():
        if key in explicit_params:
            continue
            
        if key in field_mappings:
            api_key = field_mappings[key]
        else:
            api_key = to_camel_case(key)
        
        result[api_key] = value
    
    return result