"""LLM-powered authentication page detector.

Uses a lightweight LLM call against the page's ARIA Snapshot (accessibility
tree text) to semantically determine whether the current page is a login /
authentication page, replacing the keyword-based heuristics that produced
frequent false positives.

Falls back to the legacy keyword detector when the LLM is unavailable or
times out.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass
from typing import Any

from .screenshot_stream import AuthDetectionResult, AuthPageDetector
from .session import BrowserSession

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

LLM_DETECT_TIMEOUT = 5.0  # seconds
CACHE_TTL = 30.0  # seconds
_MAX_SNAPSHOT_CHARS = 6000  # truncate ARIA snapshot to keep prompt small

# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """\
You are a web-page classifier.  Given the ARIA accessibility snapshot of a
browser page you must determine whether the page is an **authentication page**
(login form, QR-code scan, CAPTCHA / human verification, or SSO redirect) or a
normal content page.

Respond with a JSON object — nothing else:
{
  "is_auth_page": true/false,
  "auth_type": "login_form" | "qr_code" | "captcha" | "sso_redirect" | "not_auth",
  "confidence": 0.0 - 1.0,
  "reasoning": "<one sentence>"
}

Classification rules:
- "login_form": page's **primary purpose** is to collect username/email +
  password.  A visible "Sign in" / "Log in" / "登录" button **with input
  fields as the main content** qualifies.
- "qr_code": page's **primary purpose** is to ask the user to scan a QR code
  (微信扫码, 扫描二维码, etc.) for authentication.
- "captcha": page shows a CAPTCHA, slider verification, SMS code, or human
  verification challenge as the **primary content**, not a secondary widget.
- "sso_redirect": page is a corporate SSO / OAuth consent screen asking the
  user to authorise or select an account.
- "not_auth": everything else.

**Critical false-positive avoidance rules:**
1. Pages that merely *mention* authentication concepts (e.g. developer docs
   about OAuth, settings pages with a password-change section buried in a
   form) are **not_auth**.
2. **Social media home feeds, dashboards, or content pages** that show a
   user's feed, timeline, posts, or personalized content are **not_auth**
   even if they contain login/QR-code related text in navigation bars,
   sidebars, footers, pop-up templates, or hidden elements.
3. If the page shows signs of a logged-in user (e.g. "发布" button, user
   avatar, timeline/feed content, "退出登录", "个人中心"), it is
   **not_auth** regardless of any auth keywords found elsewhere on the page.
4. Only classify as auth when the page's **primary and dominant purpose** is
   to collect credentials or authorise the user."""


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------


@dataclass
class _CacheEntry:
    result: AuthDetectionResult
    expires_at: float


_cache: dict[str, _CacheEntry] = {}


def _cache_key(url: str, snapshot_text: str) -> str:
    h = hashlib.md5((url + snapshot_text[:500]).encode(), usedforsecurity=False).hexdigest()
    return f"{url}:{h}"


def _get_cached(key: str) -> AuthDetectionResult | None:
    entry = _cache.get(key)
    if entry and entry.expires_at > time.monotonic():
        return entry.result
    _cache.pop(key, None)
    return None


def _put_cached(key: str, result: AuthDetectionResult) -> None:
    _cache[key] = _CacheEntry(result=result, expires_at=time.monotonic() + CACHE_TTL)
    # Evict expired entries periodically
    if len(_cache) > 50:
        now = time.monotonic()
        expired = [k for k, v in _cache.items() if v.expires_at <= now]
        for k in expired:
            _cache.pop(k, None)


# ---------------------------------------------------------------------------
# LLM auth detector
# ---------------------------------------------------------------------------


class LLMAuthDetector:
    """Detect auth pages by asking an LLM to analyse the ARIA snapshot.

    Usage::

        detector = LLMAuthDetector(session)
        result = await detector.detect()
    """

    def __init__(self, session: BrowserSession) -> None:
        self._session = session
        self._fallback = AuthPageDetector(session)

    async def detect(self) -> AuthDetectionResult:
        """Analyse the current page for authentication indicators.

        Tries the LLM first; falls back to keyword heuristics on failure
        or timeout.
        """
        session = self._session
        if not session.cdp or not session.cdp.context:
            return AuthDetectionResult()

        try:
            pages = session.cdp.context.pages
            if not pages:
                return AuthDetectionResult()
            page = pages[0]
            url = page.url
            session.current_url = url
        except Exception:
            return AuthDetectionResult()

        # Obtain ARIA snapshot
        try:
            snapshot_text: str = await asyncio.wait_for(
                page.locator(":root").aria_snapshot(),
                timeout=3.0,
            )
        except Exception as exc:
            logger.debug("ARIA snapshot failed, falling back to keywords: %s", exc)
            return await self._fallback.detect()

        if not snapshot_text:
            return await self._fallback.detect()

        # Truncate
        if len(snapshot_text) > _MAX_SNAPSHOT_CHARS:
            snapshot_text = snapshot_text[:_MAX_SNAPSHOT_CHARS] + "\n…(truncated)"

        # Check cache
        key = _cache_key(url, snapshot_text)
        cached = _get_cached(key)
        if cached is not None:
            return cached

        # Call LLM
        try:
            result = await asyncio.wait_for(
                self._call_llm(url, snapshot_text),
                timeout=LLM_DETECT_TIMEOUT,
            )
            _put_cached(key, result)
            return result
        except TimeoutError:
            logger.warning("LLM auth detection timed out — falling back to keywords")
        except Exception as exc:
            logger.warning("LLM auth detection failed — falling back to keywords: %s", exc)

        return await self._fallback.detect()

    async def _call_llm(self, url: str, snapshot_text: str) -> AuthDetectionResult:
        """Send the ARIA snapshot to the LLM and parse its response."""
        model = _get_model()
        if model is None:
            raise RuntimeError("No LLM model available")

        from langchain_core.messages import HumanMessage, SystemMessage

        user_content = f"Page URL: {url}\n\nARIA Snapshot:\n{snapshot_text}"
        response = await model.ainvoke(
            [
                SystemMessage(content=_SYSTEM_PROMPT),
                HumanMessage(content=user_content),
            ],
        )

        return _parse_llm_response(response.content, url)


# ---------------------------------------------------------------------------
# Model lazy-init
# ---------------------------------------------------------------------------

_model_instance: Any = None


def _get_model() -> Any:
    """Lazily create a lightweight chat model for auth detection."""
    global _model_instance
    if _model_instance is not None:
        return _model_instance

    try:
        from ...langgraph.model_factory import create_chat_model

        _model_instance = create_chat_model()
        logger.info("LLMAuthDetector: created chat model for auth page detection")
        return _model_instance
    except Exception as exc:
        logger.warning("LLMAuthDetector: failed to create model: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Response parser
# ---------------------------------------------------------------------------


def _parse_llm_response(content: str, url: str) -> AuthDetectionResult:
    """Parse the LLM's JSON response into an AuthDetectionResult."""
    result = AuthDetectionResult(url=url)

    # Strip markdown code fences if present
    text = content.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [ln for ln in lines if not ln.startswith("```")]
        text = "\n".join(lines).strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        logger.debug("LLM returned non-JSON: %s", text[:200])
        return result

    result.is_auth_page = bool(data.get("is_auth_page", False))
    result.auth_type = str(data.get("auth_type", "not_auth"))
    result.confidence = float(data.get("confidence", 0.0))
    result.detail = str(data.get("reasoning", ""))

    return result
