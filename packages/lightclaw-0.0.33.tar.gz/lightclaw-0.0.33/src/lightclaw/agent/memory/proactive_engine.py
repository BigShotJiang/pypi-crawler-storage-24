"""
Proactive outreach engine (LightClaw differentiator, not present in openclaw).

v2 architecture: Engine-Driven with Callbacks

How it works:
1. _run_loop() fires on a timer (initial sleep + check_interval)
2. evaluate_and_trigger():
   a. fetch_candidates(): Qdrant payload filter (dual-layer cooldown) + dense vector search
   b. Determine mode: "topic" (has candidates) or "caring" (no candidates)
   c. Call on_evaluate(candidates, mode) callback (implemented in proactivity.py)
   d. If dispatched: update_cooldowns() writes back to Qdrant payload

Qdrant payload fields (set by qdrant_indexer.py at write time):
  proactive_enabled: bool                    — whether proactive outreach is enabled
  proactive_time_window: str                 — outreach time window (reserved)
  proactive_priority: int                    — priority (memory=1, sessions=0)
  proactive_last_triggered_at: datetime      — chunk-level cooldown
  proactive_file_last_triggered_at: datetime — file-level cooldown
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .qdrant_indexer import QdrantMemoryIndexer

logger = logging.getLogger(__name__)

# ── Time window definitions ──────────────────────────────────────────────────
TIME_WINDOW_MORNING = "morning"  # 06:00 - 11:59
TIME_WINDOW_AFTERNOON = "afternoon"  # 12:00 - 17:59
TIME_WINDOW_EVENING = "evening"  # 18:00 - 21:59
TIME_WINDOW_NIGHT = "night"  # 22:00 - 05:59

# Payload field names
PAYLOAD_PROACTIVE_ENABLED = "proactive_enabled"
PAYLOAD_PROACTIVE_TIME_WINDOW = "proactive_time_window"
PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT = "proactive_last_triggered_at"
PAYLOAD_PROACTIVE_FILE_LAST_TRIGGERED_AT = "proactive_file_last_triggered_at"
PAYLOAD_PROACTIVE_PRIORITY = "proactive_priority"

# Default cooldown durations
DEFAULT_CHUNK_COOLDOWN_HOURS = 2.0
DEFAULT_FILE_COOLDOWN_HOURS = 8.0
DEFAULT_MAX_CANDIDATES = 5


def get_current_time_window(now: datetime | None = None) -> str:
    """Return the time window name based on current time. Uses local timezone."""
    dt = now or datetime.now().astimezone()
    hour = dt.hour
    if 6 <= hour < 12:
        return TIME_WINDOW_MORNING
    if 12 <= hour < 18:
        return TIME_WINDOW_AFTERNOON
    if 18 <= hour < 22:
        return TIME_WINDOW_EVENING
    return TIME_WINDOW_NIGHT


def get_time_window_greeting(time_window: str, language: str = "zh") -> str:
    """Return a greeting for the given time window."""
    if language == "zh":
        greetings = {
            TIME_WINDOW_MORNING: "早上好",
            TIME_WINDOW_AFTERNOON: "下午好",
            TIME_WINDOW_EVENING: "晚上好",
            TIME_WINDOW_NIGHT: "夜深了",
        }
    else:
        greetings = {
            TIME_WINDOW_MORNING: "Good morning",
            TIME_WINDOW_AFTERNOON: "Good afternoon",
            TIME_WINDOW_EVENING: "Good evening",
            TIME_WINDOW_NIGHT: "It's late",
        }
    return greetings.get(time_window, "")


# ── Data types ────────────────────────────────────────────────────────────────


@dataclass
class CandidateResult:
    """Structured candidate memory chunk returned by fetch_candidates()."""

    point_id: str
    chunk_id: str
    path: str
    snippet: str
    priority: int = 0
    score: float = 0.0
    final_score: float = 0.0  # priority-weighted score


@dataclass
class ProactiveConfig:
    """Proactive outreach engine configuration."""

    enabled: bool = False
    check_interval_seconds: float = 3600.0
    chunk_cooldown_hours: float = DEFAULT_CHUNK_COOLDOWN_HOURS
    file_cooldown_hours: float = DEFAULT_FILE_COOLDOWN_HOURS
    max_candidates: int = DEFAULT_MAX_CANDIDATES
    language: str = "zh"
    # v2 callback: on_evaluate(candidates, mode) -> bool (dispatched?)
    on_evaluate: Callable[[list[CandidateResult], str], Coroutine[Any, Any, bool]] | None = None
    # v1 legacy callback: on_trigger(message) -> None (standalone mode)
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None

    # Backward compatibility: cooldown_hours maps to file_cooldown_hours
    @property
    def cooldown_hours(self) -> float:
        return self.file_cooldown_hours

    @cooldown_hours.setter
    def cooldown_hours(self, value: float) -> None:
        self.file_cooldown_hours = value


@dataclass
class ProactiveTriggerResult:
    """Proactive outreach result."""

    triggered: bool
    mode: str = ""  # "topic" | "caring"
    candidates: list[CandidateResult] = field(default_factory=list)
    time_window: str = ""


def create_proactive_config_from_env(
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None,
    on_evaluate: Callable[[list[CandidateResult], str], Coroutine[Any, Any, bool]] | None = None,
) -> ProactiveConfig:
    """Create ProactiveConfig from environment variables."""
    return ProactiveConfig(
        enabled=os.environ.get("PROACTIVE_MEMORY_ENABLED", "false").lower() == "true",
        check_interval_seconds=float(os.environ.get("PROACTIVE_CHECK_INTERVAL_SECONDS", "3600")),
        chunk_cooldown_hours=float(
            os.environ.get("PROACTIVE_CHUNK_COOLDOWN_HOURS", str(DEFAULT_CHUNK_COOLDOWN_HOURS))
        ),
        file_cooldown_hours=float(
            os.environ.get("PROACTIVE_FILE_COOLDOWN_HOURS", str(DEFAULT_FILE_COOLDOWN_HOURS))
        ),
        max_candidates=int(os.environ.get("PROACTIVE_MAX_CANDIDATES", str(DEFAULT_MAX_CANDIDATES))),
        language=os.environ.get("PROACTIVE_LANGUAGE", "zh"),
        on_trigger=on_trigger,
        on_evaluate=on_evaluate,
    )


# ── Engine ────────────────────────────────────────────────────────────────────


class ProactiveMemoryEngine:
    """
    Proactive outreach engine.

    v2 architecture: fetch_candidates() → on_evaluate callback → update_cooldowns()

    Qdrant payload filter dual-layer cooldown:
      - chunk-level: proactive_last_triggered_at (default 2h)
      - file-level: proactive_file_last_triggered_at (default 8h)
    """

    def __init__(
        self,
        indexer: QdrantMemoryIndexer,
        embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None,
        config: ProactiveConfig,
    ) -> None:
        self.indexer = indexer
        self.embedding_fn = embedding_fn
        self.config = config
        self._task: asyncio.Task | None = None
        self._closed = False

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the periodic check task."""
        if not self.config.enabled:
            logger.info("ProactiveMemoryEngine: disabled")
            return
        if self._task is not None and not self._task.done():
            logger.debug("ProactiveMemoryEngine: already running")
            return
        self._closed = False
        self._task = asyncio.create_task(self._run_loop())
        logger.info(
            "ProactiveMemoryEngine: started (interval=%.0fs, chunk_cd=%.1fh, file_cd=%.1fh)",
            self.config.check_interval_seconds,
            self.config.chunk_cooldown_hours,
            self.config.file_cooldown_hours,
        )

    def stop(self) -> None:
        """Stop the periodic check task."""
        self._closed = True
        if self._task is not None and not self._task.done():
            self._task.cancel()
            self._task = None
        logger.info("ProactiveMemoryEngine: stopped")

    # ── Core logic ─────────────────────────────────────────────────────────────

    async def evaluate_and_trigger(
        self,
        now: datetime | None = None,
    ) -> ProactiveTriggerResult:
        """
        Evaluate and trigger proactive message.

        Flow: fetch_candidates → determine mode → call on_evaluate → update_cooldowns
        """
        now_dt = now or datetime.now(UTC)
        time_window = get_current_time_window(now_dt)

        # Step 1: fetch candidates with Qdrant payload filter + vector search
        candidates = await self.fetch_candidates(
            chunk_cooldown_hours=self.config.chunk_cooldown_hours,
            file_cooldown_hours=self.config.file_cooldown_hours,
            max_results=self.config.max_candidates,
        )

        # Step 2: determine mode
        mode = "topic" if candidates else "caring"

        # Step 3: call callback
        dispatched = False
        if self.config.on_evaluate is not None:
            # v2 path: structured candidates + mode
            try:
                dispatched = await self.config.on_evaluate(candidates, mode)
            except Exception as exc:
                logger.warning("ProactiveMemoryEngine: on_evaluate failed: %s", exc)
                return ProactiveTriggerResult(
                    triggered=False, mode=mode, candidates=candidates, time_window=time_window
                )
        elif self.config.on_trigger is not None:
            # v1 legacy path: build message string for standalone mode
            if candidates:
                message = self._build_proactive_message(candidates[0], time_window)
                try:
                    await self.config.on_trigger(message)
                    dispatched = True
                except Exception as exc:
                    logger.warning("ProactiveMemoryEngine: on_trigger failed: %s", exc)
            else:
                # Caring mode for legacy callback
                try:
                    await self.config.on_trigger("")
                except Exception as exc:
                    logger.warning("ProactiveMemoryEngine: on_trigger (caring) failed: %s", exc)

        # Step 4: update cooldowns on dispatch success
        if dispatched and candidates:
            await self.update_cooldowns(candidates)

        logger.info(
            "ProactiveMemoryEngine: mode=%s, candidates=%d, dispatched=%s",
            mode,
            len(candidates),
            dispatched,
        )

        return ProactiveTriggerResult(
            triggered=dispatched,
            mode=mode,
            candidates=candidates,
            time_window=time_window,
        )

    async def fetch_candidates(
        self,
        chunk_cooldown_hours: float | None = None,
        file_cooldown_hours: float | None = None,
        max_results: int | None = None,
    ) -> list[CandidateResult]:
        """
        Fetch candidate memory chunks from Qdrant using vector search.

        When embedding_fn is available:
          Phase 1: payload filter (proactive_enabled + dual-layer cooldown)
          Phase 2: dense vector search (time-context ranking)

        When embedding_fn is None:
          Return empty list. LLM will call memory_search tool to find topics.

        Returns CandidateResult list sorted by final_score descending.
        """
        # When no embedding_fn, let LLM handle search via memory_search tool
        if self.embedding_fn is None:
            logger.info("ProactiveMemoryEngine.fetch_candidates: embedding_fn=None, deferring to LLM memory_search")
            return []

        chunk_cd = chunk_cooldown_hours or self.config.chunk_cooldown_hours
        file_cd = file_cooldown_hours or self.config.file_cooldown_hours
        limit = max_results or self.config.max_candidates

        logger.info("ProactiveMemoryEngine.fetch_candidates: embedding_fn=available, using vector search")

        # Build search query — don't hardcode time window, let the LLM agent
        # determine time via get_current_time tool and choose appropriate topic/greeting
        if self.config.language == "zh":
            query = "有什么值得关注或聊的事情，最近发生了什么有趣的"
        else:
            query = "what's worth noting or chatting about, anything interesting recently"

        # Vector search with embedding_fn
        try:
            embeddings = await self.embedding_fn([query])
            query_vec = embeddings[0] if embeddings else []
        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: embedding failed: %s", exc)
            return []

        if not query_vec:
            return []

        # Build Qdrant payload filter: enabled + dual-layer cooldown
        now = datetime.now(UTC)
        chunk_cutoff = (now - timedelta(hours=chunk_cd)).isoformat()
        file_cutoff = (now - timedelta(hours=file_cd)).isoformat()

        try:
            from qdrant_client.models import (
                DatetimeRange,
                FieldCondition,
                Filter,
                MatchValue,
            )

            # Dual-layer cooldown filter conditions:
            # chunk_level: last_triggered_at IS NULL OR < chunk_cutoff
            # file_level: file_last_triggered_at IS NULL OR < file_cutoff
            #
            # Qdrant Filter doesn't support OR, so use must_not inversion:
            # must_not: [triggered_at >= cutoff] is equivalent to triggered_at < cutoff OR NULL
            chunk_cooldown_filter = FieldCondition(
                key=PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT,
                range=DatetimeRange(gte=chunk_cutoff),
            )
            file_cooldown_filter = FieldCondition(
                key=PAYLOAD_PROACTIVE_FILE_LAST_TRIGGERED_AT,
                range=DatetimeRange(gte=file_cutoff),
            )

            query_filter = Filter(
                must_not=[
                    # Exclude explicitly disabled chunks (proactive_enabled=False)
                    # Old chunks without this field are not excluded
                    FieldCondition(
                        key=PAYLOAD_PROACTIVE_ENABLED,
                        match=MatchValue(value=False),
                    ),
                    chunk_cooldown_filter,
                    file_cooldown_filter,
                ],
            )

            response = await self.indexer.client.query_points(
                collection_name=self.indexer.collection_name,
                query=query_vec,
                query_filter=query_filter,
                limit=limit,
                with_payload=True,
                score_threshold=0.3,
            )

            logger.info("ProactiveMemoryEngine: vector search returned %d points", len(response.points) if response.points else 0)

            if not response.points:
                return []

            # Build CandidateResult list
            candidates: list[CandidateResult] = []
            for hit in response.points:
                payload = hit.payload or {}
                priority = int(payload.get("proactive_priority", 0))
                score = float(hit.score)
                # Priority weighting: memory(1) gets 1.2x boost
                final_score = score * (1.0 + priority * 0.2)
                candidates.append(
                    CandidateResult(
                        point_id=str(hit.id),
                        chunk_id=payload.get("chunk_id", str(hit.id)),
                        path=payload.get("path", ""),
                        snippet=payload.get("snippet", ""),
                        priority=priority,
                        score=score,
                        final_score=final_score,
                    )
                )

            # Sort by final_score descending
            candidates.sort(key=lambda c: c.final_score, reverse=True)
            return candidates

        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: fetch_candidates failed: %s", exc)
            return []

    async def update_cooldowns(self, candidates: list[CandidateResult]) -> None:
        """
        Batch update Qdrant payload cooldown fields.

        For all candidate chunks and their same-file sibling chunks, update:
        - proactive_last_triggered_at (chunk-level, all candidate chunks)
        - proactive_file_last_triggered_at (file-level, all chunks with same path)

        This is a coarse-grained strategy — avoids tracking which candidate the agent actually referenced.
        """
        if not candidates:
            return

        now_iso = datetime.now(UTC).isoformat()

        # 1. Update chunk-level cooldown for all candidate chunks
        point_ids = [c.point_id for c in candidates]
        try:
            from qdrant_client.models import PointIdsList

            await self.indexer.client.set_payload(
                collection_name=self.indexer.collection_name,
                payload={PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT: now_iso},
                points=PointIdsList(points=point_ids),
            )
            logger.debug("update_cooldowns: chunk-level updated %d points", len(point_ids))
        except Exception as exc:
            logger.warning("update_cooldowns: chunk-level update failed: %s", exc)

        # 2. Update file-level cooldown for all candidate file paths (including sibling chunks)
        unique_paths = list({c.path for c in candidates if c.path})
        for path in unique_paths:
            try:
                from qdrant_client.models import FieldCondition, Filter, MatchValue

                await self.indexer.client.set_payload(
                    collection_name=self.indexer.collection_name,
                    payload={PAYLOAD_PROACTIVE_FILE_LAST_TRIGGERED_AT: now_iso},
                    points=Filter(
                        must=[FieldCondition(key="path", match=MatchValue(value=path))]
                    ),
                )
                logger.debug("update_cooldowns: file-level updated path=%s", path)
            except Exception as exc:
                logger.warning("update_cooldowns: file-level update failed for %s: %s", path, exc)

    def _build_proactive_message(
        self,
        candidate: CandidateResult,
        time_window: str,
    ) -> str:
        """Build proactive message text from candidate memory (v1 legacy callback)."""
        greeting = get_time_window_greeting(time_window, self.config.language)
        snippet = candidate.snippet.strip()

        if not snippet:
            return greeting

        if self.config.language == "zh":
            return f"{greeting}！我想起了一件事：\n\n{snippet}"
        return f"{greeting}! I just remembered something:\n\n{snippet}"

    # ── Periodic loop ──────────────────────────────────────────────────────────

    async def _run_loop(self) -> None:
        """
        Periodic check loop.

        Sleeps one full interval before the first check
        to avoid triggering immediately on startup.
        """
        logger.info(
            "ProactiveMemoryEngine: loop started (interval=%.0fs)",
            self.config.check_interval_seconds,
        )
        # Initial wait
        try:
            await asyncio.sleep(self.config.check_interval_seconds)
        except asyncio.CancelledError:
            raise

        while not self._closed:
            try:
                result = await self.evaluate_and_trigger()
                if result.triggered:
                    logger.info(
                        "ProactiveMemoryEngine: triggered mode=%s window=%s",
                        result.mode,
                        result.time_window,
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("ProactiveMemoryEngine: loop error: %s", exc)

            try:
                await asyncio.sleep(self.config.check_interval_seconds)
            except asyncio.CancelledError:
                raise

        logger.info("ProactiveMemoryEngine: loop stopped")


# ── Factory function ──────────────────────────────────────────────────────────


def create_proactive_engine(
    indexer: QdrantMemoryIndexer,
    embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None = None,
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None,
    on_evaluate: Callable[[list[CandidateResult], str], Coroutine[Any, Any, bool]] | None = None,
) -> ProactiveMemoryEngine:
    """
    Factory function: create ProactiveMemoryEngine from environment variables.

    Args:
        indexer       — QdrantMemoryIndexer instance
        embedding_fn  — Async embedding function
        on_trigger    — v1 trigger callback (receives message text)
        on_evaluate   — v2 trigger callback (receives candidate list + mode, returns whether dispatched)
    """
    config = create_proactive_config_from_env(on_trigger=on_trigger, on_evaluate=on_evaluate)
    return ProactiveMemoryEngine(
        indexer=indexer,
        embedding_fn=embedding_fn,
        config=config,
    )
