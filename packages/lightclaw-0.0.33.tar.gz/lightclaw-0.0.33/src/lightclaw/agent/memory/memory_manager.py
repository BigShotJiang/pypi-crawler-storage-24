"""Memory manager independent from AgentScope runtime types."""

from __future__ import annotations

import asyncio
import datetime
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ...config.utils import load_config
from ...constant import MEMORY_COMPACT_RATIO
from .compaction_config import CompactionConfig
from .compaction_service import CompactionService
from .distillation_service import DistillationService
from .memory_query_service import MemoryQueryService
from .memory_store import MemoryBackendBootstrapper
from .message_text_adapter import extract_message_text
from .session_distillation_service import SessionDistillationService
from .summary_service import SummaryService

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel as LCBaseChatModel

    from .memory_store import MemoryIndexer, MemorySearcher

logger = logging.getLogger(__name__)

class MemoryManager:
    """Stateful facade for all memory-related runtime operations.

    This class keeps runtime dependencies (model, backend handles, config)
    and exposes stable APIs used by middleware/tools. Most heavy business
    logic lives in dedicated services and is delegated from here.
    """

    def __init__(
        self,
        working_dir: str,
    ):
        config = load_config()
        max_input_length = config.agents.running.max_input_length
        self._memory_compact_threshold = int(
            max_input_length * MEMORY_COMPACT_RATIO * 0.7,
        )

        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        vector_enabled = bool(embedding_api_key)
        if vector_enabled:
            logger.info("Vector search enabled.")
        else:
            logger.info(
                "Vector search disabled (keyword-only mode). Enable in Settings → Memory.",
            )

        self.working_dir = working_dir
        self.embedding_api_key = embedding_api_key
        self.embedding_base_url = embedding_base_url
        self.embedding_model_name = embedding_model_name
        self.embedding_dimensions = embedding_dimensions
        self.embedding_cache_enabled = embedding_cache_enabled
        self.embedding_max_cache_size = embedding_max_cache_size
        self.embedding_max_input_length = embedding_max_input_length
        self.embedding_max_batch_size = embedding_max_batch_size

        global_config = load_config()
        self.language = "zh" if global_config.agents.language == "zh" else ""
        self.summary_tasks: list[asyncio.Task] = []

        self.langchain_chat_model: LCBaseChatModel | None = None

        # Memory retrieval backend adapters injected by bootstrapper
        # (may be hybrid or FTS-only).
        self._memory_indexer: MemoryIndexer | None = None
        self._memory_searcher: MemorySearcher | None = None
        self._backend_bootstrapper: MemoryBackendBootstrapper | None = None
        self._compaction_service = CompactionService()
        self._summary_service = SummaryService()
        self._query_service = MemoryQueryService()
        self._distillation_service = DistillationService()
        self._distillation_service.configure(
            interval_days=int(os.environ.get("LIGHTCLAW_DISTILL_INTERVAL_DAYS", "1")),
            lookback_days=int(os.environ.get("LIGHTCLAW_DISTILL_LOOKBACK_DAYS", "7")),
        )
        self._session_distillation_service = SessionDistillationService()
        self._session_distillation_service.configure(
            interval_hours=int(os.environ.get("LIGHTCLAW_SESSION_DISTILL_INTERVAL_HOURS", "6")),
            max_chars_per_run=int(os.environ.get("LIGHTCLAW_SESSION_DISTILL_MAX_CHARS", "30000")),
        )

    @staticmethod
    def _safe_int(value: str | None, default: int) -> int:
        """Parse ``value`` as int; fall back to ``default`` on invalid input."""
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            logger.warning("Invalid int value '%s', using default %d", value, default)
            return default

    @staticmethod
    def get_emb_envs():
        """Resolve embedding runtime settings from config and environment."""
        # Prefer config embedding settings; environment variables act as fallback.
        try:
            cfg_embedding = load_config().embedding
        except Exception:
            cfg_embedding = None

        if cfg_embedding is not None and cfg_embedding.provider == "custom":
            # Custom provider: read from config, allow env override.
            embedding_api_key = os.environ.get("EMBEDDING_API_KEY", "") or cfg_embedding.api_key
            embedding_base_url = os.environ.get("EMBEDDING_BASE_URL", "") or cfg_embedding.base_url
            embedding_model_name = os.environ.get("EMBEDDING_MODEL_NAME", "") or cfg_embedding.model_name
            default_dimensions = cfg_embedding.dimensions
        else:
            # None/local provider or config read failure: env-only fallback.
            embedding_api_key = os.environ.get("EMBEDDING_API_KEY", "")
            embedding_base_url = os.environ.get("EMBEDDING_BASE_URL", "")
            embedding_model_name = os.environ.get("EMBEDDING_MODEL_NAME", "")
            default_dimensions = 1024

        # Graceful degradation: log info instead of warnings when embedding
        # env vars are not configured — this is expected when provider="none".
        # Vector search will be disabled automatically (see __init__).
        if not embedding_base_url:
            logger.info(
                "EMBEDDING_BASE_URL not set. Memory vector search disabled. "
                "Enable in Settings → Memory to use semantic search."
            )
        if not embedding_model_name:
            logger.info("EMBEDDING_MODEL_NAME not set. Memory vector search disabled.")

        embedding_dimensions = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_DIMENSIONS"),
            default_dimensions,
        )
        embedding_cache_enabled = os.environ.get("EMBEDDING_CACHE_ENABLED", "true").lower() == "true"
        embedding_max_cache_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_CACHE_SIZE"),
            2000,
        )
        embedding_max_input_length = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_INPUT_LENGTH"),
            8192,
        )
        embedding_max_batch_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_BATCH_SIZE"),
            10,
        )
        return (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        )

    def update_emb_envs(self):
        """Refresh embedding-related fields on the running manager instance."""
        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        self.embedding_api_key = embedding_api_key
        self.embedding_base_url = embedding_base_url
        self.embedding_model_name = embedding_model_name
        self.embedding_dimensions = embedding_dimensions
        self.embedding_cache_enabled = embedding_cache_enabled
        self.embedding_max_cache_size = embedding_max_cache_size
        self.embedding_max_input_length = embedding_max_input_length
        self.embedding_max_batch_size = embedding_max_batch_size

    async def start(self):
        """Start memory backend bootstrap and inject index/search adapters."""
        self._backend_bootstrapper = MemoryBackendBootstrapper(working_dir=self.working_dir)
        await self._backend_bootstrapper.start(self)
        return None

    async def close(self):
        """Stop memory backend bootstrap and release backend resources."""
        if self._backend_bootstrapper is not None:
            self._backend_bootstrapper.stop()
            self._backend_bootstrapper = None
        return None

    async def reload_backend(self) -> None:
        """Rebuild memory backend to apply runtime config changes."""
        if self._backend_bootstrapper is not None:
            self._backend_bootstrapper.stop()
        else:
            self._backend_bootstrapper = MemoryBackendBootstrapper(working_dir=self.working_dir)
        await self._backend_bootstrapper.start(self)
    async def _invoke_llm(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        """Run a plain LLM call for memory workflows.

        Uses ``SystemMessage`` + ``HumanMessage`` format. If no model has been
        injected yet, degrades gracefully to a truncated input echo to avoid
        hard-failing memory pipelines.
        """
        if self.langchain_chat_model is None:
            return user_message[:3000]

        from langchain_core.messages import HumanMessage, SystemMessage

        result = await self.langchain_chat_model.ainvoke(
            [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_message),
            ],
        )
        return result.content if isinstance(result.content, str) else str(result.content)
    async def _invoke_llm_with_tools(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        """Run an LLM call with restricted file tools enabled.

        This path is used by memory summarization flows that may need to read
        or edit memory markdown files during generation. Tools are intentionally
        limited to read/write/edit file operations.
        """
        if self.langchain_chat_model is None:
            return await self._invoke_llm(system_prompt, user_message)

        from langchain.agents import create_agent

        from ..langgraph.tools.builtins import edit_file, read_file, write_file

        # Restricted tool mode for memory workflows that need file context.
        graph = create_agent(
            model=self.langchain_chat_model,
            tools=[read_file, write_file, edit_file],
            system_prompt=system_prompt,
        )
        result = await graph.ainvoke({"messages": [("user", user_message)]})
        final_msg = result["messages"][-1]
        return final_msg.content if isinstance(final_msg.content, str) else str(final_msg.content)

    # ── Compaction (safeguard pipeline) ────────────────────────────────

    def _build_compaction_prompt(self, config: CompactionConfig) -> str:
        """Facade wrapper to build compaction prompt via ``CompactionService``."""
        return self._compaction_service.build_compaction_prompt(
            config=config,
            language=self.language,
        )

    def _collect_tool_failures(self, messages: list[Any]) -> str:
        """Facade wrapper to collect failed tool calls from message history."""
        return self._compaction_service.collect_tool_failures(messages)

    def _compute_adaptive_chunks(
        self,
        messages: list[Any],
        context_window: int,
        config: CompactionConfig,
    ) -> list[list[Any]]:
        """Facade wrapper for adaptive token-aware chunking."""
        return self._compaction_service.compute_adaptive_chunks(
            messages=messages,
            context_window=context_window,
            config=config,
            extract_message_text=extract_message_text,
            logger=logger,
        )

    async def _summarize_in_stages(
        self,
        chunks: list[list[Any]],
        previous_summary: str,
        system_prompt: str,
    ) -> str:
        """Facade wrapper for staged summarization and merge."""
        return await self._compaction_service.summarize_in_stages(
            chunks=chunks,
            previous_summary=previous_summary,
            system_prompt=system_prompt,
            language=self.language,
            extract_message_text=extract_message_text,
            invoke_llm=self._invoke_llm,
            logger=logger,
        )

    def _summary_system_prompt(self) -> str:
        """Facade wrapper for long-term memory extraction prompt generation."""
        return self._summary_service.summary_system_prompt(self.language)

    async def compact_memory(
        self,
        messages_to_summarize: list[Any] | None = None,
        turn_prefix_messages: list[Any] | None = None,
        previous_summary: str = "",
        config: CompactionConfig | None = None,
    ) -> str:
        """Compact recent conversation context into a structured summary.

        Delegates to ``CompactionService`` and refreshes embedding settings
        first so backend-dependent behavior stays current with runtime config.
        """
        self.update_emb_envs()
        return await self._compaction_service.compact_memory(
            messages_to_summarize=messages_to_summarize,
            turn_prefix_messages=turn_prefix_messages,
            previous_summary=previous_summary,
            config=config,
            language=self.language,
            extract_message_text=extract_message_text,
            invoke_llm=self._invoke_llm,
            logger=logger,
        )

    def _next_version(self, memory_dir: Path, prefix: str) -> int:
        """Facade wrapper to compute next versioned memory filename suffix."""
        return self._summary_service.next_version(memory_dir, prefix)

    async def summary_memory(
        self,
        messages: list[Any],
        date: str,
        channel: str = "",
        session_id: str = "",
    ) -> str:
        """Generate and persist a daily memory note from conversation messages."""
        self.update_emb_envs()
        return await self._summary_service.summary_memory(
            messages=messages,
            date=date,
            channel=channel,
            session_id=session_id,
            language=self.language,
            working_dir=self.working_dir,
            memory_searcher=self._memory_searcher,
            logger=logger,
            extract_message_text=extract_message_text,
            invoke_llm_with_tools=self._invoke_llm_with_tools,
        )

    async def _dedup_summary_against_existing(self, summary_text: str) -> str:
        """Remove blocks already represented in indexed memory content."""
        return await self._summary_service.dedup_summary_against_existing(
            summary_text=summary_text,
            memory_searcher=self._memory_searcher,
            logger=logger,
        )

    async def await_summary_tasks(self) -> str:
        """Await all pending summary tasks and return aggregated task outcomes."""
        result = ""
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"
                else:
                    done = task.result()
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
            else:
                try:
                    done = await task
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
                except Exception as exc:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"

        self.summary_tasks.clear()
        return result

    def add_async_summary_task(
        self,
        messages: list[Any],
        date: str = "",
        channel: str = "",
        session_id: str = "",
    ):
        """Schedule background summary generation and clean finished tasks."""
        remaining_tasks = []
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                else:
                    logger.info("Summary task completed: %s", task.result())
            else:
                remaining_tasks.append(task)
        self.summary_tasks = remaining_tasks

        self.summary_tasks.append(
            asyncio.create_task(
                self.summary_memory(
                    messages=messages,
                    date=date or datetime.datetime.now().strftime("%Y-%m-%d"),
                    channel=channel,
                    session_id=session_id,
                ),
            ),
        )

    def set_memory_backend(
        self,
        indexer: MemoryIndexer,
        searcher: MemorySearcher,
    ) -> None:
        """Inject memory indexer/searcher adapters after backend bootstrap."""
        self._memory_indexer = indexer
        self._memory_searcher = searcher
        logger.info("Memory backend searcher injected into MemoryManager")

    def set_qdrant_searcher(
        self,
        indexer: MemoryIndexer,
        searcher: MemorySearcher,
    ) -> None:
        """Backward-compatible alias for legacy bootstrap integration."""
        self.set_memory_backend(indexer, searcher)

    # ── Distillation: memory/*.md → MEMORY.md ────────────────────────────

    def _distill_stamp_path(self) -> Path:
        """Return path to the file tracking the last distillation timestamp."""
        return self._distillation_service.distill_stamp_path(self.working_dir)

    def should_distill(self) -> bool:
        """Return whether distillation interval requirements are satisfied."""
        return self._distillation_service.should_distill(self.working_dir)

    async def distill_to_memory_md(self) -> str:
        """Distill recent daily notes into ``MEMORY.md`` via service pipeline."""
        return await self._distillation_service.distill_to_memory_md(
            working_dir=self.working_dir,
            language=self.language,
            logger=logger,
            invoke_llm=self._invoke_llm,
            dedup_summary_against_existing=self._dedup_summary_against_existing,
        )

    # ── Session distillation: sessions/*.json → memory/YYYY-MM-DD.md ──────

    def should_distill_sessions(self) -> bool:
        """Return whether session distillation interval requirements are satisfied."""
        return self._session_distillation_service.should_distill(self.working_dir)

    async def distill_sessions_to_daily_md(self) -> str:
        """Distill incremental session deltas into today's daily memory file."""
        return await self._session_distillation_service.distill_sessions_to_daily_md(
            working_dir=self.working_dir,
            language=self.language,
            logger=logger,
            invoke_llm=self._invoke_llm,
            dedup_summary_against_existing=self._dedup_summary_against_existing,
        )

    def _touch_distill_stamp(self) -> None:
        """Update the 'last distill run' timestamp file."""
        self._distillation_service.touch_distill_stamp(self.working_dir, logger)

    async def memory_search(
        self,
        query: str,
        max_results: int = 5,
        min_score: float = 0.3,
    ) -> str:
        """Search indexed memory and return a formatted user-facing result."""
        return await self._query_service.memory_search(
            query=query,
            max_results=max_results,
            min_score=min_score,
            memory_searcher=self._memory_searcher,
            logger=logger,
        )

    async def memory_get(
        self,
        path: str,
        offset: int | None = None,
        limit: int | None = None,
    ) -> str:
        """Read memory file content through the active backend indexer."""
        return await self._query_service.memory_get(
            path=path,
            offset=offset,
            limit=limit,
            memory_indexer=self._memory_indexer,
            logger=logger,
        )

    async def memory_status(self) -> dict:
        """Return memory backend health/status metrics for diagnostics/UI."""
        return await self._query_service.memory_status(
            memory_indexer=self._memory_indexer,
            memory_searcher=self._memory_searcher,
            logger=logger,
        )

    # ── Memory Forget (deletion) ──────────────────────────────────────────

    async def memory_forget_by_query(
        self,
        query: str,
        max_candidates: int = 5,
        min_score: float = 0.5,
        auto_delete_threshold: float = 0.9,
    ) -> str:
        """Forget memory chunks by semantic query with safe candidate fallback."""
        return await self._query_service.memory_forget_by_query(
            query=query,
            max_candidates=max_candidates,
            min_score=min_score,
            auto_delete_threshold=auto_delete_threshold,
            memory_searcher=self._memory_searcher,
            memory_indexer=self._memory_indexer,
            logger=logger,
        )

    async def memory_forget_by_file(
        self,
        file_name: str,
    ) -> str:
        """Delete one memory file and clean corresponding vector chunks."""
        return await self._query_service.memory_forget_by_file(
            file_name=file_name,
            memory_indexer=self._memory_indexer,
        )

    async def delete_vector_chunks_for_file(self, file_name: str) -> None:
        """Delete vector/index chunks associated with a specific memory file."""
        await self._query_service.delete_vector_chunks_for_file(
            file_name=file_name,
            memory_indexer=self._memory_indexer,
        )

    async def memory_forget_by_chunk_ids(
        self,
        chunk_ids: list[str],
    ) -> str:
        """Delete explicit memory chunks by chunk IDs."""
        return await self._query_service.memory_forget_by_chunk_ids(
            chunk_ids=chunk_ids,
            memory_indexer=self._memory_indexer,
        )
