"""Summary generation and dedup services for memory notes."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from .summary_blocks import split_summary_into_blocks

if False:  # pragma: no cover - typing only
    pass


class SummaryService:
    """Generate daily memory summaries and deduplicate persisted notes."""

    def summary_system_prompt(self, language: str) -> str:
        """Return a structured system prompt for long-term memory extraction."""
        if language == "zh":
            return (
                "你是一个长期记忆提取器。从对话中提取值得长期保存的关键信息。\n\n"
                "请用以下结构组织输出：\n\n"
                "## 关键决策\n- 做了什么决定，为什么\n\n"
                "## 待办事项\n- [ ] 尚未完成的任务\n- [x] 已完成的任务\n\n"
                "## 重要事实\n- 人名、项目名、技术栈等关键事实\n\n"
                "## 约束与偏好\n- 用户明确表达的约束条件和偏好\n\n"
                "如果某个分类没有内容，直接省略该分类。保持简洁，只记录值得长期保存的信息。\n\n"
                "去重规则：记录事实前，检查你的输出中是否已有相同内容。"
                "同一事实、偏好或决策只保留一条，合并为最完整的版本。"
            )
        return (
            "You are a long-term memory extractor. Extract key information worth "
            "preserving from the conversation.\n\n"
            "Organize your output using this structure:\n\n"
            "## Key Decisions\n- What was decided and why\n\n"
            "## Action Items\n- [ ] Pending tasks\n- [x] Completed tasks\n\n"
            "## Important Facts\n- Names, projects, tech stack, and other key facts\n\n"
            "## Constraints & Preferences\n- User-stated constraints and preferences\n\n"
            "Omit any section that has no content. Be concise — only record "
            "information worth long-term preservation.\n\n"
            "DEDUP RULE: Before recording a fact, check if it already appears in "
            "your output. Never repeat the same fact, preference, or decision — "
            "merge into one entry with the most complete version."
        )

    def next_version(self, memory_dir: Path, prefix: str) -> int:
        """Find next available file version for ``{prefix}_v{N}.md`` pattern."""
        max_ver = 0
        for file_path in memory_dir.glob(f"{prefix}_v*.md"):
            stem = file_path.stem
            parts = stem.rsplit("_v", 1)
            if len(parts) != 2:
                continue
            try:
                max_ver = max(max_ver, int(parts[1]))
            except ValueError:
                continue
        return max_ver + 1

    async def dedup_summary_against_existing(
        self,
        summary_text: str,
        memory_searcher: Any,
        logger: logging.Logger,
    ) -> str:
        """Remove summary blocks that are near-duplicates of existing memory."""
        if memory_searcher is None or not summary_text.strip():
            return summary_text

        from .dedup import create_dedup_config_from_env, jaccard_similarity
        from .qdrant_searcher import SearchConfig

        config = create_dedup_config_from_env()
        if not config.enabled:
            return summary_text

        blocks = split_summary_into_blocks(summary_text)
        if len(blocks) <= 1:
            return summary_text

        kept_blocks: list[str] = []
        for block in blocks:
            text = block.strip()
            if not text or text.startswith("#"):
                kept_blocks.append(block)
                continue

            if len(text) < 20:
                kept_blocks.append(block)
                continue

            try:
                cfg = SearchConfig(max_results=3, min_score=0.5)
                results = await memory_searcher.search(text, config=cfg)

                is_dup = False
                for result in results:
                    sim = jaccard_similarity(text, result.snippet)
                    if sim >= config.jaccard_skip_threshold:
                        logger.info(
                            "Summary dedup: omitting block (%.3f Jaccard with %s): %.80s",
                            sim,
                            result.chunk_id,
                            text,
                        )
                        is_dup = True
                        break
                if not is_dup:
                    kept_blocks.append(block)
            except Exception:
                kept_blocks.append(block)

        result = "\n\n".join(kept_blocks).strip()
        if not result:
            logger.warning("Summary dedup removed ALL blocks — keeping original")
            return summary_text
        return result

    async def summary_memory(
        self,
        *,
        messages: list[Any],
        date: str,
        channel: str,
        session_id: str,
        language: str,
        working_dir: str,
        memory_searcher: Any,
        logger: logging.Logger,
        extract_message_text: Callable[[Any], str],
        invoke_llm_with_tools: Callable[[str, str], Awaitable[str]],
    ) -> str:
        """Generate and persist memory summary from conversation messages."""
        text = "\n\n".join(extract_message_text(msg) for msg in messages)
        if not text.strip():
            return ""

        meta = f"Date: {date}"
        if channel:
            meta += f" | Channel: {channel}"
        if session_id:
            meta += f" | Session: {session_id}"

        if language == "zh":
            prompt = f"{meta}\n\n请从以下对话中提取值得长期保存的关键信息：\n\n{text}"
        else:
            prompt = (
                f"{meta}\n\n"
                "Extract key information worth long-term preservation "
                f"from the following conversation:\n\n{text}"
            )

        try:
            result = await invoke_llm_with_tools(
                self.summary_system_prompt(language),
                prompt,
            )
            logger.info("Memory Summary Result:\n%s", result)

            result = await self.dedup_summary_against_existing(result, memory_searcher, logger)

            if result.strip():
                memory_dir = Path(working_dir) / "memory"
                memory_dir.mkdir(parents=True, exist_ok=True)
                filepath = memory_dir / f"{date}.md"

                meta_bits: list[str] = []
                if channel:
                    meta_bits.append(f"channel={channel}")
                if session_id:
                    meta_bits.append(f"session={session_id}")

                block_header = "## Auto Summary"
                if meta_bits:
                    block_header += f" ({', '.join(meta_bits)})"

                block = f"{block_header}\n\n{result.strip()}\n"
                if filepath.exists():
                    try:
                        existing = filepath.read_text(encoding="utf-8").strip()
                    except OSError:
                        existing = ""
                    if existing:
                        block = f"\n\n---\n\n{block}"

                with open(filepath, "a", encoding="utf-8") as file_obj:
                    file_obj.write(block)
                logger.info("Memory summary appended to %s", filepath)

            return result
        except Exception as exc:
            logger.exception("Failed to generate memory summary: %s", exc)
            return ""
