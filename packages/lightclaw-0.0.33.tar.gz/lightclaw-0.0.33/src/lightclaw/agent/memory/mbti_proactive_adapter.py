"""MBTI-Proactive bridge: activity multiplier and style context block.

Exposes three functions consumed by proactivity.py:
- get_activity_multiplier(dimensions)      -> float  (A3: probability gate)
- build_proactive_context_block(...)       -> str    (B3: query_text suffix)
- get_mbti_profile_for_proactive()         -> tuple  (reads IDENTITY.md)

All functions degrade gracefully: any failure returns a neutral value so
proactive behaviour is unchanged when MBTI data is unavailable.
"""

from __future__ import annotations

import logging
from pathlib import Path

from ...constant import WORKING_DIR

logger = logging.getLogger(__name__)


def get_activity_multiplier(dimensions: dict[str, int]) -> float:
    """Return a probability multiplier based on the E/I dimension.

    The *dimensions* dict stores only the dominant pole per axis,
    so E and I are mutually exclusive keys.

    Args:
        dimensions: e.g. {"I": 70, "N": 80, "T": 62, "J": 70}
                    Empty dict or missing E/I key -> returns 1.0 (no effect).

    Returns:
        Multiplier float:
          E >= 65 -> 1.2  (strong extrovert)
          E 55-64 -> 1.1  (mild extrovert)
          E 50-54 -> 1.0  (neutral)
          I 50-54 -> 1.0  (neutral)
          I 55-64 -> 0.85 (mild introvert)
          I >= 65 -> 0.7  (strong introvert)
    """
    e_val = dimensions.get("E")
    i_val = dimensions.get("I")

    if e_val is None and i_val is None:
        return 1.0

    if e_val is not None:
        if e_val >= 65:
            return 1.2
        if e_val >= 55:
            return 1.1
        return 1.0
    else:
        if i_val >= 65:  # type: ignore[operator]
            return 0.7
        if i_val >= 55:  # type: ignore[operator]
            return 0.85
        return 1.0


def build_proactive_context_block(
    mbti_type: str,
    mode: str,
    language: str = "zh",
) -> str:
    """Build the MBTI style instruction block appended to query_text.

    Instantiates PersonalityInjector internally to read hints for the
    appropriate proactive scene. Does NOT accept a dimensions parameter —
    dimensions are read from IDENTITY.md by PersonalityInjector to ensure
    a single source of truth.

    Args:
        mbti_type: 4-letter MBTI code, e.g. "INTJ". Empty string -> "".
        mode:      "topic" (has Qdrant candidates) or "caring" (no candidates).
        language:  "zh" or "en".

    Returns:
        Markdown string to append to query_text, or "" if nothing to add.
    """
    if not mbti_type:
        return ""

    try:
        from .personality_injector import PersonalityInjector

        injector = PersonalityInjector(Path(WORKING_DIR), language=language)
        scene = "proactive_topic" if mode == "topic" else "proactive_caring"
        hints = injector.get_hints_for_scene(scene, language)
        if not hints:
            return ""

        if language == "en":
            header = f"## Your personality style ({mbti_type})"
        else:
            header = f"## 你的性格风格（{mbti_type}）"

        body = "\n".join(f"- {h}" for h in hints)
        return f"{header}\n{body}"
    except Exception:
        logger.debug("build_proactive_context_block: failed for mbti_type=%s", mbti_type)
        return ""


def get_mbti_profile_for_proactive() -> tuple[str, dict[str, int]]:
    """Read current MBTI type and dimensions from IDENTITY.md.

    Reuses PersonalityInjector's parsing logic via the public
    get_profile_tuple() method.

    Side-effect note: PersonalityInjector._load_profile() will randomly
    assign an MBTI type and write it to IDENTITY.md if the file exists
    but contains no valid MBTI type. This is pre-existing behaviour.

    Returns:
        (mbti_type, dimensions), e.g. ("INTJ", {"I": 70, "N": 80, ...})
        Returns ("", {}) on any failure.
    """
    try:
        from .personality_injector import PersonalityInjector

        injector = PersonalityInjector(Path(WORKING_DIR))
        return injector.get_profile_tuple()
    except Exception:
        logger.debug("get_mbti_profile_for_proactive: failed to load profile")
        return "", {}
