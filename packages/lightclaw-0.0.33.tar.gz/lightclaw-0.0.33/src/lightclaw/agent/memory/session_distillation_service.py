"""Session distillation service: sessions/*.json -> memory/YYYY-MM-DD.md."""

from __future__ import annotations

import datetime
import json
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from ..utils.text_sanitizer import sanitize_summary_text


class SessionDistillationService:
    """Incrementally distill session files into today's daily memory note."""

    def __init__(self) -> None:
        self.interval_hours = 6
        self.max_chars_per_run = 30000
        self.max_sessions_per_run = 8

    def configure(self, interval_hours: int, max_chars_per_run: int) -> None:
        self.interval_hours = max(1, interval_hours)
        self.max_chars_per_run = max(4000, max_chars_per_run)

    def _state_path(self, working_dir: str) -> Path:
        return Path(working_dir) / ".session_distill_state.json"

    def _load_state(self, working_dir: str) -> dict[str, Any]:
        path = self._state_path(working_dir)
        if not path.exists():
            return {"last_run_ts": 0.0, "files": {}}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"last_run_ts": 0.0, "files": {}}
        if not isinstance(data, dict):
            return {"last_run_ts": 0.0, "files": {}}
        data.setdefault("last_run_ts", 0.0)
        data.setdefault("files", {})
        if not isinstance(data["files"], dict):
            data["files"] = {}
        return data

    def _save_state(self, working_dir: str, state: dict[str, Any], logger) -> None:
        path = self._state_path(working_dir)
        try:
            path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            logger.warning("Failed to save session distillation state")

    def should_distill(self, working_dir: str) -> bool:
        state = self._load_state(working_dir)
        last_ts = float(state.get("last_run_ts", 0.0) or 0.0)
        if last_ts <= 0:
            return True
        elapsed_hours = (datetime.datetime.now().timestamp() - last_ts) / 3600
        return elapsed_hours >= self.interval_hours

    @staticmethod
    def _extract_text(block: Any) -> str:
        if isinstance(block, str):
            return block.strip()
        if isinstance(block, list):
            parts: list[str] = []
            for item in block:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict):
                    text = item.get("text")
                    if isinstance(text, str) and text.strip():
                        parts.append(text.strip())
            return "\n".join(parts).strip()
        if isinstance(block, dict):
            text = block.get("text")
            if isinstance(text, str):
                return text.strip()
        return ""

    @classmethod
    def _message_to_line(cls, msg: Any) -> str:
        if not isinstance(msg, dict):
            return ""
        msg_type = str(msg.get("type", "")).lower()
        data = msg.get("data", {}) if isinstance(msg.get("data"), dict) else {}
        content = cls._extract_text(data.get("content"))
        if not content:
            return ""
        role = "unknown"
        if "human" in msg_type:
            role = "user"
        elif "ai" in msg_type:
            role = "assistant"
        return f"{role}: {content}"

    async def distill_sessions_to_daily_md(
        self,
        *,
        working_dir: str,
        language: str,
        logger,
        invoke_llm: Callable[[str, str], Awaitable[str]],
        dedup_summary_against_existing: Callable[[str], Awaitable[str]],
    ) -> str:
        state = self._load_state(working_dir)
        files_state: dict[str, Any] = state.get("files", {})

        sessions_dir = Path(working_dir) / "sessions"
        if not sessions_dir.exists():
            state["last_run_ts"] = datetime.datetime.now().timestamp()
            self._save_state(working_dir, state, logger)
            return ""

        candidates = sorted(
            list(sessions_dir.glob("*.session.json")) + list(sessions_dir.glob("*.langgraph.json")),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            state["last_run_ts"] = datetime.datetime.now().timestamp()
            self._save_state(working_dir, state, logger)
            return ""

        source_chunks: list[str] = []
        chars = 0
        processed_sessions = 0

        for fpath in candidates:
            if processed_sessions >= self.max_sessions_per_run or chars >= self.max_chars_per_run:
                break

            try:
                data = json.loads(fpath.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            if not isinstance(data, dict):
                continue
            messages = data.get("messages", [])
            if not isinstance(messages, list) or not messages:
                continue

            rel_name = fpath.name
            prev_count = int(files_state.get(rel_name, {}).get("message_count", 0) or 0)
            if prev_count >= len(messages):
                files_state[rel_name] = {"message_count": len(messages)}
                continue

            new_msgs = messages[prev_count:]
            lines = [self._message_to_line(m) for m in new_msgs]
            lines = [line for line in lines if line]
            if not lines:
                files_state[rel_name] = {"message_count": len(messages)}
                continue

            chunk = f"### {rel_name}\n" + "\n".join(lines)
            source_chunks.append(chunk)
            chars += len(chunk)
            processed_sessions += 1
            files_state[rel_name] = {"message_count": len(messages)}

        if not source_chunks:
            state["files"] = files_state
            state["last_run_ts"] = datetime.datetime.now().timestamp()
            self._save_state(working_dir, state, logger)
            return ""

        combined = "\n\n".join(source_chunks)

        if language == "zh":
            system = (
                "你是会话记忆蒸馏助手。请从最近新增的会话内容中提取值得长期保留的要点："
                "用户偏好、稳定约束、明确决策、长期目标、未完成事项。"
                "输出简洁 Markdown 要点；忽略寒暄、重复、临时闲聊。"
                "如果没有值得保留内容，仅输出 NOTHING_TO_DISTILL。"
            )
            user_msg = f"## 新增会话片段\n\n{combined}"
        else:
            system = (
                "You are a session memory distillation assistant. Extract durable insights "
                "from newly added session content: user preferences, stable constraints, "
                "clear decisions, long-term goals, and unfinished tasks. "
                "Output concise Markdown bullets. Ignore small talk and temporary chatter. "
                "If nothing is worth keeping, output ONLY NOTHING_TO_DISTILL."
            )
            user_msg = f"## Newly added session snippets\n\n{combined}"

        try:
            result = await invoke_llm(system, user_msg)
            result = sanitize_summary_text(result).strip()
        except Exception:
            logger.exception("Session distillation LLM call failed")
            return ""

        if not result or "NOTHING_TO_DISTILL" in result:
            state["files"] = files_state
            state["last_run_ts"] = datetime.datetime.now().timestamp()
            self._save_state(working_dir, state, logger)
            return ""

        result = await dedup_summary_against_existing(result)
        if not result.strip():
            state["files"] = files_state
            state["last_run_ts"] = datetime.datetime.now().timestamp()
            self._save_state(working_dir, state, logger)
            return ""

        memory_dir = Path(working_dir) / "memory"
        memory_dir.mkdir(parents=True, exist_ok=True)
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        daily_path = memory_dir / f"{today}.md"
        block = (
            "\n\n---\n\n"
            f"## Session Distilled ({datetime.datetime.now().strftime('%H:%M:%S')})\n\n"
            f"{result.strip()}\n"
        )
        try:
            with open(daily_path, "a", encoding="utf-8") as f:
                f.write(block)
        except OSError:
            logger.exception("Failed to append session distillation to %s", daily_path)
            return ""

        state["files"] = files_state
        state["last_run_ts"] = datetime.datetime.now().timestamp()
        self._save_state(working_dir, state, logger)
        logger.info(
            "Session distillation appended %d chars into %s from %d session files",
            len(result),
            daily_path,
            processed_sessions,
        )
        return result
