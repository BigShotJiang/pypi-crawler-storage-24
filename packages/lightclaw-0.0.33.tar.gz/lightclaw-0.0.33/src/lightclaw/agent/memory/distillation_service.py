"""Distillation service: daily memory notes -> MEMORY.md."""

from __future__ import annotations

import datetime
import re
from collections.abc import Awaitable, Callable
from pathlib import Path

from ..utils.text_sanitizer import sanitize_summary_text


class DistillationService:
    """Extract long-term insights from recent daily note files."""

    def __init__(self) -> None:
        self.interval_days = 1
        self.lookback_days = 7

    def configure(self, interval_days: int, lookback_days: int) -> None:
        self.interval_days = interval_days
        self.lookback_days = lookback_days

    def distill_stamp_path(self, working_dir: str) -> Path:
        return Path(working_dir) / ".last_distill"

    def should_distill(self, working_dir: str) -> bool:
        stamp = self.distill_stamp_path(working_dir)
        if not stamp.exists():
            return True
        try:
            last_ts = float(stamp.read_text(encoding="utf-8").strip())
            elapsed_days = (datetime.datetime.now().timestamp() - last_ts) / 86400
            return elapsed_days >= self.interval_days
        except (ValueError, OSError):
            return True

    def touch_distill_stamp(self, working_dir: str, logger) -> None:
        try:
            self.distill_stamp_path(working_dir).write_text(
                str(datetime.datetime.now().timestamp()),
                encoding="utf-8",
            )
        except OSError:
            logger.warning("Failed to update distillation timestamp")

    async def distill_to_memory_md(
        self,
        *,
        working_dir: str,
        language: str,
        logger,
        invoke_llm: Callable[[str, str], Awaitable[str]],
        dedup_summary_against_existing: Callable[[str], Awaitable[str]],
    ) -> str:
        memory_dir = Path(working_dir) / "memory"
        if not memory_dir.exists():
            return ""

        cutoff = datetime.datetime.now() - datetime.timedelta(days=self.lookback_days)
        date_pattern = re.compile(r"(\d{4}-\d{2}-\d{2})")
        recent_files: list[tuple[str, Path]] = []

        for md_file in sorted(memory_dir.glob("*.md")):
            match = date_pattern.search(md_file.name)
            if not match:
                continue
            try:
                file_date = datetime.datetime.strptime(match.group(1), "%Y-%m-%d")
            except ValueError:
                continue
            if file_date >= cutoff:
                recent_files.append((match.group(1), md_file))

        if not recent_files:
            logger.info("Distillation: no recent daily notes found")
            self.touch_distill_stamp(working_dir, logger)
            return ""

        source_texts: list[str] = []
        for date_str, fpath in recent_files:
            try:
                text = fpath.read_text(encoding="utf-8").strip()
                if text:
                    source_texts.append(f"### {date_str}\n{text}")
            except OSError:
                continue

        if not source_texts:
            self.touch_distill_stamp(working_dir, logger)
            return ""

        combined = "\n\n".join(source_texts)
        if len(combined) > 60000:
            combined = combined[:60000] + "\n\n[... truncated ...]"

        memory_md_path = Path(working_dir) / "MEMORY.md"
        existing_memory = ""
        if memory_md_path.exists():
            import contextlib

            with contextlib.suppress(OSError):
                existing_memory = memory_md_path.read_text(encoding="utf-8").strip()

        if language == "zh":
            system = (
                "你是一个记忆蒸馏助手。从每日笔记中提炼出值得长期保留的关键信息——"
                "重大决策、用户偏好变化、踩过的坑、重要结论。"
                "输出简洁的要点列表（Markdown），不要复述原文，不要包含日常闲聊和临时信息。"
                "如果所有内容都不值得长期保留，只输出 NOTHING_TO_DISTILL。"
            )
            user_msg = f"## 现有 MEMORY.md 内容（避免重复）\n\n{existing_memory}\n\n---\n\n## 近期每日笔记\n\n{combined}"
        else:
            system = (
                "You are a memory distillation assistant. Extract key information "
                "worth long-term retention from daily notes — major decisions, user "
                "preference changes, lessons learned, important conclusions. "
                "Output a concise bullet-point list (Markdown). Do not repeat raw "
                "conversation logs or trivial chat. "
                "If nothing is worth keeping, output only NOTHING_TO_DISTILL."
            )
            user_msg = (
                f"## Existing MEMORY.md (avoid repeating)\n\n{existing_memory}\n\n"
                f"---\n\n## Recent daily notes\n\n{combined}"
            )

        try:
            result = await invoke_llm(system, user_msg)
            result = sanitize_summary_text(result).strip()
        except Exception:
            logger.exception("Distillation LLM call failed")
            return ""

        if not result or "NOTHING_TO_DISTILL" in result:
            logger.info("Distillation: nothing worth keeping from recent notes")
            self.touch_distill_stamp(working_dir, logger)
            return ""

        result = await dedup_summary_against_existing(result)
        if not result.strip():
            logger.info("Distillation: all content duplicated existing memory")
            self.touch_distill_stamp(working_dir, logger)
            return ""

        today = datetime.datetime.now().strftime("%Y-%m-%d")
        distill_section = f"\n\n## Distilled on {today}\n\n{result}\n"
        try:
            with open(memory_md_path, "a", encoding="utf-8") as file_obj:
                file_obj.write(distill_section)
            logger.info(
                "Distillation: appended %d chars to MEMORY.md from %d daily notes",
                len(distill_section),
                len(recent_files),
            )
        except OSError:
            logger.exception("Failed to append distilled content to MEMORY.md")

        self.touch_distill_stamp(working_dir, logger)
        return result
