"""Personality context injection based on MBTI type (P1 scene layer).

The :class:`PersonalityInjector` is a pure rule-engine component (zero LLM
cost) that reads the agent's MBTI type and dimension percentages from
``IDENTITY.md`` and injects scene-appropriate personality hints into the
system prompt via middleware.

Supports three levels of personality data:
- **4-letter code** — identity label (auto-derived from percentages)
- **Dimension percentages** — 0-100 continuous spectrum per dimension
- **Descriptors** — 2-4 keywords capturing personality flavor

Scene detection uses keyword matching; personality hints are selected from
a static template table indexed by ``(scene, mbti_dimension)`` and
modulated by dimension percentage strength.
"""

from __future__ import annotations

import logging
import random
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Scene definitions — keyword-based detection
# ---------------------------------------------------------------------------

_SCENE_KEYWORDS: dict[str, list[str]] = {
    "code_review": [
        "review",
        "code review",
        "PR",
        "pull request",
        "merge request",
        "代码审查",
        "代码评审",
        "CR",
    ],
    "debug": [
        "bug",
        "error",
        "traceback",
        "exception",
        "crash",
        "segfault",
        "报错",
        "异常",
        "崩溃",
        "出错",
        "不工作",
    ],
    "planning": [
        "plan",
        "schedule",
        "roadmap",
        "sprint",
        "milestone",
        "deadline",
        "计划",
        "排期",
        "路线图",
        "里程碑",
    ],
    "brainstorm": [
        "idea",
        "brainstorm",
        "what if",
        "explore",
        "possibility",
        "想法",
        "头脑风暴",
        "如果",
        "可能性",
        "探索",
    ],
    "emotional": [
        "frustrated",
        "angry",
        "sad",
        "tired",
        "stressed",
        "happy",
        "excited",
        "烦",
        "累",
        "难过",
        "焦虑",
        "开心",
        "郁闷",
        "崩溃了",
        "好烦",
        "压力",
        "不开心",
    ],
    "casual_chat": [
        "聊聊",
        "闲聊",
        "随便说说",
        "just chatting",
        "how are you",
        "你好吗",
        "在吗",
        "无聊",
    ],
}

# Default scene when no keyword matches.
_DEFAULT_SCENE = "general"

# ---------------------------------------------------------------------------
# Personality hint templates — indexed by (scene, dimension_pole)
# ---------------------------------------------------------------------------

_PERSONALITY_HINTS: dict[str, dict[str, str]] = {
    "code_review": {
        "T": "Focus on logic, correctness, and edge cases. Be direct about issues.",
        "F": "Acknowledge good parts first, then suggest improvements constructively.",
        "J": "Provide a structured checklist of review findings.",
        "P": "Highlight areas worth exploring further; suggest alternatives.",
    },
    "debug": {
        "S": "Walk through the problem step by step; focus on concrete symptoms and logs.",
        "N": "Consider the bigger picture — could this be a systemic issue?",
        "T": "Diagnose methodically; prioritise root cause over symptoms.",
        "F": "Acknowledge the frustration, then help troubleshoot.",
    },
    "planning": {
        "J": "Propose a structured timeline with clear milestones and owners.",
        "P": "Suggest a flexible framework; leave room for pivots.",
        "E": "Proactively offer to break tasks down and discuss priorities.",
        "I": "Present the plan concisely; let the user drive the discussion.",
    },
    "brainstorm": {
        "N": "Go wide — offer unconventional angles and 'what-if' scenarios.",
        "S": "Ground ideas in practical constraints and real examples.",
        "E": "Energetically build on ideas; offer rapid-fire variations.",
        "I": "Offer a few well-thought-out ideas with depth rather than volume.",
    },
    "emotional": {
        "F": "Lead with empathy; validate feelings before offering solutions.",
        "T": "Briefly acknowledge the emotion, then pivot to actionable next steps.",
        "E": "Be warm and conversational; check in on how they're feeling.",
        "I": "Give space; offer quiet support without overwhelming.",
    },
    "casual_chat": {
        "E": "Be sociable and chatty; ask follow-up questions.",
        "I": "Keep it light but concise; don't over-extend small talk.",
        "F": "Show warmth and personal interest.",
        "T": "Be friendly but low-key; don't force emotional depth.",
    },
    "general": {
        "E": "Be proactive in offering context and next steps.",
        "I": "Be responsive; answer precisely without over-elaborating.",
        "T": "Prioritise clarity and logic.",
        "F": "Balance logic with warmth; consider how the answer lands.",
        "S": "Be concrete and specific.",
        "N": "Connect to broader patterns when helpful.",
        "J": "Wrap up with a clear action item or summary.",
        "P": "Leave space for follow-up exploration.",
    },
    "proactive_topic": {
        "N": "引导对方探索一个有深度的想法或近期值得关注的事",
        "S": "关心对方最近的具体进展或实际状态",
        "T": "以问题或洞察为切入点，不过度渲染情绪",
        "F": "以关怀和共情为基调，让对方感到被在乎",
        "E": "语气热情自然，像老朋友主动找人聊天",
        "I": "话不多但有温度，给对方留有回应空间",
    },
    "proactive_topic_en": {
        "N": "Guide the conversation toward a deeper idea or something worth exploring recently",
        "S": "Ask about recent concrete progress or practical matters",
        "T": "Lead with a question or insight rather than emotional framing",
        "F": "Set a caring, empathetic tone so the person feels valued",
        "E": "Be warm and natural, like a friend reaching out",
        "I": "Keep it brief but genuine; leave room for them to respond or not",
    },
    "proactive_caring": {
        "E": "主动、热情地问候，表达真诚的关心",
        "I": "简短温暖，不强迫，给对方自由决定是否回复",
        "F": "优先表达情感连接，问对方感受如何",
        "T": "关心具体状态而非泛泛问候，例如问最近工作/项目如何",
    },
    "proactive_caring_en": {
        "E": "Reach out warmly and enthusiastically, expressing genuine care",
        "I": "Keep it short and warm; don't pressure them to reply",
        "F": "Lead with emotional connection; ask how they're feeling",
        "T": "Ask about something specific rather than a vague check-in",
    },
}

# Weakened hint variants for moderate tendencies (60-69%).
_WEAK_HINTS: dict[str, str] = {
    "E": "Lean slightly toward proactive engagement, but stay balanced.",
    "I": "Lean slightly toward conciseness, but stay balanced.",
    "S": "Lean slightly toward concrete details, but stay balanced.",
    "N": "Lean slightly toward big-picture thinking, but stay balanced.",
    "T": "Lean slightly toward logical framing, but stay balanced.",
    "F": "Lean slightly toward empathetic framing, but stay balanced.",
    "J": "Lean slightly toward structured closure, but stay balanced.",
    "P": "Lean slightly toward flexible exploration, but stay balanced.",
}

# All 16 MBTI types for random assignment.
_ALL_MBTI_TYPES: list[str] = [
    "INTJ",
    "INTP",
    "ENTJ",
    "ENTP",
    "INFJ",
    "INFP",
    "ENFJ",
    "ENFP",
    "ISTJ",
    "ISFJ",
    "ESTJ",
    "ESFJ",
    "ISTP",
    "ISFP",
    "ESTP",
    "ESFP",
]

# Maximum number of hints injected per turn to control token usage.
_MAX_HINTS_PER_TURN = 3

# ---------------------------------------------------------------------------
# Regex patterns for IDENTITY.md parsing
# ---------------------------------------------------------------------------

# Match: **类型：** INTJ  or  **Type:** INTJ
_MBTI_REGEX = re.compile(r"\*\*类型[：:]\s*\*\*\s*([A-Z]{4})", re.IGNORECASE)
_MBTI_VALIDATE = re.compile(r"^[EI][SN][TF][JP]$", re.IGNORECASE)

# Match: E/I：E 65%  or  E/I: I 70%
_PERCENT_REGEX = re.compile(
    r"E/I[：:]\s*([EI])\s*(\d+)%.*?"
    r"S/N[：:]\s*([SN])\s*(\d+)%.*?"
    r"T/F[：:]\s*([TF])\s*(\d+)%.*?"
    r"J/P[：:]\s*([JP])\s*(\d+)%",
    re.IGNORECASE | re.DOTALL,
)

# Match: **描述词：** xxx  or  **Descriptors:** xxx
_DESCRIPTORS_REGEX = re.compile(
    r"\*\*(?:描述词|Descriptors)[：:]\s*\*\*\s*(.+)",
    re.IGNORECASE,
)

# Default percentage for legacy format (4-letter code only, no percentages).
_DEFAULT_PERCENTAGE = 70


@dataclass
class _PersonalityProfile:
    """Parsed personality data from IDENTITY.md."""

    mbti_type: str = ""
    descriptors: str = ""
    # Percentage for each dimension pole (the dominant side).
    # Key is the dominant letter, value is the percentage (50-100).
    dimensions: dict[str, int] = field(default_factory=dict)

    @property
    def is_valid(self) -> bool:
        """Return True if at least a 4-letter MBTI type is present."""
        return bool(self.mbti_type)

    def pole_for(self, axis: str) -> tuple[str, int]:
        """Return (dominant_letter, percentage) for a given axis pair.

        *axis* should be one of ``"EI"``, ``"SN"``, ``"TF"``, ``"JP"``.
        """
        for letter in axis:
            if letter in self.dimensions:
                return letter, self.dimensions[letter]
        # Fallback: derive from mbti_type with default percentage.
        for letter in axis:
            if letter.upper() in self.mbti_type.upper():
                return letter.upper(), _DEFAULT_PERCENTAGE
        return axis[0], 50  # Should not reach here.


class PersonalityInjector:
    """Rule-engine personality injector (zero LLM cost).

    Reads the MBTI type, dimension percentages, and descriptors once from
    IDENTITY.md (cached), detects the conversation scene from the latest
    user message, and returns a formatted ``<personality-context>`` block
    for middleware injection.

    Percentage-driven hint selection:
    - ≥70%: full scene-specific hint
    - 60-69%: weakened generic hint
    - <60%: no hint for that dimension (too neutral)
    """

    def __init__(self, working_dir: Path, language: str = "zh") -> None:
        self._working_dir = working_dir
        self._language = language
        self._profile: _PersonalityProfile | None = None
        self._identity_mtime: float = 0.0

    # ------------------------------------------------------------------
    # Loading & parsing
    # ------------------------------------------------------------------

    def _load_profile(self) -> _PersonalityProfile:
        """Parse personality profile from IDENTITY.md.

        If no valid type is found but the file exists, randomly assign one
        and write it back so every agent always has a personality.
        """
        identity_path = self._working_dir / "IDENTITY.md"
        if not identity_path.exists():
            return _PersonalityProfile()

        try:
            mtime = identity_path.stat().st_mtime
            if self._profile is not None and mtime == self._identity_mtime:
                return self._profile

            content = identity_path.read_text(encoding="utf-8")
            profile = self._parse_identity(content)

            if profile.is_valid:
                self._profile = profile
                self._identity_mtime = mtime
                logger.debug(
                    "Loaded personality: %s dims=%s desc=%s",
                    profile.mbti_type,
                    profile.dimensions,
                    profile.descriptors,
                )
                return profile

            # No valid MBTI found — randomly assign one and persist.
            assigned = self._assign_random_mbti(identity_path, content)
            if assigned.is_valid:
                self._profile = assigned
                self._identity_mtime = identity_path.stat().st_mtime
                return assigned

            self._profile = _PersonalityProfile()
            self._identity_mtime = mtime
            return self._profile
        except Exception:
            logger.debug("Failed to read IDENTITY.md for personality profile")
            return _PersonalityProfile()

    @staticmethod
    def _parse_identity(content: str) -> _PersonalityProfile:
        """Extract MBTI type, percentages, and descriptors from file content."""
        profile = _PersonalityProfile()

        # 1. Parse 4-letter type.
        type_match = _MBTI_REGEX.search(content)
        if type_match:
            candidate = type_match.group(1).upper()
            if _MBTI_VALIDATE.match(candidate):
                profile.mbti_type = candidate

        if not profile.mbti_type:
            return profile

        # 2. Parse dimension percentages.
        pct_match = _PERCENT_REGEX.search(content)
        if pct_match:
            pairs = [
                (pct_match.group(1).upper(), int(pct_match.group(2))),
                (pct_match.group(3).upper(), int(pct_match.group(4))),
                (pct_match.group(5).upper(), int(pct_match.group(6))),
                (pct_match.group(7).upper(), int(pct_match.group(8))),
            ]
            for letter, pct in pairs:
                profile.dimensions[letter] = max(15, min(85, pct))
        else:
            # Legacy format: no percentages, derive from 4-letter code.
            for letter in profile.mbti_type:
                profile.dimensions[letter] = _DEFAULT_PERCENTAGE

        # 3. Parse descriptors.
        desc_match = _DESCRIPTORS_REGEX.search(content)
        if desc_match:
            raw = desc_match.group(1).strip()
            # Remove placeholder markers.
            if raw.startswith("*") and raw.endswith("*"):
                raw = raw.strip("*").strip()
            if raw and "（" not in raw and "(" not in raw:
                profile.descriptors = raw

        return profile

    def _assign_random_mbti(self, identity_path: Path, content: str) -> _PersonalityProfile:
        """Randomly pick an MBTI type and write it into IDENTITY.md.

        Writes in the new percentage format. Returns the assigned profile,
        or an empty profile on failure.
        """
        chosen = random.choice(_ALL_MBTI_TYPES)
        logger.info("No MBTI type configured — randomly assigned: %s", chosen)

        pct = _DEFAULT_PERCENTAGE

        # Try to replace the placeholder in the MBTI section.
        type_placeholder = re.compile(
            r"(\*\*类型[：:]\s*\*\*\s*)(\*（.*?）\*|\s*$)",
            re.MULTILINE,
        )
        new_content, count = type_placeholder.subn(
            rf"\g<1>{chosen}（随机分配，可在此处修改）",
            content,
            count=1,
        )

        if count == 0:
            # Try English pattern.
            type_placeholder_en = re.compile(
                r"(\*\*Type[：:]\s*\*\*\s*)(\*\(.*?\)\*|\s*$)",
                re.MULTILINE,
            )
            new_content, count = type_placeholder_en.subn(
                rf"\g<1>{chosen} (randomly assigned, change here anytime)",
                content,
                count=1,
            )

        if count == 0:
            # Fallback: append MBTI section.
            dim_lines = self._format_dimension_lines(chosen, pct)
            new_content = (
                content.rstrip()
                + "\n\n## MBTI 人格\n\n"
                + f"- **类型：** {chosen}（随机分配，可在此处修改）\n"
                + "- **描述词：** （待填写）\n"
                + f"- **四维度：**\n{dim_lines}\n"
            )
        else:
            # Also try to fill in percentage placeholders.
            for letter in chosen:
                axis_pairs = {
                    "E": "E/I",
                    "I": "E/I",
                    "S": "S/N",
                    "N": "S/N",
                    "T": "T/F",
                    "F": "T/F",
                    "J": "J/P",
                    "P": "J/P",
                }
                axis = axis_pairs[letter]
                placeholder_re = re.compile(
                    rf"({re.escape(axis)}[：:]\s*)\*（.*?）\*",
                )
                new_content = placeholder_re.sub(
                    rf"\g<1>{letter} {pct}%",
                    new_content,
                    count=1,
                )

        try:
            identity_path.write_text(new_content, encoding="utf-8")
            profile = _PersonalityProfile(mbti_type=chosen)
            for letter in chosen:
                profile.dimensions[letter] = pct
            return profile
        except Exception:
            logger.warning("Failed to write random MBTI type to IDENTITY.md")
            return _PersonalityProfile()

    @staticmethod
    def _format_dimension_lines(mbti: str, pct: int) -> str:
        """Format dimension lines in percentage format."""
        axes = [("E", "I"), ("S", "N"), ("T", "F"), ("J", "P")]
        labels = {
            "E": "外向",
            "I": "内向",
            "S": "感知",
            "N": "直觉",
            "T": "思维",
            "F": "情感",
            "J": "判断",
            "P": "感知",
        }
        lines = []
        for a, b in axes:
            letter = a if a in mbti else b
            label = labels[letter]
            axis_name = f"{a}/{b}"
            lines.append(f"  - {axis_name}：{letter} {pct}%（{label}）")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Scene detection
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_scene(user_text: str) -> str:
        """Detect conversation scene from user text via keyword matching."""
        lower = user_text.lower()
        for scene, keywords in _SCENE_KEYWORDS.items():
            for kw in keywords:
                if kw.lower() in lower:
                    return scene
        return _DEFAULT_SCENE

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_personality_block(self, last_user_text: str) -> str:
        """Build the ``<personality-context>`` block for middleware injection.

        Returns empty string if MBTI type is not configured or no hints
        match the current scene.

        Hint selection is percentage-driven:
        - ≥70%: inject the full scene-specific hint for that dimension
        - 60-69%: inject a weakened generic hint
        - <60%: skip (too neutral to warrant a hint)
        """
        profile = self._load_profile()
        if not profile.is_valid:
            return ""

        scene = self._detect_scene(last_user_text)
        scene_hints = _PERSONALITY_HINTS.get(scene, _PERSONALITY_HINTS["general"])

        # Select hints based on percentage strength.
        selected: list[str] = []
        for axis in ("EI", "SN", "TF", "JP"):
            pole, pct = profile.pole_for(axis)
            if pct >= 70:
                # Strong tendency — use full scene-specific hint.
                hint = scene_hints.get(pole)
                if hint:
                    selected.append(hint)
            elif pct >= 60:
                # Moderate tendency — use weakened generic hint.
                weak = _WEAK_HINTS.get(pole)
                if weak:
                    selected.append(weak)
            # <60% — skip, too neutral.

            if len(selected) >= _MAX_HINTS_PER_TURN:
                break

        if not selected and not profile.descriptors:
            return ""

        # Build the block.
        if self._language == "zh":
            header = f"<personality-context>\n你的 MBTI 类型是 {profile.mbti_type}。"
            if profile.descriptors:
                header += f"\n你的性格描述词：{profile.descriptors}"
            if selected:
                header += f"\n在当前对话场景（{scene}）下：\n"
        else:
            header = f"<personality-context>\nYour MBTI type is {profile.mbti_type}."
            if profile.descriptors:
                header += f"\nYour personality descriptors: {profile.descriptors}"
            if selected:
                header += f"\nFor the current scene ({scene}):\n"

        body = "\n".join(f"- {h}" for h in selected) if selected else ""
        footer = "\n</personality-context>"
        return header + body + footer

    def get_profile_tuple(self) -> tuple[str, dict[str, int]]:
        """Return (mbti_type, dimensions) for external callers.

        Reuses the cached _load_profile() result.
        Returns ("", {}) on any failure.
        """
        try:
            profile = self._load_profile()
            return profile.mbti_type, dict(profile.dimensions)
        except Exception:
            logger.debug("get_profile_tuple: failed to load profile")
            return "", {}

    def get_hints_for_scene(self, scene: str, language: str = "zh") -> list[str]:
        """Return personality hints for an explicitly named scene.

        Bypasses keyword detection — caller specifies the scene directly.
        Uses a flat 60% threshold (simpler than get_personality_block's
        70%/weak-hint two-tier system; proactive needs fewer, cleaner hints).

        Args:
            scene:    Scene name, e.g. "proactive_topic", "proactive_caring"
            language: "zh" or "en". When "en", looks up "{scene}_en" first,
                      falls back to "{scene}" if not found.

        Returns:
            List of hint strings (may be empty).
        """
        try:
            profile = self._load_profile()
            if not profile.is_valid:
                return []

            # Resolve scene key with language fallback
            scene_key = f"{scene}_en" if language == "en" else scene
            scene_hints = _PERSONALITY_HINTS.get(scene_key)
            if scene_hints is None:
                scene_hints = _PERSONALITY_HINTS.get(scene, {})
            if not scene_hints:
                return []

            selected: list[str] = []
            for axis in ("EI", "SN", "TF", "JP"):
                pole, pct = profile.pole_for(axis)
                if pct >= 60:
                    hint = scene_hints.get(pole)
                    if hint:
                        selected.append(hint)
                if len(selected) >= _MAX_HINTS_PER_TURN:
                    break

            return selected
        except Exception:
            logger.debug("get_hints_for_scene: failed for scene=%s", scene)
            return []
