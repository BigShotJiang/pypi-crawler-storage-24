#!/usr/bin/env python3
"""PR1+PR2+PR3+PR4 验证脚本 — LangGraph LightClaw Agent 验证。

运行方式:
    cd <lightclaw-repo-root>
    PYTHONPATH=src python3 -m lightclaw.agent.langgraph.demo

验证项:
    PR1: LangGraph 基础链路 (model + graph + 单个工具)
    PR2: 全量工具层 (8 内置工具 + skills 适配器)
    PR3: 消息桥接 (Msg ↔ BaseMessage 转换 + EventBridge 流式输出)
    PR4: Runner 层接入 (feature flag + SessionFactory + RunController 双路径)
"""

from __future__ import annotations

import asyncio


def _section(title: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}")


# ── PR1: 基础链路 ──────────────────────────────────────────────


async def test_pr1_basic():
    """PR1 验证：Agent + 单个工具，同步+流式。"""
    from datetime import datetime

    from langchain_core.tools import tool as lc_tool

    from .config import LightClawGraphConfig
    from .graph_builder import build_lightclaw_graph
    from .model_factory import create_chat_model

    @lc_tool
    def get_time() -> str:
        """获取当前时间。"""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    model = create_chat_model()
    config = LightClawGraphConfig(
        model=model,
        tools=[get_time],
        system_prompt="你是 LightClaw。用中文简短回答。",
    )
    graph = build_lightclaw_graph(config)

    # 同步调用
    _section("PR1-a: 同步调用")
    result = await graph.ainvoke({"messages": [("user", "现在几点？")]})
    print(f"Agent 回复: {result['messages'][-1].content}")

    # 流式调用
    _section("PR1-b: 流式调用")
    async for event in graph.astream_events(
        {"messages": [("user", "你好")]},
        version="v2",
    ):
        if event["event"] == "on_chat_model_stream":
            chunk = event["data"]["chunk"]
            if chunk.content:
                print(chunk.content, end="", flush=True)
    print()


# ── PR2: 工具层验证 ────────────────────────────────────────────


def test_pr2_builtin_tools_load():
    """PR2-a: 验证 8 个内置工具全部能加载。"""
    from .tools import load_builtin_tools

    tools = load_builtin_tools()
    print(f"加载了 {len(tools)} 个内置工具:")
    for t in tools:
        print(f"  - {t.name}")
    assert len(tools) == 8, f"期望 8 个工具，实际 {len(tools)}"
    print("OK")


def test_pr2_skills_load():
    """PR2-b: 验证 skills 适配器能加载 active skills。"""
    from .tools import load_active_skills_as_tools

    tools = load_active_skills_as_tools()
    print(f"加载了 {len(tools)} 个 skill 工具:")
    for t in tools:
        print(f"  - {t.name}: {t.description[:60]}...")
    # active_skills 可能为空（未初始化），这里不 assert 数量
    print("OK (active_skills 未初始化时为 0 是正常的)")


async def test_pr2_agent_with_builtins():
    """PR2-c: 用全部内置工具创建 Agent 并调用 get_current_time。"""
    from .config import LightClawGraphConfig
    from .graph_builder import build_lightclaw_graph
    from .model_factory import create_chat_model
    from .tools import load_builtin_tools

    model = create_chat_model()
    tools = load_builtin_tools()
    config = LightClawGraphConfig(
        model=model,
        tools=tools,
        system_prompt="你是 LightClaw，一个 AI 助手。用中文简短回答。",
    )
    graph = build_lightclaw_graph(config)

    result = await graph.ainvoke({"messages": [("user", "现在几点？")]})
    print(f"Agent 回复: {result['messages'][-1].content}")


async def test_pr2_agent_with_all_tools():
    """PR2-d: 用内置工具 + skills 创建 Agent 并简单对话。"""
    from .config import LightClawGraphConfig
    from .graph_builder import build_lightclaw_graph
    from .model_factory import create_chat_model
    from .tools import load_active_skills_as_tools, load_builtin_tools

    model = create_chat_model()
    builtin = load_builtin_tools()
    skills = load_active_skills_as_tools()
    all_tools = builtin + skills
    print(f"总计工具数: {len(all_tools)} (内置 {len(builtin)} + 技能 {len(skills)})")

    config = LightClawGraphConfig(
        model=model,
        tools=all_tools,
        system_prompt="你是 LightClaw，一个 AI 助手。用中文简短回答。",
    )
    graph = build_lightclaw_graph(config)

    result = await graph.ainvoke(
        {"messages": [("user", "你好，你有哪些能力？请用一句话回答。")]},
    )
    reply = result["messages"][-1].content
    print(f"Agent 回复: {reply[:300]}")


# ── PR3: 消息桥接验证 ──────────────────────────────────────────


def test_pr3_message_converter():
    """PR3-a: 验证 Msg ↔ BaseMessage 双向转换。"""
    from langchain_core.messages import (
        AIMessage,
        HumanMessage,
        SystemMessage,
        ToolMessage,
    )

    from ...app.schemas.message_types import Message as Msg
    from .message_converter import langchain_to_msg, msg_to_langchain

    # 1. 纯文本 user message
    msg = Msg(name="user", content="你好", role="user")
    lc = msg_to_langchain(msg)
    assert isinstance(lc, HumanMessage), f"期望 HumanMessage，实际 {type(lc)}"
    assert lc.content == "你好"
    roundtrip = langchain_to_msg(lc)
    assert roundtrip.role == "user"
    assert roundtrip.content == "你好"
    print("  [1] 纯文本 user → HumanMessage → Msg: OK")

    # 2. 纯文本 assistant message
    msg = Msg(name="assistant", content="我是LightClaw", role="assistant")
    lc = msg_to_langchain(msg)
    assert isinstance(lc, AIMessage)
    assert lc.content == "我是LightClaw"
    roundtrip = langchain_to_msg(lc)
    assert roundtrip.content == "我是LightClaw"
    print("  [2] 纯文本 assistant → AIMessage → Msg: OK")

    # 3. system message
    msg = Msg(name="system", content="你是AI助手", role="system")
    lc = msg_to_langchain(msg)
    assert isinstance(lc, SystemMessage)
    roundtrip = langchain_to_msg(lc)
    assert roundtrip.role == "system"
    print("  [3] system → SystemMessage → Msg: OK")

    # 4. tool_use block → AIMessage with tool_calls
    msg = Msg(
        name="assistant",
        content=[
            {"type": "text", "text": "让我查一下"},
            {
                "type": "tool_use",
                "id": "call_1",
                "name": "get_time",
                "input": {},
            },
        ],
        role="assistant",
    )
    lc_list = msg_to_langchain(msg)
    assert isinstance(lc_list, list), f"期望 list，实际 {type(lc_list)}"
    # Should have a text message and a tool_calls message
    text_msgs = [m for m in lc_list if isinstance(m, AIMessage) and m.content]
    tool_msgs = [m for m in lc_list if isinstance(m, AIMessage) and m.tool_calls]
    assert len(text_msgs) >= 1, "应有文本消息"
    assert len(tool_msgs) >= 1, "应有工具调用消息"
    assert tool_msgs[0].tool_calls[0]["name"] == "get_time"
    print("  [4] text + tool_use → [AIMessage, AIMessage(tool_calls)]: OK")

    # 5. tool_result block → ToolMessage
    msg = Msg(
        name="tool",
        content=[
            {
                "type": "tool_result",
                "id": "call_1",
                "name": "get_time",
                "output": "2025-03-04 15:00:00",
            },
        ],
        role="user",
    )
    lc = msg_to_langchain(msg)
    if isinstance(lc, list):
        lc = lc[0]
    assert isinstance(lc, ToolMessage), f"期望 ToolMessage，实际 {type(lc)}"
    assert lc.content == "2025-03-04 15:00:00"
    assert lc.tool_call_id == "call_1"
    roundtrip = langchain_to_msg(lc)
    assert roundtrip.content[0]["type"] == "tool_result"
    print("  [5] tool_result → ToolMessage → Msg: OK")

    # 6. thinking block
    msg = Msg(
        name="assistant",
        content=[
            {"type": "thinking", "thinking": "让我想想..."},
            {"type": "text", "text": "答案是42"},
        ],
        role="assistant",
    )
    lc_list = msg_to_langchain(msg)
    assert isinstance(lc_list, list)
    thinking_msgs = [m for m in lc_list if isinstance(m, AIMessage) and (m.additional_kwargs or {}).get("thinking")]
    assert len(thinking_msgs) >= 1, "应有 thinking 消息"
    print("  [6] thinking + text → [AIMessage(thinking), AIMessage(text)]: OK")

    # 7. image block
    msg = Msg(
        name="user",
        content=[
            {"type": "text", "text": "这张图是什么？"},
            {
                "type": "image",
                "source": {"type": "url", "url": "https://example.com/a.png"},
            },
        ],
        role="user",
    )
    lc = msg_to_langchain(msg)
    if isinstance(lc, list):
        lc = lc[0]
    assert isinstance(lc, HumanMessage)
    # Multimodal content should be a list
    assert isinstance(lc.content, list), f"期望 list content，实际 {type(lc.content)}"
    image_parts = [p for p in lc.content if p.get("type") == "image_url"]
    assert len(image_parts) == 1
    assert image_parts[0]["image_url"]["url"] == "https://example.com/a.png"
    roundtrip = langchain_to_msg(lc)
    image_blocks = [b for b in roundtrip.content if isinstance(b, dict) and b.get("type") == "image"]
    assert len(image_blocks) == 1
    print("  [7] text + image → HumanMessage(multimodal) → Msg: OK")

    # 8. Reverse: AIMessage with tool_calls → Msg
    ai = AIMessage(
        content="",
        tool_calls=[
            {"name": "shell", "args": {"cmd": "ls"}, "id": "tc_1"},
        ],
    )
    roundtrip = langchain_to_msg(ai)
    assert roundtrip.role == "assistant"
    tool_use_blocks = [b for b in roundtrip.content if isinstance(b, dict) and b.get("type") == "tool_use"]
    assert len(tool_use_blocks) == 1
    assert tool_use_blocks[0]["name"] == "shell"
    print("  [8] AIMessage(tool_calls) → Msg(tool_use blocks): OK")

    print("  全部消息转换测试通过!")


async def test_pr3_event_bridge():
    """PR3-b: 通过 LangGraphEventBridge 流式运行 Agent，验证输出格式。"""
    from datetime import datetime

    from langchain_core.tools import tool as lc_tool

    from .config import LightClawGraphConfig
    from .event_bridge import LangGraphEventBridge
    from .graph_builder import build_lightclaw_graph
    from .model_factory import create_chat_model

    @lc_tool
    def get_time() -> str:
        """获取当前时间。"""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    model = create_chat_model()
    config = LightClawGraphConfig(
        model=model,
        tools=[get_time],
        system_prompt="你是 LightClaw。用中文简短回答。",
    )
    graph = build_lightclaw_graph(config)

    bridge = LangGraphEventBridge()
    messages_received = []
    last_flags = []

    async for msg, last in bridge.stream(graph, [("user", "现在几点？")]):
        messages_received.append(msg)
        last_flags.append(last)
        if last:
            print(f"  最终回复: {msg.content if isinstance(msg.content, str) else msg.get_text_content()}")

    assert len(messages_received) > 0, "应至少收到一条消息"
    assert last_flags[-1] is True, "最后一条应标记 is_last=True"
    # 所有中间消息应为 is_last=False
    for flag in last_flags[:-1]:
        assert flag is False, "中间消息不应标记 is_last"
    print(f"  收到 {len(messages_received)} 条消息（{len(last_flags) - 1} 个 chunk + 1 个 final）")
    print("  EventBridge 流式输出格式验证通过!")


async def test_pr3_event_bridge_with_tool_events():
    """PR3-c: EventBridge 开启 tool events 后验证工具事件也被输出。"""
    from datetime import datetime

    from langchain_core.tools import tool as lc_tool

    from .config import LightClawGraphConfig
    from .event_bridge import LangGraphEventBridge
    from .graph_builder import build_lightclaw_graph
    from .model_factory import create_chat_model

    @lc_tool
    def get_time() -> str:
        """获取当前时间。"""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    model = create_chat_model()
    config = LightClawGraphConfig(
        model=model,
        tools=[get_time],
        system_prompt="你是 LightClaw。用中文简短回答。",
    )
    graph = build_lightclaw_graph(config)

    bridge = LangGraphEventBridge(emit_tool_events=True)
    tool_events = []

    async for msg, _last in bridge.stream(graph, [("user", "现在几点？")]):
        if isinstance(msg.content, list):
            for block in msg.content:
                if isinstance(block, dict) and block.get("type") in (
                    "tool_use",
                    "tool_result",
                ):
                    tool_events.append(block)

    print(f"  捕获到 {len(tool_events)} 个工具事件")
    if tool_events:
        for ev in tool_events:
            print(f"    - {ev['type']}: {ev.get('name', 'N/A')}")
    print("  OK (emit_tool_events=True 验证完成)")


# ── PR4: Runner 层接入验证 ─────────────────────────────────────


def test_pr4_session_factory_imports():
    """PR4-b: 验证 LangGraphSessionContext 可导入。"""
    from ...app.runner.session_factory import (
        LangGraphSessionContext,
        SessionContext,
        SessionFactory,
    )

    assert LangGraphSessionContext is not None
    assert SessionContext is not None
    assert SessionFactory is not None
    print("  LangGraphSessionContext, SessionContext, SessionFactory 导入成功")
    print("  OK")


def test_pr4_run_controller_langgraph_only():
    """PR4-c: 验证 RunController 只有 LangGraph 路径。"""
    from ...app.runner.run_controller import RunController

    assert not hasattr(RunController, "_run_agentscope"), "_run_agentscope 应已被移除"
    assert hasattr(RunController, "_run_langgraph"), "缺少 _run_langgraph"
    print("  RunController._run_langgraph ✓ (单轨)")
    print("  OK")


def test_pr4_event_bridge_langgraph():
    """PR4-d: 验证 EventBridge 有 LangGraph stream 方法。"""
    from ...app.runner.event_bridge import EventBridge

    bridge = EventBridge()
    assert hasattr(bridge, "stream_agent_run"), "缺少 stream_agent_run"
    assert hasattr(bridge, "stream_langgraph_run"), "缺少 stream_langgraph_run"
    print("  EventBridge.stream_agent_run ✓")
    print("  EventBridge.stream_langgraph_run ✓")
    print("  OK")


def test_pr4_command_handler_static():
    """PR4-e: 验证 CommandHandler.is_command_str 静态方法。"""
    from ...agent.langgraph.command_handler import is_command

    assert is_command("/compact") is True
    assert is_command("/new") is True
    assert is_command("/clear") is True
    assert is_command("/history") is True
    assert is_command("/unknown") is False
    assert is_command("hello") is False
    assert is_command(None) is False
    print("  /compact → True ✓")
    print("  /new → True ✓")
    print("  /unknown → False ✓")
    print("  None → False ✓")
    print("  OK")


async def test_pr4_langgraph_context_build():
    """PR4-f: 端到端验证 — 通过 SessionFactory 构建 LangGraph 上下文并流式执行。"""
    from ...agent.prompt import build_system_prompt_from_working_dir
    from .config import LightClawGraphConfig
    from .event_bridge import LangGraphEventBridge
    from .model_factory import create_chat_model
    from .tools import load_active_skills_as_tools, load_builtin_tools

    # Simulate what SessionFactory.create_langgraph_context does
    model = create_chat_model()
    tools = load_builtin_tools()
    tools.extend(load_active_skills_as_tools())

    sys_prompt = build_system_prompt_from_working_dir()
    env_context = "- 当前的session_id: test_pr4\n- 当前的user_id: pr4_user"
    full_prompt = env_context + "\n\n" + sys_prompt

    from .graph_builder import build_lightclaw_graph

    graph_config = LightClawGraphConfig(
        model=model,
        tools=tools,
        system_prompt=full_prompt,
    )
    graph = build_lightclaw_graph(graph_config)

    # Execute through LangGraphEventBridge (same path as RunController._run_langgraph)
    bridge = LangGraphEventBridge()
    messages_received = []

    async for msg, last in bridge.stream(
        graph,
        [("user", "你好，用一句话介绍你自己")],
        config={"configurable": {"thread_id": "pr4_test"}},
    ):
        messages_received.append((msg, last))
        if last:
            content = msg.content if isinstance(msg.content, str) else msg.get_text_content()
            print(f"  最终回复: {content[:200]}")

    assert len(messages_received) > 0, "应至少收到一条消息"
    assert messages_received[-1][1] is True, "最后一条应标记 is_last=True"
    print(f"  收到 {len(messages_received)} 条消息")
    print("  端到端 LangGraph 路径验证通过!")


def test_pr4_tool_registry_langchain():
    """PR4-g: 验证 ToolRegistry 有 LangChain 工具方法。"""
    from ...app.runner.tool_registry import ToolRegistry

    registry = ToolRegistry()
    assert hasattr(registry, "get_langchain_mcp_tools"), "缺少 get_langchain_mcp_tools"
    print("  ToolRegistry.get_langchain_mcp_tools ✓")
    print("  OK")


# ── Main ────────────────────────────────────────────────────────


async def _async_main():
    await test_pr1_basic()

    _section("PR2-a: 内置工具加载")
    test_pr2_builtin_tools_load()

    _section("PR2-b: Skills 工具加载")
    test_pr2_skills_load()

    _section("PR2-c: Agent + 内置工具")
    await test_pr2_agent_with_builtins()

    _section("PR2-d: Agent + 全部工具")
    await test_pr2_agent_with_all_tools()

    _section("PR3-a: 消息转换 (Msg ↔ BaseMessage)")
    test_pr3_message_converter()

    _section("PR3-b: EventBridge 流式输出")
    await test_pr3_event_bridge()

    _section("PR3-c: EventBridge 工具事件")
    await test_pr3_event_bridge_with_tool_events()

    _section("PR4-a: Feature Flag")
    test_pr4_feature_flag()  # noqa: F821

    _section("PR4-b: LangGraphSessionContext 导入")
    test_pr4_session_factory_imports()

    _section("PR4-c: RunController 双路径")
    test_pr4_run_controller_dual_path()  # noqa: F821

    _section("PR4-d: EventBridge LangGraph stream")
    test_pr4_event_bridge_langgraph()

    _section("PR4-e: CommandHandler 静态方法")
    test_pr4_command_handler_static()

    _section("PR4-f: LangGraph 端到端执行")
    await test_pr4_langgraph_context_build()

    _section("PR4-g: ToolRegistry LangChain")
    test_pr4_tool_registry_langchain()


def main():
    print("\n🚀 LightClaw LangGraph 验证脚本 (PR1 + PR2 + PR3 + PR4)\n")
    asyncio.run(_async_main())
    print("\n✅ 全部验证通过！\n")


if __name__ == "__main__":
    main()
