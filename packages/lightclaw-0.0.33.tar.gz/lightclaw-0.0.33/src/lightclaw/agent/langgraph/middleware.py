"""LangGraph Middleware — implemented as agent middleware.

This module provides ``LightClawMiddleware`` which integrates:
* **Bootstrap**: first-interaction guidance injection
* **Memory Compaction**: automatic context compression when token limit is near
* **Auto Memory Recall**: proactive retrieval of relevant memories before each LLM call
* **Graceful Cancel**: check a cancel flag before each LLM call

These capabilities replaced the legacy AgentScope hooks and are now
implemented directly in middleware.

The middleware is passed as the ``middleware`` parameter to
``create_agent`` (from ``langchain.agents``), which calls it before
every LLM invocation — the same hook point as AgentScope's
``pre_reasoning``.
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    RemoveMessage,
    SystemMessage,
    ToolMessage,
)
from langgraph.graph.message import REMOVE_ALL_MESSAGES

from ..utils.text_sanitizer import sanitize_messages, sanitize_summary_text
from ..utils.token_counting import count_message_tokens as _count_tokens_estimate
from ..utils.tool_message_utils import _truncate_text as _truncate_text_impl
from .message_sanitizer import sanitize_tool_messages

if TYPE_CHECKING:
    from ..memory import LightClawInMemoryMemory, MemoryManager
    from ..memory.compaction_config import CompactionConfig
    from ..memory.fact_injector import FactInjector
    from ..memory.personality_injector import PersonalityInjector

logger = logging.getLogger(__name__)

_DEFAULT_MAX_TOOL_OUTPUT_LENGTH = 20000


def _truncate_tool_outputs(
    messages: list[BaseMessage],
    max_length: int | None = None,
) -> list[BaseMessage]:
    """Truncate long ToolMessage content, returning a new list (layer 1).

    For each ``ToolMessage`` whose content exceeds *max_length*, a new
    message object is created with truncated content — the original is
    never mutated, so callers can safely pass a shallow-copied list.
    """
    if max_length is None:
        max_length = int(
            os.environ.get(
                "MAX_FORMATTER_TEXT_LENGTH",
                _DEFAULT_MAX_TOOL_OUTPUT_LENGTH,
            ),
        )

    result: list[BaseMessage] = []
    for msg in messages:
        if not isinstance(msg, ToolMessage):
            result.append(msg)
            continue
        content = msg.content
        if isinstance(content, str) and len(content) > max_length:
            # 只在需要截断时才创建新对象，避免不必要的深拷贝
            new_msg = msg.copy()
            new_msg.content = _truncate_text_impl(content, max_length)
            result.append(new_msg)
        elif isinstance(content, list):
            new_parts = []
            changed = False
            for part in content:
                if isinstance(part, str) and len(part) > max_length:
                    new_parts.append(_truncate_text_impl(part, max_length))
                    changed = True
                elif isinstance(part, dict):
                    text = part.get("text", "")
                    if isinstance(text, str) and len(text) > max_length:
                        new_parts.append({**part, "text": _truncate_text_impl(text, max_length)})
                        changed = True
                    else:
                        new_parts.append(part)
                else:
                    new_parts.append(part)
            if changed:
                new_msg = msg.copy()
                new_msg.content = new_parts
                result.append(new_msg)
            else:
                result.append(msg)
        else:
            result.append(msg)
    return result


def _enforce_token_budget(
    messages: list[BaseMessage],
    max_input_length: int,
    token_cache: dict[str, int] | None = None,
    sys_token_cache: list[int] | None = None,
) -> list[BaseMessage]:
    """Drop oldest non-system messages when total tokens exceed budget (layer 2).

    Iterates from newest to oldest; once the running total exceeds
    *max_input_length* the remaining older messages are discarded.

    Always preserves ``SystemMessage`` messages regardless of position.

    Args:
        token_cache: 可选的消息 token 计数缓存字典，key 为消息 id，value 为 token 数。
            传入后会被读写，避免对同一消息重复调用 tiktoken。
        sys_token_cache: 长度为 1 的列表，用于缓存 system messages 的 token 总数。
            传入后会被读写，避免每次 turn 重复计算不变的 system prompt。
    """
    # Separate system messages (always kept)
    sys_msgs: list[BaseMessage] = []
    non_sys: list[BaseMessage] = []
    for m in messages:
        if isinstance(m, SystemMessage):
            sys_msgs.append(m)
        else:
            non_sys.append(m)

    # 计算 system messages token 数（带缓存，system prompt 几乎不变）
    if sys_token_cache is not None and sys_token_cache:
        sys_tokens = sys_token_cache[0]
    else:
        sys_tokens = _count_tokens_estimate(sys_msgs)
        if sys_token_cache is not None:
            sys_token_cache.append(sys_tokens)

    # Walk from newest → oldest, accumulate token budget
    budget = max_input_length - sys_tokens
    if budget <= 0:
        logger.warning(
            "System messages alone exceed max_input_length (%d), returning only system messages + last message",
            max_input_length,
        )
        return sys_msgs + (non_sys[-1:] if non_sys else [])

    kept: list[BaseMessage] = []
    running = 0
    for msg in reversed(non_sys):
        # 带缓存的 token 计数：同一条消息在同一 session 内只 encode 一次
        if token_cache is not None:
            msg_id = str(getattr(msg, "id", None) or id(msg))
            if msg_id not in token_cache:
                token_cache[msg_id] = _count_tokens_estimate([msg])
            msg_tokens = token_cache[msg_id]
        else:
            msg_tokens = _count_tokens_estimate([msg])

        if running + msg_tokens > budget:
            logger.info(
                "Token budget reached (~%d / %d tokens). Dropping %d older message(s).",
                running,
                max_input_length,
                len(non_sys) - len(kept),
            )
            break
        running += msg_tokens
        kept.append(msg)

    kept.reverse()
    return sys_msgs + kept


# ---------------------------------------------------------------------------
# Browser Task Guard — force continuation for incomplete browser workflows
# ---------------------------------------------------------------------------

# Actions that are truly "terminal" — only `stop` means the browser session ended.
# Borrowing from browser-use: snapshot/screenshot are routine verification actions,
# NOT terminal ones.  The agent should keep going after verification.
_BROWSER_TERMINAL_ACTIONS = frozenset({"stop"})

# Actions where agent is verifying state — guard should be softer but still present
_BROWSER_VERIFICATION_ACTIONS = frozenset({"snapshot", "screenshot", "pdf"})

_BROWSER_CONTINUATION_PROMPT = (
    "[BROWSER TASK GUARD — MANDATORY] You are in the MIDDLE of a browser "
    "automation workflow. The last browser_use action was "
    '"{action}" (step {step}). The user\'s task is NOT complete yet.\n\n'
    "RULES YOU MUST FOLLOW:\n"
    "1. You MUST call browser_use again with the next action.\n"
    "2. Do NOT write a text response or summary — that will end the workflow.\n"
    "3. If the page looks wrong, take a snapshot to reassess.\n"
    "4. Only call browser_use with action='stop' when the task is FULLY verified done.\n\n"
    "What to do next: Assess what step of the workflow you are in, then call "
    "browser_use with the appropriate next action."
)

_BROWSER_VERIFY_CONTINUATION_PROMPT = (
    "[BROWSER TASK GUARD] You just took a {action} to verify page state. "
    "Now assess: is the user's ENTIRE task complete?\n\n"
    "- If YES and you can see the success confirmation on the page → "
    "call browser_use with action='stop'.\n"
    "- If NO or you are unsure → call browser_use with the next action "
    "to continue the workflow. Do NOT write a text summary."
)


def _maybe_inject_browser_continuation(
    messages: list[BaseMessage],
) -> list[BaseMessage]:
    """Detect active browser sessions and inject a continuation prompt.

    Scans messages from newest to oldest looking for browser_use
    ToolMessages.  If the most recent browser action is a non-terminal
    action (click, type, open, etc.) and the browser has not been
    stopped, inject a SystemMessage reminding the LLM to continue.

    This is a programmatic safety net — even if the LLM ignores the
    ``progress_hint`` inside the tool output, the system message
    provides a stronger signal that cannot be overlooked.
    """
    # Walk messages from end to start; find the most recent browser_use
    # tool result.
    last_browser_action: str | None = None
    last_browser_step: int = 0
    browser_started = False
    browser_stopped = True  # default: no active session

    for msg in reversed(messages):
        # Detect browser_use ToolMessages by their .name attribute
        if isinstance(msg, ToolMessage):
            tool_name = getattr(msg, "name", "") or ""
            if tool_name == "browser_use":
                content = msg.content if isinstance(msg.content, str) else str(msg.content)
                # Extract action from the JSON payload
                action = _extract_browser_action(content)
                if action:
                    if last_browser_action is None:
                        last_browser_action = action
                        last_browser_step = _extract_step_count(content)

                    if action == "start":
                        browser_started = True
                        browser_stopped = False
                        break
                    elif action == "stop":
                        browser_stopped = True
                        break

        # Also check AIMessage tool_calls for browser_use
        if isinstance(msg, AIMessage) and msg.tool_calls:
            for tc in msg.tool_calls:
                if tc.get("name") == "browser_use":
                    action = (tc.get("args") or {}).get("action", "")
                    if action == "start":
                        browser_started = True
                        browser_stopped = False
                    elif action == "stop":
                        browser_stopped = True

    # No active browser session or browser has been stopped
    if browser_stopped or not browser_started or last_browser_action is None:
        return messages

    # If the last action was the stop action, the browser is closing.
    if last_browser_action in _BROWSER_TERMINAL_ACTIONS:
        return messages

    # For verification actions (snapshot/screenshot), use a softer prompt
    # that asks the agent to evaluate and decide, rather than forcing continuation.
    if last_browser_action in _BROWSER_VERIFICATION_ACTIONS:
        continuation = SystemMessage(
            content=_BROWSER_VERIFY_CONTINUATION_PROMPT.format(
                action=last_browser_action,
            ),
        )
        logger.debug(
            "BrowserTaskGuard: injecting verify-continuation prompt (last_action=%s)",
            last_browser_action,
        )
        return [*messages, continuation]

    # Inject mandatory continuation prompt for all other actions
    continuation = SystemMessage(
        content=_BROWSER_CONTINUATION_PROMPT.format(
            action=last_browser_action,
            step=last_browser_step or "?",
        ),
    )
    logger.debug(
        "BrowserTaskGuard: injecting continuation prompt (last_action=%s, step=%d)",
        last_browser_action,
        last_browser_step,
    )
    return [*messages, continuation]


def _extract_browser_action(content: str) -> str:
    """Extract the 'action' value from a browser_use tool output JSON string."""
    # Fast path: look for "action" key patterns without full JSON parsing
    import json as _json

    try:
        data = _json.loads(content)
        # Check action_history for the most recent action
        history = data.get("action_history")
        if history and isinstance(history, list) and history:
            last = history[-1]
            if isinstance(last, dict):
                return last.get("action", "")
        # Fallback: check top-level message for action hints
        msg = data.get("message", "")
        if "Browser started" in msg or "Browser launched" in msg:
            return "start"
        if "Browser stopped" in msg:
            return "stop"
        if "Clicked" in msg:
            return "click"
        if "Typed" in msg or "Type" in msg:
            return "type"
        if "Navigat" in msg:
            return "navigate"
        if "Opened" in msg:
            return "open"
    except (ValueError, TypeError, AttributeError):
        pass
    return ""


def _extract_step_count(content: str) -> int:
    """Extract total_actions_in_session from a browser_use tool output."""
    import json as _json

    try:
        data = _json.loads(content)
        return int(data.get("total_actions_in_session", 0))
    except (ValueError, TypeError, AttributeError):
        return 0


class LightClawMiddleware(AgentMiddleware):
    """Unified middleware for Bootstrap, Memory Compaction, and Cancel.

    Inherits from ``AgentMiddleware`` so it can be passed directly in
    the ``middleware`` sequence of ``create_agent``.

    Usage::

        mw = LightClawMiddleware(...)
        graph = create_agent(model=..., tools=..., middleware=[mw])
    """

    # AgentMiddleware expects a `tools` attribute (Sequence[BaseTool]).
    tools: Sequence = ()

    def __init__(
        self,
        *,
        working_dir: Path,
        language: str = "zh",
        memory_manager: MemoryManager | None = None,
        memory: LightClawInMemoryMemory | None = None,
        memory_compact_threshold: int = 90000,
        max_input_length: int = 131072,
        keep_recent: int = 3,
        compressed_summary: str = "",
        channel: str = "",
        session_id: str = "",
        compaction_config: CompactionConfig | None = None,
        fact_injector: FactInjector | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._language = language
        self._memory_manager = memory_manager
        self._memory = memory
        self._compact_threshold = memory_compact_threshold
        self._max_input_length = max_input_length
        self._keep_recent = keep_recent
        self._cancelled = False
        self._bootstrap_done = False
        self._bootstrap_pending = False
        self._compressed_summary = compressed_summary
        self._summary_version: int | None = None
        self._summary_message_count: int | None = None
        self._summary_timestamp: str | None = None
        self._channel = channel
        self._session_id = session_id
        self._compaction_config = compaction_config
        # token 计数缓存：key 为消息 id，value 为 token 数
        # 同一 session 内历史消息只 encode 一次，compaction 后清空
        self._token_cache: dict[str, int] = {}
        # system messages token 数缓存（长度为 1 的列表，空列表表示未缓存）
        # system prompt 几乎不变，避免每次 turn 重复计算
        self._sys_token_cache: list[int] = []
        # Structured fact injection (Mem0-style)
        self._fact_injector = fact_injector
        # Timestamp of last fact extraction (for cache invalidation)
        self._fact_extractor_last_modified_ms: int = 0
        # MBTI personality injection (P1 scene layer, zero LLM cost)
        self._personality_injector: PersonalityInjector | None = None
        self._init_personality_injector()
        # Memory flush reminder flag — set when compaction is imminent
        self._compaction_imminent = False
        # Auto memory recall configuration (proactive retrieval)
        from ...constant import (
            AUTO_RECALL_ENABLED,
            AUTO_RECALL_MAX_QUERY_LENGTH,
            AUTO_RECALL_MAX_RESULTS,
            AUTO_RECALL_MIN_SCORE,
        )

        self._auto_recall_enabled = AUTO_RECALL_ENABLED
        self._auto_recall_max_results = AUTO_RECALL_MAX_RESULTS
        self._auto_recall_min_score = AUTO_RECALL_MIN_SCORE
        self._auto_recall_max_query_length = AUTO_RECALL_MAX_QUERY_LENGTH

    def _init_personality_injector(self) -> None:
        """Lazily initialise the personality injector."""
        try:
            from ..memory.personality_injector import PersonalityInjector

            self._personality_injector = PersonalityInjector(
                working_dir=self._working_dir,
                language=self._language,
            )
        except Exception:
            logger.debug("Failed to initialise PersonalityInjector, continuing without it")
            self._personality_injector = None

    # -- Public API --------------------------------------------------------

    def update_fact_extractor_timestamp(self, last_modified_ms: int) -> None:
        """Update the fact extraction timestamp for cache invalidation."""
        self._fact_extractor_last_modified_ms = last_modified_ms

    @property
    def compressed_summary(self) -> str:
        return self._compressed_summary

    @compressed_summary.setter
    def compressed_summary(self, value: str) -> None:
        self._compressed_summary = value

    def cancel(self) -> None:
        """Signal cancellation — the next ``abefore_model`` will raise."""
        self._cancelled = True

    def commit_bootstrap_completion(self) -> None:
        """Persist bootstrap completion after a run finishes successfully."""
        if not self._bootstrap_pending:
            return

        bootstrap_flag = self._working_dir / ".bootstrap_completed"
        try:
            bootstrap_flag.touch()
            logger.info("Bootstrap completion flag created")
        except Exception:
            logger.exception("Failed to persist bootstrap completion flag")
        finally:
            self._bootstrap_pending = False

    async def abefore_model(self, state: Any, runtime: Any = None) -> dict[str, Any] | None:
        """Called before every LLM invocation inside the ReAct loop.

        This implements the ``AgentMiddleware.abefore_model`` hook.

        Returns:
            A state update dict when memory compaction needs to rewrite
            the persisted message history. For ordinary turns, returns
            ``None`` and leaves request-level shaping to
            ``awrap_model_call``.
        """
        # 浅拷贝：只复制引用，不深拷贝对象；_truncate_tool_outputs 已改为非 in-place
        messages: list[BaseMessage] = list(state.get("messages", []))

        # 1. Cancel check
        if self._cancelled:
            raise asyncio.CancelledError("Agent interrupted by user")

        # 2. Truncate long tool outputs before compaction/token estimates
        messages = _truncate_tool_outputs(messages)

        # 3. Sanitize orphan tool messages before compaction/token estimates
        messages = sanitize_tool_messages(messages)

        # 4. Memory compaction (if token count exceeds threshold)
        compacted, messages = await self._maybe_compact(messages)

        if compacted:
            # Compaction happened — permanently replace messages in state.
            return {"messages": [RemoveMessage(id=REMOVE_ALL_MESSAGES), *messages]}

        # No state update needed. Input-only shaping happens in awrap_model_call.
        return None

    async def awrap_model_call(self, request: Any, handler: Any) -> Any:
        """Shape the effective LLM input without mutating graph state."""
        if self._cancelled:
            raise asyncio.CancelledError("Agent interrupted by user")

        # 浅拷贝：只复制引用，不深拷贝对象；_truncate_tool_outputs 已改为非 in-place
        messages: list[BaseMessage] = list(request.messages)
        messages = _truncate_tool_outputs(messages)
        messages = self._maybe_inject_bootstrap(messages)

        # Collect extra context blocks (facts, summary, recall) to merge
        # into the system prompt.  langchain's create_agent stores the
        # system prompt separately in request.system_message and prepends
        # it in _execute_model_async.  If we create additional
        # SystemMessages in the messages list, providers that reject
        # multiple system messages (e.g. MiniMax) will fail.
        # Instead, we collect all extra context as plain strings and
        # merge them into request.system_message at the end.
        extra_sys_parts: list[str] = []

        facts_block = await self._get_facts_block(messages)
        if facts_block:
            extra_sys_parts.append(facts_block)

        summary_block = self._get_summary_block(messages)
        if summary_block:
            extra_sys_parts.append(summary_block)

        recall_block = await self._get_recall_block(messages)
        if recall_block:
            extra_sys_parts.append(recall_block)

        personality_block = self._get_personality_block(messages)
        if personality_block:
            extra_sys_parts.append(personality_block)

        # Memory flush reminder — inject once before imminent compaction
        if self._compaction_imminent:
            extra_sys_parts.append(self._build_flush_reminder())
            self._compaction_imminent = False

        messages = _enforce_token_budget(
            messages,
            self._max_input_length,
            token_cache=self._token_cache,
            sys_token_cache=self._sys_token_cache,
        )
        # 只在最后做一次 sanitize（_enforce_token_budget 可能丢弃消息，需要最终清理孤儿 ToolMessage）
        messages = sanitize_tool_messages(messages)
        # Strip vendor-specific tags (e.g. <think>, <minimax:tool_call>)
        # from AI messages so cross-provider switches don't trigger 400s.
        messages = sanitize_messages(messages)

        # Browser task guard: inject continuation prompt when there is an
        # active browser automation session that is not yet complete.
        messages = _maybe_inject_browser_continuation(messages)

        # Merge extra context into request.system_message so that there
        # is always exactly one system message in the final payload.
        override_kwargs: dict = {"messages": messages}
        if extra_sys_parts and hasattr(request, "system_message") and request.system_message is not None:
            existing = request.system_message.content if isinstance(request.system_message.content, str) else ""
            merged = existing + "\n\n" + "\n\n".join(extra_sys_parts)
            override_kwargs["system_message"] = SystemMessage(content=merged)
        elif extra_sys_parts:
            # No request.system_message — fall back to prepending in messages
            combined = "\n\n".join(extra_sys_parts)
            messages = [SystemMessage(content=combined), *messages]
            override_kwargs["messages"] = messages

        return await handler(request.override(**override_kwargs))

    # -- Bootstrap ---------------------------------------------------------

    def _maybe_inject_bootstrap(
        self,
        messages: list[BaseMessage],
    ) -> list[BaseMessage]:
        """Inject bootstrap guidance into first user message if applicable."""
        if self._bootstrap_done:
            return messages

        bootstrap_path = self._working_dir / "BOOTSTRAP.md"
        bootstrap_flag = self._working_dir / ".bootstrap_completed"

        if bootstrap_flag.exists() or not bootstrap_path.exists():
            self._bootstrap_done = True
            return messages

        # Bootstrap is a global one-shot event: inject whenever BOOTSTRAP.md
        # exists and the flag is absent, as long as there is a HumanMessage
        # to prepend guidance to.  We intentionally do NOT skip based on
        # prior AIMessages in the history — those belong to earlier sessions
        # or earlier (failed) bootstrap attempts and should not block the
        # agent-level bootstrap from triggering again.
        user_msgs = [m for m in messages if isinstance(m, HumanMessage)]
        if not user_msgs:
            return messages

        try:
            from ..prompt import build_bootstrap_guidance

            guidance = build_bootstrap_guidance(self._language)
            if not guidance:
                self._bootstrap_done = True
                return messages

            # Prepend guidance to the last (most recent) user message so the
            # bootstrap prompt is tied to the current interaction, not to an
            # old message in the session history.
            last_human_idx = None
            for i, m in enumerate(messages):
                if isinstance(m, HumanMessage):
                    last_human_idx = i
            if last_human_idx is None:
                self._bootstrap_done = True
                return messages
            result = list(messages)
            m = result[last_human_idx]
            new_content = f"{guidance}\n\n{m.content}" if isinstance(m.content, str) else m.content
            result[last_human_idx] = HumanMessage(content=new_content)

            # Delay persistence until the run completes successfully so a
            # failed first turn does not burn the one-shot bootstrap flow.
            self._bootstrap_pending = True
            self._bootstrap_done = True
            logger.info("Bootstrap guidance injected into first user message")
            return result
        except Exception:
            logger.exception("Failed to inject bootstrap guidance")
            self._bootstrap_done = True
            return messages

    # -- Structured Facts (string-only) -------------------------------------

    async def _get_facts_block(
        self,
        messages: list[BaseMessage],
    ) -> str:
        """Return structured facts text to merge into the system prompt.

        Returns empty string if facts are unavailable or already injected.
        """
        if self._fact_injector is None:
            return ""

        # Check if facts are already injected (avoid duplicates).
        for m in messages:
            text = m.content if isinstance(m.content, str) else ""
            if "<structured-facts>" in text:
                return ""

        # Also check request.system_message (it won't be in messages).
        # This is handled by the caller checking the merged result.

        last_user_text = ""
        for msg in reversed(messages):
            if isinstance(msg, HumanMessage):
                last_user_text = msg.content if isinstance(msg.content, str) else ""
                break

        try:
            facts_block = await self._fact_injector.get_relevant_facts_block(
                last_user_text=last_user_text,
                extractor_last_modified_ms=self._fact_extractor_last_modified_ms,
            )
        except Exception:
            logger.debug("Fact injection failed, continuing without facts")
            return ""

        return facts_block or ""

    # -- Personality Context (P1 scene layer, zero LLM) --------------------

    def _get_personality_block(
        self,
        messages: list[BaseMessage],
    ) -> str:
        """Return a personality-context block based on MBTI type and scene.

        Returns empty string if personality injector is not available or
        MBTI type is not configured.
        """
        if self._personality_injector is None:
            return ""

        # Avoid duplicate injection
        for m in messages:
            text = m.content if isinstance(m.content, str) else ""
            if "<personality-context>" in text:
                return ""

        user_text = self._extract_latest_user_text(messages)
        if not user_text:
            return ""

        try:
            return self._personality_injector.get_personality_block(user_text)
        except Exception:
            logger.debug("Personality injection failed, continuing without it")
            return ""

    # -- Memory Flush Reminder ---------------------------------------------

    def _build_flush_reminder(self) -> str:
        """Build a one-shot reminder for the agent to save important memories.

        Injected into the system prompt when compaction is imminent.
        """
        if self._language == "zh":
            return (
                "<memory-flush-reminder>\n"
                "上下文即将被压缩，较旧的消息将被摘要替代。\n"
                "如果对话历史中有尚未保存的重要信息，请现在用 write_file/edit_file 保存。\n"
                "重点关注：用户偏好、决策结论、项目上下文、性格反馈。\n"
                "</memory-flush-reminder>"
            )
        return (
            "<memory-flush-reminder>\n"
            "Context is about to be compressed. Older messages will be replaced by a summary.\n"
            "If there is anything important in the conversation history that you haven't\n"
            "already saved to memory files, save it now using write_file/edit_file.\n"
            "Focus on: user preferences, decisions, project context, and personality feedback.\n"
            "</memory-flush-reminder>"
        )

    # -- Compressed Summary (string-only) ----------------------------------

    def _get_summary_block(
        self,
        messages: list[BaseMessage],
    ) -> str:
        """Return compressed summary text to merge into the system prompt.

        Returns empty string if no summary is available or already present.
        """
        if not self._compressed_summary:
            return ""

        self._compressed_summary = sanitize_summary_text(self._compressed_summary)
        if not self._compressed_summary:
            return ""

        # Check if summary is already prepended (avoid duplicates).
        for m in messages:
            text = m.content if isinstance(m.content, str) else ""
            if isinstance(m, SystemMessage | HumanMessage) and (
                "<context-summary" in text or "<previous-summary>" in text
            ):
                return ""

        from ..memory.context_assembly import build_summary_message

        summary_dict = build_summary_message(
            summary_text=self._compressed_summary,
            version=self._summary_version,
            messages_compressed=self._summary_message_count,
            compressed_at=self._summary_timestamp,
            language=self._language,
        )
        content_blocks = summary_dict.get("content", [])
        return (
            content_blocks[0]["text"]
            if content_blocks and isinstance(content_blocks[0], dict)
            else self._compressed_summary
        )

    # -- Auto Memory Recall (string-only) ----------------------------------

    async def _get_recall_block(
        self,
        messages: list[BaseMessage],
    ) -> str:
        """Return auto-recall text to merge into the system prompt.

        Returns empty string if recall is disabled, not needed, or fails.
        """
        if not self._should_auto_recall():
            return ""

        if self._has_recall_context(messages):
            return ""

        user_text = self._extract_latest_user_text(messages)
        if not user_text or len(user_text.strip()) < 5:
            return ""

        query = user_text[: self._auto_recall_max_query_length]

        try:
            recall_result = await self._memory_manager.memory_search(
                query=query,
                max_results=self._auto_recall_max_results,
                min_score=self._auto_recall_min_score,
            )
        except Exception:
            logger.debug("Auto-recall search failed, continuing without recall")
            return ""

        if (
            not recall_result
            or recall_result == "No relevant memories found."
            or recall_result == "No memory backend available."
            or recall_result.startswith("Error:")
        ):
            return ""

        recall_msg = self._build_recall_message(recall_result, self._language)
        recall_text = recall_msg.content if isinstance(recall_msg.content, str) else ""

        if recall_text:
            logger.info(
                "Auto-recall: injected relevant memory snippets (%d chars)",
                len(recall_result),
            )
        return recall_text

    # -- Auto Memory Recall ------------------------------------------------

    @staticmethod
    def _extract_latest_user_text(messages: list[BaseMessage]) -> str:
        """Return the text content of the last HumanMessage, or empty string."""
        for msg in reversed(messages):
            if isinstance(msg, HumanMessage):
                content = msg.content
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    parts: list[str] = []
                    for block in content:
                        if isinstance(block, str):
                            parts.append(block)
                        elif isinstance(block, dict) and block.get("type") == "text":
                            parts.append(str(block.get("text", "")))
                    return "\n".join(parts)
        return ""

    def _should_auto_recall(self) -> bool:
        """Determine whether auto-recall should run this turn."""
        if not self._auto_recall_enabled:
            return False
        return self._memory_manager is not None

    @staticmethod
    def _has_recall_context(messages: list[BaseMessage]) -> bool:
        """Check whether an auto-recall block is already present."""
        for m in messages:
            text = m.content if isinstance(m.content, str) else ""
            if "<auto-recall-context>" in text:
                return True
        return False

    @staticmethod
    def _build_recall_message(snippet: str, language: str) -> SystemMessage:
        """Format recalled memory snippets into a SystemMessage."""
        if language == "zh":
            text = (
                "<auto-recall-context>\n"
                "根据你最近的消息，以下相关的历史记忆已被检索到：\n\n"
                f"{snippet}\n\n"
                "请参考这些信息以保持对话的连贯性。"
                "不要向用户提及这个记忆召回区块。\n"
                "</auto-recall-context>"
            )
        else:
            text = (
                "<auto-recall-context>\n"
                "Based on the latest user message, the following relevant "
                "historical memories were retrieved:\n\n"
                f"{snippet}\n\n"
                "Use these as reference to maintain continuity. "
                "Do not mention this recall block to the user.\n"
                "</auto-recall-context>"
            )
        return SystemMessage(content=text)

    # -- Memory Compaction -------------------------------------------------

    async def _maybe_compact(
        self,
        messages: list[BaseMessage],
    ) -> tuple[bool, list[BaseMessage]]:
        """Compact messages if token count exceeds threshold.

        Returns:
            A tuple ``(compacted, messages)`` where *compacted* is True
            when compaction actually happened.
        """
        if self._memory_manager is None:
            return False, messages

        # Separate system messages
        sys_msgs: list[BaseMessage] = []
        rest: list[BaseMessage] = []
        for m in messages:
            if isinstance(m, SystemMessage):
                sys_msgs.append(m)
            else:
                rest.append(m)

        if len(rest) <= self._keep_recent:
            return False, messages

        # Estimate tokens for compactable portion
        compactable = rest[: -self._keep_recent] if self._keep_recent > 0 else rest
        recent = rest[-self._keep_recent :] if self._keep_recent > 0 else []

        token_count = _count_tokens_estimate(compactable)

        if token_count <= self._compact_threshold:
            return False, messages

        # Signal that compaction is imminent so the next awrap_model_call
        # can inject a memory-flush reminder (before messages are lost).
        self._compaction_imminent = True

        logger.info(
            "Memory compaction triggered: ~%d tokens (threshold: %d), compacting %d messages, keeping %d recent",
            token_count,
            self._compact_threshold,
            len(compactable),
            len(recent),
        )

        try:
            # Start async summary task
            self._memory_manager.add_async_summary_task(
                messages=compactable,
                channel=self._channel,
                session_id=self._session_id,
            )

            # Compact memory
            compact_content = await self._memory_manager.compact_memory(
                messages_to_summarize=compactable,
                previous_summary=self._compressed_summary,
                config=self._compaction_config,
            )

            self._compressed_summary = compact_content
            self._summary_timestamp = datetime.now(UTC).isoformat(timespec="seconds")
            if compactable:
                self._summary_message_count = len(compactable)
            # compaction 后清空 token 缓存（消息已被替换，旧缓存失效）
            self._token_cache.clear()
            self._sys_token_cache.clear()
            logger.info("Memory compacted. Summary: %s...", compact_content[:100])

            # Persist versioned summary to SQLite when memory store is
            # attached — fixes the middleware persistence gap.
            if self._memory is not None:
                compacted_ids = [
                    m.additional_kwargs.get("id", "")
                    for m in compactable
                    if "id" in getattr(m, "additional_kwargs", {})
                ]
                await self._memory.update_compressed_summary(
                    summary=compact_content,
                    message_ids=compacted_ids or None,
                    trigger_source="middleware",
                    tokens_before=token_count,
                )
                # Refresh version from the persisted summary.
                self._summary_version = self._memory._summary_version

            # Rebuild: sys_msgs + recent (summary will be prepended by caller)
            return True, sys_msgs + recent

        except Exception:
            logger.exception("Memory compaction failed, continuing with full history")
            return False, messages
