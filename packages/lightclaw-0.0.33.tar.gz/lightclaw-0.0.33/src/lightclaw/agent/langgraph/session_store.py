"""Session persistence for LangChain messages.

This module provides the same session persistence semantics as
``SafeJSONSession`` but for LangChain ``BaseMessage`` objects instead
of AgentScope ``Msg`` objects.

Stored format per session::

    {
        "messages": [
            {"type": "human", "content": "...", ...},
            {"type": "ai",    "content": "...", "tool_calls": [...], ...},
            ...
        ],
        "compressed_summary": "..."
    }

Async support (PR3-Phase1):
    ``aload`` / ``asave`` / ``aclear`` wrap the synchronous I/O in
    ``asyncio.to_thread`` so callers on the event loop never block.
    The ``save`` / ``asave`` methods now emit compact JSON (no indent)
    to reduce serialisation overhead and file size.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from collections.abc import Sequence
from pathlib import Path

from langchain_core.messages import (
    BaseMessage,
    messages_from_dict,
    messages_to_dict,
)

logger = logging.getLogger(__name__)

# Characters forbidden in Windows filenames
_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|]')


def _sanitize(name: str) -> str:
    return _UNSAFE_FILENAME_RE.sub("--", name)


class LangGraphSessionStore:
    """JSON-file session store for chat messages.

    Mirrors ``SafeJSONSession`` but operates on LangChain messages.
    Files are stored as ``{user_id}_{session_id}.session.json``.
    Legacy ``.langgraph.json`` files are still readable for compatibility.
    """

    def __init__(self, save_dir: str | Path) -> None:
        self._save_dir = Path(save_dir)
        self._save_dir.mkdir(parents=True, exist_ok=True)
        self._migrate_legacy_files()

    def _migrate_legacy_files(self) -> None:
        """One-time best-effort migration for legacy ``.langgraph.json`` files."""
        migrated = 0
        skipped = 0
        failed = 0
        for legacy_path in self._save_dir.glob("*.langgraph.json"):
            target_name = legacy_path.name.replace(".langgraph.json", ".session.json")
            target_path = legacy_path.with_name(target_name)
            if target_path.exists():
                skipped += 1
                continue
            try:
                legacy_path.rename(target_path)
                migrated += 1
            except Exception:
                failed += 1
                logger.exception("Failed to migrate legacy session file %s", legacy_path.name)

        if migrated or skipped or failed:
            logger.info(
                "Session file migration: migrated=%d skipped=%d failed=%d",
                migrated,
                skipped,
                failed,
            )

    def _get_path(self, session_id: str, user_id: str | None, suffix: str = ".session.json") -> Path:
        safe_sid = _sanitize(session_id)
        safe_uid = _sanitize(user_id) if user_id else ""
        if safe_uid:
            filename = f"{safe_uid}_{safe_sid}{suffix}"
        else:
            filename = f"{safe_sid}{suffix}"
        return self._save_dir / filename

    def _get_read_paths(self, session_id: str, user_id: str | None) -> list[Path]:
        """Return candidate paths in read priority order."""
        return [
            self._get_path(session_id, user_id, ".session.json"),
            self._get_path(session_id, user_id, ".langgraph.json"),
        ]

    # ------------------------------------------------------------------
    # Synchronous API (kept for backward compatibility & CLI usage)
    # ------------------------------------------------------------------

    def load(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> tuple[list[BaseMessage], str]:
        """Load session history and compressed summary from disk.

        Returns:
            Tuple of (messages, compressed_summary).
            If no session file exists, returns ([], "").
        """
        path = next((p for p in self._get_read_paths(session_id, user_id) if p.exists()), None)
        if path is None:
            return [], ""

        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)

            raw_messages = data.get("messages", [])
            messages = messages_from_dict(raw_messages)
            compressed_summary = data.get("compressed_summary", "")

            logger.debug(
                "Loaded %d messages from %s",
                len(messages),
                path.name,
            )
            return messages, compressed_summary
        except Exception:
            logger.exception("Failed to load session from %s", path)
            return [], ""

    def save(
        self,
        session_id: str,
        user_id: str | None,
        messages: Sequence[BaseMessage],
        compressed_summary: str = "",
    ) -> None:
        """Persist session messages and compressed summary to disk.

        Note: Uses compact JSON (no indentation) to minimise serialisation
        cost and file size.  Old pretty-printed files are still readable.
        """
        path = self._get_path(session_id, user_id, ".session.json")
        try:
            data = {
                "messages": messages_to_dict(list(messages)),
                "compressed_summary": compressed_summary,
            }
            # Atomic write: write to tmp then rename
            tmp_path = path.with_suffix(".tmp")
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            tmp_path.replace(path)
            logger.debug(
                "Saved %d messages to %s",
                len(messages),
                path.name,
            )
        except Exception:
            logger.exception("Failed to save session to %s", path)

    def clear(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> None:
        """Delete the session file."""
        for path in self._get_read_paths(session_id, user_id):
            if path.exists():
                path.unlink()
                logger.debug("Cleared session file %s", path.name)

    # ------------------------------------------------------------------
    # Async API — event-loop-safe wrappers (PR3 Phase 1)
    # ------------------------------------------------------------------

    async def aload(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> tuple[list[BaseMessage], str]:
        """Async version of :meth:`load`.

        Delegates to ``asyncio.to_thread`` so the event loop is never
        blocked by file I/O.
        """
        return await asyncio.to_thread(self.load, session_id, user_id)

    async def asave(
        self,
        session_id: str,
        user_id: str | None,
        messages: Sequence[BaseMessage],
        compressed_summary: str = "",
    ) -> None:
        """Async version of :meth:`save`.

        Delegates to ``asyncio.to_thread`` so the event loop is never
        blocked by serialisation or file I/O.
        """
        await asyncio.to_thread(
            self.save,
            session_id,
            user_id,
            messages,
            compressed_summary,
        )

    async def aclear(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> None:
        """Async version of :meth:`clear`.

        Delegates to ``asyncio.to_thread`` so the event loop is never
        blocked by file deletion.
        """
        await asyncio.to_thread(self.clear, session_id, user_id)
