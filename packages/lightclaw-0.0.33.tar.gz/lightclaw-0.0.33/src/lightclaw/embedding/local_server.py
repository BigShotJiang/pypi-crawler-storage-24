"""本地 fastembed embedding 服务。

在主进程内通过 run_in_executor 运行 fastembed 推理，
不需要外部 Ollama 等服务。fastembed 为可选依赖（local-embedding extra）。
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastembed import TextEmbedding

logger = logging.getLogger(__name__)

# 默认缓存目录：~/.lightclaw/embedding_models
_DEFAULT_CACHE_DIR = Path.home() / ".lightclaw" / "embedding_models"


def get_fastembed_model_cache_dir(model_name: str) -> Path | None:
    """根据 fastembed 支持的模型列表，推导该模型对应的本地缓存目录。

    fastembed 内部使用类似 HuggingFace 的缓存子目录命名：
    `models--<org>--<repo>`，其中 `org/repo` 可能来自 sources.hf（而不一定等于 model_name）。
    """
    try:
        from fastembed import TextEmbedding
    except Exception:
        return None

    if not model_name:
        return None

    try:
        supported = TextEmbedding.list_supported_models()
    except Exception:
        return None

    entry = next((x for x in supported if x.get("model") == model_name), None)
    if entry:
        sources = entry.get("sources") or {}
        hf_source = sources.get("hf")
        if hf_source and isinstance(hf_source, str) and "/" in hf_source:
            subdir = "models--" + hf_source.replace("/", "--")
            candidate = _DEFAULT_CACHE_DIR / subdir
            return candidate

    # fallback：退化为按 model_name 直接映射
    if "/" in model_name:
        subdir = "models--" + model_name.replace("/", "--")
        return _DEFAULT_CACHE_DIR / subdir

    return None


# 预设模型列表（必须与 fastembed.TextEmbedding 内置 ONNX 列表一致）
#
# HuggingFace 上的 BAAI/bge-{base,large}-zh-v1.5 并不在 fastembed 支持范围内，
# 使用它们会在初始化时报错。可用模型请以 ``TextEmbedding.list_supported_models()``
# 为准；以下为中文/多语言场景下常用且已验证可用的选项。
PRESET_MODELS = [
    "BAAI/bge-small-zh-v1.5",  # 轻量中文，512 维，推荐默认
    "jinaai/jina-embeddings-v2-base-zh",  # 中英混合，768 维，上下文更长
    "intfloat/multilingual-e5-large",  # 多语言大模型，1024 维
]

# HuggingFace 国内镜像源（从环境变量读取，支持用户自定义）
_HF_MIRROR = os.environ.get(
    "HF_ENDPOINT",
    "https://hf-mirror.com",  # 默认国内源
)


class LocalEmbeddingServer:
    """使用 fastembed 在进程内运行本地 embedding 模型。

    生命周期：
    - ``initialize()`` — 在 lifespan startup 中调用，后台加载模型
    - ``embed()``      — 推理，返回向量列表
    - ``shutdown()``   — 在 lifespan shutdown 中调用，释放内存
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-small-zh-v1.5",
        cache_dir: Path | None = None,
    ) -> None:
        self.model_name = model_name
        self.cache_dir = cache_dir or _DEFAULT_CACHE_DIR
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self._model: TextEmbedding | None = None
        self._lock = asyncio.Lock()
        self._initialized = False
        self._dimensions: int | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def is_ready(self) -> bool:
        """模型是否已加载完成，可以推理。"""
        return self._initialized and self._model is not None

    @property
    def dimensions(self) -> int | None:
        """向量维度，初始化后才有值。"""
        return self._dimensions

    async def initialize(self) -> None:
        """后台加载模型（阻塞 IO 放入线程池，不阻塞事件循环）。

        首次调用时，fastembed 会自动从 HuggingFace 下载模型文件（~250MB）。
        后续启动直接从 cache_dir 读取，无需网络。
        """
        async with self._lock:
            if self._initialized:
                return
            logger.info(
                "Loading local embedding model '%s' (cache: %s) ...",
                self.model_name,
                self.cache_dir,
            )
            try:
                loop = asyncio.get_running_loop()
                self._model = await loop.run_in_executor(
                    None,
                    self._load_model,
                )
                # 推断维度
                self._dimensions = self._probe_dimensions()
                self._initialized = True
                logger.info(
                    "Local embedding model ready: %s (dim=%s)",
                    self.model_name,
                    self._dimensions,
                )
            except ImportError:
                logger.error("fastembed not installed. Run: uv sync --extra local-embedding")
                raise
            except Exception as exc:
                logger.error(
                    "Failed to load local embedding model '%s': %s",
                    self.model_name,
                    exc,
                )
                raise

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """对文本列表进行 embedding，返回向量列表。

        Args:
            texts: 待编码的文本列表。

        Returns:
            每条文本对应的浮点向量列表。

        Raises:
            RuntimeError: 模型尚未初始化。
        """
        if not self.is_ready:
            raise RuntimeError("LocalEmbeddingServer is not initialized. Call initialize() first.")
        loop = asyncio.get_running_loop()
        vectors = await loop.run_in_executor(
            None,
            self._embed_sync,
            texts,
        )
        return vectors

    async def shutdown(self) -> None:
        """释放模型内存。在 lifespan shutdown 中调用。"""
        async with self._lock:
            if self._model is not None:
                logger.info(
                    "Shutting down local embedding model '%s'",
                    self.model_name,
                )
                self._model = None
                self._initialized = False
                self._dimensions = None

    # ------------------------------------------------------------------
    # Sync helpers（在线程池中运行）
    # ------------------------------------------------------------------

    def _load_model(self) -> TextEmbedding:
        """同步加载 fastembed 模型（在线程池中运行）。"""
        from fastembed import TextEmbedding  # pylint: disable=import-outside-toplevel

        # 设置国内镜像源环境变量
        os.environ["HF_ENDPOINT"] = _HF_MIRROR

        return TextEmbedding(
            model_name=self.model_name,
            cache_dir=str(self.cache_dir),
            # 关闭进度条输出，避免污染日志
            show_progress=False,
        )

    def _embed_sync(self, texts: list[str]) -> list[list[float]]:
        """同步推理（在线程池中运行）。"""
        embeddings = list(self._model.embed(texts))
        # fastembed 返回 numpy array，转为 Python list
        return [emb.tolist() for emb in embeddings]

    def _probe_dimensions(self) -> int | None:
        """推断向量维度（用一条短文本试推理）。"""
        try:
            result = list(self._model.embed(["probe"]))
            if result:
                return len(result[0])
        except Exception:
            pass
        return None

    # ------------------------------------------------------------------
    # OpenAI-compatible embedding endpoint
    # ------------------------------------------------------------------

    def get_base_url(self) -> str:
        """返回本地 HTTP 服务 URL（由 EmbeddingManager 托管）。"""
        port = int(os.environ.get("LOCAL_EMBEDDING_PORT", "18765"))
        return f"http://127.0.0.1:{port}"
