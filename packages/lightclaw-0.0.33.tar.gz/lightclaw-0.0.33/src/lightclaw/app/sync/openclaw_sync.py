"""Sync utilities: pull .md files and config fields from an OpenClaw workspace
into the LightClaw working directory.

Default paths
-------------
- openclaw.json   : ``~/.openclaw/openclaw.json``
- openclaw workspace : ``~/.openclaw/workspace`` by default, or the value of
                       ``agents.defaults.workspace`` inside openclaw.json
- lightclaw WORKING_DIR : ``~/.lightclaw/workspace/`` (from constant.WORKING_DIR)

Both paths can be overridden via ``lightclaw.json`` → ``openclaw.configPath`` /
``openclaw.workspacePath``, or passed directly to :func:`sync_from_openclaw`.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from ...constant import WORKING_DIR

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants / defaults
# ---------------------------------------------------------------------------

_DEFAULT_OPENCLAW_JSON = Path.home() / ".openclaw" / "openclaw.json"
_DEFAULT_OPENCLAW_WORKSPACE = Path.home() / ".openclaw" / "workspace"


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class OpenClawSyncResult:
    """Summary of a sync operation."""

    md_synced: int = 0
    md_skipped: int = 0
    skills_synced: int = 0
    config_updated: bool = False
    updated_fields: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return len(self.errors) == 0


# ---------------------------------------------------------------------------
# Path resolution helpers
# ---------------------------------------------------------------------------


def get_openclaw_config_path(override: str | None = None) -> Path:
    """Return the path to openclaw.json.

    Priority:
    1. *override* argument (CLI flag / API body)
    2. ``lightclaw.json`` → ``openclaw.configPath``
    3. ``~/.openclaw/openclaw.json``
    """
    if override:
        return Path(override).expanduser().resolve()

    try:
        from ...config.utils import load_config

        cfg = load_config()
        if cfg.openclaw.config_path:
            return Path(cfg.openclaw.config_path).expanduser().resolve()
    except Exception:
        pass

    return _DEFAULT_OPENCLAW_JSON


def get_openclaw_workspace_path(
    openclaw_cfg: dict,
    override: str | None = None,
) -> Path:
    """Return the openclaw workspace directory.

    Priority:
    1. *override* argument
    2. ``lightclaw.json`` → ``openclaw.workspacePath``
    3. ``agents.defaults.workspace`` inside *openclaw_cfg*
    4. ``~/.openclaw/workspace``
    """
    if override:
        return Path(override).expanduser().resolve()

    try:
        from ...config.utils import load_config

        cfg = load_config()
        if cfg.openclaw.workspace_path:
            return Path(cfg.openclaw.workspace_path).expanduser().resolve()
    except Exception:
        pass

    raw = openclaw_cfg.get("agents", {}).get("defaults", {}).get("workspace", "")
    if raw:
        return Path(raw).expanduser().resolve()

    return _DEFAULT_OPENCLAW_WORKSPACE


# ---------------------------------------------------------------------------
# .md file sync
# ---------------------------------------------------------------------------


def sync_skills_from_workspace(
    src_workspace: Path,
    dry_run: bool = False,
) -> int:
    """Sync skills found inside an openclaw workspace's ``skills/`` directory.

    If ``{src_workspace}/skills/`` exists and contains valid skill directories
    (each with a ``SKILL.md``), they are copied into ``~/.lightclaw/skills/``
    (overwrite) and automatically enabled in ``lightclaw.json``.

    Args:
        src_workspace: The openclaw workspace directory.
        dry_run: If True, count but do not write.

    Returns:
        Number of skills synced.
    """
    skills_src = src_workspace / "skills"
    if not skills_src.is_dir():
        return 0

    from ...constant import SKILLS_DIR

    synced = 0
    skill_names_synced: list[str] = []

    for skill_dir in skills_src.iterdir():
        if not skill_dir.is_dir() or not (skill_dir / "SKILL.md").exists():
            continue
        target = SKILLS_DIR / skill_dir.name
        if not dry_run:
            try:
                SKILLS_DIR.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    shutil.rmtree(target)
                shutil.copytree(skill_dir, target)
                logger.debug(
                    "Synced openclaw workspace skill '%s' -> %s",
                    skill_dir.name,
                    target,
                )
            except Exception as exc:
                logger.warning("Failed to copy skill '%s': %s", skill_dir.name, exc)
                continue
        skill_names_synced.append(skill_dir.name)
        synced += 1

    # Auto-enable synced skills in lightclaw.json
    if skill_names_synced and not dry_run:
        try:
            from ...config.config import SkillEntryConfig
            from ...config.utils import load_config, save_config

            config = load_config()
            for name in skill_names_synced:
                config.skills.entries[name] = SkillEntryConfig(enabled=True)
            save_config(config)
            logger.info(
                "Auto-enabled %d workspace skill(s): %s",
                len(skill_names_synced),
                ", ".join(skill_names_synced),
            )
        except Exception as exc:
            logger.warning("Skills copied but failed to update lightclaw.json entries: %s", exc)

    return synced


def sync_prompts(
    src_workspace: Path,
    dst_workspace: Path,
    dry_run: bool = False,
) -> tuple[int, int]:
    """Recursively copy all .md files from *src_workspace* to *dst_workspace*.

    Files are always overwritten (openclaw wins on conflict).

    Returns:
        ``(synced_count, skipped_count)`` — skipped means the src file could
        not be read, not that an existing dst file was preserved.
    """
    synced = 0
    skipped = 0

    if not src_workspace.exists():
        logger.warning("OpenClaw workspace not found: %s", src_workspace)
        return 0, 0

    for src_file in src_workspace.rglob("*.md"):
        try:
            rel = src_file.relative_to(src_workspace)
            dst_file = dst_workspace / rel
            if not dry_run:
                dst_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_file, dst_file)
                logger.debug("Synced md: %s -> %s", src_file, dst_file)
            synced += 1
        except Exception as exc:
            logger.warning("Failed to sync %s: %s", src_file, exc)
            skipped += 1

    return synced, skipped


# ---------------------------------------------------------------------------
# Config field sync helpers
# ---------------------------------------------------------------------------


def _sync_models(openclaw_models: dict, config) -> bool:  # type: ignore[type-arg]
    """Merge openclaw models.providers into lightclaw config.models.

    - Each provider in openclaw.models.providers is written into
      config.models.providers (overwrites same-keyed entry).
    - If openclaw has an ``activeLlm`` equivalent it is copied over.

    Returns True if any change was applied.
    """
    from ...providers.models import ProviderEntry

    changed = False

    providers_raw: dict = openclaw_models.get("providers", {})
    for pid, pdata in providers_raw.items():
        if not isinstance(pdata, dict):
            continue
        try:
            entry = ProviderEntry.model_validate(pdata)
            # Mark as custom if it doesn't look like a known built-in provider
            if not entry.is_custom and pid not in _known_builtin_ids():
                entry.is_custom = True
            config.models.providers[pid] = entry
            changed = True
            logger.debug("Synced provider '%s' from openclaw", pid)
        except Exception as exc:
            logger.warning("Could not parse provider '%s': %s", pid, exc)

    return changed


def _known_builtin_ids() -> set[str]:
    """Return the set of built-in provider IDs from the provider registry."""
    try:
        from ...providers.registry import PROVIDERS

        return set(PROVIDERS.keys())
    except Exception:
        return set()


def _sync_active_llm(openclaw_agents: dict, config) -> bool:  # type: ignore[type-arg]
    """Copy agents.defaults.model.primary -> config.models.active_llm.

    openclaw stores the active model as:
        agents.defaults.model.primary = "provider-id/model-id"

    Returns True if changed.
    """
    primary = openclaw_agents.get("defaults", {}).get("model", {}).get("primary", "")
    if primary and primary != config.models.active_llm:
        config.models.active_llm = primary
        logger.debug("Synced activeLlm -> '%s'", primary)
        return True
    return False


def _sync_channels(openclaw_channels: dict, config) -> bool:  # type: ignore[type-arg]
    """Merge openclaw channels into lightclaw config.channels.

    Known lightclaw channels (feishu, qqbot, dingtalk, discord) are updated
    field-by-field.  Unknown channel keys are stored as extra fields on the
    ChannelConfig (which uses ``extra="allow"``).

    Returns True if any change was applied.
    """
    from ...config.config import (
        DingTalkConfig,
        DiscordConfig,
        FeishuConfig,
        LightClawBotConfig,
        QQConfig,
    )

    changed = False

    # Mapping: openclaw channel key -> (lightclaw attr, pydantic model class)
    _KNOWN: dict[str, tuple[str, type]] = {
        "feishu": ("feishu", FeishuConfig),
        "qqbot": ("qqbot", QQConfig),
        "dingtalk": ("dingtalk", DingTalkConfig),
        "discord": ("discord", DiscordConfig),
        # openclaw uses "ddingtalk" as the npm plugin key — treat as dingtalk
        "ddingtalk": ("dingtalk", DingTalkConfig),
        # lightclawbot 频道
        "lightclawbot": ("lightclawbot", LightClawBotConfig),
    }

    for oc_key, oc_val in openclaw_channels.items():
        if not isinstance(oc_val, dict):
            continue
        if oc_key in _KNOWN:
            attr, model_cls = _KNOWN[oc_key]
            try:
                merged = model_cls.model_validate(oc_val)
                setattr(config.channels, attr, merged)
                changed = True
                logger.debug("Synced channel '%s'", oc_key)
            except Exception as exc:
                logger.warning("Could not parse channel '%s': %s", oc_key, exc)
        else:
            # Store unknown channels as extra fields (ChannelConfig allows extras)
            try:
                existing_extras = config.channels.model_extra or {}
                existing_extras[oc_key] = oc_val
                # Rebuild with extras — Pydantic v2 extra fields are read-only
                # on the instance; we update the internal __pydantic_extra__ dict.
                if hasattr(config.channels, "__pydantic_extra__") and config.channels.__pydantic_extra__ is not None:
                    config.channels.__pydantic_extra__[oc_key] = oc_val
                changed = True
                logger.debug("Stored extra channel '%s'", oc_key)
            except Exception as exc:
                logger.warning("Could not store extra channel '%s': %s", oc_key, exc)

    return changed


def _sync_agents(openclaw_agents: dict, config) -> bool:  # type: ignore[type-arg]
    """Merge openclaw agents settings into lightclaw config.agents.

    Currently syncs:
    - ``agents.defaults.maxConcurrent`` (ignored — lightclaw doesn't have this)
    - ``agents.defaults.compaction.mode`` (ignored)
    - language is not directly set in openclaw.json, skip
    - ``agents.defaults.subagents.maxConcurrent`` → maxIters approximation (skip)

    Returns True if any change was applied.
    """
    # Currently a no-op placeholder.  Extend as needed.
    return False


def sync_config_fields(openclaw_cfg: dict, config, dry_run: bool = False) -> tuple[bool, list[str]]:
    """Apply all config field mappings from openclaw_cfg to config.

    Returns:
        ``(changed, updated_field_names)``
    """
    changed = False
    updated: list[str] = []

    # models (providers)
    oc_models = openclaw_cfg.get("models", {})
    if oc_models:
        if dry_run:
            # In dry-run mode, check if there's anything to sync without writing
            changed = True
            updated.append("models.providers")
        elif _sync_models(oc_models, config):
            changed = True
            updated.append("models.providers")

    # activeLlm — stored under agents.defaults.model.primary, independent of models block
    oc_agents_for_llm = openclaw_cfg.get("agents", {})
    primary = oc_agents_for_llm.get("defaults", {}).get("model", {}).get("primary", "")
    if primary:
        if dry_run:
            if primary != config.models.active_llm:
                changed = True
                updated.append("models.activeLlm")
        elif _sync_active_llm(oc_agents_for_llm, config):
            changed = True
            updated.append("models.activeLlm")

    # channels
    oc_channels = openclaw_cfg.get("channels", {})
    if oc_channels and (dry_run or _sync_channels(oc_channels, config)):
        changed = True
        updated.append("channels")

    # agents
    oc_agents = openclaw_cfg.get("agents", {})
    if oc_agents and not dry_run and _sync_agents(oc_agents, config):
        changed = True
        updated.append("agents")

    return changed, updated


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def sync_from_openclaw(
    openclaw_json_path: Path | None = None,
    sync_md: bool = True,
    sync_config: bool = True,
    dry_run: bool = False,
) -> OpenClawSyncResult:
    """Pull .md files and config fields from an OpenClaw workspace into LightClaw.

    Args:
        openclaw_json_path: Custom path to openclaw.json.  Uses default
            (``~/.openclaw/openclaw.json``) when *None*.
        sync_md: Whether to synchronise .md files.
        sync_config: Whether to update lightclaw.json config fields.
        dry_run: If True, discover what *would* be done without writing.

    Returns:
        :class:`OpenClawSyncResult` with counts and any warnings / errors.
    """
    result = OpenClawSyncResult()

    # 1. Resolve openclaw.json path
    oc_json_path = get_openclaw_config_path(str(openclaw_json_path) if openclaw_json_path else None)
    if not oc_json_path.is_file():
        result.errors.append(f"openclaw.json not found at {oc_json_path}")
        return result

    # 2. Load openclaw.json
    try:
        with open(oc_json_path, encoding="utf-8") as fh:
            openclaw_cfg: dict = json.load(fh)
    except Exception as exc:
        result.errors.append(f"Failed to read {oc_json_path}: {exc}")
        return result

    logger.info("Loaded openclaw config from %s", oc_json_path)

    # 3. Resolve openclaw workspace
    oc_workspace = get_openclaw_workspace_path(openclaw_cfg)
    logger.info("OpenClaw workspace: %s", oc_workspace)

    workspace_exists = oc_workspace.exists()
    if not workspace_exists:
        result.warnings.append(f"OpenClaw workspace directory not found: {oc_workspace}")

    # 3a. Sync .md files
    if sync_md and workspace_exists:
        synced, skipped = sync_prompts(oc_workspace, WORKING_DIR, dry_run=dry_run)
        result.md_synced = synced
        result.md_skipped = skipped
        logger.info(
            "MD sync: %d synced, %d skipped%s",
            synced,
            skipped,
            " (dry-run)" if dry_run else "",
        )

    # 3b. Sync skills from workspace/skills/ (if present)
    if workspace_exists:
        try:
            skills_count = sync_skills_from_workspace(oc_workspace, dry_run=dry_run)
            result.skills_synced = skills_count
            if skills_count:
                logger.info(
                    "Skills sync: %d skill(s)%s",
                    skills_count,
                    " (dry-run)" if dry_run else "",
                )
        except Exception as exc:
            msg = f"Failed to sync workspace skills: {exc}"
            logger.warning(msg)
            result.warnings.append(msg)

    # 4. Sync config fields
    if sync_config:
        try:
            from ...config.utils import load_config, save_config

            lc_config = load_config()
            cfg_changed, updated_fields = sync_config_fields(openclaw_cfg, lc_config, dry_run=dry_run)
            if cfg_changed and not dry_run:
                save_config(lc_config)
                logger.info("lightclaw.json updated: %s", ", ".join(updated_fields))
            result.config_updated = cfg_changed
            result.updated_fields = updated_fields
        except Exception as exc:
            msg = f"Failed to sync config fields: {exc}"
            logger.exception(msg)
            result.errors.append(msg)

    return result
