from __future__ import annotations

import asyncio
import json
from pathlib import Path

from ..models import JobsFile
from .base import BaseJobRepository


class JsonJobRepository(BaseJobRepository):
    """jobs.json repository (single-file storage).

    Notes:
    - Single-machine, no cross-process lock.
    - Atomic write: write tmp then replace.
    - File I/O runs via ``asyncio.to_thread`` to avoid blocking the event loop.
    """

    def __init__(self, path: Path):
        self._path = path.expanduser()

    @property
    def path(self) -> Path:
        return self._path

    def _load_sync(self) -> JobsFile:
        """Read and parse jobs.json synchronously (called in a thread)."""
        if not self._path.exists():
            return JobsFile(version=1, jobs=[])
        data = json.loads(self._path.read_text(encoding="utf-8"))
        return JobsFile.model_validate(data)

    async def load(self) -> JobsFile:
        return await asyncio.to_thread(self._load_sync)

    def _save_sync(self, jobs_file: JobsFile) -> None:
        """Write jobs.json atomically via tmp+rename (called in a thread)."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self._path.with_suffix(self._path.suffix + ".tmp")
        payload = jobs_file.model_dump(mode="json")
        tmp_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        tmp_path.replace(self._path)

    async def save(self, jobs_file: JobsFile) -> None:
        await asyncio.to_thread(self._save_sync, jobs_file)
