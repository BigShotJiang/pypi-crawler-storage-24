"""Shared cron agent execution: build request → run agent → dispatch to channel.

Both heartbeat and proactivity call ``run_cron_agent()`` so the
request-building / streaming / dispatch logic lives in one place.
"""
from __future__ import annotations

import asyncio
import logging
import re
from typing import Any

from ...config import load_config
from ...constant import HEARTBEAT_TARGET_LAST
from ..turn_protocol import TurnEvent, TurnEventType, TurnInput, TurnRequest

logger = logging.getLogger(__name__)


_SKIP_MARKER = "[SKIP]"

# Regex to strip <thinking>…</thinking> blocks (including multiline).
_THINKING_RE = re.compile(r"<thinking>.*?</thinking>", re.DOTALL)

# Delta message types that should be skipped (reasoning, tool internals).
_SKIP_DELTA_TYPES = {
    "reasoning",
    "thinking",
    "tool_call",
    "tool_result",
    "function_call",
    "function_call_output",
}


def _strip_thinking(text: str) -> str:
    """Remove <thinking>…</thinking> blocks and leading/trailing whitespace."""
    return _THINKING_RE.sub("", text).strip()


async def run_cron_agent(
    *,
    query_text: str,
    runner: Any,
    channel_manager: Any,
    target: str = "main",
    session_id: str = "main",
    user_id: str = "main",
    source: str = "cron",
    timeout: int = 120,
) -> bool:
    """Run an agent with *query_text* and optionally dispatch to a channel.

    Returns ``True`` if a message was actually dispatched (or run-only
    completed), ``False`` if the agent output contained ``[SKIP]``.

    Args:
        query_text: The prompt text to send to the agent.
        runner: AgentRunner instance.
        channel_manager: ChannelManager instance.
        target: ``"main"`` (run only) or ``"last"`` (dispatch to last channel).
        session_id: Session ID for the request.
        user_id: User ID for the request.
        source: Origin label (``"heartbeat"``, ``"proactivity"``, ``"cron"``).
        timeout: Maximum seconds for the entire run.
    """
    config = load_config()

    ld = config.last_dispatch
    should_dispatch = target == HEARTBEAT_TARGET_LAST

    if should_dispatch:
        # Resolve dispatch target: use last_dispatch if available,
        # otherwise fall back to dashboard channel.
        dispatch_channel = (ld.channel if ld and ld.channel else "dashboard")
        dispatch_user_id = (ld.user_id if ld else "") or user_id
        dispatch_session_id = (ld.session_id if ld else "") or session_id
    else:
        dispatch_channel = "dashboard"
        dispatch_user_id = user_id
        dispatch_session_id = session_id

    # Session isolation for proactivity: LLM runs use separate session to prevent
    # mixing proactive history with user chat history.
    # The LLM loads context from "proactive_{dispatch_session_id}",
    # but dispatch goes to "{dispatch_session_id}" (visible to user).
    if source == "proactivity":
        llm_session_id = f"proactive_{dispatch_session_id}"
        logger.debug(
            "Session isolation: LLM uses %s, dispatch goes to %s",
            llm_session_id,
            dispatch_session_id,
        )
    else:
        llm_session_id = dispatch_session_id

    # Build canonical TurnRequest
    turn_request = TurnRequest(
        inputs=[
            TurnInput(
                role="user",
                content=[{"type": "text", "text": query_text}],
            ),
        ],
        session_id=llm_session_id,  # LLM loads context from this session
        user_id=dispatch_user_id,
        channel=dispatch_channel,
        # Extra fields for runner internals
        source=source,
        ephemeral=True,
    )

    async def _run_and_maybe_dispatch() -> bool:
        """Collect delta text, check for SKIP, then dispatch a full event."""
        # Streaming mode: text arrives via assistant.delta, and
        # assistant.completed has content stripped (to avoid duplicates
        # for SSE consumers).  We accumulate deltas here and reconstruct
        # a complete event for channel dispatch.
        #
        # ReAct agents interleave reasoning text with tool calls:
        #   [text: "让我检查..."] → [tool_started] → [tool_completed] → [text: "最终回复"]
        # We only want the FINAL text segment (after the last tool call).
        # So whenever a tool event appears, we clear the accumulated text.
        text_chunks: list[str] = []
        completed_event: TurnEvent | None = None

        async for event in runner.stream_turns(turn_request):
            if event.type == TurnEventType.ASSISTANT_DELTA:
                # Skip reasoning/thinking/tool deltas — only collect message text
                meta = getattr(event, "metadata", None) or {}
                msg_type = meta.get("message_type", "")
                if msg_type in _SKIP_DELTA_TYPES:
                    continue
                delta = event.delta
                if isinstance(delta, str):
                    text_chunks.append(delta)
                elif isinstance(delta, dict) and delta.get("type") == "text":
                    text_chunks.append(delta.get("text") or "")
            elif event.type in (TurnEventType.TOOL_STARTED, TurnEventType.TOOL_COMPLETED):
                # A tool call means everything before this was intermediate
                # reasoning. Clear it — we only want the final reply.
                text_chunks.clear()
            elif event.type == TurnEventType.ASSISTANT_COMPLETED:
                completed_event = event
                # Also check if completed event itself has text content
                # (non-streaming fallback path). Skip thinking/reasoning parts.
                for part in (event.content or []):
                    if not isinstance(part, dict):
                        continue
                    part_type = part.get("type", "")
                    if part_type in ("thinking", "reasoning"):
                        continue
                    if part_type == "text":
                        t = (part.get("text") or "").strip()
                        if t:
                            text_chunks.append(t)

        full_text = _strip_thinking("".join(text_chunks))
        logger.info("%s: agent output collected, len=%d", source, len(full_text))
        logger.debug("%s: output content: %s", source, full_text[:200] if full_text else "(empty)")

        # Check if agent decided nothing is worth pushing.
        if not full_text or _SKIP_MARKER in full_text:
            logger.info(
                "%s: agent returned [SKIP] or empty, not dispatching",
                source,
            )
            return False

        if not should_dispatch:
            logger.info("%s: run-only completed (no dispatch)", source)
            return True

        # Build a complete TurnEvent with the full text for dispatch.
        dispatch_event = TurnEvent(
            type=TurnEventType.ASSISTANT_COMPLETED,
            turn_id=completed_event.turn_id if completed_event else "cron",
            message_id=completed_event.message_id if completed_event else None,
            role="assistant",
            content=[{"type": "text", "text": full_text}],
            usage=completed_event.usage if completed_event else None,
        )

        try:
            await channel_manager.send_event(
                channel=dispatch_channel,
                user_id=dispatch_user_id,
                session_id=dispatch_session_id,
                event=dispatch_event,
                meta={},
            )
            logger.info("%s: dispatched to %s", source, dispatch_channel)
        except Exception:
            logger.exception("%s: send_event failed", source)

        # Ensure a chat entry exists so the message appears in the session list.
        try:
            await _ensure_chat_exists(
                runner=runner,
                channel=dispatch_channel,
                user_id=dispatch_user_id,
                session_id=dispatch_session_id,
                source=source,
            )
        except Exception:
            logger.debug("%s: ensure_chat_exists failed", source, exc_info=True)

        # Persist the message into the dispatch target session so it survives
        # page refresh. The LLM ran in an isolated session (proactive_xxx),
        # but the user sees dispatch_session_id — append there.
        try:
            await _persist_to_session(
                runner=runner,
                user_id=dispatch_user_id,
                session_id=dispatch_session_id,
                text=full_text,
                source=source,
            )
        except Exception:
            logger.debug("%s: persist_to_session failed", source, exc_info=True)

        return True

    try:
        return await asyncio.wait_for(_run_and_maybe_dispatch(), timeout=timeout)
    except TimeoutError:
        logger.warning("%s run timed out", source)
    return False


async def _ensure_chat_exists(
    *,
    runner: Any,
    channel: str,
    user_id: str,
    session_id: str,
    source: str,
) -> None:
    """Create a chat entry if one doesn't already exist for this session.

    This ensures proactive/cron messages appear in the dashboard session list.
    """
    chat_manager = getattr(runner, "_chat_manager", None)
    if chat_manager is None:
        return

    # Build a default chat name based on source
    _SOURCE_NAMES = {
        "proactivity": "Proactive Chat",
        "heartbeat": "Heartbeat",
        "cron": "Scheduled Task",
    }
    name = _SOURCE_NAMES.get(source, "Chat")

    await chat_manager.get_or_create_chat(
        session_id=session_id,
        user_id=user_id,
        channel=channel,
        name=name,
    )
    logger.info("%s: chat entry ensured for session=%s", source, session_id)


async def _persist_to_session(
    *,
    runner: Any,
    user_id: str,
    session_id: str,
    text: str,
    source: str,
) -> None:
    """Append the proactive message to the dispatch target session file.

    This makes the message survive page refreshes. The LangGraph session
    store is loaded, the AI message is appended, and the file is saved back.
    """
    session = getattr(runner, "session", None)
    save_dir = getattr(session, "save_dir", None) or getattr(session, "_save_dir", None)
    if not save_dir:
        logger.debug("%s: no save_dir found on runner.session, skip persist", source)
        return

    from ...agent.langgraph.session_store import LangGraphSessionStore

    store = LangGraphSessionStore(save_dir=save_dir)
    messages, summary = await store.aload(session_id, user_id)

    from langchain_core.messages import AIMessage

    messages.append(AIMessage(content=text))

    await store.asave(session_id, user_id, messages, summary)
    logger.info("%s: persisted message to session %s", source, session_id)
