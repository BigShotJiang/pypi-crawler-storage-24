"""Message deduplication and throttle — Python port of dedup.ts."""

from __future__ import annotations

import logging
import time
import uuid
from collections import OrderedDict

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Unique message ID generation
# ---------------------------------------------------------------------------


def generate_msg_id() -> str:
    """Generate a short unique message ID (same convention as TS plugin)."""
    return uuid.uuid4().hex[:16]


# ---------------------------------------------------------------------------
# TTL-based dedup set
# ---------------------------------------------------------------------------


class DedupSet:
    """Track seen message IDs for a configurable TTL window.

    Evicts expired entries lazily on each ``add`` / ``has`` call.
    """

    def __init__(self, ttl_seconds: float = 120.0, max_size: int = 2000):
        self._ttl = ttl_seconds
        self._max = max_size
        self._store: OrderedDict[str, float] = OrderedDict()

    def _evict(self) -> None:
        now = time.monotonic()
        while self._store:
            key, ts = next(iter(self._store.items()))
            if now - ts > self._ttl:
                self._store.pop(key)
            else:
                break
        # Hard cap
        while len(self._store) > self._max:
            self._store.popitem(last=False)

    def has(self, msg_id: str) -> bool:
        self._evict()
        return msg_id in self._store

    def add(self, msg_id: str) -> bool:
        """Add *msg_id*. Returns ``True`` if it was already present (dup)."""
        self._evict()
        if msg_id in self._store:
            return True
        self._store[msg_id] = time.monotonic()
        return False


# ---------------------------------------------------------------------------
# Per-user throttle (for history requests etc.)
# ---------------------------------------------------------------------------


class Throttle:
    """Simple per-key cooldown (seconds)."""

    def __init__(self, cooldown: float = 2.0):
        self._cooldown = cooldown
        self._last: dict[str, float] = {}

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        prev = self._last.get(key, 0.0)
        if now - prev < self._cooldown:
            return False
        self._last[key] = now
        return True

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self._last.clear()
        else:
            self._last.pop(key, None)
