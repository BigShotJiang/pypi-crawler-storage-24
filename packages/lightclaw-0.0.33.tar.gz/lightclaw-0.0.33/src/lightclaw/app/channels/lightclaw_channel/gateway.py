"""Socket.IO gateway — manages the WebSocket connection to LightClaw server.

Python port of gateway.ts using ``python-socketio[asyncio_client]``.

Enhanced with:
  - Message queue (1000 capacity, 200ms poll) for ordered processing
  - Socket registry integration for outbound disconnect buffering
  - Socket event handlers for history/sessions queries
  - Health heartbeat timer (20min interval)
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from collections import deque
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from typing import Any

import aiohttp
import socketio

from .config import (
    DEFAULT_API_BASE,
    DEFAULT_WS_URL,
    ENDPOINT_USER_CURRENT,
    EVENT_MESSAGE_PRIVATE,
    RECONNECT_DELAY_INITIAL,
    RECONNECT_DELAY_MAX,
    SOCKET_PATH,
    X_PRODUCT,
    build_auth_headers,
    build_gateway_context,
)
from .dedup import DedupSet
from .socket_handlers import SocketEventBinder, SocketHandlerDeps
from .socket_registry import get_socket_registry
from .types import GatewayContext, LightClawAccountConfig, PrivateMessageData

logger = logging.getLogger(__name__)

# Constants
MAX_QUEUE_SIZE = 1000
QUEUE_POLL_INTERVAL = 0.2  # 200ms
HEARTBEAT_INTERVAL = 20 * 60  # 20 minutes


# Type alias for inbound handler
InboundHandler = Callable[
    [PrivateMessageData, GatewayContext],
    Coroutine[Any, Any, None],
]


@dataclass
class QueuedMessage:
    """Internal message queue item."""

    sender_id: str
    text: str
    message_id: str
    files: list
    timestamp: int
    raw: PrivateMessageData


class LightClawGateway:
    """Manages Socket.IO connection lifecycle for one LightClaw account.

    Responsibilities:
    - Fetch bot identity via HTTP (``/user/current``)
    - Establish & maintain Socket.IO connection
    - Dispatch inbound ``message:private`` events to *on_message*
    - Handle ``message:history:request`` and ``sessions:request`` events
    - Manage message queue for ordered processing
    - Socket registry integration for outbound disconnect buffering
    - Health heartbeat (20min interval)
    - Auto-reconnect with exponential backoff
    """

    def __init__(
        self,
        account_id: str,
        config: LightClawAccountConfig,
        on_message: InboundHandler,
    ):
        self._account_id = account_id
        self._config = config
        self._on_message = on_message

        self._bot_id: str = ""
        self._ctx: GatewayContext | None = None
        self._sio: socketio.AsyncClient | None = None
        self._connected = False
        self._stopping = False
        self._dedup = DedupSet(ttl_seconds=120)

        self._base_url = (config.api_base_url or DEFAULT_API_BASE).rstrip("/")
        # Derive WebSocket URL
        if config.api_base_url:
            ws = config.api_base_url.rstrip("/")
            ws = ws.replace("https://", "wss://").replace("http://", "ws://")
            self._ws_url = ws
        else:
            self._ws_url = DEFAULT_WS_URL
        self._headers = build_auth_headers(config.api_key)

        # Message queue
        self._queue: deque[QueuedMessage] = deque(maxlen=MAX_QUEUE_SIZE)
        self._queue_task: asyncio.Task | None = None

        # Health heartbeat
        self._heartbeat_task: asyncio.Task | None = None

        # Event binder
        self._event_binder: SocketEventBinder | None = None

    # ----- public -----

    @property
    def bot_id(self) -> str:
        return self._bot_id

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def context(self) -> GatewayContext | None:
        return self._ctx

    async def start(self) -> None:
        """Fetch identity and connect."""
        self._stopping = False
        await self._fetch_bot_id()
        self._ctx = build_gateway_context(self._account_id, self._bot_id, self._config)
        await self._connect()

    async def stop(self) -> None:
        """Gracefully disconnect."""
        self._stopping = True

        # Stop heartbeat
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

        # Stop queue processor
        if self._queue_task and not self._queue_task.done():
            self._queue_task.cancel()
            self._queue_task = None

        # Unregister from socket registry
        registry = get_socket_registry()
        registry.unregister(self._account_id)

        if self._sio:
            with contextlib.suppress(Exception):
                await self._sio.disconnect()
            self._sio = None
        self._connected = False

    async def send(self, msg: PrivateMessageData) -> None:
        """Send a message through the WebSocket connection.

        If disconnected, buffer via socket registry for flush on reconnect.
        """
        registry = get_socket_registry()
        entry = registry.get_socket(self._account_id)

        if entry:
            try:
                await entry.socket.emit(EVENT_MESSAGE_PRIVATE, msg.to_dict())
                return
            except Exception:
                logger.exception("Failed to emit via registry socket")

        # Try direct socket
        if self._sio and self._connected:
            try:
                await self._sio.emit(EVENT_MESSAGE_PRIVATE, msg.to_dict())
                return
            except Exception:
                logger.exception("Failed to emit message (account=%s)", self._account_id)

        # Buffer for later flush
        if registry.buffer_message(self._account_id, msg):
            logger.debug("Message buffered for reconnect (account=%s)", self._account_id)
        else:
            logger.warning("Cannot send — gateway not connected (account=%s)", self._account_id)

    # ----- identity -----

    async def _fetch_bot_id(self) -> None:
        """GET /user/current to obtain the bot's client ID."""
        url = f"{self._base_url}{ENDPOINT_USER_CURRENT}"
        try:
            async with aiohttp.ClientSession(headers=self._headers) as sess, sess.get(url) as resp:
                if resp.status != 200:
                    raise RuntimeError(f"HTTP {resp.status}")
                body = await resp.json()
                extra_raw = (body.get("data") or {}).get("client", {}).get("extra", "")
                # extra may be a JSON string (from mock server) or a dict
                if isinstance(extra_raw, str) and extra_raw:
                    try:
                        extra = json.loads(extra_raw)
                    except (json.JSONDecodeError, TypeError):
                        extra = {}
                elif isinstance(extra_raw, dict):
                    extra = extra_raw
                else:
                    extra = {}
                self._bot_id = extra.get("botId", "")
                if not self._bot_id:
                    raise RuntimeError("botId not found in /user/current response")
                logger.info(
                        "LightClaw bot identity: %s (account=%s)",
                        self._bot_id,
                        self._account_id,
                    )
        except Exception:
            logger.exception("Failed to fetch bot identity (account=%s)", self._account_id)
            raise

    # ----- socket lifecycle -----

    async def _connect(self) -> None:
        """Create Socket.IO client and connect."""
        sio = socketio.AsyncClient(
            reconnection=True,
            reconnection_delay=RECONNECT_DELAY_INITIAL,
            reconnection_delay_max=RECONNECT_DELAY_MAX,
            reconnection_attempts=0,  # unlimited
            logger=False,
            engineio_logger=False,
        )
        self._sio = sio

        registry = get_socket_registry()

        @sio.event
        async def connect():
            self._connected = True
            logger.info(
                "Socket.IO connected (account=%s, bot=%s)",
                self._account_id, self._bot_id,
            )

            # Register in socket registry
            registry.register(self._account_id, sio, self._bot_id)

            # Flush any pending messages
            result = await registry.flush_pending(self._account_id)
            if result["sent"] or result["failed"]:
                logger.info(
                    "Flushed pending: sent=%d failed=%d",
                    result["sent"], result["failed"],
                )

            # Start message queue processor
            if self._queue_task is None or self._queue_task.done():
                self._queue_task = asyncio.create_task(self._process_queue())

            # Start heartbeat
            if self._heartbeat_task is None or self._heartbeat_task.done():
                self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

        @sio.event
        async def disconnect():
            self._connected = False
            if not self._stopping:
                logger.warning(
                    "Socket.IO disconnected (account=%s), will reconnect…",
                    self._account_id,
                )

        # Bind event handlers (message:private, history, sessions)
        self._event_binder = SocketEventBinder(SocketHandlerDeps(
            account_id=self._account_id,
            bot_client_id=self._bot_id,
            enqueue_message=self._enqueue_message,
            gateway_context=self._ctx,
        ))
        self._event_binder.bind(sio)

        try:
            await sio.connect(
                self._ws_url,
                socketio_path=SOCKET_PATH,
                transports=["websocket"],
                auth={
                    "authorization": f"Bearer {self._config.api_key}",
                    "x-product": X_PRODUCT,
                },
                wait_timeout=30,
            )
        except Exception:
            logger.exception("Socket.IO connect failed (account=%s)", self._account_id)
            raise

    # ----- message queue -----

    async def _enqueue_message(
        self,
        msg: PrivateMessageData,
        ctx: GatewayContext,
    ) -> None:
        """Enqueue an inbound message for ordered processing."""
        if len(self._queue) >= MAX_QUEUE_SIZE:
            logger.warning(
                "Message queue full (account=%s), dropping oldest",
                self._account_id,
            )

        queued = QueuedMessage(
            sender_id=msg.from_id,
            text=msg.content or "",
            message_id=msg.msg_id,
            files=msg.files,
            timestamp=msg.timestamp,
            raw=msg,
        )
        self._queue.append(queued)

    async def _process_queue(self) -> None:
        """Poll-based async queue processor (200ms interval)."""
        while not self._stopping:
            if self._queue:
                item = self._queue.popleft()
                try:
                    await self._on_message(item.raw, self._ctx)
                except Exception:
                    logger.exception(
                        "Error processing queued message %s",
                        item.message_id,
                    )
            else:
                await asyncio.sleep(QUEUE_POLL_INTERVAL)

    # ----- health heartbeat -----

    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeat to keep connection alive (20min interval)."""
        while not self._stopping:
            await asyncio.sleep(HEARTBEAT_INTERVAL)
            if self._sio and self._connected:
                try:
                    # python-socketio handles ping/pong internally;
                    # this is an application-level keepalive
                    logger.debug(
                        "Heartbeat: gateway alive (account=%s, connected=%s)",
                        self._account_id, self._connected,
                    )
                except Exception:
                    logger.debug("Heartbeat error", exc_info=True)
