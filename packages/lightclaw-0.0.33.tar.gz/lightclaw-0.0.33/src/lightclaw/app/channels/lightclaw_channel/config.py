"""LightClaw channel configuration constants and helpers."""

from __future__ import annotations

import logging
import os
from typing import Any

from .types import GatewayContext, LightClawAccountConfig

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Server defaults
# ---------------------------------------------------------------------------

DEFAULT_WS_URL = "wss://lightai.intl.cloud.tencent.com"
DEFAULT_API_BASE = "https://lightai.intl.cloud.tencent.com"
SOCKET_PATH = "/claw-socket"

# HTTP endpoints
ENDPOINT_USER_CURRENT = "/user/current"
ENDPOINT_COS_UPLOAD = "/cosmanager/uploadFile"
ENDPOINT_COS_DOWNLOAD = "/cosmanager/getFileStream"

# Socket.IO event names
EVENT_MESSAGE_PRIVATE = "message:private"
EVENT_HISTORY_REQUEST = "message:history:request"
EVENT_HISTORY_RESPONSE = "message:history:response"
EVENT_SESSIONS_REQUEST = "sessions:request"
EVENT_SESSIONS_RESPONSE = "sessions:response"

# Reconnect parameters
RECONNECT_DELAY_INITIAL = 1.0  # seconds
RECONNECT_DELAY_MAX = 30.0
RECONNECT_ATTEMPTS = 0  # unlimited

# Product header
X_PRODUCT = "channel"

# ---------------------------------------------------------------------------
# Configuration parsing
# ---------------------------------------------------------------------------


def parse_channel_config(raw: dict[str, Any]) -> tuple[
    LightClawAccountConfig,
    list[tuple[str, LightClawAccountConfig]],
]:
    """Parse channel config dict into (primary, extra_accounts).

    Expected JSON shape (in ``lightclaw.json``):
    ```json
    {
      "channels": {
        "lightclawbot": {
          "enabled": true,
          "apiKeys": ["YOUR_API_KEY_HERE"],
          "apiBaseUrl": "",
          "name": "my-bot",
          "dmPolicy": "open",
          "allowFrom": ["*"],
          "systemPrompt": "",
          "accounts": {
            "another-bot": { "apiKeys": ["..."], ... }
          }
        }
      }
    }
    ```

    Legacy ``lightclaw`` / ``apiKey`` payloads are still accepted.
    """
    primary = _dict_to_account(raw)
    extras: list[tuple[str, LightClawAccountConfig]] = []
    for acct_name, acct_raw in (raw.get("accounts") or {}).items():
        if isinstance(acct_raw, dict):
            acct = _dict_to_account(acct_raw)
            acct.name = acct.name or acct_name
            extras.append((acct_name, acct))
    return primary, extras


def _dict_to_account(d: dict[str, Any]) -> LightClawAccountConfig:
    raw_api_keys = d.get("apiKeys") or []
    api_keys = [key for key in raw_api_keys if isinstance(key, str) and key.strip()]
    primary_key = api_keys[0] if api_keys else d.get("apiKey", "")
    return LightClawAccountConfig(
        api_key=primary_key or os.environ.get("LIGHTCLAW_API_KEY", ""),
        api_base_url=d.get("apiBaseUrl", "")
        or os.environ.get("LIGHTCLAW_API_BASE_URL", ""),
        enabled=d.get("enabled", True),
        name=d.get("name", ""),
        dm_policy=d.get("dmPolicy", "open"),
        allow_from=d.get("allowFrom", ["*"]),
        system_prompt=d.get("systemPrompt", ""),
    )


def build_auth_headers(api_key: str) -> dict[str, str]:
    """Build HTTP/WS authentication headers."""
    return {
        "Authorization": f"Bearer {api_key}",
        "x-product": X_PRODUCT,
    }


def build_gateway_context(
    account_id: str,
    bot_id: str,
    cfg: LightClawAccountConfig,
) -> GatewayContext:
    return GatewayContext(
        account_id=account_id,
        bot_id=bot_id,
        api_key=cfg.api_key,
        api_base_url=cfg.api_base_url,
        dm_policy=cfg.dm_policy,
        allow_from=cfg.allow_from,
    )
