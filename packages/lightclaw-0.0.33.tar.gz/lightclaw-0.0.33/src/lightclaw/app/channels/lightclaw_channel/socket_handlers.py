"""Socket.IO event handlers — decoupled from gateway main logic.

Python port of socket-handlers.ts:
  - ``message:private``           → filter, dedup, enqueue
  - ``message:history:request``   → read session history, respond
  - ``sessions:request``          → list sessions, respond

CoPaw uses its own history/session storage (via runner.manager), so the
history handler reads from the local session transcript files.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config import (
    EVENT_HISTORY_REQUEST,
    EVENT_HISTORY_RESPONSE,
    EVENT_MESSAGE_PRIVATE,
    EVENT_SESSIONS_REQUEST,
    EVENT_SESSIONS_RESPONSE,
)
from .dedup import DedupSet, Throttle, generate_msg_id
from .types import GatewayContext, PrivateMessageData

logger = logging.getLogger(__name__)

# Default history limit (matches TypeScript DEFAULT_HISTORY_LIMIT)
DEFAULT_HISTORY_LIMIT = 100

# Throttle: same user can only request history once per N seconds
HISTORY_THROTTLE_SECONDS = 2.0


@dataclass
class SocketHandlerDeps:
    """Dependencies injected by the gateway."""

    account_id: str
    bot_client_id: str
    enqueue_message: Callable[[PrivateMessageData, GatewayContext], Coroutine[Any, Any, None]]
    gateway_context: GatewayContext
    on_event: Callable[[], None] | None = None
    session_dir: Path | None = None  # for history reading


class SocketEventBinder:
    """Binds all Socket.IO event listeners to a socket instance.

    Equivalent to ``bindSocketHandlers()`` in TypeScript.
    """

    def __init__(self, deps: SocketHandlerDeps):
        self._deps = deps
        self._dedup = DedupSet(ttl_seconds=120)
        self._history_throttle = Throttle(cooldown=HISTORY_THROTTLE_SECONDS)

    def bind(self, sio: Any) -> None:
        """Attach all event listeners to *sio* (``socketio.AsyncClient``)."""
        @sio.on(EVENT_MESSAGE_PRIVATE)
        async def on_private_message(data: dict[str, Any]) -> None:
            await self._handle_private_message(data)

        @sio.on(EVENT_HISTORY_REQUEST)
        async def on_history_request(data: dict[str, Any]) -> None:
            await self._handle_history_request(sio, data)

        @sio.on(EVENT_SESSIONS_REQUEST)
        async def on_sessions_request(data: dict[str, Any]) -> None:
            await self._handle_sessions_request(sio, data)

    # ---- message:private ----

    async def _handle_private_message(self, raw: dict[str, Any]) -> None:
        deps = self._deps
        msg = PrivateMessageData.from_dict(raw)

        # Loop-back guard
        if msg.from_id == deps.bot_client_id:
            return

        # Skip control kinds (only process real text messages)
        if msg.kind and msg.kind not in ("text", ""):
            return

        # No content
        has_content = bool(msg.content and msg.content.strip())
        has_files = bool(msg.files)
        if not has_content and not has_files:
            return

        # Dedup
        if msg.msg_id and self._dedup.add(msg.msg_id):
            return

        # Notify framework (update lastEventAt)
        if deps.on_event:
            deps.on_event()

        logger.info(
            "[lightclaw] Message from %s: \"%s\" files=%d",
            msg.from_id,
            (msg.content or "")[:60],
            len(msg.files),
        )

        await deps.enqueue_message(msg, deps.gateway_context)

    # ---- message:history:request ----

    async def _handle_history_request(
        self, sio: Any, data: dict[str, Any],
    ) -> None:
        deps = self._deps
        from_id = data.get("from", "")
        if not from_id:
            logger.warning("[lightclaw] History request missing userId")
            return

        # Loop-back guard
        if from_id == deps.bot_client_id:
            return

        # Dedup on msgId
        msg_id = data.get("msgId")
        if msg_id and self._dedup.add(msg_id):
            logger.debug("Duplicate history request (msgId), ignoring")
            return

        # Per-user throttle
        if not self._history_throttle.allow(from_id):
            logger.debug("Throttled history request from %s", from_id)
            return

        # Notify framework
        if deps.on_event:
            deps.on_event()

        limit = data.get("limit", DEFAULT_HISTORY_LIMIT)
        chat_only = data.get("chatOnly", True)

        try:
            messages = self._read_session_history(from_id, limit, chat_only)
            session_key = f"lightclaw:dm:{from_id}"

            logger.info(
                "[lightclaw] History request: userId=%s found=%d",
                from_id, len(messages),
            )

            await sio.emit(EVENT_HISTORY_RESPONSE, {
                "msgId": generate_msg_id(),
                "from": deps.bot_client_id,
                "to": from_id,
                "sessionKey": session_key,
                "messages": messages,
            })
        except Exception as exc:
            logger.exception("History request error")
            await sio.emit(EVENT_HISTORY_RESPONSE, {
                "msgId": generate_msg_id(),
                "from": deps.bot_client_id,
                "to": from_id,
                "sessionKey": "",
                "messages": [],
                "error": str(exc),
            })

    # ---- sessions:request ----

    async def _handle_sessions_request(
        self, sio: Any, data: dict[str, Any],
    ) -> None:
        if self._deps.on_event:
            self._deps.on_event()

        request_id = data.get("requestId")

        try:
            sessions = self._list_sessions()
            await sio.emit(EVENT_SESSIONS_RESPONSE, {
                "requestId": request_id,
                "sessions": sessions,
            })
        except Exception as exc:
            logger.exception("Sessions list error")
            await sio.emit(EVENT_SESSIONS_RESPONSE, {
                "requestId": request_id,
                "sessions": [],
                "error": str(exc),
            })

    # ---- history helpers (read from CoPaw session transcripts) ----

    def _read_session_history(
        self,
        user_id: str,
        limit: int,
        chat_only: bool,
    ) -> list[dict[str, Any]]:
        """Read session history from local JSONL transcript files.

        CoPaw stores transcripts in ``~/.lightclaw/sessions/<session_id>/transcript.jsonl``.
        Falls back to empty list if files don't exist.
        """
        import json

        session_dir = self._deps.session_dir
        if not session_dir:
            # Try default CoPaw session dir
            home = Path.home() / ".lightclaw" / "sessions"
            if not home.exists():
                return []
            session_dir = home

        session_key = f"lightclaw:dm:{user_id}"

        # Look for matching session directory
        messages: list[dict[str, Any]] = []
        for sdir in session_dir.iterdir():
            if not sdir.is_dir():
                continue
            transcript = sdir / "transcript.jsonl"
            if not transcript.exists():
                continue

            # Check if this session belongs to the user
            meta_file = sdir / "session.json"
            if meta_file.exists():
                try:
                    meta = json.loads(meta_file.read_text())
                    if meta.get("session_key") != session_key and \
                       meta.get("session_id") != session_key:
                        continue
                except Exception:
                    continue
            else:
                # Fallback: check directory name
                if session_key.replace(":", "_") not in sdir.name:
                    continue

            # Parse JSONL
            try:
                for line in transcript.read_text().splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                        msg = entry.get("message", entry)
                        role = msg.get("role", "")
                        content = msg.get("content", "")

                        if chat_only and role not in ("user", "assistant"):
                            continue
                        if not content or not content.strip():
                            continue

                        messages.append({
                            "role": role,
                            "content": content,
                            "timestamp": msg.get("timestamp") or entry.get("timestamp"),
                        })
                    except (json.JSONDecodeError, TypeError):
                        continue
            except Exception:
                continue

        # Return last N messages
        if len(messages) > limit:
            messages = messages[-limit:]
        return messages

    def _list_sessions(self) -> list[dict[str, Any]]:
        """List all known sessions."""
        import json

        session_dir = self._deps.session_dir
        if not session_dir:
            home = Path.home() / ".lightclaw" / "sessions"
            if not home.exists():
                return []
            session_dir = home

        sessions: list[dict[str, Any]] = []
        for sdir in session_dir.iterdir():
            if not sdir.is_dir():
                continue
            meta_file = sdir / "session.json"
            if not meta_file.exists():
                continue
            try:
                meta = json.loads(meta_file.read_text())
                sessions.append({
                    "sessionKey": meta.get("session_key", sdir.name),
                    "sessionId": meta.get("session_id", sdir.name),
                    "updatedAt": meta.get("updated_at"),
                    "label": meta.get("label", ""),
                    "channel": meta.get("channel", "lightclaw"),
                })
            except Exception:
                continue

        sessions.sort(key=lambda s: s.get("updatedAt") or 0, reverse=True)
        return sessions
