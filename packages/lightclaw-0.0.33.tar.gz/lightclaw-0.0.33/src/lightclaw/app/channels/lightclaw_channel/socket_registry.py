"""Socket registry — manages Socket.IO instances and disconnect buffering.

Python port of socket-registry.ts:
  - Let gateway register socket instances on connect
  - Outbound can send via WS directly (avoiding REST fallback)
  - Buffer outbound messages during transient disconnections (max 200)
  - Flush buffered messages on reconnect
  - Only delete entry on cleanup (not transient disconnect)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from .config import EVENT_MESSAGE_PRIVATE
from .types import PrivateMessageData

logger = logging.getLogger(__name__)

MAX_PENDING_MESSAGES = 200


@dataclass
class SocketEntry:
    """One entry per accountId in the registry."""

    socket: Any  # socketio.AsyncClient
    bot_client_id: str
    pending_messages: list[PrivateMessageData] = field(default_factory=list)


class SocketRegistry:
    """Global socket registry (singleton per process)."""

    def __init__(self) -> None:
        self._entries: dict[str, SocketEntry] = {}

    # ---- register / unregister ----

    def register(
        self,
        account_id: str,
        socket: Any,
        bot_client_id: str,
    ) -> None:
        """Register (or update on reconnect) a socket for *account_id*."""
        existing = self._entries.get(account_id)
        if existing:
            # Reconnect: update socket ref, keep pending queue
            existing.socket = socket
            existing.bot_client_id = bot_client_id
        else:
            self._entries[account_id] = SocketEntry(
                socket=socket,
                bot_client_id=bot_client_id,
            )

    def unregister(self, account_id: str) -> None:
        """Remove entry entirely — only on gateway cleanup, NOT on transient disconnect."""
        self._entries.pop(account_id, None)

    # ---- query ----

    def get_socket(self, account_id: str) -> SocketEntry | None:
        """Return the entry only if the socket is connected."""
        entry = self._entries.get(account_id)
        if entry and entry.socket and getattr(entry.socket, "connected", False):
            return entry
        return None

    def has_entry(self, account_id: str) -> bool:
        return account_id in self._entries

    def get_bot_client_id(self, account_id: str) -> str | None:
        entry = self._entries.get(account_id)
        return entry.bot_client_id if entry else None

    # ---- disconnect buffering ----

    def buffer_message(
        self,
        account_id: str,
        message: PrivateMessageData,
    ) -> bool:
        """Buffer a message while socket is disconnected.

        Returns True if buffered, False if no entry exists for this account.
        """
        entry = self._entries.get(account_id)
        if not entry:
            return False

        if len(entry.pending_messages) >= MAX_PENDING_MESSAGES:
            entry.pending_messages.pop(0)  # drop oldest
        entry.pending_messages.append(message)
        return True

    async def flush_pending(self, account_id: str) -> dict[str, int]:
        """Flush all buffered messages on reconnect.

        Returns ``{"sent": N, "failed": N}``.
        """
        entry = self._entries.get(account_id)
        if not entry:
            return {"sent": 0, "failed": 0}

        pending = list(entry.pending_messages)
        entry.pending_messages.clear()

        if not pending:
            return {"sent": 0, "failed": 0}

        sent = 0
        failed = 0

        for i, msg in enumerate(pending):
            if not getattr(entry.socket, "connected", False):
                # Socket disconnected mid-flush — put remaining back
                entry.pending_messages = pending[i:] + entry.pending_messages
                break
            try:
                await entry.socket.emit(EVENT_MESSAGE_PRIVATE, msg.to_dict())
                sent += 1
            except Exception:
                failed += 1
                logger.warning(
                    "Failed to flush buffered message: msgId=%s", msg.msg_id,
                )

        if sent or failed:
            logger.info(
                "Flushed pending messages (account=%s): sent=%d, failed=%d",
                account_id, sent, failed,
            )

        return {"sent": sent, "failed": failed}

    def get_pending_count(self, account_id: str) -> int:
        entry = self._entries.get(account_id)
        return len(entry.pending_messages) if entry else 0


# Module-level singleton
_registry = SocketRegistry()


def get_socket_registry() -> SocketRegistry:
    """Get the module-level singleton registry."""
    return _registry
