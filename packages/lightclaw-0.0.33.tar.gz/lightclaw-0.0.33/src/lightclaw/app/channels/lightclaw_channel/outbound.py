"""Outbound message delivery — sends CoPaw responses back to LightClaw users.

Python port of outbound.ts: builds PrivateMessageData from rendered text and
emits via the gateway's Socket.IO connection.

Enhanced with socket registry integration:
  - Priority 1: Connected socket from registry
  - Priority 2: Buffer in registry (during transient disconnect)
  - Priority 3: REST API fallback
"""

from __future__ import annotations

import logging
import time
from typing import Any

import aiohttp

from .config import build_auth_headers
from .dedup import generate_msg_id
from .socket_registry import get_socket_registry
from .types import FileAttachment, MessageKind, PrivateMessageData

logger = logging.getLogger(__name__)


class OutboundSender:
    """Send messages from bot to a LightClaw user.

    Three-tier delivery:
      1. Connected socket from registry → direct emit
      2. Registry entry exists but disconnected → buffer for flush on reconnect
      3. No registry entry → REST API fallback
    """

    def __init__(self, gateway: Any):  # gateway: LightClawGateway (avoid circular)
        self._gw = gateway

    async def send_text(
        self,
        to_id: str,
        text: str,
        *,
        reply_to: str | None = None,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send a plain text message to *to_id*."""
        msg = PrivateMessageData(
            msg_id=generate_msg_id(),
            from_id=self._gw.bot_id,
            to_id=to_id,
            content=text,
            timestamp=int(time.time() * 1000),
            kind=MessageKind.TEXT.value,
            reply_to_msg_id=reply_to,
        )
        await self._deliver(msg)

    async def send_media(
        self,
        to_id: str,
        url: str,
        *,
        filename: str = "",
        mime_type: str = "",
        caption: str = "",
        reply_to: str | None = None,
    ) -> None:
        """Send a media file (image, video, audio, generic file)."""
        att = FileAttachment(
            name=filename or "file",
            mime_type=mime_type,
            uri=url,
        )
        text = caption or ""
        msg = PrivateMessageData(
            msg_id=generate_msg_id(),
            from_id=self._gw.bot_id,
            to_id=to_id,
            content=text,
            timestamp=int(time.time() * 1000),
            files=[att],
            kind=MessageKind.TEXT.value,
            reply_to_msg_id=reply_to,
        )
        await self._deliver(msg)

    async def send_typing(self, to_id: str, start: bool = True) -> None:
        """Send a typing indicator."""
        msg = PrivateMessageData(
            msg_id=generate_msg_id(),
            from_id=self._gw.bot_id,
            to_id=to_id,
            content="",
            timestamp=int(time.time() * 1000),
            kind=MessageKind.TYPING_START.value if start else MessageKind.TYPING_STOP.value,
        )
        # Typing indicators: try socket only, don't buffer or REST
        if self._gw.connected:
            await self._gw.send(msg)

    # ----- three-tier delivery -----

    async def _deliver(self, msg: PrivateMessageData) -> None:
        """Deliver via socket (with registry buffering) → REST fallback."""
        # Tier 1 & 2: handled by gateway.send() which uses registry
        if self._gw.connected or get_socket_registry().has_entry(self._gw._account_id):
            await self._gw.send(msg)
            return

        # Tier 3: REST fallback
        await self._send_via_rest(msg)

    async def _send_via_rest(self, msg: PrivateMessageData) -> None:
        """Fallback: POST to REST API when WebSocket is unavailable."""
        cfg = self._gw._config
        base_url = (cfg.api_base_url or "").rstrip("/")
        if not base_url:
            logger.warning("REST fallback unavailable — no apiBaseUrl configured")
            return

        headers = build_auth_headers(cfg.api_key)
        endpoint = "/send-media" if msg.files else "/send"
        url = f"{base_url}{endpoint}"

        try:
            async with aiohttp.ClientSession(headers=headers) as sess, sess.post(url, json=msg.to_dict()) as resp:
                if resp.status != 200:
                    body = await resp.text()
                    logger.error("REST send failed %s: %s", resp.status, body)
                else:
                    logger.debug("Message sent via REST fallback to %s", msg.to_id)
        except Exception:
            logger.exception("REST fallback send error")
