"""LangChain agent tools for LightClaw file operations.

Python port of upload-tool.ts and download-tool.ts:
  - ``lightclaw_upload_file``  — upload 1-5 local files to COS, return public URLs
  - ``lightclaw_get_file_url`` — get download URL / download / upload-and-get-url

These are registered as LangChain tools and injected into the agent's toolset
when the LightClaw channel is active.
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path

from langchain_core.tools import tool

logger = logging.getLogger(__name__)


def _get_file_storage():
    """Lazy import to avoid circular deps; returns a FileStorage or None."""
    try:
        from .file_storage import FileStorage
        api_key = os.environ.get("LIGHTCLAW_API_KEY", "")
        api_base = os.environ.get("LIGHTCLAW_API_BASE_URL", "")
        if not api_key:
            return None
        return FileStorage(api_key, api_base)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# lightclaw_upload_file
# ---------------------------------------------------------------------------


@tool
async def lightclaw_upload_file(paths: list[str]) -> str:
    """Upload 1-5 local files to LightClaw COS storage and return public URLs.

    Args:
        paths: List of local file paths to upload (1-5 files).

    Returns:
        A summary of upload results with public URLs for each file.
    """
    if not paths:
        return "Error: no file paths provided."
    if len(paths) > 5:
        return "Error: maximum 5 files per upload."

    # Validate all paths exist
    missing = [p for p in paths if not Path(p).is_file()]
    if missing:
        return f"Error: files not found: {', '.join(missing)}"

    storage = _get_file_storage()
    if not storage:
        return "Error: LightClaw file storage not configured (LIGHTCLAW_API_KEY missing)."

    results: list[str] = []

    # Upload concurrently in batches of 3
    sem = asyncio.Semaphore(3)

    async def _upload_one(path: str) -> str:
        async with sem:
            try:
                url = await storage.upload_and_get_url(path)
                return f"✓ {Path(path).name} → {url}"
            except Exception as exc:
                return f"✗ {Path(path).name}: {exc}"

    tasks = [_upload_one(p) for p in paths]
    results = await asyncio.gather(*tasks)

    await storage.close()
    return "\n".join(results)


# ---------------------------------------------------------------------------
# lightclaw_get_file_url
# ---------------------------------------------------------------------------


@tool
async def lightclaw_get_file_url(
    action: str,
    file_path: str,
    local_dir: str | None = None,
) -> str:
    """Get, download, or re-upload a file from LightClaw COS storage.

    Args:
        action: One of "get_url" (get public URL), "download_to_local" (download
                file to local directory), or "upload_and_get_url" (upload a local
                file and return its public URL).
        file_path: COS file path (for get_url/download) or local path (for upload).
        local_dir: Local directory to save downloaded file (only for download_to_local).

    Returns:
        The resulting URL or local file path.
    """
    storage = _get_file_storage()
    if not storage:
        return "Error: LightClaw file storage not configured (LIGHTCLAW_API_KEY missing)."

    try:
        if action == "get_url":
            url = storage.get_download_url(file_path)
            return f"Public URL: {url}"

        elif action == "download_to_local":
            save_dir = local_dir or os.getcwd()
            data, filename, _ = await storage.download(file_path)
            local_path = Path(save_dir) / (filename or Path(file_path).name)
            local_path.parent.mkdir(parents=True, exist_ok=True)
            local_path.write_bytes(data)
            return f"Downloaded to: {local_path}"

        elif action == "upload_and_get_url":
            if not Path(file_path).is_file():
                return f"Error: file not found: {file_path}"
            url = await storage.upload_and_get_url(file_path)
            return f"Public URL: {url}"

        else:
            return f"Error: unknown action '{action}'. Use get_url, download_to_local, or upload_and_get_url."
    except Exception as exc:
        return f"Error: {exc}"
    finally:
        await storage.close()


def get_lightclaw_tools() -> list:
    """Return all LightClaw agent tools for registration."""
    return [lightclaw_upload_file, lightclaw_get_file_url]
