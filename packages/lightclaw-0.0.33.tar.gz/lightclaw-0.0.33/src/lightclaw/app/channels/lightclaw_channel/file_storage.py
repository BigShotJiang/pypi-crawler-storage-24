"""COS file upload / download via LightClaw HTTP API — Python port of file-storage.ts."""

from __future__ import annotations

import io
import logging
import mimetypes

import aiohttp

from .config import (
    DEFAULT_API_BASE,
    ENDPOINT_COS_DOWNLOAD,
    ENDPOINT_COS_UPLOAD,
    build_auth_headers,
)

logger = logging.getLogger(__name__)


class FileStorage:
    """Async COS file operations through the LightClaw gateway API."""

    def __init__(self, api_key: str, base_url: str = ""):
        self._api_key = api_key
        self._base = (base_url or DEFAULT_API_BASE).rstrip("/")
        self._headers = build_auth_headers(api_key)
        self._session: aiohttp.ClientSession | None = None

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers=self._headers,
                timeout=aiohttp.ClientTimeout(total=120),
            )
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None

    # ----- upload -----

    async def upload_file(
        self,
        data: bytes,
        filename: str,
        mime_type: str = "",
    ) -> str | None:
        """Upload *data* to COS. Returns the COS file path on success."""
        if not mime_type:
            mime_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

        session = await self._ensure_session()
        url = f"{self._base}{ENDPOINT_COS_UPLOAD}"

        form = aiohttp.FormData()
        form.add_field(
            "file",
            io.BytesIO(data),
            filename=filename,
            content_type=mime_type,
        )

        try:
            async with session.post(url, data=form) as resp:
                if resp.status != 200:
                    body = await resp.text()
                    logger.error("COS upload failed %s: %s", resp.status, body)
                    return None
                result = await resp.json()
                # Server returns { data: { filePath: "..." } }
                file_path = (result.get("data") or {}).get("filePath", "")
                if file_path:
                    logger.debug("Uploaded %s -> %s", filename, file_path)
                return file_path or None
        except Exception:
            logger.exception("COS upload error for %s", filename)
            return None

    # ----- download -----

    async def download_file(self, file_path: str) -> tuple[bytes, str] | None:
        """Download a file from COS. Returns ``(data, content_type)``."""
        session = await self._ensure_session()
        url = f"{self._base}{ENDPOINT_COS_DOWNLOAD}"

        try:
            async with session.get(url, params={"filePath": file_path}) as resp:
                if resp.status != 200:
                    logger.error("COS download failed %s for %s", resp.status, file_path)
                    return None
                ct = resp.content_type or "application/octet-stream"
                data = await resp.read()
                return data, ct
        except Exception:
            logger.exception("COS download error for %s", file_path)
            return None

    # ----- convenience -----

    async def upload_and_get_url(self, local_path: str) -> str:
        """Upload a local file and return its public download URL."""

        path_obj = __import__("pathlib").Path(local_path)
        if not path_obj.is_file():
            raise FileNotFoundError(f"File not found: {local_path}")

        data = path_obj.read_bytes()
        filename = path_obj.name
        file_path = await self.upload_file(data, filename)
        if not file_path:
            raise RuntimeError(f"Upload failed for {filename}")
        return self.get_download_url(file_path)

    def get_download_url(self, cos_file_path: str) -> str:
        """Construct the public download URL for a COS file path."""
        import urllib.parse

        encoded = urllib.parse.quote(cos_file_path, safe="")
        return f"{self._base}{ENDPOINT_COS_DOWNLOAD}?filePath={encoded}"

    async def download(self, cos_file_path: str) -> tuple[bytes, str, str]:
        """Download a file. Returns ``(data, filename, content_type)``."""
        result = await self.download_file(cos_file_path)
        if result is None:
            raise RuntimeError(f"Download failed for {cos_file_path}")
        data, ct = result
        # Extract filename from path
        filename = cos_file_path.rsplit("/", 1)[-1] if "/" in cos_file_path else cos_file_path
        return data, filename, ct

    # ----- data-URL helpers -----

    @staticmethod
    def parse_data_url(data_url: str) -> tuple[bytes, str] | None:
        """Parse a ``data:mime;base64,...`` URL into (bytes, mime)."""
        import base64

        if not data_url.startswith("data:"):
            return None
        try:
            header, encoded = data_url.split(",", 1)
            mime = header.split(":")[1].split(";")[0]
            raw = base64.b64decode(encoded)
            return raw, mime
        except Exception:
            logger.debug("Invalid data URL (truncated: %s...)", data_url[:60])
            return None
