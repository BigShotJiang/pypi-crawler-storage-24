"""Type definitions for LightClaw channel — mirrors the TypeScript plugin types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

# ---------------------------------------------------------------------------
# Socket.IO message protocol
# ---------------------------------------------------------------------------


class MessageKind(str, Enum):
    """Message kind — controls how the client renders the message."""

    TEXT = "text"
    STREAM_CHUNK = "stream_chunk"
    STREAM_END = "stream_end"
    TYPING_START = "typing_start"
    TYPING_STOP = "typing_stop"


@dataclass
class FileAttachment:
    """File attachment carried inside a PrivateMessageData payload."""

    name: str = ""
    mime_type: str = ""
    # data-URL encoded bytes (inbound only, small files)
    bytes: str | None = None
    # COS URI (preferred for large files)
    uri: str | None = None


@dataclass
class PrivateMessageData:
    """Core message payload exchanged over ``message:private``."""

    msg_id: str = ""
    from_id: str = ""
    to_id: str = ""
    content: str = ""
    timestamp: int = 0
    files: list[FileAttachment] = field(default_factory=list)
    kind: str = MessageKind.TEXT.value
    reply_to_msg_id: str | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PrivateMessageData:
        """Create from a raw dict received over Socket.IO."""
        files_raw = d.get("files") or []
        files = [
            FileAttachment(
                name=f.get("name", ""),
                mime_type=f.get("mimeType", ""),
                bytes=f.get("bytes"),
                uri=f.get("uri"),
            )
            for f in files_raw
        ]
        return cls(
            msg_id=d.get("msgId", ""),
            from_id=d.get("from", ""),
            to_id=d.get("to", ""),
            content=d.get("content", ""),
            timestamp=d.get("timestamp", 0),
            files=files,
            kind=d.get("kind", MessageKind.TEXT.value),
            reply_to_msg_id=d.get("replyToMsgId"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to the wire format expected by LightClaw server."""
        d: dict[str, Any] = {
            "msgId": self.msg_id,
            "from": self.from_id,
            "to": self.to_id,
            "content": self.content,
            "timestamp": self.timestamp,
            "kind": self.kind,
        }
        if self.files:
            d["files"] = [
                {
                    "name": f.name,
                    "mimeType": f.mime_type,
                    **({"bytes": f.bytes} if f.bytes else {}),
                    **({"uri": f.uri} if f.uri else {}),
                }
                for f in self.files
            ]
        if self.reply_to_msg_id:
            d["replyToMsgId"] = self.reply_to_msg_id
        return d


# ---------------------------------------------------------------------------
# Account / config types
# ---------------------------------------------------------------------------


@dataclass
class LightClawAccountConfig:
    """Configuration for a single LightClaw bot account."""

    api_key: str = ""
    api_base_url: str = ""
    enabled: bool = True
    name: str = ""
    dm_policy: str = "open"  # open | allowlist | disabled
    allow_from: list[str] = field(default_factory=lambda: ["*"])
    system_prompt: str = ""


@dataclass
class GatewayContext:
    """Runtime context passed into gateway / handler functions."""

    account_id: str = ""
    bot_id: str = ""
    api_key: str = ""
    api_base_url: str = ""
    dm_policy: str = "open"
    allow_from: list[str] = field(default_factory=lambda: ["*"])
