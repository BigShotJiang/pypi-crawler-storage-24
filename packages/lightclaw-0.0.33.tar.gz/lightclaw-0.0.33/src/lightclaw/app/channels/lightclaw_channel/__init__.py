"""LightClaw channel plugin for CoPaw.

Provides ``LightClawChannel`` — a ``BaseChannel`` subclass that connects to the
LightClaw IM platform via Socket.IO, bridging user conversations with CoPaw's
AI agent engine.

Usage (auto-discovered by CoPaw's channel registry):
  Place this package in ``~/.lightclaw/workspace/custom_channels/lightclaw_channel/``
  and ensure ``lightclaw.json`` contains:

  {
    "channels": {
      "lightclaw": {
        "enabled": true,
        "apiKey": "YOUR_API_KEY_HERE"
      }
    }
  }
"""

from .agent_tools import get_lightclaw_tools
from .channel import LightClawChannel
from .socket_registry import get_socket_registry

__all__ = ["LightClawChannel", "get_lightclaw_tools", "get_socket_registry"]
