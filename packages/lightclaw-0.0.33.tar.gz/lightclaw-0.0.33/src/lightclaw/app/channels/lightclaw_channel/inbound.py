"""Inbound message processing — converts LightClaw messages to AgentRequest.

Python port of inbound.ts:
  LightClaw PrivateMessageData → file processing → AgentRequest → CoPaw queue
"""

from __future__ import annotations

import logging
import mimetypes
from typing import Any

from .file_storage import FileStorage
from .types import FileAttachment, GatewayContext, PrivateMessageData

logger = logging.getLogger(__name__)


def _guess_content_type(filename: str, mime: str = "") -> str:
    """Determine the content category (image/video/audio/file)."""
    mt = mime or mimetypes.guess_type(filename)[0] or ""
    if mt.startswith("image/"):
        return "image"
    if mt.startswith("video/"):
        return "video"
    if mt.startswith("audio/"):
        return "audio"
    return "file"


async def process_attachments(
    files: list[FileAttachment],
    file_storage: FileStorage,
) -> list[dict[str, Any]]:
    """Process file attachments into CoPaw content parts.

    Each attachment may arrive as:
    - ``bytes`` (data-URL for small files) — decode, upload to COS, return URL
    - ``uri`` (existing COS path) — build download URL

    Returns a list of content-part dicts compatible with CoPaw's schema:
    ``{"type": "image", "image_url": "..."}`` or ``{"type": "file", ...}``
    """
    parts: list[dict[str, Any]] = []

    for att in files:
        url: str | None = None

        # Try data-URL first
        if att.bytes:
            parsed = FileStorage.parse_data_url(att.bytes)
            if parsed:
                raw_bytes, mime = parsed
                cos_path = await file_storage.upload_file(
                    raw_bytes,
                    att.name or "attachment",
                    mime,
                )
                if cos_path:
                    url = f"{file_storage._base}/cosmanager/getFileStream?filePath={cos_path}"

        # Fall back to existing COS URI
        if not url and att.uri:
            url = f"{file_storage._base}/cosmanager/getFileStream?filePath={att.uri}"

        if not url:
            logger.warning("Could not resolve URL for attachment: %s", att.name)
            continue

        kind = _guess_content_type(att.name, att.mime_type)
        if kind == "image":
            parts.append({"type": "image", "image_url": url})
        elif kind == "video":
            parts.append({"type": "video", "video_url": url})
        elif kind == "audio":
            parts.append({"type": "audio", "data": url, "format": "url"})
        else:
            parts.append({
                "type": "file",
                "file_url": url,
                "filename": att.name,
            })

    return parts


def build_native_payload(
    msg: PrivateMessageData,
    ctx: GatewayContext,
    content_parts: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build the native payload dict that BaseChannel expects for ``_enqueue``.

    The payload follows the same convention used by Discord/QQ channels:
    ``{sender_id, content_parts, meta}``
    """
    # Build content parts: text first, then attachments
    all_parts: list[dict[str, Any]] = []

    if msg.content.strip():
        all_parts.append({"type": "text", "text": msg.content})

    all_parts.extend(content_parts)

    return {
        "sender_id": msg.from_id,
        "content_parts": all_parts,
        "meta": {
            "channel": "lightclaw",
            "msg_id": msg.msg_id,
            "from_id": msg.from_id,
            "to_id": msg.to_id,
            "timestamp": msg.timestamp,
            "account_id": ctx.account_id,
            "bot_id": ctx.bot_id,
            "reply_to_msg_id": msg.reply_to_msg_id,
        },
    }
