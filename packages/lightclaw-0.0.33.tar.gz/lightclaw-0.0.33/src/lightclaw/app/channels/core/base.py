# pylint: disable=too-many-branches,too-many-statements,unused-argument
# pylint: disable=too-many-public-methods,unnecessary-pass
"""
Base Channel: bound to TurnRequest/TurnEvent, unified by process.
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC
from collections.abc import AsyncIterator, Callable
from typing import (
    Any,
)

from ...core.error_utils import extract_event_error_message
from ...schemas import (
    AudioContent,
    ContentType,
    FileContent,
    ImageContent,
    MessageType,
    RefusalContent,
    RunStatus,
    TextContent,
    VideoContent,
)
from ...turn_protocol import TurnEvent, TurnEventType, TurnInput, TurnRequest
from .renderer import MessageRenderer, RenderStyle
from .schema import ChannelType

# Optional callback to enqueue payload (set by manager)
EnqueueCallback = Callable[[Any], None] | None

# Called when a user-originated reply was sent (channel, user_id, session_id)
OnReplySent = Callable[[str, str, str], None] | None

logger = logging.getLogger(__name__)

# Event type alias — used in type annotations
Event = Any

# Internal message types: these types are part of agent internal execution details
# and should not be forwarded to users.
_INTERNAL_MESSAGE_TYPES: frozenset = frozenset(
    {
        MessageType.PLUGIN_CALL,
        MessageType.PLUGIN_CALL_OUTPUT,
        MessageType.FUNCTION_CALL,
        MessageType.FUNCTION_CALL_OUTPUT,
        MessageType.MCP_TOOL_CALL,
        MessageType.MCP_TOOL_CALL_OUTPUT,
        MessageType.MCP_APPROVAL_REQUEST,
        MessageType.MCP_APPROVAL_RESPONSE,
        MessageType.MCP_LIST_TOOLS,
        MessageType.COMPONENT_CALL,
        MessageType.COMPONENT_CALL_OUTPUT,
        MessageType.REASONING,
        MessageType.HEARTBEAT,
    }
)

# process: accepts TurnRequest, streams TurnEvent objects
ProcessHandler = Callable[[Any], AsyncIterator[Any]]

# Outgoing part = runtime content types (no dict[str, Any])
OutgoingContentPart = TextContent | ImageContent | VideoContent | AudioContent | FileContent | RefusalContent


class _TurnMsg:
    """Minimal message shim for renderer compatibility.

    Wraps TurnEvent content into a message-like object so that
    send_message_content / _message_to_content_parts can work
    without knowing about TurnEvent internals.
    """

    def __init__(self, msg_type: str, content: list, role: str = "assistant") -> None:
        self.object = "message"
        self.status = RunStatus.Completed
        self.type = msg_type
        self.content = content
        self.role = role


class BaseChannel(ABC):
    """Base for all channels. Queue lives in ChannelManager; channel defines
    how to consume via consume_one().
    """

    channel: ChannelType

    # If True, manager creates a queue and consumer loop for this channel.
    uses_manager_queue: bool = True

    def __init__(
        self,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ):
        self._process = process
        self._on_reply_sent = on_reply_sent
        self._show_tool_details = show_tool_details
        # Set by ChannelManager.start_all(); channel calls this to enqueue.
        self._enqueue: EnqueueCallback = None
        # Pluggable renderer; subclasses may replace or inject style.
        self._render_style = RenderStyle(show_tool_details=show_tool_details)
        self._renderer = MessageRenderer(self._render_style)
        # Optional shared aiohttp.ClientSession; subclasses create in start(),
        # close in stop().
        self._http: Any | None = None
        # Debounce: content from messages that had no text; merged when text
        # arrives. Key = session_id.
        self._pending_content_by_session: dict[str, list[Any]] = {}
        # Time debounce: merge native payloads within _debounce_seconds.
        # Set > 0 in subclass (e.g. 0.3). Key = get_debounce_key(payload).
        self._debounce_seconds: float = 0.0
        self._debounce_pending: dict[str, list[Any]] = {}
        self._debounce_timers: dict[str, asyncio.Task[None]] = {}

    def _is_native_payload(self, payload: Any) -> bool:
        """True if payload is a native dict that can be time-debounced."""
        return isinstance(payload, dict) and "content_parts" in payload

    def get_debounce_key(self, payload: Any) -> str:
        """
        Key for time debounce (same key = same conversation).
        Override for channel-specific keys (e.g. short conversation_id).
        """
        if isinstance(payload, dict):
            meta = payload.get("meta") or {}
            return payload.get("session_id") or meta.get("conversation_id") or payload.get("sender_id") or ""
        return getattr(payload, "session_id", "") or ""

    def merge_native_items(self, items: list[Any]) -> Any:
        """
        Merge multiple native payloads into one. Override for
        channel-specific merge (e.g. meta keys). Default: concat
        content_parts, merge meta (reply_future, reply_loop, etc.).
        """
        if not items:
            return None
        first = items[0] if isinstance(items[0], dict) else {}
        merged_parts: list[Any] = []
        merged_meta: dict[str, Any] = dict(first.get("meta") or {})
        for it in items:
            p = it if isinstance(it, dict) else {}
            merged_parts.extend(p.get("content_parts") or [])
            m = p.get("meta") or {}
            for k in (
                "reply_future",
                "reply_loop",
                "incoming_message",
                "conversation_id",
            ):
                if k in m:
                    merged_meta[k] = m[k]
        return {
            "channel_id": first.get("channel_id") or self.channel,
            "sender_id": first.get("sender_id") or "",
            "content_parts": merged_parts,
            "meta": merged_meta,
        }

    def merge_requests(self, requests: list[Any]) -> Any:
        """
        Merge multiple TurnRequest payloads (same session) into one.
        Used when manager drains same-session queue: concatenate
        inputs from all, keep first request's meta/session.
        Returns one request; None if requests empty.
        """
        if not requests:
            return None
        first = requests[0]
        if len(requests) == 1:
            return first
        all_inputs: list[TurnInput] = []
        for req in requests:
            inputs = getattr(req, "inputs", None) or []
            all_inputs.extend(inputs)
        if not all_inputs:
            return first
        if hasattr(first, "model_copy"):
            return first.model_copy(update={"inputs": all_inputs})
        first.inputs = all_inputs
        return first

    def _on_debounce_buffer_append(
        self,
        key: str,
        payload: Any,
        existing_items: list[Any],
    ) -> None:
        """
        Hook when appending to time-debounce buffer (existing_items
        non-empty). Override e.g. to unblock previous reply_future.
        """
        del key
        del payload
        del existing_items

    def _content_has_text(self, contents: list[Any]) -> bool:
        """True if contents has at least one TEXT or REFUSAL with non-empty."""
        if not contents:
            return False
        for c in contents:
            t = getattr(c, "type", None)
            if t == ContentType.TEXT and (getattr(c, "text", None) or "").strip():
                return True
            if t == ContentType.REFUSAL and (getattr(c, "refusal", None) or "").strip():
                return True
        return False

    def _content_has_media(self, contents: list[Any]) -> bool:
        """True if contents has at least one IMAGE, VIDEO, FILE or AUDIO."""
        if not contents:
            return False
        _media_types = {
            ContentType.IMAGE,
            ContentType.VIDEO,
            ContentType.FILE,
            ContentType.AUDIO,
        }
        for c in contents:
            t = getattr(c, "type", None)
            if t in _media_types:
                return True
        return False

    def _apply_no_text_debounce(
        self,
        session_id: str,
        content_parts: list[Any],
    ) -> tuple[bool, list[Any]]:
        """
        Debounce: if content has no text AND no media, buffer and return (False, []).
        If has text or media (image/video/file/audio), return (True, merged)
        with any buffered content prepended.
        """
        has_meaningful = self._content_has_text(content_parts) or self._content_has_media(content_parts)
        if not has_meaningful:
            self._pending_content_by_session.setdefault(
                session_id,
                [],
            ).extend(content_parts)
            logger.debug(
                "channel debounce: no text/media, buffered session_id=%s",
                session_id[:24] if session_id else "",
            )
            return (False, [])
        pending = self._pending_content_by_session.pop(session_id, [])
        merged = pending + list(content_parts)
        return (True, merged)

    def set_enqueue(self, cb: EnqueueCallback) -> None:
        """Set enqueue callback (called by ChannelManager)."""
        self._enqueue = cb

    @classmethod
    def from_env(
        cls,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
    ) -> BaseChannel:
        raise NotImplementedError

    @classmethod
    def from_config(
        cls,
        process: ProcessHandler,
        config: Any,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ) -> BaseChannel:
        raise NotImplementedError

    def resolve_session_id(
        self,
        sender_id: str,
        channel_meta: dict[str, Any] | None = None,
    ) -> str:
        """
        Map sender and optional channel meta to session_id.
        Override in subclasses for channel-specific session keys
        (e.g. short suffix of conversation_id for cron lookup).
        """
        return f"{self.channel}:{sender_id}"

    def build_turn_request_from_user_content(
        self,
        channel_id: str,
        sender_id: str,
        session_id: str,
        content_parts: list[Any],
        channel_meta: dict[str, Any] | None = None,
    ) -> TurnRequest:
        """
        Build TurnRequest from content parts.
        Subclasses call this after parsing native payload to content_parts.
        """
        if not content_parts:
            content_parts = [
                TextContent(type=ContentType.TEXT, text=""),
            ]
        turn_input = TurnInput(
            role="user",
            content=content_parts,
        )
        return TurnRequest(
            session_id=session_id,
            user_id=sender_id,
            inputs=[turn_input],
            channel=channel_id,
            context={"channel_meta": channel_meta or {}},
        )

    # ── backward-compat alias (subclasses that still call the old name) ──
    def build_agent_request_from_user_content(
        self,
        channel_id: str,
        sender_id: str,
        session_id: str,
        content_parts: list[Any],
        channel_meta: dict[str, Any] | None = None,
    ) -> TurnRequest:
        """Deprecated alias for build_turn_request_from_user_content."""
        return self.build_turn_request_from_user_content(
            channel_id=channel_id,
            sender_id=sender_id,
            session_id=session_id,
            content_parts=content_parts,
            channel_meta=channel_meta,
        )

    def build_turn_request_from_native(
        self,
        native_payload: Any,
    ) -> TurnRequest:
        """
        Convert channel-native message payload to TurnRequest.
        Subclasses must implement: parse native -> content_parts (runtime
        Content types), session_id, then build_turn_request_from_user_content.
        Attach channel_meta via context["channel_meta"].
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement build_turn_request_from_native(native_payload)",
        )

    # ── backward-compat alias ──
    def build_agent_request_from_native(
        self,
        native_payload: Any,
    ) -> TurnRequest:
        """Deprecated alias for build_turn_request_from_native."""
        return self.build_turn_request_from_native(native_payload)

    def _payload_to_request(self, payload: Any) -> TurnRequest:
        """
        Convert queue payload to TurnRequest. Default: if payload looks like
        TurnRequest (has session_id, inputs), return it; else
        build_turn_request_from_native(payload). Override if needed.
        """
        if payload is None:
            raise ValueError("payload is None")
        if isinstance(payload, TurnRequest):
            return payload
        if hasattr(payload, "session_id") and hasattr(payload, "inputs"):
            return payload
        return self.build_turn_request_from_native(payload)

    def get_to_handle_from_request(self, request: TurnRequest) -> str:
        """
        Resolve send target (to_handle) from TurnRequest. Default: user_id.
        Override for channels that send by session_id (e.g. Feishu).
        """
        return getattr(request, "user_id", "") or ""

    def get_on_reply_sent_args(
        self,
        request: TurnRequest,
        to_handle: str,
    ) -> tuple:
        """
        Args for _on_reply_sent(channel, *args). Default: (to_handle,
        session_id). Override e.g. to pass (user_id, session_id).
        """
        session_id = getattr(request, "session_id", "") or f"{self.channel}:{to_handle}"
        return (to_handle, session_id)

    async def refresh_webhook_or_token(self) -> None:
        """
        Optional: refresh webhook URL or API token. Override for channels
        that need periodic or on-401 refresh. Default no-op.
        """

    async def consume_one(self, payload: Any) -> None:
        """
        Process one payload from the manager-owned queue. If
        _debounce_seconds > 0 and payload is native (dict with
        content_parts), append to buffer and flush after delay;
        otherwise call _consume_one_request(payload). Messages
        with no text are buffered until text arrives (see
        _apply_no_text_debounce). Override only when you need
        a different flow (e.g. print).
        """
        if self._debounce_seconds > 0 and self._is_native_payload(payload):
            key = self.get_debounce_key(payload)
            if self._debounce_pending.get(key):
                self._on_debounce_buffer_append(
                    key,
                    payload,
                    self._debounce_pending[key],
                )
            self._debounce_pending.setdefault(key, []).append(payload)
            old = self._debounce_timers.pop(key, None)
            if old and not old.done():
                old.cancel()

            async def flush(k: str) -> None:
                await asyncio.sleep(self._debounce_seconds)
                items = self._debounce_pending.pop(k, [])
                self._debounce_timers.pop(k, None)
                if not items:
                    return
                merged = self.merge_native_items(items)
                if not merged:
                    return
                await self._consume_one_request(merged)

            self._debounce_timers[key] = asyncio.create_task(flush(key))
            return
        await self._consume_one_request(payload)

    async def _consume_one_request(self, payload: Any) -> None:
        """
        Convert payload to TurnRequest, apply no-text debounce, run _process,
        send messages, handle errors and on_reply_sent. Used by
        consume_one (direct or after time-debounce flush).
        """
        request = self._payload_to_request(payload)
        # Extract channel_meta: prefer context["channel_meta"], fallback to payload dict
        if isinstance(payload, dict):
            meta_from_payload = dict(payload.get("meta") or {})
            if payload.get("session_webhook"):
                meta_from_payload["session_webhook"] = payload["session_webhook"]
            # Store channel_meta in context for downstream use
            ctx = request.context or {}
            if "channel_meta" not in ctx:
                ctx = {**ctx, "channel_meta": meta_from_payload}
                if hasattr(request, "model_copy"):
                    request = request.model_copy(update={"context": ctx})
                else:
                    request.context = ctx

        session_id = getattr(request, "session_id", "") or ""
        if request.inputs:
            first_input = request.inputs[0]
            contents = list(first_input.content if isinstance(first_input.content, list) else [])
            should_process, merged = self._apply_no_text_debounce(
                session_id,
                contents,
            )
            if not should_process:
                return
            if merged:
                if hasattr(request, "model_copy"):
                    new_input = first_input.model_copy(update={"content": merged})
                    request = request.model_copy(update={"inputs": [new_input, *list(request.inputs[1:])]})
                else:
                    request.inputs[0].content = merged

        to_handle = self.get_to_handle_from_request(request)
        await self._before_consume_process(request)

        # Build send_meta from channel_meta
        ctx = request.context or {}
        send_meta = dict(ctx.get("channel_meta") or {})
        if isinstance(payload, dict) and payload.get("session_webhook"):
            send_meta["session_webhook"] = payload["session_webhook"]

        bot_prefix = getattr(self, "bot_prefix", None) or getattr(
            self,
            "_bot_prefix",
            "",
        )
        if bot_prefix and "bot_prefix" not in send_meta:
            send_meta = {**send_meta, "bot_prefix": bot_prefix}
        logger.info(
            "base _consume_one_request: send_meta has_session_webhook=%s",
            bool((send_meta or {}).get("session_webhook")),
        )
        await self._run_process_loop(request, to_handle, send_meta)

    @staticmethod
    def _event_has_text_content(event: TurnEvent) -> bool:
        """Check if a TurnEvent has at least one non-empty text content block."""
        for c in (event.content or []):
            if isinstance(c, dict):
                if c.get("type") == "text" and (c.get("text") or "").strip():
                    return True
            elif getattr(c, "type", None) == ContentType.TEXT and (getattr(c, "text", None) or "").strip():
                return True
        return False

    async def _run_process_loop(
        self,
        request: TurnRequest,
        to_handle: str,
        send_meta: dict[str, Any],
    ) -> None:
        """
        Run _process(TurnRequest) and send TurnEvents.
        Only handles canonical TurnEvent stream from stream_turns.

        Accumulates ASSISTANT_DELTA text so that when event_bridge filters
        out already-streamed text from ASSISTANT_COMPLETED content, the
        channel can still reconstruct the full reply.
        """
        bot_prefix = send_meta.get("bot_prefix", "") or getattr(
            self,
            "bot_prefix",
            "",
        )
        turn_failed = False
        turn_error: Any = None
        # Accumulate streamed delta text for channels that only act on
        # ASSISTANT_COMPLETED (event_bridge strips text blocks from the
        # completed event when they were already streamed as deltas).
        _delta_text_parts: list[str] = []
        try:
            async for event in self._process(request):
                if not isinstance(event, TurnEvent):
                    continue
                # Accumulate assistant delta text
                if event.type == TurnEventType.ASSISTANT_DELTA:
                    delta = event.delta
                    if isinstance(delta, dict) and delta.get("type") == "text":
                        text = delta.get("text", "")
                        if text:
                            _delta_text_parts.append(text)
                    continue
                if event.type == TurnEventType.ASSISTANT_COMPLETED:
                    # If event_bridge stripped text content (because it was
                    # already sent via deltas), reconstruct from accumulated
                    # delta text so the channel can still send the full reply.
                    if _delta_text_parts and not self._event_has_text_content(event):
                        accumulated = "".join(_delta_text_parts)
                        patched_content = [{"type": "text", "text": accumulated}, *(event.content or [])]
                        event = event.model_copy(update={"content": patched_content})
                    _delta_text_parts.clear()
                    await self._on_turn_event_assistant_completed(request, to_handle, event, send_meta)
                elif event.type == TurnEventType.TOOL_APPROVAL_REQUIRED:
                    await self._on_tool_approval_required(request, to_handle, event, send_meta)
                elif event.type == TurnEventType.TURN_FAILED:
                    turn_failed = True
                    turn_error = event.error

            if turn_failed and turn_error is not None:
                err = extract_event_error_message(turn_error)
                err_text = (bot_prefix or "") + f"Error: {err}"
                await self._on_consume_error(request, to_handle, err_text)
            if self._on_reply_sent:
                args = self.get_on_reply_sent_args(request, to_handle)
                self._on_reply_sent(self.channel, *args)
        except Exception:
            logger.exception("channel consume_one failed")
            await self._on_consume_error(
                request,
                to_handle,
                "An error occurred while processing your request.",
            )

    async def _before_consume_process(self, request: TurnRequest) -> None:
        """
        Hook called once per consume_one before running _process. Override
        to e.g. save receive_id for send path (Feishu).
        """

    async def on_event_message_completed(
        self,
        request: TurnRequest,
        to_handle: str,
        event: Any,
        send_meta: dict[str, Any],
    ) -> None:
        """
        Hook: one message event completed. Default: send_message_content.
        Override for batch/debounce (e.g. DingTalk merge then send).
        """
        await self.send_message_content(to_handle, event, send_meta)

    async def _on_consume_error(
        self,
        request: Any,
        to_handle: str,
        err_text: str,
    ) -> None:
        """
        Called when consume_one hits an error or response.error. Default:
        send err_text via send_content_parts. Override to send via channel
        API.
        """
        ctx = getattr(request, "context", None) or {}
        channel_meta = ctx.get("channel_meta") or {}
        await self.send_content_parts(
            to_handle,
            [{"type": "text", "text": err_text}],
            channel_meta,
        )

    async def send_response(
        self,
        to_handle: str,
        response: Any,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """
        Convert response to this channel's reply and send.
        Default: take last message text from output and call
        send(to_handle, text, meta).
        Subclasses may override to support image, video attachments.
        """
        text = self._response_to_text(response)
        await self.send(to_handle, text or "", meta)

    def _message_to_content_parts(
        self,
        message: Any,
    ) -> list[OutgoingContentPart]:
        """
        Convert a message-like object into sendable parts.
        Delegates to self._renderer; override _renderer or _render_style
        for channel-specific formatting.
        """
        return self._renderer.message_to_parts(message)

    async def send_message_content(
        self,
        to_handle: str,
        message: Any,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """
        Send all content of a message
        (text, image, video, audio, file, refusal).
        Subclasses may override send_content_parts for channel-specific
        multi-part sending.
        """
        parts = self._message_to_content_parts(message)
        if not parts:
            logger.info(
                "channel send_message_content: no parts for to_handle=%s, message_type=%s content_preview=%s skip send",
                to_handle[:20] if to_handle else "",
                type(message).__name__,
                str(getattr(message, "content", None))[:200],
            )
            return
        logger.info(
            "channel send_message_content: to_handle=%s parts_count=%d part_types=%s",
            to_handle[:20] if to_handle else "",
            len(parts),
            [getattr(p, "type", None) for p in parts],
        )
        await self.send_content_parts(to_handle, parts, meta)

    async def send_content_parts(
        self,
        to_handle: str,
        parts: list[OutgoingContentPart],
        meta: dict[str, Any] | None = None,
    ) -> None:
        """
        Send a list of content parts.
        Default: merge text/refusal into one text, append media URLs as
        fallback, send one message; optionally call send_media for each
        media part if overridden.
        """
        text_parts: list[str] = []
        media_parts: list[OutgoingContentPart] = []
        for p in parts:
            t = getattr(p, "type", None)
            if t == ContentType.TEXT and getattr(p, "text", None):
                text_parts.append(p.text or "")
            elif t == ContentType.REFUSAL and getattr(p, "refusal", None):
                text_parts.append(p.refusal or "")
            elif t in (
                ContentType.IMAGE,
                ContentType.VIDEO,
                ContentType.AUDIO,
                ContentType.FILE,
            ):
                media_parts.append(p)
        body = "\n".join(text_parts) if text_parts else ""
        prefix = (meta or {}).get("bot_prefix", "") or ""
        if prefix and body:
            body = prefix + body
        for m in media_parts:
            t = getattr(m, "type", None)
            if t == ContentType.IMAGE and getattr(m, "image_url", None):
                body += f"\n[Image: {m.image_url}]"
            elif t == ContentType.VIDEO and getattr(m, "video_url", None):
                body += f"\n[Video: {m.video_url}]"
            elif t == ContentType.FILE and (getattr(m, "file_url", None) or getattr(m, "file_id", None)):
                body += f"\n[File: {m.file_url or m.file_id}]"
            elif t == ContentType.AUDIO and getattr(m, "data", None):
                body += "\n[Audio]"
        if body.strip():
            logger.debug(
                f"channel send_content_parts: to_handle={to_handle} "
                f"body_len={len(body)} preview="
                f"{body[:120] + '...' if len(body) > 120 else body}",
            )
            await self.send(to_handle, body.strip(), meta)
        for m in media_parts:
            await self.send_media(to_handle, m, meta)

    async def send_media(
        self,
        to_handle: str,
        part: OutgoingContentPart,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """
        Send a single media part (image, video, audio, file).
        Default: no-op (already appended to text in send_content_parts).
        Subclasses override to send real attachments.
        """
        pass

    def _response_to_text(self, response: Any) -> str:
        """Extract reply text from response (last message in output)."""
        if not response.output:
            return ""
        last_msg = response.output[-1]
        if last_msg.type != MessageType.MESSAGE or not last_msg.content:
            return ""
        parts = []
        for c in last_msg.content:
            if getattr(c, "type", None) == ContentType.TEXT and getattr(
                c,
                "text",
                None,
            ):
                parts.append(c.text)
            elif getattr(c, "type", None) == ContentType.REFUSAL and getattr(
                c,
                "refusal",
                None,
            ):
                parts.append(c.refusal)
        return "".join(parts)

    def clone(
        self,
        config,
        *,
        show_tool_details: bool | None = None,
    ) -> BaseChannel:
        """Clone a new channel instance with updated config, cloning
        process and on_reply_sent from self.

        Subclasses must implement from_config(process, config, on_reply_sent).
        """
        if show_tool_details is None:
            show_tool_details = getattr(self, "_show_tool_details", True)
        return self.__class__.from_config(
            process=self._process,
            config=config,
            on_reply_sent=self._on_reply_sent,
            show_tool_details=show_tool_details,
        )

    def get_connection_status(self) -> dict:
        """Return channel connection status information.

        Returns:
            dict: {
                "status": "connected" | "disconnected" | "not_enabled",
                "reason": str | None  # Disconnection reason (only set if disconnected)
            }
        Subclasses may override this method based on their connection method.
        Default implementation: return not_enabled if disabled; connected if enabled.
        """
        if not getattr(self, "enabled", False):
            return {"status": "not_enabled", "reason": None}
        return {"status": "connected", "reason": None}

    async def verify_credentials(self) -> dict:
        """Actively validate channel credentials and check connectivity.

        Returns:
            dict: {
                "valid": bool,
                "status": "connected" | "disconnected" | "not_enabled",
                "reason": str | None
            }
        Subclasses should override this method to verify credentials by calling
        platform APIs. Default implementation returns get_connection_status results.
        """
        status_info = self.get_connection_status()
        return {
            "valid": status_info["status"] == "connected",
            **status_info,
        }

    @staticmethod
    async def verify_credentials_with_params(credentials: dict) -> dict:
        """Validate connectivity using provided credential parameters (not instance-dependent).

        Args:
            credentials: dict containing channel credentials, e.g. {"app_id": ..., "client_secret": ...}

        Returns:
            dict: {"valid": bool, "status": str, "reason": str | None}
        Subclasses should override this static method.
        """
        return {
            "valid": False,
            "status": "disconnected",
            "reason": "This channel does not support credential verification",
        }

    async def start(self) -> None:
        raise NotImplementedError

    async def stop(self) -> None:
        raise NotImplementedError

    async def send(
        self,
        to_handle: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Subclass implements: send one text
        (and optional attachments) to to_handle.
        """
        raise NotImplementedError

    def to_handle_from_target(self, *, user_id: str, session_id: str) -> str:
        """Map cron dispatch target to channel-specific to_handle.

        Default: use user_id. For many channels, this is enough.
        Discord proactive send relies on meta['channel_id'] or
         meta['user_id'] anyway.
        """
        return user_id

    async def _on_tool_approval_required(
        self,
        request: Any,
        to_handle: str,
        event: TurnEvent,
        send_meta: dict[str, Any],
    ) -> None:
        """Handle TOOL_APPROVAL_REQUIRED event: send risk alert to user.

        Subclasses may override this method to implement channel-specific
        approval notifications (e.g. Feishu card, QQ message, etc.).
        Default implementation: send text risk alert, prompting user to input
        /approve to permit or send any message to deny.
        """
        data = event.data or {}
        tool_name = data.get("tool_name", "unknown")
        severity = data.get("severity", "UNKNOWN")
        findings_count = data.get("findings_count", 0)
        findings_text = data.get("findings_text", "")
        auto_denied = data.get("auto_denied", False)

        bot_prefix = send_meta.get("bot_prefix", "") or getattr(self, "bot_prefix", "")

        if auto_denied:
            msg_text = (
                f"⛔ **Tool Blocked**\n\n"
                f"- Tool: `{tool_name}`\n"
                f"- Severity: `{severity}`\n"
                f"- Findings: `{findings_count}`\n\n"
                f"{findings_text}\n\n"
                f"This tool is blocked and cannot be approved."
            )
        else:
            msg_text = (
                f"⚠️ **Risk Detected**\n\n"
                f"- Tool: `{tool_name}`\n"
                f"- Severity: `{severity}`\n"
                f"- Findings: `{findings_count}`\n\n"
                f"{findings_text}\n\n"
                f"Type `/approve` to approve, or send any message to deny."
            )

        if bot_prefix:
            msg_text = bot_prefix + msg_text

        logger.info(
            "_on_tool_approval_required: tool=%s severity=%s auto_denied=%s channel=%s",
            tool_name,
            severity,
            auto_denied,
            self.channel,
        )
        await self.send(to_handle, msg_text, send_meta)

    async def _on_turn_event_assistant_completed(
        self,
        request: Any,
        to_handle: str,
        event: TurnEvent,
        send_meta: dict[str, Any],
    ) -> None:
        """Handle assistant.completed TurnEvent: extract content and send.

        Skips tool/plugin message types (only forwards plain assistant replies).
        Override for channel-specific handling.
        """
        metadata = event.metadata or {}
        message_type = metadata.get("message_type", MessageType.MESSAGE)

        # Skip internal tool/plugin messages
        if message_type in _INTERNAL_MESSAGE_TYPES:
            logger.info(
                "_on_turn_event_assistant_completed: skipped message_type=%s channel=%s",
                message_type,
                self.channel,
            )
            return

        msg = _TurnMsg(message_type, list(event.content or []), event.role or "assistant")
        forwarding_meta = dict(send_meta or {})
        forwarding_meta["_msg_type"] = message_type
        await self.on_event_message_completed(request, to_handle, msg, forwarding_meta)

    async def send_event(
        self,
        *,
        user_id: str,
        session_id: str,
        event: Any,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send a TurnEvent to this channel (non-stream, e.g. cron proactive send).

        Only handles canonical TurnEvent (assistant.completed).
        Tool calls, plugin calls, reasoning, etc. are skipped.
        """
        if not isinstance(event, TurnEvent):
            return
        if event.type != TurnEventType.ASSISTANT_COMPLETED:
            return

        to_handle = self.to_handle_from_target(
            user_id=user_id,
            session_id=session_id,
        )
        forwarding_meta = dict(meta or {})
        forwarding_meta.setdefault("session_id", session_id)
        forwarding_meta.setdefault("user_id", user_id)

        metadata = event.metadata or {}
        message_type = metadata.get("message_type", MessageType.MESSAGE)
        if message_type in _INTERNAL_MESSAGE_TYPES:
            logger.info(
                "send_event: skipped TurnEvent message_type=%s channel=%s",
                message_type,
                self.channel,
            )
            return

        logger.info(
            "send_event: PASSING TurnEvent to channel=%s to_handle=%s message_type=%s",
            self.channel,
            to_handle[:20] if to_handle else "",
            message_type,
        )
        msg = _TurnMsg(message_type, list(event.content or []), event.role or "assistant")
        forwarding_meta["_msg_type"] = message_type
        await self.send_message_content(to_handle, msg, forwarding_meta)
