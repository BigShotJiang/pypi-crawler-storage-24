# pylint: disable=unused-argument too-many-branches too-many-statements

import logging
import time
from collections.abc import AsyncIterator
from typing import Any

from dotenv import load_dotenv

from ....agent.memory import MemoryManager
from ....constant import WORKING_DIR
from ....envs.store import get_env_file_path
from ...core.error_utils import classify_exception
from ...turn_protocol import TurnEvent, TurnEventType, TurnRequest
from ..session.session import SafeSession
from ..session.session_factory import SessionFactory
from ..tools.registry import ToolRegistry
from .event_bridge import EventBridge
from .run_controller import RunController

logger = logging.getLogger(__name__)


class AgentRunner:
    """Self-built runner that directly produces TurnEvent streams.

    ``stream_turns(request)`` is consumed by:
      - ``/api/agent/process`` SSE endpoint (via _app.py)
      - Channels via ``make_process_from_runner(runner)``
    """

    _APPROVAL_TIMEOUT_SECONDS = 300.0

    def __init__(self) -> None:
        self._chat_manager = None
        self._mcp_manager = None
        self.session: SafeSession | None = None
        self.memory_manager: MemoryManager | None = None
        # Track the number of active (non-ephemeral) runs so that
        # proactivity can avoid interrupting an ongoing conversation.
        self._active_runs: int = 0

    # ----- External dependency injection -----

    def set_chat_manager(self, chat_manager):
        """Set chat manager for auto-registration."""
        self._chat_manager = chat_manager

    def set_mcp_manager(self, mcp_manager):
        """Set MCP client manager for hot-reload support."""
        self._mcp_manager = mcp_manager

    # ----- Lifecycle -----

    async def start(self):
        """Initialise session, memory, etc. (replaces init_handler)."""
        env_path = get_env_file_path()
        if env_path.exists():
            load_dotenv(env_path)
            logger.debug("Loaded environment variables from %s", env_path)
        else:
            logger.debug(
                ".env file not found at %s, using existing environment variables",
                env_path,
            )

        session_dir = str(WORKING_DIR / "sessions")
        self.session = SafeSession(save_dir=session_dir)

        try:
            if self.memory_manager is None:
                self.memory_manager = MemoryManager(
                    working_dir=str(WORKING_DIR),
                )
            await self.memory_manager.start()
        except Exception as e:
            logger.exception("MemoryManager start failed: %s", e)

    async def stop(self):
        """Shutdown handler."""
        try:
            if self.memory_manager:
                await self.memory_manager.close()
        except Exception as e:
            logger.warning("MemoryManager stop failed: %s", e)

    # ----- Internal helpers -----

    def _extract_query_text(self, request: TurnRequest) -> str:
        """Extract plain text from the first request message."""
        inputs = getattr(request, "inputs", None) or []
        if not inputs:
            return ""
        content = getattr(inputs[0], "content", None) or []
        if not isinstance(content, list):
            return ""
        for part in content:
            text = part.get("text") if isinstance(part, dict) else getattr(part, "text", None)
            if text:
                return str(text).strip()
        return ""

    @staticmethod
    def _format_args_summary(arguments: dict, max_items: int = 3) -> str:
        """Format tool argument dict into a concise readable summary."""
        items = list(arguments.items())[:max_items]
        summary = ", ".join(f"{k}={v!r}" for k, v in items)
        return summary + (", ..." if len(arguments) > max_items else "")

    # ----- ToolGuard approval routing -----

    async def _handle_tool_guard_approval(self, request: TurnRequest) -> bool:
        """Check and route pending ToolGuard approval commands.

        If this session has a pending approval:
        - user sends /approve -> approve, return True (skip normal flow)
        - user sends any other message -> deny, return True (skip normal flow)

        If there is no pending approval, return False and continue normal flow.
        """
        try:
            from lightclaw.security.tool_guard.approval import ApprovalDecision
            from lightclaw.security.tool_guard.service import get_approval_service

            session_id = getattr(request, "session_id", "") or ""
            if not session_id:
                return False

            svc = get_approval_service()
            pending = await svc.get_pending_by_session(session_id)
            if pending is None:
                return False

            query = self._extract_query_text(request)

            elapsed = time.time() - pending.created_at

            if elapsed > self._APPROVAL_TIMEOUT_SECONDS:
                await svc.resolve_request(pending.request_id, ApprovalDecision.TIMEOUT)
                logger.info(
                    "Tool guard: approval timed out for tool '%s' (session %s)",
                    pending.tool_name,
                    session_id[:8],
                )
                return True

            normalized = query.lower()
            if normalized in ("/approve", "/daemon approve"):
                await svc.resolve_request(pending.request_id, ApprovalDecision.APPROVED)
                logger.info(
                    "Tool guard: approved tool '%s' (session %s)",
                    pending.tool_name,
                    session_id[:8],
                )
                # Approval passed: let LangGraph continue normal execution.
                return False

            # Any other message is treated as deny.
            await svc.resolve_request(pending.request_id, ApprovalDecision.DENIED)
            logger.info(
                "Tool guard: denied tool '%s' (session %s)",
                pending.tool_name,
                session_id[:8],
            )
            return True

        except ImportError:
            return False
        except Exception as exc:
            logger.warning("Tool guard approval routing error: %s", exc)
            return False

    # ----- Core: stream_turns -----

    async def stream_turns(
        self,
        request: TurnRequest,
    ) -> AsyncIterator[TurnEvent]:
        """Canonical turn-native event stream."""
        if not isinstance(request, TurnRequest):
            request = TurnRequest.model_validate(request if isinstance(request, dict) else request.model_dump())

        if self.session is None:
            raise RuntimeError("Session is not initialised")

        _extra = getattr(request, "__pydantic_extra__", None) or {}
        _source = _extra.get("source")
        _is_ephemeral = bool(_extra.get("ephemeral"))

        # Track active non-ephemeral runs so proactivity can back off.
        if not _is_ephemeral:
            self._active_runs += 1

        try:
            async for ev in self._stream_turns_inner(request, _source, _is_ephemeral):
                yield ev
        finally:
            # Guarantee decrement even on client disconnect / cancellation.
            if not _is_ephemeral:
                self._active_runs = max(0, self._active_runs - 1)

    async def _stream_turns_inner(
        self,
        request: TurnRequest,
        _source: str | None,
        _is_ephemeral: bool,
    ) -> AsyncIterator[TurnEvent]:
        """Inner generator for stream_turns — separated so the outer
        method can wrap it in try/finally for _active_runs cleanup."""
        # Reset proactivity unanswered_count on user-initiated requests
        if not _source:  # No source = user-initiated
            try:
                from lightclaw.config import get_proactivity_config

                pa_cfg = get_proactivity_config()
                if pa_cfg.enabled:
                    from lightclaw.app.cron.proactivity import (
                        read_identity_field,
                        write_activity_field,
                    )

                    unanswered = int(read_identity_field("unanswered_count", "0"))
                    if unanswered > 0:
                        write_activity_field("unanswered_count", "0")
                        logger.info(
                            "proactivity: user replied, unanswered_count %d -> 0",
                            unanswered,
                        )
            except Exception:
                logger.debug("proactivity unanswered_count reset failed", exc_info=True)

        seq = 0

        def _stamp(event: TurnEvent) -> TurnEvent:
            nonlocal seq
            stamped = event.model_copy(update={"sequence_number": seq})
            seq += 1
            return stamped

        # ToolGuard: check pending approval first.
        # Route approval command before deciding whether to continue.
        guard_consumed = await self._handle_tool_guard_approval(request)
        if guard_consumed:
            # Approval command already handled (approve/deny).
            return

        yield _stamp(
            TurnEvent(
                type=TurnEventType.TURN_STARTED,
                turn_id=request.turn_id,
                metadata={"session_id": request.session_id},
            )
        )

        controller = None
        try:
            session_factory = SessionFactory(
                session=self.session,
                memory_manager=self.memory_manager,
                chat_manager=self._chat_manager,
            )
            tool_registry = ToolRegistry(mcp_manager=self._mcp_manager)
            event_bridge = EventBridge()
            controller = RunController(
                session_factory=session_factory,
                tool_registry=tool_registry,
                event_bridge=event_bridge,
            )

            async for event, _is_last in controller.run(
                msgs=request.inputs,
                request=request,
            ):
                yield _stamp(event)

        except Exception as exc:
            error_info = classify_exception(exc)
            logger.exception(
                "stream_turns error [%s/%s]: %s",
                error_info.code,
                error_info.source,
                error_info.raw_message or error_info.message,
            )
            yield _stamp(
                TurnEvent(
                    type=TurnEventType.TURN_FAILED,
                    turn_id=request.turn_id,
                    error=error_info.to_event_error(),
                )
            )
            return

        run_usage = getattr(controller, "last_run_usage", None)
        yield _stamp(
            TurnEvent(
                type=TurnEventType.TURN_COMPLETED,
                turn_id=request.turn_id,
                usage=run_usage,
            )
        )

    async def stream_content(
        self,
        request: Any,
        *,
        include_tool_details: bool = False,
    ) -> AsyncIterator[str]:
        """Convenience wrapper for AgentExecutor.stream_content().

        Yields plain text chunks directly for channels (OpenAI / MCP, etc.)
        so callers do not need to parse TurnEvent manually.

        Args:
            request: TurnRequest or a compatible request object.
            include_tool_details: If True, TOOL_STARTED events yield
                formatted tool call details (name + arg summary).

        Yields:
            str: Assistant text chunks, or tool call descriptions when enabled.
        """
        async for turn_event in self.stream_turns(request):
            if turn_event.type == TurnEventType.ASSISTANT_DELTA:
                # Emit text deltas only.
                delta = turn_event.delta
                if isinstance(delta, dict) and delta.get("type") == "text":
                    text = delta.get("text", "")
                    if text:
                        yield text

            elif turn_event.type == TurnEventType.TOOL_STARTED and include_tool_details:
                # Emit formatted tool call description.
                data = turn_event.data or {}
                tool_name = ""
                args_summary = ""
                if isinstance(data, dict):
                    tool_name = str(data.get("name") or data.get("tool_name") or "")
                    arguments = data.get("arguments") or data.get("args") or {}
                    if isinstance(arguments, dict) and arguments:
                        args_summary = self._format_args_summary(arguments)
                if tool_name:
                    desc = f"\n[调用工具: {tool_name}"
                    if args_summary:
                        desc += f"({args_summary})"
                    desc += "]\n"
                    yield desc

            # No text output for TURN_* / ASSISTANT_COMPLETED / TOOL_COMPLETED.
