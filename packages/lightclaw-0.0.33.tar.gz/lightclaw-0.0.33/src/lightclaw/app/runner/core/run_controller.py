"""Run controller for a single agent query.

This module owns the lifecycle of a single ``query_handler`` call:
* Logging and basic request metadata
* Wiring session / tools / events together
* Handling cancellation, errors and finalisation

Execution is handled exclusively via the LangGraph path, including:
* LangGraph-native command handling
* Session persistence (save/load history + compressed summary)
* Graceful cancellation via middleware
* Middleware integration (Bootstrap + MemoryCompaction)
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any
from uuid import uuid4

from ....agent.langgraph.boundary_adapters.turn_protocol import (
    langchain_message_to_turn_event,
    turn_inputs_to_langchain_messages,
)
from ....constant import WORKING_DIR
from ...channels.schema import DEFAULT_CHANNEL
from ...core.error_utils import classify_exception
from ...turn_protocol import TurnEventType
from ..query_error_dump import write_query_error_dump
from ..session.daily_talk_store import DailyTalkStore
from ..session.session_factory import LangGraphSessionContext, SessionFactory
from ..tools.registry import ToolRegistry
from .event_bridge import EventBridge

logger = logging.getLogger(__name__)
_MEDIA_BLOCK_TYPES = frozenset({"file", "image", "audio", "video"})


def _message_has_file_or_media_blocks(message: Any) -> bool:
    """Return True when the message contains file/media blocks."""
    content = getattr(message, "content", None)
    if not isinstance(content, list):
        return False

    for block in content:
        if not isinstance(block, dict):
            if hasattr(block, "model_dump"):
                block = block.model_dump(exclude_none=True)
            elif hasattr(block, "dict"):
                block = block.dict(exclude_none=True)
            else:
                continue

        if block.get("type") in _MEDIA_BLOCK_TYPES:
            return True

    return False


def _extract_user_turn_texts(
    inputs: Any,
    *,
    is_command_predicate: Any,
) -> list[str]:
    """Extract natural-language user texts from turn inputs."""
    if inputs is None:
        return []

    messages = inputs if isinstance(inputs, list) else [inputs]
    result: list[str] = []
    for msg in messages:
        role = getattr(msg, "role", None)
        if role != "user":
            continue

        getter = getattr(msg, "get_text_content", None)
        if callable(getter):
            text = getter()
        else:
            text = ""

        normalized = (text or "").strip()
        if not normalized:
            continue
        if is_command_predicate(normalized):
            continue
        result.append(normalized)
    return result


@dataclass
class RunContext:
    """Lightweight context for a single run."""

    run_id: str
    session_id: str | None
    user_id: str | None
    channel: str


async def _safe_extract_facts(
    extractor: Any,
    user_text: str,
    assistant_text: str,
    turn_id: str,
    middleware: Any = None,
) -> None:
    """Fire-and-forget wrapper for background fact extraction.

    Updates the middleware's fact modification timestamp so the
    :class:`FactInjector` cache is invalidated on the next turn.
    """
    try:
        result = await extractor.process_turn(user_text, assistant_text, turn_id)
        # Update middleware so next turn's injection sees fresh facts.
        if middleware is not None and result.decisions:
            middleware.update_fact_extractor_timestamp(extractor.last_modified_ms)
        actions = ", ".join(d.action for d in result.decisions) if result.decisions else "none"
        logger.info(
            "Fact extraction: %d candidates → %d decisions (%s)",
            result.candidates_extracted,
            len(result.decisions),
            actions,
        )
    except Exception:
        logger.exception("Background fact extraction failed")


class RunController:
    """Control the lifecycle of a single agent run."""

    def __init__(
        self,
        *,
        session_factory: SessionFactory,
        tool_registry: ToolRegistry,
        event_bridge: EventBridge,
    ) -> None:
        self._session_factory = session_factory
        self._tool_registry = tool_registry
        self._event_bridge = event_bridge
        self.last_run_usage: dict[str, Any] | None = None
        self.last_final_output_usage: dict[str, Any] | None = None

    async def run(
        self,
        *,
        inputs=None,
        msgs=None,
        request: Any,
    ) -> AsyncIterator[tuple[Any, bool]]:
        """Execute a single agent run as an async generator.

        Always dispatches to the LangGraph execution path.
        """
        if inputs is None:
            inputs = msgs
        self.last_run_usage = None
        self.last_final_output_usage = None
        run_ctx = RunContext(
            run_id=str(uuid4()),
            session_id=request.session_id,
            user_id=request.user_id,
            channel=getattr(request, "channel", DEFAULT_CHANNEL),
        )

        logger.info(
            "Handle agent query (run_id=%s):\n%s",
            run_ctx.run_id,
            json.dumps(
                {
                    "session_id": run_ctx.session_id,
                    "user_id": run_ctx.user_id,
                    "channel": run_ctx.channel,
                    "inputs_len": len(inputs) if inputs else 0,
                    "inputs_str": str(inputs)[:300] + "...",
                },
                ensure_ascii=False,
                indent=2,
            ),
        )

        async for msg, last in self._run_langgraph(inputs=inputs, request=request, run_ctx=run_ctx):
            yield msg, last

    # ------------------------------------------------------------------
    # LangGraph path
    # ------------------------------------------------------------------

    async def _run_langgraph(
        self,
        *,
        inputs=None,
        msgs=None,
        request: Any,
        run_ctx: RunContext,
    ) -> AsyncIterator[tuple[Any, bool]]:
        """New LangGraph agent execution path.

        Stage 1: Inspect the last user message and short-circuit pure commands
        Stage 2: For normal queries, preprocess files and build full context
        Stage 3: Execute ReAct agent via graph.astream_events

        PR5: Commands are now handled natively; session state is persisted.
        """
        from ....agent.langgraph.command_handler import (
            LangGraphCommandHandler,
            is_command,
        )
        from ....agent.langgraph.event_bridge import LangGraphEventBridge
        from ....agent.utils import process_file_and_media_blocks_in_message

        chat = None
        lg_context: LangGraphSessionContext | None = None
        self.last_run_usage = None
        self.last_final_output_usage = None
        run_succeeded = False
        deferred_daily_write = False
        pending_user_texts: list[str] = []
        if inputs is None:
            inputs = msgs
        is_ephemeral = bool(
            getattr(request, "__pydantic_extra__", None)
            and request.__pydantic_extra__.get("ephemeral")
        )
        # For ephemeral runs, keep a snapshot of the original session
        # history so we only append the final AI message (stripping the
        # cron prompt and intermediate tool calls).
        _pre_run_history: list = []

        try:
            daily_talk_store = DailyTalkStore(working_dir=WORKING_DIR)

            def _build_command_handler(context: LangGraphSessionContext):
                return LangGraphCommandHandler(
                    history_messages=context.history_messages,
                    middleware=context.middleware,
                    session_store=context.session_store,
                    session_id=context.session_id or run_ctx.run_id,
                    user_id=context.user_id,
                    channel=context.channel,
                    memory_manager=(self._session_factory._memory_manager),
                )

            pending_user_texts = _extract_user_turn_texts(
                inputs,
                is_command_predicate=is_command,
            )
            if pending_user_texts:
                try:
                    deferred_daily_write = await daily_talk_store.needs_rollover()
                    if not deferred_daily_write:
                        for text in pending_user_texts:
                            await daily_talk_store.append_user_message(text)
                except Exception:
                    logger.exception("Failed to append user message into DAILY_TALK.md")

            # ── Stage 1: Command short-circuit ──
            last_msg = inputs[-1] if isinstance(inputs, list) else inputs
            query = last_msg.get_text_content() if hasattr(last_msg, "get_text_content") else None
            is_pure_command = bool(
                last_msg is not None and query and is_command(query) and not _message_has_file_or_media_blocks(last_msg)
            )

            if is_pure_command:
                logger.info(
                    "LangGraph path: short-circuiting pure command '%s'",
                    query.strip(),
                )
                lg_context = await self._session_factory.create_command_context(
                    msgs=inputs,
                    request=request,
                )
                chat = lg_context.chat
                result_msg = await _build_command_handler(lg_context).handle(query)
                yield (
                    langchain_message_to_turn_event(
                        result_msg,
                        turn_id=getattr(request, "turn_id", None) or run_ctx.run_id,
                    ),
                    True,
                )
                return

            # ── Stage 2: Full context for normal queries ──
            if inputs is not None:
                await process_file_and_media_blocks_in_message(inputs)

            mcp_clients = await self._tool_registry.get_mcp_clients()
            lg_context = await self._session_factory.create_langgraph_context(
                msgs=inputs,
                request=request,
                mcp_clients=mcp_clients,
            )
            # Ephemeral runs (proactivity / cron) still get a chat entry
            # so the user can see proactive messages in their conversation.
            # The ephemeral flag controls history handling (only persist final
            # AI message, filter SKIP, cap history) — NOT sidebar visibility.
            chat = lg_context.chat
            if deferred_daily_write and pending_user_texts:
                try:
                    for text in pending_user_texts:
                        await daily_talk_store.append_user_message(text)
                except Exception:
                    logger.exception("Failed to append deferred user message into DAILY_TALK.md")

            # ── Command interception after full init ──
            if query and is_command(query):
                logger.info(
                    "LangGraph path: handling command '%s' natively",
                    query,
                )
                result_msg = await _build_command_handler(lg_context).handle(query)
                yield (
                    langchain_message_to_turn_event(
                        result_msg,
                        turn_id=getattr(request, "turn_id", None) or run_ctx.run_id,
                    ),
                    True,
                )
                return

            # ── Stage 3: Execute Agent ──
            lc_messages = turn_inputs_to_langchain_messages(inputs if isinstance(inputs, list) else [inputs])
            # Prepend history (loaded from session store)
            all_messages = lg_context.history_messages + lc_messages

            # Snapshot the original history before running the agent so
            # ephemeral runs can later reconstruct what to persist.
            if is_ephemeral:
                _pre_run_history = list(lg_context.history_messages)

            bridge = LangGraphEventBridge(emit_tool_events=True)

            # 注入 Langfuse CallbackHandler（未配置时为 None，自动跳过）
            from ...observability import get_langfuse_callback

            langfuse_cb = get_langfuse_callback(
                trace_name="agent_run",
                session_id=run_ctx.session_id,
                user_id=run_ctx.user_id,
                metadata={"channel": run_ctx.channel, "run_id": run_ctx.run_id},
            )
            callbacks = [langfuse_cb] if langfuse_cb is not None else []

            async for event in bridge.stream(
                lg_context.graph,
                all_messages,
                turn_id=getattr(request, "turn_id", None) or run_ctx.run_id,
                config={
                    "configurable": {
                        "thread_id": lg_context.session_id or run_ctx.run_id,
                        # ToolGuard 需要这些字段来创建 pending 审批记录
                        "session_id": run_ctx.session_id or "",
                        "user_id": run_ctx.user_id or "",
                        "channel": run_ctx.channel or "",
                    },
                    "callbacks": callbacks,
                },
                max_iterations=lg_context.config.max_iterations,
            ):
                yield event, event.type == TurnEventType.ASSISTANT_COMPLETED

            self.last_run_usage = bridge.run_usage
            self.last_final_output_usage = bridge.final_output_usage

            # After streaming completes, update history with the full
            # conversation (input + output) for session persistence.
            if bridge.final_output_messages:
                if is_ephemeral:
                    # Ephemeral run (proactivity / cron): only persist the
                    # final AI message so the proactive prompt and
                    # intermediate tool calls don't pollute the session.
                    # If the message is a [SKIP] marker, discard it entirely.
                    from langchain_core.messages import AIMessage

                    _SKIP_MARKER = "[SKIP]"

                    final_ai_msgs = [
                        m
                        for m in bridge.final_output_messages
                        if isinstance(m, AIMessage) and not getattr(m, "tool_calls", None)
                    ]
                    # Filter out SKIP messages — they should not be persisted.
                    pre_filter_count = len(final_ai_msgs)
                    final_ai_msgs = [
                        m for m in final_ai_msgs
                        if _SKIP_MARKER not in (getattr(m, "content", "") or "")
                    ]
                    if len(final_ai_msgs) < pre_filter_count:
                        logger.info(
                            "ephemeral run: filtered out %d [SKIP] message(s)",
                            pre_filter_count - len(final_ai_msgs),
                        )
                    if final_ai_msgs:
                        new_history = [*_pre_run_history, final_ai_msgs[-1]]
                    else:
                        # No clean AI message — keep original history unchanged
                        new_history = _pre_run_history

                    # Cap ephemeral session history to avoid unbounded growth.
                    # Keep only the most recent messages.
                    _EPHEMERAL_MAX_HISTORY = 50
                    if len(new_history) > _EPHEMERAL_MAX_HISTORY:
                        new_history = new_history[-_EPHEMERAL_MAX_HISTORY:]
                        logger.info(
                            "ephemeral run: trimmed history to last %d messages",
                            _EPHEMERAL_MAX_HISTORY,
                        )

                    lg_context.history_messages = new_history
                    logger.info(
                        "ephemeral run: persisting %d history + %d new AI msg(s)",
                        len(_pre_run_history),
                        len(final_ai_msgs),
                    )
                else:
                    lg_context.history_messages = bridge.final_output_messages
            run_succeeded = True

        except asyncio.CancelledError:
            # PR5: graceful cancel via middleware
            if lg_context and lg_context.middleware:
                lg_context.middleware.cancel()
            raise
        except Exception as exc:  # pylint: disable=broad-except
            error_info = classify_exception(exc)
            debug_dump_path = write_query_error_dump(
                request=request,
                exc=exc,
                locals_=locals(),
            )
            path_hint = f"\n(Details:  {debug_dump_path})" if debug_dump_path else ""
            logger.exception(
                "Error in LangGraph query handler [%s/%s]: %s%s",
                error_info.code,
                error_info.source,
                error_info.raw_message or exc,
                path_hint,
            )
            exc.lightclaw_error_info = error_info.to_event_error()
            if debug_dump_path:
                exc.debug_dump_path = debug_dump_path
                if hasattr(exc, "add_note"):
                    exc.add_note(f"(Details:  {debug_dump_path})")
                suffix = f"\n(Details:  {debug_dump_path})"
                exc.args = (f"{exc.args[0]}{suffix}" if exc.args else suffix.strip(), *exc.args[1:])
            raise
        finally:
            # PR5: Save LangGraph session state
            session_saved = False
            if lg_context is not None:
                try:
                    await self._session_factory.save_langgraph_session_state(
                        lg_context,
                    )
                    session_saved = True
                except Exception:
                    logger.exception("Failed to save LangGraph session state")

                if (
                    run_succeeded
                    and session_saved
                    and lg_context.middleware is not None
                    and hasattr(
                        lg_context.middleware,
                        "commit_bootstrap_completion",
                    )
                ):
                    try:
                        lg_context.middleware.commit_bootstrap_completion()
                    except Exception:
                        logger.exception("Failed to commit bootstrap completion after run")

                # Structured fact extraction is disabled: no per-turn
                # background writes into SQLite fact tables.

            if chat is not None:
                # Accumulate run-level token usage into chat.meta
                if self.last_run_usage and isinstance(self.last_run_usage, dict):
                    prev = chat.meta.get("total_usage") or {}
                    chat.meta["total_usage"] = {
                        "input_tokens": (prev.get("input_tokens") or 0)
                        + (self.last_run_usage.get("input_tokens") or 0),
                        "output_tokens": (prev.get("output_tokens") or 0)
                        + (self.last_run_usage.get("output_tokens") or 0),
                        "total_tokens": (prev.get("total_tokens") or 0)
                        + (self.last_run_usage.get("total_tokens") or 0),
                    }
                await self._session_factory.update_chat(chat)
