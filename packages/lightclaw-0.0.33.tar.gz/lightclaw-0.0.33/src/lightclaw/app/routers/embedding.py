"""Embedding 配置 API。

端点：
    GET  /embedding/config              — 获取当前 embedding 配置
    GET  /embedding/models              — 获取预设本地模型列表
    PUT  /embedding/config              — 保存 embedding 配置（持久化到 lightclaw.json）
    POST /embedding/download-local      — 触发本地模型下载（异步后台）
    GET  /embedding/download-status     — 查询下载进度（HTTP 轮询接口）
"""

from __future__ import annotations

import logging
import shutil

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ...config import load_config, save_config
from ...config.config import EmbeddingConfig
from ...embedding.local_server import PRESET_MODELS, get_fastembed_model_cache_dir
from ...embedding.manager import DownloadState

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/embedding", tags=["embedding"])


# ---------------------------------------------------------------------------
# GET /embedding/config
# ---------------------------------------------------------------------------


@router.get(
    "/config",
    response_model=EmbeddingConfig,
    summary="获取 embedding 配置",
    description="返回当前持久化的 embedding provider 配置。",
)
async def get_embedding_config() -> EmbeddingConfig:
    """读取 lightclaw.json 中的 embedding 配置。"""
    try:
        config = load_config()
        return config.embedding
    except Exception as exc:
        logger.error("Failed to load embedding config: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# GET /embedding/models
# ---------------------------------------------------------------------------


@router.get(
    "/models",
    response_model=list[str],
    summary="获取预设本地模型列表",
    description="返回可用的预设 embedding 模型列表供前端选择。",
)
async def get_preset_models() -> list[str]:
    """返回预设的本地 embedding 模型列表。"""
    return PRESET_MODELS


# ---------------------------------------------------------------------------
# PUT /embedding/config
# ---------------------------------------------------------------------------


@router.put(
    "/config",
    response_model=EmbeddingConfig,
    summary="保存 embedding 配置",
    description="持久化 embedding 配置到 lightclaw.json，并触发运行时重新初始化。",
)
async def update_embedding_config(
    body: EmbeddingConfig,
    request: Request,
) -> EmbeddingConfig:
    """保存并应用新的 embedding 配置。"""
    try:
        config = load_config()
        config.embedding = body
        save_config(config)
    except Exception as exc:
        logger.error("Failed to save embedding config: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    # 通知 EmbeddingManager 重新初始化（如果 app.state 上有）
    manager = getattr(request.app.state, "embedding_manager", None)
    if manager is not None:
        try:
            await manager.shutdown()
            await manager.startup(body)
        except Exception as exc:
            logger.warning("Failed to reload embedding manager: %s", exc)

    # 同步重载 Memory backend，使新 embedding 配置立即生效
    runner = getattr(request.app.state, "runner", None)
    if runner is not None:
        memory_manager = getattr(runner, "memory_manager", None)
        if memory_manager is not None:
            try:
                await memory_manager.reload_backend()
                logger.info("Memory backend reloaded with new embedding config")
            except Exception as exc:
                logger.warning("Failed to reload memory backend: %s", exc)

    return body


# ---------------------------------------------------------------------------
# POST /embedding/download-local
# ---------------------------------------------------------------------------


class DownloadLocalRequest(BaseModel):
    """本地模型下载请求体（同时支持 modelName 和 model_name）。"""

    model_config = {"populate_by_name": True}
    model_name: str = Field(alias="modelName")


@router.post(
    "/download-local",
    summary="触发本地模型下载",
    description="后台异步下载本地 embedding 模型，不阻塞请求。",
)
async def download_local_model(
    body: DownloadLocalRequest,
    request: Request,
) -> dict:
    """触发本地 fastembed 模型下载。

    Args:
        body: 包含 model_name 字段的请求体
        request: FastAPI 请求对象
    """
    if not body.model_name or not body.model_name.strip():
        raise HTTPException(
            status_code=400,
            detail="model_name is required and cannot be empty",
        )

    manager = getattr(request.app.state, "embedding_manager", None)
    if manager is None:
        raise HTTPException(
            status_code=503,
            detail="EmbeddingManager not available.",
        )

    # 从请求体获取模型名称，而不是从全局配置读取
    from ...config.config import EmbeddingConfig

    config = EmbeddingConfig(provider="local", local_model=body.model_name)

    await manager.trigger_local_model_download(config)
    return {"message": "Download started", "model": body.model_name}


# ---------------------------------------------------------------------------
# GET /embedding/download-status
# ---------------------------------------------------------------------------


@router.get(
    "/download-status",
    response_model=DownloadState,
    summary="查询本地模型下载进度",
    description="轮询下载状态，status 取值：idle / downloading / done / failed。",
)
async def get_download_status(request: Request) -> DownloadState:
    """返回本地模型下载进度。"""
    manager = getattr(request.app.state, "embedding_manager", None)
    if manager is None:
        return DownloadState()
    return manager.get_download_state()


# ---------------------------------------------------------------------------
# POST /embedding/delete-local-model
# ---------------------------------------------------------------------------


class DeleteLocalModelRequest(BaseModel):
    """删除本地 embedding 模型缓存请求体。"""

    model_config = {"populate_by_name": True}
    model_name: str = Field(alias="modelName")


@router.post(
    "/delete-local-model",
    summary="删除本地 embedding 模型缓存",
    description="删除 fastembed 缓存的模型目录，并重置下载状态为 idle。",
)
async def delete_local_model(
    body: DeleteLocalModelRequest,
    request: Request,
) -> dict:
    if not body.model_name or not body.model_name.strip():
        raise HTTPException(status_code=400, detail="modelName is required")

    manager = getattr(request.app.state, "embedding_manager", None)
    if manager is None:
        raise HTTPException(status_code=503, detail="EmbeddingManager not available.")

    # Safety: prevent deleting the currently activated local embedding model.
    # Otherwise the process may still be using it for embedding (memory vector search),
    # and you end up with confusing UX.
    try:
        active_local_server = getattr(manager, "local_server", None)
        if (
            manager.is_ready
            and active_local_server is not None
            and getattr(active_local_server, "model_name", None) == body.model_name
        ):
            raise HTTPException(
                status_code=409,
                detail="This embedding model is currently active. Switch to another model (or provider) and save, then delete again.",
            )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Failed to check active local embedding model: %s", exc)

    cache_dir = get_fastembed_model_cache_dir(body.model_name)
    if cache_dir is None:
        raise HTTPException(
            status_code=400,
            detail="Unable to resolve fastembed cache dir for the given model.",
        )

    deleted = False
    removed_path: str | None = None
    try:
        if cache_dir.exists():
            # Safety: only delete within the embedding cache root
            root = cache_dir.parent
            if str(cache_dir).startswith(str(root)):
                shutil.rmtree(cache_dir, ignore_errors=True)
                deleted = True
                removed_path = str(cache_dir)
    finally:
        # 无论删除是否成功，都把 UI 状态重置，避免前端继续显示 done
        await manager.reset_download_state()

    return {
        "message": "Local embedding model cache deleted",
        "model": body.model_name,
        "deleted": deleted,
        "removed_path": removed_path,
    }
