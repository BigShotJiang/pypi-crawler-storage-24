"""Checkpointer implementations."""
