"""Tests for ContextManager.render_hard_limited() and ContextBudgetExceeded (v4.2.0)."""

import pytest
from antaris_context import ContextManager, ContextBudgetExceeded


# ---------------------------------------------------------------------------
# ContextBudgetExceeded exception
# ---------------------------------------------------------------------------

class TestContextBudgetExceeded:
    def test_attributes(self):
        exc = ContextBudgetExceeded(used=500, budget=100)
        assert exc.used == 500
        assert exc.budget == 100

    def test_message(self):
        exc = ContextBudgetExceeded(used=500, budget=100)
        msg = str(exc)
        assert "500" in msg
        assert "100" in msg

    def test_is_exception(self):
        exc = ContextBudgetExceeded(used=1, budget=2)
        assert isinstance(exc, Exception)

    def test_importable_from_top_level(self):
        from antaris_context import ContextBudgetExceeded as _CBE
        assert _CBE is ContextBudgetExceeded


# ---------------------------------------------------------------------------
# render_hard_limited() — success cases
# ---------------------------------------------------------------------------

class TestRenderHardLimitedSuccess:
    def test_empty_context_within_budget(self):
        cm = ContextManager(total_budget=8000)
        # No turns added → render returns empty list → 0 tokens → always fits
        result = cm.render_hard_limited(budget_tokens=10)
        assert isinstance(result, list)
        assert result == []

    def test_single_turn_within_budget(self):
        cm = ContextManager(total_budget=8000)
        cm.add_turn("user", "Hello")
        # 5 chars → ~1 token → fits within 1000
        result = cm.render_hard_limited(budget_tokens=1000)
        assert len(result) == 1
        assert result[0]["role"] == "user"
        assert result[0]["content"] == "Hello"

    def test_multiple_turns_within_budget(self):
        cm = ContextManager(total_budget=8000)
        cm.add_turn("user", "What is the capital of France?")
        cm.add_turn("assistant", "The capital of France is Paris.")
        cm.add_turn("user", "Thank you!")
        result = cm.render_hard_limited(budget_tokens=5000)
        assert len(result) == 3

    def test_system_prompt_within_budget(self):
        cm = ContextManager(total_budget=8000)
        cm.add_turn("user", "Hi")
        result = cm.render_hard_limited(
            budget_tokens=5000,
        )
        # system prompt in render() is optional; at least user turn present
        assert any(m["role"] == "user" for m in result)

    def test_returns_list_of_dicts(self):
        cm = ContextManager(total_budget=8000)
        cm.add_turn("user", "Test message for hard budget")
        result = cm.render_hard_limited(budget_tokens=10000)
        assert isinstance(result, list)
        for msg in result:
            assert "role" in msg
            assert "content" in msg

    def test_trims_oldest_to_fit(self):
        """When over budget, oldest non-system turns should be removed first."""
        cm = ContextManager(total_budget=8000)
        # Add two turns — first will be older
        cm.add_turn("user", "A" * 400)      # ~100 tokens
        cm.add_turn("assistant", "B" * 400)  # ~100 tokens

        # Budget allows only one turn (~100 tokens = 400 chars / 4)
        # With a budget of ~110 tokens (440 chars), only the newer turn should survive
        result = cm.render_hard_limited(budget_tokens=110)
        # Either fits fine (both or just assistant) — just ensure no exception raised
        assert isinstance(result, list)


# ---------------------------------------------------------------------------
# render_hard_limited() — over-budget cases
# ---------------------------------------------------------------------------

class TestRenderHardLimitedOverBudget:
    def _system_heavy_cm(self) -> ContextManager:
        """ContextManager with a large system prompt + user turns.
        
        The system message alone (~200 tokens) exceeds the small budgets
        used in the over-budget tests.  System turns are never trimmed,
        so the exception must be raised.
        """
        cm = ContextManager(total_budget=8000)
        cm.add_turn("system", "S" * 800)    # ~200 tokens — cannot be trimmed
        cm.add_turn("user", "A" * 400)      # ~100 tokens — can be trimmed
        cm.add_turn("assistant", "B" * 400)  # ~100 tokens — can be trimmed
        return cm

    def test_raises_context_budget_exceeded(self):
        cm = self._system_heavy_cm()
        with pytest.raises(ContextBudgetExceeded):
            cm.render_hard_limited(budget_tokens=1)  # system alone > 1 token

    def test_exception_carries_used_attribute(self):
        cm = self._system_heavy_cm()
        with pytest.raises(ContextBudgetExceeded) as exc_info:
            cm.render_hard_limited(budget_tokens=1)
        assert exc_info.value.used > 0

    def test_exception_carries_budget_attribute(self):
        cm = self._system_heavy_cm()
        with pytest.raises(ContextBudgetExceeded) as exc_info:
            cm.render_hard_limited(budget_tokens=1)
        assert exc_info.value.budget == 1

    def test_exception_used_geq_budget(self):
        cm = self._system_heavy_cm()
        with pytest.raises(ContextBudgetExceeded) as exc_info:
            cm.render_hard_limited(budget_tokens=1)
        exc = exc_info.value
        assert exc.used >= exc.budget

    def test_system_turn_cannot_be_trimmed(self):
        """A system-only context that exceeds budget should still raise."""
        cm = ContextManager(total_budget=8000)
        # Large system message: ~200 tokens — system turns are never trimmed
        cm.add_turn("system", "S" * 800)

        with pytest.raises(ContextBudgetExceeded):
            cm.render_hard_limited(budget_tokens=1)
