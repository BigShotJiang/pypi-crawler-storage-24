"""Integration tests module."""
