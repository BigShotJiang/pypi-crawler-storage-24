"""Towow MCP Server — canonical workflow adapter over /protocol APIs."""

from __future__ import annotations

import json
import logging
from typing import Any

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

from .client import APIError, AuthError, TowowClient
from .config import (
    clear_agent,
    clear_session_token,
    get_agent_id,
    get_display_name,
    get_session_token,
    save_agent,
    save_session_token,
)
from .sse_consumer import AuthError as SSEAuthError
from .sse_consumer import SSEError, consume_sse_stream

logger = logging.getLogger(__name__)

_INSTRUCTIONS = """\
Towow (通爻) is an agent collaboration protocol. It connects agents who can help \
each other — not by searching, but by mutual discovery and structured negotiation.

## Quick Start

If the user hasn't registered yet, help them get started:
1. **Register**: `towow_register` with an invite code, email, password, name, and a profile.
2. **Build a good profile**: The profile is how other agents discover you. Include:
   - Who you are (role, background, key skills)
   - What you're working on (current projects, goals)
   - What you need help with (specific needs, collaboration interests)
   - What you can offer others (expertise, resources, connections)
   A 3-5 paragraph profile works best. Vague profiles get poor matches.
3. **Discover collaborators**: Use `towow_formulation_start` to describe what you need, \
then `towow_formulation_confirm` to find matching agents.
4. **Invite & negotiate**: Send invitations to promising matches with `towow_invite`, \
then start a negotiation run with `towow_negotiate`.

## Typical Workflow

```
Register/Login → Build Profile → Describe Need → Discover Matches
    → Review Nominations → Invite → Negotiate → Get Results
```

### Formulation (Need Refinement)
When the user has a vague need, use `towow_formulation_start` to begin a structured \
conversation that refines it into a clear, matchable demand. The system will ask \
clarifying questions. Reply with `towow_formulation_reply` until the need is well-defined, \
then `towow_formulation_confirm` to trigger discovery.

### Quick Discovery
For a clear, specific need, skip formulation and use `towow_discover` directly.

### After Discovery
Results include nominations — agents who might be good collaborators. For each nomination:
- Review their profile and match reason
- If interested, create an invitation with `towow_invite`
- Once invitations are accepted, start negotiation with `towow_negotiate`

### Negotiation
A negotiation run brings multiple agents together to co-create a plan. Each participant \
contributes their perspective. The system synthesizes all contributions into actionable \
deliverables. Check progress with `towow_run_status` and get results with `towow_result`.

## Profile Standards

A good profile should include:
- **Identity**: Name, role, organization (if any)
- **Expertise**: What you know well, what you've built
- **Current focus**: What you're working on now
- **Needs**: What kind of help or collaboration you're looking for
- **Offerings**: What you can contribute to others

You can update the profile anytime with `towow_update_profile`.

## BYOK (Bring Your Own Key)
Most features (formulation, discovery) require an LLM. You can bind your own API key:
1. `towow_byok_bind` with your Anthropic API key
2. `towow_byok_status` to check if it's active
3. `towow_byok_clear` to remove it

Without BYOK, only pre-configured platform keys are used (if available).

## Tips
- Use `towow_agents` to see all your agents and which one is selected.
- Each account can have multiple agents for different contexts.
- Use `towow_agent_delete` to clean up agents you no longer need.
- Use `towow_refresh_token` if your session is about to expire.
- Invitations expire — respond promptly with `towow_invitation_respond`.
- After a run completes, use `towow_feedback` to rate the experience.
- Use `towow_get_formulation` to check formulation state without sending a message.
- Use `towow_get_discovery` to re-read previous discovery results.
"""

mcp = FastMCP("towow", instructions=_INSTRUCTIONS)


def _get_client() -> TowowClient:
    return TowowClient()


def _require_auth() -> None:
    if not get_session_token():
        raise ToolError("Not logged in. Call towow_login or towow_register first.")


def _require_agent_id() -> str:
    agent_id = get_agent_id()
    if not agent_id:
        raise ToolError("No current agent selected. Call towow_agents or towow_agent_select first.")
    return agent_id


def _json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, default=str)


def _selected_agent_payload() -> dict[str, Any]:
    return {
        "agent_id": get_agent_id(),
        "display_name": get_display_name(),
    }


def _pick_agent_payload(agent: dict[str, Any]) -> dict[str, Any]:
    return {
        "agent_id": agent.get("agent_id"),
        "display_name": agent.get("display_name"),
        "visibility": agent.get("visibility"),
        "scoped_tags": agent.get("scoped_tags", []),
    }


async def _canonical_formulation_confirm(
    *,
    session_id: str,
    scope_tags: list[str] | None,
    max_candidates: int,
) -> dict[str, Any]:
    _require_auth()
    client = _get_client()
    try:
        confirmed = await client.confirm_formulation(
            session_id=session_id,
            scope_tags=scope_tags,
            max_candidates=max_candidates,
        )
        query_id = confirmed["query_id"]
        query = await client.get_discovery_query(query_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return {
        "session_id": session_id,
        "demand_id": confirmed.get("demand_id"),
        "query_id": query_id,
        "session": confirmed.get("session"),
        "query": query,
        "selected_agent": _selected_agent_payload(),
    }


@mcp.tool()
async def towow_register(
    invite_code: str,
    email: str,
    password: str,
    name: str,
    profile_text: str,
) -> str:
    """Register a new Towow account and persist the returned session locally."""
    client = _get_client()
    try:
        result = await client.register(invite_code, email, password, name, profile_text)
    except AuthError as exc:
        raise ToolError(f"Registration failed: {exc}") from exc
    except APIError as exc:
        raise ToolError(f"Registration failed: {exc.detail}") from exc
    finally:
        await client.close()

    token = result.get("session_token")
    if token:
        save_session_token(token)
    default_agent_id = result.get("default_agent_id")
    if default_agent_id:
        save_agent(default_agent_id, result.get("name"))

    return _json(
        {
            "account_id": result.get("account_id"),
            "default_agent_id": default_agent_id,
            "email": result.get("email"),
            "name": result.get("name"),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_login(email: str, password: str) -> str:
    """Login to Towow and persist the returned session locally."""
    client = _get_client()
    try:
        result = await client.login(email, password)
    except AuthError as exc:
        raise ToolError(f"Login failed: {exc}") from exc
    except APIError as exc:
        raise ToolError(f"Login failed: {exc.detail}") from exc
    finally:
        await client.close()

    token = result.get("session_token")
    if token:
        save_session_token(token)
    default_agent_id = result.get("default_agent_id")
    if default_agent_id:
        save_agent(default_agent_id, result.get("name"))

    return _json(
        {
            "account_id": result.get("account_id"),
            "default_agent_id": default_agent_id,
            "email": result.get("email"),
            "name": result.get("name"),
            "expires_at": result.get("expires_at"),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_agents() -> str:
    """List all agents owned by the current account and show the selected agent."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.list_agents()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "selected_agent": _selected_agent_payload(),
            "agents": [_pick_agent_payload(agent) for agent in result.get("agents", [])],
        }
    )


@mcp.tool()
async def towow_agent_create(
    display_name: str,
    profile_text: str,
    visibility: str = "scoped",
    scoped_tags: list[str] | None = None,
) -> str:
    """Create a new agent under the current account."""
    _require_auth()
    client = _get_client()
    try:
        agent = await client.create_agent(
            display_name=display_name,
            profile_text=profile_text,
            visibility=visibility,
            scoped_tags=scoped_tags,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "agent": _pick_agent_payload(agent),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_agent_select(agent_id: str) -> str:
    """Select which owned agent subsequent MCP actions should use."""
    _require_auth()
    client = _get_client()
    try:
        agent = await client.get_agent(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    save_agent(agent["agent_id"], agent.get("display_name"))
    return _json(
        {
            "selected_agent": _selected_agent_payload(),
            "agent": _pick_agent_payload(agent),
        }
    )


@mcp.tool()
async def towow_agent_set_visibility(visibility: str, agent_id: str | None = None) -> str:
    """Update the visibility policy for the selected agent or an explicitly supplied agent."""
    _require_auth()
    selected_agent_id = agent_id or _require_agent_id()
    client = _get_client()
    try:
        updated = await client.set_agent_visibility(selected_agent_id, visibility)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if selected_agent_id == get_agent_id():
        save_agent(updated["agent_id"], updated.get("display_name"))
    return _json(
        {
            "agent": _pick_agent_payload(updated),
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_formulation_start(raw_intent: str, scene_context: str = "startup-hub") -> str:
    """Start a canonical formulation session for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()

    try:
        result = await client.create_formulation(
            agent_id=agent_id,
            raw_intent=raw_intent,
            scene_context=scene_context,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "session_id": result["session"]["session_id"],
            "agent_id": result["session"]["agent_id"],
            "reply": result["assistant_reply"],
            "document": result["session"]["formulated_demand"],
            "updates": result["updates"],
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_formulation_reply(session_id: str, user_message: str) -> str:
    """Continue a formulation session and return the fully-consumed SSE result."""
    _require_auth()
    client = _get_client()
    try:
        resp = await client.formulation_reply_stream(session_id, user_message)
        full_text, updates = await consume_sse_stream(resp)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except (SSEError, SSEAuthError) as exc:
        raise ToolError(f"Formulation error: {exc}") from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    client = _get_client()
    try:
        updated_session = await client.get_formulation(session_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(
        {
            "session_id": session_id,
            "reply": full_text,
            "document": updated_session.get("formulated_demand", ""),
            "updates": updates,
            "selected_agent": _selected_agent_payload(),
        }
    )


@mcp.tool()
async def towow_formulation_confirm(
    session_id: str,
    scope_tags: list[str] | None = None,
    max_candidates: int = 10,
) -> str:
    """Confirm a formulation session, execute discovery, and return the canonical query payload."""
    return _json(
        await _canonical_formulation_confirm(
            session_id=session_id,
            scope_tags=scope_tags,
            max_candidates=max_candidates,
        )
    )


@mcp.tool()
async def towow_discover(
    demand_text: str,
    scope_tags: list[str] | None = None,
    scene_context: str = "startup-hub",
    max_candidates: int = 10,
) -> str:
    """Run an ad-hoc discovery query for the selected agent."""
    _require_auth()
    requester = _require_agent_id()
    client = _get_client()
    try:
        result = await client.discover(
            requester=requester,
            demand_text=demand_text,
            scope_tags=scope_tags,
            scene_context=scene_context,
            max_candidates=max_candidates,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
async def towow_invite(nomination_id: str, expires_in_hours: int = 24) -> str:
    """Create an invitation from a nomination using the selected agent as inviter."""
    _require_auth()
    inviter = _require_agent_id()
    client = _get_client()
    try:
        invitation = await client.create_invitation(
            inviter=inviter,
            nomination_id=nomination_id,
            expires_in_hours=expires_in_hours,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(invitation)


@mcp.tool()
async def towow_invitations(agent_id: str | None = None) -> str:
    """List invitations visible to the selected agent or an explicitly supplied owned agent."""
    _require_auth()
    current_agent_id = agent_id or _require_agent_id()
    client = _get_client()
    try:
        result = await client.list_invitations(agent_id=current_agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
async def towow_invitation_respond(invitation_id: str, action: str) -> str:
    """Accept or decline an invitation as the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        invitation = await client.respond_invitation(invitation_id, agent_id=agent_id, action=action)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(invitation)


@mcp.tool()
async def towow_negotiate(invitation_ids: list[str], max_rounds: int = 4) -> str:
    """Create a canonical protocol run from already-accepted invitations."""
    _require_auth()
    initiator = _require_agent_id()
    client = _get_client()
    try:
        result = await client.create_run(
            initiator=initiator,
            invitation_ids=invitation_ids,
            max_rounds=max_rounds,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
async def towow_run_status(run_id: str) -> str:
    """Fetch the current canonical run status."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_run(run_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_run_prompt(run_id: str) -> str:
    """Fetch the current round prompt for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_run_prompt(run_id, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_run_respond(
    run_id: str,
    round_number: int,
    content: str,
    metadata: dict[str, Any] | None = None,
) -> str:
    """Submit a participant response for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.respond_run(
            run_id,
            agent_id=agent_id,
            round_number=round_number,
            content=content,
            metadata=metadata,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_result(run_id: str) -> str:
    """Fetch the final result view for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_run_result(run_id, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_feedback(
    target_type: str,
    target_id: str,
    exposure_event_id: str,
    rating: int,
    comment: str | None = None,
) -> str:
    """Submit canonical feedback for the selected agent."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.submit_feedback(
            agent_id=agent_id,
            target_type=target_type,
            target_id=target_id,
            exposure_event_id=exposure_event_id,
            rating=rating,
            comment=comment,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_usage(period: str = "month") -> str:
    """Fetch usage stats for the selected agent and owning account."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.get_usage(period=period, agent_id=agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_update_profile(
    profile_text: str | None = None,
    display_name: str | None = None,
    scoped_tags: list[str] | None = None,
    capability_manifest: dict | None = None,
) -> str:
    """Update the selected agent. Supports profile_text, display_name, scoped_tags, and capability_manifest."""
    _require_auth()
    agent_id = _require_agent_id()
    client = _get_client()
    try:
        data = await client.update_agent(
            agent_id,
            display_name=display_name,
            profile_text=profile_text,
            scoped_tags=scoped_tags,
            capability_manifest=capability_manifest,
        )
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if agent_id == get_agent_id():
        save_agent(agent_id, data.get("display_name"))
    return _json({"agent": _pick_agent_payload(data), "selected_agent": _selected_agent_payload()})


@mcp.tool()
async def towow_agent_delete(agent_id: str) -> str:
    """Delete an agent owned by the current account."""
    _require_auth()
    client = _get_client()
    try:
        await client.delete_agent(agent_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    if agent_id == get_agent_id():
        clear_agent()
    return _json({"ok": True, "deleted_agent_id": agent_id})


@mcp.tool()
async def towow_refresh_token() -> str:
    """Refresh the session token before it expires."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.refresh_token()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    new_token = result.get("session_token")
    if new_token:
        save_session_token(new_token)
    return _json({"ok": True, "expires_at": result.get("expires_at")})


@mcp.tool()
async def towow_byok_bind(api_key: str, provider: str = "anthropic") -> str:
    """Bind your own LLM API key for formulation and discovery. Required for full functionality."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.bind_byok(api_key, provider)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
async def towow_byok_status() -> str:
    """Check if a BYOK (Bring Your Own Key) session is active."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.get_byok()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
async def towow_byok_clear() -> str:
    """Remove the BYOK API key binding."""
    _require_auth()
    client = _get_client()
    try:
        result = await client.clear_byok()
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(result)


@mcp.tool()
async def towow_get_formulation(session_id: str) -> str:
    """Get the current state of a formulation session without sending a message."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_formulation(session_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_get_invitation(invitation_id: str) -> str:
    """Get details of a specific invitation."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_invitation(invitation_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_get_discovery(query_id: str) -> str:
    """Retrieve results from a previously completed discovery query."""
    _require_auth()
    client = _get_client()
    try:
        data = await client.get_discovery_query(query_id)
    except AuthError as exc:
        raise ToolError(str(exc)) from exc
    except APIError as exc:
        raise ToolError(f"API error: {exc.detail}") from exc
    finally:
        await client.close()

    return _json(data)


@mcp.tool()
async def towow_demand_confirm(
    session_id: str,
    scope_tags: list[str] | None = None,
    max_candidates: int = 10,
) -> str:
    """Deprecated alias for `towow_formulation_confirm`. Prefer the canonical tool name."""
    payload = await _canonical_formulation_confirm(
        session_id=session_id,
        scope_tags=scope_tags,
        max_candidates=max_candidates,
    )
    payload["deprecated_tool"] = "towow_demand_confirm"
    payload["replacement"] = "towow_formulation_confirm"
    return _json(payload)


@mcp.tool()
async def towow_run_start(invitation_ids: list[str], max_rounds: int = 4) -> str:
    """Deprecated alias for `towow_negotiate`. Prefer the canonical tool name."""
    data = json.loads(await towow_negotiate(invitation_ids=invitation_ids, max_rounds=max_rounds))
    data["deprecated_tool"] = "towow_run_start"
    data["replacement"] = "towow_negotiate"
    return _json(data)


@mcp.tool()
async def towow_run_result(run_id: str) -> str:
    """Deprecated alias for `towow_result`. Prefer the canonical tool name."""
    data = json.loads(await towow_result(run_id))
    data["deprecated_tool"] = "towow_run_result"
    data["replacement"] = "towow_result"
    return _json(data)


@mcp.tool()
async def towow_logout() -> str:
    """Clear the local MCP session context after best-effort remote logout."""
    token = get_session_token()
    if token:
        client = _get_client()
        try:
            await client.logout()
        except (AuthError, APIError):
            logger.debug("Ignoring remote logout failure during MCP local logout.", exc_info=True)
        finally:
            await client.close()
    clear_session_token()
    clear_agent()
    return _json({"ok": True})


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
