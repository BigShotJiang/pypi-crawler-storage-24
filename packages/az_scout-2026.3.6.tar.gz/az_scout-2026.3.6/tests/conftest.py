"""Shared test fixtures for az-scout tests."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from az_scout.app import app


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Ensure E2E tests always run after unit tests.

    The E2E server fixture applies session-scoped patches on ``azure_api``
    and starts a uvicorn event loop.  Running E2E tests last prevents those
    patches and the loop from interfering with unit-test mocks.
    """
    unit: list[pytest.Item] = []
    e2e: list[pytest.Item] = []
    for item in items:
        (e2e if "e2e" in str(item.path) else unit).append(item)
    items[:] = unit + e2e


@pytest.fixture()
def client():
    """Create a FastAPI test client with mocked Azure credentials.

    ``raise_server_exceptions=False`` ensures unhandled exceptions are
    processed by the global ``@app.exception_handler(Exception)`` middleware
    just like in production, instead of being re-raised by the test client.
    """
    with (
        patch("az_scout.azure_api.preload_discovery"),
        TestClient(app, raise_server_exceptions=False) as c,
    ):
        yield c


@pytest.fixture(autouse=True)
def _sync_arm_requests_mock():
    """Ensure ``_arm.requests`` uses the same mock as ``azure_api.requests``.

    Tests patch ``az_scout.azure_api.requests.get`` (the re-exported module in
    ``__init__.py``).  The ``_arm`` module has its own ``import requests``, so
    we alias it to the same object so mocks flow through.
    """
    import az_scout.azure_api as api_pkg
    import az_scout.azure_api._arm as arm_mod

    arm_mod.requests = api_pkg.requests  # type: ignore[attr-defined]
    yield


@pytest.fixture(autouse=True)
def _mock_credential():
    """Prevent real Azure credential calls in every test."""
    from az_scout.azure_api._auth import _token_cache

    _token_cache.clear()
    mock_token = MagicMock()
    mock_token.token = "fake-token"
    mock_token.expires_on = 9999999999  # far future
    with patch("az_scout.azure_api._auth.credential") as cred:
        cred.get_token.return_value = mock_token
        yield cred


@pytest.fixture(autouse=True)
def _clear_usage_cache():
    """Clear the compute usages cache between tests."""
    from az_scout.azure_api import _usage_cache

    _usage_cache.clear()
    yield
    _usage_cache.clear()


@pytest.fixture(autouse=True)
def _clear_discovery_cache():
    """Clear the discovery cache between tests."""
    from az_scout.azure_api import _discovery_cache

    _discovery_cache.clear()
    yield
    _discovery_cache.clear()


@pytest.fixture(autouse=True)
def _clear_spot_cache():
    """Clear the spot placement scores cache between tests."""
    from az_scout.azure_api import _spot_cache

    _spot_cache.clear()
    yield
    _spot_cache.clear()


@pytest.fixture(autouse=True)
def _clear_price_cache():
    """Clear the retail prices cache between tests."""
    from az_scout.azure_api import _detail_price_cache, _price_cache

    _price_cache.clear()
    _detail_price_cache.clear()
    yield
    _price_cache.clear()
    _detail_price_cache.clear()


@pytest.fixture(autouse=True)
def _clear_sku_profile_cache():
    """Clear the SKU profile cache between tests."""
    from az_scout.azure_api import _sku_profile_cache

    _sku_profile_cache.clear()
    yield
    _sku_profile_cache.clear()


@pytest.fixture(autouse=True)
def _clear_sku_list_cache():
    """Clear the SKU list cache between tests."""
    from az_scout.azure_api import _sku_list_cache

    _sku_list_cache.clear()
    yield
    _sku_list_cache.clear()
