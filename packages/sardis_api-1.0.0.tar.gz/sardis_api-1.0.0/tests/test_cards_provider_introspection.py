from __future__ import annotations

from types import SimpleNamespace

from fastapi import FastAPI
from fastapi.testclient import TestClient

from sardis_api.authz import Principal, require_principal
from sardis_api.routers.cards import create_cards_router


class _NoopCardRepo:
    pass


class _WalletRepo:
    async def get(self, wallet_id: str):
        return SimpleNamespace(agent_id="agent_1")


class _AgentRepo:
    async def get(self, agent_id: str):
        return SimpleNamespace(owner_id="org_demo")


class _ResolverProvider:
    name = "org_router(lithic)"

    async def resolve_provider_for_wallet(self, wallet_id: str) -> str:
        return "rain"


class _ASAHandler:
    def security_policy(self) -> dict:
        return {
            "fail_closed_on_card_lookup_error": True,
            "fail_closed_on_subscription_error": True,
            "blocked_mcc_count": 2,
            "blocked_mccs": ["4829", "7995"],
        }


def _principal() -> Principal:
    return Principal(
        kind="api_key",
        organization_id="org_demo",
        scopes=["*"],
        api_key=None,
    )


def _build_app() -> FastAPI:
    app = FastAPI()
    app.dependency_overrides[require_principal] = _principal

    provider_wrapper = SimpleNamespace(_provider=_ResolverProvider())
    router = create_cards_router(
        card_repo=_NoopCardRepo(),
        card_provider=provider_wrapper,
        wallet_repo=_WalletRepo(),
        agent_repo=_AgentRepo(),
    )
    app.include_router(router, prefix="/api/v2/cards")
    return app


def _build_app_with_asa_handler() -> FastAPI:
    app = FastAPI()
    app.dependency_overrides[require_principal] = _principal
    provider_wrapper = SimpleNamespace(_provider=_ResolverProvider())
    router = create_cards_router(
        card_repo=_NoopCardRepo(),
        card_provider=provider_wrapper,
        wallet_repo=_WalletRepo(),
        agent_repo=_AgentRepo(),
        asa_handler=_ASAHandler(),
    )
    app.include_router(router, prefix="/api/v2/cards")
    return app


def test_cards_provider_readiness_endpoint():
    app = _build_app()
    client = TestClient(app)

    response = client.get("/api/v2/cards/providers/readiness")

    assert response.status_code == 200
    payload = response.json()
    assert payload["active_provider"] == "org_router(lithic)"
    issuer_names = {item["name"] for item in payload["issuers"]}
    assert "stripe_issuing" in issuer_names
    assert "lithic" in issuer_names


def test_cards_provider_contracts_endpoint_reports_warm_mode(monkeypatch):
    monkeypatch.setenv("SARDIS_ENVIRONMENT", "production")
    monkeypatch.delenv("SARDIS_ISSUING_LIVE_ENABLED", raising=False)

    app = _build_app()
    client = TestClient(app)

    response = client.get("/api/v2/cards/providers/contracts")
    assert response.status_code == 200
    payload = response.json()
    assert payload["warm_mode"] is True
    assert payload["issuing_live_enabled"] is False
    assert payload["adapter_methods"]["create_cardholder"] is True
    assert payload["adapter_methods"]["create_virtual_card"] is True
    assert payload["adapter_methods"]["authorize"] is True


def test_cards_provider_resolve_endpoint():
    app = _build_app()
    client = TestClient(app)

    response = client.get("/api/v2/cards/providers/resolve", params={"wallet_id": "wallet_1"})

    assert response.status_code == 200
    payload = response.json()
    assert payload["wallet_id"] == "wallet_1"
    assert payload["provider"] == "rain"


def test_cards_asa_security_policy_endpoint():
    app = _build_app_with_asa_handler()
    client = TestClient(app)

    response = client.get("/api/v2/cards/asa/security-policy")

    assert response.status_code == 200
    payload = response.json()
    assert payload["fail_closed_on_card_lookup_error"] is True
    assert payload["fail_closed_on_subscription_error"] is True
    assert payload["blocked_mcc_count"] == 2
    assert payload["blocked_mccs"] == ["4829", "7995"]
