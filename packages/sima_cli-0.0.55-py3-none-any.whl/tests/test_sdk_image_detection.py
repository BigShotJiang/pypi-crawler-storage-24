import unittest
from unittest.mock import patch

from sima_cli.sdk.utils import extract_short_name, get_local_sima_images


SAMPLE_DOCKER_IMAGES = """elxr:latest
783709528641.dkr.ecr.us-west-2.amazonaws.com/vdp-cli/elxr:2.0.0_Palette_SDK_master_B240
783709528641.dkr.ecr.us-west-2.amazonaws.com/vdp-cli/modelsdk:2.0.0_Palette_SDK_master_B240
ghcr.io/sima-neat/elxr:latest
"""


class TestSdkImageDetection(unittest.TestCase):
    @patch("sima_cli.sdk.utils.subprocess.check_output", return_value=SAMPLE_DOCKER_IMAGES)
    def test_get_local_sima_images_includes_ghcr_elxr(self, _mock_check_output):
        images = get_local_sima_images()
        self.assertIn("ghcr.io/sima-neat/elxr:latest", images)
        self.assertIn("elxr:latest", images)
        self.assertIn(
            "783709528641.dkr.ecr.us-west-2.amazonaws.com/vdp-cli/elxr:2.0.0_Palette_SDK_master_B240",
            images,
        )

    def test_extract_short_name_for_ghcr_elxr(self):
        self.assertEqual(extract_short_name("ghcr.io/sima-neat/elxr:latest"), "elxr")

    def test_extract_short_name_for_ghcr_elxr_sdk_alias(self):
        self.assertEqual(extract_short_name("ghcr.io/sima-neat/elxr-sdk:latest"), "elxr")


if __name__ == "__main__":
    unittest.main()
