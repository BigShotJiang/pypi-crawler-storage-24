#!/usr/bin/env python3

import os
import ipaddress
import platform
import re
import shlex
import shutil
import socket
import subprocess
import sys
from pathlib import Path
from typing import List, Optional, Tuple
from rich.console import Console
from rich.panel import Panel

from sima_cli.sdk.preinstall import syscheck
from sima_cli.sdk.config import IMAGE_CONFIG

from sima_cli.sdk.utils import (
    create_config_json,
    find_available_ports,
    get_container_status,
    get_workspace,
    get_local_sima_images,
    prompt_image_selection,
    confirm_to_remove_exiting_container,
    sanitize_container_name,
    ensure_simasdkbridge_network,
    start_docker_container,
    bootstrap_devkit_container,
    print_section,
    extract_short_name,
    is_supported_devkit_image,
    check_os,
    detect_current_user,
)

# ─────────────────────────────────────────────
# Entrypoint for setup/start
# ─────────────────────────────────────────────
def is_container_running(name: str) -> bool:
    """Return True if the container is running."""
    try:
        status = subprocess.check_output(
            ["docker", "inspect", "-f", "{{.State.Running}}", name],
            text=True
        ).strip()
        return status == "true"
    except subprocess.CalledProcessError:
        return False

def _has_cmd(name: str) -> bool:
    return (
        subprocess.run(
            ["bash", "-lc", "command -v {} >/dev/null 2>&1".format(shlex.quote(name))],
            check=False,
        ).returncode
        == 0
    )


def _find_executable(name: str) -> Optional[str]:
    candidates = [
        shutil.which(name),
        f"/usr/sbin/{name}",
        f"/sbin/{name}",
        f"/usr/bin/{name}",
        f"/bin/{name}",
    ]
    for candidate in candidates:
        if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _linux_nfs_install_hint() -> str:
    distro_ids = set()
    os_release = Path("/etc/os-release")
    if os_release.exists():
        try:
            for line in os_release.read_text().splitlines():
                if "=" not in line:
                    continue
                key, value = line.split("=", 1)
                if key not in {"ID", "ID_LIKE"}:
                    continue
                distro_ids.update(part.strip().strip('"').lower() for part in value.split())
        except OSError:
            pass

    if {"ubuntu", "debian"} & distro_ids:
        return "Install it with: sudo apt-get install -y nfs-kernel-server"
    if {"fedora", "rhel", "centos", "rocky", "almalinux"} & distro_ids:
        return "Install it with: sudo dnf install -y nfs-utils"
    if "arch" in distro_ids:
        return "Install it with: sudo pacman -S nfs-utils"
    return "Install your host NFS server package and ensure `exportfs` is on the root PATH."


def _install_linux_nfs_server() -> None:
    commands = []
    if _has_cmd("apt-get"):
        commands = [
            ["sudo", "apt-get", "update"],
            ["sudo", "apt-get", "install", "-y", "nfs-kernel-server"],
        ]
    elif _has_cmd("dnf"):
        commands = [["sudo", "dnf", "install", "-y", "nfs-utils"]]
    elif _has_cmd("yum"):
        commands = [["sudo", "yum", "install", "-y", "nfs-utils"]]
    elif _has_cmd("zypper"):
        commands = [["sudo", "zypper", "install", "-y", "nfs-kernel-server"]]
    elif _has_cmd("pacman"):
        commands = [["sudo", "pacman", "-S", "--noconfirm", "nfs-utils"]]
    else:
        raise RuntimeError(
            "Linux NFS server tooling is not installed and no supported package manager was detected. "
            f"{_linux_nfs_install_hint()}"
        )

    print("ℹ️  `exportfs` was not found. Installing host NFS server tooling...")
    for command in commands:
        subprocess.run(command, check=True)


def _is_linux_virtual_iface(iface: str) -> bool:
    prefixes = ("lo", "docker", "br-", "veth", "virbr", "tun", "tap", "wg", "zt", "tailscale", "vmnet", "vboxnet")
    return iface.startswith(prefixes)


def _detect_physical_ipv4s_macos() -> List[Tuple[str, str]]:
    try:
        out = subprocess.check_output(["ifconfig"], text=True)
    except Exception:
        return []

    found = []  # type: List[Tuple[str, str]]
    iface = ""
    status = ""
    inet = None  # type: Optional[str]
    is_physical = False

    def flush_current() -> None:
        if iface and is_physical and status == "active" and inet and not inet.startswith("127."):
            found.append((iface, inet))

    for line in out.splitlines():
        m = re.match(r"^([a-zA-Z0-9]+): flags=", line)
        if m:
            flush_current()
            iface = m.group(1)
            status = ""
            inet = None
            is_physical = iface.startswith("en")
            continue
        if not iface:
            continue
        s = line.strip()
        if s.startswith("status:"):
            status = s.split(":", 1)[1].strip()
        elif s.startswith("inet "):
            parts = s.split()
            if len(parts) >= 2:
                inet = parts[1]

    flush_current()
    return found


def _detect_physical_ipv4s_linux() -> List[Tuple[str, str]]:
    if not _has_cmd("ip"):
        return []
    try:
        out = subprocess.check_output(["ip", "-o", "-4", "addr", "show", "up", "scope", "global"], text=True)
    except Exception:
        return []

    found = []  # type: List[Tuple[str, str]]
    for line in out.splitlines():
        m = re.match(r"^\d+:\s+([^\s]+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)/\d+", line)
        if not m:
            continue
        iface, ip = m.group(1), m.group(2)
        if _is_linux_virtual_iface(iface):
            continue
        if iface.startswith(("en", "eth")):
            found.append((iface, ip))
    return found


def _detect_host_ip(devkit_ip: Optional[str]) -> Tuple[str, str, List[Tuple[str, str]]]:
    candidates = []  # type: List[Tuple[str, str]]
    if sys.platform == "darwin":
        candidates = _detect_physical_ipv4s_macos()
    elif sys.platform.startswith("linux"):
        candidates = _detect_physical_ipv4s_linux()

    # Prefer the source IP selected by the kernel for the actual DevKit route.
    # This avoids choosing the wrong NIC when the DevKit is reachable over a
    # non-en* interface on macOS (for example feth* or a VPN-backed route).
    if devkit_ip:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((devkit_ip, 80))
            routed_ip = s.getsockname()[0]
            if routed_ip and not routed_ip.startswith("127."):
                for iface, ip in candidates:
                    if ip == routed_ip:
                        return ip, iface, candidates
                return routed_ip, "auto", candidates
        except OSError:
            pass
        finally:
            s.close()

    if candidates:
        iface, ip = candidates[0]
        return ip, iface, candidates

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((devkit_ip or "8.8.8.8", 80))
        return s.getsockname()[0], "auto", []
    finally:
        s.close()


def _print_devkit_nfs_banner(workspace: str, devkit_ip: str, host_os: str) -> None:
    console = Console()
    platform_label = "macOS" if host_os == "darwin" else "Linux"
    console.print(
        Panel(
            "\n".join(
                [
                    "DevKit workspace sync is being enabled.",
                    f"The host workspace '{workspace}' will be shared over NFS so DevKit {devkit_ip} can access it.",
                    f"You may be prompted for your {platform_label} host administrator password to install or configure the host NFS service.",
                ]
            ),
            title="DevKit NFS Setup",
            border_style="yellow",
            expand=False,
        )
    )


def _configure_nfs_export(host_dir: Path, devkit_ip: Optional[str], host_os: str, host_ip: str) -> None:
    host_path = str(host_dir.resolve())
    if host_os == "darwin":
        uid = os.getuid()
        gid = os.getgid()
        if devkit_ip:
            line = f"{host_path} -alldirs -mapall={uid}:{gid} {devkit_ip}"
        else:
            iface = ipaddress.IPv4Interface(f"{host_ip}/24")
            network = str(iface.network.network_address)
            mask = str(iface.network.netmask)
            line = f"{host_path} -alldirs -mapall={uid}:{gid} -network {network} -mask {mask}"
        script = (
            "set -eu; "
            "touch /etc/exports; "
            f"tmpf=$(mktemp); awk -v p={shlex.quote(host_path)} '"
            "/^[[:space:]]*#/ || NF==0 { print; next } "
            "{ path=$1 } "
            "(path==p) || (index(path, p \"/\")==1) || (index(p, path \"/\")==1) { next } "
            "{ print }' /etc/exports > \"$tmpf\"; "
            f"echo {shlex.quote(line)} >> \"$tmpf\"; "
            "cp \"$tmpf\" /etc/exports; rm -f \"$tmpf\"; "
            "nfsd checkexports; nfsd restart"
        )
        subprocess.run(["sudo", "sh", "-c", script], check=True)
        return

    if host_os == "linux":
        exportfs_cmd = _find_executable("exportfs")
        if not exportfs_cmd:
            _install_linux_nfs_server()
            exportfs_cmd = _find_executable("exportfs")
        if not exportfs_cmd:
            raise RuntimeError(
                "Linux NFS server tooling install completed, but `exportfs` is still not available. "
                f"{_linux_nfs_install_hint()}"
            )
        systemctl_cmd = _find_executable("systemctl") or "systemctl"
        client = devkit_ip if devkit_ip else "*"
        line = f"{host_path} {client}(rw,sync,no_subtree_check,no_root_squash,insecure)"
        script = (
            "set -eu; mkdir -p /etc/exports.d; "
            f"echo {shlex.quote(line)} > /etc/exports.d/elxr-sdk.exports; "
            f"{shlex.quote(exportfs_cmd)} -ra; "
            f"({shlex.quote(systemctl_cmd)} restart nfs-server || "
            f"{shlex.quote(systemctl_cmd)} restart nfs-kernel-server || true)"
        )
        subprocess.run(["sudo", "sh", "-c", script], check=True)
        return

    raise RuntimeError("Host NFS setup is only implemented for macOS/Linux")


def _configure_smb_share_windows(host_dir: Path) -> None:
    share_name = "elxr_workspace"
    path = str(host_dir.resolve())
    ps = (
        "$name='{}'; $path='{}'; ".format(share_name, path)
        + "if (-not (Get-SmbShare -Name $name -ErrorAction SilentlyContinue)) { "
        + "New-SmbShare -Name $name -Path $path -FullAccess Everyone | Out-Null }; "
        + "Write-Output $name"
    )
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True)


def _setup_devkit_share(devkit_ip: str, workspace: str, selected_images: List[str]):
    if not devkit_ip:
        return {}
    if not any(is_supported_devkit_image(image) for image in selected_images):
        print("ℹ️  Ignoring --devkit because selected images do not match a supported DevKit pattern: ghcr.io/sima-neat-*-elxr* or elxr:latest.")
        return {}

    host_os = platform.system().lower()
    host_dir = Path(workspace)
    host_ip, auto_iface, auto_candidates = _detect_host_ip(devkit_ip)
    backend = "smb" if host_os.startswith("win") else "nfs"

    if backend == "nfs":
        _print_devkit_nfs_banner(workspace, devkit_ip, host_os)
        _configure_nfs_export(host_dir, devkit_ip, host_os, host_ip)
        print("✅ Host NFS export configured for workspace {} -> {}".format(workspace, devkit_ip))
    elif backend == "smb":
        _configure_smb_share_windows(host_dir)
        print("✅ Host SMB share configured for workspace {}".format(workspace))
    else:
        print("ℹ️  Host share setup skipped.")

    if auto_iface != "auto":
        print("ℹ️  Detected host IP for DevKit sync: {} (interface: {})".format(host_ip, auto_iface))
        if len(auto_candidates) > 1:
            others = ", ".join(["{}:{}".format(i, ip) for i, ip in auto_candidates[1:]])
            print("ℹ️  Multiple physical interfaces detected; using first. Others: {}".format(others))
    else:
        print("ℹ️  Detected host IP for DevKit sync: {} (auto)".format(host_ip))

    return {
        "devkit_ip": devkit_ip,
        "host_ip": host_ip,
        "workspace": workspace,
        "host_platform": host_os,
        "bootstrap_interactive": True,
    }


def setup_and_start(
    noninteractive: bool = False,
    start_only: bool = False,
    yes_to_all: bool = False,
    devkit_ip: str = "",
):
    """Main entry for SDK setup and container start."""

    console = Console()

    if not start_only:
        console.print(Panel("🔧 SiMa.ai SDK Setup", border_style="cyan", expand=False))
        ensure_simasdkbridge_network()
        syscheck(force_install=yes_to_all)

    images = get_local_sima_images()
    selected_images = prompt_image_selection(images, noninteractive)


    # Step 2: Check running containers
    print("\n🔍 Checking for running SDK containers...")
    container_statuses = get_container_status()

    if container_statuses:
        count = len(container_statuses)
        print(f"✅ Found {count} SDK container{'s' if count > 1 else ''}:")
        for cname, status in container_statuses.items():
            print(f"   • {cname:<30} | {status}")
    else:
        print("ℹ️  No Running SDK containers found.")

    # ──────────────────────────────────────────────
    # Start containers
    # ──────────────────────────────────────────────
    workspace = get_workspace(yes_to_all)
    uid = os.getuid() if hasattr(os, "getuid") else 900
    gid = os.getgid() if hasattr(os, "getgid") else 900
    devkit_env = _setup_devkit_share(devkit_ip, workspace, selected_images)
    
    for img in selected_images:
        container_name = sanitize_container_name(img)
        print_section(f"🔄 CONTAINER START SEQUENCE for {container_name}")
        existing_container = confirm_to_remove_exiting_container(container_name, yes_to_all)

        if existing_container == None:
            # Get image configuration
            config = IMAGE_CONFIG.get(extract_short_name(img), {"privileged": False, "port_mapping_required": False})

            # Dynamically allocate a free port if required
            port = find_available_ports(1)[0] if config["port_mapping_required"] else 0

            create_config_json(file_path="config.json", selected_images=selected_images, port=port)

            start_docker_container(
                uid=uid,
                gid=gid,
                port=port,
                workspace=workspace,
                image=img,
                privileged=config["privileged"],
                port_mapping_required=config["port_mapping_required"],
                devkit_env=devkit_env,
            )
        else:
            if not is_container_running(existing_container):
                subprocess.run(["docker", "start", existing_container], check=True)

            if devkit_env and is_supported_devkit_image(img):
                bootstrap_devkit_container(existing_container, devkit_env)

            if len(selected_images) == 1:
                exec_cmd = ["docker", "exec", "-it"]
                fallback_cmd = ["docker", "exec", "-it", existing_container, "bash", "-l"]
                if check_os() in ["linux", "macos"]:
                    exec_cmd.extend(["-u", detect_current_user()[0]])
                exec_cmd.extend([existing_container, "bash", "-l"])
                first = subprocess.run(exec_cmd, check=False)
                if first.returncode != 0 and check_os() in ["linux", "macos"]:
                    print("⚠️ User mapping unavailable in this container; retrying without -u.")
                    subprocess.run(fallback_cmd, check=False)

    console.print("\n[bold green]✅ All selected containers started successfully![/bold green]")

if __name__ == "__main__":
    setup_and_start()
