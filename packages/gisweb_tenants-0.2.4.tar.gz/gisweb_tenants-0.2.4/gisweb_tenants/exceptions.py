class TenantConfigError(Exception):
    """Base exception for tenant config errors."""


class TenantConfigNotFoundError(TenantConfigError):
    """Raised when public or secret tenant config cannot be found."""


class TenantConfigValidationError(TenantConfigError):
    """Raised when tenant config validation fails."""