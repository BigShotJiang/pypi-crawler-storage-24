# -*- coding: utf-8 -*-
#
#    fluxwallet - Python Cryptocurrency Library
#    ENCODING - Methods for encoding and conversion
#    © 2016 - 2022 October - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import hashlib
import math
import numbers
import unicodedata
from copy import deepcopy

import logging

from fluxwallet.config.config import TYPE_TEXT

_logger = logging.getLogger(__name__)


from cryptography.hazmat.primitives.ciphers.aead import AESSIV
from cryptography.hazmat.primitives.ciphers import Cipher as AESCipher
from cryptography.hazmat.primitives.ciphers import algorithms, modes
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt as ScryptKDF


class EncodingError(Exception):
    """Log and raise encoding errors"""

    def __init__(self, msg=""):
        self.msg = msg

    def __str__(self):
        return self.msg


bytesascii = b""
for bxn in range(256):
    bytesascii += bytes((bxn,))

code_strings = {
    2: b"01",
    3: b" ,.",
    10: b"0123456789",
    16: b"0123456789abcdef",
    32: b"abcdefghijklmnopqrstuvwxyz234567",
    58: b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz",
    256: b"".join([bytes((csx,)) for csx in range(256)]),
    "bech32": b"qpzry9x8gf2tvdw0s3jn54khce6mua7l",
}


def _get_code_string(base):
    if base in code_strings:
        return code_strings[base]
    else:
        return list(range(0, base))


def _array_to_codestring(array, base):
    codebase = code_strings[base]
    codestring = ""
    for i in array:
        codestring += chr(codebase[i])
    return codestring


def _codestring_to_array(codestring, base):
    codestring = bytes(codestring, "utf8")
    codebase = code_strings[base]
    array = []
    for s in codestring:
        try:
            array.append(codebase.index(s))
        except ValueError:
            raise EncodingError("Character '%s' not found in codebase" % s)
    return array


def _bech32_polymod(values):
    """Internal function that computes the Bech32 checksum."""
    generator = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for value in values:
        top = chk >> 25
        chk = (chk & 0x1FFFFFF) << 5 ^ value
        for i in range(5):
            chk ^= generator[i] if ((top >> i) & 1) else 0
    return chk


def convertbits(data, frombits, tobits, pad=True):
    """General power-of-2 base conversion.

    Source: https://github.com/sipa/bech32/tree/master/ref/python
    """
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return ret


def pubkeyhash_to_addr_bech32(pubkeyhash, prefix="bc", witver=0, separator="1"):
    """Encode a public key hash as a bech32 (segwit) address.

    Used for SSP relay identity (P2WSH on Bitcoin network).

    :param pubkeyhash: Public key hash (20 or 32 bytes)
    :type pubkeyhash: str, bytes
    :param prefix: Human-readable part ('bc' for mainnet, 'tb' for testnet)
    :type prefix: str
    :param witver: Witness version (0-16)
    :type witver: int
    :param separator: Separator between hrp and data
    :type separator: str
    :return str: Bech32 encoded address
    """
    pubkeyhash = list(to_bytes(pubkeyhash))

    if len(pubkeyhash) not in [20, 32, 40]:
        if pubkeyhash[0] != 0:
            witver = pubkeyhash[0] - 0x50
        if pubkeyhash[1] != len(pubkeyhash[2:]):
            raise EncodingError("Incorrect pubkeyhash length")
        pubkeyhash = pubkeyhash[2:]

    if witver > 16:
        raise EncodingError("Witness version must be between 0 and 16")

    checksum_xor = 1
    data = [witver] + convertbits(pubkeyhash, 8, 5)

    hrp_expanded = [ord(x) >> 5 for x in prefix] + [0] + [ord(x) & 31 for x in prefix]
    polymod = _bech32_polymod(hrp_expanded + data + [0, 0, 0, 0, 0, 0]) ^ checksum_xor
    checksum = [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]

    return (
        prefix
        + separator
        + _array_to_codestring(data, "bech32")
        + _array_to_codestring(checksum, "bech32")
    )


def normalize_var(var, base=256):
    """
    For Python 2 convert variable to string

    For Python 3 convert to bytes

    Convert decimals to integer type

    :param var: input variable in any format
    :type var: str, byte
    :param base: specify variable format, i.e. 10 for decimal, 16 for hex
    :type base: int

    :return: Normalized var in string for Python 2, bytes for Python 3, decimal for base10
    """
    try:
        if isinstance(var, str):
            var = var.encode("ISO-8859-1")
    except ValueError:
        try:
            var = var.encode("utf-8")
        except ValueError:
            raise EncodingError("Unknown character '%s' in input format" % var)

    if base == 10:
        return int(var)
    elif isinstance(var, list):
        return deepcopy(var)
    else:
        return var


def change_base(
    chars, base_from, base_to, min_length=0, output_even=None, output_as_list=None
):
    """
    Convert input chars from one numeric base to another. For instance from hexadecimal (base-16) to decimal (base-10)

    From and to numeric base can be any base. If base is not found in definitions an array of index numbers will be returned

    Examples:

    >>> change_base('FF', 16, 10)
    255
    >>> change_base('101', 2, 10)
    5

    Convert base-58 public WIF of a key to hexadecimal format

    >>> change_base('xpub661MyMwAqRbcFnkbk13gaJba22ibnEdJS7KAMY99C4jBBHMxWaCBSTrTinNTc9G5LTFtUqbLpWnzY5yPTNEF9u8sB1kBSygy4UsvuViAmiR', 58, 16)
    '0488b21e0000000000000000007d3cc6702f48bf618f3f14cce5ee2cacf3f70933345ee4710af6fa4a330cc7d503c045227451b3454ca8b6022b0f0155271d013b58d57d322fd05b519753a46e876388698a'

    Convert base-58 address to public key hash: '00' + length '21' + 20 byte key

    >>> change_base('142Zp9WZn9Fh4MV8F3H5Dv4Rbg7Ja1sPWZ', 58, 16)
    '0021342f229392d7c9ed82c932916cee6517fbc9a2487cd97a'

    Convert to 2048-base, for example a Mnemonic word list. Will return a list of integers

    >>> change_base(100, 16, 2048)
    [100]

    :param chars: Input string
    :type chars: any
    :param base_from: Base number or name from input. For example 2 for binary, 10 for decimal and 16 for hexadecimal
    :type base_from: int, str
    :param base_to: Base number or name for output. For example 2 for binary, 10 for decimal and 16 for hexadecimal
    :type base_to: int
    :param min_length: Minimal output length. Required for decimal, advised for all output to avoid leading zeros conversion problems.
    :type min_length: int
    :param output_even: Specify if output must contain an even number of characters. Sometimes handy for hex conversions.
    :type output_even: bool
    :param output_as_list: Always output as list instead of string.
    :type output_as_list: bool

    :return str, list: Base converted input as string or list.
    """
    if base_from == 10 and not min_length:
        raise EncodingError("For a decimal input a minimum output length is required")

    code_str = _get_code_string(base_to)

    if base_to not in code_strings:
        output_as_list = True

    code_str_from = _get_code_string(base_from)
    if not isinstance(code_str_from, (bytes, list)):
        raise EncodingError("Code strings must be a list or defined as bytes")
    output = []
    input_dec = 0
    addzeros = 0
    inp = normalize_var(chars, base_from)

    # Use bytes and int's methods for standard conversions to speedup things
    if not min_length:
        if base_from == 256 and base_to == 16:
            return inp.hex()
        elif base_from == 16 and base_to == 256:
            return bytes.fromhex(chars)
    if base_from == 16 and base_to == 10:
        return int(inp, 16)
    if base_from == 10 and base_to == 16:
        hex_outp = hex(inp)[2:]
        return hex_outp.zfill(min_length) if min_length else hex_outp
    if base_from == 256 and base_to == 10:
        return int.from_bytes(inp, "big")
    if base_from == 10 and base_to == 256:
        return inp.to_bytes(min_length, byteorder="big")
    if base_from == 256 and base_to == 58:
        return base58encode(inp)
    if base_from == 16 and base_to == 58:
        return base58encode(bytes.fromhex(chars))

    if output_even is None and base_to == 16:
        output_even = True

    if isinstance(inp, numbers.Number):
        input_dec = inp
    elif isinstance(inp, (str, list, bytes)):
        factor = 1
        while len(inp):
            if isinstance(inp, list):
                item = inp.pop()
            else:
                item = inp[-1:]
                inp = inp[:-1]
            try:
                pos = code_str_from.index(item)
            except ValueError:
                try:
                    pos = code_str_from.index(item.lower())
                except ValueError:
                    raise EncodingError(
                        "Unknown character %s found in input string" % item
                    )
            input_dec += pos * factor

            # Add leading zero if there are leading zero's in input
            firstchar = chr(code_str_from[0]).encode("utf-8")
            if not pos * factor:
                if isinstance(inp, list):
                    if not len([x for x in inp if x != firstchar]):
                        addzeros += 1
                elif not len(inp.strip(firstchar)):
                    addzeros += 1
            factor *= base_from
    else:
        raise EncodingError("Unknown input format %s" % inp)

    # Convert decimal to output base
    while input_dec != 0:
        input_dec, remainder = divmod(input_dec, base_to)
        output = [code_str[remainder]] + output

    if base_to != 10:
        pos_fact = math.log(base_to, base_from)
        expected_length = len(str(chars)) / pos_fact

        zeros = int(addzeros / pos_fact)
        if addzeros == 1:
            zeros = 1
        # Different rules for base58 addresses
        if (base_from == 256 and base_to == 58) or (base_from == 58 and base_to == 256):
            zeros = addzeros
        elif base_from == 16 and base_to == 58:
            zeros = -(-addzeros // 2)
        elif base_from == 58 and base_to == 16:
            zeros = addzeros * 2

        for _ in range(zeros):
            if base_to != 10 and not expected_length == len(output):
                output = [code_str[0]] + output

        # Add zero's to make even number of digits on Hex output (or if specified)
        if output_even and len(output) % 2:
            output = [code_str[0]] + output

        # Add leading zero's
        while len(output) < min_length:
            output = [code_str[0]] + output

    if not output_as_list and isinstance(output, list):
        output = 0 if not len(output) else "".join([chr(c) for c in output])
    if base_to == 10:
        return int(0) or (output != "" and int(output))
    if base_to == 256 and not output_as_list:
        return output.encode("ISO-8859-1")
    else:
        return output


def base58encode(inp):
    """
    Convert bytes to base58 encode string

    :param inp: Input string
    :type inp: bytes

    :return str:
    """
    origlen = len(inp)
    inp = inp.lstrip(b"\0")
    padding_zeros = origlen - len(inp)
    code_str = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    acc = int.from_bytes(inp, "big")

    string = ""
    while acc:
        acc, idx = divmod(acc, 58)
        string = code_str[idx : idx + 1] + string
    return "1" * padding_zeros + string


def varbyteint_to_int(byteint):
    """
    Convert CompactSize Variable length integer in byte format to integer.

    See https://en.bitcoin.it/wiki/Protocol_documentation#Variable_length_integer for specification

    >>> varbyteint_to_int(bytes.fromhex('fd1027'))
    (10000, 3)

    :param byteint: 1-9 byte representation
    :type byteint: bytes, list

    :return (int, int): tuple wit converted integer and size
    """
    if not isinstance(byteint, (bytes, list)):
        raise EncodingError("Byteint must be a list or defined as bytes")
    if byteint == b"":
        return 0, 0
    ni = byteint[0]
    if ni < 253:
        return ni, 1
    if ni == 253:  # integer of 2 bytes
        size = 2
    elif ni == 254:  # integer of 4 bytes
        size = 4
    else:  # integer of 8 bytes
        size = 8
    return int.from_bytes(byteint[1 : 1 + size][::-1], "big"), size + 1


def read_varbyteint(s):
    """
    Read variable length integer from BytesIO stream. Wrapper for the varbyteint_to_int method

    :param s: A binary stream
    :type s: BytesIO

    :return int:
    """
    pos = s.tell()
    value, size = varbyteint_to_int(s.read(9))
    s.seek(pos + size)
    return value


def read_varbyteint_return(s):
    """
    Read variable length integer from BytesIO stream. Return original converted bytes (to reconstruct transaction or
    script).

    :param s: A binary stream
    :type s: BytesIO

    :return (int, bytes):
    """
    pos = s.tell()
    byteint = s.read(9)
    if not byteint:
        return 0, b""

    ni = byteint[0]
    if ni < 253:
        s.seek(pos + 1)
        return ni, byteint[0:1]
    if ni == 253:  # integer of 2 bytes
        size = 2
    elif ni == 254:  # integer of 4 bytes
        size = 4
    else:  # integer of 8 bytes
        size = 8
    varbytes = byteint[1 : 1 + size]
    s.seek(pos + size + 1)
    return int.from_bytes(varbytes[::-1], "big"), byteint[0:1] + varbytes


def int_to_varbyteint(inp):
    """
    Convert integer to CompactSize Variable length integer in byte format.

    See https://en.bitcoin.it/wiki/Protocol_documentation#Variable_length_integer for specification

    >>> int_to_varbyteint(10000).hex()
    'fd1027'

    :param inp: Integer to convert
    :type inp: int

    :return: byteint: 1-9 byte representation as integer
    """
    if not isinstance(inp, numbers.Number):
        raise EncodingError("Input must be a number type")
    if inp < 0xFD:
        return inp.to_bytes(1, "little")
    elif inp < 0xFFFF:
        return b"\xfd" + inp.to_bytes(2, "little")
    elif inp < 0xFFFFFFFF:
        return b"\xfe" + inp.to_bytes(4, "little")
    else:
        return b"\xff" + inp.to_bytes(8, "little")


def _der_decode_signature(sig_bytes):
    """
    Decode a DER-encoded ECDSA signature into (r, s) integers.

    :param sig_bytes: DER-encoded signature
    :type sig_bytes: bytes
    :return tuple: (r, s) as integers
    """
    if sig_bytes[0] != 0x30:
        raise EncodingError("Invalid DER signature: missing SEQUENCE tag")
    total_len = sig_bytes[1]
    data = sig_bytes[2 : 2 + total_len]

    if data[0] != 0x02:
        raise EncodingError("Invalid DER signature: missing INTEGER tag for r")
    r_len = data[1]
    r = int.from_bytes(data[2 : 2 + r_len], "big")
    data = data[2 + r_len :]

    if data[0] != 0x02:
        raise EncodingError("Invalid DER signature: missing INTEGER tag for s")
    s_len = data[1]
    s = int.from_bytes(data[2 : 2 + s_len], "big")

    return r, s


def _der_encode_signature(r, s):
    """
    DER-encode an ECDSA signature from (r, s) integers.

    :param r: r value of signature
    :type r: int
    :param s: s value of signature
    :type s: int
    :return bytes: DER-encoded signature
    """

    def _encode_int(value):
        b = value.to_bytes((value.bit_length() + 7) // 8, "big")
        # Pad with 0x00 if high bit is set (DER integers are signed)
        if b[0] & 0x80:
            b = b"\x00" + b
        return b"\x02" + bytes([len(b)]) + b

    rb = _encode_int(r)
    sb = _encode_int(s)
    content = rb + sb
    return b"\x30" + bytes([len(content)]) + content


def convert_der_sig(signature, as_hex=True):
    """
    Extract content from DER encoded string: Convert DER encoded signature to signature string.

    :param signature: DER signature
    :type signature: bytes
    :param as_hex: Output as hexstring
    :type as_hex: bool

    :return bytes, str: Signature
    """

    if not signature:
        return ""
    r, s = _der_decode_signature(bytes(signature))
    sig = "%064x%064x" % (r, s)
    if as_hex:
        return sig
    else:
        return bytes.fromhex(sig)


def der_encode_sig(r, s):
    """
    Create DER encoded signature string with signature r and s value.

    :param r: r value of signature
    :type r: int
    :param s: s value of signature
    :type s: int

    :return bytes:
    """
    return _der_encode_signature(r, s)


def addr_to_pubkeyhash(address, as_hex=False, encoding=None):
    """
    Convert base58 address to public key hash

    :param address: Crypto currency address in base-58 format
    :type address: str
    :param as_hex: Output as hexstring
    :type as_hex: bool
    :param encoding: Address encoding used. Only base58 is supported.
    :type encoding: str

    :return bytes, str: public key hash
    """

    return addr_base58_to_pubkeyhash(address, as_hex)


def addr_base58_to_pubkeyhash(address, as_hex=False):
    """
    Convert Base58 encoded address to public key hash

    >>> addr_base58_to_pubkeyhash('142Zp9WZn9Fh4MV8F3H5Dv4Rbg7Ja1sPWZ', as_hex=True)
    '21342f229392d7c9ed82c932916cee6517fbc9a2'

    :param address: Crypto currency address in base-58 format
    :type address: str, bytes
    :param as_hex: Output as hexstring
    :type as_hex: bool

    :return bytes, str: Public Key Hash
    """

    try:
        address = change_base(address, 58, 256, 25)
    except EncodingError as err:
        raise EncodingError("Invalid address %s: %s" % (address, err))
    if len(address) != 25:
        raise EncodingError(
            "Invalid address hash160 length, should be 25 characters not %d"
            % len(address)
        )
    check = address[-4:]
    pkh = address[:-4]
    checksum = double_sha256(pkh)[0:4]
    assert check == checksum, "Invalid address, checksum incorrect"
    if as_hex:
        return pkh.hex()[2:]
    else:
        return pkh[1:]


def pubkeyhash_to_addr(pubkeyhash, prefix=None, encoding="base58", witver=None):
    """
    Convert public key hash to base58 encoded address

    :param pubkeyhash: Public key hash
    :type pubkeyhash: bytes, str
    :param prefix: Prefix version byte of network, default is bitcoin '\x00'
    :type prefix: str, bytes
    :param encoding: Address encoding. Only base58 is supported.
    :type encoding: str

    :return str: Base-58 encoded address

    """
    if encoding != "base58":
        raise EncodingError("Encoding %s not supported" % encoding)
    if prefix is None:
        prefix = b"\x00"
    return pubkeyhash_to_addr_base58(pubkeyhash, prefix)


def pubkeyhash_to_addr_base58(pubkeyhash, prefix=b"\x00"):
    """
    Convert public key hash to base58 encoded address

    >>> pubkeyhash_to_addr_base58('21342f229392d7c9ed82c932916cee6517fbc9a2')
    '142Zp9WZn9Fh4MV8F3H5Dv4Rbg7Ja1sPWZ'

    :param pubkeyhash: Public key hash
    :type pubkeyhash: bytes, str
    :param prefix: Prefix version byte of network, default is bitcoin '\x00'
    :type prefix: str, bytes

    :return str: Base-58 encoded address
    """
    key = to_bytes(prefix) + to_bytes(pubkeyhash)
    addr256 = key + double_sha256(key)[:4]
    return base58encode(addr256)


def varstr(string):
    """
    Convert string to variably sized string: Bytestring preceded with length byte

    >>> varstr(to_bytes('5468697320737472696e67206861732061206c656e677468206f66203330')).hex()
    '1e5468697320737472696e67206861732061206c656e677468206f66203330'

    :param string: String input
    :type string: bytes, str

    :return bytes: varstring
    """
    s = normalize_var(string)
    if s == b"\0":
        return s
    return int_to_varbyteint(len(s)) + s


def to_bytes(string, unhexlify=True):
    """
    Convert string, hexadecimal string to bytes

    :param string: String to convert
    :type string: str, bytes
    :param unhexlify: Try to unhexlify hexstring
    :type unhexlify: bool

    :return: Bytes var
    """
    if not string:
        return b""
    if unhexlify:
        try:
            if isinstance(string, bytes):
                string = string.decode()
            s = bytes.fromhex(string)
            return s
        except (TypeError, ValueError):
            pass
    if isinstance(string, bytes):
        return string
    else:
        return bytes(string, "utf8")


def to_hexstring(string):
    """
    Convert bytes, string to a hexadecimal string. Use instead of built-in hex() method if format
    of input string is not known.

    >>> to_hexstring(b'\\x12\\xaa\\xdd')
    '12aadd'

    :param string: Variable to convert to hex string
    :type string: bytes, str

    :return: hexstring
    """
    if not string:
        return ""
    try:
        bytes.fromhex(string)
        return string
    except (ValueError, TypeError):
        pass

    if not isinstance(string, bytes):
        string = bytes(string, "utf8")
    return string.hex()


def normalize_string(string):
    """
    Normalize a string to the default NFKD unicode format
    See https://en.wikipedia.org/wiki/Unicode_equivalence#Normalization

    :param string: string value
    :type string: bytes, str

    :return: string
    """
    if isinstance(string, bytes):
        utxt = string.decode("utf8")
    elif isinstance(string, TYPE_TEXT):
        utxt = string
    else:
        raise TypeError("String value expected")

    return unicodedata.normalize("NFKD", utxt)


def double_sha256(string, as_hex=False):
    """
    Get double SHA256 hash of string

    :param string: String to be hashed
    :type string: bytes
    :param as_hex: Return value as hexadecimal string. Default is False
    :type as_hex: bool

    :return bytes, str:
    """
    if not as_hex:
        return hashlib.sha256(hashlib.sha256(string).digest()).digest()
    else:
        return hashlib.sha256(hashlib.sha256(string).digest()).hexdigest()


def ripemd160(string):
    return hashlib.new("ripemd160", string).digest()


def hash160(string):
    """
    Creates a RIPEMD-160 + SHA256 hash of the input string

    :param string: Script
    :type string: bytes

    :return bytes: RIPEMD-160 hash of script
    """
    return ripemd160(hashlib.sha256(string).digest())


def aes_encrypt(data, key):
    """
    Encrypt data using AES-SIV (RFC 5297) authenticated encryption.

    Deterministic (no nonce), which is safe for SIV mode.
    Returns ciphertext + 16-byte tag (tag appended).

    :param data: Data to encrypt
    :type data: bytes
    :param key: 32-byte AES-128-SIV key
    :type key: bytes
    :return bytes: Ciphertext + 16-byte authentication tag
    """
    aessiv = AESSIV(key)
    # pyca returns tag + ciphertext; we store ciphertext + tag for DB compat
    combined = aessiv.encrypt(data, None)
    tag = combined[:16]
    ct = combined[16:]
    return ct + tag


def aes_decrypt(encrypted_data, key):
    """
    Decrypt AES-SIV encrypted data. Input must be ciphertext + 16-byte tag.

    :param encrypted_data: Ciphertext + 16-byte tag
    :type encrypted_data: bytes
    :param key: 32-byte AES-128-SIV key
    :type key: bytes
    :return bytes: Decrypted plaintext
    """
    ct = encrypted_data[:-16]
    tag = encrypted_data[-16:]
    # pyca expects tag + ciphertext
    aessiv = AESSIV(key)
    return aessiv.decrypt(tag + ct, None)


def bip38_decrypt(encrypted_privkey, password):
    """
    BIP0038 non-ec-multiply decryption. Returns WIF private key.
    Based on code from https://github.com/nomorecoin/python-bip38-testing
    This method is called by Key class init function when importing BIP0038 key.

    :param encrypted_privkey: Encrypted private key using WIF protected key format
    :type encrypted_privkey: str
    :param password: Required password for decryption
    :type password: str

    :return tupple (bytes, bytes): (Private Key bytes, 4 byte address hash for verification)
    """
    d = change_base(encrypted_privkey, 58, 256)[2:]
    flagbyte = d[0:1]
    d = d[1:]
    if flagbyte == b"\xc0":
        compressed = False
    elif flagbyte == b"\xe0":
        compressed = True
    else:
        raise EncodingError(
            "Unrecognised password protected key format. Flagbyte incorrect."
        )
    if isinstance(password, str):
        password = password.encode("utf-8")
    addresshash = d[0:4]
    d = d[4:-4]
    kdf = ScryptKDF(salt=addresshash, length=64, n=16384, r=8, p=8)
    key = kdf.derive(password)
    derivedhalf1 = key[0:32]
    derivedhalf2 = key[32:64]
    encryptedhalf1 = d[0:16]
    encryptedhalf2 = d[16:32]
    cipher = AESCipher(algorithms.AES(derivedhalf2), modes.ECB())
    decryptor = cipher.decryptor()
    decryptedhalf2 = decryptor.update(encryptedhalf2)
    decryptedhalf1 = decryptor.update(encryptedhalf1)
    priv = decryptedhalf1 + decryptedhalf2
    priv = (int.from_bytes(priv, "big") ^ int.from_bytes(derivedhalf1, "big")).to_bytes(
        32, "big"
    )
    # if compressed:
    #     # FIXME: This works but does probably not follow the BIP38 standards (was before: priv = b'\0' + priv)
    #     priv += b'\1'
    return priv, addresshash, compressed


def bip38_encrypt(private_hex, address, password, flagbyte=b"\xe0"):
    """
    BIP0038 non-ec-multiply encryption. Returns BIP0038 encrypted private key
    Based on code from https://github.com/nomorecoin/python-bip38-testing

    :param private_hex: Private key in hex format
    :type private_hex: str
    :param address: Address string
    :type address: str
    :param password: Required password for encryption
    :type password: str
    :param flagbyte: Flagbyte prefix for WIF
    :type flagbyte: bytes

    :return str: BIP38 password encrypted private key
    """
    if isinstance(address, str):
        address = address.encode("utf-8")
    if isinstance(password, str):
        password = password.encode("utf-8")
    addresshash = double_sha256(address)[0:4]
    kdf = ScryptKDF(salt=addresshash, length=64, n=16384, r=8, p=8)
    key = kdf.derive(password)
    derivedhalf1 = key[0:32]
    derivedhalf2 = key[32:64]
    cipher = AESCipher(algorithms.AES(derivedhalf2), modes.ECB())
    encryptor = cipher.encryptor()
    encryptedhalf1 = encryptor.update(
        (
            int(private_hex[0:32], 16) ^ int.from_bytes(derivedhalf1[0:16], "big")
        ).to_bytes(16, "big")
    )
    encryptedhalf2 = encryptor.update(
        (
            int(private_hex[32:64], 16) ^ int.from_bytes(derivedhalf1[16:32], "big")
        ).to_bytes(16, "big")
    )
    encrypted_privkey = (
        b"\x01\x42" + flagbyte + addresshash + encryptedhalf1 + encryptedhalf2
    )
    encrypted_privkey += double_sha256(encrypted_privkey)[:4]
    return base58encode(encrypted_privkey)


class Quantity:
    """
    Class to convert very large or very small numbers to a readable format.

    Provided value is converted to number between 0 and 1000, and a metric prefix will be added.

    >>> # Example - the Hashrate on 10th July 2020
    >>> str(Quantity(122972532877979100000, 'H/s'))
    '122.973 EH/s'

    """

    def __init__(self, value, units="", precision=3):
        """
        Convert given value to number between 0 and 1000 and determine metric prefix

        :param value: Value as integer in base 0
        :type value: int, float
        :param units: Base units, so 'g' for grams for instance
        :type units: str
        :param precision: Number of digits after the comma
        :type precision: int

        """
        # Metric prefixes according to BIPM, the International System of Units (SI) in 10**3 steps
        self.prefix_list = list("yzafpnμm1kMGTPEZY")
        self.base = self.prefix_list.index("1")
        assert value >= 0

        self.absolute = value
        self.units = units
        self.precision = precision
        while (
            value != 0
            and (value < 1 or value > 1000)
            and 0 < self.base < len(self.prefix_list) - 1
        ):
            if value > 1000:
                self.base += 1
                value /= 1000.0
            elif value < 1000:
                self.base -= 1
                value *= 1000.0
        self.value = value

    def __str__(self):
        # > Python 3.6: return f"{self.value:4.{self.precision}f} {self.prefix_list[self.base]}{self.units}"
        prefix = self.prefix_list[self.base]
        if prefix == "1":
            prefix = ""
        return ("%4.*f %s%s" % (self.precision, self.value, prefix, self.units)).strip()
