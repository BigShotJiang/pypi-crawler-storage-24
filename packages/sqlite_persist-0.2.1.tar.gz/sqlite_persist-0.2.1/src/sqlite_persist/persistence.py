from __future__ import annotations

import re
import sqlite3
from collections.abc import Collection, Generator
from contextlib import contextmanager
from typing import Any, ClassVar, Self


class Persistence:
    _columns_cache: ClassVar[dict[str, set[str]]] = {}
    _pk: str | tuple[str, ...] = "id"
    _table: ClassVar[str | None] = None
    _managed_cons: ClassVar[set[int]] = set()  # id() des connexions sous transaction()

    # ── Utilitaires internes ───────────────────────────────────────────────

    @classmethod
    def _pk_columns(cls) -> tuple[str, ...]:
        return (cls._pk,) if isinstance(cls._pk, str) else tuple(cls._pk)

    def _pk_dict(self) -> dict:
        return {col: self.__dict__[col] for col in self._pk_columns()}

    @classmethod
    def _pk_where_clause(cls) -> str:
        return " AND ".join(f"{col}=:{col}" for col in cls._pk_columns())

    @classmethod
    def _cache_key(cls, con: sqlite3.Connection) -> str:
        return f"{id(con)}:{cls._table_name()}"

    @classmethod
    def _table_name(cls) -> str:
        return cls._table or cls.__name__

    @classmethod
    def _con(cls) -> sqlite3.Connection:
        raise NotImplementedError("Passez con= explicitement ou surchargez _con().")

    @classmethod
    def _check_columns(cls, con: sqlite3.Connection, keys: Collection) -> None:
        if cls._table_name() not in cls._columns_cache:
            cur = con.execute(f"SELECT name FROM pragma_table_info('{cls._table_name()}')")  # noqa: S608
            cls._columns_cache[cls._table_name()] = {row[0] for row in cur.fetchall()}

        valid_columns = cls._columns_cache[cls._table_name()]
        invalid = set(keys) - valid_columns
        if invalid:
            raise ValueError(f"Colonnes invalides : {invalid}")

    @classmethod
    def clear_cache(cls) -> None:
        """Invalide le cache de colonnes (utile après une migration)."""
        cls._columns_cache.pop(cls._table_name(), None)

    def _row_data(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}

    def __repr__(self) -> str:
        pk_cols = self._pk_columns()
        pk_str = ", ".join(f"{col}={self.__dict__.get(col)!r}" for col in pk_cols)
        rest_str = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items() if k not in pk_cols and not k.startswith("_"))
        return f"{self._table_name()}[{pk_str} | {rest_str}]"

    # ── Transactions ───────────────────────────────────────────────────────

    @classmethod
    @contextmanager
    def transaction(cls, con: sqlite3.Connection | None = None) -> Generator[sqlite3.Connection, None, None]:
        """
        Context manager pour grouper plusieurs opérations dans une transaction.
        Commit automatique à la sortie, rollback en cas d'exception.
        Les méthodes insert/update/delete ne commitent pas si elles sont
        appelées dans ce contexte.

        with User.transaction(con) as tx:
            user.insert(con=tx)
            other.update(con=tx)
        """
        con = con or cls._con()
        cls._managed_cons.add(id(con))
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            cls._managed_cons.discard(id(con))

    @classmethod
    def _commit(cls, con: sqlite3.Connection) -> None:
        """Commite uniquement si la connexion n'est pas gérée par transaction()."""
        if id(con) not in cls._managed_cons:
            con.commit()

    # ── Helpers de construction WHERE (partagés par select/count/exists) ───
    @classmethod
    def _build_where(cls, con: sqlite3.Connection, where: dict[str, Any] | str | None, params: dict[str, Any] | None) -> tuple[str, dict]:
        """Retourne (clause WHERE sans le mot WHERE, params nettoyés)."""
        if isinstance(where, str):
            return where, params or {}
        if isinstance(where, dict) and where:
            clean_params: dict[str, Any] = {}
            conditions = []
            for key, value in where.items():
                parts = re.split(r"\s+", key.strip(), maxsplit=1)
                col, op = (parts[0], parts[1]) if len(parts) == 2 else (parts[0], "=")
                placeholder = f"{col}_{len(clean_params)}"
                conditions.append(f"{col} {op} :{placeholder}")
                clean_params[placeholder] = value
            cls._check_columns(con, [c.split(" ")[0] for c in conditions])
            return " AND ".join(conditions), clean_params
        return "", {}

    # ── Lecture ────────────────────────────────────────────────────────────

    @classmethod
    def find(cls, *pk_values, con: sqlite3.Connection | None = None) -> Self | None:
        con: sqlite3.Connection = con or cls._con()
        pk_cols = cls._pk_columns()
        if len(pk_values) != len(pk_cols):
            raise ValueError(f"{cls._table_name()} attend {len(pk_cols)} valeur(s) de PK : {pk_cols}")
        params = dict(zip(pk_cols, pk_values, strict=False))

        cursor = con.cursor()
        cursor.row_factory = sqlite3.Row
        row = cursor.execute(
            f"SELECT * FROM {cls._table_name()} WHERE {cls._pk_where_clause()}",  # noqa: S608
            params,
        ).fetchone()
        cursor.close()

        if row is not None:
            o: Self = object.__new__(cls)
            o.__dict__.update(dict(row))
            return o
        return None

    @classmethod
    def get(cls, *pk_values, con: sqlite3.Connection | None = None) -> Self:
        result = cls.find(*pk_values, con=con)
        if result is None:
            raise KeyError(f"{cls._table_name()} introuvable : {pk_values}")
        return result

    @classmethod
    def select(
        cls,
        where: dict[str, Any] | str | None = None,
        params: dict[str, Any] | None = None,
        order_by: str | list[str] | None = None,
        con: sqlite3.Connection | None = None,
    ) -> list[Self]:
        con = con or cls._con()
        clause, clean_params = cls._build_where(con, where, params)
        query = f"SELECT * FROM {cls._table_name()}"  # noqa: S608
        if clause:
            query += f" WHERE {clause}"
        if order_by is not None:
            cols = [order_by] if isinstance(order_by, str) else order_by
            query += f" ORDER BY {', '.join(cols)}"
        cursor = con.cursor()
        cursor.row_factory = sqlite3.Row
        rows = cursor.execute(query, clean_params).fetchall()
        cursor.close()
        objects: list[Self] = []
        for row in rows:
            o: Self = object.__new__(cls)
            o.__dict__.update(dict(row))
            objects.append(o)
        return objects

    @classmethod
    def from_query(cls, query: str, params: dict[str, Any] | None = None, con: sqlite3.Connection | None = None) -> list[Self]:
        con = con or cls._con()
        cursor = con.cursor()
        cursor.row_factory = sqlite3.Row
        rows = cursor.execute(query, params or {}).fetchall()
        cursor.close()
        objects: list[Self] = []
        for row in rows:
            o: Self = object.__new__(cls)
            o.__dict__.update(dict(row))
            objects.append(o)
        return objects

    @classmethod
    def count(
        cls,
        where: dict[str, Any] | str | None = None,
        params: dict[str, Any] | None = None,
        con: sqlite3.Connection | None = None,
    ) -> int:
        con = con or cls._con()
        clause, clean_params = cls._build_where(con, where, params)
        query = f"SELECT COUNT(*) FROM {cls._table_name()}"  # noqa: S608
        if clause:
            query += f" WHERE {clause}"
        row = con.execute(query, clean_params).fetchone()
        return row[0] if row else 0

    @classmethod
    def exists(
        cls,
        where: dict[str, Any] | str | None = None,
        params: dict[str, Any] | None = None,
        con: sqlite3.Connection | None = None,
    ) -> bool:
        """
        Vérifie l'existence d'au moins une ligne.

        User.exists({"username": "alice"})
        User.exists("age >= :a", {"a": 18})
        """
        con = con or cls._con()
        clause, clean_params = cls._build_where(con, where, params)
        query = f"SELECT 1 FROM {cls._table_name()}"  # noqa: S608
        if clause:
            query += f" WHERE {clause}"
        query += " LIMIT 1"
        return con.execute(query, clean_params).fetchone() is not None

    # ── Insertion ──────────────────────────────────────────────────────────

    def insert(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        data: dict = self._row_data()
        self._check_columns(con, data.keys())
        cols = ", ".join(data.keys())
        placeholders = ", ".join(f":{k}" for k in data)
        cursor = con.execute(
            f"INSERT INTO {self._table_name()} ({cols}) VALUES ({placeholders})",  # noqa: S608
            data,
        )
        self._commit(con)
        if cursor.lastrowid is not None:
            pk_cols = self._pk_columns()
            self.__dict__[pk_cols[0]] = cursor.lastrowid

    @classmethod
    def insert_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        if not items:
            return
        con = con or cls._con()
        sample = items[0]._row_data()
        cls._check_columns(con, sample.keys())
        cols = ", ".join(sample.keys())
        placeholders = ", ".join(f":{k}" for k in sample)
        pk_col = cls._pk_columns()[0]
        query = f"INSERT INTO {cls._table_name()} ({cols}) VALUES ({placeholders})"  # noqa: S608
        with cls.transaction(con):
            for item in items:
                cursor = con.execute(query, item._row_data())
                item.__dict__[pk_col] = cursor.lastrowid

    # ── Mise à jour ────────────────────────────────────────────────────────

    def update(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        data: dict = self._row_data()
        self._check_columns(con, data.keys())
        pk_cols = self._pk_columns()
        missing = [col for col in pk_cols if col not in data]
        if missing:
            raise ValueError(f"Colonnes PK manquantes dans l'instance : {missing}")
        set_clause = ", ".join(f"{k}=:{k}" for k in data if k not in pk_cols)
        con.execute(
            f"UPDATE {self._table_name()} SET {set_clause} WHERE {self._pk_where_clause()}",  # noqa: S608
            data,
        )
        self._commit(con)

    @classmethod
    def update_where(cls, values: dict[str, Any], where: dict[str, Any], con: sqlite3.Connection | None = None) -> None:
        con = con or cls._con()
        cls._check_columns(con, list(values.keys()) + list(where.keys()))
        set_clause = ", ".join(f"{k}=:set_{k}" for k in values)
        where_clause = " AND ".join(f"{k}=:where_{k}" for k in where)
        params = {f"set_{k}": v for k, v in values.items()} | {f"where_{k}": v for k, v in where.items()}
        con.execute(
            f"UPDATE {cls._table_name()} SET {set_clause} WHERE {where_clause}",  # noqa: S608
            params,
        )
        cls._commit(con)

    @classmethod
    def update_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or cls._con()
        if not items:
            return
        pk_cols = cls._pk_columns()
        sample = items[0]._row_data()
        cls._check_columns(con, sample.keys())
        missing = [col for col in pk_cols if col not in sample]
        if missing:
            raise ValueError(f"Colonnes PK manquantes : {missing}")
        set_clause = ", ".join(f"{k}=:{k}" for k in sample if k not in pk_cols)
        con.executemany(
            f"UPDATE {cls._table_name()} SET {set_clause} WHERE {cls._pk_where_clause()}",  # noqa: S608
            [item._row_data() for item in items],
        )
        cls._commit(con)

    # ── Suppression ────────────────────────────────────────────────────────

    def delete(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        con.execute(
            f"DELETE FROM {self._table_name()} WHERE {self._pk_where_clause()}",  # noqa: S608
            self._pk_dict(),
        )
        self._commit(con)

    @classmethod
    def delete_where(cls, parameters: dict[str, Any], con: sqlite3.Connection | None = None) -> None:
        con = con or cls._con()
        cls._check_columns(con, parameters.keys())
        where_clause = " AND ".join(f"{k}=:{k}" for k in parameters)
        con.execute(
            f"DELETE FROM {cls._table_name()} WHERE {where_clause}",  # noqa: S608
            parameters,
        )
        cls._commit(con)

    @classmethod
    def delete_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or cls._con()
        if not items:
            return
        con.executemany(
            f"DELETE FROM {cls._table_name()} WHERE {cls._pk_where_clause()}",  # noqa: S608
            [item._pk_dict() for item in items],
        )
        cls._commit(con)

    # ── Upsert ────────────────────────────────────────────────────────

    def upsert(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        data: dict = self._row_data()
        self._check_columns(con, data.keys())
        cols = ", ".join(data.keys())
        placeholders = ", ".join(f":{k}" for k in data)
        cursor = con.execute(
            f"INSERT OR REPLACE INTO {self._table_name()} ({cols}) VALUES ({placeholders})",  # noqa: S608
            data,
        )
        self._commit(con)
        # Récupère l'id généré uniquement si la PK était absente
        pk_cols = self._pk_columns()
        if len(pk_cols) == 1 and self.__dict__.get(pk_cols[0]) is None:
            self.__dict__[pk_cols[0]] = cursor.lastrowid

    @classmethod
    def upsert_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        if not items:
            return
        con = con or cls._con()
        sample = items[0]._row_data()
        cls._check_columns(con, sample.keys())
        cols = ", ".join(sample.keys())
        placeholders = ", ".join(f":{k}" for k in sample)
        pk_cols = cls._pk_columns()
        query = f"INSERT OR REPLACE INTO {cls._table_name()} ({cols}) VALUES ({placeholders})"  # noqa: S608
        with cls.transaction(con):
            for item in items:
                cursor = con.execute(query, item._row_data())
                if len(pk_cols) == 1 and item.__dict__.get(pk_cols[0]) is None:
                    item.__dict__[pk_cols[0]] = cursor.lastrowid
