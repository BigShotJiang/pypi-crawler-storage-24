from sqlite_persist.persistence import Persistence

__all__ = ["Persistence"]
