# Antaris

**Personal AI assistant that remembers everything, learns your habits, and gets better every conversation.**

Zero external dependencies. Ships with memory, safety, and a soul built in.

```bash
pip install antarisbot
antaris init
antaris start
```

1,094 tests. 25 modules. One `pip install`.

---

## Table of Contents

- [Why Antaris?](#why-antaris)
- [Quick Start](#quick-start)
- [Features](#features)
  - [Memory That Persists](#-memory-that-persists)
  - [Smart Reconnect Briefings](#-smart-reconnect-briefings)
  - [Teach Your Bot](#-teach-your-bot)
  - [Focus Mode](#-focus-mode)
  - [Conversation Threading](#-conversation-threading)
  - [Proactive Memory](#-proactive-memory)
  - [Shortcut Learning](#-shortcut-learning)
  - [Mood-Aware Responses](#-mood-aware-responses)
  - [Reaction Feedback](#-reaction-feedback)
  - [Conversation Export](#-conversation-export)
  - [Multi-Provider Routing](#-multi-provider-routing)
  - [Three Security Modes](#-three-security-modes)
  - [Persona System](#-persona-system)
  - [Multi-Channel Support](#-multi-channel-support)
  - [Cron Scheduler](#-cron-scheduler)
  - [User Profiles](#-user-profiles)
  - [Daily Memory Logs](#-daily-memory-logs)
  - [Compaction Safety](#-compaction-safety)
  - [Config Protection](#-config-protection)
  - [Migration Wizard](#-migration-wizard)
- [All Chat Commands](#all-chat-commands)
- [All CLI Commands](#all-cli-commands)
- [Supported Providers](#supported-providers)
- [Configuration](#configuration)
- [Architecture](#architecture)
- [Changelog](#changelog)
- [License](#license)

---

## Why Antaris?

Most AI bots forget everything between sessions. They respond to what you say right now and nothing else. They treat every user the same. They don't learn, don't adapt, and don't remember.

Antaris is different:

- **Permanent memory**: every conversation is stored locally, searchable forever, with no cloud dependency
- **Learns your patterns**: detects shortcuts you use repeatedly and expands them automatically
- **Adapts to your mood**: sends shorter responses when you're frustrated, matches your energy when you're excited
- **Proactive reminders**: notes things you mention ("meeting tomorrow at 3") and surfaces them at the right time
- **Tracks conversation threads**: knows the difference between your project discussion and your small talk
- **User-teachable**: tell it facts, preferences, and shortcuts that persist permanently
- **Focus mode**: tell it what you're working on and it prioritizes context accordingly
- **Export anything**: your conversations, your data, your format, instantly

All of this runs on your machine. No cloud. No subscriptions beyond your LLM API key. No data leaves your device unless you send it to an LLM.

---

## Quick Start

### Install

```bash
pip install antarisbot
```

Requires Python 3.10+. No other system dependencies.

### Setup

```bash
antaris init
```

The interactive wizard walks you through:
1. Bot name
2. LLM provider (Anthropic, OpenAI, Google, or Ollama for local models)
3. API key
4. Channel setup (Discord, Telegram, Slack: all optional)
5. Security mode

For automated setup (no prompts):
```bash
antaris init --headless
```

### Run

```bash
antaris start
```

Or chat directly in terminal without any channel setup:
```bash
antaris chat
```

---

## Features

### 🧠 Memory That Persists (powered by antaris-memory 5.2)

Every conversation is permanently stored using antaris-memory's 11-layer BM25+ search engine with semantic decay ranking. No vector database. No cloud storage. Just files on your machine.

Memories are scoped per user: each person who talks to the bot gets their own isolated memory store. Search is instant, relevance-ranked, and decay-weighted (recent memories score higher).

#### Auto-Classification

Memories are automatically classified at ingest time. No manual tagging needed:
- **Semantic** (facts, decisions, preferences): persist across sessions and surface in future conversations
- **Episodic** (events, chat, task logs): scoped to the current session by default

This means when you tell NoFace "my timezone is PST," that becomes a semantic memory available in every future session. But casual chat ("lol nice") stays in the current session only.

#### Cross-Session Recall

Search uses `cross_session_recall="semantic"` by default. Facts and decisions you shared in previous sessions surface automatically. Episodic chatter stays scoped to avoid noise.

#### Session & Channel Provenance

Every memory tracks where it came from: `session_id` and `channel_id` are recorded at ingest time. This enables accurate cross-session filtering and future multi-channel analytics.

#### 6 Memory Types

| Type | Decay Rate | Use Case |
|------|-----------|----------|
| `episodic` | Normal | General conversation |
| `semantic` | Normal | Facts, decisions (crosses sessions) |
| `fact` | Normal | Verified knowledge |
| `mistake` | 10x slower | Failures (never forget) |
| `preference` | 3x slower | User preferences |
| `procedure` | 3x slower | How-to knowledge |

#### Startup Recall

On the first message of each session, the bot pulls the 10 most recent memories and injects a context summary into its response. You never have to say "remember when we talked about X": it already knows.

The ingest filter automatically skips pipeline noise (context packets, system messages, queue notifications) so only real conversations enter memory.

```
!memory         | view conversation history length
!memory clear   | clear your conversation context
```

---

### 📋 Smart Reconnect Briefings

When you've been away, run `!gather` to catch up. Unlike raw message dumps, Antaris runs gathered messages through the LLM to produce a real briefing:

```
!gather 12
```

Response:
> **#antaris-suite** (18 msgs)
> Antaris discussed the v5.0.1 README rewrites. All 5 packages were bumped and pushed to GitHub. Pre-push hook fired on PyTorch license files (false positives).
>
> **#antaris-bot** (7 msgs)
> NoFace was restarted with OAuth token. Config.save() bug that wiped the key was fixed and hardened.

Valid intervals: `!gather 3`, `!gather 6`, `!gather 12`, `!gather 18`, `!gather 24`, `!gather 48`

Each channel summary is also ingested into memory, so the bot retains context from channels it wasn't actively monitoring.

---

### 📚 Teach Your Bot

Explicitly teach facts, preferences, and shortcuts that persist permanently and get injected into every conversation:

```
!teach when I say "deploy" I mean push to PyPI and restart the bot
!teach my timezone is PST
!teach I prefer concise answers over lengthy explanations
!teach project antarisbot is at /Users/me/antarisbot
```

Teachings are stored per-user in JSON files and automatically appear in the system prompt on every message. The bot doesn't just remember them: it *uses* them.

```
!teach list              | see all your teachings (numbered)
!teach remove 3          | remove teaching #3
!teach clear             | remove all teachings
```

---

### 🎯 Focus Mode

When you're deep in a project, tell the bot to focus:

```
!focus antarisbot 2h     | focus on antarisbot for 2 hours
!focus website           | focus indefinitely (until you unfocus)
!focus                   | show current focus status
!unfocus                 | exit focus mode
```

While focused:
- **Memory recall biases toward the focus topic**: searches prepend the topic to every query
- **System prompt includes a focus banner**: the LLM knows to prioritize responses around your topic
- **Auto-expires** after the set duration, or stays until you say `!unfocus`

Duration formats: `30m`, `1h`, `2h`, bare number (minutes). No duration means indefinite.

---

### 🧵 Conversation Threading

The bot automatically detects when you shift topics and files conversation turns into named threads:

- "Let's talk about the website": starts a `website` thread
- "Yeah do it": continuation, stays on current thread
- "Btw, what about the router bug?": topic shift, starts `router bug` thread

Thread detection uses lightweight heuristics (no ML required):
- **Continuation signals** (yeah, ok, do it, nice, thanks): keep current thread
- **Shift signals** (anyway, btw, switching to, let's talk about): start new thread
- **Keyword extraction**: significant words become the thread name

```
!threads                 | list all threads with turn counts
!thread website          | show the conversation thread about "website" (fuzzy match)
```

Threads persist to disk per user. Come back three days later and ask "what were we saying about the website?" and get the actual conversation flow, not just keyword matches.

---

### 💡 Proactive Memory

The bot passively notes things you mention and surfaces them at the right moment:

**What it detects:**
- Events: "I have a meeting tomorrow at 3"
- Tasks: "I need to fix the deployment script"
- Plans: "I'm going to refactor the router next week"
- Preferences: "My favorite editor is vim"

**When it surfaces:**
- On greetings ("good morning", "hey", "I'm back")
- After being offline (reconnect)

Example: You mention "meeting tomorrow at 3 PM" on Monday. Tuesday morning you say "good morning": the bot's response context includes: *"Reminder: you mentioned a meeting at 3 today."*

Notes expire after 7 days and are marked as surfaced to prevent repetition. Temporal references (tomorrow, tonight, next week) are parsed into actual timestamps for accurate timing.

---

### ⚡ Shortcut Learning

After you repeatedly use the same short phrase for the same purpose, the bot learns it automatically: no `!teach` needed.

**How it works:**
1. You say "check the bot" and the bot runs tests on antarisbot
2. You say "check the bot" again: same response pattern
3. Third time: the bot recognizes the pattern and learns the shortcut

From now on, when you say "check the bot," the system prompt includes context: *"The user often says this when they mean: [running tests on antarisbot]."*

This is different from `!teach` (explicit): shortcuts are *implicit*, learned from watching your behavior.

- Only tracks short messages (8 words or fewer)
- Requires 3 repetitions before learning (no premature triggers)
- Maximum 50 shortcuts per user
- Action signatures are normalized (filler words stripped)

```
!shortcuts               | list all learned shortcuts
!shortcuts remove <phrase>  | delete a learned shortcut (also clears pattern history)
```

---

### 🎭 Mood-Aware Responses

The bot detects your current mood from message patterns and adapts its response style in real time:

| Mood | Detection | Response Style |
|------|-----------|----------------|
| **Frustrated** | Short messages + caps + negative words + heavy punctuation | SHORT and DIRECT. No filler. Just answers. |
| **Focused** | Lots of questions, neutral tone | Precise, technical, structured. Skip small talk. |
| **Excited** | Positive words + caps + punctuation | Match enthusiasm! Celebrate wins, bold ideas. |
| **Relaxed** | Longer messages, positive/neutral, low intensity | Detailed, conversational, personality welcome. |
| **Neutral** | Default / not enough data | Standard response style. |

Detection uses a sliding window of the last 10 messages, analyzing:
- Message length and word count
- Capitalization patterns (>30% uppercase = significant)
- Punctuation intensity (!! or ?? or ...)
- Sentiment keywords (positive vs negative word sets)
- Question frequency

The mood guidance is injected at the end of the system prompt, so it influences the LLM's tone without overriding instructions.

---

### 👍 Reaction Feedback

On Discord, react to any bot message with emoji to give implicit feedback:

**Positive reactions:** 👍 ❤️ ✅ 🔥 💯 👏
**Negative reactions:** 👎 ❌ 😕 🚫

The bot tracks these per user and builds a feedback context that's injected into the system prompt. Over time, responses calibrate to what you actually like.

```
!feedback                | show feedback stats (X positive, Y negative)
!feedback clear          | clear all feedback data
```

Feedback is stored in a rolling window of the last 50 entries per user. Requires Discord `reactions` intent enabled (handled automatically).

---

### 📤 Conversation Export

Export your conversation history as clean, readable markdown files:

```
!export today            | export today's conversations
!export week             | export last 7 days
!export project website  | export all conversations about "website"
!export all              | export everything
```

Each export generates a `.md` file in `~/.antarisbot/exports/` with:
- Timestamps per entry
- Full conversation content
- Source and relevance metadata
- Clean formatting ready for sharing or archiving

Your data. Your format. Instantly.

---

### 🧭 Multi-Provider Routing

Antaris can route messages to the best model based on complexity:

| Tier | Use Case | Example Providers |
|------|----------|-------------------|
| **Trivial/Simple** | Quick answers, math | Ollama (Qwen, local, free) |
| **Moderate** | Conversation, explanations | Claude Sonnet, GPT-4o |
| **Complex** | Multi-step reasoning | Claude Sonnet + GPT-5.2 |
| **Expert** | Deep analysis, coding | Claude Opus, GPT-5.4 |

Configure routing via `~/.antarisbot/router/` config. Supports simultaneous providers: Anthropic, OpenAI, Google, and Ollama all registered at once.

Override the model anytime:
```
!model opus              | switch to Claude Opus
!model gpt               | switch to GPT-5.4
!model qwen              | switch to local Qwen
!model auto              | return to automatic routing
```

Available aliases: `opus`, `sonnet`, `haiku`, `gpt`, `gpt5`, `gpt4`, `gemini`, `flash`, `qwen`, `qwen9b`, `qwen8b`

---

### 🔐 Three Security Modes

The only self-hosted agent with named, enforced security tiers: not just a disclaimer.

```bash
antaris start --security sandboxed   # recommended default
antaris start --security open        # developers / power users
antaris start --security locked      # maximum security
```

| Mode | What It Does | Idle RAM |
|------|-------------|----------|
| **open** | Full host access. Guard disabled. | ~50MB |
| **sandboxed** (default) | Filesystem restricted to workspace. Subprocesses blocked. Prompt injection detection active. | ~60MB |
| **locked** | Everything sandboxed + AES-256-GCM encrypted memory. Tool approval prompts. JSON audit log. Network restricted to LLM APIs. | ~75MB |

Security is enforced at the OS level via `sys.addaudithook()`: fires at the C level, before Python can intercept, and **cannot be removed once registered**.

**Sandboxed mode:**
- File access outside workspace directory: blocked with `PermissionError`
- `subprocess.Popen()`: blocked
- Prompt injection: detected by antaris-guard, logged

**Locked mode adds:**
- Memory store encrypted with AES-256-GCM at rest
- Every tool call prompts for explicit `y/N` approval
- All tool calls logged to `~/.antarisbot/audit.log` (JSON lines, 30-day rotation)
- Network calls restricted to configured LLM API endpoints only
- Memory directory set `chmod 700` (owner-only)

---

### 🎭 Persona System

Drop a `SOUL.md` file in `~/.antarisbot/` to define the bot's personality, values, and behavior. The bot runs an awakening sequence on first start to discover its identity.

Additional files supported (controlled by `~/.antarisbot/context.json`):
- `SOUL.md`: core identity (loaded every message)
- `AGENTS.md`: behavioral rules and directives (loaded every message)
- `MEMORY.md`: long-term curated memories (loaded on startup)
- `TOOLS.md`: environment-specific notes (loaded on startup)
- `USER.md`: user information (loaded manually or by user tracker)

Context cadences:
- `every`: injected on every message
- `startup`: injected on first message only
- `manual`: only when explicitly requested

```bash
antaris persona show     | view current SOUL.md
antaris persona edit     | edit in $EDITOR
antaris persona reset    | reset and trigger awakening
```

---

### 🤖 Multi-Channel Support

Run the bot across multiple platforms simultaneously from one config:

- **Discord**: full support including reaction tracking, channel history, and DM
- **Telegram**: bot API integration
- **Slack**: Socket Mode (bot token + app token)
- **Terminal**: direct conversation, no external service needed

```bash
antaris chat             # terminal only
antaris start            # all configured channels
```

Each channel has its own adapter with surface-specific formatting. Messages route through the same pipeline regardless of source.

---

### ⏰ Cron Scheduler

Schedule recurring tasks with persistent disk-based scheduling:

```
!cron list               | list all scheduled jobs
!cron remove <id>        | remove a job by ID
!cron run <id>           | force-run a job immediately
```

Supports `every` (recurring interval) and `at` (one-shot) schedule types. Jobs persist across restarts. The scheduler ticks every 10 seconds and fires jobs through the normal pipeline.

---

### 👤 User Profiles

The bot automatically tracks per-user profiles:

- Display name, message count, conversation style
- Last seen timestamp
- Personal notes
- Profile context injected into system prompt for personalized responses

```
!profile                 | view your profile
```

The user tracker also passively learns facts from messages containing personal triggers ("my name is", "I work at", "I prefer", etc.) and updates `USER.md` accordingly.

---

### 📝 Daily Memory Logs

After every 20 conversation turns (configurable), the bot writes a checkpoint to `memory/YYYY-MM-DD.md`:

```
## Session checkpoint - 14:30 UTC
_(auto-written by DailyLog after 20 conversation turns)_
```

On shutdown, a session-end marker is written. This creates a human-readable paper trail of bot activity alongside the BM25 memory store.

---

### 🛡️ Compaction Safety

Context compaction (when the conversation history gets too long and gets compressed) is the #1 cause of AI amnesia. Antaris has a three-layer defense:

**Layer 1: Early warning (75% of threshold)**
When conversation length hits 75% of the compaction threshold, Antaris automatically:
- Builds a structured summary of the current session from its conversation buffer
- Writes it to the daily log (`memory/YYYY-MM-DD.md`)
- Ingests it into BM25 memory with `source="compaction-flush"` so it's searchable later

**Layer 2: Compaction alert (at threshold)**
At the configured threshold (default: 80 messages), the bot:
- Sends a real Discord DM to the owner: "Context is getting long. Consider starting a fresh session."
- Persists the full session summary as a permanent memory (`source="compaction-summary"`)

**Layer 3: Post-compaction restoration (next session start)**
On the first message after compaction, the bot rebuilds context from three sources:
1. **MEMORY.md**: long-term curated facts (highest priority)
2. **Daily logs**: reads the last 2 days of `memory/YYYY-MM-DD.md` files
3. **BM25 recall**: semantic memories from recent sessions

All three are combined and injected into the system prompt. The bot wakes up knowing what happened, not starting from scratch.

**Conversation buffer:** A rolling window of the last 30 conversation turns is maintained in memory. This feeds both the pre-compaction flush and the compaction summary. No sensitive data is persisted beyond what enters the memory store.

```json
{
  "bot": {
    "ownerUserId": "YOUR_DISCORD_USER_ID",
    "compactionThreshold": 80,
    "preCompactionRatio": 0.75,
    "startupRestoreDays": 2
  }
}
```

---

### 🔄 Migration Wizard

Coming from OpenClaw, mem0, LangChain, or LanceDB? One command:

```bash
antaris migrate --from openclaw --path ~/.openclaw
```

The wizard:
- **Auto-detects** your existing setup and scans what's available
- **Copies identity files** (SOUL.md, AGENTS.md, MEMORY.md, etc.) without touching the source
- **Translates config** (provider keys, model routing, channel tokens) between schemas
- **Imports memories** in native format (BM25 shards copied directly, no conversion loss)
- **Handles all channels**: Discord, Telegram, Slack, iMessage, Signal, IRC, Google Chat
- **Dry run mode**: `--dry-run` shows what would happen without writing anything

Supported sources:
| Source | Detection | What Imports |
|--------|-----------|-------------|
| **OpenClaw** | `~/.openclaw/openclaw.json` | Identity, config, channels, memory shards, SQLite, daily logs |
| **mem0** | `~/.mem0/` or Qdrant | Vector memories converted to BM25 |
| **LangChain** | `chat_history.json` or SQLite | Conversation turns |
| **LanceDB** | `.lance` directories | Text extracted from vector tables |
| **Custom** | Any path | Format sniffing (JSON, JSONL, SQLite, Markdown, directories) |

Export your Antaris data for backup or transfer:
```bash
antaris export --full --output ~/backup/
antaris export --memories-only --output memories.jsonl
```

Your OpenClaw agent keeps running untouched. Migration is read-only on the source.

---

### 🛡️ Config Protection

Config files are saved atomically (write to temp file, then rename) and automatically backed up before every save. If the main config file is ever corrupted or empty, the bot falls back to `.config.json.bak` automatically.

This prevents the "config wipe" failure mode where a crash mid-write leaves you with an empty config and a bot that won't start.

---

## All Chat Commands

| Command | Description |
|---------|-------------|
| `!help` | Show all available commands |
| `!ping` | Check if the bot is alive |
| `!status` | Show bot status (memory, providers, model, guard, router) |
| `!model <name>` | Switch LLM model (opus/sonnet/haiku/gpt/gemini/qwen/auto) |
| `!gather [hours]` | Sync Discord history with smart LLM briefings (3/6/12/18/24/48) |
| `!memory [clear]` | View or clear conversation history |
| `!teach <text>` | Teach the bot a fact or preference |
| `!teach list` | List all your teachings |
| `!teach remove <n>` | Remove teaching by number |
| `!teach clear` | Remove all teachings |
| `!focus <topic> [duration]` | Enter focus mode (e.g., `!focus antarisbot 1h`) |
| `!unfocus` | Exit focus mode |
| `!threads` | List all conversation threads |
| `!thread <topic>` | Show a conversation thread (fuzzy match) |
| `!shortcuts` | List all learned implicit shortcuts |
| `!shortcuts remove <phrase>` | Remove a learned shortcut |
| `!export today` | Export today's conversations to markdown |
| `!export week` | Export last 7 days |
| `!export project <name>` | Export conversations about a topic |
| `!export all` | Export everything |
| `!feedback` | Show reaction feedback stats |
| `!feedback clear` | Clear all feedback |
| `!cron list` | List scheduled jobs |
| `!cron remove <id>` | Remove a cron job |
| `!cron run <id>` | Force-run a cron job |
| `!profile` | View your user profile |

---

## All CLI Commands

| Command | Description |
|---------|-------------|
| `antaris init` | Interactive setup wizard |
| `antaris init --headless` | Automated setup (no prompts) |
| `antaris start` | Launch the bot on all configured channels |
| `antaris start --security <mode>` | Launch with specific security mode |
| `antaris stop` | Stop the running bot |
| `antaris restart` | Restart the bot |
| `antaris chat` | Terminal conversation (no channels needed) |
| `antaris status` | Show bot status |
| `antaris security status` | Show security configuration |
| `antaris update` | Check for and apply updates |
| `antaris pulse` | System health check before launch |
| `antaris doctor` | Diagnostic checks |
| `antaris persona show` | View current persona (SOUL.md) |
| `antaris persona edit` | Edit persona in $EDITOR |
| `antaris persona reset` | Reset persona and trigger awakening |
| `antaris memory stats` | Memory usage statistics per user |
| `antaris memory search <query>` | Search memories |
| `antaris memory export` | Export all memories to JSON |
| `antaris config show` | View current configuration |
| `antaris config set model <model>` | Change the default model |
| `antaris migrate --from openclaw` | Import from OpenClaw |
| `antaris migrate --from mem0` | Import from mem0 |
| `antaris migrate --from langchain` | Import from LangChain |
| `antaris migrate --from lancedb` | Import from LanceDB |
| `antaris migrate --from custom --path ~/dir` | Import from custom path |
| `antaris export --full` | Export everything for backup |
| `antaris export --memories-only` | Export just memories as JSONL |
| `antaris logs` | View recent log output |

---

## Supported Providers

| Provider | Models | Notes |
|----------|--------|-------|
| **Anthropic** | Claude Opus, Sonnet, Haiku | OAuth (`oat01`) and API key supported |
| **OpenAI** | GPT-5.4, GPT-5.2, GPT-4o, o1 | Standard API key |
| **Google** | Gemini 3.1 Pro, 2.5 Flash, 2.0 Flash, 1.5 Pro | Standard API key |
| **Ollama** | Any local model (Qwen, Llama, Mistral, etc.) | No API key needed, runs locally |

All four providers can be registered simultaneously. The router selects the best model per message based on complexity tier. Override anytime with `!model`.

---

## Configuration

Config lives at `~/.antarisbot/config.json`. Created by `antaris init` or the setup wizard on first `antaris start`.

```json
{
  "bot": {
    "name": "NoFace",
    "ownerUserId": "YOUR_DISCORD_ID",
    "compactionThreshold": 80
  },
  "provider": {
    "name": "anthropic",
    "model": "claude-sonnet-4-6",
    "apiKey": "sk-ant-..."
  },
  "memory": {
    "store": "~/.antarisbot/memory",
    "searchLimit": 5,
    "minRelevance": 0.1
  },
  "channels": {
    "discord": {
      "enabled": true,
      "token": "your-bot-token",
      "openChannels": ["channel-id-1", "channel-id-2"]
    },
    "telegram": {
      "enabled": false,
      "token": ""
    },
    "slack": {
      "enabled": false,
      "botToken": "",
      "appToken": ""
    }
  },
  "providers": {
    "openai": { "apiKey": "sk-..." },
    "google": { "apiKey": "AIza..." }
  },
  "security": { "mode": "sandboxed" }
}
```

### Data Directories

| Path | Contents |
|------|----------|
| `~/.antarisbot/config.json` | Bot configuration |
| `~/.antarisbot/memory/` | Per-user BM25 memory stores |
| `~/.antarisbot/profiles/` | Per-user profile data |
| `~/.antarisbot/teachings/` | Per-user taught facts |
| `~/.antarisbot/threads/` | Per-user conversation threads |
| `~/.antarisbot/shortcuts/` | Per-user learned shortcuts |
| `~/.antarisbot/proactive/` | Per-user proactive notes |
| `~/.antarisbot/feedback/` | Per-user reaction feedback |
| `~/.antarisbot/exports/` | Conversation export files |
| `~/.antarisbot/logs/` | Structured log files |
| `~/.antarisbot/cron/` | Persistent cron job state |
| `~/.antarisbot/SOUL.md` | Bot persona definition |
| `~/.antarisbot/AGENTS.md` | Behavioral rules |
| `~/.antarisbot/MEMORY.md` | Long-term curated memories |
| `~/.antarisbot/TOOLS.md` | Environment-specific notes |
| `~/.antarisbot/context.json` | Controls which .md files inject and when |

---

## Architecture

Antaris uses a 10-stage message pipeline with error isolation:

```
Message In
    |
    v
[Stage 0] Rate limit check (sliding window)
[Stage 1] Input guard (prompt injection, content filter)
[Stage 2] User identification + profile touch
[Stage 3] Memory recall (BM25 search + startup recall)
[Stage 4] System prompt assembly:
          - Persona (SOUL.md, AGENTS.md)
          - User profile context
          - Teachings
          - Focus mode context
          - Proactive reminders
          - Shortcut expansions
          - Feedback patterns
          - Mood guidance
[Stage 5] Context assembly (history + current message)
[Stage 6] LLM call (with retry + model routing)
[Stage 7] Output guard check
[Stage 8] Memory ingest + thread filing + shortcut observation
[Stage 9] Surface formatting (Discord/Telegram/Slack/Terminal)
    |
    v
Message Out
```

Non-critical stages (memory, profiles, mood, threads) fail gracefully: errors are logged, defaults used, and the pipeline continues. Critical stages (guard, LLM) return a friendly error message.

---

## Powered By

[Antaris Core](https://github.com/Antaris-Analytics-LLC/antaris-suite) (antaris-suite): zero-dependency AI infrastructure.

- **Parsica Memory** (antaris-memory): 11-layer BM25 search engine with semantic decay
- **antaris-guard**: prompt injection detection + content filtering
- **antaris-context**: cross-session context management
- **antaris-router**: adaptive LLM routing with quality learning
- **antaris-pipeline**: message orchestration

---

## Changelog

### v1.2.0
- **Migration wizard**: `antaris migrate` imports from OpenClaw, mem0, LangChain, LanceDB, or custom paths
- **Export system**: `antaris export` dumps identity, config, and memories for backup or transfer
- **Channel translation**: migrates Discord, Telegram, Slack, iMessage, Signal, IRC, Google Chat configs between platforms
- **Format sniffing**: custom path import auto-detects JSON, JSONL, SQLite, Markdown, and native antaris-memory formats
- **Compaction safety: pre-flush**: auto-saves session summary to daily log and memory at 75% of compaction threshold
- **Compaction safety: post-restoration**: rebuilds context from MEMORY.md + daily logs + BM25 on first message after compaction
- **Compaction summary persistence**: session summary ingested into BM25 at compaction time, searchable in future sessions
- **Enhanced daily logs**: writes actual conversation summaries instead of just timestamp markers
- **Conversation buffer**: rolling 30-turn window feeds compaction flush and summary generation
- **Config additions**: `preCompactionRatio`, `startupRestoreDays` for tuning compaction safety behavior
- Rebranded from AntarisBot to **Antaris**
- 1,094 tests (+104 from v1.1.2)

### v1.1.2
- **antaris-memory 5.2.1 integration**: upgraded from 5.0.1
- **Auto-classification at ingest**: removed hardcoded `memory_type="episodic"`, antaris-memory 5.2 auto-classifies (semantic for facts/decisions, episodic for events/chat)
- **Cross-session recall**: `recall()` and `search()` now use `cross_session_recall="semantic"` so facts persist across sessions while chat stays scoped
- **Session/channel provenance**: `ingest()` passes `session_id` and `channel_id` for full provenance tracking
- **Config backup fix**: `save()` and `load_with_fallback()` now use consistent backup path (`.config.json.bak`), fallback actually recovers from wipes

### v1.1.0
- **Smart reconnect briefings**: `!gather` now runs messages through LLM for 2-4 sentence per-channel summaries instead of raw dumps
- **`!teach` command**: persistent per-user knowledge base, auto-injected into every conversation
- **`!focus` / `!unfocus`**: project-aware context budgeting with optional duration
- **Conversation threading**: automatic topic detection, thread filing, `!threads` and `!thread <topic>` retrieval
- **Proactive memory surfacing**: passive note-taking from conversation, greeting-triggered reminders
- **Implicit shortcut learning**: detects repeated patterns, learns after 3 repetitions
- **Mood-aware responses**: adaptive tone matching from message analysis (frustrated/focused/excited/relaxed/neutral)
- **Reaction-based feedback**: Discord emoji (👍/👎) as implicit training signal
- **Conversation export**: `!export today/week/project/all` to clean markdown
- **Startup recall injection**: first message of each session gets recent memory context
- **Compaction alerts**: real Discord DM to owner when context gets long
- **Daily memory logs**: periodic `memory/YYYY-MM-DD.md` checkpoints
- **Atomic config saves**: write-to-tmp + rename, auto-backup, fallback recovery
- 990 tests (+386 from v1.0.0)

### v1.0.0
- Identity stack (SOUL.md, AGENTS.md, MEMORY.md, TOOLS.md, context.json cadence system)
- All chat commands (!status, !model, !recap, !ping, !help, !memory, !cron, !profile, !gather)
- Cron scheduler with disk persistence
- Per-user profiles with context injection
- Ingest filter (blocks pipeline noise from memory)
- Multi-provider dispatcher (Anthropic, OpenAI, Google, Ollama simultaneous)
- Intelligent routing via antaris-router
- 604 tests

### v0.7.0
- Production hardening (SIGTERM, memory flush, empty response handling, 429/503 retry)
- Gemini provider (3.1 Pro, 2.5 Flash, 2.0 Flash, 1.5 Pro, 1.5 Flash)
- Model lineup: GPT-5.2, Gemini 3.1 Pro, Sonnet 4.6
- 502 tests

### v0.6.0
- Security modes (open, sandboxed, locked) with `sys.addaudithook()` enforcement
- AES-256-GCM encrypted memory (locked mode)
- Tool approval middleware with `y/N` prompts (locked mode)
- JSON audit log (locked mode)
- 487 tests

### v0.5.0
- Multi-channel: Discord, Telegram, Slack, Terminal
- Persona system + awakening sequence
- Persistent memory with BM25 search
- Rate limiting, content filtering
- Migration from OpenClaw

---

## License

MIT
