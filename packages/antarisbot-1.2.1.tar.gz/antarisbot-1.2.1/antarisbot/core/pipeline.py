"""
AntarisBot Message Pipeline — Step 10
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from antarisbot.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antarisbot.core.config import Config
from antarisbot.core.memory import BotMemory
from antarisbot.core.guard import BotGuard
from antarisbot.core.rate_limiter import RateLimiter
from antarisbot.llm.base import LLMProvider, Message, LLMResponse
from antarisbot.persona.loader import PersonaLoader
from antarisbot.persona.user_tracker import UserTracker

logger = logging.getLogger(__name__)

MAX_HISTORY = 20


@dataclass
class PipelineResult:
    success: bool
    response_text: str
    blocked: bool = False
    block_reason: str = ""
    tokens_used: int = 0
    cost_usd: float = 0.0
    error: Optional[str] = None
    failed_stages: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)


class Pipeline:
    """
    10-stage message processing pipeline with error isolation.

    Stage 0:  Rate limit check (sliding window, before guard)
    Stage 1:  Input guard check (critical)
    Stage 2:  User identification
    Stage 3:  Memory recall (non-critical)
    Stage 4:  Persona load (non-critical)
    Stage 5:  Context assembly
    Stage 6:  LLM call (critical)
    Stage 7:  Output guard check (non-critical)
    Stage 8:  Memory ingest (non-critical)
    Stage 9:  Surface formatting (non-critical)
    Stage 10: Return result

    Non-critical failures are logged, defaults used, processing continues.
    Critical failures return a friendly error PipelineResult.
    """

    def __init__(
        self,
        config: Config,
        memory: BotMemory,
        guard: BotGuard,
        persona: PersonaLoader,
        llm: LLMProvider,
        awakening=None,
        tool_middleware=None,
        router=None,
        dispatcher=None,
        commands: Optional[any] = None,
        profiles: Optional[any] = None,
        teachings: Optional[any] = None,
        focus: Optional[any] = None,
        threads: Optional[any] = None,
        shortcuts: Optional[any] = None,
        proactive: Optional[any] = None,
        mood: Optional[any] = None,
        feedback: Optional[any] = None,
    ):
        self.config = config
        self.memory = memory
        self.guard = guard
        self.persona = persona
        self.llm = llm
        self.awakening = awakening
        self.tool_middleware = tool_middleware
        self.router = router
        self.dispatcher = dispatcher
        self.commands = commands
        self.profiles = profiles
        self.teachings = teachings
        self.focus = focus
        self.threads = threads
        self.shortcuts = shortcuts
        self.proactive = proactive
        self.mood = mood
        self.feedback = feedback

        self._history: dict[str, list[Message]] = {}
        self._last_message: dict[str, float] = {}
        self._cooldown_seconds: float = 1.0
        self._startup_recalled: bool = False

        # Sliding-window rate limiter lives on Pipeline (not recreated per message)
        # Use isinstance guard: MagicMock attributes are not int and fall back to defaults
        _raw_max = getattr(config, "rate_limit_messages", 20)
        _raw_win = getattr(config, "rate_limit_window_seconds", 60)
        _max_msg = _raw_max if isinstance(_raw_max, int) else 20
        _window  = _raw_win if isinstance(_raw_win, int) else 60
        self._rate_limiter = RateLimiter(max_messages=_max_msg, window_seconds=_window)

        # UserTracker: silently learns facts about the user from their messages
        config_dir = str(getattr(persona, "config_dir", ""))
        self.user_tracker = UserTracker(config_dir) if config_dir else None

    async def process(self, inbound: InboundMessage, adapter: ChannelAdapter) -> PipelineResult:
        """Run a message through all stages. Returns a PipelineResult."""
        failed_stages: list[str] = []

        try:
            # ── Command dispatch (before rate limit — commands are always allowed) ──
            if self.commands:
                cmd_result = await self.commands.dispatch(inbound)
                if cmd_result.handled:
                    return PipelineResult(success=True, response_text=cmd_result.response or "")

            # ── Awakening check ────────────────────────────────────────────
            if self.awakening:
                if self.awakening.is_needed() and not self.awakening.is_active():
                    await asyncio.sleep(1.5)
                    response = self.awakening.start(inbound.user_id)
                    return PipelineResult(success=True, response_text=adapter.format_for_surface(response))
                if self.awakening.is_active():
                    await asyncio.sleep(1.2)
                    response = self.awakening.process(inbound.user_id, inbound.text)
                    return PipelineResult(success=True, response_text=adapter.format_for_surface(response))

            # ── Stage 0: Sliding-window rate limit check ──────────────────
            if not self._rate_limiter.is_allowed(inbound.user_id):
                wait = self._rate_limiter.get_wait_seconds(inbound.user_id)
                wait_int = math.ceil(wait)
                logger.warning("Rate limited user=%s (wait=%.1fs)", inbound.user_id, wait)
                return PipelineResult(
                    success=True,
                    response_text=(
                        f"You're sending messages too fast. "
                        f"Please wait {wait_int} second{'s' if wait_int != 1 else ''}."
                    ),
                    failed_stages=[],
                )

            # ── Basic cooldown ────────────────────────────────────────────
            now = time.time()
            last = self._last_message.get(inbound.user_id, 0)
            if now - last < self._cooldown_seconds:
                logger.debug("Cooldown hit for user=%s", inbound.user_id)
                return PipelineResult(success=True, response_text="")
            self._last_message[inbound.user_id] = now

            # ── Stage 1: Input guard (critical) ──────────────────────────
            try:
                allowed, reason = await self.guard.check_input(inbound.text, inbound.user_id)
                if not allowed:
                    logger.warning("Guard blocked user=%s reason=%s", inbound.user_id, reason)
                    return PipelineResult(
                        success=True, response_text="I can't respond to that.",
                        blocked=True, block_reason=reason, failed_stages=failed_stages,
                    )
            except Exception as e:
                logger.error("Stage 1 (input guard) failed: %s", e, exc_info=True)
                failed_stages.append("input_guard")
                return PipelineResult(
                    success=False,
                    response_text="Something went wrong checking your message. Please try again.",
                    error=str(e), failed_stages=failed_stages,
                )

            user_id = inbound.user_id

            # ── Mood observation (after guard, before stage 2) ────────────
            if self.mood:
                try:
                    self.mood.observe(user_id, inbound.text)
                except Exception:
                    pass

            # ── Stage 2: User profile touch ───────────────────────────────
            if self.profiles:
                try:
                    self.profiles.touch(user_id)
                    profile_context = self.profiles.get_context(user_id)
                    if profile_context:
                        logger.debug("Profile context for %s: %s", user_id, profile_context)
                except Exception as e:
                    logger.warning("Profile touch failed: %s", e)

            # ── Stage 2b: Proactive memory scan ───────────────────────────
            if self.proactive:
                try:
                    self.proactive.scan_and_note(user_id, inbound.text)
                except Exception as e:
                    logger.warning("Proactive scan failed: %s", e)

            # ── Stage 1.5: Tool approval gate (locked mode) ──────────────
            if self.tool_middleware and hasattr(self.tool_middleware, 'approve_and_run'):
                security_mode = getattr(self.tool_middleware, 'mode', 'sandboxed')
                if security_mode == "locked":
                    approved = await self.tool_middleware.approve_and_run(
                        tool_name="process_message",
                        args={"preview": inbound.text[:80]},
                        fn=None,
                    )
                    if approved is None:  # None means rejected
                        return PipelineResult(
                            success=True,
                            response_text="❌ Message processing cancelled.",
                            failed_stages=failed_stages,
                        )

            # ── Stage 3: Memory recall (non-critical) ─────────────────────
            memories: list[str] = []
            try:
                if self.tool_middleware:
                    await self.tool_middleware.approve_and_run(
                        tool_name="memory_recall",
                        args={"query": inbound.text[:60]},
                        fn=None,  # logging only in sandboxed, approval already done above in locked
                    )
                recall_query = inbound.text
                if self.focus:
                    focus_session = self.focus.get(user_id)
                    if focus_session:
                        recall_query = f"{focus_session.topic} {inbound.text}"
                        logger.debug("Focus recall bias: topic=%s user=%s", focus_session.topic, user_id)
                memories = await self.memory.recall(user_id, recall_query)
                logger.debug("Recalled %d memories for user=%s", len(memories), user_id)
            except Exception as e:
                logger.warning("Stage 3 (memory recall) failed: %s", e)
                failed_stages.append("memory_recall")

            # Startup recall: first message only, inject recent context
            if not self._startup_recalled:
                self._startup_recalled = True
                try:
                    _config_dir = str(
                        Path(getattr(self.config, "config_path", "")).parent
                    )
                    _restore_days = getattr(self.config, "startup_restore_days", 2)
                    _file_contexts = self._restore_post_compaction(
                        _config_dir, days=_restore_days
                    )
                    startup_memories = await self.memory.recall(
                        "system", "recent events today"
                    )
                    combined: list[str] = []
                    combined.extend(_file_contexts)
                    if startup_memories:
                        combined.extend(startup_memories[:10])
                    if combined:
                        self._startup_context = combined
                except Exception:
                    pass

            # ── Stage 4: Persona load (non-critical) ──────────────────────
            try:
                system_prompt = self.persona.build_system_prompt(memories)
            except Exception as e:
                logger.warning("Stage 4 (persona load) failed: %s", e)
                failed_stages.append("persona_load")
                system_prompt = "You are a helpful assistant."

            # Inject startup recall context (first message only)
            if hasattr(self, '_startup_context') and self._startup_context:
                recent_block = "\n\n---\n## Recently (startup recall):\n" + "\n".join(f"- {m}" for m in self._startup_context)
                system_prompt += recent_block
                del self._startup_context  # one-shot, don't repeat

            # Inject user profile context
            if self.profiles:
                try:
                    profile_ctx = self.profiles.get_context(user_id)
                    if profile_ctx:
                        system_prompt += f"\n\n---\n## About this user:\n{profile_ctx}"
                except Exception:
                    pass

            # Inject user teaching context
            if self.teachings:
                try:
                    teaching_ctx = self.teachings.get_context(user_id)
                    if teaching_ctx:
                        system_prompt += f"\n\n---\n{teaching_ctx}"
                except Exception:
                    pass

            # Inject focus context
            if self.focus:
                try:
                    focus_ctx = self.focus.get_context(user_id)
                    if focus_ctx:
                        system_prompt += f"\n\n---\n{focus_ctx}"
                except Exception:
                    pass

            # Inject proactive memory surfaces
            if self.proactive:
                try:
                    proactive_ctx = self.proactive.get_context(user_id, inbound.text)
                    if proactive_ctx:
                        system_prompt += f"\n\n---\n{proactive_ctx}"
                except Exception as e:
                    logger.warning("Proactive context failed: %s", e)

            # Inject shortcut context
            if self.shortcuts:
                try:
                    shortcut_ctx = self.shortcuts.get_context(user_id, inbound.text)
                    if shortcut_ctx:
                        system_prompt += f"\n\n---\n{shortcut_ctx}"
                except Exception:
                    pass

            # Inject mood style guidance
            if self.mood:
                try:
                    mood_ctx = self.mood.get_context(user_id)
                    if mood_ctx:
                        system_prompt += f"\n\n---\n{mood_ctx}"
                except Exception:
                    pass

            # Inject reaction-based feedback context
            if self.feedback:
                try:
                    feedback_ctx = self.feedback.get_context(user_id)
                    if feedback_ctx:
                        system_prompt += f"\n\n---\n{feedback_ctx}"
                except Exception as e:
                    logger.warning("Feedback context failed: %s", e)

            # ── Stage 5: Context assembly ─────────────────────────────────
            history = self._get_history(user_id)
            messages = history + [Message(role="user", content=inbound.text)]

            # ── Stage 6: LLM call (critical) — with retry ────────────────
            _max_retries = 3
            raw_text: str = ""
            for _attempt in range(_max_retries):
                try:
                    # ── Stage 5.5: Route to best model (if router available) ──
                    _use_model = self.config.model  # default
                    _use_provider = None

                    # Check for user model override first
                    _user_override = None
                    if self.commands:
                        _user_override = self.commands.get_model_override(inbound.user_id)
                    if _user_override:
                        # Find provider for this model from router config
                        _use_model = _user_override
                        _use_provider = self._resolve_provider_for_model(_user_override)
                        logger.info("User model override: %s/%s", _use_provider, _use_model)
                    elif self.router:
                        try:
                            decision = self.router.route(prompt=inbound.text)
                            _use_model = decision.model
                            _use_provider = decision.provider
                            logger.info(
                                "Router: %s → %s/%s (tier=%s, conf=%.2f)",
                                inbound.text[:50], decision.provider, decision.model,
                                decision.tier, decision.confidence,
                            )
                        except Exception as _re:
                            logger.warning("Router failed, using default model: %s", _re)

                    # Dispatch to routed provider+model, or fall back to single provider
                    if self.dispatcher and _use_provider:
                        llm_response: LLMResponse = await self.dispatcher.complete(
                            provider=_use_provider,
                            model=_use_model,
                            messages=messages,
                            system=system_prompt,
                        )
                    else:
                        llm_response = await self.llm.complete(
                            messages=messages, system=system_prompt, model=_use_model,
                        )
                    raw_text = llm_response.content
                    break  # success
                except Exception as e:
                    err_str = str(e).lower()
                    is_transient = any(kw in err_str for kw in ["rate limit", "429", "500", "503", "timeout", "overloaded"])
                    if is_transient and _attempt < _max_retries - 1:
                        wait = 2 ** _attempt  # 1s, 2s, 4s
                        logger.warning(
                            "Stage 6 transient error (attempt %d/%d, retry in %ds): %s",
                            _attempt + 1, _max_retries, wait, e,
                        )
                        await asyncio.sleep(wait)
                        continue
                    logger.error("Stage 6 (LLM call) failed: %s", e, exc_info=True)
                    failed_stages.append("llm_call")
                    return PipelineResult(
                        success=False,
                        response_text="Something went wrong on my end. Please try again in a moment.",
                        error=str(e), failed_stages=failed_stages,
                    )

            if not raw_text or not raw_text.strip():
                logger.warning("LLM returned empty response for user=%s", user_id)
                return PipelineResult(
                    success=False,
                    response_text="I didn't get a response. Please try again.",
                    error="empty_llm_response",
                    failed_stages=failed_stages + ["llm_empty"],
                )

            # ── Stage 7: Output guard (non-critical) ──────────────────────
            try:
                _ok, filtered_text = await self.guard.check_output(raw_text)
            except Exception as e:
                logger.warning("Stage 7 (output guard) failed: %s", e)
                failed_stages.append("output_guard")
                filtered_text = raw_text

            # ── Stage 8: Memory ingest (non-critical) ─────────────────────
            try:
                await self.memory.ingest(user_id, inbound.text, filtered_text)
            except Exception as e:
                logger.warning("Stage 8 (memory ingest) failed: %s", e)
                failed_stages.append("memory_ingest")

            # ── Stage 8c: Thread filing (non-critical) ───────────────────
            if self.threads:
                try:
                    self.threads.file_turn(user_id, "user", inbound.text)
                    self.threads.file_turn(user_id, "assistant", filtered_text)
                except Exception as e:
                    logger.warning("Thread filing failed: %s", e)
                    failed_stages.append("thread_filing")

            # ── Stage 8b: USER.md update (non-critical) ──────────────────
            learned_facts: list[str] = []
            try:
                await self._maybe_update_user_context(inbound, filtered_text)
                if self.user_tracker is not None:
                    learned_facts = self.user_tracker.process_message(inbound.text)
                    if learned_facts:
                        logger.debug(
                            "UserTracker: learned %d fact(s) for user=%s",
                            len(learned_facts),
                            user_id,
                        )
            except Exception as e:
                logger.warning("USER.md update failed: %s", e)
                failed_stages.append("user_context_update")

            # ── Stage 8d: Shortcut observation (non-critical) ────────────
            if self.shortcuts:
                try:
                    learned = self.shortcuts.observe(user_id, inbound.text, filtered_text)
                    if learned:
                        logger.info("New shortcut learned: %s", learned)
                except Exception as e:
                    logger.warning("Shortcut observation failed: %s", e)

            self._update_history(user_id, inbound.text, filtered_text)

            # ── Stage 9: Surface formatting (non-critical) ────────────────
            try:
                formatted = adapter.format_for_surface(filtered_text)
            except Exception as e:
                logger.warning("Stage 9 (formatting) failed: %s", e)
                failed_stages.append("surface_format")
                formatted = filtered_text

            result_metadata: dict = {}
            if learned_facts:
                result_metadata["learned_facts"] = learned_facts

            return PipelineResult(
                success=True,
                response_text=formatted,
                tokens_used=llm_response.input_tokens + llm_response.output_tokens,
                cost_usd=llm_response.cost_usd,
                failed_stages=failed_stages,
                metadata=result_metadata,
            )

        except Exception as e:
            logger.error("Pipeline unexpected error: %s", e, exc_info=True)
            return PipelineResult(
                success=False, response_text="Something went wrong on my end. Try again.",
                error=str(e), failed_stages=failed_stages,
            )

    def _resolve_provider_for_model(self, model: str) -> Optional[str]:
        """Try to resolve which provider owns a given model name."""
        model_lower = model.lower()
        if "claude" in model_lower or "anthropic" in model_lower:
            return "anthropic"
        if "gpt" in model_lower or "openai" in model_lower:
            return "openai"
        if "gemini" in model_lower or "google" in model_lower:
            return "google"
        if "qwen" in model_lower or "ollama" in model_lower:
            return "ollama"
        return None

    def _get_history(self, user_id: str) -> list[Message]:
        return list(self._history.get(user_id, []))

    def _update_history(self, user_id: str, user_text: str, bot_text: str):
        if user_id not in self._history:
            self._history[user_id] = []
        hist = self._history[user_id]
        hist.append(Message(role="user", content=user_text))
        hist.append(Message(role="assistant", content=bot_text))
        if len(hist) > MAX_HISTORY:
            self._history[user_id] = hist[-MAX_HISTORY:]

    def clear_history(self, user_id: str):
        self._history.pop(user_id, None)

    def history_length(self, user_id: str) -> int:
        return len(self._history.get(user_id, []))

    def _restore_post_compaction(
        self,
        config_dir: str,
        days: int = 2,
    ) -> list[str]:
        """Read daily logs and MEMORY.md to rebuild context after compaction.

        Priority order: MEMORY.md facts first, then daily log summaries.
        Handles missing files gracefully.

        Args:
            config_dir: Path to the bot config directory (where MEMORY.md lives
                        and where memory/ subdirectory contains daily logs).
            days: How many past days of daily logs to read.

        Returns:
            List of context strings to inject into the startup context.
        """
        from datetime import timedelta, date as _date

        contexts: list[str] = []
        base = Path(config_dir)

        # 1. MEMORY.md (long-term curated facts) - highest priority
        memory_md = base / "MEMORY.md"
        if memory_md.exists():
            try:
                content = memory_md.read_text(encoding="utf-8").strip()
                if content:
                    contexts.append(f"## Long-term memory (MEMORY.md)\n{content}")
                    logger.debug("Loaded MEMORY.md (%d chars)", len(content))
            except Exception as e:
                logger.warning("Could not read MEMORY.md: %s", e)
        else:
            logger.debug("MEMORY.md not found at %s, skipping", memory_md)

        # 2. Daily logs for the last N days
        memory_dir = base / "memory"
        today = _date.today()
        for delta in range(days):
            log_date = today - timedelta(days=delta)
            log_path = memory_dir / f"{log_date.isoformat()}.md"
            if log_path.exists():
                try:
                    content = log_path.read_text(encoding="utf-8").strip()
                    if content:
                        label = "Today" if delta == 0 else f"{delta} day(s) ago"
                        contexts.append(
                            f"## Daily log ({label}, {log_date.isoformat()})\n{content}"
                        )
                        logger.debug(
                            "Loaded daily log %s (%d chars)", log_path.name, len(content)
                        )
                except Exception as e:
                    logger.warning("Could not read daily log %s: %s", log_path, e)
            else:
                logger.debug("No daily log for %s, skipping", log_date.isoformat())

        return contexts

    async def _maybe_update_user_context(self, inbound: InboundMessage, bot_response: str):
        text = inbound.text.lower()
        personal_triggers = [
            "my name is", "i'm called", "call me",
            "i work", "i live", "i'm from", "i am from",
            "my job", "my role", "i like", "i love", "i hate",
            "i prefer", "i usually", "i always", "i never",
            "my favorite", "i'm a ", "i am a ",
        ]
        triggered = any(trigger in text for trigger in personal_triggers)
        if not triggered:
            return
        sentences = [s.strip() for s in inbound.text.split('.') if s.strip()]
        relevant = [s for s in sentences if any(t in s.lower() for t in personal_triggers)]
        if relevant:
            fact = '. '.join(relevant[:2])
            self.persona.update_user_context(f"- {fact}")
            logger.debug("Updated USER.md with: %s", fact[:80])
