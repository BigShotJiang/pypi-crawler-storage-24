from __future__ import annotations

import json
import shutil
import sqlite3
from pathlib import Path
from typing import Optional

from .base import BaseMigration, MigrationResult, ScanResult


# Default context cadence for identity files
DEFAULT_CONTEXT_CADENCE: dict = {
    "SOUL.md": "every",
    "AGENTS.md": "every",
    "MEMORY.md": "startup",
    "TOOLS.md": "startup",
    "USER.md": "manual",
}


class OpenClawMigration(BaseMigration):
    """
    Migrates from OpenClaw to AntarisBot.

    Sources:
      - Identity files: SOUL.md, AGENTS.md, MEMORY.md, TOOLS.md, USER.md,
        HEARTBEAT.md, IDENTITY.md from ~/.openclaw/workspace/
      - Config: ~/.openclaw/openclaw.json (provider, channels, models)
      - Native antaris-memory shards if antaris-suite plugin exists
      - OpenClaw built-in session memory from ~/.openclaw/memory/main.sqlite
      - Daily logs from workspace/memory/*.md

    Detection: checks for openclaw.json OR SOUL.md/AGENTS.md in source_path.
    """

    def __init__(
        self,
        source_path: str,
        dest_path: str,
        dry_run: bool = False,
        user_id: str = "migrated-user",
    ):
        super().__init__(source_path, dest_path, dry_run, user_id)
        # Resolve openclaw.json location
        self._openclaw_json = self._find_openclaw_json()

    def _find_openclaw_json(self) -> Optional[Path]:
        """Try several locations for openclaw.json.

        Looks relative to source_path first, then falls back to the standard
        ~/.openclaw/openclaw.json location (only when source_path is itself
        inside ~/.openclaw/).
        """
        candidates: list[Path] = [
            self.source_path / "openclaw.json",
            self.source_path.parent / "openclaw.json",
        ]
        # Only check the global location if source_path is under ~/.openclaw/
        openclaw_root = Path.home() / ".openclaw"
        try:
            self.source_path.relative_to(openclaw_root)
            candidates.append(openclaw_root / "openclaw.json")
        except ValueError:
            pass  # source_path is NOT under ~/.openclaw/, skip global lookup

        for c in candidates:
            if c.exists():
                return c
        return None

    def detect(self) -> bool:
        """Return True if openclaw.json exists near source_path, or workspace has SOUL/AGENTS."""
        if self._openclaw_json and self._openclaw_json.exists():
            return True
        if not self.source_path.exists():
            return False
        if (self.source_path / "SOUL.md").exists():
            return True
        if (self.source_path / "AGENTS.md").exists():
            return True
        return False

    def scan(self) -> ScanResult:
        result = ScanResult()

        # Identity files present: check both root and workspace/ subdirectory
        workspace_dir = self.source_path / "workspace"
        for name in self.IDENTITY_FILES:
            if (self.source_path / name).exists():
                result.identity_files.append(name)
            elif workspace_dir.exists() and (workspace_dir / name).exists():
                result.identity_files.append(name)

        # Config
        result.has_config = self._openclaw_json is not None

        # Channels
        if self._openclaw_json:
            try:
                cfg = json.loads(self._openclaw_json.read_text())
                channels = cfg.get("channels", {})
                result.has_channels = bool(channels)
            except Exception:
                pass

        # Memory count estimate
        memory_count = 0
        workspace_mem = self.source_path / "memory"
        if workspace_mem.exists():
            memory_count += len(list(workspace_mem.glob("*.md")))

        # antaris-suite shards
        openclaw_root = Path.home() / ".openclaw"
        is_openclaw_src = False
        try:
            self.source_path.relative_to(openclaw_root)
            is_openclaw_src = True
        except ValueError:
            pass

        shard_check_paths: list[Path] = [self.source_path / "antaris_memory_store"]
        if is_openclaw_src:
            shard_check_paths.insert(0, openclaw_root / "extensions" / "antaris-suite")

        for shard_path in shard_check_paths:
            if shard_path.exists():
                memory_count += len(list(shard_path.rglob("*.json")))
                result.notes.append(f"Native antaris-memory shards at {shard_path}")

        # SQLite session memory (only when source is under ~/.openclaw/)
        sqlite_path = openclaw_root / "memory" / "main.sqlite"
        if is_openclaw_src and sqlite_path.exists():
            try:
                conn = sqlite3.connect(str(sqlite_path))
                cur = conn.execute("SELECT COUNT(*) FROM chunks")
                memory_count += cur.fetchone()[0]
                conn.close()
                result.notes.append("OpenClaw SQLite session memory found")
            except Exception:
                pass

        result.memory_count = memory_count
        return result

    def migrate(self, selections: Optional[list[str]] = None) -> MigrationResult:
        result = MigrationResult(success=True, source="OpenClaw")

        # Load openclaw config if available
        openclaw_cfg: dict = {}
        if self._openclaw_json:
            try:
                openclaw_cfg = json.loads(self._openclaw_json.read_text())
            except Exception as e:
                result.warnings.append(f"Could not read openclaw.json: {e}")

        # 1. Identity files
        self._do_identity_files(result, openclaw_cfg)

        # 2. Config translation
        if openclaw_cfg:
            self._do_config_translation(result, openclaw_cfg)

        # 3. Memory import
        self._do_memory_import(result, openclaw_cfg)

        return result

    # ------------------------------------------------------------------
    # Step: identity files
    # ------------------------------------------------------------------

    def _resolve_identity_file(self, name: str) -> Optional[Path]:
        """Find an identity file in source_path or source_path/workspace/."""
        direct = self.source_path / name
        if direct.exists():
            return direct
        workspace = self.source_path / "workspace" / name
        if workspace.exists():
            return workspace
        return None

    def _do_identity_files(self, result: MigrationResult, openclaw_cfg: dict):
        """Copy identity markdown files to dest."""
        # SOUL.md (special: merge IDENTITY.md into it)
        soul_src = self._resolve_identity_file("SOUL.md")
        if soul_src:
            content = soul_src.read_text()
            identity_src = self._resolve_identity_file("IDENTITY.md")
            if identity_src:
                content += f"\n\n---\n## Identity\n{identity_src.read_text()}"
            self._write(self.dest_path / "SOUL.md", content)
            result.items_migrated["soul"] = True
        else:
            result.items_migrated["soul"] = False
            result.warnings.append("No SOUL.md found in source")

        # USER.md
        user_src = self._resolve_identity_file("USER.md")
        if user_src:
            self._write(self.dest_path / "USER.md", user_src.read_text())
            result.items_migrated["user"] = True
        else:
            result.items_migrated["user"] = False

        # Other identity files
        for name in ("AGENTS.md", "MEMORY.md", "TOOLS.md", "HEARTBEAT.md"):
            src = self._resolve_identity_file(name)
            if src:
                self._copy_file(src, self.dest_path / name)
                result.items_migrated[name.lower().replace(".md", "")] = True

        # context.json
        context_dest = self.dest_path / "context.json"
        if not context_dest.exists() or self.dry_run:
            self._write(context_dest, json.dumps(DEFAULT_CONTEXT_CADENCE, indent=2))
            result.items_migrated["context_json"] = True

    # ------------------------------------------------------------------
    # Step: config translation
    # ------------------------------------------------------------------

    def _do_config_translation(self, result: MigrationResult, openclaw_cfg: dict):
        """Translate openclaw.json into AntarisBot config.json + router/config.json."""
        antaris_cfg = self._translate_config(openclaw_cfg)

        config_dest = self.dest_path / "config.json"
        if not config_dest.exists() or self.dry_run:
            self._write(config_dest, json.dumps(antaris_cfg, indent=2))
            result.items_migrated["config"] = True
        else:
            result.items_migrated["config"] = False
            result.warnings.append("config.json already exists, skipped (use --all to overwrite)")

        # router/config.json
        router_cfg = self._translate_router_config(openclaw_cfg)
        if router_cfg.get("models"):
            router_dest = self.dest_path / "router" / "config.json"
            if not router_dest.exists() or self.dry_run:
                self._write(router_dest, json.dumps(router_cfg, indent=2))
                result.items_migrated["router_config"] = True

        # Report discord token status
        discord_cfg = antaris_cfg.get("channels", {}).get("discord", {})
        if discord_cfg.get("token"):
            result.items_migrated["discord_token"] = "found"
        else:
            result.items_migrated["discord_token"] = False

    # ------------------------------------------------------------------
    # Step: memory import
    # ------------------------------------------------------------------

    def _do_memory_import(self, result: MigrationResult, openclaw_cfg: dict):
        """Import memories from all available sources."""
        memory_count = 0

        # Resolve user_id: use allowlist from discord config if available
        user_id = self.user_id
        if user_id == "migrated-user" and openclaw_cfg:
            allowlist = (
                openclaw_cfg.get("channels", {})
                .get("discord", {})
                .get("allowlist", [])
            )
            if allowlist:
                user_id = str(allowlist[0])
                result.warnings.append(
                    f"Assigned memories to user_id={user_id} (first Discord allowlist entry). "
                    "Use --user-id to override."
                )

        # 1. Native antaris-memory shards
        # Only check system paths when source_path is itself under ~/.openclaw/
        openclaw_root = Path.home() / ".openclaw"
        is_openclaw_source = False
        try:
            self.source_path.relative_to(openclaw_root)
            is_openclaw_source = True
        except ValueError:
            pass

        shard_candidates: list[Path] = [
            self.source_path / "antaris_memory_store",
            self.source_path / "workspace" / "antaris_memory_store",
        ]
        if is_openclaw_source:
            shard_candidates.insert(0, openclaw_root / "extensions" / "antaris-suite")
            shard_candidates.insert(1, openclaw_root / "workspace" / "antaris_memory_store")
        # Deduplicate by resolved path
        seen: set[str] = set()
        shard_paths: list[Path] = []
        for p in shard_candidates:
            resolved = str(p.resolve())
            if resolved not in seen:
                seen.add(resolved)
                shard_paths.append(p)

        for shard_src in shard_paths:
            if shard_src.exists():
                count = self._import_native_shards(shard_src, user_id)
                if count > 0:
                    memory_count += count
                    result.items_migrated["native_shards"] = count

        # 2. SQLite session memory (only when source is under ~/.openclaw/)
        sqlite_path = Path.home() / ".openclaw" / "memory" / "main.sqlite"
        if is_openclaw_source and sqlite_path.exists():
            count = self._import_sqlite_memory(sqlite_path, user_id)
            if count > 0:
                memory_count += count
                result.items_migrated["sqlite_memories"] = count

        # 3. Daily log markdown files (check both root/memory and workspace/memory)
        daily_log_dirs = [
            self.source_path / "workspace" / "memory",
            self.source_path / "memory",
        ]
        daily_imported = False
        for workspace_mem in daily_log_dirs:
            if workspace_mem.exists() and any(workspace_mem.glob("*.md")):
                count = self._copy_daily_logs(workspace_mem)
                if count > 0:
                    memory_count += count
                    result.items_migrated["daily_logs"] = count
                    daily_imported = True
                    break
        if not daily_imported:
            result.warnings.append("No daily log .md files found in source")

        result.items_migrated["memories"] = memory_count
        if memory_count == 0:
            result.warnings.append("No memories were imported")

    def _import_native_shards(self, shard_src: Path, user_id: str) -> int:
        """Copy native antaris-memory shards directly to dest memory dir."""
        dest_user = self.dest_path / "memory" / user_id
        if self.dry_run:
            files = list(shard_src.rglob("*"))
            count = len([f for f in files if f.is_file()])
            print(f"  [dry-run] would copy {count} shard files from {shard_src}")
            return count
        dest_user.mkdir(parents=True, exist_ok=True)
        count = 0
        for f in shard_src.rglob("*"):
            if f.is_file():
                rel = f.relative_to(shard_src)
                target = dest_user / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(f), str(target))
                count += 1
        return count

    def _import_sqlite_memory(self, sqlite_path: Path, user_id: str) -> int:
        """Read chunks table from OpenClaw SQLite memory, ingest via MemorySystem."""
        try:
            conn = sqlite3.connect(str(sqlite_path))
            rows = conn.execute("SELECT text FROM chunks").fetchall()
            conn.close()
            texts = [r[0] for r in rows if r[0] and r[0].strip()]
            if not texts:
                return 0
            return self._import_memories(texts, user_id, source="openclaw-sqlite")
        except Exception as e:
            print(f"  ⚠️  Could not read SQLite memory: {e}")
            return 0

    def _copy_daily_logs(self, memory_src: Path) -> int:
        """Copy workspace memory/*.md files to dest memory dir."""
        dest_mem = self.dest_path / "memory"
        if self.dry_run:
            files = [f for f in memory_src.glob("*.md") if f.is_file()]
            print(f"  [dry-run] would copy {len(files)} daily log files")
            return len(files)
        dest_mem.mkdir(parents=True, exist_ok=True)
        count = 0
        for f in memory_src.glob("*.md"):
            if f.is_file():
                shutil.copy2(str(f), str(dest_mem / f.name))
                count += 1
        return count
