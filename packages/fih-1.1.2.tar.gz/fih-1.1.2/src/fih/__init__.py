"""fih package."""

from .game import main

__version__ = "0.1.2"

__all__ = ["main", "__version__"]
