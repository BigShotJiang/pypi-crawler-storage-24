# fih

`fih` is fishing in your terminal.

It draws a little water tank in text, lets you move a fishing line with your arrow keys, and sends fish swimming across the screen. Catch them with the hook to build up your totals.

## Features

- Terminal-based fishing game with a text water display
- Move the hook with the arrow keys
- Emoji fish drift across the water from either direction
- Catch tracking for `🐟`, `🐠`, `🐡`, and `🦈`
- Works as an installable PyPI package with a `fih` command

## Install

```bash
pip install fih
```

Or build it locally:

```bash
python -m build
pip install dist/fih-0.1.2-py3-none-any.whl
```

## Play

Run:

```bash
fih
```

Controls:

- `Left` / `Right`: move the line across the water
- `Up` / `Down`: raise or lower the hook
- `Q`: quit

## Notes

- A Unicode-friendly terminal is recommended so the fish and hook render nicely.
- On older Windows terminals, emoji width can vary a bit.

## Upload To PyPI

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload --repository testpypi dist/*
python -m twine upload dist/*
```
