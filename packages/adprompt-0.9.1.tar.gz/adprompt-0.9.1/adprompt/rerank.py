from typing import List

from openai import BaseModel as OpenAIBaseModel
from pydantic import BaseModel


class RerankScore(BaseModel):
    index: int
    score: float


class RerankResponse(OpenAIBaseModel):
    id: str
    model: str
    data: List[RerankScore]
