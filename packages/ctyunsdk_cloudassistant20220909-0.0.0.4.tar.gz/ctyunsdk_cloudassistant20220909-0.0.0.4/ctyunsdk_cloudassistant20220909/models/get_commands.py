from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class GetCommandsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    filters: Optional[List['GetCommandsRequestFilters']] = None  # 过滤条件，json形式数组。
    isPublic: Optional[bool] = None  # 是否为公共命令
    pageNo: Optional[int] = None  # 当前页码，默认为1
    pageSize: Optional[int] = None  # 分页查询时设置的每页行数，最大值为100，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class GetCommandsRequestFilters:
    key: str  # 过滤条件的字段名，key取值范围为：commandID（命令ID），commandName（命令名称），commandType（命令类型）, startTime（创建时间-起始时间，格式："2024-01-01 16:58:01"）, endTime（创建时间-截止时间，格式同上），sceneName（公共命令-命令分类）；<br />其中：命令ID、命令名称支持模糊查询
    value: str  # 过滤字段对应的值


@dataclass_json
@dataclass
class GetCommandsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['GetCommandsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class GetCommandsReturnObj:
    pageNo: Optional[int] = None  # 当前页码
    totalCount: Optional[int] = None  # 命令总个数
    pageSize: Optional[int] = None  # 每页行数
    commands: Optional[List['GetCommandsReturnObjCommands']] = None  # 命令列表


@dataclass_json
@dataclass
class GetCommandsReturnObjCommands:
    commandID: Optional[str] = None  # 命令ID
    commandName: Optional[str] = None  # 命令名称
    description: Optional[str] = None  # 命令描述
    commandType: Optional[str] = None  # 命令类型
    commandContent: Optional[str] = None  # 明文命令内容
    workingDirectory: Optional[str] = None  # 命令在实例中的运行目录
    timeout: Optional[int] = None  # 命令超时时间
    isPublic: Optional[bool] = None  # 是否是公共命令
    version: Optional[str] = None  # 公共命令的版本，仅公共命令返回该字段
    owner: Optional[str] = None  # 公共命令的提供者，仅公共命令返回该字段
    sceneName: Optional[int] = None  # 公共市场命令的分类，仅公共市场命令有该字段，取值范围：0、1、2、3，分别对应：Linux、Windows、游戏应用、运维工具
    enabledParameter: Optional[bool] = None  # 是否使用自定义参数
    defaultParameter: Optional[str] = None  # 自定义参数默认值
    createTime: Optional[str] = None  # 命令创建时间
    updateTime: Optional[str] = None  # 命令更新时间
