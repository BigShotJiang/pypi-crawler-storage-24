from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class GetCaAgentRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    instanceIDs: str  # 云主机、物理机ID列表, 使用英文","分割
    pageNo: Optional[int] = None  # 当前页码，默认值为1
    pageSize: Optional[int] = None  # 分页查询时设置的每页行数，最大值为100，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class GetCaAgentResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['GetCaAgentReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class GetCaAgentReturnObj:
    caAgentStatusSet: Optional[List['GetCaAgentReturnObjCaAgentStatusSet']] = None  # 状态列表
    totalCount: Optional[int] = None  # 总个数
    pageNo: Optional[int] = None  # 当前页码
    pageSize: Optional[int] = None  # 每页行数


@dataclass_json
@dataclass
class GetCaAgentReturnObjCaAgentStatusSet:
    status: Optional[str] = None  # agent当前状态，取值范围：<br/>Error：异常；<br/>NotInstalled：未安装；<br/>Running：运行中；
    agentName: Optional[str] = None  # agent名称
    version: Optional[str] = None  # agent版本
    instanceID: Optional[str] = None  # 实例ID
