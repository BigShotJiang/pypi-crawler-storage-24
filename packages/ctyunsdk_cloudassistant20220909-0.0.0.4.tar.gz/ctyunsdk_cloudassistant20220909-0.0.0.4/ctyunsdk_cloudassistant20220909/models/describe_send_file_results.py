from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class DescribeSendFileResultsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    fileName: Optional[str] = None  # 文件名称
    invokedID: Optional[str] = None  # 执行ID
    pageNo: Optional[int] = None  # 当前页码，默认为1
    pageSize: Optional[int] = None  # 分页查询时设置的每页行数，最大值为100，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class DescribeSendFileResultsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['DescribeSendFileResultsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class DescribeSendFileResultsReturnObj:
    results: Optional[List['DescribeSendFileResultsReturnObjResults']] = None  # 文件上传结果集合
    pageNo: Optional[int] = None  # 当前页码
    totalCount: Optional[int] = None  # 总个数
    pageSize: Optional[int] = None  # 每页行数


@dataclass_json
@dataclass
class DescribeSendFileResultsReturnObjResults:
    createTime: Optional[str] = None  # 文件上传任务创建时间
    finishTime: Optional[str] = None  # 文件上传任务完成时间
    invokeTime: Optional[float] = None  # 文件上传任务执行时间
    invocationRecordStatus: Optional[str] = None  # 文件上传任务的总执行状态，取值范围：<br/>Pending：等待上传中<br/>Running：上传中<br/>Finished：上传完成<br/>Failed：上传失败<br />Delivering：命令下发中<br />DeliverFailed：命令下发失败<br />PartialDeliverFailed：部分命令下发失败
    invokedID: Optional[str] = None  # 执行ID
    fileID: Optional[str] = None  # 文件ID
    fileName: Optional[str] = None  # 文件名称
    description: Optional[str] = None  # 文件描述
    osType: Optional[str] = None  # 目标系统：linux/windows
    instanceType: Optional[str] = None  # 实例类型：CA_VM/CA_BM
    fileContent: Optional[str] = None  # 明文文件内容
    targetDirectory: Optional[str] = None  # 文件上传目标路径
    timeout: Optional[int] = None  # 文件上传超时时间
    fileOwner: Optional[str] = None  # 文件所属用户
    fileGroup: Optional[str] = None  # 文件所属用户组
    fileMode: Optional[str] = None  # 文件权限
    overwrite: Optional[bool] = None  # 是否覆盖
    vmCount: Optional[int] = None  # 文件下发的实例数量
    invokeInstances: Optional[List['DescribeSendFileResultsReturnObjResultsInvokeInstances']] = None  # 文件上传的实例列表


@dataclass_json
@dataclass
class DescribeSendFileResultsReturnObjResultsInvokeInstances:
    createdTime: Optional[str] = None  # 单台实例的文件上传任务创建时间
    updatedTime: Optional[str] = None  # 单台实例的文件上传任务完成时间
    invokeTime: Optional[float] = None  # 单台实例的文件上传任务执行时间
    invocationStatus: Optional[str] = None  # 单台实例的文件下发执行状态，可能值：<br/>Pending：系统正在下发文件；<br/>Running：文件下发中；<br/>Success：文件下发成功；<br/>Failed：文件下发失败
    output: Optional[str] = None  # 输出信息
    errorInfo: Optional[str] = None  # 错误信息
    exitCode: Optional[int] = None  # 退出码
    instanceID: Optional[str] = None  # 实例ID
    invokedID: Optional[str] = None  # 执行ID
