from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class DescribeUserInvocationRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    commandType: Optional[str] = None  # 命令类型，取值范围：Shell、PowerShell、Bat、Python
    invokedID: Optional[str] = None  # 命令执行ID
    pageNo: Optional[int] = None  # 当前页码，默认为1
    pageSize: Optional[int] = None  # 分页查询时设置的每页行数，最大值为100，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class DescribeUserInvocationResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['DescribeUserInvocationReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class DescribeUserInvocationReturnObj:
    results: Optional[List['DescribeUserInvocationReturnObjResults']] = None  # 命令执行结果集合
    pageNo: Optional[int] = None  # 当前页码
    totalCount: Optional[int] = None  # 命令总个数
    pageSize: Optional[int] = None  # 每页行数


@dataclass_json
@dataclass
class DescribeUserInvocationReturnObjResults:
    createTime: Optional[str] = None  # 命令执行任务创建时间
    finishTime: Optional[str] = None  # 命令执行任务完成时间
    invokeTime: Optional[float] = None  # 命令执行时间
    invokeStatus: Optional[str] = None  # 命令执行任务的总执行状态，取值范围：<br />Pending：等待执行中<br/>Running：运行中<br/>Success：执行成功<br/>Failed：执行失败<br />Delivering：命令下发中<br />DeliverFailed：命令下发失败<br />PartialDeliverFailed：部分命令下发失败<br />Cancelling：命令取消中<br />CancelFailed：命令取消失败<br />Cancelled：命令已取消
    instanceType: Optional[str] = None  # 实例类型：CA_VM（云主机）、CA_BM（物理机）
    invokedID: Optional[str] = None  # 执行ID
    commandID: Optional[str] = None  # 命令ID
    commandName: Optional[str] = None  # 命令名称
    commandType: Optional[str] = None  # 命令类型
    commandDescription: Optional[str] = None  # 命令描述
    commandContent: Optional[str] = None  # 明文命令内容
    workingDirectory: Optional[str] = None  # 执行目录
    timeout: Optional[int] = None  # 超时时间
    execUser: Optional[str] = None  # 执行用户
    enabledParameter: Optional[bool] = None  # 是否开启自定义参数
    defaultParameter: Optional[str] = None  # 自定义参数
    invokeInstances: Optional[List['DescribeUserInvocationReturnObjResultsInvokeInstances']] = None  # 实例执行结果列表


@dataclass_json
@dataclass
class DescribeUserInvocationReturnObjResultsInvokeInstances:
    createdTime: Optional[str] = None  # 单台实例的命令执行任务创建时间
    updatedTime: Optional[str] = None  # 单台实例的命令执行任务完成时间
    invokeTime: Optional[float] = None  # 单台实例的命令执行时间
    invocationStatus: Optional[str] = None  # 单台实例的命令运行状态，取值范围：<br />Pending：下发中<br/>Running：运行中<br/>Success：执行成功<br/>Failed：执行失败<br />Cancelling：命令取消中<br />CancelFailed：命令取消失败<br />Cancelled：命令已取消<br />Terminated：命令已终止
    instanceID: Optional[str] = None  # 实例ID
    invokedID: Optional[str] = None  # 执行ID
    output: Optional[str] = None  # 输出信息
    exitCode: Optional[int] = None  # 退出码
    errorInfo: Optional[str] = None  # 错误信息
