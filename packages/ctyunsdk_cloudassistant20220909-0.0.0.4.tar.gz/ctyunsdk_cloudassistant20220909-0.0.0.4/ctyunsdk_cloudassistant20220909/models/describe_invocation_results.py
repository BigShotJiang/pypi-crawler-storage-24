from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class DescribeInvocationResultsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    commandID: Optional[str] = None  # 命令ID
    invokedID: Optional[str] = None  # 命令执行ID
    pageNo: Optional[int] = None  # 当前页码，默认为1
    pageSize: Optional[int] = None  # 分页查询时设置的每页行数，最大值为100，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class DescribeInvocationResultsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['DescribeInvocationResultsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class DescribeInvocationResultsReturnObj:
    results: Optional[List['DescribeInvocationResultsReturnObjResults']] = None  # 命令执行结果集合
    pageNo: Optional[int] = None  # 当前页码
    totalCount: Optional[int] = None  # 命令总个数
    pageSize: Optional[int] = None  # 每页行数


@dataclass_json
@dataclass
class DescribeInvocationResultsReturnObjResults:
    invocationStatus: Optional[str] = None  # 单台实例的命令运行状态，可能值：<br/>Pending：下发中；<br/>Running：运行中；<br/>Success：执行成功；<br/>Failed：执行失败<br />Cancelling：命令取消中<br />CancelFailed：命令取消失败<br />Cancelled：命令已取消<br />Terminated：命令已终止
    createTime: Optional[str] = None  # 命令执行创建时间
    updateTime: Optional[str] = None  # 命令执行完成时间
    invokedID: Optional[str] = None  # 命令执行ID
    commandID: Optional[str] = None  # 命令ID
    instanceID: Optional[str] = None  # 实例ID
    output: Optional[str] = None  # 命令执行后的输出信息
    exitCode: Optional[int] = None  # 命令退出码
    errorInfo: Optional[str] = None  # 命令执行失败原因详情
    invocationRecordStatus: Optional[str] = None  # 命令执行任务的总执行状态，取值范围：<br />Pending：等待执行中；<br/>Running：运行中；<br/>Finished：执行完成；<br/>Failed：执行失败；<br />Delivering：命令下发中<br />DeliverFailed：命令下发失败<br />PartialDeliverFailed：部分命令下发失败<br />Cancelling：命令取消中<br />CancelFailed：命令取消失败<br />Cancelled：命令已取消
