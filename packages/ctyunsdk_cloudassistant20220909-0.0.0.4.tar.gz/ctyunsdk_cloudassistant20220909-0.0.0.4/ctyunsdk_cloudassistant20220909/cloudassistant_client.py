from ctyun_python_sdk_core import CtyunClient, Credential, ClientConfig, CtyunRequestException

from .models import *


class CloudassistantClient:
    def __init__(self, client_config: ClientConfig):
        self.endpoint = client_config.endpoint
        self.credential = Credential(client_config.access_key_id, client_config.access_key_secret)
        self.ctyun_client = CtyunClient(client_config.verify_tls)

    def delete_command(self, request: DeleteCommandRequest) -> DeleteCommandResponse:
        """删除用户自己创建的云助手命令，支持批量删除。"""
        url = f"{self.endpoint}/v4/cloud-assistant/delete-command"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, DeleteCommandResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def describe_send_file_results(self, request: DescribeSendFileResultsRequest) -> DescribeSendFileResultsResponse:
        """查询上传到弹性云主机或物理机的文件的结果。"""
        url = f"{self.endpoint}/v4/cloud-assistant/describe-send-file-results"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, DescribeSendFileResultsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def describe_invocation_results(self, request: DescribeInvocationResultsRequest) -> DescribeInvocationResultsResponse:
        """查询一条或多条云助手命令在弹性云主机、物理机中的执行结果。"""
        url = f"{self.endpoint}/v4/cloud-assistant/describe-invocation-results"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, DescribeInvocationResultsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def describe_user_invocation(self, request: DescribeUserInvocationRequest) -> DescribeUserInvocationResponse:
        """查询一条或多条云助手命令在弹性云主机、物理机中的执行结果。"""
        url = f"{self.endpoint}/v4/cloud-assistant/describe-user-invocation"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, DescribeUserInvocationResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def get_ca_agent(self, request: GetCaAgentRequest) -> GetCaAgentResponse:
        """查询一台或多台实例的云助手agent状态（仅支持批量查询弹性云主机或物理机，不支持混合查询）。"""
        url = f"{self.endpoint}/v4/cloud-assistant/get-ca-agent"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, GetCaAgentResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def get_commands(self, request: GetCommandsRequest) -> GetCommandsResponse:
        """查询用户手动创建的云助手命令或者云助手公共命令。"""
        url = f"{self.endpoint}/v4/cloud-assistant/get-commands"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, GetCommandsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))



