"""
Minimal h5py-based reader for LVK PEDataRelease files.

This keeps only the pieces gwtc_analysis uses:
- labels
- posterior samples
- maxL sample lookup
- PSD data + plotting
- config values
- skymap payload + lightweight plotting
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import numpy as np

from .read_skymap import FixedOrderSkyMap


def _normalize_value(value: Any) -> Any:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")

    if isinstance(value, np.generic):
        return _normalize_value(value.item())

    if isinstance(value, np.ndarray):
        if value.ndim == 0:
            return _normalize_value(value.item())
        if value.size == 1:
            return _normalize_value(value.reshape(-1)[0])
        if value.dtype.kind in {"S", "U", "O"}:
            return [_normalize_value(item) for item in value.tolist()]
        return value

    if isinstance(value, list):
        return [_normalize_value(item) for item in value]

    if isinstance(value, tuple):
        return tuple(_normalize_value(item) for item in value)

    return value


def _read_dataset_value(dataset: h5py.Dataset) -> Any:
    return _normalize_value(dataset[()])


def _read_group_dict(group: h5py.Group) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, obj in group.items():
        if isinstance(obj, h5py.Group):
            out[str(key)] = _read_group_dict(obj)
        elif isinstance(obj, h5py.Dataset):
            out[str(key)] = _read_dataset_value(obj)
    return out


def _as_bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on"}
    return bool(value)


class PosteriorSamples(dict[str, np.ndarray]):
    """Dict-like posterior samples with a lazily computed maxL view."""

    def __init__(self, data: dict[str, np.ndarray]):
        super().__init__(data)
        self._maxl_cache: dict[str, np.ndarray] | None = None

    def _best_index(self) -> int:
        for key in ("log_likelihood", "loglikelihood", "log_l", "log_posterior", "logposterior"):
            if key in self:
                try:
                    return int(np.nanargmax(np.asarray(self[key], dtype=float)))
                except Exception:
                    continue
        return 0

    @property
    def maxL(self) -> dict[str, np.ndarray]:
        if self._maxl_cache is None:
            idx = self._best_index()
            self._maxl_cache = {}
            for key, values in self.items():
                arr = np.asarray(values)
                if arr.ndim == 0:
                    self._maxl_cache[key] = np.asarray([arr.item()])
                else:
                    self._maxl_cache[key] = np.asarray(arr[idx : idx + 1])
        return self._maxl_cache


class PSDCollection(dict[str, np.ndarray]):
    """Detector PSD curves keyed by detector name."""

    def plot(self, fmin: float = 20.0):
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(6, 4))
        for det, values in sorted(self.items()):
            arr = np.asarray(values, dtype=float)
            if arr.ndim != 2 or arr.shape[1] != 2:
                continue
            freq = arr[:, 0]
            psd = arr[:, 1]
            mask = np.isfinite(freq) & np.isfinite(psd) & (freq > 0.0) & (psd > 0.0)
            if fmin is not None:
                mask &= freq >= float(fmin)
            if not np.any(mask):
                continue
            ax.loglog(freq[mask], psd[mask], label=det)

        ax.set_xlabel("Frequency [Hz]")
        ax.set_ylabel("PSD [1/Hz]")
        ax.grid(True, which="both", alpha=0.25)
        if self:
            ax.legend(frameon=False, fontsize=8)
        return fig


class PESkyMap:
    """Minimal skymap wrapper with local fixed-order HEALPix plotting."""

    def __init__(self, data: np.ndarray, meta_data: dict[str, Any] | None = None):
        self.data = np.asarray(data, dtype=float)
        self.meta_data = meta_data or {}

    @property
    def nest(self) -> bool:
        return _as_bool(self.meta_data.get("nest", False))

    def plot(self, contour: list[int] | tuple[int, ...] | None = None):
        import matplotlib.pyplot as plt

        sky = FixedOrderSkyMap.from_probability_array(self.data, nest=self.nest)
        ra_grid, dec_grid, density_deg2, credible_grid = sky.rasterize()

        fig, ax = plt.subplots(figsize=(7, 4.5))
        image = ax.imshow(
            density_deg2,
            origin="lower",
            extent=(0.0, 360.0, -90.0, 90.0),
            aspect="auto",
            cmap="hot",
        )

        levels = sorted({float(level) for level in (contour or []) if 0.0 < float(level) < 100.0})
        if levels:
            cs = ax.contour(
                ra_grid,
                dec_grid,
                credible_grid,
                levels=levels,
                colors="white",
                linewidths=0.9,
            )
            ax.clabel(cs, fmt=lambda value: f"{value:g}%", fontsize=8)

        ax.set_xlim(360.0, 0.0)
        ax.set_ylim(-90.0, 90.0)
        ax.set_xlabel("RA [deg]")
        ax.set_ylabel("Dec [deg]")
        ax.grid(alpha=0.15, linewidth=0.6)

        text_lines: list[str] = []
        distmean = self.meta_data.get("distmean")
        diststd = self.meta_data.get("diststd")
        if distmean is not None and diststd is not None:
            try:
                text_lines.append(f"Distance: {round(float(distmean))}±{round(float(diststd))} Mpc")
            except Exception:
                pass
        for level in levels:
            area = sky.credible_area_deg2(level)
            text_lines.append(f"{level:g}% area: {_format_area(area)} deg^2")
        if text_lines:
            ax.text(
                0.015,
                0.985,
                "\n".join(text_lines),
                transform=ax.transAxes,
                va="top",
                ha="left",
                fontsize=8,
                bbox={"facecolor": "black", "alpha": 0.45, "edgecolor": "none", "pad": 6},
                color="white",
            )

        cbar = fig.colorbar(image, ax=ax, pad=0.02)
        cbar.set_label(r"probability density [deg$^{-2}$]")
        fig.tight_layout()
        return fig, ax


def _format_area(area: float) -> str:
    if area <= 100.0:
        return np.format_float_positional(area, precision=3, fractional=False, trim="-")
    return f"{int(round(area)):,d}"


@dataclass(slots=True)
class PEDataRelease:
    source_path: Path
    labels: list[str]
    samples_dict: dict[str, PosteriorSamples]
    psd: dict[str, PSDCollection]
    skymap: dict[str, PESkyMap]
    config: dict[str, dict[str, Any]]
    approximant: list[Any]


def _read_posterior_samples(dataset: h5py.Dataset) -> PosteriorSamples:
    raw = dataset[()]
    names = list(raw.dtype.names or [])
    if not names:
        raise ValueError("posterior_samples dataset has no named columns")
    return PosteriorSamples({name: np.asarray(raw[name]) for name in names})


def _read_approximant(group: h5py.Group) -> Any:
    obj = group.get("approximant")
    if isinstance(obj, h5py.Dataset):
        return _read_dataset_value(obj)
    if isinstance(obj, h5py.Group):
        return _read_group_dict(obj)
    return {}


def _read_psd(group: h5py.Group | None) -> PSDCollection:
    out = PSDCollection()
    if not isinstance(group, h5py.Group):
        return out
    for det, obj in group.items():
        if isinstance(obj, h5py.Dataset):
            out[str(det)] = np.asarray(obj[()], dtype=float)
    return out


def _read_skymap(group: h5py.Group | None) -> PESkyMap | None:
    if not isinstance(group, h5py.Group):
        return None

    data_obj = group.get("data")
    if not isinstance(data_obj, h5py.Dataset):
        return None

    meta_obj = group.get("meta_data")
    meta = _read_group_dict(meta_obj) if isinstance(meta_obj, h5py.Group) else {}
    return PESkyMap(np.asarray(data_obj[()], dtype=float), meta_data=meta)


def read(path: str | Path) -> PEDataRelease:
    """Read an LVK PEDataRelease HDF5 file into a minimal local object model."""

    source_path = Path(path)
    labels: list[str] = []
    samples_dict: dict[str, PosteriorSamples] = {}
    psd: dict[str, PSDCollection] = {}
    skymap: dict[str, PESkyMap] = {}
    config: dict[str, dict[str, Any]] = {}
    approximant: list[Any] = []

    with h5py.File(source_path, "r") as handle:
        for label, obj in handle.items():
            if not isinstance(obj, h5py.Group):
                continue
            if "posterior_samples" not in obj:
                continue

            label = str(label)
            labels.append(label)
            samples_dict[label] = _read_posterior_samples(obj["posterior_samples"])
            psd[label] = _read_psd(obj.get("psds"))
            config_obj = obj.get("config_file")
            config[label] = _read_group_dict(config_obj) if isinstance(config_obj, h5py.Group) else {}
            approximant.append(_read_approximant(obj))

            sky = _read_skymap(obj.get("skymap"))
            if sky is not None:
                skymap[label] = sky

    return PEDataRelease(
        source_path=source_path,
        labels=labels,
        samples_dict=samples_dict,
        psd=psd,
        skymap=skymap,
        config=config,
        approximant=approximant,
    )


read_pe_data_release = read
