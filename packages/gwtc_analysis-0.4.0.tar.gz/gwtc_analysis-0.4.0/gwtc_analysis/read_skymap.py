from __future__ import annotations

import argparse
import gzip
import io
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
from astropy import units as u
from astropy.io import fits
from astropy_healpix import HEALPix, level_to_nside, uniq_to_level_ipix


_SR_TO_DEG2 = (180.0 / np.pi) ** 2


def _stable_descending_order(values: np.ndarray) -> np.ndarray:
    return np.argsort(-np.asarray(values, dtype=float), kind="mergesort")


def _greedy_credible_percent(prob_mass: np.ndarray, rank_key: np.ndarray) -> np.ndarray:
    prob_mass = np.asarray(prob_mass, dtype=float)
    total = float(prob_mass.sum())
    if not np.isfinite(total) or total <= 0.0:
        raise ValueError("skymap probability mass is empty or invalid")

    order = _stable_descending_order(rank_key)
    credible = np.empty_like(prob_mass, dtype=float)
    credible[order] = 100.0 * np.cumsum(prob_mass[order]) / total
    return credible


def _pixel_area_sr_from_nside(nside: np.ndarray | int) -> np.ndarray:
    nside = np.asarray(nside, dtype=float)
    return 4.0 * np.pi / (12.0 * nside**2)


def _first_table_hdu(hdul: fits.HDUList) -> fits.BinTableHDU | None:
    for hdu in hdul:
        if isinstance(hdu, fits.BinTableHDU) and hdu.data is not None:
            return hdu
    return None


def _normalize_ra_deg(ra_deg: np.ndarray | float) -> np.ndarray:
    return np.mod(np.asarray(ra_deg, dtype=float), 360.0)


@dataclass
class _LevelLookup:
    level: int
    shift: int
    ipix: np.ndarray
    density_deg2: np.ndarray
    credible_percent: np.ndarray


class SkyMapData:
    def credible_level_percent(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        raise NotImplementedError

    def density_deg2_at(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        raise NotImplementedError

    def credible_area_deg2(self, credible_percent: float) -> float:
        raise NotImplementedError

    def rasterize(
        self,
        *,
        n_ra: int = 480,
        n_dec: int = 240,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        ra = np.linspace(0.0, 360.0, n_ra, endpoint=False) + 180.0 / n_ra
        dec = np.linspace(-90.0, 90.0, n_dec)
        ra_grid, dec_grid = np.meshgrid(ra, dec)
        density = self.density_deg2_at(ra_grid, dec_grid)
        credible = self.credible_level_percent(ra_grid, dec_grid)
        return ra_grid, dec_grid, density, credible


@dataclass
class MultiOrderSkyMap(SkyMapData):
    density_deg2: np.ndarray
    credible_percent_map: np.ndarray
    pixel_area_deg2: np.ndarray
    max_level: int
    lookups: list[_LevelLookup]

    @classmethod
    def from_hdu(cls, hdu: fits.BinTableHDU) -> "MultiOrderSkyMap":
        data = hdu.data
        if data is None or "UNIQ" not in data.columns.names or "PROBDENSITY" not in data.columns.names:
            raise ValueError("invalid multi-order skymap table")

        uniq = np.asarray(data["UNIQ"], dtype=np.int64)
        prob_density_sr = np.asarray(data["PROBDENSITY"], dtype=float)
        level, ipix = uniq_to_level_ipix(uniq)
        level = np.asarray(level, dtype=int)
        ipix = np.asarray(ipix, dtype=np.int64)

        nside = level_to_nside(level)
        pixel_area_sr = _pixel_area_sr_from_nside(nside)
        prob_mass = prob_density_sr * pixel_area_sr
        credible_percent = _greedy_credible_percent(prob_mass, prob_density_sr)
        density_deg2 = prob_density_sr / _SR_TO_DEG2
        pixel_area_deg2 = pixel_area_sr * _SR_TO_DEG2

        lookups: list[_LevelLookup] = []
        max_level = int(level.max())
        for lev in sorted({int(x) for x in level.tolist()}, reverse=True):
            mask = level == lev
            order = np.argsort(ipix[mask], kind="mergesort")
            lookups.append(
                _LevelLookup(
                    level=lev,
                    shift=2 * (max_level - lev),
                    ipix=ipix[mask][order],
                    density_deg2=density_deg2[mask][order],
                    credible_percent=credible_percent[mask][order],
                )
            )

        return cls(
            density_deg2=density_deg2,
            credible_percent_map=credible_percent,
            pixel_area_deg2=pixel_area_deg2,
            max_level=max_level,
            lookups=lookups,
        )

    def _max_level_ipix(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        hp = HEALPix(nside=int(level_to_nside(self.max_level)), order="nested")
        lon = _normalize_ra_deg(ra_deg) * u.deg
        lat = np.asarray(dec_deg, dtype=float) * u.deg
        return np.asarray(hp.lonlat_to_healpix(lon, lat), dtype=np.int64)

    def _lookup(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float, field: str) -> np.ndarray:
        target_shape = np.asarray(ra_deg, dtype=float).shape
        ipix_max = np.ravel(self._max_level_ipix(ra_deg, dec_deg))
        out = np.full(ipix_max.shape, np.nan, dtype=float)
        remaining = np.ones(ipix_max.shape, dtype=bool)

        for lookup in self.lookups:
            if not np.any(remaining):
                break

            parent = ipix_max
            if lookup.shift:
                parent = np.right_shift(parent, lookup.shift)

            idx = np.searchsorted(lookup.ipix, parent)
            valid = idx < lookup.ipix.size
            if not np.any(valid):
                continue

            matched = np.zeros(ipix_max.shape, dtype=bool)
            matched[valid] = lookup.ipix[idx[valid]] == parent[valid]
            fill = remaining & matched
            if not np.any(fill):
                continue

            values = getattr(lookup, field)
            out[fill] = values[idx[fill]]
            remaining[fill] = False

        if np.any(remaining):
            raise ValueError("skymap lookup did not cover the full sky")

        return out.reshape(target_shape)

    def credible_level_percent(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        return self._lookup(ra_deg, dec_deg, "credible_percent")

    def density_deg2_at(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        return self._lookup(ra_deg, dec_deg, "density_deg2")

    def credible_area_deg2(self, credible_percent: float) -> float:
        mask = self.credible_percent_map <= float(credible_percent)
        return float(self.pixel_area_deg2[mask].sum())


@dataclass
class FixedOrderSkyMap(SkyMapData):
    density_deg2: np.ndarray
    credible_percent_map: np.ndarray
    pixel_area_deg2: float
    healpix: HEALPix

    @classmethod
    def from_probability_array(cls, values: np.ndarray, *, nest: bool = False) -> "FixedOrderSkyMap":
        values = np.asarray(values, dtype=float).reshape(-1)
        npix = int(values.size)
        nside = int(round(np.sqrt(npix / 12.0)))
        if 12 * nside * nside != npix:
            raise ValueError(f"invalid HEALPix probability array length: {npix}")

        total = float(values.sum())
        if not np.isfinite(total) or total <= 0.0:
            raise ValueError("HEALPix probability array is empty or invalid")

        prob_mass = values / total
        pixel_area_sr = float(_pixel_area_sr_from_nside(nside))
        pixel_area_deg2 = pixel_area_sr * _SR_TO_DEG2
        density_deg2 = prob_mass / pixel_area_deg2
        credible_percent = _greedy_credible_percent(prob_mass, prob_mass)
        healpix = HEALPix(nside=nside, order="nested" if nest else "ring")
        return cls(
            density_deg2=density_deg2,
            credible_percent_map=credible_percent,
            pixel_area_deg2=pixel_area_deg2,
            healpix=healpix,
        )

    @classmethod
    def from_hdu(cls, hdu: fits.ImageHDU | fits.PrimaryHDU | fits.BinTableHDU) -> "FixedOrderSkyMap":
        header = hdu.header
        ordering = str(header.get("ORDERING", "RING")).strip().lower()
        order = "nested" if ordering.startswith("nest") else "ring"

        if isinstance(hdu, fits.BinTableHDU):
            data = hdu.data
            if data is None:
                raise ValueError("empty HEALPix table")
            names = list(data.columns.names)
            colname = "PROB" if "PROB" in names else ("PROBDENSITY" if "PROBDENSITY" in names else names[0])
            values = np.asarray(data[colname], dtype=float).reshape(-1)
        else:
            values = np.asarray(hdu.data, dtype=float).reshape(-1)

        npix = int(values.size)
        nside = header.get("NSIDE")
        if nside is None:
            nside = int(round(np.sqrt(npix / 12.0)))
        nside = int(nside)
        pixel_area_sr = float(_pixel_area_sr_from_nside(nside))
        pixel_area_deg2 = pixel_area_sr * _SR_TO_DEG2

        column_names = list(hdu.data.columns.names) if isinstance(hdu, fits.BinTableHDU) and hdu.data is not None else []
        if isinstance(hdu, fits.BinTableHDU) and "PROBDENSITY" in column_names:
            prob_mass = values * pixel_area_sr
            density_deg2 = values / _SR_TO_DEG2
            rank_key = values
        else:
            prob_mass = values
            density_deg2 = values / pixel_area_deg2
            rank_key = prob_mass

        credible_percent = _greedy_credible_percent(prob_mass, rank_key)
        healpix = HEALPix(nside=nside, order=order)
        return cls(
            density_deg2=density_deg2,
            credible_percent_map=credible_percent,
            pixel_area_deg2=pixel_area_deg2,
            healpix=healpix,
        )

    def _indices(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        lon = _normalize_ra_deg(ra_deg) * u.deg
        lat = np.asarray(dec_deg, dtype=float) * u.deg
        return np.asarray(self.healpix.lonlat_to_healpix(lon, lat), dtype=np.int64)

    def credible_level_percent(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        return self.credible_percent_map[self._indices(ra_deg, dec_deg)]

    def density_deg2_at(self, ra_deg: np.ndarray | float, dec_deg: np.ndarray | float) -> np.ndarray:
        return self.density_deg2[self._indices(ra_deg, dec_deg)]

    def credible_area_deg2(self, credible_percent: float) -> float:
        mask = self.credible_percent_map <= float(credible_percent)
        return float(mask.sum() * self.pixel_area_deg2)


def load_skymap(skymap_file: str | Path) -> SkyMapData:
    path = Path(skymap_file)
    with fits.open(path) as hdul:
        return _load_skymap_hdul(hdul)


def load_skymap_bytes(data: bytes) -> SkyMapData:
    if len(data) >= 2 and data[0] == 0x1F and data[1] == 0x8B:
        data = gzip.decompress(data)
    with fits.open(io.BytesIO(data)) as hdul:
        return _load_skymap_hdul(hdul)


def _load_skymap_hdul(hdul: fits.HDUList) -> SkyMapData:
    table_hdu = _first_table_hdu(hdul)
    if table_hdu is not None:
        ordering = str(table_hdu.header.get("ORDERING", "")).strip().upper()
        if ordering == "NUNIQ" and "UNIQ" in table_hdu.data.columns.names:
            return MultiOrderSkyMap.from_hdu(table_hdu)

        return FixedOrderSkyMap.from_hdu(table_hdu)

    return FixedOrderSkyMap.from_hdu(hdul[0])


def credible_level_at_radec_percent(skymap_path: str | Path, ra_deg: float, dec_deg: float) -> float:
    skymap = load_skymap(skymap_path)
    value = skymap.credible_level_percent(float(ra_deg), float(dec_deg))
    return float(np.asarray(value, dtype=float))


def _format_area(area: float) -> str:
    if area <= 100.0:
        return np.format_float_positional(area, precision=3, fractional=False, trim="-")
    return f"{int(round(area)):,d}"


def plot_skymap_with_ra_dec(
    skymapFILE: str | Path,
    title: str,
    ra: float,
    dec: float,
    color: str,
    contour_levels: Iterable[float] = (50, 90),
) -> str:
    skymap = load_skymap(skymapFILE)
    ra_grid, dec_grid, density_deg2, credible_grid = skymap.rasterize()
    credible_at_point = float(np.asarray(skymap.credible_level_percent(float(ra), float(dec)), dtype=float))

    fig, ax = plt.subplots(figsize=(11, 5.5))
    image = ax.imshow(
        density_deg2,
        origin="lower",
        extent=(0.0, 360.0, -90.0, 90.0),
        aspect="auto",
        cmap="hot",
    )

    levels = sorted({float(level) for level in contour_levels if 0.0 < float(level) < 100.0})
    if levels:
        contour = ax.contour(
            ra_grid,
            dec_grid,
            credible_grid,
            levels=levels,
            colors="white",
            linewidths=0.9,
        )
        ax.clabel(contour, fmt=lambda value: f"{value:g}%", fontsize=8)

    ax.scatter(
        [float(_normalize_ra_deg(ra))],
        [float(dec)],
        marker="*",
        s=160,
        c="white",
        edgecolors="black",
        linewidths=0.8,
        zorder=5,
    )
    ax.set_xlim(360.0, 0.0)
    ax.set_ylim(-90.0, 90.0)
    ax.set_xlabel("RA [deg]")
    ax.set_ylabel("Dec [deg]")
    ax.set_title(title)
    ax.grid(color=color, alpha=0.15, linewidth=0.6)

    text_lines = [f"Event: {title}", f"Credible @ point: {credible_at_point:.3g}%"]
    for level in levels:
        area = skymap.credible_area_deg2(level)
        text_lines.append(f"{level:g}% area: {_format_area(area)} deg^2")
    ax.text(
        0.015,
        0.985,
        "\n".join(text_lines),
        transform=ax.transAxes,
        va="top",
        ha="left",
        fontsize=9,
        bbox={"facecolor": "black", "alpha": 0.45, "edgecolor": "none", "pad": 6},
        color="white",
    )

    cbar = fig.colorbar(image, ax=ax, pad=0.02)
    cbar.set_label(r"probability density [deg$^{-2}$]")

    plotname = f"plot_{title}.png"
    fig.tight_layout()
    fig.savefig(plotname, dpi=150)
    plt.close(fig)
    return plotname


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot a GW sky map and mark a sky position.")
    parser.add_argument("skymapFILE", type=str, help="Path to the sky map FITS file")
    parser.add_argument("--title", default="GW", help="Plot title")
    parser.add_argument("--ra", type=float, default=47.0, help="Right ascension in degrees")
    parser.add_argument("--dec", type=float, default=-44.0, help="Declination in degrees")
    args = parser.parse_args()
    plot_skymap_with_ra_dec(args.skymapFILE, args.title, args.ra, args.dec, "grey")


if __name__ == "__main__":
    main()
