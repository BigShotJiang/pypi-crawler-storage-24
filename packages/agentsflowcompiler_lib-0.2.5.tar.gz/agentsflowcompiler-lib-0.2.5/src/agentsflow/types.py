"""
Shared type definitions for agentsflow.

TypedDicts and type aliases used across llm, agent, and tools packages
to enable IDE autocomplete and static type checking.
"""

from __future__ import annotations

from typing import Any, Literal, TypedDict


# ── Chat / Messages ─────────────────────────────────────────────────────────

class _ChatMessageRequired(TypedDict):
    role: Literal["system", "user", "assistant", "tool"]


class ChatMessage(_ChatMessageRequired, total=False):
    """OpenAI-style chat message. role required; content, tool_calls, tool_call_id optional."""
    content: str | None
    # Either ToolCallSpec (from provider) or OpenAI format {id, type, function: {name, arguments}}
    tool_calls: list[dict[str, Any]]
    tool_call_id: str


class ToolCallSpec(TypedDict):
    """Single tool call from LLM response."""
    id: str
    name: str
    arguments: dict[str, Any]


class ToolCallsResponse(TypedDict):
    """LLM response when model wants to call tools."""
    tool_calls: list[ToolCallSpec]


LLMChatResponse = str | ToolCallsResponse


# ── Tool Schemas ─────────────────────────────────────────────────────────────

class OpenAIFunctionSchema(TypedDict):
    """OpenAI function schema nested under 'function'."""
    name: str
    description: str
    parameters: dict[str, Any]


class OpenAIToolSchema(TypedDict):
    """OpenAI function-calling tool schema."""
    type: Literal["function"]
    function: OpenAIFunctionSchema


class AnthropicToolSchema(TypedDict):
    """Anthropic tool schema."""
    name: str
    description: str
    input_schema: dict[str, Any]


# ── Token / Stats ────────────────────────────────────────────────────────────

class TokensSummary(TypedDict):
    """Token usage summary from get_tokens_summary."""
    agent_name: str
    model: str
    prompt_system_tokens: int
    last_user_prompt: int
    last_rag_tokens: int
    last_full_prompt_tokens: int
    last_answer_tokens: int


# ── Tool call log (internal) ─────────────────────────────────────────────────

class ToolCallLogEntry(TypedDict):
    """Single entry in agent tool call log.

    ``docker`` is True when the tool ran inside Docker (``docker_enabled`` on identity).
    """
    name: str
    arguments: dict[str, Any]
    result: str
    docker: bool
