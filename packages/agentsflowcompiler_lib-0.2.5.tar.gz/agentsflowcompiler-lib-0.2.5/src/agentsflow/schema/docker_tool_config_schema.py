"""Docker execution configuration for a single tool."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, model_validator


# ── Enums ───────────────────────────────────────────────────────────────────

class NetworkMode(str, Enum):
    BRIDGE = "bridge"
    HOST = "host"
    NONE = "none"
    CUSTOM = "custom"


class RestartPolicy(str, Enum):
    NO = "no"
    ON_FAILURE = "on-failure"
    ALWAYS = "always"
    UNLESS_STOPPED = "unless-stopped"


# ── Sub-configs ──────────────────────────────────────────────────────────────

class DockerUserConfig(BaseModel):
    """User/permission settings inside the container."""
    run_as_root: bool = Field(
        default=False,
        description="Run as root. Default: non-root (uid 1000).",
    )
    user: Optional[str] = Field(
        default=None,
        description="Explicit UID:GID, e.g. '1000:1000'. Ignored when run_as_root=True.",
    )
    read_only_rootfs: bool = Field(
        default=True,
        description="Mount the container root filesystem as read-only.",
    )


class DockerNetworkConfig(BaseModel):
    """Network settings for the container."""
    mode: NetworkMode = Field(
        default=NetworkMode.NONE,
        description="Docker network mode. Default: none (isolated).",
    )
    custom_network: Optional[str] = Field(
        default=None,
        description="Name of a custom Docker network (required when mode='custom').",
    )
    enable_ipv4: bool = Field(default=True)
    enable_ipv6: bool = Field(default=False)
    dns: Optional[list[str]] = Field(
        default=None,
        description="Custom DNS servers, e.g. ['8.8.8.8'].",
    )
    expose_ports: Optional[list[str]] = Field(
        default=None,
        description="Port mappings, e.g. ['8080:80'].",
    )
    allowed_hosts: Optional[list[str]] = Field(
        default=None,
        description="Whitelist of hostnames/IPs the container may reach. "
                    "Enforced via iptables rules injected at startup.",
    )


class DockerResourceLimits(BaseModel):
    """Resource constraints."""
    memory_limit: Optional[str] = Field(
        default="256m",
        description="Max memory, e.g. '256m', '1g'.",
    )
    cpu_limit: Optional[float] = Field(
        default=1.0,
        description="CPU cores limit, e.g. 0.5, 1.0, 2.0.",
    )
    cpu_shares: Optional[int] = Field(default=None)
    shm_size: Optional[str] = Field(default=None)
    pids_limit: Optional[int] = Field(
        default=64,
        description="Max number of processes.",
    )
    timeout: Optional[int] = Field(
        default=30,
        description="Hard kill timeout in seconds for this tool execution.",
    )


class DockerVolumeMount(BaseModel):
    """A single volume mount."""
    host_path: str
    container_path: str
    read_only: bool = True


class DockerSecurityConfig(BaseModel):
    """Security hardening."""
    no_new_privileges: bool = Field(
        default=True,
        description="Prevent privilege escalation.",
    )
    cap_drop: list[str] = Field(
        default_factory=lambda: ["ALL"],
        description="Capabilities to drop. Default: drop ALL.",
    )
    cap_add: Optional[list[str]] = Field(
        default=None,
        description="Capabilities to add back, e.g. ['NET_BIND_SERVICE'].",
    )
    seccomp_profile: Optional[str] = Field(
        default=None,
        description="Path to custom seccomp JSON profile.",
    )
    apparmor_profile: Optional[str] = Field(
        default=None,
        description="AppArmor profile name.",
    )


# ── Main Config ──────────────────────────────────────────────────────────────

class DockerToolConfig(BaseModel):
    """
    Docker execution configuration for a tool.

    Loaded from: agents/<agent>/tools/custom_tools/<tool_name>/docker_config.yaml
    (for custom tools) or agents/<agent>/tools/builtin_tools/<tool_name>/docker_config.yaml
    (for built-in tools with per-agent Docker overrides).

    **Development (default):** ``mount_host_tool_script: true`` — the agent's ``tool.py`` is
    bind-mounted into the container at ``container_tool_path``.

    **Production:** set ``mount_host_tool_script: false`` and use an image built with your
    tool already at ``container_tool_path`` (e.g. ``COPY tool.py /opt/app/tool.py`` in a
    Dockerfile). No host script is mounted; ``TOOL_ARGS`` is still passed via env.
    """
    image: str = Field(
        description="Docker image, e.g. 'python:3.11-slim', 'node:20-alpine'.",
    )
    user: DockerUserConfig = Field(default_factory=DockerUserConfig)
    network: DockerNetworkConfig = Field(default_factory=DockerNetworkConfig)
    resources: DockerResourceLimits = Field(default_factory=DockerResourceLimits)
    security: DockerSecurityConfig = Field(default_factory=DockerSecurityConfig)
    volumes: Optional[list[DockerVolumeMount]] = Field(default=None)
    environment: Optional[dict[str, str]] = Field(
        default=None,
        description="Extra env vars injected into the container.",
    )
    working_dir: str = Field(
        default="/workspace",
        description="Working directory inside the container.",
    )
    auto_remove: bool = Field(
        default=True,
        description="Remove container after execution.",
    )
    entrypoint: Optional[str] = Field(
        default=None,
        description="Override container entrypoint, e.g. '/bin/sh'.",
    )
    labels: Optional[dict[str, str]] = Field(default=None)
    extra_docker_args: Optional[list[str]] = Field(
        default=None,
        description="Raw extra docker run arguments (escape hatch).",
    )
    mount_host_tool_script: bool = Field(
        default=True,
        description=(
            "If True (default), bind-mount the agent's tool script from the host into the "
            "container at container_tool_path (development-friendly). "
            "Set False for production: the image must already contain the tool at "
            "container_tool_path (built via Dockerfile COPY); no host file is mounted."
        ),
    )
    container_tool_path: str = Field(
        default="/workspace/tool.py",
        description=(
            "Path to the tool script inside the container. When mount_host_tool_script is True, "
            "the host script is mounted here. When False, this path must exist in the image."
        ),
    )
    tool_interpreter: str = Field(
        default="python",
        description=(
            "Executable used to run container_tool_path after the image name, e.g. 'python', "
            "'python3', 'node'."
        ),
    )

    # ── Validation ───────────────────────────────────────────────────────────

    @model_validator(mode="after")
    def _validate(self) -> "DockerToolConfig":
        if self.network.mode == NetworkMode.CUSTOM and not self.network.custom_network:
            raise ValueError(
                "network.custom_network is required when mode='custom'"
            )
        if self.user.run_as_root and self.user.user is not None:
            self.user.user = None  # run_as_root takes precedence
        return self


__all__ = [
    "DockerToolConfig",
    "DockerUserConfig",
    "DockerNetworkConfig",
    "DockerResourceLimits",
    "DockerVolumeMount",
    "DockerSecurityConfig",
    "NetworkMode",
    "RestartPolicy",
]
