"""Sentiment analyzer — scores text sentiment using VADER or TextBlob."""

import json
import re


def run(texts: str) -> dict:
    """Analyze sentiment of text or a list of texts.

    Tries vaderSentiment first, then TextBlob, then falls back to
    a simple lexicon-based approach.

    Args:
        texts: Single text string, or JSON array of strings for trend analysis.

    Returns:
        Dictionary with per-text sentiment scores and an overall trend.
    """
    if not texts or not texts.strip():
        raise ValueError("texts must not be empty.")

    # Parse input
    text_list = _parse_input(texts.strip())

    # Detect engine
    engine = "builtin"
    analyze_fn = _builtin_analyze

    try:
        import importlib
        vader_module = importlib.import_module("vaderSentiment.vaderSentiment")
        analyzer = vader_module.SentimentIntensityAnalyzer()
        analyze_fn = lambda t: _vader_analyze(analyzer, t)
        engine = "vader"
    except ImportError:
        try:
            import importlib
            textblob = importlib.import_module("textblob")
            analyze_fn = lambda t: _textblob_analyze(textblob, t)
            engine = "textblob"
        except ImportError:
            pass

    results = [analyze_fn(t) for t in text_list]

    # Compute overall sentiment
    scores = [r["score"] for r in results]
    avg_score = sum(scores) / len(scores) if scores else 0.0
    overall = _score_to_label(avg_score)

    # Compute trend
    trend = _compute_trend(scores)

    return {
        "results": results,
        "overall_sentiment": overall,
        "trend": trend,
        "engine": engine,
    }


def _parse_input(text: str) -> list[str]:
    """Parse input as JSON array or single string."""
    if text.startswith("["):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return [str(t) for t in parsed]
        except json.JSONDecodeError:
            pass
    return [text]


def _vader_analyze(analyzer, text: str) -> dict:
    scores = analyzer.polarity_scores(text)
    compound = scores["compound"]
    return {
        "text": text[:100],
        "sentiment": _score_to_label(compound),
        "score": compound,
        "positive": scores["pos"],
        "negative": scores["neg"],
        "neutral": scores["neu"],
    }


def _textblob_analyze(textblob, text: str) -> dict:
    blob = textblob.TextBlob(text)
    polarity = blob.sentiment.polarity
    subjectivity = blob.sentiment.subjectivity
    return {
        "text": text[:100],
        "sentiment": _score_to_label(polarity),
        "score": round(polarity, 4),
        "positive": max(0.0, polarity),
        "negative": max(0.0, -polarity),
        "neutral": 1.0 - abs(polarity),
    }


# Minimal built-in lexicon
_POSITIVE_WORDS = {
    "good", "great", "excellent", "amazing", "wonderful", "fantastic", "love",
    "happy", "joy", "perfect", "best", "awesome", "brilliant", "positive",
    "beautiful", "nice", "superb", "outstanding", "enjoy", "pleased",
}
_NEGATIVE_WORDS = {
    "bad", "terrible", "awful", "horrible", "hate", "sad", "poor", "worst",
    "negative", "disappointing", "fail", "failure", "wrong", "ugly", "boring",
    "disgusting", "annoying", "useless", "broken", "frustrating",
}


def _builtin_analyze(text: str) -> dict:
    words = set(re.findall(r"\b\w+\b", text.lower()))
    pos = len(words & _POSITIVE_WORDS)
    neg = len(words & _NEGATIVE_WORDS)
    total = max(pos + neg, 1)
    score = round((pos - neg) / total, 4)
    return {
        "text": text[:100],
        "sentiment": _score_to_label(score),
        "score": score,
        "positive": pos / total,
        "negative": neg / total,
        "neutral": 0.0 if (pos + neg) > 0 else 1.0,
    }


def _score_to_label(score: float) -> str:
    if score >= 0.05:
        return "positive"
    if score <= -0.05:
        return "negative"
    return "neutral"


def _compute_trend(scores: list[float]) -> str:
    if len(scores) < 2:
        return "stable"
    diffs = [scores[i + 1] - scores[i] for i in range(len(scores) - 1)]
    avg_diff = sum(diffs) / len(diffs)
    if avg_diff > 0.05:
        return "improving"
    if avg_diff < -0.05:
        return "declining"
    return "stable"
