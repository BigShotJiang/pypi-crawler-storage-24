"""PDF metadata extractor — reads metadata fields from PDF files."""

import struct
import re
from pathlib import Path


def run(file_path: str) -> dict:
    """Extract metadata from a PDF file.

    Uses pypdf if available, otherwise falls back to raw header parsing.

    Args:
        file_path: Path to the PDF file.

    Returns:
        Dictionary with title, author, creation date, page count, etc.
    """
    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")

    path = Path(file_path.strip()).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if path.suffix.lower() != ".pdf":
        raise ValueError(f"Not a PDF file: {path.name}")

    # Dynamic import — pypdf preferred
    try:
        import importlib
        pypdf = importlib.import_module("pypdf")
        return _extract_with_pypdf(pypdf, path)
    except ImportError:
        pass

    try:
        import importlib
        PyPDF2 = importlib.import_module("PyPDF2")
        return _extract_with_pypdf2(PyPDF2, path)
    except ImportError:
        pass

    # Fallback: raw parsing
    return _extract_raw(path)


def _extract_with_pypdf(pypdf, path: Path) -> dict:
    """Extract using pypdf library."""
    reader = pypdf.PdfReader(str(path))
    meta = reader.metadata or {}
    return {
        "file": str(path),
        "title": _clean(meta.get("/Title")),
        "author": _clean(meta.get("/Author")),
        "creator": _clean(meta.get("/Creator")),
        "producer": _clean(meta.get("/Producer")),
        "creation_date": _clean(meta.get("/CreationDate")),
        "modification_date": _clean(meta.get("/ModDate")),
        "pages": len(reader.pages),
        "encrypted": reader.is_encrypted,
    }


def _extract_with_pypdf2(PyPDF2, path: Path) -> dict:
    """Extract using PyPDF2 library."""
    with open(path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        meta = reader.metadata or {}
        return {
            "file": str(path),
            "title": _clean(meta.get("/Title")),
            "author": _clean(meta.get("/Author")),
            "creator": _clean(meta.get("/Creator")),
            "producer": _clean(meta.get("/Producer")),
            "creation_date": _clean(meta.get("/CreationDate")),
            "modification_date": _clean(meta.get("/ModDate")),
            "pages": len(reader.pages),
            "encrypted": reader.is_encrypted,
        }


def _extract_raw(path: Path) -> dict:
    """Minimal raw PDF header parsing (no third-party deps)."""
    content = path.read_bytes()
    text = content[:65536].decode("latin-1", errors="replace")

    def find_meta(key: str) -> str:
        m = re.search(rf"/{key}\s*\(([^)]*)\)", text)
        return m.group(1).strip() if m else ""

    page_count = len(re.findall(r"/Type\s*/Page[^s]", text))

    return {
        "file": str(path),
        "title": find_meta("Title"),
        "author": find_meta("Author"),
        "creator": find_meta("Creator"),
        "producer": find_meta("Producer"),
        "creation_date": find_meta("CreationDate"),
        "modification_date": find_meta("ModDate"),
        "pages": page_count,
        "encrypted": b"/Encrypt" in content,
    }


def _clean(value) -> str:
    if value is None:
        return ""
    return str(value).strip()
