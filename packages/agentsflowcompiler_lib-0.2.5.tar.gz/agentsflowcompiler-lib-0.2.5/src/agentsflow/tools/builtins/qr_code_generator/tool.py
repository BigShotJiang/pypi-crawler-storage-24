"""QR code generator — creates QR codes from text or URLs."""

import base64
import io
from pathlib import Path


def run(content: str, output_path: str = "", size: int = 10, border: int = 4) -> dict:
    """Generate a QR code from text or URL.

    Requires: pip install qrcode[pil]

    Args:
        content: Text or URL to encode.
        output_path: File path to save PNG (empty = return base64).
        size: Box size per module in pixels.
        border: Border size in modules.

    Returns:
        Dictionary with output file path or base64 encoded PNG.
    """
    try:
        import importlib
        qrcode = importlib.import_module("qrcode")
    except ImportError:
        raise ImportError("qrcode is required. Install with: pip install 'qrcode[pil]'")

    if not content or not content.strip():
        raise ValueError("content must not be empty.")

    content = content.strip()
    size = max(1, min(int(size), 50))
    border = max(0, min(int(border), 20))

    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=size,
        border=border,
    )
    qr.add_data(content)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    modules = qr.modules_count if hasattr(qr, "modules_count") else 0

    if output_path and output_path.strip():
        out_path = Path(output_path.strip()).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        img.save(str(out_path))
        return {
            "content": content,
            "output_file": str(out_path),
            "base64_png": None,
            "modules": modules,
        }
    else:
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode("ascii")
        return {
            "content": content,
            "output_file": None,
            "base64_png": b64,
            "modules": modules,
        }
