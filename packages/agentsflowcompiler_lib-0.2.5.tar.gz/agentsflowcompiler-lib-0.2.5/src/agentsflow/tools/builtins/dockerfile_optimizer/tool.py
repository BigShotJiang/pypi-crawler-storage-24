"""Dockerfile optimizer — detects anti-patterns and suggests improvements."""

import re
from pathlib import Path


_RULES = [
    # (pattern, severity, message, suggestion)
    (
        re.compile(r"^FROM\s+\S+(?<!:latest)\s*$", re.I),
        "warning",
        "Using 'latest' tag (implicit or explicit) is non-deterministic.",
        "Pin to a specific version: FROM python:3.12-slim",
    ),
    (
        re.compile(r"^FROM\s+(?!.*-slim|.*-alpine|.*-distroless)\S+:\S+", re.I),
        "info",
        "Consider using a slim/alpine base image to reduce size.",
        "E.g., FROM python:3.12-slim or FROM node:20-alpine",
    ),
    (
        re.compile(r"^RUN\s+apt-get\s+install(?!.*--no-install-recommends)", re.I),
        "warning",
        "apt-get install without --no-install-recommends installs unnecessary packages.",
        "Add: apt-get install -y --no-install-recommends ...",
    ),
    (
        re.compile(r"^RUN\s+apt-get\s+update\s*$", re.I),
        "error",
        "apt-get update in a separate RUN layer is a cache invalidation issue.",
        "Combine: RUN apt-get update && apt-get install -y ...",
    ),
    (
        re.compile(r"^RUN\b.*&&.*\bRUN\b", re.I),
        "info",
        "Multiple RUN instructions increase layer count.",
        "Merge RUN instructions with && to reduce layers.",
    ),
    (
        re.compile(r"^COPY\s+\.\s+\.", re.I),
        "warning",
        "COPY . . copies everything including .git and node_modules.",
        "Use a .dockerignore file or copy specific directories.",
    ),
    (
        re.compile(r"^(ADD)\s+http", re.I),
        "warning",
        "ADD with URL downloads at build time without caching benefits.",
        "Use RUN curl/wget instead for better layer caching.",
    ),
    (
        re.compile(r"^RUN\s+pip\s+install(?!.*--no-cache-dir)", re.I),
        "warning",
        "pip install without --no-cache-dir increases image size.",
        "Add: RUN pip install --no-cache-dir ...",
    ),
    (
        re.compile(r"^RUN\s+npm\s+install(?!\s+--production|\s+ci)", re.I),
        "info",
        "npm install includes dev dependencies. Use --production for smaller images.",
        "Use: RUN npm ci --production",
    ),
    (
        re.compile(r"^(EXPOSE|ENV|LABEL)\s*$", re.I),
        "error",
        "Empty directive found.",
        "Remove or complete the directive.",
    ),
]


def run(dockerfile_path: str = "", dockerfile_content: str = "") -> dict:
    """Analyze a Dockerfile for optimization opportunities.

    Args:
        dockerfile_path: Path to Dockerfile.
        dockerfile_content: Dockerfile content as string.

    Returns:
        Dictionary with issues, score, and suggested optimized content.
    """
    if not dockerfile_path and not dockerfile_content:
        raise ValueError("Either dockerfile_path or dockerfile_content must be provided.")

    if dockerfile_content and dockerfile_content.strip():
        content = dockerfile_content.strip()
    else:
        path = Path(dockerfile_path.strip()).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Dockerfile not found: {path}")
        content = path.read_text(encoding="utf-8")

    lines = content.splitlines()
    issues = []
    deductions = 0

    for line_num, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        for pattern, severity, message, suggestion in _RULES:
            if pattern.search(stripped):
                penalty = {"error": 10, "warning": 5, "info": 2}.get(severity, 0)
                deductions += penalty
                issues.append({
                    "line": line_num,
                    "severity": severity,
                    "message": message,
                    "suggestion": suggestion,
                })
                break

    score = max(0, 100 - deductions)
    optimized = _apply_basic_optimizations(content)

    return {
        "issues": issues,
        "score": score,
        "optimized_dockerfile": optimized,
    }


def _apply_basic_optimizations(content: str) -> str:
    """Apply simple automated fixes."""
    # Add --no-cache-dir to pip install
    content = re.sub(
        r"(RUN\s+pip\s+install)(?!\s+--no-cache-dir)",
        r"\1 --no-cache-dir",
        content, flags=re.I,
    )
    # Add --no-install-recommends to apt-get install
    content = re.sub(
        r"(apt-get\s+install\s+-y)(?!\s+--no-install-recommends)",
        r"\1 --no-install-recommends",
        content, flags=re.I,
    )
    return content
