"""MAC vendor lookup — identifies hardware manufacturer from MAC address OUI."""

import json
import re
import urllib.request


_OUI_API = "https://api.maclookup.app/v2/macs/{oui}"
_MAC_CLEAN = re.compile(r"[^0-9a-fA-F]")


def run(mac_address: str) -> dict:
    """Identify the vendor for a given MAC address.

    Args:
        mac_address: MAC address in any common format.

    Returns:
        Dictionary with normalized MAC, OUI prefix, vendor name, and flags.
    """
    if not mac_address or not mac_address.strip():
        raise ValueError("mac_address must not be empty.")

    mac_clean = _MAC_CLEAN.sub("", mac_address.strip()).upper()
    if len(mac_clean) != 12:
        raise ValueError(f"Invalid MAC address length after normalization: '{mac_address}'")

    oui = mac_clean[:6]
    formatted_mac = ":".join(mac_clean[i:i+2] for i in range(0, 12, 2))

    # Check private/multicast from first byte
    first_byte = int(mac_clean[:2], 16)
    is_multicast = bool(first_byte & 0x01)
    is_private = bool(first_byte & 0x02)  # locally administered

    vendor = _lookup_vendor(oui)

    return {
        "mac": formatted_mac,
        "oui": ":".join(oui[i:i+2] for i in range(0, 6, 2)),
        "vendor": vendor,
        "is_private": is_private,
        "is_multicast": is_multicast,
    }


def _lookup_vendor(oui: str) -> str:
    """Query the MAC lookup API for vendor info."""
    url = _OUI_API.format(oui=oui)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
        return data.get("company") or data.get("vendor") or "Unknown"
    except Exception:
        return "Unknown (lookup failed)"
