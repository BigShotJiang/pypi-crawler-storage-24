"""Git secret scanner — detects leaked API keys and secrets in local files."""

import os
import re
from pathlib import Path
from typing import Any

# Secret patterns: (pattern_name, compiled_regex)
_SECRET_PATTERNS = [
    ("AWS Access Key", re.compile(r"(?:AKIA|AIPA|ASIA|AROA)[0-9A-Z]{16}")),
    ("AWS Secret Key", re.compile(r"(?:aws.{0,20})?['\"][0-9a-zA-Z/+]{40}['\"]")),
    ("GitHub Token", re.compile(r"ghp_[0-9a-zA-Z]{36}|github_pat_[0-9a-zA-Z_]{82}")),
    ("Slack Token", re.compile(r"xox[baprs]-[0-9a-zA-Z\-]{10,}")),
    ("Google API Key", re.compile(r"AIza[0-9A-Za-z\-_]{35}")),
    ("Stripe Key", re.compile(r"(?:sk|pk)_(?:live|test)_[0-9a-zA-Z]{24,}")),
    ("SendGrid Key", re.compile(r"SG\.[0-9A-Za-z\-_]{22}\.[0-9A-Za-z\-_]{43}")),
    ("Twilio SID", re.compile(r"AC[0-9a-f]{32}")),
    ("Private Key Block", re.compile(r"-----BEGIN (?:RSA|EC|DSA|OPENSSH) PRIVATE KEY-----")),
    ("Bearer Token", re.compile(r"(?i)bearer\s+[0-9a-zA-Z\-_.~+/]{20,}")),
    ("Password in Config", re.compile(r"(?i)(?:password|passwd|pwd)\s*[=:]\s*['\"]?[^\s'\"]{8,}['\"]?")),
    ("Generic API Key", re.compile(r"(?i)api[_-]?key\s*[=:]\s*['\"]?[0-9a-zA-Z\-_]{16,}['\"]?")),
    ("Generic Secret", re.compile(r"(?i)secret\s*[=:]\s*['\"]?[0-9a-zA-Z\-_]{16,}['\"]?")),
]

_SKIP_EXTENSIONS = {".pyc", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico",
                    ".pdf", ".zip", ".tar", ".gz", ".bin", ".exe", ".dll"}
_SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".env", "dist", "build"}


def run(path: str, recursive: bool = True, max_file_size_kb: float = 500.0) -> dict:
    """Scan a local directory or file for secrets.

    Args:
        path: Local path to scan.
        recursive: Whether to scan subdirectories.
        max_file_size_kb: Skip files larger than this (KB).

    Returns:
        Dictionary with findings, file count, and secrets count.
    """
    if not path or not path.strip():
        raise ValueError("path must not be empty.")

    target = Path(path.strip()).expanduser().resolve()
    if not target.exists():
        raise FileNotFoundError(f"Path does not exist: {target}")

    max_bytes = int(max_file_size_kb * 1024)
    findings: list[dict[str, Any]] = []
    files_scanned = 0

    if target.is_file():
        files_to_scan = [target]
    else:
        files_to_scan = _collect_files(target, recursive)

    for file_path in files_to_scan:
        if file_path.suffix.lower() in _SKIP_EXTENSIONS:
            continue
        if file_path.stat().st_size > max_bytes:
            continue
        files_scanned += 1
        file_findings = _scan_file(file_path)
        findings.extend(file_findings)

    return {
        "findings": findings,
        "total_files_scanned": files_scanned,
        "secrets_found": len(findings),
    }


def _collect_files(root: Path, recursive: bool) -> list[Path]:
    """Collect files to scan."""
    files = []
    if recursive:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
            for fname in filenames:
                files.append(Path(dirpath) / fname)
    else:
        files = [f for f in root.iterdir() if f.is_file()]
    return files


def _scan_file(file_path: Path) -> list[dict[str, Any]]:
    """Scan a single file for secrets."""
    findings = []
    try:
        content = file_path.read_text(encoding="utf-8", errors="ignore")
    except (PermissionError, OSError):
        return findings

    for line_num, line in enumerate(content.splitlines(), 1):
        for pattern_name, pattern in _SECRET_PATTERNS:
            m = pattern.search(line)
            if m:
                # Redact the actual secret value in the preview
                match_text = m.group(0)
                preview = line.strip()[:120]
                findings.append({
                    "file": str(file_path),
                    "line": line_num,
                    "pattern_name": pattern_name,
                    "match_preview": preview,
                })
                break  # one finding per line
    return findings
