"""Shodan searcher — retrieves host intelligence from Shodan API."""

import json
import os
import urllib.request
import urllib.parse


def run(target: str, api_key: str = "") -> dict:
    """Fetch host information from Shodan.

    Args:
        target: IP address or hostname to look up.
        api_key: Shodan API key (falls back to SHODAN_API_KEY env var).

    Returns:
        Dictionary with open ports, hostnames, org, country, vulnerabilities, and OS.
    """
    if not target or not target.strip():
        raise ValueError("target must not be empty.")

    key = api_key.strip() or os.environ.get("SHODAN_API_KEY", "")
    if not key:
        raise ValueError("Shodan API key required. Set SHODAN_API_KEY env var or pass api_key parameter.")

    target = target.strip()

    # Resolve hostname to IP if needed
    ip = _resolve_ip(target)

    url = f"https://api.shodan.io/shodan/host/{urllib.parse.quote(ip)}?key={urllib.parse.quote(key)}"
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Shodan API error {e.code}: {e.reason}") from e

    ports = sorted(set(d.get("port") for d in data.get("data", []) if d.get("port")))
    vulns = list(data.get("vulns", {}).keys())

    return {
        "ip": data.get("ip_str", ip),
        "ports": ports,
        "hostnames": data.get("hostnames", []),
        "org": data.get("org", ""),
        "country": data.get("country_name", ""),
        "vulns": vulns,
        "os": data.get("os") or "",
    }


def _resolve_ip(target: str) -> str:
    """Resolve hostname to IP if necessary."""
    import socket
    try:
        return socket.gethostbyname(target)
    except socket.gaierror:
        return target
