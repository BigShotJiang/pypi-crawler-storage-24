"""Systemd unit status checker — reports service health via systemctl."""

import json
import re
import subprocess


def run(services: str) -> dict:
    """Check systemd service status.

    Args:
        services: Comma-separated service names.

    Returns:
        Dictionary with per-service status details.
    """
    if not services or not services.strip():
        raise ValueError("services must not be empty.")

    service_list = [s.strip() for s in services.split(",") if s.strip()]
    # Ensure .service suffix
    service_list = [s if "." in s else f"{s}.service" for s in service_list]

    results = []
    for svc in service_list:
        results.append(_get_service_status(svc))

    failed_count = sum(1 for s in results if s["active_state"] == "failed")
    return {"services": results, "failed_count": failed_count}


def _get_service_status(service: str) -> dict:
    """Get status of a single service via systemctl show."""
    try:
        result = subprocess.run(
            ["systemctl", "show", service,
             "--property=ActiveState,SubState,LoadState,MainPID,Description,ActiveEnterTimestamp"],
            capture_output=True, text=True, timeout=10,
        )
        props = {}
        for line in result.stdout.splitlines():
            if "=" in line:
                k, _, v = line.partition("=")
                props[k.strip()] = v.strip()

        return {
            "name": service,
            "active_state": props.get("ActiveState", "unknown"),
            "sub_state": props.get("SubState", ""),
            "load_state": props.get("LoadState", ""),
            "pid": int(props.get("MainPID", "0")) or None,
            "description": props.get("Description", ""),
            "since": props.get("ActiveEnterTimestamp", ""),
        }
    except FileNotFoundError:
        return {
            "name": service,
            "active_state": "error",
            "sub_state": "systemctl not found",
            "load_state": "",
            "pid": None,
            "description": "",
            "since": "",
        }
    except Exception as exc:
        return {
            "name": service,
            "active_state": "error",
            "sub_state": str(exc),
            "load_state": "",
            "pid": None,
            "description": "",
            "since": "",
        }
