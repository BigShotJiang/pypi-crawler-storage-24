"""Git branch cleanup — identifies and optionally removes merged branches."""

import subprocess
from pathlib import Path


_PROTECTED = {"main", "master", "develop", "dev", "staging", "production", "release"}


def run(repo_path: str = ".", base_branch: str = "main", delete: bool = False) -> dict:
    """Find and optionally delete merged local branches.

    Args:
        repo_path: Path to git repository.
        base_branch: Branch to check merges against.
        delete: If True, delete merged branches.

    Returns:
        Dictionary with merged branches and deletion results.
    """
    repo = Path(repo_path.strip() if repo_path else ".").expanduser().resolve()
    if not (repo / ".git").exists():
        raise ValueError(f"Not a git repository: {repo}")

    # Find actual base branch
    actual_base = _resolve_base_branch(repo, base_branch.strip() or "main")

    # Get all local branches merged into base
    merged = _get_merged_branches(repo, actual_base)
    merged_safe = [b for b in merged if b not in _PROTECTED]
    protected = [b for b in merged if b in _PROTECTED]

    deleted = []
    if delete and merged_safe:
        for branch in merged_safe:
            success = _delete_branch(repo, branch)
            if success:
                deleted.append(branch)

    return {
        "repo": str(repo),
        "base_branch": actual_base,
        "merged_branches": merged_safe,
        "deleted_branches": deleted,
        "protected_branches": protected,
    }


def _run_git(repo: Path, *args) -> str:
    result = subprocess.run(
        ["git"] + list(args),
        capture_output=True, text=True, timeout=30,
        cwd=str(repo),
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)}: {result.stderr.strip()}")
    return result.stdout.strip()


def _resolve_base_branch(repo: Path, preferred: str) -> str:
    """Find the actual default branch."""
    branches_output = subprocess.run(
        ["git", "branch"], capture_output=True, text=True, cwd=str(repo)
    ).stdout
    local_branches = [b.strip().lstrip("* ") for b in branches_output.splitlines()]

    for candidate in (preferred, "main", "master"):
        if candidate in local_branches:
            return candidate

    return preferred


def _get_merged_branches(repo: Path, base: str) -> list[str]:
    """Get local branches merged into base."""
    try:
        output = _run_git(repo, "branch", "--merged", base)
        branches = []
        for line in output.splitlines():
            branch = line.strip().lstrip("* ").strip()
            if branch and branch != base:
                branches.append(branch)
        return branches
    except Exception:
        return []


def _delete_branch(repo: Path, branch: str) -> bool:
    """Delete a local branch."""
    try:
        _run_git(repo, "branch", "-d", branch)
        return True
    except RuntimeError:
        return False
