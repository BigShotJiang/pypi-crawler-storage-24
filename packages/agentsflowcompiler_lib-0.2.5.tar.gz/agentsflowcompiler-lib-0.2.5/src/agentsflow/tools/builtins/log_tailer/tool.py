"""Log tailer — reads the last N lines from log files with filtering."""

import collections
import re
from pathlib import Path


def run(
    file_path: str,
    lines: int = 50,
    filter_pattern: str = "",
    level_filter: str = "",
) -> dict:
    """Tail a log file and optionally filter lines.

    Args:
        file_path: Path to log file.
        lines: Number of lines to return from the end.
        filter_pattern: Regex to filter lines.
        level_filter: Log level to filter (ERROR/WARN/INFO/DEBUG).

    Returns:
        Dictionary with lines, error/warn counts.
    """
    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")

    path = Path(file_path.strip()).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    lines = max(1, min(int(lines), 10000))

    # Read last N lines efficiently using a deque
    raw_lines = _tail_file(path, lines * 10)  # read more, then filter

    # Apply filters
    filtered = raw_lines
    if level_filter and level_filter.strip():
        lvl = level_filter.strip().upper()
        filtered = [l for l in filtered if lvl in l.upper()]

    if filter_pattern and filter_pattern.strip():
        pat = re.compile(filter_pattern.strip(), re.IGNORECASE)
        filtered = [l for l in filtered if pat.search(l)]

    filtered = filtered[-lines:]

    # Count log levels
    error_count = sum(1 for l in filtered if re.search(r"\bERROR\b", l, re.I))
    warn_count = sum(1 for l in filtered if re.search(r"\b(?:WARN|WARNING)\b", l, re.I))

    return {
        "file": str(path),
        "total_lines_read": len(raw_lines),
        "returned_lines": len(filtered),
        "lines": filtered,
        "error_count": error_count,
        "warn_count": warn_count,
    }


def _tail_file(path: Path, max_lines: int) -> list[str]:
    """Efficiently read last max_lines lines from a file."""
    buf = collections.deque(maxlen=max_lines)
    try:
        with open(str(path), "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                buf.append(line.rstrip("\n\r"))
    except PermissionError as exc:
        raise PermissionError(f"Cannot read {path}: {exc}") from exc
    return list(buf)
