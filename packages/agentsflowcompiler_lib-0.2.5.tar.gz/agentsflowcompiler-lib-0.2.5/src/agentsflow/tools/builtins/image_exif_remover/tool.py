"""Image EXIF remover — strips metadata (GPS, camera, timestamps) from images."""

from pathlib import Path


def run(file_path: str, output_path: str = "") -> dict:
    """Remove EXIF metadata from an image file.

    Requires Pillow. Install with: pip install Pillow

    Args:
        file_path: Path to input image.
        output_path: Output path (default: adds '_clean' before extension).

    Returns:
        Dictionary with file paths, number of EXIF fields removed, and size comparison.
    """
    try:
        import importlib
        PIL = importlib.import_module("PIL")
        Image = importlib.import_module("PIL.Image")
    except ImportError:
        raise ImportError("Pillow is required. Install with: pip install Pillow")

    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")

    in_path = Path(file_path.strip()).expanduser().resolve()
    if not in_path.exists():
        raise FileNotFoundError(f"File not found: {in_path}")

    # Determine output path
    if output_path and output_path.strip():
        out_path = Path(output_path.strip()).expanduser().resolve()
    else:
        out_path = in_path.parent / f"{in_path.stem}_clean{in_path.suffix}"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    size_before = in_path.stat().st_size

    # Open image and read EXIF
    img = Image.open(str(in_path))
    exif_count = 0
    gps_removed = False

    # Count existing EXIF fields
    try:
        exif_data = img._getexif()  # type: ignore
        if exif_data:
            exif_count = len(exif_data)
            # GPS tag is 34853 (0x8825)
            gps_removed = 34853 in exif_data
    except (AttributeError, Exception):
        pass

    # Strip EXIF by re-saving without metadata
    img_data = img.getdata()
    clean_img = Image.new(img.mode, img.size)
    clean_img.putdata(img_data)

    # Preserve format
    fmt = img.format or _guess_format(in_path.suffix)
    save_kwargs: dict = {}
    if fmt == "JPEG":
        save_kwargs["quality"] = 95
        save_kwargs["subsampling"] = 0

    clean_img.save(str(out_path), format=fmt, **save_kwargs)
    size_after = out_path.stat().st_size

    return {
        "input_file": str(in_path),
        "output_file": str(out_path),
        "exif_fields_removed": exif_count,
        "gps_removed": gps_removed,
        "file_size_before": size_before,
        "file_size_after": size_after,
    }


def _guess_format(suffix: str) -> str:
    mapping = {".jpg": "JPEG", ".jpeg": "JPEG", ".png": "PNG", ".tiff": "TIFF", ".tif": "TIFF", ".bmp": "BMP"}
    return mapping.get(suffix.lower(), "JPEG")
