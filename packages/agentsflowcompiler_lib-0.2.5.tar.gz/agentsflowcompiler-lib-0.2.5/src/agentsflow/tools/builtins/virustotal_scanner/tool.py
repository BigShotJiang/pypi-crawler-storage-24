"""VirusTotal scanner — checks hashes and URLs against threat intel database."""

import base64
import json
import os
import re
import urllib.request
import urllib.parse
import urllib.error

_HASH_PATTERN = re.compile(r"^[0-9a-fA-F]{32,64}$")
_VT_BASE = "https://www.virustotal.com/api/v3"


def run(target: str, target_type: str = "", api_key: str = "") -> dict:
    """Check a file hash or URL against VirusTotal.

    Args:
        target: MD5/SHA1/SHA256 hash or URL to scan.
        target_type: 'hash' or 'url' (auto-detected if empty).
        api_key: VT API key (falls back to VT_API_KEY env var).

    Returns:
        Dictionary with detection counts and a verdict.
    """
    if not target or not target.strip():
        raise ValueError("target must not be empty.")

    key = api_key.strip() or os.environ.get("VT_API_KEY", "")
    if not key:
        raise ValueError("VirusTotal API key required. Set VT_API_KEY env var or pass api_key parameter.")

    target = target.strip()
    detected_type = target_type.strip().lower() or _detect_type(target)

    if detected_type == "hash":
        url = f"{_VT_BASE}/files/{urllib.parse.quote(target)}"
    elif detected_type == "url":
        url_id = base64.urlsafe_b64encode(target.encode()).rstrip(b"=").decode()
        url = f"{_VT_BASE}/urls/{url_id}"
    else:
        raise ValueError(f"Unknown target_type '{target_type}'. Use 'hash' or 'url'.")

    req = urllib.request.Request(url, headers={"x-apikey": key, "User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"VirusTotal API error {e.code}: {e.reason}") from e

    stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
    malicious = stats.get("malicious", 0)
    suspicious = stats.get("suspicious", 0)
    harmless = stats.get("harmless", 0)
    undetected = stats.get("undetected", 0)
    total = malicious + suspicious + harmless + undetected

    if malicious > 0:
        verdict = "malicious"
    elif suspicious > 0:
        verdict = "suspicious"
    else:
        verdict = "clean"

    return {
        "target": target,
        "type": detected_type,
        "malicious": malicious,
        "suspicious": suspicious,
        "harmless": harmless,
        "undetected": undetected,
        "engines_total": total,
        "verdict": verdict,
    }


def _detect_type(target: str) -> str:
    """Auto-detect whether target is a hash or URL."""
    if _HASH_PATTERN.match(target):
        return "hash"
    if target.startswith(("http://", "https://")):
        return "url"
    return "unknown"
