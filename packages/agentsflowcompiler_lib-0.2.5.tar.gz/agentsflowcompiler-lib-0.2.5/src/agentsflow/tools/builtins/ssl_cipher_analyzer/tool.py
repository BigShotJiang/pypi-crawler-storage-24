"""SSL/TLS cipher suite analyzer — inspects TLS configuration of a server."""

import socket
import ssl
import datetime


_WEAK_CIPHERS = {
    "RC4", "DES", "3DES", "NULL", "EXPORT", "ANON", "MD5",
    "RC2", "IDEA", "SEED", "CAMELLIA_128_CBC", "CAMELLIA_256_CBC",
}


def run(host: str, port: int = 443) -> dict:
    """Analyze SSL/TLS configuration for a server.

    Args:
        host: Hostname or IP.
        port: Port number (default 443).

    Returns:
        Dictionary with protocol version, cipher info, certificate details,
        SAN names, and weak cipher detection.
    """
    if not host or not host.strip():
        raise ValueError("host must not be empty.")

    host = host.strip()
    port = int(port)

    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    try:
        with socket.create_connection((host, port), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=host) as ssock:
                cipher = ssock.cipher()          # (name, protocol, bits)
                cert = ssock.getpeercert()
                protocol = ssock.version()
    except (ssl.SSLError, socket.error, OSError) as exc:
        raise RuntimeError(f"TLS connection to {host}:{port} failed: {exc}") from exc

    cipher_name = cipher[0] if cipher else ""
    cipher_bits = cipher[2] if cipher else 0

    cert_subject = dict(x[0] for x in cert.get("subject", []))
    cert_issuer = dict(x[0] for x in cert.get("issuer", []))

    not_after = cert.get("notAfter", "")
    san_names = [
        v for type_, v in cert.get("subjectAltName", [])
        if type_ == "DNS"
    ]

    weak_detected = any(w in cipher_name.upper() for w in _WEAK_CIPHERS)

    return {
        "host": host,
        "port": port,
        "protocol_version": protocol or "",
        "cipher_name": cipher_name,
        "cipher_bits": cipher_bits,
        "cert_subject": cert_subject,
        "cert_issuer": cert_issuer,
        "cert_expiry": not_after,
        "san_names": san_names,
        "weak_ciphers_detected": weak_detected,
    }
