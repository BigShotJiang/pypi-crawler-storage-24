"""BibTeX citation generator — creates academic citations from DOI or manual input."""

import json
import re
import urllib.request
import urllib.parse
import urllib.error


def run(
    doi: str = "",
    title: str = "",
    authors: str = "",
    year: str = "",
    journal: str = "",
    citation_type: str = "article",
) -> dict:
    """Generate a BibTeX citation.

    If DOI is provided, fetches metadata from CrossRef API.
    Otherwise, builds from manual input.

    Args:
        doi: DOI string.
        title: Paper title (for manual entry).
        authors: Comma-separated author names.
        year: Publication year.
        journal: Journal/conference name.
        citation_type: BibTeX entry type.

    Returns:
        Dictionary with bibtex string, cite_key, and metadata.
    """
    if doi and doi.strip():
        meta = _fetch_doi_metadata(doi.strip())
    else:
        if not title:
            raise ValueError("Either doi or title must be provided.")
        meta = {
            "title": title.strip(),
            "authors": [a.strip() for a in authors.split(",") if a.strip()],
            "year": year.strip(),
            "journal": journal.strip(),
            "doi": "",
            "volume": "",
            "pages": "",
            "publisher": "",
        }

    entry_type = citation_type.strip().lower() or "article"
    cite_key = _build_cite_key(meta)
    bibtex = _build_bibtex(entry_type, cite_key, meta)

    return {
        "bibtex": bibtex,
        "cite_key": cite_key,
        "metadata": meta,
    }


def _fetch_doi_metadata(doi: str) -> dict:
    """Fetch citation metadata from CrossRef API."""
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    req = urllib.request.Request(url, headers={
        "User-Agent": "agentsflow/1.0 (mailto:noreply@example.com)",
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"CrossRef API error {e.code} for DOI '{doi}'") from e

    work = data.get("message", {})

    # Authors
    authors_raw = work.get("author", [])
    authors = [
        f"{a.get('family', '')}, {a.get('given', '')}".strip(", ")
        for a in authors_raw
    ]

    # Year
    year = ""
    date_parts = (
        work.get("published-print") or
        work.get("published-online") or
        work.get("created") or {}
    )
    parts = date_parts.get("date-parts", [[]])
    if parts and parts[0]:
        year = str(parts[0][0])

    return {
        "title": _strip_html(work.get("title", [""])[0]),
        "authors": authors,
        "year": year,
        "journal": work.get("container-title", [""])[0] if work.get("container-title") else "",
        "doi": doi,
        "volume": str(work.get("volume", "")),
        "pages": work.get("page", ""),
        "publisher": work.get("publisher", ""),
    }


def _build_cite_key(meta: dict) -> str:
    """Build a cite key like 'Smith2024'."""
    first_author = meta.get("authors", ["Unknown"])[0]
    last_name = first_author.split(",")[0] if "," in first_author else first_author.split()[-1]
    last_name = re.sub(r"[^a-zA-Z]", "", last_name)
    year = meta.get("year", "0000")
    return f"{last_name}{year}"


def _build_bibtex(entry_type: str, key: str, meta: dict) -> str:
    """Format metadata as a BibTeX entry."""
    author_str = " and ".join(meta.get("authors", []))
    fields = [("author", author_str)]

    if meta.get("title"):
        fields.append(("title", "{" + meta["title"] + "}"))
    if meta.get("year"):
        fields.append(("year", meta["year"]))
    if meta.get("journal"):
        label = "booktitle" if entry_type == "inproceedings" else "journal"
        fields.append((label, "{" + meta["journal"] + "}"))
    if meta.get("volume"):
        fields.append(("volume", meta["volume"]))
    if meta.get("pages"):
        fields.append(("pages", meta["pages"]))
    if meta.get("publisher"):
        fields.append(("publisher", "{" + meta["publisher"] + "}"))
    if meta.get("doi"):
        fields.append(("doi", meta["doi"]))

    lines = [f"@{entry_type}{{{key},"]
    for field, value in fields:
        lines.append(f"  {field} = {{{value}}},")
    lines.append("}")
    return "\n".join(lines)


def _strip_html(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text)
