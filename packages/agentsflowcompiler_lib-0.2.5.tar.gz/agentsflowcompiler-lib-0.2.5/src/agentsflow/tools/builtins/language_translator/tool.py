"""Language translator — translates text using MyMemory or LibreTranslate APIs."""

import json
import urllib.request
import urllib.parse
import urllib.error


def run(text: str, target_language: str, source_language: str = "auto") -> dict:
    """Translate text to another language.

    Uses MyMemory API (free, no key required) with LibreTranslate as fallback.

    Args:
        text: Text to translate.
        target_language: Target language code (e.g. 'en', 'he', 'fr').
        source_language: Source language code or 'auto'.

    Returns:
        Dictionary with original and translated text.
    """
    if not text or not text.strip():
        raise ValueError("text must not be empty.")
    if not target_language or not target_language.strip():
        raise ValueError("target_language must not be empty.")

    text = text.strip()
    target = target_language.strip().lower()
    source = source_language.strip().lower() or "auto"

    # Try MyMemory first
    try:
        result = _translate_mymemory(text, source, target)
        return result
    except Exception:
        pass

    # Fallback: LibreTranslate public instance
    try:
        result = _translate_libretranslate(text, source, target)
        return result
    except Exception as exc:
        raise RuntimeError(f"Translation failed with all engines: {exc}") from exc


def _translate_mymemory(text: str, source: str, target: str) -> dict:
    """Translate using MyMemory API."""
    lang_pair = f"{source}|{target}" if source != "auto" else f"auto|{target}"
    params = urllib.parse.urlencode({
        "q": text[:500],  # MyMemory limit
        "langpair": lang_pair,
    })
    url = f"https://api.mymemory.translated.net/get?{params}"
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
        data = json.loads(resp.read().decode("utf-8"))

    if data.get("responseStatus") != 200:
        raise RuntimeError(f"MyMemory: {data.get('responseDetails', 'unknown error')}")

    translated = data["responseData"]["translatedText"]
    detected_source = data.get("responseData", {}).get("match", source)

    return {
        "original_text": text,
        "translated_text": translated,
        "source_language": source,
        "target_language": target,
        "engine": "mymemory",
    }


def _translate_libretranslate(text: str, source: str, target: str) -> dict:
    """Translate using public LibreTranslate instance."""
    url = "https://libretranslate.com/translate"
    payload = json.dumps({
        "q": text,
        "source": source if source != "auto" else "auto",
        "target": target,
        "format": "text",
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "agentsflow/1.0"},
    )
    with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
        data = json.loads(resp.read().decode("utf-8"))

    return {
        "original_text": text,
        "translated_text": data.get("translatedText", ""),
        "source_language": source,
        "target_language": target,
        "engine": "libretranslate",
    }
