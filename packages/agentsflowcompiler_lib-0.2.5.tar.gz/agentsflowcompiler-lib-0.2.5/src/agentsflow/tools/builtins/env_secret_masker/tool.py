"""Environment secret masker — replaces secret values in text with *** placeholders."""

import os
import re


_COMMON_SECRET_VARS = [
    "API_KEY", "SECRET_KEY", "SECRET", "PASSWORD", "PASSWD", "TOKEN",
    "ACCESS_TOKEN", "REFRESH_TOKEN", "PRIVATE_KEY", "AUTH_TOKEN",
    "DATABASE_URL", "DB_PASSWORD", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
    "GITHUB_TOKEN", "SLACK_TOKEN", "STRIPE_SECRET_KEY", "SENDGRID_API_KEY",
    "TWILIO_AUTH_TOKEN", "OPENAI_API_KEY", "ANTHROPIC_API_KEY",
]


def run(text: str, env_vars: str = "", mask_char: str = "***") -> dict:
    """Mask secret values in text.

    Args:
        text: Text to sanitize.
        env_vars: Comma-separated env var names to mask (empty = auto-detect).
        mask_char: Replacement string.

    Returns:
        Dictionary with masked text and masking statistics.
    """
    if not text:
        raise ValueError("text must not be empty.")

    mask = mask_char or "***"

    # Determine which keys to mask
    if env_vars and env_vars.strip():
        keys_to_mask = [k.strip().upper() for k in env_vars.split(",") if k.strip()]
    else:
        keys_to_mask = list(_COMMON_SECRET_VARS)

    masked_text = text
    secrets_masked = 0
    masked_keys = []

    # Mask from actual environment variables
    for key in keys_to_mask:
        value = os.environ.get(key, "")
        if value and len(value) >= 4:
            if value in masked_text:
                masked_text = masked_text.replace(value, mask)
                secrets_masked += 1
                masked_keys.append(key)

    # Also mask patterns from text: key=value or key: value
    for key in keys_to_mask:
        pattern = re.compile(
            rf'(?i)(?:{re.escape(key)})\s*[=:]\s*["\']?([^\s"\'{{}}]+)["\']?',
            re.IGNORECASE,
        )
        def _replace(m):
            nonlocal secrets_masked
            val = m.group(1)
            if len(val) >= 4 and val != mask:
                secrets_masked += 1
                if key not in masked_keys:
                    masked_keys.append(key)
                return m.group(0).replace(val, mask)
            return m.group(0)

        masked_text = pattern.sub(_replace, masked_text)

    return {
        "masked_text": masked_text,
        "secrets_masked": secrets_masked,
        "masked_keys": list(dict.fromkeys(masked_keys)),
    }
