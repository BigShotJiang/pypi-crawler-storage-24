"""AbuseIPDB checker — reports on IP address reputation."""

import json
import os
import urllib.request
import urllib.parse
import urllib.error


_API_URL = "https://api.abuseipdb.com/api/v2/check"


def run(ip: str, max_age_days: int = 90, api_key: str = "") -> dict:
    """Check an IP address against AbuseIPDB.

    Args:
        ip: IPv4 or IPv6 address.
        max_age_days: Lookback window in days.
        api_key: AbuseIPDB API key (falls back to ABUSEIPDB_API_KEY env var).

    Returns:
        Dictionary with abuse confidence score and report details.
    """
    if not ip or not ip.strip():
        raise ValueError("ip must not be empty.")

    key = api_key.strip() or os.environ.get("ABUSEIPDB_API_KEY", "")
    if not key:
        raise ValueError("AbuseIPDB API key required. Set ABUSEIPDB_API_KEY env var or pass api_key.")

    params = urllib.parse.urlencode({
        "ipAddress": ip.strip(),
        "maxAgeInDays": max(1, min(int(max_age_days), 365)),
    })
    url = f"{_API_URL}?{params}"
    req = urllib.request.Request(url, headers={
        "Key": key,
        "Accept": "application/json",
        "User-Agent": "agentsflow/1.0",
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"AbuseIPDB API error {e.code}: {e.reason}") from e

    d = data.get("data", {})
    confidence = d.get("abuseConfidenceScore", 0)

    if confidence >= 75:
        verdict = "malicious"
    elif confidence >= 25:
        verdict = "suspicious"
    else:
        verdict = "clean"

    return {
        "ip": d.get("ipAddress", ip),
        "abuse_confidence": confidence,
        "total_reports": d.get("totalReports", 0),
        "country_code": d.get("countryCode", ""),
        "isp": d.get("isp", ""),
        "is_whitelisted": d.get("isWhitelisted", False),
        "usage_type": d.get("usageType", ""),
        "verdict": verdict,
    }
