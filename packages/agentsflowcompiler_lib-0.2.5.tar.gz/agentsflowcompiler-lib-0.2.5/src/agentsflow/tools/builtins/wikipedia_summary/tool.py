"""Wikipedia summary — fetches article summaries using the Wikipedia REST API."""

import json
import re
import urllib.request
import urllib.parse
import urllib.error


def run(topic: str, language: str = "en", sentences: int = 5) -> dict:
    """Fetch a Wikipedia summary for a topic.

    Args:
        topic: Article title or search query.
        language: Wikipedia language code (e.g. 'en', 'he', 'fr').
        sentences: Number of sentences to include in summary.

    Returns:
        Dictionary with title, summary, URL, and metadata.
    """
    if not topic or not topic.strip():
        raise ValueError("topic must not be empty.")

    topic = topic.strip()
    lang = language.strip().lower() or "en"
    sentences = max(1, min(int(sentences), 20))

    # Use Wikipedia REST summary endpoint
    slug = urllib.parse.quote(topic.replace(" ", "_"))
    url = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{slug}"
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            # Try search to find the right article
            return _search_and_summarize(topic, lang, sentences)
        raise RuntimeError(f"Wikipedia API error {e.code}") from e

    extract = data.get("extract", "")
    summary = _limit_sentences(extract, sentences)

    return {
        "title": data.get("title", topic),
        "summary": summary,
        "url": data.get("content_urls", {}).get("desktop", {}).get("page", ""),
        "categories": [],
        "image_url": data.get("thumbnail", {}).get("source", "") if data.get("thumbnail") else "",
    }


def _search_and_summarize(query: str, lang: str, sentences: int) -> dict:
    """Search Wikipedia and return the first result's summary."""
    params = urllib.parse.urlencode({
        "action": "opensearch",
        "search": query,
        "limit": 1,
        "format": "json",
    })
    search_url = f"https://{lang}.wikipedia.org/w/api.php?{params}"
    req = urllib.request.Request(search_url, headers={"User-Agent": "agentsflow/1.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
        results = json.loads(resp.read().decode("utf-8"))

    if not results or not results[1]:
        raise ValueError(f"No Wikipedia article found for '{query}'.")

    title = results[1][0]
    url = results[3][0] if results[3] else ""
    slug = urllib.parse.quote(title.replace(" ", "_"))
    summary_url = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{slug}"
    req2 = urllib.request.Request(summary_url, headers={"User-Agent": "agentsflow/1.0"})
    with urllib.request.urlopen(req2, timeout=10) as resp2:  # nosec B310 - URL validated to http/https scheme
        data = json.loads(resp2.read().decode("utf-8"))

    extract = data.get("extract", "")
    return {
        "title": data.get("title", title),
        "summary": _limit_sentences(extract, sentences),
        "url": url or data.get("content_urls", {}).get("desktop", {}).get("page", ""),
        "categories": [],
        "image_url": data.get("thumbnail", {}).get("source", "") if data.get("thumbnail") else "",
    }


def _limit_sentences(text: str, n: int) -> str:
    """Return first n sentences from text."""
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return " ".join(sentences[:n])
