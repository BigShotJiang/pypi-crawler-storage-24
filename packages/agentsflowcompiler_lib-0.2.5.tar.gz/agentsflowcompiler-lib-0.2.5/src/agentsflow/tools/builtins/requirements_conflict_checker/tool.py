"""Requirements conflict checker — finds version issues in requirements.txt."""

import re
from pathlib import Path


_REQ_LINE = re.compile(
    r"^([a-zA-Z0-9_\-\.]+)\s*([><=!~^]+.*)?$"
)
_COMMENT = re.compile(r"\s*#.*$")


def run(requirements_path: str = "", requirements_content: str = "") -> dict:
    """Check a requirements.txt for conflicts and issues.

    Args:
        requirements_path: Path to requirements file.
        requirements_content: Requirements content as string.

    Returns:
        Dictionary with packages, conflicts, duplicates, and unpinned list.
    """
    if not requirements_path and not requirements_content:
        raise ValueError("Either requirements_path or requirements_content must be provided.")

    if requirements_content and requirements_content.strip():
        content = requirements_content.strip()
    else:
        path = Path(requirements_path.strip()).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        content = path.read_text(encoding="utf-8")

    packages = _parse_requirements(content)
    duplicates = _find_duplicates(packages)
    unpinned = [p for p in packages if not p["constraint"]]
    conflicts = _find_conflicts(packages)

    return {
        "packages": packages,
        "conflicts": conflicts,
        "duplicates": duplicates,
        "unpinned": [p["name"] for p in unpinned],
        "total_packages": len(packages),
    }


def _parse_requirements(content: str) -> list[dict]:
    """Parse requirements.txt into package dicts."""
    packages = []
    for line in content.splitlines():
        line = _COMMENT.sub("", line).strip()
        if not line or line.startswith(("-r", "-c", "--", "git+", "http")):
            continue
        m = _REQ_LINE.match(line)
        if m:
            name = m.group(1).strip()
            constraint = m.group(2).strip() if m.group(2) else ""
            version = _extract_pinned_version(constraint)
            packages.append({
                "name": name,
                "constraint": constraint,
                "version": version,
            })
    return packages


def _extract_pinned_version(constraint: str) -> str:
    """Extract exact version if pinned with ==."""
    m = re.match(r"==\s*([^\s,;]+)", constraint)
    return m.group(1) if m else ""


def _find_duplicates(packages: list[dict]) -> list[dict]:
    """Find packages that appear multiple times."""
    seen: dict[str, list] = {}
    for pkg in packages:
        key = pkg["name"].lower()
        seen.setdefault(key, []).append(pkg)
    return [
        {"name": name, "occurrences": pkgs}
        for name, pkgs in seen.items()
        if len(pkgs) > 1
    ]


def _find_conflicts(packages: list[dict]) -> list[dict]:
    """Find packages with conflicting version constraints."""
    from collections import defaultdict
    by_name: dict[str, list] = defaultdict(list)
    for pkg in packages:
        by_name[pkg["name"].lower()].append(pkg["constraint"])

    conflicts = []
    for name, constraints in by_name.items():
        if len(constraints) > 1:
            # Simple conflict: same package, different pins
            unique = set(c for c in constraints if c)
            if len(unique) > 1:
                conflicts.append({
                    "package": name,
                    "constraints": list(unique),
                    "reason": "Same package specified multiple times with different constraints",
                })

    return conflicts
