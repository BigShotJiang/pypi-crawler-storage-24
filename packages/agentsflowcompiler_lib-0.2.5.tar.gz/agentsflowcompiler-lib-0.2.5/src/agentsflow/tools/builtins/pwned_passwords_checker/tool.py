"""Pwned passwords checker — checks HIBP k-anonymity API without exposing the full password."""

import hashlib
import urllib.request
import urllib.error


_HIBP_API = "https://api.pwnedpasswords.com/range/{prefix}"


def run(password: str) -> dict:
    """Check if a password has been exposed in data breaches.

    Uses k-anonymity: only the first 5 characters of the SHA-1 hash
    are sent to the API. The password itself is never transmitted.

    Args:
        password: Password to check.

    Returns:
        Dictionary with breach count and risk level.
    """
    if not password:
        raise ValueError("password must not be empty.")

    # Compute SHA-1 hash
    sha1 = hashlib.sha1(password.encode("utf-8"), usedforsecurity=False).hexdigest().upper()  # noqa: S324 - SHA1 required by HIBP k-anonymity protocol
    prefix = sha1[:5]
    suffix = sha1[5:]

    # Query HIBP with just the prefix (k-anonymity)
    url = _HIBP_API.format(prefix=prefix)
    req = urllib.request.Request(url, headers={
        "User-Agent": "agentsflow/1.0",
        "Add-Padding": "true",
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HIBP API error {e.code}: {e.reason}") from e

    # Search for our suffix in the response
    breach_count = 0
    for line in body.splitlines():
        if ":" in line:
            hash_suffix, count = line.strip().split(":", 1)
            if hash_suffix.upper() == suffix:
                breach_count = int(count)
                break

    pwned = breach_count > 0

    if breach_count == 0:
        risk_level = "safe"
    elif breach_count < 10:
        risk_level = "low"
    elif breach_count < 100:
        risk_level = "medium"
    elif breach_count < 10000:
        risk_level = "high"
    else:
        risk_level = "critical"

    return {
        "pwned": pwned,
        "breach_count": breach_count,
        "risk_level": risk_level,
        "sha1_prefix": prefix,
    }
