"""Timezone comparator — shows current time across multiple zones for scheduling."""

from datetime import datetime, timezone, timedelta
import re


def run(
    timezones: str,
    reference_time: str = "",
    reference_timezone: str = "UTC",
) -> dict:
    """Compare times across multiple timezones.

    Uses zoneinfo (Python 3.9+) or falls back to pytz.

    Args:
        timezones: Comma-separated timezone names.
        reference_time: ISO datetime string in reference timezone.
        reference_timezone: Timezone of the reference_time.

    Returns:
        Dictionary with per-timezone local times.
    """
    if not timezones or not timezones.strip():
        raise ValueError("timezones must not be empty.")

    tz_list = [t.strip() for t in timezones.split(",") if t.strip()]

    # Get the time module
    tz_module = _get_tz_module()

    # Resolve reference time in UTC
    if reference_time and reference_time.strip():
        ref_tz = tz_module(reference_timezone or "UTC")
        naive = _parse_datetime(reference_time.strip())
        ref_aware = naive.replace(tzinfo=ref_tz)
        utc_time = ref_aware.astimezone(timezone.utc)
    else:
        utc_time = datetime.now(timezone.utc)

    results = []
    for tz_name in tz_list:
        try:
            tz = tz_module(tz_name)
            local = utc_time.astimezone(tz)
            offset_seconds = local.utcoffset().total_seconds()
            offset_hours = offset_seconds / 3600
            sign = "+" if offset_hours >= 0 else "-"
            offset_str = f"UTC{sign}{abs(offset_hours):.1f}"

            hour = local.hour
            is_business = 9 <= hour < 18 and local.weekday() < 5

            results.append({
                "timezone": tz_name,
                "local_time": local.strftime("%Y-%m-%d %H:%M:%S"),
                "utc_offset": offset_str,
                "is_business_hours": is_business,
            })
        except Exception as exc:
            results.append({
                "timezone": tz_name,
                "local_time": f"Error: {exc}",
                "utc_offset": "",
                "is_business_hours": False,
            })

    return {
        "reference_utc": utc_time.strftime("%Y-%m-%d %H:%M:%S UTC"),
        "times": results,
    }


def _get_tz_module():
    """Return a timezone factory function."""
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo
    except ImportError:
        pass
    try:
        import importlib
        pytz = importlib.import_module("pytz")
        return pytz.timezone
    except ImportError:
        pass
    # Minimal fallback using fixed UTC offsets for common zones
    return _simple_tz


def _simple_tz(name: str):
    """Very basic fixed-offset timezone fallback."""
    _offsets = {
        "UTC": 0, "GMT": 0,
        "America/New_York": -5, "America/Los_Angeles": -8, "America/Chicago": -6,
        "Europe/London": 0, "Europe/Paris": 1, "Europe/Berlin": 1,
        "Asia/Jerusalem": 2, "Asia/Tokyo": 9, "Asia/Shanghai": 8,
        "Asia/Dubai": 4, "Australia/Sydney": 10,
    }
    offset = _offsets.get(name, 0)
    return timezone(timedelta(hours=offset), name=name)


def _parse_datetime(s: str) -> datetime:
    """Parse ISO datetime string."""
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise ValueError(f"Cannot parse datetime: '{s}'. Use ISO format like '2024-03-15T14:00:00'")
