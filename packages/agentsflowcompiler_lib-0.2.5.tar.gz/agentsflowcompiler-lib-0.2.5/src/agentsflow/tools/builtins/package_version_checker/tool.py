"""Package version checker — queries PyPI or npm for latest package versions."""

import json
import urllib.request
import urllib.parse
import urllib.error


def run(package: str, registry: str = "pypi", current_version: str = "") -> dict:
    """Check the latest version of a package on PyPI or npm.

    Args:
        package: Package name.
        registry: 'pypi' or 'npm'.
        current_version: Your current version for outdated check.

    Returns:
        Dictionary with version info and outdated flag.
    """
    if not package or not package.strip():
        raise ValueError("package must not be empty.")

    pkg = package.strip()
    reg = registry.strip().lower() or "pypi"

    if reg not in ("pypi", "npm"):
        raise ValueError("registry must be 'pypi' or 'npm'.")

    if reg == "pypi":
        return _check_pypi(pkg, current_version.strip())
    else:
        return _check_npm(pkg, current_version.strip())


def _check_pypi(package: str, current: str) -> dict:
    url = f"https://pypi.org/pypi/{urllib.parse.quote(package)}/json"
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ValueError(f"Package '{package}' not found on PyPI.")
        raise RuntimeError(f"PyPI API error {e.code}") from e

    info = data.get("info", {})
    latest = info.get("version", "")
    release_date = ""
    releases = data.get("releases", {})
    if latest in releases and releases[latest]:
        release_date = releases[latest][-1].get("upload_time", "")[:10]

    is_outdated = bool(current and current != latest)
    return {
        "package": package,
        "registry": "pypi",
        "latest_version": latest,
        "current_version": current,
        "is_outdated": is_outdated,
        "release_date": release_date,
        "homepage": info.get("home_page") or info.get("project_url") or "",
    }


def _check_npm(package: str, current: str) -> dict:
    url = f"https://registry.npmjs.org/{urllib.parse.quote(package, safe='@%')}/latest"
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ValueError(f"Package '{package}' not found on npm.")
        raise RuntimeError(f"npm API error {e.code}") from e

    latest = data.get("version", "")
    release_date = (data.get("dist", {}).get("tarball", "") or "")  # no direct date in /latest
    homepage = data.get("homepage", "") or data.get("repository", {}).get("url", "")
    is_outdated = bool(current and current != latest)

    return {
        "package": package,
        "registry": "npm",
        "latest_version": latest,
        "current_version": current,
        "is_outdated": is_outdated,
        "release_date": "",
        "homepage": homepage,
    }
