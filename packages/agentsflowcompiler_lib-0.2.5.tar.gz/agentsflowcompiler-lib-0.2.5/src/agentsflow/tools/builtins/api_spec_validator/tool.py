"""API spec validator — validates JSON payloads against JSON Schema."""

import json


def run(payload: str, schema: str) -> dict:
    """Validate a JSON payload against a JSON Schema.

    Uses the built-in jsonschema library if available, otherwise falls back
    to basic type/required field checking.

    Args:
        payload: JSON string to validate.
        schema: JSON Schema string to validate against.

    Returns:
        Dictionary with valid flag, errors list, and warnings list.
    """
    if not payload or not payload.strip():
        raise ValueError("payload must not be empty.")
    if not schema or not schema.strip():
        raise ValueError("schema must not be empty.")

    try:
        data = json.loads(payload)
    except json.JSONDecodeError as exc:
        return {"valid": False, "errors": [f"Invalid JSON payload: {exc}"], "warnings": []}

    try:
        schema_obj = json.loads(schema)
    except json.JSONDecodeError as exc:
        return {"valid": False, "errors": [f"Invalid JSON schema: {exc}"], "warnings": []}

    # Try jsonschema first (dynamic import)
    try:
        import importlib
        jsonschema = importlib.import_module("jsonschema")
        validator_cls = jsonschema.Draft7Validator
        validator = validator_cls(schema_obj)
        errors = [str(e.message) for e in validator.iter_errors(data)]
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": [],
        }
    except ImportError:
        pass

    # Fallback: basic manual validation
    errors, warnings = _basic_validate(data, schema_obj, path="$")
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings + ["jsonschema library not installed — using basic validation"],
    }


def _basic_validate(data: object, schema: dict, path: str = "$") -> tuple[list, list]:
    """Simple JSON Schema validation covering type, required, properties, items."""
    errors: list[str] = []
    warnings: list[str] = []

    schema_type = schema.get("type")
    if schema_type:
        type_map = {
            "object": dict, "array": list, "string": str,
            "number": (int, float), "integer": int,
            "boolean": bool, "null": type(None),
        }
        expected = type_map.get(schema_type)
        if expected and not isinstance(data, expected):
            errors.append(f"{path}: expected {schema_type}, got {type(data).__name__}")
            return errors, warnings

    if schema_type == "object" and isinstance(data, dict):
        required = schema.get("required", [])
        for field in required:
            if field not in data:
                errors.append(f"{path}: missing required field '{field}'")

        properties = schema.get("properties", {})
        for key, prop_schema in properties.items():
            if key in data:
                sub_errors, sub_warns = _basic_validate(data[key], prop_schema, f"{path}.{key}")
                errors.extend(sub_errors)
                warnings.extend(sub_warns)

    if schema_type == "array" and isinstance(data, list):
        items_schema = schema.get("items")
        if items_schema:
            for i, item in enumerate(data):
                sub_errors, sub_warns = _basic_validate(item, items_schema, f"{path}[{i}]")
                errors.extend(sub_errors)
                warnings.extend(sub_warns)

    if schema_type == "string" and isinstance(data, str):
        min_len = schema.get("minLength")
        max_len = schema.get("maxLength")
        if min_len is not None and len(data) < min_len:
            errors.append(f"{path}: string length {len(data)} < minLength {min_len}")
        if max_len is not None and len(data) > max_len:
            errors.append(f"{path}: string length {len(data)} > maxLength {max_len}")

    if schema_type in ("number", "integer") and isinstance(data, (int, float)):
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if minimum is not None and data < minimum:
            errors.append(f"{path}: value {data} < minimum {minimum}")
        if maximum is not None and data > maximum:
            errors.append(f"{path}: value {data} > maximum {maximum}")

    return errors, warnings
