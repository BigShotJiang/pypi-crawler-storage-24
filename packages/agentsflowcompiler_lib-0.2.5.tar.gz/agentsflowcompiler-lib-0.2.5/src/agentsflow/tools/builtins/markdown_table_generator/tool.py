"""Markdown table generator — converts JSON arrays to formatted Markdown tables."""

import json


def run(data: str, columns: str = "", alignment: str = "left") -> dict:
    """Convert a JSON array of objects to a Markdown table.

    Args:
        data: JSON array of objects.
        columns: Comma-separated column names (empty = all).
        alignment: Column alignment (left/center/right).

    Returns:
        Dictionary with the Markdown table string.
    """
    if not data or not data.strip():
        raise ValueError("data must not be empty.")

    try:
        rows = json.loads(data.strip())
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc}") from exc

    if not isinstance(rows, list):
        raise ValueError("JSON must be an array of objects.")
    if not rows:
        return {"table": "(empty table)", "rows": 0, "columns": []}
    if not isinstance(rows[0], dict):
        raise ValueError("Array elements must be objects (dicts).")

    align = alignment.strip().lower() or "left"
    if align not in ("left", "center", "right"):
        raise ValueError("alignment must be 'left', 'center', or 'right'.")

    # Determine columns
    all_cols = list(rows[0].keys())
    if columns and columns.strip():
        col_list = [c.strip() for c in columns.split(",") if c.strip()]
        col_list = [c for c in col_list if c in all_cols]
    else:
        col_list = all_cols

    # Calculate column widths
    widths = {col: len(col) for col in col_list}
    for row in rows:
        for col in col_list:
            val = str(row.get(col, ""))
            widths[col] = max(widths[col], len(val))

    # Alignment spec
    align_char = {"left": ":-", "center": ":-:", "right": "-:"}[align]

    # Build table
    header = "| " + " | ".join(col.ljust(widths[col]) for col in col_list) + " |"
    separator = "| " + " | ".join(
        (align_char[0] + "-" * (widths[col] - 1) + align_char[-1])
        if len(align_char) > 1 else ("-" * widths[col])
        for col in col_list
    ) + " |"

    data_rows = []
    for row in rows:
        cells = [str(row.get(col, "")).ljust(widths[col]) for col in col_list]
        data_rows.append("| " + " | ".join(cells) + " |")

    table = "\n".join([header, separator] + data_rows)

    return {
        "table": table,
        "rows": len(rows),
        "columns": col_list,
    }
