"""Slack/Discord notifier — sends messages via webhooks."""

import json
import urllib.request
import urllib.error


_COLOR_MAP = {
    "good": "#36a64f",
    "warning": "#ffcc00",
    "danger": "#ff0000",
    "info": "#0099ff",
}


def run(
    webhook_url: str,
    message: str,
    title: str = "",
    color: str = "",
    platform: str = "",
) -> dict:
    """Send a notification to Slack or Discord.

    Args:
        webhook_url: Slack or Discord webhook URL.
        message: Message text.
        title: Optional message title.
        color: Attachment color (good/warning/danger or hex).
        platform: 'slack' or 'discord' (auto-detected if empty).

    Returns:
        Dictionary with success flag and status code.
    """
    if not webhook_url or not webhook_url.strip():
        raise ValueError("webhook_url must not be empty.")
    if not message or not message.strip():
        raise ValueError("message must not be empty.")

    url = webhook_url.strip()
    detected_platform = platform.strip().lower() or _detect_platform(url)

    hex_color = _COLOR_MAP.get(color.lower(), color) if color else "#0099ff"

    if detected_platform == "discord":
        payload = _build_discord_payload(message, title, hex_color)
    else:
        payload = _build_slack_payload(message, title, hex_color)

    status = _send_webhook(url, payload)
    return {
        "success": status < 400,
        "platform": detected_platform,
        "status_code": status,
    }


def _build_slack_payload(message: str, title: str, color: str) -> dict:
    attachment = {
        "color": color,
        "text": message,
        "mrkdwn_in": ["text"],
    }
    if title:
        attachment["title"] = title
    return {"attachments": [attachment]}


def _build_discord_payload(message: str, title: str, color: str) -> dict:
    embed_color = int(color.lstrip("#"), 16) if color.startswith("#") else 0x0099FF
    embed = {
        "description": message,
        "color": embed_color,
    }
    if title:
        embed["title"] = title
    return {"embeds": [embed]}


def _detect_platform(url: str) -> str:
    if "discord.com" in url or "discordapp.com" in url:
        return "discord"
    return "slack"


def _send_webhook(url: str, payload: dict) -> int:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json", "User-Agent": "agentsflow/1.0"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            return resp.status
    except urllib.error.HTTPError as e:
        return e.code
