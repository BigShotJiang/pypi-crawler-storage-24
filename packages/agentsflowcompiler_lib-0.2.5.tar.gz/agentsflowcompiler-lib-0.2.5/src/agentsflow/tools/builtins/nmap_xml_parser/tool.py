"""Nmap XML parser — converts Nmap scan output to structured Python objects."""

try:
    import defusedxml.ElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET  # nosec B405 - defusedxml not installed, input is trusted Nmap output
from pathlib import Path


def run(xml_file: str = "", xml_content: str = "") -> dict:
    """Parse an Nmap XML scan report.

    Args:
        xml_file: Path to the Nmap XML file.
        xml_content: Nmap XML as a string (alternative to xml_file).

    Returns:
        Dictionary with scan info, hosts, and summary.
    """
    if not xml_file and not xml_content:
        raise ValueError("Either xml_file or xml_content must be provided.")

    if xml_content and xml_content.strip():
        content = xml_content.strip()
    else:
        path = Path(xml_file.strip()).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        content = path.read_text(encoding="utf-8")

    try:
        root = ET.fromstring(content)  # nosec B314
    except ET.ParseError as exc:
        raise ValueError(f"Invalid Nmap XML: {exc}") from exc

    if root.tag != "nmaprun":
        raise ValueError("Not a valid Nmap XML output (expected root tag 'nmaprun').")

    # Scan info
    scan_info = {
        "scanner": root.get("scanner", "nmap"),
        "version": root.get("version", ""),
        "start_time": root.get("startstr", ""),
        "command": root.get("args", ""),
    }

    # Scan stats
    run_stats = root.find("runstats")
    finished = run_stats.find("finished") if run_stats is not None else None
    hosts_el = run_stats.find("hosts") if run_stats is not None else None

    scan_info["end_time"] = finished.get("timestr", "") if finished is not None else ""
    total_hosts = int(hosts_el.get("total", 0)) if hosts_el is not None else 0
    up_hosts = int(hosts_el.get("up", 0)) if hosts_el is not None else 0

    # Parse hosts
    hosts = []
    for host_el in root.findall("host"):
        hosts.append(_parse_host(host_el))

    summary = {
        "total_hosts": total_hosts,
        "hosts_up": up_hosts,
        "hosts_down": total_hosts - up_hosts,
        "open_ports_total": sum(
            sum(1 for p in h["ports"] if p["state"] == "open")
            for h in hosts
        ),
    }

    return {
        "scan_info": scan_info,
        "hosts": hosts,
        "summary": summary,
    }


def _parse_host(host_el: ET.Element) -> dict:
    """Parse a <host> element."""
    # Status
    status_el = host_el.find("status")
    status = status_el.get("state", "unknown") if status_el is not None else "unknown"

    # IP address
    ip = ""
    hostname = ""
    for addr_el in host_el.findall("address"):
        if addr_el.get("addrtype") in ("ipv4", "ipv6"):
            ip = addr_el.get("addr", "")

    # Hostname
    hostnames_el = host_el.find("hostnames")
    if hostnames_el is not None:
        hn_el = hostnames_el.find("hostname")
        if hn_el is not None:
            hostname = hn_el.get("name", "")

    # OS detection
    os_name = ""
    os_el = host_el.find("os")
    if os_el is not None:
        osmatch = os_el.find("osmatch")
        if osmatch is not None:
            os_name = osmatch.get("name", "")

    # Ports
    ports = []
    ports_el = host_el.find("ports")
    if ports_el is not None:
        for port_el in ports_el.findall("port"):
            state_el = port_el.find("state")
            service_el = port_el.find("service")
            ports.append({
                "port": int(port_el.get("portid", 0)),
                "protocol": port_el.get("protocol", "tcp"),
                "state": state_el.get("state", "") if state_el is not None else "",
                "service": service_el.get("name", "") if service_el is not None else "",
                "version": (
                    f"{service_el.get('product', '')} {service_el.get('version', '')}".strip()
                    if service_el is not None else ""
                ),
            })

    return {
        "ip": ip,
        "hostname": hostname,
        "status": status,
        "os": os_name,
        "ports": ports,
    }
