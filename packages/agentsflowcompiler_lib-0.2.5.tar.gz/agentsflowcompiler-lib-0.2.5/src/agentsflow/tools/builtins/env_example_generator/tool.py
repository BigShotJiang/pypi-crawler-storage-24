"""Environment variable example generator — scans source code for env var usage."""

import fnmatch
import os
import re
from pathlib import Path


# Patterns for different languages
_PATTERNS = [
    # Python: os.environ.get("VAR") or os.environ["VAR"] or os.getenv("VAR")
    re.compile(r'os\.environ(?:\.get)?\(\s*["\']([A-Z_][A-Z0-9_]*)["\'](?:\s*,\s*["\']([^"\']*)["\'])?\s*\)'),
    re.compile(r'os\.getenv\(\s*["\']([A-Z_][A-Z0-9_]*)["\'](?:\s*,\s*["\']([^"\']*)["\'])?\s*\)'),
    # JS/TS: process.env.VAR or process.env["VAR"]
    re.compile(r'process\.env\.([A-Z_][A-Z0-9_]*)'),
    re.compile(r'process\.env\[["\']([A-Z_][A-Z0-9_]*)["\']\]'),
    # dotenv style: ${VAR} in config files
    re.compile(r'\$\{([A-Z_][A-Z0-9_]*)\}'),
]

_SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}
_SKIP_VARS = {"PATH", "HOME", "USER", "SHELL", "TERM", "PWD", "LANG", "LC_ALL"}


def run(
    source_path: str,
    output_path: str = "",
    file_patterns: str = "*.py,*.js,*.ts,*.mjs,*.env.example",
) -> dict:
    """Scan source files for environment variable usage.

    Args:
        source_path: Directory or file to scan.
        output_path: Where to write .env.example.
        file_patterns: Glob patterns for files to scan.

    Returns:
        Dictionary with discovered env vars and example content.
    """
    if not source_path or not source_path.strip():
        raise ValueError("source_path must not be empty.")

    root = Path(source_path.strip()).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"Path not found: {root}")

    patterns = [p.strip() for p in (file_patterns or "*.py,*.js,*.ts,*.mjs").split(",") if p.strip()]

    # Collect files
    files = _collect_files(root, patterns)

    # Scan for env vars
    all_vars: dict[str, dict] = {}
    for file_path in files:
        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
        except (PermissionError, OSError):
            continue
        for pat in _PATTERNS:
            for m in pat.finditer(content):
                var_name = m.group(1)
                if var_name in _SKIP_VARS:
                    continue
                default = m.group(2) if m.lastindex and m.lastindex >= 2 else ""
                if var_name not in all_vars:
                    all_vars[var_name] = {
                        "name": var_name,
                        "default": default or "",
                        "source_file": str(file_path.relative_to(root)),
                    }

    # Build .env.example
    sorted_vars = sorted(all_vars.values(), key=lambda v: v["name"])
    lines = ["# Auto-generated .env.example", "# Fill in your actual values\n"]
    for var in sorted_vars:
        comment = f"# From: {var['source_file']}"
        lines.append(comment)
        lines.append(f"{var['name']}={var['default']}")
        lines.append("")

    env_content = "\n".join(lines)

    # Write output if requested
    out_file = None
    if output_path and output_path.strip():
        out_path = Path(output_path.strip()).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(env_content, encoding="utf-8")
        out_file = str(out_path)

    return {
        "env_vars": sorted_vars,
        "env_example_content": env_content,
        "output_file": out_file,
    }


def _collect_files(root: Path, patterns: list[str]) -> list[Path]:
    """Collect matching files recursively."""
    if root.is_file():
        return [root]

    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fname in filenames:
            for pat in patterns:
                if fnmatch.fnmatch(fname, pat):
                    files.append(Path(dirpath) / fname)
                    break
    return files
