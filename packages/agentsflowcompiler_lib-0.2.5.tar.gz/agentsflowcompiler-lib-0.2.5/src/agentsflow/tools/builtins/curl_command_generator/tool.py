"""CURL command generator — converts HTTP request specs into curl commands."""

import json
import shlex


_CONTENT_TYPES = {
    "json": "application/json",
    "form": "application/x-www-form-urlencoded",
    "xml": "application/xml",
    "text": "text/plain",
    "multipart": "multipart/form-data",
}


def run(
    url: str,
    method: str = "GET",
    headers: str = "",
    body: str = "",
    content_type: str = "",
    follow_redirects: bool = False,
    verbose: bool = False,
) -> dict:
    """Build a curl command from HTTP request parameters.

    Args:
        url: Target URL.
        method: HTTP method (GET, POST, PUT, PATCH, DELETE).
        headers: JSON string of headers dict.
        body: Request body string.
        content_type: Shortcut for Content-Type (json, form, xml).
        follow_redirects: Add -L flag.
        verbose: Add -v flag.

    Returns:
        Dictionary with the curl command string and an explanation.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()
    method = method.strip().upper() or "GET"

    # Parse headers
    headers_dict: dict[str, str] = {}
    if headers and headers.strip():
        try:
            parsed = json.loads(headers)
            if isinstance(parsed, dict):
                headers_dict = {str(k): str(v) for k, v in parsed.items()}
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid headers JSON: {exc}") from exc

    # Apply content-type shortcut
    if content_type:
        ct = _CONTENT_TYPES.get(content_type.strip().lower())
        if ct:
            headers_dict.setdefault("Content-Type", ct)

    # Build curl parts
    parts = ["curl"]

    if verbose:
        parts.append("-v")
    if follow_redirects:
        parts.append("-L")

    # Method
    if method != "GET":
        parts += ["-X", method]

    # Headers
    for key, value in headers_dict.items():
        parts += ["-H", f"{key}: {value}"]

    # Body
    if body and body.strip():
        parts += ["-d", body.strip()]

    parts.append(url)

    # Build readable command
    curl_command = " \\\n  ".join(shlex.quote(p) if _needs_quoting(p) else p for p in parts)

    explanation_parts = [f"Sends a {method} request to {url}"]
    if headers_dict:
        explanation_parts.append(f"with {len(headers_dict)} custom header(s)")
    if body:
        explanation_parts.append("and a request body")
    if follow_redirects:
        explanation_parts.append("following any redirects")

    return {
        "curl_command": curl_command,
        "explanation": " ".join(explanation_parts) + ".",
    }


def _needs_quoting(s: str) -> bool:
    """Check if a string needs shell quoting."""
    safe_chars = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_./:")
    return not all(c in safe_chars for c in s)
