"""Docker inspector — lists containers and retrieves logs/details."""

import json
import subprocess


def run(action: str, container: str = "", tail_lines: int = 50) -> dict:
    """Inspect Docker containers.

    Uses docker SDK if available, otherwise falls back to docker CLI.

    Args:
        action: 'list', 'inspect', or 'logs'.
        container: Container name or ID (required for inspect/logs).
        tail_lines: Number of log lines for 'logs' action.

    Returns:
        Dictionary with action-specific results.
    """
    if not action or not action.strip():
        raise ValueError("action must not be empty.")

    action = action.strip().lower()
    if action not in ("list", "inspect", "logs"):
        raise ValueError("action must be 'list', 'inspect', or 'logs'.")

    if action in ("inspect", "logs") and not container:
        raise ValueError(f"container is required for action '{action}'.")

    # Try docker SDK first
    try:
        import importlib
        docker = importlib.import_module("docker")
        client = docker.from_env()
        if action == "list":
            return _sdk_list(client)
        elif action == "inspect":
            return _sdk_inspect(client, container)
        elif action == "logs":
            return _sdk_logs(client, container, int(tail_lines))
    except ImportError:
        pass
    except Exception:
        pass

    # Fallback: docker CLI
    if action == "list":
        return _cli_list()
    elif action == "inspect":
        return _cli_inspect(container)
    elif action == "logs":
        return _cli_logs(container, int(tail_lines))


# ── SDK implementations ────────────────────────────────────────

def _sdk_list(client) -> dict:
    containers = client.containers.list(all=True)
    return {
        "containers": [
            {
                "id": c.short_id,
                "name": c.name,
                "image": c.image.tags[0] if c.image.tags else str(c.image.id)[:12],
                "status": c.status,
                "ports": c.ports,
            }
            for c in containers
        ]
    }


def _sdk_inspect(client, name: str) -> dict:
    c = client.containers.get(name)
    attrs = c.attrs
    cfg = attrs.get("Config", {})
    return {
        "id": c.short_id,
        "name": c.name,
        "image": cfg.get("Image", ""),
        "status": c.status,
        "created": attrs.get("Created", ""),
        "env": cfg.get("Env", []),
        "ports": attrs.get("NetworkSettings", {}).get("Ports", {}),
        "mounts": [m.get("Source") for m in attrs.get("Mounts", [])],
    }


def _sdk_logs(client, name: str, tail: int) -> dict:
    c = client.containers.get(name)
    logs = c.logs(tail=tail, stream=False).decode("utf-8", errors="replace")
    return {"container": name, "lines": logs.splitlines()}


# ── CLI fallback ───────────────────────────────────────────────

def _cli_run(args: list[str]) -> str:
    result = subprocess.run(
        ["docker"] + args,
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(f"docker {' '.join(args)}: {result.stderr.strip()}")
    return result.stdout.strip()


def _cli_list() -> dict:
    out = _cli_run(["ps", "-a", "--format", "{{json .}}"])
    containers = []
    for line in out.splitlines():
        if line.strip():
            d = json.loads(line)
            containers.append({
                "id": d.get("ID", ""),
                "name": d.get("Names", ""),
                "image": d.get("Image", ""),
                "status": d.get("Status", ""),
                "ports": d.get("Ports", ""),
            })
    return {"containers": containers}


def _cli_inspect(name: str) -> dict:
    out = _cli_run(["inspect", name])
    data = json.loads(out)[0]
    cfg = data.get("Config", {})
    return {
        "id": data.get("Id", "")[:12],
        "name": data.get("Name", "").lstrip("/"),
        "image": cfg.get("Image", ""),
        "status": data.get("State", {}).get("Status", ""),
        "created": data.get("Created", ""),
        "env": cfg.get("Env", []),
        "ports": data.get("NetworkSettings", {}).get("Ports", {}),
        "mounts": [m.get("Source") for m in data.get("Mounts", [])],
    }


def _cli_logs(name: str, tail: int) -> dict:
    out = _cli_run(["logs", "--tail", str(tail), name])
    return {"container": name, "lines": out.splitlines()}
