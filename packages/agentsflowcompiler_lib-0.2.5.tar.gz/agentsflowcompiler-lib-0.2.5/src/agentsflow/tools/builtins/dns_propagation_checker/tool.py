"""DNS propagation checker — verifies DNS record consistency across global resolvers."""

import socket
import struct

# Global resolvers: (IP, friendly name)
_RESOLVERS = [
    ("8.8.8.8", "Google Primary"),
    ("8.8.4.4", "Google Secondary"),
    ("1.1.1.1", "Cloudflare Primary"),
    ("1.0.0.1", "Cloudflare Secondary"),
    ("9.9.9.9", "Quad9"),
    ("208.67.222.222", "OpenDNS"),
    ("64.6.64.6", "Verisign"),
    ("77.88.8.8", "Yandex"),
]

_RECORD_TYPES = {"A": 1, "NS": 2, "CNAME": 5, "MX": 15, "AAAA": 28, "TXT": 16}


def run(domain: str, record_type: str = "A") -> dict:
    """Check DNS propagation for a domain across multiple global resolvers.

    Args:
        domain: Domain name to query.
        record_type: DNS record type (A, AAAA, MX, TXT, CNAME, NS).

    Returns:
        Dictionary with per-resolver results and consistency check.
    """
    if not domain or not domain.strip():
        raise ValueError("domain must not be empty.")

    domain = domain.strip().lower().rstrip(".")
    rtype = record_type.strip().upper()
    if rtype not in _RECORD_TYPES:
        raise ValueError(f"Unsupported record type '{rtype}'. Supported: {list(_RECORD_TYPES)}")

    results = []
    all_answers = []

    for resolver_ip, resolver_name in _RESOLVERS:
        try:
            records = _dns_query(domain, rtype, resolver_ip)
            status = "ok"
        except Exception as exc:
            records = []
            status = f"error: {exc}"

        results.append({
            "resolver": resolver_ip,
            "resolver_name": resolver_name,
            "records": records,
            "status": status,
        })
        if records:
            all_answers.append(frozenset(records))

    unique_answers = [list(s) for s in {frozenset(r["records"]) for r in results if r["records"]}]
    consistent = len(unique_answers) <= 1

    return {
        "domain": domain,
        "record_type": rtype,
        "results": results,
        "consistent": consistent,
        "unique_answers": unique_answers,
    }


def _dns_query(domain: str, qtype: str, server: str, timeout: float = 5.0) -> list[str]:
    """Send a raw DNS query and parse A/AAAA/MX/TXT/CNAME/NS records."""
    qtype_id = _RECORD_TYPES[qtype]
    query = _build_dns_query(domain, qtype_id)

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(timeout)
        s.sendto(query, (server, 53))
        response, _ = s.recvfrom(4096)

    return _parse_dns_response(response, qtype)


def _build_dns_query(domain: str, qtype: int) -> bytes:
    """Build a minimal DNS query packet."""
    header = struct.pack(">HHHHHH", 0x1234, 0x0100, 1, 0, 0, 0)
    question = b""
    for part in domain.split("."):
        encoded = part.encode("ascii")
        question += bytes([len(encoded)]) + encoded
    question += b"\x00"
    question += struct.pack(">HH", qtype, 1)  # QTYPE, QCLASS=IN
    return header + question


def _parse_dns_response(data: bytes, qtype: str) -> list[str]:
    """Parse DNS response and extract answer records as strings."""
    if len(data) < 12:
        return []

    ancount = struct.unpack(">H", data[6:8])[0]
    if ancount == 0:
        return []

    # Skip header (12 bytes) and question section
    pos = 12
    pos = _skip_question(data, pos)

    answers = []
    for _ in range(ancount):
        if pos >= len(data):
            break
        pos, name = _read_name(data, pos)
        if pos + 10 > len(data):
            break
        rtype, rclass, ttl, rdlength = struct.unpack(">HHIH", data[pos:pos + 10])
        pos += 10
        rdata = data[pos:pos + rdlength]
        pos += rdlength

        record = _decode_rdata(rtype, rdata, data, qtype)
        if record:
            answers.append(record)

    return answers


def _skip_question(data: bytes, pos: int) -> int:
    while pos < len(data) and data[pos] != 0:
        if data[pos] & 0xC0 == 0xC0:
            pos += 2
            return pos
        pos += data[pos] + 1
    return pos + 5  # null byte + qtype(2) + qclass(2)


def _read_name(data: bytes, pos: int) -> tuple[int, str]:
    """Read a DNS name (with pointer support) starting at pos."""
    labels = []
    jumped = False
    jump_pos = pos
    while pos < len(data):
        length = data[pos]
        if length == 0:
            pos += 1
            break
        if length & 0xC0 == 0xC0:  # pointer
            if not jumped:
                jump_pos = pos + 2
            pos = ((length & 0x3F) << 8) | data[pos + 1]
            jumped = True
        else:
            pos += 1
            labels.append(data[pos:pos + length].decode("ascii", errors="replace"))
            pos += length
    return (jump_pos if jumped else pos), ".".join(labels)


def _decode_rdata(rtype: int, rdata: bytes, full_packet: bytes, qtype: str) -> str | None:
    """Decode record data to a human-readable string."""
    try:
        if rtype == 1:  # A
            return socket.inet_ntoa(rdata)
        if rtype == 28:  # AAAA
            return socket.inet_ntop(socket.AF_INET6, rdata)
        if rtype in (2, 5, 12):  # NS, CNAME, PTR
            _, name = _read_name(full_packet, len(full_packet) - len(rdata))
            # Simpler: decode directly if no pointer
            return _decode_name_bytes(rdata)
        if rtype == 15:  # MX
            pref = struct.unpack(">H", rdata[:2])[0]
            name = _decode_name_bytes(rdata[2:])
            return f"{pref} {name}"
        if rtype == 16:  # TXT
            parts = []
            i = 0
            while i < len(rdata):
                l = rdata[i]
                parts.append(rdata[i + 1:i + 1 + l].decode("utf-8", errors="replace"))
                i += 1 + l
            return " ".join(parts)
    except Exception:
        pass
    return None


def _decode_name_bytes(data: bytes) -> str:
    """Decode a raw DNS name without pointer support."""
    labels = []
    pos = 0
    while pos < len(data):
        length = data[pos]
        if length == 0:
            break
        pos += 1
        labels.append(data[pos:pos + length].decode("ascii", errors="replace"))
        pos += length
    return ".".join(labels)
