"""Gas price monitor — fetches current Ethereum network gas prices."""

import json
import urllib.request
import urllib.error


_GAS_API = "https://api.etherscan.io/api?module=gastracker&action=gasoracle"
_ETH_PRICE_API = "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd"
_ETH_RPC = "https://cloudflare-eth.com"


def run() -> dict:
    """Fetch current Ethereum gas prices.

    Returns:
        Dictionary with slow/standard/fast gas prices in Gwei.
    """
    # Get gas prices
    slow, standard, fast, base_fee = _fetch_gas_prices()
    eth_usd = _fetch_eth_price()

    # Estimate cost of a simple ETH transfer (21,000 gas)
    transfer_gas = 21000
    def gwei_to_usd(gwei: float) -> float:
        return round(gwei * 1e-9 * transfer_gas * eth_usd, 4) if eth_usd else 0.0

    return {
        "slow_gwei": slow,
        "standard_gwei": standard,
        "fast_gwei": fast,
        "base_fee_gwei": base_fee,
        "eth_usd": eth_usd,
        "estimated_transfer_usd": {
            "slow": gwei_to_usd(slow),
            "standard": gwei_to_usd(standard),
            "fast": gwei_to_usd(fast),
        },
    }


def _fetch_gas_prices() -> tuple[float, float, float, float]:
    """Fetch gas prices, falling back to eth_gasPrice RPC."""
    # Try Etherscan gas oracle (no key = limited)
    try:
        req = urllib.request.Request(_GAS_API, headers={"User-Agent": "agentsflow/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
        if data.get("status") == "1":
            result = data["result"]
            return (
                float(result.get("SafeGasPrice", 0)),
                float(result.get("ProposeGasPrice", 0)),
                float(result.get("FastGasPrice", 0)),
                float(result.get("suggestBaseFee", 0)),
            )
    except Exception:
        pass

    # Fallback: eth_gasPrice RPC
    try:
        payload = json.dumps({"jsonrpc": "2.0", "method": "eth_gasPrice", "params": [], "id": 1}).encode()
        req = urllib.request.Request(
            _ETH_RPC, data=payload,
            headers={"Content-Type": "application/json", "User-Agent": "agentsflow/1.0"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            result = json.loads(resp.read().decode("utf-8"))
        gwei = int(result["result"], 16) / 1e9
        return gwei * 0.8, gwei, gwei * 1.5, gwei * 0.7
    except Exception:
        return 0.0, 0.0, 0.0, 0.0


def _fetch_eth_price() -> float:
    try:
        req = urllib.request.Request(_ETH_PRICE_API, headers={"User-Agent": "agentsflow/1.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:  # nosec B310 - URL validated to http/https scheme
            return float(json.loads(resp.read())["ethereum"]["usd"])
    except Exception:
        return 0.0
