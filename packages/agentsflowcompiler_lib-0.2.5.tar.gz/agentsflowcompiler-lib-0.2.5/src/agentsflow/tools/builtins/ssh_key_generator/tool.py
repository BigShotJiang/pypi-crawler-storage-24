"""SSH key generator — creates RSA and Ed25519 key pairs programmatically."""

import base64
import hashlib
import struct
from pathlib import Path


def run(
    key_type: str = "ed25519",
    rsa_key_size: int = 4096,
    comment: str = "",
    output_dir: str = "",
) -> dict:
    """Generate an SSH key pair.

    Requires: pip install cryptography

    Args:
        key_type: 'ed25519' or 'rsa'.
        rsa_key_size: RSA key size (2048/3072/4096).
        comment: Comment for the public key.
        output_dir: Save directory (empty = return content only).

    Returns:
        Dictionary with public key, private key PEM, and fingerprint.
    """
    try:
        import importlib
        hazmat_rsa = importlib.import_module("cryptography.hazmat.primitives.asymmetric.rsa")
        hazmat_ed = importlib.import_module("cryptography.hazmat.primitives.asymmetric.ed25519")
        serialization = importlib.import_module("cryptography.hazmat.primitives.serialization")
        backends = importlib.import_module("cryptography.hazmat.backends")
    except ImportError:
        raise ImportError("cryptography is required. Install with: pip install cryptography")

    ktype = key_type.strip().lower() or "ed25519"
    if ktype not in ("ed25519", "rsa"):
        raise ValueError("key_type must be 'ed25519' or 'rsa'.")

    rsa_bits = int(rsa_key_size)
    if rsa_bits not in (2048, 3072, 4096):
        raise ValueError("rsa_key_size must be 2048, 3072, or 4096.")

    # Generate key
    if ktype == "ed25519":
        private_key = hazmat_ed.Ed25519PrivateKey.generate()
    else:
        private_key = hazmat_rsa.generate_private_key(
            public_exponent=65537,
            key_size=rsa_bits,
            backend=backends.default_backend(),
        )

    # Serialize private key (no passphrase)
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.OpenSSH,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")

    # Serialize public key
    public_key_obj = private_key.public_key()
    public_openssh = public_key_obj.public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    ).decode("utf-8")

    if comment and comment.strip():
        public_openssh = public_openssh.rstrip() + f" {comment.strip()}"

    # Fingerprint (SHA-256)
    pub_bytes = public_key_obj.public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    )
    # Extract the raw key material (part after 'ssh-ed25519 ' or 'ssh-rsa ')
    raw_b64 = pub_bytes.split()[1]
    raw = base64.b64decode(raw_b64)
    fingerprint = "SHA256:" + base64.b64encode(hashlib.sha256(raw).digest()).rstrip(b"=").decode()

    output_files = None
    if output_dir and output_dir.strip():
        out = Path(output_dir.strip()).expanduser().resolve()
        out.mkdir(parents=True, exist_ok=True)
        priv_file = out / f"id_{ktype}"
        pub_file = out / f"id_{ktype}.pub"
        priv_file.write_text(private_pem)
        priv_file.chmod(0o600)
        pub_file.write_text(public_openssh + "\n")
        output_files = {"private": str(priv_file), "public": str(pub_file)}

    return {
        "key_type": ktype,
        "public_key": public_openssh,
        "private_key_pem": private_pem,
        "fingerprint": fingerprint,
        "output_files": output_files,
    }
