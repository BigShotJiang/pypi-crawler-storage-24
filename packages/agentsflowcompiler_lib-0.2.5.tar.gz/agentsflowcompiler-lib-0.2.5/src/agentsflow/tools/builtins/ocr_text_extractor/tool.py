"""OCR text extractor — extracts text from images using Tesseract or EasyOCR."""

from pathlib import Path


def run(file_path: str, language: str = "eng") -> dict:
    """Extract text from an image using OCR.

    Tries pytesseract first, then easyocr as fallback.
    Install: pip install pytesseract Pillow  (also needs Tesseract binary)
    Fallback: pip install easyocr

    Args:
        file_path: Path to the image file.
        language: Language code for OCR.

    Returns:
        Dictionary with extracted text and word count.
    """
    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")

    path = Path(file_path.strip()).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    # Try pytesseract first
    try:
        import importlib
        pytesseract = importlib.import_module("pytesseract")
        PIL_Image = importlib.import_module("PIL.Image")
        img = PIL_Image.open(str(path))
        text = pytesseract.image_to_string(img, lang=language)
        text = text.strip()
        return {
            "file": str(path),
            "text": text,
            "word_count": len(text.split()),
            "engine_used": "pytesseract",
        }
    except ImportError:
        pass
    except Exception as exc:
        raise RuntimeError(f"pytesseract failed: {exc}") from exc

    # Try easyocr as fallback
    try:
        import importlib
        easyocr = importlib.import_module("easyocr")
        lang_list = language.replace("+", " ").split()
        reader = easyocr.Reader(lang_list, gpu=False, verbose=False)
        results = reader.readtext(str(path))
        text = " ".join(r[1] for r in results).strip()
        return {
            "file": str(path),
            "text": text,
            "word_count": len(text.split()),
            "engine_used": "easyocr",
        }
    except ImportError:
        pass

    raise ImportError(
        "No OCR engine available. Install pytesseract (+ Tesseract binary) or easyocr.\n"
        "  pip install pytesseract Pillow\n"
        "  pip install easyocr"
    )
