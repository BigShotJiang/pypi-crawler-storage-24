"""Disk space watcher — monitors filesystem usage and raises alerts."""

import shutil
import subprocess
import platform
from pathlib import Path


def run(path: str = "", alert_threshold: float = 80.0) -> dict:
    """Check disk space usage.

    Uses shutil.disk_usage for a specific path, or parses df output for all mounts.

    Args:
        path: Specific path (empty = check all mounts).
        alert_threshold: Usage % threshold for alerts.

    Returns:
        Dictionary with per-disk usage and alert list.
    """
    alert_threshold = max(1.0, min(float(alert_threshold), 100.0))

    if path and path.strip():
        # Single path check
        p = Path(path.strip()).expanduser().resolve()
        usage = shutil.disk_usage(str(p))
        total_gb = usage.total / 1e9
        used_gb = usage.used / 1e9
        free_gb = usage.free / 1e9
        pct = (usage.used / usage.total * 100) if usage.total else 0.0
        disk = {
            "device": str(p),
            "mount": str(p),
            "total_gb": round(total_gb, 2),
            "used_gb": round(used_gb, 2),
            "free_gb": round(free_gb, 2),
            "percent_used": round(pct, 1),
            "alert": pct >= alert_threshold,
        }
        disks = [disk]
    else:
        disks = _get_all_disks(alert_threshold)

    alerts = [
        f"ALERT: {d['mount']} is {d['percent_used']}% full ({d['free_gb']:.1f} GB free)"
        for d in disks if d["alert"]
    ]

    return {
        "disks": disks,
        "alerts": alerts,
    }


def _get_all_disks(alert_threshold: float) -> list[dict]:
    """Get disk info for all mounts using df command."""
    try:
        result = subprocess.run(
            ["df", "-B1", "--output=source,target,size,used,avail,pcent"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr)
        return _parse_df_output(result.stdout, alert_threshold)
    except FileNotFoundError:
        # Windows fallback
        return _windows_disks(alert_threshold)


def _parse_df_output(output: str, threshold: float) -> list[dict]:
    disks = []
    for line in output.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 6:
            continue
        device, mount = parts[0], parts[1]
        # Skip pseudo filesystems
        if device.startswith(("tmpfs", "devtmpfs", "udev", "none")):
            continue
        try:
            total = int(parts[2])
            used = int(parts[3])
            free = int(parts[4])
            pct = float(parts[5].rstrip("%"))
        except (ValueError, IndexError):
            continue
        disks.append({
            "device": device,
            "mount": mount,
            "total_gb": round(total / 1e9, 2),
            "used_gb": round(used / 1e9, 2),
            "free_gb": round(free / 1e9, 2),
            "percent_used": round(pct, 1),
            "alert": pct >= threshold,
        })
    return disks


def _windows_disks(threshold: float) -> list[dict]:
    """Windows: check common drive letters."""
    import string
    disks = []
    for letter in string.ascii_uppercase:
        mount = f"{letter}:\\"
        if Path(mount).exists():
            try:
                usage = shutil.disk_usage(mount)
                pct = usage.used / usage.total * 100
                disks.append({
                    "device": mount,
                    "mount": mount,
                    "total_gb": round(usage.total / 1e9, 2),
                    "used_gb": round(usage.used / 1e9, 2),
                    "free_gb": round(usage.free / 1e9, 2),
                    "percent_used": round(pct, 1),
                    "alert": pct >= threshold,
                })
            except (PermissionError, OSError):
                pass
    return disks
