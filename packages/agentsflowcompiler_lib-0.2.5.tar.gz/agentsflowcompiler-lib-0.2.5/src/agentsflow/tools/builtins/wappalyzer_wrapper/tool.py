"""Wappalyzer wrapper — detects web technologies from HTTP headers and HTML fingerprints."""

import re
import urllib.request
import urllib.error
from typing import Any

# Technology fingerprints: (name, header_key or None, html_pattern or None, header_pattern or None)
_TECH_SIGNATURES = [
    # CMS
    ("WordPress", None, re.compile(r"wp-content|wp-includes|/wp-json/", re.I), None),
    ("Drupal", None, re.compile(r"Drupal\.settings|drupal\.js|sites/default/files", re.I), re.compile(r"X-Generator.*Drupal", re.I)),
    ("Joomla", None, re.compile(r"option=com_|/components/com_", re.I), None),
    ("Shopify", None, re.compile(r"Shopify\.theme|cdn\.shopify\.com", re.I), None),
    ("Wix", None, re.compile(r"wix\.com|_wix_", re.I), None),
    ("Squarespace", None, re.compile(r"squarespace\.com|static\.squarespace", re.I), None),
    # JS frameworks
    ("React", None, re.compile(r"react(?:\.min)?\.js|__REACT|data-reactroot", re.I), None),
    ("Vue.js", None, re.compile(r"vue(?:\.min)?\.js|data-v-", re.I), None),
    ("Angular", None, re.compile(r"ng-version|angular(?:\.min)?\.js|ng-app", re.I), None),
    ("Next.js", None, re.compile(r"__NEXT_DATA__|/_next/static/", re.I), None),
    ("Nuxt.js", None, re.compile(r"__nuxt|/_nuxt/", re.I), None),
    ("jQuery", None, re.compile(r"jquery(?:\.min)?\.js|jQuery\s*\(", re.I), None),
    # Servers
    ("Apache", "Server", None, re.compile(r"Apache", re.I)),
    ("Nginx", "Server", None, re.compile(r"nginx", re.I)),
    ("IIS", "Server", None, re.compile(r"Microsoft-IIS", re.I)),
    ("Cloudflare", "Server", None, re.compile(r"cloudflare", re.I)),
    ("LiteSpeed", "Server", None, re.compile(r"LiteSpeed", re.I)),
    # Analytics
    ("Google Analytics", None, re.compile(r"google-analytics\.com|gtag\(|ga\(", re.I), None),
    ("Google Tag Manager", None, re.compile(r"googletagmanager\.com", re.I), None),
    ("Hotjar", None, re.compile(r"hotjar\.com", re.I), None),
    # CDN / Hosting
    ("Vercel", None, re.compile(r"vercel\.app|x-vercel", re.I), re.compile(r"x-vercel", re.I)),
    ("AWS CloudFront", "Via", None, re.compile(r"CloudFront", re.I)),
    ("Fastly", "Via", None, re.compile(r"Fastly", re.I)),
    # Languages
    ("PHP", "X-Powered-By", None, re.compile(r"PHP", re.I)),
    ("ASP.NET", "X-Powered-By", None, re.compile(r"ASP\.NET", re.I)),
    ("Ruby on Rails", "X-Powered-By", None, re.compile(r"Phusion Passenger|Rails", re.I)),
]


def run(url: str) -> dict:
    """Detect technologies used by a website.

    Args:
        url: Website URL to analyze.

    Returns:
        Dictionary with detected technologies, server, and key headers.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    headers_dict, html_body = _fetch_page(url)

    technologies = []
    for name, header_key, html_pat, header_pat in _TECH_SIGNATURES:
        detected = False
        if header_key and header_pat:
            header_val = headers_dict.get(header_key, "")
            if header_pat.search(header_val):
                detected = True
        if not detected and header_pat and not header_key:
            # Check all headers
            for v in headers_dict.values():
                if header_pat.search(v):
                    detected = True
                    break
        if not detected and html_pat and html_body:
            if html_pat.search(html_body):
                detected = True
        if detected:
            technologies.append(name)

    # Extract CMS hints from meta generator tag
    cms_hints = []
    gen_match = re.search(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)["\']', html_body or "", re.I)
    if not gen_match:
        gen_match = re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']generator["\']', html_body or "", re.I)
    if gen_match:
        cms_hints.append(gen_match.group(1).strip())

    return {
        "url": url,
        "server": headers_dict.get("Server", ""),
        "powered_by": headers_dict.get("X-Powered-By", ""),
        "technologies": list(dict.fromkeys(technologies)),
        "headers": headers_dict,
        "cms_hints": cms_hints,
    }


def _fetch_page(url: str) -> tuple[dict[str, str], str]:
    """Fetch page and return (headers_dict, html_body)."""
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (compatible; agentsflow/1.0)"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            headers_dict = dict(resp.headers)
            html = resp.read(512 * 1024).decode("utf-8", errors="ignore")
        return headers_dict, html
    except urllib.error.HTTPError as e:
        return dict(e.headers), ""
    except Exception as exc:
        raise RuntimeError(f"Failed to fetch {url}: {exc}") from exc
