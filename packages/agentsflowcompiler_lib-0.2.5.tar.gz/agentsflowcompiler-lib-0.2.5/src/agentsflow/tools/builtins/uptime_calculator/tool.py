"""Uptime calculator — reports system and process uptime."""

import os
import time
from datetime import datetime, timezone


def run(pid: int = 0) -> dict:
    """Calculate system or process uptime.

    Args:
        pid: Process ID (0 = system uptime).

    Returns:
        Dictionary with uptime in seconds and human-readable format.
    """
    if pid and int(pid) > 0:
        return _process_uptime(int(pid))
    return _system_uptime()


def _system_uptime() -> dict:
    """Get system uptime."""
    try:
        import importlib
        psutil = importlib.import_module("psutil")
        boot_ts = psutil.boot_time()
        uptime_sec = time.time() - boot_ts
        load = list(psutil.getloadavg()) if hasattr(psutil, "getloadavg") else None
        boot_time = datetime.fromtimestamp(boot_ts, tz=timezone.utc).isoformat()
        return {
            "target": "system",
            "uptime_seconds": round(uptime_sec),
            "uptime_human": _format_uptime(uptime_sec),
            "boot_time": boot_time,
            "load_average": [round(l, 2) for l in load] if load else None,
        }
    except ImportError:
        pass

    # Fallback: /proc/uptime (Linux)
    try:
        with open("/proc/uptime") as f:
            uptime_sec = float(f.read().split()[0])
        boot_ts = time.time() - uptime_sec
        boot_time = datetime.fromtimestamp(boot_ts, tz=timezone.utc).isoformat()
        load_avg = None
        try:
            load_avg = [round(float(x), 2) for x in os.getloadavg()]
        except (AttributeError, OSError):
            pass
        return {
            "target": "system",
            "uptime_seconds": round(uptime_sec),
            "uptime_human": _format_uptime(uptime_sec),
            "boot_time": boot_time,
            "load_average": load_avg,
        }
    except (FileNotFoundError, IOError):
        pass

    raise RuntimeError("Cannot determine system uptime. Install psutil: pip install psutil")


def _process_uptime(pid: int) -> dict:
    """Get process uptime."""
    try:
        import importlib
        psutil = importlib.import_module("psutil")
        proc = psutil.Process(pid)
        create_ts = proc.create_time()
        uptime_sec = time.time() - create_ts
        create_time = datetime.fromtimestamp(create_ts, tz=timezone.utc).isoformat()
        return {
            "target": f"pid:{pid} ({proc.name()})",
            "uptime_seconds": round(uptime_sec),
            "uptime_human": _format_uptime(uptime_sec),
            "boot_time": create_time,
            "load_average": None,
        }
    except ImportError:
        raise ImportError("psutil is required for process uptime. Install with: pip install psutil")


def _format_uptime(seconds: float) -> str:
    """Format seconds into human-readable uptime string."""
    total = int(seconds)
    days = total // 86400
    hours = (total % 86400) // 3600
    minutes = (total % 3600) // 60
    secs = total % 60

    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)
