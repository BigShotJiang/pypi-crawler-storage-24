"""Dead link checker — finds broken links on a web page."""

import re
import urllib.request
import urllib.error
import urllib.parse


_HREF_PATTERN = re.compile(r'href=["\']([^"\'#\s][^"\']*)["\']', re.I)


def run(url: str, timeout: float = 5.0, max_links: int = 50) -> dict:
    """Scan a web page for broken links.

    Args:
        url: Page URL to scan.
        timeout: Request timeout per link in seconds.
        max_links: Maximum links to check.

    Returns:
        Dictionary with broken link details and working link count.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()
    timeout = max(1.0, min(float(timeout), 30.0))
    max_links = max(1, min(int(max_links), 200))

    html = _fetch_html(url, timeout)
    links = _extract_links(html, url, max_links)

    broken = []
    working = 0

    for link in links:
        status, error = _check_link(link, timeout)
        if status is not None and status < 400:
            working += 1
        else:
            broken.append({
                "url": link,
                "status_code": status,
                "error": error or "",
            })

    return {
        "page_url": url,
        "total_links": len(links),
        "broken": broken,
        "working": working,
    }


def _fetch_html(url: str, timeout: float) -> str:
    """Fetch page HTML."""
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (compatible; agentsflow-linkchecker/1.0)"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec B310 - URL validated to http/https scheme
            return resp.read(1024 * 1024).decode("utf-8", errors="ignore")
    except Exception as exc:
        raise RuntimeError(f"Failed to fetch {url}: {exc}") from exc


def _extract_links(html: str, base_url: str, max_links: int) -> list[str]:
    """Extract and normalize href links from HTML."""
    seen: set[str] = set()
    links: list[str] = []
    base = urllib.parse.urlparse(base_url)

    for match in _HREF_PATTERN.finditer(html):
        href = match.group(1).strip()
        if href.startswith(("mailto:", "javascript:", "tel:", "#")):
            continue
        full = urllib.parse.urljoin(base_url, href)
        parsed = urllib.parse.urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        normalized = parsed._replace(fragment="").geturl()
        if normalized not in seen:
            seen.add(normalized)
            links.append(normalized)
        if len(links) >= max_links:
            break

    return links


def _check_link(url: str, timeout: float) -> tuple[int | None, str | None]:
    """Check a single link. Returns (status_code, error_message)."""
    req = urllib.request.Request(
        url,
        method="HEAD",
        headers={"User-Agent": "Mozilla/5.0 (compatible; agentsflow-linkchecker/1.0)"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec B310 - URL validated to http/https scheme
            return resp.status, None
    except urllib.error.HTTPError as e:
        return e.code, e.reason
    except urllib.error.URLError as e:
        return None, str(e.reason)
    except Exception as e:
        return None, str(e)
