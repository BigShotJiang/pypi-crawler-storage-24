"""X.509 certificate decoder — extracts fields from SSL/TLS certificates."""

import ssl
import socket
import datetime
from pathlib import Path


def run(source: str, port: int = 443) -> dict:
    """Decode an X.509 certificate.

    Args:
        source: PEM file path, PEM string, or 'hostname:port' for live fetch.
        port: Port number for live server (default 443).

    Returns:
        Dictionary with certificate fields.
    """
    if not source or not source.strip():
        raise ValueError("source must not be empty.")

    source = source.strip()

    # Determine input type
    if source.startswith("-----BEGIN"):
        cert_der = ssl.PEM_cert_to_DER_cert(source)
        cert_dict = _parse_pem_string(source)
    elif Path(source).exists():
        pem = Path(source).read_text(encoding="utf-8")
        cert_der = ssl.PEM_cert_to_DER_cert(pem)
        cert_dict = _parse_pem_string(pem)
    else:
        # Live server fetch
        host = source.split(":")[0]
        srv_port = int(source.split(":")[1]) if ":" in source else int(port)
        cert_dict = _fetch_live_cert(host, srv_port)

    return _format_cert(cert_dict)


def _parse_pem_string(pem: str) -> dict:
    """Parse PEM certificate using stdlib ssl."""
    return ssl.PEM_cert_to_DER_cert(pem)


def _fetch_live_cert(host: str, port: int) -> dict:
    """Fetch certificate from a live server."""
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    with socket.create_connection((host, port), timeout=10) as sock:
        with context.wrap_socket(sock, server_hostname=host) as ssock:
            return ssock.getpeercert()


def _format_cert(cert: dict | bytes) -> dict:
    """Format cert dict (from getpeercert) or DER bytes."""
    # If we got DER bytes, try cryptography library
    if isinstance(cert, bytes):
        try:
            return _decode_with_cryptography(cert)
        except ImportError:
            pass
        return {"error": "cryptography library required for PEM decoding. pip install cryptography"}

    # cert is a dict from getpeercert()
    subject = dict(x[0] for x in cert.get("subject", []))
    issuer = dict(x[0] for x in cert.get("issuer", []))
    san_names = [v for t, v in cert.get("subjectAltName", []) if t == "DNS"]

    not_before_str = cert.get("notBefore", "")
    not_after_str = cert.get("notAfter", "")

    # Parse dates
    now = datetime.datetime.utcnow()
    try:
        not_after = datetime.datetime.strptime(not_after_str, "%b %d %H:%M:%S %Y %Z")
        days_until = (not_after - now).days
        is_expired = days_until < 0
    except (ValueError, AttributeError):
        days_until = 0
        is_expired = False

    return {
        "subject": subject,
        "issuer": issuer,
        "san_names": san_names,
        "not_before": not_before_str,
        "not_after": not_after_str,
        "days_until_expiry": days_until,
        "is_expired": is_expired,
        "serial_number": str(cert.get("serialNumber", "")),
        "key_algorithm": "",
        "key_size": 0,
        "signature_algorithm": "",
    }


def _decode_with_cryptography(der: bytes) -> dict:
    """Use cryptography library for full DER decode."""
    import importlib
    x509 = importlib.import_module("cryptography.x509")
    hazmat = importlib.import_module("cryptography.hazmat.primitives")

    cert = x509.load_der_x509_certificate(der)
    now = datetime.datetime.utcnow()
    not_after = cert.not_valid_after_utc.replace(tzinfo=None)
    not_before = cert.not_valid_before_utc.replace(tzinfo=None)

    # Subject/Issuer
    subject = {attr.oid._name: attr.value for attr in cert.subject}
    issuer = {attr.oid._name: attr.value for attr in cert.issuer}

    # SANs
    san_names = []
    try:
        san_ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        san_names = san_ext.value.get_values_for_type(x509.DNSName)
    except Exception:
        pass

    # Key info
    pub_key = cert.public_key()
    key_algo = type(pub_key).__name__.replace("_PublicKey", "")
    key_size = getattr(pub_key, "key_size", 0)

    days_until = (not_after - now).days

    return {
        "subject": subject,
        "issuer": issuer,
        "san_names": san_names,
        "not_before": not_before.isoformat(),
        "not_after": not_after.isoformat(),
        "days_until_expiry": days_until,
        "is_expired": days_until < 0,
        "serial_number": str(cert.serial_number),
        "key_algorithm": key_algo,
        "key_size": key_size,
        "signature_algorithm": cert.signature_hash_algorithm.name if cert.signature_hash_algorithm else "",
    }
