"""Cyclomatic complexity analyzer — measures function complexity in Python code."""

import ast
import os
from pathlib import Path


def run(file_path: str, threshold: int = 10) -> dict:
    """Analyze cyclomatic complexity of Python functions.

    Uses radon if available, falls back to AST-based analysis.

    Args:
        file_path: Python file or directory to analyze.
        threshold: Complexity score to flag as problematic.

    Returns:
        Dictionary with per-function complexity scores.
    """
    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")

    path = Path(file_path.strip()).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")

    threshold = max(1, int(threshold))
    py_files = _collect_py_files(path)

    # Try radon
    try:
        import importlib
        radon_cc = importlib.import_module("radon.complexity")
        return _analyze_with_radon(radon_cc, py_files, threshold)
    except ImportError:
        pass

    return _analyze_with_ast(py_files, threshold)


def _collect_py_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path] if path.suffix == ".py" else []
    files = []
    for dirpath, dirnames, filenames in os.walk(path):
        dirnames[:] = [d for d in dirnames if not d.startswith((".", "__"))]
        files.extend(Path(dirpath) / f for f in filenames if f.endswith(".py"))
    return files


def _analyze_with_radon(radon_cc, files: list[Path], threshold: int) -> dict:
    """Use radon library for accurate complexity analysis."""
    all_funcs = []
    for py_file in files:
        try:
            source = py_file.read_text(encoding="utf-8")
            blocks = radon_cc.cc_visit(source)
            for block in blocks:
                all_funcs.append({
                    "name": block.name,
                    "file": str(py_file),
                    "line": block.lineno,
                    "complexity": block.complexity,
                    "rank": _complexity_rank(block.complexity),
                    "flagged": block.complexity >= threshold,
                })
        except (SyntaxError, Exception):
            continue
    return _format_results(all_funcs)


def _analyze_with_ast(files: list[Path], threshold: int) -> dict:
    """Built-in AST-based complexity analysis."""
    all_funcs = []
    for py_file in files:
        try:
            source = py_file.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(py_file))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    cc = _ast_complexity(node)
                    all_funcs.append({
                        "name": node.name,
                        "file": str(py_file),
                        "line": node.lineno,
                        "complexity": cc,
                        "rank": _complexity_rank(cc),
                        "flagged": cc >= threshold,
                    })
        except (SyntaxError, Exception):
            continue
    return _format_results(all_funcs)


def _ast_complexity(node: ast.AST) -> int:
    """Calculate McCabe complexity from AST node."""
    complexity = 1
    for child in ast.walk(node):
        if isinstance(child, (
            ast.If, ast.While, ast.For, ast.ExceptHandler,
            ast.With, ast.Assert, ast.comprehension,
        )):
            complexity += 1
        elif isinstance(child, ast.BoolOp):
            complexity += len(child.values) - 1
    return complexity


def _complexity_rank(cc: int) -> str:
    if cc <= 5:
        return "A"
    if cc <= 10:
        return "B"
    if cc <= 15:
        return "C"
    if cc <= 20:
        return "D"
    if cc <= 25:
        return "E"
    return "F"


def _format_results(funcs: list[dict]) -> dict:
    funcs.sort(key=lambda f: f["complexity"], reverse=True)
    high = sum(1 for f in funcs if f["flagged"])
    avg = round(sum(f["complexity"] for f in funcs) / len(funcs), 2) if funcs else 0.0
    return {
        "functions": funcs,
        "high_complexity_count": high,
        "average_complexity": avg,
    }
