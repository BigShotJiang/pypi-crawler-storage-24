"""Bash script linter — uses ShellCheck to find shell script issues."""

import json
import subprocess
import tempfile
import os
from pathlib import Path


def run(script_path: str = "", script_content: str = "", shell: str = "bash") -> dict:
    """Lint a shell script using ShellCheck.

    Requires ShellCheck installed: sudo apt install shellcheck

    Args:
        script_path: Path to the shell script.
        script_content: Script content (alternative to script_path).
        shell: Target shell (bash/sh/dash/ksh).

    Returns:
        Dictionary with issues, counts, and overall status.
    """
    if not script_path and not script_content:
        raise ValueError("Either script_path or script_content must be provided.")

    shell = shell.strip().lower() or "bash"
    if shell not in ("bash", "sh", "dash", "ksh"):
        raise ValueError("shell must be 'bash', 'sh', 'dash', or 'ksh'.")

    tmp_file = None
    try:
        if script_content and script_content.strip():
            # Write to temp file
            tmp = tempfile.NamedTemporaryFile(
                mode="w", suffix=".sh", delete=False, encoding="utf-8"
            )
            tmp.write(script_content)
            tmp.close()
            tmp_file = tmp.name
            target = tmp_file
        else:
            target = str(Path(script_path.strip()).expanduser().resolve())
            if not Path(target).exists():
                raise FileNotFoundError(f"Script not found: {target}")

        result = subprocess.run(
            ["shellcheck", "-f", "json", "-s", shell, target],
            capture_output=True, text=True, timeout=30,
        )

        issues = _parse_shellcheck_json(result.stdout)

    except FileNotFoundError as e:
        if "shellcheck" in str(e):
            return _no_shellcheck_fallback(
                script_content or Path(script_path).read_text()
            )
        raise
    finally:
        if tmp_file and os.path.exists(tmp_file):
            os.unlink(tmp_file)

    error_count = sum(1 for i in issues if i["severity"] == "error")
    warning_count = sum(1 for i in issues if i["severity"] == "warning")
    info_count = sum(1 for i in issues if i["severity"] in ("info", "style"))

    if error_count > 0:
        status = "failed"
    elif warning_count > 0:
        status = "warnings"
    else:
        status = "passed"

    return {
        "issues": issues,
        "error_count": error_count,
        "warning_count": warning_count,
        "info_count": info_count,
        "overall_status": status,
    }


def _parse_shellcheck_json(stdout: str) -> list[dict]:
    """Parse ShellCheck JSON output."""
    if not stdout.strip():
        return []
    try:
        data = json.loads(stdout)
        issues = []
        for item in data:
            issues.append({
                "line": item.get("line", 0),
                "column": item.get("column", 0),
                "severity": item.get("level", "info"),
                "code": f"SC{item.get('code', 0)}",
                "message": item.get("message", ""),
                "fix": item.get("fix", {}).get("replacements", [{}])[0].get("replacement", "") if item.get("fix") else "",
            })
        return issues
    except (json.JSONDecodeError, KeyError):
        return []


def _no_shellcheck_fallback(content: str) -> dict:
    """Basic pattern-based linting when ShellCheck is not installed."""
    import re
    issues = []
    warnings = [
        (re.compile(r"\bls\s+-la?\b"), "Consider using 'ls -lh' for human-readable sizes (SC2012)"),
        (re.compile(r"\$\w+[^}\"']"), "Variable should be quoted: \"$VAR\" (SC2086)"),
        (re.compile(r"`[^`]+`"), "Use $() instead of backticks for command substitution (SC2006)"),
        (re.compile(r"\[\s+.*==.*\]"), "Use [[ ]] for string comparison in bash (SC2039)"),
        (re.compile(r"cd\s+\S+\s*&&"), "Use 'cd ... || exit' to handle cd failure (SC2164)"),
    ]
    for i, line in enumerate(content.splitlines(), 1):
        for pat, msg in warnings:
            if pat.search(line):
                issues.append({
                    "line": i, "column": 0, "severity": "warning",
                    "code": "SC-basic", "message": msg, "fix": "",
                })

    return {
        "issues": issues,
        "error_count": 0,
        "warning_count": len(issues),
        "info_count": 0,
        "overall_status": "warnings" if issues else "passed",
    }
