"""Weather forecast — fetches weather data from Open-Meteo (no API key needed)."""

import json
import re
import urllib.request
import urllib.parse
import urllib.error


_GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search?name={name}&count=1&format=json"
_FORECAST_URL = (
    "https://api.open-meteo.com/v1/forecast"
    "?latitude={lat}&longitude={lon}"
    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code"
    "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code"
    "&forecast_days={days}"
    "&temperature_unit={unit}"
    "&wind_speed_unit=kmh"
    "&timezone=auto"
)

_WMO_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Icy fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow",
    80: "Slight showers", 81: "Moderate showers", 82: "Violent showers",
    95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Thunderstorm with heavy hail",
}


def run(location: str, days: int = 3, units: str = "celsius") -> dict:
    """Fetch weather forecast for a location.

    Args:
        location: City name or 'lat,lon' string.
        days: Forecast days (1-7).
        units: Temperature unit ('celsius' or 'fahrenheit').

    Returns:
        Dictionary with current conditions and daily forecast.
    """
    if not location or not location.strip():
        raise ValueError("location must not be empty.")

    location = location.strip()
    days = max(1, min(int(days), 7))
    unit = "fahrenheit" if "fahrenheit" in units.lower() else "celsius"

    lat, lon, location_name = _resolve_location(location)
    data = _fetch_forecast(lat, lon, days, unit)

    current = data.get("current", {})
    cur_out = {
        "temp": current.get("temperature_2m"),
        "feels_like": current.get("apparent_temperature"),
        "humidity": current.get("relative_humidity_2m"),
        "wind_speed_kmh": current.get("wind_speed_10m"),
        "description": _WMO_CODES.get(current.get("weather_code", -1), "Unknown"),
        "unit": unit,
    }

    daily = data.get("daily", {})
    dates = daily.get("time", [])
    max_temps = daily.get("temperature_2m_max", [])
    min_temps = daily.get("temperature_2m_min", [])
    precip = daily.get("precipitation_sum", [])
    codes = daily.get("weather_code", [])

    forecast = []
    for i, date in enumerate(dates):
        forecast.append({
            "date": date,
            "max_temp": max_temps[i] if i < len(max_temps) else None,
            "min_temp": min_temps[i] if i < len(min_temps) else None,
            "precipitation_mm": precip[i] if i < len(precip) else 0,
            "description": _WMO_CODES.get(codes[i] if i < len(codes) else -1, "Unknown"),
        })

    return {
        "location": location_name,
        "current": cur_out,
        "forecast": forecast,
    }


def _resolve_location(location: str) -> tuple[float, float, str]:
    """Resolve location string to (lat, lon, name)."""
    # Check if it's already coordinates
    coord_match = re.match(r"^(-?\d+\.?\d*)\s*,\s*(-?\d+\.?\d*)$", location)
    if coord_match:
        lat, lon = float(coord_match.group(1)), float(coord_match.group(2))
        return lat, lon, location

    # Geocode the city name
    url = _GEOCODING_URL.format(name=urllib.parse.quote(location))
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
        data = json.loads(resp.read().decode("utf-8"))

    results = data.get("results", [])
    if not results:
        raise ValueError(f"Location '{location}' not found.")

    r = results[0]
    country = r.get("country", "")
    name = f"{r.get('name', location)}, {country}" if country else r.get("name", location)
    return r["latitude"], r["longitude"], name


def _fetch_forecast(lat: float, lon: float, days: int, unit: str) -> dict:
    url = _FORECAST_URL.format(lat=lat, lon=lon, days=days, unit=unit)
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
        return json.loads(resp.read().decode("utf-8"))
