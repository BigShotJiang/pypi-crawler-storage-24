"""Currency converter — converts amounts using live exchange rates."""

import json
import urllib.request
import urllib.error


_API_URL = "https://open.er-api.com/v6/latest/{base}"


def run(amount: float, from_currency: str, to_currency: str) -> dict:
    """Convert an amount between currencies.

    Uses open.er-api.com (free, no API key required).

    Args:
        amount: Amount to convert.
        from_currency: Source currency code (e.g. 'USD').
        to_currency: Target currency code(s), comma-separated.

    Returns:
        Dictionary with conversion results and rate date.
    """
    if amount is None:
        raise ValueError("amount must not be None.")
    if not from_currency or not from_currency.strip():
        raise ValueError("from_currency must not be empty.")
    if not to_currency or not to_currency.strip():
        raise ValueError("to_currency must not be empty.")

    from_code = from_currency.strip().upper()
    to_codes = [c.strip().upper() for c in to_currency.split(",") if c.strip()]
    amount = float(amount)

    url = _API_URL.format(base=from_code)
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Exchange rate API error {e.code}: {e.reason}") from e

    if data.get("result") != "success":
        raise RuntimeError(f"Exchange rate API failed: {data.get('error-type', 'unknown')}")

    rates = data.get("rates", {})
    rate_date = data.get("time_last_update_utc", "")

    conversions = []
    for code in to_codes:
        rate = rates.get(code)
        if rate is None:
            conversions.append({
                "currency": code,
                "rate": None,
                "converted_amount": None,
            })
        else:
            conversions.append({
                "currency": code,
                "rate": rate,
                "converted_amount": round(amount * rate, 4),
            })

    return {
        "amount": amount,
        "from": from_code,
        "conversions": conversions,
        "rate_date": rate_date,
    }
