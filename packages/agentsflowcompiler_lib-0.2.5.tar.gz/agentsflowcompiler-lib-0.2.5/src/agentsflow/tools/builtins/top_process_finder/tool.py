"""Top process finder — identifies highest CPU/memory-consuming processes."""

import subprocess


def run(sort_by: str = "cpu", limit: int = 10) -> dict:
    """Find top processes by resource usage.

    Uses psutil if available, falls back to ps command.

    Args:
        sort_by: Sort by 'cpu' or 'memory'.
        limit: Number of processes to return.

    Returns:
        Dictionary with top process list.
    """
    metric = sort_by.strip().lower() or "cpu"
    if metric not in ("cpu", "memory"):
        raise ValueError("sort_by must be 'cpu' or 'memory'.")

    limit = max(1, min(int(limit), 50))

    try:
        import importlib
        psutil = importlib.import_module("psutil")
        return _psutil_top(psutil, metric, limit)
    except ImportError:
        pass

    return _cli_top(metric, limit)


def _psutil_top(psutil, metric: str, limit: int) -> dict:
    """Get top processes using psutil."""
    procs = []
    total_cpu = psutil.cpu_percent(interval=0.5)

    for proc in psutil.process_iter(["pid", "name", "username", "status", "cmdline",
                                      "cpu_percent", "memory_info", "memory_percent"]):
        try:
            info = proc.info
            mem_mb = info["memory_info"].rss / 1e6 if info.get("memory_info") else 0
            procs.append({
                "pid": info["pid"],
                "name": info["name"] or "",
                "cpu_percent": info.get("cpu_percent", 0.0) or 0.0,
                "memory_mb": round(mem_mb, 2),
                "memory_percent": round(info.get("memory_percent", 0.0) or 0.0, 2),
                "username": info.get("username", ""),
                "status": info.get("status", ""),
                "cmdline": " ".join(info.get("cmdline") or [])[:150],
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    key = "cpu_percent" if metric == "cpu" else "memory_mb"
    procs.sort(key=lambda p: p[key], reverse=True)
    procs = procs[:limit]

    vm = psutil.virtual_memory()
    total_mem_gb = round(vm.total / 1e9, 2)

    return {
        "sort_by": metric,
        "processes": procs,
        "total_cpu_percent": total_cpu,
        "total_memory_gb": total_mem_gb,
    }


def _cli_top(metric: str, limit: int) -> dict:
    """Get top processes using ps aux."""
    try:
        sort_flag = "--sort=-%cpu" if metric == "cpu" else "--sort=-%mem"
        result = subprocess.run(
            ["ps", "aux", sort_flag, f"--lines={limit + 1}"],
            capture_output=True, text=True, timeout=10,
        )
        procs = []
        for line in result.stdout.splitlines()[1:limit + 1]:
            parts = line.split(None, 10)
            if len(parts) >= 11:
                try:
                    procs.append({
                        "pid": int(parts[1]),
                        "name": parts[10].split()[0].split("/")[-1],
                        "cpu_percent": float(parts[2]),
                        "memory_mb": float(parts[5]) / 1024,
                        "memory_percent": float(parts[3]),
                        "username": parts[0],
                        "status": parts[7],
                        "cmdline": parts[10][:150],
                    })
                except (ValueError, IndexError):
                    continue
    except Exception:
        procs = []

    return {
        "sort_by": metric,
        "processes": procs,
        "total_cpu_percent": 0.0,
        "total_memory_gb": 0.0,
    }
