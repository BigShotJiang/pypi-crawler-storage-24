"""CVE search tool — queries NIST NVD for known vulnerabilities."""

import json
import urllib.request
import urllib.parse
import urllib.error


_NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"


def run(product: str, version: str = "", max_results: int = 10) -> dict:
    """Search NVD for CVEs related to a product.

    Args:
        product: Product name (e.g. 'openssl', 'log4j').
        version: Optional version to narrow results.
        max_results: Maximum CVEs to return (default 10).

    Returns:
        Dictionary with matching CVEs and their severity/score.
    """
    if not product or not product.strip():
        raise ValueError("product must not be empty.")

    product = product.strip()
    max_results = max(1, min(int(max_results), 50))

    keyword = product
    if version and version.strip():
        keyword = f"{product} {version.strip()}"

    params = urllib.parse.urlencode({
        "keywordSearch": keyword,
        "resultsPerPage": max_results,
    })
    url = f"{_NVD_API}?{params}"

    req = urllib.request.Request(url, headers={
        "User-Agent": "agentsflow/1.0",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"NVD API error {e.code}: {e.reason}") from e

    total = data.get("totalResults", 0)
    cves = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        cve_id = cve.get("id", "")
        descriptions = cve.get("descriptions", [])
        desc = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")

        # Extract CVSS score
        metrics = cve.get("metrics", {})
        score, severity = _extract_cvss(metrics)

        published = cve.get("published", "")[:10]
        refs = [r.get("url", "") for r in cve.get("references", [])[:3]]

        cves.append({
            "cve_id": cve_id,
            "description": desc[:300],
            "severity": severity,
            "cvss_score": score,
            "published": published,
            "references": refs,
        })

    return {
        "product": product,
        "version": version,
        "total_found": total,
        "cves": cves,
    }


def _extract_cvss(metrics: dict) -> tuple[float | None, str]:
    """Extract CVSS score and severity from metrics dict."""
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        entries = metrics.get(key, [])
        if entries:
            data = entries[0].get("cvssData", {})
            score = data.get("baseScore")
            severity = data.get("baseSeverity") or _score_to_severity(score)
            return score, severity
    return None, "UNKNOWN"


def _score_to_severity(score: float | None) -> str:
    if score is None:
        return "UNKNOWN"
    if score >= 9.0:
        return "CRITICAL"
    if score >= 7.0:
        return "HIGH"
    if score >= 4.0:
        return "MEDIUM"
    return "LOW"
