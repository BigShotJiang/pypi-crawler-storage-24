"""Zipped file explorer — lists archive contents without extraction."""

import fnmatch
import tarfile
import zipfile
from datetime import datetime
from pathlib import Path


def run(archive_path: str, filter_pattern: str = "") -> dict:
    """List contents of a ZIP or TAR archive.

    Args:
        archive_path: Path to archive file.
        filter_pattern: Glob pattern to filter entries.

    Returns:
        Dictionary with archive format and entry list.
    """
    if not archive_path or not archive_path.strip():
        raise ValueError("archive_path must not be empty.")

    path = Path(archive_path.strip()).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"Archive not found: {path}")

    suffix = "".join(path.suffixes).lower()

    if suffix in (".zip",):
        return _list_zip(path, filter_pattern)
    elif suffix in (".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz", ".gz"):
        return _list_tar(path, filter_pattern)
    else:
        raise ValueError(f"Unsupported archive format: {suffix}")


def _list_zip(path: Path, pattern: str) -> dict:
    """List ZIP archive contents."""
    entries = []
    total_size = 0

    with zipfile.ZipFile(str(path), "r") as zf:
        for info in zf.infolist():
            name = info.filename
            if pattern and not fnmatch.fnmatch(name, pattern):
                continue
            date_str = datetime(*info.date_time).isoformat() if info.date_time else ""
            is_dir = name.endswith("/")
            entries.append({
                "name": name,
                "size": info.file_size,
                "compressed_size": info.compress_size,
                "date": date_str,
                "is_dir": is_dir,
            })
            if not is_dir:
                total_size += info.file_size

    return {
        "archive": str(path),
        "format": "zip",
        "total_files": sum(1 for e in entries if not e["is_dir"]),
        "total_size_bytes": total_size,
        "entries": entries,
    }


def _list_tar(path: Path, pattern: str) -> dict:
    """List TAR archive contents."""
    entries = []
    total_size = 0
    fmt = _detect_tar_format(path)

    with tarfile.open(str(path), "r:*") as tf:
        for member in tf.getmembers():
            name = member.name
            if pattern and not fnmatch.fnmatch(name, pattern):
                continue
            date_str = datetime.utcfromtimestamp(member.mtime).isoformat() if member.mtime else ""
            entries.append({
                "name": name,
                "size": member.size,
                "compressed_size": 0,  # TAR doesn't store per-file compressed size
                "date": date_str,
                "is_dir": member.isdir(),
            })
            if not member.isdir():
                total_size += member.size

    return {
        "archive": str(path),
        "format": fmt,
        "total_files": sum(1 for e in entries if not e["is_dir"]),
        "total_size_bytes": total_size,
        "entries": entries,
    }


def _detect_tar_format(path: Path) -> str:
    suffix = "".join(path.suffixes).lower()
    if ".gz" in suffix or ".tgz" in suffix:
        return "tar.gz"
    if ".bz2" in suffix:
        return "tar.bz2"
    if ".xz" in suffix:
        return "tar.xz"
    return "tar"
