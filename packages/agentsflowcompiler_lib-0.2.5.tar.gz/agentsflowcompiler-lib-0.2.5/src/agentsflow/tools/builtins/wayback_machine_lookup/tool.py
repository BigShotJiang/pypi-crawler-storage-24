"""Wayback Machine lookup — retrieves archived page snapshots from Internet Archive."""

import json
import urllib.request
import urllib.parse
import urllib.error


_CDX_API = "https://web.archive.org/cdx/search/cdx"
_WAYBACK_BASE = "https://web.archive.org/web"


def run(url: str, limit: int = 10, from_year: int = 0) -> dict:
    """Fetch archived snapshots from the Wayback Machine.

    Args:
        url: URL to look up.
        limit: Max snapshots to return.
        from_year: Filter from this year onwards (0 = no filter).

    Returns:
        Dictionary with snapshot list including timestamps and archive URLs.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()
    limit = max(1, min(int(limit), 100))

    params: dict[str, str] = {
        "url": url,
        "output": "json",
        "fl": "timestamp,statuscode",
        "limit": str(limit),
        "collapse": "timestamp:8",  # one per day
        "filter": "statuscode:200",
    }
    if from_year and int(from_year) > 1990:
        params["from"] = f"{int(from_year)}0101000000"

    query = urllib.parse.urlencode(params)
    api_url = f"{_CDX_API}?{query}"

    req = urllib.request.Request(api_url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            rows = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Wayback API error {e.code}: {e.reason}") from e

    # First row is header
    if not rows or len(rows) < 2:
        return {
            "url": url,
            "total_snapshots": 0,
            "snapshots": [],
            "oldest": "",
            "newest": "",
        }

    data_rows = rows[1:]
    snapshots = []
    for row in data_rows:
        timestamp = row[0] if len(row) > 0 else ""
        status = row[1] if len(row) > 1 else ""
        wayback_url = f"{_WAYBACK_BASE}/{timestamp}/{url}"
        snapshots.append({
            "timestamp": _format_timestamp(timestamp),
            "wayback_url": wayback_url,
            "status_code": status,
        })

    return {
        "url": url,
        "total_snapshots": len(snapshots),
        "snapshots": snapshots,
        "oldest": snapshots[-1]["timestamp"] if snapshots else "",
        "newest": snapshots[0]["timestamp"] if snapshots else "",
    }


def _format_timestamp(ts: str) -> str:
    """Convert Wayback timestamp (YYYYMMDDHHmmss) to readable format."""
    if len(ts) >= 14:
        return f"{ts[:4]}-{ts[4:6]}-{ts[6:8]} {ts[8:10]}:{ts[10:12]}:{ts[12:14]}"
    return ts
