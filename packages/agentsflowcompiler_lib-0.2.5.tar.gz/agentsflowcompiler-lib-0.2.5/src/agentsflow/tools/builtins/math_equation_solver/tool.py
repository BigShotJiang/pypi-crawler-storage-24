"""Math equation solver — evaluates expressions and solves equations."""

import math
import re


def run(expression: str, variable: str = "x") -> dict:
    """Solve or evaluate a mathematical expression.

    Uses sympy for symbolic math if available, otherwise safe eval.

    Args:
        expression: Math expression or equation (e.g. 'x**2 - 5*x + 6 = 0').
        variable: Variable to solve for (used when '=' is present).

    Returns:
        Dictionary with result and optional numeric value.
    """
    if not expression or not expression.strip():
        raise ValueError("expression must not be empty.")

    expr = expression.strip()
    var = variable.strip() or "x"

    # Try sympy
    try:
        import importlib
        sympy = importlib.import_module("sympy")
        return _solve_sympy(sympy, expr, var)
    except ImportError:
        pass

    # Fallback: safe eval for pure expressions
    return _safe_eval(expr)


def _solve_sympy(sympy, expr: str, var_name: str) -> dict:
    """Use sympy for symbolic solving."""
    x = sympy.Symbol(var_name)

    if "=" in expr:
        # Equation solving
        lhs_str, rhs_str = expr.split("=", 1)
        lhs = sympy.sympify(lhs_str.strip())
        rhs = sympy.sympify(rhs_str.strip())
        equation = sympy.Eq(lhs, rhs)
        solutions = sympy.solve(equation, x)

        result_str = ", ".join(str(s) for s in solutions)
        numeric = None
        try:
            if len(solutions) == 1:
                numeric = float(solutions[0].evalf())
        except Exception:
            pass

        return {
            "expression": expr,
            "result": f"{var_name} = {result_str}" if solutions else "No solution",
            "numeric_result": numeric,
            "steps": [f"Equation: {equation}", f"Solutions: {solutions}"],
            "engine": "sympy",
        }
    else:
        # Expression evaluation
        parsed = sympy.sympify(expr)
        simplified = sympy.simplify(parsed)
        numeric = None
        try:
            numeric = float(simplified.evalf())
        except Exception:
            pass

        return {
            "expression": expr,
            "result": str(simplified),
            "numeric_result": numeric,
            "steps": [f"Simplified: {simplified}"],
            "engine": "sympy",
        }


# Safe math namespace for eval
_SAFE_MATH_NS = {
    "__builtins__": {},
    "abs": abs, "round": round, "min": min, "max": max, "sum": sum,
    "pow": pow, "int": int, "float": float,
    **{k: getattr(math, k) for k in dir(math) if not k.startswith("_")},
}


def _safe_eval(expr: str) -> dict:
    """Evaluate a safe math expression using restricted eval."""
    # Block dangerous patterns
    if re.search(r"(__|\bimport\b|\bexec\b|\beval\b|\bopen\b|\bos\b)", expr):
        raise ValueError("Expression contains disallowed operations.")

    try:
        result = eval(expr, _SAFE_MATH_NS)  # noqa: S307  # nosec B307 - restricted namespace, dangerous builtins blocked
        numeric = float(result) if isinstance(result, (int, float)) else None
        return {
            "expression": expr,
            "result": str(result),
            "numeric_result": numeric,
            "steps": [],
            "engine": "builtin_eval",
        }
    except Exception as exc:
        raise ValueError(f"Cannot evaluate expression: {exc}") from exc
