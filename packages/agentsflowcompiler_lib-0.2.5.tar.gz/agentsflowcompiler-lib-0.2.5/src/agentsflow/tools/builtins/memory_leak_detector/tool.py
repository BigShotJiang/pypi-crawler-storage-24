"""Memory leak detector — monitors process memory growth over time."""

import time
from datetime import datetime, timezone


def run(pid: int, samples: int = 3, interval_seconds: float = 2.0) -> dict:
    """Monitor process memory usage to detect leaks.

    Requires: pip install psutil

    Args:
        pid: Process ID to monitor.
        samples: Number of samples to collect.
        interval_seconds: Delay between samples.

    Returns:
        Dictionary with memory snapshots and growth analysis.
    """
    try:
        import importlib
        psutil = importlib.import_module("psutil")
    except ImportError:
        raise ImportError("psutil is required. Install with: pip install psutil")

    pid = int(pid)
    samples = max(2, min(int(samples), 20))
    interval = max(0.5, min(float(interval_seconds), 60.0))

    try:
        proc = psutil.Process(pid)
        proc_name = proc.name()
    except psutil.NoSuchProcess:
        raise ValueError(f"No process found with PID {pid}.")

    memory_samples = []
    for i in range(samples):
        try:
            mem = proc.memory_info()
            memory_samples.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "rss_mb": round(mem.rss / 1e6, 2),
                "vms_mb": round(mem.vms / 1e6, 2),
            })
        except psutil.NoSuchProcess:
            break
        if i < samples - 1:
            time.sleep(interval)

    if len(memory_samples) < 2:
        return {
            "pid": pid,
            "process_name": proc_name,
            "samples": memory_samples,
            "growth_mb": 0.0,
            "growth_percent": 0.0,
            "leak_suspected": False,
        }

    first_rss = memory_samples[0]["rss_mb"]
    last_rss = memory_samples[-1]["rss_mb"]
    growth_mb = round(last_rss - first_rss, 2)
    growth_pct = round((growth_mb / first_rss * 100) if first_rss > 0 else 0, 2)

    # Check if memory is consistently growing
    rss_values = [s["rss_mb"] for s in memory_samples]
    consistently_growing = all(
        rss_values[i] <= rss_values[i + 1]
        for i in range(len(rss_values) - 1)
    )
    leak_suspected = consistently_growing and growth_pct >= 1.0

    return {
        "pid": pid,
        "process_name": proc_name,
        "samples": memory_samples,
        "growth_mb": growth_mb,
        "growth_percent": growth_pct,
        "leak_suspected": leak_suspected,
    }
