"""SQL schema explorer — inspects database structure using SQLAlchemy or sqlite3."""

import fnmatch
import re


def run(connection_string: str, table_filter: str = "") -> dict:
    """Retrieve the schema of a database.

    Supports SQLite natively. SQLAlchemy required for PostgreSQL/MySQL.

    Args:
        connection_string: DB connection URL.
        table_filter: Optional table name glob filter (e.g. 'user*').

    Returns:
        Dictionary with table schemas, columns, and foreign keys.
    """
    if not connection_string or not connection_string.strip():
        raise ValueError("connection_string must not be empty.")

    cs = connection_string.strip()

    if cs.startswith("sqlite:///") or cs.startswith("sqlite://"):
        return _explore_sqlite(cs, table_filter)
    else:
        return _explore_sqlalchemy(cs, table_filter)


def _explore_sqlite(cs: str, table_filter: str) -> dict:
    """Explore SQLite database using stdlib sqlite3."""
    import sqlite3

    db_path = cs.replace("sqlite:///", "").replace("sqlite://", "")
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        all_tables = [row[0] for row in cursor.fetchall()]

        tables = []
        for table_name in all_tables:
            if table_filter and not fnmatch.fnmatch(table_name.lower(), table_filter.lower()):
                continue

            cursor.execute(f"PRAGMA table_info(\"{table_name}\")")
            col_rows = cursor.fetchall()
            columns = [
                {
                    "name": row[1],
                    "type": row[2],
                    "nullable": not row[3],
                    "primary_key": bool(row[5]),
                }
                for row in col_rows
            ]

            cursor.execute(f"PRAGMA foreign_key_list(\"{table_name}\")")
            fk_rows = cursor.fetchall()
            foreign_keys = [
                {
                    "column": row[3],
                    "ref_table": row[2],
                    "ref_column": row[4],
                }
                for row in fk_rows
            ]

            tables.append({
                "name": table_name,
                "columns": columns,
                "foreign_keys": foreign_keys,
            })
    finally:
        conn.close()

    return {
        "database_type": "sqlite",
        "tables": tables,
        "table_count": len(tables),
    }


def _explore_sqlalchemy(cs: str, table_filter: str) -> dict:
    """Explore database using SQLAlchemy reflection."""
    try:
        import importlib
        sa = importlib.import_module("sqlalchemy")
    except ImportError:
        raise ImportError("sqlalchemy is required for non-SQLite databases. Install with: pip install sqlalchemy")

    db_type = cs.split(":")[0].split("+")[0]

    engine = sa.create_engine(cs)
    insp = sa.inspect(engine)
    all_tables = insp.get_table_names()

    tables = []
    for table_name in all_tables:
        if table_filter and not fnmatch.fnmatch(table_name.lower(), table_filter.lower()):
            continue

        cols = insp.get_columns(table_name)
        pk_constraint = insp.get_pk_constraint(table_name)
        pk_cols = set(pk_constraint.get("constrained_columns", []))

        columns = [
            {
                "name": col["name"],
                "type": str(col["type"]),
                "nullable": col.get("nullable", True),
                "primary_key": col["name"] in pk_cols,
            }
            for col in cols
        ]

        fks = insp.get_foreign_keys(table_name)
        foreign_keys = [
            {
                "column": fk["constrained_columns"][0] if fk["constrained_columns"] else "",
                "ref_table": fk["referred_table"],
                "ref_column": fk["referred_columns"][0] if fk["referred_columns"] else "",
            }
            for fk in fks
        ]

        tables.append({
            "name": table_name,
            "columns": columns,
            "foreign_keys": foreign_keys,
        })

    engine.dispose()
    return {
        "database_type": db_type,
        "tables": tables,
        "table_count": len(tables),
    }
