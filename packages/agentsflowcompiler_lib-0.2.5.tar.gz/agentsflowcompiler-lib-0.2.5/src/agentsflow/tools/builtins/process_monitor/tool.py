"""Process monitor — checks if processes are running and reports resource usage."""

import subprocess


def run(process_name: str) -> dict:
    """Find running processes by name.

    Uses psutil if available, otherwise falls back to ps/tasklist CLI.

    Args:
        process_name: Process name to search for (partial match).

    Returns:
        Dictionary with found processes and their resource usage.
    """
    if not process_name or not process_name.strip():
        raise ValueError("process_name must not be empty.")

    name = process_name.strip().lower()

    # Try psutil
    try:
        import importlib
        psutil = importlib.import_module("psutil")
        return _psutil_find(psutil, name)
    except ImportError:
        pass

    # Fallback: CLI
    return _cli_find(name)


def _psutil_find(psutil, name: str) -> dict:
    instances = []
    for proc in psutil.process_iter(["pid", "name", "status", "username", "cmdline", "cpu_percent", "memory_info"]):
        try:
            info = proc.info
            if name in (info.get("name") or "").lower():
                mem_mb = info["memory_info"].rss / 1e6 if info.get("memory_info") else 0
                cmdline = " ".join(info.get("cmdline") or [])[:200]
                instances.append({
                    "pid": info["pid"],
                    "name": info["name"],
                    "status": info["status"],
                    "cpu_percent": info.get("cpu_percent", 0.0),
                    "memory_mb": round(mem_mb, 2),
                    "username": info.get("username", ""),
                    "cmdline": cmdline,
                })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return {
        "process_name": name,
        "found": len(instances) > 0,
        "instances": instances,
        "count": len(instances),
    }


def _cli_find(name: str) -> dict:
    """Fallback using ps aux / tasklist."""
    import platform
    instances = []
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["tasklist", "/FO", "CSV", "/NH"],
                capture_output=True, text=True, timeout=10,
            )
            for line in result.stdout.splitlines():
                parts = line.strip('"').split('","')
                if len(parts) >= 2 and name in parts[0].lower():
                    instances.append({
                        "pid": int(parts[1]) if parts[1].isdigit() else 0,
                        "name": parts[0],
                        "status": "running",
                        "cpu_percent": 0.0,
                        "memory_mb": 0.0,
                        "username": "",
                        "cmdline": "",
                    })
        else:
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True, text=True, timeout=10,
            )
            for line in result.stdout.splitlines()[1:]:
                parts = line.split(None, 10)
                if len(parts) >= 11 and name in parts[10].lower():
                    try:
                        instances.append({
                            "pid": int(parts[1]),
                            "name": parts[10].split()[0].split("/")[-1],
                            "status": "running",
                            "cpu_percent": float(parts[2]),
                            "memory_mb": float(parts[5]) / 1024,
                            "username": parts[0],
                            "cmdline": parts[10][:200],
                        })
                    except (ValueError, IndexError):
                        continue
    except Exception:
        pass

    return {
        "process_name": name,
        "found": len(instances) > 0,
        "instances": instances,
        "count": len(instances),
    }
