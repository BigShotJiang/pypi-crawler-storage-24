"""Keyword density analyzer — measures word frequency and density for SEO."""

import re
from collections import Counter


_STOP_WORDS = {
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "was", "are", "were", "be", "been",
    "has", "have", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "not", "no", "nor", "so",
    "yet", "both", "either", "neither", "whether", "if", "then", "than",
    "that", "this", "these", "those", "it", "its", "it's", "they", "them",
    "their", "there", "here", "when", "where", "how", "what", "which",
    "who", "whom", "whose", "why", "i", "you", "he", "she", "we",
    "me", "him", "her", "us", "your", "my", "his", "our",
}


def run(
    text: str,
    top_n: int = 20,
    min_word_length: int = 3,
    focus_keyword: str = "",
) -> dict:
    """Analyze keyword frequency and density.

    Args:
        text: Text to analyze.
        top_n: Number of top keywords to return.
        min_word_length: Minimum word length.
        focus_keyword: Specific keyword to check density for.

    Returns:
        Dictionary with keyword statistics.
    """
    if not text or not text.strip():
        raise ValueError("text must not be empty.")

    top_n = max(1, min(int(top_n), 100))
    min_len = max(1, int(min_word_length))

    # Extract words
    words = re.findall(r"\b[a-zA-Z]+\b", text.lower())
    total_words = len(words)

    if total_words == 0:
        return {
            "total_words": 0,
            "unique_words": 0,
            "top_keywords": [],
            "focus_keyword_density": None,
            "reading_time_minutes": 0,
        }

    # Filter and count
    filtered = [w for w in words if len(w) >= min_len and w not in _STOP_WORDS]
    counter = Counter(filtered)
    unique_words = len(set(words))

    # Top keywords
    top_keywords = [
        {
            "word": word,
            "count": count,
            "density_percent": round(count / total_words * 100, 2),
        }
        for word, count in counter.most_common(top_n)
    ]

    # Focus keyword density
    focus_density = None
    if focus_keyword and focus_keyword.strip():
        fk = focus_keyword.strip().lower()
        fk_count = sum(1 for w in words if w == fk or text.lower().count(fk) > 0)
        # Exact phrase count
        phrase_count = len(re.findall(re.escape(fk), text.lower()))
        phrase_words = len(fk.split())
        focus_density = round(phrase_count * phrase_words / total_words * 100, 2)

    # Reading time (avg 200 words/min)
    reading_time = round(total_words / 200, 1)

    return {
        "total_words": total_words,
        "unique_words": unique_words,
        "top_keywords": top_keywords,
        "focus_keyword_density": focus_density,
        "reading_time_minutes": reading_time,
    }
