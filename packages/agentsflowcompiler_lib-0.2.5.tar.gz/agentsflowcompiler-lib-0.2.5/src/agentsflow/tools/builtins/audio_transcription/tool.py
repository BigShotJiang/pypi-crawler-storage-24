"""Audio transcription — converts audio files to text using OpenAI Whisper."""

from pathlib import Path


def run(file_path: str, model_size: str = "base", language: str = "") -> dict:
    """Transcribe an audio file to text using Whisper.

    Requires: pip install openai-whisper

    Args:
        file_path: Path to audio file.
        model_size: Whisper model size (tiny/base/small/medium/large).
        language: Language hint (ISO code, empty = auto-detect).

    Returns:
        Dictionary with transcript text, detected language, and duration.
    """
    try:
        import importlib
        whisper = importlib.import_module("whisper")
    except ImportError:
        raise ImportError("openai-whisper is required. Install with: pip install openai-whisper")

    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")

    path = Path(file_path.strip()).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    valid_sizes = {"tiny", "base", "small", "medium", "large", "large-v2", "large-v3"}
    model_size = model_size.strip().lower() or "base"
    if model_size not in valid_sizes:
        raise ValueError(f"Invalid model_size '{model_size}'. Choose from: {sorted(valid_sizes)}")

    model = whisper.load_model(model_size)

    transcribe_kwargs: dict = {}
    if language and language.strip():
        transcribe_kwargs["language"] = language.strip()

    result = model.transcribe(str(path), **transcribe_kwargs)

    text = result.get("text", "").strip()
    detected_lang = result.get("language", "")
    segments = result.get("segments", [])
    duration = segments[-1]["end"] if segments else 0.0

    return {
        "file": str(path),
        "text": text,
        "language": detected_lang,
        "duration_seconds": round(duration, 2),
        "word_count": len(text.split()),
    }
