"""Crypto wallet balance checker — reads ETH/BTC balances from public APIs."""

import json
import re
import urllib.request
import urllib.error


def run(address: str, network: str = "") -> dict:
    """Check cryptocurrency wallet balance.

    Args:
        address: Wallet address.
        network: 'eth' or 'btc' (auto-detected if empty).

    Returns:
        Dictionary with balance and USD value.
    """
    if not address or not address.strip():
        raise ValueError("address must not be empty.")

    addr = address.strip()
    net = network.strip().lower() or _detect_network(addr)

    if net == "eth":
        return _eth_balance(addr)
    elif net == "btc":
        return _btc_balance(addr)
    else:
        raise ValueError(f"Cannot detect network for address '{addr}'. Specify 'eth' or 'btc'.")


def _detect_network(addr: str) -> str:
    if addr.startswith("0x") and len(addr) == 42:
        return "eth"
    if re.match(r"^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$", addr) or addr.startswith("bc1"):
        return "btc"
    return "unknown"


def _eth_balance(address: str) -> dict:
    """Get ETH balance via Etherscan-compatible free API."""
    url = f"https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest&apikey=YourApiKeyToken"
    # Use free API without key (rate-limited)
    url_no_key = f"https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest"
    req = urllib.request.Request(url_no_key, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        # Fallback to CloudFlare Ethereum RPC
        return _eth_balance_rpc(address)

    if data.get("status") == "1":
        wei = int(data.get("result", "0"))
        eth = wei / 1e18
    else:
        return _eth_balance_rpc(address)

    usd = _get_eth_usd_price(eth)
    return {
        "address": address,
        "network": "eth",
        "balance": round(eth, 8),
        "balance_usd": usd,
        "symbol": "ETH",
        "unit": "ether",
    }


def _eth_balance_rpc(address: str) -> dict:
    """Get ETH balance via public JSON-RPC."""
    payload = json.dumps({
        "jsonrpc": "2.0", "method": "eth_getBalance",
        "params": [address, "latest"], "id": 1,
    }).encode()
    req = urllib.request.Request(
        "https://cloudflare-eth.com",
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "agentsflow/1.0"},
    )
    with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
        data = json.loads(resp.read().decode("utf-8"))
    hex_val = data.get("result", "0x0")
    wei = int(hex_val, 16)
    eth = wei / 1e18
    usd = _get_eth_usd_price(eth)
    return {
        "address": address, "network": "eth",
        "balance": round(eth, 8), "balance_usd": usd,
        "symbol": "ETH", "unit": "ether",
    }


def _btc_balance(address: str) -> dict:
    """Get BTC balance via blockstream.info API."""
    url = f"https://blockstream.info/api/address/{address}"
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
        data = json.loads(resp.read().decode("utf-8"))

    chain = data.get("chain_stats", {})
    funded = chain.get("funded_txo_sum", 0)
    spent = chain.get("spent_txo_sum", 0)
    satoshis = funded - spent
    btc = satoshis / 1e8

    usd = _get_btc_usd_price(btc)
    return {
        "address": address, "network": "btc",
        "balance": round(btc, 8), "balance_usd": usd,
        "symbol": "BTC", "unit": "bitcoin",
    }


def _get_eth_usd_price(amount: float) -> float | None:
    """Get ETH price in USD."""
    try:
        req = urllib.request.Request(
            "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd",
            headers={"User-Agent": "agentsflow/1.0"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:  # nosec B310 - URL validated to http/https scheme
            price = json.loads(resp.read())["ethereum"]["usd"]
        return round(amount * price, 2)
    except Exception:
        return None


def _get_btc_usd_price(amount: float) -> float | None:
    try:
        req = urllib.request.Request(
            "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd",
            headers={"User-Agent": "agentsflow/1.0"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:  # nosec B310 - URL validated to http/https scheme
            price = json.loads(resp.read())["bitcoin"]["usd"]
        return round(amount * price, 2)
    except Exception:
        return None
