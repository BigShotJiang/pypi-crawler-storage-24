"""Sitemap parser — extracts all URLs from a sitemap.xml file."""

import urllib.request
import urllib.parse
import urllib.error
try:
    import defusedxml.ElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET  # nosec B405 - defusedxml not installed, input is sitemap XML


_NS = {
    "sm": "http://www.sitemaps.org/schemas/sitemap/0.9",
    "news": "http://www.google.com/schemas/sitemap-news/0.9",
    "image": "http://www.google.com/schemas/sitemap-image/1.1",
}


def run(url: str, max_urls: int = 100) -> dict:
    """Fetch and parse a sitemap.xml file.

    Args:
        url: Sitemap URL or domain (auto-discovers /sitemap.xml).
        max_urls: Maximum URLs to return.

    Returns:
        Dictionary with URL list and metadata.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()
    max_urls = max(1, min(int(max_urls), 2000))

    # Auto-discover if given a plain domain
    if not url.endswith(".xml") and "/sitemap" not in url:
        base = url.rstrip("/")
        if not base.startswith("http"):
            base = "https://" + base
        url = base + "/sitemap.xml"

    xml_content = _fetch_xml(url)
    root = ET.fromstring(xml_content)  # nosec B314

    # Handle sitemap index (sitemapindex)
    tag = root.tag.lower()
    all_urls = []

    if "sitemapindex" in tag:
        # Recursively fetch child sitemaps (up to 5)
        child_locs = [
            _text(el, "loc") for el in root
            if _text(el, "loc")
        ][:5]
        for child_url in child_locs:
            try:
                child_xml = _fetch_xml(child_url)
                child_root = ET.fromstring(child_xml)  # nosec B314
                all_urls.extend(_parse_urlset(child_root))
                if len(all_urls) >= max_urls:
                    break
            except Exception:
                continue
    else:
        all_urls = _parse_urlset(root)

    trimmed = all_urls[:max_urls]
    return {
        "sitemap_url": url,
        "total_urls": len(all_urls),
        "urls": trimmed,
    }


def _parse_urlset(root: ET.Element) -> list[dict]:
    """Parse a <urlset> element into a list of URL dicts."""
    urls = []
    for url_el in root:
        loc = _text(url_el, "loc")
        if not loc:
            continue
        urls.append({
            "loc": loc,
            "lastmod": _text(url_el, "lastmod") or "",
            "changefreq": _text(url_el, "changefreq") or "",
            "priority": _text(url_el, "priority") or "",
        })
    return urls


def _text(parent: ET.Element, tag: str) -> str | None:
    """Get text of a child element, trying both namespaced and plain."""
    for prefix, ns in _NS.items():
        el = parent.find(f"{{{ns}}}{tag}")
        if el is not None and el.text:
            return el.text.strip()
    el = parent.find(tag)
    return el.text.strip() if el is not None and el.text else None


def _fetch_xml(url: str) -> str:
    """Fetch XML content from URL."""
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            return resp.read(10 * 1024 * 1024).decode("utf-8", errors="ignore")
    except Exception as exc:
        raise RuntimeError(f"Failed to fetch sitemap at {url}: {exc}") from exc
