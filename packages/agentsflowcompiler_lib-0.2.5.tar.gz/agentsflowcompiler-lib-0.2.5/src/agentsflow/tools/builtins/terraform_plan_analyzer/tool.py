"""Terraform plan analyzer — summarizes infrastructure changes from a plan JSON."""

import json
from pathlib import Path


_ACTION_LABELS = {
    "create": "add",
    "update": "change",
    "delete": "destroy",
    "no-op": "no-op",
    "replace": "replace (destroy+create)",
    "read": "read",
}


def run(plan_file: str = "", plan_json: str = "") -> dict:
    """Parse and summarize a Terraform plan.

    Args:
        plan_file: Path to terraform plan JSON file.
        plan_json: Terraform plan JSON as a string.

    Returns:
        Dictionary with change counts, change list, and warnings.
    """
    if not plan_file and not plan_json:
        raise ValueError("Either plan_file or plan_json must be provided.")

    # Load JSON
    if plan_json and plan_json.strip():
        try:
            plan = json.loads(plan_json.strip())
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid plan JSON: {exc}") from exc
    else:
        path = Path(plan_file.strip()).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Plan file not found: {path}")
        plan = json.loads(path.read_text(encoding="utf-8"))

    # Parse resource changes
    resource_changes = plan.get("resource_changes", [])
    changes = []
    to_add = to_change = to_destroy = 0
    warnings = []

    for rc in resource_changes:
        change = rc.get("change", {})
        actions = change.get("actions", [])

        if actions == ["no-op"]:
            continue

        resource_type = rc.get("type", "")
        name = rc.get("name", "")
        provider = rc.get("provider_name", "").split("/")[-1]
        address = rc.get("address", f"{resource_type}.{name}")

        # Determine primary action
        if "create" in actions and "delete" in actions:
            action = "replace"
            to_destroy += 1
            to_add += 1
        elif "create" in actions:
            action = "create"
            to_add += 1
        elif "delete" in actions:
            action = "delete"
            to_destroy += 1
        elif "update" in actions:
            action = "update"
            to_change += 1
        else:
            action = "+".join(actions)

        # Check for sensitive changes
        before_sensitive = change.get("before_sensitive", {})
        after_sensitive = change.get("after_sensitive", {})
        if before_sensitive or after_sensitive:
            warnings.append(f"Sensitive values involved in: {address}")

        changes.append({
            "action": _ACTION_LABELS.get(action, action),
            "type": resource_type,
            "name": name,
            "address": address,
            "provider": provider,
        })

    # Outputs
    output_changes = plan.get("output_changes", {})
    output_count = len(output_changes)

    summary = (
        f"Plan: {to_add} to add, {to_change} to change, {to_destroy} to destroy"
        + (f", {output_count} output(s) affected" if output_count else "")
    )

    return {
        "summary": summary,
        "to_add": to_add,
        "to_change": to_change,
        "to_destroy": to_destroy,
        "changes": changes,
        "warnings": warnings,
    }
