"""Redis key explorer — searches, retrieves, and manages Redis keys."""


def run(
    action: str,
    pattern: str = "*",
    key: str = "",
    redis_url: str = "redis://localhost:6379/0",
) -> dict:
    """Explore and manage Redis keys.

    Requires: pip install redis

    Args:
        action: 'search', 'get', 'delete', or 'info'.
        pattern: Key pattern for search/delete.
        key: Specific key for 'get'.
        redis_url: Redis connection URL.

    Returns:
        Action-specific results dictionary.
    """
    try:
        import importlib
        redis_module = importlib.import_module("redis")
    except ImportError:
        raise ImportError("redis is required. Install with: pip install redis")

    if not action or not action.strip():
        raise ValueError("action must not be empty.")

    action = action.strip().lower()
    valid_actions = ("search", "get", "delete", "info")
    if action not in valid_actions:
        raise ValueError(f"action must be one of {valid_actions}.")

    client = redis_module.from_url(redis_url or "redis://localhost:6379/0", decode_responses=True)

    try:
        if action == "search":
            keys = client.keys(pattern or "*")
            return {"keys": sorted(keys), "count": len(keys)}

        elif action == "get":
            if not key:
                raise ValueError("key is required for 'get' action.")
            key_type = client.type(key)
            ttl = client.ttl(key)
            value = _get_value(client, key, key_type)
            return {"key": key, "value": value, "type": key_type, "ttl": ttl}

        elif action == "delete":
            keys = client.keys(pattern or "*")
            if keys:
                deleted = client.delete(*keys)
            else:
                deleted = 0
            return {"deleted_count": deleted, "keys_deleted": list(keys)}

        elif action == "info":
            info = client.info()
            return {
                "server_info": {
                    "redis_version": info.get("redis_version"),
                    "uptime_seconds": info.get("uptime_in_seconds"),
                    "connected_clients": info.get("connected_clients"),
                    "used_memory_human": info.get("used_memory_human"),
                    "total_keys": sum(
                        info.get(f"db{i}", {}).get("keys", 0)
                        for i in range(16)
                        if f"db{i}" in info
                    ),
                }
            }
    finally:
        client.close()


def _get_value(client, key: str, key_type: str) -> object:
    """Get value based on key type."""
    if key_type == "string":
        return client.get(key)
    elif key_type == "list":
        return client.lrange(key, 0, 99)  # first 100
    elif key_type == "set":
        return list(client.smembers(key))
    elif key_type == "hash":
        return client.hgetall(key)
    elif key_type == "zset":
        return client.zrange(key, 0, 99, withscores=True)
    return None
