"""Twitter/X thread formatter — splits long text into properly sized tweets."""

import re


def run(text: str, max_chars: int = 280, add_numbering: bool = True) -> dict:
    """Format a long text as a Twitter/X thread.

    Args:
        text: Text to split into tweets.
        max_chars: Max characters per tweet (Twitter limit: 280).
        add_numbering: Add '1/' numbering prefix to each tweet.

    Returns:
        Dictionary with tweet list and statistics.
    """
    if not text or not text.strip():
        raise ValueError("text must not be empty.")

    max_chars = max(50, min(int(max_chars), 280))
    content = text.strip()

    # Reserve space for numbering (e.g., "1/ " = 4 chars max for 99+ tweets)
    numbering_reserve = 5 if add_numbering else 0
    effective_max = max_chars - numbering_reserve

    # Split into sentences first, then chunk
    sentences = _split_sentences(content)
    chunks = _chunk_sentences(sentences, effective_max)

    # Add numbering
    tweets = []
    for i, chunk in enumerate(chunks, 1):
        if add_numbering:
            tweet = f"{i}/ {chunk}"
        else:
            tweet = chunk
        tweets.append(tweet)

    return {
        "tweets": tweets,
        "tweet_count": len(tweets),
        "total_chars": sum(len(t) for t in tweets),
    }


def _split_sentences(text: str) -> list[str]:
    """Split text into sentences, preserving paragraph breaks."""
    # Split on sentence-ending punctuation
    parts = re.split(r"(?<=[.!?])\s+", text)
    return [p.strip() for p in parts if p.strip()]


def _chunk_sentences(sentences: list[str], max_len: int) -> list[str]:
    """Pack sentences into tweet-sized chunks."""
    chunks = []
    current = ""

    for sentence in sentences:
        # If a single sentence is too long, split it by words
        if len(sentence) > max_len:
            sub_chunks = _split_by_words(sentence, max_len)
            for sub in sub_chunks:
                if current and len(current) + 1 + len(sub) > max_len:
                    chunks.append(current.strip())
                    current = sub
                elif current:
                    current += " " + sub
                else:
                    current = sub
        elif current and len(current) + 1 + len(sentence) > max_len:
            chunks.append(current.strip())
            current = sentence
        elif current:
            current += " " + sentence
        else:
            current = sentence

    if current:
        chunks.append(current.strip())

    return chunks


def _split_by_words(text: str, max_len: int) -> list[str]:
    """Split a long string into word-boundary chunks."""
    words = text.split()
    chunks = []
    current = ""
    for word in words:
        if current and len(current) + 1 + len(word) > max_len:
            chunks.append(current)
            current = word
        elif current:
            current += " " + word
        else:
            current = word
    if current:
        chunks.append(current)
    return chunks
