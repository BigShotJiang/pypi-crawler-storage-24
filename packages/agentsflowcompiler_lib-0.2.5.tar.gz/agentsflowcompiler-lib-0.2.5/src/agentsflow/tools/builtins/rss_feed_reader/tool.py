"""RSS feed reader — fetches and parses RSS/Atom feeds using stdlib only."""

import re
import urllib.request
import urllib.error
try:
    import defusedxml.ElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET  # nosec B405 - defusedxml not installed, input is fetched RSS/Atom feed


_NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "dc": "http://purl.org/dc/elements/1.1/",
    "content": "http://purl.org/rss/1.0/modules/content/",
}
_TAG_STRIP = re.compile(r"<[^>]+>")


def run(feed_url: str, max_items: int = 10) -> dict:
    """Fetch and parse an RSS or Atom feed.

    Args:
        feed_url: URL of the feed.
        max_items: Maximum items to return.

    Returns:
        Dictionary with feed title and latest items.
    """
    if not feed_url or not feed_url.strip():
        raise ValueError("feed_url must not be empty.")

    feed_url = feed_url.strip()
    max_items = max(1, min(int(max_items), 100))

    xml_content = _fetch_feed(feed_url)
    root = ET.fromstring(xml_content)  # nosec B314

    # Detect Atom vs RSS
    if "atom" in root.tag.lower() or root.tag == f"{{{_NS['atom']}}}feed":
        return _parse_atom(root, feed_url, max_items)
    else:
        return _parse_rss(root, feed_url, max_items)


def _parse_rss(root: ET.Element, feed_url: str, max_items: int) -> dict:
    """Parse RSS 2.0 format."""
    channel = root.find("channel") or root
    feed_title = _text(channel, "title") or feed_url

    items = []
    for item in channel.findall("item")[:max_items]:
        title = _text(item, "title") or ""
        link = _text(item, "link") or ""
        pub_date = _text(item, "pubDate") or _ns_text(item, "dc", "date") or ""
        description = _text(item, "description") or _ns_text(item, "content", "encoded") or ""
        items.append({
            "title": title,
            "link": link,
            "published": pub_date,
            "summary": _strip_html(description)[:300],
        })

    return {
        "feed_title": feed_title,
        "feed_url": feed_url,
        "items": items,
        "total_items": len(items),
    }


def _parse_atom(root: ET.Element, feed_url: str, max_items: int) -> dict:
    """Parse Atom 1.0 format."""
    ns = _NS["atom"]
    title_el = root.find(f"{{{ns}}}title")
    feed_title = (title_el.text or "").strip() if title_el is not None else feed_url

    items = []
    for entry in root.findall(f"{{{ns}}}entry")[:max_items]:
        title_el = entry.find(f"{{{ns}}}title")
        title = (title_el.text or "").strip() if title_el is not None else ""

        link_el = entry.find(f"{{{ns}}}link")
        link = link_el.get("href", "") if link_el is not None else ""

        updated_el = entry.find(f"{{{ns}}}updated") or entry.find(f"{{{ns}}}published")
        published = (updated_el.text or "").strip() if updated_el is not None else ""

        summary_el = entry.find(f"{{{ns}}}summary") or entry.find(f"{{{ns}}}content")
        summary = (summary_el.text or "").strip() if summary_el is not None else ""

        items.append({
            "title": title,
            "link": link,
            "published": published,
            "summary": _strip_html(summary)[:300],
        })

    return {
        "feed_title": feed_title,
        "feed_url": feed_url,
        "items": items,
        "total_items": len(items),
    }


def _text(parent: ET.Element, tag: str) -> str | None:
    el = parent.find(tag)
    return el.text.strip() if el is not None and el.text else None


def _ns_text(parent: ET.Element, ns_key: str, tag: str) -> str | None:
    el = parent.find(f"{{{_NS[ns_key]}}}{tag}")
    return el.text.strip() if el is not None and el.text else None


def _strip_html(text: str) -> str:
    return _TAG_STRIP.sub("", text).strip()


def _fetch_feed(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            return resp.read(5 * 1024 * 1024).decode("utf-8", errors="ignore")
    except Exception as exc:
        raise RuntimeError(f"Failed to fetch feed at {url}: {exc}") from exc
