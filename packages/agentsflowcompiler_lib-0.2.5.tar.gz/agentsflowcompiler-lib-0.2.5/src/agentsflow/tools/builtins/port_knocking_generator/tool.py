"""Port knocking generator — creates knock sequences and client commands."""

import random
import secrets


def run(
    action: str,
    sequence: str = "",
    target_host: str = "target.host",
    protocol: str = "tcp",
    ports_to_open: str = "22",
) -> dict:
    """Generate a port knocking configuration or client commands.

    Args:
        action: 'generate' (new random sequence) or 'command' (knock commands).
        sequence: Comma-separated sequence for 'command' action.
        target_host: Target host for knock commands.
        protocol: 'tcp' or 'udp'.
        ports_to_open: Ports opened after successful knock.

    Returns:
        Dictionary with sequence, shell commands, and knockd config.
    """
    if not action or not action.strip():
        raise ValueError("action must not be empty.")

    action = action.strip().lower()
    if action not in ("generate", "command"):
        raise ValueError("action must be 'generate' or 'command'.")

    proto = protocol.strip().lower() or "tcp"
    if proto not in ("tcp", "udp"):
        raise ValueError("protocol must be 'tcp' or 'udp'.")

    host = target_host.strip() or "target.host"
    open_ports = [p.strip() for p in ports_to_open.split(",") if p.strip()]

    if action == "generate":
        seq = _generate_sequence()
    else:
        if not sequence or not sequence.strip():
            raise ValueError("sequence is required for 'command' action.")
        seq = _parse_sequence(sequence)

    commands = _build_commands(seq, host, proto)
    knockd_config = _build_knockd_config(seq, open_ports, proto)

    return {
        "sequence": seq,
        "commands": commands,
        "knockd_config": knockd_config,
        "notes": (
            "Install knockd on server: sudo apt install knockd. "
            "For clients: use 'knock' tool or nmap. "
            "FOR AUTHORIZED USE ON YOUR OWN INFRASTRUCTURE ONLY."
        ),
    }


def _generate_sequence(length: int = 4) -> list[int]:
    """Generate a cryptographically random knock sequence."""
    # Use high-numbered ports to avoid conflicts
    used = set()
    seq = []
    while len(seq) < length:
        port = secrets.randbelow(55535) + 10000  # 10000-65534
        if port not in used:
            used.add(port)
            seq.append(port)
    return seq


def _parse_sequence(seq_str: str) -> list[int]:
    """Parse comma-separated port sequence."""
    ports = []
    for p in seq_str.split(","):
        p = p.strip()
        try:
            port = int(p)
            if not (1 <= port <= 65535):
                raise ValueError(f"Port {port} out of range.")
            ports.append(port)
        except ValueError as exc:
            raise ValueError(f"Invalid port in sequence: '{p}'") from exc
    if not ports:
        raise ValueError("Sequence must contain at least one port.")
    return ports


def _build_commands(seq: list[int], host: str, proto: str) -> list[str]:
    """Build client commands for the knock sequence."""
    commands = []

    # knock tool
    port_args = " ".join(f"{p}:{proto}" for p in seq)
    commands.append(f"knock {host} {port_args}")

    # nmap alternative
    nmap_cmds = []
    for p in seq:
        if proto == "tcp":
            nmap_cmds.append(f"nmap -Pn --host-timeout 100ms -p {p} {host}")
        else:
            nmap_cmds.append(f"nmap -Pn -sU --host-timeout 100ms -p {p} {host}")
    commands.append("# Or with nmap (one by one):")
    commands.extend(nmap_cmds)

    return commands


def _build_knockd_config(seq: list[int], open_ports: list[str], proto: str) -> str:
    """Generate a knockd.conf snippet."""
    port_list = ",".join(f"{p}:{proto}" for p in seq)
    open_cmd = " && ".join(
        f"iptables -A INPUT -s %IP% -p tcp --dport {p} -j ACCEPT"
        for p in open_ports
    )
    close_cmd = " && ".join(
        f"iptables -D INPUT -s %IP% -p tcp --dport {p} -j ACCEPT"
        for p in open_ports
    )

    return f"""[openSSH]
    sequence    = {port_list}
    seq_timeout = 5
    command     = {open_cmd}
    tcpflags    = syn

[closeSSH]
    sequence    = {",".join(f"{p}:{proto}" for p in reversed(seq))}
    seq_timeout = 5
    command     = {close_cmd}
    tcpflags    = syn
"""
