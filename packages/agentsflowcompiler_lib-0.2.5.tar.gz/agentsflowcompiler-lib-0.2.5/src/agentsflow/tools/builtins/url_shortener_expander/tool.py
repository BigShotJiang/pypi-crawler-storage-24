"""URL shortener/expander — resolves shortened URLs or creates TinyURLs."""

import urllib.request
import urllib.parse
import urllib.error


def run(url: str, action: str = "expand") -> dict:
    """Expand or shorten a URL.

    Args:
        url: URL to process.
        action: 'expand' (follow redirects) or 'shorten' (TinyURL).

    Returns:
        Dictionary with original URL, final URL, and redirect chain.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    action = action.strip().lower() or "expand"
    if action not in ("expand", "shorten"):
        raise ValueError("action must be 'expand' or 'shorten'.")

    if action == "expand":
        return _expand_url(url)
    else:
        return _shorten_url(url)


def _expand_url(url: str) -> dict:
    """Follow all redirects and return the final destination."""
    redirect_chain = [url]
    current = url
    max_redirects = 15

    for _ in range(max_redirects):
        req = urllib.request.Request(
            current,
            method="HEAD",
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; agentsflow/1.0)",
            },
        )
        opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler())
        # Don't follow redirects automatically — we track them
        no_redirect = urllib.request.build_opener(
            _NoRedirectHandler()
        )
        try:
            resp = no_redirect.open(req, timeout=10)
            # No redirect — this is the final URL
            break
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308):
                location = e.headers.get("Location", "")
                if not location:
                    break
                # Resolve relative redirects
                next_url = urllib.parse.urljoin(current, location)
                if next_url == current:
                    break
                redirect_chain.append(next_url)
                current = next_url
            else:
                break
        except Exception:
            break

    return {
        "original_url": url,
        "final_url": current,
        "redirect_chain": redirect_chain,
        "action": "expand",
    }


def _shorten_url(url: str) -> dict:
    """Create a TinyURL shortened link."""
    api_url = f"https://tinyurl.com/api-create.php?url={urllib.parse.quote(url)}"
    req = urllib.request.Request(api_url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            short_url = resp.read().decode("utf-8").strip()
    except Exception as exc:
        raise RuntimeError(f"TinyURL API failed: {exc}") from exc

    return {
        "original_url": url,
        "final_url": short_url,
        "redirect_chain": [url, short_url],
        "action": "shorten",
    }


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """HTTP handler that raises HTTPError instead of following redirects."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, msg, headers, fp)
