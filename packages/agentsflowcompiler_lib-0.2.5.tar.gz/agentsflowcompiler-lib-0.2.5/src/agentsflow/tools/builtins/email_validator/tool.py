"""Email validator — checks format, MX records, and disposable domains."""

import re
import socket


_EMAIL_PATTERN = re.compile(
    r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+"
    r"@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?"
    r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*"
    r"\.[a-zA-Z]{2,}$"
)

# Common disposable email domains
_DISPOSABLE_DOMAINS = {
    "mailinator.com", "guerrillamail.com", "throwam.com", "trashmail.com",
    "yopmail.com", "dispostable.com", "sharklasers.com", "guerrillamailblock.com",
    "grr.la", "guerrillamail.info", "guerrillamail.biz", "guerrillamail.de",
    "guerrillamail.net", "guerrillamail.org", "spam4.me", "tempmail.com",
    "10minutemail.com", "10minutemail.net", "temp-mail.org", "fakeinbox.com",
    "maildrop.cc", "mailnull.com", "spamgourmet.com", "discard.email",
    "mailnesia.com", "mailscrap.com", "spamotron.com", "trashmail.me",
}


def run(email: str, check_mx: bool = True) -> dict:
    """Validate an email address.

    Args:
        email: Email to validate.
        check_mx: Whether to check for valid MX records.

    Returns:
        Dictionary with validation results and issues.
    """
    if not email or not email.strip():
        raise ValueError("email must not be empty.")

    email = email.strip()
    issues = []

    # Format check
    format_valid = bool(_EMAIL_PATTERN.match(email))
    if not format_valid:
        issues.append("Invalid email format")

    # Split parts
    if "@" in email:
        local_part, domain = email.rsplit("@", 1)
    else:
        local_part, domain = email, ""
        issues.append("Missing @ symbol")

    # Length checks
    if len(email) > 254:
        issues.append("Email too long (max 254 chars)")
        format_valid = False
    if len(local_part) > 64:
        issues.append("Local part too long (max 64 chars)")
        format_valid = False

    # Disposable domain check
    is_disposable = domain.lower() in _DISPOSABLE_DOMAINS
    if is_disposable:
        issues.append(f"Disposable email domain: {domain}")

    # MX record check
    mx_valid = None
    if check_mx and domain and format_valid:
        mx_valid = _check_mx(domain)
        if not mx_valid:
            issues.append(f"No MX records found for domain: {domain}")

    valid = format_valid and not is_disposable and (mx_valid is not False)

    return {
        "email": email,
        "valid": valid,
        "format_valid": format_valid,
        "mx_valid": mx_valid,
        "is_disposable": is_disposable,
        "domain": domain,
        "local_part": local_part,
        "issues": issues,
    }


def _check_mx(domain: str) -> bool:
    """Check if domain has MX records via DNS query."""
    try:
        # Try using dnspython
        import importlib
        dns = importlib.import_module("dns.resolver")
        dns.resolve(domain, "MX")
        return True
    except ImportError:
        pass
    except Exception:
        return False

    # Fallback: try socket lookup (checks A record as proxy)
    try:
        socket.getaddrinfo(domain, None)
        return True
    except socket.gaierror:
        return False
