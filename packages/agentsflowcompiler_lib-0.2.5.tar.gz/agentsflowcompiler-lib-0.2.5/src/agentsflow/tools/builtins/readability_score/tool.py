"""Readability score calculator — Flesch-Kincaid, Gunning Fog, SMOG metrics."""

import re
import math


def run(text: str) -> dict:
    """Calculate readability metrics for text.

    Implements Flesch Reading Ease, Flesch-Kincaid Grade Level,
    Gunning Fog Index, and SMOG Index.

    Args:
        text: Text to analyze.

    Returns:
        Dictionary with readability scores and grade level.
    """
    if not text or not text.strip():
        raise ValueError("text must not be empty.")

    # Tokenize
    sentences = _count_sentences(text)
    words = re.findall(r"\b[a-zA-Z']+\b", text)
    word_count = len(words)

    if sentences == 0 or word_count == 0:
        return {
            "flesch_reading_ease": 0.0,
            "flesch_kincaid_grade": 0.0,
            "gunning_fog": 0.0,
            "smog_index": 0.0,
            "avg_sentence_length": 0.0,
            "avg_syllables_per_word": 0.0,
            "grade_level": "Unknown",
        }

    syllable_counts = [_count_syllables(w) for w in words]
    total_syllables = sum(syllable_counts)
    complex_words = sum(1 for c in syllable_counts if c >= 3)

    avg_sentence_len = word_count / sentences
    avg_syllables = total_syllables / word_count

    # Flesch Reading Ease
    flesch_re = 206.835 - 1.015 * avg_sentence_len - 84.6 * avg_syllables
    flesch_re = round(max(0.0, min(100.0, flesch_re)), 1)

    # Flesch-Kincaid Grade Level
    fk_grade = 0.39 * avg_sentence_len + 11.8 * avg_syllables - 15.59
    fk_grade = round(max(0.0, fk_grade), 1)

    # Gunning Fog Index
    fog = 0.4 * (avg_sentence_len + 100 * complex_words / word_count)
    fog = round(fog, 1)

    # SMOG Index
    smog = 3.1291 + 1.0430 * math.sqrt(complex_words * (30 / sentences))
    smog = round(smog, 1)

    return {
        "flesch_reading_ease": flesch_re,
        "flesch_kincaid_grade": fk_grade,
        "gunning_fog": fog,
        "smog_index": smog,
        "avg_sentence_length": round(avg_sentence_len, 1),
        "avg_syllables_per_word": round(avg_syllables, 2),
        "grade_level": _flesch_to_grade(flesch_re),
    }


def _count_sentences(text: str) -> int:
    """Count sentences in text."""
    sentences = re.split(r"[.!?]+", text)
    return max(1, len([s for s in sentences if s.strip()]))


def _count_syllables(word: str) -> int:
    """Count syllables in a word (simplified CMU dict approach)."""
    word = word.lower().strip("'")
    if len(word) <= 3:
        return 1

    # Count vowel groups
    count = len(re.findall(r"[aeiouy]+", word))

    # Subtract silent e at end
    if word.endswith("e") and count > 1:
        count -= 1

    return max(1, count)


def _flesch_to_grade(score: float) -> str:
    """Convert Flesch score to reading grade description."""
    if score >= 90:
        return "5th Grade (Very Easy)"
    if score >= 80:
        return "6th Grade (Easy)"
    if score >= 70:
        return "7th Grade (Fairly Easy)"
    if score >= 60:
        return "8th-9th Grade (Standard)"
    if score >= 50:
        return "10th-12th Grade (Fairly Difficult)"
    if score >= 30:
        return "College Level (Difficult)"
    return "College Graduate (Very Difficult)"
