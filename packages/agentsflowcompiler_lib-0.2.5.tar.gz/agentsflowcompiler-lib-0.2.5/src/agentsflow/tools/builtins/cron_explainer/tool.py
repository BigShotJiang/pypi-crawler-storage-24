"""Cron expression explainer — translates cron syntax to plain English."""

import re
from datetime import datetime, timedelta


_WEEKDAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
_MONTH_NAMES = [
    "", "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]


def run(expression: str, next_runs: int = 5) -> dict:
    """Explain a cron expression and calculate upcoming run times.

    Args:
        expression: 5-field cron expression (minute hour day month weekday).
        next_runs: Number of upcoming run times to calculate.

    Returns:
        Dictionary with explanation and next scheduled run times.
    """
    if not expression or not expression.strip():
        raise ValueError("expression must not be empty.")

    expr = expression.strip()
    next_runs = max(1, min(int(next_runs), 20))

    # Try croniter first
    try:
        import importlib
        croniter = importlib.import_module("croniter")
        return _explain_with_croniter(croniter, expr, next_runs)
    except ImportError:
        pass

    # Built-in explanation and next-run calculator
    parts = expr.split()
    if len(parts) != 5:
        raise ValueError(f"Expected 5 fields in cron expression, got {len(parts)}: '{expr}'")

    minute, hour, day, month, weekday = parts
    explanation = _build_explanation(minute, hour, day, month, weekday)
    frequency = _estimate_frequency(minute, hour)
    scheduled = _compute_next_runs(parts, next_runs)

    return {
        "expression": expr,
        "explanation": explanation,
        "next_runs": scheduled,
        "frequency": frequency,
    }


def _explain_with_croniter(croniter, expr: str, n: int) -> dict:
    now = datetime.now()
    cron = croniter.croniter(expr, now)
    next_run_times = [cron.get_next(datetime).isoformat() for _ in range(n)]
    # Build explanation from parts
    parts = expr.split()
    explanation = _build_explanation(*parts) if len(parts) == 5 else expr
    return {
        "expression": expr,
        "explanation": explanation,
        "next_runs": next_run_times,
        "frequency": _estimate_frequency(parts[0], parts[1]) if len(parts) == 5 else "",
    }


def _build_explanation(minute: str, hour: str, day: str, month: str, weekday: str) -> str:
    parts = []

    # Minute
    if minute == "*":
        parts.append("every minute")
    elif minute.startswith("*/"):
        parts.append(f"every {minute[2:]} minutes")
    elif "," in minute:
        parts.append(f"at minutes {minute}")
    elif "-" in minute:
        parts.append(f"every minute from {minute}")
    else:
        parts.append(f"at minute {minute}")

    # Hour
    if hour == "*":
        if minute == "*":
            pass  # already covered
        else:
            parts.append("of every hour")
    elif hour.startswith("*/"):
        parts.append(f"every {hour[2:]} hours")
    elif "," in hour:
        parts.append(f"at hours {hour}")
    else:
        parts.append(f"at {_fmt_hour(hour)}")

    # Day
    if day != "*":
        if day.startswith("*/"):
            parts.append(f"every {day[2:]} days")
        else:
            parts.append(f"on day {day} of the month")

    # Month
    if month != "*":
        try:
            parts.append(f"in {_MONTH_NAMES[int(month)]}")
        except (ValueError, IndexError):
            parts.append(f"in month(s) {month}")

    # Weekday
    if weekday != "*":
        try:
            parts.append(f"on {_WEEKDAY_NAMES[int(weekday) % 7]}")
        except (ValueError, IndexError):
            parts.append(f"on weekday(s) {weekday}")

    return "Runs " + ", ".join(parts) if parts else "Every minute"


def _fmt_hour(h: str) -> str:
    try:
        hour_int = int(h)
        suffix = "AM" if hour_int < 12 else "PM"
        h12 = hour_int % 12 or 12
        return f"{h12}:00 {suffix}"
    except ValueError:
        return f"hour {h}"


def _estimate_frequency(minute: str, hour: str) -> str:
    if minute.startswith("*/"):
        try:
            n = int(minute[2:])
            return f"Every {n} minutes"
        except ValueError:
            pass
    if minute == "*":
        return "Every minute"
    if hour.startswith("*/"):
        try:
            n = int(hour[2:])
            return f"Every {n} hours"
        except ValueError:
            pass
    if hour == "*":
        return "Every hour"
    return "Daily"


def _compute_next_runs(parts: list[str], n: int) -> list[str]:
    """Simple next-run calculator (no external deps)."""
    now = datetime.now().replace(second=0, microsecond=0) + timedelta(minutes=1)
    results = []
    candidate = now
    max_iters = 60 * 24 * 366  # up to a year

    for _ in range(max_iters):
        if len(results) >= n:
            break
        if _matches_cron(candidate, parts):
            results.append(candidate.isoformat())
        candidate += timedelta(minutes=1)

    return results


def _matches_cron(dt: datetime, parts: list[str]) -> bool:
    minute, hour, day, month, weekday = parts
    checks = [
        _field_matches(dt.minute, minute, 0, 59),
        _field_matches(dt.hour, hour, 0, 23),
        _field_matches(dt.day, day, 1, 31),
        _field_matches(dt.month, month, 1, 12),
        _field_matches(dt.weekday() + 1, weekday, 0, 7),  # 0=Sun,1=Mon...
    ]
    return all(checks)


def _field_matches(value: int, field: str, min_val: int, max_val: int) -> bool:
    if field == "*":
        return True
    allowed = _expand_field(field, min_val, max_val)
    return value in allowed


def _expand_field(field: str, min_val: int, max_val: int) -> set:
    result = set()
    for part in field.split(","):
        if part == "*":
            result.update(range(min_val, max_val + 1))
        elif "/" in part:
            range_part, step = part.split("/", 1)
            step = int(step)
            if range_part == "*":
                start, end = min_val, max_val
            elif "-" in range_part:
                start, end = map(int, range_part.split("-"))
            else:
                start = int(range_part)
                end = max_val
            result.update(range(start, end + 1, step))
        elif "-" in part:
            start, end = map(int, part.split("-"))
            result.update(range(start, end + 1))
        else:
            result.add(int(part))
    return result
