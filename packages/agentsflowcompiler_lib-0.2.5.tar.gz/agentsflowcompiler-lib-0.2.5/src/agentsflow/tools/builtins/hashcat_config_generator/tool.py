"""Hashcat/John config generator — identifies hash types and builds cracking commands.

This tool is intended for authorized penetration testing and security research only.
"""

import re


# Hash type signatures: (name, hashcat_mode, john_format, length, pattern)
_HASH_TYPES = [
    ("MD5", 0, "raw-md5", 32, re.compile(r"^[a-fA-F0-9]{32}$")),
    ("SHA-1", 100, "raw-sha1", 40, re.compile(r"^[a-fA-F0-9]{40}$")),
    ("SHA-256", 1400, "raw-sha256", 64, re.compile(r"^[a-fA-F0-9]{64}$")),
    ("SHA-512", 1700, "raw-sha512", 128, re.compile(r"^[a-fA-F0-9]{128}$")),
    ("NTLM", 1000, "nt", 32, re.compile(r"^[a-fA-F0-9]{32}$")),
    ("bcrypt", 3200, "bcrypt", None, re.compile(r"^\$2[ayb]\$\d{2}\$.{53}$")),
    ("MD5crypt", 500, "md5crypt", None, re.compile(r"^\$1\$[./a-zA-Z0-9]{1,8}\$[./a-zA-Z0-9]{22}$")),
    ("SHA-512crypt", 1800, "sha512crypt", None, re.compile(r"^\$6\$.{8,16}\$.+")),
    ("SHA-256crypt", 7400, "sha256crypt", None, re.compile(r"^\$5\$.{8,16}\$.+")),
    ("LM", 3000, "lm", 32, re.compile(r"^[a-fA-F0-9]{32}$")),
    ("WPA-PBKDF2", 2500, "wpapsk", None, None),
    ("MySQL 4.1", 300, "mysql-sha1", 41, re.compile(r"^\*[a-fA-F0-9]{40}$")),
    ("MD5(WordPress)", 400, "phpass", None, re.compile(r"^\$P\$[./a-zA-Z0-9]{31}$")),
]


def run(
    hash_value: str,
    wordlist: str = "/usr/share/wordlists/rockyou.txt",
    tool: str = "hashcat",
) -> dict:
    """Generate a hash cracking command for authorized testing.

    Args:
        hash_value: Hash string to identify.
        wordlist: Path to wordlist file.
        tool: 'hashcat' or 'john'.

    Returns:
        Dictionary with detected hash types and cracking commands.
    """
    if not hash_value or not hash_value.strip():
        raise ValueError("hash_value must not be empty.")

    h = hash_value.strip()
    wl = wordlist.strip() or "/usr/share/wordlists/rockyou.txt"
    tool_name = tool.strip().lower() or "hashcat"

    if tool_name not in ("hashcat", "john"):
        raise ValueError("tool must be 'hashcat' or 'john'.")

    detected = _detect_hash_types(h)
    commands = []

    if tool_name == "hashcat":
        for t in detected:
            mode = t["hashcat_mode"]
            if mode is not None:
                commands.append(f"hashcat -m {mode} -a 0 {h} {wl}")
                commands.append(f"hashcat -m {mode} -a 3 {h} ?a?a?a?a?a?a?a?a")
    else:
        for t in detected:
            fmt = t["john_format"]
            if fmt:
                commands.append(f"john --format={fmt} --wordlist={wl} hash.txt")
            else:
                commands.append(f"john --wordlist={wl} hash.txt")

    return {
        "hash_value": h,
        "detected_types": detected,
        "commands": commands,
        "notes": (
            "FOR AUTHORIZED SECURITY TESTING ONLY. "
            "Always have explicit written permission before running cracking tools."
        ),
    }


def _detect_hash_types(h: str) -> list[dict]:
    """Match a hash string against known patterns."""
    matches = []
    for name, hc_mode, john_fmt, length, pattern in _HASH_TYPES:
        if pattern and pattern.match(h):
            matches.append({
                "name": name,
                "hashcat_mode": hc_mode,
                "john_format": john_fmt,
            })
        elif length and len(h) == length and pattern is None:
            matches.append({
                "name": name,
                "hashcat_mode": hc_mode,
                "john_format": john_fmt,
            })

    if not matches:
        matches.append({
            "name": "Unknown",
            "hashcat_mode": None,
            "john_format": None,
        })

    return matches
