"""Robots.txt analyzer — parses and explains crawling rules."""

import urllib.request
import urllib.robotparser
import urllib.parse


def run(url: str, user_agent: str = "*") -> dict:
    """Fetch and analyze a robots.txt file.

    Args:
        url: Domain or robots.txt URL.
        user_agent: User-agent to check rules for.

    Returns:
        Dictionary with rules, sitemaps, crawl delay, and root access flag.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    # Normalize to robots.txt URL
    if not url.endswith("robots.txt"):
        parsed = urllib.parse.urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    else:
        robots_url = url

    content = _fetch_robots(robots_url)
    rules = _parse_rules(content)
    sitemaps = _extract_sitemaps(content)

    # Use urllib.robotparser to check root access
    rp = urllib.robotparser.RobotFileParser()
    rp.set_url(robots_url)
    try:
        rp.read()
        can_crawl_root = rp.can_fetch(user_agent, "/")
        crawl_delay = rp.crawl_delay(user_agent)
    except Exception:
        can_crawl_root = True
        crawl_delay = None

    return {
        "robots_url": robots_url,
        "rules": rules,
        "sitemaps": sitemaps,
        "crawl_delay": crawl_delay,
        "can_crawl_root": can_crawl_root,
    }


def _fetch_robots(url: str) -> str:
    """Fetch robots.txt content."""
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            return resp.read(512 * 1024).decode("utf-8", errors="ignore")
    except Exception as exc:
        raise RuntimeError(f"Failed to fetch robots.txt at {url}: {exc}") from exc


def _parse_rules(content: str) -> dict:
    """Parse robots.txt into {user_agent: {allowed: [...], disallowed: [...]}}."""
    rules: dict[str, dict] = {}
    current_agents: list[str] = []

    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        if ":" in line:
            key, _, value = line.partition(":")
            key = key.strip().lower()
            value = value.strip()

            if key == "user-agent":
                current_agents.append(value)
                if value not in rules:
                    rules[value] = {"allowed": [], "disallowed": []}
            elif key == "disallow":
                for agent in current_agents:
                    if agent not in rules:
                        rules[agent] = {"allowed": [], "disallowed": []}
                    if value:
                        rules[agent]["disallowed"].append(value)
            elif key == "allow":
                for agent in current_agents:
                    if agent not in rules:
                        rules[agent] = {"allowed": [], "disallowed": []}
                    if value:
                        rules[agent]["allowed"].append(value)
            else:
                # New directive resets current agents
                if key not in ("crawl-delay", "sitemap"):
                    current_agents = []

    return rules


def _extract_sitemaps(content: str) -> list[str]:
    """Extract sitemap URLs from robots.txt."""
    sitemaps = []
    for line in content.splitlines():
        line = line.strip()
        if line.lower().startswith("sitemap:"):
            _, _, value = line.partition(":")
            sitemap_url = value.strip()
            if sitemap_url:
                sitemaps.append(sitemap_url)
    return sitemaps
