"""Excel sheet merger — combines multiple Excel files into one workbook."""

from pathlib import Path


def run(input_paths: str, output_path: str, mode: str = "sheets") -> dict:
    """Merge Excel files into a single workbook.

    Requires openpyxl. Install with: pip install openpyxl

    Args:
        input_paths: Comma-separated .xlsx file paths.
        output_path: Destination .xlsx file path.
        mode: 'sheets' (keep each as separate sheet) or 'stack' (vertical merge).

    Returns:
        Dictionary with output file info and merge statistics.
    """
    try:
        import importlib
        openpyxl = importlib.import_module("openpyxl")
    except ImportError:
        raise ImportError("openpyxl is required. Install with: pip install openpyxl")

    if not input_paths or not input_paths.strip():
        raise ValueError("input_paths must not be empty.")
    if not output_path or not output_path.strip():
        raise ValueError("output_path must not be empty.")

    mode = mode.strip().lower()
    if mode not in ("sheets", "stack"):
        raise ValueError("mode must be 'sheets' or 'stack'.")

    paths = [Path(p.strip()).expanduser().resolve() for p in input_paths.split(",") if p.strip()]
    for p in paths:
        if not p.exists():
            raise FileNotFoundError(f"Input file not found: {p}")

    out_path = Path(output_path.strip()).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    out_wb = openpyxl.Workbook()
    out_wb.remove(out_wb.active)  # remove default empty sheet

    sheets_merged = 0
    rows_total = 0

    if mode == "sheets":
        for file_path in paths:
            wb = openpyxl.load_workbook(str(file_path), data_only=True)
            for sheet_name in wb.sheetnames:
                ws_src = wb[sheet_name]
                safe_name = _unique_sheet_name(out_wb, f"{file_path.stem}_{sheet_name}")
                ws_dst = out_wb.create_sheet(title=safe_name)
                for row in ws_src.iter_rows(values_only=True):
                    ws_dst.append(list(row))
                    rows_total += 1
                sheets_merged += 1

    elif mode == "stack":
        combined_ws = out_wb.create_sheet(title="Combined")
        header_written = False
        for file_path in paths:
            wb = openpyxl.load_workbook(str(file_path), data_only=True)
            for sheet_name in wb.sheetnames:
                ws_src = wb[sheet_name]
                for i, row in enumerate(ws_src.iter_rows(values_only=True)):
                    if i == 0 and header_written:
                        continue  # skip duplicate headers
                    combined_ws.append(list(row))
                    rows_total += 1
                header_written = True
                sheets_merged += 1

    out_wb.save(str(out_path))

    return {
        "output_file": str(out_path),
        "sheets_merged": sheets_merged,
        "rows_total": rows_total,
        "source_files": [str(p) for p in paths],
    }


def _unique_sheet_name(wb, name: str) -> str:
    """Ensure sheet name is unique and within Excel's 31-char limit."""
    name = name[:31]
    existing = set(wb.sheetnames)
    if name not in existing:
        return name
    for i in range(1, 1000):
        candidate = f"{name[:28]}_{i}"
        if candidate not in existing:
            return candidate
    return name
