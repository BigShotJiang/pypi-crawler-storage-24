"""YouTube transcript fetcher — retrieves video subtitles for processing."""

import re
import urllib.parse


def run(video_url: str, language: str = "en") -> dict:
    """Fetch transcript for a YouTube video.

    Requires: pip install youtube-transcript-api

    Args:
        video_url: YouTube URL or video ID.
        language: Preferred transcript language.

    Returns:
        Dictionary with full transcript text and metadata.
    """
    try:
        import importlib
        yta = importlib.import_module("youtube_transcript_api")
    except ImportError:
        raise ImportError("youtube-transcript-api is required. Install with: pip install youtube-transcript-api")

    if not video_url or not video_url.strip():
        raise ValueError("video_url must not be empty.")

    video_id = _extract_video_id(video_url.strip())
    if not video_id:
        raise ValueError(f"Cannot extract video ID from: {video_url}")

    lang = language.strip() or "en"

    # Try requested language, then auto-generated, then any available
    transcript_list = yta.YouTubeTranscriptApi.list_transcripts(video_id)
    transcript = None

    try:
        transcript = transcript_list.find_transcript([lang])
    except Exception:
        try:
            transcript = transcript_list.find_generated_transcript([lang, "en"])
        except Exception:
            # Get the first available
            for t in transcript_list:
                transcript = t
                break

    if transcript is None:
        raise RuntimeError(f"No transcript available for video {video_id}")

    data = transcript.fetch()
    actual_lang = transcript.language_code

    # Concatenate text and calculate duration
    texts = [entry["text"] for entry in data]
    full_text = " ".join(texts)
    duration = max((entry["start"] + entry.get("duration", 0)) for entry in data) if data else 0.0

    return {
        "video_id": video_id,
        "language": actual_lang,
        "transcript": full_text,
        "word_count": len(full_text.split()),
        "duration_seconds": round(duration, 1),
    }


def _extract_video_id(url: str) -> str | None:
    """Extract YouTube video ID from URL or return ID directly."""
    patterns = [
        re.compile(r'(?:youtube\.com/watch\?.*v=|youtu\.be/)([a-zA-Z0-9_-]{11})'),
        re.compile(r'(?:youtube\.com/embed/)([a-zA-Z0-9_-]{11})'),
        re.compile(r'^([a-zA-Z0-9_-]{11})$'),  # bare video ID
    ]
    for pat in patterns:
        m = pat.search(url)
        if m:
            return m.group(1)
    return None
