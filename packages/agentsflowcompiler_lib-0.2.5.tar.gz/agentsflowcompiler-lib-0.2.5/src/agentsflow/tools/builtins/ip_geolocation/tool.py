"""IP geolocation — maps IP addresses to geographic and ISP information."""

import json
import urllib.request
import urllib.parse
import urllib.error


_API_URL = "https://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,lat,lon,isp,org,timezone,proxy,query"


def run(ip: str) -> dict:
    """Get geographic location and ISP info for an IP address.

    Args:
        ip: IPv4/IPv6 address, or 'me' to look up the current machine's IP.

    Returns:
        Dictionary with city, country, coordinates, ISP, and proxy flag.
    """
    if not ip or not ip.strip():
        raise ValueError("ip must not be empty.")

    ip = ip.strip()
    if ip.lower() == "me":
        ip = ""  # ip-api.com returns your own IP when no target is given

    url = _API_URL.format(ip=urllib.parse.quote(ip) if ip else "")
    req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"ip-api.com error {e.code}: {e.reason}") from e

    if data.get("status") == "fail":
        raise ValueError(f"Geolocation failed: {data.get('message', 'unknown error')}")

    return {
        "ip": data.get("query", ip),
        "city": data.get("city", ""),
        "region": data.get("regionName", ""),
        "country": data.get("country", ""),
        "country_code": data.get("countryCode", ""),
        "lat": data.get("lat"),
        "lon": data.get("lon"),
        "isp": data.get("isp", ""),
        "org": data.get("org", ""),
        "timezone": data.get("timezone", ""),
        "is_proxy": data.get("proxy", False),
    }
