"""JSON to Pydantic model generator — converts JSON to Pydantic v2 class definitions."""

import json
import re
from typing import Any


_JSON_TYPE_MAP = {
    "string": "str",
    "integer": "int",
    "number": "float",
    "boolean": "bool",
    "null": "None",
    "array": "list",
    "object": "dict",
}


def run(json_input: str, model_name: str = "MyModel", use_optional: bool = False) -> dict:
    """Generate a Pydantic v2 model from JSON.

    Args:
        json_input: JSON data object or JSON Schema string.
        model_name: Name for the model class.
        use_optional: Make all fields Optional.

    Returns:
        Dictionary with generated Pydantic code.
    """
    if not json_input or not json_input.strip():
        raise ValueError("json_input must not be empty.")

    try:
        data = json.loads(json_input.strip())
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc}") from exc

    name = _to_class_name(model_name.strip() or "MyModel")
    is_schema = isinstance(data, dict) and "$schema" in data or "properties" in data

    if is_schema:
        fields, imports, nested = _from_json_schema(data, name, use_optional)
    else:
        fields, imports, nested = _from_json_object(data, name, use_optional)

    code = _build_pydantic_code(name, fields, imports, nested)

    return {
        "model_name": name,
        "pydantic_code": code,
        "fields": [{"name": f["name"], "type": f["type"], "required": f["required"]} for f in fields],
    }


def _from_json_object(data: Any, name: str, use_optional: bool) -> tuple:
    """Infer field types from a JSON object instance."""
    if not isinstance(data, dict):
        raise ValueError("JSON must be an object (dict) at the top level.")

    fields = []
    imports = {"from pydantic import BaseModel"}
    nested = []

    for key, value in data.items():
        field_name = _to_snake_case(key)
        python_type, extra_import, nested_code = _infer_type(value, _to_class_name(key))
        if extra_import:
            imports.add(extra_import)
        if nested_code:
            nested.append(nested_code)
        required = not use_optional
        if use_optional:
            python_type = f"Optional[{python_type}]"
            imports.add("from typing import Optional")

        fields.append({
            "name": field_name,
            "original_key": key,
            "type": python_type,
            "required": required,
            "default": "None" if use_optional else ...,
        })

    return fields, imports, nested


def _from_json_schema(schema: dict, name: str, use_optional: bool) -> tuple:
    """Build fields from JSON Schema."""
    properties = schema.get("properties", {})
    required_fields = set(schema.get("required", []))
    imports = {"from pydantic import BaseModel"}
    fields = []
    nested = []

    for key, prop in properties.items():
        field_name = _to_snake_case(key)
        is_required = key in required_fields and not use_optional
        python_type = _schema_type_to_python(prop)

        if not is_required:
            python_type = f"Optional[{python_type}]"
            imports.add("from typing import Optional")

        fields.append({
            "name": field_name,
            "original_key": key,
            "type": python_type,
            "required": is_required,
            "default": ... if is_required else "None",
        })

    return fields, imports, nested


def _infer_type(value: Any, nested_name: str) -> tuple[str, str | None, str | None]:
    """Infer Python type from a JSON value."""
    if value is None:
        return "Optional[Any]", "from typing import Optional, Any", None
    if isinstance(value, bool):
        return "bool", None, None
    if isinstance(value, int):
        return "int", None, None
    if isinstance(value, float):
        return "float", None, None
    if isinstance(value, str):
        return "str", None, None
    if isinstance(value, list):
        if value and isinstance(value[0], dict):
            return f"List[{nested_name}]", "from typing import List", None
        return "List[Any]", "from typing import List, Any", None
    if isinstance(value, dict):
        return "Dict[str, Any]", "from typing import Dict, Any", None
    return "Any", "from typing import Any", None


def _schema_type_to_python(prop: dict) -> str:
    schema_type = prop.get("type", "any")
    if isinstance(schema_type, list):
        types = [_JSON_TYPE_MAP.get(t, "Any") for t in schema_type if t != "null"]
        return types[0] if len(types) == 1 else f"Union[{', '.join(types)}]"
    if schema_type == "array":
        items = prop.get("items", {})
        item_type = _schema_type_to_python(items) if items else "Any"
        return f"List[{item_type}]"
    return _JSON_TYPE_MAP.get(schema_type, "Any")


def _build_pydantic_code(name: str, fields: list, imports: set, nested: list) -> str:
    lines = sorted(imports) + [""]
    if nested:
        lines.extend(nested)
        lines.append("")

    lines.append(f"class {name}(BaseModel):")
    if not fields:
        lines.append("    pass")
    else:
        for f in fields:
            if f["default"] is ...:
                lines.append(f"    {f['name']}: {f['type']}")
            else:
                lines.append(f"    {f['name']}: {f['type']} = {f['default']}")

    return "\n".join(lines)


def _to_class_name(name: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]", "_", name).title().replace("_", "")


def _to_snake_case(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]", "_", name)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    s = re.sub(r"([a-z\d])([A-Z])", r"\1_\2", s)
    return s.lower().strip("_")
