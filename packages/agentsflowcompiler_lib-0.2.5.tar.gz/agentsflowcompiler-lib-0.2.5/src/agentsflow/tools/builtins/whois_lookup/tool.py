"""WHOIS lookup tool — retrieves domain registration information."""

import re
import socket


_WHOIS_PORT = 43
_IANA_SERVER = "whois.iana.org"

# Common WHOIS field patterns
_FIELD_PATTERNS = {
    "registrar": re.compile(r"(?:Registrar|registrar):\s*(.+)", re.IGNORECASE),
    "creation_date": re.compile(r"(?:Creation Date|Created|created|Registration Time):\s*(.+)", re.IGNORECASE),
    "expiration_date": re.compile(r"(?:Expir\w+ Date|Expiry|expiry|Registry Expiry Date):\s*(.+)", re.IGNORECASE),
    "updated_date": re.compile(r"(?:Updated Date|Last Modified|last-modified):\s*(.+)", re.IGNORECASE),
    "nameserver": re.compile(r"(?:Name Server|nserver|nameserver):\s*(.+)", re.IGNORECASE),
    "status": re.compile(r"(?:Domain Status|status):\s*(.+)", re.IGNORECASE),
    "whois_server": re.compile(r"(?:Whois Server|whois):\s*(.+)", re.IGNORECASE),
}


def run(domain: str) -> dict:
    """Retrieve WHOIS data for a domain.

    Args:
        domain: Domain to look up (e.g. 'example.com').

    Returns:
        Dictionary with registrar, dates, nameservers, status, and raw WHOIS text.
    """
    if not domain or not domain.strip():
        raise ValueError("domain must not be empty.")

    domain = domain.strip().lower()

    # Get the authoritative WHOIS server via IANA
    raw_iana = _whois_query(_IANA_SERVER, domain)
    whois_server = _extract_first(_FIELD_PATTERNS["whois_server"], raw_iana) or "whois.verisign-grs.com"

    # Query the authoritative server
    raw = _whois_query(whois_server.strip(), domain)

    nameservers = [
        m.group(1).strip().lower()
        for m in _FIELD_PATTERNS["nameserver"].finditer(raw)
    ]
    statuses = [
        m.group(1).strip()
        for m in _FIELD_PATTERNS["status"].finditer(raw)
    ]

    return {
        "domain": domain,
        "registrar": _extract_first(_FIELD_PATTERNS["registrar"], raw) or "",
        "creation_date": _extract_first(_FIELD_PATTERNS["creation_date"], raw) or "",
        "expiration_date": _extract_first(_FIELD_PATTERNS["expiration_date"], raw) or "",
        "updated_date": _extract_first(_FIELD_PATTERNS["updated_date"], raw) or "",
        "nameservers": list(dict.fromkeys(nameservers)),  # deduplicate preserving order
        "status": list(dict.fromkeys(statuses)),
        "raw": raw,
    }


def _whois_query(server: str, query: str) -> str:
    """Send a raw WHOIS query to the given server."""
    try:
        with socket.create_connection((server, _WHOIS_PORT), timeout=10) as s:
            s.sendall(f"{query}\r\n".encode("utf-8"))
            chunks = []
            while True:
                chunk = s.recv(4096)
                if not chunk:
                    break
                chunks.append(chunk)
            return b"".join(chunks).decode("utf-8", errors="replace")
    except Exception as exc:
        raise RuntimeError(f"WHOIS query to {server} failed: {exc}") from exc


def _extract_first(pattern: re.Pattern, text: str) -> str | None:
    """Return the first capture group match from text, stripped."""
    m = pattern.search(text)
    return m.group(1).strip() if m else None
