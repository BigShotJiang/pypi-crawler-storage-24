"""Subdomain enumerator — discovers subdomains via crt.sh and AlienVault OTX."""

import json
import urllib.request
import urllib.error
import urllib.parse


def run(domain: str, sources: str = "crtsh,alienvault") -> dict:
    """Find subdomains of a domain using certificate transparency and threat intel APIs.

    Args:
        domain: Target domain (e.g. 'example.com').
        sources: Comma-separated list of sources to query ('crtsh', 'alienvault').

    Returns:
        Dictionary with subdomains list, count, and sources used.
    """
    if not domain or not domain.strip():
        raise ValueError("domain must not be empty.")

    domain = domain.strip().lower()
    source_list = [s.strip().lower() for s in sources.split(",") if s.strip()]
    if not source_list:
        source_list = ["crtsh", "alienvault"]

    subdomains: set[str] = set()
    sources_used: list[str] = []

    if "crtsh" in source_list:
        found = _query_crtsh(domain)
        subdomains.update(found)
        sources_used.append("crtsh")

    if "alienvault" in source_list:
        found = _query_alienvault(domain)
        subdomains.update(found)
        sources_used.append("alienvault")

    # Filter to valid subdomains only
    valid = sorted(
        s for s in subdomains
        if s.endswith(f".{domain}") or s == domain
    )

    return {
        "subdomains": valid,
        "count": len(valid),
        "sources_used": sources_used,
    }


def _query_crtsh(domain: str) -> list[str]:
    """Query crt.sh certificate transparency logs."""
    url = f"https://crt.sh/?q=%.{urllib.parse.quote(domain)}&output=json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
        results = set()
        for entry in data:
            name = entry.get("name_value", "")
            for line in name.splitlines():
                line = line.strip().lstrip("*.")
                if line:
                    results.add(line.lower())
        return list(results)
    except Exception:
        return []


def _query_alienvault(domain: str) -> list[str]:
    """Query AlienVault OTX passive DNS."""
    url = f"https://otx.alienvault.com/api/v1/indicators/domain/{urllib.parse.quote(domain)}/passive_dns"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "agentsflow/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - URL validated to http/https scheme
            data = json.loads(resp.read().decode("utf-8"))
        results = set()
        for entry in data.get("passive_dns", []):
            hostname = entry.get("hostname", "").strip().lower()
            if hostname:
                results.add(hostname)
        return list(results)
    except Exception:
        return []
