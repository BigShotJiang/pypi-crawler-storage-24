"""Network interface lister — shows all network interfaces with addresses and status."""

import socket
import subprocess


def run(include_loopback: bool = False) -> dict:
    """List all network interfaces.

    Uses psutil if available, falls back to socket/ip addr.

    Args:
        include_loopback: Include loopback (lo) interface.

    Returns:
        Dictionary with interface list and count.
    """
    try:
        import importlib
        psutil = importlib.import_module("psutil")
        return _psutil_interfaces(psutil, include_loopback)
    except ImportError:
        pass

    return _fallback_interfaces(include_loopback)


def _psutil_interfaces(psutil, include_loopback: bool) -> dict:
    """List interfaces using psutil."""
    addrs = psutil.net_if_addrs()
    stats = psutil.net_if_stats()

    interfaces = []
    for name, addr_list in addrs.items():
        if not include_loopback and name.lower() in ("lo", "lo0", "localhost"):
            continue

        ipv4_list, ipv6_list, mac = [], [], ""
        for addr in addr_list:
            if addr.family == socket.AF_INET:
                ipv4_list.append(f"{addr.address}/{_prefix_from_netmask(addr.netmask)}")
            elif addr.family == socket.AF_INET6:
                ipv6_list.append(addr.address.split("%")[0])  # strip scope
            elif addr.family == psutil.AF_LINK:
                mac = addr.address

        stat = stats.get(name)
        is_up = stat.isup if stat else False
        speed = stat.speed if stat else 0

        iface_type = _classify_interface(name)

        interfaces.append({
            "name": name,
            "type": iface_type,
            "mac": mac,
            "ipv4": ipv4_list,
            "ipv6": ipv6_list,
            "is_up": is_up,
            "speed_mbps": speed,
        })

    return {"interfaces": interfaces, "count": len(interfaces)}


def _fallback_interfaces(include_loopback: bool) -> dict:
    """Fallback: parse 'ip addr' or 'ifconfig' output."""
    interfaces = []
    try:
        result = subprocess.run(
            ["ip", "-j", "addr"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            import json
            data = json.loads(result.stdout)
            for iface in data:
                name = iface.get("ifname", "")
                if not include_loopback and name in ("lo",):
                    continue
                ipv4 = [a["local"] for a in iface.get("addr_info", []) if a.get("family") == "inet"]
                ipv6 = [a["local"] for a in iface.get("addr_info", []) if a.get("family") == "inet6"]
                link_info = iface.get("link_info", {})
                interfaces.append({
                    "name": name,
                    "type": _classify_interface(name),
                    "mac": iface.get("address", ""),
                    "ipv4": ipv4,
                    "ipv6": ipv6,
                    "is_up": "UP" in iface.get("flags", []),
                    "speed_mbps": 0,
                })
    except Exception:
        pass

    return {"interfaces": interfaces, "count": len(interfaces)}


def _classify_interface(name: str) -> str:
    """Classify network interface by name."""
    name_lower = name.lower()
    if name_lower.startswith(("wlan", "wifi", "wl")):
        return "WiFi"
    if name_lower.startswith(("eth", "en")):
        return "Ethernet"
    if name_lower.startswith("tun"):
        return "VPN (TUN)"
    if name_lower.startswith("tap"):
        return "VPN (TAP)"
    if name_lower.startswith("docker") or name_lower.startswith("br-"):
        return "Docker Bridge"
    if name_lower.startswith("veth"):
        return "Virtual Ethernet"
    if name_lower in ("lo", "lo0"):
        return "Loopback"
    return "Unknown"


def _prefix_from_netmask(netmask: str | None) -> int:
    """Convert netmask to prefix length."""
    if not netmask:
        return 0
    try:
        return sum(bin(int(octet)).count("1") for octet in netmask.split("."))
    except (ValueError, AttributeError):
        return 0
