"""Pandas query runner — executes filter queries on CSV/Excel DataFrames."""

from pathlib import Path


def run(file_path: str, query: str, output_columns: str = "", max_rows: int = 100) -> dict:
    """Load a data file and run a pandas query on it.

    Requires pandas. Install with: pip install pandas openpyxl

    Args:
        file_path: Path to CSV or Excel file.
        query: Pandas query expression string.
        output_columns: Comma-separated columns to include (empty = all).
        max_rows: Maximum rows to return.

    Returns:
        Dictionary with query results as list of row dicts.
    """
    try:
        import importlib
        pd = importlib.import_module("pandas")
    except ImportError:
        raise ImportError("pandas is required. Install with: pip install pandas")

    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")
    if not query or not query.strip():
        raise ValueError("query must not be empty.")

    path = Path(file_path.strip()).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    max_rows = max(1, min(int(max_rows), 10000))

    # Load file
    suffix = path.suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(str(path))
    elif suffix in (".xlsx", ".xls"):
        df = pd.read_excel(str(path))
    elif suffix == ".json":
        df = pd.read_json(str(path))
    elif suffix in (".parquet",):
        df = pd.read_parquet(str(path))
    else:
        raise ValueError(f"Unsupported file format: {suffix}. Use CSV, Excel, JSON, or Parquet.")

    # Apply query
    try:
        result = df.query(query)
    except Exception as exc:
        raise ValueError(f"Query error: {exc}") from exc

    # Filter columns
    if output_columns and output_columns.strip():
        cols = [c.strip() for c in output_columns.split(",") if c.strip()]
        valid_cols = [c for c in cols if c in result.columns]
        if valid_cols:
            result = result[valid_cols]

    total_rows = len(result)
    result = result.head(max_rows)

    return {
        "total_rows": total_rows,
        "returned_rows": len(result),
        "columns": list(result.columns),
        "data": result.where(pd.notna(result), None).to_dict(orient="records"),
    }
