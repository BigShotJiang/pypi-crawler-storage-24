"""
Agent Tools
===========
Thin wrapper around ``ToolRegistry`` that encapsulates
tool loading and execution for a single agent.
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from agentsflow.errors import AgentsFlowToolError, DockerExecutionError
from agentsflow.logging_utils import log_structured
from agentsflow.tools import ToolRegistry
from agentsflow.constants import DEFAULT_BUILTINS_DIR, DEFAULT_TOOL_PYTHON_NAME, DEFAULT_DOCKER_CONFIG_FILE
from agentsflow.schema.tool_config_schema import Tool
from agentsflow.schema.docker_tool_config_schema import DockerToolConfig, NetworkMode
from agentsflow.types import (
    AnthropicToolSchema,
    OpenAIToolSchema,
    ToolCallLogEntry,
)

logger = logging.getLogger(__name__)


class AgentTools:
    """
    Manages the tool lifecycle for a single agent.

    Responsibilities:
        - Load built-in and custom tools via ``ToolRegistry``.
        - Provide OpenAI-compatible tool schemas for the LLM call.
        - Execute a tool by name and return the result.
        - Keep a per-run log of all tool calls made.
    """

    MAX_TOOL_ROUNDS = 10  # Safety limit for tool-calling loops

    def __init__(
        self,
        agent_dir: Path,
        tool_configs: List[Tool],
        tools_base_dir: Optional[Path] = None,
        ) -> None:
        """
        Args:
            agent_dir:       Resolved directory for this agent.
            tool_configs:    List of ``Tool`` objects (built-in and custom) from the agent's config.
            tools_base_dir:  Override for the built-in tools directory.
        """
        self._agent_dir = agent_dir
        self._registry = ToolRegistry(builtins_dir=tools_base_dir)
        # Map of tool name → Tool config for docker lookup
        self._tool_config_map: Dict[str, Tool] = {t.identity.name: t for t in tool_configs}

        if len(tool_configs) > 0:
            self._registry.load_agent_tools(tool_configs=tool_configs, agent_dir=agent_dir)

        # Per-run tool call log (reset on each run)
        self._call_log: list[ToolCallLogEntry] = []

    # ── Schemas ───────────────────────────────────────────────

    @property
    def has_tools(self) -> bool:
        return self._registry.has_tools()

    def get_schemas(
        self, provider: Optional[str] = None
    ) -> list[OpenAIToolSchema] | list[AnthropicToolSchema] | None:
        """Return provider-specific tool schemas, or None if no tools."""
        if not self.has_tools:
            return None
        if provider == "anthropic":
            return self._registry.get_anthropic_schemas()
        return self._registry.get_openai_schemas()

    # ── Execution ─────────────────────────────────────────────

    def execute(self, name: str, arguments: Dict[str, Any]) -> str:
        """
        Execute a tool and return the result as a string.

        If the tool has docker_enabled=True the execution happens inside a
        Docker container; otherwise it runs in the host process.

        The call is also appended to the internal call log.
        """
        tool_obj = self._tool_config_map.get(name)
        ran_in_docker = bool(tool_obj and tool_obj.identity.docker_enabled)
        try:
            if ran_in_docker:
                result_str = self._execute_in_docker(tool_obj, arguments)
            else:
                result = self._registry.execute(name, arguments)
                result_str = (
                    json.dumps(result, ensure_ascii=False)
                    if not isinstance(result, str)
                    else result
                )
        except (AgentsFlowToolError, DockerExecutionError):
            raise
        except Exception as e:
            result_str = f"Error executing {name}: {e}"
            log_structured(
                logging.ERROR,
                "tool_error",
                agent_name=self._agent_dir.name,
                tool_name=name,
                error=str(e),
            )
            self._call_log.append({
                "name": name,
                "arguments": arguments,
                "result": result_str,
                "docker": ran_in_docker,
            })
            raise AgentsFlowToolError(result_str) from e

        self._call_log.append({
            "name": name,
            "arguments": arguments,
            "result": result_str,
            "docker": ran_in_docker,
        })

        return result_str

    # ── Docker Execution ──────────────────────────────────────

    def _execute_in_docker(self, tool: Tool, arguments: Dict[str, Any]) -> str:
        """Execute a tool inside a Docker container."""
        docker_config = self._load_docker_config(tool)
        cmd = self._build_docker_command(docker_config, tool, arguments)
        timeout = docker_config.resources.timeout or 30
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            return json.dumps({
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode,
            })
        except subprocess.TimeoutExpired:
            raise DockerExecutionError(
                f"Tool '{tool.identity.name}' execution timed out after {timeout}s"
            )
        except Exception as e:
            raise DockerExecutionError(
                f"Docker execution failed for tool '{tool.identity.name}': {e}"
            ) from e

    def _load_docker_config(self, tool: Tool) -> DockerToolConfig:
        """Load docker_config.yaml from the tool's local directory."""
        from agentsflow.dev.helper.tool_helper import _resolve_tool_docker_dir
        from agentsflow.errors import AgentsFlowConfigError

        tool_dir = _resolve_tool_docker_dir(self._agent_dir, tool)
        config_path = tool_dir / DEFAULT_DOCKER_CONFIG_FILE

        if not config_path.exists():
            raise AgentsFlowConfigError(
                f"docker_enabled=True but no docker_config.yaml found at {config_path}"
            )

        with open(config_path) as f:
            raw = yaml.safe_load(f)
        return DockerToolConfig.model_validate(raw)

    def _resolve_tool_script_path(self, tool: Tool) -> Path:
        """Resolve the absolute path to the tool's Python script."""
        if tool.custom and tool.config and tool.config.path:
            return self._agent_dir / tool.config.path
        # Built-in tool
        return DEFAULT_BUILTINS_DIR / tool.identity.name / DEFAULT_TOOL_PYTHON_NAME

    def _build_docker_command(
        self,
        config: DockerToolConfig,
        tool: Tool,
        arguments: Dict[str, Any],
    ) -> List[str]:
        """Build a docker run command from DockerToolConfig."""
        cmd = ["docker", "run"]

        # Auto-remove
        if config.auto_remove:
            cmd.append("--rm")

        # User
        if config.user.run_as_root:
            cmd.extend(["--user", "root"])
        elif config.user.user:
            cmd.extend(["--user", config.user.user])

        # Read-only rootfs
        if config.user.read_only_rootfs:
            cmd.append("--read-only")
            cmd.extend(["--tmpfs", "/tmp:rw,noexec,nosuid,size=64m"])  # nosec B108 - /tmp here is inside the Docker container, not the host filesystem

        # Network
        if config.network.mode == NetworkMode.NONE:
            cmd.extend(["--network", "none"])
        elif config.network.mode == NetworkMode.HOST:
            cmd.extend(["--network", "host"])
        elif config.network.mode == NetworkMode.CUSTOM:
            cmd.extend(["--network", config.network.custom_network])
        # bridge is default, no flag needed

        if config.network.dns:
            for dns in config.network.dns:
                cmd.extend(["--dns", dns])

        if config.network.expose_ports:
            for port in config.network.expose_ports:
                cmd.extend(["-p", port])

        # Resources
        if config.resources.memory_limit:
            cmd.extend(["--memory", config.resources.memory_limit])
        if config.resources.cpu_limit is not None:
            cmd.extend(["--cpus", str(config.resources.cpu_limit)])
        if config.resources.pids_limit is not None:
            cmd.extend(["--pids-limit", str(config.resources.pids_limit)])
        if config.resources.shm_size:
            cmd.extend(["--shm-size", config.resources.shm_size])

        # Security
        if config.security.no_new_privileges:
            cmd.append("--security-opt=no-new-privileges")
        for cap in config.security.cap_drop:
            cmd.extend(["--cap-drop", cap])
        if config.security.cap_add:
            for cap in config.security.cap_add:
                cmd.extend(["--cap-add", cap])
        if config.security.seccomp_profile:
            cmd.extend(["--security-opt", f"seccomp={config.security.seccomp_profile}"])
        if config.security.apparmor_profile:
            cmd.extend(["--security-opt", f"apparmor={config.security.apparmor_profile}"])

        # Volumes
        if config.volumes:
            for vol in config.volumes:
                ro = ":ro" if vol.read_only else ""
                cmd.extend(["-v", f"{vol.host_path}:{vol.container_path}{ro}"])

        # Mount host tool script into container (dev default). Production: mount_host_tool_script=False
        # and bake the tool into the image at container_tool_path.
        if config.mount_host_tool_script:
            tool_script_path = self._resolve_tool_script_path(tool)
            cmd.extend(["-v", f"{tool_script_path}:{config.container_tool_path}:ro"])

        # Environment
        if config.environment:
            for key, val in config.environment.items():
                cmd.extend(["-e", f"{key}={val}"])

        # Pass tool arguments as env var
        cmd.extend(["-e", f"TOOL_ARGS={json.dumps(arguments)}"])

        # Working directory
        cmd.extend(["-w", config.working_dir])

        # Entrypoint override
        if config.entrypoint:
            cmd.extend(["--entrypoint", config.entrypoint])

        # Labels
        if config.labels:
            for key, val in config.labels.items():
                cmd.extend(["--label", f"{key}={val}"])

        # Extra args (escape hatch)
        if config.extra_docker_args:
            cmd.extend(config.extra_docker_args)

        # Image + command (script path must exist in container — mounted or baked into image)
        cmd.append(config.image)
        cmd.extend([config.tool_interpreter, config.container_tool_path])

        return cmd

    # ── Log Management ────────────────────────────────────────

    def reset_log(self) -> None:
        """Clear the tool call log (call at the start of each ``Agent.run``)."""
        self._call_log = []

    @property
    def call_log(self) -> list[ToolCallLogEntry]:
        """Return the current run's tool call log."""
        return self._call_log