from __future__ import annotations
import logging
import shutil
from pathlib import Path
from typing import Optional
from uuid import UUID

from agentsflow.schema.agent_config_schema import AgentConfig, AgentModelConfig, ApiKeyConfig
from agentsflow.constants import AGENTS_DIR

from agentsflow.dev.helper.prod_sync_helper import load_agent_prompts
from agentsflow.dev.processing_api import add_postprocess, add_preprocess, edit_postprocess, edit_preprocess
from agentsflow.dev.tool_api import add_builtin_tool, add_tool
from agentsflow.dev.helper.tool_helper import _resolve_tool_docker_dir
from agentsflow.dev.helper.processing_helper import _read_process
from agentsflow.schema.tool_config_schema import ToolConfig, ToolIdentityConfig

logger = logging.getLogger(__name__)


def _copy_docker_configs(
    source_agent_dir: Path,
    dest_agent_dir: Path,
    agent_config: AgentConfig,
) -> None:
    """
    Copy docker_config.yaml files from source to destination agent directory
    for all docker-enabled tools.
    """
    for tool in (agent_config.tools or []):
        if not tool.identity.docker_enabled:
            continue

        src_docker_cfg = _resolve_tool_docker_dir(source_agent_dir, tool) / "docker_config.yaml"
        if not src_docker_cfg.exists():
            logger.warning(
                f"Tool '{tool.identity.name}' has docker_enabled=True but no "
                f"docker_config.yaml at {src_docker_cfg} — skipping"
            )
            continue

        dst_tool_dir = _resolve_tool_docker_dir(dest_agent_dir, tool)
        dst_tool_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_docker_cfg, dst_tool_dir / "docker_config.yaml")


def _duplicate_agent(base_dest_dir: Path, base_source_dir: Path, new_name: str, agent_config: AgentConfig, api_key_config: ApiKeyConfig, agent_id: Optional[UUID] = None) -> AgentConfig:
    """Duplicate an agent into a destination base directory."""
    from agentsflow.dev.agent_api import create_agent
    from agentsflow.schema.agent_config_schema import Prompt

    prompts = load_agent_prompts(agent_config.prompt_config, agent_dir=base_source_dir / AGENTS_DIR / agent_config.identity.name)
    new_model_config = AgentModelConfig(
        api_key_config=api_key_config,
        model=agent_config.model_settings.model,
        temperature=agent_config.model_settings.temperature,
        max_tokens=agent_config.model_settings.max_tokens,
        timeout=agent_config.model_settings.timeout,
        retry_config=agent_config.model_settings.retry_config,
    )
    new_agent_config = create_agent(
        base_dir=base_dest_dir,
        agent_name=new_name,
        model_config=new_model_config,
        description=agent_config.identity.description,
        prompts=prompts,
        agent_id=agent_id,
    )
    source_agent_dir = base_source_dir / AGENTS_DIR / agent_config.identity.name
    dest_agent_dir = base_dest_dir / AGENTS_DIR / new_name
    for tool in (agent_config.tools or []):
        try:
            if tool.custom:
                if tool.config is None:
                    continue
                script = (source_agent_dir / tool.config.path).read_text(encoding="utf-8")
                add_tool(
                    base_dir=base_dest_dir,
                    script=script,
                    identity=ToolIdentityConfig(
                        tool_id=tool.identity.tool_id,
                        name=tool.identity.name,
                        description=tool.identity.description,
                        category=tool.identity.category,
                        docker_enabled=tool.identity.docker_enabled,
                    ),
                    config=ToolConfig(
                        function_name=tool.config.function_name,
                        parameters=tool.config.parameters,
                        returns=tool.config.returns,
                    ),
                    agent_name=new_agent_config.identity.name,
                    agent_id=new_agent_config.identity.agent_id,
                )
            else:
                add_builtin_tool(
                    base_dir=base_dest_dir,
                    tool_name=tool.identity.name,
                    agent_name=new_agent_config.identity.name,
                    agent_id=new_agent_config.identity.agent_id,
                )
        except Exception as e:
            raise ValueError(f"Failed to add tool {tool.identity.name} to agent {agent_config.identity.name}: {e}") from e

    # Copy docker_config.yaml files for all docker-enabled tools
    _copy_docker_configs(source_agent_dir, dest_agent_dir, agent_config)

    preprocess_config = agent_config.preprocess_config
    if preprocess_config is not None:
        new_agent_config = add_preprocess(base_dest_dir, agent_name=new_agent_config.identity.name, agent_id=new_agent_config.identity.agent_id)
        script = _read_process(base_source_dir / AGENTS_DIR / agent_config.identity.name / preprocess_config.path)
        edit_preprocess(base_dest_dir, agent_name=new_agent_config.identity.name, agent_id=new_agent_config.identity.agent_id, script=script)
    postprocess_config = agent_config.postprocess_config
    if postprocess_config is not None:
        script = _read_process(base_source_dir / AGENTS_DIR / agent_config.identity.name / postprocess_config.path)
        new_agent_config = add_postprocess(base_dest_dir, agent_name=new_agent_config.identity.name, agent_id=new_agent_config.identity.agent_id)
        edit_postprocess(base_dest_dir, agent_name=new_agent_config.identity.name, agent_id=new_agent_config.identity.agent_id, script=script)
    return new_agent_config
