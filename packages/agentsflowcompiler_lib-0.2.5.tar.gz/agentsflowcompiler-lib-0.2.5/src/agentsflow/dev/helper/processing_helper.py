from __future__ import annotations

from pathlib import Path

from agentsflow.constants import AGENTS_DIR
from agentsflow.schema.agent_config_schema import AgentConfig, ProcessingConfig

def _add_default_preprocess(
    agent_dir: Path,
    agent_config: AgentConfig,
    default_preprocess_path: Path,
    default_preprocess_function_name: str,
) -> AgentConfig:
    try:
        preprocess_path = agent_dir / default_preprocess_path
        preprocess_path.parent.mkdir(parents=True, exist_ok=True)
        content = f"def {default_preprocess_function_name}(input):\n    return input\n"
        preprocess_path.write_text(content, encoding="utf-8")
        agent_config.preprocess_config = _set_process(
            default_preprocess_path, default_preprocess_function_name
        )
        return agent_config
    except Exception as e:
        raise ValueError(f"Could not add preprocess: {e}")


def _add_default_postprocess(
    agent_dir: Path,
    agent_config: AgentConfig,
    default_postprocess_path: Path,
    default_postprocess_function_name: str,
) -> AgentConfig:
    try:
        postprocess_path = agent_dir / default_postprocess_path
        postprocess_path.parent.mkdir(parents=True, exist_ok=True)
        content = f"def {default_postprocess_function_name}(input):\n    return input\n"
        postprocess_path.write_text(content, encoding="utf-8")
        agent_config.postprocess_config = _set_process(
            default_postprocess_path, default_postprocess_function_name
        )
        return agent_config
    except Exception as e:
        raise ValueError(f"Could not add postprocess: {e}")


def _set_process(process_path: Path, process_function_name: str) -> ProcessingConfig:
    try:
        return ProcessingConfig(path=process_path, function_name=process_function_name)
    except Exception as e:
        raise ValueError(f"Could not create ProcessingConfig: {e}")

def _read_process(process_path: Path) -> str:
    try:
        return process_path.read_text(encoding="utf-8")
    except Exception as e:
        raise ValueError(f"Could not read process: {e}")
def _delete_process(process_path: Path) -> None:
    try:
        if process_path.exists():
            process_path.unlink()
        else:
            raise ValueError(f"Process file {process_path} does not exist")
    except Exception as e:
        raise ValueError(f"Could not delete process: {e}")
