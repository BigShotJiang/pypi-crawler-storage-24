from __future__ import annotations

from pathlib import Path
from typing import Dict

from agentsflow.agent._utils import load_prompt
from agentsflow.schema import AgentConfig, Prompt, PromptConfig, Tool

from agentsflow.dev.helper.processing_helper import _read_process

def load_agent_prompts(agent_prompt_config: PromptConfig, agent_dir: Path) -> Prompt:
    """Load all prompt files for an agent from disk."""
    return Prompt(
        instruction=load_prompt(agent_dir, agent_prompt_config.instruction_path),
        think=load_prompt(agent_dir, agent_prompt_config.think_path),
        example=load_prompt(agent_dir, agent_prompt_config.example_path),
        next_model_rule=load_prompt(agent_dir, agent_prompt_config.next_model_rule_path),
        return_prompt=load_prompt(agent_dir, agent_prompt_config.return_path),
    )


def sync_tools_to_prod(
    base_prod_dir: Path,
    base_source_dir: Path,
    source_config: AgentConfig,
    prod_config: AgentConfig,
) -> None:
    """Sync source tools into prod agent (upsert custom, ensure built-ins)."""
    from agentsflow.constants import AGENTS_DIR
    from agentsflow.dev.helper.duplicate_helper import _copy_docker_configs

    prod_tools = {t.identity.name: t for t in (prod_config.tools or [])}
    source_agent_dir = base_source_dir / AGENTS_DIR / source_config.identity.name
    prod_agent_dir = base_prod_dir / AGENTS_DIR / prod_config.identity.name
    for tool in (source_config.tools or []):
        if tool.custom:
            _upsert_custom_tool_in_prod(base_prod_dir, source_agent_dir, tool, prod_tools, prod_config)
        else:
            _ensure_builtin_tool_in_prod(base_prod_dir, tool, prod_tools, prod_config)

    # Copy docker_config.yaml files for all docker-enabled tools
    from agentsflow.dev.helper.duplicate_helper import _copy_docker_configs
    _copy_docker_configs(source_agent_dir, prod_agent_dir, source_config)


def sync_processing_to_prod(base_prod_dir: Path, base_dev_dir: Path, source_config: AgentConfig, prod_config: AgentConfig) -> None:
    """Sync preprocess/postprocess function configs from source to prod."""
    from agentsflow.dev.processing_api import (
        add_postprocess,
        add_preprocess,
        edit_postprocess,
        edit_preprocess,
    )
    from agentsflow.constants import AGENTS_DIR
    if source_config.preprocess_config is not None:
        preprocess_script = _read_process(base_dev_dir / AGENTS_DIR / prod_config.identity.name / source_config.preprocess_config.path)

        if prod_config.preprocess_config is not None:
            edit_preprocess(
                base_prod_dir,
                agent_name=prod_config.identity.name,
                agent_id=prod_config.identity.agent_id,
                script=preprocess_script,
            )
        else:
            add_preprocess(
                base_prod_dir,
                agent_name=prod_config.identity.name,
                agent_id=prod_config.identity.agent_id)
            edit_preprocess(
                base_prod_dir,
                agent_name=prod_config.identity.name,
                agent_id=prod_config.identity.agent_id,
                script=preprocess_script,
            )

    if source_config.postprocess_config is not None:
        postprocess_script = _read_process(base_dev_dir / AGENTS_DIR / prod_config.identity.name / source_config.postprocess_config.path)
        if prod_config.postprocess_config is not None:
            edit_postprocess(
                base_prod_dir,
                agent_name=prod_config.identity.name,
                agent_id=prod_config.identity.agent_id,
                script=postprocess_script,
            )
        else:
            add_postprocess(
                base_prod_dir,
                agent_name=prod_config.identity.name,
                agent_id=prod_config.identity.agent_id,
            )
            edit_postprocess(
                base_prod_dir,
                agent_name=prod_config.identity.name,
                agent_id=prod_config.identity.agent_id,
                script=postprocess_script,
            )


def _upsert_custom_tool_in_prod(
    base_prod_dir: Path,
    source_agent_dir: Path,
    tool: Tool,
    prod_tools: Dict[str, Tool],
    prod_config: AgentConfig,
) -> None:
    from agentsflow.dev.tool_api import add_tool, edit_tool, remove_tool

    if tool.config is None:
        return

    tool_name = tool.identity.name
    script = (source_agent_dir / tool.config.path).read_text(encoding="utf-8")
    existing = prod_tools.get(tool_name)

    if existing and existing.custom:
        edit_tool(
            base_dir=base_prod_dir,
            tool_name=tool_name,
            script=script,
            function_name=tool.config.function_name,
            description=tool.identity.description,
            category=tool.identity.category,
            agent_name=prod_config.identity.name,
            agent_id=prod_config.identity.agent_id,
            parameters=tool.config.parameters,
            returns=tool.config.returns,
        )
        return

    if existing and not existing.custom:
        remove_tool(
            base_dir=base_prod_dir,
            tool_name=tool_name,
            agent_name=prod_config.identity.name,
            agent_id=prod_config.identity.agent_id,
        )

    add_tool(
        base_dir=base_prod_dir,
        tool_name=tool_name,
        script=script,
        function_name=tool.config.function_name,
        description=tool.identity.description,
        category=tool.identity.category,
        agent_name=prod_config.identity.name,
        agent_id=prod_config.identity.agent_id,
        parameters=tool.config.parameters,
        returns=tool.config.returns,
    )


def _ensure_builtin_tool_in_prod(
    base_prod_dir: Path,
    tool: Tool,
    prod_tools: Dict[str, Tool],
    prod_config: AgentConfig,
) -> None:
    from agentsflow.dev.tool_api import add_builtin_tool, remove_tool

    tool_name = tool.identity.name
    existing = prod_tools.get(tool_name)

    if existing and existing.custom:
        remove_tool(
            base_dir=base_prod_dir,
            tool_name=tool_name,
            agent_name=prod_config.identity.name,
            agent_id=prod_config.identity.agent_id,
        )
        existing = None

    if existing is None:
        add_builtin_tool(
            base_dir=base_prod_dir,
            tool_name=tool_name,
            agent_name=prod_config.identity.name,
            agent_id=prod_config.identity.agent_id,
        )
