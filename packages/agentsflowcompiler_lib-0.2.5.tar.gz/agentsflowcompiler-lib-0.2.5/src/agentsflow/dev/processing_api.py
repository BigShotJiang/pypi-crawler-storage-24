"""
Processing API
==============
Public functions for managing pre-process and post-process functions on agents.
"""

from __future__ import annotations
import ast
from pathlib import Path
from typing import Optional
from uuid import UUID

from agentsflow.constants import (
    AGENTS_DIR,
    DEFAULT_POSTPROCESS_FUNCTION_NAME,
    DEFAULT_POSTPROCESS_PATH,
    DEFAULT_PREPROCESS_FUNCTION_NAME,
    DEFAULT_PREPROCESS_PATH,
)
from agentsflow.dev.agent_api import _resolve_agent_context
from agentsflow.utils.config_io import _write_agent_config
from agentsflow.dev.helper.processing_helper import (
    _add_default_postprocess,
    _add_default_preprocess,
    _delete_process,
    _read_process,
)
from agentsflow.schema.agent_config_schema import (
    AgentConfig,
    ProcessingConfig,
)
from agentsflow.utils.paths import normalize_agent_relative_path, resolve
from agentsflow.validate.agent import validate_agent_pre_post_process

# ── Preprocess ────────────────────────────────────────────────


def add_preprocess(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Add a preprocess function to an agent.

    This creates the default preprocess script and config entry. Use
    ``edit_preprocess(..., script=...)`` to replace the generated template.

    Args:
        base_dir:       Base agents directory.
        agent_name:     Agent name.
        agent_id:       Agent id.

    Returns:
        Updated agent config.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)

    if agent_config.preprocess_config:
        raise ValueError(
            f"Agent {agent_config.identity.name} already has a preprocess. Use edit_preprocess() instead."
        )
    try:
        agent_config = _add_default_preprocess(
            agent_dir=agent_dir,
            agent_config=agent_config,
            default_preprocess_path=DEFAULT_PREPROCESS_PATH,
            default_preprocess_function_name=DEFAULT_PREPROCESS_FUNCTION_NAME
        )
    except Exception as e:
        raise ValueError(f"Could not add preprocess: {e}")
    validate_agent_pre_post_process(agent_config, agent_dir)
    _write_agent_config(agent_dir, agent_config)
    return agent_config


def edit_preprocess(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
    script: Optional[str] = None
    ) -> AgentConfig:
    """
    Replace the preprocess script of an agent.

    Args:
        base_dir:       Base agents directory.
        agent_name:     Agent name.
        agent_id:       Agent id.
        script:  New script (if changing).

    Returns:
        Updated agent config.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)

    if not script:
        raise ValueError("Script is required")

    try:
        ast.parse(script)
    except SyntaxError as e:
        raise ValueError(f"Invalid Python syntax in preprocess script: {e}")

    try:
        preprocess_path = agent_dir / DEFAULT_PREPROCESS_PATH
        preprocess_path.write_text(script, encoding="utf-8")
        agent_config.preprocess_config = ProcessingConfig(
            path=DEFAULT_PREPROCESS_PATH,
            function_name=DEFAULT_PREPROCESS_FUNCTION_NAME
        )
    except Exception as e:
        raise ValueError(f"Could not edit preprocess: {e}")
    validate_agent_pre_post_process(agent_config, agent_dir)
    _write_agent_config(agent_dir, agent_config)
    return agent_config

def remove_preprocess(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Remove the preprocess function from an agent.

    Args:
        base_dir:   Base agents directory.
        agent_name: Agent name.
        agent_id:   Agent id.

    Returns:
        Updated agent config.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    if not agent_config.preprocess_config:
        raise ValueError("Agent does not have a preprocess")
    agent_config.preprocess_config = None
    if not (agent_dir / DEFAULT_PREPROCESS_PATH).exists():
        raise ValueError(f"Preprocess file {DEFAULT_PREPROCESS_PATH} does not exist")
    _delete_process(agent_dir / DEFAULT_PREPROCESS_PATH)
    _write_agent_config(agent_dir, agent_config)
    return agent_config

def get_preprocess_script(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> str:
    """
    Get the preprocess script of an agent.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    if not agent_config.preprocess_config:
        raise ValueError("Agent does not have a preprocess")
    return _read_process(agent_dir / agent_config.preprocess_config.path)
# ── Postprocess ───────────────────────────────────────────────


def add_postprocess(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Add a postprocess function to an agent.

    This creates the default postprocess script and config entry. Use
    ``edit_postprocess(..., script=...)`` to replace the generated template.

    Args:
        base_dir:       Base agents directory.
        agent_name:     Agent name.
        agent_id:       Agent id.

    Returns:
        Updated agent config.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)

    if agent_config.postprocess_config:
        raise ValueError(
            f"Agent {agent_config.identity.name} already has a postprocess. Use edit_postprocess() instead."
        )
    
    try:
        agent_config = _add_default_postprocess(
            agent_dir=agent_dir,
            agent_config=agent_config,
            default_postprocess_path=DEFAULT_POSTPROCESS_PATH,
            default_postprocess_function_name=DEFAULT_POSTPROCESS_FUNCTION_NAME
        )
    except Exception as e:
        raise ValueError(f"Could not add postprocess: {e}")

    validate_agent_pre_post_process(agent_config, agent_dir)
    _write_agent_config(agent_dir, agent_config)
    return agent_config


def edit_postprocess(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
    script: Optional[str] = None
) -> AgentConfig:
    """
    Replace the postprocess script of an agent.

    Args:
        base_dir:       Base agents directory.
        agent_name:     Agent name.
        agent_id:       Agent id.
        script:  New script (if changing).

    Returns:
        Updated agent config.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)

    if not script:
        raise ValueError("Script is required")

    try:
        ast.parse(script)
    except SyntaxError as e:
        raise ValueError(f"Invalid Python syntax in postprocess script: {e}")

    try:
        postprocess_path = agent_dir / DEFAULT_POSTPROCESS_PATH
        postprocess_path.write_text(script, encoding="utf-8")
    except Exception as e:
        raise ValueError(f"Could not edit postprocess: {e}")
    validate_agent_pre_post_process(agent_config, agent_dir)
    _write_agent_config(agent_dir, agent_config)
    return agent_config

def remove_postprocess(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Remove the postprocess function from an agent.

    Args:
        base_dir:   Base agents directory.
        agent_name: Agent name.
        agent_id:   Agent id.

    Returns:
        Updated agent config.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    if not agent_config.postprocess_config:
        raise ValueError("Agent does not have a postprocess")
    agent_config.postprocess_config = None
    if not (agent_dir / DEFAULT_POSTPROCESS_PATH).exists():
        raise ValueError(f"Postprocess file {DEFAULT_POSTPROCESS_PATH} does not exist")
    _delete_process(agent_dir / DEFAULT_POSTPROCESS_PATH)
    _write_agent_config(agent_dir, agent_config)
    return agent_config


def get_postprocess_script(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> str:
    """
    Get the postprocess function of an agent.
    """
    _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    if not agent_config.postprocess_config:
        raise ValueError("Agent does not have a postprocess")
    return _read_process(agent_dir / agent_config.postprocess_config.path)