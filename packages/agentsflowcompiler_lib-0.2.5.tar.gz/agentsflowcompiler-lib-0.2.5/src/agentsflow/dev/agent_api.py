"""
Agent API
=========
Public functions for CRUD operations on agents.

Path convention
---------------
All paths stored in config.yaml are **relative to the agent directory**.
The SDK always normalises absolute paths to relative on read/write.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID

from agentsflow.errors import AgentsFlowConfigError
from agentsflow.schema.agent_config_schema import (
    AgentConfig,
    AgentModelConfig,
    ApiKeyConfig,
    LogsConfig,
    Prompt,
    RetryConfig,
)
from agentsflow.dev.helper.agent_helper import (
    _build_agent_identity,
    _build_agent_model_config,
    _build_api_key_config,
    _build_logs_config,
    _build_prompt_config,
    _get_agent_config_by_id,
    _get_agent_config_by_name,
    _update_agent_identity,
    _update_agent_model_config,
    _update_agent_prompt_config,
    _update_logs_config,
    _update_api_key_config
)
from agentsflow.utils.manifest_io import _load_all_agents_from_manifest
from agentsflow.utils.config_io import _write_agent_config
from agentsflow.utils.fs import (
    create_agent_dir,
    delete_agent_dir,
)
from agentsflow.utils.paths import to_relative
from agentsflow.validate.agent import validate_agent as validate_agent_config_state
from agentsflow.constants import (
    AGENTS_DIR,
)
from agentsflow.utils.manifest_io import (
    register_agent as _register_in_manifest,
    unregister_agent as _unregister_from_manifest,
)
from agentsflow.dev.helper.prod_sync_helper import (
    load_agent_prompts,
    sync_processing_to_prod,
    sync_tools_to_prod,
)
# ── Constants ────────────────────────────────────────────────────────────────

DEFAULT_TEMPERATURE = 0.0


def _resolve_base_dir(base_dir: Path) -> Path:
    """Normalize DEV API filesystem roots to Path once at the boundary."""
    return Path(base_dir)


def _resolve_agent_context(
    base_dir: Path,
    agent_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
) -> tuple[Path, AgentConfig, Path]:
    """Load an agent config and its directory from a DEV base directory."""
    resolved_base_dir = _resolve_base_dir(base_dir)
    agent_config = get_agent_config(resolved_base_dir, agent_id, agent_name)
    agent_dir = resolved_base_dir / AGENTS_DIR / agent_config.identity.name
    return resolved_base_dir, agent_config, agent_dir


# ── Public API ───────────────────────────────────────────────────────────────


def create_agent(
    base_dir: Path,
    agent_name: str,
    model_config: AgentModelConfig,
    description: str = "",
    prompts: Optional[Prompt] = None,
    logs_config: Optional[LogsConfig] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Create a new agent directory with config and optional prompts.

    Creates::

        {base_dir}/agents/{agent_name}/
        ├── config.yaml
        ├── prompts/              (if prompts provided)
        └── logs/
            ├── run_history/
            ├── audit_logs/
            ├── prompt_history/
            └── token_usage/

    All paths stored in config.yaml are relative to the agent directory.

    Args:
        base_dir:     Base agents directory.
        agent_name:   Name of the new agent.
        model_config: Model + API key configuration (:class:`AgentModelConfig`).
        description:  Human-readable description.
        prompts:      Optional prompt content (:class:`Prompt`).
        logs_config:  Optional custom log directories (:class:`LogsConfig`).
        agent_id:     Optional explicit UUID for the agent.

    Returns:
        AgentConfig for the newly created agent.

    Raises:
        FileExistsError: If an agent with this name already exists.
    """
    base_dir = _resolve_base_dir(base_dir)
    agent_dir = base_dir / AGENTS_DIR / agent_name

    effective_logs = logs_config or LogsConfig()
    # Normalise paths → always relative to agent_dir before building config
    effective_logs = _build_logs_config(
        run_history_dir=to_relative(effective_logs.run_history_dir, agent_dir),
        audit_logs_dir=to_relative(effective_logs.audit_logs_dir, agent_dir),
        prompt_history_dir=to_relative(effective_logs.prompt_history_dir, agent_dir),
        token_usage_dir=to_relative(effective_logs.token_usage_dir, agent_dir),
    )

    create_agent_dir(agent_dir, effective_logs)
    identity = _build_agent_identity(agent_name, description, agent_id)
    prompt_config = _build_prompt_config(
        agent_dir,
        prompts.instruction if prompts else None,
        prompts.think if prompts else None,
        prompts.return_prompt if prompts else None,
        prompts.example if prompts else None,
        prompts.next_model_rule if prompts else None,
    )

    agent_config = AgentConfig(
        identity=identity,
        model_settings=model_config,
        prompt_config=prompt_config,
        logs_config=effective_logs,
    )
    _write_agent_config(agent_dir, agent_config)
    _register_in_manifest(base_dir, agent_name, identity.agent_id)

    return agent_config



def edit_agent(
    base_dir: Path,
    agent_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
    new_agent_name: Optional[str] = None,
    description: Optional[str] = None,
    model: Optional[str] = None,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    timeout: Optional[float] = None,
    retry_config: Optional[RetryConfig] = None,
    api_key_config: Optional[ApiKeyConfig] = None,
    prompts: Optional[Prompt] = None,
    logs_config: Optional[LogsConfig] = None,
) -> AgentConfig:
    """
    Edit fields in an existing agent's config.

    Pass only the arguments you want to change; everything else is preserved.

    Args:
        base_dir:       Base agents directory.
        agent_id:       Agent UUID (alternative to agent_name).
        agent_name:     Agent name (alternative to agent_id).
        new_agent_name: Rename the agent (moves its directory).
        description:    New description.
        model:          New model identifier.
        temperature:    New sampling temperature.
        max_tokens:     New max output tokens.
        timeout:        New timeout in seconds.
        retry_config:   New retry policy (:class:`RetryConfig`).
        api_key_config: Replace API key settings (:class:`ApiKeyConfig`).
        prompts:        Update prompts — only non-None fields are written (:class:`Prompt`).
        logs_config:    Replace log directory paths (:class:`LogsConfig`).
    """
    base_dir, agent_config, _ = _resolve_agent_context(base_dir, agent_id, agent_name)

    # Identity may rename the agent directory, so resolve agent_dir after update.
    agent_config.identity = _update_agent_identity(
        base_dir, agent_config.identity, new_agent_name, description
    )
    agent_dir = base_dir / AGENTS_DIR / agent_config.identity.name

    # API key — full replacement when provided
    if api_key_config is not None:
        agent_config.model_settings.api_key_config = api_key_config

    # Model fields — partial update (None = keep existing)
    agent_config.model_settings = _update_agent_model_config(
        agent_config.model_settings,
        model,
        temperature,
        max_tokens,
        timeout,
        retry_config,
    )

    # Prompts — only non-None fields are written to disk
    if prompts is not None:
        agent_config.prompt_config = _update_agent_prompt_config(
            agent_config.prompt_config, agent_dir,
            prompts.instruction, prompts.think, prompts.return_prompt,
            prompts.example, prompts.next_model_rule,
        )

    # Logs — normalise to relative before storing
    if logs_config is not None:
        agent_config.logs_config = _update_logs_config(
            agent_dir,
            agent_config.logs_config,
            to_relative(logs_config.run_history_dir, agent_dir) if logs_config.run_history_dir else None,
            to_relative(logs_config.audit_logs_dir, agent_dir) if logs_config.audit_logs_dir else None,
            to_relative(logs_config.prompt_history_dir, agent_dir) if logs_config.prompt_history_dir else None,
            to_relative(logs_config.token_usage_dir, agent_dir) if logs_config.token_usage_dir else None,
        )

    _write_agent_config(agent_dir, agent_config)
    return agent_config

def delete_agent(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> bool:
    """
    Delete an agent (directory + manifest entry).

    Returns:
        True if deleted successfully.

    Raises:
        ValueError: If neither agent_id nor agent_name is provided.
        FileNotFoundError: If the agent directory does not exist.
    """
    if agent_id is None and agent_name is None:
        raise ValueError("Either agent_id or agent_name must be provided")

    base_dir, agent_config, agent_dir = _resolve_agent_context(
        base_dir, agent_id, agent_name
    )

    if not agent_dir.exists():
        raise FileNotFoundError(f"Agent directory not found: {agent_dir}")

    delete_agent_dir(agent_dir)
    _unregister_from_manifest(base_dir, agent_config.identity.agent_id)
    return True


def duplicate_agent(
    base_dir: Path,
    new_name: str,
    source_name: Optional[str] = None,
    source_id: Optional[UUID] = None,
    api_key_config: Optional[ApiKeyConfig] = None,
) -> AgentConfig:
    """
    Duplicate an existing agent under a new name.

    Logs are reset in the duplicate; all other config is copied.

    Args:
        base_dir:       Base agents directory.
        new_name:       Name for the new agent.
        source_name:    Name of the agent to copy (alternative to source_id).
        source_id:      UUID of the agent to copy (alternative to source_name).
        api_key_config: API key for the duplicate. Defaults to empty (no key).
                        Pass ``source_config.model_settings.api_key_config`` to copy the source key.

    Returns:
        AgentConfig for the new agent.

    Raises:
        ValueError: If neither source_id nor source_name is provided.
    """
    if source_id is None and source_name is None:
        raise ValueError("Either source_id or source_name must be provided")

    from agentsflow.dev.helper.duplicate_helper import _duplicate_agent

    base_dir = _resolve_base_dir(base_dir)
    source_config = get_agent_config(base_dir, source_id, source_name)
    effective_api_key_config = api_key_config or ApiKeyConfig()
    return _duplicate_agent(base_dest_dir=base_dir, base_source_dir=base_dir, new_name=new_name, agent_config=source_config, api_key_config=effective_api_key_config)

def validate_agent(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> None:
    """Validate an agent and raise ``AgentsFlowConfigError`` on failure."""
    try:
        _, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
        validate_agent_config_state(agent_config, agent_dir)
    except Exception as e:
        raise AgentsFlowConfigError(f"Agent validation failed: {e}") from e
    return None


def get_agent_config(
    base_dir: Path,
    agent_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
) -> AgentConfig:
    """
    Retrieve an AgentConfig by ID or name.

    Raises:
        ValueError: If neither argument is provided.
    """
    base_dir = _resolve_base_dir(base_dir)
    if agent_id is not None:
        return _get_agent_config_by_id(base_dir, agent_id)
    if agent_name is not None:
        return _get_agent_config_by_name(base_dir, agent_name)
    raise ValueError("Either agent_id or agent_name must be provided")


def get_all_agents(base_dir: Path) -> List[AgentConfig]:
    """
    List all agents in a project.

    Args:
        base_dir: Base directory.

    Returns:
        List of :class:`AgentConfig` objects, one per registered agent.

    Raises:
        AgentsFlowConfigError: If the manifest cannot be read or a config file is missing.
    """
    base_dir = _resolve_base_dir(base_dir)
    try:
        agents = _load_all_agents_from_manifest(base_dir)
    except Exception as e:
        raise AgentsFlowConfigError(
            f"Failed to load all agents from manifest: {e}"
        ) from e

    return agents

def push_agent_to_prod(
    base_dev_dir: Path,
    base_prod_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
    api_key_config: Optional[ApiKeyConfig] = None,
) -> AgentConfig:
    """
    Push an agent from a DEV base directory into a PROD base directory.

    Args:
        base_dev_dir:   Source DEV base directory.
        base_prod_dir:  Destination PROD base directory.
        agent_name:     Agent name (alternative to agent_id).
        agent_id:       Agent UUID (alternative to agent_name).
        api_key_config: API key for the PROD copy. Defaults to empty (no key).
    """
    from agentsflow.dev.helper.duplicate_helper import _duplicate_agent

    base_dev_dir = _resolve_base_dir(base_dev_dir)
    base_prod_dir = _resolve_base_dir(base_prod_dir)
    agent_config = get_agent_config(base_dev_dir, agent_id, agent_name)
    effective_api_key_config = api_key_config or ApiKeyConfig()
    try:
        agent_prod_config = get_agent_config(base_prod_dir, agent_config.identity.agent_id)
    except FileNotFoundError:
        agent_prod_config = None
    if agent_prod_config is None:
        agent_prod_config = _duplicate_agent(
            base_dest_dir=base_prod_dir,
            base_source_dir=base_dev_dir,
            new_name=agent_config.identity.name,
            agent_config=agent_config,
            api_key_config=effective_api_key_config,
            agent_id=agent_config.identity.agent_id,
        )
        return agent_prod_config
    else:
        prompts = load_agent_prompts(agent_config.prompt_config, agent_dir=base_dev_dir / AGENTS_DIR / agent_config.identity.name)
        agent_prod_config = edit_agent(
            base_dir=base_prod_dir,
            agent_id=agent_config.identity.agent_id,
            new_agent_name=agent_config.identity.name,
            description=agent_config.identity.description,
            model=agent_config.model_settings.model,
            temperature=agent_config.model_settings.temperature,
            max_tokens=agent_config.model_settings.max_tokens,
            retry_config=agent_config.model_settings.retry_config,
            prompts=prompts,
        )
        sync_tools_to_prod(base_prod_dir, base_dev_dir, agent_config, agent_prod_config)
        sync_processing_to_prod(base_prod_dir, base_dev_dir, agent_config, agent_prod_config)
        return agent_prod_config
def get_agent_prompts(base_dir: Path, agent_name: Optional[str] = None, agent_id: Optional[UUID] = None) -> Prompt:
    """
    Retrieve the prompts for an agent.

    Args:
        base_dir: Base directory.
        agent_name: Agent name.

    Returns:
        List of prompts.            
    """
    base_dir, agent_config, agent_dir = _resolve_agent_context(base_dir, agent_id, agent_name)
    if agent_config.prompt_config is None:
        return Prompt()
    return load_agent_prompts(agent_config.prompt_config, agent_dir=agent_dir)