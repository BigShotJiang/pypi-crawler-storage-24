"""
AgentsFlow Error Hierarchy
==========================
Custom exceptions for SDK-wide failures and LLM API failures.
"""

from __future__ import annotations

from typing import Optional


class AgentsFlowError(Exception):
    """Base exception for all agentsflow SDK failures."""


class AgentsFlowConfigError(AgentsFlowError):
    """Invalid configuration, validation, or persistence failure."""


class AgentsFlowLogError(AgentsFlowError):
    """Log or monitoring data could not be read or persisted."""


class AgentsFlowToolError(AgentsFlowError):
    """Tool execution failed during an agent run."""


class DockerExecutionError(AgentsFlowToolError):
    """Raised when Docker tool execution fails (timeout, container crash, etc.)."""


class MaxToolRoundsError(AgentsFlowError):
    """Agent exceeded MAX_TOOL_ROUNDS without a final answer."""


class LLMProviderError(AgentsFlowError):
    """Base exception for all LLM provider failures."""

    def __init__(
        self,
        message: str,
        cause: Exception | None = None,
        rid: Optional[str] = None,
        provider_request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.__cause__ = cause
        self.rid = rid
        self.provider_request_id = provider_request_id

    def __str__(self) -> str:
        base = super().__str__()
        parts = []
        if self.rid:
            parts.append(f"rid={self.rid}")
        if self.provider_request_id:
            parts.append(f"request_id={self.provider_request_id}")
        if parts:
            return f"{base} ({', '.join(parts)})"
        return base


class LLMAuthenticationError(LLMProviderError):
    """401/403 — invalid or expired API key. Do not retry."""


class LLMInvalidRequestError(LLMProviderError):
    """400 — bad request, invalid parameters. Do not retry."""


class LLMRateLimitError(LLMProviderError):
    """429 — rate limit exceeded. Retry with backoff."""


class LLMServerError(LLMProviderError):
    """500/502/503 — server-side failure. Retry with backoff."""
