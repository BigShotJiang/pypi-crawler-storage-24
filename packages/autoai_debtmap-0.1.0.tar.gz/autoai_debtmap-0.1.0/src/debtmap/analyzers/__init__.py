"""Static analysis modules for technical debt detection."""

from .complexity import ComplexityAnalyzer
from .coupling import CouplingAnalyzer
from .duplication import DuplicationAnalyzer
from .dead_code import DeadCodeAnalyzer
from .test_coverage import TestCoverageAnalyzer
from .dependency_age import DependencyAgeAnalyzer
from .documentation import DocumentationAnalyzer

__all__ = [
    "ComplexityAnalyzer",
    "CouplingAnalyzer",
    "DuplicationAnalyzer",
    "DeadCodeAnalyzer",
    "TestCoverageAnalyzer",
    "DependencyAgeAnalyzer",
    "DocumentationAnalyzer",
]
