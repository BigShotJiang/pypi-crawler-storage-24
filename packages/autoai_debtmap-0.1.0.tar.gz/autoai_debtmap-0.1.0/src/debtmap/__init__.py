"""DebtMap — Technical Debt Intelligence.

Connect code quality to business impact. Score, prioritize, and track
technical debt with real static analysis and ROI-based prioritization.
"""

__version__ = "0.1.0"
