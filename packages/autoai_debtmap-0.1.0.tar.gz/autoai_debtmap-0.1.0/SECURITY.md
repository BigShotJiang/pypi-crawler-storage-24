# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in DebtMap, please report it responsibly.

**Email**: security@autoailabs.co.uk

Please include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

We will acknowledge receipt within 48 hours and provide a detailed response within 7 days.

## Security Design

- DebtMap runs **locally only** — no data leaves your machine unless you configure an external store
- SQLite database is stored in `~/.debtmap/` with user-only permissions (0600)
- No credentials are collected or stored
- MCP server binds to localhost only
- All file system access is read-only during scans (only the SQLite store is written to)

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | Yes       |

## Dependencies

We pin major versions and audit dependencies regularly. Run `pip audit` to check for known vulnerabilities.
