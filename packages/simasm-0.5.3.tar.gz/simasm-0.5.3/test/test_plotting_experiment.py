"""
Full end-to-end test of the automatic plotting feature.

This test:
1. Creates a simple SimASM model
2. Runs an experiment with generate_plots: true
3. Verifies that plots are generated
"""

import pytest
from pathlib import Path


@pytest.mark.skip(reason="Integration test - run manually with: python -m pytest test/test_plotting_experiment.py -v --no-header -rN")
def test_plotting_experiment(tmp_path):
    """End-to-end test of the automatic plotting feature."""
    from simasm.experimenter.engine import ExperimenterEngine

    # Create a simple test model
    test_model = """
// Simple counting model for testing
model CountingModel:
    state:
        count: Nat := 0
        time_left: Real := 100.0
    endstate

    transition Increment:
        guard: time_left > 0
        effect:
            count := count + 1
            time_left := time_left - 1.0
        endeffect
    endtransition

    initial:
        schedule Increment at 0
    endinitial
endmodel
"""

    # Write model to file
    model_path = tmp_path / "test_counting_model.simasm"
    model_path.write_text(test_model)

    # Create experiment specification
    test_experiment = f"""
experiment PlottingDemo:
    model := "{model_path}"

    replication:
        count: 5
        warm_up_time: 10.0
        run_length: 100.0
        seed_strategy: "incremental"
        base_seed: 42
        generate_plots: true
        trace_interval: 5.0
    endreplication

    statistics:
        stat counter: time_average
            expression: "count"
            trace: true
        endstat

        stat time_remaining: time_average
            expression: "time_left"
            trace: true
        endstat
    endstatistics

    output:
        format: "json"
        file_path: "results.json"
    endoutput
endexperiment
"""

    exp_path = tmp_path / "test_plotting_experiment.simasm"
    exp_path.write_text(test_experiment)

    # Run experiment
    engine = ExperimenterEngine(str(exp_path))
    result = engine.run()

    assert result.num_replications == 5
    assert len(result.summary) > 0
