"""Fortinet device detection patterns."""
