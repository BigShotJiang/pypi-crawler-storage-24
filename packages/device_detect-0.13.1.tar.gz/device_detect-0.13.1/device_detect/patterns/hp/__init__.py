"""HP device patterns."""
