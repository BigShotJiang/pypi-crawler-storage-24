import re
from dataclasses import dataclass
from typing import List, Optional
from dprojectstools.console import Sequences

# ---- Token model ----
@dataclass(frozen=True)
class Token:
    kind: str   # "indent" | "comment" | "key" | "eq" | "value" | "enc" | "ws" | "other"
    text: str

# ---- Regexes (simple, not quote-aware) ----

_RX_COMMENT_LINE = re.compile(r"^\s*#.*$")
_RX_ASSIGN = re.compile(r"^(\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*)=(\s*)(.*)$")
_RX_ENC = re.compile(r"\benc(?::v\d+)?:")  # enc: or enc:v1: etc.

def tokenize_env_line(line: str) -> List[Token]:
    """
    Mini-tokenizer for .env lines.
    Goals:
      - Identify KEY=VALUE assignments
      - Identify full-line comments
      - Highlight the first enc marker within the value
    Non-goals:
      - Perfect handling of quoted values / escaped # / export prefix
      - Multiline values

    Returns list[Token].
    """
    # Preserve newline as part of the last token if present
    nl = ""
    if line.endswith("\n"):
        line, nl = line[:-1], "\n"

    # Full-line comment
    if _RX_COMMENT_LINE.match(line):
        return [Token("comment", line + nl)]

    m = _RX_ASSIGN.match(line)
    if not m:
        # Not an assignment; treat as "other"
        return [Token("other", line + nl)]

    indent, key, pre_eq_ws, post_eq_ws, rhs = m.groups()

    tokens: List[Token] = []
    if indent:
        tokens.append(Token("indent", indent))
    tokens.append(Token("key", key))
    if pre_eq_ws:
        tokens.append(Token("ws", pre_eq_ws))
    tokens.append(Token("eq", "="))
    if post_eq_ws:
        tokens.append(Token("ws", post_eq_ws))

    # Best-effort inline comment: split on first " #" or "\t#"
    comment_idx: Optional[int] = None
    for pat in (" #", "\t#"):
        idx = rhs.find(pat)
        if idx != -1 and (comment_idx is None or idx < comment_idx):
            comment_idx = idx + 1  # keep the leading whitespace before '#'

    if comment_idx is None:
        value_part = rhs
        comment_part = ""
    else:
        value_part = rhs[:comment_idx]
        comment_part = rhs[comment_idx:]

    # Tokenize value_part with enc marker (first occurrence only)
    m_enc = _RX_ENC.search(value_part)
    if not m_enc:
        tokens.append(Token("value", value_part))
    else:
        a, b = m_enc.span()
        if a > 0:
            tokens.append(Token("value", value_part[:a]))
        tokens.append(Token("enc", value_part[a:b]))
        if b < len(value_part):
            tokens.append(Token("value", value_part[b:]))

    if comment_part:
        tokens.append(Token("comment", comment_part))

    if nl:
        # Attach newline to the last token so rendering preserves lines
        last = tokens[-1]
        tokens[-1] = Token(last.kind, last.text + nl)

    return tokens


def tokenize_env(text: str) -> List[List[Token]]:
    """Tokenize a whole .env file into tokens per line."""
    return [tokenize_env_line(line) for line in text.splitlines(keepends=True)]

def hightlight_env(line: str) -> str:
    result = []
    for token in tokenize_env_line(line):
        # "indent" | "comment" | "key" | "eq" | "value" | "enc" | "ws" | "other"
        if token.kind == "comment":
            result.append(Sequences.FG_BRIGHT_GREEN + token.text + Sequences.RESET)
        elif token.kind == "key":
            result.append(Sequences.FG_CYAN + token.text + Sequences.RESET)
        elif token.kind == "enc":
            result.append(Sequences.FG_BRIGHT_BLUE + token.text)
        elif token.kind == "value":
            result.append(token.text + Sequences.RESET)
        else:
            result.append(token.text)
    return "".join(result)