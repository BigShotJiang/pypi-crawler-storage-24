import re
from dataclasses import dataclass
from typing import List, Optional
from dprojectstools.console import Sequences

# ---- Token model ----
@dataclass(frozen=True)
class Token:
    kind: str   # "text" | "heading" | "frontmatter_delim" | "frontmatter_key" | "fence" | "code" | "enc" | "comment"
    text: str

# ---- Regexes ----
_RX_HEADING = re.compile(r"^(\s{0,3})(#{1,6})(\s+)(.*)$")
_RX_FENCE   = re.compile(r"^(\s{0,3})(```+)(\s*)(.*)$")  # ```lang
_RX_FM_DELIM = re.compile(r"^\s*---\s*$")               # YAML frontmatter delimiter
_RX_FM_XVAULT = re.compile(r"^(\s*)(_xvault)(\s*:\s*)(.*)$")
_RX_ENC = re.compile(r"\benc(?::v\d+)?:")               # enc: or enc:v1: etc.

def _split_enc(text: str, base_kind: str = "text") -> List[Token]:
    """Split a string into tokens highlighting all enc markers."""
    out: List[Token] = []
    last = 0
    for m in _RX_ENC.finditer(text):
        a, b = m.span()
        if a > last:
            out.append(Token(base_kind, text[last:a]))
        out.append(Token("enc", text[a:b]))
        last = b
    if last < len(text):
        out.append(Token(base_kind, text[last:]))
    return out

@dataclass
class MdState:
    in_frontmatter: bool = False
    frontmatter_possible: bool = True   # only at top of file until first non-empty non-frontmatter line
    in_fence: bool = False
    fence_lang: str = ""

def tokenize_md_line(line: str, state: MdState) -> List[Token]:
    """
    Mini-tokenizer for Markdown lines with state.
    - Detects YAML frontmatter only at the top of file.
    - Detects fenced blocks ```lang (multi-line).
    - Highlights headings and enc markers.
    - Highlights inline code spans `...` (simple: not nested).
    """
    # Preserve newline as part of last token (same style as your env tokenizer)
    nl = ""
    if line.endswith("\n"):
        line, nl = line[:-1], "\n"

    tokens: List[Token] = []

    # --- FRONTMATTER detection (only at top) ---
    if state.frontmatter_possible:
        if not state.in_frontmatter:
            if _RX_FM_DELIM.match(line):
                state.in_frontmatter = True
                tokens.append(Token("frontmatter_delim", line + nl))
                return tokens
            # If first meaningful line is not '---', stop considering frontmatter
            if line.strip() != "":
                state.frontmatter_possible = False
        else:
            # we are inside frontmatter
            if _RX_FM_DELIM.match(line):
                state.in_frontmatter = False
                state.frontmatter_possible = False
                tokens.append(Token("frontmatter_delim", line + nl))
                return tokens

            # highlight _xvault: line specially
            mfm = _RX_FM_XVAULT.match(line)
            if mfm:
                indent, key, sep, rest = mfm.groups()
                if indent:
                    tokens.append(Token("text", indent))
                tokens.append(Token("frontmatter_key", key))
                tokens.append(Token("text", sep))
                # highlight enc markers inside value part
                tokens.extend(_split_enc(rest, base_kind="text"))
                if nl:
                    last = tokens[-1]
                    tokens[-1] = Token(last.kind, last.text + nl)
                return tokens

            # otherwise treat as frontmatter text (optionally highlight enc)
            tokens.extend(_split_enc(line, base_kind="text"))
            if nl:
                last = tokens[-1]
                tokens[-1] = Token(last.kind, last.text + nl)
            return tokens

    # --- FENCE detection (toggle in_fence) ---
    mf = _RX_FENCE.match(line)
    if mf:
        indent, ticks, sp, lang = mf.groups()
        # Toggle fence on/off
        if not state.in_fence:
            state.in_fence = True
            state.fence_lang = lang.strip()
        else:
            state.in_fence = False
            state.fence_lang = ""

        # Tokenize fence line
        if indent:
            tokens.append(Token("text", indent))
        tokens.append(Token("fence", ticks))
        tokens.append(Token("text", sp + lang))
        if nl:
            last = tokens[-1]
            tokens[-1] = Token(last.kind, last.text + nl)
        return tokens

    # --- Inside fenced block ---
    if state.in_fence:
        # For xvault blocks, highlight enc markers aggressively
        if state.fence_lang.startswith("xvault"):
            tokens.extend(_split_enc(line, base_kind="code"))
        else:
            tokens.append(Token("code", line))
        if nl:
            last = tokens[-1]
            tokens[-1] = Token(last.kind, last.text + nl)
        return tokens

    # --- Headings ---
    mh = _RX_HEADING.match(line)
    if mh:
        indent, hashes, sp, rest = mh.groups()
        if indent:
            tokens.append(Token("text", indent))
        tokens.append(Token("heading", hashes))
        tokens.append(Token("text", sp))
        # highlight enc markers in heading text if any (rare but fine)
        tokens.extend(_split_enc(rest, base_kind="heading"))
        if nl:
            last = tokens[-1]
            tokens[-1] = Token(last.kind, last.text + nl)
        return tokens

    # --- Inline code spans: split by backticks (simple) ---
    # This is not a full Markdown inline parser; it's good enough for highlighting secrets in `...`.
    parts = line.split("`")
    if len(parts) == 1:
        tokens.extend(_split_enc(line, base_kind="text"))
    else:
        for i, part in enumerate(parts):
            if i % 2 == 0:
                tokens.extend(_split_enc(part, base_kind="text"))
            else:
                # inside code span
                tokens.append(Token("code", "`"))
                tokens.extend(_split_enc(part, base_kind="code"))
                tokens.append(Token("code", "`"))

    if nl:
        last = tokens[-1]
        tokens[-1] = Token(last.kind, last.text + nl)

    return tokens


def tokenize_md(text: str) -> List[List[Token]]:
    """Tokenize a whole markdown text into tokens per line."""
    state = MdState()
    out: List[List[Token]] = []
    for line in text.splitlines(keepends=True):
        out.append(tokenize_md_line(line, state))
    return out



def hightlight_md(line: str) -> str:
    result = []
    state = MdState()
    for token in tokenize_md_line(line, state):
        # "text" | "heading" | "frontmatter_delim" | "frontmatter_key" | "fence" | "code" | "enc" | "comment"
        if token.kind == "comment":
            result.append(Sequences.FG_BRIGHT_GREEN + token.text + Sequences.RESET)
        elif token.kind == "heading":
            result.append(Sequences.FG_CYAN + token.text + Sequences.RESET)
        elif token.kind == "code":
            result.append(Sequences.FG_RED + token.text + Sequences.RESET)
        elif token.kind == "enc":
            result.append(Sequences.FG_BRIGHT_BLUE + token.text + Sequences.RESET)        
        else:
            result.append(token.text)
    return "".join(result)