from pathlib import Path
import os
import json
import keyring
import getpass
from typing import Annotated
from ..xeditor import XEditor
from ..crypto import aes_decrypt, aes_encrypt, password_generate
from .. import PATH_DPROJECTSTOOLS

# consts
KEYRING_APP = "dprojectstools"
PATH_DPROJECTSTOOLS_SECRETS = PATH_DPROJECTSTOOLS / "secrets"

# class
class SecretsManager():


    # vars
    _password = None
    _path = ""
    _dict = {}
    

    # ctr
    def __init__(self, dbname, password = "keyring:", create = False):
        folder = PATH_DPROJECTSTOOLS_SECRETS
        folder.mkdir(parents=True, exist_ok=True)
        self._path = Path(folder, dbname + ".json.aes")
        # validate
        if os.path.exists(self._path):
            if create:
                raise ValueError("Unable to create db: already exists:", dbname)
        else:
            if not create:
                raise ValueError("Unable to open db: db not found:", dbname)
        # password
        if password.startswith("keyring:"):
            username = password[password.index(":") + 1:]
            if username == "":
                username = getpass.getuser()
            password = keyring.get_password(KEYRING_APP, username)
            if password is None:
                password = password_generate()
                keyring.set_password(KEYRING_APP, username, password)
        self._password = password
        self._load()
        # save if required
        if create:
            self._save()


    # methods
    def get(self, name):
        return self._get_nested(self._dict, name);     
        value = self._dict.get(name)
        if value is None:
            value = self.set(name, value)
        return str(value)
    
    def keys(self):
        return self._dict.keys()
    
    def set(self, name, value=None):
        if value is None:
            value = getpass.getpass(prompt = "Enter secret '{0}' value: ".format(name))
        self._dict[name] = str(value)
        self._save()
        return value

    def delete(self, name):
        del self._dict[name]
        self._save()

    def edit(self):
        xeditor = XEditor()
        text = json.dumps(self._dict, indent=4)
        result = xeditor.editText(text, format = "json")
        if result != None:
            self._dict = json.loads(result)
            self._save()
            return True
        return False

    def to_json(self):
        return json.dumps(self._dict, indent=4)

    # static methods
    @staticmethod
    def get_db_names():
        folder = PATH_DPROJECTSTOOLS_SECRETS
        folder.mkdir(parents=True, exist_ok=True)
        files = [entry.name.replace(".json.aes", "") for entry in os.scandir(folder) if entry.is_file()]
        return files


    # private methods
    def _load(self):
        if os.path.isfile(self._path):
            with open(self._path, "r") as file:
                text = file.read()
                if not self._password is None:
                    text = aes_decrypt(text, self._password)
                self._dict = json.loads(text)
        pass

    def _save(self):
        text = json.dumps(self._dict, indent=4)
        if not self._password is None:
            text = aes_encrypt(text, self._password);
        with open(self._path, "w") as file:
            file.write(text)
    def _get_nested(self, dictionary, path, default=None):
        keys = path.split('.')
        current = dictionary
        for key in keys:
            if isinstance(current, dict):
                current = current.get(key, default)
            else:
                return default
        return current

    
    