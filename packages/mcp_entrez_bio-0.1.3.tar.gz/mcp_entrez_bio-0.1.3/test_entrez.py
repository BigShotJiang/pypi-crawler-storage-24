import sys
sys.path.insert(0, './src')

import asyncio
from mcp_entrez_bio.server import pubmed_esearch, pubmed_efetch_abstracts, mcp_entrez_prompt, pubmed_get_paper_metadata, pubmed_get_full_text_links

async def main():
    print("Testing MCP Entrez Bio...")
    
    # 1. Test Prompt
    print("\n--- Testing Prompt ---")
    prompt = mcp_entrez_prompt()
    print(f"Prompt Config:\n{len(prompt)} chars")

    # 2. Test ESearch
    print("\n--- Testing ESearch ---")
    query = "(lung cancer[Title/Abstract]) AND immunotherapy"
    print(f"Query: {query}")
    pmids = await pubmed_esearch(query=query, retmax=3)
    print(f"Found PMIDs: {pmids}")
    
    # 3. Test EFetch, Metadata and Links
    if pmids:
        test_pmid = pmids[0]
        print(f"\n--- Testing Tools for PMID {test_pmid} ---")
        
        abstracts = await pubmed_efetch_abstracts([test_pmid])
        print(f"Abstract Length: {len(abstracts.get(test_pmid, ''))}")
        
        metadata = await pubmed_get_paper_metadata(test_pmid)
        import json
        print(f"Metadata:\n{json.dumps(metadata, indent=2, ensure_ascii=False)}")
        
        links = await pubmed_get_full_text_links(test_pmid)
        print(f"Full Text Links:\n{json.dumps(links, indent=2, ensure_ascii=False)}")
    else:
        print("\nSkipping EFetch due to no PMIDs found.")

if __name__ == "__main__":
    asyncio.run(main())
