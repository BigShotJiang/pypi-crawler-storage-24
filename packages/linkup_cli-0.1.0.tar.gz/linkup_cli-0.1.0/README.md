# Linkup CLI

Official command-line interface for [Linkup](https://linkup.so) - AI-powered web search.

## Installation

```bash
pip install linkup-cli
```

## Quick Start

1. Get your API key at [app.linkup.so](https://app.linkup.so)

2. Set your API key:
```bash
export LINKUP_API_KEY="your-api-key"
```

3. Search:
```bash
linkup search "What is the capital of France?"
```

## Usage

### Search

```bash
# Basic search
linkup search "your query"

# Deep search (more thorough, better for complex queries)
linkup search "complex research topic" --deep

# Get raw search results instead of AI answer
linkup search "python tutorials" --results

# Short form
linkup s "your query" -d
```

### Fetch

Extract content from any URL:

```bash
linkup fetch "https://example.com"
```

### Configuration

Check your configuration:

```bash
linkup config
```

## Options

| Flag | Short | Description |
|------|-------|-------------|
| `--deep` | `-d` | Use deep search for complex queries |
| `--results` | `-r` | Return raw search results |
| `--version` | `-V` | Show version |
| `--help` | `-h` | Show help |

## Environment Variables

| Variable | Description |
|----------|-------------|
| `LINKUP_API_KEY` | Your Linkup API key (required) |

## Examples

```bash
# Quick facts
linkup search "population of tokyo"

# Research
linkup search "latest developments in quantum computing" --deep

# Get sources
linkup search "best python web frameworks" --results

# Extract article content
linkup fetch "https://example.com/article"
```

## Links

- [Linkup Website](https://linkup.so)
- [Documentation](https://docs.linkup.so)
- [Get API Key](https://app.linkup.so)
- [Python SDK](https://github.com/LinkupPlatform/linkup-python-sdk)

## License

MIT
