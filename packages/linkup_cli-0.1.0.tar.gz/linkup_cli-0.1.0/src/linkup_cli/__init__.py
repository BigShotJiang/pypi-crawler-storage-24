"""Linkup CLI - AI-powered web search from your terminal."""

__version__ = "0.1.0"
