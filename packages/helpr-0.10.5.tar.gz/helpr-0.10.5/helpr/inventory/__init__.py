"""
Inventory management module for direct Redis operations.

Provides atomic inventory reservation and release operations with sub-millisecond latency.
Used by orderbox (for order reservations) and storehouse (for ERP sync).
"""

from .client import InventoryClient
from .models import (
    ReserveResult,
    ReleaseResult,
    SetInventoryResult,
    InventoryState,
    InsufficientInventoryError,
)
from .repository import InventoryRepository

__all__ = [
    "InventoryClient",
    "ReserveResult",
    "ReleaseResult",
    "SetInventoryResult",
    "InventoryState",
    "InsufficientInventoryError",
    "InventoryRepository",
]
