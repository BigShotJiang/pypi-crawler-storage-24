//! Tests migrated from inline #[cfg(test)] module in src/embedded_data.rs

use cardgame::cards::Faction;
use cardgame::embedded_data::{
    get_mvp_deck_ids, load_embedded_cards,
    load_embedded_cards_with_commanders, load_embedded_decks, load_embedded_game_data,
};

#[test]
fn test_load_embedded_cards() {
    let card_db = load_embedded_cards().expect("Failed to load embedded cards");
    assert!(
        card_db.len() >= 300,
        "Expected at least 300 cards, got {}",
        card_db.len()
    );
}

#[test]
fn test_load_embedded_decks() {
    let registry = load_embedded_decks().expect("Failed to load embedded decks");
    assert!(registry.len() >= 12, "Expected at least 12 decks, got {}", registry.len());
}

#[test]
fn test_load_embedded_game_data() {
    let (cards, decks) = load_embedded_game_data().expect("Failed to load game data");
    assert!(cards.len() >= 300);
    assert!(decks.len() >= 12);
}

#[test]
fn test_mvp_decks_exist() {
    let registry = load_embedded_decks().expect("Failed to load decks");
    for deck_id in get_mvp_deck_ids() {
        assert!(
            registry.get(deck_id).is_some(),
            "MVP deck {} not found",
            deck_id
        );
    }
}

#[test]
fn test_all_decks_have_valid_ids() {
    // Verify every deck in the registry has a non-empty id and name.
    // This catches malformed TOML that parses but is logically empty.
    let registry = load_embedded_decks().expect("Failed to load decks");
    for deck in registry.decks() {
        assert!(!deck.id.is_empty(), "Deck has empty id");
        assert!(!deck.name.is_empty(), "Deck {} has empty name", deck.id);
        assert!(deck.commander > 0, "Deck {} has no commander", deck.id);
        assert!(!deck.cards.is_empty(), "Deck {} has no cards", deck.id);
    }
}

#[test]
fn test_load_embedded_cards_with_commanders() {
    let card_db =
        load_embedded_cards_with_commanders().expect("Failed to load embedded cards with commanders");

    assert!(
        card_db.len() >= 300,
        "Expected at least 300 cards, got {}",
        card_db.len()
    );

    let commander_count = card_db.commander_count();
    assert!(
        commander_count >= 12,
        "Expected at least 12 commanders, got {}",
        commander_count
    );

    let argentum_count = card_db
        .iter_commanders()
        .filter(|c| c.faction == Faction::Argentum)
        .count();
    let symbiote_count = card_db
        .iter_commanders()
        .filter(|c| c.faction == Faction::Symbiote)
        .count();
    let obsidion_count = card_db
        .iter_commanders()
        .filter(|c| c.faction == Faction::Obsidion)
        .count();

    assert!(argentum_count > 0, "Expected at least one Argentum commander");
    assert!(symbiote_count > 0, "Expected at least one Symbiote commander");
    assert!(obsidion_count > 0, "Expected at least one Obsidion commander");
}

#[test]
fn test_embedded_commanders_have_abilities() {
    let card_db =
        load_embedded_cards_with_commanders().expect("Failed to load cards with commanders");

    for commander in card_db.iter_commanders() {
        // Skip test-only commanders (e.g. Test Dummy Commander) which intentionally have no ability.
        if commander.name.contains("Test") || commander.name.contains("Dummy") {
            continue;
        }
        let has_passive = commander.has_passive();
        let has_triggered = commander.has_triggered();
        assert!(
            has_passive || has_triggered,
            "Commander {} has no abilities",
            commander.name
        );
    }
}
