//! Creature vs creature combat resolution.
//!
//! Handles combat between two creatures including all keyword interactions:
//! - Quick (first strike)
//! - Shield (damage absorption)
//! - Ranged (no counter-attack)
//! - Piercing (overflow damage to face)
//! - Lethal (instant kill on any damage)
//! - Lifesteal (heal for damage dealt)
//! - Fortify (damage reduction)

use crate::core::cards::{CardDatabase, LevelUpDefinition, LevelUpTrigger};
use crate::core::effects::Trigger;
use crate::core::engine::EffectQueue;
use crate::core::keywords::Keywords;
use crate::core::state::{Creature, GameState};
use crate::core::tracing::{CombatTrace, CombatTracer};
use crate::core::types::{PlayerId, Slot};

use super::death::{check_game_over, process_creature_death};
use super::face_attack::mark_attacked;
use super::triggers::trigger_creature_ability;
use super::CombatResult;

/// Resolve creature vs creature combat with all keyword interactions.
#[allow(clippy::too_many_arguments)]
pub fn resolve_creature_combat(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    defender_player: PlayerId,
    defender_slot: Slot,
    tracer: Option<&mut CombatTracer>,
) -> CombatResult {
    // Gather all creature stats and keywords before combat
    let mut attacker_stats = get_creature_stats(state, attacker_player, attacker_slot);
    let defender_stats = get_creature_stats(state, defender_player, defender_slot);

    // Apply Flanking bonus: +1 attack per occupied adjacent ally slot (max +2).
    // Suppressed by Silence (already reflected in flanking_active).
    if attacker_stats.flanking_active {
        let bonus = count_adjacent_allies(state, attacker_player, attacker_slot);
        attacker_stats.attack = attacker_stats.attack.saturating_add(bonus);
    }

    // Create trace if enabled
    let mut trace = create_combat_trace(
        tracer.as_ref(),
        attacker_player,
        attacker_slot,
        &attacker_stats,
        defender_player,
        defender_slot,
        &defender_stats,
    );

    // Log keyword checks
    log_keyword_checks(&mut trace, &attacker_stats, &defender_stats);

    // Trigger OnAttack effect before combat damage
    trigger_creature_ability(state, card_db, effect_queue, attacker_player, attacker_slot, Trigger::OnAttack);

    // Fire Ambush effects (defending player's prepared traps)
    let ambush_count = state.players[defender_player.index()]
        .prepared_effects
        .iter()
        .filter(|pe| pe.trigger == crate::core::state::PreparedTrigger::OnEnemyAttack)
        .count();

    if ambush_count > 0 {
        if let Some(ref mut t) = trace {
            t.add_step(crate::core::tracing::CombatStep::new(
                crate::core::tracing::CombatPhase::AmbushFire,
                format!("{} Ambush trap(s) fire at the attacking creature", ambush_count),
            ));
        }
    }

    crate::core::engine::turn::fire_ambush_effects(
        state, card_db, effect_queue,
        defender_player,
        attacker_player,
        attacker_slot,
    );

    // Resolve combat damage based on Quick keyword
    let mut result = resolve_combat_damage(
        state,
        attacker_player,
        attacker_slot,
        defender_player,
        defender_slot,
        &attacker_stats,
        &defender_stats,
    );

    // Log damage dealt
    if let Some(ref mut t) = trace {
        t.log_damage(result.attacker_damage_dealt, result.defender_damage_dealt);
    }

    // Apply Piercing: excess damage to face when defender dies
    apply_piercing(state, &attacker_stats, &defender_stats, &mut result, &mut trace);

    // Apply Lifesteal: heal for damage actually dealt to creatures
    apply_lifesteal_creature(state, attacker_player, &attacker_stats, &defender_stats, &mut result, &mut trace);

    // Track damage dealt to creatures
    state.players[attacker_player.index()].total_damage_dealt += result.attacker_damage_dealt as u16;

    // Mark attacker as having attacked
    mark_attacked(state, attacker_player, attacker_slot);

    // Trigger damage-related effects
    trigger_damage_effects(
        state,
        card_db,
        effect_queue,
        attacker_player,
        attacker_slot,
        defender_player,
        defender_slot,
        &result,
    );

    // Process deaths and trigger OnDeath/OnKill effects
    process_combat_deaths(
        state,
        card_db,
        effect_queue,
        attacker_player,
        attacker_slot,
        defender_player,
        defender_slot,
        &result,
    );

    // Check for game over
    check_game_over(state);

    // Post-check: Ambush effects apply synchronously before combat damage, so the attacker
    // may have died from Ambush even though combat_damage didn't record it.
    if !result.attacker_died
        && state.players[attacker_player.index()]
            .get_creature(attacker_slot)
            .is_none_or(|c| c.current_health <= 0)
    {
        result.attacker_died = true;
    }

    // Log completion and add trace to tracer
    if let Some(ref mut t) = trace {
        t.log_complete(result.attacker_died, result.defender_died);
    }
    if let (Some(tracer), Some(trace)) = (tracer, trace) {
        tracer.add_trace(trace);
    }

    result
}

/// Creature stats needed for combat resolution.
struct CreatureStats {
    attack: u8,
    health: i8,
    keywords: Keywords,
    /// Flanking is active when the creature has the FLANKING status bit and is not silenced.
    flanking_active: bool,
}

impl CreatureStats {
    fn has_quick(&self) -> bool {
        self.keywords.has_quick()
    }

    fn has_shield(&self) -> bool {
        self.keywords.has_shield()
    }

    fn has_ranged(&self) -> bool {
        self.keywords.has_ranged()
    }

    fn has_piercing(&self) -> bool {
        self.keywords.has_piercing()
    }

    fn has_lethal(&self) -> bool {
        self.keywords.has_lethal()
    }

    fn has_lifesteal(&self) -> bool {
        self.keywords.has_lifesteal()
    }
}

/// Get creature stats for combat.
fn get_creature_stats(state: &GameState, player: PlayerId, slot: Slot) -> CreatureStats {
    let creature = state.players[player.index()]
        .get_creature(slot)
        .expect("Creature must exist");
    let flanking_active = creature.status.has_flanking() && !creature.status.is_silenced();
    CreatureStats {
        attack: creature.attack.saturating_add(creature.temp_attack_bonus).max(0) as u8,
        health: creature.current_health,
        keywords: creature.keywords,
        flanking_active,
    }
}

/// Count ally creatures occupying slots adjacent to `slot` (max 2).
fn count_adjacent_allies(state: &GameState, player: PlayerId, slot: Slot) -> u8 {
    let adjacent = slot.adjacent_slots();
    state.players[player.index()].creatures.iter().filter(|c| {
        c.slot != slot && adjacent.contains(&c.slot)
    }).count() as u8
}

/// Create a combat trace if tracing is enabled.
fn create_combat_trace(
    tracer: Option<&&mut CombatTracer>,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    attacker_stats: &CreatureStats,
    defender_player: PlayerId,
    defender_slot: Slot,
    defender_stats: &CreatureStats,
) -> Option<CombatTrace> {
    tracer.and_then(|t| {
        if t.is_enabled() {
            Some(CombatTrace::new_creature_combat(
                attacker_player,
                attacker_slot,
                attacker_stats.attack as i8,
                attacker_stats.health,
                attacker_stats.keywords,
                defender_player,
                defender_slot,
                defender_stats.attack as i8,
                defender_stats.health,
                defender_stats.keywords,
            ))
        } else {
            None
        }
    })
}

/// Log keyword checks to the trace.
fn log_keyword_checks(
    trace: &mut Option<CombatTrace>,
    attacker_stats: &CreatureStats,
    defender_stats: &CreatureStats,
) {
    if let Some(ref mut t) = trace {
        t.log_quick_check(attacker_stats.has_quick(), defender_stats.has_quick());
        if attacker_stats.has_ranged() {
            t.log_ranged();
        }
        if attacker_stats.has_shield() {
            t.log_shield_check("Attacker", true);
        }
        if defender_stats.has_shield() {
            t.log_shield_check("Defender", true);
        }
    }
}

/// Resolve combat damage based on Quick keyword timing.
fn resolve_combat_damage(
    state: &mut GameState,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    defender_player: PlayerId,
    defender_slot: Slot,
    attacker_stats: &CreatureStats,
    defender_stats: &CreatureStats,
) -> CombatResult {
    let mut result = CombatResult::default();

    let attacker_has_quick = attacker_stats.has_quick();
    let defender_has_quick = defender_stats.has_quick();
    let attacker_has_ranged = attacker_stats.has_ranged();

    if attacker_has_quick && !defender_has_quick {
        // Attacker strikes first
        resolve_attacker_first(
            state,
            attacker_player,
            attacker_slot,
            defender_player,
            defender_slot,
            attacker_stats,
            defender_stats,
            attacker_has_ranged,
            &mut result,
        );
    } else if defender_has_quick && !attacker_has_quick {
        // Defender strikes first
        resolve_defender_first(
            state,
            attacker_player,
            attacker_slot,
            defender_player,
            defender_slot,
            attacker_stats,
            defender_stats,
            attacker_has_ranged,
            &mut result,
        );
    } else {
        // Simultaneous damage
        resolve_simultaneous(
            state,
            attacker_player,
            attacker_slot,
            defender_player,
            defender_slot,
            attacker_stats,
            defender_stats,
            attacker_has_ranged,
            &mut result,
        );
    }

    result
}

/// Resolve combat when attacker strikes first (has Quick, defender doesn't).
#[allow(clippy::too_many_arguments)]
fn resolve_attacker_first(
    state: &mut GameState,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    defender_player: PlayerId,
    defender_slot: Slot,
    attacker_stats: &CreatureStats,
    defender_stats: &CreatureStats,
    attacker_has_ranged: bool,
    result: &mut CombatResult,
) {
    let (damage_dealt, _, defender_died) = apply_combat_damage(
        state,
        defender_player,
        defender_slot,
        attacker_stats.attack,
        attacker_stats.has_lethal(),
        defender_stats.has_shield(),
    );

    result.attacker_damage_dealt = damage_dealt;
    result.defender_died = defender_died;

    // If defender survived, they counter-attack (unless attacker has Ranged)
    if !defender_died && !attacker_has_ranged {
        let (damage_dealt, _, attacker_died) = apply_combat_damage(
            state,
            attacker_player,
            attacker_slot,
            defender_stats.attack,
            defender_stats.has_lethal(),
            attacker_stats.has_shield(),
        );

        result.defender_damage_dealt = damage_dealt;
        result.attacker_died = attacker_died;
    }
}

/// Resolve combat when defender strikes first (has Quick, attacker doesn't).
#[allow(clippy::too_many_arguments)]
fn resolve_defender_first(
    state: &mut GameState,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    defender_player: PlayerId,
    defender_slot: Slot,
    attacker_stats: &CreatureStats,
    defender_stats: &CreatureStats,
    attacker_has_ranged: bool,
    result: &mut CombatResult,
) {
    // Defender strikes first, but only if attacker doesn't have Ranged
    if !attacker_has_ranged {
        let (damage_dealt, _, attacker_died) = apply_combat_damage(
            state,
            attacker_player,
            attacker_slot,
            defender_stats.attack,
            defender_stats.has_lethal(),
            attacker_stats.has_shield(),
        );

        result.defender_damage_dealt = damage_dealt;
        result.attacker_died = attacker_died;
    }

    // If attacker survived, they deal damage
    if !result.attacker_died {
        let (damage_dealt, _, defender_died) = apply_combat_damage(
            state,
            defender_player,
            defender_slot,
            attacker_stats.attack,
            attacker_stats.has_lethal(),
            defender_stats.has_shield(),
        );

        result.attacker_damage_dealt = damage_dealt;
        result.defender_died = defender_died;
    }
}

/// Resolve simultaneous combat damage (both have Quick or neither has Quick).
#[allow(clippy::too_many_arguments)]
fn resolve_simultaneous(
    state: &mut GameState,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    defender_player: PlayerId,
    defender_slot: Slot,
    attacker_stats: &CreatureStats,
    defender_stats: &CreatureStats,
    attacker_has_ranged: bool,
    result: &mut CombatResult,
) {
    // Apply attacker's damage to defender
    let (atk_damage_dealt, _, defender_died) = apply_combat_damage(
        state,
        defender_player,
        defender_slot,
        attacker_stats.attack,
        attacker_stats.has_lethal(),
        defender_stats.has_shield(),
    );

    result.attacker_damage_dealt = atk_damage_dealt;
    result.defender_died = defender_died;

    // Apply defender's counter-attack damage to attacker (unless Ranged)
    if !attacker_has_ranged {
        let (def_damage_dealt, _, attacker_died) = apply_combat_damage(
            state,
            attacker_player,
            attacker_slot,
            defender_stats.attack,
            defender_stats.has_lethal(),
            attacker_stats.has_shield(),
        );

        result.defender_damage_dealt = def_damage_dealt;
        result.attacker_died = attacker_died;
    }
}

/// Apply combat damage to a creature, handling Shield, Fortify, and Lethal keywords.
///
/// Returns (damage_dealt, was_blocked_by_shield, creature_died)
pub fn apply_combat_damage(
    state: &mut GameState,
    target_player: PlayerId,
    target_slot: Slot,
    damage: u8,
    attacker_has_lethal: bool,
    target_has_shield: bool,
) -> (u8, bool, bool) {
    if damage == 0 {
        return (0, false, false);
    }

    let creature = match state.players[target_player.index()].get_creature_mut(target_slot) {
        Some(c) => c,
        None => return (0, false, false),
    };

    if target_has_shield {
        // Shield absorbs the damage completely
        creature.keywords.remove(Keywords::SHIELD);
        // No damage dealt, Lethal doesn't trigger
        return (0, true, false);
    }

    // FORTIFY: Reduce damage by 1 (minimum 1 damage still dealt)
    let actual_damage = if creature.keywords.has_fortify() && damage > 1 {
        damage - 1
    } else {
        damage
    };

    // Apply damage (cap at 0 to prevent negative health)
    creature.current_health = (creature.current_health - actual_damage as i8).max(0);
    let died = creature.current_health == 0;

    // Apply Lethal: any non-zero damage kills
    if attacker_has_lethal && actual_damage > 0 && !died {
        creature.current_health = 0;
        return (actual_damage, false, true);
    }

    (actual_damage, false, died)
}

/// Apply Piercing overflow damage to face.
fn apply_piercing(
    state: &mut GameState,
    attacker_stats: &CreatureStats,
    defender_stats: &CreatureStats,
    result: &mut CombatResult,
    trace: &mut Option<CombatTrace>,
) {
    if attacker_stats.has_piercing() && result.defender_died && result.attacker_damage_dealt > 0 {
        let defender_health_before = defender_stats.health as u8;
        if attacker_stats.attack > defender_health_before {
            let excess = attacker_stats.attack - defender_health_before;
            let defender_player_idx = 1; // Defender is always opponent
            state.players[defender_player_idx].life =
                state.players[defender_player_idx].life.saturating_sub(excess as i16);
            result.face_damage = excess;

            // Track piercing damage dealt
            state.players[0].total_damage_dealt += excess as u16;

            if let Some(ref mut t) = trace {
                t.log_piercing(excess);
            }
        }
    }
}

/// Apply Lifesteal healing in creature combat.
fn apply_lifesteal_creature(
    state: &mut GameState,
    attacker_player: PlayerId,
    attacker_stats: &CreatureStats,
    defender_stats: &CreatureStats,
    result: &mut CombatResult,
    trace: &mut Option<CombatTrace>,
) {
    if attacker_stats.has_lifesteal() && result.attacker_damage_dealt > 0 {
        // Heal for damage dealt to the creature (not piercing overflow)
        // Cap the heal at the defender's health before combat
        let heal_amount = result.attacker_damage_dealt.min(defender_stats.health.max(0) as u8);
        if heal_amount > 0 {
            let current_life = state.players[attacker_player.index()].life;
            let new_life = (current_life + heal_amount as i16).min(30);
            let actual_heal = (new_life - current_life) as u8;
            state.players[attacker_player.index()].life = new_life;
            result.attacker_healed = actual_heal;

            if let Some(ref mut t) = trace {
                t.log_lifesteal(actual_heal);
            }
        }
    }
}

/// Apply a level-up upgrade to a creature that has reached its threshold.
fn apply_level_up(creature: &mut Creature, def: &LevelUpDefinition) {
    creature.level = 1;
    creature.attack = creature.attack.saturating_add(def.attack_bonus);
    creature.base_attack = creature.attack.max(0) as u8;
    creature.current_health = creature.current_health.saturating_add(def.health_bonus);
    creature.max_health = creature.max_health.saturating_add(def.health_bonus);
    creature.base_health = creature.max_health.max(0) as u8;
    creature.keywords.0 |= def.keywords_gained_bits.0;
}

/// Process level-up progress for an OnKill trigger after a kill is confirmed.
///
/// `attacker_player` is the player whose creature killed the defender.
/// `attacker_slot` is the slot of the attacking creature.
/// Only triggers when: attacker survived, attacker has level_up with OnKill trigger, attacker.level == 0.
fn process_level_up_on_kill(
    state: &mut GameState,
    card_db: &CardDatabase,
    attacker_player: PlayerId,
    attacker_slot: Slot,
) {
    // Extract data we need without holding a borrow on state
    let (card_id, level, progress) = match state.players[attacker_player.index()].get_creature(attacker_slot) {
        Some(c) => (c.card_id, c.level, c.progress),
        None => return,
    };

    if level > 0 {
        return; // Already leveled, nothing to do
    }

    let level_def = match card_db.get(card_id).and_then(|c| c.level_up()) {
        Some(d) if d.trigger == LevelUpTrigger::OnKill => d.clone(),
        _ => return,
    };

    if let Some(creature) = state.players[attacker_player.index()].get_creature_mut(attacker_slot) {
        creature.progress = progress + 1;
        if creature.progress >= level_def.threshold {
            apply_level_up(creature, &level_def);
        }
    }
}

/// Process level-up progress for an OnDealDamage trigger.
///
/// `attacker_player` is the player whose creature dealt damage.
/// `attacker_slot` is the slot of the attacking creature.
/// `damage` is the amount of damage dealt.
fn process_level_up_on_damage(
    state: &mut GameState,
    card_db: &CardDatabase,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    damage: u8,
) {
    let (card_id, level, progress) = match state.players[attacker_player.index()].get_creature(attacker_slot) {
        Some(c) => (c.card_id, c.level, c.progress),
        None => return,
    };

    if level > 0 {
        return;
    }

    let level_def = match card_db.get(card_id).and_then(|c| c.level_up()) {
        Some(d) if d.trigger == LevelUpTrigger::OnDealDamage => d.clone(),
        _ => return,
    };

    if let Some(creature) = state.players[attacker_player.index()].get_creature_mut(attacker_slot) {
        creature.progress = progress.saturating_add(damage);
        if creature.progress >= level_def.threshold {
            apply_level_up(creature, &level_def);
        }
    }
}

/// Trigger damage-related effects after combat.
#[allow(clippy::too_many_arguments)]
fn trigger_damage_effects(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    defender_player: PlayerId,
    defender_slot: Slot,
    result: &CombatResult,
) {
    // Trigger OnDealDamage effects
    if result.attacker_damage_dealt > 0 {
        trigger_creature_ability(state, card_db, effect_queue, attacker_player, attacker_slot, Trigger::OnDealDamage);
        // Level-up progress for attacker (OnDealDamage trigger) — only if attacker survived
        if !result.attacker_died {
            process_level_up_on_damage(state, card_db, attacker_player, attacker_slot, result.attacker_damage_dealt);
        }
    }
    if result.defender_damage_dealt > 0 {
        trigger_creature_ability(state, card_db, effect_queue, defender_player, defender_slot, Trigger::OnDealDamage);
        // Level-up progress for defender (OnDealDamage trigger) — only if defender survived
        if !result.defender_died {
            process_level_up_on_damage(state, card_db, defender_player, defender_slot, result.defender_damage_dealt);
        }
    }

    // Trigger OnTakeDamage effects
    if result.attacker_damage_dealt > 0 {
        trigger_creature_ability(state, card_db, effect_queue, defender_player, defender_slot, Trigger::OnTakeDamage);
    }
    if result.defender_damage_dealt > 0 {
        trigger_creature_ability(state, card_db, effect_queue, attacker_player, attacker_slot, Trigger::OnTakeDamage);
    }
}

/// Process deaths after combat.
#[allow(clippy::too_many_arguments)]
fn process_combat_deaths(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    attacker_player: PlayerId,
    attacker_slot: Slot,
    defender_player: PlayerId,
    defender_slot: Slot,
    result: &CombatResult,
) {
    use crate::core::engine::collect_commander_kill_effects;

    if result.defender_died {
        // Trigger commander OnKill effects
        for (effect, source) in collect_commander_kill_effects(state, attacker_player, card_db) {
            effect_queue.push(effect, source);
        }
        // Trigger creature OnKill effects
        trigger_creature_ability(state, card_db, effect_queue, attacker_player, attacker_slot, Trigger::OnKill);
        // Level-up progress for attacker (OnKill trigger) — only if attacker survived
        if !result.attacker_died {
            process_level_up_on_kill(state, card_db, attacker_player, attacker_slot);
        }
        process_creature_death(state, card_db, effect_queue, defender_player, defender_slot);
    }
    if result.attacker_died {
        // Note: defender doesn't get OnKill trigger since they're defending
        process_creature_death(state, card_db, effect_queue, attacker_player, attacker_slot);
    }
}
