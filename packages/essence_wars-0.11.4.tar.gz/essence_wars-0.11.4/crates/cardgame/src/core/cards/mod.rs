//! Card definitions and the card database.
//!
//! Cards are defined in YAML files and loaded at runtime into a CardDatabase.
//! The database is immutable and shared across all game instances via Arc.
//!
//! Sub-modules:
//! - [`card_types`]: All card-specific type definitions (effects, abilities, CardDefinition, etc.).
//! - [`commander_types`]: Commander-specific types (Faction, CommanderDefinition, etc.).
//! - [`database`]: The runtime CardDatabase struct and its accessor methods.
//! - [`loader`]: YAML loading, validation, and CardLoadError.

pub mod card_types;
pub mod commander_types;
pub mod database;
pub mod loader;

pub use card_types::*;
pub use commander_types::*;
pub use database::*;
pub use loader::*;
