//! Effect conversion and targeting functions.
//!
//! This module contains helper functions for resolving spell targets and
//! converting EffectDefinition to Effect enums with proper targeting.

use crate::core::cards::{AbilityDefinition, EffectDefinition};
use crate::core::effects::{Effect, EffectTarget, TargetingRule};
use crate::core::keywords::Keywords;
use crate::core::types::{PlayerId, Slot};

/// Resolve the target for a spell based on its targeting rule and the slot parameter.
///
/// Target encoding in slot parameter:
/// - For NoTarget spells: slot is ignored
/// - For creature-targeting spells: slot 0-4 indicates enemy creature slot, slot + 5 for friendly
/// - For TargetPlayer: slot 0 = enemy, slot 1 = self
/// - For TargetAny: slot 0-4 enemy creature, 5-9 friendly creature, 10 enemy player, 11 self
pub fn resolve_spell_target(
    targeting: &TargetingRule,
    slot: Slot,
    caster: PlayerId,
) -> Result<EffectTarget, String> {
    match targeting {
        TargetingRule::NoTarget => {
            Ok(EffectTarget::None)
        }
        TargetingRule::TargetCreature(_) => {
            // slot 0-4 = enemy creature, slot 5-9 = friendly creature
            if slot.0 < 5 {
                Ok(EffectTarget::Creature {
                    owner: caster.opponent(),
                    slot: Slot(slot.0),
                })
            } else if slot.0 < 10 {
                Ok(EffectTarget::Creature {
                    owner: caster,
                    slot: Slot(slot.0 - 5),
                })
            } else {
                Err("Invalid target slot for creature targeting".to_string())
            }
        }
        TargetingRule::TargetEnemyCreature => {
            // slot 0-4 = enemy creature slot
            if slot.0 < 5 {
                Ok(EffectTarget::Creature {
                    owner: caster.opponent(),
                    slot: Slot(slot.0),
                })
            } else {
                Err("Invalid target slot for enemy creature targeting".to_string())
            }
        }
        TargetingRule::TargetAllyCreature => {
            // Legal generator encodes ally slots as slot+5 to avoid action-space index collision
            // with enemy slots. Accept both direct (0-4) and offset (5-9) encodings.
            let creature_slot = if slot.0 >= 5 { slot.0 - 5 } else { slot.0 };
            if creature_slot < 5 {
                Ok(EffectTarget::Creature {
                    owner: caster,
                    slot: Slot(creature_slot),
                })
            } else {
                Err("Invalid target slot for ally creature targeting".to_string())
            }
        }
        TargetingRule::TargetPlayer => {
            // slot 0 = enemy, slot 1 = self
            if slot.0 == 0 {
                Ok(EffectTarget::Player(caster.opponent()))
            } else {
                Ok(EffectTarget::Player(caster))
            }
        }
        TargetingRule::TargetEnemyPlayer => {
            Ok(EffectTarget::Player(caster.opponent()))
        }
        TargetingRule::TargetAny => {
            // slot 0-4 enemy creature, 5-9 friendly creature, 10 enemy player, 11 self
            if slot.0 < 5 {
                Ok(EffectTarget::Creature {
                    owner: caster.opponent(),
                    slot: Slot(slot.0),
                })
            } else if slot.0 < 10 {
                Ok(EffectTarget::Creature {
                    owner: caster,
                    slot: Slot(slot.0 - 5),
                })
            } else if slot.0 == 10 {
                Ok(EffectTarget::Player(caster.opponent()))
            } else {
                Ok(EffectTarget::Player(caster))
            }
        }
        TargetingRule::TargetSlot => {
            // For summoning effects - just return the slot info
            if slot.0 < 5 {
                Ok(EffectTarget::Creature {
                    owner: caster,
                    slot: Slot(slot.0),
                })
            } else {
                Err("Invalid target slot".to_string())
            }
        }
        TargetingRule::TargetEnemyCreatureOrFace => {
            // slot 0-4 = enemy creature slot, slot 10 = enemy face
            if slot.0 < 5 {
                Ok(EffectTarget::Creature {
                    owner: caster.opponent(),
                    slot: Slot(slot.0),
                })
            } else if slot.0 == 10 {
                Ok(EffectTarget::Player(caster.opponent()))
            } else {
                Err("Invalid target slot for TargetEnemyCreatureOrFace".to_string())
            }
        }
        TargetingRule::TargetEnemySlot => {
            // TargetEnemySlot requires game state to resolve (occupied → creature, empty → face).
            // This branch should be handled by play_ritual before calling resolve_spell_target.
            // Fallback: treat as enemy face.
            Ok(EffectTarget::Player(caster.opponent()))
        }
    }
}

// =============================================================================
// UNIFIED EFFECT CONVERSION
// =============================================================================

/// Context that drives target resolution in [`convert_effect_def`].
///
/// Each variant corresponds to one of the five call sites that previously had
/// their own separate converter function. The compiler now enforces exhaustiveness
/// over all `EffectDefinition` variants in a single location — adding a new
/// variant causes a compile error here rather than silently returning `None`
/// in four out of five codepaths.
pub enum ConversionContext<'a> {
    /// Creature triggered ability via the effect-queue path (OnDeath, OnAllyDeath,
    /// OnPlay, OnAttack, …) where only the source creature is known.
    ///
    /// Damage/Bounce → `AllEnemyCreatures`; stat effects → self creature.
    CreatureTrigger {
        source_owner: PlayerId,
        source_slot: Slot,
    },

    /// Creature triggered ability from the combat path, where the `AbilityDefinition`
    /// is available and its `targeting` field influences target resolution.
    ///
    /// Damage/Bounce branch on `ability.targeting`; stat effects → self creature.
    CombatTrigger {
        source_owner: PlayerId,
        source_slot: Slot,
        ability: &'a AbilityDefinition,
    },

    /// Spell, activated ability, or any path where the target was already
    /// resolved externally. The caller provides the `EffectTarget` directly.
    ExplicitTarget {
        target: EffectTarget,
        source_player: PlayerId,
    },

    /// Support card triggered ability (OnPlay, StartOfTurn).
    ///
    /// Key difference from `CreatureTrigger`: `Heal` with `NoTarget` heals the
    /// player (not a creature); `BuffStats`/`GrantKeyword`/`RefreshCreature` →
    /// `AllAllyCreatures`; `RemoveKeyword` → `AllEnemyCreatures`.
    SupportTrigger {
        source_owner: PlayerId,
        ability: &'a AbilityDefinition,
    },

    /// Commander triggered ability. Damage always hits the enemy face;
    /// Heal always heals the owner face. Limited variant support is intentional.
    CommanderTrigger {
        source_owner: PlayerId,
    },
}

/// Convert an `EffectDefinition` to a runtime `Effect`, resolving targets based
/// on the provided `ConversionContext`.
///
/// Returns `None` for variants that are not meaningful in the given context
/// (e.g. `Destroy`/`Transform`/`Copy` without an explicit target, or
/// `BuffStatsTemporal` which is handled exclusively by the Prepare/Ambush path).
///
/// **This is the single authoritative converter.** All five previous per-context
/// functions delegate here. Adding a new `EffectDefinition` variant causes a
/// compile error in each of the five private helpers below — catching the bug
/// class at compile time rather than silently returning `None`.
pub fn convert_effect_def(def: &EffectDefinition, ctx: ConversionContext<'_>) -> Option<Effect> {
    match ctx {
        ConversionContext::CreatureTrigger { source_owner, source_slot } =>
            creature_trigger(def, source_owner, source_slot),
        ConversionContext::CombatTrigger { source_owner, source_slot, ability } =>
            combat_trigger(def, source_owner, source_slot, ability),
        ConversionContext::ExplicitTarget { target, source_player } =>
            explicit_target(def, target, source_player),
        ConversionContext::SupportTrigger { source_owner, ability } =>
            support_trigger(def, source_owner, ability),
        ConversionContext::CommanderTrigger { source_owner } =>
            commander_trigger(def, source_owner),
    }
}

// ---------------------------------------------------------------------------
// Private per-context helpers.
//
// Each function is an exhaustive `match` over *all* `EffectDefinition` variants.
// The compiler will emit a non-exhaustive-pattern error here — not in a call
// site four modules away — if a new variant is added.
// ---------------------------------------------------------------------------

fn creature_trigger(
    def: &EffectDefinition,
    source_owner: PlayerId,
    source_slot: Slot,
) -> Option<Effect> {
    let self_target = EffectTarget::Creature { owner: source_owner, slot: source_slot };
    match def {
        EffectDefinition::Damage { amount, filter } => Some(Effect::Damage {
            target: EffectTarget::AllEnemyCreatures(source_owner),
            amount: *amount,
            filter: filter.clone(),
        }),
        EffectDefinition::Heal { amount, filter } => Some(Effect::Heal {
            target: self_target,
            amount: *amount,
            filter: filter.clone(),
        }),
        EffectDefinition::Draw { count } => Some(Effect::Draw {
            player: source_owner,
            count: *count,
        }),
        EffectDefinition::BuffStats { attack, health, filter } => Some(Effect::BuffStats {
            target: self_target,
            attack: *attack,
            health: *health,
            filter: filter.clone(),
        }),
        EffectDefinition::GrantKeyword { keyword, filter } => Some(Effect::GrantKeyword {
            target: self_target,
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::RemoveKeyword { keyword, filter } => Some(Effect::RemoveKeyword {
            target: self_target,
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::Silence { filter } => Some(Effect::Silence {
            target: self_target,
            filter: filter.clone(),
        }),
        EffectDefinition::GainEssence { amount } => Some(Effect::GainEssence {
            player: source_owner,
            amount: *amount,
        }),
        EffectDefinition::RefreshCreature => Some(Effect::RefreshCreature {
            target: self_target,
        }),
        EffectDefinition::Bounce { filter } => Some(Effect::Bounce {
            target: EffectTarget::AllEnemyCreatures(source_owner),
            filter: filter.clone(),
        }),
        EffectDefinition::SummonToken { token } => Some(Effect::SummonToken {
            owner: source_owner,
            token: token.to_token_definition(),
            slot: None,
        }),
        // Require an explicit target — cannot infer from creature trigger context
        EffectDefinition::Destroy { .. } => None,
        EffectDefinition::Transform { .. } => None,
        EffectDefinition::Copy => None,
        // Only valid for Prepare/Ambush path (fire_prepared_effect_now)
        EffectDefinition::BuffStatsTemporal { .. } => None,
    }
}

fn combat_trigger(
    def: &EffectDefinition,
    source_owner: PlayerId,
    source_slot: Slot,
    ability: &AbilityDefinition,
) -> Option<Effect> {
    let self_target = EffectTarget::Creature { owner: source_owner, slot: source_slot };
    match def {
        EffectDefinition::Damage { amount, filter } => {
            let target = match &ability.targeting {
                TargetingRule::TargetAllyCreature => EffectTarget::AllAllyCreatures(source_owner),
                TargetingRule::TargetEnemyPlayer => EffectTarget::Player(source_owner.opponent()),
                _ => EffectTarget::AllEnemyCreatures(source_owner),
            };
            Some(Effect::Damage { target, amount: *amount, filter: filter.clone() })
        }
        EffectDefinition::Heal { amount, filter } => {
            let target = match &ability.targeting {
                TargetingRule::TargetPlayer => EffectTarget::Player(source_owner),
                _ => self_target,
            };
            Some(Effect::Heal { target, amount: *amount, filter: filter.clone() })
        }
        EffectDefinition::Draw { count } => Some(Effect::Draw {
            player: source_owner,
            count: *count,
        }),
        EffectDefinition::BuffStats { attack, health, filter } => Some(Effect::BuffStats {
            target: self_target,
            attack: *attack,
            health: *health,
            filter: filter.clone(),
        }),
        EffectDefinition::GrantKeyword { keyword, filter } => Some(Effect::GrantKeyword {
            target: self_target,
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::RemoveKeyword { keyword, filter } => Some(Effect::RemoveKeyword {
            target: self_target,
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::Silence { filter } => Some(Effect::Silence {
            target: self_target,
            filter: filter.clone(),
        }),
        EffectDefinition::GainEssence { amount } => Some(Effect::GainEssence {
            player: source_owner,
            amount: *amount,
        }),
        EffectDefinition::RefreshCreature => Some(Effect::RefreshCreature {
            target: self_target,
        }),
        EffectDefinition::Bounce { filter } => {
            let target = match &ability.targeting {
                TargetingRule::TargetAllyCreature => EffectTarget::AllAllyCreatures(source_owner),
                _ => EffectTarget::AllEnemyCreatures(source_owner),
            };
            Some(Effect::Bounce { target, filter: filter.clone() })
        }
        EffectDefinition::SummonToken { token } => Some(Effect::SummonToken {
            owner: source_owner,
            token: token.to_token_definition(),
            slot: None,
        }),
        EffectDefinition::Destroy { .. } => None,
        EffectDefinition::Transform { .. } => None,
        EffectDefinition::Copy => None,
        EffectDefinition::BuffStatsTemporal { .. } => None,
    }
}

fn explicit_target(
    def: &EffectDefinition,
    target: EffectTarget,
    source_player: PlayerId,
) -> Option<Effect> {
    match def {
        EffectDefinition::Damage { amount, filter } => Some(Effect::Damage {
            target,
            amount: *amount,
            filter: filter.clone(),
        }),
        EffectDefinition::Heal { amount, filter } => Some(Effect::Heal {
            target,
            amount: *amount,
            filter: filter.clone(),
        }),
        EffectDefinition::Draw { count } => Some(Effect::Draw {
            player: source_player,
            count: *count,
        }),
        EffectDefinition::BuffStats { attack, health, filter } => Some(Effect::BuffStats {
            target,
            attack: *attack,
            health: *health,
            filter: filter.clone(),
        }),
        EffectDefinition::Destroy { filter } => Some(Effect::Destroy {
            target,
            filter: filter.clone(),
        }),
        EffectDefinition::GrantKeyword { keyword, filter } => Some(Effect::GrantKeyword {
            target,
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::RemoveKeyword { keyword, filter } => Some(Effect::RemoveKeyword {
            target,
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::Silence { filter } => Some(Effect::Silence {
            target,
            filter: filter.clone(),
        }),
        EffectDefinition::GainEssence { amount } => Some(Effect::GainEssence {
            player: source_player,
            amount: *amount,
        }),
        EffectDefinition::RefreshCreature => Some(Effect::RefreshCreature { target }),
        EffectDefinition::Bounce { filter } => Some(Effect::Bounce {
            target,
            filter: filter.clone(),
        }),
        EffectDefinition::SummonToken { token } => Some(Effect::SummonToken {
            owner: source_player,
            token: token.to_token_definition(),
            slot: None,
        }),
        EffectDefinition::Transform { into } => Some(Effect::Transform {
            target,
            into: into.to_token_definition(),
        }),
        EffectDefinition::Copy => Some(Effect::Copy {
            target,
            owner: source_player,
        }),
        EffectDefinition::BuffStatsTemporal { .. } => None,
    }
}

fn support_trigger(
    def: &EffectDefinition,
    source_owner: PlayerId,
    ability: &AbilityDefinition,
) -> Option<Effect> {
    match def {
        EffectDefinition::Damage { amount, filter } => {
            let target = match &ability.targeting {
                TargetingRule::TargetEnemyPlayer => EffectTarget::Player(source_owner.opponent()),
                _ => EffectTarget::AllEnemyCreatures(source_owner),
            };
            Some(Effect::Damage { target, amount: *amount, filter: filter.clone() })
        }
        EffectDefinition::Heal { amount, filter } => {
            // Supports: NoTarget heal targets the player, not a creature
            let target = match &ability.targeting {
                TargetingRule::TargetAllyCreature => EffectTarget::AllAllyCreatures(source_owner),
                _ => EffectTarget::Player(source_owner),
            };
            Some(Effect::Heal { target, amount: *amount, filter: filter.clone() })
        }
        EffectDefinition::Draw { count } => Some(Effect::Draw {
            player: source_owner,
            count: *count,
        }),
        EffectDefinition::BuffStats { attack, health, filter } => Some(Effect::BuffStats {
            target: EffectTarget::AllAllyCreatures(source_owner),
            attack: *attack,
            health: *health,
            filter: filter.clone(),
        }),
        EffectDefinition::GrantKeyword { keyword, filter } => Some(Effect::GrantKeyword {
            target: EffectTarget::AllAllyCreatures(source_owner),
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        // NOTE: RemoveKeyword from a support targets ENEMIES (debuff effect)
        EffectDefinition::RemoveKeyword { keyword, filter } => Some(Effect::RemoveKeyword {
            target: EffectTarget::AllEnemyCreatures(source_owner),
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::GainEssence { amount } => Some(Effect::GainEssence {
            player: source_owner,
            amount: *amount,
        }),
        EffectDefinition::RefreshCreature => Some(Effect::RefreshCreature {
            target: EffectTarget::AllAllyCreatures(source_owner),
        }),
        EffectDefinition::Bounce { filter } => {
            let target = match &ability.targeting {
                TargetingRule::TargetAllyCreature => EffectTarget::AllAllyCreatures(source_owner),
                _ => EffectTarget::AllEnemyCreatures(source_owner),
            };
            Some(Effect::Bounce { target, filter: filter.clone() })
        }
        EffectDefinition::SummonToken { token } => Some(Effect::SummonToken {
            owner: source_owner,
            token: token.to_token_definition(),
            slot: None,
        }),
        // Silence requires a specific target — not resolvable from support context
        EffectDefinition::Silence { .. } => None,
        EffectDefinition::Destroy { .. } => None,
        EffectDefinition::Transform { .. } => None,
        EffectDefinition::Copy => None,
        EffectDefinition::BuffStatsTemporal { .. } => None,
    }
}

fn commander_trigger(
    def: &EffectDefinition,
    source_owner: PlayerId,
) -> Option<Effect> {
    match def {
        EffectDefinition::Damage { amount, filter } => Some(Effect::Damage {
            target: EffectTarget::Player(source_owner.opponent()),
            amount: *amount,
            filter: filter.clone(),
        }),
        EffectDefinition::Heal { amount, filter } => Some(Effect::Heal {
            target: EffectTarget::Player(source_owner),
            amount: *amount,
            filter: filter.clone(),
        }),
        EffectDefinition::Draw { count } => Some(Effect::Draw {
            player: source_owner,
            count: *count,
        }),
        EffectDefinition::BuffStats { attack, health, filter } => Some(Effect::BuffStats {
            target: EffectTarget::AllAllyCreatures(source_owner),
            attack: *attack,
            health: *health,
            filter: filter.clone(),
        }),
        EffectDefinition::GrantKeyword { keyword, filter } => Some(Effect::GrantKeyword {
            target: EffectTarget::AllAllyCreatures(source_owner),
            keyword: Keywords::parse_keyword_name(keyword),
            filter: filter.clone(),
        }),
        EffectDefinition::GainEssence { amount } => Some(Effect::GainEssence {
            player: source_owner,
            amount: *amount,
        }),
        EffectDefinition::SummonToken { token } => Some(Effect::SummonToken {
            owner: source_owner,
            token: token.to_token_definition(),
            slot: None,
        }),
        // Remaining variants are not yet used by any commander ability
        EffectDefinition::RemoveKeyword { .. } => None,
        EffectDefinition::Silence { .. } => None,
        EffectDefinition::RefreshCreature => None,
        EffectDefinition::Bounce { .. } => None,
        EffectDefinition::Destroy { .. } => None,
        EffectDefinition::Transform { .. } => None,
        EffectDefinition::Copy => None,
        EffectDefinition::BuffStatsTemporal { .. } => None,
    }
}
