//! Trigger checking and death processing utilities.
//!
//! This module contains functions for checking and queuing triggered abilities
//! from creatures, as well as processing creature deaths.

use crate::core::cards::CardDatabase;
use crate::core::effects::{Effect, EffectSource, Trigger};
use crate::core::state::GameState;
use crate::core::types::{PlayerId, Slot};

use super::effect_context::EffectContext;
use super::effect_convert::{convert_effect_def, ConversionContext};
use super::passive::{
    collect_commander_ally_death_effects,
    collect_commander_any_death_effects,
    collect_commander_enemy_death_effects,
};

/// Check for and queue triggered abilities on a creature.
///
/// This function checks if a creature has any abilities that trigger
/// on the given trigger type, and if so, queues them for processing.
pub fn check_creature_triggers(
    ctx: &mut EffectContext,
    trigger: Trigger,
    owner: PlayerId,
    slot: Slot,
) {
    let Some(creature) = ctx.state.players[owner.index()].get_creature(slot) else {
        return;
    };

    // Silenced creatures don't trigger abilities
    if creature.status.is_silenced() {
        return;
    }

    let card_id = creature.card_id;
    let Some(card_def) = ctx.card_db.get(card_id) else {
        return;
    };

    let Some(abilities) = card_def.creature_abilities() else {
        return;
    };

    for ability in abilities {
        if ability.trigger == trigger {
            // Convert ability effects to Effect enum and queue them
            let source = EffectSource::Creature { owner, slot };
            for effect_def in &ability.effects {
                if let Some(effect) = convert_effect_def(
                    effect_def,
                    ConversionContext::CreatureTrigger { source_owner: owner, source_slot: slot },
                ) {
                    ctx.push_effect(effect, source);
                }
            }
        }
    }
}

/// Process all pending deaths.
///
/// This function handles death processing including:
/// - Volatile keyword explosion (2 damage to all enemy creatures)
/// - Queuing OnDeath triggers from dying creatures
/// - Queuing OnAllyDeath triggers from allied creatures
/// - Queuing commander death triggers
/// - Removing dead creatures from the board
pub fn process_deaths(
    pending_deaths: &mut Vec<(PlayerId, Slot)>,
    state: &mut GameState,
    card_db: &CardDatabase,
    queue_effect: &mut impl FnMut(Effect, EffectSource),
) {
    // Process deaths in the order they occurred
    while let Some((owner, slot)) = pending_deaths.pop() {
        // Check creature still exists
        let creature_info = state.players[owner.index()]
            .get_creature(slot)
            .map(|c| (c.card_id, c.status.is_silenced(), c.keywords.has_volatile()));

        if let Some((card_id, is_silenced, has_volatile)) = creature_info {
            // VOLATILE: Deal 2 damage to all enemy creatures on death (if not silenced).
            // Applied before OnDeath triggers and removal, consistent with combat death handling.
            // Any enemy creatures killed by Volatile are pushed to pending_deaths and processed
            // in subsequent iterations of this loop (supporting Volatile chain reactions).
            if has_volatile && !is_silenced {
                let enemy = owner.opponent();
                let enemy_slots: Vec<Slot> = state.players[enemy.index()]
                    .creatures
                    .iter()
                    .map(|c| c.slot)
                    .collect();
                for enemy_slot in enemy_slots {
                    if let Some(c) = state.players[enemy.index()].get_creature_mut(enemy_slot) {
                        c.current_health = (c.current_health - 2).max(0);
                        if c.current_health == 0 && !pending_deaths.contains(&(enemy, enemy_slot)) {
                            pending_deaths.push((enemy, enemy_slot));
                        }
                    }
                }
            }

            // Queue OnDeath triggers before removing
            if !is_silenced {
                if let Some(card_def) = card_db.get(card_id) {
                    if let Some(abilities) = card_def.creature_abilities() {
                        for ability in abilities {
                            if ability.trigger == Trigger::OnDeath {
                                let source = EffectSource::Creature { owner, slot };
                                for effect_def in &ability.effects {
                                    if let Some(effect) = convert_effect_def(
                                        effect_def,
                                        ConversionContext::CreatureTrigger { source_owner: owner, source_slot: slot },
                                    ) {
                                        queue_effect(effect, source);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Queue OnAllyDeath triggers for other friendly creatures
            let ally_creatures: Vec<Slot> = state.players[owner.index()]
                .creatures.iter()
                .filter(|c| c.slot != slot && !c.status.is_silenced())
                .map(|c| c.slot)
                .collect();

            for ally_slot in ally_creatures {
                if let Some(ally) = state.players[owner.index()].get_creature(ally_slot) {
                    if let Some(card_def) = card_db.get(ally.card_id) {
                        if let Some(abilities) = card_def.creature_abilities() {
                            for ability in abilities {
                                if ability.trigger == Trigger::OnAllyDeath {
                                    let source = EffectSource::Creature {
                                        owner,
                                        slot: ally_slot
                                    };
                                    for effect_def in &ability.effects {
                                        if let Some(effect) = convert_effect_def(
                                            effect_def,
                                            ConversionContext::CreatureTrigger { source_owner: owner, source_slot: ally_slot },
                                        ) {
                                            queue_effect(effect, source);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Queue OnAllyDeath commander trigger (e.g., Plague Sovereign)
            for (effect, source) in collect_commander_ally_death_effects(state, owner, card_db) {
                queue_effect(effect, source);
            }

            // Queue OnEnemyDeath commander trigger
            // This triggers for the opponent when one of your creatures dies
            for (effect, source) in collect_commander_enemy_death_effects(state, owner, card_db) {
                queue_effect(effect, source);
            }

            // Queue OnAnyDeath commander triggers for both players
            for (effect, source) in collect_commander_any_death_effects(state, owner, card_db) {
                queue_effect(effect, source);
            }
            for (effect, source) in collect_commander_any_death_effects(state, owner.opponent(), card_db) {
                queue_effect(effect, source);
            }

            // Remove the creature from the board
            state.players[owner.index()].creatures.retain(|c| c.slot != slot);
        }
    }
}
