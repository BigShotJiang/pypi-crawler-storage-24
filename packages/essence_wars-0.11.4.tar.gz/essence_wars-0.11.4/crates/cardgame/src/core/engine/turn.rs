//! Turn management functions.
//!
//! Handles turn start/end logic including:
//! - Essence and AP restoration
//! - Card draw
//! - Creature status reset
//! - Regenerate, Ephemeral, and Frenzy processing
//! - Support durability and triggered effects

use crate::core::cards::{CardDatabase, CardType};
use crate::core::config::{game, player};
use crate::core::effects::{Effect, EffectSource, EffectTarget, Trigger};
use crate::core::state::{GameState, PreparedEffect, PreparedTrigger};
use crate::core::types::{CardId, PlayerId, Slot};

use super::effect_queue::EffectQueue;
use super::init::draw_card;
use super::effect_convert::{convert_effect_def, ConversionContext};
use super::passive::{
    collect_commander_start_of_turn_effects, remove_support_passives_from_all_creatures,
};
use super::victory::check_turn_limit_victory;

/// Start the current player's turn.
///
/// - Increment turn counter
/// - Check turn limit victory condition
/// - Increase max essence by 1 (cap at 10)
/// - Refill current essence to max
/// - Draw a card
/// - Restore AP to 3
/// - Reset creature attack flags (clear exhausted status)
/// - Reset Commander's Insight usage flag
/// - Process Regenerate healing
/// - Process StartOfTurn triggers for supports and commander
pub fn start_turn(state: &mut GameState, card_db: &CardDatabase, effect_queue: &mut EffectQueue) {
    // Increment turn counter
    state.current_turn += 1;

    // Check for turn limit win condition
    if state.current_turn > game::TURN_LIMIT as u16 {
        check_turn_limit_victory(state);
        return;
    }

    let current_player = state.active_player;
    let player_state = &mut state.players[current_player.index()];

    // Reset Commander's Insight usage for this turn
    player_state.used_commander_insight = false;

    // Increase max essence by 1 (capped at MAX_ESSENCE)
    if player_state.max_essence < player::MAX_ESSENCE {
        player_state.max_essence += player::ESSENCE_PER_TURN;
    }

    // Refill current essence to max
    player_state.current_essence = player_state.max_essence;

    // Draw a card
    draw_card(state, current_player);

    // Restore AP to 3
    state.players[current_player.index()].action_points = player::AP_PER_TURN;

    // Reset creature attack flags (clear exhausted status)
    // Creatures that survived a full round can now attack
    for creature in &mut state.players[current_player.index()].creatures {
        creature.status.set_exhausted(false);
    }

    // Process Regenerate - creatures with this keyword heal 2 HP at start of turn
    process_regenerate_healing(state, current_player);

    // Fire prepared effects (Prepare/Ritual) that fire at start of turn
    fire_prepared_effects_start_of_turn(state, card_db, effect_queue);

    // Process StartOfTurn triggered effects for supports
    process_support_start_of_turn_triggers(state, card_db, effect_queue, current_player);

    // Process StartOfTurn triggered effects for commander
    process_commander_start_of_turn_triggers(state, card_db, effect_queue, current_player);

    // Process queued effects
    effect_queue.process_all(state, card_db);
}

/// End the current player's turn.
///
/// - Decrement support durability and remove depleted supports
/// - Process Ephemeral deaths
/// - Reset Frenzy stacks
/// - Switch to opponent
/// - Call start_turn for new player
pub fn end_turn(state: &mut GameState, card_db: &CardDatabase, effect_queue: &mut EffectQueue) {
    let current_player = state.active_player;

    // Decrement support durability and collect supports to remove
    let supports_to_remove: Vec<(Slot, CardId)> = {
        let player_state = &mut state.players[current_player.index()];
        let mut to_remove = Vec::new();

        for support in &mut player_state.supports {
            support.current_durability = support.current_durability.saturating_sub(1);
            if support.current_durability == 0 {
                to_remove.push((support.slot, support.card_id));
            }
        }

        to_remove
    };

    // Remove depleted supports and their passive effects
    for (slot, card_id) in supports_to_remove {
        // Remove passive effects from creatures before removing support
        remove_support_passives_from_all_creatures(
            card_id,
            &mut state.players[current_player.index()].creatures,
            card_db,
        );

        // Remove the support from the board
        state.players[current_player.index()]
            .supports
            .retain(|s| s.slot != slot);
    }

    // Process Ephemeral - creatures with this keyword die at end of turn
    process_ephemeral_deaths(state, card_db, effect_queue, current_player);

    // Reset Frenzy stacks and temp attack bonuses — both expire at end of turn
    for creature in &mut state.players[current_player.index()].creatures {
        creature.frenzy_stacks = 0;
        creature.temp_attack_bonus = 0;
    }

    // Expire Ambush effects that weren't triggered this turn
    expire_ambush_effects(state);

    // Switch to opponent
    state.active_player = state.active_player.opponent();

    // Start opponent's turn
    start_turn(state, card_db, effect_queue);
}

/// Process Regenerate keyword - heal creatures by 2 HP at start of turn.
fn process_regenerate_healing(state: &mut GameState, player: PlayerId) {
    const REGEN_AMOUNT: i8 = 2;

    for creature in &mut state.players[player.index()].creatures {
        // Skip dead/dying creatures (health <= 0) - they'll be removed by death processing
        if creature.current_health <= 0 {
            continue;
        }

        if creature.keywords.has_regenerate() && creature.current_health < creature.max_health {
            // Use saturating add to prevent overflow from edge cases
            creature.current_health =
                creature.current_health.saturating_add(REGEN_AMOUNT).min(creature.max_health);
        }
    }
}

/// Process Ephemeral keyword - creatures with this keyword die at end of turn.
fn process_ephemeral_deaths(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    player: PlayerId,
) {
    // Collect slots of ephemeral creatures to process
    let ephemeral_slots: Vec<Slot> = state.players[player.index()]
        .creatures
        .iter()
        .filter(|c| c.keywords.has_ephemeral())
        .map(|c| c.slot)
        .collect();

    if ephemeral_slots.is_empty() {
        return;
    }

    // Queue OnDeath triggers for each ephemeral creature before removing them
    for slot in &ephemeral_slots {
        if let Some(creature) = state.players[player.index()].get_creature(*slot) {
            let card_id = creature.card_id;

            // Check for OnDeath triggers
            if let Some(card_def) = card_db.get(card_id) {
                if let CardType::Creature { abilities, .. } = &card_def.card_type {
                    for ability in abilities {
                        if ability.trigger == Trigger::OnDeath {
                            let source = EffectSource::Creature { owner: player, slot: *slot };
                            for effect_def in &ability.effects {
                                if let Some(effect) = convert_effect_def(
                                    effect_def,
                                    ConversionContext::ExplicitTarget {
                                        target: EffectTarget::Creature { owner: player, slot: *slot },
                                        source_player: player,
                                    },
                                ) {
                                    effect_queue.push(effect, source);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Remove ephemeral creatures
    state.players[player.index()]
        .creatures
        .retain(|c| !c.keywords.has_ephemeral());

    // Process any OnDeath effects
    effect_queue.process_all(state, card_db);
}

/// Process StartOfTurn triggered effects for a player's supports.
fn process_support_start_of_turn_triggers(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    player: PlayerId,
) {
    // Collect support info to avoid borrow conflicts
    let support_info: Vec<(Slot, CardId)> = state.players[player.index()]
        .supports
        .iter()
        .map(|s| (s.slot, s.card_id))
        .collect();

    for (slot, card_id) in support_info {
        if let Some(card_def) = card_db.get(card_id) {
            if let CardType::Support { triggered_effects, .. } = &card_def.card_type {
                for ability in triggered_effects {
                    if ability.trigger == Trigger::StartOfTurn {
                        let source = EffectSource::Support { owner: player, slot };
                        for effect_def in &ability.effects {
                            // Use support-specific effect conversion
                            if let Some(effect) = convert_effect_def(
                                effect_def,
                                ConversionContext::SupportTrigger { source_owner: player, ability },
                            ) {
                                effect_queue.push(effect, source);
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Fire all StartOfNextTurn prepared effects for the current player.
/// Called at the START of a player's turn (after essence/AP/draw).
pub fn fire_prepared_effects_start_of_turn(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
) {
    let player = state.active_player;

    // Separate effects to fire from effects to keep
    let all_effects = std::mem::take(&mut state.players[player.index()].prepared_effects);
    let mut to_keep = Vec::new();
    let mut to_fire = Vec::new();

    for pe in all_effects {
        if pe.trigger == PreparedTrigger::StartOfNextTurn {
            to_fire.push(pe);
        } else {
            to_keep.push(pe);
        }
    }

    // Restore kept effects (OnEnemyAttack / Ambush effects stay until triggered or expired)
    state.players[player.index()].prepared_effects = to_keep;

    // Fire each prepared effect
    for prepared_effect in to_fire {
        fire_prepared_effect_now(state, card_db, effect_queue, &prepared_effect);
    }
}

/// Expire all OnEnemyAttack (Ambush) prepared effects for the OPPONENT at end of turn.
///
/// Ambush effects are set up by the defending player and trigger when an enemy attacks.
/// They survive through the opponent's full turn; if still unused at end of that turn, expire.
/// We expire the *opponent's* effects here because this runs at end of the current player's turn —
/// meaning the opponent just had their full turn to attack and trigger them.
pub fn expire_ambush_effects(state: &mut GameState) {
    let opponent = state.active_player.opponent();
    state.players[opponent.index()].prepared_effects
        .retain(|pe| pe.trigger != PreparedTrigger::OnEnemyAttack);
}

/// Fire all OnEnemyAttack (Ambush) prepared effects for the defending player.
///
/// Called before an attack resolves. The `attacker_player` and `attacker_slot`
/// identify the attacking creature so Ambush effects can target it.
pub fn fire_ambush_effects(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    defending_player: PlayerId,
    attacker_player: PlayerId,
    attacker_slot: Slot,
) {
    // Take ambush effects from the defending player
    let all_effects = std::mem::take(&mut state.players[defending_player.index()].prepared_effects);
    let mut to_keep = Vec::new();
    let mut to_fire = Vec::new();

    for pe in all_effects {
        if pe.trigger == PreparedTrigger::OnEnemyAttack {
            to_fire.push(pe);
        } else {
            to_keep.push(pe);
        }
    }

    state.players[defending_player.index()].prepared_effects = to_keep;

    for prepared_effect in to_fire {
        fire_ambush_effect_now(state, card_db, effect_queue, &prepared_effect, attacker_player, attacker_slot);
    }
}

/// Execute a prepared effect now (resolve targets and push to effect queue).
fn fire_prepared_effect_now(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    prepared_effect: &PreparedEffect,
) {
    use crate::core::cards::EffectDefinition;

    let source_player = prepared_effect.source_player;
    let source_slot = prepared_effect.source_slot;

    let source = match source_slot {
        Some(slot) => EffectSource::Creature { owner: source_player, slot },
        None => EffectSource::Card(crate::core::types::CardId(0)), // Ritual source
    };

    for effect_def in &prepared_effect.effects {
        let effect = match effect_def {
            EffectDefinition::Damage { amount, .. } => {
                // Use the stored target (Ritual cards carry an explicit target).
                // Fall back to targeting the opponent's face for creature-ability Prepare effects.
                let raw_target = prepared_effect.target.unwrap_or_else(|| {
                    EffectTarget::Player(source_player.opponent())
                });
                // Resolve lazy EnemySlotOrFace: re-check the slot at fire time.
                // If the opponent placed a creature there since the ritual was cast, hit it;
                // otherwise fall through to face damage as originally intended.
                let target = match raw_target {
                    EffectTarget::EnemySlotOrFace { owner, slot } => {
                        if state.get_creature(owner, slot).is_some() {
                            EffectTarget::Creature { owner, slot }
                        } else {
                            EffectTarget::Player(owner)
                        }
                    }
                    other => other,
                };
                Some(Effect::Damage {
                    target,
                    amount: *amount,
                    filter: None,
                })
            }
            EffectDefinition::Heal { amount, .. } => {
                Some(Effect::Heal {
                    target: EffectTarget::Player(source_player),
                    amount: *amount,
                    filter: None,
                })
            }
            EffectDefinition::Draw { count } => {
                Some(Effect::Draw { player: source_player, count: *count })
            }
            EffectDefinition::GainEssence { amount } => {
                Some(Effect::GainEssence { player: source_player, amount: *amount })
            }
            EffectDefinition::SummonToken { token } => {
                Some(Effect::SummonToken {
                    owner: source_player,
                    token: token.to_token_definition(),
                    slot: None,
                })
            }
            EffectDefinition::BuffStats { attack, health, filter } => {
                // If source_slot is available, target self (the creature)
                let target = match source_slot {
                    Some(slot) => EffectTarget::Creature {
                        owner: source_player,
                        slot,
                    },
                    None => EffectTarget::TriggerSource,
                };
                Some(Effect::BuffStats {
                    target,
                    attack: *attack,
                    health: *health,
                    filter: filter.clone(),
                })
            }
            EffectDefinition::BuffStatsTemporal { attack, .. } => {
                source_slot.map(|slot| Effect::BuffStatsTemporal {
                    target: EffectTarget::Creature { owner: source_player, slot },
                    attack: *attack,
                })
            }
            EffectDefinition::Destroy { filter } => {
                source_slot.map(|slot| Effect::Destroy {
                    target: EffectTarget::Creature { owner: source_player, slot },
                    filter: filter.clone(),
                })
            }
            _ => None, // Other effects fizzle (not typical for Prepare)
        };

        if let Some(effect) = effect {
            effect_queue.push(effect, source);
        }
    }

    effect_queue.process_all(state, card_db);
}

/// Execute an Ambush effect, targeting the attacking creature for damage/debuff effects.
fn fire_ambush_effect_now(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    prepared_effect: &PreparedEffect,
    attacker_player: PlayerId,
    attacker_slot: Slot,
) {
    use crate::core::cards::EffectDefinition;

    let source_player = prepared_effect.source_player;
    let source = match prepared_effect.source_slot {
        Some(slot) => EffectSource::Creature { owner: source_player, slot },
        None => EffectSource::Card(crate::core::types::CardId(0)),
    };

    // The attacker creature is the default target for Ambush damage/debuff effects
    let attacker_target = EffectTarget::Creature { owner: attacker_player, slot: attacker_slot };

    for effect_def in &prepared_effect.effects {
        let effect = match effect_def {
            EffectDefinition::Damage { amount, .. } => {
                // Check if attacker still exists
                if state.players[attacker_player.index()].get_creature(attacker_slot).is_some() {
                    Some(Effect::Damage { target: attacker_target, amount: *amount, filter: None })
                } else {
                    None // Fizzle if attacker no longer exists
                }
            }
            EffectDefinition::BuffStats { attack, health, .. } => {
                // Debuff the attacker
                if state.players[attacker_player.index()].get_creature(attacker_slot).is_some() {
                    Some(Effect::BuffStats { target: attacker_target, attack: *attack, health: *health, filter: None })
                } else {
                    None
                }
            }
            EffectDefinition::Heal { amount, .. } => {
                // Heal the defending player (the one who set up the Ambush)
                Some(Effect::Heal { target: EffectTarget::Player(source_player), amount: *amount, filter: None })
            }
            EffectDefinition::Draw { count } => {
                Some(Effect::Draw { player: source_player, count: *count })
            }
            _ => None,
        };

        if let Some(effect) = effect {
            effect_queue.push(effect, source);
        }
    }

    effect_queue.process_all(state, card_db);
}

/// Process StartOfTurn triggered effects for a player's commander.
fn process_commander_start_of_turn_triggers(
    state: &mut GameState,
    card_db: &CardDatabase,
    effect_queue: &mut EffectQueue,
    player: PlayerId,
) {
    for (effect, source) in collect_commander_start_of_turn_effects(state, player, card_db) {
        effect_queue.push(effect, source);
    }
}
