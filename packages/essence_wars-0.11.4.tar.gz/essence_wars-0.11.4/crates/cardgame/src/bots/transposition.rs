//! Transposition Table for Alpha-Beta search.
//!
//! Uses Zobrist hashing to efficiently detect when the same position has been
//! reached via different move orders, avoiding redundant search.
//!
//! # Architecture
//! - `ZobristHasher`: Generates incremental hash values for game states
//! - `TranspositionTable`: Caches search results with replacement strategy
//!
//! # Hash Components
//! For each position, we hash:
//! - Creatures: card_id, slot, attack, health, keywords, exhausted status
//! - Supports: card_id, slot, durability
//! - Resources: life, essence, action_points per player
//! - Active player and turn number

use std::sync::OnceLock;

use crate::actions::Action;
use crate::core::state::GameState;

/// Number of random values for Zobrist hashing.
/// Layout (all ranges use pure indexed XOR — no wrapping_add):
/// - [0..5000]:    Creature card IDs: (player*5 + slot)*500 + card_id%500  = 2*5*500
/// - [5000..6000]: Creature attack:   (player*5 + slot)*100 + attack_val   = 2*5*100
/// - [6000..7000]: Creature health:   (player*5 + slot)*100 + health_val   = 2*5*100
/// - [7000..7160]: Creature keywords: (player*5 + slot)*16 + bit_index     = 2*5*16 (one entry per bit)
/// - [7160..7170]: Creature exhausted status:  player*5 + slot             = 2*5
/// - [7170..7370]: Support card IDs:  player*100 + slot*50 + card_id%50   = 2*2*50
/// - [7370..7410]: Support durability: (player*2 + slot)*10 + dur_val      = 2*2*10 (cap 9)
/// - [7410..7472]: Life values (0-30): player*31 + life_val                = 2*31
/// - [7472..7492]: Essence values (0-9): player*10 + essence_val           = 2*10
/// - [7492..7500]: Action points (0-3): player*4 + ap_val                  = 2*4
/// - [7500..7502]: Active player                                           = 2
/// - [7502..7562]: Turn number (mod 60)                                    = 60
const ZOBRIST_TABLE_SIZE: usize = 8000;

/// Pre-computed random values for Zobrist hashing.
static ZOBRIST_TABLE: OnceLock<[u64; ZOBRIST_TABLE_SIZE]> = OnceLock::new();

fn get_zobrist_table() -> &'static [u64; ZOBRIST_TABLE_SIZE] {
    ZOBRIST_TABLE.get_or_init(|| {
        use std::hash::{Hash, Hasher};
        use std::collections::hash_map::DefaultHasher;

        let mut table = [0u64; ZOBRIST_TABLE_SIZE];

        // Use a deterministic seed for reproducibility
        let seed: u64 = 0xDEADBEEF_CAFEBABE;

        for (i, entry) in table.iter_mut().enumerate() {
            let mut hasher = DefaultHasher::new();
            seed.hash(&mut hasher);
            i.hash(&mut hasher);
            *entry = hasher.finish();
        }

        table
    })
}

/// Compute Zobrist hash for a game state.
///
/// This is a fast incremental hash that XORs together pre-computed random
/// values based on game features. The result is a 64-bit hash that uniquely
/// identifies the position with high probability.
///
/// Every component uses a pure indexed lookup (one independent random value
/// per (feature, value) pair) so XOR contributions have full 64-bit entropy.
pub fn zobrist_hash(state: &GameState) -> u64 {
    let table = get_zobrist_table();
    let mut hash: u64 = 0;

    // Hash creatures for both players
    for (player_idx, player_state) in state.players.iter().enumerate() {
        for creature in &player_state.creatures {
            let slot = creature.slot.0 as usize;
            let slot_idx = player_idx * 5 + slot; // 0..10

            // Card ID (mod 500 to fit in range)
            hash ^= table[slot_idx * 500 + (creature.card_id.0 as usize) % 500];

            // Attack: clamp to [0, 99], offset by 50 to handle negatives
            let attack_val = (creature.attack as i32 + 50).clamp(0, 99) as usize;
            hash ^= table[5000 + slot_idx * 100 + attack_val];

            // Health: clamp to [0, 99]
            let health_val = creature.current_health.clamp(0, 99) as usize;
            hash ^= table[6000 + slot_idx * 100 + health_val];

            // Keywords: one independent entry per set bit
            for bit in 0..16usize {
                if creature.keywords.0 & (1 << bit) != 0 {
                    hash ^= table[7000 + slot_idx * 16 + bit];
                }
            }

            // Exhausted status
            if creature.status.is_exhausted() {
                hash ^= table[7160 + slot_idx];
            }
        }

        // Hash supports
        for support in &player_state.supports {
            let slot = support.slot.0 as usize;

            // Card ID (mod 50 to fit in range)
            hash ^= table[7170 + player_idx * 100 + slot * 50 + (support.card_id.0 as usize) % 50];

            // Durability (cap at 9 — max seen in cards is 4)
            let dur_val = (support.current_durability as usize).min(9);
            hash ^= table[7370 + (player_idx * 2 + slot) * 10 + dur_val];
        }

        // Life (0-30)
        let life_val = player_state.life.clamp(0, 30) as usize;
        hash ^= table[7410 + player_idx * 31 + life_val];

        // Essence (0-9)
        let essence_val = player_state.current_essence.min(9) as usize;
        hash ^= table[7472 + player_idx * 10 + essence_val];

        // Action points (0-3)
        let ap_val = player_state.action_points.min(3) as usize;
        hash ^= table[7492 + player_idx * 4 + ap_val];
    }

    // Active player
    hash ^= table[7500 + state.active_player.index()];

    // Turn number (mod 60)
    hash ^= table[7502 + (state.current_turn as usize % 60)];

    hash
}

/// Type of bound stored in transposition table entry.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Bound {
    /// Exact score (PV node)
    Exact,
    /// Lower bound (fail-high / beta cutoff)
    Lower,
    /// Upper bound (fail-low / alpha cutoff)
    Upper,
}

/// Entry in the transposition table.
#[derive(Clone, Debug)]
#[allow(dead_code)] // best_move stored for future move ordering enhancement
pub struct TTEntry {
    /// Zobrist hash of the position (for collision detection)
    pub hash: u64,
    /// Search depth at which this entry was computed
    pub depth: u32,
    /// Evaluation score
    pub score: f32,
    /// Type of bound
    pub bound: Bound,
    /// Best move found (for move ordering)
    pub best_move: Option<Action>,
    /// Age (generation) for replacement strategy
    pub age: u8,
}

impl TTEntry {
    /// Create a new entry.
    #[allow(dead_code)]
    pub fn new(hash: u64, depth: u32, score: f32, bound: Bound, best_move: Option<Action>) -> Self {
        Self {
            hash,
            depth,
            score,
            bound,
            best_move,
            age: 0,
        }
    }
}

/// Transposition table with configurable size.
///
/// Uses a simple replacement strategy: replace if new entry has greater depth
/// or if the existing entry is from an older search.
pub struct TranspositionTable {
    /// Table entries (power of 2 size for fast modulo)
    entries: Vec<Option<TTEntry>>,
    /// Mask for index calculation (size - 1)
    mask: usize,
    /// Current generation/age for replacement
    generation: u8,
    /// Statistics
    pub hits: u64,
    pub misses: u64,
    pub collisions: u64,
}

impl TranspositionTable {
    /// Create a new transposition table with the given size (in entries).
    /// Size will be rounded up to the next power of 2.
    pub fn new(size_hint: usize) -> Self {
        let size = size_hint.next_power_of_two().max(1024);
        Self {
            entries: vec![None; size],
            mask: size - 1,
            generation: 0,
            hits: 0,
            misses: 0,
            collisions: 0,
        }
    }

    /// Create a table with approximately the given memory budget (in MB).
    pub fn with_memory_mb(mb: usize) -> Self {
        let entry_size = std::mem::size_of::<Option<TTEntry>>();
        let entries = (mb * 1024 * 1024) / entry_size;
        Self::new(entries)
    }

    /// Increment the generation counter (call at start of each new search).
    pub fn new_search(&mut self) {
        self.generation = self.generation.wrapping_add(1);
    }

    /// Clear all entries.
    pub fn clear(&mut self) {
        for entry in &mut self.entries {
            *entry = None;
        }
        self.hits = 0;
        self.misses = 0;
        self.collisions = 0;
    }

    /// Probe the table for an entry.
    pub fn probe(&mut self, hash: u64) -> Option<&TTEntry> {
        let index = (hash as usize) & self.mask;

        if let Some(ref entry) = self.entries[index] {
            if entry.hash == hash {
                self.hits += 1;
                return Some(entry);
            } else {
                self.collisions += 1;
            }
        }

        self.misses += 1;
        None
    }

    /// Store an entry in the table.
    pub fn store(&mut self, hash: u64, depth: u32, score: f32, bound: Bound, best_move: Option<Action>) {
        let index = (hash as usize) & self.mask;

        let should_replace = match &self.entries[index] {
            None => true,
            Some(existing) => {
                // Replace if:
                // 1. Different position (collision)
                // 2. New entry has greater depth
                // 3. Existing entry is from older generation
                existing.hash != hash
                    || depth >= existing.depth
                    || existing.age != self.generation
            }
        };

        if should_replace {
            self.entries[index] = Some(TTEntry {
                hash,
                depth,
                score,
                bound,
                best_move,
                age: self.generation,
            });
        }
    }

    /// Get fill rate (percentage of entries used).
    #[allow(dead_code)]
    pub fn fill_rate(&self) -> f64 {
        let used = self.entries.iter().filter(|e| e.is_some()).count();
        (used as f64 / self.entries.len() as f64) * 100.0
    }

    /// Get hit rate (percentage of probes that found an entry).
    #[allow(dead_code)]
    pub fn hit_rate(&self) -> f64 {
        let total = self.hits + self.misses;
        if total == 0 {
            0.0
        } else {
            (self.hits as f64 / total as f64) * 100.0
        }
    }
}

impl Default for TranspositionTable {
    fn default() -> Self {
        // Default: 16MB table (~200k entries)
        Self::with_memory_mb(16)
    }
}

// =============================================================================
// MCTS Transposition Table
// =============================================================================

/// Entry in the MCTS transposition table.
///
/// Unlike Alpha-Beta's TT (which stores bounds), MCTS TT stores value estimates
/// from previous rollouts. These can be used to:
/// 1. Skip rollouts for positions we've seen many times
/// 2. Initialize node values from cached estimates
#[derive(Clone, Debug)]
pub struct MctsTranspositionEntry {
    /// Zobrist hash of the position (for collision detection)
    pub hash: u64,
    /// Number of visits to this position across the search
    pub visits: u32,
    /// Sum of rewards from rollouts starting from this position
    pub total_reward: f32,
    /// Age (generation) for replacement strategy
    pub age: u8,
}

impl MctsTranspositionEntry {
    /// Create a new entry.
    pub fn new(hash: u64) -> Self {
        Self {
            hash,
            visits: 0,
            total_reward: 0.0,
            age: 0,
        }
    }

    /// Get the average value estimate for this position.
    /// Returns 0.5 (neutral) if no visits.
    pub fn average_value(&self) -> f32 {
        if self.visits == 0 {
            0.5
        } else {
            self.total_reward / self.visits as f32
        }
    }

    /// Update with a new rollout result.
    pub fn update(&mut self, win: bool) {
        self.visits += 1;
        self.total_reward += if win { 1.0 } else { 0.0 };
    }
}

/// MCTS-specific transposition table.
///
/// Caches position evaluations across the search to avoid redundant rollouts.
/// Uses a simple replacement strategy based on visit count and age.
pub struct MctsTranspositionTable {
    /// Table entries (power of 2 size for fast modulo)
    entries: Vec<Option<MctsTranspositionEntry>>,
    /// Mask for index calculation (size - 1)
    mask: usize,
    /// Current generation/age for replacement
    generation: u8,
    /// Statistics
    pub hits: u64,
    pub misses: u64,
}

impl MctsTranspositionTable {
    /// Create a new MCTS transposition table with the given size (in entries).
    /// Size will be rounded up to the next power of 2.
    pub fn new(size_hint: usize) -> Self {
        let size = size_hint.next_power_of_two().max(1024);
        Self {
            entries: vec![None; size],
            mask: size - 1,
            generation: 0,
            hits: 0,
            misses: 0,
        }
    }

    /// Create a table with approximately the given memory budget (in MB).
    pub fn with_memory_mb(mb: usize) -> Self {
        let entry_size = std::mem::size_of::<Option<MctsTranspositionEntry>>();
        let entries = (mb * 1024 * 1024) / entry_size;
        Self::new(entries)
    }

    /// Increment the generation counter (call at start of each new search).
    pub fn new_search(&mut self) {
        self.generation = self.generation.wrapping_add(1);
    }

    /// Clear all entries.
    #[allow(dead_code)]
    pub fn clear(&mut self) {
        for entry in &mut self.entries {
            *entry = None;
        }
        self.hits = 0;
        self.misses = 0;
    }

    /// Probe the table for an entry.
    /// Returns the entry if found with matching hash.
    pub fn probe(&mut self, hash: u64) -> Option<&MctsTranspositionEntry> {
        let index = (hash as usize) & self.mask;

        if let Some(ref entry) = self.entries[index] {
            if entry.hash == hash {
                self.hits += 1;
                return Some(entry);
            }
        }

        self.misses += 1;
        None
    }

    /// Update the table with a rollout result.
    /// Creates a new entry if none exists, or updates the existing one.
    pub fn update(&mut self, hash: u64, win: bool) {
        let index = (hash as usize) & self.mask;

        match &mut self.entries[index] {
            Some(entry) if entry.hash == hash => {
                // Update existing entry
                entry.update(win);
                entry.age = self.generation;
            }
            slot => {
                // Replace with new entry (either empty or collision)
                let mut entry = MctsTranspositionEntry::new(hash);
                entry.update(win);
                entry.age = self.generation;
                *slot = Some(entry);
            }
        }
    }

    /// Get hit rate (percentage of probes that found an entry).
    #[allow(dead_code)]
    pub fn hit_rate(&self) -> f64 {
        let total = self.hits + self.misses;
        if total == 0 {
            0.0
        } else {
            (self.hits as f64 / total as f64) * 100.0
        }
    }
}

impl Default for MctsTranspositionTable {
    fn default() -> Self {
        // Default: 8MB table for MCTS (smaller than AB since entries are simpler)
        Self::with_memory_mb(8)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_zobrist_table_initialized() {
        let table = get_zobrist_table();
        // Check that values are non-zero and varied
        assert!(table[0] != 0);
        assert!(table[0] != table[1]);
        assert!(table[100] != table[101]);
    }

    #[test]
    fn test_transposition_table_basic() {
        let mut tt = TranspositionTable::new(1024);

        // Store an entry
        tt.store(12345, 5, 1.5, Bound::Exact, None);

        // Probe should find it
        let entry = tt.probe(12345);
        assert!(entry.is_some());
        let entry = entry.unwrap();
        assert_eq!(entry.depth, 5);
        assert_eq!(entry.score, 1.5);
        assert_eq!(entry.bound, Bound::Exact);

        // Different hash should miss
        assert!(tt.probe(99999).is_none());
    }

    #[test]
    fn test_replacement_strategy() {
        let mut tt = TranspositionTable::new(1024);

        // Store entry at depth 3
        tt.store(12345, 3, 1.0, Bound::Exact, None);

        // Try to replace with depth 2 (should not replace)
        tt.store(12345, 2, 2.0, Bound::Exact, None);
        let entry = tt.probe(12345).unwrap();
        assert_eq!(entry.depth, 3);
        assert_eq!(entry.score, 1.0);

        // Replace with depth 5 (should replace)
        tt.store(12345, 5, 3.0, Bound::Exact, None);
        let entry = tt.probe(12345).unwrap();
        assert_eq!(entry.depth, 5);
        assert_eq!(entry.score, 3.0);
    }
}
