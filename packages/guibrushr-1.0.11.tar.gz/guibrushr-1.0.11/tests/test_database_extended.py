"""Extended DB tests: select_retrieval_by_target, _prepare_retrieval_filters, context."""

import pytest
from unittest.mock import patch


class TestDBSelectRetrieval:
    @patch("GUIBRUSHR.GUI.DataInterface.DBSQLite3.messagebox")
    def test_select_retrieval_found(self, mock_msgbox, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_retrieval_into_DB(
                "2024-01-01_10:00", "HD209", "20210101", "free",
                "Guillot", False, False, "auto", "petitRADTRANS",
                "High", "PCA", "Transmission", "GIANO-B", "user1",
                "p1=1", "p2=2", "H2O", "s=1"
            )
            result = db.select_retrieval_by_target("user1", "HD209")
            assert result[0] is not None
            assert "2024-01-01_10:00" in result[0]

    def test_select_retrieval_not_found(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            result = db.select_retrieval_by_target("nobody", "nothing")
            assert result[0] is None

    @patch("GUIBRUSHR.GUI.DataInterface.DBSQLite3.messagebox")
    def test_select_with_chemistry_filter(self, mock_msgbox, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_retrieval_into_DB(
                "2024-01-02_10:00", "HD209", "20210101", "free",
                "Guillot", False, False, "auto", "petitRADTRANS",
                "High", "PCA", "Transmission", "GIANO-B", "user1",
                "", "", "", ""
            )
            db.insert_retrieval_into_DB(
                "2024-01-03_10:00", "HD209", "20210101", "equilibrium",
                "Guillot", False, False, "auto", "petitRADTRANS",
                "High", "PCA", "Transmission", "GIANO-B", "user1",
                "", "", "", ""
            )
            result = db.select_retrieval_by_target("user1", "HD209", chemistry="free")
            assert result[0] is not None
            assert "2024-01-02_10:00" in result[0]
            assert "2024-01-03_10:00" not in result[0]


class TestPrepareRetrievalFilters:
    def test_resolution_high(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            filters = db._prepare_retrieval_filters("High", "None", "None", "None")
            assert filters["resolution"] == "H"

    def test_resolution_low(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            filters = db._prepare_retrieval_filters("Low", "None", "None", "None")
            assert filters["resolution"] == "L"

    def test_resolution_high_low(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            filters = db._prepare_retrieval_filters("High-Low", "None", "None", "None")
            assert filters["resolution"] == "HL"

    def test_scattering_true(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            filters = db._prepare_retrieval_filters("None", "None", "True", "None")
            assert filters["scattering"] == "TRUE"

    def test_scattering_false(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            filters = db._prepare_retrieval_filters("None", "None", "False", "None")
            assert filters["scattering"] == "FALSE"

    def test_none_pass_through(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            filters = db._prepare_retrieval_filters("None", "None", "None", "None")
            assert filters["resolution"] == "None"
            assert filters["scattering"] == "None"
