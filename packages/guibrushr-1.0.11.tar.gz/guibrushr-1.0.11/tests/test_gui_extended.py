"""Extended GUI tests: MyTable, MyPanel variations, GraphicsConfig, DataInterface."""

import pytest
import numpy as np
from pathlib import Path


# ---------------------------------------------------------------------------
# GraphicsConfig
# ---------------------------------------------------------------------------

class TestGraphicsConfig:
    def test_defaults_exist(self):
        from GUIBRUSHR.GUI.LAYOUT.GraphicsConfig import GraphicsConfig as GC
        assert GC.ASPECT_RATIO > 0
        assert GC.MIN_WIDTH > 0
        assert GC.REFERENCE_HEIGHT > 0
        assert isinstance(GC.FONT_FAMILY, str)
        assert GC.FONT_SIZE_LABEL > 0
        assert GC.MIN_SCALE < GC.MAX_SCALE

    def test_font_sizes_positive(self):
        from GUIBRUSHR.GUI.LAYOUT.GraphicsConfig import GraphicsConfig as GC
        for attr in [
            "FONT_SIZE_LABEL", "FONT_SIZE_LABEL_LARGE", "FONT_SIZE_BUTTON",
            "FONT_SIZE_ENTRY", "FONT_SIZE_TAB", "FONT_SIZE_TREE",
        ]:
            assert getattr(GC, attr) > 0

    def test_window_constraints(self):
        from GUIBRUSHR.GUI.LAYOUT.GraphicsConfig import GraphicsConfig as GC
        assert GC.MIN_WIDTH <= GC.DEFAULT_WIDTH <= GC.MAX_WIDTH
        assert GC.MIN_HEIGHT <= GC.DEFAULT_HEIGHT <= GC.MAX_HEIGHT


# ---------------------------------------------------------------------------
# MyTable
# ---------------------------------------------------------------------------

class TestMyTable:
    def test_creation(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTable import MyTable
        table = MyTable(tk_frame, ["Name", "Value"], [100, 100])
        assert table["columns"] == ("Name", "Value")

    def test_column_types_default_to_str(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTable import MyTable
        table = MyTable(tk_frame, ["A", "B"], [50, 50])
        assert all(t == str for t in table.column_types)

    def test_custom_column_types(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTable import MyTable
        table = MyTable(tk_frame, ["A", "B"], [50, 50], list_type=[int, float])
        assert table.column_types == [int, float]

    def test_insert_and_get(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTable import MyTable
        table = MyTable(tk_frame, ["Name", "Value"], [100, 100])
        table.insert("", "end", values=("test", 42))
        items = table.get_children()
        assert len(items) == 1
        vals = table.item(items[0], "values")
        assert vals[0] == "test"

    def test_get_arr_values_no_selection(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTable import MyTable
        table = MyTable(tk_frame, ["A"], [50])
        assert table.get_arr_values() is None

    def test_with_height(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTable import MyTable
        table = MyTable(tk_frame, ["A"], [50], height=5)
        assert table.cget("height") == 5


# ---------------------------------------------------------------------------
# MyPanel variations
# ---------------------------------------------------------------------------

class TestMyPanelVariations:
    def test_columnspan(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
        panel = MyPanel(tk_frame, color="#AAA", row=0, column=0, columnspan=3)
        info = panel.grid_info()
        assert info["columnspan"] == 3

    def test_rowspan(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
        panel = MyPanel(tk_frame, color="#BBB", row=0, column=0, rowspan=2)
        info = panel.grid_info()
        assert info["rowspan"] == 2


# ---------------------------------------------------------------------------
# DataInterface helpers (filesystem-based, no DB needed)
# ---------------------------------------------------------------------------

class TestDataInterfaceGetTargetList:
    def test_with_targets(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import get_target_list
        (tmp_path / "HD209458b").mkdir()
        (tmp_path / "WASP-77Ab").mkdir()
        result = get_target_list(tmp_path)
        assert "HD209458b" in result
        assert "WASP-77Ab" in result

    def test_empty_folder(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import get_target_list
        result = get_target_list(tmp_path)
        assert list(result) == ["None"]

    def test_ignores_files(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import get_target_list
        (tmp_path / "not_a_dir.txt").touch()
        (tmp_path / "RealTarget").mkdir()
        result = get_target_list(tmp_path)
        assert list(result) == ["RealTarget"]


class TestDataInterfaceGetListCCModels:
    def test_with_models(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import get_list_cross_corr_models
        model_dir = tmp_path / "HD209" / "Models" / "Transmission"
        (model_dir / "model_A").mkdir(parents=True)
        (model_dir / "model_B").mkdir(parents=True)
        result = get_list_cross_corr_models(tmp_path, "HD209", "Transmission")
        assert "model_A" in result
        assert "model_B" in result

    def test_no_models(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import get_list_cross_corr_models
        result = get_list_cross_corr_models(tmp_path, "HD209", "Transmission")
        assert result == {"None": "None"}


class TestInsertTargetCatalog:
    def test_creates_directories_and_yaml(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import insert_target_catalog
        insert_target_catalog(
            tmp_path, "TestPlanet",
            radius=1.2, mass=0.9, gravity=1500, t_eq=1500,
            stellar_radius=1.0, stellar_mass=1.0, p0=-2, hjd0=2459000,
            period=3.5, vsys=-20, limph_T14=0.015, limph_T12=0.002,
            limph_T23=0.011, kp=150, ks=0.05, ecc=0, t14=2.5, t12=0.3, t23=1.9
        )
        info_yaml = tmp_path / "TestPlanet" / "info.yaml"
        assert info_yaml.exists()
        star_dir = tmp_path / "TestPlanet" / "Star_Spectrum"
        assert star_dir.is_dir()
        hr_trans = tmp_path / "TestPlanet" / "HR_Instruments" / "Transmission"
        assert hr_trans.is_dir()


class TestInsertNightInTarget:
    def test_creates_night_directory(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import insert_night_in_target
        path = insert_night_in_target(tmp_path, "HD209", "Transmission", "GIANO-B", "20210615")
        assert path.exists()
        assert "20210615" in str(path)


class TestInsertInstrumentLR:
    def test_creates_lr_directory(self, tmp_path):
        from GUIBRUSHR.GUI.DataInterface.DataInterface import insert_instrument_lr_in_target
        path = insert_instrument_lr_in_target(tmp_path, "HD209", "Emission", "WFC3")
        assert path.exists()
        assert "LR_Instruments" in str(path)
