"""Tests for Retrieval module classes: Pressure, Wavelength, SpeciesMolec."""

import pytest
import numpy as np


class TestPressure:
    def test_logspace_generation(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Pressure import Pressure
        p = Pressure(-6, 2, 100)
        assert len(p.pressures) == 100
        assert p.pressures[0] == pytest.approx(1e-6)
        assert p.pressures[-1] == pytest.approx(1e2)

    def test_stores_params(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Pressure import Pressure
        p = Pressure(-4, 3, 50)
        assert p.range_min_pressures == -4
        assert p.range_max_pressures == 3
        assert p.n_layers == 50

    def test_monotonically_increasing(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Pressure import Pressure
        p = Pressure(-6, 2, 200)
        assert np.all(np.diff(p.pressures) > 0)

    def test_single_layer(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Pressure import Pressure
        p = Pressure(-3, -3, 1)
        assert len(p.pressures) == 1
        assert p.pressures[0] == pytest.approx(1e-3)


class TestWavelength:
    def test_default_none(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Wavelength import Wavelength
        w = Wavelength()
        assert w.min_wl_hr is None
        assert w.max_wl_hr is None
        assert w.min_wl_lr is None
        assert w.max_wl_lr is None

    def test_hr_values(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Wavelength import Wavelength
        w = Wavelength(min_wl_hr=0.95, max_wl_hr=2.45)
        assert w.min_wl_hr == 0.95
        assert w.max_wl_hr == 2.45

    def test_lr_values(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Wavelength import Wavelength
        w = Wavelength(min_wl_lr=0.3, max_wl_lr=5.0)
        assert w.min_wl_lr == 0.3
        assert w.max_wl_lr == 5.0

    def test_mixed(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.Wavelength import Wavelength
        w = Wavelength(min_wl_lr=0.5, max_wl_lr=3.0, min_wl_hr=1.0, max_wl_hr=2.5)
        assert w.min_wl_lr == 0.5
        assert w.min_wl_hr == 1.0


class TestSpeciesMolec:
    def test_manual_composition(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.SpeciesMolec import SpeciesMolec
        composition = {"H2O": 1e-4, "CO": 1e-3}
        sm = SpeciesMolec(
            continum_opacity=["H2-H2", "H2-He"],
            line_species=["H2O", "CO"],
            line_species_isotope=[],
            line_species_complete_name_hr=["H2O_main_iso"],
            line_species_complete_name_lr=["H2O_lr"],
            list_condensed_molecules=[],
            rayleigh_species=["H2", "He"],
            mass_vector=[2.0, 4.0],
            start_molecs=0,
            manual_model_composition=composition
        )
        assert sm.composition == composition
        assert sm.include_h_m is False
        assert sm.skip_molec_param_array == 2

    def test_h_minus_detection(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.SpeciesMolec import SpeciesMolec
        sm = SpeciesMolec(
            continum_opacity=["H2-H2", "H-"],
            line_species=[],
            line_species_isotope=[],
            line_species_complete_name_hr=[],
            line_species_complete_name_lr=[],
            list_condensed_molecules=[],
            rayleigh_species=[],
            mass_vector=[],
            start_molecs=0,
            manual_model_composition={}
        )
        assert sm.include_h_m is True

    def test_attributes_stored(self):
        from GUIBRUSHR.Retrieval.ModelCalculation.Classes.SpeciesMolec import SpeciesMolec
        sm = SpeciesMolec(
            continum_opacity=["H2-H2"],
            line_species=["CO"],
            line_species_isotope=["13CO"],
            line_species_complete_name_hr=["CO_hr"],
            line_species_complete_name_lr=["CO_lr"],
            list_condensed_molecules=["Fe(c)"],
            rayleigh_species=["H2"],
            mass_vector=[28.0],
            start_molecs=5,
            manual_model_composition={"CO": 1e-3}
        )
        assert sm.line_species == ["CO"]
        assert sm.line_species_isotope == ["13CO"]
        assert sm.list_condensed_molecules == ["Fe(c)"]
        assert sm.start_molecs == 5
