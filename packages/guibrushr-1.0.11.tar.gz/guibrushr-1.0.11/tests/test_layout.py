"""Tests for GUIBRUSHR layout components: ScaleManager, MyPanel."""

import tkinter as tk
import pytest


class TestScaleManager:
    def test_singleton_init(self, tk_root, scale_manager):
        from GUIBRUSHR.GUI.LAYOUT.ScaleManager import ScaleManager
        assert ScaleManager.get() is scale_manager

    def test_initial_scale_is_one(self, scale_manager):
        assert scale_manager.scale == 1.0

    def test_scaled_returns_int(self, scale_manager):
        result = scale_manager.scaled(12)
        assert isinstance(result, int)
        assert result >= 7

    def test_scaled_minimum_is_7(self, scale_manager):
        result = scale_manager.scaled(1)
        assert result == 7

    def test_font_objects_exist(self, scale_manager):
        import tkinter.font as tkfont
        assert isinstance(scale_manager.font_label, tkfont.Font)
        assert isinstance(scale_manager.font_button, tkfont.Font)
        assert isinstance(scale_manager.font_entry, tkfont.Font)


class TestMyPanel:
    def test_creation(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
        panel = MyPanel(tk_frame, color="#CCCCCC", row=0, column=0)
        assert panel.cget("bg") == "#CCCCCC"

    def test_invisible_panel(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
        panel = MyPanel(tk_frame, color="#CCCCCC", row=0, column=0, visible=False)
        # Invisible panels should not have grid info
        assert panel.grid_info() == {}

    def test_visible_panel_has_grid(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
        panel = MyPanel(tk_frame, color="#CCCCCC", row=0, column=0, visible=True)
        info = panel.grid_info()
        assert info["row"] == 0
        assert info["column"] == 0

    def test_highlight_border(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
        panel = MyPanel(tk_frame, color="#AAAAAA", row=0, column=0)
        assert panel.cget("highlightbackground") == "black"
        assert int(panel.cget("highlightthickness")) == 1
