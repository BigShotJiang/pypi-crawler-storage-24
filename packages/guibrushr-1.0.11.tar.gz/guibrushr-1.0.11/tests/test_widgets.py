"""Tests for GUIBRUSHR custom Tkinter widgets."""

import tkinter as tk
import pytest


class TestMyLabel:
    def test_creation(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyLabel import MyLabel
        lbl = MyLabel(tk_frame, row=0, column=0, label_text="Hello")
        assert lbl.get_text() == "Hello"

    def test_set_text(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyLabel import MyLabel
        lbl = MyLabel(tk_frame, row=0, column=0, label_text="Before")
        lbl.set_text("After")
        assert lbl.get_text() == "After"

    def test_custom_color(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyLabel import MyLabel
        lbl = MyLabel(tk_frame, row=0, column=0, color="#FF0000", label_text="Red")
        assert lbl.cget("bg") == "#FF0000"


class TestMyButton:
    def test_creation(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyButton import MyButton
        clicked = []
        btn = MyButton(tk_frame, row=0, column=0, text="Click", bg="white", command=lambda: clicked.append(1))
        assert btn.button.cget("text") == "Click"

    def test_command_invocation(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyButton import MyButton
        clicked = []
        btn = MyButton(tk_frame, row=0, column=0, text="Go", bg="white", command=lambda: clicked.append(True))
        btn.button.invoke()
        assert clicked == [True]

    def test_set_status_disabled(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyButton import MyButton
        btn = MyButton(tk_frame, row=0, column=0, text="X", bg="white", command=lambda: None)
        btn.set_status("disabled")
        assert str(btn.button.cget("state")) == "disabled"


class TestMyEntry:
    def test_initial_value(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyEntry import MyEntry
        entry = MyEntry(tk_frame, row=0, column=0, text="42")
        assert entry.get_value() == "42"

    def test_set_value(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyEntry import MyEntry
        entry = MyEntry(tk_frame, row=0, column=0, text="old")
        entry.set_value("new")
        assert entry.get_value() == "new"

    def test_with_label(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyEntry import MyEntry
        entry = MyEntry(tk_frame, row=0, column=0, text="val", label_text="Label:")
        assert entry.get_value() == "val"

    def test_set_status(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyEntry import MyEntry
        entry = MyEntry(tk_frame, row=0, column=0, text="test")
        entry.set_status("disabled")
        assert str(entry.entry.cget("state")) == "disabled"


class TestMyCheckBox:
    def test_default_unchecked(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyCheckBox import MyCheckBox
        cb = MyCheckBox(tk_frame, row=0, column=0, text="Check me")
        assert cb.get_value() == 0

    def test_initial_checked(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyCheckBox import MyCheckBox
        cb = MyCheckBox(tk_frame, row=0, column=0, text="Check me", initial_value=1)
        assert cb.get_value() == 1

    def test_set_value(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyCheckBox import MyCheckBox
        cb = MyCheckBox(tk_frame, row=0, column=0)
        cb.set_value(1)
        assert cb.get_value() == 1
        cb.set_value(0)
        assert cb.get_value() == 0


class TestMyDropdown:
    def test_creation_with_options(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyDropDown import MyDropdown
        dd = MyDropdown(tk_frame, row=0, column=0, options=["A", "B", "C"])
        assert dd.get_value() == "A"

    def test_initial_value_index(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyDropDown import MyDropdown
        dd = MyDropdown(tk_frame, row=0, column=0, options=["X", "Y", "Z"], initial_value=2)
        assert dd.get_value() == "Z"

    def test_set_value(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyDropDown import MyDropdown
        dd = MyDropdown(tk_frame, row=0, column=0, options=["A", "B"])
        dd.set_value("B")
        assert dd.get_value() == "B"

    def test_none_options_defaults(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyDropDown import MyDropdown
        dd = MyDropdown(tk_frame, row=0, column=0, options=None)
        assert dd.get_value() == "None"

    def test_callback(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyDropDown import MyDropdown
        changes = []
        dd = MyDropdown(tk_frame, row=0, column=0, options=["A", "B"])
        dd.set_callback(lambda: changes.append(1))
        dd.set_value("B")
        tk_frame.update_idletasks()
        assert len(changes) >= 1


class TestMyTextField:
    def test_initial_text(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTextField import MyTextField
        tf = MyTextField(tk_frame, row=0, column=0, text="Hello World")
        assert tf.get_text() == "Hello World"

    def test_insert_text(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTextField import MyTextField
        tf = MyTextField(tk_frame, row=0, column=0, text="old")
        tf.insert_text("new content")
        assert tf.get_text() == "new content"

    def test_set_status(self, tk_frame, scale_manager):
        from GUIBRUSHR.GUI.WIDGET.MyTextField import MyTextField
        tf = MyTextField(tk_frame, row=0, column=0, text="x")
        tf.set_status("disabled")
        assert str(tf.text_widget.cget("state")) == "disabled"
