"""Tests for general_functions.py utility functions."""

import pytest
import numpy as np
from pandas import DataFrame


class TestGetCsvValue:
    def test_found(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_csv_value
        df = DataFrame({"Variable": ["a", "b", "c"], "Value": [1, 2, 3]})
        assert get_csv_value(df, "b") == 2

    def test_not_found(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_csv_value
        df = DataFrame({"Variable": ["a"], "Value": [1]})
        assert get_csv_value(df, "missing") is None

    def test_custom_columns(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_csv_value
        df = DataFrame({"Key": ["x"], "Result": [42]})
        assert get_csv_value(df, "x", search_column="Key", target_column="Result") == 42


class TestGetDepthFilename:
    def test_emission(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_depth_filename
        assert get_depth_filename("Emission") == "emission_depth.fits"

    def test_transmission(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_depth_filename
        assert get_depth_filename("Transmission") == "transmission_depth.fits"


class TestCreateAndReadFits:
    def test_roundtrip(self, tmp_path):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import create_fits, read_fits
        data = np.array([[1.0, 2.0], [3.0, 4.0]])
        path = str(tmp_path / "test.fits")
        create_fits(data, path)
        result = read_fits(path)
        np.testing.assert_array_almost_equal(result, data)

    def test_read_with_transpose(self, sample_fits):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import read_fits
        path, original = sample_fits
        result = read_fits(str(path), transpose=True)
        expected = np.transpose(original)
        np.testing.assert_array_almost_equal(result, expected)

    def test_read_with_intransit(self, sample_fits):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import read_fits
        path, original = sample_fits  # shape (4, 5, 6)
        intransit = np.array([0, 2, 4])
        result = read_fits(str(path), intransit=intransit)
        expected = original[:, intransit, :]
        np.testing.assert_array_almost_equal(result, expected)


class TestCCorrelate:
    def test_perfect_correlation(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import c_correlate
        signal = np.sin(np.linspace(0, 2 * np.pi, 100))
        result = c_correlate(signal, signal, np.array([0]))
        assert abs(result[0] - 1.0) < 1e-10

    def test_anticorrelation(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import c_correlate
        signal = np.sin(np.linspace(0, 2 * np.pi, 100))
        result = c_correlate(signal, -signal, np.array([0]))
        assert abs(result[0] - (-1.0)) < 1e-10

    def test_zero_lag(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import c_correlate
        s1 = np.random.randn(50)
        s2 = np.random.randn(50)
        result = c_correlate(s1, s2, np.array([0]))
        assert -1.0 <= result[0] <= 1.0


class TestSkewedGaussian:
    def test_zero_skew_is_symmetric(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import skewed_gaussian
        x = np.linspace(-5, 5, 101)
        y = skewed_gaussian(x, amp=1.0, center=0.0, width=1.0, skew=0.0)
        # With skew=0, should be symmetric around center
        np.testing.assert_array_almost_equal(y, y[::-1], decimal=10)

    def test_amplitude_scaling(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import skewed_gaussian
        x = np.array([0.0])
        y1 = skewed_gaussian(x, amp=1.0, center=0.0, width=1.0, skew=0.0)
        y2 = skewed_gaussian(x, amp=2.0, center=0.0, width=1.0, skew=0.0)
        assert abs(y2[0] - 2.0 * y1[0]) < 1e-10


class TestComputeTransitDurations:
    def test_circular_orbit(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import compute_transit_durations
        result = compute_transit_durations(
            period=3.5, a_Rs=8.0, k=0.15, inc_deg=87.0, ecc=0.0
        )
        assert "T14" in result
        assert "T23" in result
        assert "T12" in result
        assert result["ecc_factor"] == 1.0
        assert result["T14"] > 0
        assert result["T14_hours"] == result["T14"] * 24.0
        assert result["limph_T14"] == result["T14"] / (2.0 * 3.5)

    def test_t14_greater_than_t23(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import compute_transit_durations
        result = compute_transit_durations(
            period=3.5, a_Rs=8.0, k=0.15, inc_deg=87.0
        )
        assert result["T14"] >= result["T23"]

    def test_t12_equals_half_difference(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import compute_transit_durations
        result = compute_transit_durations(
            period=3.5, a_Rs=8.0, k=0.15, inc_deg=87.0
        )
        expected_t12 = (result["T14"] - result["T23"]) / 2.0
        assert abs(result["T12"] - expected_t12) < 1e-12

    def test_no_transit_raises(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import compute_transit_durations
        with pytest.raises(ValueError, match="No transit"):
            compute_transit_durations(
                period=3.5, a_Rs=8.0, k=0.01, inc_deg=0.0  # face-on = no transit
            )

    def test_eccentric_orbit(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import compute_transit_durations
        result = compute_transit_durations(
            period=3.5, a_Rs=8.0, k=0.15, inc_deg=87.0, ecc=0.1, omega=np.pi / 2
        )
        assert result["ecc_factor"] != 1.0
        assert result["T14"] > 0


class TestEstimateContinuum:
    def test_flat_spectrum(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import estimate_continuum
        spectrum = np.ones(400)
        continuum, normalized = estimate_continuum(spectrum)
        np.testing.assert_array_almost_equal(normalized, np.ones(400), decimal=2)

    def test_output_shapes(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import estimate_continuum
        spectrum = np.random.rand(400) + 1.0
        continuum, normalized = estimate_continuum(spectrum)
        assert continuum.shape == spectrum.shape
        assert normalized.shape == spectrum.shape


class TestMakeSmoothMonoCmap:
    def test_returns_colormap(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import make_smooth_mono_cmap
        import matplotlib.colors as mcolors
        cmap = make_smooth_mono_cmap("#FF0000", name="test_red")
        assert isinstance(cmap, mcolors.LinearSegmentedColormap)
