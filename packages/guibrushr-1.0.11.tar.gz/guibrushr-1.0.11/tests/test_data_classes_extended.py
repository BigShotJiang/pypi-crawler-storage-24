"""Extended tests for data classes: TemperatureProfile, UserTemperatureProfile,
BestFitParametersAndResults, Night.sigma_calc."""

import pytest
import numpy as np
from types import SimpleNamespace


# ---------------------------------------------------------------------------
# Helper: create mock parameter objects with .value and .error
# ---------------------------------------------------------------------------

def make_param(value, error=0.1):
    return SimpleNamespace(value=value, error=error, name=f"p_{value}")


# ---------------------------------------------------------------------------
# TemperatureProfile
# ---------------------------------------------------------------------------

class TestTemperatureProfile:
    def test_isothermal(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile
        pressures = np.logspace(-6, 2, 50)
        params = {"T0": make_param(1500.0)}
        tp = TemperatureProfile(pressures, params, gravity=1000.0)
        temp, err = tp.isot()
        assert temp.shape == (50,)
        np.testing.assert_array_equal(temp, np.full(50, 1500.0))
        assert err is None

    def test_isothermal_missing_param(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile
        pressures = np.logspace(-6, 2, 10)
        tp = TemperatureProfile(pressures, {}, gravity=1000.0)
        with pytest.raises(KeyError, match="T0"):
            tp.isot()

    def test_personalized_linear(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile
        pressures = np.logspace(-6, 2, 100)
        params = {
            "P_low": make_param(1.0),
            "P_high": make_param(-4.0),
            "T_low": make_param(2000.0),
            "T_high": make_param(500.0),
        }
        tp = TemperatureProfile(pressures, params, gravity=1000.0)
        temp, err = tp.personalized()
        assert temp.shape == (100,)
        # At high pressure (> 10^1), temperature should be T_low
        assert temp[pressures > 10] == pytest.approx(2000.0)
        # At low pressure (< 10^-4), temperature should be T_high
        assert temp[pressures < 1e-4][0] == pytest.approx(500.0)
        assert err is None

    def test_personalized_with_error(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile
        pressures = np.logspace(-6, 2, 50)
        params = {
            "P_low": make_param(1.0, 0.5),
            "P_high": make_param(-4.0, 0.5),
            "T_low": make_param(2000.0, 100.0),
            "T_high": make_param(500.0, 50.0),
        }
        tp = TemperatureProfile(pressures, params, gravity=1000.0, error=True)
        temp, err_temps = tp.personalized()
        assert err_temps is not None
        assert err_temps.shape == (50, 100)

    def test_return_rnd_for_error(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile
        pressures = np.logspace(-6, 2, 10)
        params = {"T0": make_param(1500.0, error=100.0)}
        tp = TemperatureProfile(pressures, params, gravity=1000.0)
        samples = tp.return_rnd_for_error("T0", amount=50)
        assert samples.shape == (50,)
        assert np.all(samples >= 1400.0)
        assert np.all(samples <= 1600.0)

    def test_return_rnd_missing_param(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile
        pressures = np.logspace(-6, 2, 10)
        tp = TemperatureProfile(pressures, {}, gravity=1000.0)
        with pytest.raises(KeyError, match="missing"):
            tp.return_rnd_for_error("missing")

    def test_four_node_spline(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile
        pressures = np.logspace(-6, 2, 100)
        params = {
            "T0_node": make_param(500.0),
            "T1_node": make_param(1000.0),
            "T2_node": make_param(1500.0),
            "T3_node": make_param(2000.0),
            "P1_node": make_param(-2.0),
            "P2_node": make_param(0.0),
        }
        tp = TemperatureProfile(pressures, params, gravity=1000.0)
        temp, err = tp.FourNodeSpline()
        assert temp.shape == (100,)
        assert err is None
        # Temperature should be monotonically varying (approximately)
        assert temp[0] != temp[-1]


# ---------------------------------------------------------------------------
# Bernstein polynomial and Bezier curve
# ---------------------------------------------------------------------------

class TestBernsteinAndBezier:
    def test_bernstein_endpoints(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import bernstein_poly
        t = np.array([0.0, 1.0])
        # B(0, 2, t): at t=0 should be 0^2=0, at t=1 should be 1
        b = bernstein_poly(0, 2, t)
        assert b[0] == pytest.approx(0.0)
        assert b[1] == pytest.approx(1.0)

    def test_bezier_curve_endpoints(self):
        from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import bezier_curve
        points = [[0, 0], [1, 1], [2, 0]]
        x, y = bezier_curve(points, nTimes=100)
        # Start point
        assert x[0] == pytest.approx(2.0, abs=0.02)
        assert y[0] == pytest.approx(0.0, abs=0.02)
        # End point
        assert x[-1] == pytest.approx(0.0, abs=0.02)
        assert y[-1] == pytest.approx(0.0, abs=0.02)


# ---------------------------------------------------------------------------
# UserTemperatureProfile
# ---------------------------------------------------------------------------

class TestUserTemperatureProfile:
    def test_inherits_isothermal(self):
        from GUIBRUSHR.General_Constants.Classes.UserTemperatureProfile import UserTemperatureProfile
        pressures = np.logspace(-6, 2, 30)
        params = {"T0": make_param(1200.0)}
        utp = UserTemperatureProfile(pressures, params, gravity=1000.0, error=False, rng=np.random.default_rng(42))
        temp, err = utp.isot()
        np.testing.assert_array_equal(temp, np.full(30, 1200.0))


# ---------------------------------------------------------------------------
# BestFitParametersAndResults
# ---------------------------------------------------------------------------

class TestBestFitParametersAndResults:
    def test_attribute_storage(self):
        from GUIBRUSHR.General_Constants.Classes.BestFitParametersAndResults import BestFitParametersAndResults
        obj = BestFitParametersAndResults(
            number_bad_chains=2,
            last_max_LH=-100.0,
            current_max_likelihood=-95.0,
            chi2_monodimensional=np.array([1.0, 2.0]),
            list_best_pars=[1.0, 2.0],
            arr1=np.array([[1, 2], [3, 4]]),
            best_fit_parameters=np.array([1.5, 2.5]),
            value_fix=[0.1],
            lista_par_fix=["fixed_p"],
            lista_parametri=["p1", "p2", "fixed_p"],
            list_best_pars_labels=["label1", "label2"]
        )
        assert obj.number_bad_chains == 2
        assert obj.last_max_LH == -100.0
        assert obj.current_max_likelihood == -95.0
        assert len(obj.list_best_pars) == 2
        assert obj.lista_par_fix == ["fixed_p"]
        assert obj.list_best_pars_labels == ["label1", "label2"]


# ---------------------------------------------------------------------------
# sigma_calc (standalone function from Night module)
# ---------------------------------------------------------------------------

class TestSigmaCalc:
    def test_shape(self):
        from GUIBRUSHR.General_Constants.Classes.Night import sigma_calc
        # shape: (n_orders, n_phases, n_pixels)
        spectra = np.random.rand(3, 5, 10)
        sigma = sigma_calc(spectra)
        assert sigma.shape == spectra.shape

    def test_all_positive(self):
        from GUIBRUSHR.General_Constants.Classes.Night import sigma_calc
        spectra = np.random.rand(2, 4, 8) + 0.1  # ensure positive
        sigma = sigma_calc(spectra)
        assert np.all(sigma > 0)

    def test_simulation_mode(self):
        from GUIBRUSHR.General_Constants.Classes.Night import sigma_calc
        spectra = np.random.rand(2, 3, 5)
        sigma_sim = sigma_calc(spectra, simulation=True)
        sigma_real = sigma_calc(spectra, simulation=False)
        # In simulation mode, near-zero sigmas get 0 instead of 1
        assert sigma_sim.shape == sigma_real.shape
