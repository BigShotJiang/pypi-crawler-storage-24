"""Extended tests for general_functions.py: w_correlate, cross_correlation,
get_keys_by_value, compute_adjusted_abundance, convolve_resolution,
kernel_solid_body_rotation, convolve_solid_body_rotation,
calculate_mass_molecule, create_path_night, linear_solver, read_depth_fits."""

import pickle
import pytest
import numpy as np
from pandas import DataFrame
from pathlib import Path
from unittest.mock import patch


# ---------------------------------------------------------------------------
# w_correlate
# ---------------------------------------------------------------------------

class TestWCorrelate:
    def test_perfect_correlation(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import w_correlate
        s = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        sigma = np.ones(5)
        result = w_correlate(s, s, sigma)
        assert result[0] > 0

    def test_anticorrelation(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import w_correlate
        s = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        sigma = np.ones(5)
        result = w_correlate(s, -s, sigma)
        assert result[0] < 0

    def test_larger_sigma_reduces_weight(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import w_correlate
        s1 = np.array([1.0, 2.0, 3.0])
        s2 = np.array([1.0, 2.0, 3.0])
        small_sigma = np.ones(3)
        large_sigma = np.ones(3) * 10.0
        r_small = w_correlate(s1, s2, small_sigma)[0]
        r_large = w_correlate(s1, s2, large_sigma)[0]
        assert abs(r_small) > abs(r_large)


# ---------------------------------------------------------------------------
# cross_correlation (dispatcher)
# ---------------------------------------------------------------------------

class TestCrossCorrelation:
    def test_numpy_method(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import cross_correlation
        s = np.sin(np.linspace(0, 4 * np.pi, 100))
        result = cross_correlation("Numpy", s, s)
        assert abs(result - 1.0) < 1e-10

    def test_normal_method(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import cross_correlation
        s = np.sin(np.linspace(0, 4 * np.pi, 100))
        result = cross_correlation("Normal", s, s)
        assert abs(result - 1.0) < 1e-10

    def test_weighted_method(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import cross_correlation
        s = np.sin(np.linspace(0, 4 * np.pi, 100))
        sigma = np.ones(100)
        result = cross_correlation("Weighted", s, s, sigma=sigma)
        assert result > 0

    def test_non_finite_returns_zero(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import cross_correlation
        # Constant arrays produce NaN corrcoef
        s = np.ones(10)
        result = cross_correlation("Numpy", s, s)
        assert result == 0.0


# ---------------------------------------------------------------------------
# get_keys_by_value
# ---------------------------------------------------------------------------

class TestGetKeysByValue:
    def test_found(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_keys_by_value
        d = {"a": [1, 2, 3], "b": [4, 5, 6]}
        assert get_keys_by_value(d, 5) == "b"

    def test_not_found(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_keys_by_value
        d = {"a": [1, 2], "b": [3, 4]}
        assert get_keys_by_value(d, 99) is None

    def test_non_iterable_values(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_keys_by_value
        d = {"a": 1, "b": 2}
        assert get_keys_by_value(d, 1) is None

    def test_string_values(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_keys_by_value
        d = {"x": "hello", "y": "world"}
        assert get_keys_by_value(d, "o") == "x"  # "o" in "hello"


# ---------------------------------------------------------------------------
# compute_adjusted_abundance
# ---------------------------------------------------------------------------

class TestComputeAdjustedAbundance:
    def test_basic_computation(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import compute_adjusted_abundance
        pressure = np.logspace(-6, 2, 50)
        temperature = np.ones(50) * 2000.0
        coeff = [1.0, 50000.0, 6.0]
        base_vmr = 1e-4
        result = compute_adjusted_abundance(pressure, temperature, coeff, base_vmr)
        assert result.shape == (50,)
        assert np.all(result > 0)
        assert np.all(result <= base_vmr)

    def test_returns_less_than_base_vmr(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import compute_adjusted_abundance
        pressure = np.array([1e-2])
        temperature = np.array([2000.0])
        coeff = [1.0, 50000.0, 6.0]
        base_vmr = 1e-4
        result = compute_adjusted_abundance(pressure, temperature, coeff, base_vmr)
        # Adjusted abundance should always be <= base_vmr
        assert result[0] <= base_vmr


# ---------------------------------------------------------------------------
# linear_solver
# ---------------------------------------------------------------------------

class TestLinearSolver:
    def test_identity(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import linear_solver
        A = np.eye(3)
        b = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]])
        result, error = linear_solver(b, A)
        assert error is False
        np.testing.assert_array_almost_equal(result, b)

    def test_reconstruction(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import linear_solver
        np.random.seed(42)
        A = np.random.randn(5, 3)
        x_true = np.random.randn(3, 4)
        b = A @ x_true
        result, error = linear_solver(b, A)
        assert error is False
        np.testing.assert_array_almost_equal(result, b, decimal=10)


# ---------------------------------------------------------------------------
# create_path_night
# ---------------------------------------------------------------------------

class TestCreatePathNight:
    def test_path_construction(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import create_path_night
        result = create_path_night("/data", "HD209458b", "Transmission", "GIANO-B")
        assert "HD209458b" in result
        assert "HR_Instruments" in result
        assert "Transmission" in result
        assert "GIANO-B" in result

    def test_emission_mode(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import create_path_night
        result = create_path_night("/data", "WASP-77Ab", "Emission", "IGRINS")
        assert "Emission" in result
        assert "IGRINS" in result


# ---------------------------------------------------------------------------
# kernel_solid_body_rotation
# ---------------------------------------------------------------------------

class TestKernelSolidBodyRotation:
    def test_emission_kernel_is_normalized(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import kernel_solid_body_rotation
        ker = kernel_solid_body_rotation(
            omegad=0.5, f_rot_arr=np.array([0.0]),
            Teq=1500.0, mu=2.3, gs=1000.0,
            Rpj=1.0e10, rad_mode="Emission", index_nights_total=0
        )
        assert abs(np.sum(ker) - 1.0) < 1e-10

    def test_emission_kernel_is_symmetric(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import kernel_solid_body_rotation
        ker = kernel_solid_body_rotation(
            omegad=0.5, f_rot_arr=np.array([0.0]),
            Teq=1500.0, mu=2.3, gs=1000.0,
            Rpj=1.0e10, rad_mode="Emission", index_nights_total=0
        )
        np.testing.assert_array_almost_equal(ker, ker[::-1])

    def test_transmission_kernel_is_normalized(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import kernel_solid_body_rotation
        ker = kernel_solid_body_rotation(
            omegad=0.5, f_rot_arr=np.array([0.0]),
            Teq=1500.0, mu=2.3, gs=1000.0,
            Rpj=1.0e10, rad_mode="Transmission", index_nights_total=0
        )
        assert abs(np.sum(ker) - 1.0) < 1e-10

    def test_transmission_asymmetry_with_f_rot(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import kernel_solid_body_rotation
        # f_rot_arr=0 => f_rot=1 => symmetric
        ker_sym = kernel_solid_body_rotation(
            omegad=0.5, f_rot_arr=np.array([0.0]),
            Teq=1500.0, mu=2.3, gs=1000.0,
            Rpj=1.0e10, rad_mode="Transmission", index_nights_total=0
        )
        # f_rot_arr=0.3 => f_rot=2 => asymmetric
        ker_asym = kernel_solid_body_rotation(
            omegad=0.5, f_rot_arr=np.array([0.3]),
            Teq=1500.0, mu=2.3, gs=1000.0,
            Rpj=1.0e10, rad_mode="Transmission", index_nights_total=0
        )
        # With f_rot != 0 they should differ
        assert not np.allclose(ker_sym, ker_asym)


# ---------------------------------------------------------------------------
# convolve_solid_body_rotation
# ---------------------------------------------------------------------------

class TestConvolveSolidBodyRotation:
    def _make_log_uniform_grid(self, n=2000):
        """Create a log-uniform wavelength grid and flat spectrum."""
        wl = np.logspace(np.log10(1.0), np.log10(2.0), n)
        flux = np.ones(n)
        return wl, flux

    def test_flat_spectrum_stays_flat(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import (
            kernel_solid_body_rotation, convolve_solid_body_rotation
        )
        wl, flux = self._make_log_uniform_grid()
        ker = kernel_solid_body_rotation(
            omegad=0.5, f_rot_arr=np.array([0.0]),
            Teq=1500.0, mu=2.3, gs=1000.0,
            Rpj=1.0e10, rad_mode="Emission", index_nights_total=0
        )
        wl_out, flux_out = convolve_solid_body_rotation(wl, flux, ker)
        # Flat spectrum convolved with anything normalized should stay ~1
        np.testing.assert_array_almost_equal(flux_out, np.ones_like(flux_out), decimal=3)

    def test_output_shorter_than_input(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import (
            kernel_solid_body_rotation, convolve_solid_body_rotation
        )
        wl, flux = self._make_log_uniform_grid()
        ker = kernel_solid_body_rotation(
            omegad=0.5, f_rot_arr=np.array([0.0]),
            Teq=1500.0, mu=2.3, gs=1000.0,
            Rpj=1.0e10, rad_mode="Emission", index_nights_total=0
        )
        wl_out, flux_out = convolve_solid_body_rotation(wl, flux, ker)
        assert len(wl_out) < len(wl)
        assert len(wl_out) == len(flux_out)


# ---------------------------------------------------------------------------
# convolve_resolution
# ---------------------------------------------------------------------------

class TestConvolveResolution:
    def _make_log_uniform_grid(self, n=2000):
        wl = np.logspace(np.log10(1.0), np.log10(2.0), n)
        flux = np.ones(n)
        return wl, flux

    def test_flat_spectrum_stays_flat(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import convolve_resolution
        wl, flux = self._make_log_uniform_grid()
        wl_out, flux_out = convolve_resolution(wl, flux, lsf_hwhm=3.0, radial_velocity_shift=0.0)
        np.testing.assert_array_almost_equal(flux_out, np.ones_like(flux_out), decimal=3)

    def test_output_shorter_than_input(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import convolve_resolution
        wl, flux = self._make_log_uniform_grid()
        wl_out, flux_out = convolve_resolution(wl, flux, lsf_hwhm=3.0, radial_velocity_shift=0.0)
        assert len(wl_out) < len(wl)

    def test_velocity_shift_moves_wavelength(self):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import convolve_resolution
        wl = np.logspace(np.log10(1.0), np.log10(2.0), 2000)
        # Gaussian absorption line at center
        center = 1.5
        flux = 1.0 - 0.5 * np.exp(-0.5 * ((wl - center) / 0.001) ** 2)
        _, flux_0 = convolve_resolution(wl, flux, lsf_hwhm=3.0, radial_velocity_shift=0.0)
        _, flux_v = convolve_resolution(wl, flux, lsf_hwhm=3.0, radial_velocity_shift=50.0)
        # The shifted spectrum should differ from unshifted
        assert not np.allclose(flux_0, flux_v, atol=1e-5)


# ---------------------------------------------------------------------------
# calculate_mass_molecule
# ---------------------------------------------------------------------------

class TestCalculateMassMolecule:
    @pytest.fixture
    def periodic_table(self):
        return DataFrame({
            "Symbol": ["H", "C", "N", "O", "Fe"],
            "NumberofProtons": [1, 6, 7, 8, 26],
            "NumberofNeutrons": [0, 6, 7, 8, 30],
        })

    def test_h2o(self, periodic_table):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import calculate_mass_molecule
        # H2O: 2*H + 1*O ~ 18 u (uses proton/neutron masses, not standard atomic masses)
        mass = calculate_mass_molecule(["H2", "O"], periodic_table)
        assert abs(mass - 18.0) < 0.3

    def test_co(self, periodic_table):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import calculate_mass_molecule
        # CO: C + O ~ 28 u
        mass = calculate_mass_molecule(["C", "O"], periodic_table)
        assert abs(mass - 28.0) < 0.3

    def test_single_hydrogen(self, periodic_table):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import calculate_mass_molecule
        mass = calculate_mass_molecule(["H"], periodic_table)
        assert abs(mass - 1.0) < 0.1


# ---------------------------------------------------------------------------
# read_depth_fits with fallback
# ---------------------------------------------------------------------------

class TestReadDepthFits:
    def test_primary_file(self, tmp_path):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import read_depth_fits, create_fits
        data = np.array([1.0, 2.0, 3.0])
        create_fits(data, str(tmp_path / "transmission_depth.fits"))
        result = read_depth_fits(tmp_path, "Transmission")
        np.testing.assert_array_almost_equal(result, data)

    def test_emission_file(self, tmp_path):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import read_depth_fits, create_fits
        data = np.array([4.0, 5.0, 6.0])
        create_fits(data, str(tmp_path / "emission_depth.fits"))
        result = read_depth_fits(tmp_path, "Emission")
        np.testing.assert_array_almost_equal(result, data)


# ---------------------------------------------------------------------------
# get_stellar_model (with mock pickle)
# ---------------------------------------------------------------------------

class TestGetStellarModel:
    def test_load_and_trim(self, tmp_path):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_stellar_model
        wl = np.linspace(1e-4, 5e-4, 100)
        sp = np.ones(100)
        pkl_path = tmp_path / "star.pkl"
        with open(pkl_path, "wb") as f:
            pickle.dump({"wavelength": wl, "spectrum": sp}, f)
        wl_out, sp_out = get_stellar_model(str(pkl_path), 2e-4, 4e-4)
        assert wl_out[0] >= 2e-4
        assert wl_out[-1] <= 4e-4
        np.testing.assert_array_almost_equal(sp_out, np.pi * np.ones(len(sp_out)))

    def test_load_full_range(self, tmp_path):
        from GUIBRUSHR.General_Constants.FunctionsAndConstants.general_functions import get_stellar_model
        wl = np.linspace(1e-4, 5e-4, 50)
        sp = np.ones(50) * 2.0
        pkl_path = tmp_path / "star2.pkl"
        with open(pkl_path, "wb") as f:
            pickle.dump({"wavelength": wl, "spectrum": sp}, f)
        wl_out, sp_out = get_stellar_model(str(pkl_path), None, None)
        assert len(wl_out) == 50
