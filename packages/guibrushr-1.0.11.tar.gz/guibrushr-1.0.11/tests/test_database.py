"""Tests for DBSQLite3 database operations."""

import sqlite3
from unittest.mock import patch

import pytest


class TestDBSQLite3:
    def test_create_db_tables(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            # Verify tables exist
            db.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = {row[0] for row in db.cursor.fetchall()}
            assert "retrieval_run" in tables
            assert "instruments" in tables
            assert "observatories" in tables

    @patch("GUIBRUSHR.GUI.DataInterface.DBSQLite3.messagebox")
    def test_insert_and_get_instrument(self, mock_msgbox, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_instrument("GIANO-B", "50000", 1.5, 0.95, 2.45)
            names, resolutions, hwhms, wl_mins, wl_maxs = db.get_instruments()
            assert "GIANO-B" in names
            assert "50000" in resolutions

    @patch("GUIBRUSHR.GUI.DataInterface.DBSQLite3.messagebox")
    def test_get_instrument_by_key(self, mock_msgbox, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_instrument("HARPS", "115000", 1.3, 0.38, 0.69)
            inst = db.get_instrument_by_key("HARPS")
            assert inst is not None
            assert inst.name == "HARPS"
            assert inst.hwhm_km_s == 1.3

    def test_get_instrument_none(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            result = db.get_instrument_by_key("None")
            assert result is None

    @patch("GUIBRUSHR.GUI.DataInterface.DBSQLite3.messagebox")
    def test_delete_instrument(self, mock_msgbox, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_instrument("DELETEME", "100", 1.0, 0.5, 1.0)
            assert db.delete_instrument_by_key("DELETEME") is True
            assert db.delete_instrument_by_key("DELETEME") is False

    @patch("GUIBRUSHR.GUI.DataInterface.DBSQLite3.messagebox")
    def test_insert_and_get_observatory(self, mock_msgbox, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_observatory("TNG", 28.7569, -17.8892, 2387.0)
            names, lats, lons, alts = db.get_observatories()
            assert "TNG" in names
            assert 28.7569 in lats

    @patch("GUIBRUSHR.GUI.DataInterface.DBSQLite3.messagebox")
    def test_delete_observatory(self, mock_msgbox, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_observatory("TestObs", 0.0, 0.0, 0.0)
            assert db.delete_observatory_by_key("TestObs") is True
            assert db.delete_observatory_by_key("TestObs") is False

    def test_get_observatory_by_key(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            # Non-existent
            assert db.get_observatory_by_key("NoSuch") is None

    def test_insert_retrieval(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            ok = db.insert_retrieval_into_DB(
                "2024-01-01_12:00", "HD209458b", "20210101", "free",
                "Guillot", False, False, "auto", "petitRADTRANS",
                "High", "PCA", "Transmission", "GIANO-B", "user1",
                "param1=1", "param2=2", "H2O,CO", "sigma=1"
            )
            assert ok is True

    def test_delete_retrieval(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            db.insert_retrieval_into_DB(
                "2024-01-01_13:00", "HD209458b", "20210101", "free",
                "Guillot", False, False, "auto", "petitRADTRANS",
                "High", "PCA", "Transmission", "GIANO-B", "user1",
                "", "", "", ""
            )
            assert db.delete_retrieval_by_date("2024-01-01_13:00") is True
            assert db.delete_retrieval_by_date("2024-01-01_13:00") is False

    def test_empty_instruments(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
            result = db.get_instruments()
            assert result[0] == ["None"]

    def test_context_manager(self, tmp_db):
        from GUIBRUSHR.GUI.DataInterface.DBSQLite3 import DBSQLite3
        with DBSQLite3(tmp_db) as db:
            db.create_db()
        # After exiting context, DB should be closed
        with pytest.raises(Exception):
            db.cursor.execute("SELECT 1;")
