"""Tests for data classes: Target, Instrument."""

import pytest
import numpy as np


class TestTarget:
    def test_empty_target(self):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        t = Target()
        assert t.name is None
        assert t.radiation_mode == "Transmission"

    def test_invalid_radiation_mode(self):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        with pytest.raises(ValueError, match="Invalid radiation mode"):
            Target(rad_mode="InvalidMode")

    def test_load_from_yaml(self, sample_target_yaml):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        t = Target(path_target_file=sample_target_yaml, rad_mode="Transmission")
        assert t.name == "TestPlanet-b"
        assert t.radius == 1.2
        assert t.mass == 0.9
        assert t.gravity == 1500.0
        assert t.equilibrium_temperature == 1500.0
        assert t.stellar_radius == 1.0
        assert t.period == 3.5
        assert t.kp == 150.0
        assert t.eccentricity == 0.0
        assert t.inclination == 87.0

    def test_load_yaml_transit_durations(self, sample_target_yaml):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        t = Target(path_target_file=sample_target_yaml)
        assert t.limit_phase_t14 == 0.015
        assert t.limit_phase_t12 == 0.002
        assert t.limit_phase_t23 == 0.011
        assert t.t14_hours == 2.5

    def test_emission_mode_sets_limit_phase(self, sample_target_yaml):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        t = Target(path_target_file=sample_target_yaml, rad_mode="Emission")
        assert t.limit_phase_t14 == 2.0
        assert t.limit_phase_t12 == 2.0
        assert t.limit_phase_t23 == 2.0

    def test_file_not_found(self):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        with pytest.raises(FileNotFoundError):
            Target(path_target_file="/nonexistent/path.yaml")

    def test_str_representation(self, sample_target_yaml):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        t = Target(path_target_file=sample_target_yaml)
        assert "TestPlanet-b" in str(t)
        assert "Transmission" in str(t)

    def test_optional_fields_default(self, sample_target_yaml):
        from GUIBRUSHR.General_Constants.Classes.Target import Target
        t = Target(path_target_file=sample_target_yaml)
        assert t.ra == 180.0
        assert t.dec == -30.0
        assert t.v_sini == 4.0
        assert t.projected_obliquity == 0.0


class TestInstrument:
    def test_creation_with_nights(self):
        from GUIBRUSHR.General_Constants.Classes.Instrument import Instrument
        inst = Instrument("GIANO-B", "/data/giano", 50000, nights="20210101_20210102")
        assert inst.name == "GIANO-B"
        assert inst.resolution == 50000
        assert inst.ndate == 2
        assert inst.dates == ["20210101", "20210102"]

    def test_creation_without_nights(self):
        from GUIBRUSHR.General_Constants.Classes.Instrument import Instrument
        inst = Instrument("HARPS", None, 115000, hwhm_km_s=1.3, wl_min=0.38, wl_max=0.69)
        assert inst.name == "HARPS"
        assert inst.hwhm_km_s == 1.3
        assert inst.ndate is None
        assert inst.dates is None

    def test_nights_unique_bool_simple(self):
        from GUIBRUSHR.General_Constants.Classes.Instrument import Instrument
        inst = Instrument("X", None, 100, nights="20210101_20210102")
        assert list(inst.nights_unique_bool) == [True, True]

    def test_nights_unique_bool_with_AB_split(self):
        from GUIBRUSHR.General_Constants.Classes.Instrument import Instrument
        inst = Instrument("X", None, 100, nights="20210101A_20210101B_20210102")
        # After stripping A/B: ["20210101", "20210101", "20210102"]
        # First "20210101" is unique, second is not, "20210102" is unique
        assert list(inst.nights_unique_bool) == [True, False, True]

    def test_append_night_obj(self):
        from GUIBRUSHR.General_Constants.Classes.Instrument import Instrument
        inst = Instrument("X", None, 100, nights="20210101")
        assert len(inst.night_arr) == 0
        inst.append_night_obj("mock_night")
        assert len(inst.night_arr) == 1
