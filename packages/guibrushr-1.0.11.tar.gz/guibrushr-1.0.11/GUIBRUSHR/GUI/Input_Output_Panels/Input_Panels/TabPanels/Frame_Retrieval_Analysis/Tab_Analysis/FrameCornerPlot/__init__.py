"""
Frame Corner Plot Module

Contains components for creating and displaying corner plots.
"""

__version__ = "1.0.11"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Corner Plot Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import corner plot components when accessed (prevents circular imports).
    """
    if name == "FrameCornerPlot":
        module = importlib.import_module(".FrameCornerPlot", package=__name__)
        sys.modules[f"{__name__}.FrameCornerPlot"] = module
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "FrameCornerPlot"
]
