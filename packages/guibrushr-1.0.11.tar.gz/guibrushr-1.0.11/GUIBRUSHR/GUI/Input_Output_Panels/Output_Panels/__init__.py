"""
Output Panels Module

Contains all output panel components for displaying results and data.
"""

__version__ = "1.0.11"
__author__ = "GUIBRUSHR Team"
__description__ = "Output Panels Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import output panel components when accessed (prevents circular imports).
    """
    # Currently no components defined, but structure is ready for future additions
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = []
