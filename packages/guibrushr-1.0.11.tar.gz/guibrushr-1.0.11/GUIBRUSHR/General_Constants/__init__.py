"""
General Constants Module for GUIBRUSHR

Contains all constants, classes, and utility functions used throughout the application.
"""

__version__ = "1.0.11"
__author__ = "GUIBRUSHR Team"
__description__ = "General Constants Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import submodules when accessed (prevents circular imports).
    """
    if name in {"Classes", "FunctionsAndConstants"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'Classes',
    'FunctionsAndConstants'
]