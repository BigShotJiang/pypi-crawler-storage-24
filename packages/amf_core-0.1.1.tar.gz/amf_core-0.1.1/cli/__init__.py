"""CLI module — Terminal interface."""
