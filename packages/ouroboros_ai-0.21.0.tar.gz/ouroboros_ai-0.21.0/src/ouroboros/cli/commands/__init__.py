"""CLI command implementations for Ouroboros.

This module contains the command group implementations:
- init: Start interactive interview
- run: Execute workflows
- config: Manage configuration
- status: Check system status
- mcp: MCP server management
"""
