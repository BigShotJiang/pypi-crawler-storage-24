"""Tests for execution module."""
