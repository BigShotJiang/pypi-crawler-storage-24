# Copyright 2026 OpenC3, Inc.
# All Rights Reserved.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE.md for more details.
#
# This file may also be used under the terms of a commercial license
# if purchased from OpenC3, Inc.

import json

from openc3.environment import OPENC3_SCOPE
from openc3.topics.topic import Topic
from openc3.utilities.json import JsonEncoder
from openc3.utilities.store_queued import EphemeralStoreQueued
from openc3.utilities.time import to_nsec_from_epoch


class CommandDecomTopic(Topic):
    @classmethod
    def topics(cls, scope):
        Topic.topics("DECOMCMD", scope)

    @classmethod
    def write_packet(cls, packet, scope):
        topic = f"{scope}__DECOMCMD__{{{packet.target_name}}}__{packet.packet_name}"
        msg_hash = {
            "time": to_nsec_from_epoch(packet.packet_time),
            "received_time": to_nsec_from_epoch(packet.received_time),
            "target_name": packet.target_name,
            "packet_name": packet.packet_name,
            "stored": str(packet.stored),
            "received_count": packet.received_count,
        }
        # Read all RAW values at once - optimized by accessor
        json_hash = packet.read_items(packet.sorted_items)
        # Read additional value types using given_raw to avoid re-reading from buffer
        for item in packet.sorted_items:
            given_raw = json_hash[item.name]
            if item.write_conversion or item.states:
                json_hash[item.name + "__C"] = packet.read_item(item, "CONVERTED", packet.buffer, given_raw)
            if item.format_string:
                json_hash[item.name + "__F"] = packet.read_item(item, "FORMATTED", packet.buffer, given_raw)
        msg_hash["json_data"] = json.dumps(json_hash, cls=JsonEncoder)
        if packet.extra:
            msg_hash["extra"] = json.dumps(packet.extra, cls=JsonEncoder)
        EphemeralStoreQueued.write_topic(topic, msg_hash)

    @classmethod
    def get_cmd_item(cls, target_name, packet_name, param_name, type="FORMATTED", scope=OPENC3_SCOPE):
        msg_id, msg_hash = Topic.get_newest_message(f"{scope}__DECOMCMD__{{{target_name}}}__{packet_name}")
        if msg_id:
            if param_name == "RECEIVED_COUNT":
                return int(msg_hash[b"received_count"])
            else:
                cmd_item = json.loads(msg_hash[b"json_data"])
                value = cmd_item.get(f"{param_name}__F")
                if value is not None and (type == "WITH_UNITS" or type == "FORMATTED"):
                    return value

                value = cmd_item.get(f"{param_name}__C")
                if value is not None and (type == "WITH_UNITS" or type == "FORMATTED" or type == "CONVERTED"):
                    return value

                return cmd_item[param_name]
