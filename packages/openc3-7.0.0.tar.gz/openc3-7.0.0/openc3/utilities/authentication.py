# Copyright 2026 OpenC3, Inc.
# All Rights Reserved.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE.md for more details.

# This file may also be used under the terms of a commercial license
# if purchased from OpenC3, Inc.

import json
import threading
import time
from urllib.parse import urlencode

from requests import Session

from openc3.environment import *


# Basic exception for known errors
class OpenC3AuthenticationError(RuntimeError):
    pass


class OpenC3AuthenticationRetryableError(OpenC3AuthenticationError):
    pass


# OpenC3 COSMOS Core authentication code
class OpenC3Authentication:
    def __init__(self):
        password = OPENC3_API_PASSWORD
        if not password:
            raise OpenC3AuthenticationError("Authentication requires environment variable OPENC3_API_PASSWORD")
        self.service = password == OPENC3_SERVICE_PASSWORD
        response = Session().post(
            self._generate_auth_url(),
            json={"password": password},
            headers={"Content-Type": "application/json"},
        )
        self._token = response.text
        if not self._token:
            raise OpenC3AuthenticationError(
                "Authentication failed. Please check the password in the environment variable OPENC3_API_PASSWORD"
            )

    def token(self, include_bearer=True):
        return self._token

    def get_otp(self, scope="DEFAULT"):
        session_token = self.token()
        if not session_token:
            raise OpenC3AuthenticationError("Uninitialized authentication: unable to get OTP")
        response = Session().get(
            self._generate_auth_url("/auth/otp"),
            params={"scope": scope},
            headers={"Authorization": session_token},
        )
        return response.text

    def _generate_auth_url(self, endpoint=None):
        schema = OPENC3_API_SCHEMA or "http"
        hostname = OPENC3_API_HOSTNAME or ("127.0.0.1" if OPENC3_DEVEL else "openc3-cosmos-cmd-tlm-api")
        port = OPENC3_API_PORT or "2901"
        port = int(port)
        if endpoint is None:
            endpoint = "auth/verify_service" if self.service else "auth/verify"
        return f"{schema}://{hostname}:{port}/openc3-api/{endpoint}"


# OpenC3 enterprise Keycloak authentication code
class OpenC3KeycloakAuthentication(OpenC3Authentication):
    # {
    #     "access_token": "",
    #     "expires_in": 600,
    #     "refresh_expires_in": 1800,
    #     "refresh_token": "",
    #     "token_type": "bearer",
    #     "id_token": "",
    #     "not-before-policy": 0,
    #     "session_state": "",
    #     "scope": "openid email profile"
    # }

    REFRESH_OFFSET_SECONDS = 60

    # @param url [String] The url of the openc3 or keycloak in the cluster
    def __init__(self, url):
        self.url = url
        self.auth_mutex = threading.Lock()
        self.refresh_token = None
        self.expires_at = None
        self.refresh_expires_at = None
        self._token = None
        self.log = [None, None]
        self.http = Session()

    # Load the token from the environment
    def token(self, include_bearer=True, openid_scope="openid"):
        with self.auth_mutex:
            self.log = [None, None]
            current_time = time.time()
            if self._token is None or self.refresh_expires_at < current_time:
                self._make_token(current_time, openid_scope=openid_scope)
            elif self.expires_at < current_time:
                self._refresh_token(current_time)
        if include_bearer:
            return f"Bearer {self._token}"
        else:
            return self._token

    def get_token_from_refresh_token(self, refresh_token):
        current_time = time.time()
        try:
            self.refresh_token = refresh_token
            self._refresh_token(current_time)
            return self._token
        except OpenC3AuthenticationError:
            return None

    # Make the token and save token to instance
    def _make_token(self, current_time, openid_scope="openid"):
        client_id = OPENC3_API_CLIENT or "api"
        if OPENC3_API_USER and OPENC3_API_PASSWORD:
            # Username and password
            data = {
                "username": OPENC3_API_USER,
                "password": OPENC3_API_PASSWORD,
                "client_id": client_id,
                "grant_type": "password",
                "scope": openid_scope,
            }
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": OPENC3_USER_AGENT,
            }
            oath = self._make_request(headers, data)
            self._token = oath["access_token"]
            self.refresh_token = oath["refresh_token"]
            self.expires_at = current_time + oath["expires_in"] - self.REFRESH_OFFSET_SECONDS
            self.refresh_expires_at = current_time + oath["refresh_expires_in"] - self.REFRESH_OFFSET_SECONDS
        else:
            # Offline Access Token
            if self.refresh_token is None:
                self.refresh_token = OPENC3_API_TOKEN
            self._refresh_token(current_time)
        return None

    # Refresh the token and save token to instance
    def _refresh_token(self, current_time):
        client_id = OPENC3_API_CLIENT or "api"
        data = {
            "client_id": client_id,
            "refresh_token": self.refresh_token,
            "grant_type": "refresh_token",
        }
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": OPENC3_USER_AGENT,
        }
        oath = self._make_request(headers, data)
        self._token = oath["access_token"]
        self.refresh_token = oath["refresh_token"]
        self.expires_at = current_time + oath["expires_in"] - self.REFRESH_OFFSET_SECONDS
        self.refresh_expires_at = current_time + oath["refresh_expires_in"] - self.REFRESH_OFFSET_SECONDS

    # Make the post request to keycloak
    def _make_request(self, headers, data):
        realm = OPENC3_KEYCLOAK_REALM or "openc3"
        url = f"{self.url}/realms/{realm}/protocol/openid-connect/token"

        # Obfuscate password and refresh token in logs unless debug mode is enabled
        if OPENC3_DEVEL:
            log_data = str(data)
        else:
            # Create a copy of the dict with sensitive values obfuscated
            log_data = data.copy()
            if "password" in log_data:
                log_data["password"] = "***"
            if "refresh_token" in log_data:
                log_data["refresh_token"] = "***"
            log_data = str(log_data)

        self.log[0] = f"request uri: {url} header: {headers} body: {log_data}"
        # print(self.log[0])

        # URL encode the data
        resp = self.http.post(url, data=urlencode(data), headers=headers)

        self.log[1] = f"response status: {resp.status_code} header: {resp.headers} body: {resp.text}"
        # print(self.log[1])
        if resp.status_code >= 200 and resp.status_code <= 299:
            return json.loads(resp.text)
        elif resp.status_code >= 500 and resp.status_code <= 599:
            raise OpenC3AuthenticationRetryableError(
                f"authentication request retryable {self.log[0]} ::: {self.log[1]}"
            )
        else:
            raise OpenC3AuthenticationError(f"authentication request failed {self.log[0]} ::: {self.log[1]}")
