"""Tests for CLI commands — init, validate, version, help."""

from loony.cli import app


class TestVersion:
    def test_version_flag(self, runner) -> None:  # type: ignore[no-untyped-def]
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "loony" in result.stdout

    def test_help(self, runner) -> None:  # type: ignore[no-untyped-def]
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "deploy" in result.stdout
        assert "run" in result.stdout
        assert "describe" in result.stdout
        assert "query" in result.stdout
        assert "mcp" in result.stdout
        assert "keys" in result.stdout


class TestInit:
    def test_creates_project(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["init", "my-service"])
        assert result.exit_code == 0
        assert "Created app" in result.stdout
        assert (tmp_path / "my-service" / "loony.yaml").exists()
        assert (tmp_path / "my-service" / "schema.yaml").exists()
        assert (tmp_path / "my-service" / "scripts").is_dir()
        assert (tmp_path / "my-service" / "transforms").is_dir()

    def test_creates_agent_templates(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["init", "my-service", "--agent", "claude"])
        assert result.exit_code == 0
        assert (tmp_path / "my-service" / ".claude" / "rules" / "loony.md").exists()

    def test_update_mode(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        runner.invoke(app, ["init", "my-service"])
        monkeypatch.chdir(tmp_path / "my-service")
        result = runner.invoke(app, ["init", "my-service", "--update"])
        assert result.exit_code == 0
        assert "Updated" in result.stdout


class TestValidate:
    def test_validate_valid_project(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        runner.invoke(app, ["init", "test-svc"])
        monkeypatch.chdir(tmp_path / "test-svc")
        (tmp_path / "test-svc" / "schema.yaml").write_text(
            "tables:\n  raw_test:\n    description: test\n    sync_mode: replace\n"
            "    primary_key: [id]\n    columns:\n      id: { type: integer, description: ID }"
        )
        result = runner.invoke(app, ["validate"])
        assert result.exit_code == 0

    def test_validate_no_loony_yaml(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["validate"])
        assert result.exit_code == 1

    def test_validate_no_schema(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        (tmp_path / "loony.yaml").write_text("name: test")
        result = runner.invoke(app, ["validate"])
        assert "schema" in (result.stdout + result.stderr).lower()


class TestNoLoonyYaml:
    """Commands that require loony.yaml should fail gracefully."""

    def test_describe_no_yaml(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["describe"])
        assert result.exit_code == 1

    def test_query_no_yaml(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["query", "SELECT 1"])
        assert result.exit_code == 1

    def test_cancel_no_yaml(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["cancel"])
        assert result.exit_code == 1

    def test_connect_no_yaml(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["connect"])
        assert result.exit_code == 1

    def test_reset_no_yaml(self, runner, tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["reset", "--yes"])
        assert result.exit_code == 1
