"""HTTP client for talking to the control plane."""

from typing import Any

import httpx

from . import config


class ApiError(Exception):
    """User-friendly API error with message from server."""

    def __init__(self, message: str, status_code: int = 0) -> None:
        self.message = message
        self.status_code = status_code
        super().__init__(message)


def _raise_for_status(resp: httpx.Response) -> None:
    """Raise ApiError with the server's error message, not raw httpx text."""
    if resp.is_success:
        return
    try:
        body = resp.json()
        error = body.get("error", {})
        message = error.get("message", resp.text)
    except Exception:
        message = resp.text
    raise ApiError(message, resp.status_code)


def _refresh_token(env: str | None = None) -> str | None:
    """Attempt to refresh the access token using the stored refresh token."""
    env = env or config.get_current_env()
    env_config = config.get_env_config(env)
    endpoint = env_config.get("endpoint")
    refresh = env_config.get("refresh_token")

    if not endpoint or not refresh:
        return None

    try:
        resp = httpx.post(
            f"{endpoint}/auth/refresh",
            json={"refresh_token": refresh},
            timeout=10,
        )
        if resp.is_success:
            data = resp.json()
            new_token = data["access_token"]
            creds: dict[str, Any] = {"access_token": new_token}
            if data.get("refresh_token"):
                creds["refresh_token"] = data["refresh_token"]
            config.save_credentials(env, creds)
            return str(new_token)
    except Exception:
        pass
    return None


def _get_client(env: str | None = None, timeout: int = 30) -> tuple[httpx.Client, dict[str, Any]]:
    env = env or config.get_current_env()
    env_config = config.get_env_config(env)
    endpoint: str | None = env_config.get("endpoint")
    token: str | None = env_config.get("access_token")

    if not endpoint:
        raise ValueError(f"No endpoint configured for environment '{env}'")
    if not token:
        raise ValueError("Not logged in. Run 'loony login' first.")

    # Proactively refresh if token is expired or about to expire
    try:
        import base64
        import json
        import time

        payload = token.split(".")[1] + "==="
        claims = json.loads(base64.urlsafe_b64decode(payload))
        exp = claims.get("exp", 0)
        if exp < time.time() + 30:  # expired or within 30s of expiry
            new_token = _refresh_token(env)
            if new_token:
                token = new_token
                env_config = config.get_env_config(env)  # reload with new token
    except Exception:
        pass  # if decode fails, try with existing token

    client = httpx.Client(
        base_url=endpoint,
        headers={"Authorization": f"Bearer {token}"},
        timeout=timeout,
    )
    return client, env_config



def register_app(name: str, env: str | None = None) -> dict[str, Any]:
    """Register an app on the server without deploying."""
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/register")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def usage(env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.get("/api/v1/usage")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def keys_create(name: str, key_name: str | None = None, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/keys", json={"name": key_name})
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def keys_list(name: str, show_key: bool = False, env: str | None = None) -> list[dict[str, Any]]:
    client, _ = _get_client(env)
    params = {"show_key": "true"} if show_key else {}
    resp = client.get(f"/api/v1/services/{name}/keys", params=params)
    _raise_for_status(resp)
    result: list[dict[str, Any]] = resp.json()
    return result


def keys_revoke(name: str, prefix: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.delete(f"/api/v1/services/{name}/keys/{prefix}")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def schedule_list(name: str, env: str | None = None) -> list[dict[str, Any]]:
    client, _ = _get_client(env)
    resp = client.get(f"/api/v1/services/{name}/schedule")
    _raise_for_status(resp)
    result: list[dict[str, Any]] = resp.json()
    return result


def schedule_pause(name: str, script: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/schedule/{script}/pause")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def schedule_resume(name: str, script: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/schedule/{script}/resume")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def me(env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.get("/api/v1/me")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def health(env: str | None = None) -> dict[str, Any]:
    env_config = config.get_env_config(env)
    endpoint: str | None = env_config.get("endpoint")
    if not endpoint:
        raise ValueError(f"No endpoint configured for environment '{config.get_current_env()}'")

    resp = httpx.get(f"{endpoint}/health", timeout=10)
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def secrets_set(name: str, secret_name: str, value: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/secrets", json={"secret_name": secret_name, "value": value})
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def secrets_list(name: str, env: str | None = None) -> list[str]:
    client, _ = _get_client(env)
    resp = client.get(f"/api/v1/services/{name}/secrets")
    _raise_for_status(resp)
    result: list[str] = resp.json()
    return result


def secrets_remove(name: str, secret_name: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.delete(f"/api/v1/services/{name}/secrets/{secret_name}")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def deploy(name: str, payload: dict[str, Any], env: str | None = None) -> dict[str, Any]:
    # Large script uploads can take well over 30s — use a generous timeout.
    client, _ = _get_client(env, timeout=300)
    resp = client.post(f"/api/v1/services/{name}/deploy", json=payload)
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def get_deployment(name: str, deployment_id: int, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.get(f"/api/v1/services/{name}/deployments/{deployment_id}")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def query(name: str, sql: str, limit: int = 1000, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/query", json={"sql": sql, "limit": limit})
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def describe(name: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.get(f"/api/v1/services/{name}/describe")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def get_logs(
    name: str, limit: int = 10, status_filter: str | None = None, env: str | None = None
) -> list[dict[str, Any]]:
    client, _ = _get_client(env)
    params: dict[str, Any] = {"limit": limit}
    if status_filter:
        params["status_filter"] = status_filter
    resp = client.get(f"/api/v1/services/{name}/logs", params=params)
    _raise_for_status(resp)
    result: list[dict[str, Any]] = resp.json()
    return result


def run_pipeline(name: str, script: str | None = None, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    path = f"/api/v1/services/{name}/run/{script}" if script else f"/api/v1/services/{name}/run"
    resp = client.post(path)
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def cancel_deployment(name: str, deployment_id: int, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/deployments/{deployment_id}/cancel")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def get_connect_details(name: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.get(f"/api/v1/services/{name}/connect")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def reset_pipeline(name: str, env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post(f"/api/v1/services/{name}/reset")
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result


def submit_feedback(payload: dict[str, Any], env: str | None = None) -> dict[str, Any]:
    client, _ = _get_client(env)
    resp = client.post("/api/v1/feedback", json=payload)
    _raise_for_status(resp)
    result: dict[str, Any] = resp.json()
    return result
