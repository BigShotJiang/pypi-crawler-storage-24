"""Encryption endpoints for public key certificates."""

from typing import final

from ksef2.core import routes
from ksef2.endpoints.base import BaseEndpoints
from ksef2.infra.schema.api import spec


@final
class EncryptionEndpoints(BaseEndpoints):
    def fetch_public_certificates(self) -> list[spec.PublicKeyCertificate]:
        """Fetch public certificates used for token and session-key encryption."""
        return self._parse_list(
            self._transport.get(routes.EncryptionRoutes.PUBLIC_KEY_CERTIFICATES),
            spec.PublicKeyCertificate,
        )
