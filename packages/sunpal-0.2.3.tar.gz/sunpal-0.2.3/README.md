# Sunpal

Python client library for the Sunpal API - simplifying access to Sunpal services.

[![PyPI version](https://badge.fury.io/py/sunpal.svg)](https://pypi.org/project/sunpal/)
[![Python Support](https://img.shields.io/pypi/pyversions/sunpal.svg)](https://pypi.org/project/sunpal/)

## 🚀 Quick Start

### Installation

```bash
pip install sunpal
```

### Basic Usage

```python
import sunpal

# Configure with your credentials
sunpal.configure(
    api_key="your_api_key_here",
    site="sunwise"  # your company/site identifier
)

# Use the library
# (Add your specific usage examples here)
```

## 💻 Development

We use Docker for a consistent development environment across all team members.

### Quick Setup

```bash
# Clone the repository
git clone <repository-url>
cd sunpal-library

# Run the quick start script
./quick-start.sh
```

The script will guide you through setting up either:
1. **Docker environment** (recommended) - Isolated, consistent Python versions
2. **Local environment** - Direct Python installation

### Development with Docker

```bash
# Build the Docker image
make build

# Start development environment
make up

# Enter the container shell
make shell

# Run tests
make test

# Run linting
make lint

# Format code
make format

# See all available commands
make help
```

### Development without Docker

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
make install
make install-dev

# Run tests locally
make test-local

# Format and lint
make format
make lint
```

## 🧪 Testing

```bash
# Run all tests
make test

# Run specific test file
python3 -m unittest tests.customers

# Run specific test
python3 -m unittest tests.interactive.TestCases.test_retrieve

# Multi-version testing (Docker)
make test-all-versions  # Tests on Python 3.8, 3.9, 3.10
```

## 📦 Deployment

To deploy a new version to PyPI:

```bash
# 1. Update version in setup.py and sunpal/version.py

# 2. Build distribution packages
make dist

# 3. Check packages are valid
make check-dist

# 4. Upload to PyPI (requires credentials)
make deploy

# For TestPyPI first
make deploy-test
```

## 🔧 Configuration

### Environment Variables

Create a `.env` file (copy from `.env.example`):

```bash
# Sunpal API Configuration
SUNPAL_API_KEY=your_api_key_here
SUNPAL_SITE=sunwise

# Optional: Override API domain (for local development)
LOCAL_SUNPAL_DOMAIN=localhost:8004
```

### Using Custom Domain

For local development against a local Sunpal API instance:

```bash
export LOCAL_SUNPAL_DOMAIN=localhost:8004
export SUNPAL_API_KEY=your_dev_api_key
```

## 📚 Documentation

- [DEVELOPMENT.md](DEVELOPMENT.md) - Comprehensive development guide
- [PyPI Package](https://pypi.org/project/sunpal/) - Published package info

## 🛠️ Available Make Commands

Run `make help` to see all available commands:

- **Development**: `build`, `up`, `down`, `shell`, `logs`
- **Testing**: `test`, `test-local`, `test-all-versions`, `coverage`
- **Code Quality**: `lint`, `format`, `type-check`
- **Deployment**: `dist`, `deploy`, `deploy-test`
- **Cleanup**: `clean`, `docker-clean`, `clean-all`

## 📋 Requirements

- **Runtime**: Python 3.6+
- **Development**: Python 3.9+ (or use Docker)
- **Docker**: For containerized development (optional but recommended)

## 🤝 Contributing

1. Create a feature branch from `master`
2. Make your changes
3. Run tests: `make test`
4. Format code: `make format`
5. Lint: `make lint`
6. Commit with conventional commits (feat:, fix:, docs:, etc.)
7. Submit a pull request

## 📄 License

See [LICENSE.txt](LICENSE.txt) for details.
