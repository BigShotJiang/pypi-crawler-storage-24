import os


class Environment(object):

    sunpal_domain = None
    protocol = "https"
    if "LOCAL_SUNPAL_DOMAIN" in os.environ:
        sunpal_domain = os.environ.get("LOCAL_SUNPAL_DOMAIN")
        protocol = "http"

    # Optional env var to override the base domain globally without using site.
    # e.g. SUNPAL_CUSTOM_DOMAIN=api.mycompany.com
    custom_domain_env = os.environ.get("SUNPAL_CUSTOM_DOMAIN")

    API_VERSION = "v1"
    connect_timeout = 30
    read_timeout = 80

    def __init__(self, options):
        self.api_key = options["api_key"]
        # site is optional when custom_domain is provided
        self.site = options.get("site")
        # custom_domain from options takes precedence over the env var
        custom_domain = options.get("custom_domain") or self.custom_domain_env

        if self.sunpal_domain is not None:
            # LOCAL_SUNPAL_DOMAIN wins over everything (local dev)
            self.api_endpoint = "http://%s/api/%s" % (
                self.sunpal_domain,
                self.API_VERSION,
            )
        elif custom_domain is not None:
            # Caller-supplied domain: https://<custom_domain>/api/v1
            self.api_endpoint = "https://%s/api/%s" % (
                custom_domain,
                self.API_VERSION,
            )
        elif self.site is not None:
            # Default: https://<site>.sunpal.io/api/v1
            self.api_endpoint = "https://%s.sunpal.io/api/%s" % (
                self.site,
                self.API_VERSION,
            )
        else:
            raise ValueError(
                "sunpal.configure() requires either 'site' or 'custom_domain'."
            )

    def api_url(self, url):
        # print(self.api_endpoint + url)
        return self.api_endpoint + url
