from sunpal.api_error import APIError, InvalidRequestError, OperationFailedError
from sunpal.models import *
from sunpal.main import SunPal


def configure(api_key, site=None, custom_domain=None):
    SunPal.configure(
        {
            "api_key": api_key,
            "site": site,
            "custom_domain": custom_domain,
        }
    )


def update_connect_timeout_secs(connect_timeout):
    SunPal.update_connect_timeout_secs(connect_timeout)


def update_read_timeout_secs(read_timeout):
    SunPal.update_read_timeout_secs(read_timeout)
