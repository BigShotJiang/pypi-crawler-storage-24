"""
Consulta (Credit Bureau) API Tests with Mocks

Tests consulta operations without requiring real API credentials.
The mock target is `sunpal.http_request.request` which returns an already-parsed
dict (not an HTTP response object).
"""
import unittest
from unittest.mock import patch
import sunpal
from sunpal.api_error import APIError


class ConsultaTestsWithMocks(unittest.TestCase):

    def setUp(self):
        sunpal.configure("test_api_key", "test_site")

    @patch("sunpal.http_request.request")
    def test_create_consulta_success(self, mock_request):
        mock_request.return_value = {
            "consulta": {
                "id": "CONS123456",
                "reference": "proposal-uuid-sunwise",
                "rfc": "EAEN6506051Y8",
                "status": "pending",
            }
        }
        result = sunpal.Consulta.create({
            "reference": "proposal-uuid-sunwise",
            "rfc": "EAEN6506051Y8",
            "first_name": "NOVENTAYTRES",
            "second_name": "PRUEBA",
            "first_last_name": "EXPPAT",
            "second_last_name": "EXPMAT",
        })
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "consulta"))

    @patch("sunpal.http_request.request")
    def test_retrieve_consulta_by_id_and_reference(self, mock_request):
        mock_request.return_value = {
            "consulta": {
                "id": "EAEN6506051Y8",
                "reference": "proposal-uuid-sunwise",
                "status": "completed",
                "score": 720,
            }
        }
        result = sunpal.Consulta.retrieve(
            id="EAEN6506051Y8",
            params={"reference": "proposal-uuid-sunwise"},
        )
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "consulta"))

    @patch("sunpal.http_request.request")
    def test_consulta_pending_status(self, mock_request):
        mock_request.return_value = {
            "consulta": {
                "id": "CONS789",
                "reference": "test-reference",
                "status": "pending",
            }
        }
        result = sunpal.Consulta.retrieve(
            id="CONS789",
            params={"reference": "test-reference"},
        )
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "consulta"))

    @patch("sunpal.http_request.request")
    def test_consulta_failed_status(self, mock_request):
        mock_request.return_value = {
            "consulta": {
                "id": "CONS999",
                "reference": "test-ref",
                "status": "failed",
            }
        }
        result = sunpal.Consulta.retrieve(
            id="CONS999",
            params={"reference": "test-ref"},
        )
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "consulta"))

    @patch("sunpal.http_request.request")
    def test_consulta_retrieval_not_found_returns_empty(self, mock_request):
        """404 -> process_response returns {} -> Result wraps empty dict."""
        mock_request.return_value = {}
        result = sunpal.Consulta.retrieve(
            id="NONEXISTENT",
            params={"reference": "fake-ref"},
        )
        self.assertIsNotNone(result)
        mock_request.assert_called_once()

    @patch("sunpal.http_request.request")
    def test_consulta_with_invalid_rfc_raises_error(self, mock_request):
        mock_request.side_effect = APIError(
            400, {"errors": ["Invalid RFC"], "type": "invalid_request"}
        )
        with self.assertRaises(APIError):
            sunpal.Consulta.create({
                "reference": "ref",
                "rfc": "INVALID",
                "first_name": "X",
                "first_last_name": "Y",
            })

    @patch("sunpal.http_request.request")
    def test_unauthorized_raises_api_error(self, mock_request):
        mock_request.side_effect = APIError(
            401,
            {
                "errors": ["Authentication credentials were not provided."],
                "type": "api_error",
            },
        )
        with self.assertRaises(APIError):
            sunpal.Consulta.create({
                "reference": "ref",
                "rfc": "EAEN6506051Y8",
                "first_name": "JUAN",
                "first_last_name": "PEREZ",
            })


class ConsultaValidationTests(unittest.TestCase):

    def test_required_fields_for_creation(self):
        data = {
            "reference": "proposal-uuid-123",
            "rfc": "EAEN6506051Y8",
            "first_name": "JUAN",
            "first_last_name": "PEREZ",
        }
        for field in ["reference", "rfc", "first_name", "first_last_name"]:
            self.assertIn(field, data)
            self.assertTrue(data[field])

    def test_optional_fields_accepted(self):
        data = {
            "reference": "ref-123",
            "rfc": "EAEN6506051Y8",
            "first_name": "JUAN",
            "second_name": "CARLOS",
            "first_last_name": "PEREZ",
            "second_last_name": "GOMEZ",
        }
        for field in ["second_name", "second_last_name"]:
            if field in data:
                self.assertTrue(data[field])

    def test_rfc_format_for_consulta(self):
        rfc = "EAEN6506051Y8"
        self.assertEqual(len(rfc), 13)
        self.assertTrue(rfc.isalnum())
        self.assertTrue(rfc.isupper())


if __name__ == "__main__":
    unittest.main()
