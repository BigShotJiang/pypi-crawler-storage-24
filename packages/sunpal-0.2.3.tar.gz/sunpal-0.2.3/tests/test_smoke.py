"""
Smoke tests - Basic tests that don't require API credentials
These tests verify the package can be imported and basic functionality works
"""
import unittest
import sunpal
from sunpal.version import VERSION


class SmokeTests(unittest.TestCase):
    """Basic smoke tests that don't require API access"""

    def test_package_imports(self):
        """Test that the sunpal package can be imported"""
        self.assertIsNotNone(sunpal)

    def test_version_available(self):
        """Test that version information is available and follows semver"""
        self.assertIsNotNone(VERSION)
        self.assertIsInstance(VERSION, str)
        # Verify semver format X.Y.Z (no hardcoded version — updated by release-please)
        parts = VERSION.split(".")
        self.assertEqual(len(parts), 3, f"VERSION '{VERSION}' is not semver X.Y.Z")
        self.assertTrue(all(p.isdigit() for p in parts), f"VERSION '{VERSION}' has non-numeric parts")

    def test_configure_function_exists(self):
        """Test that configure function exists"""
        self.assertTrue(hasattr(sunpal, 'configure'))
        self.assertTrue(callable(sunpal.configure))

    def test_models_importable(self):
        """Test that model classes can be imported"""
        from sunpal.models import customers, consulta
        self.assertIsNotNone(customers)
        self.assertIsNotNone(consulta)

    def test_customer_class_exists(self):
        """Test that Customer class exists"""
        self.assertTrue(hasattr(sunpal, 'Customer'))

    def test_environment_import(self):
        """Test that environment module can be imported"""
        from sunpal import environment
        self.assertIsNotNone(environment)

    def test_request_import(self):
        """Test that request module can be imported"""
        from sunpal import request
        self.assertIsNotNone(request)


if __name__ == '__main__':
    unittest.main()
