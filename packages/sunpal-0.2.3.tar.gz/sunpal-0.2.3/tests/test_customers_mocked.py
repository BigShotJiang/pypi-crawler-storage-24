"""
Customer API Tests with Mocks

Tests customer operations without requiring real API credentials.
The mock target is `sunpal.http_request.request` which returns an already-parsed
dict (not an HTTP response object).
"""
import unittest
from unittest.mock import patch
import sunpal
from sunpal.api_error import APIError


class CustomerTestsWithMocks(unittest.TestCase):

    def setUp(self):
        sunpal.configure("test_api_key", "test_site")

    @patch("sunpal.http_request.request")
    def test_create_customer_success(self, mock_request):
        mock_request.return_value = {
            "customer": {
                "id": "GACA910614A36",
                "first_name": "Jason",
                "last_name": "Bates",
                "second_surname": "Doub",
                "rfc": "GACA910614A36",
                "email": "jason.bates@example.com",
            }
        }
        result = sunpal.Customer.create({
            "first_name": "Jason",
            "last_name": "Bates",
            "second_surname": "Doub",
            "rfc": "GACA910614A36",
            "email": "jason.bates@example.com",
        })
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "customer"))

    @patch("sunpal.http_request.request")
    def test_retrieve_customer_by_id(self, mock_request):
        mock_request.return_value = {
            "customer": {
                "id": "EAEN6506051Y8",
                "first_name": "John",
                "last_name": "Doe",
                "email": "john@example.com",
            }
        }
        result = sunpal.Customer.retrieve(
            id="EAEN6506051Y8",
            params={"reference": "test-reference"},
        )
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "customer"))

    @patch("sunpal.http_request.request")
    def test_retrieve_customer_by_reference(self, mock_request):
        mock_request.return_value = {
            "customer": {
                "id": "EAEN6506051Y8",
                "reference": "proposal-uuid-sunwise",
                "first_name": "Jane",
                "last_name": "Smith",
            }
        }
        result = sunpal.Customer.retrieve_by_reference("proposal-uuid-sunwise")
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "customer"))

    @patch("sunpal.http_request.request")
    def test_retrieve_nonexistent_customer_returns_empty(self, mock_request):
        """404 -> process_response returns {} -> Result wraps empty dict."""
        mock_request.return_value = {}
        result = sunpal.Customer.retrieve("NONEXISTENT123")
        self.assertIsNotNone(result)
        mock_request.assert_called_once()

    @patch("sunpal.http_request.request")
    def test_update_customer(self, mock_request):
        mock_request.return_value = {
            "customer": {
                "id": "EAEN6506051Y8",
                "first_name": "Updated",
                "last_name": "Name",
                "email": "updated@example.com",
            }
        }
        result = sunpal.Customer.update(
            "EAEN6506051Y8",
            {"first_name": "Updated", "last_name": "Name"},
        )
        self.assertIsNotNone(result)
        mock_request.assert_called_once()
        self.assertTrue(hasattr(result, "customer"))

    @patch("sunpal.http_request.request")
    def test_list_customers(self, mock_request):
        mock_request.return_value = {
            "results": [
                {"id": "CUST001", "first_name": "John"},
                {"id": "CUST002", "first_name": "Jane"},
            ],
            "next_offset": None,
        }
        result = sunpal.Customer.list()
        self.assertIsNotNone(result)
        mock_request.assert_called_once()

    @patch("sunpal.http_request.request")
    def test_list_customers_with_params(self, mock_request):
        mock_request.return_value = {
            "results": [{"id": "CUST001", "first_name": "John"}],
            "next_offset": None,
        }
        result = sunpal.Customer.list(params={"limit": 1})
        self.assertIsNotNone(result)
        mock_request.assert_called_once()

    @patch("sunpal.http_request.request")
    def test_unauthorized_raises_api_error(self, mock_request):
        mock_request.side_effect = APIError(
            401,
            {
                "errors": ["Authentication credentials were not provided."],
                "type": "api_error",
            },
        )
        with self.assertRaises(APIError):
            sunpal.Customer.retrieve("TEST123")

    @patch("sunpal.http_request.request")
    def test_duplicate_customer_raises_api_error(self, mock_request):
        mock_request.side_effect = APIError(
            409,
            {"errors": ["Customer already exists."], "type": "invalid_request"},
        )
        with self.assertRaises(APIError):
            sunpal.Customer.create({
                "rfc": "GACA910614A36",
                "email": "existing@example.com",
            })

    def test_configure_function(self):
        sunpal.configure("key_12345", "my_site")
        from sunpal.main import SunPal
        self.assertIsNotNone(SunPal.default_env)
        self.assertEqual(SunPal.default_env.api_key, "key_12345")


class CustomerValidationTests(unittest.TestCase):

    def test_rfc_format_validation(self):
        for rfc in ["GACA910614A36", "EAEN6506051Y8", "XAXX010101000"]:
            self.assertEqual(len(rfc), 13)
            self.assertTrue(rfc.isalnum())

    def test_email_format(self):
        for email in ["test@example.com", "user.name@domain.co.mx", "admin@sunwise.io"]:
            self.assertIn("@", email)
            self.assertIn(".", email)

    def test_required_fields(self):
        data = {
            "first_name": "John",
            "last_name": "Doe",
            "rfc": "GACA910614A36",
            "email": "john@example.com",
        }
        for field in ["first_name", "last_name", "rfc", "email"]:
            self.assertIn(field, data)
            self.assertTrue(data[field])


if __name__ == "__main__":
    unittest.main()
