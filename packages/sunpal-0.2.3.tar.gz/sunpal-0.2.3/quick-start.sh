#!/bin/bash
# Quick start script for Sunpal development

set -e

echo "🚀 Sunpal Library - Quick Start"
echo "================================"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first:"
    echo "   https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if docker-compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ docker-compose is not installed. Please install docker-compose:"
    echo "   https://docs.docker.com/compose/install/"
    exit 1
fi

echo "✅ Docker is installed"
echo ""

# Create .env if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo "✅ .env created. Edit it with your credentials if needed."
else
    echo "✅ .env file already exists"
fi
echo ""

# Ask user preference
echo "Choose development setup:"
echo "1) Docker (recommended - isolated environment)"
echo "2) Local (requires Python 3.9+)"
read -p "Enter choice [1-2]: " choice

case $choice in
    1)
        echo ""
        echo "🐳 Setting up Docker environment..."
        echo ""
        
        # Build and start
        make build
        echo ""
        make up
        
        echo ""
        echo "✅ Docker environment ready!"
        echo ""
        echo "Next steps:"
        echo "  1. Enter container:  make shell"
        echo "  2. Run tests:        make test"
        echo "  3. See all commands: make help"
        echo ""
        echo "To stop: make down"
        ;;
    2)
        echo ""
        echo "🐍 Setting up local environment..."
        echo ""
        
        # Check Python version
        PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
        echo "Python version: $PYTHON_VERSION"
        
        # Create venv if not exists
        if [ ! -d "venv" ]; then
            echo "Creating virtual environment..."
            python3 -m venv venv
        fi
        
        # Activate and install
        echo "Installing dependencies..."
        source venv/bin/activate
        pip install --upgrade pip
        make install
        make install-dev
        
        echo ""
        echo "✅ Local environment ready!"
        echo ""
        echo "Next steps:"
        echo "  1. Activate venv:    source venv/bin/activate"
        echo "  2. Run tests:        make test-local"
        echo "  3. See all commands: make help"
        ;;
    *)
        echo "Invalid choice. Exiting."
        exit 1
        ;;
esac

echo ""
echo "📚 Read DEVELOPMENT.md for detailed documentation"
echo ""
echo "Happy coding! 🎉"
