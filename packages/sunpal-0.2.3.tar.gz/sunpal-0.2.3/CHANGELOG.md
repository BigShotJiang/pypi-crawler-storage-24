# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.3](https://github.com/sunwisesoftware/sunpal-library/compare/v0.2.2...v0.2.3) (2026-03-07)


### 🐛 Bug Fixes

* add concurrency group and checkout before release-please action ([82d1454](https://github.com/sunwisesoftware/sunpal-library/commit/82d14545ea8f8595f3924c1c08badddcd4c8147c))
* add concurrency group and checkout before release-please action ([56f19cd](https://github.com/sunwisesoftware/sunpal-library/commit/56f19cdd4cdbbdad27e78bc0538e8913ec757169))
* add explicit tag and GitHub Release creation step as fallback ([173ccb7](https://github.com/sunwisesoftware/sunpal-library/commit/173ccb791566ce2372c90440aabaaef6cfd31a99))
* add explicit tag and GitHub Release creation step as fallback ([3eb5985](https://github.com/sunwisesoftware/sunpal-library/commit/3eb5985f08c82334bfd99bc2ece13760e25f7f6a))

## [0.2.2](https://github.com/sunwisesoftware/sunpal-library/compare/v0.2.1...v0.2.2) (2026-03-07)


### 🐛 Bug Fixes

* use RELEASE_PLEASE_TOKEN directly (|| operator not valid for sec… ([22ffd12](https://github.com/sunwisesoftware/sunpal-library/commit/22ffd1273a6971260c4ba54faf23a89fb6dd755d))
* use RELEASE_PLEASE_TOKEN directly (|| operator not valid for secrets) ([12af3aa](https://github.com/sunwisesoftware/sunpal-library/commit/12af3aa2c3409a78670af482e70d0b4a38af1a11))

## [0.2.1](https://github.com/sunwisesoftware/sunpal-library/compare/v0.2.0...v0.2.1) (2026-03-06)


### 🐛 Bug Fixes

* fallback to github.token if RELEASE_PLEASE_TOKEN secret not set ([c41ed37](https://github.com/sunwisesoftware/sunpal-library/commit/c41ed37f786da9cfabde578e4e70f01528e6a316))
* replace hardcoded version assertion with semver format check ([3fbecb4](https://github.com/sunwisesoftware/sunpal-library/commit/3fbecb4777777d5be62100cf93a60e5e955fe931))
* sync version.py to 0.2.0 and add release-please annotation ([b2c3fde](https://github.com/sunwisesoftware/sunpal-library/commit/b2c3fdeafc6d9a602fc14afdccbf2a78079dcb42))

## [0.2.0](https://github.com/sunwisesoftware/sunpal-library/compare/v0.1.12...v0.2.0) (2026-03-06)


### ✨ Features

* add CI/CD, release automation, and comprehensive documentation ([731be3b](https://github.com/sunwisesoftware/sunpal-library/commit/731be3b91b2d8916b454e8893b9907dbe899e67d))
* add comprehensive security scanning pipeline ([8980bdf](https://github.com/sunwisesoftware/sunpal-library/commit/8980bdf55a960c81cc055d6194f97af399da6291))
* add consultas methods ([9b5e84b](https://github.com/sunwisesoftware/sunpal-library/commit/9b5e84bcda6ce97ece51f89fb1051dee03b70e69))
* add custom_domain support to Environment ([26edb78](https://github.com/sunwisesoftware/sunpal-library/commit/26edb78400c3030bce70a38e098b5e00307a9684))
* add Docker development environment ([92bdd97](https://github.com/sunwisesoftware/sunpal-library/commit/92bdd97e17dbb15e24c7e1b465c619f15392a935))
* change email on setup ([9fa8e79](https://github.com/sunwisesoftware/sunpal-library/commit/9fa8e791ea067c8e61a1646876ae7ccb8243212c))
* crud addres ([67eef6e](https://github.com/sunwisesoftware/sunpal-library/commit/67eef6e5edaf9389ca37d85be9a5722e570d9cf8))
* customer params pass reference ([609d218](https://github.com/sunwisesoftware/sunpal-library/commit/609d2189958d6e504934d4136ee7c255ac84432d))
* doc version ([ddd1390](https://github.com/sunwisesoftware/sunpal-library/commit/ddd13905040dbfd2514c36549e94e39f1f6edc60))
* get retrieve by reference ([36ea57e](https://github.com/sunwisesoftware/sunpal-library/commit/36ea57eca46b227ffebaa9d08b7062b951570a76))
* gunicorn python config ([3e10445](https://github.com/sunwisesoftware/sunpal-library/commit/3e1044500f26f575b120f930ebfaa7ab9e82b139))
* remove logic ([1c4c7d9](https://github.com/sunwisesoftware/sunpal-library/commit/1c4c7d98deabbfb1b01e6d5ff563a1f075a12244))
* response maping customer ([485457e](https://github.com/sunwisesoftware/sunpal-library/commit/485457e599695a2cb5518ea49f180f9d189ddb11))
* return None object 404 ([8d1b939](https://github.com/sunwisesoftware/sunpal-library/commit/8d1b93984372f61adaf0ebf788f0fd5160ccb361))
* status and record objects ([bee6606](https://github.com/sunwisesoftware/sunpal-library/commit/bee6606d0a98751cfb9634126c509f2103060172))
* test and connect get customer ([e0816e9](https://github.com/sunwisesoftware/sunpal-library/commit/e0816e9ffe5f2de9d14ee3f426c290a799f04672))
* test create customer ([9925ded](https://github.com/sunwisesoftware/sunpal-library/commit/9925ded8b3ec762e7f36a19a930f4552c1b124de))
* version 0.1.5 ([d977943](https://github.com/sunwisesoftware/sunpal-library/commit/d9779434d857e026b4723f6dce6185560ddc74f2))
* version 2 ([37f63ed](https://github.com/sunwisesoftware/sunpal-library/commit/37f63ed45b35b12429819690f00b38c5ea5dfbea))


### 🐛 Bug Fixes

* correct release-please extra-files config ([f5672e2](https://github.com/sunwisesoftware/sunpal-library/commit/f5672e216da533b0ce3745964055e42819b5a9b3))
* correct security workflow configuration ([172e61b](https://github.com/sunwisesoftware/sunpal-library/commit/172e61b3c01df32e8652169155a729b673c89697))
* feat commits now bump minor version correctly ([7af4f12](https://github.com/sunwisesoftware/sunpal-library/commit/7af4f12486c0932f49b5682ce5747916f989363b))
* improve pytest configuration and docker-compose ([96cea97](https://github.com/sunwisesoftware/sunpal-library/commit/96cea97c8ac727e3b15bddd29c70405d8731055f))
* noqa changes ([2d6c469](https://github.com/sunwisesoftware/sunpal-library/commit/2d6c4690b0439fa4f2109f79de986ae5caf58cb3))
* release-please now reads manifest and config files correctly ([18ad851](https://github.com/sunwisesoftware/sunpal-library/commit/18ad851688f54dc57b88e63f921e64cc78c14a38))
* remove reference ([c239be5](https://github.com/sunwisesoftware/sunpal-library/commit/c239be5aa66c3c75077457b3b0656eecb1fb4d56))
* remove SARIF upload from bandit (requires GitHub Advanced Security) ([cc9107d](https://github.com/sunwisesoftware/sunpal-library/commit/cc9107d35ac17bd3490ddda91bf5943ca9ebe5f2))
* remove SARIF upload from bandit (requires GitHub Advanced Security) ([f11a253](https://github.com/sunwisesoftware/sunpal-library/commit/f11a253e7bcf7292a241198b66062849e71a776a))
* resolve Docker build issues ([4c3a354](https://github.com/sunwisesoftware/sunpal-library/commit/4c3a354281b2803bffbf79e2cbbb35fff3264a6a))
* resolve gitleaks false positives and clean docs ([c8de0fe](https://github.com/sunwisesoftware/sunpal-library/commit/c8de0fe37a3cacd415ae3b0310cfe8a1ed23d344))
* update customer ([9c07529](https://github.com/sunwisesoftware/sunpal-library/commit/9c07529b40eeb119d0327b5f0a11efead55c5041))
* use PAT token in release-please to trigger CI checks on PR ([d8bff21](https://github.com/sunwisesoftware/sunpal-library/commit/d8bff219f81ac1dcc95e4f9c7d6b7c6f6d1e308b))
* use PAT token in release-please to trigger CI checks on PR ([c59f320](https://github.com/sunwisesoftware/sunpal-library/commit/c59f320c055fed3929227b5eb97424eaa50232a2))


### 📖 Documentation

* add CHANGELOG to track project changes ([93c03bc](https://github.com/sunwisesoftware/sunpal-library/commit/93c03bcc9f111c340654452d42228b73d3fbacab))
* update README with modern documentation and Docker instructions ([42e58f7](https://github.com/sunwisesoftware/sunpal-library/commit/42e58f70768841425256b02b9cb5fac9bd655c5c))

## [Unreleased]

### Added
- Docker development environment with Python 3.9
- Multi-version testing support (Python 3.8, 3.9, 3.10) via docker-compose
- Comprehensive Makefile with 30+ development commands
- Quick start script (`quick-start.sh`) for easy onboarding
- Development documentation in DEVELOPMENT.md
- Tool configurations in setup.cfg (flake8, pytest, mypy, coverage)
- Environment variable template (.env.example)
- Improved README with installation, usage, and contribution guidelines

### Changed
- Restored codebase to PyPI version 0.1.12 as baseline
- Updated README with modern documentation structure
- Improved development workflow with standardized commands

### Fixed
- Version synchronization between setup.py and version.py

## [0.1.12] - 2023-01-XX

Published on PyPI - baseline version.

### Notes
- This version serves as the clean baseline for future development
- All changes above are in development and will be part of the next release

[Unreleased]: https://github.com/your-org/sunpal-library/compare/v0.1.12...HEAD
[0.1.12]: https://pypi.org/project/sunpal/0.1.12/
