# Testing Guide

## Test Organization

### Current Test Files

#### ✅ Working Tests (No API Required)

1. **tests/test_smoke.py** - 7 tests ✅
   - Package imports
   - Version check
   - Module availability
   - Basic functionality

2. **CustomerValidationTests** - 3 tests ✅
   - RFC format validation
   - Email format validation
   - Required fields validation

3. **ConsultaValidationTests** - 3 tests ✅
   - Required fields validation
   - Optional fields handling
   - RFC format for consulta

**Total: 13 passing tests without API credentials**

#### 🔧 Integration Tests (Require API Key)

Located in:
- `tests/customers.py` - Customer API tests (mostly commented out)
- `tests/consulta.py` - Consulta API tests
- `tests/address.py` - Address tests
- `tests/interactive.py` - Interactive mode tests
- `tests/views.py` - Views tests

**These require:**
```bash
export API_KEY_SUNPAL=your_real_api_key_here
```

#### 🚧 Mocked Tests (Work in Progress)

- `tests/test_customers_mocked.py` - API mocking approach
- `tests/test_consulta_mocked.py` - Consulta mocking approach

**Status:** Partially working (13 validation tests pass, 15 mocked API tests need refinement)

## Running Tests

### Quick Test (No Credentials)

```bash
# Docker
make test-smoke  # or:
docker exec sunpal-dev-py39 pytest tests/test_smoke.py -v

# Local
pytest tests/test_smoke.py -v
```

### All Tests (Requires API Key)

```bash
# Set API key
export API_KEY_SUNPAL=your_key_here

# Run all tests
make test  # or:
pytest tests/ -v

# With coverage
pytest tests/ -v --cov=sunpal --cov-report=html
```

### Integration Tests Only

```bash
export API_KEY_SUNPAL=your_key_here

# Specific test file
pytest tests/customers.py -v
pytest tests/consulta.py -v

# Specific test
pytest tests/customers.py::TestCases::test_get_customer -v
```

### Validation Tests (Always Pass)

```bash
# No API key needed
pytest tests/test_customers_mocked.py::CustomerValidationTests -v
pytest tests/test_consulta_mocked.py::ConsultaValidationTests -v
```

## Test Coverage

### Current Status

```
tests/test_smoke.py               ✅ 7/7   (100%)
Validation tests                  ✅ 6/6   (100%)
Integration tests                 ⚠️  Require API key
Mocked API tests                  🚧 Work in progress
```

### Coverage Report

```bash
# Generate coverage report
make coverage  # or:
pytest tests/ --cov=sunpal --cov-report=html

# View report
open htmlcov/index.html
```

## Writing New Tests

### Smoke Tests (No API)

```python
# tests/test_smoke.py
import unittest
import sunpal

class MyTests(unittest.TestCase):
    def test_feature(self):
        # Test without API calls
        self.assertTrue(hasattr(sunpal, 'Customer'))
```

### Integration Tests (With API)

```python
# tests/test_my_feature.py
import os
import unittest
import sunpal

api_key = os.environ.get("API_KEY_SUNPAL")
site = "sunwise-test"
sunpal.configure(api_key, site)

class MyFeatureTests(unittest.TestCase):
    def test_real_api_call(self):
        result = sunpal.Customer.retrieve("CUSTOMER_ID")
        self.assertIsNotNone(result)
```

### Validation Tests (No API)

```python
# tests/test_validators.py
import unittest

class ValidationTests(unittest.TestCase):
    def test_rfc_format(self):
        rfc = "GACA910614A36"
        self.assertEqual(len(rfc), 13)
        self.assertTrue(rfc.isalnum())
```

## CI/CD Testing

### GitHub Actions

Tests run automatically on:
- Push to `main`/`master`
- Pull requests
- Multiple Python versions (3.8, 3.9, 3.10, 3.11)

See `.github/workflows/tests.yml`

### Required Secrets

Set in GitHub repo settings:
```
API_KEY_SUNPAL=your_real_api_key
```

### Test Stages

1. **Smoke tests** - Always run (no credentials)
2. **Lint** - Code quality checks
3. **Integration tests** - Run if API_KEY_SUNPAL is set
4. **Coverage** - Upload to Codecov

## Best Practices

### ✅ DOs

- Write smoke tests for all new features
- Use descriptive test names
- Test edge cases and error conditions
- Keep tests independent
- Clean up test data after tests
- Document test requirements

### ❌ DON'Ts

- Don't commit API keys
- Don't create test data that can't be cleaned up
- Don't rely on test execution order
- Don't skip error handling tests
- Don't use production credentials in tests

## Test Data

### Test Customers

For integration testing, use these test RFCs:
```python
TEST_CUSTOMERS = {
    "valid": "EAEN6506051Y8",
    "test": "GACA914A36",
    "reference": "proposal-uuid-sunwise"
}
```

### Test References

```python
TEST_REFERENCES = [
    "proposal-uuid-sunwise",
    "test-reference-123",
    "59be24f9-7cb1-4cea-88e0-cf237880bb29"
]
```

## Troubleshooting

### Tests not discovered

```bash
# Check pytest configuration
pytest --collect-only

# Verify setup.cfg
cat setup.cfg
```

### Import errors

```bash
# Install in editable mode
pip install -e .

# Verify installation
python -c "import sunpal; print(sunpal.__file__)"
```

### API errors in tests

```bash
# Check API key is set
echo $API_KEY_SUNPAL

# Test configuration
python -c "import os; import sunpal; sunpal.configure(os.getenv('API_KEY_SUNPAL'), 'sunwise-test')"
```

### Docker test issues

```bash
# Restart container
make down && make up

# Check logs
docker logs sunpal-dev-py39

# Enter container
make shell
pytest tests/test_smoke.py -v
```

## Future Improvements

### Planned

- [ ] Complete mocked API tests
- [ ] Add integration test fixtures
- [ ] Implement test data cleanup
- [ ] Add performance benchmarks
- [ ] Create test documentation generator
- [ ] Add mutation testing
- [ ] Set up test database

### Ideas

- Mock server for integration tests
- Contract testing with Pact
- Load testing with Locust
- Security testing with Bandit
- Property-based testing with Hypothesis

## Resources

- [pytest documentation](https://docs.pytest.org/)
- [unittest.mock guide](https://docs.python.org/3/library/unittest.mock.html)
- [Coverage.py](https://coverage.readthedocs.io/)
- [Testing in Python](https://realpython.com/python-testing/)
