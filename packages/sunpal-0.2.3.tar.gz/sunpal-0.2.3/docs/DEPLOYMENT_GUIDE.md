# Plan de Deployment - Sunpal Library v0.1.6

## 📋 Checklist Pre-Deployment

### 1. Correcciones Críticas (OBLIGATORIO)

- [ ] Sincronizar versión en `setup.py` y `sunpal/version.py` a `0.1.6`
- [ ] Corregir typo de codificación en `http_request.py` línea 107
- [ ] Revisar y corregir lógica de protocolo en `environment.py`
- [ ] Eliminar código comentado y prints de debug
- [ ] Fijar versiones de dependencias en `requirements.txt`
- [ ] Cambiar `verify_ca_certs` a `True` por defecto (seguridad)
- [ ] Crear `CHANGELOG.md` documentando todos los cambios

### 2. Mejoras de Calidad (RECOMENDADO)

- [ ] Agregar validación de configuración en `configure()`
- [ ] Mejorar documentación en `README.md`
- [ ] Agregar más tests unitarios
- [ ] Crear `CONTRIBUTING.md`
- [ ] Agregar ejemplos de uso en `examples/` directory

### 3. Configuración Moderna (OPCIONAL)

- [ ] Migrar a `pyproject.toml`
- [ ] Configurar GitHub Actions para CI/CD
- [ ] Agregar pre-commit hooks
- [ ] Configurar code coverage reporting

## 🔧 Comandos de Corrección

### Paso 1: Actualizar versión
```bash
# Actualizar manualmente ambos archivos a 0.1.6
# setup.py línea 16
# sunpal/version.py línea 1
```

### Paso 2: Corregir typo de encoding
```bash
# En sunpal/http_request.py línea 107
# Cambiar: response.text.encode("utf 8")
# A: response.text.encode("utf-8")
```

### Paso 3: Limpiar código
```bash
# Eliminar prints y código comentado mediante búsqueda
grep -r "# print" sunpal/
grep -r "def test_" tests/ | grep "#"
```

### Paso 4: Actualizar requirements.txt
```txt
requests>=2.28.0,<3.0.0
wheel>=0.38.0
twine>=4.0.0
```

### Paso 5: Ejecutar tests
```bash
# Ejecutar todos los tests
python3 -m unittest discover -s tests -p "*.py" -v

# Ejecutar test específico
python3 -m unittest -v tests/customers.py
```

### Paso 6: Crear CHANGELOG.md
```bash
# Ver plantilla en sección siguiente
```

### Paso 7: Limpiar builds anteriores
```bash
# Limpiar distribuciones antiguas
rm -rf build/ dist/ *.egg-info/

# Limpiar cache de Python
find . -type d -name "__pycache__" -exec rm -rf {} +
find . -type f -name "*.pyc" -delete
```

### Paso 8: Construir nueva versión
```bash
# Construir paquetes
python3 setup.py sdist bdist_wheel
```

### Paso 9: Verificar paquetes
```bash
# Verificar que los paquetes están correctos
twine check dist/*
```

### Paso 10: Subir a PyPI
```bash
# Test en PyPI Test (opcional pero recomendado)
python3 -m twine upload --repository testpypi dist/*

# Producción
python3 -m twine upload dist/*
```

### Paso 11: Crear tag de Git
```bash
# Commit de cambios
git add .
git commit -m "chore: release version 0.1.6"

# Crear tag
git tag -a v0.1.6 -m "Release version 0.1.6"

# Push
git push origin main
git push origin v0.1.6
```

## 📝 Conventional Commits a Usar

```bash
# Para correcciones de bugs
git commit -m "fix: correct utf-8 encoding typo in http_request"

# Para cambios de versión
git commit -m "chore: bump version to 0.1.6"

# Para mejoras de seguridad
git commit -m "security: enable SSL certificate verification by default"

# Para limpieza de código
git commit -m "refactor: remove commented code and debug prints"

# Para documentación
git commit -m "docs: add CHANGELOG and improve README"

# Para actualizaciones de dependencias
git commit -m "build: pin dependency versions in requirements.txt"

# Para nuevas features (si aplica)
git commit -m "feat: add new customer validation method"

# Para tests
git commit -m "test: add comprehensive tests for error handling"
```

## 📄 Plantilla de CHANGELOG.md

```markdown
# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.6] - 2026-03-06

### Fixed
- Corrected UTF-8 encoding typo in http_request.py
- Fixed protocol logic in environment.py
- Synchronized version across setup.py and version.py

### Security
- Enabled SSL certificate verification by default

### Changed
- Pinned dependency versions for better stability
- Updated requirements.txt with specific version ranges

### Removed
- Removed debug print statements and commented code

## [0.1.5] - [Previous Date]

### Added
- Initial public release
- Customer management endpoints
- Consulta endpoints
- Basic error handling

[0.1.6]: https://github.com/sunwise/sunpal-library/compare/v0.1.5...v0.1.6
[0.1.5]: https://github.com/sunwise/sunpal-library/releases/tag/v0.1.5
```

## ⚠️ Notas Importantes

1. **Credenciales PyPI**: Asegúrate de tener configuradas tus credenciales:
   ```bash
   # Crear ~/.pypirc
   [pypi]
   username = __token__
   password = pypi-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
   ```

2. **Testing Local**: Antes de subir, prueba la instalación local:
   ```bash
   pip install dist/sunpal-0.1.6-py3-none-any.whl
   python3 -c "import sunpal; print(sunpal.VERSION)"
   ```

3. **Backup**: Haz backup del código antes de hacer cambios:
   ```bash
   git branch backup-pre-0.1.6
   ```

4. **Reversión**: Si algo sale mal, puedes revertir:
   ```bash
   git reset --hard backup-pre-0.1.6
   ```

## 🎯 Orden de Ejecución Recomendado

1. ✅ Crear branch para release: `git checkout -b release/0.1.6`
2. ✅ Aplicar todas las correcciones críticas
3. ✅ Ejecutar tests y verificar que pasen
4. ✅ Actualizar documentación (README, CHANGELOG)
5. ✅ Commit con conventional commits
6. ✅ Limpiar builds antiguos
7. ✅ Construir nuevos paquetes
8. ✅ Verificar paquetes con twine
9. ✅ (Opcional) Probar en TestPyPI
10. ✅ Subir a PyPI producción
11. ✅ Merge a main y crear tag
12. ✅ Anunciar release

## 📞 Soporte

Si encuentras problemas durante el deployment:
1. Revisa los logs de error completos
2. Verifica que todas las dependencias estén instaladas
3. Confirma que tienes permisos en PyPI
4. Consulta la documentación oficial de [packaging.python.org](https://packaging.python.org)
