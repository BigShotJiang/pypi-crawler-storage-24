# Release Please - Automated Versioning Guide

## What is Release Please?

Release Please is a GitHub Action from Google that automates:
- **Version bumping** (semantic versioning)
- **CHANGELOG generation** (from conventional commits)
- **GitHub releases** (automated tags and releases)
- **PyPI publishing** (when combined with our workflow)

## How It Works

```
Developer commits:
  feat: add new customer API
  fix: resolve timeout issue
  
       ↓
       
Release Please analyzes commits
  - feat → minor version bump (0.1.12 → 0.2.0)
  - fix → patch version bump (0.1.12 → 0.1.13)
  
       ↓
       
Creates Release PR:
  - Updates version in all files
  - Generates CHANGELOG.md
  - Title: "chore(release): release v0.2.0"
  
       ↓
       
You merge the PR
  
       ↓
       
Automatically:
  - Creates Git tag: v0.2.0
  - Creates GitHub release
  - Publishes to PyPI
  - Builds Docker images (if configured)
```

## Setup Steps

### 1. Configure PyPI Token (One-time)

```bash
# 1. Generate PyPI API token
# Go to: https://pypi.org/manage/account/token/
# Create token with scope: "Entire account" or specific to "sunpal"

# 2. Add to GitHub Secrets
# Go to: https://github.com/YOUR_ORG/sunpal-library/settings/secrets/actions
# Click "New repository secret"
# Name: PYPI_API_TOKEN
# Value: pypi-AgEIcH...your-token-here
```

### 2. Initial Setup (Already Done!)

Files created:
- ✅ `.release-please-config.json` - Configuration
- ✅ `.release-please-manifest.json` - Current version tracking
- ✅ `.github/workflows/release-please.yml` - GitHub Action
- ✅ `.github/workflows/tests.yml` - CI tests

### 3. Configure Branch Protection (Recommended)

```
GitHub → Settings → Branches → Add rule

Rule settings:
  ☑ Require pull request reviews before merging
  ☑ Require status checks to pass before merging
    - Select: Tests / test
    - Select: Tests / lint
  ☑ Require conversation resolution before merging
  ☑ Do not allow bypassing the above settings
```

## Usage Workflow

### Making Changes

```bash
# 1. Create feature branch
git checkout -b feature/new-api

# 2. Make changes
# ... edit code ...

# 3. Commit with conventional commit format
git commit -m "feat: add pagination to customer list API"
git commit -m "fix: handle null values in address parser"
git commit -m "docs: update API documentation"

# 4. Push and create PR
git push origin feature/new-api
# Create PR to master/main

# 5. Merge PR
# After review, merge to master
```

### Release Process (Automated!)

```bash
# After merging to master:

# 1. Release Please runs automatically
#    - Analyzes commits since last release
#    - Determines version bump (major/minor/patch)
#    - Creates a "Release PR"

# 2. Review the Release PR
#    - Check CHANGELOG.md
#    - Verify version number
#    - Review updated files

# 3. Merge the Release PR
#    When merged, automatically:
#    ✅ Creates Git tag (v0.x.x)
#    ✅ Creates GitHub Release
#    ✅ Publishes to PyPI
#    ✅ Updates CHANGELOG

# 4. Users can install new version
#    pip install --upgrade sunpal
```

## Conventional Commit Format

### Commit Message Structure

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

### Types and Version Impact

| Type | Description | Version Bump | Example |
|------|-------------|--------------|---------|
| `feat` | New feature | **MINOR** (0.1.0 → 0.2.0) | `feat: add batch processing` |
| `fix` | Bug fix | **PATCH** (0.1.0 → 0.1.1) | `fix: resolve timeout error` |
| `feat!` | Breaking change | **MAJOR** (0.1.0 → 1.0.0) | `feat!: change API signature` |
| `docs` | Documentation | No bump | `docs: update README` |
| `test` | Tests | No bump | `test: add unit tests` |
| `chore` | Maintenance | No bump | `chore: update dependencies` |
| `refactor` | Code refactor | No bump | `refactor: simplify parser` |
| `perf` | Performance | **PATCH** | `perf: optimize query` |
| `ci` | CI/CD changes | No bump | `ci: add Docker build` |

### Breaking Changes

To indicate a breaking change (MAJOR version bump):

```bash
# Option 1: Add ! after type
git commit -m "feat!: change configure() parameters"

# Option 2: Add BREAKING CHANGE in footer
git commit -m "feat: update API

BREAKING CHANGE: configure() now requires site parameter"
```

## Examples

### Patch Release (0.1.12 → 0.1.13)

```bash
git commit -m "fix: handle empty customer list response"
git commit -m "fix: validate RFC format correctly"
git push origin main

# Release Please creates PR:
# - Version: 0.1.13
# - Includes both fixes in CHANGELOG
```

### Minor Release (0.1.12 → 0.2.0)

```bash
git commit -m "feat: add customer search by email"
git commit -m "feat: add pagination to list APIs"
git commit -m "fix: timeout on large responses"
git push origin main

# Release Please creates PR:
# - Version: 0.2.0 (because of feat commits)
# - CHANGELOG includes all changes
```

### Major Release (0.1.12 → 1.0.0)

```bash
git commit -m "feat!: redesign API with async/await

BREAKING CHANGE: All API methods are now async.
Users must update their code to use async/await.

Migration:
  Before: customer = sunpal.Customer.get(id)
  After:  customer = await sunpal.Customer.get(id)"

git push origin main

# Release Please creates PR:
# - Version: 1.0.0
# - Highlights breaking changes in CHANGELOG
```

## Manual Release (Without GitHub Actions)

If you want to create a release locally:

```bash
# 1. Install release-please CLI
npm install -g release-please

# 2. Create release
release-please release-pr \
  --repo-url=YOUR_ORG/sunpal-library \
  --token=$GITHUB_TOKEN \
  --release-type=python

# 3. Or just follow manual process
# Update version in:
#   - setup.py
#   - sunpal/version.py
#   - pyproject.toml
#   - CHANGELOG.md

# 4. Commit and tag
git commit -m "chore(release): release v0.2.0"
git tag v0.2.0
git push origin master --tags

# 5. Build and publish
make dist
make deploy
```

## CHANGELOG Format

Release Please generates CHANGELOG automatically:

```markdown
# Changelog

## [0.2.0](https://github.com/org/sunpal/compare/v0.1.12...v0.2.0) (2026-03-06)

### Features

* add customer search by email ([abc123](commit-link))
* add pagination to list APIs ([def456](commit-link))

### Bug Fixes

* timeout on large responses ([ghi789](commit-link))
* validate RFC format correctly ([jkl012](commit-link))

## [0.1.12](previous-link) (2023-01-XX)

...
```

## Troubleshooting

### Release PR not created?

**Check:**
1. Are commits following conventional format?
2. Is there a new commit since last release?
3. Check GitHub Actions logs

```bash
# Verify commits since last tag
git log v0.1.12..HEAD --oneline

# Should see conventional commits:
# abc123 feat: new feature
# def456 fix: bug fix
```

### Version not bumping correctly?

**Common issues:**
- Typo in commit type (`feat:` not `feature:`)
- No meaningful commits (only `chore:`, `docs:`)
- Missing colon after type (`feat add` should be `feat: add`)

### PyPI publish failed?

**Check:**
1. `PYPI_API_TOKEN` secret is configured
2. Token has correct permissions
3. Version doesn't already exist on PyPI
4. Check workflow logs for details

## Benefits

✅ **No manual version updates**
✅ **Automatic CHANGELOG generation**
✅ **Consistent release process**
✅ **Semantic versioning enforced**
✅ **Integrated with CI/CD**
✅ **Clear release history**
✅ **Reduced human error**

## Resources

- [Release Please Docs](https://github.com/googleapis/release-please)
- [Conventional Commits](https://www.conventionalcommits.org/)
- [Semantic Versioning](https://semver.org/)

---

**Current Sunpal Status:**
- Current version: `0.1.12`
- Ready to use Release Please
- Push conventional commits to master → automatic releases!
