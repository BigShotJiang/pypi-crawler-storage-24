# 🏗️ Sunpal Library - Arquitectura Técnica

**Versión:** 0.1.6  
**Fecha:** 6 de marzo de 2026  

---

## 📖 Visión General

Sunpal es una librería cliente Python que actúa como **wrapper** para la API REST de Sunpal. Proporciona una interfaz Python idiomática para interactuar con los servicios de gestión de clientes y consultas de buró de crédito.

### Principios de Diseño

1. **Simplicidad** - API simple y fácil de usar
2. **Consistencia** - Patrones consistentes en todos los métodos
3. **Extensibilidad** - Fácil agregar nuevos endpoints
4. **Robustez** - Manejo de errores comprehensivo
5. **Testabilidad** - Diseño que facilita testing

---

## 🏛️ Arquitectura de Alto Nivel

```
┌─────────────────────────────────────────────────┐
│           User Application Code                 │
└────────────────┬────────────────────────────────┘
                 │
                 │ import sunpal
                 │ sunpal.configure()
                 │ sunpal.Customer.create()
                 │
┌────────────────▼────────────────────────────────┐
│          sunpal/__init__.py                     │
│  ┌────────────────────────────────────────┐    │
│  │  Public API                             │    │
│  │  - configure()                          │    │
│  │  - update_connect_timeout_secs()        │    │
│  │  - update_read_timeout_secs()           │    │
│  └────────────────────────────────────────┘    │
└────────────────┬────────────────────────────────┘
                 │
                 │
┌────────────────▼────────────────────────────────┐
│            Core Components                      │
│  ┌──────────────────────────────────────────┐  │
│  │  SunPal (main.py)                        │  │
│  │  - default_env: Environment              │  │
│  │  - configure()                           │  │
│  │  - verify_ca_certs                       │  │
│  └──────────────────────────────────────────┘  │
│                                                 │
│  ┌──────────────────────────────────────────┐  │
│  │  Environment (environment.py)            │  │
│  │  - api_key                               │  │
│  │  - site                                  │  │
│  │  - sunpal_domain                         │  │
│  │  - API_VERSION = "v1"                    │  │
│  │  - connect_timeout, read_timeout         │  │
│  └──────────────────────────────────────────┘  │
└────────────────┬────────────────────────────────┘
                 │
                 │
┌────────────────▼────────────────────────────────┐
│           Request Layer                         │
│  ┌──────────────────────────────────────────┐  │
│  │  request.py                              │  │
│  │  - send()                                │  │
│  │  - send_list_request()                   │  │
│  │  - uri_path()                            │  │
│  └──────────┬───────────────────────────────┘  │
│             │                                   │
│  ┌──────────▼───────────────────────────────┐  │
│  │  http_request.py                         │  │
│  │  - request()                             │  │
│  │  - process_response()                    │  │
│  │  - handle_api_resp_error()               │  │
│  └──────────────────────────────────────────┘  │
└────────────────┬────────────────────────────────┘
                 │
                 │ HTTP/HTTPS
                 │
┌────────────────▼────────────────────────────────┐
│         External API                            │
│   https://test.sunpal.mx/api/v1/                │
└─────────────────────────────────────────────────┘
```

---

## 🧩 Componentes Principales

### 1. Public API (`__init__.py`)

**Responsabilidad:** Exponer la interfaz pública de la librería.

```python
# Funciones públicas
def configure(api_key, site)
def update_connect_timeout_secs(connect_timeout)
def update_read_timeout_secs(read_timeout)

# Modelos exportados
from sunpal.models import Customer, Consulta

# Excepciones exportadas
from sunpal.api_error import APIError, InvalidRequestError, OperationFailedError
```

**Validaciones:**
- Valida que `api_key` y `site` sean strings no vacíos
- Lanza `ValueError` si la validación falla

---

### 2. Core - SunPal Class (`main.py`)

**Responsabilidad:** Configuración global y gestión de estado.

```python
class SunPal:
    default_env = None              # Environment instance
    verify_ca_certs = True          # SSL verification
    ca_cert_path = "ssl/ca-certs.crt"
    
    @classmethod
    def configure(cls, options)
    
    @classmethod
    def update_connect_timeout_secs(cls, connect_timeout)
    
    @classmethod
    def update_read_timeout_secs(cls, read_timeout)
```

**Características:**
- Singleton pattern (class variables)
- Configuración global compartida
- SSL certificate verification

---

### 3. Environment (`environment.py`)

**Responsabilidad:** Configuración del entorno de conexión.

```python
class Environment:
    # Configuración de dominio
    sunpal_domain = "test.sunpal.mx"  # Hardcoded
    protocol = "https"                 # o "http" con LOCAL_SUNPAL_DOMAIN
    
    # Configuración de API
    API_VERSION = "v1"
    
    # Timeouts
    connect_timeout = 30  # segundos
    read_timeout = 80     # segundos
    
    def __init__(self, options):
        self.api_key = options["api_key"]
        self.site = options["site"]  # No usado actualmente en URL
        self.api_endpoint = f"{protocol}://{sunpal_domain}/api/{API_VERSION}"
    
    def api_url(self, url):
        return self.api_endpoint + url
```

**URL Construction:**
```
https://test.sunpal.mx/api/v1/{endpoint}
```

**Desarrollo Local:**
```bash
export LOCAL_SUNPAL_DOMAIN=localhost:8004
# → http://localhost:8004/api/v1/{endpoint}
```

**Nota:** El parámetro `site` se almacena pero no se usa en la construcción de la URL.

---

### 4. Request Layer (`request.py`)

**Responsabilidad:** Construcción y envío de requests.

```python
def send(method, url, params=None, env=None, headers=None):
    """
    Enviar request y procesar respuesta
    
    Returns:
        Result: Para respuestas simples
        ListResult: Para respuestas con arrays
    """
    # 1. Serializar parámetros
    ser_params = util.serialize(params)
    
    # 2. Obtener environment
    env = env or SunPal.default_env
    
    # 3. Hacer HTTP request
    response = http_request.request(method, url, env, ser_params, headers)
    
    # 4. Wrappear respuesta
    if "results" in response:
        return ListResult(response["results"], response.get("next_offset"))
    return Result(response)


def send_list_request(method, url, params=None, env=None, headers=None):
    """Variante para requests con listas en parámetros"""
    # Serializa arrays a JSON strings
    for k, v in params.items():
        if isinstance(v, list):
            params[k] = json.dumps(v)
    return send(method, url, params, env, headers)


def uri_path(*paths):
    """
    Construir URI path de forma segura
    
    uri_path("customers", "123") → "/customers/123/"
    """
    url = ""
    for path in paths:
        if not path:
            raise Exception("Id is None or empty")
        url += "/" + urllib.parse.quote(str(path).strip())
    return url + "/"
```

---

### 5. HTTP Request (`http_request.py`)

**Responsabilidad:** Manejo de HTTP requests y respuestas.

```python
def request(method, url, env, params=None, headers=None):
    """
    Ejecutar HTTP request
    
    Args:
        method: GET, POST, PATCH, DELETE
        url: endpoint relativo
        env: Environment instance
        params: query params o body
        headers: headers adicionales
    
    Returns:
        dict: JSON response parseado
    """
    # 1. Construir URL completa
    url = env.api_url(url)
    
    # 2. Preparar headers
    headers = {
        "User-Agent": f"Sunpal-Python-Client v{VERSION}",
        "Accept": "application/json",
        "api-key": env.api_key,
        "Lang-Version": f"{py_major_v}.{py_minor_v}",
        "OS-Version": platform.platform(),
        **headers
    }
    
    # 3. Preparar payload según método
    if method in ("GET", "HEAD", "DELETE"):
        url += "?" + urlencode(params) if params else ""
        payload = None
    else:
        payload = urlencode(params)
        headers["Content-type"] = "application/x-www-form-urlencoded"
    
    # 4. Ejecutar request con requests library
    response = requests.request(
        method=method,
        url=url,
        data=payload,
        headers=headers,
        timeout=(env.connect_timeout, env.read_timeout),
        verify=SunPal.verify_ca_certs  # SSL verification
    )
    
    # 5. Procesar respuesta
    return process_response(url, response.text, response.status_code)


def process_response(url, response, http_code):
    """Parsear y validar respuesta"""
    # Parse JSON
    resp_json = json.loads(response)
    
    # 404 → retorna dict vacío
    if http_code == 404:
        return {}
    
    # Error codes → lanzar excepción
    if http_code < 200 or http_code > 299:
        handle_api_resp_error(url, http_code, resp_json)
    
    return resp_json


def handle_api_resp_error(url, http_code, resp_json):
    """Lanzar excepción apropiada según tipo de error"""
    if resp_json.get("type") == "operation_failed":
        raise OperationFailedError(http_code, resp_json)
    elif resp_json.get("type") == "invalid_request":
        raise InvalidRequestError(http_code, resp_json)
    else:
        raise APIError(http_code, resp_json)
```

---

### 6. Models (`models/`)

**Responsabilidad:** Representar entidades de negocio.

#### Customer Model

```python
class Customer(Model):
    fields = [
        "id",
        "first_name",
        "last_name",
        "email",
        "status",
    ]
    
    # Static methods para operaciones CRUD
    
    @staticmethod
    def create(params=None, env=None, headers=None):
        return request.send(
            "post",
            request.uri_path("accounts/register-customer"),
            params, env, headers
        )
    
    @staticmethod
    def retrieve(id, params=None, env=None, headers=None):
        return request.send(
            "get",
            request.uri_path("accounts/customer", id),
            params, env, headers
        )
    
    @staticmethod
    def update(id, params=None, env=None, headers=None):
        return request.send(
            "patch",
            request.uri_path("accounts/customer", id),
            params, env, headers
        )
    
    @staticmethod
    def list(params=None, env=None, headers=None):
        return request.send_list_request(
            "get",
            request.uri_path("customers/customer/"),
            params, env, headers
        )
    
    # Address management
    @staticmethod
    def add_address(id, params, env=None, headers=None):
        params.update({"customer_id": id})
        return request.send("post", "/accounts/address/", params, env, headers)
    
    @staticmethod
    def update_address(id, params, env=None, headers=None):
        return request.send("patch", f"/accounts/address/{id}/", params, env, headers)
    
    @staticmethod
    def delete_address(id):
        return request.send("delete", f"/accounts/address/{id}/")
```

#### Consulta Model

```python
class Consulta(Model):
    fields = ["id", "folio", "reference", "user"]
    
    @staticmethod
    def create(params=None, env=None, headers=None):
        return request.send(
            "post",
            request.uri_path("burocredito/record"),
            params, env, headers
        )
    
    @staticmethod
    def retrieve(id, params, env=None, headers=None):
        return request.send(
            "get",
            request.uri_path("burocredito/record", id),
            params, env, headers
        )
```

---

### 7. Base Model (`model.py`)

**Responsabilidad:** Clase base para todos los modelos.

```python
class Model:
    fields = []  # Definir en subclases
    
    def __init__(self, values, sub_types=None, dependant_types=None):
        self.values = values
        self.sub_types = sub_types or {}
        self.dependant_types = dependant_types or {}
        
        # Inicializar campos
        for field in self.fields:
            setattr(self, field, None)
    
    def load(self, values):
        """Cargar valores del dict a atributos"""
        for k, v in values.items():
            if isinstance(v, dict) and k in self.sub_types:
                # Modelo anidado
                setattr(self, k, self.sub_types[k].construct(v))
            elif isinstance(v, list) and k in self.sub_types:
                # Lista de modelos
                setattr(self, k, [self.sub_types[k].construct(x) for x in v])
            else:
                # Valor simple
                setattr(self, k, v)
    
    @classmethod
    def construct(cls, values, sub_types=None, dependant_types=None):
        """Factory method"""
        obj = cls(values, sub_types, dependant_types)
        obj.load(values)
        return obj
```

---

### 8. Result Wrappers

#### Result (`result.py`)

```python
class Result:
    """Wrapper para respuestas simples"""
    
    def __init__(self, response):
        self._response = response
        self._response_obj = {}
    
    @property
    def customer(self):
        return self._get("customer", Customer, {
            "status": Customer.StatusItem,
            "records": Customer.RecordItem
        })
    
    @property
    def consulta(self):
        return self._get("consulta", Consulta, {})
    
    @property
    def address(self):
        return self._get("address", Customer, {})
    
    def _get(self, type, cls, sub_types=None):
        """Construir modelo desde respuesta"""
        if not self._response:
            return None
        return cls.construct(self._response, sub_types)
```

#### ListResult (`list_result.py`)

```python
class ListResult(list):
    """Wrapper para respuestas con listas paginadas"""
    
    def __init__(self, response, next_offset):
        self.response = response
        self.next_offset = next_offset  # Para paginación
        self._init_items()
    
    def _init_items(self):
        """Convertir cada item a Result"""
        for item in self.response:
            self.append(Result(item))
```

**Uso:**
```python
result = Customer.list()
for customer_result in result:
    print(customer_result.customer.email)

if result.next_offset:
    # Hay más resultados
    next_page = Customer.list({"offset": result.next_offset})
```

---

### 9. Error Handling (`api_error.py`)

```python
class APIError(Exception):
    """Error base de la API"""
    def __init__(self, http_code, json_obj):
        Exception.__init__(self, json_obj.get("errors"))
        self.json_obj = json_obj
        self.http_status_code = http_code
        self.http_code = http_code
        self.http_body = None


class InvalidRequestError(APIError):
    """Error en la request (400-level)"""
    pass


class OperationFailedError(APIError):
    """Error en la operación (500-level o lógica de negocio)"""
    pass
```

**Jerarquía:**
```
Exception
  └── APIError
        ├── InvalidRequestError (400s)
        └── OperationFailedError (500s o business logic)
```

---

### 10. Utilities

#### util.py

```python
def serialize(value, prefix=None, idx=None):
    """
    Serializar dict/list a formato x-www-form-urlencoded
    
    {"user": {"name": "John"}} → {"user[name]": "John"}
    {"tags": ["a", "b"]} → {"tags[0]": "a", "tags[1]": "b"}
    """
    # Implementación recursiva para nested structures
    ...

def get_val(val):
    """Convertir valor Python a string para HTTP"""
    if val is None:
        return ""
    elif isinstance(val, bool):
        return str(val).lower()  # true/false
    else:
        return val
```

#### compat.py

```python
"""Compatibilidad Python 2/3"""

import sys

py_major_v = sys.version_info[0]
py_minor_v = sys.version_info[1]

if py_major_v < 3:
    from urllib import urlencode
    from urlparse import urlparse
else:
    from urllib.parse import urlencode, urlparse

# JSON con fallback
try:
    import simplejson as json
except ImportError:
    import json
```

---

## 🔄 Flujo de Ejecución

### Ejemplo: Customer.create()

```
1. User Code
   ↓
   sunpal.Customer.create({"first_name": "John", ...})

2. Customer Model (models/customers.py)
   ↓
   request.send("post", "/accounts/register-customer", params)

3. Request Layer (request.py)
   ↓
   - Serializar parámetros: util.serialize(params)
   - Obtener environment: SunPal.default_env
   - Llamar http_request.request()

4. HTTP Request (http_request.py)
   ↓
   - Construir URL: env.api_url("/accounts/register-customer")
     → https://test.sunpal.mx/api/v1/accounts/register-customer
   - Agregar headers (api-key, User-Agent, etc.)
   - Preparar payload (urlencoded)
   - Ejecutar: requests.post()

5. External API
   ↓
   → POST https://test.sunpal.mx/api/v1/accounts/register-customer
   ← 200 OK {"id": "ABC123", "first_name": "John", ...}

6. Response Processing (http_request.py)
   ↓
   - Parse JSON
   - Verificar status code
   - Si error → lanzar excepción
   - Si OK → retornar dict

7. Result Wrapping (request.py → result.py)
   ↓
   - Crear Result(response)
   - Lazy loading de modelo Customer

8. User Code
   ↓
   result.customer.id  # "ABC123"
   result.customer.first_name  # "John"
```

---

## 🔌 Endpoints Mapping

### Customers

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| `Customer.create()` | `POST /accounts/register-customer` | Crear cliente |
| `Customer.retrieve(id)` | `GET /accounts/customer/{id}` | Obtener cliente |
| `Customer.retrieve_by_reference(ref)` | `GET /accounts/customer-by-reference/{ref}` | Obtener por referencia |
| `Customer.update(id)` | `PATCH /accounts/customer/{id}` | Actualizar cliente |
| `Customer.list()` | `GET /customers/customer/` | Listar clientes |
| `Customer.send_nip()` | `POST /accounts/resend/authorization` | Enviar NIP |
| `Customer.add_address(id)` | `POST /accounts/address/` | Agregar dirección |
| `Customer.update_address(id)` | `PATCH /accounts/address/{id}/` | Actualizar dirección |
| `Customer.delete_address(id)` | `DELETE /accounts/address/{id}/` | Eliminar dirección |

### Consultas

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| `Consulta.create()` | `POST /burocredito/record` | Crear consulta |
| `Consulta.retrieve(id)` | `GET /burocredito/record/{id}` | Obtener consulta |

---

## 🔒 Seguridad

### Authentication

```python
# Header agregado automáticamente:
headers["api-key"] = env.api_key
```

### SSL/TLS

```python
# Por defecto (desde v0.1.6):
SunPal.verify_ca_certs = True

# Para desarrollo con certificados self-signed:
SunPal.verify_ca_certs = False
```

### Timeouts

```python
# Prevenir requests colgados
timeout = (connect_timeout, read_timeout)  # (30, 80) por defecto

# Configurables:
sunpal.update_connect_timeout_secs(60)
sunpal.update_read_timeout_secs(120)
```

---

## 📊 Diagrama de Clases

```
┌─────────────────┐
│    SunPal       │
├─────────────────┤
│ - default_env   │
│ + configure()   │
└────────┬────────┘
         │ has-a
         │
┌────────▼────────┐
│  Environment    │
├─────────────────┤
│ - api_key       │
│ - site          │
│ - sunpal_domain │
│ + api_url()     │
└─────────────────┘

┌─────────────────┐        ┌──────────────┐
│     Model       │◄───────│   Customer   │
├─────────────────┤        ├──────────────┤
│ - fields[]      │        │ + create()   │
│ + construct()   │        │ + retrieve() │
│ + load()        │        │ + update()   │
└─────────────────┘        │ + list()     │
                           └──────────────┘
         △
         │ inherits
         │
┌────────┴────────┐
│    Consulta     │
├─────────────────┤
│ + create()      │
│ + retrieve()    │
└─────────────────┘

┌─────────────────┐        ┌──────────────┐
│    Result       │        │  ListResult  │
├─────────────────┤        ├──────────────┤
│ - _response     │        │ - response[] │
│ + customer      │        │ - next_offset│
│ + consulta      │        │ + [items]    │
│ + address       │        └──────────────┘
└─────────────────┘

┌─────────────────────────┐
│      APIError           │
├─────────────────────────┤
│ - http_code             │
│ - json_obj              │
└──────────┬──────────────┘
           │ inherits
    ┌──────┴──────┐
    │             │
┌───▼────────┐ ┌──▼────────────────┐
│ Invalid    │ │ OperationFailed   │
│ RequestErr │ │ Error             │
└────────────┘ └───────────────────┘
```

---

## 🧪 Testing Architecture

```python
# tests/customers.py
class CustomersTestCase(unittest.TestCase):
    def setUp(self):
        # Configuración antes de cada test
        sunpal.configure(api_key="test_key", site="test_site")
    
    def test_get_customer(self):
        # Test individual
        entry = sunpal.Customer.retrieve(id="CUSTOMER_ID")
        self.assertTrue(entry.customer, True)
```

---

## 📈 Extensibilidad

### Agregar Nuevo Modelo

1. **Crear modelo en `sunpal/models/`:**

```python
# sunpal/models/payment.py
from sunpal.model import Model
from sunpal import request

class Payment(Model):
    fields = ["id", "amount", "status", "created_at"]
    
    @staticmethod
    def create(params=None, env=None, headers=None):
        return request.send(
            "post",
            request.uri_path("payments"),
            params, env, headers
        )
    
    @staticmethod
    def retrieve(id, params=None, env=None, headers=None):
        return request.send(
            "get",
            request.uri_path("payments", id),
            params, env, headers
        )
```

2. **Exportar en `sunpal/models/__init__.py`:**

```python
from sunpal.models.payment import Payment
```

3. **Exportar en `sunpal/__init__.py`:**

```python
from sunpal.models import Payment
```

4. **Agregar property en `Result`:**

```python
# sunpal/result.py
@property
def payment(self):
    return self._get("payment", Payment, {})
```

---

## 🔄 Ciclo de Vida de un Request

```
┌─────────────────────────────────────────────────┐
│ 1. Configuración (una vez)                      │
│    sunpal.configure(api_key, site)              │
│    → Crea Environment                           │
│    → Almacena en SunPal.default_env             │
└─────────────────────────────────────────────────┘
                     │
                     │ Configurado
                     ▼
┌─────────────────────────────────────────────────┐
│ 2. Llamada de Usuario                           │
│    result = sunpal.Customer.create({...})       │
└─────────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────┐
│ 3. Preparación                                  │
│    - Serializar parámetros                      │
│    - Obtener environment                        │
│    - Construir URI                              │
└─────────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────┐
│ 4. HTTP Request                                 │
│    - Construir URL completa                     │
│    - Agregar headers (api-key, etc.)            │
│    - Ejecutar requests.request()                │
└─────────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────┐
│ 5. Procesamiento de Respuesta                   │
│    - Parse JSON                                 │
│    - Verificar status code                      │
│    - Manejar errores                            │
└─────────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────┐
│ 6. Wrapping                                     │
│    - Crear Result o ListResult                  │
│    - Lazy loading de modelos                    │
└─────────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────┐
│ 7. Retorno a Usuario                            │
│    result.customer.id                           │
│    result.customer.first_name                   │
└─────────────────────────────────────────────────┘
```

---

## 📝 Consideraciones de Diseño

### Por qué Static Methods en Models?

```python
# Ventaja: API simple
sunpal.Customer.create({...})

# vs. alternativa con instancias:
customer = sunpal.Customer()
customer.create({...})
```

Los static methods son más simples para un wrapper de API REST.

### Por qué Lazy Loading en Result?

```python
@property
def customer(self):
    # Solo construye el modelo cuando se accede
    return self._get("customer", Customer, {...})
```

- Evita construcción innecesaria de objetos
- Permite acceso flexible: `result.customer` o `result.consulta`

### Por qué Singleton Pattern en SunPal?

```python
class SunPal:
    default_env = None  # Class variable, compartida
```

- Configuración global única
- No necesita instanciación
- Thread-safe para configuración una sola vez

---

## 🔮 Futuras Mejoras

1. **Async Support:**
   ```python
   async def create_customer_async(...):
       async with aiohttp.ClientSession() as session:
           ...
   ```

2. **Type Hints:**
   ```python
   def create(params: Dict[str, Any]) -> Result:
       ...
   ```

3. **Retry Logic:**
   ```python
   @retry(max_attempts=3, backoff=exponential)
   def request(...):
       ...
   ```

4. **Cache Layer:**
   ```python
   @cache(ttl=300)  # 5 minutos
   def retrieve(id):
       ...
   ```

---

**Última actualización:** 6 de marzo de 2026  
**Versión:** 0.1.6
