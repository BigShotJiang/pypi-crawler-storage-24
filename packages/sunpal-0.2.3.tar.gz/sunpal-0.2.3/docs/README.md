# 📚 Sunpal Library - Documentación Técnica

Esta carpeta contiene documentación técnica detallada para desarrolladores y mantenedores.

## 📋 Índice de Documentos

### Para Desarrolladores

- **[ARCHITECTURE.md](ARCHITECTURE.md)** - Arquitectura detallada del sistema
- **[AUDIT.md](AUDIT.md)** - Auditoría completa del código y mejores prácticas

### Para Deployment

- **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** - Guía paso a paso para deployment
- **[DEPLOYMENT_READY.md](DEPLOYMENT_READY.md)** - Checklist y resumen de readiness

### Resumen Ejecutivo

- **[RESUMEN_EJECUTIVO.md](RESUMEN_EJECUTIVO.md)** - Resumen completo de auditoría y estado

## 📂 Estructura de Documentación

```
docs/
├── README.md                 # Este archivo
├── ARCHITECTURE.md           # Arquitectura técnica
├── AUDIT.md                  # Auditoría de código
├── DEPLOYMENT_GUIDE.md       # Guía de deployment
├── DEPLOYMENT_READY.md       # Checklist deployment
└── RESUMEN_EJECUTIVO.md      # Resumen ejecutivo
```

## 🚀 Inicio Rápido

### Para Desarrollar
1. Lee [../WORKFLOW.md](../WORKFLOW.md) para el flujo de trabajo
2. Consulta [ARCHITECTURE.md](ARCHITECTURE.md) para entender la estructura

### Para Deployar
1. Revisa [DEPLOYMENT_READY.md](DEPLOYMENT_READY.md) para el checklist
2. Sigue [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) paso a paso

### Para Auditar
1. Consulta [AUDIT.md](AUDIT.md) para análisis detallado
2. Revisa [RESUMEN_EJECUTIVO.md](RESUMEN_EJECUTIVO.md) para el resumen

## 📖 Documentación Principal

La documentación orientada al usuario está en:
- **[../README.md](../README.md)** - Documentación principal para usuarios
- **[../CHANGELOG.md](../CHANGELOG.md)** - Historial de cambios
- **[../CONTRIBUTING.md](../CONTRIBUTING.md)** - Guía para contribuir
- **[../WORKFLOW.md](../WORKFLOW.md)** - Workflow de desarrollo

## 🔗 Enlaces Útiles

- **PyPI:** https://pypi.org/project/sunpal/
- **Repositorio:** Tu repo privado/público
- **Documentación Online:** https://sunpal.readthedocs.io/
- **Issues:** GitHub/GitLab Issues

---

**Última actualización:** 6 de marzo de 2026
