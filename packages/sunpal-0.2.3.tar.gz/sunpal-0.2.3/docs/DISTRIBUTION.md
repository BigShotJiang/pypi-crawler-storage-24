# Distribution Options

## Option 1: Public PyPI (Recommended for Open Source)

**Pros:**
- Simple: `pip install sunpal`
- No authentication needed
- Automatic version discovery
- CDN distribution

**Setup:**
```bash
# One-time setup
python3 -m pip install --upgrade twine

# Build and publish
make dist
make deploy  # or: python3 -m twine upload dist/*
```

**Users install:**
```bash
pip install sunpal
pip install sunpal==0.1.12  # specific version
```

---

## Option 2: Private Repository + Public PyPI

**This is what you need!**

- **Code:** Private GitHub/GitLab repo (source code stays private)
- **Distribution:** Public PyPI (only compiled wheels, no source code)
- **Users:** Install via `pip install sunpal` (don't need repo access)

**Advantages:**
- ✅ Source code remains private
- ✅ Easy installation for users
- ✅ No repository access needed
- ✅ Standard Python workflow

**CI/CD Setup (GitHub Actions example):**

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: '3.9'
      - name: Build package
        run: |
          pip install build twine
          python -m build
      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*
```

---

## Option 3: Private PyPI Server

**For fully private distribution:**

**Self-hosted:**
- [PyPI server](https://pypi.org/project/pypiserver/)
- [devpi](https://www.devpi.net/)
- [Artifactory](https://jfrog.com/artifactory/)

**Managed services:**
- [AWS CodeArtifact](https://aws.amazon.com/codeartifact/)
- [Google Artifact Registry](https://cloud.google.com/artifact-registry)
- [Azure Artifacts](https://azure.microsoft.com/en-us/services/devops/artifacts/)
- [Gemfury](https://gemfury.com/)

**Example with private PyPI:**
```bash
# Configure pip
pip config set global.index-url https://your-pypi.company.com/simple/
pip config set global.extra-index-url https://pypi.org/simple/

# Install works normally
pip install sunpal
```

---

## Option 4: Install Directly from Git (Private Repo)

**For internal teams with repo access:**

```bash
# Via HTTPS with token
pip install git+https://github-token@github.com/company/sunpal-library.git

# Via SSH (with SSH keys configured)
pip install git+ssh://git@github.com/company/sunpal-library.git

# Specific version/branch/tag
pip install git+https://github.com/company/sunpal-library.git@v0.1.12
pip install git+https://github.com/company/sunpal-library.git@main
pip install git+https://github.com/company/sunpal-library.git@feature/new-api
```

**In requirements.txt:**
```
# From specific tag
sunpal @ git+https://github.com/company/sunpal-library.git@v0.1.12

# From branch
sunpal @ git+https://github.com/company/sunpal-library.git@main

# With authentication token (use environment variable)
sunpal @ git+https://${GITHUB_TOKEN}@github.com/company/sunpal-library.git
```

---

## Recommended Setup for Sunpal

**Current situation:**
- ✅ Already published on PyPI as public package (v0.1.12)
- ✅ Users can `pip install sunpal`

**Recommended approach:**

1. **Keep private repo** for source code
2. **Publish to PyPI** for distribution
3. **Use CI/CD** to automate publishing
4. **Only wheels** get published (not full source)

**Benefits:**
- Source code stays private
- Easy installation for end users
- No credentials needed for installation
- Professional distribution

**What gets published to PyPI:**
- Compiled wheel: `sunpal-0.1.12-py3-none-any.whl`
- Optionally source dist: `sunpal-0.1.12.tar.gz`
- Metadata: description, version, dependencies
- NOT included: tests/, docs/, .git/, development files

---

## Security Best Practices

### 1. Protect Sensitive Code

**In `.gitignore` and build exclusions:**
```
# Don't include in distributions
internal/
proprietary/
secrets/
*.key
*.pem
```

### 2. Review Wheel Contents

```bash
# Build wheel
python -m build

# Check what's included
unzip -l dist/sunpal-0.1.12-py3-none-any.whl

# Verify before upload
twine check dist/*
```

### 3. Use PyPI API Tokens

```bash
# Create token at https://pypi.org/manage/account/token/
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcH...your-token-here

# Upload
twine upload dist/*
```

### 4. Separate Test and Production PyPI

```bash
# Test first
twine upload --repository testpypi dist/*

# Then production
twine upload dist/*
```

---

## Migration Path

If you want to make the repo private:

1. **GitHub/GitLab:** Change repo visibility to private
2. **PyPI:** Keep publishing normally (already public)
3. **Users:** No change needed - `pip install sunpal` still works
4. **Team:** Clone with authentication, install from PyPI

**Example workflow:**
```bash
# Developer
git clone git@github.com:company/sunpal-library.git  # Private repo
cd sunpal-library
make dev-setup  # Local development

# User (doesn't need repo access)
pip install sunpal  # Just works from PyPI
```

---

## Current Sunpal Status

```bash
# Already on PyPI
pip install sunpal  # ✅ Works now

# Repository can be private
# Publishing still works via CI/CD or manual upload
```

No changes needed for basic users - they use PyPI!
