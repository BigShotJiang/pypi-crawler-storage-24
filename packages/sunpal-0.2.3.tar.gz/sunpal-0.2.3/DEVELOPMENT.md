# Sunpal Library - Development Guide

## 🚀 Quick Start

### Opción 1: Docker (Recomendado)

```bash
# 1. Construir y arrancar
make dev-setup

# 2. Entrar al contenedor
make shell

# Dentro del contenedor:
python -m pytest tests/
```

### Opción 2: Local (Sin Docker)

```bash
# 1. Crear ambiente virtual
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. Instalar dependencias
make install
make install-dev

# 3. Ejecutar tests
make test-local
```

---

## 🐳 Desarrollo con Docker

### Comandos Principales

```bash
# Construir imagen
make build

# Iniciar contenedor
make up

# Entrar al shell
make shell

# Ver logs
make logs

# Detener
make down
```

### Testing

```bash
# Tests en Docker
make test

# Tests con coverage
make test-cov

# Tests en múltiples versiones de Python
make test-all  # Corre en 3.8, 3.9, 3.10

# Tests locales (rápido)
make quick-test
```

### Calidad de Código

```bash
# Linter
make lint

# Formatear código
make format

# Verificar formato
make format-check

# Type checking
make type-check
```

---

## 📦 Workflow de Desarrollo

### 1. Setup Inicial

```bash
# Clonar repo
git clone <repo-url>
cd sunpal-library

# Copiar env template
cp .env.example .env
# Editar .env con tus credenciales

# Setup con Docker
make dev-setup

# O setup local
make install
make install-dev
```

### 2. Crear Feature/Fix

```bash
# Crear rama
git checkout -b feat/nueva-funcionalidad

# Desarrollar...
# Editar archivos en sunpal/

# Test continuo
make quick-test

# O dentro del container:
make shell
pytest tests/ -v
```

### 3. Antes de Commit

```bash
# Formatear código
make format

# Verificar calidad
make lint

# Ejecutar todos los tests
make test

# Verificar coverage
make test-cov
```

### 4. Commit y Push

```bash
git add .
git commit -m "feat: descripción del cambio"
git push origin feat/nueva-funcionalidad
```

---

## 🏗️ Estructura del Proyecto

```
sunpal-library/
├── sunpal/                 # Código fuente
│   ├── __init__.py        # API pública
│   ├── main.py            # Clase principal
│   ├── environment.py     # Configuración
│   ├── http_request.py    # HTTP client
│   ├── request.py         # Request builders
│   ├── api_error.py       # Excepciones
│   ├── model.py           # Base model
│   ├── result.py          # Result wrappers
│   ├── version.py         # Versión
│   └── models/            # Modelos de datos
│       ├── customers.py
│       ├── consulta.py
│       └── interactive.py
│
├── tests/                 # Tests
│   ├── customers.py
│   ├── consulta.py
│   └── ...
│
├── Dockerfile.dev         # Docker para desarrollo
├── docker-compose.yml     # Orquestación Docker
├── Makefile              # Comandos útiles
├── setup.py              # Package config
├── requirements.txt      # Dependencias
├── .env.example          # Template de env vars
└── README.md             # Documentación principal
```

---

## 🧪 Testing

### Ejecutar Tests

```bash
# Todos los tests
make test

# Test específico
docker exec -it sunpal-dev-py39 python -m pytest tests/customers.py -v

# Test con palabra clave
docker exec -it sunpal-dev-py39 python -m pytest tests/ -k "customer" -v

# Detenerse en primer fallo
docker exec -it sunpal-dev-py39 python -m pytest tests/ -x
```

### Coverage

```bash
# Generar reporte HTML
make test-cov

# Ver en navegador
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

### Agregar Nuevo Test

```python
# tests/nuevo_test.py
import sunpal
import unittest

class NuevoTestCase(unittest.TestCase):
    
    def setUp(self):
        sunpal.configure(
            api_key="test_key",
            site="test_site"
        )
    
    def test_algo_nuevo(self):
        """Test descripción"""
        result = sunpal.Customer.list()
        self.assertIsNotNone(result)

if __name__ == "__main__":
    unittest.main()
```

---

## 📋 Checklist de Calidad

Antes de cada commit:

- [ ] Tests pasan: `make test`
- [ ] Código formateado: `make format`
- [ ] Sin errores de lint: `make lint`
- [ ] Coverage aceptable: `make test-cov`
- [ ] Commit message sigue conventional commits

---

## 🔄 Versionamiento

### Semantic Versioning

```
MAJOR.MINOR.PATCH
  |     |     |
  |     |     └─ Bug fixes
  |     └─────── New features (backward compatible)
  └───────────── Breaking changes
```

### Actualizar Versión

```bash
# 1. Editar ambos archivos:
# - setup.py (línea ~17)
# - sunpal/version.py

# 2. Verificar sincronización
make version

# 3. Commit
git commit -m "chore: bump version to X.Y.Z"

# 4. Tag
git tag -a vX.Y.Z -m "Release X.Y.Z"
git push origin main --tags
```

---

## 🚢 Deployment

### Build Local

```bash
# Limpiar builds anteriores
make clean

# Construir distribución
make build-dist

# Verificar paquetes
make check-dist

# Ver archivos generados
ls -lh dist/
```

### Deploy a PyPI

```bash
# TestPyPI (prueba primero)
make deploy-test

# Verificar instalación
pip install --index-url https://test.pypi.org/simple/ sunpal

# PyPI Production
make deploy
```

---

## 🔧 Troubleshooting

### Docker no arranca

```bash
# Reconstruir desde cero
make docker-rebuild

# Ver logs
make logs
```

### Tests fallan

```bash
# Limpiar cache
make clean

# Reinstalar en modo dev
make shell
pip install -e .
exit

# Ejecutar tests con verbose
make test
```

### Imports no funcionan

```bash
# Verificar instalación
make shell
python -c "import sunpal; print(sunpal.VERSION)"

# Reinstalar
pip uninstall sunpal
pip install -e .
```

---

## 🔐 Mejores Prácticas

### 1. Nunca Commitear

- ❌ `.env` con credenciales reales
- ❌ `__pycache__/` o `.pyc`
- ❌ `dist/` builds
- ❌ Credenciales en código

### 2. Siempre

- ✅ Usar `.env.example` como template
- ✅ Tests para nuevas features
- ✅ Formatear con black
- ✅ Conventional commits
- ✅ Sincronizar versiones

### 3. Testing

- ✅ Test antes de commit
- ✅ Test en múltiples Python versions
- ✅ Mock API calls en tests
- ✅ Coverage > 80%

---

## 📞 Comandos Útiles

```bash
# Ver versión actual
make version

# Info del proyecto
make info

# Limpiar todo
make clean-all

# Reset completo
make dev-reset

# Ayuda (ver todos los comandos)
make help
```

---

## 🎯 Workflow Completo Ejemplo

```bash
# 1. Setup inicial
make dev-setup

# 2. Crear feature
git checkout -b feat/nueva-feature

# 3. Desarrollar
make shell
# ... editar código ...
pytest tests/ -v
exit

# 4. Calidad
make format
make lint
make test-cov

# 5. Commit
git add .
git commit -m "feat: add nueva feature"

# 6. Push
git push origin feat/nueva-feature

# 7. Pull Request en GitHub/GitLab
```

---

## 🐍 Versiones de Python Soportadas

| Versión | Soporte | Testing |
|---------|---------|---------|
| 3.6     | ✅ Mínima | Manual |
| 3.7     | ✅ Soportada | Manual |
| 3.8     | ✅ Soportada | Automático |
| 3.9     | ✅ Principal | Automático |
| 3.10    | ✅ Soportada | Automático |
| 3.11+   | ⚠️ No probada | - |

---

**Última actualización:** 6 de marzo de 2026  
**Versión actual:** 0.1.12
