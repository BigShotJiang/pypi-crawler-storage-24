# SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Registration for dynamic middleware."""

from nat.builder.builder import Builder
from nat.cli.register_workflow import register_middleware
from nat.middleware.dynamic.dynamic_function_middleware import DynamicFunctionMiddleware
from nat.middleware.dynamic.dynamic_middleware_config import DynamicMiddlewareConfig


@register_middleware(config_type=DynamicMiddlewareConfig)
async def dynamic_middleware(config: DynamicMiddlewareConfig, builder: Builder):
    """Build a dynamic middleware from configuration.

    Args:
        config: The dynamic middleware configuration
        builder: The workflow builder

    Yields:
        A configured dynamic middleware instance
    """
    yield DynamicFunctionMiddleware(config=config, builder=builder)
