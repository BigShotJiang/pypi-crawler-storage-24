# SPDX-FileCopyrightText: Copyright (c) 2024-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# flake8: noqa
# isort:skip_file
"""Register LLM providers via import side effects.

This module is imported by the NeMo Agent Toolkit runtime to ensure providers are registered and discoverable.
"""
# Import any providers which need to be automatically registered here
from . import aws_bedrock_llm
from . import azure_openai_llm
from . import dynamo_llm
from . import huggingface_inference_llm
from . import huggingface_llm
from . import litellm_llm
from . import nim_llm
from . import openai_llm
