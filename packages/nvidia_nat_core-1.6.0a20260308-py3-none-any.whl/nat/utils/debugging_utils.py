# SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


def is_debugger_attached() -> bool:
    """
    Check if a debugger is attached to the current process.

    Returns
    -------
    bool
        True if a debugger is attached, False otherwise
    """
    import sys

    if "debugpy" in sys.modules:

        import debugpy

        return debugpy.is_client_connected()

    trace_func = sys.gettrace()

    # The presence of a trace function and pydevd means a debugger is attached
    if (trace_func is not None):
        trace_module = getattr(trace_func, "__module__", None)

        if (trace_module is not None and trace_module.find("pydevd") != -1):
            return True

    return False
