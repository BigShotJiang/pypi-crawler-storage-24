# Copyright (C) 2025, 2026 Embedl AB


from embedl_hub.tracking.client import Client as _Client
from embedl_hub.tracking.device_cloud import TFLiteBenchmarkParams
from embedl_hub.tracking.errors import (
    ArtifactUploadError,
    FileTooLargeError,
    StorageQuotaExceededError,
    UnsupportedDeviceError,
)
from embedl_hub.tracking.job import BenchmarkJob
from embedl_hub.tracking.rest_api import (
    REMOVE_PARENT,
    Device,
    Metric,
    Parameter,
    RunType,
    Tag,
)

global_client = _Client()

set_project = global_client.set_project
start_run = global_client.start_run
log_param = global_client.log_param
log_metric = global_client.log_metric
log_tag = global_client.log_tag
log_artifact = global_client.log_artifact
update_run = global_client.update_active_run
get_devices = global_client.get_devices
validate_device = global_client.validate_device
submit_benchmark_job = global_client.submit_benchmark_job

__all__ = [
    "set_project",
    "start_run",
    "log_param",
    "log_metric",
    "log_tag",
    "log_artifact",
    "get_devices",
    "validate_device",
    "submit_benchmark_job",
    "RunType",
    "REMOVE_PARENT",
    "global_client",
    "update_run",
    "Parameter",
    "Metric",
    "Tag",
    "Device",
    "BenchmarkJob",
    "TFLiteBenchmarkParams",
    "StorageQuotaExceededError",
    "FileTooLargeError",
    "ArtifactUploadError",
    "UnsupportedDeviceError",
]
