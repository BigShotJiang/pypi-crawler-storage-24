# Copyright (C) 2025, 2026 Embedl AB

from dataclasses import dataclass
from pathlib import Path

# See valid TFLite benchmark tool parameters:
# https://github.com/google-ai-edge/LiteRT/tree/main/tflite/tools/benchmark
VALID_TFLITE_PARAMS: frozenset[str] = frozenset(
    {
        # Core parameters
        "graph",
        "signature_to_run_for",
        "num_threads",
        "warmup_runs",
        "num_runs",
        "max_secs",
        "run_delay",
        "run_frequency",
        "enable_op_profiling",
        "max_profiling_buffer_entries",
        "allow_dynamic_profiling_buffer_increase",
        "op_profiling_output_mode",
        "op_profiling_output_file",
        "export_model_runtime_info",
        "model_runtime_info_output_file",
        "output_filepath",
        "output_proto_filepath",
        "print_preinvoke_state",
        "print_postinvoke_state",
        "report_peak_memory_footprint",
        "memory_footprint_check_interval_ms",
        "dry_run",
        "verbose",
        "release_dynamic_tensors",
        "optimize_memory_for_large_tensors",
        "enable_builtin_cast_constant_cache",
        # Model input parameters
        "input_layer",
        "input_layer_shape",
        "input_layer_value_range",
        "input_layer_value_files",
        # Common delegate parameters
        "max_delegated_partitions",
        "min_nodes_per_partition",
        "delegate_serialize_dir",
        "delegate_serialize_token",
        # GPU delegate
        "use_gpu",
        "gpu_precision_loss_allowed",
        "gpu_experimental_enable_quant",
        "gpu_inference_for_sustained_speed",
        "gpu_backend",
        "gpu_wait_type",
        # NNAPI delegate
        "use_nnapi",
        "nnapi_execution_preference",
        "nnapi_execution_priority",
        "nnapi_accelerator_name",
        "disable_nnapi_cpu",
        "nnapi_allow_fp16",
        "nnapi_allow_dynamic_dimensions",
        "nnapi_use_burst_mode",
        # Hexagon delegate
        "use_hexagon",
        "hexagon_profiling",
        "hexagon_lib_path",
        # XNNPACK delegate
        "use_xnnpack",
        "xnnpack_force_fp16",
        # CoreML delegate
        "use_coreml",
        "coreml_version",
        # External delegate
        "external_delegate_path",
        "external_delegate_options",
        # Stable delegate
        "stable_delegate_loader_settings",
    }
)


@dataclass
class TFLiteBenchmarkParams:
    """TFLite benchmark parameters.

    These parameters are passed to the TFLite benchmark tool when running
    on-device benchmarks. All parameters are optional - when not specified,
    the TFLite benchmark tool defaults will be used.

    For a complete list of supported parameters, see:
    https://github.com/google-ai-edge/LiteRT/tree/main/tflite/tools/benchmark
    """

    _params: dict[str, str]

    def __init__(self, params: dict[str, str] | None = None):
        """Initialize the TFLite benchmark parameters.

        Args:
            params: A dictionary of TFLite benchmark parameters.

        Raises:
            ValueError: If an invalid parameter is provided.
        """
        for key in params:
            if key not in VALID_TFLITE_PARAMS:
                raise ValueError(
                    f"Invalid benchmark parameter: '{key}'. "
                    "See https://github.com/google-ai-edge/LiteRT/tree/main/tflite/tools/benchmark "
                    "for valid parameters."
                )
        object.__setattr__(self, "_params", params or {})

    def to_dict(self) -> dict[str, str]:
        """Return the parameters as a dictionary."""
        return dict(self._params)


@dataclass
class LiteRtFiles:
    """Paths to LiteRT output files."""

    log_file: Path
    profile_pb: Path


def get_litert_output_files(artifacts_dir: Path) -> LiteRtFiles:
    """Return paths to the LiteRT output files in the artifacts directory.

    Raises FileNotFoundError if any expected files are not found.
    """

    def find_required(name: str) -> Path:
        path = next(artifacts_dir.rglob(name), None)
        if path is None:
            raise FileNotFoundError(
                f"Could not find {name} in {artifacts_dir}"
            )
        return path

    return LiteRtFiles(
        log_file=find_required("tflite-logs.txt"),
        profile_pb=find_required("tflite-op-profile.pb"),
    )
