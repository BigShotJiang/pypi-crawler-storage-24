# Copyright (C) 2025, 2026 Embedl AB

"""
Utility functions for working with TFLite models.
"""

import re
from pathlib import Path

from google.protobuf import json_format


def instantiate_tflite_interpreter(
    model_path: str, experimental_preserve_all_tensors: bool = False
) -> 'Interpreter':
    """Instantiate a TFLite interpreter and allocate tensors."""

    # pylint: disable=import-outside-toplevel
    # TF logging showed up in cli output without this.
    from ai_edge_litert.interpreter import Interpreter
    # pylint: enable=import-outside-toplevel

    interpreter = Interpreter(
        model_path=model_path,
        experimental_preserve_all_tensors=experimental_preserve_all_tensors,
    )
    interpreter.allocate_tensors()
    return interpreter


def get_tflite_model_input_names(model_path: str) -> list[str]:
    """Get the input tensor names of a TFLite model.

    Args:
        model_path: Path to the TFLite model file.

    Returns:
        A list of input tensor names.
    """
    interpreter = instantiate_tflite_interpreter(model_path)

    signatures: dict[str, dict[str, list[str]]] = (
        interpreter.get_signature_list()
    )
    signature_key = list(signatures.keys())[0]
    return signatures[signature_key]['inputs']


_MEMORY_LINE_RE = re.compile(
    r"Memory footprint delta from the start of the tool \(MB\):\s*"
    r"init=(?P<init>\d+(?:\.\d+)?)\s+overall=(?P<overall>\d+(?:\.\d+)?)"
)
_LATENCY_LINE_RE = re.compile(
    r"Inference \(avg\):\s*(?P<latency>\d+(?:\.\d+)?)"
)
_DELEGATE_LINE_RE = re.compile(
    r"Explicitly\s+applied\s+(?P<delegate>\w+)\s+delegate,\s+and\s+the\s+model\s+graph\s+"
    r"will\s+be\s+(?P<execution>completely|partially)\s+executed\s+by\s+the\s+delegate"
    r"(?:\s+w/\s+(?P<kernels>\d+)\s+delegate\s+kernels?)?\."
)

_DELEGATE_TO_COMPUTE_UNIT = {
    "coreml": "NPU",
    "gpu": "GPU",
    "hexagon": "NPU",
    "metal": "GPU",
    "nnapi": "NPU",
    "xnnpack": "CPU",
}


def _determine_compute_unit(
    name: str, node_type: str, active_delegate: str | None
) -> str:
    """Determine compute unit for a layer based on its name, nodeType, and active delegate.

    Args:
        name: The layer name from profiling data.
        node_type: The nodeType from profiling data.
        active_delegate: The delegate that was explicitly applied (from log parsing).

    Returns:
        A compute unit such as "CPU", "GPU", "NPU", etc.
    """
    # Check for delegate indicators in nodeType - this is the authoritative source
    node_type_lower = node_type.lower()
    for delegate, compute_unit in _DELEGATE_TO_COMPUTE_UNIT.items():
        if delegate in node_type_lower:
            return compute_unit

    # If nodeType didn't identify a delegate, check name prefix with active_delegate
    # GPU delegate uses "Delegate/" prefix but doesn't include "gpu" in nodeType.
    # XNNPACK also uses "Delegate/" prefix when running implicitly.
    if name.startswith("Delegate/"):
        if active_delegate and active_delegate.upper() == "GPU":
            return "GPU"
        return "CPU"

    # Default to CPU if no delegate indicators are found
    return "CPU"


def _count_layers_by_unit(layers: list[dict]) -> dict[str, int]:
    """Count layers by compute unit from layer records.

    Args:
        layers: List of layer records with 'compute_unit' key.

    Returns:
        Dictionary with counts for each compute unit.
    """
    counts = {}
    for layer in layers:
        unit = layer.get("compute_unit", "CPU")
        counts[unit] = counts.get(unit, 0) + 1
    return counts


def _parse_info_from_log_file(
    log_file: Path,
) -> tuple[float | None, float | None, str | None]:
    """
    Parse memory, latency, and active delegate from a tflite benchmark log.

    Returns:
        A tuple of (memory in MB or None, latency in ms or None, active delegate or None).
    """
    log_text = log_file.read_text(encoding="utf-8", errors="ignore")

    memory: float | None = None
    latency: float | None = None
    active_delegate: str | None = None

    for line in log_text.splitlines():
        if memory is None and (match := _MEMORY_LINE_RE.search(line)):
            memory = float(match.group("overall"))
        elif latency is None and (match := _LATENCY_LINE_RE.search(line)):
            latency = float(match.group("latency")) / 1000.0  # us to ms
        elif active_delegate is None and (
            match := _DELEGATE_LINE_RE.search(line)
        ):
            active_delegate = match.group("delegate")

    return memory, latency, active_delegate


def parse_tflite_profiling_artifacts(
    proto_path: Path,
    log_path: Path,
) -> tuple[dict, list[dict]]:
    """Parse TFLite profiling proto and return a summary dictionary and execution details."""

    # pylint: disable=import-outside-toplevel
    # TF logging showed up in cli output without this.
    from tensorflow.lite.profiling.proto import profiling_info_pb2
    # pylint: enable=import-outside-toplevel

    proto = profiling_info_pb2.BenchmarkProfilingData()
    with proto_path.open("rb") as f:
        proto.ParseFromString(f.read())
        profile_info = json_format.MessageToDict(proto)

    memory, mean_ms, active_delegate = _parse_info_from_log_file(log_path)

    layer_times = []
    execution_detail = []

    for subgraph in profile_info['runtimeProfile']['subgraphProfiles']:
        for layer in subgraph['perOpProfiles']:
            name = layer['name']
            latency_us = float(layer['inferenceMicroseconds']['avg'])
            node_type = layer['nodeType']
            compute_unit = _determine_compute_unit(
                name, node_type, active_delegate
            )
            layer_times.append((latency_us, name, node_type))
            layer_record = {
                "name": name,
                "type": node_type,
                "compute_unit": compute_unit,
                "execution_time": latency_us,
                "execution_cycles": 0,
            }
            execution_detail.append(layer_record)

    # Top 5 slowest layers
    top_5_layers = sorted(layer_times, reverse=True)[:5]

    summary_dict = {
        "mean_ms": mean_ms,
        "peak_memory_usage_mb": memory,
        "layer_times": top_5_layers,
        "layers": execution_detail,
        "layers_by_unit": _count_layers_by_unit(execution_detail),
    }

    return summary_dict, execution_detail
