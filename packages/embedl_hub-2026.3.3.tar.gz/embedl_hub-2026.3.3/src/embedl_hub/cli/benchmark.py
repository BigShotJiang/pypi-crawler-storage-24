# Copyright (C) 2025, 2026 Embedl AB

"""
CLI command to benchmark a model's performance on a device.

This command profiles the latency of a compiled model on a specified device.
"""

from pathlib import Path

import typer

from embedl_hub.cli.commands import (
    PROJECT_NAME_OPTION,
    RUN_NAME_OPTION,
    TAGS_OPTION,
)

# All other embedl_hub imports should be done inside the function.
from embedl_hub.cli.helper import DEVICE_HELPER, EMBEDL_BENCHMARK_PARAM_HELPER
from embedl_hub.tracking.errors import JobQuotaExceededError

benchmark_cli = typer.Typer(
    name="benchmark",
    help="Benchmark commands (default subcommand: 'embedl').",
    invoke_without_command=True,
)


@benchmark_cli.callback(invoke_without_command=True)
def benchmark_command(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled model file (.tflite).",
        show_default=False,
    ),
    device: str | None = typer.Option(
        None, "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Output folder for artifacts."
    ),
    parent_run_id: str | None = typer.Option(
        None,
        "--parent-id",
        help="ID of the parent run to link this benchmark run to.",
    ),
    benchmark_params: list[str] | None = typer.Option(
        None,
        "--param",
        "-p",
        help=EMBEDL_BENCHMARK_PARAM_HELPER,
        show_default=False,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Benchmark a model on the specified device."""

    # pylint: disable=import-outside-toplevel
    from embedl_hub.cli.utils import assert_api_config
    from embedl_hub.core.context import require_initialized_ctx
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])
    if ctx.invoked_subcommand is None:
        if not model:
            raise typer.BadParameter(
                "Please specify a model to compile using --model"
            )
        if not device:
            raise typer.BadParameter(
                "Please specify a device to benchmark on using --device"
            )
        ctx.invoke(
            embedl_benchmark_command,
            ctx=ctx,
            model=model,
            device=device,
            output_dir=output_dir,
            parent_run_id=parent_run_id,
            benchmark_params=benchmark_params,
            project_name=project_name,
            run_name=run_name,
            tags=tags,
        )


@benchmark_cli.command("embedl", no_args_is_help=True)
def embedl_benchmark_command(
    ctx: typer.Context,
    model: Path = typer.Option(
        ...,
        "-m",
        "--model",
        help="Path to a .tflite model file.",
        show_default=False,
    ),
    device: str = typer.Option(
        ..., "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Output folder for artifacts."
    ),
    parent_run_id: str | None = typer.Option(
        None,
        "--parent-id",
        help="ID of the parent run to link this benchmark run to.",
    ),
    benchmark_params: list[str] | None = typer.Option(
        None,
        "--param",
        "-p",
        help=EMBEDL_BENCHMARK_PARAM_HELPER,
        show_default=False,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Benchmark compiled model using the Embedl device cloud.

    Examples:
    ---------
    Benchmark a .tflite model on Samsung Galaxy S25 and upload artifacts to the web app:

        $ embedl-hub benchmark embedl -m my_model.tflite -d "Samsung Galaxy S25"

    Benchmark a .tflite model on Samsung Galaxy 8 Elite QRD and save
    artifacts to a custom output directory:

        $ embedl-hub benchmark embedl -m my_model.tflite -d "Samsung Galaxy 8 Elite QRD" -o results/

    Benchmark a .tflite model on Samsung Galaxy S25with custom TFLite benchmark parameters:

        $ embedl-hub benchmark embedl -m my_model.tflite -d "Samsung Galaxy S25" -p num_threads=2 -p warmup_runs=10

    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub.cli.utils import parse_tags, print_profile_summary
    from embedl_hub.core.benchmark import EmbedlBenchmarker
    from embedl_hub.core.hub_logging import console
    from embedl_hub.tracking import TFLiteBenchmarkParams
    # pylint: enable=import-outside-toplevel

    parsed_params: dict[str, str] = {}
    if benchmark_params:
        for param in benchmark_params:
            if "=" not in param:
                raise typer.BadParameter(
                    f"Invalid benchmark param format: '{param}'. Expected key=value."
                )
            key, value = param.split("=", 1)
            parsed_params[key] = value

    bp: TFLiteBenchmarkParams | None = None
    if parsed_params:
        try:
            bp = TFLiteBenchmarkParams(parsed_params)
        except ValueError as e:
            raise typer.BadParameter(str(e))

    console.log(f"Profiling {model.name} on {device}")
    config = ctx.obj["config"]
    tags_dict = parse_tags(tags)
    try:
        benchmarker = EmbedlBenchmarker(
            device, artifacts_dir=output_dir, benchmark_params=bp
        )
        result = benchmarker.benchmark(
            project_name=project_name or config["project_name"],
            model_path=model,
            run_name=run_name,
            parent_run_id=parent_run_id,
            tags=tags_dict,
        )
    except JobQuotaExceededError as exc:
        console.print(f"[red]Job quota exceeded:[/] {exc}")
        raise typer.Exit(1)
    except Exception as exc:
        console.print(f"[red]✗ profiling failed:[/] {exc}")
        raise typer.Exit(1)

    print_profile_summary(result.summary)

    if output_dir is not None:
        console.print(
            f"[green]✓ Saved benchmark artifacts to:[/] {output_dir.absolute()}"
        )


@benchmark_cli.command("qai-hub", no_args_is_help=True)
def qai_hub_benchmark_command(
    ctx: typer.Context,
    model: Path = typer.Option(
        ...,
        "-m",
        "--model",
        help="Path to a compiled model file (.tflite, .onnx, or .bin), or "
        "to a directory containing an ONNX model and its data files.",
        show_default=False,
    ),
    device: str = typer.Option(
        ..., "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    output_dir: Path = typer.Option(
        None, "--output-dir", "-o", help="Output folder for artifacts."
    ),
    parent_run_id: str | None = typer.Option(
        None,
        "--parent-id",
        help="ID of the parent run to link this benchmark run to.",
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Benchmark compiled model using Qualcomm AI Hub.

    Examples:
    ---------
    Benchmark a .tflite model on Samsung Galaxy S25 and save artifacts to
    the default benchmarks folder:

        $ embedl-hub benchmark qai-hub -m my_model.tflite -d "Samsung Galaxy S25"

    Benchmark an .onnx model on Samsung Galaxy 8 Elite QRD and save
    artifacts to a custom output directory:

        $ embedl-hub benchmark qai-hub -m my_model.onnx -d "Samsung Galaxy 8 Elite QRD" -o results/

    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub.cli.utils import parse_tags, print_profile_summary
    from embedl_hub.core.benchmark import BenchmarkError, QAIHubBenchmarker
    from embedl_hub.core.hub_logging import console
    # pylint: enable=import-outside-toplevel

    console.log(f"Profiling {model.name} on {device} using Qualcomm AI Hub")
    config = ctx.obj["config"]
    tags_dict = parse_tags(tags)
    try:
        benchmarker = QAIHubBenchmarker(device, output_dir)
        result = benchmarker.benchmark(
            project_name=project_name or config["project_name"],
            model_path=model,
            run_name=run_name,
            parent_run_id=parent_run_id,
            tags=tags_dict,
        )
    except (ValueError, BenchmarkError) as e:
        console.print(f"[red]✗ profiling failed:[/] {e}")
        raise typer.Exit(1)

    print_profile_summary(result.summary)

    console.print(
        f"[green]✓ Saved benchmark artifacts to:[/] {benchmarker.output_dir.absolute()}"
    )
