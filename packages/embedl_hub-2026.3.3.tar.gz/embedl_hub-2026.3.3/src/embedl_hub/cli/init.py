# Copyright (C) 2025, 2026 Embedl AB
"""
Project context management for embedl-hub CLI.

This module provides CLI commands to initialize and display the current project
context. The selected context determines under which project all data, results,
and metadata are stored in the user's account on https://hub.embedl.com.

Users can create new projects, switch between them, and view the active context.
Context information is stored locally in a YAML file.
"""

from __future__ import annotations

import typer
from rich.table import Table

init_cli = typer.Typer(help="Initialise / show project context")


@init_cli.command("init")
def init_command(
    ctx: typer.Context,
    project: str | None = typer.Option(
        None, "-p", "--project", help="Project name or id", show_default=False
    ),
):
    """
    Configure persistent CLI context.

    This command stores values used by other commands in a local context file
    in your home directory. The context file can contain:

    - Active project (created automatically if name does not exist)

    Examples
    --------
    Create a new project with a random name:
        $ embedl-hub init

    Create or set named project:
        $ embedl-hub init -p "My Flower Detector App"

    Set a project explicitly:
        $ embedl-hub init -p "My Flower Detector App"
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub.cli.utils import assert_api_config
    from embedl_hub.core.context import write_ctx_config, write_ctx_state
    from embedl_hub.core.hub_logging import console
    from embedl_hub.core.utils.tracking_utils import (
        set_new_project,
    )
    from embedl_hub.tracking.utils import (
        to_project_url,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()

    current_project = ctx.obj["config"].get("project_name")
    # Decide which project to use
    project_to_use: str | None
    if project:
        console.print(f"Setting project to '{project}'")
        project_to_use = project
    elif not current_project:
        console.print("No active project, creating a new one")
        project_to_use = project
    else:
        console.print(f"Keeping current project '{current_project}'")
        project_to_use = current_project
    set_new_project(ctx.obj, project_to_use)

    write_ctx_config(ctx.obj["config"])
    write_ctx_state(ctx.obj["state"])

    console.print(f"[green]✓ Project:[/] {ctx.obj['config']['project_name']}")
    console.print(
        f"See your results: {to_project_url(ctx.obj['state']['project_id'])}"
    )


@init_cli.command("show")
def show_command(
    ctx: typer.Context,
):
    """Print active project IDs and names."""

    # pylint: disable=import-outside-toplevel
    from embedl_hub.cli.utils import assert_api_config
    from embedl_hub.core.context import require_initialized_ctx
    from embedl_hub.core.hub_logging import console
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    table = Table(title="Configuration", show_lines=True, show_header=False)
    for k in ("project_name",):
        table.add_row(k, ctx.obj["config"].get(k, "—"))
    console.print(table)
