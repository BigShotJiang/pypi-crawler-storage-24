# Fantasy Genius MCP Server

Connect [Claude Desktop](https://claude.ai/download) to your [Fantasy Genius](https://fantasy-genius.com) NBA fantasy leagues.

Once configured, you can ask Claude things like:
- *"Show me the top 20 free agents in my Fantrax league."*
- *"Where does my team rank in each statistical category?"*
- *"Who should I pick up to improve my rebounding?"*
- *"Give me a draft strategy for my snake draft."*

## Requirements

- Python 3.10+
- An active [Fantasy Genius](https://fantasy-genius.com) account
- [Claude Desktop](https://claude.ai/download)

## Installation

```bash
pip install fantasy-genius-mcp
```

## Setup

### 1. Get your API token

Log in to Fantasy Genius and go to **Settings → Claude AI / MCP** (or navigate to `/mcp/token/`). Generate a token and copy it.

### 2. Create a config file

Create `~/.config/fantasy-genius-mcp/config.json`:

```json
{
  "api_token": "your-token-here",
  "base_url": "https://fantasy-genius.com"
}
```

### 3. Add to Claude Desktop

Edit your Claude Desktop config file:
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "fantasy-genius": {
      "command": "fantasy-genius-mcp",
      "env": {
        "FG_MCP_CONFIG": "/path/to/your/config.json"
      }
    }
  }
}
```

### 4. Restart Claude Desktop

Quit and reopen Claude Desktop. You'll see **fantasy-genius** listed as an MCP server.

## Available Tools

| Tool | Description |
|------|-------------|
| `get_my_leagues` | List all your leagues and team IDs |
| `get_league_settings` | Scoring system, roster size, IR slots |
| `get_team_roster` | Team roster with projections or live stats |
| `get_free_agents` | Available players ranked by value |
| `get_team_analysis` | Category rankings across all league teams |
| `search_players` | Find players by name or position |

## License

MIT
