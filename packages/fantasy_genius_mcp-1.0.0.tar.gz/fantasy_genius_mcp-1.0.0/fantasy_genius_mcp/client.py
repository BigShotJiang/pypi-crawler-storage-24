"""HTTP client wrapping the Fantasy Genius REST API."""
import httpx
from .config import MCPConfig


class FGClient:
    def __init__(self, config: MCPConfig):
        self.base_url = config.base_url.rstrip('/')
        self.headers = {
            'X-Api-Key': config.api_token,
            'Content-Type': 'application/json',
        }
        self.timeout = config.timeout_seconds

    def _get(self, path: str, params: dict = None) -> dict:
        url = f"{self.base_url}{path}"
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(url, headers=self.headers, params=params or {})
        response.raise_for_status()
        return response.json()

    def get_leagues(self) -> dict:
        return self._get('/mcp/api/v1/leagues/')

    def get_league_settings(self, league_id: str, provider: str) -> dict:
        return self._get(f'/mcp/api/v1/leagues/{league_id}/settings/',
                         {'provider': provider})

    def get_roster(self, league_id: str, provider: str, team_id: str,
                   stats_type: int = -1, game_value: str = 'per-game') -> dict:
        return self._get(f'/mcp/api/v1/leagues/{league_id}/roster/', {
            'provider': provider,
            'team_id': team_id,
            'stats_type': stats_type,
            'game_value': game_value,
        })

    def get_free_agents(self, league_id: str, provider: str,
                        stats_type: int = -1, limit: int = 30,
                        position: str = None, game_value: str = 'per-game') -> dict:
        params = {
            'provider': provider,
            'stats_type': stats_type,
            'limit': limit,
            'game_value': game_value,
        }
        if position:
            params['position'] = position
        return self._get(f'/mcp/api/v1/leagues/{league_id}/free-agents/', params)

    def get_team_analysis(self, league_id: str, provider: str, team_id: str,
                          stats_type: int = -1, game_value: str = 'per-game') -> dict:
        return self._get(f'/mcp/api/v1/leagues/{league_id}/team-analysis/', {
            'provider': provider,
            'team_id': team_id,
            'stats_type': stats_type,
            'game_value': game_value,
        })

    def search_players(self, league_id: str, provider: str, query: str = None,
                       limit: int = 20, position: str = None,
                       stats_type: int = -1) -> dict:
        params = {
            'league_id': league_id,
            'provider': provider,
            'limit': limit,
            'stats_type': stats_type,
        }
        if query:
            params['q'] = query
        if position:
            params['position'] = position
        return self._get('/mcp/api/v1/players/search/', params)
