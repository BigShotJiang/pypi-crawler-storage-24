"""Configuration loader for the Fantasy Genius MCP server."""
import json
import os
from pathlib import Path
from pydantic import BaseModel


class MCPConfig(BaseModel):
    api_token: str
    base_url: str = "https://fantasy-genius.com"
    timeout_seconds: int = 30


def load_config() -> MCPConfig:
    config_path = os.environ.get(
        'FG_MCP_CONFIG',
        str(Path.home() / '.config' / 'fantasy-genius-mcp' / 'config.json'),
    )
    with open(config_path) as f:
        data = json.load(f)
    return MCPConfig(**data)
