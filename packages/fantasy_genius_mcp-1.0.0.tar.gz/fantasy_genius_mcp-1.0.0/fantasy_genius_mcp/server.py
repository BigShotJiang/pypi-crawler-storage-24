"""
Fantasy Genius MCP Server entry point.

Run via:  fantasy-genius-mcp
Or:       python -m fantasy_genius_mcp.server
"""
import asyncio
import json
import sys
from typing import Any

import mcp.server.stdio
import mcp.types as types
from mcp.server import Server

from .client import FGClient
from .config import load_config

# ---------------------------------------------------------------------------
# Initialise server and client
# ---------------------------------------------------------------------------

app = Server("fantasy-genius")

try:
    _config = load_config()
    _client = FGClient(_config)
    _init_error = None
except Exception as e:
    _config = None
    _client = None
    _init_error = str(e)


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

_TOOLS = [
    types.Tool(
        name="get_my_leagues",
        description=(
            "List all your Fantasy Genius leagues across Fantrax, ESPN, and Yahoo. "
            "Returns league IDs, names, providers, your team ID, and scoring settings. "
            "Always call this first to get the league_id and provider needed by other tools."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    types.Tool(
        name="get_league_settings",
        description=(
            "Get scoring system, roster size, IR slots, keeper type, punt categories, "
            "and draft budget for a specific league."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "league_id": {"type": "string", "description": "League ID from get_my_leagues"},
                "provider": {"type": "string", "enum": ["fantrax", "espn", "yahoo"]},
            },
            "required": ["league_id", "provider"],
        },
    ),
    types.Tool(
        name="get_team_roster",
        description=(
            "Get the current roster of a specific team with stats and rankings. "
            "Use stats_type=-1 for rest-of-season projections (recommended for draft), "
            "stats_type=30 for last 30 days, stats_type=14 for last 14 days."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "league_id": {"type": "string"},
                "provider": {"type": "string", "enum": ["fantrax", "espn", "yahoo"]},
                "team_id": {"type": "string", "description": "Team ID from get_my_leagues"},
                "stats_type": {
                    "type": "integer",
                    "default": -1,
                    "description": "-1=projections, 7/14/30=last N days",
                },
                "game_value": {
                    "type": "string",
                    "enum": ["per-game", "total"],
                    "default": "per-game",
                },
            },
            "required": ["league_id", "provider", "team_id"],
        },
    ),
    types.Tool(
        name="get_free_agents",
        description=(
            "Get the best available (unowned) players in a league, ranked by projected value. "
            "Optionally filter by position. Ideal for finding waiver wire pickups or draft targets."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "league_id": {"type": "string"},
                "provider": {"type": "string", "enum": ["fantrax", "espn", "yahoo"]},
                "stats_type": {"type": "integer", "default": -1},
                "limit": {
                    "type": "integer",
                    "default": 25,
                    "maximum": 100,
                    "description": "Max players to return",
                },
                "position": {
                    "type": "string",
                    "description": "Filter by position: PG, SG, SF, PF, C (optional)",
                },
                "game_value": {
                    "type": "string",
                    "enum": ["per-game", "total"],
                    "default": "per-game",
                },
            },
            "required": ["league_id", "provider"],
        },
    ),
    types.Tool(
        name="get_team_analysis",
        description=(
            "Get category-by-category rankings for all teams in a league. "
            "Shows where a team ranks in PTS, REB, AST, STL, BLK, TOV, FG%, FT%, 3P "
            "so you can identify strengths, weaknesses, and draft/trade strategy."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "league_id": {"type": "string"},
                "provider": {"type": "string", "enum": ["fantrax", "espn", "yahoo"]},
                "team_id": {"type": "string"},
                "stats_type": {"type": "integer", "default": -1},
                "game_value": {
                    "type": "string",
                    "enum": ["per-game", "total"],
                    "default": "per-game",
                },
            },
            "required": ["league_id", "provider", "team_id"],
        },
    ),
    types.Tool(
        name="search_players",
        description=(
            "Search for NBA players by name, or get a ranked list of players for a league. "
            "If q (query) is provided, filters by player name. "
            "Returns stats, rankings, injury status, and fantasy value."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "league_id": {"type": "string"},
                "provider": {"type": "string", "enum": ["fantrax", "espn", "yahoo"]},
                "q": {"type": "string", "description": "Player name to search (optional)"},
                "position": {"type": "string", "description": "Filter by position (optional)"},
                "limit": {"type": "integer", "default": 20},
                "stats_type": {"type": "integer", "default": -1},
            },
            "required": ["league_id", "provider"],
        },
    ),
]


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

@app.list_tools()
async def list_tools() -> list[types.Tool]:
    return _TOOLS


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[types.TextContent]:
    if _client is None:
        return [types.TextContent(
            type="text",
            text=f"Fantasy Genius MCP server failed to initialise: {_init_error}\n"
                 "Check your config file and try again.",
        )]

    try:
        if name == "get_my_leagues":
            data = _client.get_leagues()
        elif name == "get_league_settings":
            data = _client.get_league_settings(**arguments)
        elif name == "get_team_roster":
            data = _client.get_roster(**arguments)
        elif name == "get_free_agents":
            data = _client.get_free_agents(**arguments)
        elif name == "get_team_analysis":
            data = _client.get_team_analysis(**arguments)
        elif name == "search_players":
            data = _client.search_players(**arguments)
        else:
            return [types.TextContent(type="text", text=f"Unknown tool: {name}")]

        return [types.TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Error calling Fantasy Genius API ({name}): {e}",
        )]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def _main():
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options(),
        )


def main():
    asyncio.run(_main())


if __name__ == "__main__":
    main()
