---
title: "XML API Reference"
tags: [xml, envelope, header, body, tags, static-variables, request, response, export, import, execute]
sources:
  - url: https://help.tallysolutions.com/understanding-tally-xml-tags/
    description: "Deep dive on every XML tag — header, body, TDL blocks"
    tier: official
  - url: https://help.tallysolutions.com/integration-with-tallyprime/
    description: "48-min comprehensive reference — masters, vouchers, reports"
    tier: official
  - url: https://help.tallysolutions.com/xml-integration/
    description: "XML schema overview and base document structure"
    tier: official
  - url: https://help.tallysolutions.com/case-study-1/
    description: "Worked import/export examples with duplicate handling"
    tier: official
  - url: https://help.tallysolutions.com/developer-reference/integration-capabilities/xml-message-formats/
    description: "XML message format reference — request/response components"
    tier: official
  - url: https://help.tallysolutions.com/tally/tallyprime-as-server/
    description: "Tally as HTTP server — VB code patterns, import logs"
    tier: official
relevance: "Read this when building or debugging any XML request/response to Tally"
project_lessons: "docs/lessons/tally-xml-format.md"
---

# XML API Reference

## Envelope Structure

Every XML request follows this structure:

```xml
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export|Import|Execute</TALLYREQUEST>
    <TYPE>Data|Collection|Object|Function</TYPE>
    <SUBTYPE>Ledger|StockItem|...</SUBTYPE>   <!-- optional -->
    <ID>Report Name or Object Name</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>...</STATICVARIABLES>
      <REPEATVARIABLES>...</REPEATVARIABLES>   <!-- optional -->
      <FETCHLIST>...</FETCHLIST>               <!-- optional, for Object exports -->
      <FUNCPARAMLIST>...</FUNCPARAMLIST>        <!-- optional, for Function calls -->
      <TDL><TDLMESSAGE>...</TDLMESSAGE></TDL> <!-- optional, inline TDL -->
    </DESC>
    <DATA>
      <TALLYMESSAGE>...</TALLYMESSAGE>         <!-- for imports -->
    </DATA>
  </BODY>
</ENVELOPE>
```

## Header Tags

| Tag | Required | Values | Notes |
|-----|----------|--------|-------|
| `VERSION` | Yes | `1` | Messaging format version |
| `TALLYREQUEST` | Yes | `Export`, `Import`, `Execute` | Operation type |
| `TYPE` | Yes | `Data`, `Collection`, `Object`, `Function` | Entity category |
| `SUBTYPE` | Only for Object | e.g. `Ledger`, `StockItem` | Refines TYPE |
| `ID` | Yes | Report name, collection name, object name | Can have `TYPE="Name"` attribute |

## Three Request Types

| Type | Purpose | Example |
|------|---------|---------|
| **Export** | Read data from Tally | Trial Balance, P&L, ledger list |
| **Import** | Write data to Tally | Create ledger, create voucher |
| **Execute** | Trigger Tally actions | Sync, custom TDL actions |

## Static Variables (Prefix: `SV`)

All static variable tags begin with `SV`. Key ones:

| Variable | Purpose | Example |
|----------|---------|---------|
| `SVCURRENTCOMPANY` | Target company (exact name) | `ABC Company Ltd` |
| `SVEXPORTFORMAT` | Response format | `$$SysName:XML` |
| `SVFROMDATE` | Period start | `20250401` |
| `SVTODATE` | Period end | `20260331` |
| `EXPLODEFLAG` | Expand groups in reports | `Yes` / `No` |
| `IMPORTDUPS` | Duplicate handling | `@@DUPCOMBINE` |

## Export Format Options

`$$SysName:XML`, `$$SysName:HTML`, `$$SysName:ASCII`, `$$SysName:SDF`, `$$SysName:BinaryXML`

## Response Structure

```xml
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <STATUS>1</STATUS>        <!-- 1=success, 0=failure, -1=error -->
  </HEADER>
  <BODY>
    <DATA>...</DATA>
  </BODY>
</ENVELOPE>
```

### Import Response Tags

```xml
<RESPONSE>
  <CREATED>1</CREATED>
  <ALTERED>0</ALTERED>
  <DELETED>0</DELETED>
  <LASTVCHID>12345</LASTVCHID>
  <LASTMID>67890</LASTMID>
  <COMBINED>0</COMBINED>
  <IGNORED>0</IGNORED>
  <ERRORS>0</ERRORS>
  <CANCELLED>0</CANCELLED>
</RESPONSE>
```

### Error Response

```xml
<ENVELOPE>
  <HEADER><VERSION>1</VERSION><STATUS>0</STATUS></HEADER>
  <BODY>
    <DATA>
      <STATUS.LIST>
        <STATUS><CODE>123</CODE><DESC>Invalid Request</DESC></STATUS>
      </STATUS.LIST>
    </DATA>
  </BODY>
</ENVELOPE>
```

## Two Import Envelope Styles

Both work. Style B is more common for HTTP API usage.

**Style A (file-based / older):**
```xml
<HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
<BODY>
  <IMPORTDATA>
    <REQUESTDESC><REPORTNAME>All Masters</REPORTNAME></REQUESTDESC>
    <REQUESTDATA><TALLYMESSAGE>...</TALLYMESSAGE></REQUESTDATA>
  </IMPORTDATA>
</BODY>
```

**Style B (HTTP API):**
```xml
<HEADER>
  <VERSION>1</VERSION>
  <TALLYREQUEST>Import</TALLYREQUEST>
  <TYPE>Data</TYPE>
  <ID>All Masters</ID>   <!-- or "Vouchers" -->
</HEADER>
<BODY>
  <DESC><STATICVARIABLES>...</STATICVARIABLES></DESC>
  <DATA><TALLYMESSAGE>...</TALLYMESSAGE></DATA>
</BODY>
```

## SOAP Wrapper (Alternative)

Tally also accepts SOAP-wrapped envelopes:
```xml
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
  <SOAP-ENV:Body>
    <ENVELOPE>...</ENVELOPE>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
```

## FETCHLIST (for Object exports)

```xml
<FETCHLIST>
  <FETCH>Name</FETCH>
  <FETCH>TNetBalance</FETCH>
  <FETCH>LedgerPhone</FETCH>
</FETCHLIST>
```

Only works when `TYPE` is `Object`.

## Inline TDL Block

Embed TDL definitions directly in XML requests:
```xml
<TDL>
  <TDLMESSAGE>
    <COLLECTION NAME="Remote Ledger Coll" ISINITIALIZE="Yes">
      <TYPE>Ledger</TYPE>
      <NATIVEMETHOD>Name</NATIVEMETHOD>
      <NATIVEMETHOD>OpeningBalance</NATIVEMETHOD>
    </COLLECTION>
  </TDLMESSAGE>
</TDL>
```

TDL elements support attributes: `NAME`, `ISMODIFY`, `ISFIXED`, `ISINITIALIZE`, `ISOPTION`, `ISINTERNAL`.

## Content-Type and Encoding

- `text/xml; charset=utf-8` (recommended)
- `text/xml; charset=utf-16`
- `text/xml; charset=ascii`
