---
title: "Master Data Import & Export"
tags: [masters, ledger, group, stock-item, unit, godown, create, alter, delete, duplicates, aliases, contact-details]
sources:
  - url: https://help.tallysolutions.com/integration-with-tallyprime/
    description: "Comprehensive master creation XML — groups, ledgers, stock items, UOMs"
    tier: official
  - url: https://help.tallysolutions.com/sample-xml/
    description: "Ledger with full contact details, alteration examples"
    tier: official
  - url: https://help.tallysolutions.com/case-study-1/
    description: "Master import with duplicate handling strategies"
    tier: official
  - url: https://help.tallysolutions.com/scenario-1/
    description: "End-to-end master migration from legacy system"
    tier: official
  - url: https://help.tallysolutions.com/scenario-3/
    description: "Bidirectional master export, modify, re-import"
    tier: official
relevance: "Read this when creating or modifying ledgers, groups, stock items, or other master data"
---

# Master Data Import & Export

## Import Envelope

```xml
<ENVELOPE>
  <HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>All Masters</REPORTNAME>
        <STATICVARIABLES>
          <SVCURRENTCOMPANY>MyCompany</SVCURRENTCOMPANY>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <!-- master elements here -->
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>
```

## Group

```xml
<GROUP Action="Create">
  <NAME>North Zone Debtors</NAME>
  <PARENT>Sundry Debtors</PARENT>
</GROUP>
```

## Ledger (Basic)

```xml
<LEDGER Action="Create">
  <NAME>New Customer</NAME>
  <PARENT>Sundry Debtors</PARENT>
  <OPENINGBALANCE>0</OPENINGBALANCE>
</LEDGER>
```

## Ledger (Full Contact Details)

```xml
<LEDGER Action="Create">
  <NAME>Customer ABC</NAME>
  <PARENT>Sundry Debtors</PARENT>
  <MAILINGNAME.LIST TYPE="String">
    <MAILINGNAME>Customer – Mailing name</MAILINGNAME>
  </MAILINGNAME.LIST>
  <ADDRESS.LIST TYPE="String">
    <ADDRESS>Door No</ADDRESS>
    <ADDRESS>Lane</ADDRESS>
    <ADDRESS>Locality</ADDRESS>
  </ADDRESS.LIST>
  <PINCODE>560068</PINCODE>
  <COUNTRYNAME>India</COUNTRYNAME>
  <LEDSTATENAME>Karnataka</LEDSTATENAME>
  <EMAIL>A@abc.com</EMAIL>
  <EMAILCC>ACC@abc.com</EMAILCC>
  <LEDGERPHONE>0888888</LEDGERPHONE>
  <LEDGERMOBILE>99999999</LEDGERMOBILE>
  <LEDGERFAX>FaxNumber</LEDGERFAX>
  <ADDITIONALNAME>Additional Name</ADDITIONALNAME>
</LEDGER>
```

## Ledger with Aliases

```xml
<NAME.LIST TYPE="String">
  <NAME>Primary Name</NAME>
  <NAME>Alias 1</NAME>
  <NAME>Alias 2</NAME>
</NAME.LIST>
```

## Stock Item

```xml
<STOCKITEM Action="Create">
  <NAME>Red Colored Striped Shirt</NAME>
  <BASEUNITS>Pcs</BASEUNITS>
  <PARENT>Stock Group Name</PARENT>
  <OPENINGBALANCE>100</OPENINGBALANCE>
  <OPENINGRATE>250.00</OPENINGRATE>
  <NAME.LIST TYPE="String">
    <NAME>Red Colored Striped Shirt</NAME>
  </NAME.LIST>
</STOCKITEM>
```

### Part Numbers (via MAILINGNAME)

```xml
<MAILINGNAME.LIST TYPE="String">
  <MAILINGNAME>PART-12345</MAILINGNAME>
</MAILINGNAME.LIST>
```

## Units of Measure

### Simple UOM
```xml
<UNIT Action="Create">
  <NAME>Pcs</NAME>
  <ISSIMPLEUNIT>Yes</ISSIMPLEUNIT>
  <ORIGINALNAME>Pieces</ORIGINALNAME>
  <DECIMALPLACES>2</DECIMALPLACES>
</UNIT>
```

### Compound UOM
```xml
<UNIT Action="Create">
  <NAME>Dozen of 12 Pieces</NAME>
  <ISSIMPLEUNIT>No</ISSIMPLEUNIT>
  <BASEUNITS>Doz</BASEUNITS>
  <ADDITIONALUNITS>Pcs</ADDITIONALUNITS>
  <CONVERSION>12</CONVERSION>
</UNIT>
```

**Warning:** Cannot alter a UOM if it's used in transactions.

## Godown

```xml
<GODOWN Action="Create">
  <NAME>Factory</NAME>
</GODOWN>
```

Default godown name: `Main Location`

## Alter a Master

```xml
<LEDGER NAME="Customer ABC" Action="Alter">
  <NAME>Customer ABC Updated</NAME>
</LEDGER>
```

For ledger rename:
```xml
<LEDGER NAME="ICICI" Action="Alter">
  <NAME>HDFC</NAME>
</LEDGER>
```

## Delete a Master

```xml
<LEDGER NAME="ICICI" Action="Delete"></LEDGER>
```

## Duplicate Handling

Set in `STATICVARIABLES`:

```xml
<IMPORTDUPS>@@DUPCOMBINE</IMPORTDUPS>
```

| Strategy | Behavior |
|----------|----------|
| `@@DUPCOMBINE` | Merge opening balances (useful for company mergers) |
| `@@DupModify` | Replace existing value with imported value |
| `@@DupIgnoreCombine` | Skip existing records entirely |

## Creation Order (Dependencies)

Create in this order to avoid missing reference errors:
1. **Groups** (parent groups first)
2. **Units of Measure**
3. **Godowns**
4. **Stock Groups**
5. **Ledgers** (parent groups must exist)
6. **Stock Items** (UOMs and stock groups must exist)
7. **Vouchers** (all referenced ledgers and stock items must exist)

## Special Character Handling

XML-unsafe characters in master names must be escaped:
- `&` → `&amp;`
- `<` → `&lt;`
- `>` → `&gt;`
- `"` → `&quot;`

Use a sanitization function before constructing XML.

## Bidirectional Pattern (Scenario 3)

1. Configure TDL report on Tally side for structured export
2. Send export request → receive ledger data as XML
3. Parse and modify externally
4. Generate alteration XML and POST back
