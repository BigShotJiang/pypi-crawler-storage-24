---
title: "TDL Essentials for Integration"
tags: [tdl, collections, objects, methods, reports, functions, custom-reports, inline-tdl, nativemethod, datasource]
sources:
  - url: https://help.tallysolutions.com/developer-reference/tally-definition-language/
    description: "TDL language overview — definitions, attributes, modifiers"
    tier: official
  - url: https://help.tallysolutions.com/developer-reference/tally-definition-language/what-is-reports-and-printing-in-tdl/
    description: "Report types — tabular, hierarchical, columnar, drill-down"
    tier: official
  - url: https://help.tallysolutions.com/article/DeveloperReference/
    description: "Legacy TDL developer reference hub"
    tier: official
  - url: https://help.tallysolutions.com/integration-methods-and-technologies/
    description: "TDL functions and collection attributes for integration"
    tier: official
relevance: "Read this when building custom collections, embedding TDL in XML requests, or understanding Tally's data model"
---

# TDL Essentials for Integration

## Core Concepts

| TDL Concept | Analogy | Purpose |
|-------------|---------|---------|
| **Collection** | Table | Defines what data to gather |
| **Object** | Row | Each instance of master/voucher |
| **Method** | Column | Properties like `$Name`, `$ClosingBalance` |
| **Report** | View | Composed of Forms, Parts, Lines, Fields |
| **Function** | Formula | Computed values like `$$IsDr`, `$$IsLedger` |

## Method Prefix: `$`

Access object properties with `$` prefix:
- `$Name` — object name
- `$ClosingBalance` — closing balance
- `$OpeningBalance` — opening balance
- `$Parent` — parent group

## Built-in Functions: `$$`

| Function | Purpose |
|----------|---------|
| `$$IsDr` | Check if balance is debit |
| `$$IsCr` | Check if balance is credit |
| `$$IsLedger` | Check if object is a ledger |
| `$$SysName` | System name resolution (e.g., `$$SysName:XML`) |
| `$$NumStockItems` | Count of stock items |
| `$$Round` | Rounding with precision |
| `$$SetAutoColumns` | Multi-column report generation |
| `$$KeyExplode` | Drill-down on Shift+Enter |

## Variable Types and Prefixes

TDL variables control report behavior. Two key prefixes for integration:

| Prefix | Scope | Purpose | Example |
|--------|-------|---------|---------|
| `SV` | System/Static | Global config — company, dates, format | `SVCURRENTCOMPANY`, `SVFROMDATE` |
| `DSP` | Display | Report display toggles — columns, totals, detail level | `DSPHasColumnTotal`, `DSPShowOpening` |

### SV Variables (well-documented)

| Variable | Type | Purpose |
|----------|------|---------|
| `SVCURRENTCOMPANY` | String | Target company name |
| `SVFROMDATE` / `SVTODATE` | Date | Period range (YYYYMMDD) |
| `SVEXPORTFORMAT` | String | Output format (`$$SysName:XML`, `$$SysName:HTML`, etc.) |
| `SVPrinterName` | String | Target printer |
| `SVPreview` | Logical | Print preview on/off |
| `SVPrintCopies` | Number | Number of copies |
| `SVBackupPath` | String | Backup file path (persistent) |

### DSP Variables (largely undocumented)

These correspond to GUI toggles (F5, F12, Alt+F1, Alt+B) but are not officially catalogued.
Known ones:

| Variable | Type | Default | Effect |
|----------|------|---------|--------|
| `DSPHasColumnTotal` | Logical | Yes | Show column totals |
| `DSPShowOpening` | Logical | — | Show opening balances |
| `DSPShowMonthly` | Logical | — | Monthly breakdown |
| `DSPOrderCombo` | String | — | Sort order control |

**Discovery:** Use Expression Diagnostics in Developer Mode to find which DSP variables
a specific report uses. See `04-report-export-patterns.md` for the step-by-step process.

### Passing Variables via XML

Both SV and DSP variables go inside `<STATICVARIABLES>`:
```xml
<STATICVARIABLES>
  <SVCURRENTCOMPANY>MyCompany</SVCURRENTCOMPANY>
  <EXPLODEFLAG>Yes</EXPLODEFLAG>
  <DSPHasColumnTotal>No</DSPHasColumnTotal>
</STATICVARIABLES>
```

## Inline TDL in XML Requests

Embed TDL definitions directly in export requests — no need to install TDL files on Tally:

```xml
<TDL>
  <TDLMESSAGE>
    <COLLECTION NAME="My Custom Collection" ISINITIALIZE="Yes">
      <TYPE>Ledger</TYPE>
      <NATIVEMETHOD>Name</NATIVEMETHOD>
      <NATIVEMETHOD>OpeningBalance</NATIVEMETHOD>
      <NATIVEMETHOD>ClosingBalance</NATIVEMETHOD>
    </COLLECTION>
  </TDLMESSAGE>
</TDL>
```

### TDL Element Attributes

All TDL definition elements support:
- `NAME` — element name
- `ISMODIFY` — Yes/No (modify existing definition)
- `ISFIXED` — Yes/No
- `ISINITIALIZE` — Yes/No (initialize collection)
- `ISOPTION` — Yes/No
- `ISINTERNAL` — Yes/No

## Collection Definition Syntax

```
[Collection: <Name>]
Type      : <Object Type>        ; e.g., Ledger, Voucher, StockItem
Child Of  : #<Variable Name>     ; for hierarchical reports
Filter    : <Filter Expression>  ; subset the collection
```

### NATIVEMETHOD

Specifies which object fields to include in collection export:
```xml
<NATIVEMETHOD>Name</NATIVEMETHOD>
<NATIVEMETHOD>ClosingBalance</NATIVEMETHOD>
<NATIVEMETHOD>Parent</NATIVEMETHOD>
```

## Report Types in TDL

| Type | Structure | Examples |
|------|-----------|----------|
| **Tabular** | Fixed columns | Day Book, Stock Summary, Trial Balance |
| **Hierarchical** | Drill-down via `Child Of` | Group summaries with explode |
| **Column-Based** | Multiple periods | Multi-column Trial Balance |
| **Columnar** | Voucher-based | Sales Register, Purchase Register |

### Report Definition Syntax

```
[Report: <Name>]
Form    : <Form Name>
Variable: <Variable Name>
Repeat  : <Variable(s)>
```

### Line Explosion (Drill-Down)

```
Explode : <Part Name> : <Logical Condition>
```
Use `$$KeyExplode` for Shift+Enter drill-down behavior.

## Collection-Level Attributes for Integration

| Attribute | Purpose |
|-----------|---------|
| `Remote URL` | HTTP endpoint for data source |
| `Remote Request` | Request report definition |
| `JSON Object Path` / `XML Object Path` | Navigate into response structure |
| `JSON Object` / `XML Object` | Map response to Tally object |
| `Input JSON` / `Input XML` | Input data format |
| `Input Parameter` | Parameters for request |
| `Break On` | Pagination / chunking |
| `Data Source` | Specify data source type (HTTPJSON, FileJSON, etc.) |

## TDL Integration Functions

| Function | Purpose |
|----------|---------|
| `$$HTTPInfo` | HTTP status and header information |
| `$$ImportInfo` | Import statistics (created, altered, etc.) |
| `$$LastImportError` | Error message from last import |
| `$$ImportType` | Type of import operation |
| `$$ImportAction` | Action being performed (Create/Alter/Delete) |
| `$$GetMethodNameValue` | Extract field values from JSON/XML |

## Loading TDL Files

- `.tcp` or `.tdl` files can be loaded at Tally startup
- Place in Tally installation directory or configure via F1 > TDL & Add-On
- Persistent customizations that survive restarts

## TDL for JSON Export

```
[Form/Part/Line/Field: <Definition>]
JSON Tag : <String Expression>      ; defines JSON tag name

[Report: <Report>]
Plain JSON: <Logical Expression>    ; controls formatting
```

`XML Tag` and `JSON Tag` are aliases — same attribute, two names.

## TDL Special Keywords for JSON

- `__tlyEmptyIf` — skip entire object when expression is true
- `__tlyEmptyIf_<JSON Tag>` — skip specific tag when condition met

## Printing from TDL

Actions: `Print Report`, `Print Collection`
Scope: `Selected Lines`
Page breaks: Form/Part level (vertical), Line level (horizontal)
