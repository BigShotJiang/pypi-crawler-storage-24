---
title: "JSON / JSONEx API Reference"
tags: [json, jsonex, headers, http, tallyprime-7, static-variables, export, import, migration]
sources:
  - url: https://help.tallysolutions.com/tally-prime-integration-using-json-1/
    description: "PRIMARY 22-min JSON integration reference — headers, body, all operations"
    tier: official
  - url: https://help.tallysolutions.com/release-notes-tally-prime-developer-7/
    description: "JSONEx format introduction in TallyPrime 7.0"
    tier: official
  - url: https://help.tallysolutions.com/json-based-export-import/
    description: "TDL-based JSON export — JSON Tag, Plain JSON attributes"
    tier: official
  - url: https://help.tallysolutions.com/general-attributes-integration/
    description: "JSON Tag as Desc Name attribute, JSONEx behavior differences"
    tier: official
  - url: https://help.tallysolutions.com/data-sources-xml-and-json-string/
    description: "Using JSON strings as TDL collection data sources"
    tier: official
relevance: "Read this when using JSON interface (requires TallyPrime 7.0+)"
---

# JSON / JSONEx API Reference

## JSON vs JSONEx

| Format | Since | SVExportFormat | Notes |
|--------|-------|----------------|-------|
| **JSON** (legacy) | Tally.ERP 9 v6.2 | `UTF8JSON`, `ANSIJSON`, `UTF16JSON` | Older, requires TDL customization |
| **JSONEx** (new) | TallyPrime 7.0 (Dec 2025) | `JSONEx` (via `$$SysName:Jsonex`) | Enhanced, richer data, recommended |

## HTTP Headers (Mandatory)

Unlike XML where metadata is in the envelope, JSON puts it in HTTP headers:

| Header | Values | Required | Notes |
|--------|--------|----------|-------|
| `content-type` | `application/json` or `application/json;charset=utf-8` | Yes | Charset must match payload |
| `version` | `1` | Yes | Numeric |
| `tallyrequest` | `Export` / `Import` / `Execute` | Yes | Operation type |
| `type` | `Data` / `Collection` / `Object` / `Function` | Yes | Entity category |
| `subtype` | e.g. `Ledger`, `StockItem` | Only for Object | Object type |
| `id` | Report/collection/object name | Yes | e.g. `Trial Balance`, `List of Ledgers` |
| `id-encoded` | Base64 | Only for non-ASCII names | Multilingual support |
| `detailed-response` | `Yes` / `No` | No | Extra counts in import response |

## Request Body Structure

```json
{
  "static_variables": [
    { "type": "", "key": "svExportFormat", "name": "", "value": "JSONEx" }
  ],
  "repeat_variables": [
    { "type": "", "key": "", "name": "", "value": ["val1", "val2"] }
  ],
  "fetchlist": ["fieldA", "fieldB"],
  "func_param_list": [
    { "type": "", "value": "" }
  ],
  "tdlmessage": [
    { "descriptions": [{ "metadata": {}, "attributes": [] }] },
    { "definitions": [] }
  ],
  "tallymessage": {}
}
```

## Critical Static Variables

| Variable | Values | When Required | Notes |
|----------|--------|---------------|-------|
| `svExportFormat` | `JSONEx` or `XML` | All exports | **Always set to JSONEx** |
| `svMstImportFormat` | `JSONEx` or `XML` | Master imports | **Absence causes import failure** |
| `svVchImportFormat` | `JSONEx` or `XML` | Voucher imports | **Absence causes import failure** |
| `svCurrentCompany` | Exact company name | Always | Without it, wrong company silently used |
| `svFromDate` | `YYYYMMDD` | Period reports | Start date |
| `svToDate` | `YYYYMMDD` | Period reports | End date |
| `SVExportInPlainFormat` | `Yes` | Plain JSON reports | For flat JSON export |

## Response Structure

```json
{
  "status": "1",
  "cmp_info": {},
  "parms": [],
  "tallymessage": [],
  "data": {},
  "result": {}
}
```

- `status`: `1` = success, `0` = failure
- `tallymessage`: Full object exports
- `data`: Collection/data export results
- `result`: Function execution results

## Export Examples

### Export Trial Balance
```
Headers: content-type: application/json, version: 1,
         tallyrequest: Export, type: Data, id: Trial Balance
Body:
{
  "static_variables": [
    {"key": "svExportFormat", "value": "JSONEx"},
    {"key": "svCurrentCompany", "value": "MyCompany"},
    {"key": "svFromDate", "value": "20250401"},
    {"key": "svToDate", "value": "20260331"}
  ]
}
```

### Export a Collection (all Ledgers)
```
Headers: ..., type: Collection, id: List of Ledgers
Body: { "static_variables": [{"key": "svExportFormat", "value": "JSONEx"}] }
```

### Export a Single Object (specific Ledger)
```
Headers: ..., type: Object, subtype: Ledger, id: Customer ABC
Body: {
  "static_variables": [{"key": "svExportFormat", "value": "JSONEx"}],
  "fetchlist": ["ClosingBalance", "OpeningBalance", "Parent"]
}
```

## Import Examples

### Create a Ledger
```
Headers: ..., tallyrequest: Import, type: Data, id: All Masters
Body: {
  "static_variables": [
    {"key": "svMstImportFormat", "value": "JSONEx"},
    {"key": "svCurrentCompany", "value": "MyCompany"}
  ],
  "tallymessage": {
    "ledger": [{ "@action": "Create", "name": "New Customer", "parent": "Sundry Debtors" }]
  }
}
```

### Create a Voucher
```
Headers: ..., tallyrequest: Import, type: Data, id: Vouchers
Body: {
  "static_variables": [
    {"key": "svVchImportFormat", "value": "JSONEx"},
    {"key": "svCurrentCompany", "value": "MyCompany"}
  ],
  "tallymessage": {
    "voucher": [{ "@action": "Create", "@vchtype": "Sales", "date": "20260315", ... }]
  }
}
```

## TDL-Based JSON Export (Legacy Approach)

For custom reports, TDL attributes control JSON structure:

| Attribute | Scope | Purpose |
|-----------|-------|---------|
| `JSON Tag` | Form, Part, Line, Field | Defines tag name in JSON output |
| `Plain JSON` | Report | Controls formatting (indents/newlines) |
| `JSON Tag as Desc Name` | Part, Line | Use definition name as tag (default: Yes) |

**SVExportFormat sysnames for legacy JSON:** `UTF8JSON`, `ANSIJSON`, `UTF16JSON`

### JSONEx Behavior Differences
- Form-level `JSON Tag` is **ignored** in JSONEx
- Part/Line tags controlled by `JSON Tag as Desc Name`
- `XML Tag` and `JSON Tag` are aliases — existing TDL using `XML Tag` works for JSON too

## JSON-to-TallyPrime Type Mapping

| JSON Type | Tally Types |
|-----------|-------------|
| String | String, Long, Amount, Date, DateTime |
| Number | Number, Quantity, Rate |
| Boolean | Logical |
| Object | Tally Object |
| Array | Collection |

## JSON Strings as TDL Data Sources

```
[Collection: JSONGather1]
Data Source: JSON String: '{"ResponseCode":200, ...}'
JSON Object Path: Response: 1
```

Input can come from: direct string, system formula (`@@`), or system variable (`##`).

## Migration Path: XML → JSON

1. Switch `svMstImportFormat`/`svVchImportFormat` from `XML` to `JSONEx`
2. Switch `svExportFormat` from `XML` to `JSONEx`
3. HTTP headers replace XML envelope metadata
4. `tallymessage` body structure is conceptually the same
5. TDL projects can be converted via "Convert to JSON TDL" option in TallyPrime 7.0+

## Key Gotchas

- **Requires TallyPrime 7.0+** — older versions must use XML
- JSON format cannot have duplicate tags at same hierarchy level (unlike XML)
- Missing `svMstImportFormat`/`svVchImportFormat` causes **silent import failure**
- Charset mismatch between header and payload encoding causes failures
- Empty fields excluded by default in reports — needs `Export Empty Fields` TDL attribute
- `fetchlist` only works when `type` is `Object`
- Currency symbols: TallyPrime 7.0 uses Unicode entities (AED=`\u20c3`, SAR=`\u20c1`)
