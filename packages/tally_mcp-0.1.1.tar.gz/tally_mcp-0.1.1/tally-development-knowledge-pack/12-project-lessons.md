---
title: "Project-Specific Lessons (Battle-Tested)"
tags: [lessons, tested, crashes, objview, repeat-variables, silent-rejection, idempotent, inventory, heartbeat]
sources:
  - url: file://docs/lessons/tally-xml-format.md
    description: "Voucher XML structure, OBJVIEW crash, amount convention, master XML"
    tier: project
  - url: file://docs/lessons/tally-crashes.md
    description: "Known crash scenarios, defensive patterns, log files"
    tier: project
  - url: file://docs/lessons/read-api-patterns.md
    description: "Working export patterns, report sizes, multi-period approaches"
    tier: project
  - url: file://docs/lessons/tally-debugging.md
    description: "Silent rejection diagnosis, error message improvements"
    tier: project
relevance: "These are findings from building THIS project — tested against our Tally instance. Always check these before the broader knowledge pack."
---

# Project-Specific Lessons

> These lessons were discovered during development and tested against our Tally instance.
> They override any conflicting information in the broader knowledge pack.
> For full details, read the source files in `docs/lessons/`.

## Critical Findings

### JSONEx NOT Supported on Our Instance
Tested: JSONEx returns "Unknown Request" on our Tally. Our instance is pre-7.0.
All code must use XML. The `json_builder.py` and `json_parser.py` exist for future use.
→ See `docs/lessons/tally-xml-format.md`

### OBJVIEW Crashes Tally
The `OBJVIEW` XML attribute on VOUCHER tags causes `c0000005` memory access violation.
Our `build_voucher_xml` never emits it. Tally defaults to Accounting Voucher View.
→ See `docs/lessons/tally-crashes.md`

### PERSISTEDVIEW Is Safe But Incomplete
`<PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>` as child element does NOT crash,
but invoice mode returns `EXCEPTIONS=1` — needs more required fields (still under investigation).

### Inventory Entries Currently Unsupported
`ALLINVENTORYENTRIES.LIST` requires Invoice Voucher View. Since that view crashes Tally
(via OBJVIEW) or returns exceptions (via PERSISTEDVIEW), inventory tracking is not yet working.
Accounting entries (Dr purchase / Cr vendor) work fine without inventory.

### REPEAT_VARIABLES Returns Cumulative YTD
Tested 2026-03-18: `repeat_variables` for multi-period P&L returns **cumulative year-to-date**
amounts, NOT individual period amounts. Use separate requests per month instead.
→ See `docs/lessons/read-api-patterns.md`

## Tested Export Patterns

### Collections That Work

| Collection Name | Element Tag | Returns |
|----------------|-------------|---------|
| `List of Companies` | `COMPANY` | All open companies |
| `List of Ledgers` | `LEDGER` | All ledgers |
| `List of Groups` | `GROUP` | All account groups |
| `List of Stock Items` | `STOCKITEM` | All stock items |
| `List of Voucher Types` | `VOUCHERTYPE` | All voucher types |

### Reports That Work

| Report Name | Notes |
|-------------|-------|
| `Trial Balance` | Use `EXPLODEFLAG=Yes` for ledger detail |
| `Profit and Loss A/c` | Note: XML name differs from JSON (`Profit and Loss`) |
| `Balance Sheet` | ~1 KB response |
| `Day Book` | ~60 KB for full year — filter by date/type |
| `Sales Register` | ~1.6 KB |
| `Bills Payable` | ~5.3 KB |
| `Bills Receivable` | ~65 KB — filter by party/date |

### What Crashes or Fails

| Pattern | Problem | Alternative |
|---------|---------|-------------|
| `NATIVEMETHOD>*` on large sets | Connection dropped | Use built-in reports |
| `<TYPE>Data</TYPE><ID>Company</ID>` | Connection dropped | Use `list_companies()` |
| OBJVIEW attribute | Tally crash (c0000005) | Don't use it |

## Report Format Control

### Built-in Reports Have Limited Format Options
Tested 2026-03-19: Built-in report exports (e.g., `Sales Register`, `Purchase Register`) return
a fixed format. The GUI's F5/F12/Alt+F1 toggles set internal `DSP*` variables, but these are
largely undocumented by Tally. Known working variables: `EXPLODEFLAG`, `DSPHasColumnTotal`,
`DSPShowOpening`.

### Custom Collections Are the Way to Get Different Formats
For full control over which fields appear in a report export, use `<TYPE>COLLECTION</TYPE>` with
inline TDL and `<NATIVEMETHOD>` tags instead of built-in report names. This lets you specify
exactly which voucher/ledger fields to return.
→ See `04-report-export-patterns.md` for the custom sales voucher collection example.

### Large Tally Responses May Contain Non-UTF-8 Bytes
Tested 2026-03-19: Custom collection queries returning large datasets caused `'utf-8' codec
can't decode byte 0xf7` errors. The `execute_custom_query` tool was doing `response.decode("utf-8")`
without error handling. Fixed with `errors="replace"`. The parsed XML paths (`parse_report_raw`,
`parse_collection`) already handle this via `_clean_xml()` + lxml's byte-level parsing.

### DSP Variables Can Be Discovered via Developer Mode
Launch Tally with `/DevMode`, use Calculator pane `START` → navigate report → `DUMP` to capture
all evaluated expressions (including DSP variables) to `tdldebug.log`.
→ See `04-report-export-patterns.md` "Discovering DSP Variables" section.

## Defensive Patterns in Use

### Idempotent Master Creation
Try `ACTION="Create"` first. If `created=0` and `altered=0`, retry with `ACTION="Alter"`.
Currencies may return `created=0 altered=0` even on success if they already exist.

### Heartbeat Before Batch Ops
```python
hb = await client.heartbeat(company="Company Name")
if not hb["ok"]:
    print(f"Tally not ready: {hb['message']}")
```

### Silent Rejection Detection
Check `result["exceptions"]` — Tally returns `EXCEPTIONS=1` with no error message.
Our `xml_parser.py` surfaces these as errors when `created+altered=0`.

## Tally Log Files

| File | Location | Purpose |
|------|----------|---------|
| `tallyerr.log` | TallyPrime dir | Runtime errors, crashes |
| `tally.imp` | TallyPrime dir | Last XML import request |
| `tally.log` | TallyPrime dir | General operational log |
| `tdlfunc.log` | TallyPrime dir | TDL function trace |
| `tdldebug.log` | TallyPrime dir | Expression Diagnostics dump (Developer Mode) |

Enable debug: add `Debug = Yes` to `tally.ini`, restart Tally.
Get better errors: add `<IMPORTRESULTONERROR>Yes</IMPORTRESULTONERROR>` to STATICVARIABLES.
