---
title: "Existing Tools & Libraries"
tags: [mcp-server, python, nodejs, csharp, tally-py, open-source, commercial, cdata, postman]
sources:
  - url: https://github.com/dhananjay1405/tally-mcp-server
    description: "Purpose-built Tally MCP server — Node.js, XML-based, MIT license"
    tier: open-source
  - url: https://github.com/dhananjay1405/tally-database-loader
    description: "Tally→DB loader — extraction patterns, incremental sync"
    tier: open-source
  - url: https://github.com/aadil-sengupta/Tally.Py
    description: "Python library for Tally XML API — PyPI: tally-integration"
    tier: open-source
  - url: https://github.com/Accounting-Companion/TallyConnector
    description: "C# library with source-generated TDL reports"
    tier: open-source
  - url: https://github.com/CDataSoftware/tally-mcp-server-by-cdata
    description: "JDBC-based read-only MCP server"
    tier: open-source
  - url: https://documenter.getpostman.com/view/13855108/TzeRpAMt
    description: "Postman collection with ready-to-use Tally XML requests"
    tier: community
  - url: https://www.cdata.com/drivers/tally/
    description: "CData commercial drivers — ODBC, JDBC, Python, MCP"
    tier: commercial
relevance: "Read this for reference implementations, design patterns, and available tools"
---

# Existing Tools & Libraries

## Open Source MCP Servers

### dhananjay1405/tally-mcp-server (Most Relevant)

**Stack:** Node.js / TypeScript | **License:** MIT | **Stars:** ~19

**Tools exposed:**

| Tool | Purpose |
|------|---------|
| `list-master` | Lists ledgers, stock items, groups for validation/autocomplete |
| `chart-of-accounts` | Group hierarchy for BS/P&L/TB construction |
| `ledger-account` | Ledger-level account statement for period |
| `stock-item-account` | Stock item voucher statement for period |
| `receivables-payables` | Bill-wise outstanding report |
| `trial-balance` | Trial Balance for period |
| `balance-sheet` | Balance Sheet |
| `profit-and-loss` | P&L statement |

**Key design decisions:**
- XML HTTP POST to Tally on port 9000
- Supports local mode (Claude Desktop + local Tally) and remote/web mode
- LLM uses `list-master` for fuzzy name matching before querying
- Handles company selection (defaults to active)

**Links:**
- GitHub: https://github.com/dhananjay1405/tally-mcp-server
- Download: https://excelkida.com/resource/tally-mcp-server-v6.zip
- MCP Market: https://mcpmarket.com/server/tally-prime
- ICAI listing: https://ai.icai.org/usecases_details.php?id=200

### CDataSoftware/tally-mcp-server-by-cdata

**Stack:** Java + JDBC | **License:** MIT

**Approach:** JDBC driver abstracts Tally XML into SQL tables. Three tools: `get_tables`, `get_columns`, `run_query`.

**Pros:** Clean SQL interface for simple queries.
**Cons:** Read-only (free version). Requires Java + CData JDBC driver. Less control over composite reports.

## Python Libraries

### aadil-sengupta/Tally.Py

**PyPI:** `tally-integration` | **License:** Open source

**Capabilities:**
- `TallyClient` class for all common operations
- Data retrieval: companies, ledgers, stock items, vouchers, groups, reports
- Master management: create/manage ledgers, stock items, companies
- Transaction processing: create vouchers, update, cancel
- Reports: sales reports, payslips, bill receivables, stock aging
- Experimental TDL files for AI integration (Claude, AI Studio)
- Bundled docs: TDL Reference Manual, Tally Functions Guide

**Links:**
- GitHub: https://github.com/aadil-sengupta/Tally.Py
- PyPI: https://pypi.org/project/tally-integration/

## Database Loader

### dhananjay1405/tally-database-loader

**Stack:** Node.js | **Targets:** SQL Server, MySQL, PostgreSQL, BigQuery, CSV, JSON, Azure Data Lake

**Key learnings:**
- Default batch size of 5,000 vouchers per extraction is stable
- Supports full sync and incremental sync (based on AlterID tracking)
- Handles multi-company scenarios
- Includes TDL report specifications for all standard Tally entities

## C# Library

### Accounting-Companion/TallyConnector

- Abstracts Tally XML API into C# objects
- Auto-generates TDL reports using source generators
- Postman Collection: https://documenter.getpostman.com/view/13855108/TzeRpAMt

## Other Tools

| Tool | Type | Notes |
|------|------|-------|
| **CData Python Connector** | Commercial | DB-API module, works with Pandas/SQLAlchemy. https://www.cdata.com/drivers/tally/python/ |
| **CData ODBC Driver** | Commercial | Cross-platform ODBC. https://www.cdata.com/drivers/tally/odbc/ |
| **api2books.com** | Commercial SaaS | GET/POST API platform, plugin-based (.tcp). https://api2books.com/ |
| **RootFi** | Commercial SaaS | Unified accounting API with Tally connector. https://www.rootfi.dev/integrations/tally-prime |
| **tendril-connector-tally** | Python (AGPL) | Older Tally XML connector. https://pypi.org/project/tendril-connector-tally/ |
| **hashfx/Tally-Automation** | Python | Simple automation scripts. https://github.com/hashfx/Tally-Automation |
| **iodize6399/TallPy** | Python | Tally ERP9 connector with Discord bot. https://github.com/iodize6399/TallPy |
| **ramajayam-CA/Tally-Connector** | TDL + Excel | ODBC-based, good SQL examples. https://github.com/ramajayam-CA/Tally-Connector |

## Postman Collection

Ready-to-use Tally XML API requests:
https://documenter.getpostman.com/view/13855108/TzeRpAMt

## Downloadable XML Report Templates

XML templates for every report type (older ERP 9 but patterns still apply):
https://www.rtslink.com/articles/tally-xml-tags-export/
