# Tally Development Knowledge Pack

> Distilled reference for building integrations with TallyPrime.
> Each file has YAML frontmatter with `tags` and `sources` for discoverability.
> Sources include URLs for deeper reading, rated by tier: official > open-source > community > commercial.

## Files

| # | File | Tags | When to read |
|---|------|------|-------------|
| 01 | [integration-overview.md](01-integration-overview.md) | `architecture, setup, prerequisites, push-pull, http-server, comparison` | Starting out, choosing integration method |
| 02 | [xml-api-reference.md](02-xml-api-reference.md) | `xml, envelope, header, body, tags, static-variables, request, response` | Building or debugging XML requests |
| 03 | [json-api-reference.md](03-json-api-reference.md) | `json, jsonex, headers, http, tallyprime-7, static-variables` | Using JSON interface (TallyPrime 7.0+) |
| 04 | [report-export-patterns.md](04-report-export-patterns.md) | `export, reports, trial-balance, profit-loss, balance-sheet, receivables, collections, functions` | Reading financial data from Tally |
| 05 | [master-import-export.md](05-master-import-export.md) | `masters, ledger, group, stock-item, unit, godown, create, alter, delete, duplicates` | Creating/modifying master data |
| 06 | [voucher-import-export.md](06-voucher-import-export.md) | `vouchers, sales, purchase, payment, receipt, journal, invoice, create, alter, cancel, delete, amount-convention` | Creating/modifying transactions |
| 07 | [tdl-essentials.md](07-tdl-essentials.md) | `tdl, collections, objects, methods, reports, functions, custom-reports, inline-tdl` | Custom collections, embedded TDL in requests |
| 08 | [odbc-integration.md](08-odbc-integration.md) | `odbc, sql, queries, tables, server, client, pyodbc` | SQL-based access to Tally data |
| 09 | [existing-tools-and-libraries.md](09-existing-tools-and-libraries.md) | `mcp-server, python, nodejs, csharp, tally-py, open-source, commercial` | Reference implementations, libraries |
| 10 | [reliability-and-gotchas.md](10-reliability-and-gotchas.md) | `errors, crashes, batch-size, encoding, silent-failures, debugging, objview, line-breaks` | Troubleshooting, production hardening |
| 11 | [mcp-server-design.md](11-mcp-server-design.md) | `mcp, tool-design, architecture, natural-language, safety, phases` | Designing MCP server tools and workflows |
| 12 | [project-lessons.md](12-project-lessons.md) | `lessons, tested, crashes, objview, repeat-variables, silent-rejection, idempotent` | **Check first** — battle-tested findings from this project |
