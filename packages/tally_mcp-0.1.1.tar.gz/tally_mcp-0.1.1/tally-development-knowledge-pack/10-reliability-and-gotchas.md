---
title: "Reliability, Gotchas & Debugging"
tags: [errors, crashes, batch-size, encoding, silent-failures, debugging, objview, line-breaks, special-characters, exceptions, tally-imp]
sources:
  - url: https://help.tallysolutions.com/integration-with-tallyprime/
    description: "Official reliability notes — batch sizes, stale data, multi-company"
    tier: official
  - url: https://help.tallysolutions.com/import-data-from-xml-or-json/
    description: "Import errors, exceptions report, feature mismatch"
    tier: official
  - url: http://tdlintegration.blogspot.com/2012/11/case-study-tally-xml-integration.html
    description: "Community-discovered gotchas — line breaks, batch limits, encoding"
    tier: community
  - url: https://help.tallysolutions.com/scenario-2/
    description: "Special character escaping in voucher creation"
    tier: official
relevance: "Read this when troubleshooting errors, crashes, or silent failures"
project_lessons: ["docs/lessons/tally-crashes.md", "docs/lessons/tally-debugging.md"]
---

# Reliability, Gotchas & Debugging

## Critical: OBJVIEW Crash

**NEVER use `<OBJVIEW>` attribute on VOUCHER tags.** Causes Tally memory access violation crash (error code c0000005). Tally defaults to Accounting Voucher View when no view is specified.

## Silent Rejections

Tally silently rejects bad vouchers with `EXCEPTIONS=1` and no error message. Always check the `exceptions` field in import results. A response showing `CREATED=0, ERRORS=0` with no error details means the data was silently dropped.

## Batch Size Limits

| Operation | Safe Limit | Danger Zone |
|-----------|-----------|-------------|
| Voucher import | 50–100 per request | 10,000+ causes "Unknown Request" |
| Database loader extraction | 5,000 per batch | Stable |
| General rule | Keep batches small | Monitor response times |

## Line Break Corruption

Embedded line breaks (`\r`, `\n`, `chr(10)`, `chr(13)`) in XML payloads cause **"Unknown Request, cannot be processed"** errors. Sanitize all string inputs before XML construction.

## Special Character Escaping

XML-unsafe characters in data values (especially ledger names) must be escaped:

| Character | Escape |
|-----------|--------|
| `&` | `&amp;` |
| `<` | `&lt;` |
| `>` | `&gt;` |
| `"` | `&quot;` |
| `'` | `&apos;` |

The `&` character in ledger names is the most common culprit.

## Company Name Must Be Exact

`SVCURRENTCOMPANY` must match the exact company name in Tally. Without it, data may silently go to the wrong company (whichever is active). Example: use `"Procedure Technologies Private Limited"` not `"Procedure Tech"`.

## Date Format

Always use `YYYYMMDD` format (e.g., `20250401`). Other formats cause silent failures.

**Exception:** Voucher alter/delete attributes may use `dd-mmm-yyyy` format (e.g., `15-Apr-2025`).

## Encoding Issues

- Dev environments may get clean XML while production returns garbled responses
- Verify encoding consistency between request Content-Type and actual payload
- For JSON: charset mismatch between header and payload causes failures
- Currency symbols (AED/SAR) use Unicode entities in TallyPrime 7.0+

## Stale Data

When Tally runs for several days (especially on Windows Server), it can occasionally return stale data. Restart Tally if this happens.

## Multi-Company Edge Cases

When multiple companies are loaded, rare edge cases can cause Tally to fetch from the wrong company. Always specify `SVCURRENTCOMPANY`.

## Heartbeat Check

Always use `heartbeat(company)` before batch operations to verify:
1. Tally is running and accepting connections on port 9000
2. The specific company is loaded and open

## Import Logging

- Check `Tally.imp` log file in Tally installation folder for detailed import logs
- Runtime logs stored in installation `/logs/` directory
- An **Exceptions Report** is generated for missing masters or incompatible configurations

## Feature Mismatch on Import

"The company features that were enabled while exporting the data should be enabled in the company in which the data is imported." Feature mismatch causes silent failures.

## Large Response Handling

- Large reports can take 10–30 seconds — set reasonable timeouts
- Tally can return partial/malformed XML on very large datasets
- Custom TDL reports may return data without standard HEADER/BODY envelope wrapping

## Ledger Name Validation

Ledger names in vouchers must **exactly** match existing masters in Tally. Always validate names against master list before creating vouchers.

## GST / Statutory Configuration

GST, HSN/SAC codes, and tax classifications must be pre-configured in Tally before importing vouchers with tax details.

## Missing Import Format Variable

For JSON imports, missing `svMstImportFormat` or `svVchImportFormat` causes **silent import failure** — no error, no data imported.

## Debugging Checklist

1. Check `CREATED`, `ALTERED`, `ERRORS`, `EXCEPTIONS` in response
2. Check `Tally.imp` log file
3. Verify company name matches exactly
4. Verify all referenced ledgers/masters exist
5. Verify date format is `YYYYMMDD`
6. Check for special characters in names
7. Check for embedded line breaks in XML
8. Try with a single item before batching
9. Export the target data first to verify XML structure
10. Use `heartbeat()` to confirm Tally connectivity
