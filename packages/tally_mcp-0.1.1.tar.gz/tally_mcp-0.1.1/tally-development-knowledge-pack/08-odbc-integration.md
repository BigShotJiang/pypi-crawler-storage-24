---
title: "ODBC Integration"
tags: [odbc, sql, queries, tables, server, client, pyodbc, excel, power-bi]
sources:
  - url: https://help.tallysolutions.com/odbc-integrations/
    description: "ODBC setup, collection exposure, SQL queries, stored procedures"
    tier: official
  - url: https://help.tallysolutions.com/using-odbc-interface/
    description: "ODBC client/server detailed guide, DSN setup"
    tier: official
relevance: "Read this when using SQL queries against Tally or connecting BI tools"
---

# ODBC Integration

## Setup

1. Run Tally as **Administrator**
2. `F12: Configure > Advanced Configuration > Enable ODBC Server = Yes`
3. Specify port number
4. Use Tally's built-in ODBC driver from any ODBC client

## TallyPrime as ODBC Server (Exposing Data)

External apps query Tally data using SQL.

### SQL Query Syntax

Uses `$MethodName` for column names and `$$Function` for Tally functions:

```sql
-- List all ledgers with closing balance
SELECT $Name, $ClosingBalance FROM Ledger

-- Debit balances sorted descending
SELECT $Name FROM Ledger WHERE $$IsDr:$ClosingBalance ORDER BY $ClosingBalance DESC

-- List available ODBC tables
SELECT $Name FROM ODBCTables
```

### Exposing Custom Collections as Tables

```
[Collection: MyCustomTable]
Type          : Ledger
Is ODBCTable  : Yes
```

### Exposing Custom Methods

Internal object methods are exposed by default. For external/custom methods, prefix with underscore `_`:

```
_Difference : $ClosingBalance - $OpeningBalance
```

### SQL Stored Procedures

Map TDL collections with parameters:

```
[Collection: ParamQuery]
SQLParms  : ParamName
SQLValues : ParamValue
```

### VB Connection Example

```vb
Dim TallyCn As New ADODB.Connection
Dim rst As New ADODB.Recordset

TallyCn.Open "TallyODBC_9000"
rst.Open "Select $Name From Ledger", TallyCn, adOpenDynamic, adLockOptimistic

Do While Not rst.EOF
    Debug.Print rst.Fields("$Name").Value
    rst.MoveNext
Loop
```

## TallyPrime as ODBC Client (Importing External Data)

Tally queries external databases:

```
[Collection: Led Coll From Access]
ODBC : "Driver={Microsoft Access Driver (*.mdb)};Dbq=C:\Masters.mdb;Uid=;Pwd=;"
SQL  : Select * From LedgerMaster
```

Each SQL result row becomes a Tally object. Columns accessible via `$_1`, `$_2`, etc. (positional).

## Limitations

- Only first-level collections exposed by default
- Custom collections need TDL with `IsODBCTable` attribute
- **Read-only** — no INSERT/UPDATE via ODBC
- External methods of objects need `_` prefix to be exposed
- Composite reports (P&L, Balance Sheet) aren't naturally exposed as SQL tables without significant TDL work
- Requires TDL knowledge to expose custom/complex data structures

## When to Use ODBC vs XML/JSON

| Use Case | Recommended |
|----------|-------------|
| Ad-hoc queries | ODBC |
| Excel / Power BI dashboards | ODBC |
| Composite financial reports | XML/JSON (built-in report names) |
| Voucher creation/modification | XML/JSON only |
| Programmatic integration (Python) | XML/JSON (or pyodbc for reads) |
| Real-time reporting | ODBC |

## Python via pyodbc

```python
import pyodbc
conn = pyodbc.connect("DSN=TallyODBC_9000")
cursor = conn.cursor()
cursor.execute("SELECT $Name, $ClosingBalance FROM Ledger")
for row in cursor:
    print(row)
```
