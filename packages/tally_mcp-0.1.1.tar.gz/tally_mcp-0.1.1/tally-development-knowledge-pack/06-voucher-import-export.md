---
title: "Voucher Import & Export"
tags: [vouchers, sales, purchase, payment, receipt, journal, invoice, create, alter, cancel, delete, amount-convention, bill-allocation, inventory, master-id]
sources:
  - url: https://help.tallysolutions.com/integration-with-tallyprime/
    description: "All voucher types — accounting view, invoice view, with/without inventory"
    tier: official
  - url: https://help.tallysolutions.com/sample-xml/
    description: "Complete voucher XML with tax, inventory, bill allocations"
    tier: official
  - url: https://help.tallysolutions.com/case-study-1/
    description: "Payment voucher, voucher deletion examples"
    tier: official
  - url: https://help.tallysolutions.com/scenario-2/
    description: "Receipt voucher creation and alteration via MASTER ID"
    tier: official
relevance: "Read this when creating, modifying, or cancelling any transaction in Tally"
project_lessons: "docs/lessons/tally-xml-format.md"
---

# Voucher Import & Export

## Amount Convention

| Context | Debit | Credit |
|---------|-------|--------|
| VoucherEntry (Python) | Positive | Negative |
| XML `<AMOUNT>` | Negative | Positive |
| `ISDEEMEDPOSITIVE` | `Yes` (debit) | `No` (credit) |

**Key rule:** `build_voucher_xml` negates amounts before sending. `ISDEEMEDPOSITIVE` is computed from the negated XML amount sign.

## Two Voucher Views

| View | Tag | `ISINVOICE` | Ledger Tag | Use Case |
|------|-----|-------------|------------|----------|
| **Accounting** | `Accounting Voucher View` | `No` | `LEDGERENTRIES.LIST` | Simple debit/credit |
| **Invoice** | `Invoice Voucher View` | `Yes` | `LEDGERENTRIES.LIST` + `ALLINVENTORYENTRIES.LIST` | Sales/Purchase with inventory |

## LEDGERENTRIES.LIST vs ALLLEDGERENTRIES.LIST

- `LEDGERENTRIES.LIST` — Sales/Purchase vouchers (Accounting View)
- `ALLLEDGERENTRIES.LIST` — Payment/Receipt/Journal/Contra vouchers

## Sales Voucher (Accounting View)

```xml
<VOUCHER Action="Create">
  <DATE>20250415</DATE>
  <VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>
  <VOUCHERNUMBER>1</VOUCHERNUMBER>
  <PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>
  <ISINVOICE>No</ISINVOICE>
  <LEDGERENTRIES.LIST>
    <LEDGERNAME>Customer ABC</LEDGERNAME>
    <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
    <ISPARTYLEDGER>Yes</ISPARTYLEDGER>
    <ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE>
    <AMOUNT>-21546.00</AMOUNT>
  </LEDGERENTRIES.LIST>
  <LEDGERENTRIES.LIST>
    <LEDGERNAME>Sales</LEDGERNAME>
    <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
    <AMOUNT>21546.00</AMOUNT>
  </LEDGERENTRIES.LIST>
</VOUCHER>
```

## Sales Invoice (Invoice View with Inventory)

```xml
<VOUCHER Action="Create">
  <DATE>20250415</DATE>
  <VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>
  <PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>
  <ISINVOICE>Yes</ISINVOICE>
  <LEDGERENTRIES.LIST>
    <LEDGERNAME>Customer ABC</LEDGERNAME>
    <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
    <ISPARTYLEDGER>Yes</ISPARTYLEDGER>
    <AMOUNT>-21546.00</AMOUNT>
    <BILLALLOCATIONS.LIST>
      <NAME>1</NAME>
      <BILLTYPE>New Ref</BILLTYPE>
      <AMOUNT>-21546.00</AMOUNT>
    </BILLALLOCATIONS.LIST>
  </LEDGERENTRIES.LIST>
  <LEDGERENTRIES.LIST>
    <LEDGERNAME>VAT</LEDGERNAME>
    <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
    <AMOUNT>2646.00</AMOUNT>
    <BASICRATEOFINVOICETAX.LIST TYPE="Number">
      <BASICRATEOFINVOICETAX>14</BASICRATEOFINVOICETAX>
    </BASICRATEOFINVOICETAX.LIST>
  </LEDGERENTRIES.LIST>
  <ALLINVENTORYENTRIES.LIST>
    <STOCKITEMNAME>Sony Television</STOCKITEMNAME>
    <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
    <RATE>15000.00/nos</RATE>
    <AMOUNT>15000.00</AMOUNT>
    <ACTUALQTY>1 nos</ACTUALQTY>
    <BILLEDQTY>1 nos</BILLEDQTY>
    <BATCHALLOCATIONS.LIST>
      <GODOWNNAME>Main Location</GODOWNNAME>
      <BATCHNAME>Primary Batch</BATCHNAME>
      <DESTINATIONGODOWNNAME>Main Location</DESTINATIONGODOWNNAME>
      <AMOUNT>15000.00</AMOUNT>
      <ACTUALQTY>1 nos</ACTUALQTY>
      <BILLEDQTY>1 nos</BILLEDQTY>
    </BATCHALLOCATIONS.LIST>
    <ACCOUNTINGALLOCATIONS.LIST>
      <LEDGERNAME>Sales</LEDGERNAME>
      <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
      <AMOUNT>15000.00</AMOUNT>
    </ACCOUNTINGALLOCATIONS.LIST>
  </ALLINVENTORYENTRIES.LIST>
</VOUCHER>
```

## Payment Voucher

```xml
<VOUCHER Action="Create">
  <DATE>20250415</DATE>
  <NARRATION>Ch. No. 12345</NARRATION>
  <VOUCHERTYPENAME>Payment</VOUCHERTYPENAME>
  <VOUCHERNUMBER>1</VOUCHERNUMBER>
  <ALLLEDGERENTRIES.LIST>
    <LEDGERNAME>Conveyance</LEDGERNAME>
    <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
    <AMOUNT>-12000.00</AMOUNT>
  </ALLLEDGERENTRIES.LIST>
  <ALLLEDGERENTRIES.LIST>
    <LEDGERNAME>Bank of India</LEDGERNAME>
    <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
    <AMOUNT>12000.00</AMOUNT>
  </ALLLEDGERENTRIES.LIST>
</VOUCHER>
```

## Inventory Allocations (within Accounting View)

When Accounting View vouchers need stock tracking:

```xml
<INVENTORYALLOCATIONS.LIST>
  <STOCKITEMNAME>SAMSUNG DVD PLAYER</STOCKITEMNAME>
  <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
  <AMOUNT>21546.00</AMOUNT>
  <ACTUALQTY>1 nos</ACTUALQTY>
  <BILLEDQTY>1 nos</BILLEDQTY>
  <BATCHALLOCATIONS.LIST>
    <GODOWNNAME>Factory</GODOWNNAME>
    <BATCHNAME>Primary Batch</BATCHNAME>
    <AMOUNT>21546.00</AMOUNT>
    <ACTUALQTY>1 nos</ACTUALQTY>
    <BILLEDQTY>1 nos</BILLEDQTY>
  </BATCHALLOCATIONS.LIST>
</INVENTORYALLOCATIONS.LIST>
```

## Voucher Actions

| Action | Attribute | Notes |
|--------|-----------|-------|
| Create | `Action="Create"` | New voucher |
| Alter | `Action="Alter"` | Modify existing — needs identifier |
| Cancel | `ACTION="Cancel"` | Retains audit trail |
| Delete | `ACTION="Delete"` | Permanent removal |

## Voucher Identification for Alter/Delete/Cancel

### Method 1: TAGNAME + TAGVALUE
```xml
<VOUCHER DATE="01-Apr-2025" TAGNAME="Voucher Number"
         TAGVALUE="1" Action="Alter" VCHTYPE="Sales">
  <NARRATION>Updated narration</NARRATION>
</VOUCHER>
```

### Method 2: MASTER ID (from creation response)
```xml
<VOUCHER ACTION="Alter" VCHTYPE="Receipt"
         TAGNAME="MASTER ID" TAGVALUE="12345">
  <!-- modified fields -->
</VOUCHER>
```

**Best practice:** Capture `LASTVCHID` / MASTER ID from the creation response and store it for future alterations.

### Voucher Deletion
```xml
<VOUCHER DATE="02-Apr-2025" TAGNAME="Voucher Number"
         TAGVALUE="3" VCHTYPE="Sales" ACTION="Delete">
</VOUCHER>
```

### Voucher Cancellation
```xml
<VOUCHER DATE="01-Apr-2025" TAGNAME="VoucherNumber"
         TAGVALUE="2" ACTION="Cancel" VCHTYPE="Sales">
  <NARRATION>Being goods returned</NARRATION>
</VOUCHER>
```

## Critical Voucher Tags Reference

| Tag | Purpose |
|-----|---------|
| `ISDEEMEDPOSITIVE` | `Yes`=Debit, `No`=Credit |
| `ISPARTYLEDGER` | Identifies party-related ledger entries |
| `ISLASTDEEMEDPOSITIVE` | Tracks last deemed positive state |
| `PERSISTEDVIEW` | Controls voucher rendering mode |
| `ISINVOICE` | `Yes` for invoice format, `No` for voucher format |
| `BILLALLOCATIONS.LIST` | Bill-wise detail for party ledger |
| `BATCHALLOCATIONS.LIST` | Required for inventory tracking |
| `ACCOUNTINGALLOCATIONS.LIST` | Links inventory entries to GL accounts |

## Date Format Warning

Different date formats appear across operations:
- **Creation:** `YYYYMMDD` (e.g., `20250415`) — in `<DATE>` tag
- **Alter/Delete attributes:** `dd-mmm-yyyy` (e.g., `15-Apr-2025`) or `dd-Mon-yyyy` — in `DATE` attribute

Always use `YYYYMMDD` for the `<DATE>` element inside `<VOUCHER>`.

## OBJVIEW Warning

**NEVER use `<OBJVIEW>` on VOUCHER tags.** It causes Tally memory access violation crash (c0000005). Tally defaults to Accounting Voucher View when no view is specified.
