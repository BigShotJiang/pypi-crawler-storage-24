---
title: "MCP Server Design Patterns"
tags: [mcp, tool-design, architecture, natural-language, safety, phases, reads, writes, validation]
sources:
  - url: https://github.com/dhananjay1405/tally-mcp-server
    description: "Reference MCP server — tool names and parameter design"
    tier: open-source
  - url: https://help.tallysolutions.com/integration-with-tallyprime/
    description: "Official best practices for reliability and safety"
    tier: official
relevance: "Read this when designing MCP server tools, planning architecture, or mapping natural language to tools"
---

# MCP Server Design Patterns

## Architecture

```
User (Natural Language)
    ↓
LLM (Claude)
    ↓
MCP Server (Python / FastMCP)
    ↓ HTTP POST (XML or JSON)
TallyPrime (HTTP Server on port 9000)
    ↓ XML or JSON Response
MCP Server → Parse → Structured Data → LLM
    ↓
Natural Language Answer to User
```

## Recommended Tools — Phase 1 (Reads)

| MCP Tool | Input | Tally Request | Purpose |
|---|---|---|---|
| `list_companies` | — | Collection: Company | Available companies |
| `list_masters` | master_type, company | Collection: Ledger/StockItem/Group | Autocomplete & validation |
| `get_chart_of_accounts` | company | Collection: Group hierarchy | Structural understanding |
| `get_trial_balance` | company, from_date, to_date | Report: Trial Balance | Foundation for most queries |
| `get_profit_and_loss` | company, from_date, to_date | Report: Profit and Loss | P&L statement |
| `get_balance_sheet` | company, from_date, to_date | Report: Balance Sheet | Balance sheet |
| `get_receivables` | company | Report: Bills Receivable | Outstanding receivables |
| `get_payables` | company | Report: Bills Payable | Outstanding payables |
| `get_ledger_vouchers` | ledger_name, company, from_date, to_date | Report: Ledger Vouchers | Transaction detail |
| `get_stock_summary` | company | Report: Stock Summary | Inventory position |
| `get_day_book` | company, from_date, to_date | Report: Day Book | All transactions |
| `get_sales_register` | company, from_date, to_date | Report: Sales Register | Sales detail |

## Recommended Tools — Phase 2 (Writes)

| MCP Tool | Input | Tally Request | Purpose |
|---|---|---|---|
| `create_ledger` | name, parent_group, company | Import: All Masters | Create new ledger |
| `create_voucher` | voucher_type, date, entries, company | Import: Vouchers | Record transaction |
| `alter_voucher` | voucher_id, changes, company | Import: Vouchers (Alter) | Modify transaction |
| `cancel_voucher` | voucher_id, company | Import: Vouchers (Cancel) | Cancel transaction |

## Natural Language → Tool Mapping

| User Question Pattern | MCP Tool |
|---|---|
| "What is our revenue?" / "How much did we sell?" | `get_profit_and_loss` |
| "What are our receivables?" / "Who owes us money?" | `get_receivables` |
| "What's the cash balance?" | `get_trial_balance` → filter cash/bank groups |
| "Monthly expense trend" | Multiple `get_profit_and_loss` calls per month |
| "How much did we spend on rent?" | `get_ledger_vouchers` for rent ledger |
| "Stock position" / "Inventory value" | `get_stock_summary` |
| "Create a sales invoice" | `create_voucher` (Phase 2) |
| "List all customers" | `list_masters` with type=Ledger, group=Sundry Debtors |

## Safety for Writes

1. **Always require explicit user confirmation** before writing
2. **Validate all ledger/party names** against existing masters before creating vouchers
3. **Implement dry-run / preview mode** — show the XML that would be sent
4. **Log all write operations** for audit trail
5. **Read-only by default** with a write-enable flag
6. **Use heartbeat()** before batch operations to verify Tally is alive
7. **Create masters before vouchers** that reference them

## Reliability Best Practices

1. Always check if Tally is running (ping port 9000) before requests
2. Validate master names using `list-master` tool before queries
3. Handle XML parsing errors gracefully — Tally returns partial XML on large datasets
4. Set reasonable timeouts (10–30 seconds for large reports)
5. Always use `YYYYMMDD` date format
6. Always specify `SVCURRENTCOMPANY`
7. Batch writes to 50–100 items per request
8. Use UTF-8 encoding consistently

## Version Detection

The MCP server should detect Tally version and switch format:
- **TallyPrime 7.0+**: Use JSON/JSONEx (simpler parsing)
- **TallyPrime < 7.0**: Fall back to XML

## Monthly P&L Strategy

For trend analysis:
1. Make N separate P&L requests with per-month date ranges
2. Parse and aggregate
3. Cache results for closed months (data doesn't change)
4. Alternative: Extract monthly Trial Balances and compute P&L from group totals

## Key Design Decision from Reference Server

The `list-master` tool is called first for **fuzzy name matching** — the LLM uses it to resolve user-provided names (e.g., "ICICI" → "ICICI Bank") before passing exact names to other tools.
