---
title: "Integration Overview — How TallyPrime Exposes Data"
tags: [architecture, setup, prerequisites, push-pull, http-server, comparison, odbc, xml, json, tdl]
sources:
  - url: https://help.tallysolutions.com/getting-started-with-tally-integrations/
    description: "Business benefits, supported formats, push vs pull models"
    tier: official
  - url: https://help.tallysolutions.com/integration-methods-and-technologies/
    description: "Four integration methods compared (TDL, JSON, XML, DLL)"
    tier: official
  - url: https://help.tallysolutions.com/pre-requisites-for-integrations/
    description: "HTTP server setup, port config, company loading"
    tier: official
  - url: https://help.tallysolutions.com/integrate-with-tallyprime/
    description: "Landing page linking to all integration sub-sections"
    tier: official
  - url: https://help.tallysolutions.com/integration-initiated-from-tpas/
    description: "External apps pulling/pushing data to Tally"
    tier: official
  - url: https://help.tallysolutions.com/integration-initiated-from-tally/
    description: "Tally as HTTP client — pulling data from external APIs"
    tier: official
relevance: "Read this first when starting integration work or choosing an approach"
---

# Integration Overview

## Four Integration Methods

| Method | Protocol | Format | Best For | Complexity |
|--------|----------|--------|----------|-----------|
| **XML** | HTTP POST | XML | Most integrations, voucher CRUD, reports | Low-Medium |
| **JSON/JSONEx** | HTTP POST | JSON | Modern APIs, TallyPrime 7.0+ only | Low-Medium |
| **ODBC** | SQL | Tabular | Dashboards, Excel, Power BI, ad-hoc queries | Low |
| **TDL** | Native | Custom | UI customization, internal workflows, DLL integration | Medium-High |

## Two Integration Models

### Push (External App → Tally)
- External system POSTs XML/JSON to Tally's HTTP server
- Tally acts as **server** on port 9000
- Used for: importing masters, creating vouchers, exporting reports

### Pull (Tally → External System)
- Tally initiates HTTP GET/POST or ODBC queries
- Tally acts as **client**
- TDL attributes: `RemoteURL`, `RemoteRequest`, `XMLObject`
- Event-driven via `On: Form Accept` triggers
- Used for: syncing with web services, scheduled data pushes

## HTTP Server Setup (Prerequisites)

1. Open TallyPrime
2. `F1 (Help) > Settings > Advanced Configuration`
3. Set `TallyPrime act as`: **Both** or **Server**
4. Set port (default: **9000**)
5. Optionally enable ODBC server
6. At least one company must be loaded

**HTTP request requirements:**
- Method: `POST HTTP/1.1`
- Host: `localhost:9000`
- Content-Type: `text/xml; charset=utf-8` (for XML) or `application/json` (for JSON)

## Format Support by TallyPrime Version

| Release | XML | JSON | JSONEx | Excel |
|---------|-----|------|--------|-------|
| 7.0+ | Yes | Yes | Yes | Yes |
| 4.0–6.x | Yes | Limited (TDL-based) | No | Yes |
| 3.0.1 and earlier | Yes | No | No | No |

## Key DataSource Attributes (for TDL collections)

| Attribute | Purpose |
|-----------|---------|
| `HTTPJSON` | Fetch JSON from HTTP endpoint |
| `HTTPJSONEX` | Fetch JSONEx from HTTP endpoint |
| `FileJSON` | Read JSON from file |
| `HTTPXML` | Fetch XML from HTTP endpoint |
| `FileXML` | Read XML from file |
| `PluginJSON` / `PluginXML` | Via DLL plugins |

## Key TDL Functions for Integration

| Function | Purpose |
|----------|---------|
| `$$HTTPInfo` | HTTP status and header info |
| `$$ImportInfo` | Import statistics |
| `$$LastImportError` | Error logging during import |
| `$$ImportType` / `$$ImportAction` | Import operation metadata |
| `$$GetMethodNameValue` | Extract JSON/XML field values |

## Downloadable Sample Files

Official integration demo samples (XML tags, TDL snippets, request-response examples):
https://help.tallysolutions.com/wp-content/uploads/2025/07/Integration_Demo_Samples.zip
