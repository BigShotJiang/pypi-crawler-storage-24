---
title: "Report Export Patterns"
tags: [export, reports, trial-balance, profit-loss, balance-sheet, receivables, payables, stock, day-book, collections, functions, report-names]
sources:
  - url: https://help.tallysolutions.com/sample-xml/
    description: "Report export XML examples with report name list"
    tier: official
  - url: https://help.tallysolutions.com/case-study-1/
    description: "Export patterns — Trial Balance, collections, functions"
    tier: official
  - url: https://help.tallysolutions.com/financial-statements-for-nce/
    description: "Financial statement XML export for regulatory compliance"
    tier: official
  - url: https://www.rtslink.com/articles/tally-xml-tags-export/
    description: "Downloadable XML templates for every report type"
    tier: community
relevance: "Read this when exporting any financial data or report from Tally"
project_lessons: "docs/lessons/read-api-patterns.md"
---

# Report Export Patterns

## Two Approaches to Report Format Control

There are two ways to control what data comes back from Tally reports:

1. **Static Variables** — pass `DSP*`/`SV*` variables in `<STATICVARIABLES>` to toggle the same
   display options the GUI exposes (F5, F12, Alt+F1, Alt+B). Limited and largely undocumented.
2. **Custom Collections with Inline TDL** — define exactly which fields you want via
   `<TYPE>COLLECTION</TYPE>` with `<NATIVEMETHOD>` tags. Full control, well-documented.

**Recommendation:** Use custom collections for anything beyond the basic built-in report format.
Static variables are useful for simple toggles (e.g., `EXPLODEFLAG`) but the full set of `DSP*`
variables is not officially documented. See "Discovering DSP Variables" below for how to find them.

## Built-in Report Names (for `<ID>` tag)

These names go in the `<ID>` header tag and work with both XML and JSON interfaces:

| Report Name | What It Returns |
|---|---|
| `Trial Balance` | Group-wise trial balance |
| `Profit and Loss` | P&L statement |
| `Balance Sheet` | Balance sheet |
| `Stock Summary` | Stock-in-hand summary |
| `Day Book` | All vouchers for period |
| `List of Accounts` | Chart of accounts |
| `Bills Receivable` | Outstanding receivables |
| `Bills Payable` | Outstanding payables |
| `Cash/Bank Book` | Cash/Bank summary |
| `Sales Register` | Sales voucher register |
| `Purchase Register` | Purchase voucher register |
| `Journal Register` | Journal entries register |
| `Ratio Analysis` | Financial ratios |
| `Group Summary` | Summary for a specific group |
| `Ledger Vouchers` | Vouchers for a specific ledger |
| `Stock Item` | Stock item movement details |

> **Tip:** Full list discoverable via TallyPrime Developer: Navigate > Jump to Definition > Report.

## Additional Report Categories (from rtslink.com templates)

- **Financial:** Balance Sheet, P&L, Trial Balance (multiple variants), Ratio Analysis
- **Inventory:** Stock Summary, Godowns, Monthly inward/outward/closing, Negative Stock
- **Transaction Registers:** Daybook, Sales/Purchase/Journal/Debit Note/Credit Note Registers
- **Ledger Analysis:** Voucher details, bill-wise breakdowns, Group Summaries, Cash/Bank Books
- **Outstandings:** Receivables/Payables with opening balances, bill-wise analysis
- **Cost Analysis:** Category-wise, centre-wise, ledger-wise, group-wise cost centre reports
- **Statistics:** Master/voucher counts, Price Levels

## Basic Export Request (XML)

```xml
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Data</TYPE>
    <ID>Trial Balance</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <EXPLODEFLAG>Yes</EXPLODEFLAG>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
        <SVCURRENTCOMPANY>MyCompany</SVCURRENTCOMPANY>
        <SVFROMDATE>20250401</SVFROMDATE>
        <SVTODATE>20260331</SVTODATE>
      </STATICVARIABLES>
    </DESC>
  </BODY>
</ENVELOPE>
```

`EXPLODEFLAG=Yes` expands groups to show individual ledgers.

## Report-Specific Static Variables

Known variables that affect built-in report output:

| Variable | Effect | Reports |
|----------|--------|---------|
| `EXPLODEFLAG` | Expand groups to individual ledgers | Trial Balance |
| `VOUCHERTYPENAME` | Filter by voucher type | Day Book |
| `LEDGERNAME` | Filter by specific ledger | Ledger Vouchers, Bank Book |
| `GROUPNAME` | Filter by account group | Group Summary |
| `STOCKITEMNAME` | Filter by stock item | Stock Item |
| `DSPHasColumnTotal` | Show/hide column totals (default: Yes) | Various |
| `DSPShowOpening` | Show/hide opening balances | Trial Balance |

> **Note:** The `DSP*` (Display) variables correspond to GUI toggles (F5 columnar, F12
> configuration, Alt+F1 detailed, Alt+B bill-wise) but are **largely undocumented** by Tally.
> See "Discovering DSP Variables with Expression Diagnostics" below for how to find them.

## Custom Collection Export for Sales Vouchers

When the built-in `Sales Register` report doesn't return the fields you need, use a custom
collection to specify exactly which voucher fields to export:

```xml
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>COLLECTION</TYPE>
    <ID>CustomSalesVouchers</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
        <SVCURRENTCOMPANY>MyCompany</SVCURRENTCOMPANY>
        <SVFROMDATE>20250401</SVFROMDATE>
        <SVTODATE>20260331</SVTODATE>
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <COLLECTION NAME="CustomSalesVouchers" ISINITIALIZE="Yes">
            <TYPE>Voucher</TYPE>
            <FILTER>SalesFilter</FILTER>
            <NATIVEMETHOD>VoucherNumber</NATIVEMETHOD>
            <NATIVEMETHOD>Date</NATIVEMETHOD>
            <NATIVEMETHOD>PartyLedgerName</NATIVEMETHOD>
            <NATIVEMETHOD>Amount</NATIVEMETHOD>
            <NATIVEMETHOD>NarrationString</NATIVEMETHOD>
          </COLLECTION>
          <SYSTEM TYPE="Formulae" NAME="SalesFilter">
            $VoucherTypeName = "Sales"
          </SYSTEM>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>
```

This pattern works for any voucher type — change the filter expression for purchases, journals, etc.
Add more `<NATIVEMETHOD>` tags for additional fields (e.g., `GSTRegistrationType`, `BasicBuyerName`).

## Collection-Based Export (with inline TDL)

Export specific fields from a collection:

```xml
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>COLLECTION</TYPE>
    <ID>Remote Ledger Coll</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <COLLECTION NAME="Remote Ledger Coll" ISINITIALIZE="Yes">
            <TYPE>Ledger</TYPE>
            <NATIVEMETHOD>Name</NATIVEMETHOD>
            <NATIVEMETHOD>OpeningBalance</NATIVEMETHOD>
          </COLLECTION>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>
```

### Collection Response

```xml
<COLLECTION>
  <LEDGER NAME="ABC India Pvt. Ltd." RESERVEDNAME="">
    <OPENINGBALANCE TYPE="Amount">5000.00</OPENINGBALANCE>
    <LANGUAGENAME.LIST>
      <NAME.LIST TYPE="String"><NAME>ABC India Pvt. Ltd.</NAME></NAME.LIST>
      <LANGUAGEID TYPE="Number">1033</LANGUAGEID>
    </LANGUAGENAME.LIST>
  </LEDGER>
</COLLECTION>
```

## Single Object Export (with FETCHLIST)

```xml
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>OBJECT</TYPE>
    <SUBTYPE>Ledger</SUBTYPE>
    <ID TYPE="Name">ABC India Pvt. Ltd.</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>
      <FETCHLIST>
        <FETCH>Name</FETCH>
        <FETCH>TNetBalance</FETCH>
        <FETCH>LedgerPhone</FETCH>
      </FETCHLIST>
    </DESC>
  </BODY>
</ENVELOPE>
```

## Function Evaluation

### Without parameters
```xml
<HEADER>
  <VERSION>1</VERSION>
  <TALLYREQUEST>EXPORT</TALLYREQUEST>
  <TYPE>FUNCTION</TYPE>
  <ID>$$NumStockItems</ID>
</HEADER>
<!-- Response: <RESULT TYPE="Number">33</RESULT> -->
```

### With parameters (via TDL formula)
```xml
<HEADER>...<TYPE>FUNCTION</TYPE><ID>$$Round</ID></HEADER>
<BODY>
  <DESC>
    <FUNCPARAMLIST>
      <PARAM>@@FirstParameter</PARAM>
      <PARAM TYPE="Number">0.10</PARAM>
    </FUNCPARAMLIST>
    <TDL>
      <TDLMESSAGE>
        <SYSTEM TYPE="Formulae" NAME="FirstParameter">1242849 / 1000</SYSTEM>
      </TDLMESSAGE>
    </TDL>
  </DESC>
</BODY>
```

## Collection-Based P&L Reconstruction

Instead of using the `Profit and Loss` report, you can build P&L from collections:
- Export all ledgers under `Sales Accounts` group → Revenue
- Export all ledgers under `Purchase Accounts` group → COGS
- Export all ledgers under `Direct Expenses` / `Indirect Expenses` → Expenses
- Group hierarchy follows Tally's chart of accounts

## Monthly P&L Approach

For "What's the revenue trend?" questions:
1. Make N separate P&L requests with per-month date ranges
2. Parse and aggregate results
3. Alternative: Extract Trial Balance for each month, compute P&L from group totals
4. Consider caching — closed months don't change frequently

## Discovering DSP Variables with Expression Diagnostics

The Tally GUI's F5/F12/Alt+F1/Alt+B toggles set internal `DSP*` variables that are largely
undocumented. To discover which variables a specific report uses:

1. **Launch Tally in Developer Mode:** `tally.exe /DevMode`
2. **Open Calculator pane:** Press `Ctrl+N` (or Ctrl+M in some versions)
3. **Start expression capture:** Type `START` and press Enter
4. **Navigate to the report** (e.g., Sales Register) and toggle display options (F5, F12, etc.)
5. **Dump captured expressions:** Type `DUMP` and press Enter
6. **Read the log:** Check `tdldebug.log` in the Tally installation directory

The dump file contains every evaluated expression with its result, including all `DSP*` and `SV*`
variables the report used. Variables that show `FAILED` were evaluated but not set.

### Additional Calculator Pane Commands

| Command | Purpose |
|---------|---------|
| `EVAL <expr>` | Evaluate a TDL expression and see its value |
| `PRINT <var>` | Print a specific variable's current value |
| `START` | Begin capturing all expression evaluations |
| `DUMP` | Write captured data to `tdldebug.log` |
| `STOP` | Stop capturing |

**Example:** To check if a variable exists, type `EVAL ##DSPShowOpening` in the calculator pane
while viewing a Trial Balance report.

## Financial Statements for NCE (Regulatory Export)

Export via `Alt+E > Financial Statements for NCE`:
- Reports: Balance Sheet, P&L, Trial Balance
- Worksheets: Trial Balance, Stock Summary, Trade Payables, Trade Receivables
- Filename: `FinancialStatementsforNCE.xml`
- Options: Current/Previous year, zero-balance inclusion, bill-wise detail
