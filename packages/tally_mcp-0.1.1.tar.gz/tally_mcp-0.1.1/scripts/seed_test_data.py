"""Seed a blank Tally company with comprehensive Indian business test data.

Usage:
    cd pro-tally-mcp
    .venv/Scripts/python scripts/seed_test_data.py

Exercises every MCP endpoint, voucher type, GST scenario, and bulk operation.
Talks directly to TallyClient (not via MCP server).

Assumes:
  - TallyPrime is running on localhost:9000 with a blank company open.
  - The .env file has the correct TALLY_MCP_TALLY_DEFAULT_COMPANY.
  - Company is set to Maharashtra (state code 27) for intra/inter-state GST logic.

Convention: positive amount = debit, negative amount = credit (in VoucherEntry).
"""

import asyncio
import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from tally_mcp.config import settings
from tally_mcp.tally_client import TallyClient
from tally_mcp.voucher_builder import (
    build_group_xml,
    build_ledger_xml,
    build_stock_item_xml,
    build_voucher_xml,
)
from tally_mcp.models import (
    GroupCreate,
    LedgerCreate,
    StockItemCreate,
    VoucherCreate,
    VoucherEntry,
    InventoryEntry,
)

COMPANY = settings.tally_default_company
if not COMPANY:
    print("ERROR: Set TALLY_MCP_TALLY_DEFAULT_COMPANY in .env")
    sys.exit(1)

FY_START = "20250401"
FY_END = "20260331"

# Counters for summary
_counts = {
    "groups": 0,
    "ledgers": 0,
    "units": 0,
    "stock_items": 0,
    "vouchers": {},
    "bulk_ledgers": 0,
    "bulk_vouchers": 0,
    "csv_ledgers": 0,
    "csv_vouchers": 0,
    "cancelled": 0,
    "read_endpoints": 0,
    "errors": [],
}


def ok(label: str, result: dict) -> None:
    created = result.get("created", 0)
    altered = result.get("altered", 0)
    errors = result.get("errors", [])
    status = "OK" if not errors else "WARN"
    print(f"  [{status}] {label}: created={created} altered={altered}", end="")
    if errors:
        print(f"  errors={errors}", end="")
        _counts["errors"].append(f"{label}: {errors}")
    print()


def report(label: str, data) -> None:
    _counts["read_endpoints"] += 1
    if isinstance(data, list):
        print(f"  [{len(data)} items] {label}")
    elif isinstance(data, str):
        lines = data.strip().splitlines()
        print(f"  [{len(lines)} lines] {label}")
    else:
        print(f"  {label}: {data}")


async def check_tally(client: TallyClient, phase: str) -> None:
    """Heartbeat check before each phase. Exits if Tally is unreachable."""
    hb = await client.heartbeat()
    if not hb["ok"]:
        print(f"\n  HEARTBEAT FAILED before {phase}: {hb['message']}")
        sys.exit(1)


async def create_master(client: TallyClient, xml: str, label: str) -> dict:
    """Create a master, falling back to Alter if it already exists."""
    result = await client.import_data(xml, request_type="All Masters")
    if result.get("created", 0) == 0 and result.get("altered", 0) == 0:
        # Try alter if create didn't work (idempotent)
        altered_xml = xml.replace('ACTION="Create"', 'ACTION="Alter"')
        result = await client.import_data(altered_xml, request_type="All Masters")
    ok(label, result)
    return result


async def main():
    client = TallyClient(
        host=settings.tally_host,
        port=settings.tally_port,
        default_company=COMPANY,
        username=settings.tally_username,
        password=settings.tally_password,
    )

    # ══════════════════════════════════════════════════════════════════
    # STEP 0: Health Check
    # ══════════════════════════════════════════════════════════════════
    print("\n=== Step 0: Health Check ===")
    health = await client.health_check()
    print(f"  Tally status: {health['status']}")
    print(f"  Companies: {health['companies']}")
    if COMPANY not in health["companies"]:
        print(f"  ERROR: '{COMPANY}' not found in open companies!")
        sys.exit(1)

    # ══════════════════════════════════════════════════════════════════
    # MASTER DATA SETUP
    # ══════════════════════════════════════════════════════════════════

    # ── Heartbeat before master setup ───────────────────────────────
    await check_tally(client, "Master Data Setup")

    # ── A. Currency Setup ──────────────────────────────────────────
    # NOTE: Currency creation requires raw XML as there's no model for it.
    # Tally may already have these if configured. We'll create them raw.
    print("\n=== A: Currency Setup ===")
    currencies = [
        ("USD", "US Dollar", "2"),
        ("GBP", "British Pound", "2"),
    ]
    for symbol, name, decimals in currencies:
        currency_xml = (
            f'<CURRENCY NAME="{symbol}" ACTION="Create">'
            f"<NAME>{symbol}</NAME>"
            f"<ORIGINALNAME>{name}</ORIGINALNAME>"
            f"<DECIMALPLACES>{decimals}</DECIMALPLACES>"
            f"<ISSUFFIX>No</ISSUFFIX>"
            f"</CURRENCY>"
        )
        result = await client.import_data(currency_xml, request_type="All Masters")
        ok(f"Currency: {symbol} ({name})", result)

    # ── B. Groups ──────────────────────────────────────────────────
    print("\n=== B: Create Groups ===")
    groups = [
        GroupCreate(name="Export Sales", parent="Sales Accounts"),
        GroupCreate(name="Domestic Services", parent="Direct Incomes"),
        GroupCreate(name="Import Expenses", parent="Purchase Accounts"),
        GroupCreate(name="Reverse Charge Expenses", parent="Purchase Accounts"),
    ]
    for g in groups:
        xml = build_group_xml(g)
        await create_master(client, xml, f"Group: {g.name}")
        _counts["groups"] += 1

    # ── C. Customers (Sundry Debtors) ──────────────────────────────
    print("\n=== C: Create Customers ===")
    customers = [
        LedgerCreate(name="Pinnacle Infra Pvt Ltd", parent="Sundry Debtors",
                     gst_number="27AABCP1234A1Z5"),
        LedgerCreate(name="Southern Tech Solutions", parent="Sundry Debtors",
                     gst_number="33AABCS5678B1ZQ"),
        LedgerCreate(name="Greenfield Exports LLP", parent="Sundry Debtors",
                     gst_number="07AABCG9012C1ZP"),
        LedgerCreate(name="Unregistered Retail Customer", parent="Sundry Debtors"),
        LedgerCreate(name="Acme Global Inc", parent="Sundry Debtors"),
        LedgerCreate(name="BritSoft Ltd", parent="Sundry Debtors"),
    ]
    for l in customers:
        xml = build_ledger_xml(l)
        await create_master(client, xml, f"Customer: {l.name}")
        _counts["ledgers"] += 1

    # ── D. Vendors (Sundry Creditors) ──────────────────────────────
    print("\n=== D: Create Vendors ===")
    vendors = [
        LedgerCreate(name="Reliable Hardware Pvt Ltd", parent="Sundry Creditors",
                     gst_number="27AABCR3456D1Z8"),
        LedgerCreate(name="Northern Supplies Co", parent="Sundry Creditors",
                     gst_number="09AABCN7890E1ZF"),
        LedgerCreate(name="Freelance Designer (Unregistered)", parent="Sundry Creditors"),
        LedgerCreate(name="CloudHost USA Inc", parent="Sundry Creditors"),
    ]
    for l in vendors:
        xml = build_ledger_xml(l)
        await create_master(client, xml, f"Vendor: {l.name}")
        _counts["ledgers"] += 1

    # ── E. Income Ledgers ──────────────────────────────────────────
    print("\n=== E: Create Income Ledgers ===")
    income_ledgers = [
        LedgerCreate(name="Software Development Services", parent="Domestic Services"),
        LedgerCreate(name="IT Consulting Services", parent="Domestic Services"),
        LedgerCreate(name="Export Software Services", parent="Export Sales"),
        LedgerCreate(name="Product Sales - Domestic", parent="Sales Accounts"),
    ]
    for l in income_ledgers:
        xml = build_ledger_xml(l)
        await create_master(client, xml, f"Income: {l.name}")
        _counts["ledgers"] += 1

    # ── F. Expense Ledgers ─────────────────────────────────────────
    print("\n=== F: Create Expense Ledgers ===")
    expense_ledgers = [
        LedgerCreate(name="Computer Hardware Purchase", parent="Purchase Accounts"),
        LedgerCreate(name="Office Supplies Purchase", parent="Purchase Accounts"),
        LedgerCreate(name="Design Services (RCM)", parent="Reverse Charge Expenses"),
        LedgerCreate(name="Cloud Hosting (Import)", parent="Import Expenses"),
        LedgerCreate(name="Office Rent", parent="Indirect Expenses"),
        LedgerCreate(name="Salary & Wages", parent="Indirect Expenses"),
        LedgerCreate(name="Travel & Conveyance", parent="Indirect Expenses"),
        LedgerCreate(name="Professional Fees", parent="Indirect Expenses"),
        LedgerCreate(name="Electricity Charges", parent="Indirect Expenses"),
        LedgerCreate(name="Bank Charges", parent="Indirect Expenses"),
    ]
    for l in expense_ledgers:
        xml = build_ledger_xml(l)
        await create_master(client, xml, f"Expense: {l.name}")
        _counts["ledgers"] += 1

    # ── G. Tax Ledgers ─────────────────────────────────────────────
    print("\n=== G: Create Tax Ledgers ===")
    tax_ledgers = [
        LedgerCreate(name="Output CGST @ 9%", parent="Duties & Taxes"),
        LedgerCreate(name="Output SGST @ 9%", parent="Duties & Taxes"),
        LedgerCreate(name="Output IGST @ 18%", parent="Duties & Taxes"),
        LedgerCreate(name="Input CGST @ 9%", parent="Duties & Taxes"),
        LedgerCreate(name="Input SGST @ 9%", parent="Duties & Taxes"),
        LedgerCreate(name="Input IGST @ 18%", parent="Duties & Taxes"),
        LedgerCreate(name="RCM CGST @ 9%", parent="Duties & Taxes"),
        LedgerCreate(name="RCM SGST @ 9%", parent="Duties & Taxes"),
        LedgerCreate(name="RCM IGST @ 18%", parent="Duties & Taxes"),
    ]
    for l in tax_ledgers:
        xml = build_ledger_xml(l)
        await create_master(client, xml, f"Tax: {l.name}")
        _counts["ledgers"] += 1

    # ── H. Bank & Cash Ledgers ─────────────────────────────────────
    print("\n=== H: Create Bank & Cash Ledgers ===")
    bank_ledgers = [
        LedgerCreate(name="HDFC Current A/c", parent="Bank Accounts"),
        LedgerCreate(name="Petty Cash", parent="Cash-in-Hand"),
    ]
    for l in bank_ledgers:
        xml = build_ledger_xml(l)
        await create_master(client, xml, f"Bank: {l.name}")
        _counts["ledgers"] += 1

    # ── I. Other Ledgers ───────────────────────────────────────────
    print("\n=== I: Create Other Ledgers ===")
    other_ledgers = [
        LedgerCreate(name="Owner Capital", parent="Capital Account"),
        LedgerCreate(name="TDS Receivable (Sec 194J)", parent="Current Assets"),
        LedgerCreate(name="Employee Advances", parent="Current Assets"),
        LedgerCreate(name="Security Deposit - Office", parent="Deposits (Asset)"),
        LedgerCreate(name="Laptop & Equipment", parent="Fixed Assets"),
        LedgerCreate(name="Unsecured Loan - Director", parent="Loans (Liability)"),
        LedgerCreate(name="Round Off", parent="Indirect Expenses"),
    ]
    for l in other_ledgers:
        xml = build_ledger_xml(l)
        await create_master(client, xml, f"Other: {l.name}")
        _counts["ledgers"] += 1

    # ── J. Units of Measure ────────────────────────────────────────
    print("\n=== J: Create Units ===")
    units = [
        ("Nos", "Numbers"),
        ("Hrs", "Hours"),
        ("Kg", "Kilograms"),
    ]
    for symbol, formal_name in units:
        unit_xml = (
            f'<UNIT NAME="{symbol}" ACTION="Create">'
            f"<NAME>{symbol}</NAME>"
            f"<ORIGINALNAME>{formal_name}</ORIGINALNAME>"
            f"<ISSIMPLEUNIT>Yes</ISSIMPLEUNIT>"
            f"</UNIT>"
        )
        result = await client.import_data(unit_xml, request_type="All Masters")
        ok(f"Unit: {symbol} ({formal_name})", result)
        _counts["units"] += 1

    # ── K. Stock Items ─────────────────────────────────────────────
    print("\n=== K: Create Stock Items ===")
    stock_items = [
        StockItemCreate(name="Laptop Dell Vostro", unit="Nos", hsn_code="8471", gst_rate=18.0),
        StockItemCreate(name="USB-C Hub", unit="Nos", hsn_code="8473", gst_rate=18.0),
        StockItemCreate(name="Dev Hours - Standard", unit="Hrs", hsn_code="998314", gst_rate=18.0),
    ]
    for item in stock_items:
        xml = build_stock_item_xml(item)
        await create_master(client, xml, f"Stock: {item.name}")
        _counts["stock_items"] += 1

    # ══════════════════════════════════════════════════════════════════
    # VOUCHER TEST CASES
    # ══════════════════════════════════════════════════════════════════

    async def v(label: str, voucher: VoucherCreate) -> dict:
        """Create a voucher and track it."""
        vtype = voucher.voucher_type
        _counts["vouchers"][vtype] = _counts["vouchers"].get(vtype, 0) + 1
        result = await client.import_data(
            build_voucher_xml(voucher), request_type="Vouchers"
        )
        ok(label, result)
        return result

    # ── Phase 1: Opening & Capital (Apr 1-2) ───────────────────────
    await check_tally(client, "Phase 1: Vouchers")
    print("\n=== Phase 1: Opening & Capital ===")

    # #1 Journal: Owner capital introduction
    await v("1. Owner capital introduction", VoucherCreate(
        voucher_type="Journal",
        date="20250401",
        narration="Owner capital introduction",
        entries=[
            VoucherEntry(ledger_name="HDFC Current A/c", amount=1000000),
            VoucherEntry(ledger_name="Owner Capital", amount=-1000000),
        ],
    ))

    # #2 Journal: Director loan received
    await v("2. Director loan received", VoucherCreate(
        voucher_type="Journal",
        date="20250401",
        narration="Director loan received",
        entries=[
            VoucherEntry(ledger_name="HDFC Current A/c", amount=500000),
            VoucherEntry(ledger_name="Unsecured Loan - Director", amount=-500000),
        ],
    ))

    # #3 Contra: Transfer to petty cash
    await v("3. Transfer to petty cash", VoucherCreate(
        voucher_type="Contra",
        date="20250402",
        narration="Transfer to petty cash",
        entries=[
            VoucherEntry(ledger_name="Petty Cash", amount=50000),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-50000),
        ],
    ))

    # ── Phase 2: Purchases (Apr 5-12) ──────────────────────────────
    await check_tally(client, "Phase 2: Purchases")
    print("\n=== Phase 2: Purchases ===")

    # #4 Purchase: Hardware from same-state vendor (MH), CGST+SGST, with inventory
    await v("4. Hardware purchase (intra-state, CGST+SGST)", VoucherCreate(
        voucher_type="Purchase",
        date="20250405",
        party_name="Reliable Hardware Pvt Ltd",
        reference="PO-001",
        narration="Laptop purchase from same-state vendor",
        entries=[
            VoucherEntry(ledger_name="Reliable Hardware Pvt Ltd", amount=-118000),
            VoucherEntry(ledger_name="Computer Hardware Purchase", amount=100000),
            VoucherEntry(ledger_name="Input CGST @ 9%", amount=9000),
            VoucherEntry(ledger_name="Input SGST @ 9%", amount=9000),
        ],
    ))

    # #5 Purchase: Supplies from other-state vendor (UP), IGST, no inventory
    await v("5. Office supplies (inter-state, IGST)", VoucherCreate(
        voucher_type="Purchase",
        date="20250407",
        party_name="Northern Supplies Co",
        reference="PO-002",
        narration="Office supplies from UP vendor",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Northern Supplies Co", amount=-23600),
            VoucherEntry(ledger_name="Office Supplies Purchase", amount=20000),
            VoucherEntry(ledger_name="Input IGST @ 18%", amount=3600),
        ],
    ))

    # #6 Purchase: Design work from unregistered vendor (RCM)
    # RCM: self-assess GST - tax appears both as debit (input credit) and credit (liability)
    await v("6. Design services (RCM, unregistered vendor)", VoucherCreate(
        voucher_type="Purchase",
        date="20250408",
        party_name="Freelance Designer (Unregistered)",
        reference="PO-003",
        narration="Design services from unregistered vendor, RCM applicable",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Freelance Designer (Unregistered)", amount=-15000),
            VoucherEntry(ledger_name="Design Services (RCM)", amount=15000),
            VoucherEntry(ledger_name="RCM CGST @ 9%", amount=1350),
            VoucherEntry(ledger_name="RCM SGST @ 9%", amount=1350),
            VoucherEntry(ledger_name="RCM CGST @ 9%", amount=-1350),
            VoucherEntry(ledger_name="RCM SGST @ 9%", amount=-1350),
        ],
    ))

    # #7 Purchase: Cloud hosting from US vendor (import of services, RCM on IGST)
    # Foreign currency: INR-equivalent for now (no currency field on VoucherEntry)
    # TODO: Add multi-currency support to VoucherEntry model
    await v("7. Cloud hosting import (RCM IGST, USD vendor)", VoucherCreate(
        voucher_type="Purchase",
        date="20250410",
        party_name="CloudHost USA Inc",
        reference="PO-004",
        narration="Cloud hosting from US vendor, 500 USD @ 85, RCM on import of services",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="CloudHost USA Inc", amount=-42500),
            VoucherEntry(ledger_name="Cloud Hosting (Import)", amount=42500),
            VoucherEntry(ledger_name="RCM IGST @ 18%", amount=7650),
            VoucherEntry(ledger_name="RCM IGST @ 18%", amount=-7650),
        ],
    ))

    # #8 Purchase: USB-C Hubs from same-state vendor
    await v("8. USB-C Hubs (intra-state, with inventory)", VoucherCreate(
        voucher_type="Purchase",
        date="20250412",
        party_name="Reliable Hardware Pvt Ltd",
        reference="PO-005",
        narration="USB-C Hub purchase",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Reliable Hardware Pvt Ltd", amount=-5900),
            VoucherEntry(ledger_name="Computer Hardware Purchase", amount=5000),
            VoucherEntry(ledger_name="Input CGST @ 9%", amount=450),
            VoucherEntry(ledger_name="Input SGST @ 9%", amount=450),
        ],
        # TODO: inventory_entries require Invoice Voucher View which crashes Tally
    ))

    # ── Phase 3: Sales (Apr 15-25) ─────────────────────────────────
    await check_tally(client, "Phase 3: Sales")
    print("\n=== Phase 3: Sales ===")

    # #9 Sales: Software services to same-state customer (MH), CGST+SGST
    await v("9. Software services (intra-state, CGST+SGST)", VoucherCreate(
        voucher_type="Sales",
        date="20250415",
        party_name="Pinnacle Infra Pvt Ltd",
        reference="INV-001",
        narration="Software development services - April",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Pinnacle Infra Pvt Ltd", amount=236000),
            VoucherEntry(ledger_name="Software Development Services", amount=-200000),
            VoucherEntry(ledger_name="Output CGST @ 9%", amount=-18000),
            VoucherEntry(ledger_name="Output SGST @ 9%", amount=-18000),
        ],
    ))

    # #10 Sales: IT consulting to other-state customer (TN), IGST
    await v("10. IT consulting (inter-state, IGST)", VoucherCreate(
        voucher_type="Sales",
        date="20250417",
        party_name="Southern Tech Solutions",
        reference="INV-002",
        narration="IT consulting services",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Southern Tech Solutions", amount=118000),
            VoucherEntry(ledger_name="IT Consulting Services", amount=-100000),
            VoucherEntry(ledger_name="Output IGST @ 18%", amount=-18000),
        ],
    ))

    # #11 Sales: Hardware sale to other-state customer (DL), IGST, with inventory
    await v("11. Hardware sale (inter-state, with inventory)", VoucherCreate(
        voucher_type="Sales",
        date="20250418",
        party_name="Greenfield Exports LLP",
        reference="INV-003",
        narration="USB-C Hub sale to Delhi customer",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Greenfield Exports LLP", amount=59000),
            VoucherEntry(ledger_name="Product Sales - Domestic", amount=-50000),
            VoucherEntry(ledger_name="Output IGST @ 18%", amount=-9000),
        ],
        # TODO: inventory_entries require Invoice Voucher View which crashes Tally
    ))

    # #12 Sales: Export software services to US client (LUT, zero-rated)
    await v("12. Export services USD (LUT, zero-rated)", VoucherCreate(
        voucher_type="Sales",
        date="20250420",
        party_name="Acme Global Inc",
        reference="INV-004",
        narration="Export software services, 5000 USD @ 85, LUT zero-rated",
        entries=[
            VoucherEntry(ledger_name="Acme Global Inc", amount=425000),
            VoucherEntry(ledger_name="Export Software Services", amount=-425000),
        ],
    ))

    # #13 Sales: Export services to UK client (LUT, zero-rated, GBP)
    await v("13. Export services GBP (LUT, zero-rated)", VoucherCreate(
        voucher_type="Sales",
        date="20250422",
        party_name="BritSoft Ltd",
        reference="INV-005",
        narration="Export software services, 3000 GBP @ 110, LUT zero-rated",
        entries=[
            VoucherEntry(ledger_name="BritSoft Ltd", amount=330000),
            VoucherEntry(ledger_name="Export Software Services", amount=-330000),
        ],
    ))

    # #14 Sales: Sale to unregistered customer (B2C)
    await v("14. B2C sale (unregistered customer)", VoucherCreate(
        voucher_type="Sales",
        date="20250424",
        party_name="Unregistered Retail Customer",
        reference="INV-006",
        narration="Retail sale to unregistered customer",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Unregistered Retail Customer", amount=11800),
            VoucherEntry(ledger_name="Product Sales - Domestic", amount=-10000),
            VoucherEntry(ledger_name="Output CGST @ 9%", amount=-900),
            VoucherEntry(ledger_name="Output SGST @ 9%", amount=-900),
        ],
    ))

    # #15 Sales: Service with TDS deducted by client
    await v("15. Service sale with TDS deduction", VoucherCreate(
        voucher_type="Sales",
        date="20250425",
        party_name="Southern Tech Solutions",
        reference="INV-007",
        narration="IT consulting, client deducts TDS u/s 194J (10%)",
        # NOTE: is_invoice=True causes Tally crashes (memory access violation).
        # Using Accounting Voucher View (default) instead.
        entries=[
            VoucherEntry(ledger_name="Southern Tech Solutions", amount=106200),
            VoucherEntry(ledger_name="TDS Receivable (Sec 194J)", amount=11800),
            VoucherEntry(ledger_name="IT Consulting Services", amount=-100000),
            VoucherEntry(ledger_name="Output IGST @ 18%", amount=-18000),
        ],
    ))

    # ── Phase 4: Payments (Apr 28 - May 5) ─────────────────────────
    await check_tally(client, "Phase 4: Payments")
    print("\n=== Phase 4: Payments ===")

    # #16 Payment: Pay same-state vendor (partial)
    await v("16. Partial payment to Reliable Hardware", VoucherCreate(
        voucher_type="Payment",
        date="20250428",
        party_name="Reliable Hardware Pvt Ltd",
        reference="PAY-001",
        narration="Partial payment against PO-001",
        entries=[
            VoucherEntry(ledger_name="Reliable Hardware Pvt Ltd", amount=100000),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-100000),
        ],
    ))

    # #17 Payment: Pay other-state vendor (full)
    await v("17. Full payment to Northern Supplies", VoucherCreate(
        voucher_type="Payment",
        date="20250430",
        party_name="Northern Supplies Co",
        reference="PAY-002",
        narration="Full settlement of PO-002",
        entries=[
            VoucherEntry(ledger_name="Northern Supplies Co", amount=23600),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-23600),
        ],
    ))

    # #18 Payment: Office rent
    await v("18. Office rent payment", VoucherCreate(
        voucher_type="Payment",
        date="20250501",
        narration="Office rent for May 2025",
        entries=[
            VoucherEntry(ledger_name="Office Rent", amount=30000),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-30000),
        ],
    ))

    # #19 Payment: Salary
    await v("19. Salary payment", VoucherCreate(
        voucher_type="Payment",
        date="20250502",
        narration="Staff salary for April 2025",
        entries=[
            VoucherEntry(ledger_name="Salary & Wages", amount=200000),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-200000),
        ],
    ))

    # #20 Payment: Petty cash travel expense
    await v("20. Petty cash - travel expense", VoucherCreate(
        voucher_type="Payment",
        date="20250503",
        narration="Local travel - client visit",
        entries=[
            VoucherEntry(ledger_name="Travel & Conveyance", amount=1500),
            VoucherEntry(ledger_name="Petty Cash", amount=-1500),
        ],
    ))

    # #21 Payment: Pay foreign vendor (INR)
    await v("21. Pay CloudHost USA in INR", VoucherCreate(
        voucher_type="Payment",
        date="20250504",
        party_name="CloudHost USA Inc",
        reference="PAY-003",
        narration="Cloud hosting payment, 500 USD equivalent in INR",
        entries=[
            VoucherEntry(ledger_name="CloudHost USA Inc", amount=42500),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-42500),
        ],
    ))

    # #22 Payment: Pay unregistered vendor
    await v("22. Pay freelance designer", VoucherCreate(
        voucher_type="Payment",
        date="20250505",
        party_name="Freelance Designer (Unregistered)",
        reference="PAY-004",
        narration="Design services payment (GST already self-assessed via RCM)",
        entries=[
            VoucherEntry(ledger_name="Freelance Designer (Unregistered)", amount=15000),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-15000),
        ],
    ))

    # ── Phase 5: Receipts (May 7-13) ───────────────────────────────
    await check_tally(client, "Phase 5: Receipts")
    print("\n=== Phase 5: Receipts ===")

    # #23 Receipt: Receive from same-state customer (full)
    await v("23. Full receipt from Pinnacle Infra", VoucherCreate(
        voucher_type="Receipt",
        date="20250507",
        party_name="Pinnacle Infra Pvt Ltd",
        reference="REC-001",
        narration="Full payment received against INV-001",
        entries=[
            VoucherEntry(ledger_name="HDFC Current A/c", amount=236000),
            VoucherEntry(ledger_name="Pinnacle Infra Pvt Ltd", amount=-236000),
        ],
    ))

    # #24 Receipt: Receive from other-state customer (partial)
    await v("24. Partial receipt from Southern Tech", VoucherCreate(
        voucher_type="Receipt",
        date="20250509",
        party_name="Southern Tech Solutions",
        reference="REC-002",
        narration="Partial payment against INV-002",
        entries=[
            VoucherEntry(ledger_name="HDFC Current A/c", amount=100000),
            VoucherEntry(ledger_name="Southern Tech Solutions", amount=-100000),
        ],
    ))

    # #25 Receipt: USD from export client (with forex gain)
    await v("25. USD receipt with forex gain", VoucherCreate(
        voucher_type="Receipt",
        date="20250510",
        party_name="Acme Global Inc",
        reference="REC-003",
        narration="5000 USD received @ 86 (booked @ 85), forex gain Rs.5000",
        entries=[
            VoucherEntry(ledger_name="HDFC Current A/c", amount=430000),
            VoucherEntry(ledger_name="Acme Global Inc", amount=-425000),
            VoucherEntry(ledger_name="Round Off", amount=-5000),
        ],
    ))

    # #26 Receipt: GBP from UK client
    await v("26. GBP receipt from BritSoft", VoucherCreate(
        voucher_type="Receipt",
        date="20250512",
        party_name="BritSoft Ltd",
        reference="REC-004",
        narration="3000 GBP received at same rate",
        entries=[
            VoucherEntry(ledger_name="HDFC Current A/c", amount=330000),
            VoucherEntry(ledger_name="BritSoft Ltd", amount=-330000),
        ],
    ))

    # #27 Receipt: From B2C customer
    await v("27. Receipt from B2C customer", VoucherCreate(
        voucher_type="Receipt",
        date="20250513",
        party_name="Unregistered Retail Customer",
        reference="REC-005",
        narration="Payment from retail customer against INV-006",
        entries=[
            VoucherEntry(ledger_name="HDFC Current A/c", amount=11800),
            VoucherEntry(ledger_name="Unregistered Retail Customer", amount=-11800),
        ],
    ))

    # ── Phase 6: Adjustments (May 15-20) ───────────────────────────
    await check_tally(client, "Phase 6: Adjustments")
    print("\n=== Phase 6: Adjustments ===")

    # #28 Credit Note: Discount to same-state customer
    await v("28. Credit note - discount to Pinnacle Infra", VoucherCreate(
        voucher_type="Credit Note",
        date="20250515",
        party_name="Pinnacle Infra Pvt Ltd",
        reference="CN-001",
        narration="Discount on software services, reverses GST",
        entries=[
            VoucherEntry(ledger_name="Software Development Services", amount=20000),
            VoucherEntry(ledger_name="Output CGST @ 9%", amount=1800),
            VoucherEntry(ledger_name="Output SGST @ 9%", amount=1800),
            VoucherEntry(ledger_name="Pinnacle Infra Pvt Ltd", amount=-23600),
        ],
    ))

    # #29 Debit Note: Return to same-state vendor
    await v("29. Debit note - return to Reliable Hardware", VoucherCreate(
        voucher_type="Debit Note",
        date="20250516",
        party_name="Reliable Hardware Pvt Ltd",
        reference="DN-001",
        narration="Return defective USB-C Hubs, reverses input GST",
        entries=[
            VoucherEntry(ledger_name="Reliable Hardware Pvt Ltd", amount=5900),
            VoucherEntry(ledger_name="Computer Hardware Purchase", amount=-5000),
            VoucherEntry(ledger_name="Input CGST @ 9%", amount=-450),
            VoucherEntry(ledger_name="Input SGST @ 9%", amount=-450),
        ],
    ))

    # #30 Journal: Employee advance
    await v("30. Employee advance", VoucherCreate(
        voucher_type="Journal",
        date="20250517",
        narration="Advance to employee for travel",
        entries=[
            VoucherEntry(ledger_name="Employee Advances", amount=25000),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-25000),
        ],
    ))

    # #31 Journal: Security deposit for office
    await v("31. Office security deposit", VoucherCreate(
        voucher_type="Journal",
        date="20250518",
        narration="Security deposit paid for office premises",
        entries=[
            VoucherEntry(ledger_name="Security Deposit - Office", amount=100000),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-100000),
        ],
    ))

    # #32 Journal: Bank charges
    await v("32. Bank charges", VoucherCreate(
        voucher_type="Journal",
        date="20250519",
        narration="HDFC bank charges for April",
        entries=[
            VoucherEntry(ledger_name="Bank Charges", amount=500),
            VoucherEntry(ledger_name="HDFC Current A/c", amount=-500),
        ],
    ))

    # #33 Journal: Depreciation on laptop
    await v("33. Laptop depreciation", VoucherCreate(
        voucher_type="Journal",
        date="20250520",
        narration="Depreciation on Laptop & Equipment for April",
        entries=[
            VoucherEntry(ledger_name="Travel & Conveyance", amount=5000),
            VoucherEntry(ledger_name="Laptop & Equipment", amount=-5000),
        ],
    ))

    # ── Phase 7: Bulk Operations (May 22-23) ───────────────────────
    await check_tally(client, "Phase 7: Bulk Operations")
    print("\n=== Phase 7: Bulk Operations ===")

    # #34 Bulk create ledgers
    print("  --- 34. Bulk create 3 expense ledgers ---")
    bulk_ledgers = [
        LedgerCreate(name="Printing & Stationery", parent="Indirect Expenses"),
        LedgerCreate(name="Courier & Shipping", parent="Indirect Expenses"),
        LedgerCreate(name="Staff Welfare", parent="Indirect Expenses"),
    ]
    combined_xml = "\n".join(build_ledger_xml(l) for l in bulk_ledgers)
    result = await client.import_data(combined_xml, request_type="All Masters")
    ok(f"Bulk: {len(bulk_ledgers)} expense ledgers", result)
    _counts["bulk_ledgers"] = len(bulk_ledgers)

    # #35 Import CSV ledgers (2 customer ledgers)
    print("  --- 35. Import 2 customer ledgers from CSV ---")
    csv_ledger_data = (
        "name,parent,opening_balance,address,gst_number\n"
        "Metro Electronics,Sundry Debtors,0,,27AABCM4567F1Z3\n"
        "Sunrise Traders,Sundry Debtors,0,,29AABCS8901G1Z7\n"
    )
    import csv
    import io
    reader = csv.DictReader(io.StringIO(csv_ledger_data))
    csv_xml_parts = []
    for row in reader:
        ledger = LedgerCreate(
            name=row["name"],
            parent=row["parent"],
            opening_balance=float(row.get("opening_balance", 0) or 0),
            address=row.get("address", ""),
            gst_number=row.get("gst_number", ""),
        )
        csv_xml_parts.append(build_ledger_xml(ledger))
    result = await client.import_data("\n".join(csv_xml_parts), request_type="All Masters")
    ok("CSV import: 2 customer ledgers", result)
    _counts["csv_ledgers"] = 2

    # #36 Bulk create vouchers (3 payment vouchers)
    print("  --- 36. Bulk create 3 payment vouchers ---")
    bulk_vouchers = [
        VoucherCreate(
            voucher_type="Payment",
            date="20250522",
            narration="Printing & stationery expense",
            entries=[
                VoucherEntry(ledger_name="Printing & Stationery", amount=2000),
                VoucherEntry(ledger_name="HDFC Current A/c", amount=-2000),
            ],
        ),
        VoucherCreate(
            voucher_type="Payment",
            date="20250522",
            narration="Courier charges",
            entries=[
                VoucherEntry(ledger_name="Courier & Shipping", amount=1500),
                VoucherEntry(ledger_name="HDFC Current A/c", amount=-1500),
            ],
        ),
        VoucherCreate(
            voucher_type="Payment",
            date="20250522",
            narration="Electricity bill for April",
            entries=[
                VoucherEntry(ledger_name="Electricity Charges", amount=3500),
                VoucherEntry(ledger_name="HDFC Current A/c", amount=-3500),
            ],
        ),
    ]
    combined_xml = "\n".join(build_voucher_xml(v_item) for v_item in bulk_vouchers)
    result = await client.import_data(combined_xml, request_type="Vouchers")
    ok(f"Bulk: {len(bulk_vouchers)} payment vouchers", result)
    _counts["bulk_vouchers"] = len(bulk_vouchers)

    # #37 Import CSV vouchers (2 journal vouchers)
    print("  --- 37. Import 2 journal vouchers via CSV ---")
    csv_voucher_data = (
        "reference,date,ledger_name,amount,narration,party_name\n"
        "JV-CSV-001,20250523,Staff Welfare,5000,Staff welfare expense,\n"
        "JV-CSV-001,20250523,HDFC Current A/c,-5000,Staff welfare expense,\n"
        "JV-CSV-002,20250523,Professional Fees,10000,Legal consultation fee,\n"
        "JV-CSV-002,20250523,HDFC Current A/c,-10000,Legal consultation fee,\n"
    )
    reader = csv.DictReader(io.StringIO(csv_voucher_data))
    csv_groups: dict[str, list[dict]] = {}
    for row in reader:
        ref = row["reference"]
        csv_groups.setdefault(ref, []).append(row)
    csv_voucher_xml_parts = []
    for ref, rows in csv_groups.items():
        first = rows[0]
        entries = [
            VoucherEntry(
                ledger_name=r["ledger_name"],
                amount=float(r["amount"]),
                cost_centre=r.get("cost_centre", ""),
            )
            for r in rows
        ]
        voucher_obj = VoucherCreate(
            voucher_type="Journal",
            date=first["date"],
            party_name=first.get("party_name", ""),
            narration=first.get("narration", ""),
            reference=ref,
            entries=entries,
        )
        csv_voucher_xml_parts.append(build_voucher_xml(voucher_obj))
    result = await client.import_data("\n".join(csv_voucher_xml_parts), request_type="Vouchers")
    ok("CSV import: 2 journal vouchers", result)
    _counts["csv_vouchers"] = 2

    # ── Phase 8: Cancellation ──────────────────────────────────────
    await check_tally(client, "Phase 8: Cancellation")
    print("\n=== Phase 8: Cancellation ===")

    # #38 Cancel Credit Note #1 (from case 28)
    cancel_xml = '''<VOUCHER VCHTYPE="Credit Note" ACTION="Cancel">
    <VOUCHERNUMBER>1</VOUCHERNUMBER>
    <DATE>20250515</DATE>
    <VOUCHERTYPENAME>Credit Note</VOUCHERTYPENAME>
    </VOUCHER>'''
    result = await client.import_data(cancel_xml, request_type="Vouchers")
    ok("Cancel: Credit Note #1", result)
    _counts["cancelled"] = 1

    # ══════════════════════════════════════════════════════════════════
    # Phase 9: Read Endpoints (Verify Everything)
    # ══════════════════════════════════════════════════════════════════
    await check_tally(client, "Phase 9: Read Endpoints")
    print("\n=== Phase 9: Read Endpoints ===")

    # R1: health_check
    health = await client.health_check()
    report("R1 health_check", f"status={health['status']}")

    # R2: list_companies
    companies = await client.list_companies()
    report("R2 list_companies", companies)

    # R3: list_ledgers (all)
    all_ledgers = await client.export_collection("List of Ledgers", "LEDGER")
    report("R3 list_ledgers (all)", all_ledgers)

    # R4: list_ledgers (filtered by group)
    filtered_ledgers = await client.export_collection(
        "FilteredLedgers", "LEDGER",
        tdl='''
        <COLLECTION NAME="FilteredLedgers" ISMODIFY="No">
            <TYPE>Ledger</TYPE>
            <FILTER>GroupFilter</FILTER>
            <FETCH>Name, Parent, OpeningBalance, ClosingBalance</FETCH>
        </COLLECTION>
        <SYSTEM TYPE="Formulae" NAME="GroupFilter">$Parent = "Sundry Debtors"</SYSTEM>
        ''',
    )
    report("R4 list_ledgers (group=Sundry Debtors)", filtered_ledgers)

    # R5: list_groups
    all_groups = await client.export_collection("List of Groups", "GROUP")
    report("R5 list_groups", all_groups)

    # R6: list_stock_items
    all_stock = await client.export_collection("List of Stock Items", "STOCKITEM")
    report("R6 list_stock_items", all_stock)

    # R7: list_voucher_types
    all_vtypes = await client.export_collection("List of Voucher Types", "VOUCHERTYPE")
    report("R7 list_voucher_types", all_vtypes)

    # R8: get_ledger (HDFC Current A/c, full FY)
    ledger_report = await client.export_report(
        "Ledger Vouchers", extra_vars={"LEDGERNAME": "HDFC Current A/c"},
        from_date=FY_START, to_date=FY_END,
    )
    report("R8 get_ledger (HDFC Current A/c)", ledger_report)

    # R9: get_stock_item (Laptop Dell Vostro)
    stock_report = await client.export_report(
        "Stock Item", extra_vars={"STOCKITEMNAME": "Laptop Dell Vostro"},
    )
    report("R9 get_stock_item (Laptop Dell Vostro)", stock_report)

    # R10: get_trial_balance
    tb = await client.export_report(
        "Trial Balance", from_date=FY_START, to_date=FY_END,
        extra_vars={"EXPLODEFLAG": "Yes"},
    )
    report("R10 get_trial_balance", tb)

    # R11: get_balance_sheet
    bs = await client.export_report(
        "Balance Sheet", from_date=FY_START, to_date=FY_END,
    )
    report("R11 get_balance_sheet", bs)

    # R12: get_profit_and_loss
    pnl = await client.export_report(
        "Profit and Loss A/c", from_date=FY_START, to_date=FY_END,
    )
    report("R12 get_profit_and_loss", pnl)

    # R13: get_day_book (all)
    daybook = await client.export_report(
        "Day Book", from_date=FY_START, to_date=FY_END,
    )
    report("R13 get_day_book (all)", daybook)

    # R14: get_day_book (Sales only)
    daybook_sales = await client.export_report(
        "Day Book", from_date=FY_START, to_date=FY_END,
        extra_vars={"VOUCHERTYPENAME": "Sales"},
    )
    report("R14 get_day_book (Sales only)", daybook_sales)

    # R15: get_day_book (Purchase only)
    daybook_purchase = await client.export_report(
        "Day Book", from_date=FY_START, to_date=FY_END,
        extra_vars={"VOUCHERTYPENAME": "Purchase"},
    )
    report("R15 get_day_book (Purchase only)", daybook_purchase)

    # R16: get_stock_summary
    stock_summary = await client.export_report("Stock Summary")
    report("R16 get_stock_summary", stock_summary)

    # R17: get_sales_register
    sales_reg = await client.export_report(
        "Sales Register", from_date=FY_START, to_date=FY_END,
    )
    report("R17 get_sales_register", sales_reg)

    # R18: get_purchase_register
    purchase_reg = await client.export_report(
        "Purchase Register", from_date=FY_START, to_date=FY_END,
    )
    report("R18 get_purchase_register", purchase_reg)

    # R19: get_receivables
    receivables = await client.export_report("Bills Receivable")
    report("R19 get_receivables", receivables)

    # R20: get_payables
    payables = await client.export_report("Bills Payable")
    report("R20 get_payables", payables)

    # R21: get_bank_book (HDFC)
    bank_book = await client.export_report(
        "Ledger Vouchers", extra_vars={"LEDGERNAME": "HDFC Current A/c"},
        from_date=FY_START, to_date=FY_END,
    )
    report("R21 get_bank_book (HDFC Current A/c)", bank_book)

    # R22: get_bank_book (Petty Cash)
    cash_book = await client.export_report(
        "Ledger Vouchers", extra_vars={"LEDGERNAME": "Petty Cash"},
        from_date=FY_START, to_date=FY_END,
    )
    report("R22 get_bank_book (Petty Cash)", cash_book)

    # R23: get_ledger_vouchers (Acme Global - USD export)
    acme_vouchers = await client.export_report(
        "Ledger Vouchers", extra_vars={"LEDGERNAME": "Acme Global Inc"},
        from_date=FY_START, to_date=FY_END,
    )
    report("R23 get_ledger_vouchers (Acme Global Inc)", acme_vouchers)

    # R24: get_group_summary (Sundry Debtors)
    group_debtors = await client.export_report(
        "Group Summary", extra_vars={"GROUPNAME": "Sundry Debtors"},
        from_date=FY_START, to_date=FY_END,
    )
    report("R24 get_group_summary (Sundry Debtors)", group_debtors)

    # R25: get_group_summary (Sundry Creditors)
    group_creditors = await client.export_report(
        "Group Summary", extra_vars={"GROUPNAME": "Sundry Creditors"},
        from_date=FY_START, to_date=FY_END,
    )
    report("R25 get_group_summary (Sundry Creditors)", group_creditors)

    # R26: get_group_summary (Sales Accounts)
    group_sales = await client.export_report(
        "Group Summary", extra_vars={"GROUPNAME": "Sales Accounts"},
        from_date=FY_START, to_date=FY_END,
    )
    report("R26 get_group_summary (Sales Accounts)", group_sales)

    # R27: execute_custom_query (raw XML for company info)
    try:
        custom_xml = (
            '<ENVELOPE>'
            '<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST>'
            '<TYPE>Data</TYPE><ID>Company</ID></HEADER>'
            '<BODY><DESC><STATICVARIABLES>'
            f'<SVCURRENTCOMPANY>{COMPANY}</SVCURRENTCOMPANY>'
            '<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>'
            '</STATICVARIABLES></DESC></BODY></ENVELOPE>'
        )
        custom_response = await client._post(custom_xml.encode("utf-8"))
        custom_lines = custom_response.decode("utf-8").strip().splitlines()
        report("R27 execute_custom_query (Company info)", f"{len(custom_lines)} lines of XML")
    except Exception as exc:
        print(f"  [SKIP] R27 execute_custom_query: {exc}")
        _counts["read_endpoints"] += 1

    # ══════════════════════════════════════════════════════════════════
    # Summary
    # ══════════════════════════════════════════════════════════════════
    total_vouchers = sum(_counts["vouchers"].values())
    print("\n" + "=" * 70)
    print("TEST DATA SEEDING COMPLETE")
    print("=" * 70)
    print(f"  Company:           {COMPANY}")
    print(f"  Groups created:    {_counts['groups']}")
    print(f"  Ledgers created:   {_counts['ledgers']} individual + {_counts['bulk_ledgers']} bulk + {_counts['csv_ledgers']} CSV")
    print(f"  Units created:     {_counts['units']}")
    print(f"  Stock items:       {_counts['stock_items']}")
    print(f"  Vouchers by type:")
    for vtype, count in sorted(_counts["vouchers"].items()):
        print(f"    {vtype:20s} {count}")
    print(f"  Bulk vouchers:     {_counts['bulk_vouchers']}")
    print(f"  CSV vouchers:      {_counts['csv_vouchers']}")
    print(f"  Total vouchers:    {total_vouchers} + {_counts['bulk_vouchers']} bulk + {_counts['csv_vouchers']} CSV")
    print(f"  Cancelled:         {_counts['cancelled']}")
    print(f"  Read endpoints:    {_counts['read_endpoints']}")
    if _counts["errors"]:
        print(f"\n  WARNINGS ({len(_counts['errors'])}):")
        for err in _counts["errors"]:
            print(f"    - {err}")
    print()


if __name__ == "__main__":
    asyncio.run(main())
