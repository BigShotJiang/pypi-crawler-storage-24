"""Phase 1: Test all read endpoints against whatever data exists in Tally.

Usage:
    .venv/Scripts/python scripts/test_read_endpoints.py
    .venv/Scripts/python scripts/test_read_endpoints.py "Company Name"

No writes. No side effects. Safe to run repeatedly against any company.
Tests every read MCP tool by calling TallyClient directly.
When JSONEx is available, tests BOTH JSON and XML transports for key endpoints.
"""

import asyncio
import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from tally_mcp.config import settings
from tally_mcp.tally_client import TallyClient

# Allow company override from CLI arg
COMPANY = sys.argv[1] if len(sys.argv) > 1 else settings.tally_default_company
if not COMPANY:
    print("ERROR: Pass company name as arg or set TALLY_MCP_TALLY_DEFAULT_COMPANY in .env")
    sys.exit(1)

FY_START = "20250401"
FY_END = "20260331"

_passed = 0
_failed = 0
_skipped = 0


def ok(label: str, data) -> None:
    global _passed
    _passed += 1
    if isinstance(data, list):
        print(f"  [PASS] {label} -> {len(data)} items")
    elif isinstance(data, str):
        lines = data.strip().splitlines()
        print(f"  [PASS] {label} -> {len(lines)} lines")
    elif isinstance(data, dict):
        # For JSON reports, show top-level keys
        keys = list(data.keys())[:5]
        print(f"  [PASS] {label} -> dict keys={keys}")
    else:
        print(f"  [PASS] {label}")


def fail(label: str, error: str) -> None:
    global _failed
    _failed += 1
    print(f"  [FAIL] {label} -> {error}")


def skip(label: str, reason: str) -> None:
    global _skipped
    _skipped += 1
    print(f"  [SKIP] {label} -> {reason}")


async def try_read(label: str, coro):
    """Run a read operation, catching and reporting errors."""
    try:
        result = await coro
        if result is None:
            fail(label, "returned None")
        elif isinstance(result, list) and len(result) == 0:
            skip(label, "empty result (no data in company)")
        elif isinstance(result, str) and len(result.strip()) == 0:
            skip(label, "empty response")
        elif isinstance(result, dict) and result.get("error"):
            fail(label, f"error: {result['error']}")
        else:
            ok(label, result)
        return result
    except Exception as exc:
        fail(label, f"{type(exc).__name__}: {exc}")
        return None


async def main():
    client = TallyClient(
        host=settings.tally_host,
        port=settings.tally_port,
        default_company=COMPANY,
        username=settings.tally_username,
        password=settings.tally_password,
    )

    print(f"\n{'=' * 70}")
    print(f"  PHASE 1: READ ENDPOINT TESTS")
    print(f"  Company: {COMPANY}")
    print(f"  FY: {FY_START} - {FY_END}")
    print(f"{'=' * 70}")

    # ── 1. Heartbeat (also detects JSON support) ──────────────────
    print("\n--- Connectivity ---")
    hb = await try_read("heartbeat", client.heartbeat(COMPANY))
    if hb and not hb.get("ok"):
        print(f"\n  FATAL: {hb['message']}")
        sys.exit(1)

    json_ok = client._json_supported
    transport = client.transport
    print(f"  Transport: {transport} (JSONEx {'supported' if json_ok else 'not supported'})")

    health = await try_read("health_check", client.health_check())

    # ── 2. Company & Master Lists ─────────────────────────────────
    print("\n--- Master Lists ---")

    companies = await try_read("list_companies", client.list_companies())

    all_ledgers = await try_read(
        "list_ledgers (all)",
        client.export_collection("List of Ledgers", "LEDGER"),
    )

    # Get ledgers with parent info for dynamic lookups
    detailed_ledgers = await client.export_collection(
        "DetailedLedgers", "LEDGER",
        tdl='''
        <COLLECTION NAME="DetailedLedgers" ISMODIFY="No">
            <TYPE>Ledger</TYPE>
            <FETCH>Name, Parent</FETCH>
        </COLLECTION>
        ''',
    )

    # Pick ledger names by group for further queries
    first_ledger = None
    first_debtor = None
    first_creditor = None
    bank_ledger = None
    cash_ledger = None
    for l in (detailed_ledgers or []):
        name = l.get("NAME", l.get("@NAME", ""))
        parent = l.get("PARENT", "")
        if not first_ledger and name:
            first_ledger = name
        if not first_debtor and parent == "Sundry Debtors":
            first_debtor = name
        if not first_creditor and parent == "Sundry Creditors":
            first_creditor = name
        if not bank_ledger and parent == "Bank Accounts":
            bank_ledger = name
        if not cash_ledger and parent == "Cash-in-Hand":
            cash_ledger = name

    # Filtered ledger list (Sundry Debtors) — always uses XML (TDL filter)
    await try_read(
        "list_ledgers (group=Sundry Debtors) [XML/TDL]",
        client.export_collection(
            "FilteredLedgers", "LEDGER",
            tdl='''
            <COLLECTION NAME="FilteredLedgers" ISMODIFY="No">
                <TYPE>Ledger</TYPE>
                <FILTER>GroupFilter</FILTER>
                <FETCH>Name, Parent, OpeningBalance, ClosingBalance</FETCH>
            </COLLECTION>
            <SYSTEM TYPE="Formulae" NAME="GroupFilter">$Parent = "Sundry Debtors"</SYSTEM>
            ''',
        ),
    )

    all_groups = await try_read(
        "list_groups",
        client.export_collection("List of Groups", "GROUP"),
    )

    all_stock = await try_read(
        "list_stock_items",
        client.export_collection("List of Stock Items", "STOCKITEM"),
    )

    all_vtypes = await try_read(
        "list_voucher_types",
        client.export_collection("List of Voucher Types", "VOUCHERTYPE"),
    )

    # ── 3. Financial Reports ──────────────────────────────────────
    print("\n--- Financial Reports ---")

    await try_read(
        "get_trial_balance",
        client.export_report(
            "Trial Balance", from_date=FY_START, to_date=FY_END,
            extra_vars={"ExplodeFlag": "Yes"},
        ),
    )

    await try_read(
        "get_balance_sheet",
        client.export_report("Balance Sheet", from_date=FY_START, to_date=FY_END),
    )

    await try_read(
        "get_profit_and_loss",
        client.export_report("Profit and Loss A/c", from_date=FY_START, to_date=FY_END),
    )

    # ── 4. Voucher Reports ────────────────────────────────────────
    print("\n--- Voucher Reports ---")

    await try_read(
        "get_day_book (all)",
        client.export_report("Day Book", from_date=FY_START, to_date=FY_END),
    )

    await try_read(
        "get_day_book (Sales)",
        client.export_report(
            "Day Book", from_date=FY_START, to_date=FY_END,
            extra_vars={"VOUCHERTYPENAME": "Sales"},
        ),
    )

    await try_read(
        "get_sales_register",
        client.export_report("Sales Register", from_date=FY_START, to_date=FY_END),
    )

    await try_read(
        "get_purchase_register",
        client.export_report("Purchase Register", from_date=FY_START, to_date=FY_END),
    )

    # ── 5. Receivables & Payables ─────────────────────────────────
    print("\n--- Receivables & Payables ---")

    await try_read("get_receivables", client.export_report("Bills Receivable"))
    await try_read("get_payables", client.export_report("Bills Payable"))

    # ── 6. Ledger-Specific Reports ────────────────────────────────
    print("\n--- Ledger Reports ---")

    if bank_ledger:
        await try_read(
            f"get_ledger ({bank_ledger})",
            client.export_report(
                "Ledger Vouchers", extra_vars={"LEDGERNAME": bank_ledger},
                from_date=FY_START, to_date=FY_END,
            ),
        )
    else:
        skip("get_ledger (bank)", "no Bank Accounts ledger found")

    if cash_ledger:
        await try_read(
            f"get_bank_book ({cash_ledger})",
            client.export_report(
                "Ledger Vouchers", extra_vars={"LEDGERNAME": cash_ledger},
                from_date=FY_START, to_date=FY_END,
            ),
        )
    else:
        skip("get_bank_book (cash)", "no Cash-in-Hand ledger found")

    if first_debtor:
        await try_read(
            f"get_ledger_vouchers ({first_debtor})",
            client.export_report(
                "Ledger Vouchers", extra_vars={"LEDGERNAME": first_debtor},
                from_date=FY_START, to_date=FY_END,
            ),
        )
    else:
        skip("get_ledger_vouchers (debtor)", "no Sundry Debtors ledger found")

    # ── 7. Stock Reports ──────────────────────────────────────────
    print("\n--- Stock Reports ---")

    await try_read("get_stock_summary", client.export_report("Stock Summary"))

    first_stock = None
    if all_stock and isinstance(all_stock, list):
        first_stock = all_stock[0].get("NAME", all_stock[0].get("@NAME", ""))

    if first_stock:
        await try_read(
            f"get_stock_item ({first_stock})",
            client.export_report("Stock Item", extra_vars={"STOCKITEMNAME": first_stock}),
        )
    else:
        skip("get_stock_item", "no stock items found")

    # ── 8. Group Summaries ────────────────────────────────────────
    print("\n--- Group Summaries ---")

    for group in ["Sundry Debtors", "Sundry Creditors", "Sales Accounts"]:
        await try_read(
            f"get_group_summary ({group})",
            client.export_report(
                "Group Summary", extra_vars={"GROUPNAME": group},
                from_date=FY_START, to_date=FY_END,
            ),
        )

    # ══════════════════════════════════════════════════════════════
    # DUAL TRANSPORT TESTS — only run if JSONEx is supported
    # ══════════════════════════════════════════════════════════════
    if json_ok:
        print(f"\n{'=' * 70}")
        print("  DUAL TRANSPORT TESTS (JSON vs XML)")
        print(f"{'=' * 70}")

        # Collection: List of Ledgers — both transports
        print("\n--- Collections: JSON vs XML ---")
        json_ledgers = await try_read(
            "list_ledgers [JSON]",
            client.export_collection_json("List of Ledgers", "LEDGER"),
        )
        xml_ledgers = await try_read(
            "list_ledgers [XML]",
            client.export_collection_xml("List of Ledgers", "LEDGER"),
        )
        if json_ledgers and xml_ledgers:
            jcount = len(json_ledgers)
            xcount = len(xml_ledgers)
            match = "MATCH" if jcount == xcount else f"MISMATCH ({jcount} vs {xcount})"
            print(f"  [{'PASS' if jcount == xcount else 'WARN'}] "
                  f"Count comparison: JSON={jcount} XML={xcount} -> {match}")

        # Collection: List of Groups — both transports
        json_groups = await try_read(
            "list_groups [JSON]",
            client.export_collection_json("List of Groups", "GROUP"),
        )
        xml_groups = await try_read(
            "list_groups [XML]",
            client.export_collection_xml("List of Groups", "GROUP"),
        )

        # Reports: Trial Balance — both transports
        print("\n--- Reports: JSON vs XML ---")
        json_tb = await try_read(
            "trial_balance [JSON]",
            client.export_report_json(
                "Trial Balance", from_date=FY_START, to_date=FY_END,
                extra_vars={"ExplodeFlag": "Yes"},
            ),
        )
        xml_tb = await try_read(
            "trial_balance [XML]",
            client.export_report_xml(
                "Trial Balance", from_date=FY_START, to_date=FY_END,
                extra_vars={"EXPLODEFLAG": "Yes"},
            ),
        )

        # Report: P&L — both transports
        json_pnl = await try_read(
            "profit_and_loss [JSON]",
            client.export_report_json(
                "Profit and Loss A/c", from_date=FY_START, to_date=FY_END,
            ),
        )
        xml_pnl = await try_read(
            "profit_and_loss [XML]",
            client.export_report_xml(
                "Profit and Loss A/c", from_date=FY_START, to_date=FY_END,
            ),
        )

        # Report: Balance Sheet — both transports
        json_bs = await try_read(
            "balance_sheet [JSON]",
            client.export_report_json(
                "Balance Sheet", from_date=FY_START, to_date=FY_END,
            ),
        )
        xml_bs = await try_read(
            "balance_sheet [XML]",
            client.export_report_xml(
                "Balance Sheet", from_date=FY_START, to_date=FY_END,
            ),
        )

        # Report: Bills Receivable — both transports
        json_recv = await try_read(
            "receivables [JSON]",
            client.export_report_json("Bills Receivable"),
        )
        xml_recv = await try_read(
            "receivables [XML]",
            client.export_report_xml("Bills Receivable"),
        )
    else:
        print("\n  (Skipping dual transport tests — JSONEx not supported)")

    # ── Summary ───────────────────────────────────────────────────
    total = _passed + _failed + _skipped
    print(f"\n{'=' * 70}")
    print(f"  RESULTS: {_passed} passed, {_failed} failed, {_skipped} skipped ({total} total)")
    print(f"  Transport: {transport}")
    print(f"{'=' * 70}\n")

    if _failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
