# Tally MCP Project

## Quick Reference
- Python project: `src/tally_mcp/` is the package, `scripts/` has test/utility scripts
- Run tests: `make test` or `.venv/Scripts/python -m pytest tests/ -q`
- Run seed script: `.venv/Scripts/python scripts/seed_test_data.py`
- Tally runs on `localhost:9000`, company name from `.env` (`TALLY_MCP_TALLY_DEFAULT_COMPANY`)
- Financial year: April 2025 - March 2026 (dates in YYYYMMDD format)

## Hard Rules

### Tally XML
- NEVER use the `OBJVIEW` XML attribute on VOUCHER tags - causes Tally memory access violation crash (c0000005)
- `build_voucher_xml` no longer emits OBJVIEW (matches official Tally Case Study 1 docs)
- Tally defaults to Accounting Voucher View when no view is specified
- JSONEx (TallyPrime 7.0+) is NOT supported on our Tally instance
- Company name must be EXACT - e.g. "Procedure Technologies Private Limited" not "Procedure Tech"
- Tally silently rejects bad vouchers with `EXCEPTIONS=1` and no error message - check the `exceptions` field in import results
- Tally may crash and need manual restart - always use `heartbeat()` before batch operations

### Amount Convention
- In VoucherEntry: positive = debit, negative = credit
- In XML: amounts are negated by `build_voucher_xml` before sending
- ISDEEMEDPOSITIVE is computed automatically from the negated XML amount sign

### Development
- Always run `make test` after changing src/ files to verify unit tests pass
- The xml_parser now extracts `exceptions` count from Tally responses
- `heartbeat(company)` checks both connectivity AND that the specific company is open
- When changing code that affects tools, config, auth, deployment, or architecture, update the corresponding `docs/` file(s) to keep documentation in sync. See `docs/index.md` for which file covers what.

## Documentation

### MCP Server Docs
`docs/` — Documentation for the MCP server itself: installation, deployment, configuration, tools, auth, multi-company, architecture. Start with `docs/index.md`.

### Tally Knowledge Pack
`tally-development-knowledge-pack/` — Tally integration reference (XML formats, crash patterns, debugging, TDL). Each file has YAML frontmatter with `tags` and `sources`. Start with `tally-development-knowledge-pack/INDEX.md`.

### When to consult

**BEFORE planning or implementing** any Tally integration work:
1. Check `12-project-lessons.md` for battle-tested findings from this project
2. Check the relevant knowledge pack file(s) for broader patterns and examples
3. Follow source URLs in knowledge pack files if you need deeper detail

**WHEN troubleshooting** Tally errors, crashes, or unexpected behavior:
1. Check `12-project-lessons.md` first (aggregated tested findings)
2. Check `10-reliability-and-gotchas.md` for broader patterns

**WHEN discovering something new** about Tally behavior:
1. Update `12-project-lessons.md` with the finding
2. If broadly relevant, also update the corresponding knowledge pack file

### Lookup Guide

| Task | Knowledge pack file |
|------|-------------------|
| Writing/debugging voucher XML | `06-voucher-import-export.md`, `02-xml-api-reference.md` |
| Creating/modifying masters | `05-master-import-export.md` |
| Tally crashes or connection drops | `10-reliability-and-gotchas.md`, `12-project-lessons.md` |
| Export/report queries | `04-report-export-patterns.md` |
| Debugging Tally rejections | `10-reliability-and-gotchas.md`, `12-project-lessons.md` |
| Planning new MCP tools | `11-mcp-server-design.md`, `09-existing-tools-and-libraries.md` |
| TDL / custom collections | `07-tdl-essentials.md` |
| JSON/JSONEx integration | `03-json-api-reference.md`, `12-project-lessons.md` (JSONEx status) |
| ODBC / SQL access | `08-odbc-integration.md` |
| Architecture decisions | `01-integration-overview.md`, `11-mcp-server-design.md` |
| Finding reference code | `09-existing-tools-and-libraries.md` |
