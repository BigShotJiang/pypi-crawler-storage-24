from tally_mcp.confirm import summarize_import_xml
from tally_mcp.tally_client import TallyClient
from tally_mcp.voucher_builder import build_ledger_xml, build_voucher_xml, build_group_xml, build_stock_item_xml
from tally_mcp.models import LedgerCreate, VoucherCreate, VoucherEntry, GroupCreate, StockItemCreate


def _build_envelope(data_xml: str, company: str = "Test Co", request_type: str = "All Masters") -> bytes:
    """Helper: build a full import envelope for testing summaries."""
    client = TallyClient(default_company=company)
    return client.build_import_xml(data_xml, request_type=request_type, company=company)


class TestSummarizeCreateLedger:
    def test_basic_ledger(self):
        ledger = LedgerCreate(name="HDFC Bank", parent="Bank Accounts")
        xml = build_ledger_xml(ledger)
        envelope = _build_envelope(xml)
        summary = summarize_import_xml(envelope)
        assert "Company: Test Co" in summary
        assert "Create Ledger: HDFC Bank" in summary
        assert "under Bank Accounts" in summary

    def test_ledger_with_gst(self):
        ledger = LedgerCreate(name="Customer A", parent="Sundry Debtors", gst_number="29ABCDE1234F1Z5")
        xml = build_ledger_xml(ledger)
        envelope = _build_envelope(xml)
        summary = summarize_import_xml(envelope)
        assert "GSTIN 29ABCDE1234F1Z5" in summary

    def test_alter_ledger(self):
        ledger = LedgerCreate(name="Old Ledger", parent="Sales Accounts")
        xml = build_ledger_xml(ledger, action="Alter")
        envelope = _build_envelope(xml)
        summary = summarize_import_xml(envelope)
        assert "Alter Ledger: Old Ledger" in summary


class TestSummarizeCreateVoucher:
    def test_journal_voucher(self):
        voucher = VoucherCreate(
            voucher_type="Journal",
            date="20250415",
            narration="Test journal",
            entries=[
                VoucherEntry(ledger_name="Cash", amount=1000),
                VoucherEntry(ledger_name="Sales", amount=-1000),
            ],
        )
        xml = build_voucher_xml(voucher)
        envelope = _build_envelope(xml, request_type="Vouchers")
        summary = summarize_import_xml(envelope)
        assert "Company: Test Co" in summary
        assert "Create Journal voucher on 15-Apr-2025" in summary
        assert "Cash" in summary
        assert "Sales" in summary
        assert "1,000.00" in summary

    def test_sales_voucher_with_party(self):
        voucher = VoucherCreate(
            voucher_type="Sales",
            date="20250601",
            party_name="Customer A",
            reference="INV-001",
            entries=[
                VoucherEntry(ledger_name="Customer A", amount=5000),
                VoucherEntry(ledger_name="Sales Account", amount=-5000),
            ],
        )
        xml = build_voucher_xml(voucher)
        envelope = _build_envelope(xml, request_type="Vouchers")
        summary = summarize_import_xml(envelope)
        assert "Party: Customer A" in summary
        assert "Ref: INV-001" in summary

    def test_cancel_voucher(self):
        cancel_xml = '''<VOUCHER VCHTYPE="Sales" ACTION="Cancel">
        <VOUCHERNUMBER>101</VOUCHERNUMBER>
        <DATE>20250415</DATE>
        <VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>
        </VOUCHER>'''
        envelope = _build_envelope(cancel_xml, request_type="Vouchers")
        summary = summarize_import_xml(envelope)
        assert "CANCEL Sales voucher #101" in summary


class TestSummarizeGroup:
    def test_create_group(self):
        group = GroupCreate(name="Online Sales", parent="Sales Accounts")
        xml = build_group_xml(group)
        envelope = _build_envelope(xml)
        summary = summarize_import_xml(envelope)
        assert "Create Group: Online Sales under Sales Accounts" in summary


class TestSummarizeStockItem:
    def test_create_stock_item(self):
        item = StockItemCreate(name="Widget", unit="Nos", hsn_code="8471", gst_rate=18.0)
        xml = build_stock_item_xml(item)
        envelope = _build_envelope(xml)
        summary = summarize_import_xml(envelope)
        assert "Create Stock Item: Widget" in summary
        assert "HSN 8471" in summary
        assert "GST 18.0%" in summary


class TestSummarizeBulk:
    def test_multiple_ledgers(self):
        ledgers = [
            LedgerCreate(name="Ledger A", parent="Sundry Debtors"),
            LedgerCreate(name="Ledger B", parent="Sundry Creditors"),
        ]
        xml = "\n".join(build_ledger_xml(l) for l in ledgers)
        envelope = _build_envelope(xml)
        summary = summarize_import_xml(envelope)
        assert "1." in summary
        assert "2." in summary
        assert "Ledger A" in summary
        assert "Ledger B" in summary


class TestCompanyDisplay:
    def test_company_shown_in_summary(self):
        ledger = LedgerCreate(name="Test", parent="Cash-in-Hand")
        xml = build_ledger_xml(ledger)
        envelope = _build_envelope(xml, company="My Real Company Pvt Ltd")
        summary = summarize_import_xml(envelope)
        assert "Company: My Real Company Pvt Ltd" in summary
