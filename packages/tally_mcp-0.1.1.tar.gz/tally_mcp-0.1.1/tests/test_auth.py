"""Tests for tally_mcp.auth module."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from tally_mcp.auth import (
    ScopedTokenVerifier,
    get_auth_provider,
    verify_token,
)


# ---------- verify_token (synchronous helper) ----------


class TestVerifyToken:
    def test_matching_tokens(self):
        assert verify_token("secret-abc-123", "secret-abc-123") is True

    def test_mismatched_tokens(self):
        assert verify_token("wrong-token", "secret-abc-123") is False

    def test_empty_provided_token(self):
        assert verify_token("", "secret-abc-123") is False

    def test_empty_expected_token(self):
        assert verify_token("any-token", "") is False

    def test_both_empty(self):
        assert verify_token("", "") is False


# ---------- ScopedTokenVerifier (async) ----------


class TestScopedTokenVerifier:
    @pytest.mark.asyncio
    async def test_legacy_valid_token_returns_access_token(self):
        with patch("tally_mcp.auth.settings") as mock_settings:
            mock_settings.auth_token = "my-secret"
            verifier = ScopedTokenVerifier()
            result = await verifier.verify_token("my-secret")
            assert result is not None
            assert result.token == "my-secret"
            assert result.client_id == "tally-mcp-client"
            assert result.scopes == ["*"]

    @pytest.mark.asyncio
    async def test_invalid_token_returns_none(self):
        with patch("tally_mcp.auth.settings") as mock_settings:
            mock_settings.auth_token = "my-secret"
            verifier = ScopedTokenVerifier()
            result = await verifier.verify_token("wrong")
            assert result is None

    @pytest.mark.asyncio
    async def test_empty_token_returns_none(self):
        with patch("tally_mcp.auth.settings") as mock_settings:
            mock_settings.auth_token = "my-secret"
            verifier = ScopedTokenVerifier()
            result = await verifier.verify_token("")
            assert result is None


# ---------- get_auth_provider factory ----------


class TestGetAuthProvider:
    def test_returns_verifier_when_legacy_token_set(self):
        with patch("tally_mcp.auth.settings") as mock_settings, \
             patch("tally_mcp.auth._get_token_manager") as mock_tm:
            mock_settings.auth_token = "secret-123"
            mock_registry = mock_tm.return_value.load.return_value
            mock_registry.tokens = {}
            provider = get_auth_provider()
            assert isinstance(provider, ScopedTokenVerifier)

    def test_returns_none_when_no_auth(self):
        with patch("tally_mcp.auth.settings") as mock_settings, \
             patch("tally_mcp.auth._get_token_manager") as mock_tm:
            mock_settings.auth_token = ""
            mock_registry = mock_tm.return_value.load.return_value
            mock_registry.tokens = {}
            provider = get_auth_provider()
            assert provider is None
