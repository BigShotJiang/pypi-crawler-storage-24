import json
import pytest

from tally_mcp.company_config import (
    BusinessConfig,
    CompaniesConfig,
    CompanyRouter,
    ResolvedCompany,
    TallyCompanyEntry,
)


@pytest.fixture
def multi_company_config():
    return CompaniesConfig(businesses=[
        BusinessConfig(
            name="ABC Corp",
            aliases=["abc", "ABC"],
            tally_companies=[
                TallyCompanyEntry(
                    company="ABC Corp FY2022-24",
                    from_date="20220401",
                    to_date="20240331",
                ),
                TallyCompanyEntry(
                    company="ABC Corp FY2024-26",
                    from_date="20240401",
                    to_date="20260331",
                ),
            ],
            default_company="ABC Corp FY2024-26",
        ),
        BusinessConfig(
            name="XYZ Ltd",
            tally_companies=[
                TallyCompanyEntry(
                    company="XYZ Limited",
                    from_date="20230401",
                    to_date="20260331",
                ),
            ],
            default_company="XYZ Limited",
        ),
    ])


@pytest.fixture
def router(multi_company_config):
    return CompanyRouter(
        multi_company_config,
        fallback_company="Default Co",
    )


class TestCompanyRouter:
    def test_exact_company_match(self, router):
        r = router.resolve(company="ABC Corp FY2022-24")
        assert r.company == "ABC Corp FY2022-24"
        assert r.business_name == "ABC Corp"

    def test_exact_company_case_insensitive(self, router):
        r = router.resolve(company="abc corp fy2022-24")
        assert r.company == "ABC Corp FY2022-24"

    def test_business_with_date_routes_correctly(self, router):
        # Date in FY2022-24 range
        r = router.resolve(business="ABC Corp", from_date="20230101")
        assert r.company == "ABC Corp FY2022-24"

        # Date in FY2024-26 range
        r = router.resolve(business="ABC Corp", from_date="20250101")
        assert r.company == "ABC Corp FY2024-26"

    def test_business_without_date_uses_default(self, router):
        r = router.resolve(business="ABC Corp")
        assert r.company == "ABC Corp FY2024-26"

    def test_alias_resolves(self, router):
        r = router.resolve(business="abc")
        assert r.company == "ABC Corp FY2024-26"
        assert r.business_name == "ABC Corp"

    def test_fallback_when_nothing_specified(self, router):
        r = router.resolve()
        assert r.company == "Default Co"

    def test_unknown_company_uses_as_is(self, router):
        r = router.resolve(company="Some Unknown Co")
        assert r.company == "Some Unknown Co"


class TestCompaniesConfig:
    def test_roundtrip_json(self, multi_company_config):
        dumped = json.dumps(multi_company_config.model_dump(), indent=2)
        loaded = CompaniesConfig(**json.loads(dumped))
        assert len(loaded.businesses) == 2
        assert loaded.businesses[0].name == "ABC Corp"
        assert len(loaded.businesses[0].tally_companies) == 2

    def test_empty_config(self):
        config = CompaniesConfig()
        assert config.businesses == []
        router = CompanyRouter(config, fallback_company="Fallback")
        r = router.resolve()
        assert r.company == "Fallback"
