"""Tests for tally_mcp.token_manager module."""

import json

import pytest

from tally_mcp.token_manager import TokenManager


@pytest.fixture
def tm(tmp_path):
    return TokenManager(tmp_path)


class TestTokenManager:
    def test_generate_admin_token(self, tm):
        token = tm.generate_admin_token()
        assert token.startswith("tmcp_adm_")
        assert len(token) == 9 + 12  # prefix + 12 hex chars

    def test_generate_company_token(self, tm):
        token = tm.generate_company_token("My Company")
        assert token.startswith("tmcp_co_")
        assert len(token) == 8 + 12

    def test_validate_valid_token(self, tm):
        token = tm.generate_admin_token()
        entry = tm.validate(token)
        assert entry is not None
        assert entry.companies == ["*"]
        assert entry.last_used is not None

    def test_validate_invalid_token(self, tm):
        assert tm.validate("tmcp_adm_nonexistent") is None

    def test_validate_empty_token(self, tm):
        assert tm.validate("") is None

    def test_can_access_admin(self, tm):
        token = tm.generate_admin_token()
        assert tm.can_access(token, "Any Company") is True

    def test_can_access_scoped(self, tm):
        token = tm.generate_company_token("My Company")
        assert tm.can_access(token, "My Company") is True
        assert tm.can_access(token, "Other Company") is False

    def test_can_access_invalid_token(self, tm):
        assert tm.can_access("bad_token", "My Company") is False

    def test_revoke(self, tm):
        token = tm.generate_admin_token()
        assert tm.revoke(token) is True
        assert tm.validate(token) is None

    def test_revoke_nonexistent(self, tm):
        assert tm.revoke("tmcp_adm_nonexistent") is False

    def test_cycle_token(self, tm):
        old = tm.generate_company_token("My Company")
        new = tm.cycle_token(old)
        assert new is not None
        assert new != old
        assert new.startswith("tmcp_co_")
        # Old is revoked
        assert tm.validate(old) is None
        # New works
        assert tm.can_access(new, "My Company") is True

    def test_cycle_admin_token(self, tm):
        old = tm.generate_admin_token()
        new = tm.cycle_token(old)
        assert new.startswith("tmcp_adm_")
        assert tm.can_access(new, "Any Company") is True

    def test_cycle_invalid_token(self, tm):
        assert tm.cycle_token("bad_token") is None

    def test_find_by_prefix(self, tm):
        token = tm.generate_admin_token()
        found = tm.find_by_prefix(token[:8])
        assert found == token

    def test_find_by_prefix_not_found(self, tm):
        assert tm.find_by_prefix("tmcp_xx_") is None

    def test_list_tokens(self, tm):
        tm.generate_admin_token()
        tm.generate_company_token("Co A")
        tokens = tm.list_tokens()
        assert len(tokens) == 2
        # Tokens are redacted
        for t in tokens:
            assert "..." in t["token_hint"]

    def test_persistence(self, tmp_path):
        tm1 = TokenManager(tmp_path)
        token = tm1.generate_admin_token()

        # New instance loads from disk
        tm2 = TokenManager(tmp_path)
        entry = tm2.validate(token)
        assert entry is not None
        assert entry.companies == ["*"]

    def test_empty_registry(self, tm):
        assert tm.list_tokens() == []
        reg = tm.load()
        assert reg.tokens == {}
