import pytest

from tally_mcp.tally_client import TallyClient, TallyError


@pytest.fixture
def client():
    c = TallyClient(
        host="localhost",
        port=9000,
        default_company="Test Co",
    )
    # Pre-set to XML so auto-detection doesn't make unmocked HTTP requests
    c._json_supported = False
    return c


class TestTallyClient:
    async def test_health_check_success(self, client, httpx_mock):
        httpx_mock.add_response(
            url="http://localhost:9000",
            content=b"<ENVELOPE><BODY><DATA><COLLECTION><COMPANY><NAME>Test Co</NAME></COMPANY></COLLECTION></DATA></BODY></ENVELOPE>",
        )
        result = await client.health_check()
        assert result["status"] == "ok"
        assert "Test Co" in result["companies"]

    async def test_list_companies(self, client, httpx_mock):
        httpx_mock.add_response(
            url="http://localhost:9000",
            content=b"<ENVELOPE><BODY><DATA><COLLECTION><COMPANY><NAME>Co A</NAME></COMPANY><COMPANY><NAME>Co B</NAME></COMPANY></COLLECTION></DATA></BODY></ENVELOPE>",
        )
        companies = await client.list_companies()
        assert len(companies) == 2

    async def test_request_failure_raises(self, client, httpx_mock):
        httpx_mock.add_response(url="http://localhost:9000", status_code=500)
        with pytest.raises(TallyError):
            await client.list_companies()

    async def test_export_collection(self, client, httpx_mock):
        httpx_mock.add_response(
            url="http://localhost:9000",
            content=b"<ENVELOPE><BODY><DATA><COLLECTION><LEDGER NAME='Cash'><NAME>Cash</NAME><PARENT>Cash-in-Hand</PARENT></LEDGER></COLLECTION></DATA></BODY></ENVELOPE>",
        )
        ledgers = await client.export_collection("List of Ledgers", "LEDGER")
        assert len(ledgers) == 1
        assert ledgers[0]["NAME"] == "Cash"

    async def test_export_report(self, client, httpx_mock):
        httpx_mock.add_response(
            url="http://localhost:9000",
            content=b"<ENVELOPE><BODY><DATA>some report data</DATA></BODY></ENVELOPE>",
        )
        result = await client.export_report("Trial Balance")
        assert "DATA" in result

    async def test_import_data(self, client, httpx_mock):
        httpx_mock.add_response(
            url="http://localhost:9000",
            content=b"<ENVELOPE><HEADER><VERSION>1</VERSION><STATUS>1</STATUS></HEADER><BODY><DATA><IMPORTRESULT><CREATED>1</CREATED><ALTERED>0</ALTERED><LASTVCHID>123</LASTVCHID></IMPORTRESULT></DATA></BODY></ENVELOPE>",
        )
        result = await client.import_data(
            "<LEDGER ACTION='Create'><NAME>Test</NAME><PARENT>Sundry Debtors</PARENT></LEDGER>"
        )
        assert result["created"] == 1
