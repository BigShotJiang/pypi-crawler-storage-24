from pathlib import Path

from tally_mcp.xml_parser import (
    parse_collection,
    parse_import_result,
    parse_response_status,
)

FIXTURES = Path(__file__).parent / "fixtures"


def test_parse_collection_companies():
    xml_bytes = (FIXTURES / "list_companies.xml").read_bytes()
    items = parse_collection(xml_bytes, "COMPANY")
    assert len(items) == 2
    assert items[0]["NAME"] == "ABC Company Pvt Ltd"
    assert items[1]["NAME"] == "XYZ Traders"


def test_parse_collection_ledgers():
    xml_bytes = (FIXTURES / "ledger_list.xml").read_bytes()
    items = parse_collection(xml_bytes, "LEDGER")
    assert len(items) == 2
    assert items[0]["NAME"] == "Cash"
    assert items[0]["PARENT"] == "Cash-in-Hand"
    assert items[1]["NAME"] == "Sales Account"


def test_parse_import_result_success():
    xml_bytes = (FIXTURES / "import_success.xml").read_bytes()
    result = parse_import_result(xml_bytes)
    assert result["created"] == 1
    assert result["altered"] == 0
    assert result["last_vch_id"] == "12345"
    assert result["errors"] == []


def test_parse_import_result_error():
    xml_bytes = (FIXTURES / "import_error.xml").read_bytes()
    result = parse_import_result(xml_bytes)
    assert result["created"] == 0
    assert len(result["errors"]) > 0


def test_parse_response_status_success():
    xml_bytes = (FIXTURES / "import_success.xml").read_bytes()
    assert parse_response_status(xml_bytes) is True


def test_parse_response_status_failure():
    xml_bytes = (FIXTURES / "import_error.xml").read_bytes()
    assert parse_response_status(xml_bytes) is False
