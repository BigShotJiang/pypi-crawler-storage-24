from lxml import etree

from tally_mcp.voucher_builder import build_ledger_xml, build_voucher_xml
from tally_mcp.models import LedgerCreate, VoucherCreate, VoucherEntry


def test_build_ledger_xml():
    ledger = LedgerCreate(name="Test Party", parent="Sundry Debtors", opening_balance=5000.0)
    xml = build_ledger_xml(ledger)
    root = etree.fromstring(xml.encode())
    assert root.tag == "LEDGER"
    assert root.attrib["ACTION"] == "Create"
    assert root.findtext("NAME") == "Test Party"
    assert root.findtext("PARENT") == "Sundry Debtors"
    assert root.findtext("OPENINGBALANCE") == "5000.0"


def test_build_voucher_xml_journal():
    voucher = VoucherCreate(
        voucher_type="Journal",
        date="20250415",
        narration="Test journal entry",
        entries=[
            VoucherEntry(ledger_name="Office Rent", amount=10000),
            VoucherEntry(ledger_name="Cash", amount=-10000),
        ],
    )
    xml = build_voucher_xml(voucher)
    root = etree.fromstring(xml.encode())
    assert root.tag == "VOUCHER"
    assert root.attrib["VCHTYPE"] == "Journal"
    assert root.findtext("DATE") == "20250415"
    entries = root.findall("ALLLEDGERENTRIES.LIST")
    assert len(entries) == 2
