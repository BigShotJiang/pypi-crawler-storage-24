from lxml import etree

from tally_mcp.xml_builder import (
    build_export_report_request,
    build_export_collection_request,
    build_import_request,
)


def test_export_report_request_basic():
    xml = build_export_report_request(
        report_name="Trial Balance",
        company="Test Co",
    )
    root = etree.fromstring(xml)
    assert root.tag == "ENVELOPE"
    header = root.find("HEADER")
    assert header.findtext("TALLYREQUEST") == "Export"
    assert header.findtext("TYPE") == "Data"
    assert header.findtext("ID") == "Trial Balance"
    body = root.find("BODY")
    sv = body.find(".//STATICVARIABLES")
    assert sv.findtext("SVCURRENTCOMPANY") == "Test Co"
    assert sv.findtext("SVEXPORTFORMAT") == "$$SysName:XML"


def test_export_report_request_with_auth():
    xml = build_export_report_request(
        report_name="Trial Balance",
        company="Test Co",
        username="admin",
        password="secret",
    )
    root = etree.fromstring(xml)
    sv = root.find(".//STATICVARIABLES")
    assert sv.findtext("SVUSERNAME") == "admin"
    assert sv.findtext("SVPASSWORD") == "secret"


def test_export_report_request_with_date_range():
    xml = build_export_report_request(
        report_name="Day Book",
        company="Test Co",
        from_date="20250401",
        to_date="20260331",
    )
    root = etree.fromstring(xml)
    sv = root.find(".//STATICVARIABLES")
    assert sv.findtext("SVFROMDATE") == "20250401"
    assert sv.findtext("SVTODATE") == "20260331"


def test_export_collection_request():
    xml = build_export_collection_request(
        collection_name="List of Ledgers",
        company="Test Co",
    )
    root = etree.fromstring(xml)
    header = root.find("HEADER")
    assert header.findtext("TYPE") == "Collection"
    assert header.findtext("ID") == "List of Ledgers"


def test_import_request_ledger():
    ledger_xml = "<LEDGER NAME='Test Ledger' ACTION='Create'><NAME>Test Ledger</NAME><PARENT>Sundry Debtors</PARENT></LEDGER>"
    xml = build_import_request(
        data_xml=ledger_xml,
        request_type="All Masters",
        company="Test Co",
    )
    root = etree.fromstring(xml)
    header = root.find("HEADER")
    assert header.findtext("TALLYREQUEST") == "Import Data"
