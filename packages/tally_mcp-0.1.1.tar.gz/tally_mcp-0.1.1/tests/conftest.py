import pytest


@pytest.fixture
def tally_url():
    return "http://localhost:9000"
