import pytest

from tally_mcp.server import mcp


@pytest.mark.asyncio
async def test_write_tools_registered():
    tools = await mcp.list_tools()
    tool_names = [t.name for t in tools]
    expected = [
        "create_ledger",
        "alter_ledger",
        "create_group",
        "create_stock_item",
        "create_voucher",
        "cancel_voucher",
    ]
    for name in expected:
        assert name in tool_names, f"Tool '{name}' not registered"
