import pytest

from tally_mcp.server import mcp


@pytest.mark.asyncio
async def test_bulk_tools_registered():
    tools = await mcp.list_tools()
    tool_names = [t.name for t in tools]
    expected = [
        "bulk_create_ledgers",
        "bulk_create_vouchers",
        "import_csv_ledgers",
        "import_csv_vouchers",
        "execute_custom_query",
    ]
    for name in expected:
        assert name in tool_names, f"Tool '{name}' not registered"
