import pytest

from tally_mcp.server import mcp


@pytest.mark.asyncio
async def test_read_tools_registered():
    tools = await mcp.list_tools()
    tool_names = [t.name for t in tools]
    expected = [
        "list_companies",
        "list_ledgers",
        "get_ledger",
        "list_groups",
        "list_stock_items",
        "get_stock_item",
        "list_voucher_types",
        "get_trial_balance",
        "get_balance_sheet",
        "get_profit_and_loss",
        "get_day_book",
        "get_stock_summary",
        "get_sales_register",
        "get_purchase_register",
        "get_receivables",
        "get_payables",
        "get_bank_book",
        "get_ledger_vouchers",
        "get_group_summary",
        "health_check",
    ]
    for name in expected:
        assert name in tool_names, f"Tool '{name}' not registered"
