# TODO

## High Priority

- [x] **Add file logging** - RotatingFileHandler in `server.py` logs all MCP tool calls, Tally XML requests/responses, and errors to `tally-mcp.log` with timestamps.

## Features

- [ ] GST report tools (GSTR-1, GSTR-3B summary)
- [ ] Cost centre reports
- [ ] Godown/warehouse reports
- [ ] Voucher alteration tool (modify existing vouchers)
- [ ] Multi-currency support
- [ ] Voucher search/lookup by number

## Performance

- [ ] Caching layer for frequently-accessed master data (ledger list, groups)
- [ ] Connection pooling for Tally HTTP client
- [ ] Rate limiting on write operations

## Packaging & Deployment

- [x] Windows service installer (WinSW-based, auto-starts on boot)
- [ ] Docker packaging
- [x] PyPI publishing (tally-mcp 0.1.0)
- [ ] Configuration wizard / setup UI

## Remote Access (via Cloudflare Tunnel)

- [x] MCP server accessible remotely via `tally.procedure.tech/mcp`
- [x] cloudflared + tally-mcp as Windows services (auto-start on reboot)
- [ ] **Remote license validation** — expose Tally Gateway Server (port 9999) via Cloudflare private network + WARP client so remote TallyPrime instances can use the office Gold license. Partially set up: private CIDR route (`192.168.29.126/32`) added, still need Split Tunnel config and WARP enrollment. Note: remote TallyPrime still needs its own license, but can use office data via Tally.NET (requires active TSS).
- [ ] **Remote shared drive access** — expose Tally data folder (SMB/CIFS) to remote users via Cloudflare private network + WARP. Same CIDR route covers both this and license server.

### TallyPrime Port Reference

| Port | Protocol | Purpose |
|------|----------|---------|
| 9000 | TCP/HTTP | Tally XML API (data communication, ODBC) |
| 9090 | TCP | Tally Gateway Server (Gold multi-user routing) |
| 9999 | TCP | Tally License Server (license sharing on LAN) |
| 80 | TCP | Cloud license validation (`licensing.tallysolutions.com`) |
| 9050 | TCP | Tally.NET sync & remote access (`tallyenterprise.com`) |
| 443 | TCP | e-Invoice, e-Way Bill, browser reports |
| 9009 | TCP | Tally Reports in Browser |
| 10089 | TCP | Tally Scheduler |

### Cloudflare Private Network Setup (in progress)

Both remote license and shared drive need the same infrastructure:
1. ~~Private CIDR route `192.168.29.126/32` → tunnel `tally-mcp`~~ (done)
2. Split Tunnel config — ensure `192.168.29.0/24` routes through WARP (not done)
3. WARP client installed and enrolled on each remote machine (not done)
4. Test: `ping 192.168.29.126` from WARP-enrolled machine (not done)

## Observability

- [ ] **Remote log access** - MCP tool (`get_server_logs`) that returns recent log entries so a remote user/agent can diagnose issues without SSH access to the Tally machine
- [ ] **Feedback command** - MCP tool or CLI command to send error reports / feedback to the maintainer (webhook, email, or GitHub issue)
- [ ] Audit logging (who did what, when)

## Security

- [ ] Read-only mode option (disable write tools)
- [ ] IP allowlist for remote connections

## Manual notes
- What if the tally mcp responses also told the AI application to store lessons either in a memory or in a file, so agent prompts the user to check if they would like to maintain a tally personal instruction sets in a local file somewhere - and somehow it was read at the time of each session - why am I suggesting this - I asked the mcp to build be a month X customer - sales grid - it went through a cycle of iterations - tried to use sales register then realized that it only has monthly numbers - then it tried to look for sales ledgers - that did not work because it did not know what sales group is called - so then it wnet on to get all groups - then find 
