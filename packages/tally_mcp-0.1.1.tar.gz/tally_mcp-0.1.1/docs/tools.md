# Tool Reference

40 tools organized by category. All write tools require user confirmation via `ctx.elicit`.

## Utility (2)

| Tool | Parameters | Description |
|------|-----------|-------------|
| `health_check` | — | List all open companies in Tally |
| `heartbeat` | `company?` | Verify Tally is reachable and a specific company is open |

## Onboarding (4)

| Tool | Parameters | Description |
|------|-----------|-------------|
| `discover_companies` | — | Scan Tally for open companies, show what's configured vs new |
| `save_company_config` | `businesses_json` | Save multi-company config (overwrites). Requires confirmation |
| `list_businesses` | — | Show configured businesses with date ranges and status |
| `check_all_companies` | — | Heartbeat all configured companies, update status log |

## Masters — Read (7)

| Tool | Parameters | Description |
|------|-----------|-------------|
| `list_companies` | — | List all open companies |
| `list_ledgers` | `company?`, `group?` | List ledgers, optionally filtered by parent group |
| `get_ledger` | `ledger_name`, `company?`, `from_date?`, `to_date?` | Voucher report for a ledger |
| `list_groups` | `company?` | List all account groups |
| `list_stock_items` | `company?` | List all stock items |
| `get_stock_item` | `stock_item_name`, `company?` | Monthly movement for a stock item |
| `list_voucher_types` | `company?` | List all voucher types |

## Reports (13)

| Tool | Parameters | Description |
|------|-----------|-------------|
| `get_trial_balance` | `company?`, `from_date?`, `to_date?` | Trial Balance with group expansion |
| `get_balance_sheet` | `company?`, `from_date?`, `to_date?` | Balance Sheet |
| `get_profit_and_loss` | `company?`, `from_date?`, `to_date?` | Profit & Loss statement |
| `get_day_book` | `company?`, `from_date?`, `to_date?`, `voucher_type?` | All vouchers, optionally filtered |
| `get_stock_summary` | `company?` | Stock items with quantities and values |
| `get_sales_register` | `company?`, `from_date?`, `to_date?` | Sales Register (period totals only) |
| `get_sales_by_party` | `company?`, `from_date?`, `to_date?`, `voucher_type?`, `group_by?` | Party × month grid for Sales/Purchase vouchers. Single call replaces per-customer queries |
| `get_purchase_register` | `company?`, `from_date?`, `to_date?` | Purchase Register |
| `get_receivables` | `company?` | Outstanding receivables / bills receivable |
| `get_payables` | `company?` | Outstanding payables / bills payable |
| `get_bank_book` | `ledger_name`, `company?`, `from_date?`, `to_date?` | Cash/Bank book for a ledger |
| `get_ledger_vouchers` | `ledger_name`, `company?`, `from_date?`, `to_date?` | All vouchers for a ledger |
| `get_group_summary` | `group_name`, `company?`, `from_date?`, `to_date?` | Ledger summary under a group |

## Write — Masters (4)

All require explicit `company` parameter and user confirmation.

| Tool | Parameters | Description |
|------|-----------|-------------|
| `create_ledger` | `name`, `parent`, `company`, `opening_balance?`, `address?`, `gst_number?` | Create a ledger |
| `alter_ledger` | `name`, `company`, `parent?`, `opening_balance?`, `address?`, `gst_number?` | Modify an existing ledger |
| `create_group` | `name`, `parent`, `company` | Create an account group |
| `create_stock_item` | `name`, `company`, `parent?`, `unit?`, `hsn_code?`, `gst_rate?` | Create a stock item |

## Write — Vouchers (2)

| Tool | Parameters | Description |
|------|-----------|-------------|
| `create_voucher` | `voucher_type`, `date`, `entries`, `company`, `party_name?`, `narration?`, `reference?`, `is_invoice?`, `inventory_entries?` | Create any voucher type |
| `cancel_voucher` | `voucher_type`, `voucher_number`, `date`, `company` | Cancel a voucher |

Supported voucher types: Sales, Purchase, Payment, Receipt, Journal, Contra, Credit Note, Debit Note.

## Bulk (5)

| Tool | Parameters | Description |
|------|-----------|-------------|
| `bulk_create_ledgers` | `ledgers_json`, `company` | Create multiple ledgers from JSON array |
| `bulk_create_vouchers` | `vouchers_json`, `company` | Create multiple vouchers from JSON array |
| `import_csv_ledgers` | `csv_data`, `company` | Import ledgers from CSV string |
| `import_csv_vouchers` | `csv_data`, `voucher_type`, `company` | Import vouchers from CSV (grouped by reference) |
| `execute_custom_query` | `xml_request`, `company?` | Raw XML request to Tally |

## Token Management (3)

| Tool | Parameters | Description |
|------|-----------|-------------|
| `generate_tokens` | — | Generate admin + per-company tokens. Shown once only. Confirmation required |
| `cycle_token` | `token_prefix` | Replace a token (same scope). Old one revoked immediately |
| `list_tokens` | — | List active tokens with redacted hints and scopes |

## Common Patterns

**Dates**: YYYYMMDD format. Indian FY runs April-March (e.g., FY 2025-26 = `20250401` to `20260331`).

**Amounts**: In tool parameters: positive = debit, negative = credit. In reports: same convention.

**Company parameter**: Optional on read tools (uses default from config). Required on all write tools to prevent accidental writes.

**Confirmation**: All write tools show a summary and require explicit user approval before sending to Tally.

**Access control**: Every tool with a `company` parameter checks the current token's scope. See [authentication.md](authentication.md).
