# Multi-Company Setup

## Concepts

| Term | Meaning |
|------|---------|
| **Business** | A logical entity the user refers to (e.g., "Acme Corp") |
| **Tally company** | A physical company file in TallyPrime (e.g., "Acme Corp FY2024-26") |
| **Routing** | Mapping a business name + date to the correct Tally company |

One business can have **multiple Tally companies**, typically split by financial year. The router picks the right one automatically.

## Onboarding Flow

### Step 1: Discover

```
"Scan Tally for open companies"
→ discover_companies()
```

Returns: list of open companies, which are already configured, which are new.

### Step 2: Configure

The agent discusses with the user:
- Which companies belong to the same business? (group them)
- What date range does each cover? (`from_date`, `to_date` in YYYYMMDD)
- What's a friendly business name? Any aliases?
- Which company is the default? (usually the most recent FY)

Then:

```
→ save_company_config(businesses_json)
```

Writes `companies.json` to the [config directory](configuration.md).

### Step 3 (optional): Generate Tokens

Only needed for HTTP/remote deployment:

```
→ generate_tokens()
```

See [authentication.md](authentication.md).

## Date-Based Routing

`CompanyRouter` resolves queries with this priority:

1. **Exact company name** — e.g., `company="Acme Corp FY2022-24"`
2. **Business name + date** — e.g., `business="Acme Corp", from_date="20230601"` routes to the company whose date range includes that date
3. **Business name, no date** — uses the business's `default_company`
4. **Nothing specified** — falls back to `TALLY_MCP_TALLY_DEFAULT_COMPANY` from env

Company name matching is **case-insensitive**.

Source: `src/tally_mcp/company_config.py:CompanyRouter.resolve()`

## Business Aliases

Alternative names the user might use. Configured in `save_company_config`:

```json
{
  "name": "Acme Corporation Pvt Ltd",
  "aliases": ["Acme", "acme corp", "AC"]
}
```

Alias matching is case-insensitive. The router checks business names first, then aliases.

## Heartbeat Tracking

The server tracks last-known status for each company in `companies_status.json`:

- **last_seen**: timestamp of last successful contact
- **is_open**: whether the company was open at last check
- **transport**: `"xml"` or `"json"` (detected protocol)

Updated automatically by:
- `heartbeat()` — single company
- `discover_companies()` — all found companies
- `check_all_companies()` — all configured + open companies

`list_businesses()` shows this status alongside the configuration.

## companies.json Schema

```json
{
  "businesses": [
    {
      "name": "Acme Corp",
      "aliases": ["acme", "AC"],
      "tally_companies": [
        {
          "company": "Acme Corp FY2022-24",
          "from_date": "20220401",
          "to_date": "20240331"
        },
        {
          "company": "Acme Corp FY2024-26",
          "from_date": "20240401",
          "to_date": "20260331"
        }
      ],
      "default_company": "Acme Corp FY2024-26"
    }
  ]
}
```
