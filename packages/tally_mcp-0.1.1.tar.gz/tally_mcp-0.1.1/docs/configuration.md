# Configuration Reference

## Environment Variables

All variables use the `TALLY_MCP_` prefix (pydantic-settings convention).

| Variable | Default | Description |
|----------|---------|-------------|
| `TALLY_MCP_TALLY_HOST` | `localhost` | TallyPrime hostname |
| `TALLY_MCP_TALLY_PORT` | `9000` | TallyPrime server port |
| `TALLY_MCP_TALLY_DEFAULT_COMPANY` | `""` | Default company name (must be exact) |
| `TALLY_MCP_TALLY_USERNAME` | `""` | Tally XML auth username (if protected) |
| `TALLY_MCP_TALLY_PASSWORD` | `""` | Tally XML auth password |
| `TALLY_MCP_SERVER_HOST` | `0.0.0.0` | HTTP server bind address |
| `TALLY_MCP_SERVER_PORT` | `8765` | HTTP server port |
| `TALLY_MCP_AUTH_TOKEN` | `""` | Legacy single auth token (see [authentication.md](authentication.md)) |
| `TALLY_MCP_TRANSPORT` | — | Set to `http` to force HTTP transport |
| `TALLY_MCP_CONFIG_DIR` | — | Override config directory path |

Source: `src/tally_mcp/config.py`

## Config Directory

### Location

| Platform | Default path |
|----------|-------------|
| Windows | `%APPDATA%\tally-mcp\` |
| Linux/macOS | `~/.config/tally-mcp/` (or `$XDG_CONFIG_HOME/tally-mcp/`) |

Override with `TALLY_MCP_CONFIG_DIR` env var.

Source: `src/tally_mcp/company_config.py:_config_dir()`

### Files

| File | Created by | Purpose |
|------|-----------|---------|
| `companies.json` | `save_company_config()` tool | Multi-company configuration |
| `companies_status.json` | Auto-updated by heartbeat | Last-seen status per company |
| `auth_tokens.json` | `generate_tokens()` tool | Scoped token registry |

## .mcp.json Examples

### Local stdio (default)

```json
{
  "mcpServers": {
    "tally": {
      "command": "uv",
      "args": ["run", "tally-mcp"],
      "env": {
        "TALLY_MCP_TALLY_PORT": "9000"
      }
    }
  }
}
```

### Remote HTTP with auth

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://your-tunnel.trycloudflare.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_x7y8z9w0v1u2"
      }
    }
  }
}
```

## .env File

For local development or direct server runs, create a `.env` file:

```bash
TALLY_MCP_TALLY_HOST=localhost
TALLY_MCP_TALLY_PORT=9000
TALLY_MCP_TALLY_DEFAULT_COMPANY=My Company Pvt Ltd
```

Not needed when env vars are passed via `.mcp.json` or system environment.
Copy `.env.example` for a template.
