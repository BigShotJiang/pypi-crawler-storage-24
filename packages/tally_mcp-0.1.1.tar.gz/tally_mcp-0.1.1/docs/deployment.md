# Deployment Patterns

## Pattern 1: Solo Local (stdio)

### When to use

- Single user on the same machine as TallyPrime
- No network exposure needed
- Simplest possible setup

### Architecture

```
┌──────────────────────────────────────────────┐
│  Your Machine                                │
│  ┌────────────┐  stdio  ┌──────────┐  XML  ┌──────────┐ │
│  │ MCP Client ├────────►│ tally-mcp├──────►│TallyPrime│ │
│  │ (Claude)   │         │          │◄──────│ :9000    │ │
│  └────────────┘         └──────────┘       └──────────┘ │
└──────────────────────────────────────────────┘
```

### Setup

1. Add to `.mcp.json` (project-level or global):

```json
{
  "mcpServers": {
    "tally": {
      "command": "uv",
      "args": ["run", "tally-mcp"],
      "env": { "TALLY_MCP_TALLY_PORT": "9000" }
    }
  }
}
```

Or via CLI:

```bash
claude mcp add tally -- uvx tally-mcp
```

2. Open TallyPrime with your company loaded
3. Start your MCP client — the server starts automatically via stdio

**No auth needed** — stdio is inherently local and single-client.

### Limitations

- One MCP client session at a time
- Client must be on the Tally machine

---

## Pattern 2: Central Remote (HTTP + Tunnel)

### When to use

- Team of users accessing one Tally instance
- MCP clients on different machines (laptops, cloud)
- Tally machine is behind NAT/firewall
- Need per-user access control

### Architecture

```
Remote MCP Clients                         Tally Machine
┌──────────────┐                    ┌──────────────────────────────┐
│ Alice (Claude)│                    │                              │
│  token: co_A  ├──HTTPS──┐         │  ┌────────────┐  ┌────────┐ │
├──────────────┤          │         │  │ tally-mcp  │  │ Tally  │ │
│ Bob (Claude)  │          ├────────►│  │ :8765      ├─►│ :9000  │ │
│  token: co_B  ├──HTTPS──┤ Tunnel  │  │ (HTTP+auth)│◄─│        │ │
├──────────────┤          │         │  └────────────┘  └────────┘ │
│ Admin (Claude)│          │         │                              │
│  token: adm   ├──HTTPS──┘         └──────────────────────────────┘
└──────────────┘
```

### Setup (on the Tally machine)

**1. Install**

```bash
pip install tally-mcp
```

**2. Configure environment**

Create a `.env` file or set env vars:

```bash
TALLY_MCP_TALLY_HOST=localhost
TALLY_MCP_TALLY_PORT=9000
TALLY_MCP_TALLY_DEFAULT_COMPANY=My Company Pvt Ltd
```

**3. Start in HTTP mode**

```bash
tally-mcp --http
```

Server binds to `0.0.0.0:8765` by default.

**4. Set up Cloudflare Tunnel**

```bash
cloudflared tunnel --url http://localhost:8765
```

This gives you a public URL like `https://random-words.trycloudflare.com`.
For a persistent subdomain, create a named tunnel.

**5. Onboard companies**

Connect with an MCP client and run:
- `discover_companies()` — find open companies
- `save_company_config()` — save the configuration

**6. Generate tokens**

```
"Generate access tokens for the team"
```

The `generate_tokens()` tool creates:
- 1 admin token (`tmcp_adm_...`) — access to all companies
- 1 token per company (`tmcp_co_...`) — scoped to that company

**Save these immediately** — they're shown only once.

**7. Distribute to team members**

Each team member adds to their MCP client config:

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://your-tunnel.trycloudflare.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_x7y8z9w0v1u2"
      }
    }
  }
}
```

### Security

- **Always use scoped tokens** — give each user only the companies they need
- **Use Cloudflare Tunnel** — never expose port 8765 directly to the internet
- **Admin token stays with the server operator** — don't distribute it
- **Cycle compromised tokens** — `cycle_token(token_prefix="tmcp_co_x7")` immediately revokes the old one and generates a replacement
- See [authentication.md](authentication.md) for full token lifecycle

---

## Choosing a Pattern

| Factor | Solo Local | Central Remote |
|--------|-----------|----------------|
| Users | 1 | Multiple |
| Auth required | No | Yes (scoped tokens) |
| Network exposure | None | Via tunnel |
| Setup complexity | Minimal | Moderate |
| MCP client location | Same machine | Anywhere |
| Transport | stdio | streamable-http |
