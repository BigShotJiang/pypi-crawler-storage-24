# Authentication

Auth is only relevant for HTTP transport. Stdio (local) has no auth — it's inherently single-user.

## Auth Modes

The server checks these in order:

### 1. Scoped Tokens (recommended)

Stored in `auth_tokens.json` in the [config directory](configuration.md). Generated via `generate_tokens()` tool.

Two token types:

| Type | Prefix | Scope | Use case |
|------|--------|-------|----------|
| Admin | `tmcp_adm_` | `["*"]` (all companies) | Server operator |
| Company | `tmcp_co_` | `["Company Name"]` | Team member with specific access |

Validated by `ScopedTokenVerifier` in `src/tally_mcp/auth.py`.

### 2. Legacy Single Token

Set via `TALLY_MCP_AUTH_TOKEN` env var. Grants full access (`["*"]` scope). For backwards compatibility — use scoped tokens instead.

### 3. No Auth

When neither scoped tokens nor legacy token are configured, auth is disabled entirely. `get_auth_provider()` returns `None` and all requests pass through.

## Token Lifecycle

```
generate_tokens()     Create admin + per-company tokens after save_company_config
       │
       ▼
  Distribute          Share company tokens with team members
       │
       ▼
  list_tokens()       View active tokens (redacted hints, not full tokens)
       │
       ▼
  cycle_token()       Replace a compromised token — old one revoked immediately
```

**Tokens are shown only once** at generation. They cannot be retrieved later. If lost, use `cycle_token()` to generate a replacement.

## Access Enforcement

`_check_access(company)` is called at the start of every tool that takes a `company` parameter.

It checks:
1. Is auth configured? If not, allow (open access).
2. Is a company specified? If not, allow (will use default).
3. Does the token's scope include `"*"`? If yes, allow (admin).
4. Does the token's scope include the specific company name? If yes, allow.
5. Otherwise, raise `AccessDeniedError`.

Source: `src/tally_mcp/server.py:_check_access()`

## MCP Client Config

Include the token as a Bearer header:

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://your-tunnel.trycloudflare.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_x7y8z9w0v1u2"
      }
    }
  }
}
```

## Token Breach Response

1. Identify the compromised token: `list_tokens()` shows hints (first 8 + last 4 chars)
2. Cycle it: `cycle_token(token_prefix="tmcp_co_x7")` — old token stops working immediately
3. Share the new token with the affected user
