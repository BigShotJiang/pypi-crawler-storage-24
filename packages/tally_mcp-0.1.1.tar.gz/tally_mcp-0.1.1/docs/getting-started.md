# Getting Started

## Prerequisites

- **Python 3.11+** on the machine running TallyPrime
- **TallyPrime** with server mode enabled (tested with 6.2 Edit Log)
- At least one company **open** in TallyPrime

### Enable TallyPrime Server Mode

1. Open TallyPrime with your company loaded
2. Press **F12** (Configure) > **Connectivity**
3. Set **"Tally Server Port"** to `9000` (or your preferred port)
4. Ensure the server is enabled

## Install

### Option A: uvx (recommended for end users)

No clone or venv needed — runs directly:

```bash
uvx tally-mcp
```

Or add to your MCP client config (see below).

### Option B: pip / development

```bash
git clone <repo-url>
cd pro-tally-mcp
make setup          # creates venv + installs editable with dev deps
```

Or manually:

```bash
python -m venv .venv
.venv/Scripts/activate   # Windows
pip install -e ".[dev]"
```

## First Run

### Local (stdio) — default

The server starts in stdio mode by default. This is the simplest setup for a single user on the same machine as Tally.

```bash
tally-mcp
```

To wire it into an MCP client, add to `.mcp.json` in your project or `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "tally": {
      "command": "uv",
      "args": ["run", "tally-mcp"],
      "env": { "TALLY_MCP_TALLY_PORT": "9000" }
    }
  }
}
```

### Remote (HTTP)

For team access or when the MCP client is on a different machine:

```bash
tally-mcp --http
```

This starts a streamable-http server on `0.0.0.0:8765`. See [deployment.md](deployment.md) for the full remote setup including tunnels and auth.

## Verify Connectivity

Once the MCP server is running and connected to your MCP client:

1. Call the `health_check` tool — it should return a list of open companies
2. Call `heartbeat` with your company name to confirm it's reachable

Or test Tally directly:

```bash
curl -s http://localhost:9000 \
  -H "Content-Type: text/xml;charset=utf-8" \
  -d '<?xml version="1.0" encoding="utf-8"?><ENVELOPE><HEADER><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>List of Companies</ID></HEADER><BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT></STATICVARIABLES></DESC></BODY></ENVELOPE>'
```

## Onboarding Flow

After first connecting, set up multi-company support:

1. **`discover_companies()`** — scans Tally for open companies
2. **Discuss with user** — grouping, date ranges, business names, aliases
3. **`save_company_config()`** — writes `companies.json` to config dir
4. **(Optional) `generate_tokens()`** — creates scoped auth tokens (only needed for HTTP/remote)

See [multi-company.md](multi-company.md) for details.

## Next Steps

- [deployment.md](deployment.md) — solo vs team setup patterns
- [configuration.md](configuration.md) — all env vars and config files
- [tools.md](tools.md) — complete tool reference
