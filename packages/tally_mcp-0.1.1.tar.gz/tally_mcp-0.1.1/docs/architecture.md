# Architecture

## Module Map

| Module | Responsibility |
|--------|---------------|
| `server.py` | FastMCP server, 39 tool definitions, entry point (`main()`) |
| `config.py` | Pydantic Settings — env var loading with `TALLY_MCP_` prefix |
| `auth.py` | `ScopedTokenVerifier`, legacy token fallback, `get_auth_provider()` |
| `token_manager.py` | Token registry CRUD — generate, validate, revoke, cycle |
| `company_config.py` | `CompaniesConfig`, `CompanyRouter`, heartbeat status, config file I/O |
| `tally_client.py` | Async httpx client, XML-over-HTTP to Tally, transport auto-detection |
| `xml_builder.py` | Builds XML request envelopes (export + import) |
| `xml_parser.py` | Parses Tally XML responses — collections, reports, import results |
| `voucher_builder.py` | Builds VOUCHER, LEDGER, GROUP, STOCKITEM XML elements |
| `models.py` | Pydantic models: `VoucherCreate`, `VoucherEntry`, `LedgerCreate`, etc. |
| `confirm.py` | `summarize_import_xml()` — human-readable write confirmation text |
| `json_builder.py` | JSON request building (for future TallyPrime 7.0+ support) |
| `json_parser.py` | JSON response parsing (for future TallyPrime 7.0+ support) |

## Request Flow — Read

```
MCP Client
    │  calls tool (e.g. get_trial_balance)
    ▼
server.py
    │  1. _check_access(company)     ← verify token scope
    │  2. get_client()               ← TallyClient singleton
    ▼
tally_client.py
    │  3. export_report() or export_collection()
    │  4. xml_builder builds XML envelope
    │  5. httpx POST to Tally (localhost:9000)
    ▼
xml_parser.py
    │  6. parse response → structured data
    ▼
MCP Client  ← result returned
```

## Request Flow — Write

```
MCP Client
    │  calls tool (e.g. create_voucher)
    ▼
server.py
    │  1. _check_access(company)
    │  2. models.py validates input (VoucherCreate, etc.)
    │  3. voucher_builder.py builds data XML
    ▼
_confirm_and_send()
    │  4. tally_client wraps in import envelope
    │  5. confirm.py generates human-readable summary
    │  6. ctx.elicit() → user sees summary, confirms or cancels
    │  7. If confirmed: httpx POST to Tally
    ▼
xml_parser.py
    │  8. parse import result (created/altered/exceptions counts)
    ▼
MCP Client  ← result with counts
```

## Transport Selection

```python
# server.py:main()
if "--http" in sys.argv or TALLY_MCP_TRANSPORT == "http":
    transport = "streamable-http"   # binds to server_host:server_port
else:
    transport = "stdio"             # single client, local
```

Auth is only active for HTTP. Determined by `get_auth_provider()`:
- Scoped tokens exist in `auth_tokens.json` → `ScopedTokenVerifier`
- Legacy `TALLY_MCP_AUTH_TOKEN` set → same verifier (fallback mode)
- Neither → `None` (no auth)

## Key Design Decisions

**Explicit company on writes**: All write tools require the `company` parameter to prevent accidental writes to the wrong company. Read tools allow omitting it (uses default).

**Confirmation before mutation**: Every write tool calls `ctx.elicit()` showing a human-readable summary of what will be sent to Tally. The operation only proceeds if the user explicitly confirms.

**Amount convention**: In the API (tool parameters and models), positive = debit, negative = credit. The `voucher_builder` negates amounts before building XML, matching Tally's internal convention. `ISDEEMEDPOSITIVE` is computed automatically from the negated sign.

**Transparent routing**: Tools accept a `business` name + date range. `CompanyRouter` resolves this to the correct Tally company file. The resolution is invisible to the user — they just say "Acme Corp" and the router picks the right FY.

**Scoped access**: Each tool checks `_check_access(company)` which compares the authenticated token's scope against the requested company. This runs synchronously before any Tally communication, providing fast rejection.
