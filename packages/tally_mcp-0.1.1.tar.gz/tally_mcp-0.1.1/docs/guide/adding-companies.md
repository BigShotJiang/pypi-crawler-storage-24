# Adding Companies

This guide covers onboarding companies into Tally MCP — from a fresh start to adding new companies to an existing setup.

## Concepts

| Term | Meaning | Example |
|------|---------|---------|
| **Business** | A logical entity you refer to | "Acme Corp" |
| **Tally company** | A physical company file in TallyPrime | "Acme Corp FY2024-26" |
| **Alias** | A shorthand name for a business | "acme", "AC" |

One business can have **multiple Tally companies** (typically one per financial year). The MCP server routes queries to the right one based on the date range.

## First-time onboarding

### Step 1: Discover what's open

Ask the assistant:

> "Scan Tally for open companies"

This calls `discover_companies()` and returns a list of all companies currently open in TallyPrime, along with which ones are already configured.

### Step 2: Group companies into businesses

The assistant will ask you questions like:

- **"Do these companies belong to the same business?"** — If you have `Acme Corp FY2022-24` and `Acme Corp FY2024-26`, they're the same business with two financial year splits
- **"What date range does each cover?"** — Typically April 1 to March 31 for Indian companies (e.g., `20240401` to `20260331`)
- **"What should we call this business?"** — A friendly name like "Acme Corp"
- **"Any short aliases?"** — So you can say "acme" instead of the full name

### Step 3: Save the configuration

The assistant calls `save_company_config()` with your answers. This writes `companies.json` to the config directory.

Example configuration:

```json
{
  "businesses": [
    {
      "name": "Acme Corp",
      "aliases": ["acme", "AC"],
      "tally_companies": [
        {
          "company": "Acme Corp FY2022-24",
          "from_date": "20220401",
          "to_date": "20240331"
        },
        {
          "company": "Acme Corp FY2024-26",
          "from_date": "20240401",
          "to_date": "20260331"
        }
      ],
      "default_company": "Acme Corp FY2024-26"
    }
  ]
}
```

## Adding a new company to an existing setup

When you open a new company in TallyPrime (e.g., a new financial year):

1. Open the new company in TallyPrime
2. Ask: **"Scan Tally for new companies"**
3. `discover_companies()` shows the new company as "unconfigured"
4. Tell the assistant to add it to the existing business with the correct date range
5. `save_company_config()` saves the updated config

If you're using HTTP mode with tokens, run `generate_tokens()` again to create a token for the new company.

## Adding a completely new business

Same flow — `discover_companies()` finds it, you tell the assistant it's a new business (not part of an existing one), give it a name and aliases, and `save_company_config()` saves it.

## How date-based routing works

Once configured, the MCP server automatically picks the right Tally company:

| What you say | What happens |
|-------------|-------------|
| "Show P&L for Acme, April 2023" | Routes to `Acme Corp FY2022-24` (date falls in that range) |
| "Show P&L for Acme, Jan 2025" | Routes to `Acme Corp FY2024-26` |
| "Show P&L for Acme" (no date) | Uses `default_company` → `Acme Corp FY2024-26` |
| "Show P&L for acme" | Alias match → routes to Acme Corp business |

The routing priority is:
1. Exact Tally company name (if you specify it directly)
2. Business name + date range match
3. Business name → default company
4. Global default company (from `TALLY_MCP_TALLY_DEFAULT_COMPANY` env var)

## Checking current configuration

> "Show me the configured businesses"

This calls `list_businesses()` and shows all businesses, their companies, date ranges, aliases, and last-known connectivity status.

## Checking all companies are reachable

> "Check all companies"

This calls `check_all_companies()` which heartbeats every configured company and reports which ones are open, closed, or unreachable.

## Removing a company

There's no dedicated removal tool. To remove a company or business:

1. Ask the assistant to reconfigure with `save_company_config()`, excluding the company you want to remove
2. The new config overwrites the old one

If you're using tokens, regenerate them after (`generate_tokens()`).

## Troubleshooting

### "Company not found" or empty results

- Is the company **open** in TallyPrime? (Tally must have it loaded)
- Is the company name **exact**? Run `discover_companies()` to see exact names
- Check date ranges — queries outside the configured range won't route correctly

### Company name doesn't match

Tally company names are exact strings including punctuation. Common issues:

- "Acme Corp" vs "Acme Corp." (trailing period)
- "Acme Corporation Private Limited" vs "Acme Corporation Pvt Ltd"
- Extra spaces

Use `discover_companies()` to get the exact name from Tally.

### Multiple companies open for the same date range

The router picks the first match. Set `default_company` to the one you use most often.
