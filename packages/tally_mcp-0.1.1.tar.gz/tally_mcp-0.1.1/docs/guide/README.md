# User Guides

Step-by-step walkthroughs for common tasks. Start with the one that matches your situation.

| Guide | Who it's for |
|-------|-------------|
| [Setup (Local)](setup-local.md) | Single user running Tally and the MCP client on the same machine |
| [Setup (Remote / Team)](setup-remote.md) | Server admin setting up shared access for a team |
| [Managing Access](managing-access.md) | Generating tokens, giving/revoking access, handling breaches |
| [Adding Companies](adding-companies.md) | Onboarding new companies, setting up multi-company routing |
| [Common Queries](common-queries.md) | Examples of what to ask your AI assistant once everything is connected |

For reference documentation (env vars, tool parameters, architecture), see the [parent docs folder](../index.md).
