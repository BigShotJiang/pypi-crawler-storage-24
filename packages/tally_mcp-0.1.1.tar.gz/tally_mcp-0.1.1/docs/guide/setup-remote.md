# Setup: Remote / Team Access

This guide walks a server admin through setting up Tally MCP for multiple users connecting remotely. The MCP server runs on the Tally machine; team members connect from their own machines via a Cloudflare Tunnel.

## Architecture

```
Team members (anywhere)                    Tally machine (office)
┌──────────────┐                    ┌─────────────────────────────┐
│ Alice        │                    │                             │
│  Claude Code ├──HTTPS──┐         │  ┌──────────┐  ┌─────────┐ │
├──────────────┤         │         │  │tally-mcp │  │ Tally   │ │
│ Bob          │         ├────────►│  │ :8765    ├─►│ :9000   │ │
│  Claude Code ├──HTTPS──┤ Tunnel  │  │(HTTP+auth│◄─│         │ │
├──────────────┤         │         │  └──────────┘  └─────────┘ │
│ Admin        │         │         │                             │
│  Claude Code ├──HTTPS──┘         └─────────────────────────────┘
└──────────────┘
```

## What you'll need

**On the Tally machine:**
- TallyPrime running with server mode on port 9000
- Python 3.11+ (or `uv`)
- A Cloudflare account with at least one domain

**For each team member:**
- An MCP client (Claude Code, Claude Desktop, etc.)
- Their access token (you'll generate these in Step 4)

## Step 1: Install and start the MCP server

On the Tally machine, open PowerShell:

```powershell
# Install uv (Python package manager)
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Close and reopen PowerShell (so PATH updates), then:

```powershell
uvx tally-mcp --http
```

Verify it's running — open a browser on the Tally machine and go to `http://localhost:8765/mcp`. You should see a JSON error response (that's fine — it means the server is listening).

Leave this terminal open for now. We'll make it a service later.

## Step 2: Quick tunnel test (temporary)

Before setting up a permanent tunnel, verify the concept works:

```powershell
# Download cloudflared
Invoke-WebRequest -Uri "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe" -OutFile cloudflared.exe
```

```powershell
.\cloudflared.exe tunnel --url http://localhost:8765
```

Cloudflare gives you a temporary URL like `https://random-words.trycloudflare.com`. Test it from another machine — if it works, you're ready for the permanent setup.

Press Ctrl+C to stop the temporary tunnel.

## Step 3: Set up a permanent Cloudflare Tunnel

The dashboard-based approach is the simplest and avoids config file permission issues on Windows.

### 3a. Create the tunnel in Cloudflare dashboard

1. Go to [https://one.dash.cloudflare.com](https://one.dash.cloudflare.com)
2. Navigate to **Networking** > **Tunnels**
3. Click **Create a tunnel**
4. Name it `tally-mcp`
5. Select **Windows** and **64-bit**

### 3b. Install the tunnel connector

The dashboard shows an install command like:

```
cloudflared.exe service install eyJhIjoi...long-token...
```

Copy this command and run it in **admin PowerShell** on the Tally machine. This does three things:
- Downloads the connector configuration
- Installs cloudflared as a Windows service
- Starts it automatically

Verify:

```powershell
Get-Service Cloudflared
```

Should show `Running`.

### 3c. Add the public hostname route

Back in the Cloudflare dashboard, on the tunnel page:

1. Click **Add route** (or go to the **Routes** tab)
2. Select **Published application**
3. Fill in:
   - **Subdomain:** `tally` (or whatever you prefer)
   - **Domain:** select your domain from the dropdown
   - **Path:** leave empty
   - **Service Type:** `HTTP`
   - **Service URL:** `http://localhost:8765`
4. Click **Add route**

Wait a minute, then verify the tunnel shows **Healthy** in the dashboard.

### 3d. Test the permanent tunnel

From any machine:

```bash
curl -X POST "https://tally.yourdomain.com/mcp" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}'
```

You should get a JSON response with `"serverInfo":{"name":"Tally MCP Server"}`.

## Step 4: Install tally-mcp as a Windows service

The temporary `uvx tally-mcp --http` terminal needs to become a service that survives reboots.

### 4a. Download WinSW

```powershell
Invoke-WebRequest -Uri "https://github.com/winsw/winsw/releases/download/v3.0.0-alpha.11/WinSW-x64.exe" -OutFile "C:\Users\$env:USERNAME\tally-mcp-svc.exe"
```

### 4b. Create the service config

Create `C:\Users\<your-username>\tally-mcp-svc.xml` with this content:

```xml
<service>
  <id>tally-mcp</id>
  <name>Tally MCP Server</name>
  <description>MCP server for TallyPrime</description>
  <executable>C:\Users\YOUR_USERNAME\.local\bin\uv.exe</executable>
  <arguments>tool run tally-mcp --http</arguments>
  <startmode>Automatic</startmode>
  <log mode="roll-by-size">
    <sizeThreshold>10240</sizeThreshold>
    <keepFiles>3</keepFiles>
  </log>
</service>
```

Replace `YOUR_USERNAME` with the actual Windows username. To find the exact `uv.exe` path:

```powershell
where.exe uv
```

### 4c. Install and start

In **admin PowerShell**:

```powershell
C:\Users\YOUR_USERNAME\tally-mcp-svc.exe install
C:\Users\YOUR_USERNAME\tally-mcp-svc.exe start
```

Verify:

```powershell
Get-Service tally-mcp
netstat -an | findstr 8765
```

Both should show the service running and listening on port 8765.

Now close the temporary `uvx tally-mcp --http` terminal — the service has taken over.

## Step 5: Onboard companies

Connect to the server yourself (use the tunnel URL or `localhost:8765`) and run the onboarding flow:

1. `discover_companies()` — finds open companies
2. Discuss grouping, date ranges, aliases
3. `save_company_config()` — saves the config

See [Adding Companies](adding-companies.md) for details.

## Step 6: Generate access tokens

Ask the assistant:

> "Generate access tokens for the team"

This calls `generate_tokens()` which creates:

| Token | Prefix | Access |
|-------|--------|--------|
| Admin token | `tmcp_adm_...` | All companies |
| Per-company token | `tmcp_co_...` | One specific company |

**Save these immediately.** Tokens are shown only once and cannot be retrieved later.

See [Managing Access](managing-access.md) for the full token lifecycle.

## Step 7: Distribute access to team members

Send each team member:
1. The tunnel URL (e.g., `https://tally.yourdomain.com/mcp`)
2. Their scoped token

Tell them to add this to their MCP client config:

### Claude Code

Add to `.mcp.json` in their project:

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://tally.yourdomain.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_THEIR_TOKEN_HERE"
      }
    }
  }
}
```

### Claude Desktop

Add to `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://tally.yourdomain.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_THEIR_TOKEN_HERE"
      }
    }
  }
}
```

## Step 8: Verify

Ask each team member to run a health check from their MCP client:

> "Check if Tally is connected"

## What auto-starts on reboot

| Component | How it starts | Notes |
|-----------|--------------|-------|
| **cloudflared** | Windows service (installed by dashboard command) | Connects tunnel automatically |
| **tally-mcp** | Windows service (WinSW) | Listens on port 8765 |
| **TallyPrime** | Must be opened manually | Someone needs to log in and open Tally with the company loaded |

The tunnel and MCP server start even if nobody logs in. But TallyPrime requires a user session — if the machine reboots, someone needs to open Tally before the MCP tools will work.

## Troubleshooting

### Tunnel shows "Down" in Cloudflare dashboard

```powershell
Get-Service Cloudflared
# If stopped:
Start-Service Cloudflared
```

### Error 1033 from tunnel URL

Cloudflared can't reach the origin. Check both services:

```powershell
Get-Service Cloudflared, tally-mcp
```

Restart both if needed:

```powershell
Restart-Service Cloudflared
Restart-Service tally-mcp
```

### Error 503 from tunnel URL

The tunnel connects to Cloudflare but can't reach `localhost:8765`. Check tally-mcp:

```powershell
netstat -an | findstr 8765
```

If nothing is listening, check the service logs:

```powershell
Get-Content C:\Users\YOUR_USERNAME\tally-mcp-svc.wrapper.log -Tail 20
Get-Content C:\Users\YOUR_USERNAME\tally-mcp-svc.out.log -Tail 20
```

### tally-mcp service won't start

Check the WinSW log:

```powershell
Get-Content C:\Users\YOUR_USERNAME\tally-mcp-svc.wrapper.log -Tail 20
```

Common causes:
- Wrong path to `uv.exe` in the XML config
- Port 8765 already in use (another tally-mcp instance running?)

### `sc.exe delete` says "marked for deletion"

A Service Manager window or process has a handle open. Close all `services.msc` windows, or reboot.

### Cloudflared service permission errors

If you used the config-file approach (not recommended) and see permission errors, the SYSTEM account can't read files in user directories. The dashboard token-based approach avoids this entirely — use that instead.

## Security checklist

- [ ] Never expose port 8765 directly to the internet — always use the tunnel
- [ ] Use scoped tokens — give each user only the companies they need
- [ ] Keep the admin token with the server operator only
- [ ] Cycle tokens immediately if compromised (see [Managing Access](managing-access.md))
- [ ] Monitor tunnel health in the Cloudflare dashboard
