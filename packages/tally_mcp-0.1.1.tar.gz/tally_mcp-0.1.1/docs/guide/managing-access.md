# Managing Access

This guide covers the full lifecycle of access tokens: generating them, distributing them, monitoring them, and revoking them when needed.

Access tokens are only needed for **remote/HTTP deployments**. If you're running locally via stdio, skip this guide — local mode has no auth.

## How tokens work

Tally MCP uses Bearer tokens scoped to specific companies. There are two types:

| Type | Prefix | What it can access | Who gets it |
|------|--------|--------------------|-------------|
| **Admin** | `tmcp_adm_` | All companies (`*`) | Server operator only |
| **Company** | `tmcp_co_` | One specific company | Team member who needs that company |

Tokens are stored as SHA-256 hashes in `auth_tokens.json` on the server. The actual token values are **shown only once** at generation — if lost, they must be cycled (replaced).

## Generating tokens

### First time setup

After onboarding companies with `save_company_config()`, ask the assistant:

> "Generate access tokens for the team"

This calls `generate_tokens()` which creates:
- 1 admin token
- 1 token per configured company

Example output:

```
Tokens generated:

Admin token (all companies):
  tmcp_adm_a1b2c3d4e5f6g7h8

Company tokens:
  Acme Corp FY2024-26:  tmcp_co_x9y8z7w6v5u4
  Beta Ltd FY2025-26:   tmcp_co_p3q4r5s6t7u8
```

**Copy these immediately.** They will not be shown again.

### What happens behind the scenes

1. Random 24-character tokens are generated with a type prefix
2. The raw token is shown to you
3. A SHA-256 hash of the token is saved to `auth_tokens.json`
4. When a request arrives, the server hashes the provided token and looks it up

This means even if someone reads `auth_tokens.json` on the server, they can't recover the actual tokens.

## Distributing tokens

Give each team member:

1. **The tunnel URL** — e.g., `https://tally.yourdomain.com/mcp`
2. **Their company token** — e.g., `tmcp_co_x9y8z7w6v5u4`

Tell them to add to their MCP client config:

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://tally.yourdomain.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_x9y8z7w6v5u4"
      }
    }
  }
}
```

**Best practices for distribution:**
- Send tokens via a secure channel (encrypted chat, not email)
- Never post tokens in shared documents or Slack channels
- Each person should get only the company token(s) they need
- The admin token stays with the server operator

## Checking who has access

Ask the assistant:

> "List all active tokens"

This calls `list_tokens()` and shows:

```
Active tokens:

1. tmcp_adm_a1b2...g7h8  →  scope: * (all companies)
2. tmcp_co_x9y8...v5u4   →  scope: Acme Corp FY2024-26
3. tmcp_co_p3q4...t7u8   →  scope: Beta Ltd FY2025-26
```

Tokens are shown with a redacted hint (first 8 + last 4 characters) — enough to identify them, not enough to use them.

## Revoking / cycling a token

If a token is compromised, lost, or a team member leaves:

> "Cycle the token starting with tmcp_co_x9y8"

This calls `cycle_token(token_prefix="tmcp_co_x9y8")` which:

1. **Immediately revokes** the old token (it stops working right away)
2. **Generates a new token** with the same scope
3. **Shows the new token once**

Share the new token with the appropriate person.

### When to cycle tokens

- A team member leaves the organization
- A token was shared in an insecure channel
- You suspect unauthorized access
- Routine rotation (e.g., quarterly)

## Adding access for a new team member

If you already have tokens set up and need to add access for a new person:

1. **If a company token exists** for the company they need — share that existing token with them (if you still have it), or cycle it to generate a new one and share the replacement

2. **If no token exists** for a new company — run `generate_tokens()` again. This regenerates all tokens (existing tokens stop working), so you'll need to redistribute.

> **Tip:** If you frequently add users, consider keeping the admin token and using `cycle_token()` to refresh individual company tokens as needed, rather than regenerating everything.

## Troubleshooting

### "Access denied" errors

The user's token doesn't have access to the company they're querying.

Check:
- Is the token correct (no extra spaces or line breaks)?
- Does the token's scope include the company being accessed? (`list_tokens()` to check)
- Is the company name exact? (Tally company names are case-sensitive in token scopes)

### "Invalid token" errors

The token doesn't match any hash in `auth_tokens.json`.

Possible causes:
- Token was typed incorrectly
- Token was already cycled/revoked
- `auth_tokens.json` was regenerated (all old tokens invalidated)

Fix: Cycle the token or regenerate all tokens.

### Token file location

Tokens are stored in the config directory:

| Platform | Path |
|----------|------|
| Windows | `%APPDATA%\tally-mcp\auth_tokens.json` |
| Linux/macOS | `~/.config/tally-mcp/auth_tokens.json` |

Override with `TALLY_MCP_CONFIG_DIR` env var.

## Quick reference

| Task | What to do |
|------|-----------|
| First-time setup | `generate_tokens()` after `save_company_config()` |
| Check active tokens | `list_tokens()` |
| Revoke + replace a token | `cycle_token(token_prefix="tmcp_co_x9y8")` |
| Regenerate everything | `generate_tokens()` (invalidates all existing tokens) |
| Give someone access | Share their company token + tunnel URL |
| Remove someone's access | Cycle their token |
