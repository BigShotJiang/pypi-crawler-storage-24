# Setup: Local (Single User)

This guide walks you through setting up Tally MCP on the same machine where TallyPrime is running. This is the simplest configuration — no network, no auth, no tunnels.

## What you'll need

- Windows PC with TallyPrime installed and a company open
- Python 3.11+ (or just `uv` / `uvx`)
- An MCP client (Claude Code, Claude Desktop, or any MCP-compatible app)

## Step 1: Enable TallyPrime's server mode

1. Open TallyPrime with your company loaded
2. Press **F12** (Configure) > **Connectivity**
3. Set **Tally Server Port** to `9000`
4. Make sure the server is enabled

To verify it's working, open a browser and go to `http://localhost:9000` — you should see a Tally response (or a blank page, not a connection error).

## Step 2: Install tally-mcp

The easiest way — no clone, no venv:

```bash
uvx tally-mcp
```

Or if you prefer pip:

```bash
pip install tally-mcp
```

## Step 3: Connect your MCP client

### Claude Code

Run this in your terminal:

```bash
claude mcp add tally -- uvx tally-mcp
```

Or add manually to `.mcp.json` in your project directory:

```json
{
  "mcpServers": {
    "tally": {
      "command": "uv",
      "args": ["run", "tally-mcp"],
      "env": {
        "TALLY_MCP_TALLY_PORT": "9000"
      }
    }
  }
}
```

### Claude Desktop

Add to your Claude Desktop config file (`%APPDATA%\Claude\claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "tally": {
      "command": "uvx",
      "args": ["tally-mcp"],
      "env": {
        "TALLY_MCP_TALLY_PORT": "9000"
      }
    }
  }
}
```

Restart Claude Desktop after editing.

## Step 4: Verify the connection

Open your MCP client and ask:

> "Check if Tally is connected"

The assistant will call `health_check` and should return a list of your open companies.

If it fails:
- Is TallyPrime open with a company loaded?
- Is server mode enabled on port 9000?
- Can you reach `http://localhost:9000` in a browser?

## Step 5: Onboard your companies

Ask the assistant:

> "Scan Tally for open companies and set them up"

This triggers the onboarding flow:
1. `discover_companies()` — finds what's open in Tally
2. The assistant asks you about business names, date ranges, and aliases
3. `save_company_config()` — saves the configuration

After this, you can refer to companies by their friendly name or alias instead of the exact Tally company name.

## You're done

No tokens or auth needed for local setup. Start asking questions:

> "Show me the trial balance for this month"
> "What are our outstanding receivables?"
> "Give me monthly sales by customer for FY 2025-26"

See [Common Queries](common-queries.md) for more examples.
