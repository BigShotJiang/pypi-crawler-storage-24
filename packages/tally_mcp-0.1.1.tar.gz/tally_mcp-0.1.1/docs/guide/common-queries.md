# Common Queries

Once your MCP client is connected to Tally, you can ask questions in natural language. Here are examples organized by use case.

## Financial Statements

> "Show me the trial balance for March 2026"

> "What's the P&L for FY 2025-26?"

> "Show the balance sheet as of today"

> "What's our revenue for October 2025?"

These use `get_trial_balance`, `get_profit_and_loss`, and `get_balance_sheet` under the hood.

## Sales & Revenue

> "Give me monthly sales by customer for FY 2025-26"

Uses `get_sales_by_party` — returns a compact party × month grid in a single call.

> "Show me the sales register for November 2025"

Uses `get_sales_register` — returns period totals (not customer-level detail).

> "What did we bill Acme Corp this year?"

Uses `get_ledger_vouchers` with Acme Corp's ledger name.

## Purchases

> "Show me monthly purchases by vendor for FY 2025-26"

Uses `get_sales_by_party` with `voucher_type="Purchase"`.

> "Show the purchase register for Q3"

Uses `get_purchase_register`.

## Receivables & Payables

> "Who owes us money?"

Uses `get_receivables` — shows outstanding bills receivable with ageing.

> "What do we owe our vendors?"

Uses `get_payables` — shows outstanding bills payable.

## Cash & Bank

> "What's our bank balance?"

Uses `get_trial_balance` — look at the Bank Accounts group.

> "Show HDFC Bank transactions for February 2026"

Uses `get_bank_book` with the specific bank ledger name.

## Inventory

> "Show the stock summary"

Uses `get_stock_summary`.

> "What's the movement for Widget-A this year?"

Uses `get_stock_item` with the stock item name.

## Ledger & Account Details

> "List all ledgers under Sundry Debtors"

Uses `list_ledgers` with `group="Sundry Debtors"`.

> "Show all transactions for Cash ledger in March 2026"

Uses `get_ledger_vouchers`.

> "What account groups do we have?"

Uses `list_groups`.

## Creating Data

> "Create a sales entry: sold to Acme Corp for 50,000 on March 15"

Uses `create_voucher`. The assistant will show a confirmation summary before sending to Tally.

> "Create a new customer ledger: Beta Ltd under Sundry Debtors"

Uses `create_ledger`.

> "Import these invoices from the CSV I pasted"

Uses `import_csv_vouchers`.

## System & Admin

> "Is Tally connected?"

Uses `heartbeat`.

> "Show me configured businesses"

Uses `list_businesses`.

> "Check all companies are reachable"

Uses `check_all_companies`.

## Tips

- **Dates**: Use natural language ("March 2026", "last quarter", "FY 2025-26") — the AI converts to YYYYMMDD format
- **Company names**: Use aliases if configured ("acme" instead of "Acme Corporation Private Limited")
- **Amounts**: In Indian accounting, negative = credit (income/liability), positive = debit (expense/asset)
- **Financial year**: Indian FY runs April to March (FY 2025-26 = April 2025 to March 2026)
- **One call, not many**: For party-wise sales/purchase data, the assistant uses `get_sales_by_party` (one call) instead of querying each customer individually
