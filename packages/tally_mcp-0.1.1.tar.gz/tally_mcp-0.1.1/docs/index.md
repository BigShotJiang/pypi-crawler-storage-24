# Tally MCP Documentation

MCP server bridging AI assistants to TallyPrime accounting software via XML-over-HTTP.

| Topic | File | When to read |
|-------|------|--------------|
| Installation & first run | [getting-started.md](getting-started.md) | New users |
| Deployment patterns | [deployment.md](deployment.md) | Solo local vs team remote setup |
| Configuration reference | [configuration.md](configuration.md) | Env vars, config files, .mcp.json |
| Tool reference | [tools.md](tools.md) | What tools exist, parameters, patterns |
| Authentication | [authentication.md](authentication.md) | Scoped tokens, admin tokens, legacy mode |
| Multi-company setup | [multi-company.md](multi-company.md) | Onboarding, date routing, aliases |
| Architecture | [architecture.md](architecture.md) | Module map, request flow, internals |

## User Guides

Step-by-step walkthroughs in [`guide/`](guide/README.md):
- [Setup (Local)](guide/setup-local.md) — single user, same machine as Tally
- [Setup (Remote / Team)](guide/setup-remote.md) — shared access with tokens and tunnels
- [Managing Access](guide/managing-access.md) — token generation, distribution, revocation
- [Adding Companies](guide/adding-companies.md) — onboarding, multi-company routing
- [Common Queries](guide/common-queries.md) — examples of what to ask once connected

## Other reference

For Tally-specific knowledge (XML formats, crash patterns, debugging, TDL):
see [`tally-development-knowledge-pack/`](../tally-development-knowledge-pack/) and its `INDEX.md`.

For project hard rules and coding conventions: see [`CLAUDE.md`](../CLAUDE.md).
