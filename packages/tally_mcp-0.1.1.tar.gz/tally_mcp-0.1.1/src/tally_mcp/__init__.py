"""Tally MCP Server - Bridge MCP clients to TallyPrime."""

__version__ = "0.1.1"
