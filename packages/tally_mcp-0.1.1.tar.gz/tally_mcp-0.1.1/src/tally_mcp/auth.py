"""Token-based authentication for remote HTTP access.

Supports two modes:
1. **Scoped tokens** (preferred): Token registry in ``auth_tokens.json`` with
   per-company access control. Tokens are generated via ``generate_tokens`` tool.
2. **Legacy single token**: ``TALLY_MCP_AUTH_TOKEN`` env var for backwards
   compatibility. Grants full access to all companies.

If neither is configured, authentication is disabled (open access).
"""

from __future__ import annotations

import hmac

from fastmcp.server.auth import AccessToken, TokenVerifier

from tally_mcp.company_config import _config_dir
from tally_mcp.config import settings
from tally_mcp.token_manager import TokenManager


def _get_token_manager() -> TokenManager:
    """Get or create the global TokenManager."""
    return TokenManager(_config_dir())


class ScopedTokenVerifier(TokenVerifier):
    """Verify incoming Bearer tokens against the token registry.

    Falls back to legacy single-token mode if ``auth_tokens.json``
    doesn't exist but ``TALLY_MCP_AUTH_TOKEN`` is set.
    """

    def __init__(self) -> None:
        super().__init__()
        self._tm = _get_token_manager()

    async def verify_token(self, token: str) -> AccessToken | None:
        """Return an AccessToken when *token* is valid, else None."""
        if not token:
            return None

        # Try scoped token registry first
        entry = self._tm.validate(token)
        if entry:
            return AccessToken(
                token=token,
                client_id="tally-mcp-client",
                scopes=entry.companies,
            )

        # Fall back to legacy single token
        if settings.auth_token and _verify_token_str(token, settings.auth_token):
            return AccessToken(
                token=token,
                client_id="tally-mcp-client",
                scopes=["*"],
            )

        return None


# Keep for backwards compatibility in tests
StaticTokenVerifier = ScopedTokenVerifier


def verify_token(provided: str, expected: str) -> bool:
    """Constant-time comparison of two token strings (legacy helper)."""
    return _verify_token_str(provided, expected)


def _verify_token_str(provided: str, expected: str) -> bool:
    """Constant-time comparison of two token strings.

    Returns True when *provided* equals *expected* and both are non-empty.
    """
    if not provided or not expected:
        return False
    return hmac.compare_digest(provided, expected)


def get_auth_provider() -> TokenVerifier | None:
    """Build an auth provider based on current settings.

    Returns a ScopedTokenVerifier when any auth is configured
    (token registry exists OR legacy env var is set), else None.
    """
    tm = _get_token_manager()
    registry = tm.load()

    # Auth enabled if: registry has tokens OR legacy env var is set
    if registry.tokens or settings.auth_token:
        return ScopedTokenVerifier()

    return None
