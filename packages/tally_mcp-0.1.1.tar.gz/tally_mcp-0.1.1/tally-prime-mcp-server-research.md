# Tally Prime MCP Server — Research & Resource Guide

> **Purpose:** Comprehensive reference for building a Tally Prime MCP server that can (a) read structured data and answer natural language questions about financials, and (b) write data back to Tally.
>
> **Compiled:** March 2026

---

## 1. Executive Summary

Tally Prime exposes data through three primary interfaces: an **XML HTTP Server** (native, most battle-tested), an **ODBC Server** (SQL-queryable), and **TDL (Tally Definition Language)** for deep customization. Two open-source MCP servers already exist — one by Dhananjay Patel (XML-based, purpose-built) and one by CData (JDBC/SQL-based, commercial driver).

**Critical new development:** TallyPrime 7.0 (released Dec 2025) introduced **native JSON support** ("JSONEx" format) over the same HTTP server. This is a game-changer for MCP server development — you can now send JSON requests via HTTP headers and receive structured JSON responses, eliminating XML parsing entirely. **For a new Python MCP server, the JSON/JSONEx approach on TallyPrime 7.0+ is the recommended primary path**, with XML as a fallback for older Tally versions.

---

## 2. How Tally Prime Exposes Data — Integration Methods

### 2.1 XML HTTP Server (Native — Recommended Primary Method)

**How it works:** Tally Prime runs as an HTTP server (default port 9000). External applications POST XML requests and receive XML responses. This is Tally's native, first-party integration interface and the most widely used method for programmatic access.

**Setup:**
- Enable in Tally: `F1 > Settings > Connectivity > Client/Server Configuration`
- Set `TallyPrime acts as = Server` and `Port = 9000`
- Tally must be running for requests to work

**Capabilities:**
- **Export any built-in report** (Trial Balance, P&L, Balance Sheet, Stock Summary, Receivables, Payables, Day Book, etc.) by specifying the TDL report name
- **Export custom reports** by embedding TDL definitions within the XML request itself
- **Export master data** (Ledgers, Groups, Stock Items, Voucher Types, Cost Centres)
- **Export collections** with custom filters, fields, and computations
- **Import masters and vouchers** (create, alter, delete, cancel)
- **Execute actions** (e.g., sync triggers)
- **Date filtering** via `STATICVARIABLES` for period-specific reports

**XML Request Structure:**
```xml
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Data</TYPE>              <!-- Data | Object | Collection -->
    <ID>Trial Balance</ID>         <!-- TDL Report Name -->
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
        <SVCURRENTCOMPANY>MyCompany</SVCURRENTCOMPANY>
        <SVFROMDATE>20250401</SVFROMDATE>
        <SVTODATE>20260331</SVTODATE>
      </STATICVARIABLES>
    </DESC>
  </BODY>
</ENVELOPE>
```

**Key Built-in Report Names (for the `<ID>` tag):**

| Report Name | What It Returns |
|---|---|
| `Trial Balance` | Group-wise trial balance |
| `Profit and Loss` | P&L statement |
| `Balance Sheet` | Balance sheet |
| `Stock Summary` | Stock-in-hand summary |
| `Day Book` | Day book (all vouchers) |
| `List of Accounts` | Chart of accounts |
| `Bills Receivable` | Outstanding receivables |
| `Bills Payable` | Outstanding payables |
| `Cash/Bank Book` | Cash/Bank summary |
| `Sales Register` | Sales voucher register |
| `Purchase Register` | Purchase voucher register |
| `Journal Register` | Journal entries register |
| `Ratio Analysis` | Financial ratios |
| `Group Summary` | Summary for a specific group |
| `Ledger Vouchers` | Vouchers for a specific ledger |
| `Stock Item` | Stock item movement details |

> **Tip:** The full list of report names can be discovered using TallyPrime Developer (Navigate > Jump to Definition > Report). All variables used in reports are in the default TDL.

**Reliability notes from the community:**
- Batch voucher imports should be kept to ~50-100 vouchers per request; 10,000+ in one request causes "Unknown Request" errors
- When Tally runs for several days (especially on Windows Server), it can occasionally return stale data — restart Tally if this happens
- When multiple companies are loaded and a specific company is targeted, rare edge cases can cause Tally to fetch from the wrong company
- All dates must follow `YYYYMMDD` format

**Official Sources:**
- [Integration With TallyPrime — TallyHelp](https://help.tallysolutions.com/integration-with-tallyprime/) ⭐ **Primary reference**
- [Sample XML — TallyHelp](https://help.tallysolutions.com/sample-xml/) ⭐ **Report export examples**
- [Case Study 1 — XML Request & Response Formats](https://help.tallysolutions.com/case-study-1/) ⭐ **Import/Export patterns**
- [Integration Methods and Technologies — TallyHelp](https://help.tallysolutions.com/integration-methods-and-technologies/) ⭐ **Architecture overview (Nov 2025)**

---

### 2.2 ODBC Server (SQL Queryable Interface)

**How it works:** Tally Prime can act as an ODBC server, allowing external applications to fire SQL SELECT queries against Tally data. Collections exposed via TDL become tables; object methods become columns.

**Setup:**
- Run Tally as Administrator
- `F12: Configure > Advanced Configuration > Enable ODBC server = Yes`
- Specify a port number
- Use Tally's built-in ODBC driver from any ODBC client

**Capabilities:**
- Fire SQL queries like `SELECT $Name, $ClosingBalance FROM Ledger WHERE $$IsDr:$ClosingBalance ORDER BY $ClosingBalance DESC`
- Call stored procedures (SQL Procedures mapped to TDL Collections with `SQLParms`)
- Access from Excel, Python (via pyodbc), VB, .NET, Java

**Limitations:**
- Only first-level collections exposed by default
- Custom collections need TDL with `IsODBCTable` attribute
- Read-only by default (no INSERT/UPDATE via ODBC)
- External methods of objects need `'_` prefix to be exposed
- Requires TDL knowledge to expose composite reports

**When to use:** Good for ad-hoc SQL queries and BI tool integration. Less suitable as the sole method for an MCP server because composite reports (P&L, Balance Sheet) aren't naturally exposed as SQL tables without significant TDL work.

**Official Sources:**
- [ODBC Integrations — TallyHelp](https://help.tallysolutions.com/odbc-integrations/) ⭐
- [Integration Using ODBC Interface — TallyHelp](https://help.tallysolutions.com/using-odbc-interface/) ⭐

---

### 2.3 TDL (Tally Definition Language) — Deep Customization

**What it is:** TDL is Tally's native programming language for customization. It can modify the UI, create custom reports, add validations, automate workflows, and define how data is structured for import/export.

**Relevance to MCP Server:**
- TDL is used to define custom collections and reports that can be exported via XML
- Custom TDL can be embedded within XML requests (in the `<TDL>` block) — no need to pre-install TDL files
- TDL can call external APIs (HTTP GET/POST) and process JSON/XML responses
- TDL can interact with DLLs for hardware/database/cloud integrations
- `.tcp` or `.tdl` files can be loaded at Tally startup for persistent customizations

**Key TDL Concepts for MCP:**
- **Collections** = Tables (define what data to gather)
- **Objects** = Rows (each instance of master/voucher)
- **Methods** = Columns (properties of objects like `$Name`, `$ClosingBalance`)
- **Reports** = Composed of Forms, Parts, Lines, Fields
- **Functions** = Computed values (e.g., `$$IsDr`, `$$IsLedger`)

**Official Sources:**
- [TDL Developer Reference — TallyHelp](https://help.tallysolutions.com/article/DeveloperReference/) ⭐ **Comprehensive TDL docs**
- [TDL Reference — Introduction](https://help.tallysolutions.com/developer-reference/tally-definition-language/) ⭐
- [Reports and Printing in TDL](https://help.tallysolutions.com/developer-reference/tally-definition-language/what-is-reports-and-printing-in-tdl/)

---

### 2.4 File-Based Export (Manual/Scheduled)

Tally can export any visible report to Excel, PDF, or XML via `Alt+E`. This can be scheduled (daily/weekly/monthly) and saved to a local directory or FTP. Useful for ETL pipelines but not suitable for real-time MCP queries.

### 2.5 JSON HTTP Interface (Native — TallyPrime 7.0+) ⭐⭐⭐ RECOMMENDED FOR NEW MCP SERVERS

**This is the most important finding for your MCP server.** TallyPrime 7.0 (released Dec 2025) introduced **native JSON support** as a first-class citizen alongside XML. This means you can now send JSON requests and receive JSON responses over the same HTTP server on port 9000 — no XML parsing needed. For a Python MCP server, this is a significantly cleaner integration path.

#### How It Works

The JSON interface uses the **same HTTP server** (port 9000) as XML. The difference is:
- You set `Content-Type: application/json` in headers
- Request metadata goes in **HTTP headers** (not in an XML envelope)
- Request body is a **JSON object** with `static_variables`, `tallymessage`, etc.
- Responses come back as **native JSON**

#### Two JSON Formats

| Format | Since | Description |
|---|---|---|
| **JSON** (legacy) | Tally.ERP 9 Release 6.2 | Older JSON format. Requires TDL customization for most operations. |
| **JSONEx** (new) ⭐ | TallyPrime 7.0 | Enhanced native JSON format. Richer data representation, better alignment with Tally's internal object model. **Use this.** |

#### JSON Request Structure

Unlike XML where everything is in the `<ENVELOPE>`, JSON separates concerns:

**HTTP Headers (metadata):**
```
content-type     : application/json
version          : 1
tallyrequest     : Export
type             : Data
id               : Trial Balance
```

**HTTP Body (payload):**
```json
{
  "static_variables": [
    {
      "key": "svExportFormat",
      "value": "JSONEx"
    },
    {
      "key": "svCurrentCompany",
      "value": "MyCompany"
    },
    {
      "key": "svFromDate",
      "value": "20250401"
    },
    {
      "key": "svToDate",
      "value": "20260331"
    }
  ]
}
```

#### Header Reference

| Header | Values | Required | Purpose |
|---|---|---|---|
| `content-type` | `application/json` or `application/json;charset=utf-8` or `application/json;charset=utf-16` | Yes | Content type. Use `charset=utf-8` for multilingual. |
| `version` | `1` | Yes | Message format version. |
| `tallyrequest` | `Export` / `Import` / `Execute` | Yes | Export = read data, Import = write data, Execute = run actions. |
| `type` | `Data` / `Collection` / `Object` / `Function` | Yes | What kind of entity to request. `Data` = report, `Collection` = group of objects, `Object` = single entity. |
| `subtype` | e.g. `Ledger`, `StockItem` | Only if type=Object | Specifies the object type. |
| `id` | Report/Collection/Object name | Yes | The identifier — e.g. `Trial Balance`, `Profit and Loss`, `All Masters`, `Vouchers`. |
| `id-encoded` | Base64-encoded id | Only for multilingual | For non-ASCII report/entity names. |
| `detailed-response` | `Yes` / `No` | No | Get extra counts in import response. |

#### Body Tags Reference

| Body Key | Purpose | When Used |
|---|---|---|
| `static_variables` | System variables (company, date range, export format, etc.) | Always for exports; for imports to set context |
| `repeat_variables` | Repeated variable info (multiple date ranges for multi-column reports) | Multi-period reports |
| `fetchlist` | List of storages/methods to fetch from an object | When type=Object |
| `func_param_list` | Parameters for function execution | When type=Function |
| `tdlmessage` | Inline TDL definitions (for custom reports not in default TDL) | When requesting custom/non-default reports |
| `tallymessage` | The actual data payload for import (masters or vouchers) | When tallyrequest=Import |

#### Mandatory Static Variables

| Variable | Values | When Required | Purpose |
|---|---|---|---|
| `svExportFormat` | `JSONEx` or `XML` | All Export requests | Ensures response comes in the right format. **Always set to `JSONEx`.** |
| `svMstImportFormat` | `JSONEx` or `XML` | Master imports | Tells Tally the import data format. |
| `svVchImportFormat` | `JSONEx` or `XML` | Voucher imports | Tells Tally the import data format. |
| `svCurrentCompany` | Company name | Always | Target company. Without it, data may go to wrong company. |
| `svFromDate` | `YYYYMMDD` | Period-based reports | Start of reporting period. |
| `svToDate` | `YYYYMMDD` | Period-based reports | End of reporting period. |

#### Export Examples (Reading Reports)

**Export Trial Balance:**
```
Headers:
  content-type: application/json
  version: 1
  tallyrequest: Export
  type: Data
  id: Trial Balance

Body:
{
  "static_variables": [
    {"key": "svExportFormat", "value": "JSONEx"},
    {"key": "svCurrentCompany", "value": "MyCompany"},
    {"key": "svFromDate", "value": "20250401"},
    {"key": "svToDate", "value": "20260331"}
  ]
}
```

**Export Profit and Loss:**
```
Headers:
  content-type: application/json
  version: 1
  tallyrequest: Export
  type: Data
  id: Profit and Loss

Body:
{
  "static_variables": [
    {"key": "svExportFormat", "value": "JSONEx"},
    {"key": "svCurrentCompany", "value": "MyCompany"},
    {"key": "svFromDate", "value": "20250401"},
    {"key": "svToDate", "value": "20260331"}
  ]
}
```

**Export a Collection (e.g., all Ledgers):**
```
Headers:
  content-type: application/json
  version: 1
  tallyrequest: Export
  type: Collection
  id: List of Ledgers

Body:
{
  "static_variables": [
    {"key": "svExportFormat", "value": "JSONEx"}
  ]
}
```

**Export a Single Object (e.g., a specific Ledger):**
```
Headers:
  content-type: application/json
  version: 1
  tallyrequest: Export
  type: Object
  subtype: Ledger
  id: Customer ABC

Body:
{
  "static_variables": [
    {"key": "svExportFormat", "value": "JSONEx"}
  ],
  "fetchlist": ["ClosingBalance", "OpeningBalance", "Parent"]
}
```

#### Import Examples (Writing Data)

**Import a Ledger (Create Master):**
```
Headers:
  content-type: application/json
  version: 1
  tallyrequest: Import
  type: Data
  id: All Masters

Body:
{
  "static_variables": [
    {"key": "svMstImportFormat", "value": "JSONEx"},
    {"key": "svCurrentCompany", "value": "MyCompany"}
  ],
  "tallymessage": {
    "ledger": [
      {
        "@action": "Create",
        "name": "New Customer",
        "parent": "Sundry Debtors"
      }
    ]
  }
}
```

**Import a Sales Voucher:**
```
Headers:
  content-type: application/json
  version: 1
  tallyrequest: Import
  type: Data
  id: Vouchers

Body:
{
  "static_variables": [
    {"key": "svVchImportFormat", "value": "JSONEx"},
    {"key": "svCurrentCompany", "value": "MyCompany"}
  ],
  "tallymessage": {
    "voucher": [
      {
        "@action": "Create",
        "@vchtype": "Sales",
        "date": "20260315",
        "vouchertypename": "Sales",
        "partyledgername": "Customer ABC",
        ...
      }
    ]
  }
}
```

> **Note:** The exact JSON schema for vouchers in JSONEx format should be discovered by first **exporting** a manually-created voucher from TallyPrime in JSON format, then using that structure as your import template. This is the official recommended approach from Tally's docs.

#### Why JSON is Better Than XML for Your MCP Server

1. **No XML parsing** — Python's `json.loads()` is simpler and faster than `xml.etree.ElementTree`
2. **Cleaner data structures** — JSON arrays and objects map directly to Python lists and dicts
3. **Header-based metadata** — Separation of concerns (headers for request type, body for data)
4. **Modern standard** — Better tooling, better LLM comprehension of JSON vs XML
5. **Native support** — No TDL customization needed for standard operations in TallyPrime 7.0+
6. **Same capabilities** — Everything you can do with XML, you can do with JSON (masters, vouchers, reports, collections, objects, functions)

#### Important Caveats

- **Requires TallyPrime 7.0+** — Released Dec 2025. If users are on older versions, fall back to XML.
- **JSONEx is the recommended format** — The older `JSON` format (from ERP 9 6.2) has limitations. Always use `JSONEx`.
- **Currency symbols** — TallyPrime 7.0 uses Unicode entity codes for AED/SAR. Ensure correct encoding when importing.
- **The JSON schema for native format isn't fully documented in examples** — Best approach: export data from Tally in JSONEx format first, then reverse-engineer the structure for your imports.

#### Official Sources

- [Integration using JSON — TallyHelp](https://help.tallysolutions.com/tally-prime-integration-using-json-1/) ⭐⭐ **PRIMARY reference** (22-min read, updated Dec 2025). Covers headers, body structure, static variables, all request types.
- [Release Notes — TallyPrime Developer 7.0](https://help.tallysolutions.com/release-notes-tally-prime-developer-7/) ⭐ Introduces JSONEx format.
- [Release Notes — TallyPrime 7.0](https://help.tallysolutions.com/release-notes-tallyprime-7-0/) — Product-level release notes.
- [Import Data from JSON or XML](https://help.tallysolutions.com/import-data-from-xml-or-json/) — Import guide covering JSON.
- [JSON Integration (TDL-level)](https://help.tallysolutions.com/json-integration/) — Older page covering TDL-based JSON export with `JSON Tag`, `Plain JSON` attributes. Relevant for custom reports.
- [JSON-Based Export/Import (Reference)](https://help.tallysolutions.com/json-based-export-import/) — Detailed TDL reference for JSON format.

---

## 3. Composite Reports — Getting P&L, Balance Sheet, etc.

### 3.1 Via XML HTTP (Most Reliable)

Request `Profit and Loss` or `Balance Sheet` directly by name. These are built-in TDL reports. Use `STATICVARIABLES` for date ranges:

```xml
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Data</TYPE>
    <ID>Profit and Loss</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
        <SVFROMDATE>20250401</SVFROMDATE>
        <SVTODATE>20260331</SVTODATE>
      </STATICVARIABLES>
    </DESC>
  </BODY>
</ENVELOPE>
```

For **monthly P&L**, you make separate requests for each month's date range, or use TDL's multi-column report feature to get comparative periods in one request.

### 3.2 Via Collection-Based Extraction

Instead of report-level export, you can export collections of ledgers with computed closing balances, then reconstruct financial statements:
- Export all ledgers under `Sales Accounts` group → Revenue
- Export all ledgers under `Purchase Accounts` group → COGS
- Export all ledgers under `Direct/Indirect Expenses` → Expenses
- Group hierarchy follows Tally's chart of accounts structure

### 3.3 Receivables & Payables

- Use report name `Bills Receivable` / `Bills Payable` for bill-wise outstandings
- Use `Ledger Vouchers` with specific sundry debtor/creditor ledgers for party-level detail
- Age-wise analysis available via report configuration variables

---

## 4. Existing MCP Servers & Open Source Projects

### 4.1 dhananjay1405/tally-mcp-server ⭐⭐⭐ (Most Relevant)

**What:** Purpose-built Tally Prime MCP server using XML HTTP interface. Node.js/TypeScript. MIT licensed.

**Tools Exposed:**
| Tool | Purpose |
|---|---|
| `list-master` | Lists ledgers, stock items, groups, etc. for validation/autocomplete |
| `chart-of-accounts` | Extracts group hierarchy for BS/P&L/TB construction |
| `ledger-account` | Ledger-level account statement for a period |
| `stock-item-account` | Stock item voucher statement for a period |
| `receivables-payables` | Bill-wise outstanding report |
| `trial-balance` | Trial Balance for period |
| `balance-sheet` | Balance Sheet |
| `profit-and-loss` | Profit & Loss statement |

**Key Design Decisions:**
- Uses XML HTTP POST to Tally on port 9000
- Supports both local mode (Claude Desktop + local Tally) and remote/web mode
- Handles company selection (defaults to active company)
- LLM uses `list-master` for fuzzy name matching before querying

**Links:**
- GitHub: [github.com/dhananjay1405/tally-mcp-server](https://github.com/dhananjay1405/tally-mcp-server) (19 stars, MIT license)
- Download: [excelkida.com/resource/tally-mcp-server-v6.zip](https://excelkida.com/resource/tally-mcp-server-v6.zip)
- MCP Market listing: [mcpmarket.com/server/tally-prime](https://mcpmarket.com/server/tally-prime)
- ICAI (Institute of Chartered Accountants of India) listing: [ai.icai.org/usecases_details.php?id=200](https://ai.icai.org/usecases_details.php?id=200)

---

### 4.2 CDataSoftware/tally-mcp-server-by-cdata

**What:** Read-only MCP server using CData JDBC Driver. Exposes Tally as relational SQL tables. Java-based.

**Approach:** JDBC driver abstracts Tally's XML API into SQL tables (Accounts, SalesOrders, PurchaseOrders, etc.). MCP server wraps this with three tools: `get_tables`, `get_columns`, `run_query`.

**Pros:** SQL interface is clean; good for simple queries.
**Cons:** Read-only (free version). Full CRUD requires paid CData MCP Server. Requires Java + CData JDBC driver. Less control over composite report extraction.

**Links:**
- GitHub: [github.com/CDataSoftware/tally-mcp-server-by-cdata](https://github.com/CDataSoftware/tally-mcp-server-by-cdata) (MIT license)
- Commercial MCP Server: [cdata.com/drivers/tally/download/mcp/](https://www.cdata.com/drivers/tally/download/mcp/)

---

### 4.3 aadil-sengupta/Tally.Py ⭐⭐ (Python Library)

**What:** Comprehensive Python library for Tally XML API integration. Published on PyPI as `tally-integration`.

**Capabilities:**
- `TallyClient` class with methods for all common operations
- Data retrieval: companies, ledgers, stock items, vouchers, groups, reports
- Master data management: create/manage ledgers, stock items, companies
- Transaction processing: create vouchers (receipts, journals), update, cancel
- Reports: sales reports, payslips, bill receivables, stock aging
- Includes experimental TDL files for AI integration (Claude, AI Studio)
- Bundled documentation: TDL Reference Manual, Tally Functions Guide

**Links:**
- GitHub: [github.com/aadil-sengupta/Tally.Py](https://github.com/aadil-sengupta/Tally.Py)
- PyPI: [pypi.org/project/tally-integration/](https://pypi.org/project/tally-integration/)

---

### 4.4 dhananjay1405/tally-database-loader ⭐⭐

**What:** Node.js utility that extracts data from Tally's XML server and loads it into a relational database (SQL Server, MySQL, PostgreSQL, BigQuery). Also supports CSV, JSON, and Azure Data Lake export.

**Relevance:** Demonstrates robust extraction patterns for all Tally data types. Good reference for collection-based extraction with TDL embedded in XML requests.

**Key Learnings:**
- Default batch size of 5000 vouchers per extraction is stable; avoid >10,000
- Supports full sync and incremental sync (based on AlterID tracking)
- Handles multi-company scenarios with company name in config
- Includes TDL report specifications for all standard Tally entities

**Links:**
- GitHub: [github.com/dhananjay1405/tally-database-loader](https://github.com/dhananjay1405/tally-database-loader)

---

### 4.5 Accounting-Companion/TallyConnector (C#)

**What:** C# library that abstracts Tally's XML API into C# objects. Auto-generates TDL reports using source generators.

**Links:**
- GitHub: [github.com/Accounting-Companion/TallyConnector](https://github.com/Accounting-Companion/TallyConnector)
- Postman Collection (XML samples): [documenter.getpostman.com/view/13855108/TzeRpAMt](https://documenter.getpostman.com/view/13855108/TzeRpAMt)

---

### 4.6 Other Tools

| Tool | Type | Notes |
|---|---|---|
| **CData Python Connector** | Commercial | DB-API module for Python. SQL over Tally. Works with Pandas/SQLAlchemy. [cdata.com/drivers/tally/python](https://www.cdata.com/drivers/tally/python/) |
| **CData ODBC Driver** | Commercial | ODBC driver wrapping Tally HTTP. Cross-platform. [cdata.com/drivers/tally/odbc](https://www.cdata.com/drivers/tally/odbc/) |
| **api2books.com** | Commercial SaaS | GET/POST API platform for Tally with JSON format. Plugin-based (.tcp). Subscription model. [api2books.com](https://api2books.com/) |
| **RootFi** | Commercial SaaS | Unified accounting API that includes Tally connector. [rootfi.dev/integrations/tally-prime](https://www.rootfi.dev/integrations/tally-prime) |
| **tendril-connector-tally** | Python (AGPL) | Tally XML interface connector. Older, limited maintenance. [PyPI](https://pypi.org/project/tendril-connector-tally/) |
| **hashfx/Tally-Automation** | Python | Simple Tally automation scripts. [GitHub](https://github.com/hashfx/Tally-Automation) |
| **iodize6399/TallPy** | Python | Tally ERP9 + Python connector via XML. Includes Discord bot example. [GitHub](https://github.com/iodize6399/TallPy) |
| **ramajayam-CA/Tally-Connector** | TDL + Excel | Tally-Excel connector via TDL and ODBC. Good SQL query examples. [GitHub](https://github.com/ramajayam-CA/Tally-Connector) |

---

## 5. Writing Data Back to Tally

### 5.1 XML Import via HTTP POST

The same HTTP server that handles reads also accepts write requests. The XML structure for imports differs from exports.

**Import Masters (Ledgers, Groups, Stock Items):**
```xml
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Import Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>All Masters</REPORTNAME>
        <STATICVARIABLES>
          <SVCURRENTCOMPANY>MyCompany</SVCURRENTCOMPANY>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <LEDGER NAME="New Customer" ACTION="Create">
            <NAME>New Customer</NAME>
            <PARENT>Sundry Debtors</PARENT>
            <OPENINGBALANCE>0</OPENINGBALANCE>
          </LEDGER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>
```

**Import Vouchers (Sales, Purchase, Payment, Receipt, Journal):**
```xml
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Import Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>Vouchers</REPORTNAME>
        <STATICVARIABLES>
          <SVCURRENTCOMPANY>MyCompany</SVCURRENTCOMPANY>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          <VOUCHER VCHTYPE="Sales" ACTION="Create">
            <DATE>20260315</DATE>
            <VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>
            <!-- Voucher details... -->
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>
```

**Key Write Operations:**

| Operation | ACTION value | Notes |
|---|---|---|
| Create master/voucher | `Create` | New entry |
| Alter master/voucher | `Alter` | Modify existing (needs identifier) |
| Delete master/voucher | `Delete` | Remove (needs identifier) |
| Cancel voucher | `Cancel` | Tally-specific cancel (retains audit trail) |

**Duplicate Handling (for masters):**
- `DupModify` — Overwrite with new values
- `DupIgnoreCombine` — Skip if exists
- `DupCombine` — Merge opening balances (for group company consolidation)

**Voucher Identification for Alter/Delete:**
- Use `MASTERID` or combination of `VOUCHERNUMBER`, `VOUCHERTYPENAME`, and `DATE`
- Best practice: Export the target voucher first, modify XML, re-import with `Alter`

**Response Format:**
```xml
<RESPONSE>
  <CREATED>1</CREATED>
  <ALTERED>0</ALTERED>
  <LASTVCHID>12345</LASTVCHID>
  <LASTMASTERID>67890</LASTMASTERID>
</RESPONSE>
```

**Community Learnings on Writes:**
- Always batch imports: 50–100 vouchers per request is safe
- Ledger names in vouchers must exactly match existing masters in Tally
- Create masters before vouchers that reference them
- Create groups before ledgers, stock groups before stock items
- Test with a backup company before production
- Check `Tally.imp` log file in Tally installation folder for detailed import logs
- GST, HSN/SAC codes, and tax classifications must be pre-configured

**Official Sources:**
- [Integration With TallyPrime — Import Section](https://help.tallysolutions.com/integration-with-tallyprime/) ⭐
- [How to Import Data into TallyPrime](https://help.tallysolutions.com/import-data-in-tally/)

---

## 6. Recommended Architecture for Custom MCP Server

### 6.1 For Reads (Phase 1)

```
User (Natural Language)
    ↓
LLM (Claude / ChatGPT)
    ↓
MCP Server (Python/FastMCP)
    ↓ HTTP POST (JSON — Content-Type: application/json)
    ↓ Headers: tallyrequest=Export, type=Data, id=<Report Name>
Tally Prime 7.0+ (HTTP Server on port 9000)
    ↓ JSON Response (JSONEx format)
MCP Server → json.loads() → Python dict → LLM
    ↓
Natural Language Answer to User

NOTE: If users are on TallyPrime < 7.0, fall back to XML.
      The MCP server should detect version and switch format.
```

**Recommended Tool Design:**

| MCP Tool | Input | Tally Request | Purpose |
|---|---|---|---|
| `list_companies` | — | Collection: Company | Available companies |
| `list_masters` | master_type, company | Collection: Ledger/StockItem/Group | Autocomplete & validation |
| `get_chart_of_accounts` | company | Collection: Group hierarchy | Structural understanding |
| `get_trial_balance` | company, from_date, to_date | Report: Trial Balance | Foundation for most financial queries |
| `get_profit_and_loss` | company, from_date, to_date | Report: Profit and Loss | P&L statement |
| `get_balance_sheet` | company, from_date, to_date | Report: Balance Sheet | Balance sheet |
| `get_receivables` | company | Report: Bills Receivable | Outstanding receivables |
| `get_payables` | company | Report: Bills Payable | Outstanding payables |
| `get_ledger_vouchers` | ledger_name, company, from_date, to_date | Report: Ledger Vouchers | Transaction detail for specific account |
| `get_stock_summary` | company | Report: Stock Summary | Inventory position |
| `get_day_book` | company, from_date, to_date | Report: Day Book | All transactions for a period |
| `get_sales_register` | company, from_date, to_date | Report: Sales Register | Sales detail |

### 6.2 For Writes (Phase 2)

| MCP Tool | Input | Tally Request | Purpose |
|---|---|---|---|
| `create_ledger` | name, parent_group, company | Import: All Masters | Create new ledger |
| `create_voucher` | voucher_type, date, entries, company | Import: Vouchers | Record transaction |
| `alter_voucher` | voucher_id, changes, company | Import: Vouchers (Alter) | Modify transaction |
| `cancel_voucher` | voucher_id, company | Import: Vouchers (Cancel) | Cancel transaction |

**Safety Considerations for Writes:**
- Always require explicit user confirmation before writing
- Validate all ledger/party names against existing masters before creating vouchers
- Implement dry-run / preview mode
- Log all write operations
- Consider making the MCP server read-only by default with a write-enable flag

---

## 7. Resource Ranking by Credibility

### Tier 1 — Official Tally Solutions Documentation (Most Authoritative)

| Resource | URL | Notes |
|---|---|---|
| Integration With TallyPrime | [help.tallysolutions.com/integration-with-tallyprime/](https://help.tallysolutions.com/integration-with-tallyprime/) | Primary integration docs. Updated Jul 2025. |
| Integration Methods & Technologies | [help.tallysolutions.com/integration-methods-and-technologies/](https://help.tallysolutions.com/integration-methods-and-technologies/) | Architecture overview. Updated Nov 2025. |
| Sample XML | [help.tallysolutions.com/sample-xml/](https://help.tallysolutions.com/sample-xml/) | Report export examples. Updated Aug 2025. |
| Case Study 1 — XML Formats | [help.tallysolutions.com/case-study-1/](https://help.tallysolutions.com/case-study-1/) | Import/export patterns with examples. |
| ODBC Integrations | [help.tallysolutions.com/odbc-integrations/](https://help.tallysolutions.com/odbc-integrations/) | ODBC server setup and TDL. Updated Aug 2025. |
| ODBC Interface Guide | [help.tallysolutions.com/using-odbc-interface/](https://help.tallysolutions.com/using-odbc-interface/) | ODBC client/server detailed guide. Updated Jul 2025. |
| TDL Developer Reference | [help.tallysolutions.com/article/DeveloperReference/](https://help.tallysolutions.com/article/DeveloperReference/) | Complete TDL documentation. |
| Import Data into TallyPrime | [help.tallysolutions.com/import-data-in-tally/](https://help.tallysolutions.com/import-data-in-tally/) | Excel/XML/JSON import guide. |

### Tier 2 — Open Source Projects with Active Maintenance

| Resource | URL | Notes |
|---|---|---|
| tally-mcp-server (Dhananjay) | [github.com/dhananjay1405/tally-mcp-server](https://github.com/dhananjay1405/tally-mcp-server) | Purpose-built MCP server. Node.js. MIT. Active 2025. |
| tally-database-loader (Dhananjay) | [github.com/dhananjay1405/tally-database-loader](https://github.com/dhananjay1405/tally-database-loader) | Tally→DB loader. Great extraction patterns. |
| Tally.Py (Aadil Sengupta) | [github.com/aadil-sengupta/Tally.Py](https://github.com/aadil-sengupta/Tally.Py) | Python library. PyPI package. Includes AI-integration TDLs. |
| TallyConnector (C#) | [github.com/Accounting-Companion/TallyConnector](https://github.com/Accounting-Companion/TallyConnector) | C# abstraction. Source-generated TDL reports. |
| CData Tally MCP Server | [github.com/CDataSoftware/tally-mcp-server-by-cdata](https://github.com/CDataSoftware/tally-mcp-server-by-cdata) | JDBC-based MCP. Read-only (free). |

### Tier 3 — Community References & Tutorials

| Resource | URL | Notes |
|---|---|---|
| Tally XML Tags Reference | [rtslink.com/articles/tally-xml-tags-export/](https://www.rtslink.com/articles/tally-xml-tags-export/) | Downloadable XML templates for every report type. Older (ERP 9) but patterns still apply. |
| TDL Integration Blog | [tdlintegration.blogspot.com](http://tdlintegration.blogspot.com/2012/11/case-study-tally-xml-integration.html) | Community blog with XML examples and troubleshooting. Comments section has real-world issues. |
| Tally XML Postman Collection | [documenter.getpostman.com/view/13855108/TzeRpAMt](https://documenter.getpostman.com/view/13855108/TzeRpAMt) | Ready-to-use Postman requests for Tally XML API. |
| Ghanshyam Digital Blog | [blog.ghanshyamdigital.com](https://blog.ghanshyamdigital.com/how-to-use-xml-requests-for-exporting-data-from-tally-prime) | Practical XML export guide with examples. Jul 2025. |
| TechGuruPlus TDL Codes | [techguruplus.com/tally-prime-tdl/](https://techguruplus.com/tally-prime-tdl/) | Collection of TDL files with community discussion. |

### Tier 4 — Commercial Solutions (Reference Only)

| Resource | URL | Notes |
|---|---|---|
| CData Drivers Suite | [cdata.com/drivers/tally/](https://www.cdata.com/drivers/tally/) | ODBC, JDBC, Python, MCP drivers. Paid. |
| api2books.com | [api2books.com](https://api2books.com/) | GET/POST API plugin platform. Subscription. |
| RootFi | [rootfi.dev/integrations/tally-prime](https://www.rootfi.dev/integrations/tally-prime) | Unified accounting API. |
| SAW India | [sawindia.com/tally-integration](https://sawindia.com/tally-integration) | Integration services. |

---

## 8. Key Considerations for MCP Server Design

### 8.1 Reliability Best Practices

1. **Always check if Tally is running** before making requests (ping port 9000)
2. **Validate master names** before using them in queries (use `list-master` tool)
3. **Handle XML parsing errors gracefully** — Tally can return partial/malformed XML on large datasets
4. **Set reasonable timeouts** — large reports can take 10-30 seconds
5. **Date format is critical** — always use `YYYYMMDD` format
6. **Company context** — always specify `SVCURRENTCOMPANY` to avoid wrong-company issues
7. **Batch writes** — keep to 50-100 items per request
8. **Encoding** — Tally uses UTF-8 but some older versions have encoding issues with special characters

### 8.2 Monthly P&L Approach

For "What's the revenue trend?" or "Monthly P&L" questions:
1. Make N separate P&L requests with per-month date ranges
2. Parse and aggregate results
3. Consider caching — financial data for closed months doesn't change frequently
4. Alternative: Extract Trial Balance for each month and compute P&L from group totals

### 8.3 Natural Language → Tool Mapping

| User Question Pattern | MCP Tool to Call |
|---|---|
| "What is our revenue?" / "How much did we sell?" | `get_profit_and_loss` |
| "What are our receivables?" / "Who owes us money?" | `get_receivables` |
| "What's the cash balance?" | `get_trial_balance` → filter for cash/bank groups |
| "Monthly expense trend" | Multiple `get_profit_and_loss` calls per month |
| "How much did we spend on rent?" | `get_ledger_vouchers` for rent ledger |
| "Stock position" / "Inventory value" | `get_stock_summary` |
| "Create a sales invoice" | `create_voucher` (Phase 2 - writes) |

---

## 9. Getting Started — Quick Path

### Recommended Path: JSON on TallyPrime 7.0+

1. **Read the JSON integration doc first** — [Integration using JSON](https://help.tallysolutions.com/tally-prime-integration-using-json-1/) is the 22-minute primary reference. Understand the header-based request structure and JSONEx format.

2. **Download official sample files** — Get the [Integration Demo Samples ZIP](https://help.tallysolutions.com/wp-content/uploads/2025/07/Integration_Demo_Samples.zip) from Tally. These include working examples.

3. **Test with curl/Postman against a local Tally instance** — Start with a simple export:
   ```bash
   curl -X POST http://localhost:9000 \
     -H "content-type: application/json" \
     -H "version: 1" \
     -H "tallyrequest: Export" \
     -H "type: Collection" \
     -H "id: List of Ledgers" \
     -d '{"static_variables": [{"key": "svExportFormat", "value": "JSONEx"}]}'
   ```

4. **Discover the JSON schema for each report** — Export Trial Balance, P&L, Balance Sheet, Receivables, etc. via the JSON interface. Save the response structures — these become your parsing templates.

5. **Study the existing XML MCP server for tool design** — Clone [dhananjay1405/tally-mcp-server](https://github.com/dhananjay1405/tally-mcp-server). The tool names and parameters are well-designed. Re-implement the same tools using JSON instead of XML.

6. **Build with Python/FastMCP** — Use `httpx` for async HTTP POST to Tally. Response is already JSON — just `response.json()`. No XML parsing needed.

7. **For writes: export first, then import** — Create a sample voucher manually in Tally, export it in JSON format, and use that exact structure as your import template. This is the official recommended approach.

### Fallback Path: XML (for TallyPrime < 7.0)

1. Use the [Tally.Py](https://github.com/aadil-sengupta/Tally.Py) Python library as a reference for XML construction/parsing.
2. Import the [Tally XML Postman Collection](https://documenter.getpostman.com/view/13855108/TzeRpAMt) for testing.
3. Get XML templates from [rtslink.com/articles/tally-xml-tags-export/](https://www.rtslink.com/articles/tally-xml-tags-export/).
4. Parse XML responses with `lxml` or `xml.etree.ElementTree`.

---

---

## Appendix A: Official Tally Developer Documentation — Complete Sitemap

Tally recently (mid-2025) restructured their developer documentation under `help.tallysolutions.com`. Below is the complete navigation tree of pages relevant to integration, with URLs and brief descriptions. These are the **authoritative, first-party sources** for everything you need.

### A.1 Top-Level Entry Points

| Page | URL | Description |
|---|---|---|
| **Integrate with TallyPrime** (Landing) | [help.tallysolutions.com/integrate-with-tallyprime/](https://help.tallysolutions.com/integrate-with-tallyprime/) | Overview of all integration capabilities. Links to all sub-sections. |
| **Developer Reference** (Root) | [help.tallysolutions.com/developer-reference/](https://help.tallysolutions.com/developer-reference/) | Root of all developer docs including TDL reference, integration, and what's new. |

### A.2 Getting Started & Architecture

| Page | URL | What You'll Learn |
|---|---|---|
| **Getting Started with Tally Integrations** | [help.tallysolutions.com/getting-started-with-tally-integrations/](https://help.tallysolutions.com/getting-started-with-tally-integrations/) | Business benefits, supported formats (XML/JSON/ODBC), push vs pull models, Tally as server vs client. **Includes downloadable sample files.** |
| **Integration Methods and Technologies** | [help.tallysolutions.com/integration-methods-and-technologies/](https://help.tallysolutions.com/integration-methods-and-technologies/) | TDL-based vs external integration. JSON & XML format support. DLL integration. Comparison of approaches. (Updated Nov 2025) |
| **Pre-requisites for Integrations** | [help.tallysolutions.com/pre-requisites-for-integrations/](https://help.tallysolutions.com/pre-requisites-for-integrations/) | How to enable HTTP server, ODBC, port config, company loading. |

### A.3 Integration by Direction (Push/Pull)

| Page | URL | What You'll Learn |
|---|---|---|
| **Integration Initiated from Tally** | [help.tallysolutions.com/integration-initiated-from-tally/](https://help.tallysolutions.com/integration-initiated-from-tally/) | Tally as client — pulling data from external APIs, ODBC queries to external DBs. |
| **Integration Initiated From TPAs** ⭐ | [help.tallysolutions.com/integration-initiated-from-tpas/](https://help.tallysolutions.com/integration-initiated-from-tpas/) | **Most relevant for MCP server.** External apps pulling data from Tally (reports, collections) and pushing data into Tally (masters, vouchers). Includes sample XML for both directions. |

### A.4 Method-Specific Integration (XML / JSON / ODBC)

#### XML (Primary method for MCP server)

| Page | URL | What You'll Learn |
|---|---|---|
| **XML Integration** (Overview) | [help.tallysolutions.com/xml-integration/](https://help.tallysolutions.com/xml-integration/) | XML schema overview, base document structure (`ENVELOPE > HEADER + BODY`), common tags explained, import template. (Updated Aug 2025) |
| **Understanding Tally XML Tags** ⭐ | [help.tallysolutions.com/understanding-tally-xml-tags/](https://help.tallysolutions.com/understanding-tally-xml-tags/) | **Deep dive into every XML tag.** Header tags (VERSION, TALLYREQUEST, TYPE, ID, STATUS), Body tags (STATICVARIABLES, REPEATVARIABLES, FETCHLIST, FUNCPARAMLIST, TDL). Essential reading. (Updated Aug 2025) |
| **Sample XML** ⭐ | [help.tallysolutions.com/sample-xml/](https://help.tallysolutions.com/sample-xml/) | Ready-to-use XML for exporting Trial Balance, and how to export any report by name. Shows how to embed custom TDL in XML requests. Lists frequently used report names. (Updated Aug 2025) |
| **Integration Using XML Interface** (Old ref) | [help.tallysolutions.com/xml-interface/](https://help.tallysolutions.com/xml-interface/) | Overview of Tally as server/client via XML. Links to sub-pages for each role. |
| **TallyPrime as Server** | [help.tallysolutions.com/tally/tallyprime-as-server/](https://help.tallysolutions.com/tally/tallyprime-as-server/) | Detailed: how external apps send XML to Tally and receive responses. |
| **TallyPrime as Client** | [help.tallysolutions.com/tally/tallyprime_as_a_client/](https://help.tallysolutions.com/tally/tallyprime_as_a_client/) | Tally pulling data from web services. |
| **Generic JSON and XML Attributes** | [help.tallysolutions.com/general-attributes-integration/](https://help.tallysolutions.com/general-attributes-integration/) | How to use generic attributes for XML/JSON data exchange in TDL. |
| **XML/JSON Strings as Data Sources** | [help.tallysolutions.com/data-sources-xml-and-json-string/](https://help.tallysolutions.com/data-sources-xml-and-json-string/) | Using XML/JSON strings directly as collection data sources in TDL. |

#### JSON (Newer alternative to XML)

| Page | URL | What You'll Learn |
|---|---|---|
| **Integration Using JSON** | [help.tallysolutions.com/tally-prime-integration-using-json-1/](https://help.tallysolutions.com/tally-prime-integration-using-json-1/) | JSON-based import/export via TDL customization. Newer approach. |
| **JSON-Based Export/Import** (Old ref) | [help.tallysolutions.com/json-based-export-import/](https://help.tallysolutions.com/json-based-export-import/) | JSON format details for data exchange. |

#### ODBC

| Page | URL | What You'll Learn |
|---|---|---|
| **ODBC Integrations** | [help.tallysolutions.com/odbc-integrations/](https://help.tallysolutions.com/odbc-integrations/) | ODBC server setup, exposing collections as tables, SQL queries, stored procedures. (Updated Aug 2025) |
| **Integration Using ODBC Interface** | [help.tallysolutions.com/using-odbc-interface/](https://help.tallysolutions.com/using-odbc-interface/) | ODBC client/server roles, DSN setup, TDL for ODBC. (Updated Jul 2025) |

### A.5 References & Case Studies

| Page | URL | What You'll Learn |
|---|---|---|
| **Integration With TallyPrime** ⭐⭐ | [help.tallysolutions.com/integration-with-tallyprime/](https://help.tallysolutions.com/integration-with-tallyprime/) | **THE single most comprehensive page.** 48-minute read. Covers: HTTP setup, XML request/response structure, sample code (PHP/Java/C#/VB.NET), creating masters (Groups, Ledgers with GST, address), all voucher types (Sales in voucher mode, Sales in invoice mode, with/without inventory), voucher alteration/cancellation, and report export. **Start here for voucher XML schemas.** (Updated Jul 2025) |
| **Case Study 1 — XML Request & Response** | [help.tallysolutions.com/case-study-1/](https://help.tallysolutions.com/case-study-1/) | Worked examples: export Trial Balance, export custom TDL reports, export objects/collections, import masters, import vouchers, alter/delete masters, execute actions. |
| **XML Message Formats** | [help.tallysolutions.com/developer-reference/integration-capabilities/xml-message-formats/](https://help.tallysolutions.com/developer-reference/integration-capabilities/xml-message-formats/) | Detailed tag reference for request/response XML. |

### A.6 Real-World Scenarios (Newer docs, mid-2025)

| Page | URL | What You'll Learn |
|---|---|---|
| **Scenario 1** | [help.tallysolutions.com/scenario-1/](https://help.tallysolutions.com/scenario-1/) | End-to-end integration scenario with examples. |
| **Scenario 2** | [help.tallysolutions.com/scenario-2/](https://help.tallysolutions.com/scenario-2/) | Second integration scenario. |
| **Scenario 3** | [help.tallysolutions.com/scenario-3/](https://help.tallysolutions.com/scenario-3/) | Third integration scenario. |

### A.7 TDL Developer Reference (For custom reports/collections)

| Page | URL | What You'll Learn |
|---|---|---|
| **TDL Reference — Introduction** | [help.tallysolutions.com/developer-reference/tally-definition-language/](https://help.tallysolutions.com/developer-reference/tally-definition-language/) | TDL language overview, components, symbols, prefixes. |
| **Objects and Collections** | (Under TDL Reference) | How Tally stores data internally. Critical for understanding what you can export. |
| **Reports, Printing and Validation** | [help.tallysolutions.com/developer-reference/tally-definition-language/what-is-reports-and-printing-in-tdl/](https://help.tallysolutions.com/developer-reference/tally-definition-language/what-is-reports-and-printing-in-tdl/) | How TDL reports work (tabular, hierarchical, columnar, drill-down). Explains why report names like "Trial Balance", "Profit and Loss" work in XML exports. |
| **Functions in TDL** | (Under TDL Reference) | Built-in functions like `$$IsDr`, `$$IsCr`, `$$IsLedger`, `$$SysName`. Used in STATICVARIABLES and custom collections. |

### A.8 Downloadable Resources

| Resource | URL | What It Is |
|---|---|---|
| **Integration Demo Samples** (ZIP) ⭐ | [help.tallysolutions.com/wp-content/uploads/2025/07/Integration_Demo_Samples.zip](https://help.tallysolutions.com/wp-content/uploads/2025/07/Integration_Demo_Samples.zip) | Official sample files with XML tags, TDL snippets, request-response examples. **Download this first.** (Jul 2025) |
| **Integration Capabilities Videos** | [help.tallysolutions.com/integration-capabilities-videos/](https://help.tallysolutions.com/integration-capabilities-videos/) | Video library covering XML integration, ODBC, data push/pull. |
| **Financial Statements for NCE** | [help.tallysolutions.com/financial-statements-for-nce/](https://help.tallysolutions.com/financial-statements-for-nce/) | How TallyPrime exports financial data (Trial Balance, P&L, Balance Sheet) as XML for regulatory compliance. Shows the XML-to-Excel mapping workflow. |

### A.9 Recommended Reading Order for MCP Server Development

**For Reads (Phase 1):**
1. [Getting Started with Tally Integrations](https://help.tallysolutions.com/getting-started-with-tally-integrations/) — Understand the architecture
2. [Integration With TallyPrime](https://help.tallysolutions.com/integration-with-tallyprime/) — The 48-min comprehensive reference (scroll to "Export Reports" section)
3. [Understanding Tally XML Tags](https://help.tallysolutions.com/understanding-tally-xml-tags/) — Master the XML structure
4. [Sample XML](https://help.tallysolutions.com/sample-xml/) — Copy-paste report export examples
5. [Integration Initiated From TPAs](https://help.tallysolutions.com/integration-initiated-from-tpas/) — Pull patterns for external apps
6. Download the [Integration Demo Samples ZIP](https://help.tallysolutions.com/wp-content/uploads/2025/07/Integration_Demo_Samples.zip)

**For Writes (Phase 2):**
1. [Integration With TallyPrime](https://help.tallysolutions.com/integration-with-tallyprime/) — Scroll to "Accounting Masters" and "Vouchers" sections for create/alter/delete XML schemas for every voucher type (Sales voucher mode, Sales invoice mode, Purchase, Payment, Receipt, Journal, Contra)
2. [Case Study 1](https://help.tallysolutions.com/case-study-1/) — Import masters, import vouchers, duplicate handling
3. [Integration Initiated From TPAs](https://help.tallysolutions.com/integration-initiated-from-tpas/) — Push patterns, validation, error handling

---

*This document is a living reference. Update as Tally releases new versions and as the MCP ecosystem evolves.*
