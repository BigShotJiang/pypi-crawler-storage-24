import click
import os
import uuid
import time


@click.command()
@click.option("--all", "validate_all", is_flag=True, help="Validate all registered contracts")
@click.option("--contract", help="Validate a specific contract by name")
@click.option(
    "--config",
    "config_path",
    default="./dcvpg.config.yaml",
    show_default=True,
    help="Path to dcvpg.config.yaml",
)
def validate(validate_all, contract, config_path):
    """Run validation manually against configured data sources."""
    if not validate_all and not contract:
        click.echo("Please specify --all or --contract <name>")
        raise SystemExit(1)

    if not os.path.exists(config_path):
        click.echo(f"Error: Config file not found: {config_path}")
        raise SystemExit(1)

    try:
        from dcvpg.config.config_loader import load_config
        from dcvpg.engine.registry import ContractRegistry
        from dcvpg.engine.validator import Validator
        from dcvpg.engine.quarantine_engine import QuarantineEngine
        from dcvpg.engine.connectors.postgres_connector import PostgresConnector
        from dcvpg.engine.connectors.mysql_connector import MySQLConnector
        from dcvpg.engine.connectors.snowflake_connector import SnowflakeConnector
        from dcvpg.engine.connectors.bigquery_connector import BigQueryConnector
        from dcvpg.engine.connectors.s3_connector import S3Connector
        from dcvpg.engine.connectors.gcs_connector import GCSConnector
        from dcvpg.engine.connectors.rest_api_connector import RestApiConnector
        from dcvpg.engine.connectors.file_connector import FileConnector

        _CONNECTOR_MAP = {
            "postgres":  PostgresConnector,
            "mysql":     MySQLConnector,
            "snowflake": SnowflakeConnector,
            "bigquery":  BigQueryConnector,
            "s3":        S3Connector,
            "gcs":       GCSConnector,
            "rest":      RestApiConnector,
            "file":      FileConnector,
        }

        config = load_config(config_path)
        registry = ContractRegistry(config.contracts.directory)
        contracts = registry.list_contracts() if validate_all else [registry.get_contract(contract)]

        def _get_connector(type_str):
            connector_cls = _CONNECTOR_MAP.get(type_str)
            if connector_cls is None:
                supported = ", ".join(_CONNECTOR_MAP.keys())
                raise NotImplementedError(
                    f"Connector for '{type_str}' not available in CLI. Supported: {supported}"
                )
            return connector_cls()

        pass_count = 0
        fail_count = 0

        for c in contracts:
            click.echo(f"Validating {c.name} v{c.version}...")
            conn_config = next((x for x in config.connections if x.name == c.source_connection), None)
            if not conn_config:
                click.echo(f"  ⚠️  Connection '{c.source_connection}' not found in config — skipping")
                fail_count += 1
                continue

            try:
                connector = _get_connector(conn_config.type)
                connector.connect(conn_config.model_dump())
                source = getattr(c, "source_table", None) or c.name
                start = time.time()
                df = connector.fetch_batch(source=source, batch_id=str(uuid.uuid4()))
                duration_ms = int((time.time() - start) * 1000)
                custom_dir = config.extensions.custom_rules_dir if config.extensions else None
                engine = Validator(c, custom_dir)
                report = engine.validate_batch(df, pipeline_name=c.name, duration_ms=duration_ms)

                if report.status == "PASSED":
                    click.echo(f"  ✅ PASSED — {report.rows_processed} rows in {duration_ms}ms")
                    pass_count += 1
                else:
                    click.echo(
                        f"  ❌ FAILED — {report.violations_count} violations on {report.rows_processed} rows"
                    )
                    for v in report.violation_details[:5]:
                        click.echo(f"     • {v.field}: {v.violation_type} (rows: {v.rows_affected})")
                    fail_count += 1
                    quarantine = QuarantineEngine(config.database.model_dump())
                    quarantine.isolate_batch(report, str(uuid.uuid4()))

            except Exception as e:
                click.echo(f"  💥 Error validating {c.name}: {e}")
                fail_count += 1

        click.echo(f"\nResults: {pass_count} PASSED | {fail_count} FAILED")
        if fail_count > 0:
            raise SystemExit(1)

    except ImportError as e:
        click.echo(f"Import error: {e}. Is dcvpg properly installed?")
        raise SystemExit(1)
