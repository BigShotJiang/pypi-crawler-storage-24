# ----------------------------------------------------------------------------------------
#   gitlab_api
#   ----------
#
#   GitLab REST API client for accessing the package registry and group structures.
#   Uses only Python stdlib (urllib.request) - no external dependencies.
#
#   Supports:
#   - Auto-detecting whether a path is a group or project
#   - Listing all projects within a group (including subgroups)
#   - Listing packages and their files
#   - Downloading package files
#   - Uploading files to the generic package registry
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Mar 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from dataclasses import field
from pathlib import Path
from typing import Any

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class ProjectInfo:
    """Information about a GitLab project."""

    id: int
    name: str
    path_with_namespace: str


@dataclass
class PackageFileInfo:
    """A file within a package version."""

    id: int
    package_id: int
    file_name: str
    size: int
    file_sha256: str
    created_at: str


@dataclass
class PackageInfo:
    """Information about a package within a project."""

    id: int
    name: str
    version: str
    package_type: str
    created_at: str
    project_id: int
    files: list[PackageFileInfo] = field(
        default_factory=lambda: list[PackageFileInfo]()
    )


# ----------------------------------------------------------------------------------------
#   GitLab Client
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
class GitLabClient:
    """
    Client for interacting with GitLab's Package Registry and Groups API.

    Supports both public and private projects (via access token).
    """

    # ------------------------------------------------------------------------------------
    def __init__(self, gitlab_url: str, token: str | None = None):
        """
        Initialise the GitLab client.

        Parameters:
            gitlab_url: Base URL of the GitLab instance (e.g., https://gitlab.com)
            token: Optional private access token for authentication
        """
        # Ensure URL has a scheme
        url = gitlab_url.rstrip("/")
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        self.gitlab_url = url
        self.token = token
        self.logger = logging.getLogger(__name__)

    # ------------------------------------------------------------------------------------
    def _api_url(self, endpoint: str) -> str:
        """Build full API URL for an endpoint."""
        return f"{self.gitlab_url}/api/v4{endpoint}"

    # ------------------------------------------------------------------------------------
    def _request(self, url: str) -> Any:
        """
        Make an HTTP GET request and return parsed JSON response.

        Parameters:
            url: Full URL to request

        Returns:
            Parsed JSON response

        Raises:
            urllib.error.HTTPError: On HTTP errors
            urllib.error.URLError: On connection errors
        """
        self.logger.debug(f"GET {url}")

        request = urllib.request.Request(url)
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)

    # ------------------------------------------------------------------------------------
    def _paginated_request(self, url: str) -> list[Any]:
        """
        Make paginated API requests and return all results.

        GitLab's API returns paginated results. This method follows pagination
        headers to fetch all pages.

        Parameters:
            url: Base URL (without pagination parameters)

        Returns:
            List of all results across all pages
        """
        results: list[Any] = []
        page = 1
        per_page = 100

        while True:
            separator = "&" if "?" in url else "?"
            paginated_url = f"{url}{separator}page={page}&per_page={per_page}"

            self.logger.debug(f"GET {paginated_url}")

            request = urllib.request.Request(paginated_url)
            request.add_header("Accept", "application/json")
            if self.token:
                request.add_header("PRIVATE-TOKEN", self.token)

            with urllib.request.urlopen(request) as response:
                data = response.read().decode("utf-8")
                page_results = json.loads(data)

                if not page_results:
                    break

                results.extend(page_results)

                # Check if there are more pages
                total_pages_header = response.headers.get("X-Total-Pages")
                if total_pages_header:
                    total_pages = int(total_pages_header)
                    if page >= total_pages:
                        break
                elif len(page_results) < per_page:
                    # No pagination headers, use result count as heuristic
                    break

                page += 1

        return results

    # ------------------------------------------------------------------------------------
    def _put_file(self, url: str, file_path: Path) -> Any:
        """
        Upload a file via HTTP PUT.

        Parameters:
            url: Full URL to PUT to
            file_path: Path to the file to upload

        Returns:
            Parsed JSON response

        Raises:
            urllib.error.HTTPError: On HTTP errors
            urllib.error.URLError: On connection errors
        """
        self.logger.debug(f"PUT {url}")

        file_data = file_path.read_bytes()

        request = urllib.request.Request(url, data=file_data, method="PUT")
        request.add_header("Content-Type", "application/octet-stream")
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            return json.loads(response.read().decode("utf-8"))

    # ------------------------------------------------------------------------------------
    def resolve_path(self, path: str) -> tuple[str, int]:
        """
        Determine whether a GitLab path refers to a group or a project.

        Tries the project API first, then the group API.

        Parameters:
            path: GitLab path (e.g., "group/subgroup/project" or "group/subgroup")

        Returns:
            Tuple of (path_type, id) where path_type is "project" or "group"

        Raises:
            ValueError: If the path is neither a valid project nor group
            urllib.error.URLError: On connection errors
        """
        encoded_path = urllib.parse.quote(path, safe="")

        # Try as a project first
        try:
            project_data = self._request(self._api_url(f"/projects/{encoded_path}"))
            return ("project", int(project_data["id"]))
        except (urllib.error.HTTPError, TypeError, KeyError) as e:
            if isinstance(e, urllib.error.HTTPError) and e.code != 404:
                raise

        # Try as a group
        try:
            group_data = self._request(self._api_url(f"/groups/{encoded_path}"))
            return ("group", int(group_data["id"]))
        except (urllib.error.HTTPError, TypeError, KeyError) as e:
            if isinstance(e, urllib.error.HTTPError) and e.code != 404:
                raise

        raise ValueError(f"Path not found as project or group: {path}")

    # ------------------------------------------------------------------------------------
    def get_group_projects(
        self,
        group_id: int,
        project_filter: str | None = None,
    ) -> list[ProjectInfo]:
        """
        List all projects within a group, including subgroups.

        Parameters:
            group_id: The numeric group ID
            project_filter: Optional substring filter for project paths

        Returns:
            List of ProjectInfo objects
        """
        url = self._api_url(
            f"/groups/{group_id}/projects"
            "?include_subgroups=true&simple=true&archived=false"
            "&order_by=path&sort=asc"
        )

        try:
            projects_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"Group not found: {group_id}")
                return []
            raise

        projects: list[ProjectInfo] = []
        for proj in projects_data:
            # Skip projects pending deletion
            if proj.get("marked_for_deletion_at"):
                continue

            info = ProjectInfo(
                id=proj["id"],
                name=proj["name"],
                path_with_namespace=proj["path_with_namespace"],
            )

            # Apply project filter if specified
            if project_filter:
                if project_filter.lower() not in info.path_with_namespace.lower():
                    continue

            projects.append(info)

        projects.sort(key=lambda p: p.path_with_namespace)
        return projects

    # ------------------------------------------------------------------------------------
    def get_project_info(self, project_id: int) -> ProjectInfo | None:
        """
        Get project information by ID.

        Parameters:
            project_id: The numeric project ID

        Returns:
            ProjectInfo if found, None otherwise
        """
        url = self._api_url(f"/projects/{project_id}")

        try:
            data = self._request(url)
            return ProjectInfo(
                id=data["id"],
                name=data["name"],
                path_with_namespace=data["path_with_namespace"],
            )
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise

    # ------------------------------------------------------------------------------------
    def list_packages(
        self,
        project_id: int,
        package_type: str | None = None,
    ) -> list[PackageInfo]:
        """
        List all packages for a project.

        Parameters:
            project_id: The numeric project ID
            package_type: Optional package type filter (e.g., "generic", "pypi")

        Returns:
            List of PackageInfo objects (without files populated)
        """
        url = self._api_url(f"/projects/{project_id}/packages?order_by=name&sort=asc")

        if package_type:
            url += f"&package_type={urllib.parse.quote(package_type, safe='')}"

        try:
            packages_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"No packages found for project: {project_id}")
                return []
            raise

        packages: list[PackageInfo] = []
        for pkg in packages_data:
            # Skip packages in error state
            if pkg.get("status") == "error":
                continue

            packages.append(
                PackageInfo(
                    id=pkg["id"],
                    name=pkg["name"],
                    version=pkg["version"],
                    package_type=pkg["package_type"],
                    created_at=pkg.get("created_at", ""),
                    project_id=project_id,
                )
            )

        return packages

    # ------------------------------------------------------------------------------------
    def list_package_files(
        self,
        project_id: int,
        package_id: int,
    ) -> list[PackageFileInfo]:
        """
        List all files for a specific package.

        Parameters:
            project_id: The numeric project ID
            package_id: The numeric package ID

        Returns:
            List of PackageFileInfo objects
        """
        url = self._api_url(
            f"/projects/{project_id}/packages/{package_id}/package_files"
        )

        try:
            files_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"No files found for package: {package_id}")
                return []
            raise

        files: list[PackageFileInfo] = []
        for f in files_data:
            files.append(
                PackageFileInfo(
                    id=f["id"],
                    package_id=package_id,
                    file_name=f["file_name"],
                    size=f.get("size", 0),
                    file_sha256=f.get("file_sha256", ""),
                    created_at=f.get("created_at", ""),
                )
            )

        return files

    # ------------------------------------------------------------------------------------
    def download_package_file(
        self,
        project_id: int,
        package_id: int,
        package_file_id: int,
    ) -> bytes:
        """
        Download a package file by its ID.

        Uses the package file download endpoint which works for all package types.

        Parameters:
            project_id: The numeric project ID
            package_id: The numeric package ID
            package_file_id: The numeric package file ID

        Returns:
            File contents as bytes

        Raises:
            urllib.error.HTTPError: On HTTP errors
        """
        url = self._api_url(
            f"/projects/{project_id}/packages/{package_id}"
            f"/package_files/{package_file_id}/download"
        )

        self.logger.debug(f"Downloading: {url}")
        request = urllib.request.Request(url)
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        try:
            with urllib.request.urlopen(request) as response:
                return response.read()
        except urllib.error.HTTPError as e:
            e.read()
            raise

    # ------------------------------------------------------------------------------------
    def upload_generic_package_file(
        self,
        project_id: int,
        package_name: str,
        package_version: str,
        file_path: Path,
    ) -> None:
        """
        Upload a file to the generic package registry.

        Parameters:
            project_id: The numeric project ID
            package_name: Name of the package
            package_version: Version of the package
            file_path: Path to the file to upload

        Raises:
            urllib.error.HTTPError: On API errors
        """
        encoded_name = urllib.parse.quote(package_name, safe="")
        encoded_version = urllib.parse.quote(package_version, safe="")
        encoded_file = urllib.parse.quote(file_path.name, safe="")

        url = self._api_url(
            f"/projects/{project_id}/packages/generic"
            f"/{encoded_name}/{encoded_version}/{encoded_file}"
        )

        self._put_file(url, file_path)

    # ------------------------------------------------------------------------------------
    def list_generic_package_files(
        self,
        project_id: int,
        package_name: str,
        package_version: str,
    ) -> list[PackageFileInfo]:
        """
        List files for a specific generic package version.

        This fetches the package by name/version and then lists its files,
        returning full file info including SHA256 for existence and integrity
        checking.

        Parameters:
            project_id: The numeric project ID
            package_name: Name of the package
            package_version: Version of the package

        Returns:
            List of PackageFileInfo objects in the package version
        """
        # Find the package by name and version
        encoded_name = urllib.parse.quote(package_name, safe="")
        encoded_version = urllib.parse.quote(package_version, safe="")
        url = self._api_url(
            f"/projects/{project_id}/packages"
            f"?package_name={encoded_name}&package_version={encoded_version}"
            f"&package_type=generic"
        )

        try:
            packages_data = self._request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return []
            raise

        if not packages_data:
            return []

        # Get files for the first matching package
        package_id = packages_data[0]["id"]
        return self.list_package_files(project_id, package_id)
