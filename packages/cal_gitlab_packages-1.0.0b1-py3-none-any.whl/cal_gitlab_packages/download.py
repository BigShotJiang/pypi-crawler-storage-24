# ----------------------------------------------------------------------------------------
#   download
#   --------
#
#   Core download orchestration - resolves GitLab paths (group or project), fetches
#   package files, and saves them to disk. Skips already-downloaded files by default.
#
#   Downloads are parallelised using a thread pool for fast I/O throughput.
#
#   Output directory structure:
#
#       output_dir/
#           relative/project/path/
#               package_name/
#                   version/
#                       file_1
#                       file_2
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Mar 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
import sys
import urllib.error
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from dataclasses import dataclass
from dataclasses import field
from datetime import UTC
from datetime import datetime
from pathlib import Path
from typing import Any
from .colour import bold
from .colour import cyan
from .colour import green
from .colour import red
from .colour import yellow
from .gitlab_api import GitLabClient
from .gitlab_api import PackageInfo
from .gitlab_api import ProjectInfo
from .version_filter import matches_version_filter

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class DownloadResult:
    """Result of a download operation."""

    success: bool
    total_projects: int = 0
    total_packages: int = 0
    total_files: int = 0
    downloaded_files: int = 0
    skipped_files: int = 0
    failed_files: int = 0
    error_message: str | None = None
    downloaded_paths: list[Path] = field(default_factory=lambda: list[Path]())


@dataclass
class DownloadConfig:
    """Configuration for the download operation."""

    gitlab_url: str
    path: str
    output_dir: Path
    token: str | None = None
    version_filter: str = "release"
    project_filter: str | None = None
    package_type: str | None = None
    overwrite: bool = False
    flat: bool = False
    parallel: int = 32
    manifest_path: Path | None = None


@dataclass
class _DownloadTask:
    """A single file download task."""

    project_id: int
    package_id: int
    package_file_id: int
    file_path: Path
    package_name: str
    package_version: str
    file_name: str
    project_path: str


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def download_packages(config: DownloadConfig) -> DownloadResult:
    """
    Download package files from a GitLab project or group.

    If the path is a group, all projects within the group (including subgroups)
    are processed. If the path is a project, only that project is processed.

    Downloads are executed in parallel using a thread pool.

    Parameters:
        config: Download configuration

    Returns:
        DownloadResult with statistics about the download
    """
    logger = logging.getLogger(__name__)

    # Validate output directory
    output_dir = config.output_dir
    if not output_dir.exists():
        print(f"Creating output directory: {output_dir}")
        output_dir.mkdir(parents=True, exist_ok=True)

    # Create GitLab client
    client = GitLabClient(config.gitlab_url, token=config.token)

    # Resolve path to group or project
    print(f"Connecting to {config.gitlab_url}...")

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        return DownloadResult(success=False, error_message=str(e))
    except urllib.error.URLError as e:
        return DownloadResult(
            success=False,
            error_message=f"Failed to connect to GitLab: {e}",
        )

    # Gather list of projects to process
    projects: list[ProjectInfo] = []

    if path_type == "group":
        print(f"Found group: {config.path}")

        try:
            projects = client.get_group_projects(
                path_id, project_filter=config.project_filter
            )
        except urllib.error.HTTPError as e:
            return DownloadResult(
                success=False,
                error_message=f"Failed to list group projects: {e}",
            )

        if config.project_filter:
            print(
                f"Found {len(projects)} project(s) matching filter "
                f"'{config.project_filter}'"
            )
        else:
            print(f"Found {len(projects)} project(s) in group")

    else:
        # Single project
        print(f"Found project: {config.path}")
        project_info = client.get_project_info(path_id)
        if project_info is None:
            return DownloadResult(
                success=False,
                error_message=f"Project not found: {config.path}",
            )
        projects = [project_info]

    if not projects:
        print("No projects found matching the specified filters.")
        return DownloadResult(success=True, total_projects=0)

    result = DownloadResult(
        success=True,
        total_projects=len(projects),
    )

    # Load manifest for incremental downloads
    manifest: dict[str, dict[str, str]] = {}
    if config.manifest_path:
        manifest = _load_manifest(config.manifest_path)

    # Phase 1: Fetch package lists in parallel, then gather download tasks
    all_tasks: list[_DownloadTask] = []
    is_group = path_type == "group"
    group_path = config.path if is_group else None

    # Fetch package listings in parallel, processing each project as results arrive
    for project, packages in _fetch_packages_streaming(
        client, projects, config.parallel, config.package_type
    ):
        tasks, skipped, package_count = _gather_project_tasks(
            client=client,
            project=project,
            packages=packages,
            config=config,
            output_dir=output_dir,
            is_group=is_group,
            group_path=group_path,
            manifest=manifest,
        )
        all_tasks.extend(tasks)
        result.skipped_files += skipped
        result.total_packages += package_count

    result.total_files = len(all_tasks) + result.skipped_files

    if not all_tasks:
        if config.manifest_path and manifest:
            _save_manifest(config.manifest_path, manifest)
        return result

    # Phase 2: Download in parallel
    print(f"\nDownloading {len(all_tasks)} file(s) with {config.parallel} threads...")

    with ThreadPoolExecutor(max_workers=config.parallel) as executor:
        futures_list = [
            executor.submit(_download_single_file, client, task) for task in all_tasks
        ]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed_dl: dict[int, BaseException | None] = {}
        next_to_print = 0
        printed = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            error: BaseException | None = None
            try:
                future.result()
            except (urllib.error.HTTPError, urllib.error.URLError) as e:
                error = e
            completed_dl[idx] = error

            # Flush consecutive results in submission order
            while next_to_print in completed_dl:
                err = completed_dl.pop(next_to_print)
                task = all_tasks[next_to_print]
                printed += 1
                progress = f"[{printed}/{len(all_tasks)}]"

                if err is None:
                    result.downloaded_files += 1
                    result.downloaded_paths.append(task.file_path)
                    print(
                        f"  {green('Downloaded')} - "
                        f"{task.package_name}/{task.package_version}: "
                        f"{task.file_name}  {progress}"
                    )
                else:
                    logger.debug(f"Failed to download {task.file_name}: {err}")
                    result.failed_files += 1
                    reason = ""
                    if isinstance(err, urllib.error.HTTPError):
                        reason = f" ({err.code})"
                    print(
                        f"  {red('Error')}{reason:6s} - "
                        f"{task.package_name}/{task.package_version}: "
                        f"{task.file_name}  {progress}"
                    )
                next_to_print += 1

    # Update manifest with all attempted downloads (successful and failed)
    if config.manifest_path:
        now = datetime.now(UTC).isoformat()
        for task in all_tasks:
            key = str(task.file_path.relative_to(output_dir))
            status = (
                "downloaded" if task.file_path in result.downloaded_paths else "failed"
            )
            manifest[key] = {"path": key, "status": status, "downloaded": now}
        _save_manifest(config.manifest_path, manifest)

    return result


# ----------------------------------------------------------------------------------------
def _fetch_packages_streaming(
    client: GitLabClient,
    projects: list[ProjectInfo],
    max_workers: int,
    package_type: str | None,
) -> Iterator[tuple[ProjectInfo, list[PackageInfo]]]:
    """
    Fetch package listings for multiple projects in parallel, yielding results
    in the original project order as they become available.

    Results are buffered so that earlier projects are always yielded first,
    even if later projects finish sooner.

    Parameters:
        client: GitLab API client
        projects: Projects to fetch packages for
        max_workers: Number of parallel threads
        package_type: Optional package type filter

    Yields:
        (project, packages) tuples in the original project order
    """
    logger = logging.getLogger(__name__)

    def fetch(project: ProjectInfo) -> list[PackageInfo]:
        try:
            return client.list_packages(project.id, package_type=package_type)
        except urllib.error.HTTPError as e:
            logger.warning(
                f"Failed to list packages for {project.path_with_namespace}: {e}"
            )
            return []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures_list = [executor.submit(fetch, p) for p in projects]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed: dict[int, list[PackageInfo]] = {}
        next_idx = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            completed[idx] = future.result()

            while next_idx in completed:
                yield projects[next_idx], completed.pop(next_idx)
                next_idx += 1


# ----------------------------------------------------------------------------------------
def _gather_project_tasks(
    *,
    client: GitLabClient,
    project: ProjectInfo,
    packages: list[PackageInfo] | None,
    config: DownloadConfig,
    output_dir: Path,
    is_group: bool,
    group_path: str | None,
    manifest: dict[str, dict[str, str]],
) -> tuple[list[_DownloadTask], int, int]:
    """
    Gather all download tasks for a single project from pre-fetched packages.

    Parameters:
        client: GitLab API client (for fetching package files)
        project: Project to gather tasks from
        packages: Pre-fetched packages (None or empty if fetch failed)
        config: Download configuration
        output_dir: Base output directory
        is_group: Whether we're processing a group
        group_path: The group path (for calculating relative project paths)
        manifest: Dict mapping relative paths to manifest entries

    Returns:
        Tuple of (download_tasks, skipped_count, package_count)
    """
    print(f"\n{bold(project.path_with_namespace)}")

    # Determine project output directory
    if config.flat:
        project_dir = output_dir
    elif is_group and group_path:
        relative_path = project.path_with_namespace
        if relative_path.startswith(group_path + "/"):
            relative_path = relative_path[len(group_path) + 1 :]
        project_dir = output_dir / relative_path
    else:
        project_dir = output_dir

    if not packages:
        print(f"  {cyan('No packages found')}")
        return [], 0, 0

    # Filter packages by version
    filtered_packages = [
        p for p in packages if matches_version_filter(p.version, config.version_filter)
    ]

    if len(filtered_packages) < len(packages):
        print(
            f"  Filtered to {len(filtered_packages)} of {len(packages)} package(s) "
            f"(mode: {config.version_filter})"
        )

    if not filtered_packages:
        print(f"  {cyan('No packages match version filter')}")
        return [], 0, 0

    # Fetch files for each package and gather tasks
    tasks: list[_DownloadTask] = []
    skipped = 0

    for package in filtered_packages:
        # Fetch files for this package
        try:
            files = client.list_package_files(project.id, package.id)
        except urllib.error.HTTPError as e:
            logging.getLogger(__name__).warning(
                f"Failed to list files for {package.name}/{package.version}: {e}"
            )
            continue

        package.files = files

        pkg_tasks, pkg_skipped = _gather_package_tasks(
            package=package,
            project_dir=project_dir,
            output_dir=output_dir,
            config=config,
            project=project,
            manifest=manifest,
        )
        tasks.extend(pkg_tasks)
        skipped += pkg_skipped

    return tasks, skipped, len(filtered_packages)


# ----------------------------------------------------------------------------------------
def _gather_package_tasks(
    *,
    package: PackageInfo,
    project_dir: Path,
    output_dir: Path,
    config: DownloadConfig,
    project: ProjectInfo,
    manifest: dict[str, dict[str, str]],
) -> tuple[list[_DownloadTask], int]:
    """
    Gather download tasks for a single package.

    Parameters:
        package: Package to gather tasks from
        project_dir: Project output directory
        output_dir: Base output directory (for computing manifest keys)
        config: Download configuration
        project: Project info for display
        manifest: Dict mapping relative paths to manifest entries

    Returns:
        Tuple of (download_tasks, skipped_count)
    """
    if not package.files:
        return [], 0

    if config.flat:
        version_dir = output_dir
    else:
        version_dir = project_dir / package.name / package.version

    dir_created = False

    tasks: list[_DownloadTask] = []
    skipped = 0

    for pkg_file in package.files:
        file_path = version_dir / pkg_file.file_name
        file_desc = f"{package.name}/{package.version}: {pkg_file.file_name}"
        relative_key = str(file_path.relative_to(output_dir))

        # Skip if already in manifest or file exists on disk
        if not config.overwrite:
            if relative_key in manifest or file_path.exists():
                if relative_key not in manifest:
                    manifest[relative_key] = {"path": relative_key, "status": "exists"}
                skipped += 1
                print(f"  {yellow('Skipped')}    - {file_desc}")
                continue

        if not dir_created:
            version_dir.mkdir(parents=True, exist_ok=True)
            dir_created = True

        tasks.append(
            _DownloadTask(
                project_id=project.id,
                package_id=package.id,
                package_file_id=pkg_file.id,
                file_path=file_path,
                package_name=package.name,
                package_version=package.version,
                file_name=pkg_file.file_name,
                project_path=project.path_with_namespace,
            )
        )

    return tasks, skipped


# ----------------------------------------------------------------------------------------
def _download_single_file(client: GitLabClient, task: _DownloadTask) -> None:
    """
    Download a single file and write it to disk.

    This function runs in a worker thread.

    Parameters:
        client: GitLab API client
        task: Download task with project/package/file IDs and destination path
    """
    content = client.download_package_file(
        task.project_id, task.package_id, task.package_file_id
    )
    task.file_path.write_bytes(content)


# ----------------------------------------------------------------------------------------
def _load_manifest(manifest_path: Path) -> dict[str, dict[str, str]]:
    """
    Load the download manifest from disk.

    Parameters:
        manifest_path: Path to the manifest JSON file

    Returns:
        Dict mapping relative file paths to entry dicts (status, downloaded)
    """
    if not manifest_path.exists():
        return {}

    try:
        with manifest_path.open() as f:
            data: dict[str, Any] = json.load(f)
            entries: list[dict[str, str]] = data.get("entries", [])
            return {e["path"]: e for e in entries if "path" in e}
    except (json.JSONDecodeError, OSError, TypeError) as e:
        print(
            yellow(f"Warning: Could not read manifest {manifest_path}: {e}"),
            file=sys.stderr,
        )

    return {}


# ----------------------------------------------------------------------------------------
def _save_manifest(manifest_path: Path, manifest: dict[str, dict[str, str]]) -> None:
    """
    Save the download manifest to disk.

    Parameters:
        manifest_path: Path to the manifest JSON file
        manifest: Dict mapping relative file paths to entry dicts
    """
    entries = sorted(manifest.values(), key=lambda e: e.get("path", ""))
    data = {"entries": entries}
    try:
        with manifest_path.open("w") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
    except OSError as e:
        print(
            yellow(f"Warning: Could not write manifest {manifest_path}: {e}"),
            file=sys.stderr,
        )


# ----------------------------------------------------------------------------------------
def list_projects(config: DownloadConfig, *, json_output: bool = False) -> int:
    """
    List projects for the given path and exit.

    Parameters:
        config: Download configuration
        json_output: If True, output as JSON

    Returns:
        Exit code (0 for success, 1 for error)
    """
    client = GitLabClient(config.gitlab_url, token=config.token)

    if not json_output:
        print(f"Connecting to {config.gitlab_url}...")

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        print(f"\nError: {e}")
        return 1
    except urllib.error.URLError as e:
        print(f"\nError: Failed to connect to GitLab: {e}")
        return 1

    projects: list[ProjectInfo] = []

    if path_type == "group":
        try:
            projects = client.get_group_projects(
                path_id, project_filter=config.project_filter
            )
        except urllib.error.HTTPError as e:
            print(f"\nError: Failed to list group projects: {e}")
            return 1
    else:
        project_info = client.get_project_info(path_id)
        if project_info is None:
            print(f"\nError: Project not found: {config.path}")
            return 1
        projects = [project_info]

    if json_output:
        json_list: list[dict[str, object]] = [
            {"id": p.id, "path": p.path_with_namespace, "name": p.name}
            for p in projects
        ]
        print(json.dumps(json_list, indent=2))
    else:
        for project in projects:
            print(project.path_with_namespace)

    return 0


# ----------------------------------------------------------------------------------------
def list_packages(config: DownloadConfig, *, json_output: bool = False) -> int:
    """
    List packages for the given path and exit.

    Parameters:
        config: Download configuration
        json_output: If True, output as JSON

    Returns:
        Exit code (0 for success, 1 for error)
    """
    client = GitLabClient(config.gitlab_url, token=config.token)

    if not json_output:
        print(f"Connecting to {config.gitlab_url}...")

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        print(f"\nError: {e}")
        return 1
    except urllib.error.URLError as e:
        print(f"\nError: Failed to connect to GitLab: {e}")
        return 1

    projects: list[ProjectInfo] = []

    if path_type == "group":
        try:
            projects = client.get_group_projects(
                path_id, project_filter=config.project_filter
            )
        except urllib.error.HTTPError as e:
            print(f"\nError: Failed to list group projects: {e}")
            return 1
    else:
        project_info = client.get_project_info(path_id)
        if project_info is None:
            print(f"\nError: Project not found: {config.path}")
            return 1
        projects = [project_info]

    json_data: list[dict[str, object]] = []

    # Fetch package listings in parallel, processing each project as results arrive
    for project, packages in _fetch_packages_streaming(
        client, projects, config.parallel, config.package_type
    ):
        if not json_output:
            print(f"\n{bold(project.path_with_namespace)}")

        if not packages:
            if not json_output:
                print(f"  {cyan('No packages found')}")
            continue

        # Filter packages by version
        filtered = [
            p
            for p in packages
            if matches_version_filter(p.version, config.version_filter)
        ]

        if not json_output and len(filtered) < len(packages):
            print(
                f"  Filtered to {len(filtered)} of {len(packages)} package(s) "
                f"(mode: {config.version_filter})"
            )

        if json_output:
            for package in filtered:
                json_data.append(
                    {
                        "project": project.path_with_namespace,
                        "name": package.name,
                        "version": package.version,
                        "type": package.package_type,
                    }
                )
        else:
            for package in filtered:
                print(f"  {package.name} {package.version} ({package.package_type})")

    if json_output:
        print(json.dumps(json_data, indent=2))

    return 0


# ----------------------------------------------------------------------------------------
def format_result_summary(result: DownloadResult) -> str:
    """
    Format a human-readable summary of the download result.

    Parameters:
        result: The download result to summarise

    Returns:
        Formatted summary string
    """
    lines: list[str] = []
    lines.append("")
    lines.append("Download Summary")
    lines.append("================")
    lines.append(f"Total projects: {result.total_projects}")
    lines.append(f"Total packages: {result.total_packages}")
    lines.append(f"Total files:    {result.total_files}")
    lines.append(f"Downloaded:     {result.downloaded_files}")

    if result.skipped_files > 0:
        lines.append(f"Skipped:        {result.skipped_files} (already exist)")

    if result.failed_files > 0:
        lines.append(f"Failed:         {result.failed_files}")

    return "\n".join(lines)
