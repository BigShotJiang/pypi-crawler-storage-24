# ----------------------------------------------------------------------------------------
#   cli
#   ---
#
#   CLI definition and command dispatch. Provides two subcommands:
#
#   - download: Download package files from GitLab package registries
#   - upload:   Upload package files to GitLab generic package registry
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Mar 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import logging
import os
import sys
import traceback
from pathlib import Path
from typing import Any
from .argbuilder import ArgsParser
from .argbuilder import Namespace
from .colour import set_colours_enabled
from .config import DEFAULT_CONFIG_PATH
from .config import TOKEN_ENV
from .config import load_config
from .download import DownloadConfig
from .download import download_packages
from .download import format_result_summary as format_download_summary
from .download import list_packages
from .download import list_projects
from .upload import UploadConfig
from .upload import format_result_summary as format_upload_summary
from .upload import upload_packages
from .version import VERSION_STR
from .version_filter import FILTER_MODES

LICENSE_TEXT = """\
MIT License

Copyright (c) 2026 Cyber Assessment Labs

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE."""

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def get_args(argv: list[str]) -> Namespace:
    """
    Parse the CLI args.
    """

    p = ArgsParser(
        prog="cal-gitlab-packages",
        description=(
            f"cal-gitlab-packages: {VERSION_STR}\n"
            "(c) 2026 Cyber Assessment Labs. MIT License.\n\n"
            "Download and upload package files for GitLab projects and groups.\n"
            "\n"
            "Use 'download' to fetch package files from a GitLab instance.\n"
            "Use 'upload' to push package files to a GitLab instance.\n"
            "\n"
            "Settings can be provided via CLI args, environment variables, or a "
            f"config file (default: {DEFAULT_CONFIG_PATH})."
        ),
        version=f"cal-gitlab-packages: {VERSION_STR}\npython: {sys.version.split()[0]}",
    )
    p.add_argument(
        "--license",
        action="version",
        version=LICENSE_TEXT,
        help="show license and exit",
    )

    # =========== Common options (shared across all commands) ===========

    common = p.create_common_collection()

    connection = common.add_group("Connection")

    connection.add_argument(
        "--gitlab-url",
        "-u",
        metavar="URL",
        help="GitLab instance URL (e.g., https://gitlab.com)",
    )

    connection.add_argument(
        "--token",
        "-t",
        metavar="TOKEN",
        help=(
            "Access token for private GitLab groups/projects"
            f" (or set {TOKEN_ENV} env var, or config file)"
        ),
    )

    connection.add_argument(
        "--config",
        "-c",
        metavar="FILE",
        type=Path,
        help=f"Config file path (default: {DEFAULT_CONFIG_PATH})",
    )

    target = common.add_group("Target")

    target.add_argument(
        "--path",
        "-p",
        metavar="PATH",
        help=(
            "Group or project path (e.g., group/subgroup or group/subgroup/project)."
            " If base_group is set in config, path is relative to it"
        ),
    )

    filtering = common.add_group("Filtering")

    filtering.add_argument(
        "--version-filter",
        "-V",
        metavar="MODE",
        default=None,
        choices=FILTER_MODES,
        help=(
            "Version filter mode (default: release for download, all for upload).\n"
            "  release - Only full releases (x.y.z)\n"
            "  beta    - Full releases and beta versions\n"
            "  all     - All versions including pre-release"
        ),
    )

    filtering.add_argument(
        "--project-filter",
        "-f",
        metavar="FILTER",
        help=(
            "Filter projects by name (substring match, case-insensitive). Only used"
            " when path is a group"
        ),
    )

    filtering.add_argument(
        "--package-type",
        "-T",
        metavar="TYPE",
        help=(
            "Filter packages by type (e.g., generic, pypi, npm, maven)."
            " Default: all types for download"
        ),
    )

    output_opts = common.add_group("Output")

    output_opts.add_argument(
        "--verbose",
        "-v",
        action="count",
        default=0,
        help="Display verbose output. Use twice for debug logging",
    )

    output_opts.add_argument(
        "--no-colour",
        "--no-color",
        action="store_true",
        dest="no_colour",
        help="Disable coloured output",
    )

    # =========== Download command ===========

    download = p.add_command(
        "download",
        help="Download package files from GitLab",
        description=(
            "Download package files from a GitLab project or group.\n"
            "\n"
            "Automatically detects whether the given path is a group or project. "
            "For groups, all projects (including subgroups) are processed."
        ),
    )

    dl_opts = download.add_group("Download Options")

    dl_opts.add_argument(
        "--output",
        "-o",
        metavar="DIR",
        help="Output directory for downloaded package files",
    )

    dl_opts.add_argument(
        "--manifest",
        "-m",
        metavar="FILE",
        help=(
            "Path to a JSON manifest file for incremental downloads. When set,"
            " tracks downloaded files so subsequent runs only fetch new items"
        ),
    )

    dl_opts.add_argument(
        "--overwrite",
        "-O",
        action="store_true",
        help="Overwrite existing files instead of skipping",
    )

    dl_opts.add_argument(
        "--flat",
        "-F",
        action="store_true",
        help=(
            "Download all files directly into the output directory (no subdirectories)."
            " Note: flat output cannot be used with the upload command, which requires"
            " the project/package/version directory structure"
        ),
    )

    dl_opts.add_argument(
        "--jobs",
        "-j",
        metavar="N",
        type=int,
        default=None,
        help="Number of parallel download threads (default: 32)",
    )

    dl_actions = download.add_group("List Actions")

    dl_actions.add_argument(
        "--list-projects",
        "-L",
        action="store_true",
        help="List projects and exit (no download)",
    )

    dl_actions.add_argument(
        "--list-packages",
        "-R",
        action="store_true",
        help="List packages and exit (no download)",
    )

    dl_actions.add_argument(
        "--json",
        "-J",
        action="store_true",
        help="Output in JSON format (with --list-projects or --list-packages)",
    )

    # =========== Upload command ===========

    upload = p.add_command(
        "upload",
        help="Upload package files to GitLab",
        description=(
            "Upload package files to a GitLab project or group via the generic\n"
            "package registry.\n"
            "\n"
            "Reads a directory of package files (in the same structure produced "
            "by the download command) and uploads them to the generic package "
            "registry on the target GitLab instance.\n"
            "\n"
            "Expected directory structure:\n"
            "  input_dir/project_path/package_name/version/files\n"
            "\n"
            "The --path specifies the base group on GitLab. Directory entries "
            "under input_dir are treated as relative project paths within that group."
        ),
    )

    ul_opts = upload.add_group("Upload Options")

    ul_opts.add_argument(
        "--input",
        "-i",
        metavar="DIR",
        help="Input directory containing package files to upload",
    )

    ul_opts.add_argument(
        "--dry-run",
        "-n",
        action="store_true",
        help="Show what would be uploaded without actually uploading",
    )

    ul_opts.add_argument(
        "--jobs",
        "-j",
        metavar="N",
        type=int,
        default=None,
        help="Number of parallel upload threads (default: 32)",
    )

    return p.parse(argv)


# ----------------------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    """
    Main entry point for the CLI.

    Parameters:
        argv: Command line arguments (without program name). If None, uses sys.argv[1:].

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    if argv is None:
        argv = sys.argv[1:]

    try:
        return _main_inner(argv)
    except KeyboardInterrupt:
        print()
        print("---- Manually Terminated ----")
        print()
        return 1
    except SystemExit:
        raise
    except BaseException as e:
        t = "-----------------------------------------------------------------------------\n"
        t += "UNHANDLED EXCEPTION OCCURRED!!\n"
        t += "\n"
        t += traceback.format_exc()
        t += "\n"
        t += f"EXCEPTION: {type(e)} {e}\n"
        t += "-----------------------------------------------------------------------------\n"
        t += "\n"
        print(t, file=sys.stderr)
        return 1


# ----------------------------------------------------------------------------------------
def _main_inner(argv: list[str]) -> int:
    """Inner main function that does the actual work."""
    args = get_args(argv)

    # Configure colour output - CLI > config (loaded below)
    # Note: colour must be configured early so warnings from config loading are coloured
    if args.no_colour:
        set_colours_enabled(False)

    # Configure logging
    if args.verbose >= 2:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    elif args.verbose >= 1:
        logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")

    # Load config file
    config_file = load_config(args.config)

    # Apply colour from config if not set via CLI
    if not args.no_colour and config_file.get("no_colour"):
        set_colours_enabled(False)

    # Dispatch to command handler
    if args.command == "download":
        return _run_download(args, config_file)
    elif args.command == "upload":
        return _run_upload(args, config_file)

    return 0


# ----------------------------------------------------------------------------------------
def _resolve_path(args: Namespace, config_file: dict[str, Any]) -> str | None:
    """
    Resolve the GitLab path from CLI args and config file.

    Returns the resolved path, or None with an error printed if not available.
    """
    base_group_val = config_file.get("base_group")
    base_group: str | None = str(base_group_val) if base_group_val else None

    if args.path and base_group:
        return f"{base_group.rstrip('/')}/{args.path}"
    elif args.path:
        return str(args.path)
    elif base_group:
        return base_group.rstrip("/")
    else:
        print(
            "Error: --path is required (or set base_group in config file)",
            file=sys.stderr,
        )
        return None


# ----------------------------------------------------------------------------------------
def _run_download(args: Namespace, config_file: dict[str, Any]) -> int:
    """Run the download command."""

    # Resolve settings: CLI arg > env var > config file > default
    gitlab_url: str | None = args.gitlab_url or config_file.get("gitlab_url")
    token: str | None = (
        args.token or os.environ.get(TOKEN_ENV) or config_file.get("token")
    )
    output: str | None = args.output or config_file.get("output")
    version_filter: str = (
        args.version_filter or config_file.get("version_filter") or "release"
    )
    project_filter: str | None = args.project_filter or config_file.get(
        "project_filter"
    )
    package_type: str | None = args.package_type or config_file.get("package_type")
    parallel: int = args.jobs or config_file.get("parallel") or 32
    manifest: str | None = args.manifest or config_file.get("manifest")
    flat: bool = args.flat or config_file.get("flat", False)

    # Resolve path
    path = _resolve_path(args, config_file)
    if path is None:
        return 1

    # Validate required settings
    if not gitlab_url:
        print(
            "Error: --gitlab-url is required (or set gitlab_url in config file)",
            file=sys.stderr,
        )
        return 1

    # Handle list modes (no output dir needed)
    if args.list_projects or args.list_packages:
        config = DownloadConfig(
            gitlab_url=gitlab_url,
            path=path,
            output_dir=Path("."),
            token=token,
            version_filter=version_filter,
            project_filter=project_filter,
            package_type=package_type,
            parallel=parallel,
        )
        if args.list_projects:
            return list_projects(config, json_output=args.json)
        return list_packages(config, json_output=args.json)

    if not output:
        print(
            "Error: --output is required (or set output in config file)",
            file=sys.stderr,
        )
        return 1

    # Build configuration
    config = DownloadConfig(
        gitlab_url=gitlab_url,
        path=path,
        output_dir=Path(output).resolve(),
        token=token,
        version_filter=version_filter,
        project_filter=project_filter,
        package_type=package_type,
        overwrite=args.overwrite,
        flat=flat,
        parallel=parallel,
        manifest_path=Path(manifest).resolve() if manifest else None,
    )

    # Perform download
    result = download_packages(config)

    if not result.success:
        print(f"\nError: {result.error_message}")
        return 1

    # Print summary
    print(format_download_summary(result))

    if result.failed_files > 0:
        return 1

    return 0


# ----------------------------------------------------------------------------------------
def _run_upload(args: Namespace, config_file: dict[str, Any]) -> int:
    """Run the upload command."""

    # Resolve settings: CLI arg > env var > config file > default
    gitlab_url: str | None = args.gitlab_url or config_file.get("gitlab_url")
    token: str | None = (
        args.token or os.environ.get(TOKEN_ENV) or config_file.get("token")
    )
    input_dir: str | None = getattr(args, "input", None) or config_file.get("input")
    version_filter: str = (
        args.version_filter or config_file.get("version_filter") or "all"
    )
    project_filter: str | None = args.project_filter or config_file.get(
        "project_filter"
    )
    parallel: int = args.jobs or config_file.get("parallel") or 32
    dry_run: bool = args.dry_run

    # Resolve path
    path = _resolve_path(args, config_file)
    if path is None:
        return 1

    # Validate required settings
    if not gitlab_url:
        print(
            "Error: --gitlab-url is required (or set gitlab_url in config file)",
            file=sys.stderr,
        )
        return 1

    if not token:
        print(
            "Error: --token is required for upload"
            f" (or set {TOKEN_ENV} env var, or config file)",
            file=sys.stderr,
        )
        return 1

    if not input_dir:
        print(
            "Error: --input is required (or set input in config file)",
            file=sys.stderr,
        )
        return 1

    # Build configuration
    config = UploadConfig(
        gitlab_url=gitlab_url,
        path=path,
        input_dir=Path(input_dir).resolve(),
        token=token,
        version_filter=version_filter,
        project_filter=project_filter,
        parallel=parallel,
        dry_run=dry_run,
    )

    # Perform upload
    result = upload_packages(config)

    if not result.success:
        print(f"\nError: {result.error_message}")
        return 1

    # Print summary
    print(format_upload_summary(result))

    if result.failed_files > 0:
        return 1

    return 0
