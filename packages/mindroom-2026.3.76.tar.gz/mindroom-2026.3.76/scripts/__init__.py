"""Scripts for Mindroom utilities."""
