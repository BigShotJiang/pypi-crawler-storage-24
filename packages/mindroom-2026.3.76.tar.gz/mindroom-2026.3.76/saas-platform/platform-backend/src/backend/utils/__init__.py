# Utils module for backend
