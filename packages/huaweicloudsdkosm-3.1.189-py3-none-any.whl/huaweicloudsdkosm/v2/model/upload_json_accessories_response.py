# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UploadJsonAccessoriesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'accessory_id': 'str'
    }

    attribute_map = {
        'accessory_id': 'accessory_id'
    }

    def __init__(self, accessory_id=None):
        r"""UploadJsonAccessoriesResponse

        The model defined in huaweicloud sdk

        :param accessory_id: 附件id
        :type accessory_id: str
        """
        
        super().__init__()

        self._accessory_id = None
        self.discriminator = None

        if accessory_id is not None:
            self.accessory_id = accessory_id

    @property
    def accessory_id(self):
        r"""Gets the accessory_id of this UploadJsonAccessoriesResponse.

        附件id

        :return: The accessory_id of this UploadJsonAccessoriesResponse.
        :rtype: str
        """
        return self._accessory_id

    @accessory_id.setter
    def accessory_id(self, accessory_id):
        r"""Sets the accessory_id of this UploadJsonAccessoriesResponse.

        附件id

        :param accessory_id: The accessory_id of this UploadJsonAccessoriesResponse.
        :type accessory_id: str
        """
        self._accessory_id = accessory_id

    def to_dict(self):
        import warnings
        warnings.warn("UploadJsonAccessoriesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UploadJsonAccessoriesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
