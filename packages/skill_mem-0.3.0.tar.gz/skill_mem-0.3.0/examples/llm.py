"""Full loop with real LLM via OpenRouter: route, judge, evolve, discover."""

import json
import os
import tempfile
from pathlib import Path

from openrouter import OpenRouter

from skill_mem import Library, Outcome, Revision, Skill

CHAT_MODEL = "minimax/minimax-m2.7"
EMBED_MODEL = "nvidia/llama-nemotron-embed-vl-1b-v2:free"

client = OpenRouter(api_key=os.environ["OPENROUTER_API_KEY"])


def embed(text: str) -> list[float]:
    res = client.embeddings.generate(input=text, model=EMBED_MODEL)
    assert not isinstance(res, str), f"Embedding request failed: {res}"
    return [float(x) for x in res.data[0].embedding]


def chat(system: str, user: str) -> str:
    res = client.chat.send(
        model=CHAT_MODEL,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    )
    return res.choices[0].message.content


def rewrite(skill: Skill, context: str) -> Revision:
    raw = chat(
        "You maintain reusable skill instructions for an AI agent. "
        "Given the current skill and a failure report, return updated JSON. "
        'Return ONLY: {"description": "...", "content": "..."}',
        f"Skill: {skill.name}\nDescription: {skill.description}\nContent:\n{skill.content}\n\nFailure:\n{context}",
    )
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
    data = json.loads(raw)
    return Revision(description=data["description"], content=data["content"])


def create(query: str, context: str) -> tuple[str, str, str]:
    raw = chat(
        "You create reusable skill instructions for an AI agent. "
        "Given a query and context, extract a reusable skill. "
        'Return ONLY: {"name": "kebab-case", "description": "when to use", "content": "instructions"}',
        f"Query: {query}\nContext: {context}",
    )
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
    data = json.loads(raw)
    return data["name"], data["description"], data["content"]


def judge(query: str, skill: Skill, result: str) -> Outcome:
    verdict = chat(
        "Judge whether the result addresses the query using the skill. "
        "Reply ONLY 'success' or 'failure' on line 1, brief reason on line 2.",
        f"Query: {query}\nSkill: {skill.name}\nInstructions:\n{skill.content}\n\nResult:\n{result}",
    )
    lines = verdict.strip().split("\n", 1)
    success = lines[0].strip().lower().startswith("success")
    reason = lines[1].strip() if len(lines) > 1 else ""
    return Outcome(success=success, reason=reason)


def rerank(query: str, docs: list[str]) -> list[float]:
    scores = []
    for doc in docs:
        raw = chat(
            "Rate how relevant this skill is to the query. "
            "Reply ONLY with a number from 0.0 to 1.0.",
            f"Query: {query}\n\nSkill:\n{doc}",
        )
        scores.append(float(raw.strip()))
    return scores


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        lib = Library(Path(tmp) / "skills", embed, rerank=rerank)

        lib.add(
            "csv-analysis",
            "Analyze, summarize, or query CSV files and tabular data.",
            """
Load the file with pandas. Use df.describe() for numeric columns.
Check nulls with df.isnull().sum().""".strip(),
        )

        lib.add(
            "code-review",
            "Review code for bugs, style issues, and improvements.",
            """
Read the diff carefully. Focus on correctness first, style second.
Flag security issues. Suggest concrete fixes.""".strip(),
        )

        print("=== Route + Simulate Failure ===\n")

        query = "analyze this CSV of sales data and find which products are declining"
        matches = lib.route(query, k=2)
        top = matches[0]
        skill = lib.get(top.name)
        print(f"Query: {query}")
        print(f"Routed to: {top.name} ({top.score:.3f})\n")

        fake_result = "Error: the CSV has 2M rows and pandas ran out of memory"
        outcome = judge(query, skill, fake_result)
        lib.record(skill.name, query, outcome)
        print(f"Judgment: {'success' if outcome.success else 'FAILURE'}")
        print(f"Reason: {outcome.reason}")
        print(f"Utility: {lib.utility(skill.name):.2f}\n")

        print("=== Evolve ===\n")

        evolved = lib.evolve(skill.name, f"Failed: {fake_result}", rewrite)
        print(f"Evolved {skill.name} to v{evolved.version}")
        print(f"Description: {evolved.description}")
        print(f"Content:\n{evolved.content}\n")

        print("=== Discover ===\n")

        new_query = "generate a matplotlib chart showing monthly revenue trends"
        print(f"Query: {new_query}")
        matches = lib.route(new_query, k=1)
        print(f"Best match: {matches[0].name} ({matches[0].score:.3f}) — not great\n")

        fake_success = "Created a line chart with monthly revenue, saved to revenue.png"
        new_skill = lib.discover(new_query, fake_success, create)
        print(f"Discovered: {new_skill.name}")
        print(f"Description: {new_skill.description}")
        print(f"Content:\n{new_skill.content}\n")

        matches = lib.route(new_query, k=2)
        print(f"Re-routing: '{new_query[:50]}...'")
        for m in matches:
            print(f"  {m.name}: {m.score:.3f}")

        print(f"\nAll skills: {[s.name for s in lib.all()]}")


if __name__ == "__main__":
    main()
