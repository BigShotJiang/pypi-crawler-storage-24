"""Evolution loop: skills improve from failures."""

import hashlib
import tempfile
from pathlib import Path

from skill_mem import Library, Outcome, Revision, Skill


def mock_embed(text: str) -> list[float]:
    h = hashlib.sha256(text.encode()).digest()
    return [b / 255.0 for b in h[:32]]


def mock_rewrite(skill: Skill, context: str) -> Revision:
    return Revision(
        description=f"{skill.description} Handles large files.",
        content=f"{skill.content}\n\nFor large files (>100k rows), sample with df.sample(10000) first.",
    )


def mock_create(query: str, context: str) -> tuple[str, str, str]:
    return (
        "email-drafting",
        "Draft professional emails from instructions or bullet points.",
        "Write concise emails. Match tone to audience. Open with purpose, close with action.",
    )


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        lib = Library(Path(tmp) / "skills", mock_embed)

        lib.add(
            "csv-analysis",
            "Analyze CSV files and dataframes.",
            "Load with pandas. df.describe(). df.isnull().sum().",
        )
        print(f"v{lib.get('csv-analysis').version}: {lib.get('csv-analysis').content}")

        lib.record(
            "csv-analysis", "analyze data", Outcome(success=True, reason="worked")
        )
        lib.record("csv-analysis", "big file", Outcome(success=False, reason="OOM"))
        lib.record(
            "csv-analysis", "huge file", Outcome(success=False, reason="timeout")
        )
        print(f"\nUtility: {lib.utility('csv-analysis'):.2f}")

        evolved = lib.evolve(
            "csv-analysis", "Failed on large files (500k+ rows)", mock_rewrite
        )
        print(f"\nv{evolved.version}: {evolved.content}")
        print(f"  description now: {evolved.description}")

        rejected = lib.evolve(
            "csv-analysis",
            "another failure",
            lambda s, c: Revision(s.description, "terrible rewrite"),
            validate=lambda old, new: len(new.content) > len(old.content),
        )
        print(f"\nAfter rejected evolve: v{rejected.version} (unchanged)")

        history = (
            Path(tmp) / "skills" / ".skill-meta" / "history" / "csv-analysis" / "v1.md"
        )
        print(f"v1 archived: {history.exists()}")

        new_skill = lib.discover(
            "draft an email", "user drafted an email successfully", mock_create
        )
        print(f"\nDiscovered: {new_skill.name}")
        print(f"All skills: {[s.name for s in lib.all()]}")


if __name__ == "__main__":
    main()
