from pathlib import Path

from skill_mem.tracker import Tracker
from skill_mem.types import Outcome


def test_record_success(tmp_path: Path) -> None:
    tracker = Tracker(tmp_path)
    tracker.record("s", "do the thing", Outcome(success=True, reason="worked"))
    assert tracker.utility("s") == 1.0


def test_record_failure(tmp_path: Path) -> None:
    tracker = Tracker(tmp_path)
    tracker.record("s", "do the thing", Outcome(success=False, reason="broke"))
    assert tracker.utility("s") == 0.0


def test_utility_default(tmp_path: Path) -> None:
    tracker = Tracker(tmp_path)
    assert tracker.utility("unknown") == 0.5


def test_mixed_outcomes(tmp_path: Path) -> None:
    tracker = Tracker(tmp_path)
    tracker.record("s", "q1", Outcome(success=True, reason="ok"))
    tracker.record("s", "q2", Outcome(success=True, reason="ok"))
    tracker.record("s", "q3", Outcome(success=False, reason="bad"))
    assert abs(tracker.utility("s") - 2 / 3) < 1e-9


def test_attempts(tmp_path: Path) -> None:
    tracker = Tracker(tmp_path)
    assert tracker.attempts("s") == 0
    tracker.record("s", "q1", Outcome(success=True, reason="ok"))
    tracker.record("s", "q2", Outcome(success=False, reason="bad"))
    assert tracker.attempts("s") == 2


def test_persistence(tmp_path: Path) -> None:
    tracker1 = Tracker(tmp_path)
    tracker1.record("s", "q1", Outcome(success=True, reason="ok"))
    tracker1.record("s", "q2", Outcome(success=False, reason="bad"))

    tracker2 = Tracker(tmp_path)
    assert tracker2.utility("s") == 0.5
    assert tracker2.attempts("s") == 2


def test_stats(tmp_path: Path) -> None:
    tracker = Tracker(tmp_path)
    tracker.record("s", "query 1", Outcome(success=True, reason="good"))
    tracker.record("s", "query 2", Outcome(success=False, reason="bad"))

    st = tracker.stats("s")
    assert st.attempts == 2
    assert st.successes == 1
    assert st.failures == 1
    assert st.utility == 0.5
    assert len(st.recent) == 2
    assert st.recent[0].query == "query 1"
    assert st.recent[0].success is True
    assert st.recent[1].query == "query 2"
    assert st.recent[1].success is False


def test_successful_queries(tmp_path: Path) -> None:
    tracker = Tracker(tmp_path)
    tracker.record("s", "good query", Outcome(success=True, reason="ok"))
    tracker.record("s", "bad query", Outcome(success=False, reason="no"))
    tracker.record("s", "another good", Outcome(success=True, reason="ok"))

    queries = tracker.successful_queries("s")
    assert queries == ["good query", "another good"]
