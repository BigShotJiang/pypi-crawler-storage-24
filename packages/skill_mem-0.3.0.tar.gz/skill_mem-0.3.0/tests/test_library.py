import hashlib
from pathlib import Path

import pytest

from skill_mem import Library, Match, Outcome, Revision, Skill


def mock_embed(text: str) -> list[float]:
    h = hashlib.sha256(text.encode()).digest()
    return [b / 255.0 for b in h[:32]]


def test_empty_library(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    assert lib.all() == []


def test_add_and_get(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    skill = lib.add("csv", "Analyze CSV files.", "Use pandas.")
    assert skill.name == "csv"
    assert skill.version == 1

    got = lib.get("csv")
    assert got.name == "csv"
    assert got.content == "Use pandas."


def test_add_and_route(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files and dataframes.", "Use pandas.")
    lib.add("web", "Search the web for information.", "Use requests.")
    lib.add("sql", "Write SQL queries from questions.", "Use sqlite3.")

    matches = lib.route("I want to analyze a spreadsheet")
    assert len(matches) == 3
    assert all(isinstance(m, Match) for m in matches)
    assert all(m.name and m.description and m.path for m in matches)


def test_record_and_utility(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    assert lib.utility("csv") == 0.5  # default prior

    lib.record("csv", "q1", Outcome(success=True, reason="worked"))
    lib.record("csv", "q2", Outcome(success=True, reason="worked"))
    lib.record("csv", "q3", Outcome(success=False, reason="failed"))

    assert abs(lib.utility("csv") - 2 / 3) < 1e-9


def test_stats(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    lib.record("csv", "analyze sales", Outcome(success=True, reason="ok"))
    lib.record("csv", "big file", Outcome(success=False, reason="OOM"))

    st = lib.stats("csv")
    assert st.attempts == 2
    assert st.successes == 1
    assert st.failures == 1
    assert len(st.recent) == 2
    assert st.recent[0].query == "analyze sales"


def test_evolve(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(
            description=skill.description,
            content=f"{skill.content}\n\nFor large files, sample first.",
        )

    evolved = lib.evolve("csv", "choked on 500k rows", rewrite)
    assert evolved.version == 2
    assert "sample first" in evolved.content

    got = lib.get("csv")
    assert got.version == 2


def test_evolve_updates_description(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(
            description="Analyze CSV files, parquet files, and tabular data.",
            content=f"{skill.content}\n\nAlso handles parquet.",
        )

    evolved = lib.evolve("csv", "failed on parquet", rewrite)
    assert "parquet" in evolved.description
    assert "parquet" in evolved.content


def test_evolve_archives(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Original content.")

    lib.evolve("csv", "failed", lambda s, c: Revision(s.description, "New content."))

    history = tmp_path / "skills" / ".skill-meta" / "history" / "csv" / "v1.md"
    assert history.exists()
    archived = history.read_text()
    assert "name: csv" in archived
    assert "Original content." in archived


def test_evolve_preserves_extra_frontmatter(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    path = tmp_path / "skills" / "csv" / "SKILL.md"
    path.write_text(
        "---\nname: csv\ndescription: Analyze CSV files.\nlicense: MIT\nmetadata:\n  author: joey\n---\n\nUse pandas.\n"
    )

    lib2 = Library(tmp_path / "skills", mock_embed)
    assert lib2.get("csv").extra_frontmatter == {
        "license": "MIT",
        "metadata": {"author": "joey"},
    }

    text = (tmp_path / "skills" / "csv" / "SKILL.md").read_text()
    assert "license: MIT" in text
    assert "author: joey" in text


def test_evolve_validate_rejects(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Original.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(skill.description, "Bad rewrite.")

    result = lib.evolve("csv", "context", rewrite, validate=lambda old, new: False)
    assert result.content == "Original."
    assert result.version == 1


def test_evolve_validate_accepts(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Original.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(skill.description, "Good rewrite.")

    result = lib.evolve("csv", "context", rewrite, validate=lambda old, new: True)
    assert result.content == "Good rewrite."
    assert result.version == 2


def test_discover(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)

    def create(query: str, context: str) -> tuple[str, str, str]:
        return ("email", "Draft emails from instructions.", "Be concise.")

    skill = lib.discover("write an email", "some context", create)
    assert skill.name == "email"
    assert lib.get("email").content == "Be concise."


def test_discover_duplicate_asserts(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Content.")

    def create(q: str, c: str) -> tuple[str, str, str]:
        return ("csv", "Duplicate.", "Content.")

    with pytest.raises(AssertionError, match="already exists"):
        lib.discover("anything", "context", create)


def test_get_missing_asserts(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    with pytest.raises(AssertionError, match="not found"):
        lib.get("nonexistent")


def test_gitignore_created(tmp_path: Path) -> None:
    Library(tmp_path / "skills", mock_embed)
    assert (tmp_path / "skills" / ".skill-meta" / ".gitignore").exists()


def test_add_duplicate_asserts(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")
    with pytest.raises(AssertionError, match="already exists"):
        lib.add("csv", "Different description.", "Different content.")


def test_evolve_deletes_files(tmp_path: Path) -> None:
    root = tmp_path / "skills"
    lib = Library(root, mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    scripts = root / "csv" / "scripts"
    scripts.mkdir(parents=True)
    (scripts / "old.py").write_text("old script")
    (scripts / "keep.py").write_text("keep this")

    lib2 = Library(root, mock_embed)
    assert "scripts/old.py" in lib2.get("csv").files

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(
            description=skill.description,
            content=skill.content,
            files={"scripts/old.py": None},
        )

    evolved = lib2.evolve("csv", "cleanup", rewrite)
    assert "scripts/old.py" not in evolved.files
    assert "scripts/keep.py" in evolved.files
    assert not (scripts / "old.py").exists()


def test_evolve_updates_files(tmp_path: Path) -> None:
    root = tmp_path / "skills"
    lib = Library(root, mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    scripts = root / "csv" / "scripts"
    scripts.mkdir(parents=True)
    (scripts / "analyze.py").write_text("import pandas as pd\n# v1")

    lib2 = Library(root, mock_embed)
    assert "scripts/analyze.py" in lib2.get("csv").files

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(
            description=skill.description,
            content=skill.content,
            files={"scripts/analyze.py": "import pandas as pd\n# v2 with sampling"},
        )

    evolved = lib2.evolve("csv", "OOM on large files", rewrite)
    assert "v2 with sampling" in evolved.files["scripts/analyze.py"]
    assert "v2 with sampling" in (scripts / "analyze.py").read_text()


def test_evolve_preserves_unmodified_files(tmp_path: Path) -> None:
    root = tmp_path / "skills"
    lib = Library(root, mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    scripts = root / "csv" / "scripts"
    scripts.mkdir(parents=True)
    (scripts / "analyze.py").write_text("original script")

    refs = root / "csv" / "references"
    refs.mkdir(parents=True)
    (refs / "guide.md").write_text("original guide")

    lib2 = Library(root, mock_embed)

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(
            description=skill.description,
            content=skill.content,
            files={"scripts/analyze.py": "updated script"},
        )

    evolved = lib2.evolve("csv", "context", rewrite)
    assert evolved.files["scripts/analyze.py"] == "updated script"
    assert evolved.files["references/guide.md"] == "original guide"


def test_route_with_rerank(tmp_path: Path) -> None:
    rerank_called = False

    def mock_rerank(query: str, docs: list[str]) -> list[float]:
        nonlocal rerank_called
        rerank_called = True
        return [1.0 / (i + 1) for i in range(len(docs))]

    lib = Library(tmp_path / "skills", mock_embed, rerank=mock_rerank)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")
    lib.add("web", "Search the web.", "Use requests.")
    lib.add("sql", "Write SQL queries.", "Use sqlite3.")

    matches = lib.route("query a database")
    assert rerank_called
    assert len(matches) == 3


def test_persists_across_instances(tmp_path: Path) -> None:
    root = tmp_path / "skills"
    lib1 = Library(root, mock_embed)
    lib1.add("csv", "Analyze CSV files.", "Use pandas.")
    lib1.evolve("csv", "failed", lambda s, c: Revision(s.description, "Improved."))

    lib2 = Library(root, mock_embed)
    assert lib2.get("csv").version == 2
    assert lib2.get("csv").content == "Improved."


def test_record_returns_none_on_success(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")
    result = lib.record("csv", "q1", Outcome(success=True, reason="ok"))
    assert result is None


def test_auto_evolve_on_low_utility(tmp_path: Path) -> None:
    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(skill.description, f"{skill.content}\nImproved.")

    lib = Library(
        tmp_path / "skills",
        mock_embed,
        rewrite=rewrite,
        evolve_threshold=0.3,
        min_attempts=5,
    )
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    result = None
    for i in range(5):
        result = lib.record("csv", f"q{i}", Outcome(success=False, reason="failed"))

    assert result is not None
    assert result.version == 2
    assert "Improved" in result.content


def test_auto_evolve_respects_min_attempts(tmp_path: Path) -> None:
    calls = 0

    def rewrite(skill: Skill, context: str) -> Revision:
        nonlocal calls
        calls += 1
        return Revision(skill.description, "Rewritten.")

    lib = Library(
        tmp_path / "skills",
        mock_embed,
        rewrite=rewrite,
        evolve_threshold=0.3,
        min_attempts=5,
    )
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    for i in range(4):
        lib.record("csv", f"q{i}", Outcome(success=False, reason="failed"))

    assert calls == 0


def test_auto_evolve_requires_rewrite(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed, min_attempts=2)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    for i in range(5):
        result = lib.record("csv", f"q{i}", Outcome(success=False, reason="failed"))

    assert result is None


def test_auto_evolve_cooldown(tmp_path: Path) -> None:
    """After auto-evolution, requires min_attempts new failures before triggering again."""
    calls = 0

    def rewrite(skill: Skill, context: str) -> Revision:
        nonlocal calls
        calls += 1
        return Revision(skill.description, f"{skill.content}\nv{calls + 1}")

    lib = Library(
        tmp_path / "skills",
        mock_embed,
        rewrite=rewrite,
        evolve_threshold=0.3,
        min_attempts=3,
    )
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    for i in range(3):
        lib.record("csv", f"q{i}", Outcome(success=False, reason="failed"))
    assert calls == 1

    for i in range(2):
        lib.record("csv", f"q{i + 3}", Outcome(success=False, reason="still failing"))
    assert calls == 1

    lib.record("csv", "q5", Outcome(success=False, reason="still bad"))
    assert calls == 2


def test_match_has_path(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    matches = lib.route("analyze data", k=1)
    assert matches[0].name == "csv"
    assert matches[0].description == "Analyze CSV files."
    assert matches[0].path.name == "SKILL.md"
