import hashlib
from pathlib import Path

from skill_mem.router import _BM25, BruteForce, Router, _rrf
from skill_mem.types import Skill


def mock_embed(text: str) -> list[float]:
    h = hashlib.sha256(text.encode()).digest()
    return [b / 255.0 for b in h[:32]]


def _skill(name: str, description: str, content: str = "skill body") -> Skill:
    return Skill(
        name=name,
        description=description,
        content=content,
        path=Path(f"/{name}/SKILL.md"),
    )


def test_index_and_search(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    skills = [
        _skill("csv", "Analyze CSV files and dataframes"),
        _skill("web", "Search the web for information"),
        _skill("sql", "Write SQL queries from natural language"),
    ]
    router.index(skills)
    matches = router.search("I need to query a database", k=3)
    assert len(matches) == 3
    assert all(m.score > 0 for m in matches)


def test_search_returns_k(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    skills = [_skill(f"s{i}", f"Skill {i} description") for i in range(10)]
    router.index(skills)
    matches = router.search("anything", k=3)
    assert len(matches) == 3


def test_search_fewer_than_k(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([_skill("only", "The only skill")])
    matches = router.search("anything", k=5)
    assert len(matches) == 1


def test_search_empty(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([])
    matches = router.search("anything", k=3)
    assert matches == []


def test_cache_invalidation(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([_skill("s", "Original description")])
    original_hash = router._entries["s"]["hash"]

    router.index([_skill("s", "Changed description")])
    assert router._entries["s"]["hash"] != original_hash


def test_cache_hit(tmp_path: Path) -> None:
    call_count = 0

    def counting_embed(text: str) -> list[float]:
        nonlocal call_count
        call_count += 1
        return mock_embed(text)

    router = Router(tmp_path, counting_embed)
    skills = [_skill("s", "Same description")]

    router.index(skills)
    first_count = call_count

    router.index(skills)
    assert call_count == first_count


def test_prunes_removed_skills(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([_skill("a", "A"), _skill("b", "B"), _skill("c", "C")])
    assert "c" in router._entries

    router.index([_skill("a", "A"), _skill("b", "B")])
    assert "c" not in router._entries


def test_index_with_successful_queries(tmp_path: Path) -> None:
    call_count = 0

    def counting_embed(text: str) -> list[float]:
        nonlocal call_count
        call_count += 1
        return mock_embed(text)

    router = Router(tmp_path, counting_embed)
    skills = [_skill("csv", "Analyze CSV files")]
    router.index(skills)
    first_count = call_count

    router.index(skills, {"csv": ["analyze sales.csv"]})
    assert call_count > first_count


def test_rerank_reorders_results(tmp_path: Path) -> None:
    def rerank(query: str, docs: list[str]) -> list[float]:
        return list(reversed(range(len(docs))))

    router = Router(tmp_path, mock_embed, rerank=rerank, retrieve_k=10)
    skills = [_skill(f"s{i}", f"Skill {i}") for i in range(5)]
    router.index(skills)

    matches = router.search("anything", k=3)
    assert len(matches) == 3
    assert matches[0].score >= matches[1].score >= matches[2].score


def test_rerank_sees_full_text(tmp_path: Path) -> None:
    seen_docs: list[list[str]] = []

    def capturing_rerank(query: str, docs: list[str]) -> list[float]:
        seen_docs.append(docs)
        return [1.0] * len(docs)

    router = Router(tmp_path, mock_embed, rerank=capturing_rerank)
    skills = [_skill("csv", "Analyze CSV files", "Use pandas for analysis.")]
    router.index(skills, {"csv": ["analyze sales.csv"]})

    router.search("query", k=1)
    assert len(seen_docs) == 1
    doc = seen_docs[0][0]
    assert "csv" in doc
    assert "Analyze CSV files" in doc
    assert "Use pandas for analysis." in doc
    assert "analyze sales.csv" in doc


def test_retrieve_k_widens_window(tmp_path: Path) -> None:
    seen_counts: list[int] = []

    def counting_rerank(query: str, docs: list[str]) -> list[float]:
        seen_counts.append(len(docs))
        return [1.0 / (i + 1) for i in range(len(docs))]

    router = Router(tmp_path, mock_embed, rerank=counting_rerank, retrieve_k=10)
    skills = [_skill(f"s{i}", f"Skill {i}") for i in range(15)]
    router.index(skills)

    router.search("anything", k=3)
    assert seen_counts[0] == 10


def test_no_rerank_unchanged_behavior(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    skills = [_skill(f"s{i}", f"Skill {i}") for i in range(5)]
    router.index(skills)

    matches = router.search("anything", k=3)
    assert len(matches) == 3
    assert matches[0].score >= matches[1].score >= matches[2].score


def test_rerank_fewer_than_retrieve_k(tmp_path: Path) -> None:
    seen_counts: list[int] = []

    def counting_rerank(query: str, docs: list[str]) -> list[float]:
        seen_counts.append(len(docs))
        return [1.0] * len(docs)

    router = Router(tmp_path, mock_embed, rerank=counting_rerank, retrieve_k=20)
    router.index([_skill("only", "The only skill")])

    matches = router.search("anything", k=5)
    assert len(matches) == 1
    assert seen_counts[0] == 1


def test_routing_text_includes_files(tmp_path: Path) -> None:
    seen_docs: list[list[str]] = []

    def capturing_rerank(query: str, docs: list[str]) -> list[float]:
        seen_docs.append(docs)
        return [1.0] * len(docs)

    router = Router(tmp_path, mock_embed, rerank=capturing_rerank)
    skill = Skill(
        name="csv",
        description="Analyze CSV files",
        content="Use pandas.",
        path=Path("/csv/SKILL.md"),
        files={"scripts/analyze.py": "import pandas as pd"},
    )
    router.index([skill])
    router.search("query", k=1)

    doc = seen_docs[0][0]
    assert "import pandas as pd" in doc
    assert "scripts/analyze.py" in doc


def test_match_score_is_reranker_score(tmp_path: Path) -> None:
    def fixed_rerank(query: str, docs: list[str]) -> list[float]:
        return [0.99] * len(docs)

    router = Router(tmp_path, mock_embed, rerank=fixed_rerank)
    router.index([_skill("s", "A skill")])

    matches = router.search("anything", k=1)
    assert matches[0].score == 0.99


def test_match_has_metadata(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([_skill("csv", "Analyze CSV files")])

    matches = router.search("data", k=1)
    assert matches[0].name == "csv"
    assert matches[0].description == "Analyze CSV files"
    assert matches[0].path == Path("/csv/SKILL.md")


def test_bm25_keyword_match(tmp_path: Path) -> None:
    """BM25 boosts skills that share exact query terms."""
    router = Router(tmp_path, mock_embed)
    router.index(
        [
            _skill(
                "pandas-csv",
                "Analyze CSV spreadsheets",
                "Load CSV with pandas read_csv",
            ),
            _skill(
                "web-search", "Search the internet", "Use HTTP requests to fetch pages"
            ),
        ]
    )

    matches = router.search("pandas csv analysis", k=2)
    assert matches[0].name == "pandas-csv"


def test_rrf_combines_rankings() -> None:
    dense = [("a", 0.9), ("b", 0.8), ("c", 0.7)]
    sparse = [("b", 5.0), ("c", 3.0), ("a", 1.0)]
    fused = _rrf([dense, sparse])
    names = [name for name, _ in fused]
    assert set(names) == {"a", "b", "c"}
    assert names[0] == "b"


def test_bm25_standalone() -> None:
    bm25 = _BM25()
    bm25.index(
        {
            "csv": "analyze csv files with pandas dataframes",
            "web": "search the web using http requests",
        }
    )
    results = bm25.search("pandas csv", k=2)
    assert results[0][0] == "csv"
    assert results[0][1] > results[1][1]


def test_custom_vector_index(tmp_path: Path) -> None:
    """Pluggable vector index replaces brute-force search."""
    search_calls = 0

    class ReverseIndex:
        def index(self, vectors: dict[str, list[float]]) -> None:
            self._names = list(vectors.keys())

        def search(self, query: list[float], k: int) -> list[tuple[str, float]]:
            nonlocal search_calls
            search_calls += 1
            return [
                (name, 1.0 / (i + 1)) for i, name in enumerate(reversed(self._names))
            ][:k]

    router = Router(tmp_path, mock_embed, vector_index=ReverseIndex())
    router.index([_skill("a", "Alpha"), _skill("b", "Beta"), _skill("c", "Charlie")])

    matches = router.search("anything", k=3)
    assert search_calls == 1
    assert len(matches) == 3


def test_brute_force_index() -> None:
    bf = BruteForce()
    bf.index({"a": [1.0, 0.0], "b": [0.0, 1.0]})
    results = bf.search([1.0, 0.0], k=2)
    assert results[0][0] == "a"
    assert results[0][1] > results[1][1]
