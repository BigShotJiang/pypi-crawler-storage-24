from pathlib import Path

import pytest

from skill_mem.parse import read_skill, scan_skills, validate_name, write_skill


def _write_md(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_read_skill(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "my-skill" / "SKILL.md",
        "---\nname: my-skill\ndescription: Do the thing.\n---\n\nStep 1: do it.\n",
    )
    skill = read_skill(tmp_path / "my-skill" / "SKILL.md")
    assert skill.name == "my-skill"
    assert skill.description == "Do the thing."
    assert skill.content == "Step 1: do it."
    assert skill.version == 1


def test_read_skill_missing_name(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "bad" / "SKILL.md",
        "---\ndescription: No name here.\n---\n\nBody.\n",
    )
    with pytest.raises(AssertionError, match="name"):
        read_skill(tmp_path / "bad" / "SKILL.md")


def test_read_skill_missing_description(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "bad" / "SKILL.md",
        "---\nname: bad\n---\n\nBody.\n",
    )
    with pytest.raises(AssertionError, match="description"):
        read_skill(tmp_path / "bad" / "SKILL.md")


def test_read_skill_extra_fields(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "extra" / "SKILL.md",
        "---\nname: extra\ndescription: Has extras.\nlicense: MIT\nmetadata:\n  author: joey\n---\n\nBody.\n",
    )
    skill = read_skill(tmp_path / "extra" / "SKILL.md")
    assert skill.name == "extra"
    assert skill.description == "Has extras."
    assert skill.extra_frontmatter == {"license": "MIT", "metadata": {"author": "joey"}}


def test_write_and_read_roundtrip(tmp_path: Path) -> None:
    skill = write_skill(
        tmp_path, "round-trip", "Trigger text.", "Do the thing.\n\nStep 2."
    )
    assert skill.name == "round-trip"
    assert skill.content == "Do the thing.\n\nStep 2."
    assert (tmp_path / "round-trip" / "SKILL.md").exists()

    loaded = read_skill(tmp_path / "round-trip" / "SKILL.md")
    assert loaded.name == skill.name
    assert loaded.description == skill.description
    assert loaded.content == skill.content


def test_scan_skills(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "alpha" / "SKILL.md",
        "---\nname: alpha\ndescription: A.\n---\n\nA body.\n",
    )
    _write_md(
        tmp_path / "beta" / "SKILL.md",
        "---\nname: beta\ndescription: B.\n---\n\nB body.\n",
    )

    skills = scan_skills(tmp_path)
    assert len(skills) == 2
    assert skills[0].name == "alpha"
    assert skills[1].name == "beta"


def test_scan_skips_dotdirs(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "real" / "SKILL.md",
        "---\nname: real\ndescription: Real.\n---\n\nBody.\n",
    )
    _write_md(
        tmp_path / ".hidden" / "SKILL.md",
        "---\nname: hidden\ndescription: Hidden.\n---\n\nBody.\n",
    )

    skills = scan_skills(tmp_path)
    assert len(skills) == 1
    assert skills[0].name == "real"


def test_write_skill_special_chars(tmp_path: Path) -> None:
    desc = 'Use this skill when: the user says "hello"'
    write_skill(tmp_path, "special", desc, "Content here.")
    loaded = read_skill(tmp_path / "special" / "SKILL.md")
    assert loaded.description == desc


def test_read_skill_with_files(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "my-skill" / "SKILL.md",
        "---\nname: my-skill\ndescription: Do the thing.\n---\n\nBody.\n",
    )
    scripts = tmp_path / "my-skill" / "scripts"
    scripts.mkdir()
    (scripts / "run.py").write_text("print('hello')")

    refs = tmp_path / "my-skill" / "references"
    refs.mkdir()
    (refs / "guide.md").write_text("# Guide\nDetails here.")

    skill = read_skill(tmp_path / "my-skill" / "SKILL.md")
    assert skill.files == {
        "references/guide.md": "# Guide\nDetails here.",
        "scripts/run.py": "print('hello')",
    }


def test_read_skill_skips_binary(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "my-skill" / "SKILL.md",
        "---\nname: my-skill\ndescription: Do the thing.\n---\n\nBody.\n",
    )
    assets = tmp_path / "my-skill" / "assets"
    assets.mkdir()
    (assets / "image.png").write_bytes(b"\x89PNG\r\n\x1a\n" + bytes(range(256)))

    skill = read_skill(tmp_path / "my-skill" / "SKILL.md")
    assert skill.files == {}


def test_write_skill_with_files(tmp_path: Path) -> None:
    files: dict[str, str | None] = {
        "scripts/extract.py": "import sys\nprint(sys.argv)",
        "references/API.md": "# API\nEndpoint details.",
    }
    skill = write_skill(tmp_path, "with-files", "A skill.", "Body.", files=files)
    assert skill.files == files
    assert (tmp_path / "with-files" / "scripts" / "extract.py").exists()
    assert (tmp_path / "with-files" / "references" / "API.md").exists()

    loaded = read_skill(tmp_path / "with-files" / "SKILL.md")
    assert loaded.files == files


def test_validate_name_valid() -> None:
    for name in ("csv", "my-skill", "a1-b2-c3", "x"):
        validate_name(name)


def test_validate_name_invalid() -> None:
    for name in (
        "",
        "UPPER",
        "-leading",
        "trailing-",
        "double--hyphen",
        "has space",
        "../escape",
        "a" * 65,
    ):
        with pytest.raises(AssertionError, match="Invalid skill name"):
            validate_name(name)


def test_write_skill_rejects_bad_name(tmp_path: Path) -> None:
    with pytest.raises(AssertionError, match="Invalid skill name"):
        write_skill(tmp_path, "../escape", "Bad.", "Body.")


def test_write_skill_rejects_path_traversal(tmp_path: Path) -> None:
    with pytest.raises(AssertionError, match="escapes skill directory"):
        write_skill(
            tmp_path,
            "safe",
            "Ok.",
            "Body.",
            files={"../../etc/passwd": "pwned"},
        )


def test_write_skill_deletes_file_with_none(tmp_path: Path) -> None:
    write_skill(
        tmp_path,
        "my-skill",
        "A skill.",
        "Body.",
        files={"scripts/old.py": "print('old')"},
    )
    assert (tmp_path / "my-skill" / "scripts" / "old.py").exists()

    skill = write_skill(
        tmp_path,
        "my-skill",
        "A skill.",
        "Body.",
        files={"scripts/old.py": None},
    )
    assert not (tmp_path / "my-skill" / "scripts" / "old.py").exists()
    assert "scripts/old.py" not in skill.files


def test_body_with_horizontal_rule(tmp_path: Path) -> None:
    body = "Before rule.\n\n---\n\nAfter rule."
    _write_md(
        tmp_path / "hr" / "SKILL.md",
        f"---\nname: hr\ndescription: Has HR.\n---\n\n{body}\n",
    )
    skill = read_skill(tmp_path / "hr" / "SKILL.md")
    assert "After rule." in skill.content
