from __future__ import annotations

import re
from pathlib import Path

import yaml

from skill_mem.types import Skill

SKILL_DIRS = ("scripts", "references", "assets")
_NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


def validate_name(name: str) -> None:
    assert name and len(name) <= 64 and _NAME_RE.match(name), (
        f"Invalid skill name: {name!r}. Must be 1-64 lowercase alphanumeric characters and hyphens, "
        "no leading/trailing/consecutive hyphens."
    )


def _validate_file_path(rel_path: str, skill_dir: Path) -> None:
    resolved = (skill_dir / rel_path).resolve()
    assert resolved.is_relative_to(skill_dir.resolve()), (
        f"File path escapes skill directory: {rel_path!r}"
    )


def _read_files(skill_dir: Path) -> dict[str, str]:
    files: dict[str, str] = {}
    for subdir in SKILL_DIRS:
        dir_path = skill_dir / subdir
        if not dir_path.is_dir():
            continue
        for file_path in sorted(dir_path.rglob("*")):
            if file_path.is_file() and not file_path.name.startswith("."):
                try:
                    rel = str(file_path.relative_to(skill_dir))
                    files[rel] = file_path.read_text()
                except UnicodeDecodeError:
                    pass
    return files


def read_skill(path: Path) -> Skill:
    text = path.read_text()
    assert text.startswith("---"), f"SKILL.md must start with ---: {path}"

    end = text.index("\n---", 3)
    frontmatter = yaml.safe_load(text[3:end])
    body = text[end + 4 :].strip()

    assert isinstance(frontmatter, dict), f"Invalid frontmatter in {path}"
    name = frontmatter.get("name")
    description = frontmatter.get("description")
    assert name, f"Missing 'name' in {path}"
    assert description, f"Missing 'description' in {path}"

    extra = {k: v for k, v in frontmatter.items() if k not in ("name", "description")}
    files = _read_files(path.parent)

    return Skill(
        name=name,
        description=description,
        content=body,
        path=path.resolve(),
        files=files,
        extra_frontmatter=extra,
    )


def write_skill(
    root: Path,
    name: str,
    description: str,
    content: str,
    extra_frontmatter: dict | None = None,
    files: dict[str, str | None] | None = None,
) -> Skill:
    validate_name(name)
    skill_dir = root / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"

    fm = {"name": name, "description": description}
    if extra_frontmatter:
        fm.update(extra_frontmatter)

    header = yaml.dump(fm, default_flow_style=False, sort_keys=False).strip()
    path.write_text(f"---\n{header}\n---\n\n{content}\n")

    written_files: dict[str, str] = {}
    if files:
        for rel_path, file_content in files.items():
            _validate_file_path(rel_path, skill_dir)
            if file_content is None:
                file_path = skill_dir / rel_path
                if file_path.exists():
                    file_path.unlink()
            else:
                file_path = skill_dir / rel_path
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(file_content)
                written_files[rel_path] = file_content

    all_files = _read_files(skill_dir)

    return Skill(
        name=name,
        description=description,
        content=content,
        path=path.resolve(),
        files=all_files,
        extra_frontmatter=extra_frontmatter or {},
    )


def scan_skills(root: Path) -> list[Skill]:
    skills = []
    for skill_md in sorted(root.glob("*/SKILL.md")):
        if skill_md.parent.name.startswith("."):
            continue
        skills.append(read_skill(skill_md))
    return skills
