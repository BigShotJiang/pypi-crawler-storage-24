from __future__ import annotations

import json
from pathlib import Path

from skill_mem.types import Attempt, Outcome, Stats


class Tracker:
    def __init__(self, meta_path: Path) -> None:
        self._path = meta_path / "attempts.json"
        self._attempts: dict[str, list[dict]] = self._load()

    def record(self, name: str, query: str, outcome: Outcome) -> None:
        self._attempts.setdefault(name, []).append(
            {
                "query": query,
                "success": outcome.success,
                "reason": outcome.reason,
            }
        )
        self._save()

    def utility(self, name: str) -> float:
        entries = self._attempts.get(name)
        if not entries:
            return 0.5
        successes = sum(1 for e in entries if e["success"])
        return successes / len(entries)

    def attempts(self, name: str) -> int:
        return len(self._attempts.get(name, []))

    def stats(self, name: str) -> Stats:
        entries = self._attempts.get(name, [])
        successes = sum(1 for e in entries if e["success"])
        failures = len(entries) - successes
        recent = [
            Attempt(
                query=e["query"], skill=name, success=e["success"], reason=e["reason"]
            )
            for e in entries[-10:]
        ]
        return Stats(
            utility=self.utility(name),
            attempts=len(entries),
            successes=successes,
            failures=failures,
            recent=recent,
        )

    def successful_queries(self, name: str) -> list[str]:
        entries = self._attempts.get(name, [])
        return [e["query"] for e in entries if e["success"]]

    def _load(self) -> dict[str, list[dict]]:
        if self._path.exists():
            return json.loads(self._path.read_text())
        return {}

    def _save(self) -> None:
        self._path.write_text(json.dumps(self._attempts))
