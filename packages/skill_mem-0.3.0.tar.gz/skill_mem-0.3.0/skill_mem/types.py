from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class Skill:
    name: str
    description: str
    content: str
    path: Path
    version: int = 1
    files: dict[str, str] = field(default_factory=dict)
    extra_frontmatter: dict = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Match:
    name: str
    description: str
    path: Path
    score: float


@dataclass(frozen=True, slots=True)
class Outcome:
    success: bool
    reason: str


@dataclass(frozen=True, slots=True)
class Attempt:
    query: str
    skill: str
    success: bool
    reason: str


@dataclass(frozen=True, slots=True)
class Revision:
    description: str
    content: str
    files: dict[str, str | None] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Stats:
    utility: float
    attempts: int
    successes: int
    failures: int
    recent: list[Attempt]


@runtime_checkable
class VectorIndex(Protocol):
    def index(self, vectors: dict[str, list[float]]) -> None: ...
    def search(self, query: list[float], k: int) -> list[tuple[str, float]]: ...


Embed = Callable[[str], list[float]]
Rerank = Callable[[str, list[str]], list[float]]
Rewrite = Callable[[Skill, str], Revision]
Create = Callable[[str, str], tuple[str, str, str]]
Validate = Callable[[Skill, Skill], bool]
