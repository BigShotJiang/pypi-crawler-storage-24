from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

from skill_mem.parse import read_skill, scan_skills, write_skill
from skill_mem.router import Router
from skill_mem.tracker import Tracker
from skill_mem.types import (
    Create,
    Embed,
    Match,
    Outcome,
    Rerank,
    Rewrite,
    Skill,
    Stats,
    Validate,
    VectorIndex,
)


class Library:
    def __init__(
        self,
        path: str | Path,
        embed: Embed,
        rerank: Rerank | None = None,
        rewrite: Rewrite | None = None,
        retrieve_k: int = 20,
        evolve_threshold: float = 0.3,
        min_attempts: int = 5,
        vector_index: VectorIndex | None = None,
    ) -> None:
        self._root = Path(path).resolve()
        self._root.mkdir(parents=True, exist_ok=True)

        self._meta = self._root / ".skill-meta"
        self._meta.mkdir(exist_ok=True)
        (self._meta / "history").mkdir(exist_ok=True)

        gitignore = self._meta / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("*\n")

        self._versions_path = self._meta / "versions.json"
        self._versions = self._load_versions()

        self._rewrite = rewrite
        self._evolve_threshold = evolve_threshold
        self._min_attempts = min_attempts
        self._last_auto_evolve: dict[str, int] = {}

        skills = scan_skills(self._root)
        self._index: dict[str, tuple[str, Path, int]] = {}
        for skill in skills:
            v = self._versions.get(skill.name, 1)
            self._index[skill.name] = (skill.description, skill.path, v)

        self._router = Router(
            self._meta,
            embed,
            rerank=rerank,
            retrieve_k=retrieve_k,
            vector_index=vector_index,
        )
        self._tracker = Tracker(self._meta)
        self._reindex(skills)

    def route(self, query: str, k: int = 3) -> list[Match]:
        return self._router.search(query, k)

    def get(self, name: str) -> Skill:
        assert name in self._index, f"Skill not found: {name}"
        _, path, version = self._index[name]
        skill = read_skill(path)
        return replace(skill, version=version)

    def all(self) -> list[Skill]:
        return sorted(
            (self.get(name) for name in self._index),
            key=lambda s: s.name,
        )

    def utility(self, name: str) -> float:
        return self._tracker.utility(name)

    def stats(self, name: str) -> Stats:
        return self._tracker.stats(name)

    def add(self, name: str, description: str, content: str) -> Skill:
        assert name not in self._index, f"Skill already exists: {name}"
        skill = write_skill(self._root, name, description, content)
        self._versions[name] = 1
        self._save_versions()
        self._index[name] = (skill.description, skill.path, 1)
        self._reindex()
        return skill

    def record(self, name: str, query: str, outcome: Outcome) -> Skill | None:
        assert name in self._index, f"Skill not found: {name}"
        self._tracker.record(name, query, outcome)
        if outcome.success:
            self._reindex()
            return None
        attempts_since = self._tracker.attempts(name) - self._last_auto_evolve.get(
            name, 0
        )
        if (
            self._rewrite
            and attempts_since >= self._min_attempts
            and self._tracker.utility(name) < self._evolve_threshold
        ):
            self._last_auto_evolve[name] = self._tracker.attempts(name)
            context = self._build_evolve_context(name)
            return self.evolve(name, context, self._rewrite)
        return None

    def evolve(
        self,
        name: str,
        context: str,
        rewrite: Rewrite,
        validate: Validate | None = None,
    ) -> Skill:
        old = self.get(name)
        revision = rewrite(old, context)

        merged_files = {**old.files, **revision.files}
        live_files = {k: v for k, v in merged_files.items() if v is not None}
        candidate = replace(
            old,
            description=revision.description,
            content=revision.content,
            files=live_files,
            version=old.version + 1,
        )

        if validate and not validate(old, candidate):
            return old

        history_dir = self._meta / "history" / name
        history_dir.mkdir(parents=True, exist_ok=True)
        (history_dir / f"v{old.version}.md").write_text(old.path.read_text())

        updated = write_skill(
            self._root,
            name,
            revision.description,
            revision.content,
            old.extra_frontmatter,
            {**old.files, **revision.files},
        )
        updated = replace(updated, version=old.version + 1)

        self._versions[name] = updated.version
        self._save_versions()
        self._index[name] = (updated.description, updated.path, updated.version)
        self._reindex()
        return updated

    def discover(self, query: str, context: str, create: Create) -> Skill:
        name, description, content = create(query, context)
        assert name not in self._index, f"Skill already exists: {name}"
        return self.add(name, description, content)

    def _build_evolve_context(self, name: str) -> str:
        stats = self._tracker.stats(name)
        failures = [a for a in stats.recent if not a.success]
        lines = [
            f"Skill '{name}' utility={stats.utility:.2f} after {stats.attempts} attempts."
        ]
        for a in failures:
            lines.append(f"  query: {a.query} — {a.reason}")
        return "\n".join(lines)

    def _reindex(self, skills: list[Skill] | None = None) -> None:
        if skills is None:
            skills = scan_skills(self._root)
        queries = {name: self._tracker.successful_queries(name) for name in self._index}
        self._router.index(skills, queries)

    def _load_versions(self) -> dict[str, int]:
        if self._versions_path.exists():
            return json.loads(self._versions_path.read_text())
        return {}

    def _save_versions(self) -> None:
        self._versions_path.write_text(json.dumps(self._versions))
