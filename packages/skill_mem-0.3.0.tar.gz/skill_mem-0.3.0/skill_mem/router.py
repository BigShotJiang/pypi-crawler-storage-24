from __future__ import annotations

import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path

from skill_mem.types import Embed, Match, Rerank, Skill, VectorIndex


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    assert norm_a > 0 and norm_b > 0, "Zero-norm vector"
    return dot / (norm_a * norm_b)


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def _routing_text(skill: Skill, successful_queries: list[str]) -> str:
    parts = [skill.name, skill.description, skill.content]
    for rel_path, content in sorted(skill.files.items()):
        parts.append(f"{rel_path}:\n{content}")
    if successful_queries:
        examples = successful_queries[-5:]
        parts.append("Examples: " + " | ".join(examples))
    return "\n".join(parts)


def _rrf(
    rankings: list[list[tuple[str, float]]], k: int = 60
) -> list[tuple[str, float]]:
    """Reciprocal rank fusion across multiple ranked lists."""
    scores: dict[str, float] = {}
    for ranking in rankings:
        for rank, (name, _) in enumerate(ranking):
            scores[name] = scores.get(name, 0) + 1 / (k + rank + 1)
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


class BruteForce:
    """Default brute-force cosine similarity search."""

    def __init__(self) -> None:
        self._vectors: dict[str, list[float]] = {}

    def index(self, vectors: dict[str, list[float]]) -> None:
        self._vectors = vectors

    def search(self, query: list[float], k: int) -> list[tuple[str, float]]:
        scored = [(name, _cosine(query, vec)) for name, vec in self._vectors.items()]
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:k]


class _BM25:
    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self._k1 = k1
        self._b = b
        self._docs: dict[str, Counter] = {}
        self._doc_lens: dict[str, int] = {}
        self._avg_dl: float = 0.0
        self._idf: dict[str, float] = {}

    def index(self, documents: dict[str, str]) -> None:
        self._docs = {}
        self._doc_lens = {}
        df: Counter = Counter()

        for name, text in documents.items():
            tokens = _tokenize(text)
            self._docs[name] = Counter(tokens)
            self._doc_lens[name] = len(tokens)
            df.update(set(tokens))

        n = len(documents)
        self._avg_dl = sum(self._doc_lens.values()) / max(n, 1)
        self._idf = {
            term: math.log((n - freq + 0.5) / (freq + 0.5) + 1)
            for term, freq in df.items()
        }

    def search(self, query: str, k: int) -> list[tuple[str, float]]:
        tokens = _tokenize(query)
        scores: list[tuple[str, float]] = []
        for name, tf in self._docs.items():
            s = 0.0
            dl = self._doc_lens[name]
            for t in tokens:
                if t not in tf:
                    continue
                idf = self._idf.get(t, 0.0)
                freq = tf[t]
                s += (
                    idf
                    * (freq * (self._k1 + 1))
                    / (freq + self._k1 * (1 - self._b + self._b * dl / self._avg_dl))
                )
            scores.append((name, s))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:k]


class Router:
    def __init__(
        self,
        meta_path: Path,
        embed: Embed,
        rerank: Rerank | None = None,
        retrieve_k: int = 20,
        vector_index: VectorIndex | None = None,
    ) -> None:
        self._embed = embed
        self._rerank = rerank
        self._retrieve_k = retrieve_k
        self._db_path = meta_path / "embeddings.json"
        self._entries: dict[str, dict] = self._load()
        self._meta: dict[str, tuple[str, Path]] = {}
        self._routing_texts: dict[str, str] = {}
        self._bm25 = _BM25()
        self._vector_index: VectorIndex = vector_index or BruteForce()

    def index(
        self,
        skills: list[Skill],
        successful_queries: dict[str, list[str]] | None = None,
    ) -> None:
        queries = successful_queries or {}
        current_names = {s.name for s in skills}

        self._meta = {s.name: (s.description, s.path) for s in skills}

        for name in list(self._entries):
            if name not in current_names:
                del self._entries[name]

        routing_texts: dict[str, str] = {}
        for skill in skills:
            text = _routing_text(skill, queries.get(skill.name, []))
            routing_texts[skill.name] = text
            h = _hash(text)
            entry = self._entries.get(skill.name)
            if entry and entry["hash"] == h:
                continue
            self._entries[skill.name] = {
                "vector": [float(x) for x in self._embed(text)],
                "hash": h,
            }

        self._routing_texts = routing_texts
        self._vector_index.index(
            {name: e["vector"] for name, e in self._entries.items()}
        )
        self._bm25.index(routing_texts)
        self._save()

    def search(self, query: str, k: int) -> list[Match]:
        if not self._entries:
            return []

        window = max(k, self._retrieve_k) if self._rerank else k

        q_vec = self._embed(query)
        dense = self._vector_index.search(q_vec, window)
        sparse = self._bm25.search(query, window)
        fused = _rrf([dense, sparse])
        candidates = [
            (name, score) for name, score in fused[:window] if name in self._meta
        ]

        if not candidates:
            return []

        if self._rerank:
            names = [name for name, _ in candidates]
            texts = [self._routing_texts[name] for name in names]
            rerank_scores = self._rerank(query, texts)
            assert len(rerank_scores) == len(names), (
                f"Reranker returned {len(rerank_scores)} scores for {len(names)} documents"
            )
            reranked = sorted(
                zip(names, rerank_scores),
                key=lambda x: x[1],
                reverse=True,
            )
            candidates = reranked[:k]
        else:
            candidates = candidates[:k]

        return [
            Match(
                name=name,
                description=self._meta[name][0],
                path=self._meta[name][1],
                score=score,
            )
            for name, score in candidates
        ]

    def _load(self) -> dict[str, dict]:
        if self._db_path.exists():
            return json.loads(self._db_path.read_text())
        return {}

    def _save(self) -> None:
        self._db_path.write_text(json.dumps(self._entries))
