from __future__ import annotations

import os
import platform
import stat
import subprocess
import sys
from pathlib import Path

__version__ = "0.1.23"

_SYSTEM_MAPPING = {
    "windows": "windows",
    "linux": "linux",
    "darwin": "darwin",
}

_ARCH_MAPPING = {
    "amd64": "amd64",
    "x86_64": "amd64",
    "arm64": "arm64",
    "aarch64": "arm64",
}


def _binary_name() -> str:
    system = platform.system().strip().lower()
    machine = platform.machine().strip().lower()

    platform_key = _SYSTEM_MAPPING.get(system)
    arch_key = _ARCH_MAPPING.get(machine)
    if not platform_key or not arch_key:
        raise RuntimeError(
            f"Unsupported platform: {platform.system()}-{platform.machine()}"
        )

    suffix = ".exe" if platform_key == "windows" else ""
    return f"distromate-{platform_key}-{arch_key}{suffix}"


def get_binary_path() -> Path:
    binary_path = Path(__file__).parent / "binaries" / _binary_name()
    if not binary_path.is_file():
        raise RuntimeError(
            f"Binary not found: {binary_path}. Reinstall distromate to restore it."
        )
    return binary_path


def resolve_resource_dir(binary_path: Path) -> Path | None:
    env_value = os.environ.get("DISTROMATE_RESOURCE_DIR", "").strip()
    if env_value:
        env_path = Path(env_value)
        if env_path.exists():
            return env_path

    package_dir = Path(__file__).parent
    candidates = [
        package_dir / "resource",
        binary_path.parent / "resource",
        binary_path.parent.parent / "resource",
        package_dir.parent / "resource",
        package_dir.parent.parent / "resource",
        package_dir.parent.parent.parent / "resource",
    ]

    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            resolved = candidate
        if resolved in seen:
            continue
        seen.add(resolved)
        if resolved.exists() and resolved.is_dir():
            return resolved

    return None


def main() -> None:
    try:
        binary_path = get_binary_path()
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    if sys.platform != "win32":
        current_mode = binary_path.stat().st_mode
        if not (current_mode & stat.S_IEXEC):
            binary_path.chmod(current_mode | stat.S_IEXEC)

    env = os.environ.copy()
    resource_dir = resolve_resource_dir(binary_path)
    if resource_dir is not None:
        env.setdefault("DISTROMATE_RESOURCE_DIR", str(resource_dir))

    try:
        result = subprocess.run([str(binary_path), *sys.argv[1:]], env=env, check=False)
    except FileNotFoundError:
        print("Error: distromate binary not found", file=sys.stderr)
        print(
            "Try reinstalling it: pip install --force-reinstall distromate",
            file=sys.stderr,
        )
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)

    sys.exit(result.returncode)
