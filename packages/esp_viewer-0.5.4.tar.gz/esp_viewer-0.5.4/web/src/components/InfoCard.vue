<template>
    <div class="bg-slate-800/20 border border-slate-800 rounded-xl p-4">
      <h3 class="text-[10px] font-black text-slate-600 uppercase mb-3 tracking-widest">{{ title }}</h3>
      <slot></slot>
    </div>
</template>

<script setup>
defineProps(['title']);
</script>
