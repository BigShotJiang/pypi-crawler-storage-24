<template>
    <div class="flex justify-between items-center py-2 border-b border-slate-800/50 last:border-0">
      <span class="text-[11px] font-bold text-slate-500 uppercase">{{ label }}</span>
      <span class="text-xs font-semibold text-slate-200">{{ value || 'N/A' }}</span>
    </div>
</template>

<script setup>
defineProps(['label', 'value']);
</script>
