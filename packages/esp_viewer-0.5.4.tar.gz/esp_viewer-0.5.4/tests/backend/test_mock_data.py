import asyncio
import sys
from pprint import pprint

import os
# Add parent directory of esp_viewer to path to allow imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../..")))

from esp_viewer.core.backend import DeviceService
from esp_viewer.core.protocol import CommandType, Packet
import queue

def verify_mock_chip_info():
    cmd_q = queue.Queue()
    evt_q = queue.Queue()
    profile = {"meta": {"name": "Test", "mock_type": "data"}, "parameters": [], "streams": []}
    
    service = DeviceService(cmd_q, evt_q, profile)
    
    # Use real MockDevice but don't open it
    from esp_viewer.core.mock_device import MockDevice
    service.device_interface = MockDevice(port="MOCK", profile=profile)
    
    # Send GET_CHIP_INFO command
    service._handle_command(Packet(CommandType.GET_CHIP_INFO))
    
    # Check event queue
    while not evt_q.empty():
        pkt = evt_q.get()
        if pkt.type.name == "CHIP_INFO_RECEIVED":
            print("Successfully received CHIP_INFO_RECEIVED event.")
            print("\n--- CHIP INFO ---")
            pprint(pkt.payload.get("chip", {}))
            print("\n--- FLASH INFO ---")
            pprint(pkt.payload.get("flash", {}))
            print("\n--- SECURITY INFO ---")
            pprint(pkt.payload.get("security", {}))
            return

    print("Error: Event not received or missing data.")

if __name__ == "__main__":
    verify_mock_chip_info()
