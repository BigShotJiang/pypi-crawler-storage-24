# Copyright 2026 Espressif Systems (Shanghai) Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import json
import unittest

from esp_viewer.core.mock_device import MockDevice


class TestInteractiveMock(unittest.TestCase):
    def test_mock_param_update(self):
        # 1. Setup Mock with a profile
        profile = {
            "parameters": [
                {"id": "gain", "type": "int", "default": 10},
                {"id": "threshold_v", "type": "float", "default": 5.0},
            ],
            "streams": [],
        }
        mock = MockDevice(profile=profile)

        # 2. Verify defaults
        self.assertEqual(mock.params.get("gain"), 10)
        self.assertEqual(mock.params.get("threshold_v"), 5.0)

        # 3. Send Set Config command
        cmd = {
            "method": "set_config",
            "params": {"gain": 20, "threshold_v": 8.5},
            "id": 1,
        }
        mock.write(json.dumps(cmd))

        # 4. Verify updates
        self.assertEqual(mock.params.get("gain"), 20)
        self.assertEqual(mock.params.get("threshold_v"), 8.5)


if __name__ == "__main__":
    unittest.main()
