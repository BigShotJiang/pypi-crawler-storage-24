## TODO List
- [ ] Control Panel: Make the sync button fetch actual parameter values directly from the connected ESP device instead of just reloading the local JSON profile.


## IN Review

## Done
