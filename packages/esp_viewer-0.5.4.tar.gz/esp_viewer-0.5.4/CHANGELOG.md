# Changelog

All notable changes to this project will be documented in this file.

## [0.5.4] - 2026-03-11

### Added
- **Baud Rate Selection**: Added baud rate selection to the UI, applying it consistently to serial communication and flashing operations.
- **Improved Test Tasks**: Refined VSCode tasks for unit tests and mock integration, consolidating definitions.

### Changed
- **UI Enhancements**: Renamed "Backing up" to "Save" and removed the obsolete "Flash Write" button.
- **Mock Configuration**: Relocated `mock_chip_info.json` from `assets/` to `core/` to avoid confusion with example profiles.

### Fixed
- **Firmware Downloads**: Fixed "file not found" errors and FastAPI mount orders for serving `.bin` and `.json` files.
- **Workflow & Check**: Adopted `final_check_and_release` workflow documentation.

## [0.5.3] - 2026-03-06
### Fixed
- **Web UI Sync**: Fixed issue where refreshing the page would lose current data/streaming state (Bug #1).
- **Port Discovery**: Replaced hardcoded port list with dynamic system port detection (Bug #2).
- **Connection Feedback**: Added error notifications for failed device connections and removed "optimistic" connection UI (Bug #3).
- **Parameter Refresh**: Added a refresh button and "Syncing" status indicator to the Control Panel (Bug #4).
- **Simulator Branding**: Renamed and moved "Simulator" to the bottom of the device list for better UX (Bug #5).
- **WebSocket Robustness**: Fixed a syntax error in the web adapter and improved initial state handshake.

## [v0.5.2] - 2026-03-06

### Changed
- **Package Renaming**: Unified project and package naming to `esp_viewer` for consistency across PyPI and imports.

### Fixed
- **Installation Consistency**: Fixed modular execution issue (`python -m esp_viewer`) after renaming by ensuring correct submodule discovery.

## [v0.5.1] - 2026-03-06

### Added
- **Mock Data Persistence**: Backend now persistently loads `mock_chip_info.json` if available, reflecting captured hardware details in mock mode.
- **Improved CLI Robustness**: Added mandatory `--profile` checks to prevent GUI launcher deadlocks in non-interactive/SSH environments.

### Fixed
- **Chip Info Robustness**: Improved parsing for newer `esptool` output formats and fixed ANSI escape sequence stripping.
- **Web UI Connectivity**: Optimized WebSocket handshake and ensured clean port cleanup on restart.
- **Linting**: Fixed various PEP8 and unused import issues in the core and web adapter.

## [v0.5.0] - 2026-03-05

### Added
- **Chip Info Diagnostics**: New "Chip Info" perspective in the Web UI, providing deep inspection of ESP hardware.
- **Hardware Summaries**: Automated gathering of Chip Summary (Model, Revision, MAC), Flash Identity (Size, Manufacturer, Status), ADC Calibration data, and full eFuse dumps via background `esptool` and `espefuse` integration.
- **Security Audit**: High-level security status dashboard to quickly verify Flash Encryption and Secure Boot states.
- **Protocol Expansion**: Added `GET_CHIP_INFO` command and `CHIP_INFO_RECEIVED` event to the core protocol.
- **Iterative Hardware Re-Connect**: Backend now supports temporary device suspension to allow low-level tools (like `esptool`) to claim the serial port, automatically restoring the telemetry stream once diagnostics are complete.

## [v0.4.0] - 2026-03-04

### Added
- **Firmware Integration**: Added `esptool.py` to the core dependency tree.
- **Dynamic Downloads**: Added `DOWNLOAD_FIRMWARE` command. The engine can now parse a `url` payload to download a firmware binary file to a local `Data/firmware/` cache.
- **Mock Firmware Loader**: `start_download('test')` generates a 1MB dummy binary for UI testing.
- **Subprocess Flashing**: Added `FLASH_FIRMWARE` command. `FirmwareManager` suspends serial monitoring, allocates the port to an `esptool write_flash` subprocess, and pipes realtime terminal output and progress stats back to the frontend log GUI.

## [v0.3.0] - 2026-03-03

### Added
- **Modern Web UI (`esp_viewer.web`)**: Implemented a complete frontend Alternative using Vue 3 and Vite, available via the `--web` CLI flag. Supports dynamic control panels, realtime uPlot charts, and table monitors driven purely by `profile.json`.
- **System Logger Integration**: `EspViewerEngine` and `DeviceService` now use Python's standard `logging` library. Crash traces and system details are now persistently rotated and archived to `logs/esp_viewer.log`.
- **Custom Plot Colors for Web**: The Web UI now parses and applies custom telemetry definitions (`colors` field) from the active profile.
- **Dynamic Gestures Table**: Web UI now supports profile `table` monitors, creating dynamic real-time event logs for non-continuous data like `SHAKE DETECTED`.

### Fixed
- **Web Reactivity Memory Leak**: Reduced Vue prop reactivity overhead in high-frequency plots by using a 60FPS `requestAnimationFrame` grouping strategy.
- **Web UI Stale Plot Data Bug**: Reconnecting or toggling streams in the browser no longer causes new plot paths to overlap and squish the X-axis onto older disconnected plot states.

## [v0.2.0] - 2026-02-28

### Added
- **Multi-Plot Demo**: New `assets/examples/multi_plot_demo.json` profile demonstrating 3 independent data streams (`P1`, `P2`, `P3`) each driving a dedicated plot window.
- **`multi_plot` Mock Type**: New `MockDevice` generator emitting 9 realistic waveforms (Sine/Cosine/Square, Triangle/Sawtooth/Noise, Phase-shifted sines).
- **Resizable Plot Layout**: Replaced the static `pg.GraphicsLayoutWidget` with a `QSplitter` container. Each plot is now an independent `PlotWidget`, allowing drag-to-resize.
- **Auto-Timestamping**: Backend now auto-injects a local PC timestamp if the device stream omits a `ts` field.
- **Agent Code of Conduct**: Formal guidelines in `docs/agent_guide.md` covering SemVer, mandatory changelog updates, documentation synchronization, and no-placeholder policy.

### Changed
- **License**: Transitioned `esp_viewer` from MIT to **Apache License 2.0**. All Python source files now include the required copyright header.

### Fixed
- Fixed missing timestamps in `MockDevice` event emissions, causing the Gestures table to remain empty.
- Fixed redundant marker cleanup calls in the high-speed data loop causing UI stutter.
- Fixed X-axis "jitter" caused by markers by explicitly locking the view range to the data buffer boundaries.
- Fixed plot data overlap when starting a new stream session (auto-clear now runs on stream start).

## [v0.1.1] - 2026-02-28

### Added
- New **Clear** button in the toolbar to manually wipe all plot data and event tables.
- Automatic plot/marker/table clearing when starting a new stream session.
- Mandatory **Agent Code of Conduct** in `docs/agent_guide.md`.

### Changed
- **License Change**: Transitioned from MIT to **Apache License 2.0**.
- **Performance**: Optimized marker rendering (single-label mode) to reduce UI stutter.
- **Improved Stability**: Locked X-Axis range to data buffers to prevent "jitter" or "jumping" when markers are added.
- Refactored `GenericWindow` to unify marker and event processing logic.

### Fixed
- Fixed missing timestamps in `MockDevice` event emissions, which caused the "Gestures" table to remain empty.
- Fixed redundant marker cleanup calls in the high-speed data loop.

## [v0.1.0] - 2026-02-26

### Added
- Initial generic framework release.
- Dynamic control panel generation from JSON profiles.
- High-speed data plotting with `pyqtgraph`.
- Support for multiple data streams (CSV/Regex).
- Data IO monitoring with TX/RX logging and recording.
- Serial and Mock device drivers.
- Automatic profile synchronization (Fetch from device).
- Support for `set_template` in parameter definitions for flexible protocols.

### Changed
- Refactored UI for improved scalability.
- Standardized internal protocol using JSON-RPC 2.0.

### Fixed
- Fixed duplicate method definitions and inconsistent marker cleanup.
- Improved docstrings and type hints for better developer/agent experience.
