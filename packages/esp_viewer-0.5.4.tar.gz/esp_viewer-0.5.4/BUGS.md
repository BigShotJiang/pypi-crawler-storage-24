## TODO List

## IN Review

## Done
- 1. 设备列表显示错误（已在前端修复，每次打开下拉框动态请求列表）
- 2. Connector和disconnect按钮异常（已在后端修复，处理chip info时静默连接切换）
- 3. 后端应该给一个debug指令（已经在 main 和 logger 配置里加了 --debug 参数）
- 4. 连接mock设备并没有输出数据（已经修复，安全的类型转换使得 generator 的 time.sleep 正常工作）
