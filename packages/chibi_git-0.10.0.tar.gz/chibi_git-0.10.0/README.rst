=========
Chibi_git
=========


.. image:: https://img.shields.io/pypi/v/chibi_git.svg
        :target: https://pypi.python.org/pypi/chibi_git

.. image:: https://readthedocs.org/projects/chibi-git/badge/?version=latest
        :target: https://chibi-git.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


wrapper to use git in python

* Free software: WTFPL
* Documentation: https://chibi-git.readthedocs.io.


Ejemplos de uso
---------------

agregar los archivos con cambios y hacer un commit
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

	from chibi_git import Git


	repo = Git( '/algun/directorio' )
	for file in repo.status.modified:
		file.add()
	repo.commit( 'algun mensaje' )
	repo.push()

revisar si head esta desincronizado de origin

.. code-block:: python

	from chibi_git import Git


	repo = Git( '/algun/directorio' )
	assert repo.is_head_synchronize_with_origin
