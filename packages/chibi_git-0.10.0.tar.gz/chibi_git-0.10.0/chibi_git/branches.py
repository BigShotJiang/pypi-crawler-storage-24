from chibi_atlas import Chibi_atlas
from chibi_git.obj import Branch, Commit
from chibi_git.command import Git


class Branches:
    def __init__( self, repo ):
        self.repo = repo

    def __repr__( self ):
        return (
            f"Branches( repo={self.repo} )"
        )

    @property
    def local( self ):
        branches = Git.branch( src=self.repo.path ).run()
        result = map( lambda x: Branch( self.repo, x ), branches.result )
        return Chibi_atlas( { b: b for b in result } )

    @property
    def remote( self ):
        return Branches_remote( repo=self.repo )
        branches = Git.branch( remote=True, src=self.repo.path ).run()
        result = map( lambda x: Branch( self.repo, x ), branches.result )
        return Branches_remote( result )

    def __iter__( self ):
        return iter( self.local )

    def create( self, name, target=None ):
        """
        crea una nueva rama en el target

        Parameters
        ----------
        name: str
            nombre de la rama nueva
        target: str
            objetivo de la rama
        """
        if target is None:
            target = 'HEAD'
        if isinstance( target, Commit ):
            target = str( target )
        if isinstance( target, str ):
            pass
        else:
            raise NotImplementedError(
                f"target {type(target)} con valor {target} no implementado" )

        command = Git.branch( name, target, src=self.repo.path )
        command.run()
        return self.local[ name ]


class Branches_remote:
    def __init__( self, repo, prefix=None ):
        self.repo = repo
        self.prefix = prefix

    def __repr__( self ):
        return (
            f"Branches_remote( repo={self.repo} )"
        )

    @property
    def origin( self ):
        return Branches_remote( repo=self.repo, prefix='origin' )

    def __iter__( self ):
        if self.prefix is not None:
            yield from self._branches
        else:
            yield from self._branches

    def __getitem__( self, name ):
        if self.prefix:
            for branch in self:
                branch_name = branch.name
                prefix, branch_name = branch_name.split( '/', 1 )
                if prefix != self.prefix:
                    raise NotImplementedError(
                        "los prefijos son diferentes "
                        f"{self.prefix}, {prefix}" )
                if name == branch_name:
                    return branch
        else:
            for branch in self:
                if name == branch.name:
                    return branch
        raise KeyError( f'no se encontro la rama "{name}"' )

    @property
    def _branches( self ):
        branches = Git.branch( remote=True, src=self.repo.path ).run()
        for branch in branches.result:
            yield Branch( repo=self.repo, name=branch, is_remote=True )

    def __getattr__( self, name ):
        try:
            return super().__getattribute__( name )
        except AttributeError as e:
            try:
                return self[ name ]
            except KeyError:
                raise e
