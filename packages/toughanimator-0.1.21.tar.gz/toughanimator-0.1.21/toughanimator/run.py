from csv import reader

import toughanimator as ta

#reader = ta.vis_reader(r"D:\Projects\tough-processing\tough_case\tcs_20260316")
reader = ta.vis_reader(r"D:\Projects\tough-processing\tough_case\tcs_20260324_v2_hetero\tough3")
# You can create main geometry, initial condition, and result files seperately using those functions(must run it with this order): 
reader.write_eleme_conne()
reader.write_geometry()
reader.write_incon()
reader.write_result()