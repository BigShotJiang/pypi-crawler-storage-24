#!/usr/bin/env python3
"""ClawCoder - Setup configuration for Windows installer"""
from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='clawcoder',
    version='1.0.3',
    description='ClawCoder - AI-Powered Coding Assistant',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Jason Sang (桑杰逊)',
    author_email='sangjiexun@gmail.com',
    python_requires='>=3.9',
    packages=find_packages(exclude=['tests', 'tests.*', 'examples', 'examples.*']),
    include_package_data=True,
    install_requires=[
        'langgraph>=0.2.0',
        'langchain>=0.3.0',
        'langchain-openai>=0.2.0',
        'langchain-anthropic>=0.2.0',
        'langchain-community>=0.3.0',
        'Pillow>=10.0.0',
        'pydub>=0.25.0',
        'moviepy>=1.0.0',
        'capstone>=5.0.0',
        'pefile>=2024.0.0',
        'msgpack>=1.0.0',
    ],
    entry_points={
        'console_scripts': [
            'clawcode=clawcoder_cli:main',
            'clawcoder=clawcoder_cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: Microsoft :: Windows',
        'Topic :: Software Development :: Tools',
    ],
    keywords='ai coding assistant llm langgraph',
    project_urls={
        'Source': 'https://github.com/sangjiexun/clawcoder',
    },
)
