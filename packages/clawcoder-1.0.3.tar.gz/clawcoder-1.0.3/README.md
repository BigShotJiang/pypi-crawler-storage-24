# 🦞ClawCoder🦞

**AI-Powered Coding Assistant** - 一个基于 LangGraph 的交互式命令行编程助手，由 Kimi K2.5 驱动。

## 特性

- 🤖 **AI 对话** - 直接与 Kimi K2.5 智能对话
- 📁 **文件操作** - 浏览、读取、编辑文件
- ⚡ **代码执行** - 运行 shell 命令
- ✏️ **AI 编辑** - 用 AI 辅助修改代码
- 🔍 **文件分析** - 分析文本、图片、音视频文件
- 🛠️ **二进制反汇编** - 支持 x86/x64/ARM 架构
- 💾 **历史存储** - 对话保存为二进制格式
- 🔑 **智能配置** - 首次运行自动引导配置 API Key

## 安装

```bash
pip install clawcoder
```

## 快速开始

### 首次运行

安装后直接运行：

```bash
clawcode
```

首次运行时，如果未配置 API Key，会自动弹出配置向导：

```
============================================================
  🔑 API Key 配置
============================================================

  欢迎使用 🦞ClawCoder🦞 - AI 编程助手

  首次使用需要配置 Kimi API Key
  您可以从 https://platform.moonshot.cn/ 获取 API Key

------------------------------------------------------------

  请输入您的 API Key: 
  请输入 API Base URL [默认: https://api.kimi.com/coding]: 
  请输入模型名称 [默认: k2p5]: 

  ✅ 配置已保存到: ~/.clawcoder/config.json
============================================================
```

### 获取 API Key

1. 访问 [Moonshot AI 平台](https://platform.moonshot.cn/)
2. 注册/登录账号
3. 在控制台创建 API Key
4. 将 API Key 输入到配置向导中

## 使用方式

```bash
# 交互式 REPL 模式
clawcode

# 指定工作目录
clawcode /path/to/project

# 快速提问
clawcode --ask "如何实现快速排序"

# 执行单条命令
clawcode -e "/ls"

# 查看版本
clawcode --version
```

## 命令列表

### 基本命令

| 命令 | 功能 |
|------|------|
| `/help`, `/h` | 显示帮助信息 |
| `/exit`, `/quit`, `/q` | 退出程序 |
| `/clear`, `/cls` | 清屏 |

### 文件操作

| 命令 | 功能 |
|------|------|
| `/ls [path]` | 列出文件 |
| `/cd <path>` | 切换目录 |
| `/pwd` | 显示当前目录 |
| `/cat <file>` | 读取文件内容 |
| `/write <file>` | 写入文件 |
| `/edit <file>` | AI 辅助编辑文件 |
| `/rm <file>` | 删除文件 |
| `/mkdir <dir>` | 创建目录 |

### 代码执行

| 命令 | 功能 |
|------|------|
| `/run <command>` | 运行命令 (如: `/run python script.py`) |
| `/shell`, `/sh` | 进入 shell 模式 |
| `/disasm <file>` | 反汇编二进制文件 |

### AI 功能

| 命令 | 功能 |
|------|------|
| `/analyze <file>` | 分析文件 |
| `/new` | 开始新对话 |
| `/history` | 查看对话历史 |
| `/save <file>` | 保存对话历史 |
| `/load <file>` | 加载对话历史 |

### 系统配置

| 命令 | 功能 |
|------|------|
| `/info` | 显示系统信息 |
| `/model` | 显示当前模型 |
| `/config` | 重新配置 API Key |
| `/config show` | 显示当前配置 |

## 支持的文件类型

| 类型 | 扩展名 |
|------|--------|
| 文本 | `.md`, `.txt`, `.json`, `.jsonl` |
| 图片 | `.jpg`, `.jpeg`, `.png`, `.bmp` |
| 音频 | `.mp3`, `.wav` |
| 视频 | `.mp4`, `.flv` |
| 二进制 | `.bin` |

## 配置方式

### 方式一：交互式配置（推荐）

首次运行时自动引导配置，配置保存在 `~/.clawcoder/config.json`

### 方式二：环境变量

```bash
# Linux/macOS
export KIMI_API_KEY="your-api-key"
export KIMI_BASE_URL="https://api.kimi.com/coding"  # 可选
export KIMI_MODEL="k2p5"  # 可选

# Windows PowerShell
$env:KIMI_API_KEY="your-api-key"
```

### 方式三：代码配置

```python
from clawcoder import create_coder

coder = create_coder(
    api_key="your-api-key",
    base_url="https://api.kimi.com/coding",
    model="k2p5",
    workspace="."
)

# 与 AI 对话
response = coder.chat("如何实现快速排序？")
print(response)

# 分析文件
result = coder.analyze_file("example.py")
print(result)

# 反汇编二进制
disasm = coder.disassemble_binary("program.bin", arch="x64")
print(disasm)
```

### 配置优先级

1. **环境变量** `KIMI_API_KEY`（最高优先级）
2. **配置文件** `~/.clawcoder/config.json`
3. **交互式输入**（首次使用）

## 配置文件位置

- **Linux/macOS**: `~/.clawcoder/config.json`
- **Windows**: `C:\Users\<用户名>\.clawcoder\config.json`

配置文件格式：

```json
{
  "api_key": "sk-xxxxxxxxxxxxxxxx",
  "base_url": "https://api.kimi.com/coding",
  "model": "k2p5"
}
```

## 项目架构

```
clawcoder/
├── agent/           # LangGraph 核心框架
│   ├── state.py     # 状态定义
│   └── graph.py     # 图构建
├── processors/      # 文件处理器
│   ├── file_handler.py    # 文本文件处理
│   ├── image_handler.py   # 图片处理
│   └── media_handler.py   # 音视频处理
├── skills/          # 技能模块
│   └── disassembler.py    # 二进制反汇编
├── storage/         # 存储模块
│   └── history_storage.py # 对话历史存储
├── clawcoder.py     # 核心类
└── clawcoder_cli.py # CLI 入口
```

## 常见问题

### Q: 如何更换 API Key？

运行 `/config` 命令重新配置，或直接编辑 `~/.clawcoder/config.json` 文件。

### Q: 支持哪些模型？

默认使用 Kimi K2.5 (k2p5)，也可以配置其他兼容 OpenAI API 的模型。

### Q: 对话历史保存在哪里？

对话历史以二进制格式保存在工作目录的 `./history/` 文件夹中。

### Q: 如何查看当前配置？

运行 `/config show` 命令查看当前配置（API Key 会被隐藏显示）。

## 作者

**Jason Sang (桑杰逊)**
- Email: sangjiexun@gmail.com
- QQ: 1009900122
- WeChat: bitchatgpt
- GitHub: https://github.com/sangjiexun

## License

MIT License - 详见 [LICENSE](LICENSE) 文件
