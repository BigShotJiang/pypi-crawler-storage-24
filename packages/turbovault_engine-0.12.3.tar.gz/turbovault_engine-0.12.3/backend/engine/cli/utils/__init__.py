"""Console utilities package."""
