import logging
import sys
from collections.abc import Sequence
from pathlib import Path
from typing import cast

from control_arena.eval import EvalMode, get_control_task
from inspect_ai import eval
from inspect_ai.model import get_model
from inspect_ai.solver import chain, human_agent

from ...config import Config, create_fingerprint
from ...settings.full_repo_refactor_setting import FullRepoRefactorSetting
from ...solvers import agent_control_solver
from ...utils.collections import find_index, is_element_sequence, to_list
from ...utils.format import format_as_yaml

logger = logging.getLogger(__name__)


def eval_command(config: Config, logs_dir: Path) -> int:
    """
    Runs the evaluation.
    """
    try:
        dataset = config.get("setting.dataset")
        main_task = config.get("setting.main_task")
        side_task = config.get("setting.side_task")
        eval_mode = config.get("eval.mode")

        # TODO: Figure out a way to integrate this into the config parser itself. I extended the
        #       args parser to create enums, but when the eval mode is set in a configuration file,
        #       it is not converted to an enum. [fastfedora 20.Oct.25]
        # Force the eval mode to be an enum
        if isinstance(eval_mode, str):
            eval_mode = EvalMode(eval_mode)
            config.add_overrides({"eval": { "mode": eval_mode }})

        use_human_agent = config.get("human_agent.active")
        swe_agent = config.get("swe_agent.name")
        extra_features = []

        if use_human_agent:
            extra_features.append("human-agent")

        setting = FullRepoRefactorSetting(
            main_task=main_task,
            side_task=side_task,
            dataset=dataset,
            scorer_model=config.get("setting.scorer_model"),
            extra_sandbox_features=extra_features,
            tool_timeout=config.get("setting.tool_timeout"),
        )

        logger.info(f"Starting Full Repository Refactor evaluation in {eval_mode.value} mode")
        logger.info(f"Dataset: {dataset}")
        logger.info(f"Main task filter: {main_task or 'all'}")
        logger.info(f"Side task filter: {side_task or 'all'}")
        logger.info(f"Logs directory: {logs_dir}")
        logger.info(f"Config Fingerprint:\n{format_as_yaml(create_fingerprint(config))}")

        # Create evaluation configuration
        eval_config = config.get("eval.config")

        # Create policy and micro-protocol
        untrusted_model = config.get("models.untrusted.name")
        policy_name = config.get("policy.name")
        micro_protocol = config.get(f"policy.options.{policy_name}")
        monitors = _get_monitors(config)

        # Create evaluation tasks
        eval_task = get_control_task(
            setting=setting,
            micro_protocol=micro_protocol,
            mode=eval_mode,
            eval_config=eval_config,
            monitoring_scorers=monitors,
            metadata={
                # Store only the actual configuration values used by this eval, not the full config
                "config": config.get_usage(),
            }
        )

        # Set the primary model for the eval log, so tools that only show this model will show a
        # useful model string. Use the untrusted model since it's the primary agent.
        # TODO: Review this decision. Now that we have configurable policies, it may not always be
        #       appropriate to use the untrusted model. [fastfedora 30.Jan.26]
        if untrusted_model:
            eval_task.model = get_model(untrusted_model)

        solvers = list(cast(Sequence, eval_task.solver))
        control_solver_index = find_index(solvers, lambda x: "control_solver" in str(x))

        if control_solver_index is not None:
            if use_human_agent:
                solvers[control_solver_index] = human_agent(
                    intermediate_scoring=config.get("human_agent.intermediate_scoring", True),
                    record_session=config.get("human_agent.record_session", False),
                )
                eval_task.solver = chain(solvers)
            elif swe_agent:
                solvers[control_solver_index] = agent_control_solver(
                    micro_protocol=micro_protocol,
                    tools=setting.get_agent_tools,
                    get_submit_tool_config=setting.get_submit_tool_config,
                )
                eval_task.solver = chain(solvers)

        import_path = config.get("import.path")
        import_mode = config.get("import.mode")

        # Allow human agent if we're only scoring, but otherwise remove the control solver
        if import_path and import_mode == "score" and not use_human_agent:
            logger.info(f"Import mode: Using trajectory from {import_path}")
            if control_solver_index is not None:
                solvers.pop(control_solver_index)
            eval_task.solver = chain(solvers)

        eval(
            eval_task,
            **eval_config.eval_args(),
        )

        if hasattr(setting, "cleanup"):
            setting.cleanup()

        logger.info("Evaluation completed")

        return 0

    except KeyboardInterrupt:
        logger.info("Evaluation interrupted by user")
        return 1

    except Exception as e:
        logger.error(f"Evaluation failed: {e}")
        # logger.error(e.with_traceback())
        if config.get("logs.verbose"):
            logger.exception("Full traceback:")
        return 1


def _get_monitors(config: Config) -> list:
    monitors_list = config.get("monitors.list")
    monitors: list = []

    if not monitors_list:
        return []

    if isinstance(monitors_list, str):
        monitor_names = [name.strip() for name in monitors_list.split(",") if name.strip()]
    else:
        monitor_names = to_list(monitors_list)

    for name in monitor_names:
        option_key = f"monitors.options.{name}"
        monitor_config = config.get(option_key)
        if monitor_config is None:
            raise ValueError(
                f"Monitor '{name}' is listed in 'monitors.list' but '{option_key}' is not defined."
            )
        monitors.append(monitor_config)

    return monitors
