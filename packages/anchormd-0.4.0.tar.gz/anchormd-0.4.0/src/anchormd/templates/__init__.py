"""Template system for AnchorMD."""
