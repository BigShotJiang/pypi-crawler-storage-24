import threading
import time
import serial.tools
from WeeLab.interfaces.power_supply import PowerSupply
from WeeLab.connections.base import InstrumentConnection
from WeeLab.connections.serial import SerialConnection

from colorama import Fore, Style

"""Hamamatsu C11204 Power Supply Control Module for SiPM Biasing.
This module provides an interface to control the Hamamatsu C11204 power supply,
allowing for setting voltage, current, and ramp speed, as well as reading
the current and voltage values.
Example usage:
```python
from WeeLab.devices.hamamatsu_c11204 import HPK_C11204
from WeeLab.connections.serial import SerialConnection

hv = HPK_C11204(
    conn=SerialConnection(port="COM3", baudrate=115200))
hv.set_voltage(50)  # Set voltage to 30V
hv.get_IV()  # Get the current and voltage values
"""

class HPK_C11204(PowerSupply):
    def __init__(self, conn: InstrumentConnection, serial_number: str = "0"):
        """
        Initialize the Hamamatsu C11204 power supply.
        :param conn: An instance of InstrumentConnection (e.g., SerialConnection).
        :param serial_number: Serial number of the Hamamatsu C11204 device.
                              If not using InstrumentConnection, this must be provided.

        Example:
        ``` python
        from LabPack.devices.caen_a7585 import CAEN_A7585
        from LabPack.connections.serial import SerialConnection
        caen = CAEN_A7585(
            conn=SerialConnection(port="COM6", baudrate=115200))
        ```
        """
        self.conn = conn
        self.N_RETRY = 3

    ######### Low-Level Communication Methods #########
        
    def write(self, command):
        self.conn.write(command)

    def read_all(self):
        return self.conn.read_all()

    def read(self):
        return self.conn.read()

    def query(self, command):
        return self.conn.query(command)

    def clear_comm(self):
        self.read_all()

    # def get_hv(self):
    #     self.clear_comm()
    #     response = self.query("get_hv")
    #     hv_value = float(response.split()[1])
    #     return hv_value

    def send_command(self, command):
        for attempt in range(self.N_RETRY):
            self.clear_comm()
            self.write(command)
            response = self.read_all()
            if "ERROR" not in response:
                return response
        print(Fore.RED + f"Error in response: {response}" + Style.RESET_ALL)
        return None


    def decode_status(self, status_code):
        status_flags = {
            0: "HV ON",
            1: "Overcurrent protection trip",
            2: "Current value outside specs",
            3: "Temperature sensor connect",
            4: "Temperature sensor outside specs",
            5: "Reserve 1",
            6: "Temperature connection valid",
        }
        active_flags = []
        for bit_position, description in status_flags.items():
            if status_code & (1 << bit_position):
                active_flags.append(description)
        return active_flags

    def parse_poll(self, response):
        if "ERROR" in response:
            print(Fore.RED + "Error in response: " + response + Style.RESET_ALL)
            return {"Error": response}
        
        hv_value = None
        current_value = None
        temperature_value = None
        active_flags = []
        for line in response.splitlines():
            if line.startswith("HV mon"):
                hv_value = float(line.split()[3])
            elif line.startswith("I"):
                current_value = float(line.split()[2])
            elif line.startswith("Temp"):
                temperature_value = float(line.split()[2])
            elif line.startswith("Status"):
                status_code = int(line.split()[2], 16)
                active_flags = self.decode_status(status_code)
        return {
            "HV": hv_value,
            "Current": current_value,
            "Temperature": temperature_value,
            "Status": active_flags,
        }
    
    def poll(self):
        response = self.send_command("hpo")
        parsed_response = self.parse_poll(response)
        return parsed_response
    
    ##### Standard PowerSupply Interface Methods #####
    def get_IV(self):
        response = self.poll()
        if "Error" in response:
            print(Fore.RED + "Error in response: " + response["Error"] + Style.RESET_ALL)
            return None, None
        return response["Current"], response["HV"]
    
    def get_voltage(self):
        return self.get_IV()[1]
    
    def get_current(self):
        return self.get_IV()[0]
    
    def set_voltage(self, voltage: float):
        command = f"set_hv {voltage}"
        response = self.send_command(command)
        if response is not None:
            print("OK HV SET")
        else:
            print(Fore.RED + "Failed to set HV" + Style.RESET_ALL)

    def hv_on(self):
        response = self.send_command("hv_on")
        if response is not None:
            print("OK HV ON")
        else:
            print(Fore.RED + "Failed to turn HV ON" + Style.RESET_ALL)

    def hv_off(self):
        response = self.send_command("hv_off")
        if response is not None:
            print("OK HV OFF")
        else:
            print(Fore.RED + "Failed to turn HV OFF" + Style.RESET_ALL)

    def reset(self):
        response = self.send_command("reset")
        if response is not None:
            print("OK RESET")
        else:
            print(Fore.RED + "Failed to reset device" + Style.RESET_ALL)
    
    def temp_compensation_off(self):
        response = self.send_command("temp_comp_off")
        if response is not None:
            print("OK TEMP COMPENSATION OFF")
        else:
            print(Fore.RED + "Failed to turn off temp compensation" + Style.RESET_ALL)