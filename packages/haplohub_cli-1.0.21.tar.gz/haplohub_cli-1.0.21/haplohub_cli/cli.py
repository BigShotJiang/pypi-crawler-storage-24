import click

from haplohub_cli.commands import algorithm, cohort, config, file, login, metadata, variant, version
from haplohub_cli.config.config import OutputFormat
from haplohub_cli.config.config_manager import config_manager
from haplohub_cli.formatters.formatter_registry import formatter_registry


@click.group()
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice([f.value for f in OutputFormat], case_sensitive=False),
    default=None,
    help="Output format (overrides config setting)",
)
@click.pass_context
def cli(ctx, output_format):
    """
    HaploHub CLI

    To get started, take a look at the documentation:
    https://github.com/haplotypelabs/haplohub-cli
    """
    ctx.ensure_object(dict)
    ctx.obj["output_format"] = output_format


@cli.result_callback()
@click.pass_context
def formatter_callback(ctx, result, **_):
    if result is None:
        return

    output_format = ctx.obj.get("output_format") or config_manager.config.output_format

    if output_format == OutputFormat.json:
        if hasattr(result, "to_json"):
            click.echo(result.to_json())
        else:
            import json

            click.echo(json.dumps(result, default=str))
        return

    if not formatter_registry.has_formatter(type(result)):
        from pprint import pprint

        pprint(result)
        return

    formatter_registry.format(result)


cli.add_command(algorithm.algorithm)
cli.add_command(cohort.cohort)
cli.add_command(config.config)
cli.add_command(file.file)
cli.add_command(login.cmd)
cli.add_command(metadata.metadata)
cli.add_command(version.cmd)
cli.add_command(variant.variant)


if __name__ == "__main__":
    cli()
