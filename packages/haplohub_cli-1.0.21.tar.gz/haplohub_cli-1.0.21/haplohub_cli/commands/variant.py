import click
from haplohub import ClinvarFilterRequest, GetVariantRequest, LookupHgvsRequest, VariantRange

from haplohub_cli.core.api.client import client
from haplohub_cli.types.variant_range import VariantRangeType


@click.group()
def variant():
    """
    Work with variants
    """
    pass


@variant.command()
@click.option("--sample_id", "-s", type=int, required=True)
@click.option("--cohort", "-c", type=str, required=True)
@click.option(
    "--ranges",
    "-r",
    type=VariantRangeType(),
    multiple=True,
    required=True,
    help="Variant ranges to fetch in format <accession>:<start>:<end>",
)
def fetch(sample_id: str, cohort: str, ranges: list[tuple[str, int, int]]):
    request = GetVariantRequest(
        sample_id=sample_id,
        variants=[
            VariantRange(
                accession=accession,
                start=start,
                end=end,
            )
            for accession, start, end in ranges
        ],
    )

    return client.variant.get_variant(cohort, request)


@variant.command()
@click.option("--sample_id", "-s", type=int, required=True)
@click.option("--cohort", "-c", type=str, required=True)
@click.option(
    "--hgvs",
    "-h",
    type=str,
    multiple=True,
    required=True,
    help="HGVS variants to lookup",
)
def lookup_hgvs(sample_id: str, cohort: str, hgvs: list[str]):
    request = LookupHgvsRequest(
        sample_id=sample_id,
        hgvs=hgvs,
    )

    return client.variant.lookup_hgvs(cohort, request)


@variant.command()
@click.option("--sample_id", "-s", type=str, required=True)
@click.option("--cohort", "-c", type=str, required=True)
@click.option(
    "--gene",
    "-g",
    type=str,
    multiple=True,
    required=True,
    help="Gene symbols to filter by",
)
@click.option(
    "--significance",
    type=str,
    multiple=True,
    default=["Pathogenic", "Likely_pathogenic"],
    help="Clinical significance values to filter by (default: Pathogenic, Likely_pathogenic)",
)
@click.option(
    "--include_uncalled",
    is_flag=True,
    default=False,
    help="Include uncalled variants",
)
def filter_clinvar(
    sample_id: str,
    cohort: str,
    gene: list[str],
    significance: list[str],
    include_uncalled: bool,
):
    request = ClinvarFilterRequest(
        sample_id=sample_id,
        gene_symbols=list(gene),
        clinical_significance=list(significance),
        include_uncalled=include_uncalled,
    )

    return client.variant.filter_clinvar(cohort, request)
