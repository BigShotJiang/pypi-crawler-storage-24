# fastapi-easy-setup

CLI tool that scaffolds a production-ready **FastAPI** project in seconds, powered by [uv](https://docs.astral.sh/uv/).

## What you get

```
myapp/
├── pyproject.toml
├── uv.lock
├── .env / .env.example
├── .gitignore
├── alembic.ini              # only with Alembic (default)
├── alembic/
│   ├── env.py               # async, reads DATABASE_URL from Settings
│   ├── script.py.mako
│   └── versions/
├── app/
│   ├── main.py              # create_app() factory, lifespan, CORS
│   ├── core/
│   │   ├── config.py        # pydantic-settings — .env auto-loaded
│   │   └── database.py      # async engine + session + get_db dependency
│   ├── models/
│   │   └── base.py          # DeclarativeBase + UUID / Timestamp mixins
│   ├── schemas/
│   ├── api/
│   │   ├── deps.py          # DBSession annotated dependency
│   │   └── v1/
│   │       ├── router.py    # /health endpoint
│   │       └── endpoints/
│   ├── services/
│   └── utils/
└── tests/
    ├── conftest.py           # async httpx test client
    └── test_health.py
```

## Prerequisites

- [uv](https://docs.astral.sh/uv/) (any recent version)
- Python 3.12+ (managed by uv automatically)

## Quick start

### Run directly (no install)

```bash
uvx --from /path/to/this/folder fastapi-easy-setup myapp
```

If the tool is installed, you can run:

```bash
uvx fastapi-easy-setup myapp
```

### Interactive mode

Omit the project name and the tool will prompt you:

```bash
fastapi-easy-setup
# Project name: _
```

## Options

```
fastapi-easy-setup [project_name] [OPTIONS]

positional arguments:
  project_name          Name of the project directory (prompted if omitted)

options:
  --python VERSION      Python version for uv init (default: 3.12)
  --no-alembic          Skip Alembic initialization
  --version             Show version and exit
  -h, --help            Show help and exit
```

### Examples

```bash
# Default: FastAPI + Alembic + Python 3.12
fastapi-easy-setup myapp

# Skip Alembic
fastapi-easy-setup myapp --no-alembic

# Use Python 3.11
fastapi-easy-setup myapp --python 3.11
```

## After scaffolding

```bash
cd myapp

# Run the dev server
uv run uvicorn app.main:app --reload

# Generate a migration (if Alembic was included)
uv run alembic revision --autogenerate -m "initial"

# Apply migrations
uv run alembic upgrade head

# Run tests
uv run pytest
```

## License

MIT
