#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""fastapi-easy-setup — scaffold a production-ready FastAPI project using uv."""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

__version__ = "0.1.1"

# ── Validation ────────────────────────────────────────────────────────────────

_VALID_NAME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_-]*$")


def validate_project_name(name: str) -> str:
    """Return *name* unchanged or raise with a human-friendly message."""
    if not name:
        _die("project name cannot be empty.")
    if not _VALID_NAME_RE.match(name):
        _die(
            f"invalid project name '{name}'. "
            "Use only letters, digits, hyphens, or underscores, "
            "and start with a letter."
        )
    if name in (".", ".."):
        _die("project name cannot be '.' or '..'.")
    return name


def validate_python_version(version: str) -> str:
    if not re.match(r"^\d+\.\d+(\.\d+)?$", version):
        _die(f"invalid Python version '{version}'. Expected format: 3.12 or 3.12.0")
    return version


# ── Helpers ───────────────────────────────────────────────────────────────────

def _die(msg: str) -> None:
    print(f"Error: {msg}", file=sys.stderr)
    raise SystemExit(1)


def _run(cmd: list[str], *, cwd: Path | None = None) -> None:
    result = subprocess.run(cmd, cwd=cwd, check=False)
    if result.returncode != 0:
        _die(f"command failed (exit {result.returncode}): {' '.join(cmd)}")


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _append(path: Path, content: str) -> None:
    with path.open("a", encoding="utf-8") as f:
        f.write(content)


def _touch(project_dir: Path, *relative_paths: str) -> None:
    for rel in relative_paths:
        _write(project_dir / rel, "")


# ── Templates ─────────────────────────────────────────────────────────────────

TEMPLATE_CONFIG = """\
from functools import lru_cache

from pydantic import PostgresDsn
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    APP_NAME: str = "FastAPI App"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = False
    API_V1_PREFIX: str = "/api/v1"

    DATABASE_URL: PostgresDsn = "postgresql+asyncpg://postgres:postgres@localhost:5432/app"  # type: ignore[assignment]

    SECRET_KEY: str = "change-me-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

    CORS_ORIGINS: list[str] = ["*"]


@lru_cache
def get_settings() -> Settings:
    return Settings()
"""

TEMPLATE_DATABASE = """\
from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import get_settings

settings = get_settings()

engine = create_async_engine(
    str(settings.DATABASE_URL),
    echo=settings.DEBUG,
    pool_pre_ping=True,
)

async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
"""

TEMPLATE_MODELS_BASE = """\
import uuid
from datetime import datetime

from sqlalchemy import DateTime, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class UUIDMixin:
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )
"""

TEMPLATE_DEPS = """\
from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

DBSession = Annotated[AsyncSession, Depends(get_db)]
"""

TEMPLATE_ROUTER = """\
from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health_check():
    return {"status": "ok"}
"""

TEMPLATE_MAIN = """\
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1.router import router as v1_router
from app.core.config import get_settings

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        debug=settings.DEBUG,
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(v1_router, prefix=settings.API_V1_PREFIX)

    return app


app = create_app()
"""

TEMPLATE_ENV = """\
APP_NAME="FastAPI App"
APP_VERSION="0.1.0"
DEBUG=true

DATABASE_URL="postgresql+asyncpg://postgres:postgres@localhost:5432/app"

SECRET_KEY="change-me-in-production"
ACCESS_TOKEN_EXPIRE_MINUTES=1440

CORS_ORIGINS=["*"]
"""

TEMPLATE_ENV_EXAMPLE = """\
APP_NAME=
APP_VERSION=
DEBUG=

DATABASE_URL=

SECRET_KEY=
ACCESS_TOKEN_EXPIRE_MINUTES=

CORS_ORIGINS=
"""

TEMPLATE_GITIGNORE_EXTRA = """
# env
.env
!.env.example

# IDE
.vscode/
.idea/

# Python
__pycache__/
*.pyc
.pytest_cache/
.ruff_cache/

# venv (uv)
.venv/
"""

TEMPLATE_CONFTEST = """\
import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app


@pytest.fixture
async def client():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac
"""

TEMPLATE_TEST_HEALTH = """\
import pytest


@pytest.mark.asyncio
async def test_health(client):
    resp = await client.get("/api/v1/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
"""

TEMPLATE_ALEMBIC_ENV = """\
import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config

from app.core.config import get_settings
from app.models.base import Base

# Import all models here so Alembic can detect them.
# e.g.: from app.models.user import User  # noqa: F401

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

settings = get_settings()
config.set_main_option("sqlalchemy.url", str(settings.DATABASE_URL))

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata)

    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
"""


# ── Scaffold ──────────────────────────────────────────────────────────────────

def scaffold(project_dir: Path, *, python_version: str, with_alembic: bool) -> None:
    _run(["uv", "init", "--python", python_version, project_dir.name], cwd=project_dir.parent)

    deps = [
        "fastapi[standard]",
        "uvicorn[standard]",
        "sqlalchemy",
        "pydantic-settings",
        "asyncpg",
        "python-dotenv",
    ]
    if with_alembic:
        deps.append("alembic")

    _run(["uv", "add", *deps], cwd=project_dir)
    _run(["uv", "add", "--dev", "pytest", "pytest-asyncio", "httpx", "ruff"], cwd=project_dir)

    for folder in (
        "app/core",
        "app/models",
        "app/schemas",
        "app/api/v1/endpoints",
        "app/services",
        "app/utils",
        "tests",
    ):
        (project_dir / folder).mkdir(parents=True, exist_ok=True)

    _touch(
        project_dir,
        "app/__init__.py",
        "app/core/__init__.py",
        "app/models/__init__.py",
        "app/schemas/__init__.py",
        "app/api/__init__.py",
        "app/api/v1/__init__.py",
        "app/api/v1/endpoints/__init__.py",
        "app/services/__init__.py",
        "app/utils/__init__.py",
        "tests/__init__.py",
    )

    _write(project_dir / "app/core/config.py", TEMPLATE_CONFIG)
    _write(project_dir / "app/core/database.py", TEMPLATE_DATABASE)
    _write(project_dir / "app/models/base.py", TEMPLATE_MODELS_BASE)
    _write(project_dir / "app/api/deps.py", TEMPLATE_DEPS)
    _write(project_dir / "app/api/v1/router.py", TEMPLATE_ROUTER)
    _write(project_dir / "app/main.py", TEMPLATE_MAIN)
    _write(project_dir / ".env", TEMPLATE_ENV)
    _write(project_dir / ".env.example", TEMPLATE_ENV_EXAMPLE)
    _append(project_dir / ".gitignore", TEMPLATE_GITIGNORE_EXTRA)
    _write(project_dir / "tests/conftest.py", TEMPLATE_CONFTEST)
    _write(project_dir / "tests/test_health.py", TEMPLATE_TEST_HEALTH)

    if with_alembic:
        _run(["uv", "run", "alembic", "init", "-t", "async", "alembic"], cwd=project_dir)
        _write(project_dir / "alembic/env.py", TEMPLATE_ALEMBIC_ENV)

    for leftover in ("hello.py", "main.py"):
        candidate = project_dir / leftover
        if candidate.exists():
            candidate.unlink()


# ── CLI ───────────────────────────────────────────────────────────────────────

def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="fastapi-easy-setup",
        description="Scaffold a production-ready FastAPI project using uv.",
    )
    parser.add_argument(
        "project_name",
        nargs="?",
        help="Name of the project directory to create (prompted if omitted)",
    )
    parser.add_argument(
        "--python",
        default="3.12",
        help="Python version for uv init (default: 3.12)",
    )
    parser.add_argument(
        "--no-alembic",
        action="store_true",
        default=False,
        help="Skip Alembic initialization",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    if shutil.which("uv") is None:
        _die("uv is not installed. https://docs.astral.sh/uv/")

    args = parse_args(argv)

    project_name = args.project_name
    if not project_name:
        try:
            project_name = input("Project name: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            raise SystemExit(130)

    project_name = validate_project_name(project_name)
    python_version = validate_python_version(args.python)
    with_alembic: bool = not args.no_alembic

    project_dir = Path.cwd() / project_name

    if project_dir.exists():
        _die(f"directory '{project_name}' already exists.")

    try:
        scaffold(project_dir, python_version=python_version, with_alembic=with_alembic)
    except SystemExit:
        if project_dir.exists():
            shutil.rmtree(project_dir)
            print(f"Cleaned up partial directory '{project_name}'.", file=sys.stderr)
        raise

    print(f"\nProject '{project_name}' is ready.\n")
    print(f"  cd {project_name}")
    print("  uv run uvicorn app.main:app --reload")
    if with_alembic:
        print('  uv run alembic revision --autogenerate -m "initial"')
        print("  uv run alembic upgrade head")
    print("  uv run pytest")


if __name__ == "__main__":
    main()
