"""Tests for fastapi-easy-setup CLI (unit-level, no subprocess calls)."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from create_fastapi_project import (
    __version__,
    main,
    parse_args,
    scaffold,
    validate_project_name,
    validate_python_version,
)


# ── validate_project_name ─────────────────────────────────────────────────────


class TestValidateProjectName:
    def test_valid_simple(self):
        assert validate_project_name("myapp") == "myapp"

    def test_valid_with_hyphens(self):
        assert validate_project_name("my-app") == "my-app"

    def test_valid_with_underscores(self):
        assert validate_project_name("my_app") == "my_app"

    def test_valid_with_digits(self):
        assert validate_project_name("app2") == "app2"

    def test_rejects_empty(self):
        with pytest.raises(SystemExit):
            validate_project_name("")

    def test_rejects_dot(self):
        with pytest.raises(SystemExit):
            validate_project_name(".")

    def test_rejects_dotdot(self):
        with pytest.raises(SystemExit):
            validate_project_name("..")

    def test_rejects_path_traversal(self):
        with pytest.raises(SystemExit):
            validate_project_name("../etc")

    def test_rejects_slash(self):
        with pytest.raises(SystemExit):
            validate_project_name("foo/bar")

    def test_rejects_starts_with_digit(self):
        with pytest.raises(SystemExit):
            validate_project_name("2fast")

    def test_rejects_spaces(self):
        with pytest.raises(SystemExit):
            validate_project_name("my app")

    def test_rejects_special_chars(self):
        with pytest.raises(SystemExit):
            validate_project_name("my@app")


# ── validate_python_version ───────────────────────────────────────────────────


class TestValidatePythonVersion:
    def test_valid_minor(self):
        assert validate_python_version("3.12") == "3.12"

    def test_valid_patch(self):
        assert validate_python_version("3.12.1") == "3.12.1"

    def test_rejects_major_only(self):
        with pytest.raises(SystemExit):
            validate_python_version("3")

    def test_rejects_garbage(self):
        with pytest.raises(SystemExit):
            validate_python_version("abc")


# ── parse_args ────────────────────────────────────────────────────────────────


class TestParseArgs:
    def test_positional_name(self):
        args = parse_args(["myapp"])
        assert args.project_name == "myapp"
        assert args.python == "3.12"
        assert args.no_alembic is False

    def test_no_name(self):
        args = parse_args([])
        assert args.project_name is None

    def test_custom_python(self):
        args = parse_args(["myapp", "--python", "3.11"])
        assert args.python == "3.11"

    def test_no_alembic_flag(self):
        args = parse_args(["myapp", "--no-alembic"])
        assert args.no_alembic is True

    def test_version_flag(self, capsys):
        with pytest.raises(SystemExit, match="0"):
            parse_args(["--version"])
        assert __version__ in capsys.readouterr().out


# ── main (integration, mocked subprocess) ─────────────────────────────────────


def _fake_run(cmd, *, cwd=None, check=False):
    """Stub subprocess.run so we never actually call uv."""
    return subprocess.CompletedProcess(cmd, returncode=0)


class TestMainIntegration:
    def test_creates_project_structure(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        with patch("create_fastapi_project.subprocess.run", side_effect=_fake_run):
            main(["testproj"])

        root = tmp_path / "testproj"
        assert root.is_dir()

        expected_files = [
            "app/__init__.py",
            "app/main.py",
            "app/core/__init__.py",
            "app/core/config.py",
            "app/core/database.py",
            "app/models/__init__.py",
            "app/models/base.py",
            "app/schemas/__init__.py",
            "app/api/__init__.py",
            "app/api/deps.py",
            "app/api/v1/__init__.py",
            "app/api/v1/router.py",
            "app/api/v1/endpoints/__init__.py",
            "app/services/__init__.py",
            "app/utils/__init__.py",
            "tests/__init__.py",
            "tests/conftest.py",
            "tests/test_health.py",
            ".env",
            ".env.example",
            "alembic/env.py",
        ]
        for f in expected_files:
            assert (root / f).exists(), f"missing: {f}"

    def test_no_alembic_skips_alembic_dir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        with patch("create_fastapi_project.subprocess.run", side_effect=_fake_run):
            main(["testproj", "--no-alembic"])

        root = tmp_path / "testproj"
        assert root.is_dir()
        assert not (root / "alembic").exists()
        assert (root / "app/main.py").exists()

    def test_env_example_has_no_secrets(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        with patch("create_fastapi_project.subprocess.run", side_effect=_fake_run):
            main(["testproj"])

        env_example = (tmp_path / "testproj" / ".env.example").read_text()
        assert "change-me" not in env_example
        assert "postgres:postgres" not in env_example

    def test_removes_uv_default_entrypoints(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        def fake_run_with_leftovers(cmd, *, cwd=None, check=False):
            if cmd[0] == "uv" and cmd[1] == "init":
                d = Path(cwd) / cmd[-1]
                d.mkdir(parents=True, exist_ok=True)
                (d / "main.py").write_text("print('hello')")
                (d / "hello.py").write_text("print('hello')")
            return subprocess.CompletedProcess(cmd, returncode=0)

        with patch("create_fastapi_project.subprocess.run", side_effect=fake_run_with_leftovers):
            main(["testproj"])

        root = tmp_path / "testproj"
        assert not (root / "main.py").exists()
        assert not (root / "hello.py").exists()
        assert (root / "app/main.py").exists()

    def test_rejects_existing_directory(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "existing").mkdir()

        with pytest.raises(SystemExit):
            main(["existing"])

    def test_rejects_invalid_name(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        with pytest.raises(SystemExit):
            main(["../sneaky"])

    def test_cleanup_on_failure(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        call_count = 0

        def fail_on_second(cmd, *, cwd=None, check=False):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                return subprocess.CompletedProcess(cmd, returncode=1)
            return subprocess.CompletedProcess(cmd, returncode=0)

        with (
            patch("create_fastapi_project.subprocess.run", side_effect=fail_on_second),
            pytest.raises(SystemExit),
        ):
            main(["failproj"])

        assert not (tmp_path / "failproj").exists(), "partial directory should be cleaned up"

    def test_interactive_prompt(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        with (
            patch("create_fastapi_project.subprocess.run", side_effect=_fake_run),
            patch("builtins.input", return_value="prompted"),
        ):
            main([])

        assert (tmp_path / "prompted" / "app/main.py").exists()

    def test_interactive_prompt_ctrl_c(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        with (
            patch("builtins.input", side_effect=KeyboardInterrupt),
            pytest.raises(SystemExit, match="130"),
        ):
            main([])
