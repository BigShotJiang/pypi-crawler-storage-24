import glob
import os
import shutil
import subprocess
import sys
import tempfile

from .obfuscate import obfuscate_source

_SUPPORTED_CYTHON_MAJOR = 3


def _strip_binary(path):
    """strip 符号表，失败静默"""
    try:
        if sys.platform.startswith('win'):
            return
        cmd = ['strip', '-x' if sys.platform == 'darwin' else '--strip-all', path]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def _get_cython_major_version():
    """返回当前运行环境的 Cython 主版本号。"""
    try:
        import Cython
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError('编译 Python 源码需要先安装 Cython。') from exc

    version = getattr(Cython, '__version__', '0')
    major = str(version).split('.', 1)[0]
    try:
        return int(major)
    except ValueError as exc:  # pragma: no cover
        raise RuntimeError(f'无法解析 Cython 版本: {version}') from exc


def _ensure_supported_cython():
    """阻断已知会破坏运行时注解的旧版 Cython。"""
    major = _get_cython_major_version()
    if major != _SUPPORTED_CYTHON_MAJOR:
        raise RuntimeError(
            '检测到不受支持的 Cython 版本。'
            'AutoCython 要求 Cython>=3,<4；'
            '因为 Cython<3 可能剥离编译产物中的运行时注解，'
            '导致 Pydantic/FastAPI/dataclass 的字段发现失效。'
        )


def get_platform_extension() -> str:
    """返回当前平台的扩展名"""
    if sys.platform.startswith('win'):
        return '.pyd'
    return '.so'


def _infer_compile_root(abs_file_path: str) -> str:
    """推导编译根目录。

    对包内模块，返回最外层 package 目录的父目录，以便保留完整 qualified module name。
    对普通脚本，返回源码所在目录，保持现有行为。
    """
    source_dir = os.path.dirname(abs_file_path)
    current_dir = source_dir
    top_level_package_dir = None

    while os.path.isfile(os.path.join(current_dir, '__init__.py')):
        top_level_package_dir = current_dir
        parent_dir = os.path.dirname(current_dir)
        if parent_dir == current_dir:
            break
        current_dir = parent_dir

    if top_level_package_dir is None:
        return source_dir

    return os.path.dirname(top_level_package_dir)


def _resolve_module_layout(abs_file_path: str):
    """解析编译布局，保留 package 相对路径与 qualified module name。"""
    compile_root = _infer_compile_root(abs_file_path)
    rel_path = os.path.relpath(abs_file_path, compile_root)
    rel_dir = os.path.dirname(rel_path)
    file_name = os.path.basename(rel_path)
    module_name, ext = os.path.splitext(file_name)
    safe_module_name = module_name.replace('-', '_')

    safe_rel_parts = [part for part in rel_dir.split(os.sep) if part and part != '.']
    safe_rel_parts.append(safe_module_name + ext)
    safe_rel_path = os.path.join(*safe_rel_parts) if safe_rel_parts else safe_module_name + ext

    module_parts = [part for part in rel_dir.split(os.sep) if part and part != '.']
    module_parts.append(safe_module_name)
    qualified_module_name = '.'.join(module_parts)

    return {
        'compile_root': compile_root,
        'rel_path': rel_path,
        'safe_rel_path': safe_rel_path,
        'safe_module_name': safe_module_name,
        'qualified_module_name': qualified_module_name,
    }


def _copy_package_inits(abs_file_path: str, compile_root: str, temp_dir: str) -> None:
    """复制包链上的 __init__.py，确保 build_ext --inplace 输出落到正确包路径。"""
    current_dir = os.path.dirname(abs_file_path)

    while True:
        init_path = os.path.join(current_dir, '__init__.py')
        if not os.path.isfile(init_path):
            break

        rel_init_path = os.path.relpath(init_path, compile_root)
        temp_init_path = os.path.join(temp_dir, rel_init_path)
        os.makedirs(os.path.dirname(temp_init_path), exist_ok=True)
        shutil.copy2(init_path, temp_init_path)

        if current_dir == compile_root:
            break

        parent_dir = os.path.dirname(current_dir)
        if parent_dir == current_dir:
            break
        current_dir = parent_dir


def compile_to_binary(file_path: str, del_source=False, obfuscate=True, obfuscate_seed=None):
    """
    将指定的 Python 文件（.py）通过 Cython 编译为二进制扩展文件

    :param file_path: Python 文件路径（可以是相对路径或绝对路径）
    :param del_source: 是否删除源代码
    :param obfuscate: 是否在编译前混淆源码（默认True）
    :param obfuscate_seed: 混淆随机种子（None 表示不固定）
    :return: 生成的二进制文件路径（与输入保持相同的路径类型）
    """
    _ensure_supported_cython()

    is_absolute = os.path.isabs(file_path)
    abs_file_path = os.path.abspath(file_path)

    if not os.path.isfile(abs_file_path):
        raise FileNotFoundError(f"FileNotFoundError: {file_path}.")

    file_name = os.path.basename(abs_file_path)
    _, ext = os.path.splitext(file_name)
    source_dir = os.path.dirname(abs_file_path)

    if ext != '.py':
        raise ValueError(f"ValueError: The file {file_path} is not a valid Python file (.py)!")

    module_layout = _resolve_module_layout(abs_file_path)
    safe_module_name = module_layout['safe_module_name']
    target_ext = get_platform_extension()
    temp_dir = tempfile.mkdtemp()

    try:
        temp_file_path = os.path.join(temp_dir, module_layout['safe_rel_path'])
        os.makedirs(os.path.dirname(temp_file_path), exist_ok=True)
        _copy_package_inits(abs_file_path, module_layout['compile_root'], temp_dir)
        shutil.copy2(abs_file_path, temp_file_path)

        if obfuscate:
            try:
                with open(temp_file_path, 'r', encoding='utf-8') as f:
                    original_source = f.read()
                obfuscated = obfuscate_source(original_source, seed=obfuscate_seed)
                with open(temp_file_path, 'w', encoding='utf-8') as f:
                    f.write(obfuscated)
            except Exception as exc:
                raise RuntimeError(f"Obfuscation failed for {file_path}: {exc}") from exc

        setup_code = f"""
from setuptools import setup
from setuptools import Extension
from Cython.Build import cythonize

compiler_directives = {{
    'language_level': '3',
    'annotation_typing': False,
    'always_allow_keywords': True,
    'binding': True,
    'embedsignature': False,
    'wraparound': False,
}}

setup(
    ext_modules=cythonize(
        [
            Extension(
                {repr(module_layout['qualified_module_name'])},
                [{repr(module_layout['safe_rel_path'])}],
            )
        ],
        compiler_directives=compiler_directives,
        force=True
    )
)
"""
        setup_path = os.path.join(temp_dir, 'setup.py')
        with open(setup_path, 'w', encoding='utf-8') as f:
            f.write(setup_code)

        command = [sys.executable, 'setup.py', 'build_ext', '--inplace']
        try:
            result = subprocess.run(
                command,
                cwd=temp_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=300,
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Compilation timed out after 300s: {file_path}")

        if result.returncode != 0:
            error_msg = result.stderr.decode('utf-8', errors='replace')
            raise RuntimeError(f"Compilation failed: {error_msg}")

        temp_output_dir = os.path.dirname(temp_file_path) or temp_dir
        pattern = os.path.join(temp_output_dir, f"{safe_module_name}*{target_ext}")
        matches = glob.glob(pattern)
        if not matches:
            pattern = os.path.join(temp_output_dir, f"*{safe_module_name}*{target_ext}")
            matches = glob.glob(pattern)

        if not matches:
            raise FileNotFoundError(
                f"FileNotFoundError: The file {file_path} is not a valid Python file (.py)! "
                f"Generated file {target_ext} not found, in {temp_dir} possible file: {os.listdir(temp_dir)}"
            )

        generated_file = max(matches, key=os.path.getmtime)
        output_dir = source_dir if is_absolute else (os.path.dirname(file_path) or '.')
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

        output_file_name = os.path.basename(generated_file)
        output_path = os.path.join(output_dir, output_file_name)
        if os.path.exists(output_path):
            os.remove(output_path)
        shutil.move(generated_file, output_path)

        _strip_binary(output_path)

        if del_source:
            os.remove(file_path)

        return output_path
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == '__main__':  # pragma: no cover
    target_file = 'test/example.py'
    try:
        output_file = compile_to_binary(target_file)
        print(output_file)
    except Exception as e:
        print(e)
