from SpectrumCommon.Modvars.GB.GBUtil import get_country_ISO3Alpha
from SpectrumCommon.Modvars.GB.GBDefs import createProjectionParams
from AvenirCommon.Util import findTagRow

from SpectrumCommon.Const.GB import *

def openPJN(file):
    importVersionNum = '6.2'
    importBetaNum = '4'
    params = createProjectionParams()
    import pandas as pd
    sheet = pd.read_csv(file, header=None, na_filter=False)
    
    projectionVersionRow = findTagRow(sheet, '<Projection Version Details>')
    versionNum = sheet.values[projectionVersionRow + 2, GB_RW_DataStartCol]
    betaNum = sheet.values[projectionVersionRow + 4, GB_RW_DataStartCol]
    
    # if (importVersionNum != versionNum) or (importBetaNum != betaNum):
    #     raise Exception('PJNZ file has not been created with the correct version of Spectrum Desktop, Version' + importVersionNum + ', Beta ' + importBetaNum)

    projNameRow = findTagRow(sheet, '<Projection Name>')
    params.fileName = sheet.values[projNameRow + 2, GB_RW_DataStartCol]

    projYrDtlsRow = findTagRow(sheet, '<Projection Year Details>')
    # params.firstYear = sheet.values[projYrDtlsRow + 2, valueCol]
    params.finalYear = int(sheet.values[projYrDtlsRow + 4, GB_RW_DataStartCol])
    params.firstYear = int(sheet.values[projYrDtlsRow + 6, GB_RW_DataStartCol])

    projParamsRow = findTagRow(sheet, '<Projection Parameters>')
    params.country = get_country_ISO3Alpha(int(sheet.values[projParamsRow + 2, GB_RW_DataStartCol]))
    
    projParamsSubnatRow = findTagRow(sheet, '<Projection Parameters - Subnational Region Name2>')
    params.extra[GB_Extra_subnatName] = sheet.values[projParamsSubnatRow + 2, GB_RW_DataStartCol]
    params.extra[GB_Extra_SubnatCode] = int(sheet.values[projParamsSubnatRow + 3, GB_RW_DataStartCol])

    

    projModulesRow = findTagRow(sheet, '<Projection Modules>')
    modules = []
    modulesRow = projModulesRow + 2
    while sheet.values[modulesRow, GB_RW_DataStartCol] != '':
        modules.append(int(sheet.values[modulesRow, GB_RW_DataStartCol]))
        modulesRow += 1
    params.modules = modules

    # params.extra['region'] = 4

    return params