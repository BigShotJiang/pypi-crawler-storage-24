import asyncio
import sys

from dotenv import load_dotenv
from os import environ as env

from AvenirCommon.Keys import store_keys_in_env
store_keys_in_env()

from loguru import logger
from AvenirCommon.Logger import initialise_logger, set_pt_log_level

load_dotenv()
tool_name = sys.argv[1] if len(sys.argv)>1 else "NoName"
initialise_logger(
            program=f'{tool_name} worker',
            env=env.get("AVENIR_SW_MODE", "beta")
        )

if env.get("AVENIR_SW_MODE", "beta")=="beta":
    set_pt_log_level('DEBUG')
                    #     program=f'{tool_name} worker',
                    #     env=env.get("AVENIR_SW_MODE", "beta")
                    # )


# Tool imports
from Tools.taskUtil import run_task
from Tools.ToolsSwitch import tool_fn_switch


POLLING_INTERVAL_SECONDS = 5

if __name__ == "__main__":
    if tool_name!="NoName":
        asyncio.run(run_task(tool_fn_switch(tool_name), tool_name))
    else:
        logger.error('No tool parameter passed')
