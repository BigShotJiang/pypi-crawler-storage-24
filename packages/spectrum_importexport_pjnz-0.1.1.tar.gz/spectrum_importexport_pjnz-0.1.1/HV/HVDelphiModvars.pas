

//==============================================================================
//                               General
//==============================================================================

{$REGION 'HV_MV_TFirstYear'}
  constructor HV_MV_TFirstYear.Create(aOwner : GB_TXXData; firstYear : integer);
  begin
    inherited Create(aOwner);

    tag := HV_TG_FirstYear_MV;
    stringID := GB_stFirstYear;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];

    InitData(firstYear);
  end;

  procedure HV_MV_TFirstYear.InitData(firstYear : integer);
  begin
    value := firstYear;
  end;

  procedure HV_MV_TFirstYear.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TFirstYear.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TFinalYear'}
  constructor HV_MV_TFinalYear.Create(aOwner : GB_TXXData; finalYear : integer);
  begin
    inherited Create(aOwner);

    tag := HV_TG_FinalYear_MV;
    stringID := GB_stFinalYear;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];

    InitData(finalYear);
  end;

  procedure HV_MV_TFinalYear.InitData(finalYear : integer);
  begin
    value := finalYear;
  end;

  procedure HV_MV_TFinalYear.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TFinalYear.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TFinalIndex'}
  constructor HV_MV_TFinalIndex.Create(aOwner : GB_TXXData; finalIdx : integer);
  begin
    inherited Create(aOwner);

    tag := HV_TG_FinalIndex_MV;
    stringID := GB_stFinalIndex;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];

    InitData(finalIdx);
  end;

  procedure HV_MV_TFinalIndex.InitData(finalIdx : integer);
  begin
    value := finalIdx;
  end;

  procedure HV_MV_TFinalIndex.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TFinalIndex.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TDataChanged'}
  constructor HV_MV_TDataChanged.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_DataChanged_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];

    InitData;
  end;

  procedure HV_MV_TDataChanged.InitData;
  begin
    value := False;
  end;

  procedure HV_MV_TDataChanged.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := boolean(sheet.ints[GB_RW_DataStartCol, currRow]);
    Inc(currRow);
  end;

  procedure HV_MV_TDataChanged.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := byte(value);
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TProjectionValid'}
  constructor HV_MV_TProjectionValid.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_ProjectionValid_MV;
    stringID := GB_stProjValid;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];

    InitData;
  end;

  procedure HV_MV_TProjectionValid.InitData;
  begin
    value := False;
  end;

  procedure HV_MV_TProjectionValid.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := boolean(sheet.ints[GB_RW_DataStartCol, currRow]);
    Inc(currRow);
  end;

  procedure HV_MV_TProjectionValid.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := byte(value);
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TProjectionValidDate'}
  constructor HV_MV_TProjectionValidDate.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_ProjectionValidDate_MV;
    stringID := GB_stProjectionValidDate;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];

    InitData;
  end;

  procedure HV_MV_TProjectionValidDate.InitData;
  begin
     //
  end;

  procedure HV_MV_TProjectionValidDate.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := sheet.cells[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TProjectionValidDate.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.cells[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TFileName'}
  constructor HV_MV_TFileName.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_FileName_MV;
    stringID := GB_stFileName;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable];

    InitData;
  end;

  procedure HV_MV_TFileName.InitData;
  begin
    //
  end;

{$ENDREGION}

{$REGION 'HV_MV_TBehavior}
  constructor HV_MV_TBehavior.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := HV_TG_Behavior_MV;
    stringID    := HV_stBehavior;
    FlagSet     := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TBehavior.InitData;
  var
    i   : byte;
  begin
    for i := HV_AllRisk to HV_MSM_F3 do
    begin
      value[i,HV_PercPop] := 0.0;
      value[i,HV_AvgDur] := 1000;
    end;

  (* Set not sexually active for males and females to 100, as default *)
  value[HV_None,HV_PercPop] := 100.0;
  value[HV_None_F3,HV_PercPop] := 100.0;

  value[HV_HRH_F3,HV_AvgDur] := 5;
  end;

  procedure HV_MV_TBehavior.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s,i : byte;
  begin
    Inc(currRow);
    Inc(currRow); //pass males
    for i := HV_None to HV_MSMIDU do

    begin
      Inc(currRow);
      for s := HV_PercPop to HV_AvgDur do
      begin
        value[i, s] := sheet.floats[GB_RW_DataStartCol + s - 1, currRow];
      end;
      Inc(currRow);
    end;
    Inc(currRow);
    for i := HV_None_F3 to HV_IDU_F3 do
    begin
      Inc(currRow);
      for s := HV_PercPop to HV_AvgDur do
      begin
          value[i, s] := sheet.floats[GB_RW_DataStartCol + s - 1, currRow];
      end;
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TBehavior.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, s  : byte;
  begin
    Inc(currRow);
    sheet.cells[GB_RW_DescriptCol, currRow] := RS(HV_stMales);
    Inc(currRow);
    for i := HV_None to HV_MSMIDU do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_BehaviorVarName(i);
      Inc(currRow);
      for s := HV_PercPop to HV_AvgDur do
      begin
        sheet.floats[GB_RW_DataStartCol + s - 1, currRow] := value[i, s];
      end;
      Inc(currRow);
    end;
    sheet.cells[GB_RW_DescriptCol, currRow] := RS(HV_stFemales);
    Inc(currRow);
    for i := HV_None_F3 to HV_IDU_F3 do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_BehaviorVarName(i);
      Inc(currRow);
      for s := HV_PercPop to HV_AvgDur do
      begin
        sheet.floats[GB_RW_DataStartCol + s - 1, currRow] := value[i, s];
      end;
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TBehavior.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_MSM_F3 + 1, HV_AvgDur +1 );
  end;

{$ENDREGION}

{$REGION 'HV_MV_TAgeFirstSex'}
  constructor HV_MV_TAgeFirstSex.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_AgeFirstSex_MV;
    stringID := HV_stAgeFirstSex;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TAgeFirstSex.InitData;
  var
    s, t : byte;
  begin
    for s := HV_Male to HV_Female do
    begin
      for t := HV_min_year to length(value[s]) - 1 do
        value[s,t] := 0.0;
    end;
  end;

  procedure HV_MV_TAgeFirstSex.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    Inc(currRow);
    Inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[HV_Male, t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[HV_Male, t] := sheet.floats[c - 1, currRow];
    Inc(currRow);

    Inc(currRow);//pass females
    c := c1;
    for t := t1 to t2 do
    begin
      value[HV_Female, t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[HV_Female, t] := sheet.floats[c - 1, currRow];
  end;

  procedure HV_MV_TAgeFirstSex.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    Inc(currRow);
    sheet.cells[GB_RW_DescriptCol, currRow] := RS(HV_stMales);
    Inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[HV_Male, t];
    Inc(currRow);

    sheet.cells[GB_RW_DescriptCol, currRow] := RS(HV_stFemales);
    Inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[HV_Female, t];
    Inc(currRow);
  end;

  procedure HV_MV_TAgeFirstSex.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Adults_P + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Adults_P do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TForceInf'}
  constructor HV_MV_TForceInf.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_ForceInf_MV;
    stringID := HV_stForceInfect;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TForceInf.InitData;
  var
    s, t  : byte;
  begin
    for s := HV_Male to HV_Female do
      for t := HV_min_year to length(value[s]) -1 do
        value[s,t] := 0.0;
  end;

  procedure HV_MV_TForceInf.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    Inc(currRow);
    Inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[HV_Male, t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[HV_Male, t] := sheet.floats[c - 1, currRow];
    Inc(currRow);

    Inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[HV_Female, t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[HV_Female, t] := sheet.floats[c - 1, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TForceInf.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    Inc(currRow);
    sheet.cells[GB_RW_DescriptCol, currRow] := RS(HV_stMales);
    Inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[HV_Male, t];
    end;
    Inc(currRow);

    sheet.cells[GB_RW_DescriptCol, currRow] := RS(HV_stFemales);
    Inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[HV_Female, t];
    end;
    Inc(currRow);
  end;

  procedure HV_MV_TForceInf.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Adults_P + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Adults_P do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  {$ENDREGION}

{$REGION 'HV_MV_TInfectiousness'}
  constructor HV_MV_TInfectiousness.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_Infectiousness_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TInfectiousness.InitData;
  begin
    value[HV_PrimaryInf] := 8;
    value[HV_Asymptomatic] := 1;
    value[HV_SympNoART] := 4;
  end;

  procedure HV_MV_TInfectiousness.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    t : byte;
  begin
    inc(currRow);
    inc(currRow);
    for t := HV_PrimaryInf to HV_SympART do
    begin
      Inc(currRow);
      value[t] := sheet.floats[GB_RW_DataStartCol, currRow];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TInfectiousness.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    inc(currRow);
    inc(currRow);
    for t := HV_PrimaryInf to HV_SympART do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_InfectiousnessVarName(t);
      Inc(currRow);
      sheet.floats[GB_RW_DataStartCol, currRow] := value[t];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TInfectiousness.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, finalIndex +1 );
  end;

{$ENDREGION}

{$REGION 'HV_MV_TPrevalence'}
  constructor HV_MV_TPrevalence.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_Prevalence_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TPrevalence.InitData;
  var
    s, i : byte;
  begin
    for s := HV_Males_P to HV_Adults_P do
      for i := HV_min_year to length(value[s])-1 do
        value[s,i] := 0.0;
  end;

  procedure HV_MV_TPrevalence.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    inc(currRow);
    (* Prevalence *)
    for s := HV_Males_P to HV_Adults_P do
    begin
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[s, t] :=sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[s, t] := sheet.floats[c - 1, currRow];
      inc(currRow);
    end;
    inc(currRow);
  end;

  procedure HV_MV_TPrevalence.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s, t  : byte;
  begin
    inc(currRow);
    for s := HV_Males_P to HV_Adults_P do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_PrevalenceVarName(s);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      begin
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] := value[s, t];
      end;
      inc(currRow);
    end;
    inc(currRow);
  end;

  procedure HV_MV_TPrevalence.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Adults_P + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Adults_P do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TPrevalence'}
  constructor HV_MV_TCondomPercent.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_CondomPercent_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TCondomPercent.InitData;
  var
    t, i : byte;
  begin
    for i := HV_None to HV_MSMHR do
      for t := HV_min_year to length(value[i]) - 1 do
      begin
        value[i,t] := 0.0;
      end;
  end;

  procedure HV_MV_TCondomPercent.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    r, t, t1,
    t2, t3, nrow : byte;
    c, c1        : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    nrow := 1;
    for r := HV_LRH to (HV_MSMHR - 1) do
    begin
      Inc(nrow);
      if r = HV_IDU then
        Inc(nrow);
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[nrow, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[nrow, t] := sheet.floats[c - 1, currRow];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomPercent.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r,t,nrow  : byte;
  begin
    inc(currRow);
    nrow := 1;
    for r := HV_LRH to (HV_MSMHR - 1) do
    begin
      Inc(nrow);
      if r = HV_IDU then
        Inc(nrow);
      sheet.cells[GB_RW_DescriptCol, currRow] :=  GetHV_VarName(nrow);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      begin
         sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] := value[nrow, t];
      end;
      inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomPercent.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Adults_P + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Adults_P do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTransMultSTI'}
  constructor HV_MV_TTransMultSTI.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_TransMultSTI_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TTransMultSTI.InitData;
  begin
    value := 6.0;
  end;

  procedure HV_MV_TTransMultSTI.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure HV_MV_TTransMultSTI.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTransHIVF'}
  constructor HV_MV_TTransHIVF.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_TransHIVF_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TTransHIVF.InitData;
  begin
    value := 0.0011;
  end;

  procedure HV_MV_TTransHIVF.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure HV_MV_TTransHIVF.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTransMultM'}
  constructor HV_MV_TTransMultM.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_TransMultM_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TTransMultM.InitData;
  begin
    value := 1.0;
  end;

  procedure HV_MV_TTransMultM.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure HV_MV_TTransMultM.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCondomEff'}
  constructor HV_MV_TCondomEff.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_CondomEff_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TCondomEff.InitData;
  begin
    value := 80.0;
  end;

  procedure HV_MV_TCondomEff.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure HV_MV_TCondomEff.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNumPart'}
  constructor HV_MV_TNumPart.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_NumPart_MV2;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TNumPart.InitData;
  var
    t, i : byte;
  begin
    for i := HV_AllRisk to HV_MSM_F3 do
      for t := HV_min_year to length(value[i]) - 1 do
      begin
        value[i,t] := 0.0;
      end;
  end;

  procedure HV_MV_TNumPart.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);

    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F1         = 10;
      HV_LRH_F1          = 11;
      HV_MRH_F1          = 12;
      HV_HRH_F1          = 13;
      HV_IDU_F1          = 14;
    var
      r, t, t1,
      t2, t3, nrow :  byte;
      c, c1        : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      (* Number of Partners *)
      Inc(currRow);
      inc(currRow);//pass males
      nrow := 1;
      { * need to subtract two since HV_IDU_NP and HV_None_F_NP do not have data * }
      for r := HV_LRH to (HV_HRH_F1 - 2) do
      begin
        Inc(nrow);
        if nrow = HV_IDU then
          Inc(nrow);

        { * This accounts for the blank line and label between Male and Female data * }
        if nrow = HV_None_F1 then
        begin
          Inc(nrow);
          inc(currRow);
        end;
        inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[GetFIndexFromF1(nrow), t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[GetFIndexFromF1(nrow), t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      r, t, t1,
      t2, t3  :  byte;
      c, c1   : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      inc(currRow);
      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[r, t] := sheet.floats[c, currRow];
          inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
  begin
    if tag = HV_TG_NumPart_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_NumPart_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TNumPart.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r,t : byte;
  begin
    (* Number of Partners *)
    inc(currRow);
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_VarName(r);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] :=  value[r, t];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TNumPart.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_MSM_F3 + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_MSM_F3 do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function HV_MV_TNumPart.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_NumPart_MV) or (tag = HV_TG_NumPart_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TSexActs'}
  constructor HV_MV_TSexActs.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_SexActs_MV2;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TSexActs.InitData;
  var
    t, i : byte;
  begin
    for i := HV_AllRisk to HV_MSM_F3 do
      for t := HV_min_year to length(value[i]) - 1 do
      begin
        value[i,t] := 0.0;
      end;
  end;

  procedure HV_MV_TSexActs.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F1         = 10;
      HV_LRH_F1          = 11;
      HV_MRH_F1          = 12;
      HV_HRH_F1          = 13;
      HV_IDU_F1          = 14;
    var
      r, t, t1, t2, t3, nrow : byte;
      c, c1 : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);
      Inc(currRow);
           (* Sex Acts Per Partner Per Year *)
      Inc(currRow);//pass males
      nrow := 1;
      { * need to subtract two since HV_IDU_SA and HV_None_F_SA do not have data * }
      for r := HV_LRH to (HV_HRH_F1 - 2) do
      begin
        Inc(nrow);
        if nrow = HV_IDU then
          Inc(nrow);

        { * This accounts for the blank line and label between Male and Female data * }
        if nrow = HV_None_F1 then
        begin
          Inc(nrow);
          inc(currRow);
        end;
        Inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[GetFIndexFromF1(nrow), t] := sheet.Floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[GetFIndexFromF1(nrow), t] := sheet.Floats[c - 1, currRow];
        Inc(currRow);
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      r, t, t1,
      t2, t3  :  byte;
      c, c1   : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      inc(currRow);
      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[r, t] := sheet.floats[c, currRow];
          inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
  begin
    if tag = HV_TG_SexActs_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_SexActs_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TSexActs.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r, t : byte;
  begin
    (* Sex Acts Per Partner Per Year *)
    inc(currRow);
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_VarName(r);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] :=  value[r, t];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TSexActs.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_MSM_F3 + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_MSM_F3 do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function HV_MV_TSexActs.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_SexActs_MV) or (tag = HV_TG_SexActs_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TSTIPrev'}
  constructor HV_MV_TSTIPrev.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_STIPrev_MV2;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TSTIPrev.InitData;
  var
    t, i : byte;
  begin
    for i := HV_AllRisk to HV_MSM_F3 do
      for t := HV_min_year to length(value[i]) - 1 do
      begin
        value[i,t] := 0.0;
      end;
  end;

  procedure HV_MV_TSTIPrev.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F2          = 11;
      HV_LRH_F2           = 12;
      HV_MRH_F2           = 13;
      HV_HRH_F2           = 14;
      HV_IDU_F2           = 15;
    var
      r, t, t1, t2, t3, nrow : byte;
      c, c1 : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      (* STI Prevalence *)
      inc(currRow);
      inc(currRow);
      nrow := 1;
      { * need to subtract two since HV_None_F_SP, HV_IDU_M_SP do not have data * }
      for r := HV_LRH to (HV_HRH_F2 - 2) do
      begin
        Inc(nrow);
        if r = HV_IDU then
          Inc(nrow);
        { * This accounts for the blank line and label between Male and Female data * }
        if nrow = HV_None_F2 then
        begin
          Inc(nrow);
          inc(currRow);
        end;
        inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[GetFIndexFromF2(nrow), t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[GetFIndexFromF2(nrow), t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      r, t, t1,
      t2, t3  :  byte;
      c, c1   : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      inc(currRow);
      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[r, t] := sheet.floats[c, currRow];
          inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
  begin
    if tag = HV_TG_STIPrev_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_STIPrev_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TSTIPrev.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r, t : byte;
  begin
    (* STI Prevalence *)
    inc(currRow);
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_VarName(r);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] :=  value[r, t];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TSTIPrev.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_MSM_F3 + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_MSM_F3 do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function HV_MV_TSTIPrev.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_STIPrev_MV) or (tag = HV_TG_STIPrev_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TEpidemicStYr'}
  constructor HV_MV_TEpidemicStYr.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_EpidemicStYr_MV;
    stringID := HV_stEpidemiology;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TEpidemicStYr.InitData();
  begin
    value := 1980;
  end;

  procedure HV_MV_TEpidemicStYr.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);

    if value < parentx.GB.GetCalcYear(p) then    //to fix old projections which would have 0 as a value if there was no default data
      value := 1980;
  end;

  procedure HV_MV_TEpidemicStYr.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TIncRecruitment'}
  constructor HV_MV_TIncRecruitment.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_IncRecruitment_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TIncRecruitment.InitData;
  var
    s, i : byte;
  begin
    for s := HV_Male to HV_Female do
    begin
      for i := HV_None to HV_MSMIDU do
      begin
        value[s,i] := 0.0
      end;
    end;
  end;

  procedure HV_MV_TIncRecruitment.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s,r : byte;
  begin
    (* Percent of Deaths replaced by Increased Recruitment *)
    Inc(currRow);
    for s := HV_Male to HV_Female do
    begin
      inc(currROw);
      for r := HV_None to HV_MSMIDU do
      begin
        inc(currRow);
        value[s, r] := sheet.floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TIncRecruitment.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r : byte;
  begin
    (* Percent of Deaths replaced by Increased Recruitment *)
    Inc(currRow);
    for s := HV_Male to HV_Female do
    begin
      sheet.Cells[GB_RW_DescriptCol,currRow]:= GetHV_SexNames(s);
      inc(currROw);
      for r := HV_None to HV_MSMIDU do
      begin
        sheet.Cells[GB_RW_DescriptCol,currRow]:= GetHV_RiskVarNames(r);
        inc(currRow);
        sheet.floats[GB_RW_DataStartCol, currRow] := value[s, r];
        inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TIncRecruitment.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_Female + 1, HV_MSMIDU +1 );
  end;

{$ENDREGION}

{$REGION 'HV_MV_TAllRiskOutput'}
  constructor HV_MV_TAllRiskOutput.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_AllRiskOutput_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TAllRiskOutput.InitData;
  var
    i, t : byte;
  begin
    for i := 0 to HV_max_services-1 do
      for t := 1 to length(value[i]) - 1 do
        value[i,t] := 0.0;
  end;

  procedure HV_MV_TAllRiskOutput.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    i, t : byte;
    t1, t2, t3 : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    Inc(currRow);
    for i := 0 to HV_max_services-1 do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[i, t] := sheet.floats[c, currRow];
        inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[i, t] := sheet.floats[c-1, currRow];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TAllRiskOutput.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, t : byte;
  begin
    Inc(currRow);
    for i := 0 to HV_max_services-1 do
    begin
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[i, t];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TAllRiskOutput.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_max_services-1 + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_max_services-1 do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TMaxAllRisk'}
  constructor HV_MV_TMaxAllRisk.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_MaxAllRisk_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TMaxAllRisk.InitData;
  begin
    value := 0.0;
  end;

  procedure HV_MV_TMaxAllRisk.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TMaxAllRisk.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TPercMarried'}
  constructor HV_MV_TPercMarried.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_PercMarried_MV2;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TPercMarried.InitData;
  var
    i : byte;
  begin
    for i := HV_AllRisk to HV_MSM_F3 do
      value[i] := 0.0;
  end;

  procedure HV_MV_TPercMarried.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F1         = 10;
      HV_LRH_F1          = 11;
      HV_MRH_F1          = 12;
      HV_HRH_F1          = 13;
      HV_IDU_F1          = 14;
    var
      r : byte;
    begin
      (* Percent Married *)
      Inc(currRow);
      inc(currRow);
      begin
        for r := HV_LRH to HV_IDU_F1 do
        begin
          if r = HV_LRH_F1 then
          begin
            inc(currRow);
          end;
          inc(currRow);
          value[GetFIndexFromF1(r)] := sheet.floats[GB_RW_DataStartCol, currRow];
          inc(currRow);
        end;
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      r :  byte;
    begin
      inc(currRow);
      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        value[r] := sheet.floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;
    end;
  begin
    if tag = HV_TG_PercMarried_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_PercMarried_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TPercMarried.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r : byte;
  begin
    (* Percent Married *)
    inc(currRow);
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.Cells[GB_RW_DescriptCol,currRow]:=  GetHV_VarName(r);
      sheet.floats[GB_RW_DataStartCol, currRow] := value[r];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TPercMarried.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_MSM_F3 + 1);
  end;

  function HV_MV_TPercMarried.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_PercMarried_MV) or (tag = HV_TG_PercMarried_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TPerIDUsharing'}
  constructor HV_MV_TPerIDUsharing.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_PerIDUsharing_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TPerIDUsharing.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
     value[t] := 30;

  end;

  procedure HV_MV_TPerIDUsharing.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    Inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
  end;

  procedure HV_MV_TPerIDUsharing.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    sheet.cells[GB_RW_DescriptCol+1, currRow] := 'Percent IDU Sharing';
    Inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[t];
    end;
    Inc(currRow);
  end;

  procedure HV_MV_TPerIDUsharing.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TInitialPulse'}
  constructor HV_MV_TInitialPulse.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_InitialPulse_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TInitialPulse.InitData;
  begin
    value := 0.001;
  end;

  procedure HV_MV_TInitialPulse.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TInitialPulse.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTransMultMSM'}
  constructor HV_MV_TTransMultMSM.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_TransMultMSM_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TTransMultMSM.InitData;
  begin
    value := 2.6;
  end;

  procedure HV_MV_TTransMultMSM.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure HV_MV_TTransMultMSM.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TRedWHenCircum'}
  constructor HV_MV_TRedWHenCircum.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_RedWHenCircum_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TRedWHenCircum.InitData;
  begin
    value[HV_Susceptibility] := 60;
    value[HV_Infect] := 0;
  end;

  procedure HV_MV_TRedWHenCircum.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    i : byte;
  begin
    for i := HV_Susceptibility to HV_Infect do
      value[i] := sheet.floats[GB_RW_DataStartCol+i-1,currRow];
  end;

  procedure HV_MV_TRedWHenCircum.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
   var
    i : byte;
  begin
    for i := HV_Susceptibility to HV_Infect do
      sheet.floats[GB_RW_DataStartCol+i-1, currRow] :=value[i];
    inc(currRow);
  end;

  procedure HV_MV_TRedWHenCircum.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_Infect +1 );
  end;

{$ENDREGION}

{$REGION 'HV_MV_TInfectMultiplierOnART'}
  constructor HV_MV_TInfectMultiplierOnART.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_InfectMultiplierOnART_MV;
    stringID := GB_stRatioInfectLbl;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TInfectMultiplierOnART.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
    begin
      value[t] := 0.25;
    end;
  end;

  procedure HV_MV_TInfectMultiplierOnART.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    inc(currRow);
    inc(CurrRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TInfectMultiplierOnART.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t  :  byte;
  begin
    inc(currRow);
     (* Blood Infection *)
    sheet.cells[GB_RW_DescriptCol,currRow]:='Infectiousness multiplier on ART';
    inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TInfectMultiplierOnART.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TBloodInfection'}
  constructor HV_MV_TBloodInfection.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_BloodInfection_MV;
    stringID := HV_stBloodInfection;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TBloodInfection.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
    begin
      value[t] := 0;
    end;
  end;

  procedure HV_MV_TBloodInfection.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    inc(CurrRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TBloodInfection.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t  :  byte;
  begin
    inc(currRow);
     (* Blood Infection *)
    sheet.cells[GB_RW_DescriptCol,currRow]:='Blood Infection';
    inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TBloodInfection.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TARTReceive'}
  constructor HV_MV_TARTReceive.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_ARTReceive_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TARTReceive.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
    begin
      value[t] := 0;
    end;
  end;

  procedure HV_MV_TARTReceive.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t : byte;
    t1, t2, t3 : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    Inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c-1, currRow];
    Inc(currRow);
  end;


  procedure HV_MV_TARTReceive.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    Inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
      sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[t];
    Inc(currRow);
  end;

  procedure HV_MV_TARTReceive.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TMonthsInPrimaryStage'}
  constructor HV_MV_TMonthsInPrimaryStage.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_MonthsInPrimaryStage_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TMonthsInPrimaryStage.InitData;
  begin
    value := 3;
  end;

  procedure HV_MV_TMonthsInPrimaryStage.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure HV_MV_TMonthsInPrimaryStage.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TGoalsBaseYearIdx'}
  constructor HV_MV_TGoalsBaseYearIdx.Create(aOwner : GB_TXXData; finalyear : integer);
  begin
    inherited Create(aOwner);

    tag := HV_TG_GoalsBaseYearIdx_MV2;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_Extractable];

    InitData(finalyear);
  end;

  procedure HV_MV_TGoalsBaseYearIdx.InitData(finalYear : integer);
  begin
    (* We want to grab the index of the current year or the final year of the
       projection, whichever is less.

       This is an index for a combobox, not for use with our data arrays.
       Therefore, we add 1, not GetGBCalcYearIdx, and the place where this
       guy is used, 1 is subtracted from it as well.  *)
    value := max(1, min(finalYear, YearOf(Date)) - GetGBCalcYear(GetProj) + 1);
  end;

  procedure HV_MV_TGoalsBaseYearIdx.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    if tag = HV_TG_GoalsBaseYearIdx_MV then
    begin
      if parentx.GB.GetInCalcStateMode(p) then
        value := sheet.ints[GB_RW_DataStartCol, currRow]+1 // was shifted by one
      else
        value := sheet.ints[GB_RW_DataStartCol, currRow];

    end
    else if tag = HV_TG_GoalsBaseYearIdx_MV2 then
      value := sheet.ints[GB_RW_DataStartCol, currRow];

    Inc(currRow);
  end;

  procedure HV_MV_TGoalsBaseYearIdx.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TGoalsTargetYearIdx'}
  constructor HV_MV_TGoalsTargetYearIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_GoalsTargetYearIdx_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TGoalsTargetYearIdx.InitData;
  begin
    value := 7;
  end;

  procedure HV_MV_TGoalsTargetYearIdx.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TGoalsTargetYearIdx.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TImpactMatrix'}
  constructor HV_MV_TImpactMatrix.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_ImpactMatrix_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TImpactMatrix.InitData;
  var
    d, i, r : byte;
  begin
    for d := HV_Default to HV_Data do
      for i := 1 to HV_RN_IDUDrugSub do
        for r := 1 to HV_MaxRiskGroups  do
//          value[d, i, r] := SetHVImpactMatrix(d,i,r, 0.0);  /////Now has problem. It was like this before: SetHVImpactMatrix(p,d,i,r, 0.0)   ????????;
  end;

  procedure HV_MV_TImpactMatrix.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    d, i, r : byte;
  begin
    for d := HV_Default to HV_Data do
      for i := 1 to HV_RN_IDUDrugSub do
      begin
        for r := 1 to HV_MaxRiskGroups  do
           value[d, i, r] := sheet.floats[GB_RW_Datastartcol + r, CurrRow];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TImpactMatrix.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    d, i, r : byte;
  begin
    for d := HV_Default to HV_Data do
      for i := 1 to HV_RN_IDUDrugSub do
      begin
        for r := 1 to HV_MaxRiskGroups  do
          sheet.floats[GB_RW_Datastartcol + r, CurrRow] := value[d, i, r];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TImpactMatrix.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_Data + 1, HV_RN_IDUDrugSub + 1, HV_MaxRiskGroups +1 );
  end;

{$ENDREGION}

{$REGION 'HV_MV_TImpactMatrixCBIdx'}
  constructor HV_MV_TImpactMatrixCBIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_ImpactMatrixCBIdx_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TImpactMatrixCBIdx.InitData();
  begin
    value := HV_Average;
  end;

  procedure HV_MV_TImpactMatrixCBIdx.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TImpactMatrixCBIdx.Write(p : byte; sheet : GB_TFile;
  var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNumMSMRiskGroups'}
  constructor HV_MV_TNumMSMRiskGroups.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_NumMSMRiskGroups_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TNumMSMRiskGroups.InitData();
  begin
    value := 0;
  end;

  procedure HV_MV_TNumMSMRiskGroups.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TNumMSMRiskGroups.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TBalanceSexActs'}
  constructor HV_MV_TBalanceSexActs.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_BalanceSexActs_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TBalanceSexActs.InitData;
  begin
    value := True;
  end;

  procedure HV_MV_TBalanceSexActs.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := boolean(sheet.ints[GB_RW_DataStartCol, currRow]);
    Inc(currRow);
  end;

  procedure HV_MV_TBalanceSexActs.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := byte(value);
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCondomUseRadioGroupIdx'}
  constructor HV_MV_TCondomUseRadioGroupIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_CondomUseRadioGroupIdx_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TCondomUseRadioGroupIdx.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TCondomUseRadioGroupIdx.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCondomUseLogCurveParVal'}
  constructor HV_MV_TCondomUseLogCurveParVal.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_CondomUseLogCurveParVal_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TCondomUseLogCurveParVal.InitData;
  var
    r, i : byte;
  begin
    for r := HV_LRH to HV_MSMHR do
      for i := HV_CU_A to HV_CU_M do
        value[r,i] := 0.0;

    for r := HV_LRH to HV_MSMHR do
      value[r,HV_CU_Q] := 0.2;
  end;

  procedure HV_MV_TCondomUseLogCurveParVal.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    r, par : integer;
  begin
    for r := HV_LRH to HV_MSMHR do
    begin
      for par := HV_CU_A to HV_CU_Q do
        value[r, par] := sheet.floats[GB_RW_DataStartCol+par-1, currRow];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomUseLogCurveParVal.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r, par : integer;
  begin
    for r := HV_LRH to HV_MSMHR do
    begin
      for par := HV_CU_A to HV_CU_Q do
        sheet.floats[(GB_RW_DataStartCol + par - 1), currRow] := value[r, par];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomUseLogCurveParVal.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_MSMHR + 1, HV_CU_Q +1 );
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCondomUseInterpolatedVal'}
  constructor HV_MV_TCondomUseInterpolatedVal.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_CondomUseInterpolatedVal_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TCondomUseInterpolatedVal.InitData;
  var
    i, t : byte;
  begin
    for i := HV_None to HV_MSMHR do
      for t := HV_min_year to length(value[i]) - 1 do
        value[i,t] := 0.0;
  end;

  procedure HV_MV_TCondomUseInterpolatedVal.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    r, t, t1, t2, t3, nrow : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    Inc(currRow);
    nrow := 1;
    for r := HV_LRH to (HV_MSMHR - 1) do
    begin
      Inc(nrow);
      if r = HV_IDU then
        Inc(nrow);
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[nrow, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[nrow, t] := sheet.floats[c - 1, currRow];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomUseInterpolatedVal.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r,t,nrow  : byte;
  begin
    Inc(currRow);
    nrow := 1;
    for r := HV_LRH to (HV_MSMHR - 1) do
    begin
      Inc(nrow);
      if r = HV_IDU then
        Inc(nrow);
      sheet.cells[GB_RW_DescriptCol, currRow] :=  GetHV_VarName(nrow);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      begin
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] := value[nrow, t];
      end;
      inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomUseInterpolatedVal.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_MSMIDU do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCondomUseLogisticsVal'}
  constructor HV_MV_TCondomUseLogisticsVal.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_CondomUseLogisticsVal_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TCondomUseLogisticsVal.InitData;
  var
    i, t : byte;
  begin
    for i := HV_None to HV_MSMHR do
      for t := HV_min_year to length(value[i]) - 1 do
        value[i,t] := 0.0;
  end;

  procedure HV_MV_TCondomUseLogisticsVal.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    r, t, t1, t2, t3, nrow : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    nrow := 1;
    for r := HV_LRH to (HV_MSMHR - 1) do
    begin
      Inc(nrow);
      if r = HV_IDU then
        Inc(nrow);
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[nrow, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[nrow, t] := sheet.floats[c - 1, currRow];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomUseLogisticsVal.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r,t,nrow  : byte;
  begin
    nrow := 1;
    for r := HV_LRH to (HV_MSMHR - 1) do
    begin
      Inc(nrow);
      if r = HV_IDU then
        Inc(nrow);
      sheet.cells[GB_RW_DescriptCol+1, currRow] :=  GetHV_VarName(nrow);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      begin
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] := value[nrow, t];
      end;
      inc(currRow);
    end;
  end;

  procedure HV_MV_TCondomUseLogisticsVal.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_MSMIDU do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TSTIPrevRadioGroupIdx'}
  constructor HV_MV_TSTIPrevRadioGroupIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_STIPrevRadioGroupIdx_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TSTIPrevRadioGroupIdx.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TSTIPrevRadioGroupIdx.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TSTIPrevLogCurveParVal}
  constructor HV_MV_TSTIPrevLogCurveParVal.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := HV_TG_STIPrevLogCurveParVal_MV2;
    stringID    := GB_stLogisticsParSTIPrev;
    FlagSet     := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TSTIPrevLogCurveParVal.InitData;
  var
    r, i   : byte;
  begin
    for r := HV_LRH to HV_MSM_F3 do
      for i := HV_CU_A to HV_CU_M do
        value[r,i] := 0.0;

    for r := HV_LRH to HV_MSM_F3 do
      value[r,HV_CU_Q] := 0.2;
  end;

  procedure HV_MV_TSTIPrevLogCurveParVal.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F2          = 11;
      HV_LRH_F2           = 12;
      HV_MRH_F2           = 13;
      HV_HRH_F2           = 14;
      HV_IDU_F2           = 15;
    var
      r, par : integer;
    begin
      for r := HV_LRH to HV_IDU_F2 do
      begin
        for par := HV_CU_A to HV_CU_Q do
          value[GetFIndexFromF2(r), par] := sheet.floats[GB_RW_DataStartCol+par-1, currRow];
        Inc(currRow);
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
    r, par : integer;
    begin
      for r := HV_AllRisk to HV_MSM_F3 do
        begin
          for par := HV_CU_A to HV_CU_Q do
            value[r, par] := sheet.floats[GB_RW_DataStartCol+par-1, currRow];
          Inc(currRow);
        end;
    end;
  begin
    if tag = HV_TG_STIPrevLogCurveParVal_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_STIPrevLogCurveParVal_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TSTIPrevLogCurveParVal.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r, par : integer;
  begin
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      for par := HV_CU_A to HV_CU_Q do
        sheet.floats[(GB_RW_DataStartCol + par - 1), currRow] := value[r, par];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TSTIPrevLogCurveParVal.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_MSM_F3 + 1, HV_CU_Q +1 );
  end;

  function HV_MV_TSTIPrevLogCurveParVal.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_STIPrevLogCurveParVal_MV) or (tag = HV_TG_STIPrevLogCurveParVal_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TSTIPrevInterpolatedVal'}
  constructor HV_MV_TSTIPrevInterpolatedVal.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_STIPrevInterpolatedVal_MV2;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TSTIPrevInterpolatedVal.InitData;
  var
    i, t : byte;
  begin
    for i := HV_None to HV_MSM_F3 do
      for t := HV_min_year to length(value[i]) - 1 do
      begin
        value[i,t] := 0.0;
      end;
  end;

  procedure HV_MV_TSTIPrevInterpolatedVal.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F2          = 11;
      HV_LRH_F2           = 12;
      HV_MRH_F2           = 13;
      HV_HRH_F2           = 14;
      HV_IDU_F2           = 15;
    var
      r, t, t1, t2, t3, nrow : byte;
      c, c1 : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      (* STI Prevalence *)
      inc(currRow);
      nrow := 1;
      { * need to subtract two since HV_None_F_SP, HV_IDU_M_SP do not have data * }
      for r := HV_LRH to (HV_HRH_F2 - 2) do
      begin
        Inc(nrow);
        if r = HV_IDU then
          Inc(nrow);
        { * This accounts for the blank line and label between Male and Female data * }
        if nrow = HV_None_F2 then
        begin
          Inc(nrow);
          inc(currRow);
        end;
        inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[GetFIndexFromF2(nrow), t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[GetFIndexFromF2(nrow), t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      r, t, t1,
      t2, t3  :  byte;
      c, c1   : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      inc(currRow);
      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[r, t] := sheet.floats[c, currRow];
          inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
  begin
    if tag = HV_TG_STIPrevInterpolatedVal_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_STIPrevInterpolatedVal_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TSTIPrevInterpolatedVal.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r,t : byte;
  begin
    (* Number of Partners *)
    inc(currRow);
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_VarName(r);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] :=  value[r, t];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TSTIPrevInterpolatedVal.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_MSM_F3 + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_MSM_F3 do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function HV_MV_TSTIPrevInterpolatedVal.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_STIPrevInterpolatedVal_MV) or (tag = HV_TG_STIPrevInterpolatedVal_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TSTIPrevLogisticsVal'}
  constructor HV_MV_TSTIPrevLogisticsVal.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_STIPrevLogisticsVal_MV2;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TSTIPrevLogisticsVal.InitData;
  var
    i, t : byte;
  begin
    for i := HV_None to HV_MSM_F3 do
      for t := HV_min_year to length(value[i]) - 1 do
      begin
        value[i,t] := 0.0;
      end;
  end;

  procedure HV_MV_TSTIPrevLogisticsVal.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F2          = 11;
      HV_LRH_F2           = 12;
      HV_MRH_F2           = 13;
      HV_HRH_F2           = 14;
      HV_IDU_F2           = 15;
    var
      r, t, t1, t2, t3, nrow : byte;
      c, c1 : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);
      (* STI Prevalence *)
      inc(currRow);
      inc(currRow);
      nrow := 1;
      { * need to subtract two since HV_None_F_SP, HV_IDU_M_SP do not have data * }
      for r := HV_LRH to (HV_HRH_F2 - 2) do
      begin
        Inc(nrow);
        if r = HV_IDU then
          Inc(nrow);
        { * This accounts for the blank line and label between Male and Female data * }
        if nrow = HV_None_F2 then
        begin
          Inc(nrow);
          inc(currRow);
        end;
        inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[GetFIndexFromF2(nrow), t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[GetFIndexFromF2(nrow), t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      r, t, t1,
      t2, t3  :  byte;
      c, c1   : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
        GB_RW_DataStartCol, t1, t2, t3, c1);

      inc(currRow);
      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[r, t] := sheet.floats[c, currRow];
          inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
  begin
    if tag = HV_TG_STIPrevLogisticsVal_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_STIPrevLogisticsVal_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TSTIPrevLogisticsVal.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    r,t : byte;
  begin
    (* Number of Partners *)
    inc(currRow);
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := GetHV_VarName(r);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] :=  value[r, t];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TSTIPrevLogisticsVal.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_MSM_F3 + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_MSM_F3 do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function HV_MV_TSTIPrevLogisticsVal.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_STIPrevLogisticsVal_MV) or (tag = HV_TG_STIPrevLogisticsVal_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TRiskGroupNames'}
  constructor HV_MV_TRiskGroupNames.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_RiskGroupNames_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  destructor HV_MV_TRiskGroupNames.destroy;
  begin
    value.free;
    inherited destroy;
  end;

  procedure HV_MV_TRiskGroupNames.InitData;
  begin
    value := TStringList.Create;
    value.Sorted := false;
  end;

  procedure HV_MV_TRiskGroupNames.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s: integer;
  begin
    for s := 1 to sheet.Ints[GB_RW_DataStartCol,currRow] do
      value.Add(sheet.Cells[GB_RW_DataStartCol+s,currRow]);
  end;

  procedure HV_MV_TRiskGroupNames.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    l     : byte;
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := value.Count;
    for l := 1 to value.Count do
      sheet.cells[GB_RW_DataStartCol + l , currRow] := value.Strings[l - 1];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TEdHVSource'}
  constructor HV_MV_TEdHVSource.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_EdHVSource_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  destructor HV_MV_TEdHVSource.destroy;
  begin
    value.free;
    inherited destroy;
  end;

  procedure HV_MV_TEdHVSource.InitData;
  begin
    value := TStringList.Create;
    value.Sorted := false;
  end;

  procedure HV_MV_TEdHVSource.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s: integer;
  begin
    for s := 1 to sheet.Ints[GB_RW_DataStartCol,currRow] do
      value.Add(sheet.Cells[GB_RW_DataStartCol+s,currRow]);
  end;

  procedure HV_MV_TEdHVSource.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    l     : byte;
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := value.Count;
    for l := 1 to value.Count do
      sheet.cells[GB_RW_DataStartCol + l , currRow] := value.Strings[l - 1];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCalcStateData'}
  constructor HV_MV_TCalcStateData.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_CalcStateData_MV2;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  destructor HV_MV_TCalcStateData.Destroy;
  begin
    value.Free;
    Inherited Destroy;
  end;

  procedure HV_MV_TCalcStateData.InitData;
  begin
    if not assigned(value) then
      value :=  HV_TCalcStateObject.Create;
  end;

  procedure HV_MV_TCalcStateData.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    const
      HV_None_F1         = 10;
      HV_LRH_F1          = 11;
      HV_MRH_F1          = 12;
      HV_HRH_F1          = 13;
      HV_IDU_F1          = 14;

      HV_None_F2          = 11;
      HV_LRH_F2           = 12;
      HV_MRH_F2           = 13;
      HV_HRH_F2           = 14;
      HV_IDU_F2           = 15;
    var
      a,b,s,c,r,h,v,pop      : byte;
    begin
      value.TotalNewVaccinations := sheet.Floats[GB_RW_DataStartCol, currRow];
      inc(currRow);

      value.Unvaccinated := sheet.Floats[GB_RW_DataStartCol, currRow];
      inc(currRow);

      value.VaccineTargeting := sheet.Ints[GB_RW_DataStartCol, currRow];
      inc(currRow);

      value.TypeOfVaccine := sheet.Ints[GB_RW_DataStartCol, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.Populations[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.TotalVaccinated[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.TotalAdultsHIV[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.TotalAdultsART[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
      begin
        for r := HV_AllRisk to HV_MSMIDU do
          value.NewVaccinations[s,r] := sheet.Floats[GB_RW_DataStartCol + r, currRow];
        inc(currRow);
      end;

      for s := HV_BothSexes to HV_Female do
      begin
        inc(currRow);
        for r := HV_AllRisk to HV_MSMIDU do
        begin
          for h := HV_Negative to HV_AllHIV do
            value.Vaccinated[s,r,h] := sheet.Floats[GB_RW_DataStartCol + h, currRow];
          inc(currRow);
        end;
      end;

      for s := HV_BothSexes to HV_Female do
      begin
        inc(currRow);
        for r := HV_AllRisk to HV_MSMIDU do
        begin
          for h := HV_Negative to HV_AllHIV do
          begin
            for v := HV_RN_ALLVacc to HV_RN_NoProt do
              value.Adults[s,r,h,v] := sheet.Floats[GB_RW_DataStartCol + v, currRow];
            inc(currRow);
          end;
        end;
      end;

      for r := HV_RN_Efficacy to HV_RN_Duration do
        value.VaccineEffectiveness[r] := sheet.Floats[GB_RW_DataStartCol + r - 1, currRow];
      inc(currRow);

      for r := HV_RN_AllRisk to HV_RN_MSM_F do
        value.VacCoverage[r] := sheet.Floats[GB_RW_DataStartCol + r, currRow];
      inc(currRow);

      for b := HV_RN_AmongVacc to HV_RN_AmongAdults do
        value.VaccineBehavEffect[b] := sheet.Floats[GB_RW_DataStartCol + b - 1, currRow];
      inc(currRow);

      for c := HV_CD4_GT500 to HV_CD4_LT50 do
        value.CD4Coverage[c] := sheet.Floats[GB_RW_DataStartCol + c - 2, currRow];
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.CovPopsEligTreat[pop] := sheet.Floats[GB_RW_DataStartCol + pop - 1, currRow];
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.PopsEligTreatEligible[pop] := Boolean(sheet.Ints[GB_RW_DataStartCol + pop - 1, currRow]);
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.PopsEligTreatPercentHIV[pop] := sheet.Floats[GB_RW_DataStartCol + pop - 1, currRow];
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.PopsEligTreatYear[pop] := sheet.Ints[GB_RW_DataStartCol + pop - 1, currRow];
      inc(currRow);

      for s := GB_BothSexes to GB_Female do
      begin
        value.AgeFirstSex[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
        inc(currRow)
      end;

      for s := GB_BothSexes to GB_Female do
      begin
        value.NonAIDSDeathRate[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
        inc(currRow);
      end;

      for s := GB_BothSexes to GB_Female do
      begin
        for a := HV_DP_A15_19 to HV_DP_A45_49 do
          value.MigrRate[s,a] := sheet.Floats[GB_RW_DataStartCol + a - 4, currRow];
        inc(currRow);
      end;

      for c := 1 to HV_RN_IDUDrugSub do
        value.Coverage[c] := sheet.Floats[GB_RW_DataStartCol + c - 1, currRow];
      inc(currRow);

      for r := HV_AllRisk to HV_IDU_F1 do
        value.NumPart[GetFIndexFromF1(r)] := sheet.Floats[GB_RW_DataStartCol + r, currRow];
      inc(currRow);

      value.PerIDUSharing := sheet.Floats[GB_RW_DataStartCol, currRow];

      for r := HV_LRH to HV_IDU_F2 do
      begin
        value.STIPrev[GetFIndexFromF2(r)] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

      for r := HV_LRH to HV_IDU_F2 do
      begin
        value.STIPrevInterpolatedVal[GetFIndexFromF2(r)] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

      for r := HV_LRH to HV_MSM do
      begin
        value.CondomPercent[r] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

      for r := HV_LRH to HV_MSM do
      begin
        value.CondomUseInterpolatedVal[r] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      a,b,s,c,r,h,v,pop      : byte;
    begin
      value.TotalNewVaccinations := sheet.Floats[GB_RW_DataStartCol, currRow];
      inc(currRow);

      value.Unvaccinated := sheet.Floats[GB_RW_DataStartCol, currRow];
      inc(currRow);

      value.VaccineTargeting := sheet.Ints[GB_RW_DataStartCol, currRow];
      inc(currRow);

      value.TypeOfVaccine := sheet.Ints[GB_RW_DataStartCol, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.Populations[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.TotalVaccinated[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.TotalAdultsHIV[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
        value.TotalAdultsART[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
      inc(currRow);

      for s := HV_BothSexes to HV_Female do
      begin
        for r := HV_AllRisk to HV_MSMIDU do
          value.NewVaccinations[s,r] := sheet.Floats[GB_RW_DataStartCol + r, currRow];
        inc(currRow);
      end;

      for s := HV_BothSexes to HV_Female do
      begin
        inc(currRow);
        for r := HV_AllRisk to HV_MSMIDU do
        begin
          for h := HV_Negative to HV_AllHIV do
            value.Vaccinated[s,r,h] := sheet.Floats[GB_RW_DataStartCol + h, currRow];
          inc(currRow);
        end;
      end;

      for s := HV_BothSexes to HV_Female do
      begin
        inc(currRow);
        for r := HV_AllRisk to HV_MSMIDU do
        begin
          for h := HV_Negative to HV_AllHIV do
          begin
            for v := HV_RN_ALLVacc to HV_RN_NoProt do
              value.Adults[s,r,h,v] := sheet.Floats[GB_RW_DataStartCol + v, currRow];
            inc(currRow);
          end;
        end;
      end;

      for r := HV_RN_Efficacy to HV_RN_Duration do
        value.VaccineEffectiveness[r] := sheet.Floats[GB_RW_DataStartCol + r - 1, currRow];
      inc(currRow);

      for r := HV_RN_AllRisk to HV_RN_MSM_F do
        value.VacCoverage[r] := sheet.Floats[GB_RW_DataStartCol + r, currRow];
      inc(currRow);

      for b := HV_RN_AmongVacc to HV_RN_AmongAdults do
        value.VaccineBehavEffect[b] := sheet.Floats[GB_RW_DataStartCol + b - 1, currRow];
      inc(currRow);

      for c := HV_CD4_GT500 to HV_CD4_LT50 do
        value.CD4Coverage[c] := sheet.Floats[GB_RW_DataStartCol + c - 2, currRow];
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.CovPopsEligTreat[pop] := sheet.Floats[GB_RW_DataStartCol + pop - 1, currRow];
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.PopsEligTreatEligible[pop] := Boolean(sheet.Ints[GB_RW_DataStartCol + pop - 1, currRow]);
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.PopsEligTreatPercentHIV[pop] := sheet.Floats[GB_RW_DataStartCol + pop - 1, currRow];
      inc(currRow);

      for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
        value.PopsEligTreatYear[pop] := sheet.Ints[GB_RW_DataStartCol + pop - 1, currRow];
      inc(currRow);

      for s := GB_BothSexes to GB_Female do
      begin
        value.AgeFirstSex[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
        inc(currRow)
      end;

      for s := GB_BothSexes to GB_Female do
      begin
        value.NonAIDSDeathRate[s] := sheet.Floats[GB_RW_DataStartCol + s, currRow];
        inc(currRow);
      end;

      for s := GB_BothSexes to GB_Female do
      begin
        for a := HV_DP_A15_19 to HV_DP_A45_49 do
          value.MigrRate[s,a] := sheet.Floats[GB_RW_DataStartCol + a - 4, currRow];
        inc(currRow);
      end;

      for c := 1 to HV_RN_IDUDrugSub do
        value.Coverage[c] := sheet.Floats[GB_RW_DataStartCol + c - 1, currRow];
      inc(currRow);

      for r := HV_AllRisk to HV_MSM_F3 do
        value.NumPart[r] := sheet.Floats[GB_RW_DataStartCol + r, currRow];
      inc(currRow);

      value.PerIDUSharing := sheet.Floats[GB_RW_DataStartCol, currRow];

      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        value.STIPrev[r] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

      for r := HV_AllRisk to HV_MSM_F3 do
      begin
        value.STIPrevInterpolatedVal[r] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

      for r := HV_LRH to HV_MSM do
      begin
        value.CondomPercent[r] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

      for r := HV_LRH to HV_MSM do
      begin
        value.CondomUseInterpolatedVal[r] := sheet.Floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;

    end;
  begin
    if tag = HV_TG_CalcStateData_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_CalcStateData_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;


  procedure HV_MV_TCalcStateData.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    a,b,s,c,r,h,v,pop      : byte;
  begin
//    value := GetHVCalcStateData(p);

    sheet.cells[GB_RW_DescriptCol+1, currRow] := 'Total new vaccinations';
    sheet.Floats[GB_RW_DataStartCol, currRow] := value.TotalNewVaccinations;
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Unvaccinated';
    sheet.Floats[GB_RW_DataStartCol, currRow] := value.Unvaccinated;
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Vaccine targeting';
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.VaccineTargeting;
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Type of vaccine';
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.TypeOfVaccine;
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Populations';
    for s := HV_BothSexes to HV_Female do
      sheet.Floats[GB_RW_DataStartCol + s, currRow] := value.Populations[s];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Total vaccinated';
    for s := HV_BothSexes to HV_Female do
      sheet.Floats[GB_RW_DataStartCol + s, currRow] := value.TotalVaccinated[s];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Total adults HIV';
    for s := HV_BothSexes to HV_Female do
      sheet.Floats[GB_RW_DataStartCol + s, currRow] := value.TotalAdultsHIV[s];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Total adults ART';
    for s := HV_BothSexes to HV_Female do
      sheet.Floats[GB_RW_DataStartCol + s, currRow] := value.TotalAdultsART[s];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'New vaccinations by risk group';
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_SexNames(s);
      for r := HV_AllRisk to HV_MSMIDU do
        sheet.Floats[GB_RW_DataStartCol + r, currRow] := value.NewVaccinations[s,r];
      inc(currRow);
    end;

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Vaccinated by risk group by HIV status';
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for r := HV_AllRisk to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_RiskVarNames(r);
        for h := HV_Negative to HV_AllHIV do
          sheet.Floats[GB_RW_DataStartCol + h, currRow] := value.Vaccinated[s,r,h];
        inc(currRow);
      end;
    end;

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Adults array';
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for r := HV_AllRisk to HV_MSMIDU do
      begin
        for h := HV_Negative to HV_AllHIV do
        begin
          sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_RiskVarNames(r) + ': ' + GetHV_CD4VarNames(h);
          for v := HV_RN_ALLVacc to HV_RN_NoProt do
            sheet.Floats[GB_RW_DataStartCol + v, currRow] := value.Adults[s,r,h,v];
          inc(currRow);
        end;
      end;
    end;

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Vaccine effectiveness';
    for r := HV_RN_Efficacy to HV_RN_Duration do
      sheet.Floats[GB_RW_DataStartCol + r - 1, currRow] := value.VaccineEffectiveness[r];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Vaccine coverage';
    for r := HV_RN_AllRisk to HV_RN_MSM_F do
      sheet.Floats[GB_RW_DataStartCol + r, currRow] := value.VacCoverage[r];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Vaccine behavior effect';
    for b := HV_RN_AmongVacc to HV_RN_AmongAdults do
      sheet.Floats[GB_RW_DataStartCol + b - 1, currRow] := value.VaccineBehavEffect[b];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'CD4 coverage';
    for c := HV_CD4_GT500 to HV_CD4_LT50 do
      sheet.Floats[GB_RW_DataStartCol + c - 2, currRow] := value.CD4Coverage[c];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Coverage for populations eligible for treatment regardless of CD4 count';
    for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
      sheet.Floats[GB_RW_DataStartCol + pop - 1, currRow] := value.CovPopsEligTreat[pop];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Populations eligible for treatment regardless of CD4 count';
    for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
      sheet.Ints[GB_RW_DataStartCol + pop - 1, currRow] := byte(value.PopsEligTreatEligible[pop]);
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Percent HIV for populations eligible for treatment regardless of CD4 count';
    for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
      sheet.Floats[GB_RW_DataStartCol + pop - 1, currRow] := value.PopsEligTreatPercentHIV[pop];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Treatment year for populations eligible for treatment regardless of CD4 count';
    for pop := HV_DP_EligTreatPregnantWomen to HV_DP_EligTreatOtherPop do
      sheet.Ints[GB_RW_DataStartCol + pop - 1, currRow] := value.PopsEligTreatYear[pop];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Age at first sex';
    for s := GB_BothSexes to GB_Female do
    begin
      sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_SexNames(s);
      sheet.Floats[GB_RW_DataStartCol + s, currRow] := value.AgeFirstSex[s];
      inc(currRow)
    end;

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Non AIDS death rate';
    for s := GB_BothSexes to GB_Female do
    begin
      sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_SexNames(s);
      sheet.Floats[GB_RW_DataStartCol + s, currRow] := value.NonAIDSDeathRate[s];
      inc(currRow);
    end;

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Migration rate by five year age groups (15-49)';
    for s := GB_BothSexes to GB_Female do
    begin
      sheet.cells[GB_RW_NotesCol,currRow]:= GetHV_SexNames(s);
      for a := HV_DP_A15_19 to HV_DP_A45_49 do
        sheet.Floats[GB_RW_DataStartCol + a - 4, currRow] := value.MigrRate[s,a];
      inc(currRow);
    end;

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Coverage from Resources Needs Module';
    for c := 1 to HV_RN_IDUDrugSub do
      sheet.Floats[GB_RW_DataStartCol + c - 1, currRow] := value.Coverage[c];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Number of partners by risk group';
    for r := HV_AllRisk to HV_MSM_F3 do
      sheet.Floats[GB_RW_DataStartCol + r, currRow] := value.NumPart[r];
    inc(currRow);

    sheet.Cells[GB_RW_DescriptCol, currRow] := 'Percent IDU sharing';
    sheet.Floats[GB_RW_DataStartCol, currRow] := value.PerIDUSharing;

    sheet.Cells[GB_RW_DescriptCol,currRow] := 'STI prevalence by risk group';
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.Cells[GB_RW_NotesCol,currRow] := GetHV_VarName(r);
      sheet.Floats[GB_RW_DataStartCol, currRow] := value.STIPrev[r];
      inc(currRow);
    end;

    sheet.Cells[GB_RW_DescriptCol,currRow] := 'STI prevalence interpolated values by risk group';
    for r := HV_AllRisk to HV_MSM_F3 do
    begin
      sheet.Cells[GB_RW_NotesCol,currRow] := GetHV_VarName(r);
      sheet.Floats[GB_RW_DataStartCol, currRow] := value.STIPrevInterpolatedVal[r];
      inc(currRow);
    end;

    sheet.Cells[GB_RW_DescriptCol,currRow] := 'Condom percent by risk group';
    for r := HV_LRH to HV_MSM do
    begin
      sheet.Cells[GB_RW_NotesCol,currRow] := GetHV_VarName(r);
      sheet.Floats[GB_RW_DataStartCol, currRow] := value.CondomPercent[r];
      inc(currRow);
    end;

    sheet.Cells[GB_RW_DescriptCol,currRow] := 'Condom use interpolated values by risk group';
    for r := HV_LRH to HV_MSM do
    begin
      sheet.Cells[GB_RW_NotesCol,currRow] := GetHV_VarName(r);
      sheet.Floats[GB_RW_DataStartCol, currRow] := value.CondomUseInterpolatedVal[r];
      inc(currRow);
    end;
  end;

  function HV_MV_TCalcStateData.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_CalcStateData_MV) or (tag = HV_TG_CalcStateData_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'HV_MV_TAdults'}
  constructor HV_MV_TAdults.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_Adults_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TAdults.InitData;
  var
    s, r, h, v, t : byte;
  begin
    for s := HV_Male to HV_Female do
      for r := HV_AllRisk to HV_MSMIDU do
          {[CDP] change to add CD4 structure}
        for h := HV_Negative to HV_AllHIV do
          for v := HV_RN_AllVacc to HV_RN_NoProt do
            for t := 1 to length(value[s,r,h,v]) - 1 do
              value[s,r,h,v,t] := 0;
  end;

  procedure HV_MV_TAdults.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, t, v, h, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol + 2, t1, t2, t3, c1);

    for s := HV_BothSexes to HV_Female do
    begin
      inc(currRow);
      for r := HV_AllRisk to HV_MSMIDU do
      begin
        for h := HV_Negative to HV_AllHIV do
        begin
          for v := HV_RN_AllVacc to HV_RN_NoProt do
          begin
            c := c1;
            for t := t1 to t2 do
            begin
              value[s, r, h, v, t] := sheet.floats[c, currRow];
              Inc(c);
            end;
            for t := t2 + 1 to t3 do
              value[s, r, h, v, t] := sheet.floats[c - 1, currRow];
            inc(currRow);
          end;
        end;
      end;
    end;
  end;

  procedure HV_MV_TAdults.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s, r, t, v, h : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:=  GetHV_SexNames(s);
      inc(currRow);
      for r := HV_AllRisk to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_DescriptCol+1,currRow]:=  GetHV_RiskVarNames(r);
        for h := HV_Negative to HV_AllHIV do
        begin
          sheet.cells[GB_RW_DescriptCol+2,currRow]:=  GetHV_CD4VarNames(h);
          for v := HV_RN_AllVacc to HV_RN_NoProt do
          begin
            sheet.cells[GB_RW_DescriptCol+3,currRow]:=  GetHV_VaccVarNames(v);
            for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
            begin
              sheet.floats[GB_RW_DescriptCol+4+t-GetGBCalcYearIdx(p),currRow]:= value[s, r, h, v, t];
            end;
            inc(currRow);
          end;
        end;
      end;
    end;
  end;

  procedure HV_MV_TAdults.Resize(action : byte; finalIndex : integer);
  var
    t, i, j, m, n,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, HV_AllHIV + 1, HV_RN_NoProt + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for m := HV_Negative to HV_AllHIV do
              for n := HV_RN_AllVacc to HV_RN_NoProt do
                for t := oldIndex + 1 to finalIndex do
                  value[i, j, m, n, t] := value[i, j, m, n, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TRiskGroupPercent'}
  constructor HV_MV_TRiskGroupPercent.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_RiskGroupPercent_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TRiskGroupPercent.InitData;
  begin
   //
  end;

  procedure HV_MV_TRiskGroupPercent.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s : byte;
  begin
      for s := HV_AllRisk to HV_MSM_F3 do
      begin
        inc(currRow);
        value[s] := sheet.floats[GB_RW_DataStartCol, currRow];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TRiskGroupPercent.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s : byte;
  begin
    (* Percent of Deaths replaced by Increased Recruitment *)
      for s := HV_AllRisk to HV_MSM_F3 do
      begin
       // sheet.Cells[GB_RW_DescriptCol,currRow]:= GetHV_RiskVarNames(s);
        inc(currRow);
        sheet.floats[GB_RW_DataStartCol, currRow] := value[s];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TRiskGroupPercent.Resize(action : byte; finalIndex : integer);
  begin
    SetLength(value, HV_MSM_F3 +1 );
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNonAIDSDeathRate'}
  constructor HV_MV_TNonAIDSDeathRate.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_NonAIDSDeathRate_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TNonAIDSDeathRate.InitData;
  begin
    //
  end;

  procedure HV_MV_TNonAIDSDeathRate.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    i, t : byte;
    t1, t2, t3 : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    for i := HV_BothSexes to HV_Female -1 do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[i, t] := sheet.floats[c, currRow];
        inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[i, t] := sheet.floats[c-1, currRow];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TNonAIDSDeathRate.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, t : byte;
  begin
    for i := HV_BothSexes to HV_Female -1 do
    begin
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[i, t];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TNonAIDSDeathRate.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TRateofAging'}
  constructor HV_MV_TRateofAging.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_RateofAging_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TRateofAging.InitData;
  begin
    //
  end;

  procedure HV_MV_TRateofAging.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    i, t : byte;
    t1, t2, t3 : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    for i := HV_BothSexes to HV_Female - 1 do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[i, t] := sheet.floats[c, currRow];
        inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[i, t] := sheet.floats[c-1, currRow];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TRateofAging.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, t : byte;
  begin
    for i := HV_BothSexes to HV_Female - 1 do
    begin
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[i, t];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TRateofAging.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TPopulations'}
  constructor HV_MV_TPopulations.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_Populations_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TPopulations.InitData;
  begin
    //
  end;

  procedure HV_MV_TPopulations.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    (* Population *)
    for s := HV_BothSexes to HV_Female do
    begin
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[s, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[s, t] := sheet.floats[c - 1, currRow];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TPopulations.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      begin
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:=  value[s, t];
      end;
      inc(currRow);
    end;
  end;

  procedure HV_MV_TPopulations.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TVaccinated'}
  constructor HV_MV_TVaccinated.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_Vaccinated_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TVaccinated.InitData;
  begin
    //
  end;

  procedure HV_MV_TVaccinated.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    i, j,
    m, t : byte;
    t1, t2, t3 : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    for i := HV_BothSexes to HV_Female - 1 do
      for j := HV_AllRisk to HV_MSMIDU - 1 do
        for m := HV_Negative to HV_AllHIV - 1 do
          begin
            c := c1;
            for t := t1 to t2 do
            begin
              value[i, j, m, t] := sheet.floats[c, currRow];
              inc(c);
            end;
            for t := t2 + 1 to t3 do
              value[i, j, m, t] := sheet.floats[c-1, currRow];
            Inc(currRow);
          end;
  end;

  procedure HV_MV_TVaccinated.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, j,
    m, t : byte;
  begin
    for i := HV_BothSexes to HV_Female - 1 do
      for j := HV_AllRisk to HV_MSMIDU - 1 do
        for m := HV_Negative to HV_AllHIV - 1 do
          begin
            for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
              sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[i, j, m, t];
            Inc(currRow);
          end;
  end;

  procedure HV_MV_TVaccinated.Resize(action : byte; finalIndex : integer);
  var
    t, i, j, m,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, HV_AllHIV + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for m := HV_Negative to HV_AllHIV do
              for t := oldIndex + 1 to finalIndex do
                value[i, j, m, t] := value[i, j, m, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTotalVaccinated'}
  constructor HV_MV_TTotalVaccinated.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_TotalVaccinated_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TTotalVaccinated.InitData;
  begin
    //
  end;

  procedure HV_MV_TTotalVaccinated.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    (* Total Vaccinated *)
    for s := HV_BothSexes to HV_Female do
    begin
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[s, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[s, t] :=  sheet.floats[c - 1, currRow];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TTotalVaccinated.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      begin
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[s, t];
      end;
      inc(currRow);
    end;
  end;

  procedure HV_MV_TTotalVaccinated.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TUnvaccinated'}
  constructor HV_MV_TUnvaccinated.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_Unvaccinated_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TUnvaccinated.InitData;
  begin
    //
  end;

  procedure HV_MV_TUnvaccinated.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1  : byte;
    t2, t3 : byte;
    c, c1  : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
      c := c1;
      for t := t1 to t2 do
      begin
        value[t] := sheet.floats[c, currRow];
        inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[t] := sheet.floats[c-1, currRow];
      Inc(currRow);
  end;

  procedure HV_MV_TUnvaccinated.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[t];
      Inc(currRow);
  end;

  procedure HV_MV_TUnvaccinated.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNewVaccinations'}
  constructor HV_MV_TNewVaccinations.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_NewVaccinations_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TNewVaccinations.InitData;
  begin
    //
  end;

  procedure HV_MV_TNewVaccinations.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

   (* New Vaccinations *)
    for s := HV_Male to HV_Female do
    begin
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
        inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, r, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
    inc(currRow);
  end;

  procedure HV_MV_TNewVaccinations.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r,t : byte;
  begin
    for s := HV_Male to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:=  GetHV_SexNames(s);
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_DescriptCol,currRow]:=  GetHV_RiskVarNames(r);
        inc(currRow);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[s, r, t];
        inc(currRow);
      end;
    end;
    inc(currRow);
  end;

  procedure HV_MV_TNewVaccinations.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTotalNewVaccinations'}
  constructor HV_MV_TTotalNewVaccinations.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_TotalNewVaccinations_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TTotalNewVaccinations.InitData;
  begin
    //
  end;

  procedure HV_MV_TTotalNewVaccinations.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TTotalNewVaccinations.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    sheet.cells[GB_RW_DescriptCol+1,currRow]:=  'Total New Vaccinations';
    inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:=  value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TTotalNewVaccinations.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTotalAdultsHIV'}
  constructor HV_MV_TTotalAdultsHIV.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_TotalAdultsHIV_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TTotalAdultsHIV.InitData;
  var
    s, t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
      for t := HV_min_year to length(value[s]) - 1 do
        value[s,t] := 0.0;
  end;

  procedure HV_MV_TTotalAdultsHIV.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    (* Total Adults HIV *)
    for s := HV_Male to HV_Female do
    begin
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[s, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[s, t] := sheet.floats[c - 1, currRow];
      inc(currRow)
    end;
  end;

  procedure HV_MV_TTotalAdultsHIV.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,t : byte;
  begin
    (* Adults HIV by risk group *)
    for s := HV_Male to HV_Female do
    begin
      sheet.Cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] := value[s, t];
      inc(currRow)
    end;
  end;

  procedure HV_MV_TTotalAdultsHIV.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNewlyOnART'}
  constructor HV_MV_TNewlyOnART.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_NewlyOnART_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TNewlyOnART.InitData;
  var
    s, h, t : byte;
  begin
   for s := HV_BothSexes to HV_Female do
    for h := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
      for t := HV_min_year to length(value[s, h]) - 1 do
      begin
        value[s,h,t] := 0.0;
      end;
  end;

  procedure HV_MV_TNewlyOnART.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, h, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    for s := HV_BothSexes to HV_Female do
      for h := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, h, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, h, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TNewlyOnART.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,h,t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1, currRow] :=  GetHV_SexNames(s);
      for h := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
      begin
        sheet.cells[GB_RW_DescriptCol + 1, currRow] := GetHV_CD4VarNames(h);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow] := value[s, h, t];
        Inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TNewlyOnART.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_CD4_LT50_ART + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNewlyEligibleART'}
  constructor HV_MV_TNewlyEligibleART.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_NewlyEligibleART_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TNewlyEligibleART.InitData;
  var
    s, h, t : byte;
  begin
   for s := HV_BothSexes to HV_Female do
    for h := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
      for t := HV_min_year to length(value[s, h]) - 1 do
      begin
        value[s,h,t] := 0.0;
      end;
  end;

  procedure HV_MV_TNewlyEligibleART.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, h, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    for s := HV_BothSexes to HV_Female do
      for h := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, h, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, h, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TNewlyEligibleART.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,h,t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1, currRow] :=  GetHV_SexNames(s);
      for h := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
      begin
        sheet.cells[GB_RW_DescriptCol + 1, currRow] := GetHV_CD4VarNames(h);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow] := value[s, h, t];
        Inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TNewlyEligibleART.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_CD4_LT50_ART + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_CD4_GT500_ART to HV_CD4_LT50_ART do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTotalAdultsART'}
  constructor HV_MV_TTotalAdultsART.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_TotalAdultsART_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TTotalAdultsART.InitData;
  var
    s, t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
      for t := HV_min_year to length(value[s]) - 1 do
        value[s,t] := 0.0;
  end;

  procedure HV_MV_TTotalAdultsART.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    (* Total Adults ART *)
    for s := HV_Male to HV_Female do
    begin
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[s, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[s, t] := sheet.floats[c - 1, currRow];
      inc(currRow)
    end;
  end;

  procedure HV_MV_TTotalAdultsART.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,t : byte;
  begin
    (* Adults ART by risk group *)
    for s := HV_Male to HV_Female do
    begin
      sheet.Cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p), currRow] :=value[s, t];
      inc(currRow)
    end;
  end;

  procedure HV_MV_TTotalAdultsART.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TrMultAll'}
  constructor HV_MV_TrMultAll.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_rMultAll_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TrMultAll.InitData;
  begin
    //
  end;

  procedure HV_MV_TrMultAll.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    for s := HV_Male to HV_Female do
      for r := HV_None to HV_MSMIDU do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, r, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, r, t] := sheet.floats[c - 1, currRow];
        Inc(currRow);
      end;
  end;

  procedure HV_MV_TrMultAll.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r,t : byte;
  begin
    inc(currRow);
    for s := HV_Male to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] :=  GetHV_SexNames(s);
      for r := HV_None to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_DescriptCol + 1, currRow] := GetHV_RiskVarNames(r);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow] := value[s, r, t];
        Inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TrMultAll.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCalcPrevalence'}
  constructor HV_MV_TCalcPrevalence.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_CalcPrevalence_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TCalcPrevalence.InitData;
  begin
    //
  end;

  procedure HV_MV_TCalcPrevalence.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    (* Calculated Prevalence *)
    inc(currRow);
    for s := HV_Male to HV_Female do
    begin
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
        inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, r, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TCalcPrevalence.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r,t : byte;
  begin
    inc(currRow);
    (* Calculated Prevalence *)
    for s := HV_Male to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
      sheet.cells[GB_RW_DescriptCol,currRow]:= GetHV_RiskVarNames(r);
      inc(currRow);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        begin
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:=  value[s, r, t];
        end;
      inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TCalcPrevalence.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNewInfections'}
  constructor HV_MV_TNewInfections.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_NewInfections_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TNewInfections.InitData;
  begin
    //
  end;

  procedure HV_MV_TNewInfections.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, v, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    (* New Infections *)
    for s := HV_Male to HV_Female do
    begin
//      sheet.cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
      inc(currRow);
        for v := HV_RN_AllVacc to HV_RN_NoProt do
        begin
          inc(currRow);
          c := c1;
          for t := t1 to t2 do
          begin
            value[s, r, v, t] := sheet.floats[c, currRow];
            Inc(c);
          end;
          for t := t2 + 1 to t3 do
            value[s, r, v, t] := sheet.floats[c - 1, currRow];
          inc(currRow);
        end;
      end;
    end;
  end;

  procedure HV_MV_TNewInfections.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r,v,t : byte;
  begin
    (* New Infections *)
    for s := HV_Male to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
      sheet.cells[GB_RW_DescriptCol,currRow]:= GetHV_RiskVarNames(r);
      inc(currRow);
        for v := HV_RN_AllVacc to HV_RN_NoProt do
        begin
        sheet.cells[GB_RW_DescriptCol,currRow]:= GetHV_VaccVarNames(v);
        inc(currRow);
          for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          begin
            sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[s, r, v,t];
          end;
        inc(currRow);
        end;
      end;
    end;
  end;

  procedure HV_MV_TNewInfections.Resize(action : byte; finalIndex : integer);
  var
    t, i, j, m,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, HV_AllHIV + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for m := HV_Negative to HV_AllHIV do
              for t := oldIndex + 1 to finalIndex do
                value[i, j, m, t] := value[i, j, m, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TExitRate'}
  constructor HV_MV_TExitRate.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_ExitRate_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TExitRate.InitData;
  begin
    //
  end;

  procedure HV_MV_TExitRate.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    i, j,
    m, t : byte;
    t1, t2, t3 : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
    for i := HV_BothSexes to HV_Female - 1 do
          for j := HV_AllRisk to HV_MSMIDU - 1 do
            for m := HV_Primary to HV_CD4_LT50 - 1 do
              begin
                c := c1;
                for t := t1 to t2 do
                begin
                  value[i, j, m, t] := sheet.floats[c, currRow];
                  inc(c);
                end;
                for t := t2 + 1 to t3 do
                  value[i, j, m, t] := sheet.floats[c-1, currRow];
                Inc(currRow);
              end;
  end;

  procedure HV_MV_TExitRate.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, j,
    m, t : byte;
  begin
    for i := HV_BothSexes to HV_Female - 1 do
          for j := HV_AllRisk to HV_MSMIDU - 1 do
            for m := HV_Primary to HV_CD4_LT50 - 1 do
              begin
                for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
                  sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[i, j, m, t];
                Inc(currRow);
              end;
  end;

  procedure HV_MV_TExitRate.Resize(action : byte; finalIndex : integer);
  var
    t, i, j, m,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, HV_CD4_LT50 + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for m := HV_Primary to HV_CD4_LT50 do
              for t := oldIndex + 1 to finalIndex do
                value[i, j, m, t] := value[i, j, m, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TAIDSDeaths'}
  constructor HV_MV_TAIDSDeaths.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_AIDSDeaths_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TAIDSDeaths.InitData;
  begin
    //
  end;

  procedure HV_MV_TAIDSDeaths.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, v, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    (* AIDS Deaths by Risk Group *)
    for s := HV_Male to HV_Female do
    begin
    inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
      inc(currRow);
        for v := HV_RN_UnV to HV_RN_NoProt do
        begin
          inc(currRow);
          c := c1;
          for t := t1 to t2 do
          begin
            value[s, r, v, t] := sheet.floats[c, currRow];
            Inc(c);
          end;
          for t := t2 + 1 to t3 do
            value[s, r, v, t] := sheet.floats[c - 1, currRow];
          inc(currRow);
        end;
      end;
    end;
  end;

  procedure HV_MV_TAIDSDeaths.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r,v,t : byte;
  begin
    for s := HV_Male to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_DescriptCol,currRow]:=GetHV_RiskVarNames(r);
        inc(currRow);
        for v := HV_RN_UnV to HV_RN_NoProt do
        begin
          sheet.cells[GB_RW_DescriptCol,currRow]:= GetHV_VaccVarNames(v);
          inc(currRow);
          for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          begin
            sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[s, r, v, t];
          end;
          inc(currRow);
        end;
      end;
    end;
  end;

  procedure HV_MV_TAIDSDeaths.Resize(action : byte; finalIndex : integer);
  var
    t, i, j, m,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, HV_RN_NoProt + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for m := HV_RN_AllVacc to HV_RN_NoProt do
              for t := oldIndex + 1 to finalIndex do
                value[i, j, m, t] := value[i, j, m, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TAIDSDeathsART'}
  constructor HV_MV_TAIDSDeathsART.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_AIDSDeathsART_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TAIDSDeathsART.InitData;
  var
    s, r, t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
      for r := HV_AllRisk to HV_MSMIDU do
        for t := HV_min_year to length(value[s, r]) - 1 do
          value[s,r,t] := 0.0;
  end;

  procedure HV_MV_TAIDSDeathsART.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    for s := HV_BothSexes to HV_Female do
      for r := HV_AllRisk to HV_MSMIDU do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, r, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TAIDSDeathsART.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
 var
   s,r,t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1, currRow] :=  GetHV_SexNames(s);
      for r := HV_AllRisk to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_DescriptCol + 1, currRow] := GetHV_RiskVarNames(r);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow] := value[s, r, t];
        Inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TAIDSDeathsART.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTotalAIDSDeaths'}
  constructor HV_MV_TTotalAIDSDeaths.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_TotalAIDSDeaths_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TTotalAIDSDeaths.InitData;
  begin
    //
  end;

  procedure HV_MV_TTotalAIDSDeaths.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TTotalAIDSDeaths.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    sheet.cells[GB_RW_DescriptCol+1,currRow]:= 'Total AIDS Deaths';
    inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:=  value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TTotalAIDSDeaths.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTotalNewInfection'}
  constructor HV_MV_TTotalNewInfection.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_TotalNewInfection_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TTotalNewInfection.InitData;
  begin
    //
  end;

  procedure HV_MV_TTotalNewInfection.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1,
    t2, t3    : byte;
    c, c1     : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TTotalNewInfection.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    sheet.cells[GB_RW_DescriptCol+1,currRow]:= 'Total New Infections';
    inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TTotalNewInfection.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TIncidence'}
  constructor HV_MV_TIncidence.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_Incidence_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TIncidence.InitData;
  begin
    //
  end;

  procedure HV_MV_TIncidence.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TIncidence.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    sheet.cells[GB_RW_DescriptCol+1,currRow]:= 'Incidence';
    inc(currRow);
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    inc(currRow);
  end;

  procedure HV_MV_TIncidence.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TIncSexRatio'}
  constructor HV_MV_TIncSexRatio.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_IncSexRatio_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TIncSexRatio.InitData;
  begin
    //
  end;

  procedure HV_MV_TIncSexRatio.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1,
    t2, t3     : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
      c := c1;
      for t := t1 to t2 do
      begin
        value[t] := sheet.floats[c, currRow];
        inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[t] := sheet.floats[c-1, currRow];
      Inc(currRow);
  end;

  procedure HV_MV_TIncSexRatio.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[t];
      Inc(currRow);
  end;

  procedure HV_MV_TIncSexRatio.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TPercentPop'}
  constructor HV_MV_TPercentPop.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_PercentPop_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TPercentPop.InitData;
  begin
    //
  end;

  procedure HV_MV_TPercentPop.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

        (* Percent of Population *)
    for s := HV_Male to HV_Female do
    begin
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        value[s, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[s, t] := sheet.floats[c - 1, currRow];
      inc(currRow);
    end;
  end;

  procedure HV_MV_TPercentPop.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,t : byte;
  begin
    (* Percent of Population *)
    for s := HV_Male to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:= GetHV_SexNames(s);
      inc(currRow);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
      begin
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:=  value[s, t];
      end;
      inc(currRow);
    end;
  end;

  procedure HV_MV_TPercentPop.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TInfectionsAverted'}
  constructor HV_MV_TInfectionsAverted.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_InfectionsAverted_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TInfectionsAverted.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
      value[t] := 0;
  end;

  procedure HV_MV_TInfectionsAverted.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TInfectionsAverted.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TInfectionsAverted.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCumInfectionsAverted'}
  constructor HV_MV_TCumInfectionsAverted.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_CumInfectionsAverted_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TCumInfectionsAverted.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
      value[t] := 0;
  end;

  procedure HV_MV_TCumInfectionsAverted.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TCumInfectionsAverted.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TCumInfectionsAverted.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TDeathsAverted'}
  constructor HV_MV_TDeathsAverted.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_DeathsAverted_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TDeathsAverted.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
      value[t] := 0;
  end;

  procedure HV_MV_TDeathsAverted.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TDeathsAverted.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TDeathsAverted.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TCumDeathsAverted'}
  constructor HV_MV_TCumDeathsAverted.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_CumDeathsAverted_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TCumDeathsAverted.InitData;
  var
    t : byte;
  begin
    for t := HV_min_year to length(value) - 1 do
      value[t] := 0;
  end;

  procedure HV_MV_TCumDeathsAverted.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;
    for t := t2 + 1 to t3 do
      value[t] := sheet.floats[c - 1, currRow];
    inc(currRow);
  end;

  procedure HV_MV_TCumDeathsAverted.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
    begin
      sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[t];
    end;
    inc(currRow);
  end;

  procedure HV_MV_TCumDeathsAverted.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TARTCoverageByRG'}
  constructor HV_MV_TARTCoverageByRG.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_ARTCoverageByRG_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TARTCoverageByRG.InitData;
  var
    s, r, t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
      for r := HV_None to HV_MSMIDU do
        for t := HV_Min_Year to length(value[s, r]) - 1 do
          value[s,r,t] := 0.0;
  end;

  procedure HV_MV_TARTCoverageByRG.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    for s := HV_BothSexes to HV_Female do
      for r := HV_None to HV_MSMIDU do
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, r, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
  end;

  procedure HV_MV_TARTCoverageByRG.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r,t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1, currRow] :=  GetHV_SexNames(s);
      for r := HV_None to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_DescriptCol + 1, currRow] := GetHV_RiskVarNames(r);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow] := value[s, r, t];
        Inc(currRow);
      end;
    end;
  end;

  procedure HV_MV_TARTCoverageByRG.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TTotalARTCoverage'}
  constructor HV_MV_TTotalARTCoverage.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_TotalARTCoverage_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_RW_ImportData, MV_RW_ExtendFinalYr, MV_ResultVariable];

    InitData;
  end;

  procedure HV_MV_TTotalARTCoverage.InitData;
  var
    s, t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
      for t := HV_Min_Year to length(value[s]) - 1 do
        value[s,t] := 0.0;

  end;

  procedure HV_MV_TTotalARTCoverage.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    s, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

    for s := HV_BothSexes to HV_Female do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[s, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[s, t] := sheet.floats[c - 1, currRow];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TTotalARTCoverage.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,t : byte;
  begin
    for s := HV_BothSexes to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1, currRow] :=  GetHV_SexNames(s);
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
        sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow] := value[s, t];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TTotalARTCoverage.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TNewHIV'}
  constructor HV_MV_TNewHIV.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := HV_TG_NewHIV_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_HV, MV_ResultVariable, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure HV_MV_TNewHIV.InitData;
  begin
    //
  end;

  procedure HV_MV_TNewHIV.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);
  var
    i, t : byte;
    t1, t2, t3 : byte;
    c, c1      : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);
   // for i := 0 to HV_max_services-1 do
   for i := HV_BothSexes to HV_Female do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[i, t] := sheet.floats[c, currRow];
        inc(c);
      end;
      for t := t2 + 1 to t3 do
        value[i, t] := sheet.floats[c-1, currRow];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TNewHIV.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, t : byte;
  begin
    //for i := 0 to HV_max_services-1 do
    for i := HV_BothSexes to HV_Female do
    begin
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p)do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := value[i, t];
      Inc(currRow);
    end;
  end;

  procedure HV_MV_TNewHIV.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, HV_Female + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to HV_Female do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

{$ENDREGION}

{$REGION 'HV_MV_TlowRiskCondomUseFromFP'}
  constructor HV_MV_TlowRiskCondomUseFromFP.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_lowRiskCondomUseFromFP_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable, MV_RW_ImportData, MV_Extractable];

    InitData;
  end;

  procedure HV_MV_TlowRiskCondomUseFromFP.InitData;
  begin
    //
  end;

  procedure HV_MV_TlowRiskCondomUseFromFP.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := boolean(sheet.ints[GB_RW_DataStartCol, currRow]);
    Inc(currRow);
  end;

  procedure HV_MV_TlowRiskCondomUseFromFP.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := byte(value);
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'HV_MV_TFitData'}
  constructor HV_MV_TFitData.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_FitData_MV2;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_InputVariable, MV_RW_ImportData];

    InitData;
  end;

  procedure HV_MV_TFitData.InitData;
  begin
    SetLength(vValue, 1);
  end;

  procedure HV_MV_TFitData.Read(p : byte; tag : string; sheet : GB_TFile; var currRow : integer;
    actionRW : byte; var firstYr, finalYr : integer);

    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      i, count : integer;
    begin

      count := sheet.ints[GB_RW_NotesCol, currRow];
      setLength(vValue, count);
      for i := 0 to count-1 do
      begin
        inc(currRow);

        vValue[i].pop     := sheet.ints[1, currRow];
        vValue[i].sex     := sheet.ints[2, currRow];
        vValue[i].year    := sheet.ints[3, currRow];
        vValue[i].value   := sheet.floats[4, currRow];
        vValue[i].lower   := sheet.floats[5, currRow];
        vValue[i].upper   := sheet.floats[6, currRow];
        vValue[i].ssize   := sheet.floats[7, currRow];
        vValue[i].use     := boolean(sheet.ints[8, currRow]);
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      i, count : integer;
    begin

      count := sheet.ints[GB_RW_NotesCol, currRow];
      setLength(vValue, count);
      for i := 0 to count-1 do
      begin
        inc(currRow);

        vValue[i].pop     := sheet.ints[1, currRow];
        vValue[i].sex     := sheet.ints[2, currRow];
        vValue[i].year    := sheet.ints[3, currRow];
        vValue[i].value   := sheet.floats[4, currRow];
        vValue[i].lower   := sheet.floats[5, currRow];
        vValue[i].upper   := sheet.floats[6, currRow];
        vValue[i].ssize   := sheet.floats[7, currRow];
        vValue[i].use     := boolean(sheet.ints[8, currRow]);
        vValue[i].source  := sheet.cells[9, currRow];
      end;
    end;

  begin
    if tag = HV_TG_FitData_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = HV_TG_FitData_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure HV_MV_TFitData.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, count : integer;
  begin

    count := length(vValue);
    sheet.ints[GB_RW_NotesCol, currRow] := count;

    for i := 0 to count-1 do
    begin
      inc(currRow);

      sheet.ints[1, currRow]   := vValue[i].pop;
      sheet.ints[2, currRow]   := vValue[i].sex;
      sheet.ints[3, currRow]   := vValue[i].year;
      sheet.floats[4, currRow] := vValue[i].value;
      sheet.floats[5, currRow] := vValue[i].lower;
      sheet.floats[6, currRow] := vValue[i].upper;
      sheet.floats[7, currRow] := vValue[i].ssize;
      sheet.ints[8, currRow]   := byte(vValue[i].use);
      sheet.cells[9, currRow]  := vValue[i].source;
    end;
  end;

  function HV_MV_TFitData.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = HV_TG_FitData_MV) or (tag = HV_TG_FitData_MV2) then
      result := true;
  end;

  procedure HV_MV_TFitData.ResizeArray(count : integer);
  begin
    setLength(vValue, count);
  end;
{$ENDREGION}

{$REGION 'HV_MV_TFitParamSet'}
  constructor HV_MV_TFitParamSet.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_FitParamSet_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_InputVariable, MV_RW_ImportData];

    InitData;
  end;

  procedure HV_MV_TFitParamSet.InitData;
    procedure InitParamRecord(const index, prior : byte; const mu, sd : double);
    begin
      vValue[index].prior  := prior;
      vValue[index].init   := mu;
      vValue[index].mu     := mu;
      vValue[index].sd     := sd;
      vValue[index].value  := 0.0;
      vValue[index].use    := FALSE;
      vValue[index].fitted := FALSE;
    end;
  begin
    { Prior distributions on Goals inputs are specified via their means and
      standard deviations. The natural parameters of the priors, e.g. Gamma
      distribution shape and scale parameters, are calculated automatically.
      Generally, we use Beta for probabilities (transmission), Gamma for
      non-negative real values (e.g., partner change rates), and Normal for
      inputs that can be positive or negative. }

    // Epidemiological parameters
    InitParamRecord(HV_FitTransmitBase, HV_PriorBeta,   0.00118, 0.00040);
    InitParamRecord(HV_FitTransmitMtoF, HV_PriorGamma,  1.8,     0.3);
    InitParamRecord(HV_FitTransmitSTI,  HV_PriorGamma, 10.0,     2.0);
    InitParamRecord(HV_FitTransmitMSM,  HV_PriorGamma,  1.6,     1.0);

    InitParamRecord(HV_FitStageDurPrimary,      HV_PriorGamma, 3.0,  0.5);
    InitParamRecord(HV_FitStageInfPrimary,      HV_PriorGamma, 9.2, 10.0);
    InitParamRecord(HV_FitStageInfSymptomatic,  HV_PriorGamma, 7.3,  1.0);

    InitParamRecord(HV_FitInitialPulse, HV_PriorBeta, 0.0031, 0.001);

    // Behavioral parameters
    { Coital frequency in LRH based on analysis done by Kristin Bietsch
      2017-06-29: average annual coital frequency from DHS, derived from time
      since last sex among respondents who reported having sex in the last month }
    InitParamRecord(HV_FitCoitalFreqLRH, HV_PriorGamma, 67.0, 14.0);
    InitParamRecord(HV_FitCoitalFreqMRH, HV_PriorGamma, 67.0/3.0, 14.0/3.0); // arbitrary - assume same acts/year as LRH, but distributed across 3 partners
    InitParamRecord(HV_FitCoitalFreqHRH, HV_PriorGamma, 2.0, 2.0); // arbitrary
    InitParamRecord(HV_FitCoitalFreqMSM, HV_PriorGamma, 67.0/3.0, 14.0/3.0); // arbitrary - assume same as MRH

    InitParamRecord(HV_FitNeedleSharing, HV_PriorBeta, 0.5, 1.0 / 12.0); // noninformative - uniform distribution

    InitParamRecord(HV_FitSTIGrowthRate,         HV_PriorGamma,   0.34, 0.25);
    InitParamRecord(HV_FitSTIGrowthLocation,     HV_PriorGamma,   0.28, 0.25);
    InitParamRecord(HV_FitSTIYearstoFinalValue,  HV_PriorNormal, 27.57, 2.80);
  end;

  procedure HV_MV_TFitParamSet.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    i, index, count : integer;
  begin
    inc(currRow);
    count := Min(sheet.ints[GB_RW_NotesCol, currRow], HV_MaxFitParams);
    inc(currRow);
    for i := 0 to count-1 do
    begin
      inc(currRow);
      index                 := sheet.ints[1, currRow];
      vValue[index].prior   := sheet.ints[2, currRow];
      vValue[index].init    := sheet.floats[3, currRow];
      vValue[index].mu      := sheet.floats[4, currRow];
      vValue[index].sd      := sheet.floats[5, currRow];
      vValue[index].value   := sheet.floats[6, currRow];
      vValue[index].use     := boolean(sheet.ints[7, currRow]);
      vValue[index].fitted  := boolean(sheet.ints[8, currRow]);
    end;
  end;

  procedure HV_MV_TFitParamSet.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    i, count : integer;
  begin
    inc(currRow);
    count := length(vValue);
    sheet.ints[GB_RW_NotesCol, currRow] := count;
    inc(currRow);

    for i := 0 to HV_MaxFitParams do
    begin
      inc(currRow);
      sheet.ints[1, currRow]    := i;
      sheet.ints[2, currRow]    := vValue[i].prior;
      sheet.floats[3, currRow]  := vValue[i].init;
      sheet.floats[4, currRow]  := vValue[i].mu;
      sheet.floats[5, currRow]  := vValue[i].sd;
      sheet.floats[6, currRow]  := vValue[i].value;
      sheet.ints[7, currRow]    := byte(vValue[i].use);
      sheet.ints[8, currRow]    := byte(vValue[i].fitted);
    end;
    inc(currRow);
  end;

  procedure HV_MV_TFitParamSet.Resize(action : byte; finalIndex : integer);
  begin
    setLength(vValue, HV_MaxFitParams + 1);
  end;
{$ENDREGION}

{$REGION 'HV_MV_TFitControl'}
  constructor HV_MV_TFitControl.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_FitControl_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_InputVariable, MV_RW_ImportData];

    InitData;
  end;

  procedure HV_MV_TFitControl.InitData;
  begin
    vValue.MaxIterations := 1000;
    vValue.ErrorTolerance := 0.1;
    vValue.PrevWeight := 100;
  end;

  procedure HV_MV_TFitControl.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
      inc(currRow);
      vValue.MaxIterations    := sheet.ints[1, currRow];
      vValue.ErrorTolerance   := sheet.floats[2, currRow];
      vValue.PrevWeight       := sheet.ints[3, currRow];
      inc(currRow);
  end;

  procedure HV_MV_TFitControl.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    inc(currRow);
    sheet.ints[1, currRow]    := vValue.MaxIterations;
    sheet.floats[2, currRow]  := vValue.ErrorTolerance;
    sheet.ints[3, currRow]    := vValue.PrevWeight;
    inc(currRow);
  end;
{$ENDREGION}


{$REGION 'HV_MV_TedFmHighlight'}
  constructor HV_MV_TedFmHighlight.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_edFmHighlight_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];

    InitData;
  end;

  procedure HV_MV_TedFmHighlight.InitData;
  begin
    value := HV_ConfigBtn;
  end;

  procedure HV_MV_TedFmHighlight.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure HV_MV_TedFmHighlight.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow]:= value;
    inc(currRow);
  end;

{$ENDREGION}


{$REGION 'HV_MV_TARTInputCoverageByRG'}
  constructor HV_MV_TARTInputCoverageByRG.Create(aOwner: GB_TXXData);
  begin
    inherited Create(aOwner);

    tag := HV_TG_ARTInputCoverageByRG_MV;
    stringID := GB_stNull;
    FlagSet := FlagSet + [MV_HV, MV_InputVariable];
  end;




  procedure HV_MV_TARTInputCoverageByRG.Read(p : byte; tag : string; sheet : GB_TFile;
    var currRow : integer; actionRW : byte; var firstYr, finalYr : integer);
  var
    s, r, t, t1, t2, t3 : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(p), firstYr, finalYr,
      GB_RW_DataStartCol, t1, t2, t3, c1);

   (* New Vaccinations *)
    for s := HV_Male to HV_Female do
    begin
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
        inc(currRow);
        c := c1;
        for t := t1 to t2 do
        begin
          value[s, r, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
        for t := t2 + 1 to t3 do
          value[s, r, t] := sheet.floats[c - 1, currRow];
        inc(currRow);
      end;
    end;
    inc(currRow);
  end;

  procedure HV_MV_TARTInputCoverageByRG.Write(p : byte; sheet : GB_TFile;
    var currRow : integer; actionRW : byte);
  var
    s,r,t : byte;
  begin
    for s := HV_Male to HV_Female do
    begin
      sheet.cells[GB_RW_DescriptCol+1,currRow]:=  GetHV_SexNames(s);
      inc(currRow);
      for r := HV_None to HV_MSMIDU do
      begin
        sheet.cells[GB_RW_DescriptCol,currRow]:=  GetHV_RiskVarNames(r);
        inc(currRow);
        for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(p) do
          sheet.floats[GB_RW_DataStartCol+t-GetGBCalcYearIdx(p),currRow]:= value[s, r, t];
        inc(currRow);
      end;
    end;
    inc(currRow);
  end;

  procedure HV_MV_TARTInputCoverageByRG.Resize(action: byte; finalIndex: integer);
  var
    t, i, j,
    oldIndex    : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, HV_Female + 1, HV_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := HV_BothSexes to HV_Female do
          for j := HV_AllRisk to HV_MSMIDU do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

{$ENDREGION}


end.