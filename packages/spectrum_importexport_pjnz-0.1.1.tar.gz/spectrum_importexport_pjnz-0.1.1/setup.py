from setuptools import find_packages, setup


subpackages = [pkg for pkg in find_packages(where=".") if not pkg.startswith("Tools")]

packages = ["Tools", "Tools.ImportExportPJNZ"]
package_dir = {
    "Tools": "..",
    "Tools.ImportExportPJNZ": ".",
}

for package_name in subpackages:
    full_name = f"Tools.ImportExportPJNZ.{package_name}"
    packages.append(full_name)
    package_dir[full_name] = package_name.replace(".", "/")


setup(
    packages=packages,
    package_dir=package_dir,
    py_modules=["Tools.taskUtil", "Tools.ToolsSwitch", "Tools.__main__"],
    include_package_data=True,
)