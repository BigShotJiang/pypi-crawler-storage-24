
                      (* ______________________________
                       /                               \
                      /        General Variables        \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_ProjectionValid'}
  constructor RN_MV_ProjectionValid.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_ProjectionValid_MV2;
    stringID    := GB_stProjValid;
    //FlagSet   := FlagSet + [MV_InputVariable];

    InitData;
  end;

  procedure RN_MV_ProjectionValid.InitData;
  begin
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;


  procedure RN_MV_ProjectionValid.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    if actionRW <> MV_RW_ExtendFinalYr then
      Value := boolean(sheet.ints[GB_RW_DataStartCol, currRow]);
  end;

  procedure RN_MV_ProjectionValid.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
     (* Write a note *)
    if value then
      sheet.cells[GB_RW_NotesCol, currRow] := 'yes'
    else
      sheet.cells[GB_RW_NotesCol, currRow] := 'no';

    (* Write the data. *)
    sheet.ints[GB_RW_DataStartCol, currRow] := byte(Value);
    inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_ProjectionValidDate'}
  constructor RN_MV_ProjectionValidDate.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ProjectionValidDate_MV;
    stringID := GB_stProjectionValidDate_MV;
    FlagSet  := FlagSet + [];

    InitData;
  end;

  procedure RN_MV_ProjectionValidDate.InitData;
  begin
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;


  procedure RN_MV_ProjectionValidDate.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    Value := sheet.cells[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_ProjectionValidDate.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.cells[GB_RW_DataStartCol, currRow] := Value;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_DataSource'}
  constructor RN_MV_DataSource.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    SetLength(value, RN_NUM_EDITORS + 1);
    tag         := RN_TG_DataSource_MV;
    stringID    := GB_stDataSource2;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  destructor RN_MV_DataSource.Destroy;
  var
    i : byte;
  begin
    inherited Destroy;

    for i := 0 to RN_NUM_EDITORS do
      value[i].Free;

    Setlength(value, 0);
  end;

  procedure RN_MV_DataSource.InitData;
  var
  i : byte;
  begin
    (* Value *)
    for i := 0 to RN_NUM_EDITORS do
    begin
      value[i] := TStringList.Create;
      value[i].sorted := false;
      value[i].add('Test');
    end;

    (* Dynamic Arrays *)
    SetMin(0);
    SetMax(99.99);
    SetLDec(3);
    SetRDec(3);

    SetSource('');
  end;

  procedure RN_MV_DataSource.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    i             : integer;
    SList         : TStringList;
  begin
//    GetGBYearAndColIndices(actionRW, GetGBFinalIdx(GetProj), firstYr, finalYr,
//      GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    (* Data Source for editors *)
    SList := TStringList.Create;
    SList.Sorted := false;

    for i := 1 to sheet.ints[GB_RW_DataStartCol, currRow] do
      SList.Add(sheet.cells[GB_RW_DataStartCol + i, currRow]);

    value[1].Assign(SList) ;
    SList.Free;
    Inc(currRow);
  end;

  procedure RN_MV_DataSource.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    l: integer;
    SList: TStringList;
  begin
    SList := TStringList.Create;
    SList.Sorted := false;
     SList.Assign(value[1]);
    sheet.ints[GB_RW_DataStartCol, currRow] := SList.Count;
    for l := 0 to SList.Count - 1 do
      sheet.cells[GB_RW_DataStartCol + l + 1, currRow] := SList.Strings[l];
    Inc(currRow);
    SList.Free;
  end;

//
//  procedure RN_MV_DataSource.WriteJson(var jo:TJSONObject);
//  var
//    val       : TJSonValue;
//    jsonArray : TJsonArray;
//    strArray  : TJsonArray;
//    i         : integer;
//    s         : string;
//  begin
////    GB_AddJSONPair(jo, 'tag', tag);
//    inherited WriteJson(jo);
//
////    jsonArray := TJsonArray.Create;
////    for i := 0 to length(value)-1 do
////    begin
////      strArray := TJsonArray.Create;
////      for s in value[i] do
////      begin
////        val := GB_GetJSONValue(s);
////        strArray.addElement(val);
////      end;
////      jsonArray.addElement(strArray);
////    end;
////    jo.RemovePair('value');
////    GB_AddJSONPair(jo, 'value', jsonArray);
//  end;
//
//  procedure RN_MV_DataSource.ReadJson(var jo:TJSONObject);
//  var
//    jsonArray : TJsonArray;
//    strArray  : TJsonArray;
//    i,s       : integer;
//    str       : string;
//  begin
//    jsonArray := nil;
//    jsonArray := GB_FindJSONPairArr(jo, 'value', jsonArray);
//    for i := 0 to jsonArray.Count-1 do
//    begin
//      strArray := TJsonArray(jsonArray.items[i]);
//      value[i].Clear;
//      for s := 0 to strArray.Count-1 do
//      begin
//        str := strArray.items[s].ToString;
//        str := StringReplace(str,'"','',[rfReplaceAll]);
//        value[i].Add(str);
//      end;
//    end;
//  end;
{$ENDREGION}

{$REGION 'RN_MV_TVariablesRW'}
  constructor RN_MV_TVariablesRW.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_VariablesRW_MV;
    stringID    := GB_stVariablesRW;
    FlagSet     := FlagSet + [MV_RW_ImportData];

    RN_MaxPSConstantsRW   := RN_PS_MaxProgramSupport;
    RN_MaxPOPConstantsRW  := RN_POP_MaxPopulations;
    RN_MaxInterventionsRW := RN_MaxInterventions;
    RN_MaxSummaryTableRW  := RN_ST_MaxSummaryTable;
  end;

  procedure RN_MV_TVariablesRW.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr : Integer);
  var
    tag2 : string;

    procedure ReadMaxCOVConstants(p: byte; sheet: GB_TFile;
      var currRow: integer);
    begin
      (* 6/15/15 This is not being used? *)
      Inc(currRow); // description line
      RN_MaxCOVConstantsRW := sheet.ints[GB_RW_DataStartCol, currRow];
    end;

    procedure ReadMaxInterventions(p: byte;
      sheet: GB_TFile; var currRow: integer);
    begin
      Inc(currRow); // description line
      RN_MaxInterventionsRW := sheet.ints[GB_RW_DataStartCol, currRow];
    end;

    procedure ReadMaxPOPConstants(p: byte; sheet: GB_TFile;
      var currRow: integer);
    begin
      Inc(currRow); // description line
      RN_MaxPOPConstantsRW := sheet.ints[GB_RW_DataStartCol, currRow];
    end;

    procedure ReadMaxPSConstants(p: byte; sheet: GB_TFile;
      var currRow: integer);
    begin
      Inc(currRow); // description line
      RN_MaxPSConstantsRW := sheet.ints[GB_RW_DataStartCol, currRow];
    end;

    procedure ReadMaxSummaryTableConstants(p: byte;
    sheet: GB_TFile; var currRow: integer);
    begin
      Inc(currRow); // description line
      RN_MaxSummaryTableRW := sheet.ints[GB_RW_DataStartCol, currRow];
    end;

    procedure ReadMaxInterventionsConstant(p: byte; sheet: GB_TFile;
      var currRow: integer);
    begin
      RN_MaxInterventionsRW := sheet.ints[GB_RW_DataStartCol, currRow];
      Inc(currRow);
    end;

  begin
    while not(sheet.cells[GB_RW_DescriptCol, currRow] = GB_TG_End) do
    begin
      tag2 := sheet.cells[GB_RW_DescriptCol, currRow];
      inc(currRow);

      if      tag2 = RN_TG_MaxInterventions_MV         then ReadMaxInterventions(p, sheet, currRow)
      else if tag2 = RN_TG_MaxPOPConstants_MV          then ReadMaxPOPConstants(p, sheet, currRow)
      else if tag2 = RN_TG_MaxPSConstants_MV           then ReadMaxPSConstants(p, sheet, currRow)
      else if tag2 = RN_TG_MaxSummaryTableConstants_MV then ReadMaxSummaryTableConstants(p, sheet, currRow)
      else if tag2 = RN_TG_MaxInterventions_MV         then ReadMaxInterventionsConstant(p, sheet, currRow);
    end;
    inc(currRow);
  end;

  procedure RN_MV_TVariablesRW.Write(p: byte; sheet: GB_TFile; var currRow: integer; actionRW: byte);
    procedure WriteMaxInterventions(p: byte; sheet: GB_TFile; var currRow: integer);
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := RN_TG_MaxInterventions_MV;
      Inc(currRow);

      (* Write Number COV Constants *)
      sheet.cells[GB_RW_NotesCol, currRow] := 'Number of Interventions';
      Inc(currRow);
      sheet.ints[GB_RW_DataStartCol, currRow] := RN_MaxInterventions;
      Inc(currRow);
    end;
    procedure WriteMaxPOPConstants(p: byte; sheet: GB_TFile; var currRow: integer);
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := RN_TG_MaxPOPConstants_MV;
      Inc(currRow);

      (* Write Number POP Constants *)
      sheet.cells[GB_RW_NotesCol, currRow] := 'Number of Population Sizes constants';
      Inc(currRow);
      sheet.ints[GB_RW_DataStartCol, currRow] := RN_POP_MaxPopulations;
      Inc(currRow);
    end;
    procedure WriteMaxPSConstants(p: byte; sheet: GB_TFile; var currRow: integer);
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := RN_TG_MaxPSConstants_MV;
      Inc(currRow);

      (* Write Number PS Constants *)
      sheet.cells[GB_RW_NotesCol, currRow] := 'Number of Program Support constants';
      Inc(currRow);
      sheet.ints[GB_RW_DataStartCol, currRow] := RN_PS_MaxProgramSupport;
      Inc(currRow);
    end;
    procedure WriteMaxSummaryTableConstants(p: byte; sheet: GB_TFile; var currRow: integer);
    begin
      sheet.cells[GB_RW_DescriptCol, currRow] := RN_TG_MaxSummaryTableConstants_MV;
      Inc(currRow);

      (* Write Number COV Constants *)
      sheet.cells[GB_RW_NotesCol, currRow] := 'Number of Summary Table constants';
      Inc(currRow);
      sheet.ints[GB_RW_DataStartCol, currRow] := RN_ST_MaxSummaryTable;
      Inc(currRow);
    end;
    procedure WriteMaxInterventionsConstant(p: byte; sheet: GB_TFile;
      var currRow: integer);
    begin
      sheet.ints[GB_RW_DataStartCol, currRow] := RN_MaxInterventions;
      Inc(currRow);
    end;

  begin
    Inc(currRow);
    WriteMaxInterventions(p, sheet, currRow);
    WriteMaxPOPConstants(p, sheet, currRow);
    WriteMaxPSConstants(p, sheet, currRow);
    WriteMaxSummaryTableConstants(p, sheet, currRow);
    WriteMaxInterventionsConstant(p, sheet, currRow);

    (* This variable needs a stop tag *)
    sheet.Cells[GB_RW_DescriptCol, currRow] := GB_TG_End;
    inc(currRow);
  end;

{$ENDREGION}

                      (* ______________________________
                       /                               \
                      /          Configuration          \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_FirstYearOfEstimates'}
  constructor RN_MV_FirstYearOfEstimates.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_FirstYearOfEstimates_MV;
    stringID    := GB_stFirstYearOfEstimates;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_FirstYearOfEstimates.InitData;
  begin
    (* Value *)
    value := CurrentYear;

    (* Dynamic Arrays *)
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_FirstYearOfEstimates.Read(p: byte; tag : string; sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    Value := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_FirstYearOfEstimates.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.Ints[GB_RW_DataStartCol, currRow] := Value;
    Inc(currRow);
  end;

  procedure RN_MV_FirstYearOfEstimates.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_LastYearOfEstimates'}
  constructor RN_MV_LastYearOfEstimates.Create(aOwner : GB_TXXData; FinalYr: integer);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_LastYearOfEstimates_MV;
    stringID    := GB_stLastYearOfEstimates;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData(FinalYr);
  end;

  procedure RN_MV_LastYearOfEstimates.InitData(FinalYr: integer);
  begin
    (* Value *)
    value := FinalYr;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_LastYearOfEstimates.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
//    SetRNLastYearOfEstimates(P,sheet.Ints[GB_RW_DataStartCol, currRow]);
//    Inc(currRow);
  end;

  procedure RN_MV_LastYearOfEstimates.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
//    sheet.Ints[GB_RW_DataStartCol, currRow] := GetRNLastYearOfEstimates(p);
//    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_FirstYearOfEstimatesCBIdx'}
  constructor RN_MV_FirstYearOfEstimatesCBIdx.Create(aOwner : GB_TXXData; FirstYr: integer);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_FirstYearOfEstimatesCBIdx_MV;
    stringID    := GB_stFirstYearOfEstimates;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData(FirstYr);
  end;

  procedure RN_MV_FirstYearOfEstimatesCBIdx.InitData(FirstYr: integer);
  begin
    (* Value *)
    if CurrentYear - FirstYr > 0 then
      value := CurrentYear - FirstYr
    else
      value := 0;

    (* Dynamic Arrays *)
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_FirstYearOfEstimatesCBIdx.Read(p: byte; tag : string; sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    Value := GetGBAdjustedYearIdxRW(p, sheet.Ints[GB_RW_DataStartCol, currRow]);
    Inc(currRow);
  end;

  procedure RN_MV_FirstYearOfEstimatesCBIdx.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.Ints[GB_RW_DataStartCol, currRow] := Value;
    Inc(currRow);
  end;

  procedure RN_MV_FirstYearOfEstimatesCBIdx.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i         : integer;
    valueNum  : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_LastYearOfEstimatesCBIdx'}
  constructor RN_MV_LastYearOfEstimatesCBIdx.Create(aOwner : GB_TXXData; FinalYr: integer);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_LastYearOfEstimatesCBIdx_MV;
    stringID    := GB_stLastYearOfEstimates;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData(FinalYr);
  end;

  procedure RN_MV_LastYearOfEstimatesCBIdx.InitData(FinalYr: integer);
  begin
    (* Value *)
    value := FinalYr - CurrentYear;

    (* Dynamic Arrays *)
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;


  procedure RN_MV_LastYearOfEstimatesCBIdx.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
//    SetRNLastYearOfEstimatesCBIdx(P,sheet.Ints[GB_RW_DataStartCol, currRow]);
//    Inc(currRow);
  end;

  procedure RN_MV_LastYearOfEstimatesCBIdx.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
//    sheet.Ints[GB_RW_DataStartCol, currRow] := GetRNLastYearOfEstimatesCBIdx(p);
//    Inc(currRow);
  end;

  procedure RN_MV_LastYearOfEstimates.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

  procedure RN_MV_LastYearOfEstimatesCBIdx.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

                      (* ______________________________
                       /                               \
                      /         Population Sizes        \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_PopulationSizes'}
  constructor RN_MV_PopulationSizes.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_PopulationSizes_MV2;
    stringID    := GB_stPopSizes;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    SetLengthDynArrays(1, RN_POP_MaxPopulations + 1);

    InitData;
  end;

  procedure RN_MV_PopulationSizes.InitData;
  var
    r, t, i : byte;
  begin
    for i := 1 to RN_POP_MaxPopulations do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0.0;

    for r := 1 to RN_POP_MaxPopulations do
    begin
      case r of
        RN_POP_FormalSectorEmployees:
        begin
          SetMin(r,0);
          SetMax(999999999);
          SetLDec(r,9);
          SetRDec(r,2);
          SetSource(5,'');
        end;

        RN_POP_SexuallyActive15_49, RN_POP_Males15_49RegPartners,RN_POP_Males15_49NonRegPartners,
          RN_POP_CondomWastage,RN_POP_STIsSymptomaticMale, RN_POP_IDUOpiodDependent,
          RN_POP_STIsSymptomaticFemale, RN_POP_InjectionsUnsafe:
        begin
          SetMin(r,0);
          SetMax(r,100);
          SetLDec(r,3);
          SetRDec(r,1);
          SetSource(r,'');
        end;

        RN_POP_FemaleSexWorkers, RN_POP_MaleSexWorkers, RN_POP_MSM, RN_POP_IDU,
          RN_POP_NumInjectionsPerYear, RN_POP_NewCasesSTIsMale, RN_POP_NewCasesSTIsFemale:
        begin
          SetMin(r,0);
          SetMax(r,999999999);
          SetLDec(r,9);
          SetRDec(r,0);
          SetSource(r,'');
        end;

        RN_POP_BloodUnitsRequired, RN_POP_PEPKitsRequired, RN_POP_NumImmunChild0_23Mths,
          RN_POP_NumAdultInjections, RN_POP_HospitalBeds:
        begin
          SetMin(r,0);
          SetMax(r,999999999);
          SetLDec(r,9);
          SetRDec(r,1);
          SetSource(r,'');
        end

        else
        begin
          SetMin(r,0);
          SetMax(r,999);
          SetLDec(r,3);
          SetRDec(r,1);
          SetSource(r,'');
        end;
      end;
    end;
  end;

  destructor RN_MV_PopulationSizes.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

   procedure RN_MV_PopulationSizes.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);


    procedure Read1(p : byte; sheet: GB_TFile;
      var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
    var
      VariablesRW          : RN_MV_TVariablesRW;
      i, MstID, CurrID : integer;
      t                : byte;
    begin
      VariablesRW  := GetRNData(p).GetVariablesRWMV;
      //GetGBYearAndColIndices(actionRW, GetGBFinalIdx(GetProj), firstYr,
      //  finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

      Inc(currRow); // Skip header strings

      for i := 1 to VariablesRW.RN_MaxPOPConstantsRW do
      begin
        MstID := sheet.ints[GB_RW_DataStartCol, currRow];
        CurrID := GetRN_POPConstantCurrID(MstID);
          if (CurrID <> 0) then
            for t := 1 to GetGBFinalYearIdx(GetProj) do
              Value[i, t] := sheet.floats[GB_RW_DataStartCol+1, currRow];
        Inc(currRow);
      end;
    end;

    procedure Read2(p : byte; sheet: GB_TFile;
      var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
    var
      VariablesRW               : RN_MV_TVariablesRW;
      i, MstID, CurrID, c1, Col : integer;
      t, t1, t2, t3             : byte;
    begin
      VariablesRW  := GetRNData(p).GetVariablesRWMV;
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
        finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

      Inc(currRow); // Skip header strings

      for i := 1 to VariablesRW.RN_MaxPOPConstantsRW do
      begin
        MstID := sheet.ints[GB_RW_DataStartCol, currRow];
        CurrID := GetRN_POPConstantCurrID(MstID);
        Col := C1;
        if (CurrID <> 0) then
        begin
          for t := t1 to t2 do
          begin
            Value[i, t] := sheet.floats[Col, currRow];
            Inc(Col);
          end;
          for t := t2 + 1 to t3 do
            value[i, t] := sheet.floats[Col - 1, currRow];
        end;
        Inc(currRow);
      end;
    end;

   begin
    if tag = RN_TG_PopulationSizes_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = RN_TG_PopulationSizes_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure RN_MV_PopulationSizes.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : byte;
    Col  : integer;
  begin
    (* Header Strings *)
    sheet.cells[GB_RW_NotesCol, currRow] := 'Name';
    sheet.cells[GB_RW_DataStartCol, currRow] := 'Master ID';
    sheet.cells[GB_RW_DataStartCol + 1, currRow] := 'Size';
    Inc(currRow);

    (* Data *)
    for i := 1 to RN_POP_MaxPopulations do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_POPConstantString(i);
      sheet.ints[GB_RW_DataStartCol, currRow] := GetRN_POPConstantMstID(i);
      Col := GB_RW_DataStartCol +1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        sheet.floats[Col, currRow] := Value[i, t];
        Inc(Col);
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_PopulationSizes.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_POP_MaxPopulations + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_POP_MaxPopulations do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function RN_MV_PopulationSizes.GetString(i2 : integer) : string;
  begin
    result := '';

    case i2 of
      RN_POP_FemaleSexWorkers         : result := RS(GB_stFemaleSexWorkers);
      RN_POP_MaleSexWorkers           : result := RS(GB_stMaleSexWorkers);
      RN_POP_MSM                      : result := RS(GB_stMSM);
      RN_POP_IDU                      : result := RS(GB_stPeopleWhoInjectDrugs_PWID);
      RN_POP_IDUOpiodDependent        : result := RS(GB_stPWIDOpiodDependent);
      RN_POP_NumInjectionsPerYear     : result := RS(GB_stInjectionsPerYear);
      RN_POP_PrimarySchoolMale        : result := RS(GB_stPrimarySchoolGrossEnrollment) + ' ' + RS(GB_stMale);
      RN_POP_PrimarySchoolFemale      : result := RS(GB_stPrimarySchoolGrossEnrollment) + ' ' + RS(GB_stFemale);
      RN_POP_PrimaryPupilTeacher      : result := RS(GB_stPrimaryPupilTeacher);
      RN_POP_SecondarySchoolMale      : result := RS(GB_stSecondarySchoolGrossEnrollment) + ' ' + RS(GB_stMale);
      RN_POP_SecondarySchoolFemale    : result := RS(GB_stSecondarySchoolGrossEnrollment) + ' ' + RS(GB_stFemale);
      RN_POP_SecondaryPupilTeacher    : result := RS(GB_stSecondaryPupilTeacher);
      RN_POP_TeacherRetraining        : result := RS(GB_stTeacherRetraining);
      RN_POP_FormalSectorEmployees    : result := RS(GB_stWomenAndGirls15_24);
      RN_POP_SexuallyActive15_49      : result := RS(GB_st15_49SexuallyActive);
      RN_POP_Males15_49RegPartners    : result := RS(GB_st15_49MalesRegularPartner);
      RN_POP_Males15_49NonRegPartners : result := RS(GB_st15_49MalesNonRegularPartner);
      RN_POP_NumSexActsNonRegPartners : result := RS(GB_stSexActsCasualNonRegularPartners);
      RN_POP_NumSexActsRegPartners    : result := RS(GB_stSexActsRegularPartners);
      RN_POP_CommercialSexActsFSW     : result := RS(GB_stCommercialSexActsFSW);
      RN_POP_CommercialSexActsMSW     : result := RS(GB_stCommercialSexActsMSW);
      RN_POP_CondomWastage            : result := RS(GB_stCondomWastage);
      RN_POP_NewCasesSTIsMale         : result := RS(GB_stNewCasesTreatableSTIs) + ' ' + RS(GB_stMaleInc);
      RN_POP_NewCasesSTIsFemale       : result := RS(GB_stNewCasesTreatableSTIs) + ' ' + RS(GB_stFemaleInc);
      RN_POP_STIsSymptomaticMale      : result := RS(GB_stSTIsSymptomatic) + ' ' + RS(GB_stMale);
      RN_POP_STIsSymptomaticFemale    : result := RS(GB_stSTIsSymptomatic) + ' ' + RS(GB_stFemale);
      RN_POP_BloodUnitsRequired       : result := RS(GB_stBloodUnitsRequired);
      RN_POP_PEPKitsRequired          : result := RS(GB_stPEPKitsRequired);
      RN_POP_NumImmunChild0_23Mths    : result := RS(GB_stAveNumImmunizationsPerChild);
      RN_POP_NumAdultInjections       : result := RS(GB_stAdultInjections);
      RN_POP_InjectionsUnsafe         : result := RS(GB_stInjectionsUnsafe);
      RN_POP_HospitalBeds             : result := RS(GB_stHospitalBeds);
      RN_POP_AdultMalesCircum         : result := RS(GB_stAdultMalesCircum);
      RN_POP_Rapes                    : result := RS(GB_stRapesPer1000Pop);
    end;
  end;

  function RN_MV_PopulationSizes.GetExtractConfig(i : integer) : string;
  begin
    result := '';

    case i of
      RN_POP_FemaleSexWorkers         : result := RS(GB_stKeyPopulations);
      RN_POP_MaleSexWorkers           : result := RS(GB_stKeyPopulations);
      RN_POP_MSM                      : result := RS(GB_stKeyPopulations);
      RN_POP_IDU                      : result := RS(GB_stKeyPopulations);
      RN_POP_IDUOpiodDependent        : result := RS(GB_stKeyPopulations);
      RN_POP_NumInjectionsPerYear     : result := RS(GB_stKeyPopulations);

      RN_POP_PrimarySchoolMale        : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_POP_PrimarySchoolFemale      : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_POP_PrimaryPupilTeacher      : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_POP_SecondarySchoolMale      : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_POP_SecondarySchoolFemale    : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_POP_SecondaryPupilTeacher    : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_POP_TeacherRetraining        : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_POP_FormalSectorEmployees    : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stEconomicStrengthening);
      RN_POP_SexuallyActive15_49      : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_Males15_49RegPartners    : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_Males15_49NonRegPartners : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_NumSexActsNonRegPartners : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_NumSexActsRegPartners    : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_CommercialSexActsFSW     : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_CommercialSexActsMSW     : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_CondomWastage            : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_POP_Rapes                    : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stViolenceAgainstWomen);

      RN_POP_NewCasesSTIsMale         : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSTIManagement);
      RN_POP_NewCasesSTIsFemale       : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSTIManagement);
      RN_POP_STIsSymptomaticMale      : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSTIManagement);
      RN_POP_STIsSymptomaticFemale    : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSTIManagement);
      RN_POP_BloodUnitsRequired       : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stBloodSafety);
      RN_POP_PEPKitsRequired          : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stPostExposProphylaxis);

      RN_POP_NumImmunChild0_23Mths    : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSafeMedicalInject);
      RN_POP_NumAdultInjections       : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSafeMedicalInject);
      RN_POP_InjectionsUnsafe         : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSafeMedicalInject);
      RN_POP_HospitalBeds             : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSafeMedicalInject);

      RN_POP_AdultMalesCircum         : result := RS(GB_stAdultMalesCircum);

    end;
  end;

  procedure RN_MV_PopulationSizes.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, i          : byte;
    j,
    configTextIdx,
    col           : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 1 to RN_POP_MaxPopulations do
    begin
      projInfo[configTextIdx] := GetExtractConfig(i) + '; '+ GetString(i);
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i, t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

  function RN_MV_PopulationSizes.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = RN_TG_PopulationSizes_MV) or (tag = RN_TG_PopulationSizes_MV2) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UserGeneralPop'}
  constructor RN_MV_UserGeneralPopObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag      := RN_TG_UserGeneralPop_MV2;
    stringID := GB_stUserGeneralPop_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    SetLengthDynArrays(1, RN_Percent + 1);

    InitData;
  end;

  destructor RN_MV_UserGeneralPopObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_UserGeneralPopObjList.InitData;
  begin
    SetMin(RN_Number, 0);
    SetMax(RN_Number, Maxint);
    SetLDec(RN_Number, 9);
    SetRDec(RN_Number, 0);
    SetSource(RN_Number, '');

    SetMin(RN_Percent, 0);
    SetMax(RN_Percent, 100);
    SetLDec(RN_Percent, 3);
    SetRDec(RN_Percent, 1);
    SetSource(RN_Percent, '');
  end;

  procedure RN_MV_UserGeneralPopObjList.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3               : byte;
    t, c, c1,
    UserGeneralPopCount, i   : integer;
    UserGeneralPopObj        : RN_TUserGeneralPopObject;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    value.Clear;
    Inc(currRow);
    UserGeneralPopCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
    Inc(currRow);
    for i := 0 to UserGeneralPopCount -1 do
    begin
      UserGeneralPopObj := RN_TUserGeneralPopObject.Create(p);
      UserGeneralPopObj.UserGenPop := sheet.cells[GB_RW_DataStartCol, currRow];
      UserGeneralPopObj.PerNum := sheet.ints[GB_RW_DataStartCol + 1, currRow];
      UserGeneralPopObj.Value := sheet.floats[GB_RW_DataStartCol + 2, currRow];
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        UserGeneralPopObj.ResourcesRequired[t] := sheet.Floats[c, currRow];
        inc(c);
      end;
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        UserGeneralPopObj.NumberPeopleReached[t] := sheet.Floats[c, currRow];
        inc(c);
      end;
      value.Add(UserGeneralPopObj);
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserGeneralPopObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t, i : integer;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of User Entered General Populations';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of User Entered General Populations';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := RN_TUserGeneralPopObject(value.Items[i]).UserGenPop;
      sheet.cells[GB_RW_DataStartCol, currRow] := RN_TUserGeneralPopObject(value.Items[i]).UserGenPop;
      sheet.ints[GB_RW_DataStartCol + 1, currRow] := RN_TUserGeneralPopObject(value.Items[i]).PerNum;
      sheet.floats[GB_RW_DataStartCol + 2, currRow] := RN_TUserGeneralPopObject(value.Items[i]).Value;

      inc(currRow);
      sheet.cells[GB_RW_NotesCol, currRow] := 'Resources required';
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(GetProj) do
        sheet.Floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := RN_TUserGeneralPopObject(value.Items[i]).ResourcesRequired[t];

      inc(currRow);
      sheet.cells[GB_RW_NotesCol, currRow] := 'Number people reached';
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(GetProj) do
        sheet.Floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := RN_TUserGeneralPopObject(value.Items[i]).NumberPeopleReached[t];

      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserGeneralPopObjList.Resize(action : byte; finalIndex : integer);
  var
    i        : integer;
    t,
    oldIndex,
    newIndex : integer;
  begin
    if (action = GB_FINALYEAR_CHANGE)  and assigned(value) then
    begin
      for i := 0 to value.Count - 1 do
      begin
        oldIndex := MAX(0, Length(RN_TUserGeneralPopObject(value.Items[i]).ResourcesRequired) - 1); // choose one
        newIndex := finalIndex;

        SetLength(RN_TUserGeneralPopObject(value.Items[i]).ResourcesRequired, newIndex + 1);
        SetLength(RN_TUserGeneralPopObject(value.Items[i]).NumberPeopleReached, newIndex + 1);

        (* If extending, flatline the values from the final index. *)
        if oldIndex < newIndex then
          for t := oldIndex + 1 to newIndex do
          begin
            RN_TUserGeneralPopObject(value.Items[i]).ResourcesRequired[t] := RN_TUserGeneralPopObject(value.Items[i]).ResourcesRequired[t - 1];
            RN_TUserGeneralPopObject(value.Items[i]).NumberPeopleReached[t] := RN_TUserGeneralPopObject(value.Items[i]).NumberPeopleReached[t - 1];
          end;
       end;
    end;
  end;

  procedure RN_MV_UserGeneralPopObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    valueNum      : double;
    j,
    configTextIdx,
    col,
    t, i          : integer;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to GetRNData(GetProj).GetUserGeneralPopObjList.Count -1 do
    begin
      projInfo[configTextIdx] := RN_TUserGeneralPopObject(GetRNData(GetProj).GetUserGeneralPopObjList.Items[i]).UserGenPop +
        '; ' + Chr(RN_TUserGeneralPopObject(GetRNData(GetProj).GetUserGeneralPopObjList.Items[i]).PerNum);
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := RN_TUserGeneralPopObject(GetRNData(GetProj).GetUserGeneralPopObjList.Items[i]).Value;
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UserMostAtRiskPop'}
  constructor RN_MV_UserMostAtRiskPopObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag      := RN_TG_UserMostAtRiskPop_MV2;
    stringID := GB_stUserMostAtRiskPop_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    SetLengthDynArrays(1, RN_Percent + 1);

    InitData;
  end;

  destructor RN_MV_UserMostAtRiskPopObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_UserMostAtRiskPopObjList.InitData;
  begin
    SetMin(RN_Number, 0);
    SetMax(RN_Number, 999999999);
    SetLDec(RN_Number, 9);
    SetRDec(RN_Number, 0);
    SetSource(RN_Number, '');

    SetMin(RN_Percent, 0);
    SetMax(RN_Percent, 100);
    SetLDec(RN_Percent, 3);
    SetRDec(RN_Percent, 1);
    SetSource(RN_Percent, '');
  end;


  procedure RN_MV_UserMostAtRiskPopObjList.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3                  : byte;
    t, c, c1,
    UserMostAtRiskPopCount, i   : integer;
    UserMostAtRiskPopObj        : RN_TUserMostAtRiskPopObject;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    value.Clear;

    Inc(currRow);
    UserMostAtRiskPopCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
    Inc(currRow); // Skip Text
    for i := 0 to UserMostAtRiskPopCount -1 do
    begin
      UserMostAtRiskPopObj := RN_TUserMostAtRiskPopObject.Create(p);
      UserMostAtRiskPopObj.UserMARPop := sheet.cells[GB_RW_DataStartCol, currRow];
      UserMostAtRiskPopObj.PerNum := sheet.ints[GB_RW_DataStartCol + 1, currRow];
      UserMostAtRiskPopObj.Value := sheet.floats[GB_RW_DataStartCol + 2, currRow];
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        UserMostAtRiskPopObj.ResourcesRequired[t] := sheet.Floats[c, currRow];
        inc(c);
      end;
      inc(currRow);
      c := c1;
      for t := t1 to t2 do
      begin
        UserMostAtRiskPopObj.NumberPeopleReached[t] := sheet.Floats[c, currRow];
        inc(c);
      end;
      value.Add(UserMostAtRiskPopObj);
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : integer;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of User Entered Most At-Risk Populations';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of User Entered Most At-Risk Populations';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := RN_TUserMostAtRiskPopObject(Value.Items[i]).UserMARPop;
      sheet.cells[GB_RW_DataStartCol, currRow] := RN_TUserMostAtRiskPopObject(Value.Items[i]).UserMARPop;
      sheet.ints[GB_RW_DataStartCol + 1, currRow] := RN_TUserMostAtRiskPopObject(Value.Items[i]).PerNum;
      sheet.floats[GB_RW_DataStartCol + 2, currRow] := RN_TUserMostAtRiskPopObject(Value.Items[i]).Value;

      inc(currRow);
      sheet.cells[GB_RW_NotesCol, currRow] := 'Resources required';
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(GetProj) do
        sheet.Floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := RN_TUserMostAtRiskPopObject(value.Items[i]).ResourcesRequired[t];

      inc(currRow);
      sheet.cells[GB_RW_NotesCol, currRow] := 'Number people reached';
      for t := GetGBCalcYearIdx(p) to GetGBFinalYearIdx(GetProj) do
        sheet.Floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(p), currRow] := RN_TUserMostAtRiskPopObject(value.Items[i]).NumberPeopleReached[t];

      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopObjList.Resize(action : byte; finalIndex : integer);
  var
    i        : integer;
    t,
    oldIndex,
    newIndex : integer;
  begin
    if (action = GB_FINALYEAR_CHANGE) and assigned(value) then
    begin
      for i := 0 to value.Count - 1 do
      begin
        oldIndex := Length(RN_TUserGeneralPopObject(value.Items[i]).ResourcesRequired) - 1; // choose one
        newIndex := finalIndex;

        SetLength(RN_TUserMostAtRiskPopObject(value.Items[i]).ResourcesRequired, newIndex + 1);
        SetLength(RN_TUserMostAtRiskPopObject(value.Items[i]).NumberPeopleReached, newIndex + 1);

        (* If extending, flatline the values from the final index. *)
        if oldIndex < newIndex then
          for t := oldIndex + 1 to newIndex do
          begin
            RN_TUserMostAtRiskPopObject(value.Items[i]).ResourcesRequired[t] :=
              RN_TUserMostAtRiskPopObject(value.Items[i]).ResourcesRequired[t - 1];
            RN_TUserMostAtRiskPopObject(value.Items[i]).NumberPeopleReached[t] :=
              RN_TUserMostAtRiskPopObject(value.Items[i]).NumberPeopleReached[t - 1];
          end;
       end;
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    valueNum      : double;
    configTextIdx,
    j, col,
    t, i          : integer;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to GetRNData(GetProj).GetUserMostAtRiskPopObjList.Count -1 do
    begin
      projInfo[configTextIdx] := RN_TUserMostAtRiskPopObject(GetRNData(GetProj).GetUserMostAtRiskPopObjList.Items[i]).UserMARPop +
        '; ' + Chr(RN_TUserMostAtRiskPopObject(GetRNData(GetProj).GetUserMostAtRiskPopObjList.Items[i]).PerNum);
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := RN_TUserMostAtRiskPopObject(GetRNData(GetProj).GetUserMostAtRiskPopObjList.Items[i]).Value;
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;

      Inc(currRow);
    end;
  end;

{$ENDREGION}

                      (* ______________________________
                       /                               \
                      /            Coverage             \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_Coverage'}
  constructor RN_MV_Coverage.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_Coverage_MV;
    stringID    := GB_stCoverage;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    SetLengthDynArrays(1, RN_MaxInterventions + 1);

    InitData;
  end;

  procedure RN_MV_Coverage.InitData;
  var
    r, t, i : byte;
  begin
    for i := 1 to RN_MaxInterventions do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
      begin
        if i in [RN_MC15_49, RN_MCInfant] then
          value[i, t] := 10.0
        else
          value[i, t] := 0.0;
      end;

    for r := 1 to RN_MaxInterventions do
    begin
      case r of RN_MC15_49:
        begin
          SetMin(r,0);
          SetMax(r,100);
          SetLDec(r,3);
          SetRDec(r,2);
          SetSource(r,'');
        end
      else
        begin
          SetMin(r,0);
          SetMax(r,100);
          SetLDec(r,3);
          SetRDec(r,1);
          SetSource(r,'');
        end;
      end;
    end;
  end;

  destructor RN_MV_Coverage.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_Coverage.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    VariablesRW    : RN_MV_TVariablesRW;
    t, t1, t2, t3, i     : byte;
    MstID, CurrID, c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr, finalYr,
      GB_RW_DataStartCol + 1, t1, t2, t3, c1);
    VariablesRW := GetRNData(p).GetVariablesRWMV;

    Inc(currRow); // Skip Header Strings

    for i := 1 to VariablesRW.RN_MaxInterventionsRW - RN_NumIntervExcludedFromCov do
    begin
      MstID := sheet.ints[GB_RW_DataStartCol, currRow];
      CurrID := GetRN_COVConstantCurrID(MstID);
      if (CurrID <> 0) then
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[CurrID, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_Coverage.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : byte;
  begin
    (* Header Strings *)
    sheet.cells[GB_RW_NotesCol, currRow] := 'Name';
    sheet.cells[GB_RW_DataStartCol, currRow] := 'Master ID';
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[GB_RW_DataStartCol + 1 + t - GetGBCalcYearIdx(GetProj), currRow] := GetGBCalcYear(GetProj) + t - 1;
    Inc(currRow);

    (* Data *)
    for i := 1 to RN_MaxInterventions do
      if not (i in RN_NotInCov) then
      begin
        sheet.cells[GB_RW_NotesCol, currRow] := GetRN_COVConstantString(i);
        sheet.ints[GB_RW_DataStartCol, currRow] := GetRN_COVConstantMstID(i);
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1), currRow] := value[i, t];
        Inc(currRow);
      end;
  end;

  procedure RN_MV_Coverage.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex : byte;
  begin
  oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_MaxInterventions + 1, finalIndex +1 );
    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_MaxInterventions do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function RN_MV_Coverage.GetString(i2 : integer) : string;
  begin
    result := '';
    case i2 of
      RN_FSW                   : Result := RS(GB_stSexWorkersReached);
      RN_MSW                   : Result := RS(GB_stSexWorkersReached);
      RN_MSMOutreach           : Result := RS(GB_stMSMReached);
      RN_IDUHarmRed            : Result := RS(GB_stPWIDReceivingHarmReduction);
      RN_IDUCandT              : Result := RS(GB_stPWIDReceivingCounseling);
      RN_IDUOutreach           : Result := RS(GB_stPWIDReceivingCommunityOutreach);
      RN_IDUNSEP               : Result := RS(GB_stPWIDReceivingNeedle);
      RN_IDUDrugSub            : Result := RS(GB_stPWIDReceivingDrugSubstitution);
      RN_ComMob                : Result := RS(GB_stReachedByComMobile);
      RN_PrimaryTeachers       : Result := RS(GB_stPrimaryStudentsTeachersTrained);
      RN_SecondaryTeachers     : Result := RS(GB_stSecondaryStudentsTeachersTrained);
      RN_OutOfSchoolYouth      : Result := RS(GB_stOutOfSchoolYouthReached);
      RN_EconomicStrengthening : Result := RS(GB_stWomenAndGirlsReceiveEconomicStrengthening);
      RN_WorkplaceSTI          : Result := RS(GB_stWorkforceReceivingSTITreatment);
      RN_Condom                : Result := RS(GB_stCondomCoverage);
      RN_MalesSTITx            : Result := RS(GB_stMalesWithSTI);
      RN_FemalesSTITx          : Result := RS(GB_stFemalesWithSTI);
      RN_VCT                   : Result := RS(GB_stAdultPopReceivingVCT);
      RN_MassMedia             : Result := RS(GB_stReachedByCampPerYr);
      RN_BloodSafety           : Result := RS(GB_stUnitsBloodTransfusionTested);
      RN_PEP                   : Result := RS(GB_stNeedThatIsMet);
      RN_ADSyringes            : Result := RS(GB_stUnsafeInjectionsReplaced);
      RN_ReduceInjects         : Result := RS(GB_stReductionNumberInjections);
      RN_UniversalPrec         : Result := RS(GB_stHospitalBedsCovered);
      RN_MC15_49               : Result := RS(GB_stMales15_49Circumcised);
      RN_MCInfant              : Result := RS(GB_stInfantMalesCircumcised);
      RN_MSMLub                : Result := RS(GB_stMSMsReceivingLubricants);
      RN_PrEPOralDaily         : Result := '  ' + RS(GB_stOralDaily);
      RN_PrEPOralMonthly       : Result := '  ' + RS(GB_stOralMonthly);
      RN_PrEPOralPlusCon       : Result := '  ' + RS(GB_stOralPlusCon);
      RN_PrEPInject1Mo         : Result := '  ' + RS(GB_stInjectable1Mo);
      RN_PrEPInject2Mo         : Result := '  ' + RS(GB_stInjectable2Mo);
      RN_PrEPInject6Mo         : Result := '  ' + RS(GB_stInjectable6Mo);
      RN_PrEPRing              : Result := '  ' + RS(GB_stRing);
      RN_PrEPbNABs             : Result := '  ' + RS(GB_stbNABs);
      RN_Vaccines              : Result := RS(GB_stVaccines);
    end;
  end;

  function RN_MV_Coverage.GetExtractConfig(i : integer) : string;
  begin
    result := '';
    case i of
      RN_FSW                   : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stFemaleSexWorkers);
      RN_MSW                   : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stMaleSexWorkers);
      RN_MSMOutreach           : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stMSM);
      RN_MSMLub                : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stMSM);
      RN_IDUHarmRed            : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUCandT              : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUOutreach           : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUNSEP               : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUDrugSub            : Result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stInjectingDrugUsers);

      RN_ComMob                : Result := RS(GB_stGeneralPopulation) + '; ' + RS(Gl_stCommunityMobil);
      RN_PrimaryTeachers       : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_SecondaryTeachers     : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_OutOfSchoolYouth      : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_EconomicStrengthening : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stEconomicStrengthening);
      RN_WorkplaceSTI          : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stEconomicStrengthening);
      RN_Condom                : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_VCT                   : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stHIVTest);
      RN_MassMedia             : Result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stMassMedia);

      RN_MalesSTITx            : Result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSTIManagement);
      RN_FemalesSTITx          : Result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSTIManagement);
      RN_BloodSafety           : Result := RS(GB_stMedicalServices) + '; ' + RS(GB_stBloodSafety);
      RN_PEP                   : Result := RS(GB_stMedicalServices) + '; ' + RS(GB_stPostExposProphylaxis);
      RN_ADSyringes            : Result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSafeMedicalInject);
      RN_ReduceInjects         : Result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSafeMedicalInject);
      RN_UniversalPrec         : Result := RS(GB_stMedicalServices) + '; ' + RS(GB_stUniversalPrecautions);

      RN_MC15_49               : Result := RS(HV_stMaleCircum);
      RN_MCInfant              : Result := RS(GB_stInfantMalesCircumcised);

      RN_PrEPOralDaily         : Result := '  ' + RS(GB_stOralDaily);
      RN_PrEPOralMonthly       : Result := '  ' + RS(GB_stOralMonthly);
      RN_PrEPOralPlusCon       : Result := '  ' + RS(GB_stOralPlusCon);
      RN_PrEPInject1Mo         : Result := '  ' + RS(GB_stInjectable1Mo);
      RN_PrEPInject2Mo         : Result := '  ' + RS(GB_stInjectable2Mo);
      RN_PrEPInject6Mo         : Result := '  ' + RS(GB_stInjectable6Mo);
      RN_PrEPRing              : Result := '  ' + RS(GB_stRing);
      RN_PrEPbNABs             : Result := '  ' + RS(GB_stbNABs);

      RN_Vaccines              : Result := RS(GB_stVaccines);
    end;
  end;

  procedure RN_MV_Coverage.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, i          : byte;
    configTextIdx,
    j, col        : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 1 to RN_MaxInterventions do
    begin
      projInfo[configTextIdx] := GetExtractConfig(i) + '; '+ GetString(i);
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i, t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UserGeneralPopCoverage'}
  constructor RN_MV_UserGeneralPopCoverageObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag      := RN_TG_UserGeneralPopCoverage_MV;
    stringID := GB_stUserGeneralPopCoverage_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_UserGeneralPopCoverageObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_UserGeneralPopCoverageObjList.InitData;
  begin
    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(1);
    SetSource('');
  end;

  procedure RN_MV_UserGeneralPopCoverageObjList.Read(p: byte; tag : string; sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3                      : byte;
    UserGeneralPopCoverageCount,
    i, t, c, c1                 : integer;
    UserGeneralPopCoverageObj   : RN_TUserGeneralPopCoverageObject;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    value.Clear;
    Inc(currRow); // Skip Text
    UserGeneralPopCoverageCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
    Inc(currRow); // Skip Text
    for i := 0 to UserGeneralPopCoverageCount -1 do
    begin
      UserGeneralPopCoverageObj := RN_TUserGeneralPopCoverageObject.Create(p);
      UserGeneralPopCoverageObj.UserGenPop := sheet.cells[GB_RW_DataStartCol, currRow];
      c := c1;
      for t := t1 to t2 do
      begin
        UserGeneralPopCoverageObj.Value[t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      value.Add(UserGeneralPopCoverageObj);
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserGeneralPopCoverageObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : integer;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of User Entered General Populations';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of Coverage Values for User Entered General Populations';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      sheet.cells[GB_RW_DataStartCol, currRow] := RN_TUserGeneralPopCoverageObject(value.Items[i]).UserGenPop;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1, currRow] := RN_TUserGeneralPopCoverageObject(value.Items[i]).Value[t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserGeneralPopCoverageObjList.Resize(action : byte; finalIndex : integer);
  var
    i        : integer;
    t,
    oldIndex,
    newIndex : integer;
  begin
    if (action = GB_FINALYEAR_CHANGE) and assigned(value)  then
    begin
      for i := 0 to value.Count - 1 do
      begin
        oldIndex := Max(0, Length(RN_TUserGeneralPopCoverageObject(value.Items[i]).value) - 1);
        newIndex := finalIndex;

        SetLength(RN_TUserGeneralPopCoverageObject(value.Items[i]).value, newIndex + 1);

        (* If extending, flatline the values from the final index. *)
        if oldIndex < newIndex then
          for t := oldIndex + 1 to newIndex do
            RN_TUserGeneralPopCoverageObject(value.Items[i]).value[t] := RN_TUserGeneralPopCoverageObject(value.Items[i]).value[t - 1]
       end;
    end;
  end;

  procedure RN_MV_UserGeneralPopCoverageObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    valueNum      : double;
    configTextIdx,
    j, col,
    i, t          : integer;
 begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to GetRNData(GetProj).GetUserGeneralPopCoverageObjList.Count -1 do
    begin
      projInfo[configTextIdx] := RN_TUserGeneralPopCoverageObject(GetRNData(GetProj).GetUserGeneralPopCoverageObjList.Items[i]).UserGenPop;
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := RN_TUserGeneralPopCoverageObject(GetRNData(GetProj).GetUserGeneralPopCoverageObjList.Items[i]).Value[t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;

      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UserMostAtRiskPopCoverage'}
  constructor RN_MV_UserMostAtRiskPopCoverageObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag      := RN_TG_UserMostAtRiskPopCoverage_MV;
    stringID := GB_stUserMostAtRiskPopCoverage_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_UserMostAtRiskPopCoverageObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_UserMostAtRiskPopCoverageObjList.InitData;
  begin
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_UserMostAtRiskPopCoverageObjList.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3                     : byte;
    UserMostAtRiskPopCoverageCount,
    i, t, c, c1                    : integer;
    UserMostAtRiskPopCoverageObj   : RN_TUserMostAtRiskPopCoverageObject;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    value.Clear;
    Inc(currRow);
    UserMostAtRiskPopCoverageCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
    Inc(currRow); // Skip Text
    for i := 0 to UserMostAtRiskPopCoverageCount -1 do
    begin
      UserMostAtRiskPopCoverageObj := RN_TUserMostAtRiskPopCoverageObject.Create(p);
      UserMostAtRiskPopCoverageObj.UserMARPop := sheet.cells[GB_RW_DataStartCol, currRow];
      c := c1;
      for t := t1 to t2 do
      begin
        UserMostAtRiskPopCoverageObj.Value[t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      value.Add(UserMostAtRiskPopCoverageObj);
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopCoverageObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : integer;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of User Entered Most At-Risk Populations';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of Coverage Values for User Entered Most At-Risk Populations';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      sheet.cells[GB_RW_DataStartCol, currRow] := RN_TUserMostAtRiskPopCoverageObject(value.Items[i]).UserMARPop;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1, currRow] := RN_TUserMostAtRiskPopCoverageObject(value.Items[i]).Value[t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopCoverageObjList.Resize(action : byte; finalIndex : integer);
  var
    i        : integer;
    t,
    oldIndex,
    newIndex : integer;
  begin
    if (action = GB_FINALYEAR_CHANGE)and assigned(value)  then
    begin
      for i := 0 to value.Count - 1 do
      begin
        oldIndex := Max(0, Length(RN_TUserMostAtRiskPopCoverageObject(value.Items[i]).value) - 1);
        newIndex := finalIndex;

        SetLength(RN_TUserMostAtRiskPopCoverageObject(value.Items[i]).value, newIndex + 1);

        (* If extending, flatline the values from the final index. *)
        if oldIndex < newIndex then
          for t := oldIndex + 1 to newIndex do
            RN_TUserMostAtRiskPopCoverageObject(value.Items[i]).value[t] := RN_TUserMostAtRiskPopCoverageObject(value.Items[i]).value[t - 1]
       end;
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopCoverageObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t             : byte;
    valueNum      : double;
    configTextIdx,
    col, i, j     : integer;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to GetRNData(GetProj).GetUserMostAtRiskPopCoverageObjList.Count -1 do
    begin
      projInfo[configTextIdx] := RN_TUserMostAtRiskPopCoverageObject(GetRNData(GetProj).GetUserMostAtRiskPopCoverageObjList.Items[i]).UserMARPop;
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := RN_TUserMostAtRiskPopCoverageObject(GetRNData(GetProj).GetUserMostAtRiskPopCoverageObjList.Items[i]).Value[t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UseRNMData'}
  constructor RN_MV_UseRNMData.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_UseRNMData_MV;
    stringID := GB_stUseRNMData;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_UseRNMData.InitData;
  begin
    value := false;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_UseRNMData.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := boolean(sheet.Ints[GB_RW_DataStartCol, currRow]);
    Inc(currRow);
  end;

  procedure RN_MV_UseRNMData.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin

    sheet.Ints[GB_RW_DataStartCol, currRow] := byte(value);
    Inc(currRow);
  end;

{$ENDREGION}

(* Only when Goals is on *)
{$REGION 'RN_MV_PrEPCoverage'}
  constructor RN_MV_PrEPCoverage.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PrEPCoverage_MV;
    stringID := GB_stPrEPCoverage_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_PrEPCoverage.InitData;
  var
    s, r, t : byte;
  begin
    for s := RN_Male to RN_Female do
      for r := RN_LRH to RN_MSMIDU do
          for t := 0 to GetGBFinalYearIdx(GetProj) do
            value[s, r, t] := 0.0;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_PrEPCoverage.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_PrEPCoverage.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3, r : byte;
    c, c1        : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);
    inc(currRow);
    for r := RN_LRH to RN_MSMIDU do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[ RN_Male, r, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      Inc(currRow);
    end;
    for r := RN_LRH to RN_IDU do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[RN_Female, r, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_PrEPCoverage.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    r, t : byte;
  begin
    Inc(currRow);
    sheet.cells[GB_RW_DescriptCol, currRow] :=  RS(GB_stMale);
    for r := RN_LRH to RN_MSMIDU do
    begin
      sheet.cells[GB_RW_DescriptCol + 1, currRow] := GetRN_RiskVarNames(r);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj),currRow] := value[RN_Male, r, t];
      Inc(currRow);
    end;
    sheet.cells[GB_RW_DescriptCol, currRow] :=  RS(GB_stFemale);
    for r := RN_LRH to RN_IDU do
    begin
      sheet.cells[GB_RW_DescriptCol + 1, currRow] := GetRN_RiskVarNames(r);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj),currRow] := value[RN_Female, r, t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_PrEPCoverage.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, RN_Female + 1, RN_MSMIDU + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
     if oldIndex < finalIndex then
      for i := RN_Male to RN_Female do
        for j := RN_LRH to RN_MSMIDU do
          for t := oldIndex + 1 to finalIndex do
             value[i, j, t] := value[i, j, t - 1];
  end;

  function RN_MV_PrEPCoverage.GetString(i2 : integer) : string;
  begin
    result := '';

    case i2 of
      RN_LRH           : result := RS(HV_stLRH);
      RN_MRH           : result := RS(HV_stMRH);
      RN_HRH           : result := RS(HV_stHRH);
      RN_IDU           : result := RS(GB_stPeopleWhoInjectDrugs);
      RN_MSM           : result := RS(GB_stMSM);
      RN_MSMLR         : result := RS(HV_stMSMLowRisk);
      RN_MSMMR         : result := RS(HV_stMSMMediumRisk);
      RN_MSMHR         : result := RS(HV_stMSMHighRisk);
      RN_MSMIDU        : result := RS(GB_stMSMPWID);
    end;
  end;

  procedure RN_MV_PrEPCoverage.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    s, r, t       : byte;
    i, col,
    configTextIdx : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for s := RN_Male to RN_Female do
      for r := RN_LRH to RN_MSMIDU do
      begin
        projInfo[configTextIdx] := GetRN_Sex(s) + '; ' + GetString(r);
        for i := 1 to projInfo.count do
          GB_File.cells[i - 1, currRow] := projInfo[i - 1];

        col := projInfo.count + ConfigRec.yrStartCol - 1;
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        begin
          valueNum := value[s,r,t];
          GB_File.RDec := GetRDec;
          GB_File.floats[col, currRow] := valueNum;
          Inc(col);
        end;

        Inc(currRow);
      end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_PrEPEffectiveness'}
  constructor RN_MV_PrEPEffectiveness.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PrEPEffectiveness_MV3;
    stringID := GB_stPrEPEffectiveness_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];
    InitData;
  end;

  destructor RN_MV_PrEPEffectiveness.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;
  procedure RN_MV_PrEPEffectiveness.InitData;
  begin
    SetLength(value, RN_Duration + 1, RN_PrEP_PEP + 1);
    value[RN_Effectiveness,RN_PrEPOralDaily  ] := 95;
    value[RN_Effectiveness,RN_PrEPOralMonthly] := 95;
    value[RN_Effectiveness,RN_PrEPOralPlusCon] := 95;
    value[RN_Effectiveness,RN_PrEPInject1Mo  ] := 98;
    value[RN_Effectiveness,RN_PrEPInject2Mo  ] := 98;
    value[RN_Effectiveness,RN_PrEPInject6Mo  ] := 98;
    value[RN_Effectiveness,RN_PrEPRing       ] := 95;
    value[RN_Effectiveness,RN_PrEPbNABs      ] := 98;
    value[RN_Effectiveness,RN_PrEPImplant    ] := 99;
    value[RN_Effectiveness,RN_PrEP_PEP       ] := 90;

    value[RN_Adherence,RN_PrEPOralDaily  ] := 50;
    value[RN_Adherence,RN_PrEPOralMonthly] := 75;
    value[RN_Adherence,RN_PrEPOralPlusCon] := 75;
    value[RN_Adherence,RN_PrEPInject1Mo  ] := 99;
    value[RN_Adherence,RN_PrEPInject2Mo  ] := 99;
    value[RN_Adherence,RN_PrEPInject6Mo  ] := 99;
    value[RN_Adherence,RN_PrEPRing       ] := 50;
    value[RN_Adherence,RN_PrEPbNABs      ] := 99;
    value[RN_Adherence,RN_PrEPImplant    ] := 99;
    value[RN_Adherence,RN_PrEP_PEP       ] := 90;

    value[RN_Substitution,RN_PrEPOralDaily  ] := 0;
    value[RN_Substitution,RN_PrEPOralMonthly] := 0;
    value[RN_Substitution,RN_PrEPOralPlusCon] := 50;
    value[RN_Substitution,RN_PrEPInject1Mo  ] := 0;
    value[RN_Substitution,RN_PrEPInject2Mo  ] := 0;
    value[RN_Substitution,RN_PrEPInject6Mo  ] := 0;
    value[RN_Substitution,RN_PrEPRing       ] := 0;
    value[RN_Substitution,RN_PrEPbNABs      ] := 0;
    value[RN_Substitution,RN_PrEPImplant    ] := 0;
    value[RN_Substitution,RN_PrEP_PEP       ] := 0;


    value[RN_DurationMonths,RN_PrEPOralDaily  ] := 0;
    value[RN_DurationMonths,RN_PrEPOralMonthly] := 0;
    value[RN_DurationMonths,RN_PrEPOralPlusCon] := 0;
    value[RN_DurationMonths,RN_PrEPInject1Mo  ] := 0;
    value[RN_DurationMonths,RN_PrEPInject2Mo  ] := 0;
    value[RN_DurationMonths,RN_PrEPInject6Mo  ] := 0;
    value[RN_DurationMonths,RN_PrEPRing       ] := 0;
    value[RN_DurationMonths,RN_PrEPbNABs      ] := 0;
    value[RN_DurationMonths,RN_PrEPImplant    ] := 20;
    value[RN_DurationMonths,RN_PrEP_PEP       ] := 0;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_PrEPEffectiveness.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      e,m : byte;
    begin
      inc(currRow);
      for e := RN_Effectiveness to RN_Adherence do
        for m in [RN_PrEPOralDaily, RN_PrepInject1Mo, RN_PrEPRing] do
        begin
          value[e, m] :=sheet.floats[GB_RW_DataStartCol,currRow];
          Inc(currRow);
          if m = RN_PrepInject1Mo then  //skips over old Gel value
            Inc(currRow);
        end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      e, mstID, currID : byte;
    begin

      inc(currRow);
      while not(sheet.cells[GB_RW_TagCol, currRow] = GB_TG_End) do
//      for m in RN_PrepInterventions do
      begin
        mstID := sheet.ints[GB_RW_DataStartCol, currRow];
        currID := GetRN_UCConstantCurrID(MstID);
        for e := RN_Effectiveness to RN_Substitution do
        begin
          value[e, currID] := sheet.floats[GB_RW_DataStartCol + e, currRow];
        end;
        inc(currRow);
      end;
    end;

    procedure Read3(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      e, mstID, currID : byte;
    begin

      inc(currRow);
      while not(sheet.cells[GB_RW_TagCol, currRow] = GB_TG_End) do
//      for m in RN_PrepInterventions do
      begin
        mstID := sheet.ints[GB_RW_DataStartCol, currRow];
        currID := GetRN_UCConstantCurrID(MstID);
        for e := RN_Effectiveness to RN_DurationMonths do
        begin
          value[e, currID] := sheet.floats[GB_RW_DataStartCol + e, currRow];
        end;
        inc(currRow);
      end;
    end;

  begin
    if tag = RN_TG_PrEPEffectiveness_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = RN_TG_PrEPEffectiveness_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
    if tag = RN_TG_PrEPEffectiveness_MV3 then Read3(p, sheet, currRow, actionRW, firstYr, finalYr);
  end;

  procedure RN_MV_PrEPEffectiveness.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    e, m : byte;
  begin
    for e := RN_Effectiveness to RN_DurationMonths do
    begin
      sheet.cells[GB_RW_DataStartCol + e, currRow] :=  GetRN_EffectivenessNames(e);
    end;

    inc(currRow);
    for m in RN_PrepInterventions do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_MethodMixNames(m);
      sheet.ints[GB_RW_DataStartCol, currRow] := GetRN_UCConstantMstID(m);
      for e := RN_Effectiveness to RN_DurationMonths do
      begin
        sheet.floats[GB_RW_DataStartCol + e, currRow] :=  value[e, m];
      end;
      inc(currRow);
    end;
  end;

   function RN_MV_PrEPEffectiveness.GetString(i2 : integer) : string;
  begin
    result := '';
    case i2 of
      RN_PrEPOralDaily    : Result := '  ' + RS(GB_stOralDaily);
      RN_PrEPOralMonthly  : Result := '  ' + RS(GB_stOralMonthly);
      RN_PrEPOralPlusCon  : Result := '  ' + RS(GB_stOralPlusCon);
      RN_PrEPInject1Mo    : Result := '  ' + RS(GB_stInjectable1Mo);
      RN_PrEPInject2Mo    : Result := '  ' + RS(GB_stInjectable2Mo);
      RN_PrEPInject6Mo    : Result := '  ' + RS(GB_stInjectable6Mo);
      RN_PrEPRing         : Result := '  ' + RS(GB_stRing);
      RN_PrEPbNABs        : Result := '  ' + RS(GB_stbNABs);
      RN_PrEPImplant      : Result := '  ' + RS(GB_stImplant);
      RN_PrEP_PEP         : Result := '  ' + RS(GB_stPEP);
    end;
  end;

  procedure RN_MV_PrEPEffectiveness.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    m, e          : byte;
    i,
    configTextIdx : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for e := RN_Effectiveness to RN_DurationMonths do
      for m in RN_PrepInterventions do
      begin
        projInfo[configTextIdx] := GetRN_EffectivenessNames(e) + '; ' + GetString(m);
        for i := 1 to projInfo.count do
          GB_File.cells[i - 1, currRow] := projInfo[i - 1];

        valueNum := value[e,m];
        GB_File.RDec := GetRDec;
        GB_File.floats[projInfo.count, currRow] := valueNum;
        Inc(currRow);
      end;
  end;

  function RN_MV_PrEPEffectiveness.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = RN_TG_PrEPEffectiveness_MV) or (tag = RN_TG_PrEPEffectiveness_MV2) or (tag = RN_TG_PrEPEffectiveness_MV3) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'RN_MV_MethodMix'}
  constructor RN_MV_MethodMix.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_MethodMix_MV5;
    stringID := GB_stMethodMix_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_MethodMix.InitData;
  var
    s, r, t, m: byte;
  begin
    for s := RN_Male to RN_Female do
      for r := RN_LRH to RN_MSMIDU do
        for m in RN_PrepInterventions do
          for t := 0 to GetGBFinalYearIdx(GetProj) do
            value[s, r, m, t] := 0.0;

    for s := RN_Male to RN_Female do
      for r := RN_LRH to RN_MSMIDU do
        for t := 0 to GetGBFinalYearIdx(GetProj) do
          value[s,r,RN_PrEPOralDaily,t] := 100;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_MethodMix.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_MethodMix.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
    procedure Read1(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      t, t1, t2, t3, r, m : byte;
      c, c1           : integer;
    begin
      GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
        finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

      inc(currRow);
      for r := RN_LRH to RN_MSMIDU do
      begin
       Inc(currRow);
        for m in [RN_PrEPOralDaily, RN_PrEPInject1Mo] do
        begin
          c := c1;
          for t := t1 to t2 do
          begin
            value[RN_Male, r, m, t] := sheet.floats[c, currRow];
            Inc(c);
          end;
          Inc(currRow);
        end;
      end;
      for r := RN_LRH to RN_IDU do
      begin
        Inc(currRow);
        for m in [RN_PrEPOralDaily, RN_PrEPInject1Mo, RN_PrEPRing] do
        begin
          c := c1;
          for t := t1 to t2 do
          begin
            value[RN_Female, r, m, t] := sheet.floats[c, currRow];
            Inc(c);
          end;
          Inc(currRow);
          if m = RN_PrepInject1Mo then  //skips over old Gel value
            Inc(currRow);
        end;
      end;
    end;

    procedure Read2(p : byte; sheet : GB_TFile; var currRow : integer;
        actionRW : byte; var firstYr, finalYr : integer);
    var
      m, r, t, col : byte;
    begin
      inc(currRow);
      for r := RN_LRH to RN_MSMIDU do
      begin
        for m in [RN_PrEPOralDaily..RN_PrEPInject6Mo, RN_PrEPbNABs] do
        begin
  //        sex := GB_Male;
          col := GB_RW_DataStartCol + 2;
          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          begin
            value[GB_Male, r, m, t] := sheet.floats[col, currRow];
            inc(col);
          end;
          Inc(currRow);
        end;
      end;
      for r := RN_LRH to RN_IDU do
      begin
        for m in [RN_PrEPOralDaily..RN_PrEPbNABs] do
        begin
  //        sex := GB_Female;
          col := GB_RW_DataStartCol + 2;
          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          begin
            value[GB_Female, r, m, t] := sheet.floats[col, currRow];
            inc(col);
          end;
          Inc(currRow);
        end;
      end;
    end;

    procedure Read3(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      r, t, col, mstID, currID, sex : byte;
    begin
      inc(currRow);

      while not(sheet.cells[GB_RW_TagCol, currRow] = GB_TG_End) do
      begin
          // sheet.cells[GB_RW_NotesCol, currRow] := GetRN_RiskVarNames(r) + '; ' + GetRN_MethodMixNames(m);
          r := sheet.ints[GB_RW_DataStartCol, currRow];
          sex := sheet.ints[GB_RW_DataStartCol+1, currRow];
          mstID := sheet.ints[GB_RW_DataStartCol+2, currRow];
          currID := GetRN_UCConstantCurrID(mstID);

          col := GB_RW_DataStartCol + 3;
          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          begin
            value[sex, r, currID, t] := sheet.floats[col, currRow];
            inc(col);
          end;
          Inc(currRow);
      end;
    end;

    procedure Read4(p : byte; sheet : GB_TFile; var currRow : integer;
      actionRW : byte; var firstYr, finalYr : integer);
    var
      m, r, t, col, mstID, currID, sex : byte;
    begin
      inc(currRow);

      while not(sheet.cells[GB_RW_TagCol, currRow] = GB_TG_End) do
      begin
        for m in [RN_PrEPOralDaily..RN_PrEPInject6Mo, RN_PrEPbNABs, RN_PrEPImplant] do
        begin
          // sheet.cells[GB_RW_NotesCol, currRow] := GetRN_RiskVarNames(r) + '; ' + GetRN_MethodMixNames(m);
          r := sheet.ints[GB_RW_DataStartCol, currRow];
          sex := sheet.ints[GB_RW_DataStartCol+1, currRow];
          mstID := sheet.ints[GB_RW_DataStartCol+2, currRow];
          currID := GetRN_UCConstantCurrID(mstID);

          col := GB_RW_DataStartCol + 3;
          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          begin
            value[sex, r, currID, t] := sheet.floats[col, currRow];
            inc(col);
          end;
          Inc(currRow);
        end;
      end;
    end;

//    procedure Read5(p : byte; sheet : GB_TFile; var currRow : integer;
//      actionRW : byte; var firstYr, finalYr : integer);
//    var
//      m, r, t, col, mstID, currID, sex : byte;
//    begin
//      inc(currRow);
//
//      while not(sheet.cells[GB_RW_TagCol, currRow] = GB_TG_End) do
//      begin
//        for m in [RN_PrEPOralDaily..RN_PrEPInject6Mo, RN_PrEPbNABs, RN_PrEPImplant, RN_PrEP_PEP] do
//        begin
//          sheet.cells[GB_RW_NotesCol, currRow] := GetRN_RiskVarNames(r) + '; ' + GetRN_MethodMixNames(m);
//          r := sheet.ints[GB_RW_DataStartCol, currRow];
//          sex := sheet.ints[GB_RW_DataStartCol+1, currRow];
//          mstID := sheet.ints[GB_RW_DataStartCol+2, currRow];
//          currID := GetRN_UCConstantCurrID(mstID);
//
//          col := GB_RW_DataStartCol + 3;
//          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
//          begin
//            value[sex, r, currID, t] := sheet.floats[col, currRow];
//            inc(col);
//          end;
//          Inc(currRow);
//        end;
//      end;
//    end;
//
    procedure Read5(p : byte; sheet : GB_TFile; var currRow : integer;
        actionRW : byte; var firstYr, finalYr : integer);
    var
      m, r, t, col : byte;
    begin
      inc(currRow);
      for r := RN_LRH to RN_MSMIDU do
      begin
        for m in RN_PrepInterventions_Male do
        begin
  //        sex := GB_Male;
          col := GB_RW_DataStartCol + 3;
          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          begin
            value[GB_Male, r, m, t] := sheet.floats[col, currRow];
            inc(col);
          end;
          Inc(currRow);
        end;
      end;
      for r := RN_LRH to RN_IDU do
      begin
        for m in RN_PrepInterventions_Female do
        begin
  //        sex := GB_Female;
          col := GB_RW_DataStartCol + 3;
          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          begin
            value[GB_Female, r, m, t] := sheet.floats[col, currRow];
            inc(col);
          end;
          Inc(currRow);
        end;
      end;
    end;


    begin
      if tag = RN_TG_MethodMix_MV  then Read1(p, sheet, currRow, actionRW, firstYr, finalYr);
      if tag = RN_TG_MethodMix_MV2 then Read2(p, sheet, currRow, actionRW, firstYr, finalYr);
      if tag = RN_TG_MethodMix_MV3 then Read3(p, sheet, currRow, actionRW, firstYr, finalYr);
      if tag = RN_TG_MethodMix_MV4 then Read4(p, sheet, currRow, actionRW, firstYr, finalYr);
      if tag = RN_TG_MethodMix_MV5 then Read5(p, sheet, currRow, actionRW, firstYr, finalYr);
    end;

  procedure RN_MV_MethodMix.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    m, r, t, col : byte;
  begin
    inc(currRow);
    sheet.cells[GB_RW_DescriptCol, currRow] :=  RS(GB_stMale);
    for r := RN_LRH to RN_MSMIDU do
    begin
//      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_RiskVarNames(r);
//      Inc(currRow);
      for m in RN_PrepInterventions_Male do
      begin
        sheet.cells[GB_RW_NotesCol, currRow] := GetRN_RiskVarNames(r) + '; ' + GetRN_MethodMixNames(m);
        sheet.ints[GB_RW_DataStartCol, currRow] := r;
        sheet.ints[GB_RW_DataStartCol+1, currRow] := GB_Male;
        sheet.ints[GB_RW_DataStartCol+2, currRow] := GetRN_UCConstantMstID(m);
        col := GB_RW_DataStartCol + 3;
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        begin
          sheet.floats[col, currRow] := value[RN_Male, r, m, t];
          inc(col);
        end;
        Inc(currRow);
      end;
    end;
    sheet.cells[GB_RW_DescriptCol, currRow] :=  RS(GB_stFemale);
    for r := RN_LRH to RN_IDU do
    begin
      for m in RN_PrepInterventions_Female do
      begin
        sheet.cells[GB_RW_NotesCol, currRow] := GetRN_RiskVarNames(r) + '; ' + GetRN_MethodMixNames(m);
        sheet.ints[GB_RW_DataStartCol, currRow] := r;
        sheet.ints[GB_RW_DataStartCol+1, currRow] := GB_Female;
        sheet.ints[GB_RW_DataStartCol+2, currRow] := GetRN_UCConstantMstID(m);
        col := GB_RW_DataStartCol + 3;
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        begin
          sheet.floats[col, currRow] := value[RN_Female, r, m, t];
          inc(col);
        end;
        Inc(currRow);
      end;
    end;
  end;

  procedure RN_MV_MethodMix.Resize(action : byte; finalIndex : integer);
  var
    t, i, j, m,
    oldIndex    : byte;
  begin
  oldIndex := 0;
     if assigned (value) then
       oldIndex := Max(0, Length(value[0, 0, 0]) - 1);


    SetLength(value, RN_Female + 1, RN_MSMIDU + 1, RN_PrEP_PEP + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := RN_Male to RN_Female do
          for j := RN_LRH to RN_MSMIDU do
            for m := RN_PrEPOralDaily to RN_PrEP_PEP do
              for t := oldIndex + 1 to finalIndex do
                value[i, j, m, t] := value[i, j, m, t - 1];
  end;


  function RN_MV_MethodMix.GetString(i2 : integer) : string;
  begin
    result := '';

    case i2 of
      RN_PrEPOralDaily    : Result := '  ' + RS(GB_stOralDaily);
      RN_PrEPOralMonthly  : Result := '  ' + RS(GB_stOralMonthly);
      RN_PrEPOralPlusCon  : Result := '  ' + RS(GB_stOralPlusCon);
      RN_PrEPInject1Mo    : Result := '  ' + RS(GB_stInjectable1Mo);
      RN_PrEPInject2Mo    : Result := '  ' + RS(GB_stInjectable2Mo);
      RN_PrEPInject6Mo    : Result := '  ' + RS(GB_stInjectable6Mo);
      RN_PrEPRing         : Result := '  ' + RS(GB_stRing);
      RN_PrEPbNABs        : Result := '  ' + RS(GB_stbNABs);
      RN_PrEPImplant      : Result := '  ' + RS(GB_stImplant);
      RN_PrEP_PEP         : Result := '  ' + RS(GB_stPEP);
    end;
  end;

  procedure RN_MV_MethodMix.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    s, r, t, m    : byte;
    configTextIdx,
    col, i        : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for s := RN_Male to RN_Female do
      for r := RN_LRH to RN_MSMIDU do
        for m in RN_PrepInterventions do
        begin
          projInfo[configTextIdx] := GetRN_Sex(s) + '; ' +
            GetRN_RiskVarNames(r) + '; ' + GetString(m);
          for i := 1 to projInfo.count do
            GB_File.cells[i - 1, currRow] := projInfo[i - 1];

          col := projInfo.count + ConfigRec.yrStartCol - 1;
          for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          begin
            valueNum := value[s,r,m,t];
            GB_File.RDec := GetRDec;
            GB_File.floats[col, currRow] := valueNum;
            Inc(col);
          end;

          Inc(currRow);
        end;
  end;

  function RN_MV_MethodMix.HasTag(tag : string) : boolean;
  begin
    result := false;
    if (tag = RN_TG_MethodMix_MV) or (tag = RN_TG_MethodMix_MV2) or
       (tag = RN_TG_MethodMix_MV3) or (tag = RN_TG_MethodMix_MV4)or
       (tag = RN_TG_MethodMix_MV5) then
      result := true;
  end;

{$ENDREGION}

{$REGION 'RN_MV_VaccineCovType'}
  constructor RN_MV_VaccineCovType.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_VaccineCovType_MV;
    stringID := GB_stVaccCovType;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_VaccineCovType.InitData;
  begin
    value := 0;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_VaccineCovType.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value :=sheet.ints[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure RN_MV_VaccineCovType.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow] := value;
    inc(currRow);
  end;

  procedure RN_MV_VaccineCovType.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_VacCoverage'}
  constructor RN_MV_VacCoverage.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_VacCoverage_MV;
    stringID := GB_stVaccineCov;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor  RN_MV_VacCoverage.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_VacCoverage.InitData;
  var
    i, t : byte;
  begin
    for i := RN_AllRisk to RN_MSM_F do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_VacCoverage.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3, r : byte;
    c, c1        : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    Inc(currRow); // Skip Males
    for r := RN_AllRisk to RN_MSM_F do
    begin
      if r = RN_AllRisk_F then
        Inc(currRow);

      c := c1;
      for t := t1 to t2 do
      begin
        value[r, t] :=sheet.floats[c, currRow];
        Inc(c);
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_VacCoverage.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    r, t : byte;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := RS(HV_stMales);
    Inc(currRow);
    for r := RN_AllRisk to RN_MSM_F do
    begin
      if r = RN_AllRisk_F then
      begin
        sheet.cells[GB_RW_NotesCol, currRow] := RS(HV_stFemales);
        Inc(currRow);
      end;
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_VacCoverageVarName(r);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj), currRow] := value[r, t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_VacCoverage.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
  oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_MSM_F + 1, finalIndex +1 );

     (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_AllRisk do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function RN_MV_VacCoverage.GetString(i2 : integer) : string;
  begin
      result := '';

    case i2 of
      RN_AllRisk      : Result := 'All Risk';
      RN_None         : Result := RS(HV_stNSA);
      RN_LRH          : Result := RS(HV_stLRH);
      RN_MRH          : Result := RS(HV_stMRH);
      RN_HRH          : Result := RS(HV_stHRH);
      RN_IDU          : Result := RS(GB_stPeopleWhoInjectDrugs);
      RN_MSM          : Result := RS(GB_stMSM);
      RN_MSMLR        : Result := RS(HV_stMSMLowRisk);
      RN_MSMMR        : Result := RS(HV_stMSMMediumRisk);
      RN_MSMHR        : Result := RS(HV_stMSMHighRisk);
      RN_MSMIDU       : Result := RS(GB_stMSMPWID);
      RN_AllRisk_F    : Result := 'All Risk';
      RN_None_F       : Result := RS(HV_stNSA);
      RN_LRH_F        : Result := RS(HV_stLRH);
      RN_MRH_F        : Result := RS(HV_stMRH);
      RN_HRH_F        : Result := RS(HV_stHRH);
      RN_IDU_F        : Result := RS(GB_stPeopleWhoInjectDrugs);
      RN_MSM_F        : Result := RS(GB_stMSM);
    end;
  end;

  procedure RN_MV_VacCoverage.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, i          : byte;
    configTextIdx,
    col, j        : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := RN_AllRisk to RN_MSM_F do
    begin
      if i in [RN_AllRisk..RN_MSMIDU] then
        projInfo[configTextIdx] := GetRN_Sex(RN_Male) + '; ' + GetString(i)
      else if i in [RN_AllRisk_F..RN_MSM_F] then
        projInfo[configTextIdx] := GetRN_Sex(RN_Female) + '; ' + GetString(i)
      else
        projInfo[configTextIdx] := GetString(i);

      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i,t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_VaccineEffectiveness'}
  constructor RN_MV_VaccineEffectiveness.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_VaccineEffectiveness_MV;
    stringID := GB_stVaccineEffectiveness_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    SetLengthDynArrays(1, RN_Duration + 1);

    InitData;
  end;
  destructor RN_MV_VaccineEffectiveness.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;
  procedure RN_MV_VaccineEffectiveness.InitData;
  var i : Byte;
  begin
    SetLength(value, RN_Duration + 1);
    value[RN_Efficacy] := 50;
    value[RN_Infectiousness] := 50.0;
    value[RN_Progression] := 0.0;
    value[RN_Duration] := 20;

    for i := RN_Efficacy to RN_Duration do
    case i of
      RN_Progression :
      begin
       SetMin(i,0);
       SetMax(i,100);
       SetLDec(i,3);
       SetRDec(i,2);
       SetSource(i,'');
      end;
    else
      begin
       SetMin(i,0);
       SetMax(i,500);
       SetLDec(i,3);
       SetRDec(i,2);
       SetSource(i,'');
      end;
    end;
  end;

  procedure RN_MV_VaccineEffectiveness.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    r : byte;
  begin
    for r := RN_Efficacy to RN_Duration do
    begin
      Inc(currRow); // skip name
      value[r] := sheet.floats[GB_RW_DataStartCol, currRow];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_VaccineEffectiveness.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    r : byte;
  begin
    for r := RN_Efficacy to RN_Duration do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_VaccineEffectivenessVarName(r);
      Inc(currRow);
      sheet.floats[GB_RW_DataStartCol, currRow] := value[r];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_VaccineEffectiveness.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    r                : byte;
    i, configTextIdx : integer;
    valueNum         : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for r := RN_Efficacy to RN_Duration do
    begin
      projInfo[configTextIdx] := GetString + '; ' + GetRN_VaccineEffectivenessVarName(r);
      for i := 1 to projInfo.count do
        GB_File.cells[i - 1, currRow] := projInfo[i - 1];

      valueNum := value[r];
      GB_File.RDec := GetRDec;
      GB_File.floats[projInfo.count, currRow] := valueNum;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_VaccineBehavEffect'}
  constructor RN_MV_VaccineBehavEffect.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_VaccineBehavEffect_MV;
    stringID := GB_stVaccineBehavEffect_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  destructor RN_MV_VaccineBehavEffect.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_VaccineBehavEffect.InitData;
  begin
    SetLength(value, RN_AmongAdults + 1);
    value[RN_AmongVacc] := 0;
    value[RN_AmongAdults] := 0;

    SetMin(-100);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_VaccineBehavEffect.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value[RN_AmongVacc] := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);

    value[RN_AmongAdults] := sheet.floats[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure RN_MV_VaccineBehavEffect.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.cells[GB_RW_NotesCol,currRow]:='Behavioral Effect- All Vaccinated';
    sheet.floats[GB_RW_DataStartCol,currRow]:= value[RN_AmongVacc];
    inc(currRow);

    sheet.cells[GB_RW_NotesCol,currRow]:= 'Behavioral Effect- Adults';
    sheet.floats[GB_RW_DataStartCol,currRow]:= value[RN_AmongAdults];
    inc(currRow);
  end;

  function RN_MV_VaccineBehavEffect.GetString(i2 : integer) : string;
  begin
    result := '';

    case i2 of
      RN_AmongVacc   : Result := RS(HV_stAmongVacc);
      RN_AmongAdults : Result := RS(HV_stAmongAdults);
    end;
  end;

  procedure RN_MV_VaccineBehavEffect.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    r             : byte;
    i,
    configTextIdx : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for r := RN_AmongVacc to RN_AmongAdults do
    begin
      projInfo[configTextIdx] := GetString(r);
      for i := 1 to projInfo.count do
        GB_File.cells[i - 1, currRow] := projInfo[i - 1];

      valueNum := value[r];
      GB_File.RDec := GetRDec;
      GB_File.floats[projInfo.count, currRow] := valueNum;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_TypeOfVaccine'}
  constructor RN_MV_TypeOfVaccine.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_TypeOfVaccine_MV;
    stringID := HV_stType;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_TypeOfVaccine.InitData;
  begin
    value := RN_TakeAction;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_TypeOfVaccine.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_TypeOfVaccine.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

  procedure RN_MV_TypeOfVaccine.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i         : integer;
    valueNum  : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_VaccineTargeting'}
  constructor RN_MV_VaccineTargeting.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_VaccineTargeting_MV;
    stringID := GB_stVaccineTargeting_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_VaccineTargeting.InitData;
  begin
    value := 0;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_VaccineTargeting.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := sheet.ints[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure RN_MV_VaccineTargeting.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.ints[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

  procedure RN_MV_VaccineTargeting.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i         : integer;
    valueNum  : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;
{$ENDREGION}

{$REGION 'RN_MV_CureCovType'}
  constructor RN_MV_CureCovType.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_CureCovType_MV;
    stringID := GB_stCureCovType;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_CureCovType.InitData;
  begin
    value := 0;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_CureCovType.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value :=sheet.ints[GB_RW_DataStartCol,currRow];
    inc(currRow);
  end;

  procedure RN_MV_CureCovType.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.ints[GB_RW_DataStartCol,currRow] := value;
    inc(currRow);
  end;

  procedure RN_MV_CureCovType.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_CureCoverage'}
  constructor RN_MV_CureCoverage.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_CureCoverage_MV;
    stringID := GB_stCureCov;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor  RN_MV_CureCoverage.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_CureCoverage.InitData;
  var
    i, t : byte;
  begin
    for i := RN_AllRisk to RN_MSM_F do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_CureCoverage.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3, r : byte;
    c, c1        : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    Inc(currRow); // Skip Males
    for r := RN_AllRisk to RN_MSM_F do
    begin
      if r = RN_AllRisk_F then
        Inc(currRow);

      c := c1;
      for t := t1 to t2 do
      begin
        value[r, t] :=sheet.floats[c, currRow];
        Inc(c);
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_CureCoverage.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    r, t : byte;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := RS(HV_stMales);
    Inc(currRow);
    for r := RN_AllRisk to RN_MSM_F do
    begin
      if r = RN_AllRisk_F then
      begin
        sheet.cells[GB_RW_NotesCol, currRow] := RS(HV_stFemales);
        Inc(currRow);
      end;
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_VacCoverageVarName(r);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj), currRow] := value[r, t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_CureCoverage.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
  oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_MSM_F + 1, finalIndex +1 );

     (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_AllRisk do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function RN_MV_CureCoverage.GetString(i2 : integer) : string;
  begin
      result := '';

    case i2 of
      RN_AllRisk      : Result := 'All Risk';
      RN_None         : Result := RS(HV_stNSA);
      RN_LRH          : Result := RS(HV_stLRH);
      RN_MRH          : Result := RS(HV_stMRH);
      RN_HRH          : Result := RS(HV_stHRH);
      RN_IDU          : Result := RS(GB_stPeopleWhoInjectDrugs);
      RN_MSM          : Result := RS(GB_stMSM);
      RN_MSMLR        : Result := RS(HV_stMSMLowRisk);
      RN_MSMMR        : Result := RS(HV_stMSMMediumRisk);
      RN_MSMHR        : Result := RS(HV_stMSMHighRisk);
      RN_MSMIDU       : Result := RS(GB_stMSMPWID);
      RN_AllRisk_F    : Result := 'All Risk';
      RN_None_F       : Result := RS(HV_stNSA);
      RN_LRH_F        : Result := RS(HV_stLRH);
      RN_MRH_F        : Result := RS(HV_stMRH);
      RN_HRH_F        : Result := RS(HV_stHRH);
      RN_IDU_F        : Result := RS(GB_stPeopleWhoInjectDrugs);
      RN_MSM_F        : Result := RS(GB_stMSM);
    end;
  end;

  procedure RN_MV_CureCoverage.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, i          : byte;
    configTextIdx,
    col, j        : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := RN_AllRisk to RN_MSM_F do
    begin
      if i in [RN_AllRisk..RN_MSMIDU] then
        projInfo[configTextIdx] := GetRN_Sex(RN_Male) + '; ' + GetString(i)
      else if i in [RN_AllRisk_F..RN_MSM_F] then
        projInfo[configTextIdx] := GetRN_Sex(RN_Female) + '; ' + GetString(i)
      else
        projInfo[configTextIdx] := GetString(i);

      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i,t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_CureEffectiveness'}
  constructor RN_MV_CureEffectiveness.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_CureEffectiveness_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    SetLengthDynArrays(1, RN_Duration + 1);

    InitData;
  end;
  destructor RN_MV_CureEffectiveness.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;
  procedure RN_MV_CureEffectiveness.InitData;
  var i : Byte;
  begin
    SetLength(value, RN_Duration + 1);
    value[RN_Efficacy] := 80;
    value[RN_Duration] := 3;

    for i := RN_Efficacy to RN_Duration do
    case i of
      RN_Progression :
      begin
       SetMin(i,0);
       SetMax(i,100);
       SetLDec(i,3);
       SetRDec(i,2);
       SetSource(i,'');
      end;
    else
      begin
       SetMin(i,0);
       SetMax(i,500);
       SetLDec(i,3);
       SetRDec(i,2);
       SetSource(i,'');
      end;
    end;
  end;

  procedure RN_MV_CureEffectiveness.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    r : byte;
  begin
    for r := RN_Efficacy to RN_Duration do
    begin
      Inc(currRow); // skip name
      value[r] := sheet.floats[GB_RW_DataStartCol, currRow];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_CureEffectiveness.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    r : byte;
  begin
    for r := RN_Efficacy to RN_Duration do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_VaccineEffectivenessVarName(r);
      Inc(currRow);
      sheet.floats[GB_RW_DataStartCol, currRow] := value[r];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_CureEffectiveness.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    r                : byte;
    i, configTextIdx : integer;
    valueNum         : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for r := RN_Efficacy to RN_Duration do
    begin
      projInfo[configTextIdx] := GetString + '; ' + GetRN_VaccineEffectivenessVarName(r);
      for i := 1 to projInfo.count do
        GB_File.cells[i - 1, currRow] := projInfo[i - 1];

      valueNum := value[r];
      GB_File.RDec := GetRDec;
      GB_File.floats[projInfo.count, currRow] := valueNum;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_ADHTreatCov'}
  constructor RN_MV_ADHTreatCov.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ADHTreatCov_MV;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ADHTreatCov.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_ADHTreatCov.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_ADHTreatCov.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_ADHTreatCov.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

  procedure RN_MV_ADHTreatCov.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_ADHTreatCov.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;
{$ENDREGION}

{$REGION 'RN_MV_ADHTreatReducMort'}
  constructor RN_MV_ADHTreatReducMort.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_ADHTreatReducMort_MV;
    stringID    := GB_stNull;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_ADHTreatReducMort.InitData;
  begin
    (* Value *)
    value := 0;

    (* Dynamic Arrays *)
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_ADHTreatReducMort.Read(p: byte; tag : string; sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    Value := sheet.floats[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_ADHTreatReducMort.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.floats[GB_RW_DataStartCol, currRow] := Value;
    Inc(currRow);
  end;

  procedure RN_MV_ADHTreatReducMort.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_POCCoverage'}
  constructor RN_MV_POCCoverage.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_POCCoverage_MV;
    stringID := GB_stPointOfCare;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_POCCoverage.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_POCCoverage.InitData;
  var
    i, t : byte;
  begin
    for i := RN_POC_CD4 to RN_POC_VL do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  procedure RN_MV_POCCoverage.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 , r : byte;
    c, c1             : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    for r := RN_POC_CD4 to RN_POC_VL do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[r, t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_POCCoverage.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    r, t : byte;
  begin
    for r := RN_POC_CD4 to RN_POC_VL do
    begin
      if r = RN_POC_CD4 then
        sheet.cells[GB_RW_NotesCol, currRow] := RS(GB_stPOC_CD4)
      else
        sheet.cells[GB_RW_NotesCol, currRow] := RS(GB_stPOC_VL);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[r, t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_POCCoverage.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_POC_VL + 1, finalIndex + 1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := RN_POC_CD4 to RN_POC_VL do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  procedure RN_MV_POCCoverage.Extract(projInfo: TStringList; ConfigRec: GB_TExConfigRec; var currRow: integer; GB_File: GB_TFile);
  var
    t, i           : byte;
    configTextIdx,
    col, j         : integer;
    valueNum       : double;
  begin
    projInfo.Add(GetString);
    configTextIdx := projInfo.Add('');

    for i := RN_POC_CD4 to RN_POC_VL do
    begin
      if i = RN_POC_CD4 then
        projInfo[configTextIdx] := RS(GB_stPOC_CD4)
      else
        projInfo[configTextIdx] := RS(GB_stPOC_VL);

      for j := 1 to projInfo.Count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.Count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i, t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_POCEffect'}
  constructor RN_MV_POCEffect.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    SetLength(value, 3, 2);

    tag      := RN_TG_POCEffect_MV;
    stringID := GB_stPOCEffect;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_POCEffect.Destroy;
  begin
    SetLength(value, 0);
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_POCEffect.InitData;
  var
    effectCol: byte;
  begin
    effectCol := 1;
    value[RN_POC_CD4, effectCol] := 25;
    value[RN_POC_VL, effectCol] := 12;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_POCEffect.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    effectCol, r: byte;
  begin
    effectCol := 1;
    for r := RN_POC_CD4 to RN_POC_VL do
    begin
      value[r,effectCol] := sheet.floats[GB_RW_DataStartCol, currRow];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_POCEffect.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    effectCol, r : byte;
  begin
    effectCol := 1;
    for r := RN_POC_CD4 to RN_POC_VL do
    begin
      if r = RN_POC_CD4 then
        sheet.cells[GB_RW_NotesCol, currRow] := RS(GB_stPOC_CD4_Effect)
      else
        sheet.cells[GB_RW_NotesCol, currRow] := RS(GB_stPOC_VL_Effect);
      sheet.floats[GB_RW_DataStartCol, currRow] := value[r,effectCol];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_POCEffect.Extract(projInfo: TStringList; ConfigRec: GB_TExConfigRec; var currRow: integer; GB_File: GB_TFile);
  var
    i, effectCol      : byte;
    configTextIdx, j : integer;
    valueNum         : double;
  begin
    projInfo.Add(GetString);
    configTextIdx := projInfo.Add('');

    effectCol := 1;
    for i := RN_POC_CD4 to RN_POC_VL do
    begin
      if i = RN_POC_CD4 then
        projInfo[configTextIdx] := RS(GB_stPOC_CD4_Effect)
      else
        projInfo[configTextIdx] := RS(GB_stPOC_VL_Effect);

      for j := 1 to projInfo.Count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      valueNum := value[i, effectCol];
      GB_File.RDec := GetRDec;
      GB_File.floats[i, currRow] := valueNum;
    end;
    Inc(currRow);
  end;

{$ENDREGION}


                      (* ______________________________
                       /                               \
                      /            Unit Costs           \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_UnitCosts'}
  constructor RN_MV_UnitCosts.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_UnitCosts_MV;
    stringID    := GB_stUnitCosts;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_UnitCosts.InitData;
  var
    t, i : byte;
  begin
    for i := 1 to RN_MaxInterventions do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
        if i in [RN_MC15_49, RN_MCInfant] then
          value[i, t] := 0.0;

    SetMin(0);
    SetMax(999999999);
    SetLDec(8);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_UnitCosts.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_UnitCosts.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3    : byte;
    i, t, c, c1,
    MstID, CurrID : integer;
    VariablesRW    : RN_MV_TVariablesRW;
  begin
   VariablesRW  := GetRNData(p).GetVariablesRWMV;
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    Inc(currRow); // skip header strings

    for i := 1 to VariablesRW.RN_MaxInterventionsRW - RN_NumIntervExcludedFromUC do
    begin
      MstID := sheet.ints[GB_RW_DataStartCol, currRow];
      CurrID := GetRN_UCConstantCurrID(MstID);
      if (CurrID <> 0) then
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[CurrID, t] :=  sheet.floats[c, currRow];
          Inc(c);
        end;
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UnitCosts.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : byte;
  begin
    (* Header Strings *)
    sheet.cells[GB_RW_NotesCol, currRow] := 'Name';
    sheet.cells[GB_RW_DataStartCol, currRow] := 'Master ID';
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.ints[(GB_RW_DataStartCol + 1 + t - GetGBCalcYearIdx(GetProj)), currRow] := GetGBCalcYear(GetProj) + t - 1;
    Inc(currRow);

    (* Data *)
    for i := 1 to RN_MaxInterventions do
      if not (i in RN_NotInUC) then
      begin
        sheet.cells[GB_RW_NotesCol, currRow] := GetRN_UCConstantString(i);
        sheet.ints[GB_RW_DataStartCol, currRow] := GetRN_UCConstantMstID(i);
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1), currRow] := value[i, t];
        Inc(currRow);
      end;
  end;

  procedure RN_MV_UnitCosts.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex    : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_MaxInterventions + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_MaxInterventions do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function RN_MV_UnitCosts.GetString(i2 : integer) : string;
  begin
    result := '';

    case i2 of
      RN_ComMob                  : result := RS(GB_stCostPerPersonReached);
      RN_MassMedia               : result := RS(GB_stCostPerPersonReached);
      RN_VCT                     : result := RS(GB_stCostPerVCTClient);
      RN_Condom                  : result := RS(GB_stCostPerCondomDistPublicSector);
      RN_PrimaryTeachers         : result := RS(GB_stCostPerTeacherPrimary);
      RN_SecondaryTeachers       : result := RS(GB_stCostPerTeacherSecondary);
      RN_OutOfSchoolYouth        : result := RS(GB_stCostPeerEdOutOfSchoolYouth);
      RN_EconomicStrengthening   : result := RS(GB_stCostPerWomanEconomicStrengtheningPerYr);
      RN_WorkPlaceSTI            : result := RS(GB_stCostPerSTITreatedWorkplace);
      RN_FSW                     : result := RS(GB_stCostPerSexWorkerTargeted);
      RN_MSW                     : result := RS(GB_stCostPerSexWorkerTargeted);
      RN_MSMOutreach             : result := RS(GB_stCostperMSMTargeted);
      RN_MSMLub                  : result := RS(GB_stCostPerMSMLubricants);
      RN_IDUHarmRed              : result := RS(GB_stCostHarmRedProg);
      RN_IDUCandT                : result := RS(GB_stCostCounselingAndTesting);
      RN_IDUOutreach             : result := RS(GB_stCostCommunityOutreach);
      RN_IDUNSEP                 : result := RS(GB_stCostNeedleDistAndDestroy);
      RN_IDUDrugSub              : result := RS(GB_stCostDrugSubstitution);
      RN_MC15_49                 : result := RS(GB_stCostPerAdultCircumcision);
      RN_MCInfant                : result := RS(GB_stCostPerInfantCircumcision);
      RN_PrEPOralDaily           : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_stDailyParen);
      RN_PrEPOralMonthly         : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_stMonthlyParen);
      RN_PrEPOralPlusCon         : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_stPlusConParen);
      RN_PrEPInject1Mo           : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_st1MonthParen);
      RN_PrEPInject2Mo           : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_st2MonthParen);
      RN_PrEPInject6Mo           : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_st6MonthParen);
      RN_PrEPRing                : result := RS(GB_stCostPerPersonTreated);
      RN_PrEPbNABs               : result := RS(GB_stCostPerPersonTreated);
      RN_PrEPImplant             : result := RS(GB_stCostPerPersonTreated);
      RN_PrEP_PEP                : result := RS(GB_stCostPerPersonTreated);
      RN_MalesSTITx              : result := RS(GB_stCostPerSTITreatedClinics);
      RN_FemalesSTITx            : result := RS(GB_stFemalesWithSTI);                 // was missing
      RN_BloodSafety             : result := RS(GB_stCostScreeningUnitBloodForHIV);
      RN_PEP                     : result := RS(GB_stCostPerPEPKit);
      RN_ADSYringes              : result := RS(GB_stAdditionalCostADSyringes);
      RN_ReduceInjects           : result := RS(GB_stReductionNumberInjections);      // was missing
      RN_UniversalPrec           : result := RS(GB_stAnnualCostPerHospitalBed);
      RN_Vaccines                : result := RS(GB_stCostPerPersonFullyVaccinated);
      RN_Cure                    : result := RS(GB_stCostPerPersonTreated);
      RN_AHDTreatment            : result := RS(GB_stCostPerPersonTreated);
      RN_POC_CD4_Int             : result := RS(GB_stCostPerPersonTested);
      RN_POC_VL_Int              : result := RS(GB_stCostPerPersonTested);
    end;
  end;

  function RN_MV_UnitCosts.GetExtractConfig(i : integer) : string;
    begin
    result := '';

    case i of
      (*Most at-risk populations *)
      RN_FSW                   : result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stFemaleSexWorkers);
      RN_MSW                   : result := RS(GB_stKeyPopulations) + '; ' + RS(GB_stMaleSexWorkers);
      RN_MSMOutreach           : result := RS(GB_stKeyPopulations)+ '; ' + RS(GB_stMSM);
      RN_MSMLub                : result := RS(GB_stKeyPopulations)+ '; ' + RS(GB_stMSM);
      RN_IDUHarmRed            : result := RS(GB_stKeyPopulations)+ '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUCandT              : result := RS(GB_stKeyPopulations)+ '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUOutreach           : result := RS(GB_stKeyPopulations)+ '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUNSEP               : result := RS(GB_stKeyPopulations)+ '; ' + RS(GB_stInjectingDrugUsers);
      RN_IDUDrugSub            : result := RS(GB_stKeyPopulations)+ '; ' + RS(GB_stInjectingDrugUsers);
      (*General population*)
      RN_ComMob                : result := RS(GB_stGeneralPopulation) + '; ' + RS(Gl_stCommunityMobil);
      RN_MassMedia             : result := RS(GB_stGeneralPopulation) + '; ' + RS(GL_stMassMedia);
      RN_PrimaryTeachers       : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_SecondaryTeachers     : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_OutOfSchoolYouth      : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stYouth);
      RN_EconomicStrengthening : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stEconomicStrengthening);
      RN_WorkPlaceSTI          : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stEconomicStrengthening);
      RN_Condom                : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stCondomProvision);
      RN_VCT                   : result := RS(GB_stGeneralPopulation) + '; ' + RS(GB_stHIVTest);
      (*Medical services *)
      RN_MalesSTITx            : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSTIManagement);
      RN_BloodSafety           : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stBloodSafety);
      RN_PEP                   : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stPostExposProphylaxis);
      RN_ADSYringes            : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stSafeMedicalInject);
      RN_UniversalPrec         : result := RS(GB_stMedicalServices) + '; ' + RS(GB_stUniversalPrecautions);
      (*Male Circumcision *    )
      RN_MC15_49               : result := RS(HV_stMaleCircum) + '; ' + RS(HV_stMaleCircum);
      RN_MCInfant              : result := RS(HV_stMaleCircum) + '; ' + RS(HV_stMaleCircum);
      (*PrEP *)
      RN_PrEPOralDaily         : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPOralDaily);
      RN_PrEPOralMonthly       : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPOralMonthly);
      RN_PrEPOralPlusCon       : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPOralPlusCon);
      RN_PrEPInject1Mo         : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPInjectable1Mo);
      RN_PrEPInject2Mo         : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPInjectable2Mo);
      RN_PrEPInject6Mo         : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPInjectable6Mo);
      RN_PrEPRing              : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPInjectable);
      RN_PrEPbNABs             : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPbNABs);
      RN_PrEPImplant           : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEPImplant);
      RN_PrEP_PEP              : result := RS(GB_stPrEPL) + '; ' + RS(GB_stPrEP_PEP);
      (*Vaccines *)
      RN_Vaccines              : result := RS(GB_stVaccines) + '; ' + RS(GB_stVaccines);
    end;
  end;

  procedure RN_MV_UnitCosts.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    j, col,
    configTextIdx : integer;
    t, i          : byte;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 1 to RN_MaxInterventions do
    begin
      projInfo[configTextIdx] := GetExtractConfig(i) + '; ' + GetString(i);
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i, t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UserGeneralPopUnitCosts'}
  constructor RN_MV_UserGeneralPopUnitCostsObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag      := RN_TG_UserGeneralPopUnitCosts_MV;
    stringID := GB_stUserGeneralPopUnitCosts_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_UserGeneralPopUnitCostsObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_UserGeneralPopUnitCostsObjList.InitData;
  begin
    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(2);
    SetSource('');
  end;


  procedure RN_MV_UserGeneralPopUnitCostsObjList.Read(p: byte; tag : string; sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3                       : byte;
    UserGeneralPopUnitCostsCount,
    i, t, c, c1                  : integer;
    UserGeneralPopUnitCostsObj   : RN_TUserGeneralPopUnitCostsObject;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    value.Clear;
    Inc(currRow);
    UserGeneralPopUnitCostsCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
    Inc(currRow); // Skip Text
    for i := 0 to UserGeneralPopUnitCostsCount -1 do
    begin
      UserGeneralPopUnitCostsObj := RN_TUserGeneralPopUnitCostsObject.Create(p);
      UserGeneralPopUnitCostsObj.UserGenPop := sheet.cells[GB_RW_DataStartCol, currRow];
      c := c1;
      for t := t1 to t2 do
      begin
        UserGeneralPopUnitCostsObj.Value[t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      value.Add(UserGeneralPopUnitCostsObj);
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserGeneralPopUnitCostsObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : integer;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of User Entered General Populations';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of Unit Costs for User Entered General Populations';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      sheet.cells[GB_RW_DataStartCol, currRow] := RN_TUserGeneralPopUnitCostsObject(value.Items[i]).UserGenPop;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1, currRow] := RN_TUserGeneralPopUnitCostsObject(value.Items[i]).Value[t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserGeneralPopUnitCostsObjList.Resize(action : byte; finalIndex : integer);
  var
    i        : integer;
    t,
    oldIndex,
    newIndex : integer;
  begin
    if (action = GB_FINALYEAR_CHANGE) and assigned(value) then
    begin
      for i := 0 to value.Count - 1 do
      begin
        oldIndex := Max(0, Length(RN_TUserGeneralPopUnitCostsObject(value.Items[i]).value) - 1);
        newIndex := finalIndex;

        SetLength(RN_TUserGeneralPopUnitCostsObject(value.Items[i]).value, newIndex + 1);

        (* If extending, flatline the values from the final index. *)
        if oldIndex < newIndex then
          for t := oldIndex + 1 to newIndex do
            RN_TUserGeneralPopUnitCostsObject(value.Items[i]).value[t] := RN_TUserGeneralPopUnitCostsObject(value.Items[i]).value[t - 1]
       end;
    end;
  end;

  procedure RN_MV_UserGeneralPopUnitCostsObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t             : byte;
    valueNum      : double;
    i, j, col,
    configTextIdx : integer;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to GetRNData(GetProj).GetUserGeneralPopUnitCostsObjList.Count -1 do
    begin
      projInfo[configTextIdx] :=
        RN_TUserGeneralPopUnitCostsObject(GetRNData(GetProj).GetUserGeneralPopUnitCostsObjList.Items[i]).UserGenPop;
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := RN_TUserGeneralPopUnitCostsObject(GetRNData(GetProj).GetUserGeneralPopUnitCostsObjList.Items[i]).Value[t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;

      Inc(currRow);
    end;
  end;

  function RN_MV_UserGeneralPopUnitCostsObjList.GetString(i2 : integer) : string;
  begin
    result := '';

    case i2 of
      RN_ComMob                : result := RS(GB_stCostPerPersonReached);
      RN_MassMedia             : result := RS(GB_stCostPerPersonReached);
      RN_VCT                   : result := RS(GB_stCostPerVCTClient);
      RN_Condom                : result := RS(GB_stCostPerCondomDistPublicSector);
      RN_PrimaryTeachers       : result := RS(GB_stCostPerTeacherPrimary);
      RN_SecondaryTeachers     : result := RS(GB_stCostPerTeacherSecondary);
      RN_OutOfSchoolYouth      : result := RS(GB_stCostPeerEdOutOfSchoolYouth);
      RN_EconomicStrengthening : result := RS(GB_stCostPerWomanEconomicStrengtheningPerYr);
      RN_WorkPlaceSTI          : result := RS(GB_stCostPerSTITreatedWorkplace);
      RN_FSW                   : result := RS(GB_stCostPerSexWorkerTargeted);
      RN_MSW                   : result := RS(GB_stCostPerSexWorkerTargeted);
      RN_MSMOutreach           : result := RS(GB_stCostperMSMTargeted);
      RN_MSMLub                : result := RS(GB_stCostPerMSMLubricants);
      RN_IDUHarmRed            : result := RS(GB_stCostHarmRedProg);
      RN_IDUCandT              : result := RS(GB_stCostCounselingAndTesting);
      RN_IDUOutreach           : result := RS(GB_stCostCommunityOutreach);
      RN_IDUNSEP               : result := RS(GB_stCostNeedleDistAndDestroy);
      RN_IDUDrugSub            : result := RS(GB_stCostDrugSubstitution);
      RN_MC15_49               : result := RS(GB_stCostPerAdultCircumcision);
      RN_MCInfant              : result := RS(GB_stCostPerInfantCircumcision);
      RN_PrEPOralDaily         : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_stDailyParen);
      RN_PrEPOralMonthly       : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_stMonthlyParen);
      RN_PrEPOralPlusCon       : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_stPlusConParen);
      RN_PrEPInject1Mo         : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_st1MonthParen);
      RN_PrEPInject2Mo         : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_st2MonthParen);
      RN_PrEPInject6Mo         : result := RS(GB_stCostPerPersonTreated) + ' ' + RS(GB_st6MonthParen);
      RN_PrEPRing              : result := RS(GB_stCostPerPersonTreated);
      RN_PrEPbNABs             : result := RS(GB_stCostPerPersonTreated);
      RN_MalesSTITx            : result := RS(GB_stCostPerSTITreatedClinics);
      RN_FemalesSTITx          : result := RS(GB_stFemalesWithSTI);                 // was missing
      RN_BloodSafety           : result := RS(GB_stCostScreeningUnitBloodForHIV);
      RN_PEP                   : result := RS(GB_stCostPerPEPKit);
      RN_ADSYringes            : result := RS(GB_stAdditionalCostADSyringes);
      RN_ReduceInjects         : result := RS(GB_stReductionNumberInjections);      // was missing
      RN_UniversalPrec         : result := RS(GB_stAnnualCostPerHospitalBed);
      RN_Vaccines              : result := RS(GB_stCostPerPersonFullyVaccinated);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UserMostAtRiskPopUnitCostsObjList'}
  constructor RN_MV_UserMostAtRiskPopUnitCostsObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag      := RN_TG_UserMostAtRiskPopUnitCosts_MV;
    stringID := GB_stUserMostAtRiskPopUnitCosts_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_UserMostAtRiskPopUnitCostsObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_UserMostAtRiskPopUnitCostsObjList.InitData;
  begin
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_UserMostAtRiskPopUnitCostsObjList.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3                        : byte;
    UserMostAtRiskPopUnitCostsCount,
    i, t, c, c1                       : integer;
    UserMostAtRiskPopUnitCostsObj     : RN_TUserMostAtRiskPopUnitCostsObject;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    value.Clear;
    Inc(currRow);
    UserMostAtRiskPopUnitCostsCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
    Inc(currRow); // Skip Text
    for i := 0 to UserMostAtRiskPopUnitCostsCount -1 do
    begin
      UserMostAtRiskPopUnitCostsObj := RN_TUserMostAtRiskPopUnitCostsObject.Create(p);
      UserMostAtRiskPopUnitCostsObj.UserMARPop := sheet.cells[GB_RW_DataStartCol, currRow];
      c := c1;
      for t := t1 to t2 do
      begin
        UserMostAtRiskPopUnitCostsObj.Value[t] := sheet.floats[c, currRow];
        Inc(c);
      end;
      value.Add(UserMostAtRiskPopUnitCostsObj);
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopUnitCostsObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var i, t : integer;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of User Entered Key Populations';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of Unit Costs for User Entered Key Populations';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      sheet.cells[GB_RW_DataStartCol, currRow] := RN_TUserMostAtRiskPopUnitCostsObject(value.Items[i]).UserMARPop;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1, currRow] := RN_TUserMostAtRiskPopUnitCostsObject(value.Items[i]).Value[t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopUnitCostsObjList.Resize(action : byte; finalIndex : integer);
  var
    i        : integer;
    t,
    oldIndex,
    newIndex : integer;
  begin
    if (action = GB_FINALYEAR_CHANGE) and assigned(value) then
    begin
      for i := 0 to value.Count - 1 do
      begin
        oldIndex := Max(0, Length(RN_TUserMostAtRiskPopUnitCostsObject(value.Items[i]).value) - 1);
        newIndex := finalIndex;

        SetLength(RN_TUserMostAtRiskPopUnitCostsObject(value.Items[i]).value, newIndex + 1);

        (* If extending, flatline the values from the final index. *)
        if oldIndex < newIndex then
          for t := oldIndex + 1 to newIndex do
            RN_TUserMostAtRiskPopUnitCostsObject(value.Items[i]).value[t] :=
              RN_TUserMostAtRiskPopUnitCostsObject(value.Items[i]).value[t - 1];
       end;
    end;
  end;

  procedure RN_MV_UserMostAtRiskPopUnitCostsObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    valueNum       : double;
    i, t, j,
    col,
    configTextIdx  : integer;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to GetRNData(GetProj).GetUserMostAtRiskPopUnitCostsObjList.Count -1 do
    begin
      projInfo[configTextIdx] := RN_TUserMostAtRiskPopUnitCostsObject(GetRNData(GetProj).GetUserMostAtRiskPopUnitCostsObjList.Items[i]).UserMARPop;
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;

      if GetRNData(GetProj).GetMitigationProgramsEntered then
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        begin
          valueNum := RN_TUserMostAtRiskPopUnitCostsObject(GetRNData(GetProj).GetUserMostAtRiskPopUnitCostsObjList.Items[i]).Value[t];
          GB_File.RDec := GetRDec;
          GB_File.floats[col, currRow] := valueNum;
          Inc(col);
        end;
      Inc(currRow);
    end;
  end;

  function RN_MV_UserMostAtRiskPopUnitCostsObjList.GetString(i2 : integer) : string;
  begin
    result := '';

    case i2 of
      RN_FSW               : Result := RS(GB_stCostPerSexWorkerTargeted);
      RN_MSW               : Result := RS(GB_stCostPerSexWorkerTargeted);
      RN_MSMOutreach       : Result := RS(GB_stCostperMSMTargeted);
      RN_MSMLub            : Result := RS(GB_stCostPerMSMLubricants);
      RN_IDUHarmRed        : Result := RS(GB_stCostHarmRedProg);
      RN_IDUCandT          : Result := RS(GB_stCostCounselingAndTesting);
      RN_IDUOutreach       : Result := RS(GB_stCostCommunityOutreach);
      RN_IDUNSEP           : Result := RS(GB_stCostNeedleDistAndDestroy);
      RN_IDUDrugSub        : Result := RS(GB_stCostDrugSubstitution);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_CurrencyForUnitCostsCBIdx'}
  constructor RN_MV_CurrencyForUnitCostsCBIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_CurrencyForUnitCostsCBIdx_MV;
    stringID    := GB_stCurrency;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_CurrencyForUnitCostsCBIdx.InitData;
  begin
    value := RN_USCurrency;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_CurrencyForUnitCostsCBIdx.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_CurrencyForUnitCostsCBIdx.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.Ints[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

  procedure RN_MV_CurrencyForUnitCostsCBIdx.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

(* PMTCT *)
{$REGION 'RN_MV_PreTest'}
  constructor RN_MV_PreTest.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PreTest_MV;
    stringID := GB_stPreTest;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_PreTest.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_PreTest.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

//  procedure RN_MV_PreTest.Clone(NewMV : GB_TModVarObj);
//  begin
//    inherited Clone(NewMV);
//    RN_MV_PreTest(NewMV).value := CloneVariant(value);
//  end;

//  procedure RN_MV_PreTest.ToJSONValue(var jo : TJSONObject);
//  begin
//    GB_AddJSONPair(jo, 'value', value);
//  end;
//
//  procedure RN_MV_PreTest.FromJSONValue(jo : TJSONObject);
//  begin
//    value := GB_FindJSONPair(jo, 'value', value);
//  end;

  procedure RN_MV_PreTest.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_PreTest.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex   : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_PreTest.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_PreTest.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_PostTest'}
  constructor RN_MV_PostTest.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PostTest_MV;
    stringID := GB_stPostTest;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_PostTest.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_PostTest.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_PostTest.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_PostTest.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_PostTest.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_PostTest.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_PostNatal'}
  constructor RN_MV_PostNatal.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PostNatal_MV;
    stringID := GB_stPostNatal_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_PostNatal.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_PostNatal.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_PostNatal.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_PostNatal.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_PostNatal.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_PostNatal.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_Mother'}
  constructor RN_MV_Mother.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_Mother_MV;
    stringID := GB_stMother;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_Mother.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_Mother.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;
//
//  procedure RN_MV_Mother.Clone(NewMV : GB_TModVarObj);
//  begin
//    inherited Clone(NewMV);
//    RN_MV_Mother(NewMV).value := CloneVariant(value);
//  end;
//
//  procedure RN_MV_Mother.ToJSONValue(var jo : TJSONObject);
//  begin
//    GB_AddJSONPair(jo, 'value', value);
//  end;
//
//  procedure RN_MV_Mother.FromJSONValue(jo : TJSONObject);
//  begin
//    value := GB_FindJSONPair(jo, 'value', value);
//  end;

  procedure RN_MV_Mother.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_Mother.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_Mother.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_Mother.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_PCRForInfantAfterBirth'}
  constructor RN_MV_PCRForInfantAfterBirth.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PCRForInfantAfterBirth_MV;
    stringID := GB_stPCRInfant;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_PCRForInfantAfterBirth.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_PCRForInfantAfterBirth.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_PCRForInfantAfterBirth.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_PCRForInfantAfterBirth.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_PCRForInfantAfterBirth.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_PCRForInfantAfterBirth.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_InfantAfterBF'}
  constructor RN_MV_InfantAfterBF.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_InfantAfterBF_MV;
    stringID := GB_stInfantAfterBF;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_InfantAfterBF.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_InfantAfterBF.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_InfantAfterBF.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_InfantAfterBF.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_InfantAfterBF.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_InfantAfterBF.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_Nevirapine200'}
  constructor RN_MV_Nevirapine200.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_Nevirapine200_MV;
    stringID := GB_stNevirapinForMother;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_Nevirapine200.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_Nevirapine200.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_Nevirapine200.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_Nevirapine200.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_Nevirapine200.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_Nevirapine200.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_NevirapineInfant'}
  constructor RN_MV_NevirapineInfant.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_NevirapineInfant_MV;
    stringID := GB_stNevirapineInfant;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_NevirapineInfant.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_NevirapineInfant.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_NevirapineInfant.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_NevirapineInfant.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_NevirapineInfant.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_NevirapineInfant.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_AZT'}
  constructor RN_MV_AZT.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_AZT_MV;
    stringID := GB_stAZT;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_AZT.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_AZT.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_AZT.Read(p : byte; tag : string;  sheet: GB_TFile; var currRow: integer;
    actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_AZT.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_AZT.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_AZT.Write(p: byte; sheet: GB_TFile; var currRow: integer;
    actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_ThreeTC'}
  constructor RN_MV_ThreeTC.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ThreeTC_MV;
    stringID := GB_stThreeTC;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ThreeTC.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_ThreeTC.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_ThreeTC.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_ThreeTC.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_ThreeTC.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_ThreeTC.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_TripleTreatment'}
  constructor RN_MV_TripleTreatment.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_TripleTreatment_MV;
    stringID := GB_stTripleTreatment;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_TripleTreatment.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_TripleTreatment.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_TripleTreatment.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    inc(currRow);
  end;

  procedure RN_MV_TripleTreatment.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_TripleTreatment.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_TripleTreatment.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_TripleProphylaxis'}
  constructor RN_MV_TripleProphylaxis.Create(aOwner : GB_TXXData);
   begin
     inherited Create(aOwner);

     tag      := RN_TG_TripleProphylaxis_MV;
     stringID := GB_stTripleProphylaxis;
     FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

     InitData;
   end;

  procedure RN_MV_TripleProphylaxis.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_TripleProphylaxis.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_TripleProphylaxis.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_TripleProphylaxis.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_TripleProphylaxis.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_TripleProphylaxis.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

  {$ENDREGION}

{$REGION 'RN_MV_ServiceDelivery'}
  constructor RN_MV_ServiceDelivery.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ServiceDelivery_MV;
    stringID := GB_stServiceDelivery;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ServiceDelivery.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_ServiceDelivery.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_ServiceDelivery.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_ServiceDelivery.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_ServiceDelivery.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_ServiceDelivery.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte ;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_Formula'}
  constructor RN_MV_Formula.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_Formula_MV;
    stringID := GB_stFormula;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_Formula.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_Formula.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_Formula.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_Formula.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_Formula.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_Formula.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

(* Unit Costs Treatment *)

{$REGION 'RN_MV_FirstLineARTDrugs'}
  constructor RN_MV_FirstLineARTDrugs.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_FirstLineARTDrugs_MV;
    stringID    := GB_stFirstlineARTdrugs;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_FirstLineARTDrugs.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_FirstLineARTDrugs.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_FirstLineARTDrugs.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_FirstLineARTDrugs.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

  procedure RN_MV_FirstLineARTDrugs.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_FirstLineARTDrugs.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);

    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_SecondLineARTDrugs'}
  constructor RN_MV_SecondLineARTDrugs.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_SecondLineARTDrugs_MV;
    stringID    := GB_stSecondlineARTdrugs;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_SecondLineARTDrugs.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_SecondLineARTDrugs.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_SecondLineARTDrugs.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_SecondLineARTDrugs.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

  procedure RN_MV_SecondLineARTDrugs.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_SecondLineARTDrugs.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_AdditARTDrugCostsTBmale'}
  constructor RN_MV_AdditARTDrugCostsTBmale.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_AdditARTDrugCostsTBmale_MV;
    stringID := GB_stAdditionalARTTBMale;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_AdditARTDrugCostsTBmale.InitData;
  var
    t : byte;
  begin
     (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_AdditARTDrugCostsTBmale.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_AdditARTDrugCostsTBmale.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_AdditARTDrugCostsTBmale.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_AdditARTDrugCostsTBmale.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

  procedure RN_MV_AdditARTDrugCostsTBmale.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_AdditARTDrugCostsTBfemale'}
  constructor RN_MV_AdditARTDrugCostsTBfemale.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_AdditARTDrugCostsTBfemale_MV;
    stringID := GB_stAdditionalARTTBFeMale;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_AdditARTDrugCostsTBfemale.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_AdditARTDrugCostsTBfemale.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_AdditARTDrugCostsTBfemale.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_AdditARTDrugCostsTBfemale.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_AdditARTDrugCostsTBfemale.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_AdditARTDrugCostsTBfemale.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_LabCostsARTTr'}
  constructor RN_MV_LabCostsARTTr.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_LabCostsARTTr_MV;
    stringID := GB_stLabcostsARTtreatment;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_LabCostsARTTr.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_LabCostsARTTr.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_LabCostsARTTr.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_LabCostsARTTr.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_LabCostsARTTr.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_LabCostsARTTr.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_DrugLabCostsTrInf'}
  constructor RN_MV_DrugLabCostsTrInf.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_DrugLabCostsTrInf_MV;
    stringID := GB_stDrugLabCostsTrInf_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_DrugLabCostsTrInf.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_DrugLabCostsTrInf.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_DrugLabCostsTrInf.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_DrugLabCostsTrInf.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_DrugLabCostsTrInf.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_DrugLabCostsTrInf.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_CotrimProphylaxis'}
  constructor RN_MV_CotrimProphylaxis.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_CotrimProphylaxis_MV;
    stringID := GB_stCotrimoxazoleProphylaxis;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_CotrimProphylaxis.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_CotrimProphylaxis.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_CotrimProphylaxis.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_CotrimProphylaxis.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_CotrimProphylaxis.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_CotrimProphylaxis.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_TBProphylaxis'}
  constructor RN_MV_TBProphylaxis.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_TBProphylaxis_MV;
    stringID := GB_stTBprophylaxis;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_TBProphylaxis.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_TBProphylaxis.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_TBProphylaxis.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_TBProphylaxis.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_TBProphylaxis.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_TBProphylaxis.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_NutritionSuppSixMo'}
  constructor RN_MV_NutritionSuppSixMo.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_NutritionSuppSixMo_MV;
    stringID := GB_stNutritionSupplements;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_NutritionSuppSixMo.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_NutritionSuppSixMo.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_NutritionSuppSixMo.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_NutritionSuppSixMo.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_NutritionSuppSixMo.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_NutritionSuppSixMo.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_ChildrenARVDrugs'}
  constructor RN_MV_ChildrenARVDrugs.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ChildrenARVDrugs_MV;
    stringID := GB_stChildrenARVDrugs_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ChildrenARVDrugs.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_ChildrenARVDrugs.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_ChildrenARVDrugs.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_ChildrenARVDrugs.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_ChildrenARVDrugs.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_ChildrenARVDrugs.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_ChildrenLabCostsARTTr'}
  constructor RN_MV_ChildrenLabCostsARTTr.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ChildrenLabCostsARTTr_MV;
    stringID := GB_stChildrenLabCostsARTTr_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ChildrenLabCostsARTTr.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_ChildrenLabCostsARTTr.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_ChildrenLabCostsARTTr.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_ChildrenLabCostsARTTr.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_ChildrenLabCostsARTTr.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;

  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_ChildrenLabCostsARTTr.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_CostPerInpatientDay'}
  constructor RN_MV_CostPerInpatientDay.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_CostPerInpatientDay_MV;
    stringID := GB_stCostperinpatientday;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_CostPerInpatientDay.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_CostPerInpatientDay.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_CostPerInpatientDay.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_CostPerInpatientDay.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_CostPerInpatientDay.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_CostPerInpatientDay.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_CostPerOutpatientDay'}
  constructor RN_MV_CostPerOutpatientDay.Create(aOwner : GB_TXXData);
   begin
     inherited Create(aOwner);

     tag      := RN_TG_CostPerOutpatientDay_MV;
     stringID := GB_stCostperOutpatientday;
     FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

     InitData;
   end;

  procedure RN_MV_CostPerOutpatientDay.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_CostPerOutpatientDay.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_CostPerOutpatientDay.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_CostPerOutpatientDay.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_CostPerOutpatientDay.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_CostPerOutpatientDay.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
   for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_ARTinpatientDays'}
  constructor RN_MV_ARTinpatientDays.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ARTinpatientDays_MV;
    stringID := GB_stARTinPatientDays;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ARTinpatientDays.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_ARTinpatientDays.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

//  procedure RN_MV_ARTinpatientDays.Clone(NewMV : GB_TModVarObj);
//  begin
//    inherited Clone(NewMV);
//    RN_MV_ARTinpatientDays(NewMV).value := CloneVariant(value);
//  end;
//
//  procedure RN_MV_ARTinpatientDays.ToJSONValue(var jo : TJSONObject);
//  begin
//    GB_AddJSONPair(jo, 'value', value);
//  end;
//
//  procedure RN_MV_ARTinpatientDays.FromJSONValue(jo : TJSONObject);
//  begin
//    value := GB_FindJSONPair(jo, 'value', value);
//  end;

  procedure RN_MV_ARTinpatientDays.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_ARTinpatientDays.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_ARTinpatientDays.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_ARTinpatientDays.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;
{$ENDREGION}

{$REGION 'RN_MV_ARToutpatientDays'}
  constructor RN_MV_ARToutpatientDays.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ARToutpatientDays_MV;
    stringID := GB_stARToutPatientDays;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ARToutpatientDays.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_ARToutpatientDays.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_ARToutpatientDays.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_ARToutpatientDays.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_ARToutpatientDays.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_ARToutpatientDays.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_OItreatmentInpatientDays'}
  constructor RN_MV_OItreatmentInpatientDays.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_OItreatmentInpatientDays_MV;
    stringID := GB_stARToiInPatientDays;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_OItreatmentInpatientDays.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_OItreatmentInpatientDays.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_OItreatmentInpatientDays.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_OItreatmentInpatientDays.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_OItreatmentInpatientDays.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_OItreatmentInpatientDays.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_OItreatmentOutpatientDays'}
  constructor RN_MV_OItreatmentOutpatientDays.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_OItreatmentOutpatientDays_MV;
    stringID := GB_stARToiOutPatientDays;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_OItreatmentOutpatientDays.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(99999999);
    SetLDec(8);
    SetRDec(1);
    SetSource('');
  end;

  destructor RN_MV_OItreatmentOutpatientDays.Destroy;
  begin
    inherited Destroy;
    finalize(Value);
  end;

  procedure RN_MV_OItreatmentOutpatientDays.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_OItreatmentOutpatientDays.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_OItreatmentOutpatientDays.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

  procedure RN_MV_OItreatmentOutpatientDays.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_MigFirstToSecondLine'}
  constructor RN_MV_MigFirstToSecondLine.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_MigFirstToSecondLine_MV;
    stringID := GB_stMigrationFirstToSecondLine;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_MigFirstToSecondLine.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_MigFirstToSecondLine.InitData();
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_MigFirstToSecondLine.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3  : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    (* Percent of adults that migrate from first line treatement to second line treatment *)
    inc(currRow);
    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.Floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_MigFirstToSecondLine.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Percent of adults that migrate from first line treatment to second line treatment';
    Inc(currRow);
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj), currRow] := value[t];
    Inc(currRow);
  end;

  procedure RN_MV_MigFirstToSecondLine.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_MigFirstToSecondLine.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t        : byte;
    i, col   : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    col := projInfo.count + ConfigRec.yrStartCol - 1;
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
    begin
      valueNum := value[t];
      GB_File.RDec := GetRDec;
      GB_File.floats[col, currRow] := valueNum;
      Inc(col);
    end;
    Inc(currRow);
  end;

{$ENDREGION}

(* ART Unit costs *)

{$REGION 'RN_MV_TestAndVisitSchedule'}
  constructor RN_MV_TestAndVisitSchedule.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_TestAndVisitSchedule_MV;
    stringID := GB_stTestAndVisitSchedule;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  destructor RN_MV_TestAndVisitSchedule.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_TestAndVisitSchedule.InitData();
  var
    i, j : byte;
  begin
    SetLength(value, RN_PregnantWomen + 1, RN_EID + 1);
    (* Value *)
    for i := RN_PatientsInitiatingART to RN_PregnantWomen do
      for j := RN_CD4Test to RN_EID do
        value[i,j] := 0;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_TestAndVisitSchedule.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    i, j : byte;
  begin
    (* Percent of adults that migrate from first line treatement to second line treatment *)
    inc(currRow);
    for i := RN_PatientsInitiatingART to RN_PregnantWomen do
      for j := RN_CD4Test to RN_EID do
        if not ((i = RN_PregnantWomen) and (j in [RN_CD4Test,RN_ViralLoadTests,RN_DrugDelivAdherenceVisits])) and
           not ((i in [RN_PatientsInitiatingART..RN_PatientsNotVirallySuppressed]) and (j = RN_EID)) then
        begin
          value[i, j] := sheet.Floats[GB_RW_DataStartCol, currRow];
          inc(currRow);
        end;
  end;

  procedure RN_MV_TestAndVisitSchedule.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, j : byte;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Test and visit schedule';
    inc(currRow);
    for i := RN_PatientsInitiatingART to RN_PregnantWomen do
      for j := RN_CD4Test to RN_EID do
      begin
        if not ((i = RN_PregnantWomen) and (j in [RN_CD4Test,RN_ViralLoadTests,RN_DrugDelivAdherenceVisits])) and
           not ((i in [RN_PatientsInitiatingART..RN_PatientsNotVirallySuppressed]) and (j = RN_EID)) then
        begin
          sheet.Cells[GB_RW_DescriptCol, currRow] := GetRN_TestAndVisitSchedulePopName(i) + ' - ' + GetRN_TestAndVisitScheduleTestName(i,j);
          sheet.floats[GB_RW_DataStartCol, currRow] := value[i, j];
          inc(currRow);
        end;
      end;
  end;

  procedure RN_MV_TestAndVisitSchedule.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i, j          : byte;
    configTextIdx,
    k             : integer;
    ValueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := RN_PatientsInitiatingART to RN_PregnantWomen do
      for j := RN_CD4Test to RN_EID do
        if not ((i = RN_PregnantWomen) and (j in [RN_CD4Test,RN_ViralLoadTests,RN_DrugDelivAdherenceVisits])) and
           not ((i in [RN_PatientsInitiatingART..RN_PatientsNotVirallySuppressed]) and (j = RN_EID)) then
        begin
          projInfo[configTextIdx] := GetRN_TestAndVisitSchedulePopName(i) +
                     ' - ' + GetRN_TestAndVisitScheduleTestName(i,j);
          for k := 1 to projInfo.count do
            GB_File.cells[k - 1, currRow] := projInfo[k - 1];

          ValueNum := Value[i,j];
          GB_File.RDec := GetRDec;
          GB_File.floats[projInfo.count, currRow] := valueNum;
          Inc(currRow);
        end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_ARTUnitCosts'}
  constructor RN_MV_ARTUnitCosts.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_ARTUnitCosts_MV2;
    stringID := GB_stARTUnitCosts;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_ARTUnitCosts.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_ARTUnitCosts.InitData();
  var
    i, t : byte;
  begin
    (* Value *)
    for i := RN_CostPerCD4Test to RN_CostOfThirdLineARVs do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0;

    SetMin(0);
    SetMax(99999);
    SetLDec(5);
    SetRDec(2);

    SetSource('');
  end;

  procedure RN_MV_ARTUnitCosts.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    i,
    t, t1, t2, t3  : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    for i := RN_CostPerCD4Test to RN_CostOfThirdLineARVs do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[i, t] := sheet.Floats[c, currRow];
        Inc(c);
      end;
      inc(currRow);
    end;
  end;

  procedure RN_MV_ARTUnitCosts.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : byte;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'ART uint costs';
    Inc(currRow);
    for i := RN_CostPerCD4Test to RN_CostOfThirdLineARVs do
    begin
      sheet.Cells[GB_RW_NotesCol, currRow] := GetRN_ARTUnitCostsName(i);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj), currRow] := value[i, t];
      inc(currRow);
    end;
  end;

  procedure RN_MV_ARTUnitCosts.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_CostOfThirdLineARVs + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_CostOfThirdLineARVs do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  procedure RN_MV_ARTUnitCosts.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, i          : byte;
    col, j,
    configTextIdx : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := RN_CostPerCD4Test to RN_CostOfThirdLineARVs do
    begin
      projInfo[configTextIdx] := GetRN_ARTUnitCostsName(i);
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i,t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_PercentOnART'}
  constructor RN_MV_PercentOnART.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PercentOnART_MV;
    stringID := GB_stPercentOnART;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_PercentOnART.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_PercentOnART.InitData();
  var
    i, t : byte;
  begin
    (* Value *)
    for i := RN_PercentPatientsSecondLine to RN_PercentPatientsThirdLine do
      for t := 0 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0;

    SetMin(0);
    SetMax(100);
    SetLDec(3);
    SetRDec(2);

    SetSource('');
  end;

  procedure RN_MV_PercentOnART.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    i,
    t, t1, t2, t3  : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    inc(currRow);
    for i := RN_PercentPatientsSecondLine to RN_PercentPatientsThirdLine do
    begin
      c := c1;
      for t := t1 to t2 do
      begin
        value[i, t] := sheet.Floats[c, currRow];
        Inc(c);
      end;
      inc(currRow);
    end;
  end;

  procedure RN_MV_PercentOnART.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : byte;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Percent on ART';
    Inc(currRow);
    for i := RN_PercentPatientsSecondLine to RN_PercentPatientsThirdLine do
    begin
      sheet.Cells[GB_RW_NotesCol, currRow] := GetRN_PercentOnARTName(i);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj), currRow] := value[i, t];
      inc(currRow);
    end;
  end;

  procedure RN_MV_PercentOnART.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_PercentPatientsThirdLine + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_PercentPatientsThirdLine do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  procedure RN_MV_PercentOnART.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, i          : byte;
    j, col,
    configTextIdx : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := RN_PercentPatientsSecondLine to RN_PercentPatientsThirdLine do
    begin
      projInfo[configTextIdx] := GetRN_PercentOnARTName(i);
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        valueNum := value[i,t];
        GB_File.RDec := GetRDec;
        GB_File.floats[col, currRow] := valueNum;
        Inc(col);
      end;
      Inc(currRow);
    end;
  end;

{$ENDREGION}


                      (* ______________________________
                       /                               \
                      /         Program Support         \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_CurrencyForProgramSupportCBIdx'}
  constructor RN_MV_CurrencyForProgramSupportCBIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_CurrencyForProgramSupportCBIdx_MV;
    stringID    := GB_stCurrency;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_CurrencyForProgramSupportCBIdx.InitData;
  begin
    value := RN_USCurrency;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_CurrencyForProgramSupportCBIdx.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_CurrencyForProgramSupportCBIdx.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.Ints[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

  procedure RN_MV_CurrencyForProgramSupportCBIdx.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_ProgramSupport2'}
  constructor RN_MV_ProgramSupport2.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_ProgramSupport_MV;
    stringID    := GB_stProgramSupport;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    SetLengthDynArrays(1, RN_Percent + 1);

    InitData;
  end;

  procedure RN_MV_ProgramSupport2.InitData;
  var
    t,i,j : byte;
  begin
    for i := 1 to RN_PS_MaxProgramSupport do
      for j := RN_Number to RN_Percent do
        for t := 1 to GetGBFinalYearIdx(GetProj) do
          value[i, j, t] := 0.0;

    SetMin(RN_Number, 0);
    SetMax(RN_Number, Maxint);
    SetLDec(RN_Number, 10);
    SetRDec(RN_Number, 0);
    SetSource(RN_Number, '');

    SetMin(RN_Percent, 0);
    SetMax(RN_Percent, 100);
    SetLDec(RN_Percent, 3);
    SetRDec(RN_Percent, 1);
    SetSource(RN_Percent, '');

    for i := 1 to RN_PS_MaxProgramSupport do
      options[i] := RN_Percent;
  end;

  destructor RN_MV_ProgramSupport2.Destroy;
  begin
    inherited Destroy;
    finalize(value);
    finalize(options);
  end;

  procedure RN_MV_ProgramSupport2.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    VariablesRW    : RN_MV_TVariablesRW;
    MstID, CurrID  : integer;
    t, t1, t2, t3  : byte;
    i, c, c1, k    : integer;
  begin
    VariablesRW := GetRNData(p).GetVariablesRWMV;
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr, finalYr,
      GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    Inc(currRow); // skip header strings

    for k := RN_Number to RN_Percent do
    begin
      for i := 1 to VariablesRW.RN_MaxPSConstantsRW do
      begin
        MstID := sheet.ints[GB_RW_DataStartCol, currRow];
        CurrID := GetRN_PSConstantCurrID(MstID);
        self.options[i] := sheet.Ints[GB_RW_DataStartCol + 1, currRow];

        if (CurrID <> 0) then
        begin
          c := c1;
          for t := t1 to t2 do
          begin
            value[CurrID, k, t] := sheet.floats[c + 1, currRow];
            Inc(c);
          end;
        end;
        Inc(currRow);
      end;
    end;
  end;

  procedure RN_MV_ProgramSupport2.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    k, i, t : byte;
  begin
    (* Header Strings *)
    sheet.cells[GB_RW_NotesCol, currRow] := 'Name';
    sheet.cells[GB_RW_DataStartCol, currRow] := 'Master ID';
    sheet.cells[GB_RW_DataStartCol + 1, currRow] := 'Option';
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.ints[(GB_RW_DataStartCol + 1 + t - GetGBCalcYearIdx(GetProj) + 1), currRow] := GetGBCalcYear(GetProj) + t - 1;
    Inc(currRow);

    (* Data *)
    for k := RN_Number to RN_Percent do
    begin
      if k = RN_Number then
        sheet.cells[GB_RW_DescriptCol, currRow] := RS(DP_stNumber)
      else
        sheet.cells[GB_RW_DescriptCol, currRow] := RS(GB_stPercent);

      for i := 1 to RN_PS_MstMaxProgramSupport do
      begin
        sheet.cells[GB_RW_NotesCol, currRow] := GetRN_PSConstantString(i);
        sheet.ints[GB_RW_DataStartCol, currRow] := GetRN_PSConstantMstID(i);
        sheet.Ints[GB_RW_DataStartCol + 1, currRow] := self.options[i];

        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          sheet.floats[(GB_RW_DataStartCol + 1 + t - GetGBCalcYearIdx(GetProj) + 1), currRow] := value[i, k, t];

        Inc(currRow);
      end;
    end;
  end;

  procedure RN_MV_ProgramSupport2.Resize(action : byte; finalIndex : integer);
  var
    t, i, j,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0, 0]) - 1);

    SetLength(value, RN_PS_MaxProgramSupport + 1, RN_Percent + 1, finalIndex +1 );
    SetLength(options,  RN_PS_MaxProgramSupport + 1 );
    //SetLength(options, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 1 to RN_PS_MaxProgramSupport do
          for j := RN_Number to RN_Percent do
            for t := oldIndex + 1 to finalIndex do
              value[i, j, t] := value[i, j, t - 1];
  end;

  function RN_MV_ProgramSupport2.GetString(i2 : integer) : string;
    begin
      result := '';

      case i2 of
        RN_PS_EnablingEnvironment     : result := RS(GB_stEnablingEnvironment);
        RN_PS_ProgramManagement       : result := RS(GB_stProgramManagement);
        RN_PS_Research                : result := RS(GB_stResearch);
        RN_PS_MonitoringAndEvaluation : result := RS(GB_stMonitorAndEvaluation);
        RN_PS_StrategicCommunication  : result := RS(GB_stStrategicCommunication);
        RN_PS_Logistics               : result := RS(GB_stLogistics);
        RN_PS_ProgramLevelHR          : result := RS(GB_stProgramLevelHR);
        RN_PS_Training                : result := RS(GB_stTrainingHV);
        RN_PS_LaboratoryEquipment     : result := RS(GB_stLaboratoryEquipment);
      end;
    end;

  procedure RN_MV_ProgramSupport2.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, i, k       : byte;
    j, col,
    configTextIdx : integer;
    valueNum      : double;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 1 to RN_PS_MaxProgramSupport do
      for k := RN_Number to RN_Percent do
      begin
        projInfo[configTextIdx] := GetString(i) + '; ' + GetRN_PercNum(k);
        for j := 1 to projInfo.count do
          GB_File.cells[j - 1, currRow] := projInfo[j - 1];

        col := projInfo.count + ConfigRec.yrStartCol - 1;
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        begin
          valueNum := value[i, k, t];
          GB_File.RDec := GetRDec;
          GB_File.floats[col, currRow] := valueNum;
          Inc(col);
        end;
        Inc(currRow);
      end;
  end;

{$ENDREGION}

{$REGION 'RN_MV_UserProgramSupportObjList'}
  constructor RN_MV_UserProgramSupportObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag      := RN_TG_UserProgramSupport_MV;
    stringID := GB_stUserProgramSupport_MV;
    FlagSet  := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  destructor RN_MV_UserProgramSupportObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_UserProgramSupportObjList.InitData;
  begin
    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_UserProgramSupportObjList.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    UserProgramSupportCount, i   : integer;
    UserProgramSupportObj        : RN_TUserProgramSupportObject;
    t, t1, t2, t3, k  : byte;
    c, c1 : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    value.Clear;
    Inc(currRow);
    UserProgramSupportCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);

    Inc(currRow); // skip text
    for k := RN_Number to RN_Percent do
    begin
      for i := 0 to UserProgramSupportCount -1 do
      begin
        (* Only create the object if we do not have it in our objectlist. *)
        if k = 0 then
          UserProgramSupportObj := RN_TUserProgramSupportObject.Create(p)
        else
          UserProgramSupportObj := RN_TUserProgramSupportObject(value.Items[i]);

        c := c1;
        UserProgramSupportObj.SupportFunction := sheet.cells[c-1, currRow];

        for t := t1 to t2 do
        begin
          UserProgramSupportObj.Value[k, t] := sheet.floats[c, currRow];
          Inc(c);
        end;

        (* Only add the object to the objectlist if it does not exist. *)
        if k = 0 then
          value.Add(UserProgramSupportObj);

        Inc(currRow);
      end;
    end;

    Inc(currRow); // skip text
    for i := 0 to value.Count -1 do
    begin
      UserProgramSupportObj := RN_TUserProgramSupportObject(value.Items[i]);
      c := c1;

      for t := t1 to t2 do
      begin
        UserProgramSupportObj.Option := sheet.ints[c, currRow];
        Inc(c);
      end;

      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserProgramSupportObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    k, i, t : integer;
  begin
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of User Entered Support Functions';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of User Entered Support Functions';
    Inc(currRow);

    for k := RN_Number to RN_Percent do
    begin
      for i := 0 to value.Count -1 do
      begin
        if k = RN_Number then
          sheet.cells[GB_RW_NotesCol, currRow] := RS(DP_stNumber)
        else
          sheet.cells[GB_RW_NotesCol, currRow] := RS(GB_stPercent);

        sheet.cells[GB_RW_DataStartCol, currRow] :=
          RN_TUserProgramSupportObject(value.Items[i]).SupportFunction;

        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
          sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1, currRow] :=
            RN_TUserProgramSupportObject(value.Items[i]).Value[k, t];

        Inc(currRow);
      end;
    end;

    sheet.cells[GB_RW_NotesCol, currRow] := 'User Entered Support Functions Option';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      begin
        sheet.cells[GB_RW_DataStartCol, currRow] :=
          RN_TUserProgramSupportObject(value.Items[i]).SupportFunction;
        sheet.ints[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1, currRow] :=
          RN_TUserProgramSupportObject(value.Items[i]).Option;
      end;

      Inc(currRow);
    end;
  end;

  procedure RN_MV_UserProgramSupportObjList.Resize(action : byte; finalIndex : integer);
  var
    i                     : integer;
    t, k,
    oldIndex,
    newIndex              : integer;
    UserProgramSupportObj : RN_TUserProgramSupportObject;
  begin
    if (action = GB_FINALYEAR_CHANGE) and assigned(value) then
    begin
      for i := 0 to value.count - 1 do
      begin
        UserProgramSupportObj := RN_TUserProgramSupportObject(value.Items[i]);
        SetLength(UserProgramSupportObj.value, RN_Percent + 1, finalIndex + 1);
        for k := RN_Number to RN_Percent do
        begin
          oldIndex := Max(0, Length(UserProgramSupportObj.value[k]) - 1);
          newIndex := finalIndex;

          //SetLength(UserProgramSupportObj.value[k], newIndex + 1);

          (* If extending, flatline the values from the final index. *)
          if oldIndex < newIndex then
            for t := oldIndex + 1 to newIndex do
              UserProgramSupportObj.value[k, t] := UserProgramSupportObj.value[k, t - 1];
        end;
      end;
    end;
  end;

  procedure RN_MV_UserProgramSupportObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t, k          : byte;
    valueNum      : double;
    j, col, i,
    configTextIdx : integer;
  begin
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to value.Count-1 do
    begin
      for k := RN_Number to RN_Percent do
      begin
        projInfo[configTextIdx] :=
          RN_TUserProgramSupportObject(value.Items[i]).SupportFunction + '; ' +
            GetRN_PercNum(k);
        for j := 1 to projInfo.count do
          GB_File.cells[j - 1, currRow] := projInfo[j - 1];

        col := projInfo.count + ConfigRec.yrStartCol - 1;
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        begin
          valueNum := RN_TUserProgramSupportObject(value.Items[i]).value[k, t];
          GB_File.RDec := GetRDec;
          GB_File.floats[col, currRow] := valueNum;
          Inc(col);
        end;

        Inc(currRow);
      end;
    end;
  end;

{$ENDREGION}

                      (* ______________________________
                       /                               \
                      /           Mitigation            \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_Mitigation'}
  constructor RN_MV_MitigationObjList.Create(aOwner : GB_TXXData);
  begin
    value := TObjectList.Create;

    inherited Create(aOwner);

    tag         := RN_TG_Mitigation_MV;
    stringID    := GB_stMitigation;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  destructor RN_MV_MitigationObjList.Destroy;
  begin
    inherited Destroy;

    if value <> nil then
      FreeAndNil(value);
  end;

  procedure RN_MV_MitigationObjList.InitData;
  begin
    SetMin(0);
    SetMax(999999999);
    SetLDec(9);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_MitigationObjList.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3               : byte;
    MitigationProgramsCount,
    i, t, c, c1              : integer;
    MitigationObj            : RN_TMitigationObject;
    RN                       : TRNData;
  begin
    RN := GetRNData(p);
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    value.Clear;

    Inc(currRow);
    MitigationProgramsCount := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
    Inc(currRow);
    for i := 0 to MitigationProgramsCount -1 do
    begin
      MitigationObj := RN_TMitigationObject.Create(p);
      MitigationObj.MitProgram := sheet.cells[GB_RW_DataStartCol, currRow];
      if RN.GetMitigationProgramsEntered then
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          MitigationObj.Value[t] := sheet.floats[c, currRow];
          Inc(c);
        end;
      end;
      value.Add(MitigationObj);
      Inc(currRow);
    end;
  end;

  procedure RN_MV_MitigationObjList.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : integer;
    RN   : TRNData;
  begin
    RN := GetRNData(p);
    sheet.cells[GB_RW_NotesCol, currRow] := 'Number of Mitigation Programs';
    Inc(currRow);
    sheet.Ints[GB_RW_DataStartCol, currRow] := value.Count;
    Inc(currRow);
    sheet.cells[GB_RW_NotesCol, currRow] := 'List of Programs';
    Inc(currRow);
    for i := 0 to value.Count -1 do
    begin
      sheet.cells[GB_RW_DataStartCol, currRow] := RN_TMitigationObject(value.Items[i]).MitProgram;
      if RN.GetMitigationProgramsEntered then
        for t := GetGBCalcYearIdx(GetProj)  to GetGBFinalYearIdx(GetProj) do
          sheet.floats[GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1, currRow] := RN_TMitigationObject(value.Items[i]).Value[t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_MitigationObjList.Resize(action : byte; finalIndex : integer);
  var
    i        : integer;
    t,
    oldIndex,
    newIndex : integer;
  begin
    if (action = GB_FINALYEAR_CHANGE) and assigned(value) then
    begin
      for i := 0 to value.Count - 1 do
      begin
        oldIndex := Max(0, Length(RN_TMitigationObject(value.Items[i]).value) - 1);
        newIndex := finalIndex;

        SetLength(RN_TMitigationObject(value.Items[i]).value, newIndex + 1);

        (* If extending, flatline the values from the final index. *)
        if oldIndex < newIndex then
          for t := oldIndex + 1 to newIndex do
            RN_TMitigationObject(value.Items[i]).value[t] := RN_TMitigationObject(value.Items[i]).value[t - 1];
       end;
    end;
  end;

  procedure RN_MV_MitigationObjList.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    t             : byte;
    valueNum      : double;
    i, j, col,
    configTextIdx : integer;
     RN           : TRNData;
  begin

    RN := GetRNData(GetProj);
    projInfo.Add(RS(stringID));
    configTextIdx := projInfo.Add('');

    for i := 0 to value.Count -1 do
    begin
      projInfo[configTextIdx] :=
        RN_TMitigationObject(value.Items[i]).MitProgram;
      for j := 1 to projInfo.count do
        GB_File.cells[j - 1, currRow] := projInfo[j - 1];

      col := projInfo.count + ConfigRec.yrStartCol - 1;
      if RN.GetMitigationProgramsEntered then
        for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        begin
          valueNum := RN_TMitigationObject(value.Items[i]).Value[t];
          GB_File.RDec := GetRDec;
          GB_File.floats[col, currRow] := valueNum;
          Inc(col);
        end;
      Inc(currRow);
    end;
  end;
{$ENDREGION}

{$REGION 'RN_MV_MitigationProgramsEntered'}
  constructor RN_MV_MitigationProgramsEntered.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_MitigationProgramsEntered_MV;
    stringID    := GB_stMitigationProgramsEnters_MV;
    FlagSet     := FlagSet + [MV_InputVariable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_MitigationProgramsEntered.InitData;
  begin
    value := false;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;
//
//  procedure RN_MV_MitigationProgramsEntered.Clone(NewMV : GB_TModVarObj);
//  begin
//    inherited Clone(NewMV);
//    RN_MV_MitigationProgramsEntered(NewMV).value := CloneVariant(value);
//  end;
//
//  procedure RN_MV_MitigationProgramsEntered.ToJSONValue(var jo : TJSONObject);
//  begin
//    GB_AddJSONPair(jo, 'value', value);
//  end;
//
//  procedure RN_MV_MitigationProgramsEntered.FromJSONValue(jo : TJSONObject);
//  begin
//    value := GB_FindJSONPair(jo, 'value', value);
//  end;

  procedure RN_MV_MitigationProgramsEntered.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := boolean(sheet.Ints[GB_RW_DataStartCol, currRow]);
    Inc(currRow);
  end;

  procedure RN_MV_MitigationProgramsEntered.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.Ints[GB_RW_DataStartCol, currRow] := byte(value);
    Inc(currRow);
  end;

  procedure RN_MV_MitigationProgramsEntered.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
//  var
//    s, i, a  : byte;
//    valueNum : double;
//
//
//    valueStr : string;
  begin
//    indName := '"' + RS(stringID) + '",';
//    config := '"' + GetString + '",';
//    GBWrite(f, rowHeaderStr + indName + config);
//
//    valueNum := value;
//    valueStr := FloatToStrF(valueNum, ffFixed, GetLDec, GetRDec);
//    GBWriteLn(f, valueStr);
  end;

{$ENDREGION}

{$REGION 'RN_MV_CurrencyForMitigationCBIdx'}
  constructor RN_MV_CurrencyForMitigationCBIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_CurrencyForMitigationCBIdx_MV;
    stringID    := GB_stCurrency;
    FlagSet     := FlagSet + [MV_InputVariable, MV_Extractable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_CurrencyForMitigationCBIdx.InitData;
  begin
    value := RN_USCurrency;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_CurrencyForMitigationCBIdx.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_CurrencyForMitigationCBIdx.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.Ints[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;

  procedure RN_MV_CurrencyForMitigationCBIdx.Extract(projInfo : TStringList; ConfigRec : GB_TExConfigRec; var currRow : integer; GB_File : GB_TFile);
  var
    i        : integer;
    valueNum : double;
  begin
    projInfo.Add(RS(stringID));
    projInfo.Add(GetString);
    for i := 1 to projInfo.count do
      GB_File.cells[i - 1, currRow] := projInfo[i - 1];

    valueNum := value;
    GB_File.RDec := GetRDec;
    GB_File.floats[projInfo.count, currRow] := valueNum;
    Inc(currRow);
  end;

{$ENDREGION}

                      (* ______________________________
                       /                               \
                      /       Output configuration      \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_CurrencyDisplayedCBIdx'}
  constructor RN_MV_CurrencyDisplayedCBIdx.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_CurrencyDisplayedCBIdx_MV;
    stringID    := GB_stNumberPeopleReached;
    FlagSet     := FlagSet + [MV_ResultVariable, MV_RW_ImportData];

    InitData;
  end;

  procedure RN_MV_CurrencyDisplayedCBIdx.InitData;
  begin
    value := RN_USCurrency;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  procedure RN_MV_CurrencyDisplayedCBIdx.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  begin
    value := sheet.Ints[GB_RW_DataStartCol, currRow];
    Inc(currRow);
  end;

  procedure RN_MV_CurrencyDisplayedCBIdx.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  begin
    sheet.Ints[GB_RW_DataStartCol, currRow] := value;
    Inc(currRow);
  end;
{$ENDREGION}

                      (* ______________________________
                       /                               \
                      /   Output/Calculated variables   \
                     /_____/_________________\_________o_\
                     \_____\_________________|___________/  *)

{$REGION 'RN_MV_ResourcesRequired'}
  constructor RN_MV_ResourcesRequired.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_ResourcesRequired_MV;
    stringID    := GB_stResourcesRequired;
    FlagSet     := FlagSet + [MV_ResultVariable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_ResourcesRequired.InitData;
  var
    t, i : byte;
  begin
    for i := 1 to RN_ST_MaxSummaryTable do
      for t := 1 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0.0;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_ResourcesRequired.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_ResourcesRequired.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t1, t2, t3                     : byte;
    i, t, MstID, CurrID, c, c1     : integer;
    VariablesRW    : RN_MV_TVariablesRW;
  begin
    VariablesRW  := GetRNData(p).GetVariablesRWMV;
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    Inc(currRow); // skip header strings

    for i := 1 to VariablesRW.RN_MaxSummaryTableRW do
    begin
      MstID := sheet.ints[GB_RW_DataStartCol, currRow];
      CurrID := GetRN_STConstantCurrID(MstID);
      if (CurrID <> 0) then
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[CurrID, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_ResourcesRequired.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : byte;
  begin
    (* Header Strings *)
    sheet.cells[GB_RW_NotesCol, currRow] := 'Name';
    sheet.cells[GB_RW_DataStartCol, currRow] := 'Master ID';
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[GB_RW_DataStartCol + 1 + t - GetGBCalcYearIdx(GetProj), currRow] := GetGBCalcYear(GetProj) + t - 1;
    Inc(currRow);

    for i := 1 to RN_ST_MaxSummaryTable do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_STConstantString(i);
      sheet.ints[GB_RW_DataStartCol, currRow] := GetRN_STConstantMstID(i);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1), currRow] := value[i, t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_ResourcesRequired.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex : byte;
  begin
  oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_ST_MaxSummaryTable + 1, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_ST_MaxSummaryTable do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;

  function RN_MV_ResourcesRequired.GetString(i2 : integer) : string;
  begin
    Result := GetRN_StConstantString(i2);
  end;
{$ENDREGION}

{$REGION 'RN_MV_NumberPeopleReached'}
  constructor RN_MV_NumberPeopleReached.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag         := RN_TG_NumberPeopleReached_MV;
    stringID    := GB_stNumberPeopleReached;
    FlagSet     := FlagSet + [MV_ResultVariable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_NumberPeopleReached.InitData;
  var
    t,i : byte;
  begin
    for i := 1 to RN_ST_MaxSummaryTable do
      for t := 1 to GetGBFinalYearIdx(GetProj) do
        value[i, t] := 0.0;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_NumberPeopleReached.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_NumberPeopleReached.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    VariablesRW    : RN_MV_TVariablesRW;
    t1, t2, t3                     : byte;
    i, t, MstID, CurrID, c, c1     : integer;
  begin
    VariablesRW  := GetRNData(p).GetVariablesRWMV;
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol + 1, t1, t2, t3, c1);

    Inc(currRow); // skip header strings

    for i := 1 to VariablesRW.RN_MaxSummaryTableRW do
    begin
      MstID := sheet.ints[GB_RW_DataStartCol, currRow];
      CurrID := GetRN_STConstantCurrID(MstID);
      if (CurrID <> 0) then
      begin
        c := c1;
        for t := t1 to t2 do
        begin
          value[CurrID, t] := sheet.floats[c, currRow];
          Inc(c);
        end;
      end;
      Inc(currRow);
    end;
  end;

  procedure RN_MV_NumberPeopleReached.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i, t : byte;
  begin
    (* Header Strings *)
    sheet.cells[GB_RW_NotesCol, currRow] := 'Name';
    sheet.cells[GB_RW_DataStartCol, currRow] := 'Master ID';
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[GB_RW_DataStartCol + 1 + t - GetGBCalcYearIdx(GetProj), currRow] := GetGBCalcYear(GetProj) + t - 1;
    Inc(currRow);

    for i := 1 to RN_ST_MaxSummaryTable do
    begin
      sheet.cells[GB_RW_NotesCol, currRow] := GetRN_STConstantString(i);
      sheet.ints[GB_RW_DataStartCol, currRow] := GetRN_STConstantMstID(i);
      for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
        sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj) + 1), currRow] := value[i, t];
      Inc(currRow);
    end;
  end;

  procedure RN_MV_NumberPeopleReached.Resize(action : byte; finalIndex : integer);
  var
    t, i,
    oldIndex : byte;
  begin
  oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value[0]) - 1);

    SetLength(value, RN_ST_MaxSummaryTable + 1, finalIndex +1 );

(* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for i := 0 to RN_ST_MaxSummaryTable do
          for t := oldIndex + 1 to finalIndex do
            value[i, t] := value[i, t - 1];
  end;


  function RN_MV_NumberPeopleReached.GetString(i2 : integer) : string;
  begin
    Result := GetRN_StConstantString(i2);
  end;
{$ENDREGION}

{$REGION 'RN_MV_PMTCTCosts'}
  constructor RN_MV_PMTCTCosts.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_PMTCTCosts_MV;
    stringID := GB_stPMTCTCosts;
    FlagSet  := FlagSet + [MV_ResultVariable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_PMTCTCosts.InitData;
  var
    t : byte;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999);
    SetLDec(6);
    SetRDec(0);
    SetSource('');
  end;

  destructor RN_MV_PMTCTCosts.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_PMTCTCosts.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_PMTCTCosts.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_PMTCTCosts.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_TotalCosts'}
  constructor RN_MV_TotalCosts.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_TotalCosts_MV;
    stringID := GB_stTotalCosts;
    FlagSet  := FlagSet + [MV_ResultVariable, MV_RW_ImportData, MV_RW_ExtendFinalYr];

    InitData;
  end;

  procedure RN_MV_TotalCosts.InitData;
  var
    t : integer;
  begin
    (* Value *)
    for t := 0 to GetGBFinalYearIdx(GetProj) do
      value[t] := 0;

    SetMin(0);
    SetMax(999999999);
    SetLDec(12);
    SetRDec(2);
    SetSource('');
  end;

  destructor RN_MV_TotalCosts.Destroy;
  begin
    inherited Destroy;
    finalize(value);
  end;

  procedure RN_MV_TotalCosts.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    t, t1, t2, t3 : byte;
    c, c1         : integer;
  begin
    GetGBYearAndColIndices(actionRW, GetGBFinalYearIdx(GetProj), firstYr,
      finalYr, GB_RW_DataStartCol, t1, t2, t3, c1);

    c := c1;
    for t := t1 to t2 do
    begin
      value[t] := sheet.floats[c, currRow];
      Inc(c);
    end;

    Inc(currRow);
  end;

  procedure RN_MV_TotalCosts.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value) then
      oldIndex := Max(0, Length(value) - 1);

    SetLength(value, finalIndex +1 );

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value[t] := value[t - 1];
  end;

  procedure RN_MV_TotalCosts.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    t : byte;
  begin
    for t := GetGBCalcYearIdx(GetProj) to GetGBFinalYearIdx(GetProj) do
      sheet.floats[(GB_RW_DataStartCol + t - GetGBCalcYearIdx(GetProj)), currRow] := value[t];
    Inc(currRow);
  end;

{$ENDREGION}

{$REGION 'RN_MV_OptimizerVars'}
  constructor RN_MV_OptimizerVars.Create(aOwner : GB_TXXData);
  begin
    inherited Create(aOwner);

    tag      := RN_TG_OptimizerVars_MV2;
    stringID := GB_stNull;
    FlagSet  := FlagSet + [];

    InitData;
  end;

  destructor RN_MV_OptimizerVars.Destroy;
  begin
    inherited Destroy;

    finalize(value.Coverages);
    finalize(value.FundingAmnts);
    finalize(value.CostInfectionsAverted);
    finalize(value.CostAIDSDeathsAverted);
    finalize(value.CostDALYsAverted);
  end;

  procedure RN_MV_OptimizerVars.InitData;
  var
    i,
    t         : byte;
    cov, iv   : integer;
  begin

    value.StartYearIndex := 0;
    value.TargetYearIndex := GetGBCalcYearIdx(GetProj);
    value.FinalYearIndex := GetGBFinalYearIdx(GetProj);

    value.GoalIndex := 0;
    value.DiscountRate := 3;

    value.LoadDefaultValues := true;

    for cov := RN_MinCov  to RN_MaxCov do
      for iv := 1 to RN_OP_MaxOptimize do
        value.Coverages[cov, iv] := 0;

    SetLength(value.FundingAmnts, GetGBFinalYearIdx(GetProj) + 1);

    for t := 1 to GetGBFinalYearIdx(GetProj) do
      value.FundingAmnts[t] := 0;

    value.CEAValuesAvailable := false;
    value.UsePriorCEAValues := false;
    for i := RN_ComMob to RN_MaxCEA do
    begin
      value.CostInfectionsAverted[i] := 0;
      value.CostAIDSDeathsAverted[i] := 0;
      value.CostDALYsAverted[i] := 0;
    end;
  end;

  procedure RN_MV_OptimizerVars.Read(p : byte; tag : string;  sheet: GB_TFile;
    var currRow: integer; actionRW: byte; var firstYr, finalYr: integer);
  var
    i,
    t             : byte;
    iv,
    multiplier,
    offset        : integer;
  begin
    value.StartYearIndex := sheet.ints[GB_RW_DataStartCol,currRow];
    Inc(currRow);
    value.TargetYearIndex := sheet.ints[GB_RW_DataStartCol,currRow];
    Inc(currRow);
    value.FinalYearIndex := sheet.ints[GB_RW_DataStartCol,currRow];
    Inc(currRow);
    value.GoalIndex := sheet.ints[GB_RW_DataStartCol,currRow];
    Inc(currRow);
    value.DiscountRate := sheet.ints[GB_RW_DataStartCol,currRow];
    Inc(currRow);
    value.LoadDefaultValues := bool(sheet.ints[GB_RW_DataStartCol,currRow]);
    Inc(currRow);
    for iv := 1 to RN_OP_MaxOptimize do
      value.Coverages[RN_MinCov, iv] := sheet.Floats[GB_RW_NotesCol + iv, currRow];
    Inc(currRow);
    for iv := 1 to RN_OP_MaxOptimize do
      value.Coverages[RN_MaxCov, iv] := sheet.Floats[GB_RW_NotesCol + iv, currRow];
    Inc(currRow);
    SetLength(value.FundingAmnts, GetGBFinalYearIdx(GetProj) + 1);
    multiplier := 0;
    for t := 1 to GetGBFinalYearIdx(GetProj) do
    begin
      if t  mod RN_OP_MaxOptimize = 0 then
      begin
        Inc(currRow);
        Inc(multiplier);
      end;
      offset := t - multiplier * RN_OP_MaxOptimize;
      if multiplier > 0 then
        Inc(offset);

      value.FundingAmnts[t] := sheet.Floats[GB_RW_NotesCol + offset, currRow];
    end;

    Inc(currRow);
    value.CEAValuesAvailable := bool(sheet.ints[GB_RW_DataStartCol,currRow]);
    Inc(currRow);
    value.UsePriorCEAValues := bool(sheet.ints[GB_RW_DataStartCol,currRow]);
    Inc(currRow);
    for i := RN_ComMob to RN_MaxCEA do
      value.CostInfectionsAverted[i] := sheet.Floats[GB_RW_NotesCol + i, currRow];
    inc(currRow);
    for i := RN_ComMob to RN_MaxCEA do
      value.CostAIDSDeathsAverted[i] := sheet.Floats[GB_RW_NotesCol + i, currRow];
    inc(currRow);
    for i := RN_ComMob to RN_MaxCEA do
      value.CostDALYsAverted[i] := sheet.Floats[GB_RW_NotesCol + i, currRow];
  end;

  procedure RN_MV_OptimizerVars.Write(p: byte; sheet: GB_TFile;
    var currRow: integer; actionRW: byte);
  var
    i,
    t           : byte;
    iv,
    multiplier,
    offset      : integer;
  begin
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Start year index: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := value.StartYearIndex;
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Target year index: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := value.TargetYearIndex;
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Final year index: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := value.FinalYearIndex;
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Goal index: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := value.GoalIndex;
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Discount rate: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := value.DiscountRate;
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Load default values: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := byte(value.LoadDefaultValues);
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Min coverages: ';
    for iv := 1 to RN_OP_MaxOptimize do
      sheet.Floats[GB_RW_NotesCol + iv, currRow] := value.Coverages[RN_MinCov, iv];
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Max coverages: ';
    for iv := 1 to RN_OP_MaxOptimize do
      sheet.Floats[GB_RW_NotesCol + iv, currRow] := value.Coverages[RN_MaxCov, iv];
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Funding values: ';
    multiplier := 0;
    for t := 1 to GetGBFinalYearIdx(GetProj) do
    begin
      if t mod RN_OP_MaxOptimize = 0 then
      begin
        Inc(currRow);
        Inc(multiplier);
      end;
      offset := t - multiplier * RN_OP_MaxOptimize;
      if multiplier > 0 then
        Inc(offset);

      sheet.Floats[GB_RW_NotesCol + offset, currRow] := value.FundingAmnts[t];
    end;

    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'CEA values available: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := byte(value.CEAValuesAvailable);
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Use prior CEA values: ';
    sheet.ints[GB_RW_DataStartCol,currRow] := byte(value.UsePriorCEAValues);
    Inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Cost of infections averted: ';
    for i := RN_ComMob to RN_MaxCEA do
      sheet.Floats[GB_RW_NotesCol + i, currRow] := value.CostInfectionsAverted[i];
    inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Cost of AIDS deaths averted: ';
    for i := RN_ComMob to RN_MaxCEA do
      sheet.Floats[GB_RW_NotesCol + i, currRow] := value.CostAIDSDeathsAverted[i];
    inc(currRow);
    sheet.Cells[GB_RW_NotesCol,currRow] := 'Cost of DALYs averted: ';
    for i := RN_ComMob to RN_MaxCEA do
      sheet.Floats[GB_RW_NotesCol + i, currRow] := value.CostDALYsAverted[i];
  end;

  procedure RN_MV_OptimizerVars.Resize(action : byte; finalIndex : integer);
  var
    t,
    oldIndex : byte;
  begin
    oldIndex := 0;
    if assigned (value.FundingAmnts) then
      oldIndex := Max(0, Length(value.FundingAmnts) - 1);

    SetLength(value.FundingAmnts, finalIndex +1 );
    SetLength(value.Coverages, RN_MaxCov + 1, RN_OP_MaxOptimize + 1);
    SetLength(value.CostInfectionsAverted, RN_MaxCEA + 1);
    SetLength(value.CostAIDSDeathsAverted, RN_MaxCEA + 1);
    SetLength(value.CostDALYsAverted, RN_MaxCEA + 1);

    (* If extending, flatline the values from the final index. *)
    if action = GB_FINALYEAR_CHANGE then
      if oldIndex < finalIndex then
        for t := oldIndex + 1 to finalIndex do
          value.FundingAmnts[t] := value.FundingAmnts[t - 1];
  end;

{$ENDREGION}
