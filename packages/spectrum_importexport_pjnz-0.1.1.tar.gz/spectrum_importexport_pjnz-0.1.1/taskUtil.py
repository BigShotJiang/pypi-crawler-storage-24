import os
from os import environ as env
import ujson
import traceback
from loguru import logger
import aiohttp
import ssl
import certifi

from AvenirCommon.Logger import set_pt_log_level

from SpectrumCommon.ServerUtils.MakeAuthenticatedCalls import make_post


async def fetch_task_by_id(task_id):
    """
    Fetch a task by its ID from the task API server.
    Args:
        task_id (str): The ID of the task to fetch.
    Returns:
        dict or None: The task data as a dictionary if found, otherwise None.
    Raises:
        Exception: If there is an error in making the POST request or parsing the response.
    """
    task_url = os.environ.get("AVENIR_SW_TASK_URL")
    headers = {}
    logger.debug(task_url)

    task = ujson.loads(make_post(f'{task_url}/tasks/fetchTask', data={"id": task_id}, headers=headers).body)
    if 'id' not in task:
        return None
    return task


async def accept_task(task_id, version=""):
    """
    Accepts a task by sending a POST request to update the task with a working status.
    Args:
        task_id (str): The ID of the task to be accepted.
        version (str, optional): The version of the task. Defaults to an empty string.
    Returns:
        dict: The response from the server parsed as a dictionary.
    Raises:
        Exception: If the POST request fails or the response cannot be parsed.
    """
    task_url = os.environ.get("AVENIR_SW_TASK_URL")
    headers = {}

    payload = {
        "id": task_id,
        "version": version,
    }
    logger.info(version)
    return ujson.loads(make_post(f'{task_url}/tasks/updateTaskWithWorking', data=payload, headers=headers).body)


async def errored_task(task_id, errorMsg="Test", payloadContents={}):
    """
    Asynchronously sends an error task to the specified task URL.
    Args:
        task_id (str): The ID of the task that encountered an error.
        errorMsg (str, optional): The error message to be sent. Defaults to "Test".
        payloadContents (dict, optional): Additional payload contents to be included. Defaults to {}.
    Returns:
        dict: The response from the server parsed as a dictionary.
    Raises:
        Exception: If the request to the server fails.
    Environment Variables:
        AVENIR_SW_TASK_URL (str): The URL of the task server.
    """
    task_url = os.environ.get("AVENIR_SW_TASK_URL")
    headers = {}

    payload = {
        "id": task_id,
        "error":{
            "message":errorMsg
        }
    }
    payload.update(payloadContents)

    return ujson.loads(make_post(f'{task_url}/tasks/errorTask', data=payload, headers=headers).body)

def updateTaskWithProgress(task_id, progress):
    task_url = os.environ.get("AVENIR_SW_TASK_URL").strip('/')
    headers = {"AVENIR_SW_MODE":"beta"}
    # logger.error('task_url in updateTaskWithProgress: ' + task_url)
    payload = {
        "id": task_id,
        "progress": progress,
    }

    res = ujson.loads(make_post(f'{task_url}/tasks/updateTaskWithProgress', data=payload, headers=headers).body)
    return res

async def report_progress(task_id, progress):
    """
    Asynchronously reports the progress of a task to a specified URL.
    Args:
        task_id (str): The unique identifier of the task.
        progress (int): The current progress of the task, typically represented as a percentage.
    Returns:
        dict: The response from the server after updating the task progress.
    Raises:
        Exception: If the HTTP request fails or the response cannot be parsed.
    Environment Variables:
        AVENIR_SW_TASK_URL (str): The base URL for the task API.
    """
    return updateTaskWithProgress(task_id, progress)



async def post_result(task_id, result):
    """
    Asynchronously posts the result of a task to the specified task URL.
    Args:
        task_id (str): The unique identifier of the task.
        result (Any): The result to be posted for the task.
    Returns:
        dict: The response from the server after posting the result.
    Raises:
        Exception: If the request to the server fails.
    Environment Variables:
        AVENIR_SW_TASK_URL (str): The base URL for the task API server.
    """
    task_url = os.environ.get("AVENIR_SW_TASK_URL")
    headers = {"AVENIR_SW_MODE":"beta"}

    payload = {
        "id": task_id,
        "progress": 100,
        "result": result,
    }

    return ujson.loads(make_post(f'{task_url}/tasks/updateTaskWithProgress', data=payload, headers=headers).body)

async def updateTaskWithResultReady(task_id, result = {}):
    """
    Asynchronously updates a task with the result ready status.
    This function sends a POST request to the task API server to update the task
    with the given task ID and result data. The task API server URL is retrieved
    from the environment variable 'AVENIR_SW_TASK_URL'. The request includes
    a header indicating the mode as 'beta'.
    Args:
        task_id (str): The unique identifier of the task to be updated.
        result (dict, optional): The result data to be associated with the task. Defaults to an empty dictionary.
    Returns:
        dict: The response from the task API server parsed as a JSON object.
    Raises:
        Exception: If the POST request fails or the response cannot be parsed as JSON.
    """
    task_url = os.environ.get("AVENIR_SW_TASK_URL")
    headers = {"AVENIR_SW_MODE":"beta"}

    payload = {
        "id": task_id,
        "result": result,
    }

    return ujson.loads(make_post(f'{task_url}/tasks/updateTaskWithResultsReady', data=payload, headers=headers).body)

def updateEnvURLS(task):
    """
    Updates environment variables with URLs from the given task dictionary.

    This function sets the following environment variables:
    - AVENIR_SW_PM_URL
    - AVENIR_SW_CALC_URL
    - AVENIR_SW_DPS_URL
    - AVENIR_SW_FILTER_URL

    If the environment variable is already set, it will not be overwritten.

    Args:
        task (dict): A dictionary containing the following keys:
            - pmURL (str): URL for the project management service.
            - calcURL (str): URL for the calculation service.
            - dpsURL (str): URL for the data processing service.
            - filterURL (str): URL for the filter service.
    """
    os.environ['AVENIR_SW_PM_URL']     = os.environ.get("AVENIR_SW_PM_URL", task["pmURL"])
    os.environ['AVENIR_SW_CALC_URL']   = os.environ.get("AVENIR_SW_CALC_URL", task["calcURL"])
    os.environ['AVENIR_SW_DPS_URL']    = os.environ.get("AVENIR_SW_DPS_URL", task["dpsURL"])
    os.environ['AVENIR_SW_FILTER_URL'] = os.environ.get("AVENIR_SW_FILTER_URL", task["filterURL"])


def get_conn():
    """
    Creates and returns an aiohttp TCPConnector with SSL context. Needed for https requests.

    This function sets up an SSL context using the default CA certificates
    provided by the certifi package and uses it to create an aiohttp TCPConnector.

    Returns:
        aiohttp.TCPConnector: A TCPConnector instance configured with SSL context.
    """
    ssl_context = ssl.create_default_context(cafile=certifi.where())
    # global conn
    conn = aiohttp.TCPConnector(ssl=ssl_context)
    return conn

async def run_task(fn_task, tool_name):
    """
    Executes a given task function within the context of a specific tool, handling environment setup and error reporting.
    Args:
        fn_task (callable): The asynchronous function representing the task to be executed.
        tool_name (str): The name of the tool associated with the task.
    Raises:
        Exception: If there is an error fetching the task or running the task, it logs the error and updates the task status accordingly.
    Environment Variables:
        AVENIR_TASK_ID (str): The ID of the task to be fetched and executed.
        AVENIR_SW_MODE (str): The software mode environment variable used for setting the log level (default is "beta").
    Logging:
        Logs various debug and error messages throughout the task execution process.
    Workflow:
        1. Fetches the task using the task ID from the environment variables.
        2. Updates environment variables based on the fetched task.
        3. Sets the log level if specified in the task payload.
        4. Executes the provided task function.
        5. Handles any exceptions by logging errors, updating the task status, and posting the result.
    """
    task_id = os.environ["AVENIR_TASK_ID"]
    # task_id = '99191dc5-f84a-4eaf-bc4d-4f910999be96'
    try:
        logger.debug(f"fetching task {task_id}")
        task = await fetch_task_by_id(task_id)
        logger.debug(f"fetched task {task_id}")
    except Exception as e:
        logger.error(f'failed to fetch task {task_id}')
        logger.error(f'task {task_id} e={e}')
        await errored_task(task_id)

    try:
        if task:
            logger.debug(task)
            logger.debug(f"updating env variables {task_id}")
            updateEnvURLS(task)
            if 'logLevel' in task['payload']:
                logger.debug(f"setting log level {task_id}")
                set_pt_log_level(task['payload']['logLevel'],
                    program=f'{tool_name} worker',
                    env=env.get("AVENIR_SW_MODE", "beta")
                )
            logger.debug(f"running tool {tool_name} {task_id}")
            await fn_task(task)
    except Exception as e:
        logger.error(f'failed to run task {task_id}')
        logger.error(f'task {task_id} e={e}')
        call_stack = traceback.format_exception(e)
        logger.error(call_stack)
        await errored_task(task_id)
        task = await fetch_task_by_id(task_id)
        result = task['result']
        result['msg'] = e.args[0]
        await post_result(task_id, result)
