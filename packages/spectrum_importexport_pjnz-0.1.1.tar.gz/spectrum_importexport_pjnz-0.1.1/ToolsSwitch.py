# Tool imports
def tool_fn_switch(tool_name):
    match tool_name:
        case 'aggregate':              from Tools.AM.Aggregate.AMAggregate import process_aim_aggregate as tool_fn
        case 'fitWithLocalAdj':        from Tools.AM.FitLocalAdjustment.AMFitLocalAdj import process_aim_fit_local_adj_task as tool_fn
        case 'sexAge':                 from Tools.AM.SexAge.SexAge import process_sex_age_task as tool_fn
        case 'extract':                from Tools.GB.Extract.ExtractWorker import process_extract as tool_fn
        case 'multiproj':              from Tools.GB.Multiproj.MultiprojWorker import process_multiproj as tool_fn
        case 'aimUncertaintyAnalyses': from Tools.AM.UncertaintyAnalysis.AMUncertaintyAnalyses import process_aim_ua as tool_fn
        case 'LiST_SG':                from Tools.CS.SG.CSScenarioGenerator import process_list_scenario_generator as tool_fn
        case 'tbdynamicalmodel':       from Tools.TB.TBDynamicalModelTool.TBDynamicalModelTool import process_tb_dynamical_task as tool_fn
        case 'gam':                    from Tools.AM.GAM.AMGAMWorker import process_aim_gam_task as tool_fn
        case 'ihtdataimport':          from Tools.IH.IHTDataImportTool.IHTDataImportTool import process_iht_data_import_task as tool_fn
        case 'test':                   from Tools.GB.Test.TestWorker import process_test as tool_fn
        case _: raise Exception('No tool found')
    return tool_fn
