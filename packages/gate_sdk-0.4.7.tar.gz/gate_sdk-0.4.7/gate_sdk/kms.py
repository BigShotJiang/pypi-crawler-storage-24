"""
Gate SDK - KMS Wrapper

Wraps boto3 KMS client to intercept sign() calls and enforce Gate policies.
"""

import hashlib
from typing import Dict, Any, Optional, Callable, Literal, Union
from types import MethodType

from .client import GateClient
from .errors import (
    BlockIntelBlockedError,
    BlockIntelStepUpRequiredError,
    GateError,
)
from .tx_digest import build_tx_binding_object, compute_tx_digest


class WrapKmsClientOptions:
    """KMS wrapper options"""

    def __init__(
        self,
        mode: Literal["enforce", "dry-run"] = "enforce",
        on_decision: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        extract_tx_intent: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
        additional_signing_context: Optional[Union[Dict[str, Any], Callable[[], Dict[str, Any]]]] = None,
    ):
        """
        Initialize wrapper options.

        Args:
            mode: Wrapper mode ("enforce" or "dry-run")
            on_decision: Callback invoked when a decision is made
            extract_tx_intent: Custom hook to extract transaction intent from sign params
            additional_signing_context: Additional fields to merge into signingContext.
                May be a dict (e.g., run_id) or a callable returning a dict (for per-sign
                context such as caller repo/workflow for provenance).
        """
        self.mode = mode
        self.on_decision = on_decision or (lambda decision, details: None)
        self.extract_tx_intent = extract_tx_intent or default_extract_tx_intent
        self.additional_signing_context = additional_signing_context or {}


class WrappedKmsClient:
    """Wrapped KMS client that enforces Gate policies"""

    def __init__(
        self,
        original_client: Any,  # boto3.client("kms")
        gate_client: GateClient,
        options: WrapKmsClientOptions,
    ):
        """
        Initialize wrapped KMS client.

        Args:
            original_client: Original boto3 KMS client
            gate_client: Gate client for evaluation
            options: Wrapper options
        """
        self._original_client = original_client
        self._gate_client = gate_client
        self._options = options

        # Preserve all original client methods and attributes
        for attr_name in dir(original_client):
            if not attr_name.startswith("_") and attr_name != "sign":
                try:
                    attr_value = getattr(original_client, attr_name)
                    if not callable(attr_value) or isinstance(attr_value, MethodType):
                        setattr(self, attr_name, attr_value)
                except AttributeError:
                    pass

    def sign(self, **kwargs) -> Dict[str, Any]:
        """
        Intercept sign() call and evaluate with Gate before forwarding to KMS.

        Args:
            **kwargs: KMS sign() parameters (KeyId, Message, MessageType, SigningAlgorithm)

        Returns:
            KMS sign response

        Raises:
            BlockIntelBlockedError: If Gate blocks the transaction
            BlockIntelStepUpRequiredError: If step-up is required
        """
        return self._handle_sign_call(kwargs)

    def _handle_sign_call(self, sign_params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle intercepted sign() call"""

        # Extract transaction intent
        tx_intent = self._options.extract_tx_intent(sign_params)

        # Extract signer ID from KeyId
        # Normalize KeyId to match heartbeat signer_id format (remove 'alias/' prefix if present)
        key_id = sign_params.get("KeyId", "unknown")
        # Normalize: 'alias/gate-canary-trading-bot' -> 'gate-canary-trading-bot'
        # This ensures heartbeat signer_id matches what we use here
        signer_id = key_id.replace("alias/", "") if key_id.startswith("alias/") else key_id

        # Update heartbeat manager with actual signer_id from KeyId
        # This may invalidate the current token if signer_id changed
        # Skip if heartbeat manager is None (local mode)
        heartbeat_token = None
        if self._gate_client._heartbeat_manager is not None:
            self._gate_client._heartbeat_manager.update_signer_id(signer_id)
            # Get heartbeat token (if available) - but don't block here
            # Let the Hot Path handle heartbeat validation to ensure decisions are saved
            heartbeat_token = self._gate_client._heartbeat_manager.get_token()
        
        # Debug logging for heartbeat token in KMS wrapper
        import logging
        logger = logging.getLogger(__name__)
        if heartbeat_token:
            logger.debug(f'[KMS WRAPPER] Heartbeat token available for sign() call (length={len(heartbeat_token)})')
        else:
            # More detailed logging to understand why token is None
            logger.warning('[KMS WRAPPER] No heartbeat token available for sign() call', extra={
                'has_heartbeat_manager': self._gate_client._heartbeat_manager is not None,
                'heartbeat_manager_started': self._gate_client._heartbeat_manager._started if self._gate_client._heartbeat_manager else False,
                'has_current_token': self._gate_client._heartbeat_manager._current_token is not None if self._gate_client._heartbeat_manager else False,
                'signer_id': signer_id,
            })

        # Build signing context
        signing_context = {
            "signerId": signer_id,
            "actorPrincipal": "kms-signer",  # Default
            **({"heartbeatToken": heartbeat_token} if heartbeat_token else {}),  # Attach heartbeat token if available
            **(
                self._options.additional_signing_context()
                if callable(self._options.additional_signing_context)
                else (self._options.additional_signing_context or {})
            ),  # Merge additional fields (e.g., run_id, caller for provenance)
        }
        
        # Log signing context for debugging (including provenance caller)
        has_caller = bool(signing_context.get("caller"))
        caller_repo = signing_context.get("caller", {}).get("repo") if has_caller else None
        caller_workflow = signing_context.get("caller", {}).get("workflow") if has_caller else None
        logger.info(
            f'[KMS WRAPPER] Signing context: signerId={signer_id}, hasCaller={has_caller}, '
            f'caller.repo={caller_repo!r}, caller.workflow={caller_workflow!r}'
        )

        try:
            # Call Gate evaluate() with correct signature for gate_sdk
            # gate_sdk.evaluate() expects: evaluate(req={'txIntent': ..., 'signingContext': ...}, request_id=None)
            decision = self._gate_client.evaluate(
                {
                    "txIntent": tx_intent,
                    "signingContext": signing_context,
                },
                None,  # request_id (optional, None = auto-generate)
            )

            # Decision is ALLOW - verify decision token binding when required
            if (
                decision.get("decision") == "ALLOW"
                and self._gate_client.get_require_decision_token()
                and decision.get("txDigest") is not None
            ):
                binding = build_tx_binding_object(
                    tx_intent,
                    signer_id=signer_id,
                    decoded_recipient=None,
                    decoded_fields=None,
                    from_address=tx_intent.get("fromAddress") or tx_intent.get("from"),
                )
                computed_digest = compute_tx_digest(binding)
                if computed_digest != decision["txDigest"]:
                    err = BlockIntelBlockedError(
                        reason_code="DECISION_TOKEN_TX_MISMATCH",
                        receipt_id=decision.get("decisionId"),
                        correlation_id=decision.get("correlationId"),
                        request_id=None,
                    )
                    self._options.on_decision("BLOCK", {"error": err, "signerId": signer_id, "params": sign_params})
                    raise err

            # Decision is ALLOW (evaluate() doesn't throw)
            self._options.on_decision("ALLOW", {"decision": decision, "signerId": signer_id, "params": sign_params})

            if self._options.mode == "dry-run":
                # Dry-run mode: evaluate but still allow
                return self._original_client.sign(**sign_params)

            # Check adoption stage from heartbeat - at Gateway stages, route to signing proxy
            # HSM Gateway uses local PKCS#11 signing (GenericHsmSigner), not this proxy
            GATEWAY_STAGES = ("HARD_KMS_GATEWAY", "HARD_GCP_GATEWAY")
            current_stage = None
            if self._gate_client._heartbeat_manager is not None:
                current_stage = getattr(self._gate_client._heartbeat_manager, '_adoption_stage', None)

            if current_stage and current_stage in GATEWAY_STAGES:
                # At KMS Gateway: app role has NO kms:Sign. Route to Gate's signing proxy.
                logger.info(f'[KMS WRAPPER] Stage={current_stage}, routing to signing proxy')
                return self._sign_via_proxy(decision, sign_params, signer_id)

            # Pre-Gateway stages: forward to real KMS (app has kms:Sign)
            return self._original_client.sign(**sign_params)

        except BlockIntelBlockedError as error:
            # Gate blocked the transaction
            self._options.on_decision("BLOCK", {"error": error, "signerId": signer_id, "params": sign_params})
            raise

        except BlockIntelStepUpRequiredError as error:
            # Step-up required
            self._options.on_decision(
                "REQUIRE_STEP_UP", {"error": error, "signerId": signer_id, "params": sign_params}
            )
            raise

        except Exception as error:
            # Other errors (network, auth, etc.) - re-raise
            raise

    def _sign_via_proxy(self, decision: Dict[str, Any], sign_params: Dict[str, Any], signer_id: str) -> Dict[str, Any]:
        """
        Sign via Gate's server-side proxy (POST /defense/sign).
        Used at HARD_KMS_GATEWAY+ stages where the app has no kms:Sign permission.
        Gate's control plane assumes a cross-account role to sign with the customer's KMS key.
        """
        import base64
        import json
        import logging
        import urllib.request
        import urllib.error

        logger = logging.getLogger(__name__)

        config = self._gate_client._config if hasattr(self._gate_client, '_config') else {}
        base_url = getattr(config, 'base_url', None) or getattr(config, 'control_plane_url', None) or getattr(self._gate_client, '_base_url', '')
        tenant_id = getattr(config, 'tenant_id', None) or getattr(self._gate_client, '_tenant_id', '')

        if not base_url or not tenant_id:
            raise GateError("Cannot use signing proxy: base_url or tenant_id not configured")

        # Extract message from sign params
        message = sign_params.get("Message")
        if message is None:
            raise GateError("sign() missing Message for proxy signing")
        if isinstance(message, str):
            message = message.encode("utf-8")
        message_b64 = base64.b64encode(message).decode("ascii")

        key_id = sign_params.get("KeyId", "")
        signing_algorithm = sign_params.get("SigningAlgorithm", "ECDSA_SHA_256")
        message_type = sign_params.get("MessageType", "RAW")

        # Build proxy URL
        proxy_url = f"{base_url.rstrip('/').replace('/defense', '')}/tenants/{tenant_id}/defense/sign"

        body = json.dumps({
            "requestId": decision.get("decisionId") or decision.get("requestId"),
            "decisionToken": decision.get("decisionToken"),
            "keyId": key_id,
            "message": message_b64,
            "signingAlgorithm": signing_algorithm,
            "messageType": message_type,
        }).encode("utf-8")

        # Build auth headers
        headers = {"Content-Type": "application/json"}
        auth = getattr(config, 'auth', None) or getattr(self._gate_client, '_auth', {})
        if isinstance(auth, dict):
            if auth.get("mode") == "api_key" and auth.get("api_key"):
                headers["x-api-key"] = auth["api_key"]
        # Also try to get JWT from client
        jwt_token = getattr(self._gate_client, '_jwt', None)
        if jwt_token:
            headers["Authorization"] = f"Bearer {jwt_token}"

        req = urllib.request.Request(proxy_url, data=body, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            error_body = {}
            try:
                error_body = json.loads(e.read().decode("utf-8"))
            except Exception:
                pass
            code = error_body.get("error", {}).get("code", "SIGN_PROXY_FAILED")
            msg = error_body.get("error", {}).get("message", f"Signing proxy returned {e.code}")
            raise GateError(f"[Gate SDK] {code}: {msg}")

        data = result.get("data", {})
        signature = data.get("signature")
        if not signature:
            raise GateError("[Gate SDK] Signing proxy returned no signature")

        # Return in the same format as boto3 kms.sign() response
        return {
            "Signature": base64.b64decode(signature),
            "KeyId": data.get("keyId", key_id),
            "SigningAlgorithm": data.get("signingAlgorithm", signing_algorithm),
            "ResponseMetadata": {"HTTPStatusCode": 200},
        }


def default_extract_tx_intent(sign_params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Default transaction intent extraction from KMS sign parameters.

    Extracts minimal txIntent from KMS sign params:
    - Uses Message hash as payloadHash
    - Sets networkFamily to 'OTHER' (unknown)
    - Sets signerId from KeyId
    """
    message = sign_params.get("Message")
    if message is None:
        return {
            "networkFamily": "OTHER",
            "toAddress": None,
            "payloadHash": None,
            "dataHash": None,
        }

    # Compute SHA256 hash of message
    if isinstance(message, bytes):
        message_bytes = message
    elif isinstance(message, str):
        message_bytes = message.encode("utf-8")
    else:
        # Try to convert to bytes
        message_bytes = bytes(message)

    message_hash = hashlib.sha256(message_bytes).hexdigest()

    return {
        "networkFamily": "OTHER",
        "toAddress": None,  # Unknown from KMS message alone
        "payloadHash": message_hash,
        "dataHash": message_hash,  # Backward compatibility
    }


def wrap_kms_client(
    kms_client: Any,  # boto3.client("kms")
    gate_client: GateClient,
    options: Optional[WrapKmsClientOptions] = None,
) -> WrappedKmsClient:
    """
    Wrap boto3 KMS client to intercept sign() calls.

    Args:
        kms_client: boto3 KMS client instance
        gate_client: Gate client for evaluation
        options: Wrapper options (optional)

    Returns:
        Wrapped KMS client that enforces Gate policies

    Example:
        ```python
        import boto3
        from gate_sdk import GateClient, wrap_kms_client

        kms = boto3.client("kms")
        gate = GateClient(
            base_url=os.getenv("GATE_BASE_URL"),
            tenant_id=os.getenv("GATE_TENANT_ID"),
            auth={"mode": "hmac", "key_id": os.getenv("GATE_KEY_ID"), "secret": os.getenv("GATE_HMAC_SECRET")},
        )

        protected_kms = wrap_kms_client(kms, gate)

        # Now calls to protected_kms.sign(...) will be intercepted
        result = protected_kms.sign(
            KeyId="alias/my-key",
            Message=b"...",
            MessageType="RAW",
            SigningAlgorithm="ECDSA_SHA_256",
        )
        ```
    """
    if options is None:
        options = WrapKmsClientOptions()

    return WrappedKmsClient(kms_client, gate_client, options)


