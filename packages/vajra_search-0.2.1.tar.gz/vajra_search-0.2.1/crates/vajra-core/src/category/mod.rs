//! Core Category Theory Primitives
//!
//! A category consists of:
//! - Objects (types)
//! - Morphisms (arrows between objects)
//! - Composition of morphisms
//! - Identity morphisms
//!
//! ## Categorical Laws
//!
//! **Identity**: For any morphism `f: A → B`:
//! - `f ∘ id_A = f`
//! - `id_B ∘ f = f`
//!
//! **Associativity**: For morphisms `f: A → B`, `g: B → C`, `h: C → D`:
//! - `(h ∘ g) ∘ f = h ∘ (g ∘ f)`

mod morphism;

pub use morphism::{Composed, FnMorphism, Identity, Morphism};
