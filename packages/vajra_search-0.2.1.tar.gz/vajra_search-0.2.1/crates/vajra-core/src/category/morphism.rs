//! Morphisms: arrows between objects in a category
//!
//! A morphism `f: A → B` is a structure-preserving map.
//!
//! ## Laws
//!
//! - **Identity**: `f ∘ id = f = id ∘ f`
//! - **Associativity**: `(h ∘ g) ∘ f = h ∘ (g ∘ f)`

use std::marker::PhantomData;

/// A morphism from type `A` to type `B`.
///
/// Morphisms are the fundamental arrows in category theory.
/// They represent structure-preserving transformations.
///
/// # Type Parameters
///
/// - `A`: The source object (domain)
/// - `B`: The target object (codomain)
///
/// # Example
///
/// ```
/// use vajra_core::category::{Morphism, FnMorphism};
///
/// let f = FnMorphism::new(|x: i32| x + 1);
/// let g = FnMorphism::new(|x: i32| x * 2);
/// let h = f.then(g); // (x + 1) * 2
///
/// assert_eq!(h.apply(5), 12);
/// ```
pub trait Morphism<A, B> {
    /// Apply this morphism to an object.
    ///
    /// This is the core operation: given an element of the domain,
    /// produce an element of the codomain.
    fn apply(&self, a: A) -> B;

    /// Compose this morphism with another: `self >> other` means apply self first, then other.
    ///
    /// If `self: A → B` and `other: B → C`, then `self.then(other): A → C`.
    ///
    /// This is "diagrammatic order" composition, reading left to right.
    fn then<C, G>(self, other: G) -> Composed<Self, G, A, B, C>
    where
        Self: Sized,
        G: Morphism<B, C>,
    {
        Composed::new(self, other)
    }

    /// Compose with another morphism using operator syntax.
    ///
    /// `f >> g` is equivalent to `f.then(g)`.
    fn compose<C, G>(self, other: G) -> Composed<Self, G, A, B, C>
    where
        Self: Sized,
        G: Morphism<B, C>,
    {
        self.then(other)
    }
}

/// Identity morphism: `id_A: A → A`
///
/// The identity morphism does nothing - it returns its input unchanged.
///
/// # Categorical Law
///
/// For any morphism `f: A → B`:
/// - `f ∘ id_A = f` (right identity)
/// - `id_B ∘ f = f` (left identity)
#[derive(Debug, Clone, Copy, Default)]
pub struct Identity<A>(PhantomData<A>);

impl<A> Identity<A> {
    /// Create a new identity morphism.
    pub fn new() -> Self {
        Identity(PhantomData)
    }
}

impl<A> Morphism<A, A> for Identity<A> {
    #[inline]
    fn apply(&self, a: A) -> A {
        a
    }
}

/// The composition of two morphisms.
///
/// If `f: A → B` and `g: B → C`, then `Composed(f, g): A → C`.
///
/// Application proceeds left to right: first `f`, then `g`.
#[derive(Debug, Clone)]
pub struct Composed<F, G, A, B, C>
where
    F: Morphism<A, B>,
    G: Morphism<B, C>,
{
    first: F,
    second: G,
    _phantom: PhantomData<(A, B, C)>,
}

impl<F, G, A, B, C> Composed<F, G, A, B, C>
where
    F: Morphism<A, B>,
    G: Morphism<B, C>,
{
    /// Create a new composed morphism.
    pub fn new(first: F, second: G) -> Self {
        Self {
            first,
            second,
            _phantom: PhantomData,
        }
    }
}

impl<F, G, A, B, C> Morphism<A, C> for Composed<F, G, A, B, C>
where
    F: Morphism<A, B>,
    G: Morphism<B, C>,
{
    #[inline]
    fn apply(&self, a: A) -> C {
        let b = self.first.apply(a);
        self.second.apply(b)
    }
}

/// A morphism implemented as a closure.
///
/// This is the most common way to create morphisms from plain functions.
///
/// # Example
///
/// ```
/// use vajra_core::category::{Morphism, FnMorphism};
///
/// let double = FnMorphism::new(|x: i32| x * 2);
/// assert_eq!(double.apply(21), 42);
/// ```
pub struct FnMorphism<F, A, B>
where
    F: Fn(A) -> B,
{
    func: F,
    _phantom: PhantomData<(A, B)>,
}

impl<F, A, B> FnMorphism<F, A, B>
where
    F: Fn(A) -> B,
{
    /// Create a new function-based morphism.
    pub fn new(func: F) -> Self {
        Self {
            func,
            _phantom: PhantomData,
        }
    }
}

impl<F, A, B> Morphism<A, B> for FnMorphism<F, A, B>
where
    F: Fn(A) -> B,
{
    #[inline]
    fn apply(&self, a: A) -> B {
        (self.func)(a)
    }
}

impl<F: Clone, A, B> Clone for FnMorphism<F, A, B>
where
    F: Fn(A) -> B,
{
    fn clone(&self) -> Self {
        Self {
            func: self.func.clone(),
            _phantom: PhantomData,
        }
    }
}

// Implement Debug for FnMorphism (can't show the function, but can indicate it exists)
impl<F, A, B> std::fmt::Debug for FnMorphism<F, A, B>
where
    F: Fn(A) -> B,
{
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("FnMorphism")
            .field("func", &"<closure>")
            .finish()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_identity_law() {
        let id: Identity<i32> = Identity::new();
        assert_eq!(id.apply(42), 42);
    }

    #[test]
    fn test_function_morphism() {
        let f = FnMorphism::new(|x: i32| x + 1);
        assert_eq!(f.apply(5), 6);
    }

    #[test]
    fn test_composition() {
        let f = FnMorphism::new(|x: i32| x + 1);
        let g = FnMorphism::new(|x: i32| x * 2);
        let h = f.then(g);
        // (5 + 1) * 2 = 12
        assert_eq!(h.apply(5), 12);
    }

    #[test]
    fn test_composition_associativity() {
        // Test: (h ∘ g) ∘ f = h ∘ (g ∘ f)
        let f = FnMorphism::new(|x: i32| x + 1);
        let g = FnMorphism::new(|x: i32| x * 2);
        let h = FnMorphism::new(|x: i32| x - 3);

        // Left association: (f >> g) >> h
        let fg = FnMorphism::new(|x: i32| x + 1).then(FnMorphism::new(|x: i32| x * 2));
        let left = fg.then(FnMorphism::new(|x: i32| x - 3));

        // Right association: f >> (g >> h)
        let gh = FnMorphism::new(|x: i32| x * 2).then(FnMorphism::new(|x: i32| x - 3));
        let right = FnMorphism::new(|x: i32| x + 1).then(gh);

        // Both should give same result: ((5 + 1) * 2) - 3 = 9
        assert_eq!(left.apply(5), 9);
        assert_eq!(right.apply(5), 9);
    }

    #[test]
    fn test_identity_is_neutral() {
        let f = FnMorphism::new(|x: i32| x * 2);
        let id: Identity<i32> = Identity::new();

        // f ∘ id = f (but we need to test via apply since types differ)
        let f_then_id = FnMorphism::new(|x: i32| x * 2).then(Identity::new());
        let id_then_f = Identity::<i32>::new().then(FnMorphism::new(|x: i32| x * 2));

        assert_eq!(f.apply(5), f_then_id.apply(5));
        assert_eq!(f.apply(5), id_then_f.apply(5));
    }
}
