//! Coalgebra trait and implementations
//!
//! A coalgebra (X, α) consists of:
//! - A carrier type X (the state space)
//! - A structure map α: X → F(X) (the transition/unfolding function)

use crate::functor::Tree;
use std::marker::PhantomData;

/// A coalgebra with carrier X and structure map α: X → F(X).
///
/// This is the categorical essence of state-based dynamics.
/// While algebras fold/consume data, coalgebras unfold/produce it.
///
/// # Type Parameters
///
/// - `X`: The carrier type (state space)
/// - `FX`: The functor applied to X, i.e., F(X)
///
/// # Example: Search Dynamics
///
/// For search, we use `F = List`, so:
/// - α: State → List[State]
/// - Each state unfolds into possible successor states
pub trait Coalgebra<X, FX> {
    /// The structure map α: X → F(X).
    ///
    /// Given a state, produce its unfolding in the functor F.
    /// This is the heart of dynamics.
    fn structure_map(&self, state: &X) -> FX;

    /// Unfold the coalgebra from an initial state (one step).
    ///
    /// This is just an alias for `structure_map`.
    fn unfold(&self, initial_state: &X) -> FX {
        self.structure_map(initial_state)
    }
}

/// A coalgebra for search: X → Vec<X>
///
/// Each state unfolds into a list of successor states.
/// This is the categorical essence of search.
///
/// The functor is List, capturing nondeterministic branching.
///
/// # Example
///
/// ```
/// use vajra_core::coalgebra::{Coalgebra, SearchCoalgebra};
///
/// // A simple graph: 1 -> [2, 3], 2 -> [4], 3 -> [4], 4 -> []
/// let coalgebra = SearchCoalgebra::new(|&state: &i32| {
///     match state {
///         1 => vec![2, 3],
///         2 | 3 => vec![4],
///         _ => vec![],
///     }
/// });
///
/// assert_eq!(coalgebra.structure_map(&1), vec![2, 3]);
/// assert_eq!(coalgebra.structure_map(&4), vec![]);
/// ```
pub struct SearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    successor_fn: F,
    _phantom: PhantomData<X>,
}

impl<X, F> SearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    /// Create a new search coalgebra with the given successor function.
    pub fn new(successor_fn: F) -> Self {
        Self {
            successor_fn,
            _phantom: PhantomData,
        }
    }
}

impl<X, F> Coalgebra<X, Vec<X>> for SearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    fn structure_map(&self, state: &X) -> Vec<X> {
        (self.successor_fn)(state)
    }
}

impl<X, F: Clone> Clone for SearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    fn clone(&self) -> Self {
        Self {
            successor_fn: self.successor_fn.clone(),
            _phantom: PhantomData,
        }
    }
}

/// A coalgebra for tree search: X → Tree<X>
///
/// Each state unfolds into a tree of successor states.
/// Captures hierarchical/recursive search structure.
pub struct TreeSearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    successor_fn: F,
    _phantom: PhantomData<X>,
}

impl<X, F> TreeSearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    /// Create a new tree search coalgebra.
    pub fn new(successor_fn: F) -> Self {
        Self {
            successor_fn,
            _phantom: PhantomData,
        }
    }

    /// Fully unfold the search tree to a given depth.
    ///
    /// This is corecursion: the categorical generative process.
    pub fn full_unfold(&self, initial_state: X, max_depth: usize) -> Tree<X>
    where
        X: Clone,
    {
        if max_depth == 0 {
            return Tree::leaf(initial_state);
        }

        let successors = (self.successor_fn)(&initial_state);
        let children = successors
            .into_iter()
            .map(|succ| self.full_unfold(succ, max_depth - 1))
            .collect();

        Tree::new(initial_state, children)
    }
}

impl<X: Clone, F> Coalgebra<X, Tree<X>> for TreeSearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    fn structure_map(&self, state: &X) -> Tree<X> {
        let successors = (self.successor_fn)(state);
        let children = successors.into_iter().map(Tree::leaf).collect();
        Tree::new(state.clone(), children)
    }
}

impl<X, F: Clone> Clone for TreeSearchCoalgebra<X, F>
where
    F: Fn(&X) -> Vec<X>,
{
    fn clone(&self) -> Self {
        Self {
            successor_fn: self.successor_fn.clone(),
            _phantom: PhantomData,
        }
    }
}

/// A coalgebra with termination conditions.
///
/// X → 1 + Vec<X>
///
/// Either terminates (empty) or continues with successors (Vec<X>).
/// This is closer to real search with goal states.
///
/// # Example
///
/// ```
/// use vajra_core::coalgebra::{Coalgebra, ConditionalCoalgebra};
///
/// // Search that stops at state 4
/// let coalgebra = ConditionalCoalgebra::new(
///     |&state: &i32| match state {
///         1 => vec![2, 3],
///         2 | 3 => vec![4],
///         _ => vec![],
///     },
///     |&state: &i32| state == 4,  // Terminal condition
/// );
///
/// // State 4 is terminal, so returns empty
/// assert_eq!(coalgebra.structure_map(&4), vec![]);
/// // State 1 is not terminal, returns successors
/// assert_eq!(coalgebra.structure_map(&1), vec![2, 3]);
/// ```
pub struct ConditionalCoalgebra<X, S, P>
where
    S: Fn(&X) -> Vec<X>,
    P: Fn(&X) -> bool,
{
    successor_fn: S,
    is_terminal: P,
    _phantom: PhantomData<X>,
}

impl<X, S, P> ConditionalCoalgebra<X, S, P>
where
    S: Fn(&X) -> Vec<X>,
    P: Fn(&X) -> bool,
{
    /// Create a new conditional coalgebra.
    ///
    /// # Arguments
    ///
    /// * `successor_fn` - Function that returns successor states
    /// * `is_terminal` - Predicate that returns true for terminal states
    pub fn new(successor_fn: S, is_terminal: P) -> Self {
        Self {
            successor_fn,
            is_terminal,
            _phantom: PhantomData,
        }
    }

    /// Check if a state is terminal.
    pub fn is_terminal(&self, state: &X) -> bool {
        (self.is_terminal)(state)
    }
}

impl<X, S, P> Coalgebra<X, Vec<X>> for ConditionalCoalgebra<X, S, P>
where
    S: Fn(&X) -> Vec<X>,
    P: Fn(&X) -> bool,
{
    fn structure_map(&self, state: &X) -> Vec<X> {
        if (self.is_terminal)(state) {
            vec![]
        } else {
            (self.successor_fn)(state)
        }
    }
}

impl<X, S: Clone, P: Clone> Clone for ConditionalCoalgebra<X, S, P>
where
    S: Fn(&X) -> Vec<X>,
    P: Fn(&X) -> bool,
{
    fn clone(&self) -> Self {
        Self {
            successor_fn: self.successor_fn.clone(),
            is_terminal: self.is_terminal.clone(),
            _phantom: PhantomData,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_search_coalgebra() {
        let coalgebra =
            SearchCoalgebra::new(|&x: &i32| if x < 3 { vec![x + 1, x + 2] } else { vec![] });

        assert_eq!(coalgebra.structure_map(&1), vec![2, 3]);
        assert_eq!(coalgebra.structure_map(&3), vec![]);
    }

    #[test]
    fn test_tree_search_coalgebra() {
        let coalgebra = TreeSearchCoalgebra::new(|&x: &i32| {
            if x < 3 {
                vec![x * 2, x * 2 + 1]
            } else {
                vec![]
            }
        });

        let tree = coalgebra.structure_map(&1);
        assert_eq!(tree.value, 1);
        assert_eq!(tree.children.len(), 2);
        assert_eq!(tree.children[0].value, 2);
        assert_eq!(tree.children[1].value, 3);
    }

    #[test]
    fn test_tree_full_unfold() {
        let coalgebra =
            TreeSearchCoalgebra::new(|&x: &i32| if x < 4 { vec![x * 2] } else { vec![] });

        let tree = coalgebra.full_unfold(1, 3);
        // 1 -> 2 -> 4 -> (nothing, depth exceeded before 8)
        assert_eq!(tree.value, 1);
        assert_eq!(tree.children[0].value, 2);
        assert_eq!(tree.children[0].children[0].value, 4);
    }

    #[test]
    fn test_conditional_coalgebra() {
        let coalgebra = ConditionalCoalgebra::new(
            |&x: &i32| vec![x + 1],
            |&x: &i32| x >= 5, // Terminal at 5+
        );

        assert_eq!(coalgebra.structure_map(&3), vec![4]);
        assert_eq!(coalgebra.structure_map(&5), vec![]); // Terminal
        assert!(coalgebra.is_terminal(&5));
        assert!(!coalgebra.is_terminal(&3));
    }

    #[test]
    fn test_coalgebra_unfold_alias() {
        let coalgebra = SearchCoalgebra::new(|&x: &i32| vec![x + 1]);
        // unfold is just an alias for structure_map
        assert_eq!(coalgebra.unfold(&1), coalgebra.structure_map(&1));
    }
}
