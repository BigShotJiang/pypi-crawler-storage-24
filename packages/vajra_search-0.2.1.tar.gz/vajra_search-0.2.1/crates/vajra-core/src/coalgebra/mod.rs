//! Coalgebras: The categorical structure for dynamics and unfolding
//!
//! A coalgebra for a functor F is:
//! - A carrier object X (the state space)
//! - A structure map α: X → F(X) (how states unfold)
//!
//! Coalgebras capture:
//! - Streams (infinite sequences)
//! - Transition systems
//! - Automata
//! - Search tree generation
//! - Any "productive" or "generative" process
//!
//! The dual of algebras (which fold/consume), coalgebras unfold/produce.

mod traits;

pub use traits::{Coalgebra, ConditionalCoalgebra, SearchCoalgebra, TreeSearchCoalgebra};
