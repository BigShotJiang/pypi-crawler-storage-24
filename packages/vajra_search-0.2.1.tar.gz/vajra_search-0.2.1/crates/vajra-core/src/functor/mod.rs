//! Functors: Structure-preserving maps between categories
//!
//! A functor `F: C → D` consists of:
//! - Object mapping: `F(A)` for each object `A` in `C`
//! - Morphism mapping: `F(f): F(A) → F(B)` for each morphism `f: A → B`
//!
//! ## Functor Laws
//!
//! **Identity**: `F(id_A) = id_F(A)`
//!
//! **Composition**: `F(g ∘ f) = F(g) ∘ F(f)`

mod traits;

pub use traits::{Functor, ListFunctor, OptionFunctor, Tree, TreeFunctor};
