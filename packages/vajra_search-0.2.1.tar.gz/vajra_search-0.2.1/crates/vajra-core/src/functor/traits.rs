//! Functor trait and implementations
//!
//! Functors lift morphisms from one category to another while preserving structure.

use crate::category::Morphism;

/// A functor maps objects and morphisms between categories.
///
/// # Type Parameters
///
/// This trait uses GATs (Generic Associated Types) to express the type constructor.
///
/// # Laws
///
/// 1. **Identity**: `F::fmap(id) = id`
/// 2. **Composition**: `F::fmap(g ∘ f) = F::fmap(g) ∘ F::fmap(f)`
pub trait Functor {
    /// The type constructor: given type `T`, produce `F<T>`.
    type Target<T>;

    /// Lift a value into the functor (pure/return in Haskell).
    fn pure<A>(a: A) -> Self::Target<A>;

    /// Map a function over the functor's contents.
    ///
    /// This is the standard `fmap` operation.
    fn fmap<A, B, F>(fa: Self::Target<A>, f: F) -> Self::Target<B>
    where
        F: Fn(A) -> B;

    /// Map a morphism over the functor.
    ///
    /// This is the categorical version using our Morphism trait.
    fn fmap_morphism<A, B, M>(fa: Self::Target<A>, m: &M) -> Self::Target<B>
    where
        M: Morphism<A, B>,
        A: Clone;
}

/// The List functor: maps types to vectors.
///
/// This captures nondeterministic or branching behavior:
/// - One state can unfold into multiple possible next states
/// - List represents all possible futures
///
/// # Mathematical Interpretation
///
/// `List(A) = A*` (Kleene star - finite sequences of A)
#[derive(Debug, Clone, Copy, Default)]
pub struct ListFunctor;

impl Functor for ListFunctor {
    type Target<T> = Vec<T>;

    fn pure<A>(a: A) -> Vec<A> {
        vec![a]
    }

    fn fmap<A, B, F>(fa: Vec<A>, f: F) -> Vec<B>
    where
        F: Fn(A) -> B,
    {
        fa.into_iter().map(f).collect()
    }

    fn fmap_morphism<A, B, M>(fa: Vec<A>, m: &M) -> Vec<B>
    where
        M: Morphism<A, B>,
        A: Clone,
    {
        fa.into_iter().map(|a| m.apply(a)).collect()
    }
}

impl ListFunctor {
    /// Create a new ListFunctor instance.
    pub fn new() -> Self {
        ListFunctor
    }

    /// Flatten a nested list (monadic join).
    pub fn flatten<A>(ffa: Vec<Vec<A>>) -> Vec<A> {
        ffa.into_iter().flatten().collect()
    }

    /// FlatMap (monadic bind): map then flatten.
    pub fn flat_map<A, B, F>(fa: Vec<A>, f: F) -> Vec<B>
    where
        F: Fn(A) -> Vec<B>,
    {
        fa.into_iter().flat_map(f).collect()
    }
}

/// The Option (Maybe) functor: captures computation that might fail.
///
/// `F(A) = A ∪ {None}`
///
/// Useful for search paths that might terminate or fail.
#[derive(Debug, Clone, Copy, Default)]
pub struct OptionFunctor;

impl Functor for OptionFunctor {
    type Target<T> = Option<T>;

    fn pure<A>(a: A) -> Option<A> {
        Some(a)
    }

    fn fmap<A, B, F>(fa: Option<A>, f: F) -> Option<B>
    where
        F: Fn(A) -> B,
    {
        fa.map(f)
    }

    fn fmap_morphism<A, B, M>(fa: Option<A>, m: &M) -> Option<B>
    where
        M: Morphism<A, B>,
        A: Clone,
    {
        fa.map(|a| m.apply(a))
    }
}

impl OptionFunctor {
    /// Create a new OptionFunctor instance.
    pub fn new() -> Self {
        OptionFunctor
    }
}

/// A tree data structure for the TreeFunctor.
///
/// Trees capture hierarchical branching in search.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Tree<A> {
    /// The value at this node.
    pub value: A,
    /// Child subtrees.
    pub children: Vec<Tree<A>>,
}

impl<A> Tree<A> {
    /// Create a new tree with a value and children.
    pub fn new(value: A, children: Vec<Tree<A>>) -> Self {
        Self { value, children }
    }

    /// Create a leaf node (no children).
    pub fn leaf(value: A) -> Self {
        Self {
            value,
            children: vec![],
        }
    }

    /// Check if this is a leaf node.
    pub fn is_leaf(&self) -> bool {
        self.children.is_empty()
    }

    /// Map a function over all values in the tree.
    pub fn map<B, F>(self, f: &F) -> Tree<B>
    where
        F: Fn(A) -> B,
    {
        Tree {
            value: f(self.value),
            children: self.children.into_iter().map(|c| c.map(f)).collect(),
        }
    }

    /// Get the depth of the tree.
    pub fn depth(&self) -> usize {
        if self.children.is_empty() {
            1
        } else {
            1 + self.children.iter().map(|c| c.depth()).max().unwrap_or(0)
        }
    }

    /// Count all nodes in the tree.
    pub fn size(&self) -> usize {
        1 + self.children.iter().map(|c| c.size()).sum::<usize>()
    }

    /// Collect all values in pre-order (root first).
    pub fn collect_preorder(&self) -> Vec<&A> {
        let mut result = vec![&self.value];
        for child in &self.children {
            result.extend(child.collect_preorder());
        }
        result
    }
}

/// The Tree functor: captures hierarchical branching.
///
/// Perfect for search trees where each state unfolds into a tree of possibilities.
#[derive(Debug, Clone, Copy, Default)]
pub struct TreeFunctor;

impl Functor for TreeFunctor {
    type Target<T> = Tree<T>;

    fn pure<A>(a: A) -> Tree<A> {
        Tree::leaf(a)
    }

    fn fmap<A, B, F>(fa: Tree<A>, f: F) -> Tree<B>
    where
        F: Fn(A) -> B,
    {
        fa.map(&f)
    }

    fn fmap_morphism<A, B, M>(fa: Tree<A>, m: &M) -> Tree<B>
    where
        M: Morphism<A, B>,
        A: Clone,
    {
        fn map_tree<A: Clone, B, M: Morphism<A, B>>(tree: Tree<A>, m: &M) -> Tree<B> {
            Tree {
                value: m.apply(tree.value),
                children: tree.children.into_iter().map(|c| map_tree(c, m)).collect(),
            }
        }
        map_tree(fa, m)
    }
}

impl TreeFunctor {
    /// Create a new TreeFunctor instance.
    pub fn new() -> Self {
        TreeFunctor
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::category::FnMorphism;

    #[test]
    fn test_list_functor_pure() {
        let xs = ListFunctor::pure(42);
        assert_eq!(xs, vec![42]);
    }

    #[test]
    fn test_list_functor_fmap() {
        let xs = vec![1, 2, 3];
        let ys = ListFunctor::fmap(xs, |x| x * 2);
        assert_eq!(ys, vec![2, 4, 6]);
    }

    #[test]
    fn test_list_functor_identity_law() {
        // F(id) = id
        let xs = vec![1, 2, 3];
        let ys = ListFunctor::fmap(xs.clone(), |x| x);
        assert_eq!(xs, ys);
    }

    #[test]
    fn test_list_functor_composition_law() {
        // F(g ∘ f) = F(g) ∘ F(f)
        let xs = vec![1, 2, 3];

        // Direct composition
        let left = ListFunctor::fmap(xs.clone(), |x| (x + 1) * 2);

        // Sequential fmap
        let intermediate = ListFunctor::fmap(xs, |x| x + 1);
        let right = ListFunctor::fmap(intermediate, |x| x * 2);

        assert_eq!(left, right);
    }

    #[test]
    fn test_option_functor() {
        let x = OptionFunctor::pure(42);
        assert_eq!(x, Some(42));

        let y = OptionFunctor::fmap(Some(5), |x| x * 2);
        assert_eq!(y, Some(10));

        let z: Option<i32> = OptionFunctor::fmap(None, |x: i32| x * 2);
        assert_eq!(z, None);
    }

    #[test]
    fn test_tree_functor() {
        let tree = Tree::new(1, vec![Tree::leaf(2), Tree::leaf(3)]);
        let mapped = TreeFunctor::fmap(tree, |x| x * 2);

        assert_eq!(mapped.value, 2);
        assert_eq!(mapped.children[0].value, 4);
        assert_eq!(mapped.children[1].value, 6);
    }

    #[test]
    fn test_tree_depth_and_size() {
        let tree = Tree::new(
            1,
            vec![
                Tree::new(2, vec![Tree::leaf(4), Tree::leaf(5)]),
                Tree::leaf(3),
            ],
        );
        assert_eq!(tree.depth(), 3);
        assert_eq!(tree.size(), 5);
    }

    #[test]
    fn test_fmap_morphism() {
        let m = FnMorphism::new(|x: i32| x + 10);
        let xs = vec![1, 2, 3];
        let ys = ListFunctor::fmap_morphism(xs, &m);
        assert_eq!(ys, vec![11, 12, 13]);
    }
}
