//! # Vajra Core - Categorical Abstractions
//!
//! Pure category theory primitives for building search systems.
//!
//! ## Mathematical Foundation
//!
//! A category consists of:
//! - **Objects**: Types in our programming context
//! - **Morphisms**: Structure-preserving maps between objects
//! - **Composition**: Combining morphisms (g ∘ f)
//! - **Identity**: The "do nothing" morphism for each object
//!
//! ## Modules
//!
//! - [`category`]: Core morphism definitions and composition
//! - [`functor`]: Functors that lift morphisms (List, Option, Tree)
//! - [`coalgebra`]: Coalgebras for dynamics and state unfolding

pub mod category;
pub mod coalgebra;
pub mod functor;

// Re-export main types for convenience
pub use category::{Composed, FnMorphism, Identity, Morphism};
pub use coalgebra::{Coalgebra, ConditionalCoalgebra, SearchCoalgebra, TreeSearchCoalgebra};
pub use functor::{Functor, ListFunctor, OptionFunctor, Tree, TreeFunctor};
