//! Criterion benchmarks for `vajra-hnsw`.
//!
//! Measures:
//! - **Index build**: time to insert N vectors (varies by N)
//! - **Single search**: single query against a 10 000-vector index
//! - **Batch search**: 100 queries in parallel via `search_batch`
//! - **Greedy descent**: isolated upper-layer traversal cost
//!
//! Run with:
//!     cargo bench -p vajra-hnsw
//! or for a quick smoke check:
//!     cargo bench -p vajra-hnsw -- --warm-up-time 1 --measurement-time 3

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion};
use vajra_hnsw::{HnswIndex, Metric};

// ─── Helpers ─────────────────────────────────────────────────────────────────

/// Deterministic pseudo-random vectors in [-1, 1].
fn gen_vectors(n: usize, dim: usize) -> Vec<f32> {
    (0..n * dim)
        .map(|k| {
            let i = k / dim;
            let d = k % dim;
            let raw = ((i * 6271 + d * 3571 + i * d * 13) % 9973) as f32 / 9973.0;
            raw * 2.0 - 1.0
        })
        .collect()
}

fn build_index(n: usize, dim: usize) -> HnswIndex {
    let vecs = gen_vectors(n, dim);
    let mut idx = HnswIndex::new(dim, Metric::L2, 16, 200, n + 10, 50);
    for i in 0..n {
        idx.add(&i.to_string(), &vecs[i * dim..(i + 1) * dim])
            .unwrap();
    }
    idx
}

// ─── Index build ─────────────────────────────────────────────────────────────

fn bench_index_build(c: &mut Criterion) {
    const DIM: usize = 128;
    let mut group = c.benchmark_group("index_build_l2_dim128");
    // Building an index is expensive; 10 samples is enough for a stable estimate.
    group.sample_size(10);

    for &n in &[1_000usize, 5_000, 10_000] {
        let vecs = gen_vectors(n, DIM);
        group.bench_with_input(BenchmarkId::from_parameter(n), &n, |b, &n| {
            b.iter(|| {
                let mut idx = HnswIndex::new(DIM, Metric::L2, 16, 200, n + 10, 50);
                for i in 0..n {
                    idx.add(
                        black_box(&i.to_string()),
                        black_box(&vecs[i * DIM..(i + 1) * DIM]),
                    )
                    .unwrap();
                }
                black_box(idx)
            });
        });
    }
    group.finish();
}

// ─── Single search ───────────────────────────────────────────────────────────

fn bench_search_single(c: &mut Criterion) {
    const N: usize = 10_000;
    const DIM: usize = 128;

    let idx = build_index(N, DIM);
    // Query vector: first vector from a fresh batch
    let query_vecs = gen_vectors(N + 10, DIM);
    let query = &query_vecs[N * DIM..(N + 1) * DIM];

    let mut group = c.benchmark_group("search_single_l2");

    for &k in &[1usize, 10, 50] {
        group.bench_with_input(BenchmarkId::new("k", k), &k, |b, &k| {
            b.iter(|| black_box(idx.search(black_box(query), k).unwrap()));
        });
    }
    group.finish();
}

// ─── Batch search (Rayon parallel) ───────────────────────────────────────────

fn bench_search_batch(c: &mut Criterion) {
    const N: usize = 10_000;
    const DIM: usize = 128;
    const BATCH: usize = 100;
    const K: usize = 10;

    let idx = build_index(N, DIM);
    let query_vecs = gen_vectors(N + BATCH, DIM);
    let queries: &[f32] = &query_vecs[N * DIM..];

    c.bench_function("search_batch_100q_k10_l2_dim128", |b| {
        b.iter(|| black_box(idx.search_batch(black_box(queries), K).unwrap()));
    });
}

// ─── Dimension scaling ───────────────────────────────────────────────────────

fn bench_search_dim_scaling(c: &mut Criterion) {
    const N: usize = 5_000;
    const K: usize = 10;

    let mut group = c.benchmark_group("search_dim_scaling");
    for &dim in &[32usize, 64, 128, 256, 512] {
        let idx = build_index(N, dim);
        let qvecs = gen_vectors(N + 1, dim);
        let query = &qvecs[N * dim..];

        group.bench_with_input(BenchmarkId::new("dim", dim), &dim, |b, _| {
            b.iter(|| black_box(idx.search(black_box(query), K).unwrap()))
        });
    }
    group.finish();
}

// ─── Cosine vs L2 ────────────────────────────────────────────────────────────

fn bench_metric_comparison(c: &mut Criterion) {
    const N: usize = 5_000;
    const DIM: usize = 128;
    const K: usize = 10;

    let vecs = gen_vectors(N, DIM);
    let qvecs = gen_vectors(N + 1, DIM);
    let query = &qvecs[N * DIM..];

    let mut group = c.benchmark_group("metric_comparison_dim128");

    for metric in [Metric::L2, Metric::Cosine, Metric::InnerProduct] {
        let label = metric.as_str();
        let mut idx = HnswIndex::new(DIM, metric, 16, 200, N + 10, 50);
        for i in 0..N {
            idx.add(&i.to_string(), &vecs[i * DIM..(i + 1) * DIM])
                .unwrap();
        }
        group.bench_with_input(BenchmarkId::new("metric", label), &label, |b, _| {
            b.iter(|| black_box(idx.search(black_box(query), K).unwrap()))
        });
    }
    group.finish();
}

criterion_group!(
    benches,
    bench_index_build,
    bench_search_single,
    bench_search_batch,
    bench_search_dim_scaling,
    bench_metric_comparison,
);
criterion_main!(benches);
