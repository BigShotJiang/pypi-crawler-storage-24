//! Integration tests for `vajra-hnsw`.
//!
//! These tests exercise the full stack:
//!
//! - **Recall**: 1000 randomly generated 32-dim vectors; average recall@10 must
//!   be ≥ 0.90 (in practice HNSW with M=16/ef=200 achieves > 0.98 here).
//! - **Persistence**: save → load round-trip produces identical search results.
//! - **Correctness**: the coalgebraic path and the fast imperative path must
//!   agree on the same 4-node graph (mirrors the unit tests in each module).
//! - **Error handling**: all documented error variants are exercised.
//!
//! Vectors are generated with a deterministic formula so the test suite is
//! reproducible without pulling in an RNG feature flag.

use std::collections::HashSet;
use std::path::Path;
use tempfile::NamedTempFile;

use vajra_hnsw::{HnswError, HnswIndex, HnswNavigationCoalgebra, HnswSearchState, Metric};

// ─── Helpers ──────────────────────────────────────────────────────────────────

/// Generate `n * dim` pseudo-random f32 values in [−1, 1] using a simple
/// deterministic formula so the test is reproducible without external RNG.
fn gen_vectors(n: usize, dim: usize) -> Vec<f32> {
    (0..n * dim)
        .map(|k| {
            let i = k / dim;
            let d = k % dim;
            // Mix i and d to get a spread in [−1, 1]
            let raw = ((i * 6271 + d * 3571 + i * d * 13) % 9973) as f32 / 9973.0;
            raw * 2.0 - 1.0
        })
        .collect()
}

/// Brute-force exact k-NN for a query against a flat vector buffer (L2).
fn brute_force_knn_l2(indexed: &[f32], dim: usize, query: &[f32], k: usize) -> Vec<usize> {
    let n = indexed.len() / dim;
    let mut dists: Vec<(usize, f32)> = (0..n)
        .map(|i| {
            let v = &indexed[i * dim..(i + 1) * dim];
            let d: f32 = v
                .iter()
                .zip(query.iter())
                .map(|(a, b)| (a - b).powi(2))
                .sum::<f32>()
                .sqrt();
            (i, d)
        })
        .collect();
    dists.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
    dists.into_iter().take(k).map(|(i, _)| i).collect()
}

// ─── Recall test ──────────────────────────────────────────────────────────────

/// Build a 1000-vector 32-dim L2 index and verify average recall@10 ≥ 0.90.
///
/// In practice HNSW with M=16, ef_construction=200, ef_search=50 achieves
/// > 0.98 recall on random data in this dimensionality, so the 0.90 threshold
/// is a conservative correctness floor.
#[test]
fn test_recall_l2_1000_vectors() {
    const N: usize = 1000;
    const DIM: usize = 32;
    const K: usize = 10;
    const QUERY_COUNT: usize = 50;
    const RECALL_THRESHOLD: f32 = 0.90;

    let indexed = gen_vectors(N, DIM);

    let mut idx = HnswIndex::new(DIM, Metric::L2, 16, 200, N + 10, 50);
    for i in 0..N {
        idx.add(&i.to_string(), &indexed[i * DIM..(i + 1) * DIM])
            .unwrap();
    }
    assert_eq!(idx.len(), N);

    // Use a separate block of vectors as queries (indices N..N+QUERY_COUNT).
    let queries = gen_vectors(N + QUERY_COUNT, DIM);
    let query_vecs: Vec<f32> = queries[N * DIM..].to_vec();

    let mut total_recall = 0.0f32;
    for qi in 0..QUERY_COUNT {
        let q = &query_vecs[qi * DIM..(qi + 1) * DIM];

        let true_knn: HashSet<usize> = brute_force_knn_l2(&indexed, DIM, q, K)
            .into_iter()
            .collect();

        let hnsw_results = idx.search(q, K).unwrap();
        let hnsw_set: HashSet<usize> = hnsw_results
            .iter()
            .map(|r| r.id.parse::<usize>().unwrap())
            .collect();

        let hit = true_knn.intersection(&hnsw_set).count();
        total_recall += hit as f32 / K as f32;
    }

    let avg_recall = total_recall / QUERY_COUNT as f32;
    assert!(
        avg_recall >= RECALL_THRESHOLD,
        "average recall@{K} = {avg_recall:.4} is below threshold {RECALL_THRESHOLD}"
    );
}

// ─── Persistence ──────────────────────────────────────────────────────────────

/// Save and reload a small index; verify identical search results.
#[test]
fn test_save_load_round_trip() {
    let mut idx = HnswIndex::new(4, Metric::L2, 8, 100, 20, 20);
    let data: &[(&str, &[f32])] = &[
        ("a", &[1.0, 0.0, 0.0, 0.0]),
        ("b", &[0.0, 1.0, 0.0, 0.0]),
        ("c", &[-1.0, 0.0, 0.0, 0.0]),
        ("d", &[0.0, -1.0, 0.0, 0.0]),
    ];
    for &(id, v) in data {
        idx.add(id, v).unwrap();
    }

    let query = [1.0f32, 0.1, 0.0, 0.0];
    let original = idx.search(&query, 2).unwrap();

    let tmp = NamedTempFile::new().expect("tempfile creation failed");
    idx.save(tmp.path()).unwrap();

    let loaded = HnswIndex::load(tmp.path()).unwrap();
    assert_eq!(loaded.len(), idx.len());
    assert_eq!(loaded.dimension(), idx.dimension());
    assert_eq!(loaded.metric(), idx.metric());

    let reloaded = loaded.search(&query, 2).unwrap();
    assert_eq!(original.len(), reloaded.len());
    for (o, r) in original.iter().zip(reloaded.iter()) {
        assert_eq!(o.id, r.id, "ID mismatch after round-trip");
        assert!(
            (o.score - r.score).abs() < 1e-6,
            "score mismatch after round-trip: {} vs {}",
            o.score,
            r.score
        );
    }
}

/// Load from a non-existent path returns HnswError::Io.
#[test]
fn test_load_nonexistent_file_returns_io_error() {
    let err = HnswIndex::load(Path::new("/tmp/vajra_hnsw_this_does_not_exist.bin")).unwrap_err();
    assert!(
        matches!(err, HnswError::Io(_)),
        "expected Io error, got {:?}",
        err
    );
}

// ─── Error handling ───────────────────────────────────────────────────────────

#[test]
fn test_error_dimension_mismatch_add() {
    let mut idx = HnswIndex::new(4, Metric::L2, 8, 100, 10, 10);
    let err = idx.add("x", &[1.0, 0.0]).unwrap_err();
    assert!(
        matches!(
            err,
            HnswError::DimensionMismatch {
                expected: 4,
                got: 2
            }
        ),
        "unexpected error: {:?}",
        err
    );
}

#[test]
fn test_error_dimension_mismatch_search() {
    let mut idx = HnswIndex::new(4, Metric::L2, 8, 100, 10, 10);
    idx.add("x", &[1.0, 0.0, 0.0, 0.0]).unwrap();
    let err = idx.search(&[1.0, 0.0], 1).unwrap_err();
    assert!(matches!(err, HnswError::DimensionMismatch { .. }));
}

#[test]
fn test_error_duplicate_id() {
    let mut idx = HnswIndex::new(4, Metric::L2, 8, 100, 10, 10);
    idx.add("a", &[1.0, 0.0, 0.0, 0.0]).unwrap();
    let err = idx.add("a", &[0.0, 1.0, 0.0, 0.0]).unwrap_err();
    assert!(
        matches!(err, HnswError::DuplicateId(ref s) if s == "a"),
        "unexpected error: {:?}",
        err
    );
}

#[test]
fn test_error_index_full() {
    let mut idx = HnswIndex::new(2, Metric::L2, 4, 50, 2, 5);
    idx.add("a", &[1.0, 0.0]).unwrap();
    idx.add("b", &[0.0, 1.0]).unwrap();
    let err = idx.add("c", &[1.0, 1.0]).unwrap_err();
    assert!(matches!(err, HnswError::IndexFull { capacity: 2 }));
}

#[test]
fn test_error_empty_index_search() {
    let idx = HnswIndex::new(4, Metric::L2, 8, 100, 10, 10);
    let err = idx.search(&[1.0, 0.0, 0.0, 0.0], 1).unwrap_err();
    assert!(matches!(err, HnswError::EmptyIndex));
}

// ─── Correctness: coalgebra path == fast path ─────────────────────────────────

/// For a 4-node graph, every query must return identical results from the
/// coalgebraic path (`search_to_completion`) and the fast path (`search`).
///
/// This mirrors the unit test in `coalgebra.rs` but runs through the full
/// `HnswIndex` public API.
#[test]
fn test_coalgebra_path_agrees_with_index_search() {
    use vajra_hnsw::search::beam_search_fast;
    use vajra_hnsw::HnswGraph;

    // Build the same 4-node graph used in unit tests.
    let mut g = HnswGraph::new(2, 4, 200, 10);
    for v in [[1.0f32, 0.0], [0.0, 1.0], [-1.0, 0.0], [0.0, -1.0]] {
        g.vectors.extend_from_slice(&v);
    }
    for i in 0..4usize {
        g.ids.push(i.to_string());
        g.id_to_idx.insert(i.to_string(), i);
    }
    g.layers.push(vec![
        vec![1, 2, 3],
        vec![0, 2, 3],
        vec![0, 1, 3],
        vec![0, 1, 2],
    ]);
    g.size = 4;
    g.entry_point = Some(0);

    let metric = Metric::L2;
    let coalgebra = HnswNavigationCoalgebra::new(&g, &metric);
    let ef = 4;

    for &query_arr in &[[1.0f32, 0.0], [0.0, 1.0], [-0.5, 0.5]] {
        let query = query_arr.to_vec();
        let entry = g.entry_point.unwrap();

        // Coalgebraic path — seed with the correct entry distance so it matches
        // beam_search_fast exactly (both start with the same initial results heap).
        let entry_dist = metric.compute(&query, g.get_vector(entry));
        let coal = coalgebra.search_to_completion(HnswSearchState::new(
            query.clone(),
            entry,
            entry_dist,
            ef,
            0,
        ));

        // Fast path
        let fast = beam_search_fast(&g, &query, entry, ef, 0, &metric);

        assert_eq!(
            coal.len(),
            fast.len(),
            "result counts differ for query {:?}",
            query_arr
        );
        for (c, f) in coal.iter().zip(fast.iter()) {
            assert_eq!(c.0, f.0, "node mismatch for query {:?}", query_arr);
            assert!(
                (c.1 - f.1).abs() < 1e-6,
                "distance mismatch for query {:?}: {} vs {}",
                query_arr,
                c.1,
                f.1
            );
        }
    }
}

// ─── Cosine metric ────────────────────────────────────────────────────────────

#[test]
fn test_cosine_index_finds_most_similar_direction() {
    let mut idx = HnswIndex::new(3, Metric::Cosine, 8, 100, 20, 20);
    let vecs: &[(&str, &[f32])] = &[
        ("pos_x", &[1.0, 0.0, 0.0]),
        ("pos_y", &[0.0, 1.0, 0.0]),
        ("neg_x", &[-1.0, 0.0, 0.0]),
        ("pos_z", &[0.0, 0.0, 1.0]),
    ];
    for &(id, v) in vecs {
        idx.add(id, v).unwrap();
    }

    // Query nearly aligned with +x → nearest should be pos_x (cosine dist ≈ 0)
    let results = idx.search(&[0.99f32, 0.1, 0.0], 1).unwrap();
    assert_eq!(results[0].id, "pos_x");
    assert!(results[0].score < 0.1, "expected low cosine distance");
}

// ─── Batch operations ─────────────────────────────────────────────────────────

#[test]
fn test_add_batch_and_search_batch() {
    let mut idx = HnswIndex::new(2, Metric::L2, 4, 100, 20, 10);
    let ids = vec!["0", "1", "2", "3", "4"];
    let vecs: Vec<f32> = (0..5).flat_map(|i| vec![i as f32, 0.0f32]).collect();
    idx.add_batch(&ids, &vecs).unwrap();
    assert_eq!(idx.len(), 5);

    // Search batch: two queries at the extremes
    let queries = vec![0.0f32, 0.0, 4.0, 0.0];
    let results = idx.search_batch(&queries, 1).unwrap();
    assert_eq!(results.len(), 2);
    assert_eq!(results[0][0].id, "0");
    assert_eq!(results[1][0].id, "4");
}

#[test]
fn test_search_batch_dimension_mismatch() {
    let mut idx = HnswIndex::new(4, Metric::L2, 4, 100, 10, 5);
    idx.add("a", &[1.0, 0.0, 0.0, 0.0]).unwrap();
    // Flat buffer length (7) is not divisible by dim (4)
    let err = idx
        .search_batch(&[1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0], 1)
        .unwrap_err();
    assert!(matches!(err, HnswError::DimensionMismatch { .. }));
}

// ─── Many insertions ──────────────────────────────────────────────────────────

/// 200-vector index: verify that search results are sorted and contain the
/// correct nearest neighbour for a direct lookup.
#[test]
fn test_medium_index_sorted_results_and_exact_match() {
    const N: usize = 200;
    const DIM: usize = 16;

    let vecs = gen_vectors(N, DIM);
    let mut idx = HnswIndex::new(DIM, Metric::L2, 16, 200, N + 10, 50);
    for i in 0..N {
        idx.add(&i.to_string(), &vecs[i * DIM..(i + 1) * DIM])
            .unwrap();
    }

    // Query with vector #42 exactly; it must be the nearest (score ≈ 0).
    let q = &vecs[42 * DIM..43 * DIM];
    let results = idx.search(q, 10).unwrap();

    assert!(!results.is_empty());
    assert_eq!(
        results[0].id, "42",
        "vector 42 must be its own nearest neighbour"
    );
    assert!(results[0].score < 1e-5);

    // Results must be sorted ascending by score.
    for w in results.windows(2) {
        assert!(w[0].score <= w[1].score, "results not sorted");
    }
}
