//! HNSW search algorithms.
//!
//! Two paths are provided for each operation:
//!
//! 1. **Fast path** (`beam_search_fast`, `greedy_descent`): imperative, uses
//!    in-place `BinaryHeap` and dense visited markers.
//!    This is the **production path** used by `HnswIndex::search`.
//!
//! 2. **Coalgebraic path** (`beam_search_coalgebra`): driven by
//!    `HnswNavigationCoalgebra::search_to_completion`.  Canonically correct
//!    by construction and used as the reference in tests.
//!
//! Both paths must return identical results for any given input (tested in
//! `tests/integration_test.rs`).

use crate::distance::Metric;
use crate::graph::HnswGraph;
use crate::state::Candidate;
use ordered_float::OrderedFloat;
use std::cmp::Reverse;
use std::collections::BinaryHeap;

// ─── Fast beam search ─────────────────────────────────────────────────────────

/// Reusable scratch buffers for `beam_search_fast`.
///
/// Build-time insertion invokes beam search many times; keeping these heaps and
/// marker buffers alive avoids repeated allocations in hot paths.
#[derive(Debug, Default)]
pub struct BeamSearchScratch {
    candidates: BinaryHeap<Reverse<Candidate>>,
    results: BinaryHeap<Candidate>,
    visit_marks: Vec<u32>,
    out: Vec<(usize, f32)>,
    mark: u32,
}

impl BeamSearchScratch {
    #[inline]
    fn next_mark(&mut self) -> u32 {
        self.mark = self.mark.wrapping_add(1);
        if self.mark == 0 {
            self.visit_marks.fill(0);
            self.mark = 1;
        }
        self.mark
    }
}

/// Beam search on one layer of the HNSW graph.
///
/// This is the hot path used for both construction (ef_construction) and
/// querying (ef_search).  It maintains:
/// - `candidates` (min-heap): nodes to expand, nearest first.
/// - `results`    (max-heap, capped at `ef`): best results, farthest on top.
///
/// Early termination: when the nearest unvisited candidate is farther than
/// the current worst result AND the result set is full, further expansion
/// cannot improve the result set.
///
/// # Returns
///
/// Sorted `Vec<(node_index, distance)>`, nearest first.
pub fn beam_search_fast(
    graph: &HnswGraph,
    query: &[f32],
    entry: usize,
    ef: usize,
    level: usize,
    metric: &Metric,
) -> Vec<(usize, f32)> {
    let mut scratch = BeamSearchScratch::default();
    beam_search_fast_with_scratch(graph, query, entry, ef, level, metric, &mut scratch).to_vec()
}

/// Beam search using caller-provided scratch buffers.
///
/// Returns a sorted slice `(node_index, distance)` nearest-first, backed by
/// `scratch` storage.
pub fn beam_search_fast_with_scratch<'a>(
    graph: &HnswGraph,
    query: &[f32],
    entry: usize,
    ef: usize,
    level: usize,
    metric: &Metric,
    scratch: &'a mut BeamSearchScratch,
) -> &'a [(usize, f32)] {
    let entry_dist = metric.compute(query, graph.get_vector(entry));

    scratch.candidates.clear();
    scratch.results.clear();
    scratch.out.clear();
    if scratch.visit_marks.len() < graph.size {
        scratch.visit_marks.resize(graph.size, 0);
    }
    // Dense visited markers are faster than hashing node IDs in hot loops.
    let current_mark = scratch.next_mark();

    scratch.candidates.push(Reverse(Candidate {
        node: entry,
        dist: OrderedFloat(entry_dist),
    }));
    scratch.results.push(Candidate {
        node: entry,
        dist: OrderedFloat(entry_dist),
    });
    scratch.visit_marks[entry] = current_mark;

    while let Some(Reverse(nearest)) = scratch.candidates.pop() {
        let farthest_dist = scratch
            .results
            .peek()
            .map(|c| c.dist.0)
            .unwrap_or(f32::INFINITY);

        // Early termination: can't improve
        if nearest.dist.0 > farthest_dist && scratch.results.len() >= ef {
            break;
        }

        for &neighbor in graph.neighbors(nearest.node, level) {
            if scratch.visit_marks[neighbor] == current_mark {
                continue;
            }
            scratch.visit_marks[neighbor] = current_mark;

            let dist = metric.compute(query, graph.get_vector(neighbor));
            let farthest = scratch
                .results
                .peek()
                .map(|c| c.dist.0)
                .unwrap_or(f32::INFINITY);

            if dist < farthest || scratch.results.len() < ef {
                scratch.candidates.push(Reverse(Candidate {
                    node: neighbor,
                    dist: OrderedFloat(dist),
                }));
                scratch.results.push(Candidate {
                    node: neighbor,
                    dist: OrderedFloat(dist),
                });
                if scratch.results.len() > ef {
                    scratch.results.pop(); // evict farthest
                }
            }
        }
    }

    scratch
        .out
        .extend(scratch.results.iter().map(|c| (c.node, c.dist.0)));
    scratch
        .out
        .sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
    scratch.out.as_slice()
}

// ─── Greedy descent (upper layers) ────────────────────────────────────────────

/// Greedy best-first descent for layers > 0.
///
/// At upper layers during construction and search, we only need the single
/// nearest node (ef = 1).  Using a full beam search heap for ef = 1 is
/// unnecessarily expensive; this function does a direct loop instead.
///
/// Starts at `entry` and repeatedly moves to the nearest neighbour until no
/// improvement is possible.
///
/// # Returns
///
/// The node index of the local minimum.
pub fn greedy_descent(
    graph: &HnswGraph,
    query: &[f32],
    entry: usize,
    level: usize,
    metric: &Metric,
) -> usize {
    let mut current = entry;
    let mut current_dist = metric.compute(query, graph.get_vector(current));

    loop {
        let mut improved = false;
        for &neighbor in graph.neighbors(current, level) {
            let dist = metric.compute(query, graph.get_vector(neighbor));
            if dist < current_dist {
                current = neighbor;
                current_dist = dist;
                improved = true;
            }
        }
        if !improved {
            break;
        }
    }

    current
}

// ─── Neighbour selection ──────────────────────────────────────────────────────

/// Simple neighbour selection: take the `m` nearest candidates.
///
/// Used when `select_neighbors_heuristic` produces fewer than `m` results
/// during the fill-up phase.
pub fn select_neighbors_simple(candidates: &[(usize, f32)], m: usize) -> Vec<usize> {
    let mut out = Vec::with_capacity(m);
    select_neighbors_simple_into(candidates, m, &mut out);
    out
}

/// Scratch-buffer variant of [`select_neighbors_simple`].
#[inline]
pub fn select_neighbors_simple_into(candidates: &[(usize, f32)], m: usize, out: &mut Vec<usize>) {
    out.clear();
    out.extend(candidates.iter().take(m).map(|&(n, _)| n));
}

/// Heuristic neighbour selection from the HNSW paper (Algorithm 4).
///
/// Selects neighbours that are diverse in direction, improving graph
/// navigability.  For each candidate `c`:
/// - If `dist(c, query) < dist(c, any_already_selected)` → add `c`.
/// - Otherwise → prune (there is a closer existing neighbour in that direction).
///
/// Falls back to nearest-first when the heuristic yields fewer than `m` results.
///
/// # Arguments
///
/// - `graph`: read-only access to vector data.
/// - `metric`: distance metric.
/// - `query`: the node being inserted or the search query.
/// - `candidates`: sorted `(node, dist_to_query)`, nearest first.
/// - `m`: desired number of neighbours.
pub fn select_neighbors_heuristic(
    graph: &HnswGraph,
    metric: &Metric,
    _query: &[f32],
    candidates: &[(usize, f32)],
    m: usize,
) -> Vec<usize> {
    let mut selected: Vec<(usize, f32)> = Vec::with_capacity(m);
    let mut out: Vec<usize> = Vec::with_capacity(m);
    select_neighbors_heuristic_into(graph, metric, candidates, m, &mut selected, &mut out);
    out
}

/// Scratch-buffer variant of [`select_neighbors_heuristic`] for hot insertion
/// loops where repeated allocations dominate.
pub fn select_neighbors_heuristic_into(
    graph: &HnswGraph,
    metric: &Metric,
    candidates: &[(usize, f32)],
    m: usize,
    selected: &mut Vec<(usize, f32)>,
    out: &mut Vec<usize>,
) {
    selected.clear();
    out.clear();

    'outer: for &(candidate, dist_q_c) in candidates {
        if selected.len() >= m {
            break;
        }
        for &(sel, _) in selected.iter() {
            // Prune: if candidate is closer to an already-selected node
            // than to the query, it doesn't add directional diversity.
            let d_c_sel = metric.compute(graph.get_vector(candidate), graph.get_vector(sel));
            if d_c_sel < dist_q_c {
                continue 'outer;
            }
        }
        selected.push((candidate, dist_q_c));
    }

    // Fill up if heuristic didn't yield enough
    if selected.len() < m {
        for &(candidate, dist) in candidates {
            if selected.len() >= m {
                break;
            }
            if !selected.iter().any(|&(n, _)| n == candidate) {
                selected.push((candidate, dist));
            }
        }
    }

    out.extend(selected.iter().map(|(n, _)| *n));
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::HnswGraph;

    /// Build a tiny 4-node graph:
    ///
    /// Nodes (2-D): 0=(1,0), 1=(0,1), 2=(-1,0), 3=(0,-1)
    /// All connected at layer 0.
    fn four_node_graph() -> HnswGraph {
        let mut g = HnswGraph::new(2, 4, 200, 10);
        for v in [[1.0f32, 0.0], [0.0, 1.0], [-1.0, 0.0], [0.0, -1.0]] {
            g.vectors.extend_from_slice(&v);
        }
        g.ids = vec!["0".into(), "1".into(), "2".into(), "3".into()];
        for i in 0..4usize {
            g.id_to_idx.insert(i.to_string(), i);
        }
        // Layer 0: full clique
        g.layers.push(vec![
            vec![1, 2, 3],
            vec![0, 2, 3],
            vec![0, 1, 3],
            vec![0, 1, 2],
        ]);
        g.size = 4;
        g.entry_point = Some(0);
        g
    }

    #[test]
    fn test_beam_search_returns_nearest() {
        let g = four_node_graph();
        let query = [1.0f32, 0.0]; // closest to node 0
        let results = beam_search_fast(&g, &query, 0, 4, 0, &Metric::L2);
        assert!(!results.is_empty());
        // Node 0 should be the nearest
        assert_eq!(results[0].0, 0);
        assert!(results[0].1 < 1e-6);
    }

    #[test]
    fn test_beam_search_ef_limits_results() {
        let g = four_node_graph();
        let query = [1.0f32, 0.0];
        let results = beam_search_fast(&g, &query, 0, 2, 0, &Metric::L2);
        assert_eq!(results.len(), 2);
    }

    #[test]
    fn test_beam_search_results_sorted() {
        let g = four_node_graph();
        let query = [0.5f32, 0.5];
        let results = beam_search_fast(&g, &query, 0, 4, 0, &Metric::L2);
        for w in results.windows(2) {
            assert!(w[0].1 <= w[1].1, "results not sorted by distance");
        }
    }

    #[test]
    fn test_greedy_descent_finds_local_optimum() {
        let g = four_node_graph();
        let query = [1.0f32, 0.0];
        // Starting from node 0 (which IS the nearest), descent should stay at 0
        let result = greedy_descent(&g, &query, 0, 0, &Metric::L2);
        assert_eq!(result, 0);
    }

    #[test]
    fn test_greedy_descent_from_wrong_start() {
        let g = four_node_graph();
        let query = [1.0f32, 0.0]; // nearest to node 0
                                   // Starting from node 2 (-1,0), greedy should find node 0
        let result = greedy_descent(&g, &query, 2, 0, &Metric::L2);
        assert_eq!(result, 0);
    }

    #[test]
    fn test_select_neighbors_simple() {
        let candidates = vec![(10, 0.1), (20, 0.2), (30, 0.3), (40, 0.4)];
        let selected = select_neighbors_simple(&candidates, 2);
        assert_eq!(selected, vec![10, 20]);
    }

    #[test]
    fn test_select_neighbors_heuristic_diverse() {
        let g = four_node_graph();
        let query = [0.0f32, 0.0]; // centre
                                   // Candidates: all 4 nodes
        let candidates = vec![(0, 1.0f32), (1, 1.0), (2, 1.0), (3, 1.0)];
        let selected = select_neighbors_heuristic(&g, &Metric::L2, &query, &candidates, 2);
        assert_eq!(selected.len(), 2);
    }

    #[test]
    fn test_select_neighbors_heuristic_fill_up() {
        let g = four_node_graph();
        let query = [1.0f32, 0.0];
        // Candidates close together — heuristic may prune most; fill-up kicks in
        let candidates = vec![(0, 0.0f32), (1, 1.0)];
        let selected = select_neighbors_heuristic(&g, &Metric::L2, &query, &candidates, 3);
        // Can't have more than 2 since only 2 candidates
        assert!(selected.len() <= 2);
    }
}
