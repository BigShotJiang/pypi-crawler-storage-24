//! HNSW navigation coalgebra.
//!
//! [`HnswNavigationCoalgebra`] implements [`vajra_core::coalgebra::Coalgebra`] with:
//! - Carrier type X = [`HnswSearchState`]
//! - Functor F = `ListFunctor` (from `vajra_core`)
//! - F(X) = `Vec<HnswSearchState>`
//!
//! The structure map α: X → List(X) encodes **one step** of beam search:
//! - If `state.is_terminal()` → returns `vec![]` (coalgebra terminates).
//! - Otherwise → pops one candidate, expands its neighbours, returns `vec![new_state]`.
//!
//! ## `unfold` vs `search_to_completion`
//!
//! The [`Coalgebra`] trait's `unfold` method is a **one-step alias** for
//! `structure_map` (by design in `vajra-core`).  The full corecursive execution
//! is [`HnswNavigationCoalgebra::search_to_completion`], which repeatedly
//! calls `structure_map` until the result is `vec![]`.
//!
//! ## Fast path
//!
//! In production, [`crate::search::beam_search_fast`] is used instead of this
//! coalgebra.  It is semantically equivalent but avoids per-step state cloning.
//! Both paths are tested to return identical results.

use crate::distance::Metric;
use crate::graph::HnswGraph;
use crate::state::{Candidate, HnswSearchState};
use ordered_float::OrderedFloat;
use std::cmp::Reverse;
use vajra_core::coalgebra::Coalgebra;

/// HNSW search modelled as a coalgebra (X, α) where α: X → List(X).
///
/// Holds an immutable reference to the graph and the distance metric.
/// Both are borrowed for the lifetime of the coalgebra object.
pub struct HnswNavigationCoalgebra<'a> {
    graph: &'a HnswGraph,
    metric: &'a Metric,
}

impl<'a> HnswNavigationCoalgebra<'a> {
    /// Construct a new coalgebra for `graph` with `metric`.
    pub fn new(graph: &'a HnswGraph, metric: &'a Metric) -> Self {
        Self { graph, metric }
    }

    /// Corecursive execution: iterate `structure_map` until terminal.
    ///
    /// This is **not** the same as the trait's `unfold` (which is one step).
    /// Named distinctly to avoid confusion.
    ///
    /// Used as the canonical correctness reference in tests; the production
    /// path is [`crate::search::beam_search_fast`].
    ///
    /// # Returns
    ///
    /// Sorted `Vec<(node_index, distance)>`, nearest first.
    pub fn search_to_completion(&self, initial: HnswSearchState) -> Vec<(usize, f32)> {
        let mut state = initial;
        loop {
            let next = self.structure_map(&state);
            match next.into_iter().next() {
                None => break,
                Some(new_state) => state = new_state,
            }
        }
        state.into_sorted_results()
    }
}

impl<'a> Coalgebra<HnswSearchState, Vec<HnswSearchState>> for HnswNavigationCoalgebra<'a> {
    /// One step of HNSW beam search.
    ///
    /// - Returns `vec![]`          when `state.is_terminal()` (candidates exhausted)
    ///   or when early-termination applies (nearest unvisited > farthest result).
    /// - Returns `vec![new_state]` after processing one candidate (expanding
    ///   its neighbours and updating the result set).
    fn structure_map(&self, state: &HnswSearchState) -> Vec<HnswSearchState> {
        if state.is_terminal() {
            return vec![];
        }

        let mut new_state = state.clone();

        // Pop the nearest candidate (min-heap via Reverse)
        let Reverse(nearest) = match new_state.candidates.pop() {
            Some(c) => c,
            None => return vec![],
        };

        // Early termination: nearest is farther than our worst result → no improvement
        let farthest = new_state.farthest_result_dist();
        if nearest.dist.0 > farthest && new_state.results.len() >= new_state.ef {
            return vec![];
        }

        // Expand: visit all unvisited neighbours of `nearest`
        for &neighbor in self.graph.neighbors(nearest.node, new_state.current_level) {
            if new_state.visited.contains(&neighbor) {
                continue;
            }
            new_state.visited.insert(neighbor);

            let dist = self
                .metric
                .compute(new_state.query.as_slice(), self.graph.get_vector(neighbor));
            let farthest_now = new_state.farthest_result_dist();

            if dist < farthest_now || new_state.results.len() < new_state.ef {
                new_state.candidates.push(Reverse(Candidate {
                    node: neighbor,
                    dist: OrderedFloat(dist),
                }));
                new_state.results.push(Candidate {
                    node: neighbor,
                    dist: OrderedFloat(dist),
                });
                if new_state.results.len() > new_state.ef {
                    new_state.results.pop(); // evict farthest
                }
            }
        }

        vec![new_state]
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::HnswGraph;
    use crate::search::beam_search_fast;

    fn four_node_graph() -> HnswGraph {
        let mut g = HnswGraph::new(2, 4, 200, 10);
        for v in [[1.0f32, 0.0], [0.0, 1.0], [-1.0, 0.0], [0.0, -1.0]] {
            g.vectors.extend_from_slice(&v);
        }
        for i in 0..4usize {
            g.ids.push(i.to_string());
            g.id_to_idx.insert(i.to_string(), i);
        }
        g.layers.push(vec![
            vec![1, 2, 3],
            vec![0, 2, 3],
            vec![0, 1, 3],
            vec![0, 1, 2],
        ]);
        g.size = 4;
        g.entry_point = Some(0);
        g
    }

    #[test]
    fn test_structure_map_terminal_on_empty_candidates() {
        let g = four_node_graph();
        let coalgebra = HnswNavigationCoalgebra::new(&g, &Metric::L2);

        let terminal_state = HnswSearchState {
            query: vec![1.0, 0.0],
            current_level: 0,
            ef: 4,
            candidates: std::collections::BinaryHeap::new(), // empty
            results: std::collections::BinaryHeap::new(),
            visited: std::collections::HashSet::new(),
        };

        let result = coalgebra.structure_map(&terminal_state);
        assert!(
            result.is_empty(),
            "should return vec![] for empty candidates"
        );
    }

    #[test]
    fn test_structure_map_returns_single_successor() {
        let g = four_node_graph();
        let coalgebra = HnswNavigationCoalgebra::new(&g, &Metric::L2);

        let query = vec![1.0f32, 0.0];
        let init = HnswSearchState::new(query, 0, 0.0, 4, 0);
        let result = coalgebra.structure_map(&init);
        // Not terminal: should return exactly one new state
        assert_eq!(result.len(), 1);
    }

    /// Core correctness test: coalgebra path and fast path must agree exactly
    /// on the same graph and query.
    #[test]
    fn test_coalgebra_agrees_with_fast_path() {
        let g = four_node_graph();
        let metric = Metric::L2;
        let coalgebra = HnswNavigationCoalgebra::new(&g, &metric);

        for &query_arr in &[[1.0f32, 0.0], [0.0, 1.0], [-0.5, 0.5]] {
            let query = query_arr.to_vec();
            let entry = g.entry_point.unwrap();
            let ef = 4;

            // Compute the actual entry distance so the coalgebra seed matches
            // exactly what beam_search_fast uses for the initial results heap.
            let entry_dist = metric.compute(&query, g.get_vector(entry));

            let coal_results = coalgebra.search_to_completion(HnswSearchState::new(
                query.clone(),
                entry,
                entry_dist,
                ef,
                0,
            ));

            let fast_results = beam_search_fast(&g, &query, entry, ef, 0, &metric);

            assert_eq!(
                coal_results.len(),
                fast_results.len(),
                "result counts differ for query {:?}",
                query_arr
            );
            for (c, f) in coal_results.iter().zip(fast_results.iter()) {
                assert_eq!(c.0, f.0, "node mismatch for query {:?}", query_arr);
                assert!(
                    (c.1 - f.1).abs() < 1e-6,
                    "distance mismatch for query {:?}: {} vs {}",
                    query_arr,
                    c.1,
                    f.1
                );
            }
        }
    }

    #[test]
    fn test_search_to_completion_finds_nearest() {
        let g = four_node_graph();
        let coalgebra = HnswNavigationCoalgebra::new(&g, &Metric::L2);

        let query = vec![1.0f32, 0.0];
        let init = HnswSearchState::new(query, 0, 0.0, 4, 0);
        let results = coalgebra.search_to_completion(init);

        assert!(!results.is_empty());
        assert_eq!(results[0].0, 0, "nearest to (1,0) should be node 0");
        assert!(results[0].1 < 1e-6);
    }

    #[test]
    fn test_unfold_trait_is_one_step() {
        // Confirm that Coalgebra::unfold is identical to structure_map (one step)
        let g = four_node_graph();
        let coalgebra = HnswNavigationCoalgebra::new(&g, &Metric::L2);
        let query = vec![1.0f32, 0.0];
        let init = HnswSearchState::new(query, 0, 0.0, 4, 0);

        let via_unfold = coalgebra.unfold(&init);
        let via_structure_map = coalgebra.structure_map(&init);

        assert_eq!(via_unfold.len(), via_structure_map.len());
    }
}
