//! Core HNSW graph data structure.
//!
//! [`HnswGraph`] stores the navigable small-world graph used by both the
//! coalgebraic and fast imperative search paths.  It is deliberately kept
//! separate from insertion logic (which lives in [`crate::index`]) so that
//! read-only search functions can take a plain `&HnswGraph`.
//!
//! ## Memory layout
//!
//! - `vectors`: pre-allocated flat `Vec<f32>` with capacity `max_elements × dim`.
//!   Grows via `extend_from_slice` on each insertion; no per-insert heap allocation.
//! - `id_to_idx`: `FxHashMap` pre-allocated with `max_elements` capacity.
//! - `layers[l][node_idx]` = neighbour indices at level `l` (dense node-indexed
//!   adjacency vectors; no per-access hash lookup in hot loops).
//!   Layer 0 has all nodes; higher layers have exponentially fewer.

use crate::distance::Metric;
use rand::Rng;
use rustc_hash::FxHashMap;
use serde::{Deserialize, Serialize};

/// Maximum layer index the graph will accept.
///
/// Limits `sample_level` output; prevents degenerate indices from tiny random values.
pub const MAX_LEVEL: usize = 16;

/// The HNSW graph: nodes, vectors, and per-level adjacency lists.
///
/// Does **not** include the RNG (used only during insertion, provided by the
/// caller via `rand::thread_rng()`) or `ef_search` (stored in `HnswIndex`).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HnswGraph {
    /// Vector dimensionality.
    pub dim: usize,
    /// Max connections per node at layers > 0.
    pub m: usize,
    /// Max connections per node at layer 0 (= 2 × m).
    pub m0: usize,
    /// Level multiplier = 1 / ln(m).  Controls the expected height of the graph.
    pub ml: f64,
    /// Beam width used during index construction (ef_construction).
    pub ef_construction: usize,
    /// Pre-allocated capacity (number of vectors).
    pub max_elements: usize,

    /// Flat vector buffer: `vectors[idx * dim .. (idx+1) * dim]` is node `idx`'s vector.
    ///
    /// Pre-allocated with `capacity = max_elements × dim`; len grows on insert.
    pub vectors: Vec<f32>,

    /// Mapping from external string IDs to internal 0-based indices.
    pub ids: Vec<String>,
    /// Reverse map: external ID → internal index.
    pub id_to_idx: FxHashMap<String, usize>,

    /// Per-level adjacency vectors: `layers[level][node_idx]` = neighbour indices.
    ///
    /// Layer 0 exists from the first insertion. Higher layers are added lazily.
    /// Each layer is sized to `self.size`, so neighbour lookup is a direct index.
    pub layers: Vec<Vec<Vec<usize>>>,

    /// Current entry point (the node with the highest level).
    pub entry_point: Option<usize>,
    /// Maximum level any node currently occupies.
    pub max_level: usize,
    /// Number of nodes currently stored.
    pub size: usize,
}

impl HnswGraph {
    /// Create a new empty graph.
    ///
    /// Allocates the vector buffer and ID map upfront to avoid per-insert
    /// reallocations.
    pub fn new(dim: usize, m: usize, ef_construction: usize, max_elements: usize) -> Self {
        assert!(m >= 2, "m must be at least 2");
        assert!(dim > 0, "dim must be positive");

        let m0 = 2 * m;
        let ml = 1.0 / (m as f64).ln();

        let mut vectors = Vec::new();
        vectors.reserve_exact(max_elements * dim);

        let mut id_to_idx = FxHashMap::default();
        id_to_idx.reserve(max_elements);
        let ids = Vec::with_capacity(max_elements);

        Self {
            dim,
            m,
            m0,
            ml,
            ef_construction,
            max_elements,
            vectors,
            ids,
            id_to_idx,
            layers: Vec::new(),
            entry_point: None,
            max_level: 0,
            size: 0,
        }
    }

    // ─── Vector access ────────────────────────────────────────────────────────

    /// Return a slice into the pre-allocated vector buffer for node `idx`.
    ///
    /// # Panics
    ///
    /// Panics in debug builds if `idx >= self.size`.
    #[inline]
    pub fn get_vector(&self, idx: usize) -> &[f32] {
        debug_assert!(idx < self.size, "node index out of bounds");
        let start = idx * self.dim;
        &self.vectors[start..start + self.dim]
    }

    /// Return a copy of node `idx`'s vector.
    ///
    /// Use this when you need to break a borrow on `self.vectors` before
    /// mutating `self.layers` in the same scope.
    #[inline]
    pub fn get_vector_copy(&self, idx: usize) -> Vec<f32> {
        self.get_vector(idx).to_vec()
    }

    // ─── Adjacency ────────────────────────────────────────────────────────────

    /// Return the neighbour list of node `node` at `level`, or an empty slice.
    #[inline]
    pub fn neighbors(&self, node: usize, level: usize) -> &[usize] {
        self.layers
            .get(level)
            .and_then(|layer| layer.get(node))
            .map(|v| v.as_slice())
            .unwrap_or(&[])
    }

    /// Set (overwrite) the neighbour list of node `node` at `level`.
    pub fn set_neighbors(&mut self, node: usize, level: usize, neighbors: Vec<usize>) {
        if let Some(layer) = self.layers.get_mut(level) {
            if node < layer.len() {
                layer[node] = neighbors;
            }
        }
    }

    /// Push one neighbour onto node `node`'s list at `level`.
    pub fn push_neighbor(&mut self, node: usize, level: usize, neighbor: usize) {
        if let Some(layer) = self.layers.get_mut(level) {
            if node < layer.len() {
                layer[node].push(neighbor);
            }
        }
    }

    /// Return the neighbour count of `node` at `level`.
    #[inline]
    pub fn neighbors_len(&self, node: usize, level: usize) -> usize {
        self.layers
            .get(level)
            .and_then(|layer| layer.get(node))
            .map(|v| v.len())
            .unwrap_or(0)
    }

    /// Take (move out) the neighbour list of `node` at `level`, leaving it empty.
    ///
    /// This avoids cloning neighbour vectors in insertion-time prune paths.
    pub fn take_neighbors(&mut self, node: usize, level: usize) -> Vec<usize> {
        if let Some(layer) = self.layers.get_mut(level) {
            if node < layer.len() {
                return std::mem::take(&mut layer[node]);
            }
        }
        Vec::new()
    }

    /// Ensure all existing layers contain a slot for `node`.
    ///
    /// Called after a new node index is assigned so direct `layer[node]` access
    /// remains valid at every existing level.
    pub fn ensure_node_slot(&mut self, node: usize) {
        for layer in &mut self.layers {
            if layer.len() <= node {
                layer.push(Vec::new());
            }
        }
    }

    /// Ensure layers exist up to (and including) `max_level`.
    ///
    /// New layers are initialized with `self.size` empty neighbour lists so they
    /// are immediately node-indexable.
    pub fn ensure_levels(&mut self, max_level: usize) {
        while self.layers.len() <= max_level {
            self.layers.push(vec![Vec::new(); self.size]);
        }
    }

    // ─── Level sampling ───────────────────────────────────────────────────────

    /// Sample a random level for a new node.
    ///
    /// Uses the exponential distribution with parameter `ml = 1 / ln(m)`.
    /// Result is capped at [`MAX_LEVEL`] to prevent degenerate indices.
    pub fn sample_level_from_ml<R: Rng>(ml: f64, rng: &mut R) -> usize {
        let r: f64 = rng.gen::<f64>();
        // Guard against r == 0 which would give ln(0) = -inf
        let r = r.max(1e-300_f64);
        let level = ((-r.ln()) * ml) as usize;
        level.min(MAX_LEVEL)
    }

    /// Sample a random level for the current graph's `ml`.
    pub fn sample_level<R: Rng>(&self, rng: &mut R) -> usize {
        Self::sample_level_from_ml(self.ml, rng)
    }

    // ─── Utilities ────────────────────────────────────────────────────────────

    /// Return the maximum number of neighbours allowed at `level`.
    #[inline]
    pub fn m_at_level(&self, level: usize) -> usize {
        if level == 0 {
            self.m0
        } else {
            self.m
        }
    }

    /// Compute the distance between node `node` and `query` using `metric`.
    ///
    /// Convenience wrapper over `metric.compute(self.get_vector(node), query)`.
    #[inline]
    pub fn dist_to_query(&self, node: usize, query: &[f32], metric: &Metric) -> f32 {
        metric.compute(self.get_vector(node), query)
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn small_graph() -> HnswGraph {
        let mut g = HnswGraph::new(4, 4, 200, 100);
        // Manually add two nodes
        g.vectors.extend_from_slice(&[1.0f32, 0.0, 0.0, 0.0]);
        g.vectors.extend_from_slice(&[0.0f32, 1.0, 0.0, 0.0]);
        g.ids.push("a".to_string());
        g.ids.push("b".to_string());
        g.id_to_idx.insert("a".to_string(), 0);
        g.id_to_idx.insert("b".to_string(), 1);
        g.layers.push(vec![vec![1], vec![0]]); // layer 0
        g.size = 2;
        g.entry_point = Some(0);
        g
    }

    #[test]
    fn test_get_vector_returns_correct_slice() {
        let g = small_graph();
        let v0 = g.get_vector(0);
        assert_eq!(v0, &[1.0f32, 0.0, 0.0, 0.0]);
        let v1 = g.get_vector(1);
        assert_eq!(v1, &[0.0f32, 1.0, 0.0, 0.0]);
    }

    #[test]
    fn test_get_vector_copy_is_owned() {
        let g = small_graph();
        let copy = g.get_vector_copy(0);
        assert_eq!(copy, vec![1.0f32, 0.0, 0.0, 0.0]);
    }

    #[test]
    fn test_neighbors_existing() {
        let g = small_graph();
        assert_eq!(g.neighbors(0, 0), &[1usize]);
        assert_eq!(g.neighbors(1, 0), &[0usize]);
    }

    #[test]
    fn test_neighbors_missing_level() {
        let g = small_graph();
        assert_eq!(g.neighbors(0, 5), &[] as &[usize]);
    }

    #[test]
    fn test_set_neighbors() {
        let mut g = small_graph();
        g.set_neighbors(0, 0, vec![1, 2, 3]);
        assert_eq!(g.neighbors(0, 0), &[1usize, 2, 3]);
    }

    #[test]
    fn test_push_neighbor() {
        let mut g = small_graph();
        g.push_neighbor(0, 0, 99);
        assert!(g.neighbors(0, 0).contains(&99));
    }

    #[test]
    fn test_m_at_level() {
        let g = HnswGraph::new(4, 8, 200, 100);
        assert_eq!(g.m_at_level(0), 16); // m0 = 2 * m
        assert_eq!(g.m_at_level(1), 8);
        assert_eq!(g.m_at_level(5), 8);
    }

    #[test]
    fn test_sample_level_stays_bounded() {
        let g = HnswGraph::new(4, 16, 200, 100);
        let mut rng = rand::thread_rng();
        for _ in 0..1000 {
            let level = g.sample_level(&mut rng);
            assert!(
                level <= MAX_LEVEL,
                "level {} exceeded MAX_LEVEL {}",
                level,
                MAX_LEVEL
            );
        }
    }

    #[test]
    fn test_sample_level_mostly_zero() {
        // With M=16, ~94% of nodes should land at level 0
        let g = HnswGraph::new(4, 16, 200, 100);
        let mut rng = rand::thread_rng();
        let zeros = (0..1000).filter(|_| g.sample_level(&mut rng) == 0).count();
        assert!(zeros > 800, "expected >80% at level 0, got {}/1000", zeros);
    }

    #[test]
    fn test_dist_to_query() {
        let g = small_graph();
        let query = [1.0f32, 0.0, 0.0, 0.0];
        let d = g.dist_to_query(0, &query, &Metric::L2);
        assert!(d.abs() < 1e-6, "L2 distance to self should be 0");
    }

    #[test]
    fn test_new_graph_pre_allocates_vectors() {
        let g = HnswGraph::new(128, 16, 200, 1000);
        assert_eq!(g.vectors.len(), 0); // empty
        assert!(g.vectors.capacity() >= 1000 * 128); // pre-allocated
    }

    #[test]
    fn test_new_graph_pre_allocates_id_map() {
        let g = HnswGraph::new(4, 4, 200, 500);
        // capacity() >= 500
        assert!(g.id_to_idx.capacity() >= 500);
    }
}
