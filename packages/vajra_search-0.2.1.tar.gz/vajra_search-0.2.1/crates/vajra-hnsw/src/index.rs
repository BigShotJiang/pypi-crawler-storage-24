//! High-level HNSW index API.
//!
//! [`HnswIndex`] is the primary entry point for this crate.  It wraps
//! [`HnswGraph`] with a distance metric, an `ef_search` parameter, and the
//! full HNSW insertion algorithm:
//!
//! 1. Sample a random level for the new node.
//! 2. Greedy descent from `max_level` down to `level + 1` to find the best
//!    entry point for the insertion layers.
//! 3. For each layer from `min(level, max_level)` down to 0:
//!    - Beam search with `ef_construction` to find candidate neighbours.
//!    - Heuristic neighbour selection (HNSW paper Algorithm 4).
//!    - Bidirectional edge wiring with pruning if a neighbour exceeds `M`.
//! 4. Promote the new node to entry point if its level exceeds `max_level`.
//!
//! # Borrow discipline
//!
//! Insertion requires careful sequencing to satisfy Rust's borrow checker:
//! - Gather neighbour/distance candidates into owned vectors before mutating
//!   layer adjacency.
//! - Keep immutable vector reads and adjacency writes in separate phases.
//!
//! # Concurrency
//!
//! `HnswIndex` is `Send + Sync`, so shared `&HnswIndex` references can be
//! distributed across Rayon threads for parallel batch search.  Insertions
//! require `&mut self` and are single-threaded (standard HNSW).
//!
//! # Persistence
//!
//! [`HnswIndex::save`] / [`HnswIndex::load`] use `bincode` through a
//! `BufWriter` / `BufReader` for efficient I/O.

use std::io::{BufReader, BufWriter};
use std::path::Path;

use rand::{rngs::SmallRng, SeedableRng};
use rayon::prelude::*;
use rustc_hash::{FxHashMap, FxHashSet};
use serde::{Deserialize, Serialize};

use crate::distance::{normalize_f32, Metric};
use crate::error::HnswError;
use crate::graph::HnswGraph;
use crate::search::{
    beam_search_fast, beam_search_fast_with_scratch, greedy_descent, select_neighbors_heuristic,
    select_neighbors_heuristic_into, select_neighbors_simple, select_neighbors_simple_into,
    BeamSearchScratch,
};

// ─── Public result type ───────────────────────────────────────────────────────

/// A single search result returned by [`HnswIndex::search`].
#[derive(Debug, Clone, PartialEq)]
pub struct HnswResult {
    /// External string ID provided at insertion time.
    pub id: String,
    /// Distance to the query vector (lower = closer for L2 and cosine).
    ///
    /// For the `InnerProduct` metric this is the negated dot product (more
    /// negative = closer), preserving min-heap ordering throughout search.
    pub score: f32,
    /// 1-based rank in the result list (1 = nearest).
    pub rank: usize,
}

// ─── Serialisable mirror struct ───────────────────────────────────────────────

/// Wire-format mirror of [`HnswIndex`] used for `bincode` serialisation.
///
/// `HnswIndex` itself holds no non-serialisable state today, but the mirror
/// exists to allow the public struct to evolve independently of the on-disk
/// format.
#[derive(Serialize, Deserialize)]
struct HnswIndexData {
    graph: HnswGraph,
    metric: Metric,
    ef_search: usize,
    #[serde(default = "default_true")]
    use_heuristic: bool,
}

#[inline]
fn default_true() -> bool {
    true
}

#[derive(Debug, Default)]
struct BuildScratch {
    beam: BeamSearchScratch,
    nb_dists: Vec<(usize, f32)>,
    heuristic_selected: Vec<(usize, f32)>,
    heuristic_out: Vec<usize>,
    prune_out: Vec<usize>,
    batch_defer_prune: bool,
    pending_prune: Vec<FxHashSet<usize>>,
}

const HEURISTIC_CANDIDATE_FACTOR_L0: usize = 8;
const HEURISTIC_CANDIDATE_FACTOR_UPPER: usize = 6;
const UPPER_LAYER_EF_CAP: usize = 128;
const FAST_LAYER0_EF_EARLY: usize = 64;
const FAST_LAYER0_EF_MID: usize = 80;
const FAST_LAYER0_EF_LATE: usize = 96;
const FAST_UPPER_EF_CAP: usize = 64;
const MICRO_BATCH_PLAN_THRESHOLD: usize = 256;
const MICRO_BATCH_PLAN_SIZE: usize = 256;
const PLAN_EPOCH_SIZE: usize = 1024;
const BATCH_PRUNE_FLUSH_INTERVAL: usize = 64;
const DEFERRED_PRUNE_HARD_CAP_MULTIPLIER: usize = 2;

#[derive(Debug)]
struct PlannedInsertion {
    idx: usize,
    level: usize,
    layer_neighbors: Vec<(usize, Vec<usize>)>,
}

#[inline]
fn fast_layer0_ef_for_size(size: usize, max_elements: usize) -> usize {
    let max_elements = max_elements.max(1);
    // Non-heuristic profiles ("fast"/"instant") don't need quality-level
    // beam widths during the whole build. Use a staged schedule so the
    // frontier densifies gradually with corpus growth.
    if size * 10 < max_elements * 5 {
        FAST_LAYER0_EF_EARLY
    } else if size * 10 < max_elements * 8 {
        FAST_LAYER0_EF_MID
    } else {
        FAST_LAYER0_EF_LATE
    }
}

fn ef_construction_for_level_snapshot_with_mode(
    graph: &HnswGraph,
    level: usize,
    use_heuristic: bool,
) -> usize {
    if use_heuristic {
        if level == 0 {
            graph.ef_construction
        } else {
            graph.ef_construction.min(UPPER_LAYER_EF_CAP)
        }
    } else if level == 0 {
        graph
            .ef_construction
            .min(fast_layer0_ef_for_size(graph.size, graph.max_elements))
    } else {
        graph.ef_construction.min(FAST_UPPER_EF_CAP)
    }
}

fn plan_insertion_on_snapshot(
    graph: &HnswGraph,
    metric: &Metric,
    use_heuristic: bool,
    vector: &[f32],
    level: usize,
    snapshot_max_level: usize,
) -> Vec<(usize, Vec<usize>)> {
    if graph.size == 0 {
        return Vec::new();
    }

    let mut ep = graph
        .entry_point
        .expect("entry_point must be set when snapshot graph is non-empty");

    if snapshot_max_level > level {
        for lc in (level + 1..=snapshot_max_level).rev() {
            ep = greedy_descent(graph, vector, ep, lc, metric);
        }
    }

    let insert_from = level.min(snapshot_max_level);
    let mut layers = Vec::with_capacity(insert_from + 1);
    for lc in (0..=insert_from).rev() {
        let ef_c = ef_construction_for_level_snapshot_with_mode(graph, lc, use_heuristic);
        let m = graph.m_at_level(lc);
        let candidates = beam_search_fast(graph, vector, ep, ef_c, lc, metric);

        if let Some(&(nearest, _)) = candidates.first() {
            ep = nearest;
        }

        let selected = if use_heuristic && lc == 0 {
            let factor = if lc == 0 {
                HEURISTIC_CANDIDATE_FACTOR_L0
            } else {
                HEURISTIC_CANDIDATE_FACTOR_UPPER
            };
            let limit = (m.saturating_mul(factor)).max(m).min(candidates.len());
            select_neighbors_heuristic(graph, metric, vector, &candidates[..limit], m)
        } else {
            select_neighbors_simple(&candidates, m)
        };
        layers.push((lc, selected));
    }
    layers
}

// ─── HnswIndex ────────────────────────────────────────────────────────────────

/// Hierarchical Navigable Small-World approximate nearest-neighbour index.
///
/// # Example
///
/// ```rust
/// use vajra_hnsw::{HnswIndex, Metric};
///
/// let mut idx = HnswIndex::new(4, Metric::L2, 16, 200, 1_000, 50);
/// idx.add("a", &[1.0f32, 0.0, 0.0, 0.0]).unwrap();
/// idx.add("b", &[0.0f32, 1.0, 0.0, 0.0]).unwrap();
///
/// let results = idx.search(&[1.0f32, 0.0, 0.0, 0.0], 1).unwrap();
/// assert_eq!(results[0].id, "a");
/// assert_eq!(results[0].rank, 1);
/// ```
#[derive(Debug)]
pub struct HnswIndex {
    graph: HnswGraph,
    metric: Metric,
    ef_search: usize,
    use_heuristic: bool,
    rng: SmallRng,
    build_scratch: BuildScratch,
}

impl HnswIndex {
    // ─── Construction ─────────────────────────────────────────────────────────

    /// Create a new empty HNSW index.
    ///
    /// # Parameters
    ///
    /// - `dim`: Vector dimensionality — fixed for the lifetime of the index.
    /// - `metric`: Distance metric (`Cosine`, `L2`, or `InnerProduct`).
    /// - `m`: Max connections per node at layers > 0.  Typical range 8–48.
    /// - `ef_construction`: Beam width during construction.  Higher values
    ///   improve recall at the cost of slower insertions.  Typical 100–400.
    /// - `max_elements`: Pre-allocated capacity.  Insertions beyond this limit
    ///   return [`HnswError::IndexFull`].
    /// - `ef_search`: Default beam width for queries.  Can be overridden
    ///   per-query via [`search_ef`](Self::search_ef).
    pub fn new(
        dim: usize,
        metric: Metric,
        m: usize,
        ef_construction: usize,
        max_elements: usize,
        ef_search: usize,
    ) -> Self {
        Self::new_with_options_and_seed(
            dim,
            metric,
            m,
            ef_construction,
            max_elements,
            ef_search,
            true,
            None,
        )
    }

    /// Create a new empty HNSW index with explicit build-neighbour strategy.
    ///
    /// `use_heuristic = true` enables HNSW's diversification heuristic
    /// (higher build cost, usually better recall). Set to `false` for a fast
    /// nearest-only neighbour selection path during insertion.
    pub fn new_with_options(
        dim: usize,
        metric: Metric,
        m: usize,
        ef_construction: usize,
        max_elements: usize,
        ef_search: usize,
        use_heuristic: bool,
    ) -> Self {
        Self::new_with_options_and_seed(
            dim,
            metric,
            m,
            ef_construction,
            max_elements,
            ef_search,
            use_heuristic,
            None,
        )
    }

    /// Create a new index with explicit RNG seed support.
    ///
    /// When `seed` is provided, insertion-level sampling is deterministic.
    pub fn new_with_options_and_seed(
        dim: usize,
        metric: Metric,
        m: usize,
        ef_construction: usize,
        max_elements: usize,
        ef_search: usize,
        use_heuristic: bool,
        seed: Option<u64>,
    ) -> Self {
        Self {
            graph: HnswGraph::new(dim, m, ef_construction, max_elements),
            metric,
            ef_search,
            use_heuristic,
            rng: match seed {
                Some(s) => SmallRng::seed_from_u64(s),
                None => SmallRng::from_entropy(),
            },
            build_scratch: BuildScratch::default(),
        }
    }

    #[inline]
    fn ef_construction_for_level(&self, level: usize) -> usize {
        ef_construction_for_level_snapshot_with_mode(&self.graph, level, self.use_heuristic)
    }

    fn wire_selected_for_layer(
        &mut self,
        new_node: usize,
        lc: usize,
        m: usize,
        selected: &[usize],
    ) {
        let use_heuristic = self.use_heuristic && lc == 0;
        for &nb in selected {
            if nb >= new_node {
                continue;
            }
            self.graph.push_neighbor(nb, lc, new_node);
            let nb_degree = self.graph.neighbors_len(nb, lc);
            if nb_degree <= m {
                continue;
            }

            if self.build_scratch.batch_defer_prune {
                let hard_cap = m
                    .saturating_mul(DEFERRED_PRUNE_HARD_CAP_MULTIPLIER)
                    .max(m + 1);
                if nb_degree <= hard_cap {
                    if self.build_scratch.pending_prune.len() <= lc {
                        self.build_scratch
                            .pending_prune
                            .resize_with(lc + 1, FxHashSet::default);
                    }
                    self.build_scratch.pending_prune[lc].insert(nb);
                    continue;
                }
            }

            self.prune_node_neighbors(nb, lc, m, use_heuristic);
        }

        // Wire new_node → selected neighbours.
        let mut selected_with_capacity = Vec::with_capacity((m + 1).max(selected.len()));
        selected_with_capacity.extend_from_slice(selected);
        self.graph
            .set_neighbors(new_node, lc, selected_with_capacity);
    }

    fn prune_node_neighbors(&mut self, nb: usize, lc: usize, m: usize, use_heuristic: bool) {
        // Move neighbour list out of the graph so pruning can proceed
        // without cloning and then write back the pruned result.
        let mut nb_neighbors = self.graph.take_neighbors(nb, lc);
        let nb_vec = self.graph.get_vector(nb);
        self.build_scratch.nb_dists.clear();
        for &n in &nb_neighbors {
            let d = self.metric.compute(nb_vec, self.graph.get_vector(n));
            self.build_scratch.nb_dists.push((n, d));
        }

        self.build_scratch.prune_out.clear();
        if use_heuristic {
            // Quality path: keep full ordering so heuristic
            // diversification can scan all candidates.
            self.build_scratch
                .nb_dists
                .sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
            select_neighbors_heuristic_into(
                &self.graph,
                &self.metric,
                &self.build_scratch.nb_dists,
                m,
                &mut self.build_scratch.heuristic_selected,
                &mut self.build_scratch.heuristic_out,
            );
            self.build_scratch
                .prune_out
                .extend_from_slice(&self.build_scratch.heuristic_out);
        } else {
            // Fast/instant path: we only need top-m nearest. Avoid
            // full O(k log k) sort via partition + small sort.
            let cmp = |a: &(usize, f32), b: &(usize, f32)| {
                a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)
            };
            if self.build_scratch.nb_dists.len() > m {
                self.build_scratch.nb_dists.select_nth_unstable_by(m, cmp);
                self.build_scratch.nb_dists.truncate(m);
            }
            self.build_scratch.nb_dists.sort_by(cmp);
            select_neighbors_simple_into(
                &self.build_scratch.nb_dists,
                m,
                &mut self.build_scratch.prune_out,
            );
        }

        // Reuse the old neighbor vector allocation to avoid re-allocating
        // at every prune event (common when degree oscillates around m).
        nb_neighbors.clear();
        nb_neighbors.extend_from_slice(&self.build_scratch.prune_out);
        self.graph.set_neighbors(nb, lc, nb_neighbors);
    }

    fn flush_deferred_prunes(&mut self) {
        for lc in 0..self.build_scratch.pending_prune.len() {
            let pending = std::mem::take(&mut self.build_scratch.pending_prune[lc]);
            if pending.is_empty() || lc >= self.graph.layers.len() {
                continue;
            }
            let m = self.graph.m_at_level(lc);
            let use_heuristic = self.use_heuristic && lc == 0;
            for nb in pending {
                if nb >= self.graph.size {
                    continue;
                }
                if self.graph.neighbors_len(nb, lc) > m {
                    self.prune_node_neighbors(nb, lc, m, use_heuristic);
                }
            }
        }
    }

    fn insert_prepared_with_plan(
        &mut self,
        id: &str,
        vector: &[f32],
        level: usize,
        layer_neighbors: &[(usize, Vec<usize>)],
    ) -> Result<(), HnswError> {
        if vector.len() != self.graph.dim {
            return Err(HnswError::DimensionMismatch {
                expected: self.graph.dim,
                got: vector.len(),
            });
        }
        if self.graph.size >= self.graph.max_elements {
            return Err(HnswError::IndexFull {
                capacity: self.graph.max_elements,
            });
        }
        if self.graph.id_to_idx.contains_key(id) {
            return Err(HnswError::DuplicateId(id.to_string()));
        }

        let new_node = self.graph.size;
        let owned = id.to_string();
        self.graph.id_to_idx.insert(owned.clone(), new_node);
        self.graph.ids.push(owned);
        self.graph.vectors.extend_from_slice(vector);
        self.graph.size += 1;

        self.graph.ensure_node_slot(new_node);
        self.graph.ensure_levels(level);

        if self.graph.size == 1 {
            self.graph.entry_point = Some(new_node);
            self.graph.max_level = level;
            return Ok(());
        }

        let insert_from = level.min(self.graph.max_level);
        for (lc, selected) in layer_neighbors {
            if *lc > insert_from {
                continue;
            }
            let m = self.graph.m_at_level(*lc);
            self.wire_selected_for_layer(new_node, *lc, m, selected);
        }

        if level > self.graph.max_level {
            self.graph.entry_point = Some(new_node);
            self.graph.max_level = level;
        }
        Ok(())
    }

    // ─── Insertion ────────────────────────────────────────────────────────────

    fn insert_prepared(&mut self, id: &str, vector: &[f32], level: usize) -> Result<(), HnswError> {
        if vector.len() != self.graph.dim {
            return Err(HnswError::DimensionMismatch {
                expected: self.graph.dim,
                got: vector.len(),
            });
        }
        if self.graph.size >= self.graph.max_elements {
            return Err(HnswError::IndexFull {
                capacity: self.graph.max_elements,
            });
        }
        if self.graph.id_to_idx.contains_key(id) {
            return Err(HnswError::DuplicateId(id.to_string()));
        }

        let new_node = self.graph.size;
        let owned = id.to_string();
        self.graph.id_to_idx.insert(owned.clone(), new_node);
        self.graph.ids.push(owned);
        self.graph.vectors.extend_from_slice(vector);
        self.graph.size += 1;

        // Keep layer vectors node-indexable for the new node at all existing
        // levels, then ensure levels exist up to `level`.
        self.graph.ensure_node_slot(new_node);
        self.graph.ensure_levels(level);

        // ── First insertion: set entry point and return ────────────────────────
        if self.graph.size == 1 {
            self.graph.entry_point = Some(new_node);
            self.graph.max_level = level;
            return Ok(());
        }

        // ── Greedy descent from max_level down to level + 1 ───────────────────
        // This narrows down the entry point for the insertion layers.
        let mut ep = self
            .graph
            .entry_point
            .expect("entry_point must be set when size > 1");

        if self.graph.max_level > level {
            for lc in (level + 1..=self.graph.max_level).rev() {
                ep = greedy_descent(&self.graph, vector, ep, lc, &self.metric);
            }
        }

        // ── Insert at each layer from min(level, max_level) down to 0 ─────────
        let insert_from = level.min(self.graph.max_level);
        for lc in (0..=insert_from).rev() {
            let ef_c = self.ef_construction_for_level(lc);
            let m = self.graph.m_at_level(lc);
            let use_heuristic_lc = self.use_heuristic && lc == 0;

            let (mut selected, selected_from_heuristic) = {
                // Beam search: finds the best ef_c candidates at this layer.
                let candidates = beam_search_fast_with_scratch(
                    &self.graph,
                    vector,
                    ep,
                    ef_c,
                    lc,
                    &self.metric,
                    &mut self.build_scratch.beam,
                );

                // Update entry point to the nearest found at this layer.
                if let Some(&(nearest, _)) = candidates.first() {
                    ep = nearest;
                }

                // Heuristic neighbour selection (HNSW paper Algorithm 4), or
                // nearest-only fast path when build speed is prioritised.
                if use_heuristic_lc {
                    let factor = if lc == 0 {
                        HEURISTIC_CANDIDATE_FACTOR_L0
                    } else {
                        HEURISTIC_CANDIDATE_FACTOR_UPPER
                    };
                    let limit = (m.saturating_mul(factor)).max(m).min(candidates.len());
                    let candidates = &candidates[..limit];
                    select_neighbors_heuristic_into(
                        &self.graph,
                        &self.metric,
                        candidates,
                        m,
                        &mut self.build_scratch.heuristic_selected,
                        &mut self.build_scratch.heuristic_out,
                    );
                    (std::mem::take(&mut self.build_scratch.heuristic_out), true)
                } else {
                    select_neighbors_simple_into(candidates, m, &mut self.build_scratch.prune_out);
                    (std::mem::take(&mut self.build_scratch.prune_out), false)
                }
            };

            self.wire_selected_for_layer(new_node, lc, m, &selected);
            if selected_from_heuristic {
                selected.clear();
                self.build_scratch.heuristic_out = selected;
            } else {
                selected.clear();
                self.build_scratch.prune_out = selected;
            }
        }

        // ── Promote to entry point if the new node occupies a higher level ─────
        if level > self.graph.max_level {
            self.graph.entry_point = Some(new_node);
            self.graph.max_level = level;
        }

        Ok(())
    }

    /// Insert a single vector into the index.
    ///
    /// For the `Cosine` metric, `vector` is normalised in place before storage.
    ///
    /// # Errors
    ///
    /// - [`HnswError::DimensionMismatch`] when `vector.len() != self.dimension()`.
    /// - [`HnswError::IndexFull`] when `self.len() >= max_elements`.
    /// - [`HnswError::DuplicateId`] when `id` was already inserted.
    pub fn add(&mut self, id: &str, vector: &[f32]) -> Result<(), HnswError> {
        let level = self.graph.sample_level(&mut self.rng);
        if self.metric == Metric::Cosine {
            let mut prepared = vector.to_vec();
            normalize_f32(&mut prepared);
            self.insert_prepared(id, &prepared, level)
        } else {
            self.insert_prepared(id, vector, level)
        }
    }

    /// Insert a batch of vectors with staged preprocessing.
    ///
    /// `vectors` is a flat row-major buffer: vector `i` occupies
    /// `vectors[i * dim .. (i+1) * dim]`.
    ///
    /// Preprocessing stages:
    /// 1. (parallel) optional cosine normalization over all vectors
    /// 2. (parallel) level sampling for each vector
    /// 3. (micro-batch) parallel planning on graph snapshots
    /// 4. (ordered commit) graph insertion preserving HNSW invariants
    pub fn add_batch(&mut self, ids: &[&str], vectors: &[f32]) -> Result<(), HnswError> {
        let n = ids.len();
        let dim = self.graph.dim;
        if vectors.len() != n * dim {
            return Err(HnswError::DimensionMismatch {
                expected: n * dim,
                got: vectors.len(),
            });
        }
        if self.graph.size + n > self.graph.max_elements {
            return Err(HnswError::IndexFull {
                capacity: self.graph.max_elements,
            });
        }
        // Up-front duplicate validation keeps the fast paths allocation-only.
        let mut seen_ids = FxHashSet::default();
        for &id in ids {
            if self.graph.id_to_idx.contains_key(id) || !seen_ids.insert(id) {
                return Err(HnswError::DuplicateId(id.to_string()));
            }
        }

        let ml = self.graph.ml;
        let mut levels = vec![0usize; n];
        levels
            .par_iter_mut()
            .for_each_init(SmallRng::from_entropy, |rng, slot| {
                *slot = HnswGraph::sample_level_from_ml(ml, rng)
            });

        let prepared;
        let source: &[f32] = if self.metric == Metric::Cosine {
            prepared = {
                let mut p = vectors.to_vec();
                p.par_chunks_mut(dim).for_each(normalize_f32);
                p
            };
            &prepared
        } else {
            vectors
        };

        let defer_prune_enabled = std::env::var("VAJRA_HNSW_DEFER_PRUNE")
            .ok()
            .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
            .unwrap_or(false);
        let parallel_commit_enabled = std::env::var("VAJRA_HNSW_PARALLEL_COMMIT")
            .ok()
            .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
            .unwrap_or(false);
        self.build_scratch.batch_defer_prune = defer_prune_enabled;
        self.build_scratch.pending_prune.clear();
        let result = (|| -> Result<(), HnswError> {
            let mut inserted_since_flush = 0usize;
            if n < MICRO_BATCH_PLAN_THRESHOLD {
                for (i, &id) in ids.iter().enumerate() {
                    let start = i * dim;
                    self.insert_prepared(id, &source[start..start + dim], levels[i])?;
                    inserted_since_flush += 1;
                    if inserted_since_flush >= BATCH_PRUNE_FLUSH_INTERVAL {
                        self.flush_deferred_prunes();
                        inserted_since_flush = 0;
                    }
                }
                self.flush_deferred_prunes();
                return Ok(());
            }

            // Seed the graph to enable snapshot planning.
            let mut start_idx = 0usize;
            if self.graph.size == 0 {
                self.insert_prepared(ids[0], &source[0..dim], levels[0])?;
                inserted_since_flush += 1;
                start_idx = 1;
            }
            if inserted_since_flush >= BATCH_PRUNE_FLUSH_INTERVAL {
                self.flush_deferred_prunes();
                inserted_since_flush = 0;
            }

            // Snapshot-plan + two-phase commit:
            // 1) deterministic allocation and forward-edge wiring (ordered),
            // 2) parallel reverse-edge merge+prune per touched node.
            for epoch_start in (start_idx..n).step_by(PLAN_EPOCH_SIZE) {
                let epoch_end = (epoch_start + PLAN_EPOCH_SIZE).min(n);

                let snapshot_max_level = self.graph.max_level;
                let metric = self.metric;
                let use_heuristic = self.use_heuristic;
                let mut ordered: Vec<PlannedInsertion> =
                    Vec::with_capacity(epoch_end - epoch_start);
                for chunk_start in (epoch_start..epoch_end).step_by(MICRO_BATCH_PLAN_SIZE) {
                    let chunk_end = (chunk_start + MICRO_BATCH_PLAN_SIZE).min(epoch_end);
                    let mut chunk_plans: Vec<PlannedInsertion> = {
                        let snapshot = &self.graph;
                        (chunk_start..chunk_end)
                            .into_par_iter()
                            .map(|i| {
                                let start = i * dim;
                                let vector = &source[start..start + dim];
                                let layer_neighbors = plan_insertion_on_snapshot(
                                    snapshot,
                                    &metric,
                                    use_heuristic,
                                    vector,
                                    levels[i],
                                    snapshot_max_level,
                                );
                                PlannedInsertion {
                                    idx: i,
                                    level: levels[i],
                                    layer_neighbors,
                                }
                            })
                            .collect()
                    };
                    ordered.append(&mut chunk_plans);
                }
                ordered.sort_unstable_by_key(|p| p.idx);

                if !parallel_commit_enabled {
                    // Default path: deterministic ordered commit with plan-aware
                    // inserts and fallback if snapshot max-level drifts.
                    let mut snapshot_drifted = false;
                    for plan in ordered {
                        let start = plan.idx * dim;
                        let vector = &source[start..start + dim];
                        if snapshot_drifted || self.graph.max_level != snapshot_max_level {
                            self.insert_prepared(ids[plan.idx], vector, plan.level)?;
                            snapshot_drifted = true;
                        } else {
                            self.insert_prepared_with_plan(
                                ids[plan.idx],
                                vector,
                                plan.level,
                                &plan.layer_neighbors,
                            )?;
                            if self.graph.max_level != snapshot_max_level {
                                snapshot_drifted = true;
                            }
                        }

                        inserted_since_flush += 1;
                        if inserted_since_flush >= BATCH_PRUNE_FLUSH_INTERVAL {
                            self.flush_deferred_prunes();
                            inserted_since_flush = 0;
                        }
                    }
                    continue;
                }

                let mut reverse_adds: Vec<FxHashMap<usize, Vec<usize>>> =
                    vec![FxHashMap::default(); snapshot_max_level + 1];
                let mut epoch_max_level = self.graph.max_level;
                let mut epoch_entry_point = self.graph.entry_point;

                for plan in ordered {
                    let start = plan.idx * dim;
                    let vector = &source[start..start + dim];

                    let new_node = self.graph.size;
                    let owned = ids[plan.idx].to_string();
                    self.graph.id_to_idx.insert(owned.clone(), new_node);
                    self.graph.ids.push(owned);
                    self.graph.vectors.extend_from_slice(vector);
                    self.graph.size += 1;
                    self.graph.ensure_node_slot(new_node);
                    self.graph.ensure_levels(plan.level);

                    let insert_from = plan.level.min(snapshot_max_level);
                    for (lc, selected) in plan.layer_neighbors {
                        if lc > insert_from {
                            continue;
                        }

                        let m = self.graph.m_at_level(lc);
                        let mut selected_with_capacity =
                            Vec::with_capacity((m + 1).max(selected.len()));
                        selected_with_capacity.extend_from_slice(&selected);
                        self.graph
                            .set_neighbors(new_node, lc, selected_with_capacity);

                        let layer_adds = &mut reverse_adds[lc];
                        for nb in selected {
                            if nb < new_node {
                                layer_adds.entry(nb).or_default().push(new_node);
                            }
                        }
                    }
                    if plan.level > epoch_max_level {
                        epoch_max_level = plan.level;
                        epoch_entry_point = Some(new_node);
                    }

                    inserted_since_flush += 1;
                    if inserted_since_flush >= BATCH_PRUNE_FLUSH_INTERVAL {
                        self.flush_deferred_prunes();
                        inserted_since_flush = 0;
                    }
                }

                for (lc, layer_adds) in reverse_adds.into_iter().enumerate() {
                    if layer_adds.is_empty() {
                        continue;
                    }

                    let m = self.graph.m_at_level(lc);
                    let use_heuristic = self.use_heuristic && lc == 0;
                    let metric = self.metric;
                    let graph_ref = &self.graph;
                    let touched: Vec<(usize, Vec<usize>)> = layer_adds.into_iter().collect();

                    let updates: Vec<(usize, Vec<usize>)> = touched
                        .into_par_iter()
                        .map(|(nb, adds)| {
                            let mut nb_neighbors = graph_ref.neighbors(nb, lc).to_vec();
                            nb_neighbors.extend(adds);

                            if nb_neighbors.len() <= m {
                                return (nb, nb_neighbors);
                            }

                            let nb_vec = graph_ref.get_vector(nb);
                            let mut nb_dists: Vec<(usize, f32)> =
                                Vec::with_capacity(nb_neighbors.len());
                            for n in nb_neighbors {
                                let d = metric.compute(nb_vec, graph_ref.get_vector(n));
                                nb_dists.push((n, d));
                            }

                            let pruned = if use_heuristic {
                                nb_dists.sort_by(|a, b| {
                                    a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)
                                });
                                select_neighbors_heuristic(graph_ref, &metric, nb_vec, &nb_dists, m)
                            } else {
                                let cmp = |a: &(usize, f32), b: &(usize, f32)| {
                                    a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)
                                };
                                if nb_dists.len() > m {
                                    nb_dists.select_nth_unstable_by(m, cmp);
                                    nb_dists.truncate(m);
                                }
                                nb_dists.sort_by(cmp);
                                select_neighbors_simple(&nb_dists, m)
                            };
                            (nb, pruned)
                        })
                        .collect();

                    for (nb, pruned) in updates {
                        self.graph.set_neighbors(nb, lc, pruned);
                    }
                }

                self.graph.max_level = epoch_max_level;
                self.graph.entry_point = epoch_entry_point;
            }

            self.flush_deferred_prunes();
            Ok(())
        })();
        self.build_scratch.batch_defer_prune = false;
        self.build_scratch.pending_prune.clear();
        result
    }

    // ─── Search ───────────────────────────────────────────────────────────────

    /// Search for the `k` nearest neighbours using `self.ef_search` as the beam width.
    ///
    /// # Errors
    ///
    /// - [`HnswError::EmptyIndex`] if no vectors have been inserted.
    /// - [`HnswError::DimensionMismatch`] if `query.len() != self.dimension()`.
    pub fn search(&self, query: &[f32], k: usize) -> Result<Vec<HnswResult>, HnswError> {
        self.search_ef(query, k, self.ef_search)
    }

    /// Search with an explicit `ef` beam width.
    ///
    /// `ef` overrides `self.ef_search` for this query only.  The actual beam
    /// width used is `max(k, ef)` to ensure at least `k` candidates are
    /// evaluated.
    pub fn search_ef(
        &self,
        query: &[f32],
        k: usize,
        ef: usize,
    ) -> Result<Vec<HnswResult>, HnswError> {
        if self.graph.size == 0 {
            return Err(HnswError::EmptyIndex);
        }
        if query.len() != self.graph.dim {
            return Err(HnswError::DimensionMismatch {
                expected: self.graph.dim,
                got: query.len(),
            });
        }

        // Normalise query for cosine (vectors in the index are pre-normalised).
        let normalised: Vec<f32>;
        let q: &[f32] = if self.metric == Metric::Cosine {
            normalised = {
                let mut v = query.to_vec();
                normalize_f32(&mut v);
                v
            };
            &normalised
        } else {
            query
        };

        let ep = self
            .graph
            .entry_point
            .expect("entry_point is set in a non-empty index");

        // Greedy descent through upper layers to find a good layer-0 entry.
        let mut current_ep = ep;
        for lc in (1..=self.graph.max_level).rev() {
            current_ep = greedy_descent(&self.graph, q, current_ep, lc, &self.metric);
        }

        // Beam search at layer 0 with ef = max(k, ef).
        let ef_actual = ef.max(k);
        let raw = beam_search_fast(&self.graph, q, current_ep, ef_actual, 0, &self.metric);

        // Map to HnswResult, capped at k.
        let results = raw
            .into_iter()
            .take(k)
            .enumerate()
            .map(|(i, (node, dist))| HnswResult {
                id: self.graph.ids[node].clone(),
                score: dist,
                rank: i + 1,
            })
            .collect();

        Ok(results)
    }

    /// Search multiple query vectors in parallel using Rayon.
    ///
    /// `queries` is a flat row-major buffer: query `i` occupies
    /// `queries[i * dim .. (i+1) * dim]`.  Returns one result list per query
    /// in input order.
    ///
    /// # Errors
    ///
    /// Returns the first search error encountered, if any.
    pub fn search_batch(
        &self,
        queries: &[f32],
        k: usize,
    ) -> Result<Vec<Vec<HnswResult>>, HnswError> {
        let dim = self.graph.dim;
        if queries.len() % dim != 0 {
            return Err(HnswError::DimensionMismatch {
                expected: dim,
                got: queries.len() % dim,
            });
        }
        let n = queries.len() / dim;
        (0..n)
            .into_par_iter()
            .map(|i| self.search(&queries[i * dim..(i + 1) * dim], k))
            .collect()
    }

    // ─── Persistence ──────────────────────────────────────────────────────────

    /// Serialise the index to `path` using `bincode`.
    ///
    /// Uses a `BufWriter` for efficient I/O.  The parent directory must exist.
    ///
    /// # Errors
    ///
    /// Returns [`HnswError::Io`] on file errors or [`HnswError::Serialization`]
    /// on encoding errors.
    pub fn save(&self, path: &Path) -> Result<(), HnswError> {
        let file = std::fs::File::create(path)?;
        let writer = BufWriter::new(file);
        let data = HnswIndexData {
            graph: self.graph.clone(),
            metric: self.metric,
            ef_search: self.ef_search,
            use_heuristic: self.use_heuristic,
        };
        bincode::serialize_into(writer, &data)?;
        Ok(())
    }

    /// Load an index from a file written by [`save`](Self::save).
    ///
    /// Uses a `BufReader` for efficient I/O.
    ///
    /// # Errors
    ///
    /// Returns [`HnswError::Io`] on file errors or [`HnswError::Serialization`]
    /// on decoding errors.
    pub fn load(path: &Path) -> Result<Self, HnswError> {
        let file = std::fs::File::open(path)?;
        let reader = BufReader::new(file);
        let data: HnswIndexData = bincode::deserialize_from(reader)?;
        Ok(Self {
            graph: data.graph,
            metric: data.metric,
            ef_search: data.ef_search,
            use_heuristic: data.use_heuristic,
            rng: SmallRng::from_entropy(),
            build_scratch: BuildScratch::default(),
        })
    }

    // ─── Accessors ────────────────────────────────────────────────────────────

    /// Number of vectors currently stored.
    #[inline]
    pub fn len(&self) -> usize {
        self.graph.size
    }

    /// Returns `true` if no vectors have been inserted.
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.graph.size == 0
    }

    /// Returns `true` if `id` is present in the index.
    #[inline]
    pub fn contains(&self, id: &str) -> bool {
        self.graph.id_to_idx.contains_key(id)
    }

    /// Vector dimensionality of this index.
    #[inline]
    pub fn dimension(&self) -> usize {
        self.graph.dim
    }

    /// Distance metric used by this index.
    #[inline]
    pub fn metric(&self) -> Metric {
        self.metric
    }

    /// Returns whether heuristic neighbour diversification is enabled for insertion.
    #[inline]
    pub fn use_heuristic(&self) -> bool {
        self.use_heuristic
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn small_index() -> HnswIndex {
        let mut idx = HnswIndex::new(4, Metric::L2, 4, 50, 20, 10);
        idx.add("a", &[1.0f32, 0.0, 0.0, 0.0]).unwrap();
        idx.add("b", &[0.0f32, 1.0, 0.0, 0.0]).unwrap();
        idx.add("c", &[-1.0f32, 0.0, 0.0, 0.0]).unwrap();
        idx.add("d", &[0.0f32, -1.0, 0.0, 0.0]).unwrap();
        idx
    }

    #[test]
    fn test_add_and_search_nearest() {
        let idx = small_index();
        let results = idx.search(&[1.0f32, 0.0, 0.0, 0.0], 1).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "a");
        assert!(results[0].score < 1e-6);
        assert_eq!(results[0].rank, 1);
    }

    #[test]
    fn test_search_results_sorted() {
        let idx = small_index();
        let results = idx.search(&[1.0f32, 0.0, 0.0, 0.0], 4).unwrap();
        for w in results.windows(2) {
            assert!(w[0].score <= w[1].score, "results not sorted by score");
        }
    }

    #[test]
    fn test_search_ranks_are_sequential() {
        let idx = small_index();
        let results = idx.search(&[1.0f32, 0.0, 0.0, 0.0], 4).unwrap();
        for (i, r) in results.iter().enumerate() {
            assert_eq!(r.rank, i + 1);
        }
    }

    #[test]
    fn test_len_and_is_empty() {
        let mut idx = HnswIndex::new(2, Metric::L2, 4, 50, 10, 5);
        assert!(idx.is_empty());
        assert_eq!(idx.len(), 0);
        idx.add("x", &[1.0, 0.0]).unwrap();
        assert!(!idx.is_empty());
        assert_eq!(idx.len(), 1);
    }

    #[test]
    fn test_contains() {
        let idx = small_index();
        assert!(idx.contains("a"));
        assert!(!idx.contains("z"));
    }

    #[test]
    fn test_dimension_and_metric_accessors() {
        let idx = HnswIndex::new(8, Metric::Cosine, 4, 50, 10, 5);
        assert_eq!(idx.dimension(), 8);
        assert_eq!(idx.metric(), Metric::Cosine);
    }

    #[test]
    fn test_error_dimension_mismatch() {
        let mut idx = HnswIndex::new(4, Metric::L2, 4, 50, 10, 5);
        let err = idx.add("x", &[1.0, 0.0]).unwrap_err();
        assert!(matches!(
            err,
            HnswError::DimensionMismatch {
                expected: 4,
                got: 2
            }
        ));
    }

    #[test]
    fn test_error_duplicate_id() {
        let mut idx = HnswIndex::new(2, Metric::L2, 4, 50, 10, 5);
        idx.add("a", &[1.0, 0.0]).unwrap();
        let err = idx.add("a", &[0.0, 1.0]).unwrap_err();
        assert!(matches!(err, HnswError::DuplicateId(s) if s == "a"));
    }

    #[test]
    fn test_error_index_full() {
        let mut idx = HnswIndex::new(2, Metric::L2, 4, 50, 2, 5);
        idx.add("a", &[1.0, 0.0]).unwrap();
        idx.add("b", &[0.0, 1.0]).unwrap();
        let err = idx.add("c", &[1.0, 1.0]).unwrap_err();
        assert!(matches!(err, HnswError::IndexFull { capacity: 2 }));
    }

    #[test]
    fn test_error_search_empty_index() {
        let idx = HnswIndex::new(4, Metric::L2, 4, 50, 10, 5);
        let err = idx.search(&[1.0, 0.0, 0.0, 0.0], 1).unwrap_err();
        assert!(matches!(err, HnswError::EmptyIndex));
    }

    #[test]
    fn test_error_search_dimension_mismatch() {
        let idx = small_index();
        let err = idx.search(&[1.0, 0.0], 1).unwrap_err();
        assert!(matches!(
            err,
            HnswError::DimensionMismatch {
                expected: 4,
                got: 2
            }
        ));
    }

    #[test]
    fn test_single_node_search() {
        let mut idx = HnswIndex::new(3, Metric::L2, 4, 50, 10, 5);
        idx.add("only", &[1.0f32, 2.0, 3.0]).unwrap();
        let results = idx.search(&[1.0, 2.0, 3.0], 1).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "only");
        assert!(results[0].score < 1e-6);
    }

    #[test]
    fn test_cosine_search_nearest_direction() {
        let mut idx = HnswIndex::new(3, Metric::Cosine, 4, 100, 20, 10);
        idx.add("pos_x", &[1.0f32, 0.0, 0.0]).unwrap();
        idx.add("pos_y", &[0.0f32, 1.0, 0.0]).unwrap();
        idx.add("pos_z", &[0.0f32, 0.0, 1.0]).unwrap();
        let results = idx.search(&[1.0f32, 0.1, 0.0], 1).unwrap();
        assert_eq!(results[0].id, "pos_x");
    }

    #[test]
    fn test_add_batch() {
        let mut idx = HnswIndex::new(2, Metric::L2, 4, 100, 20, 10);
        let ids = vec!["p", "q", "r"];
        let vecs: Vec<f32> = vec![1.0, 0.0, 0.0, 1.0, -1.0, 0.0];
        idx.add_batch(&ids, &vecs).unwrap();
        assert_eq!(idx.len(), 3);
        assert!(idx.contains("p"));
        assert!(idx.contains("r"));
    }

    #[test]
    fn test_search_batch_returns_correct_order() {
        let mut idx = HnswIndex::new(2, Metric::L2, 4, 100, 20, 10);
        for i in 0..10usize {
            idx.add(&i.to_string(), &[i as f32, 0.0]).unwrap();
        }
        let queries = vec![0.0f32, 0.0, 9.0, 0.0];
        let results = idx.search_batch(&queries, 1).unwrap();
        assert_eq!(results.len(), 2);
        assert_eq!(results[0][0].id, "0");
        assert_eq!(results[1][0].id, "9");
    }
}
