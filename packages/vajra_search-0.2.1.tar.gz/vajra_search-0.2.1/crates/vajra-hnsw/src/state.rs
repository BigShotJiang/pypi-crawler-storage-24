//! Carrier type for the HNSW search coalgebra.
//!
//! [`HnswSearchState`] is the carrier set X in the coalgebra (X, α) where
//! α: X → List(X) is implemented by [`crate::coalgebra::HnswNavigationCoalgebra`].
//!
//! One state snapshot holds everything needed to resume beam search from any point,
//! making the coalgebra semantics explicit: search is an unfolding of states.

use ordered_float::OrderedFloat;
use std::cmp::Reverse;
use std::collections::{BinaryHeap, HashSet};

// ─── Candidate ────────────────────────────────────────────────────────────────

/// A single node candidate with its distance to the query.
///
/// Ordering is **max by distance**, so `BinaryHeap<Candidate>` is a max-heap:
/// the farthest node is at the top and can be evicted first.
///
/// For a **min-heap** (process nearest first), wrap as `BinaryHeap<Reverse<Candidate>>`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Candidate {
    /// Node index in the graph's flat vector buffer.
    pub node: usize,
    /// Distance to the query vector (NaN-safe via `OrderedFloat`).
    pub dist: OrderedFloat<f32>,
}

impl PartialOrd for Candidate {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Candidate {
    /// Max by distance: the candidate with the **largest** distance has the highest priority.
    ///
    /// This makes `BinaryHeap<Candidate>` a max-heap suited for the results set,
    /// where we evict the farthest element when the heap exceeds `ef`.
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.dist.cmp(&other.dist)
    }
}

// ─── HnswSearchState ──────────────────────────────────────────────────────────

/// Carrier type X for the HNSW search coalgebra.
///
/// Represents one complete snapshot of the beam search traversal:
/// - `candidates` (min-heap): nodes to expand, nearest first
/// - `results` (max-heap, capped at `ef`): best results found so far, farthest on top
/// - `visited`: nodes already examined (prevents re-expansion)
///
/// The coalgebra's `structure_map` takes one `HnswSearchState` and returns
/// `Vec<HnswSearchState>` (either `[]` if terminal, or `[new_state]` if
/// one more step is possible).
///
/// # Relationship to Python
///
/// Maps directly to `HNSWSearchState` in `vajra_bm25/vector/hnsw.py`, which is
/// a `@dataclass(frozen=True)`.  Rust ownership provides equivalent safety guarantees
/// without immutability — we clone state when the coalgebra steps.
#[derive(Debug, Clone)]
pub struct HnswSearchState {
    /// Query vector (normalised if cosine metric).
    pub query: Vec<f32>,
    /// Current layer in the HNSW graph.
    pub current_level: usize,
    /// Expansion factor: maximum number of results maintained in the beam.
    pub ef: usize,
    /// Min-heap of candidates to expand (nearest distance = highest priority).
    pub candidates: BinaryHeap<Reverse<Candidate>>,
    /// Max-heap of current best results (farthest = highest priority, for easy eviction).
    pub results: BinaryHeap<Candidate>,
    /// Nodes already visited; prevents redundant distance computations.
    pub visited: HashSet<usize>,
}

impl HnswSearchState {
    /// Construct a new search state seeded with a single entry node.
    pub fn new(
        query: Vec<f32>,
        entry_node: usize,
        entry_dist: f32,
        ef: usize,
        level: usize,
    ) -> Self {
        let seed = Candidate {
            node: entry_node,
            dist: OrderedFloat(entry_dist),
        };
        let mut candidates = BinaryHeap::new();
        let mut results = BinaryHeap::new();
        let mut visited = HashSet::new();

        candidates.push(Reverse(seed.clone()));
        results.push(seed);
        visited.insert(entry_node);

        Self {
            query,
            current_level: level,
            ef,
            candidates,
            results,
            visited,
        }
    }

    /// Return `true` when the candidate heap is empty (no more nodes to expand).
    ///
    /// The coalgebra's `structure_map` returns `vec![]` when this is true.
    #[inline]
    pub fn is_terminal(&self) -> bool {
        self.candidates.is_empty()
    }

    /// Distance of the worst (farthest) result currently in the beam.
    ///
    /// Returns `f32::INFINITY` when no results have been collected yet.
    #[inline]
    pub fn farthest_result_dist(&self) -> f32 {
        self.results
            .peek()
            .map(|c| c.dist.0)
            .unwrap_or(f32::INFINITY)
    }

    /// Consume the state and return the results sorted by distance (nearest first).
    pub fn into_sorted_results(self) -> Vec<(usize, f32)> {
        let mut out: Vec<(usize, f32)> = self
            .results
            .into_iter()
            .map(|c| (c.node, c.dist.0))
            .collect();
        out.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
        out
    }

    /// Descend to a lower level, resetting candidates/results/visited but
    /// keeping the query and ef.  The new entry node is the best result at the
    /// current level.
    ///
    /// Returns `None` if there are no results to descend from.
    pub fn descend_to_level(&self, new_level: usize, entry_dist: f32) -> Option<Self> {
        let entry = self.results.peek()?.node;
        Some(HnswSearchState::new(
            self.query.clone(),
            entry,
            entry_dist,
            self.ef,
            new_level,
        ))
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn make_state(entry_dist: f32, ef: usize) -> HnswSearchState {
        HnswSearchState::new(vec![1.0, 0.0, 0.0], 0, entry_dist, ef, 0)
    }

    #[test]
    fn test_candidate_max_heap_ordering() {
        let mut heap: BinaryHeap<Candidate> = BinaryHeap::new();
        heap.push(Candidate {
            node: 0,
            dist: OrderedFloat(0.5),
        });
        heap.push(Candidate {
            node: 1,
            dist: OrderedFloat(0.1),
        });
        heap.push(Candidate {
            node: 2,
            dist: OrderedFloat(0.9),
        });
        // max-heap: peek returns farthest
        assert_eq!(heap.peek().unwrap().node, 2);
    }

    #[test]
    fn test_candidate_min_heap_via_reverse() {
        let mut heap: BinaryHeap<Reverse<Candidate>> = BinaryHeap::new();
        heap.push(Reverse(Candidate {
            node: 0,
            dist: OrderedFloat(0.5),
        }));
        heap.push(Reverse(Candidate {
            node: 1,
            dist: OrderedFloat(0.1),
        }));
        heap.push(Reverse(Candidate {
            node: 2,
            dist: OrderedFloat(0.9),
        }));
        // Reverse turns it into min-heap: peek returns nearest
        let Reverse(top) = heap.peek().unwrap();
        assert_eq!(top.node, 1);
    }

    #[test]
    fn test_new_state_seeded_correctly() {
        let state = make_state(0.3, 10);
        assert_eq!(state.candidates.len(), 1);
        assert_eq!(state.results.len(), 1);
        assert_eq!(state.visited.len(), 1);
        assert!(state.visited.contains(&0));
        assert!(!state.is_terminal());
    }

    #[test]
    fn test_is_terminal_when_candidates_empty() {
        let mut state = make_state(0.3, 10);
        state.candidates.clear();
        assert!(state.is_terminal());
    }

    #[test]
    fn test_farthest_result_dist() {
        let state = make_state(0.7, 10);
        assert!((state.farthest_result_dist() - 0.7).abs() < 1e-6);
    }

    #[test]
    fn test_farthest_result_dist_empty_results() {
        let state = HnswSearchState {
            query: vec![1.0],
            current_level: 0,
            ef: 5,
            candidates: BinaryHeap::new(),
            results: BinaryHeap::new(),
            visited: HashSet::new(),
        };
        assert_eq!(state.farthest_result_dist(), f32::INFINITY);
    }

    #[test]
    fn test_into_sorted_results() {
        let mut state = make_state(0.5, 10);
        // Add more candidates manually
        state.results.push(Candidate {
            node: 1,
            dist: OrderedFloat(0.2),
        });
        state.results.push(Candidate {
            node: 2,
            dist: OrderedFloat(0.8),
        });
        let sorted = state.into_sorted_results();
        assert_eq!(sorted.len(), 3);
        // Should be sorted nearest first
        assert!(sorted[0].1 <= sorted[1].1);
        assert!(sorted[1].1 <= sorted[2].1);
    }
}
