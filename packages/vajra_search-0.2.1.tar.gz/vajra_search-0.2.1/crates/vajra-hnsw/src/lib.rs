//! `vajra-hnsw`: coalgebraic HNSW approximate nearest-neighbour index.
//!
//! This crate provides a Hierarchical Navigable Small-World (HNSW) vector
//! index implemented with the categorical design pattern used throughout the
//! `vajra_search_engine` workspace:
//!
//! - Distance functions implement [`vajra_core::category::Morphism`] — see
//!   [`distance`].
//! - Graph navigation is modelled as a [`Coalgebra`] over a carrier state —
//!   see [`coalgebra`] and [`state`].
//! - A fast imperative path ([`search::beam_search_fast`]) is used in
//!   production; the coalgebraic path serves as the correctness reference in
//!   tests.
//!
//! # Quick start
//!
//! ```rust
//! use vajra_hnsw::{HnswIndex, Metric};
//!
//! let mut idx = HnswIndex::new(4, Metric::L2, 16, 200, 1_000, 50);
//! idx.add("a", &[1.0f32, 0.0, 0.0, 0.0]).unwrap();
//! idx.add("b", &[0.0f32, 1.0, 0.0, 0.0]).unwrap();
//!
//! let results = idx.search(&[1.0f32, 0.0, 0.0, 0.0], 1).unwrap();
//! assert_eq!(results[0].id, "a");
//! assert_eq!(results[0].rank, 1);
//! ```
//!
//! # Crate layout
//!
//! | Module | Contents |
//! |--------|----------|
//! | [`index`] | [`HnswIndex`] — primary entry point |
//! | [`graph`] | [`HnswGraph`] — flat vector store + adjacency |
//! | [`state`] | [`HnswSearchState`], [`Candidate`] — coalgebra carrier |
//! | [`distance`] | [`Metric`] enum + morphism impls |
//! | [`coalgebra`] | [`HnswNavigationCoalgebra`] — correctness reference |
//! | [`search`] | Fast beam search and neighbour selection |
//! | [`error`] | [`HnswError`] — structured error type |

pub mod coalgebra;
pub mod distance;
pub mod error;
pub mod graph;
pub mod index;
pub mod search;
pub mod state;

// ── Top-level re-exports ──────────────────────────────────────────────────────

/// Primary entry point: the HNSW index.
pub use index::{HnswIndex, HnswResult};

/// Distance metric enum (L2, Cosine, InnerProduct).
pub use distance::Metric;

/// Structured error type for all fallible operations.
pub use error::HnswError;

/// The underlying graph (advanced / testing use).
pub use graph::HnswGraph;

/// Coalgebraic navigator — the correctness reference path.
pub use coalgebra::HnswNavigationCoalgebra;

/// Carrier type and candidate for the coalgebra (advanced / testing use).
pub use state::{Candidate, HnswSearchState};
