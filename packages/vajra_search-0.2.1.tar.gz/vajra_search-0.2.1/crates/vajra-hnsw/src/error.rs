//! Error types for the HNSW index.
//!
//! All fallible operations on [`crate::HnswIndex`] return `Result<_, HnswError>`.
//! The PyO3 layer maps these variants to appropriate Python exception types.

/// Errors that can occur during HNSW index operations.
#[derive(Debug, thiserror::Error)]
pub enum HnswError {
    /// A vector's dimensionality does not match the index dimension.
    ///
    /// Raised on `add`, `add_batch`, `search`, `search_batch`.
    #[error("dimension mismatch: expected {expected}, got {got}")]
    DimensionMismatch { expected: usize, got: usize },

    /// The index has reached its pre-allocated capacity.
    ///
    /// Create a new index with a larger `max_elements` or stop adding vectors.
    #[error("index is full (capacity {capacity})")]
    IndexFull { capacity: usize },

    /// A search was attempted on an index with no vectors.
    #[error("index is empty: add vectors before searching")]
    EmptyIndex,

    /// A vector with this ID already exists in the index.
    #[error("duplicate id: '{0}' already exists in the index")]
    DuplicateId(String),

    /// The metric string passed to `HnswIndex::new` was not recognised.
    ///
    /// Valid values: `"cosine"`, `"l2"`, `"inner_product"`.
    #[error("unknown metric '{0}': expected \"cosine\", \"l2\", or \"inner_product\"")]
    InvalidMetric(String),

    /// A serialization or deserialization error from `bincode`.
    #[error("serialization error: {0}")]
    Serialization(#[from] bincode::Error),

    /// An I/O error when reading or writing the index file.
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_messages() {
        let e = HnswError::DimensionMismatch {
            expected: 128,
            got: 64,
        };
        assert!(e.to_string().contains("128"));
        assert!(e.to_string().contains("64"));

        let e = HnswError::IndexFull { capacity: 1000 };
        assert!(e.to_string().contains("1000"));

        let e = HnswError::EmptyIndex;
        assert!(e.to_string().contains("empty"));

        let e = HnswError::DuplicateId("doc-1".to_string());
        assert!(e.to_string().contains("doc-1"));

        let e = HnswError::InvalidMetric("jaccard".to_string());
        assert!(e.to_string().contains("jaccard"));
    }

    #[test]
    fn test_io_error_conversion() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let hnsw_err: HnswError = io_err.into();
        assert!(matches!(hnsw_err, HnswError::Io(_)));
    }
}
