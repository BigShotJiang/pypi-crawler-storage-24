//! Distance functions and the `Metric` enum.
//!
//! Distance functions are implemented as [`vajra_core::category::Morphism`] instances,
//! keeping the categorical design consistent with the rest of the codebase.
//!
//! # SIMD
//!
//! The scalar loops in `dot_f32` and `l2_sq_f32` are written in a form that LLVM
//! auto-vectorises to AVX2 / NEON when built with `target-cpu=native`
//! (configured in `.cargo/config.toml` for local builds).
//! No explicit SIMD crate is required.

use serde::{Deserialize, Serialize};
use vajra_core::category::Morphism;

// ─── Scalar distance kernels ────────────────────────────────────────────────

/// Dot product of two equal-length f32 slices.
///
/// LLVM auto-vectorises this loop to AVX2 / NEON under `target-cpu=native`.
///
/// # Panics
///
/// Does not panic, but results are undefined if `a.len() != b.len()`.
#[inline]
pub fn dot_f32(a: &[f32], b: &[f32]) -> f32 {
    debug_assert_eq!(a.len(), b.len());
    let n = a.len();
    let mut i = 0usize;

    // Four-way unroll keeps multiple accumulators live, which helps LLVM
    // emit wider vector code and reduces loop-carried dependency.
    let mut s0 = 0.0f32;
    let mut s1 = 0.0f32;
    let mut s2 = 0.0f32;
    let mut s3 = 0.0f32;

    while i + 4 <= n {
        s0 += a[i] * b[i];
        s1 += a[i + 1] * b[i + 1];
        s2 += a[i + 2] * b[i + 2];
        s3 += a[i + 3] * b[i + 3];
        i += 4;
    }

    let mut sum = s0 + s1 + s2 + s3;
    while i < n {
        sum += a[i] * b[i];
        i += 1;
    }
    sum
}

/// Squared L2 (Euclidean) distance between two f32 vectors.
#[inline]
pub fn l2_sq_f32(a: &[f32], b: &[f32]) -> f32 {
    debug_assert_eq!(a.len(), b.len());
    let n = a.len();
    let mut i = 0usize;

    let mut s0 = 0.0f32;
    let mut s1 = 0.0f32;
    let mut s2 = 0.0f32;
    let mut s3 = 0.0f32;

    while i + 4 <= n {
        let d0 = a[i] - b[i];
        let d1 = a[i + 1] - b[i + 1];
        let d2 = a[i + 2] - b[i + 2];
        let d3 = a[i + 3] - b[i + 3];
        s0 += d0 * d0;
        s1 += d1 * d1;
        s2 += d2 * d2;
        s3 += d3 * d3;
        i += 4;
    }

    let mut sum = s0 + s1 + s2 + s3;
    while i < n {
        let d = a[i] - b[i];
        sum += d * d;
        i += 1;
    }
    sum
}

/// Normalise a vector in-place to unit L2 norm.
///
/// Vectors closer to the zero vector than `1e-12` are left unchanged.
#[inline]
pub fn normalize_f32(v: &mut [f32]) {
    let norm: f32 = v.iter().map(|x| x * x).sum::<f32>().sqrt();
    if norm > 1e-12 {
        v.iter_mut().for_each(|x| *x /= norm);
    }
}

// ─── Morphism implementations ────────────────────────────────────────────────

/// Cosine distance morphism.
///
/// Assumes vectors are pre-normalised (unit L2 norm).
/// Under this assumption, cosine distance = 1 − dot(a, b), which is cheap to compute.
///
/// The `HnswIndex` normalises all vectors at insertion time when `metric = Cosine`.
pub struct CosineMorphism;

impl<'a> Morphism<(&'a [f32], &'a [f32]), f32> for CosineMorphism {
    /// Apply cosine distance: `1.0 − dot(a, b)` (assumes unit-norm inputs).
    #[inline]
    fn apply(&self, (a, b): (&'a [f32], &'a [f32])) -> f32 {
        1.0 - dot_f32(a, b)
    }
}

/// L2 (Euclidean) distance morphism.
pub struct L2Morphism;

impl<'a> Morphism<(&'a [f32], &'a [f32]), f32> for L2Morphism {
    /// Apply L2 distance: `sqrt(sum((a_i − b_i)²))`.
    #[inline]
    fn apply(&self, (a, b): (&'a [f32], &'a [f32])) -> f32 {
        l2_sq_f32(a, b).sqrt()
    }
}

/// Inner product (negated) morphism.
///
/// Negated so that "closer" (higher inner product) maps to smaller distance,
/// making it compatible with min-heap priority queues.
pub struct InnerProductMorphism;

impl<'a> Morphism<(&'a [f32], &'a [f32]), f32> for InnerProductMorphism {
    /// Apply negated inner product: `−dot(a, b)`.
    #[inline]
    fn apply(&self, (a, b): (&'a [f32], &'a [f32])) -> f32 {
        -dot_f32(a, b)
    }
}

// ─── Metric enum ─────────────────────────────────────────────────────────────

/// The distance metric used by the HNSW index.
///
/// Passed to [`crate::HnswIndex::new`] as a string (`"cosine"`, `"l2"`,
/// `"inner_product"`) or constructed directly.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Metric {
    /// Cosine distance. Vectors are normalised at insertion time.
    Cosine,
    /// L2 (Euclidean) distance.
    L2,
    /// Negated inner product. Higher dot product = closer.
    InnerProduct,
}

impl Metric {
    /// Compute the distance between two vectors according to this metric.
    ///
    /// For `Cosine`, assumes both vectors have already been normalised.
    #[inline]
    pub fn compute(&self, a: &[f32], b: &[f32]) -> f32 {
        match self {
            Metric::Cosine => CosineMorphism.apply((a, b)),
            Metric::L2 => L2Morphism.apply((a, b)),
            Metric::InnerProduct => InnerProductMorphism.apply((a, b)),
        }
    }

    /// Parse a metric from its string name (case-insensitive).
    ///
    /// Accepted: `"cosine"`, `"l2"`, `"euclidean"`, `"inner_product"`, `"ip"`, `"dot"`.
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "cosine" => Some(Metric::Cosine),
            "l2" | "euclidean" => Some(Metric::L2),
            "inner_product" | "ip" | "dot" => Some(Metric::InnerProduct),
            _ => None,
        }
    }

    /// Return the canonical string name for this metric.
    pub fn as_str(&self) -> &'static str {
        match self {
            Metric::Cosine => "cosine",
            Metric::L2 => "l2",
            Metric::InnerProduct => "inner_product",
        }
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── Scalar kernels ────────────────────────────────────────────────────────

    #[test]
    fn test_dot_f32_orthogonal() {
        let a = [1.0f32, 0.0, 0.0];
        let b = [0.0f32, 1.0, 0.0];
        assert!((dot_f32(&a, &b) - 0.0).abs() < 1e-7);
    }

    #[test]
    fn test_dot_f32_parallel() {
        let a = [1.0f32, 0.0, 0.0];
        assert!((dot_f32(&a, &a) - 1.0).abs() < 1e-7);
    }

    #[test]
    fn test_l2_sq_zero_distance() {
        let a = [1.0f32, 2.0, 3.0];
        assert!((l2_sq_f32(&a, &a)).abs() < 1e-7);
    }

    #[test]
    fn test_l2_sq_known_value() {
        let a = [0.0f32, 0.0];
        let b = [3.0f32, 4.0];
        // squared distance should be 9 + 16 = 25
        assert!((l2_sq_f32(&a, &b) - 25.0).abs() < 1e-6);
    }

    #[test]
    fn test_normalize_unit_vector() {
        let mut v = vec![3.0f32, 4.0];
        normalize_f32(&mut v);
        let norm: f32 = v.iter().map(|x| x * x).sum::<f32>().sqrt();
        assert!((norm - 1.0).abs() < 1e-6);
        assert!((v[0] - 0.6).abs() < 1e-6);
        assert!((v[1] - 0.8).abs() < 1e-6);
    }

    #[test]
    fn test_normalize_zero_vector_unchanged() {
        let mut v = vec![0.0f32; 4];
        normalize_f32(&mut v);
        // Should remain zero (not NaN or panic)
        assert!(v.iter().all(|&x| x == 0.0));
    }

    // ── Morphisms ─────────────────────────────────────────────────────────────

    #[test]
    fn test_cosine_identical_unit_vectors() {
        let a = [1.0f32, 0.0, 0.0];
        // distance to itself = 0
        assert!((CosineMorphism.apply((&a, &a))).abs() < 1e-7);
    }

    #[test]
    fn test_cosine_orthogonal_unit_vectors() {
        let a = [1.0f32, 0.0];
        let b = [0.0f32, 1.0];
        // distance = 1 - dot(a,b) = 1 - 0 = 1
        assert!((CosineMorphism.apply((&a, &b)) - 1.0).abs() < 1e-7);
    }

    #[test]
    fn test_l2_morphism_known_distance() {
        let a = [0.0f32, 0.0];
        let b = [3.0f32, 4.0];
        // distance = 5
        assert!((L2Morphism.apply((&a, &b)) - 5.0).abs() < 1e-6);
    }

    #[test]
    fn test_inner_product_negated() {
        let a = [1.0f32, 2.0, 3.0];
        let b = [4.0f32, 5.0, 6.0];
        // dot = 4 + 10 + 18 = 32, negated = -32
        assert!((InnerProductMorphism.apply((&a, &b)) + 32.0).abs() < 1e-6);
    }

    // ── Metric enum ───────────────────────────────────────────────────────────

    #[test]
    fn test_metric_from_str_valid() {
        assert_eq!(Metric::from_str("cosine"), Some(Metric::Cosine));
        assert_eq!(Metric::from_str("COSINE"), Some(Metric::Cosine));
        assert_eq!(Metric::from_str("l2"), Some(Metric::L2));
        assert_eq!(Metric::from_str("euclidean"), Some(Metric::L2));
        assert_eq!(
            Metric::from_str("inner_product"),
            Some(Metric::InnerProduct)
        );
        assert_eq!(Metric::from_str("ip"), Some(Metric::InnerProduct));
        assert_eq!(Metric::from_str("dot"), Some(Metric::InnerProduct));
    }

    #[test]
    fn test_metric_from_str_invalid() {
        assert_eq!(Metric::from_str("jaccard"), None);
        assert_eq!(Metric::from_str(""), None);
    }

    #[test]
    fn test_metric_compute_cosine_identical() {
        let mut a = vec![1.0f32, 2.0, 3.0];
        normalize_f32(&mut a);
        assert!(Metric::Cosine.compute(&a, &a).abs() < 1e-6);
    }

    #[test]
    fn test_metric_as_str_roundtrip() {
        for m in [Metric::Cosine, Metric::L2, Metric::InnerProduct] {
            assert_eq!(Metric::from_str(m.as_str()), Some(m));
        }
    }
}
