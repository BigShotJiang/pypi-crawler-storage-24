//! # Vajra Parallel - Parallel Processing
//!
//! Parallel query processing using Rayon.
//!
//! ## Features
//!
//! - Batch query processing with automatic parallelization
//! - Thread-safe index access via Arc
//! - Configurable thread pool

use rayon::prelude::*;
use std::sync::Arc;
use vajra_ir::bm25::BM25Params;
use vajra_ir::document::DocumentCorpus;
use vajra_ir::search::{QueryState, SearchResult, VajraSearch};

/// Parallel search engine wrapper.
///
/// Wraps VajraSearch with thread-safe shared state for parallel queries.
pub struct VajraSearchParallel {
    inner: Arc<VajraSearch>,
}

impl VajraSearchParallel {
    /// Create a new parallel search engine from a corpus.
    pub fn new(corpus: DocumentCorpus, params: BM25Params) -> Self {
        Self {
            inner: Arc::new(VajraSearch::new(corpus, params)),
        }
    }

    /// Create with default BM25 parameters.
    pub fn with_defaults(corpus: DocumentCorpus) -> Self {
        Self::new(corpus, BM25Params::default())
    }

    /// Create from an existing VajraSearch instance.
    pub fn from_engine(engine: VajraSearch) -> Self {
        Self {
            inner: Arc::new(engine),
        }
    }

    /// Execute a single search query.
    pub fn search(&self, query: impl Into<QueryState>, top_k: usize) -> Vec<SearchResult> {
        self.inner.search(query, top_k)
    }

    /// Execute multiple queries in parallel.
    ///
    /// Each query is processed independently, leveraging all available CPU cores.
    pub fn search_batch(&self, queries: &[&str], top_k: usize) -> Vec<Vec<SearchResult>> {
        queries
            .par_iter()
            .map(|&query| self.inner.search(query, top_k))
            .collect()
    }

    /// Execute multiple queries in parallel with QueryState.
    pub fn search_batch_states(
        &self,
        queries: Vec<QueryState>,
        top_k: usize,
    ) -> Vec<Vec<SearchResult>> {
        queries
            .into_par_iter()
            .map(|query| self.inner.search(query, top_k))
            .collect()
    }

    /// Get the number of documents in the corpus.
    pub fn num_documents(&self) -> usize {
        self.inner.num_documents()
    }

    /// Get the number of unique terms in the index.
    pub fn num_terms(&self) -> usize {
        self.inner.num_terms()
    }

    /// Get the BM25 parameters.
    pub fn params(&self) -> &BM25Params {
        self.inner.params()
    }

    /// Get a reference to the inner search engine.
    pub fn inner(&self) -> &VajraSearch {
        &self.inner
    }

    /// Get a clone of the Arc to share with other threads.
    pub fn share(&self) -> Arc<VajraSearch> {
        Arc::clone(&self.inner)
    }
}

impl Clone for VajraSearchParallel {
    fn clone(&self) -> Self {
        Self {
            inner: Arc::clone(&self.inner),
        }
    }
}

/// Configure the global thread pool size.
///
/// Should be called once at program startup if custom thread count is needed.
pub fn set_num_threads(n: usize) {
    rayon::ThreadPoolBuilder::new()
        .num_threads(n)
        .build_global()
        .ok(); // Ignore error if already initialized
}

/// Get the current number of threads in the global pool.
pub fn num_threads() -> usize {
    rayon::current_num_threads()
}

#[cfg(test)]
mod tests {
    use super::*;
    use vajra_ir::document::create_sample_corpus;

    #[test]
    fn test_parallel_search() {
        let corpus = create_sample_corpus();
        let engine = VajraSearchParallel::with_defaults(corpus);

        let results = engine.search("category theory", 3);
        assert!(!results.is_empty());
    }

    #[test]
    fn test_batch_search() {
        let corpus = create_sample_corpus();
        let engine = VajraSearchParallel::with_defaults(corpus);

        let queries = vec![
            "category theory",
            "functional programming",
            "search algorithms",
        ];
        let results = engine.search_batch(&queries, 3);

        assert_eq!(results.len(), 3);
        for result_set in &results {
            assert!(!result_set.is_empty());
        }
    }

    #[test]
    fn test_clone_shares_data() {
        let corpus = create_sample_corpus();
        let engine1 = VajraSearchParallel::with_defaults(corpus);
        let engine2 = engine1.clone();

        // Both should point to the same data
        assert_eq!(engine1.num_documents(), engine2.num_documents());
    }

    #[test]
    fn test_thread_count() {
        let count = num_threads();
        assert!(count > 0);
    }
}
