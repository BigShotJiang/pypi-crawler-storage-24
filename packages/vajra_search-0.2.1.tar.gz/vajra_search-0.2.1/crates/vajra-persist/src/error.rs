//! Error types for persistence operations

use thiserror::Error;

/// Errors that can occur during persistence operations.
#[derive(Error, Debug)]
pub enum PersistError {
    /// IO error during file operations.
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    /// JSON serialization/deserialization error.
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    /// Binary serialization error.
    #[error("Binary serialization error: {0}")]
    Bincode(#[from] bincode::Error),

    /// Invalid file format or version.
    #[error("Invalid format: {0}")]
    InvalidFormat(String),

    /// Version mismatch.
    #[error("Version mismatch: expected {expected}, got {actual}")]
    VersionMismatch { expected: u32, actual: u32 },
}
