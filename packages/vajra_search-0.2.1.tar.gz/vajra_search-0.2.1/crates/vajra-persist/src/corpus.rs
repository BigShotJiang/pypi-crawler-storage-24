//! Corpus serialization (JSONL format)
//!
//! JSONL (JSON Lines) format stores one document per line,
//! making it easy to stream and process large corpora.

use crate::Result;
use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::Path;
use vajra_ir::document::{Document, DocumentCorpus};

/// Save a corpus to a JSONL file.
///
/// Morphism: Corpus → File
///
/// Each document is serialized as a single JSON line.
pub fn save_corpus_jsonl(corpus: &DocumentCorpus, path: impl AsRef<Path>) -> Result<()> {
    let file = File::create(path)?;
    let mut writer = BufWriter::new(file);

    for doc in corpus.iter() {
        let json = serde_json::to_string(doc)?;
        writeln!(writer, "{}", json)?;
    }

    writer.flush()?;
    Ok(())
}

/// Load a corpus from a JSONL file.
///
/// Morphism: File → Corpus
///
/// Each line is parsed as a JSON document.
pub fn load_corpus_jsonl(path: impl AsRef<Path>) -> Result<DocumentCorpus> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);

    let mut documents = Vec::new();

    for line in reader.lines() {
        let line = line?;
        if line.trim().is_empty() {
            continue;
        }
        let doc: Document = serde_json::from_str(&line)?;
        documents.push(doc);
    }

    Ok(DocumentCorpus::from_documents(documents))
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn test_corpus_round_trip() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("corpus.jsonl");

        let corpus = DocumentCorpus::from_documents(vec![
            Document::new("1", "Title One", "Content one"),
            Document::new("2", "Title Two", "Content two"),
        ]);

        // Save
        save_corpus_jsonl(&corpus, &path).unwrap();

        // Load
        let loaded = load_corpus_jsonl(&path).unwrap();

        assert_eq!(loaded.len(), 2);
        assert_eq!(loaded.get("1").unwrap().title, "Title One");
        assert_eq!(loaded.get("2").unwrap().content, "Content two");
    }
}
