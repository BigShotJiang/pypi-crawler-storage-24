//! Index serialization
//!
//! Provides persistence for VajraSearch engines.

use crate::{PersistError, Result};
use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io::{BufReader, BufWriter, Write};
use std::path::Path;
use vajra_ir::document::DocumentCorpus;
use vajra_ir::search::VajraSearch;
use vajra_ir::BM25Params;

/// Current version of the index format.
const INDEX_VERSION: u32 = 1;

/// Index file format.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum IndexFormat {
    /// Compact JSON format (single line, smaller).
    #[default]
    Compact,
    /// Pretty JSON format (human-readable, larger).
    Pretty,
}

/// Serializable search engine state.
#[derive(Serialize, Deserialize)]
struct SerializableEngine {
    version: u32,
    params: BM25Params,
    corpus: SerializableCorpus,
}

/// Serializable corpus.
#[derive(Serialize, Deserialize)]
struct SerializableCorpus {
    documents: Vec<vajra_ir::document::Document>,
}

/// Save a VajraSearch engine to a file.
///
/// This saves the corpus and parameters, allowing the index to be rebuilt on load.
pub fn save_index(engine: &VajraSearch, path: impl AsRef<Path>, format: IndexFormat) -> Result<()> {
    let state = SerializableEngine {
        version: INDEX_VERSION,
        params: *engine.params(),
        corpus: SerializableCorpus {
            documents: engine.corpus().iter().cloned().collect(),
        },
    };

    let file = File::create(path)?;
    let mut writer = BufWriter::new(file);

    match format {
        IndexFormat::Compact => {
            serde_json::to_writer(&mut writer, &state)?;
        }
        IndexFormat::Pretty => {
            serde_json::to_writer_pretty(&mut writer, &state)?;
        }
    }

    writer.flush()?;
    Ok(())
}

/// Load a VajraSearch engine from a JSON file.
pub fn load_index_json(path: impl AsRef<Path>) -> Result<VajraSearch> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let state: SerializableEngine = serde_json::from_reader(reader)?;

    if state.version != INDEX_VERSION {
        return Err(PersistError::VersionMismatch {
            expected: INDEX_VERSION,
            actual: state.version,
        });
    }

    let corpus = DocumentCorpus::from_documents(state.corpus.documents);
    let engine = VajraSearch::new(corpus, state.params);

    Ok(engine)
}

/// Load a VajraSearch engine from a file.
///
/// Alias for `load_index_json`.
pub fn load_index(path: impl AsRef<Path>) -> Result<VajraSearch> {
    load_index_json(path)
}

/// Alias for backward compatibility.
pub fn load_index_binary(path: impl AsRef<Path>) -> Result<VajraSearch> {
    load_index_json(path)
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;
    use vajra_ir::document::create_sample_corpus;

    #[test]
    fn test_compact_round_trip() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("index.json");

        let corpus = create_sample_corpus();
        let engine = VajraSearch::with_defaults(corpus);

        // Save
        save_index(&engine, &path, IndexFormat::Compact).unwrap();

        // Load
        let loaded = load_index(&path).unwrap();

        assert_eq!(loaded.num_documents(), engine.num_documents());

        // Test search still works
        let results = loaded.search("category theory", 3);
        assert!(!results.is_empty());
    }

    #[test]
    fn test_pretty_round_trip() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("index.json");

        let corpus = create_sample_corpus();
        let engine = VajraSearch::new(corpus, BM25Params::new(1.2, 0.8));

        // Save
        save_index(&engine, &path, IndexFormat::Pretty).unwrap();

        // Load
        let loaded = load_index(&path).unwrap();

        assert_eq!(loaded.num_documents(), engine.num_documents());
        assert!((loaded.params().k1 - 1.2).abs() < f32::EPSILON);
        assert!((loaded.params().b - 0.8).abs() < f32::EPSILON);
    }
}
