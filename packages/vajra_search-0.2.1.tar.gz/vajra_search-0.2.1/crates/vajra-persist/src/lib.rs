//! # Vajra Persist - Serialization
//!
//! Serialization for Vajra indices and corpora.
//!
//! ## Features
//!
//! - JSONL corpus I/O (human-readable, line-by-line)
//! - Binary index serialization (fast, compact)
//! - Versioned format for backward compatibility

mod corpus;
mod error;
mod index;

pub use corpus::{load_corpus_jsonl, save_corpus_jsonl};
pub use error::PersistError;
pub use index::{load_index, load_index_binary, load_index_json, save_index, IndexFormat};

/// Result type for persistence operations.
pub type Result<T> = std::result::Result<T, PersistError>;
