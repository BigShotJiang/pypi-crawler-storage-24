//! Document model
//!
//! Documents are objects in our category.
//! They are immutable and uniquely identified by ID.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::hash::{Hash, Hasher};

/// A document object.
///
/// Immutable because documents are objects in a category.
/// Identity is preserved through transformations.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Document {
    /// Unique document identifier
    pub id: String,
    /// Document title
    pub title: String,
    /// Document content
    pub content: String,
    /// Optional metadata
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub metadata: Option<HashMap<String, String>>,
}

impl Document {
    /// Create a new document.
    pub fn new(
        id: impl Into<String>,
        title: impl Into<String>,
        content: impl Into<String>,
    ) -> Self {
        Self {
            id: id.into(),
            title: title.into(),
            content: content.into(),
            metadata: None,
        }
    }

    /// Create a document with metadata.
    pub fn with_metadata(
        id: impl Into<String>,
        title: impl Into<String>,
        content: impl Into<String>,
        metadata: HashMap<String, String>,
    ) -> Self {
        Self {
            id: id.into(),
            title: title.into(),
            content: content.into(),
            metadata: Some(metadata),
        }
    }

    /// Get the full text of the document (title + content).
    pub fn full_text(&self) -> String {
        format!("{} {}", self.title, self.content)
    }
}

impl PartialEq for Document {
    fn eq(&self, other: &Self) -> bool {
        self.id == other.id
    }
}

impl Eq for Document {}

impl Hash for Document {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.id.hash(state);
    }
}

/// A corpus of documents.
///
/// Provides efficient ID-based lookup and iteration.
#[derive(Debug, Clone, Default)]
pub struct DocumentCorpus {
    documents: Vec<Document>,
    id_to_idx: HashMap<String, usize>,
}

impl DocumentCorpus {
    /// Create an empty corpus.
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a corpus from a list of documents.
    pub fn from_documents(documents: Vec<Document>) -> Self {
        let id_to_idx = documents
            .iter()
            .enumerate()
            .map(|(idx, doc)| (doc.id.clone(), idx))
            .collect();

        Self {
            documents,
            id_to_idx,
        }
    }

    /// Add a document to the corpus.
    pub fn add(&mut self, doc: Document) {
        let idx = self.documents.len();
        self.id_to_idx.insert(doc.id.clone(), idx);
        self.documents.push(doc);
    }

    /// Get a document by ID.
    pub fn get(&self, doc_id: &str) -> Option<&Document> {
        self.id_to_idx.get(doc_id).map(|&idx| &self.documents[idx])
    }

    /// Get a document by index.
    pub fn get_by_index(&self, idx: usize) -> Option<&Document> {
        self.documents.get(idx)
    }

    /// Get the index for a document ID.
    pub fn get_index(&self, doc_id: &str) -> Option<usize> {
        self.id_to_idx.get(doc_id).copied()
    }

    /// Get the document ID for an index.
    pub fn get_id(&self, idx: usize) -> Option<&str> {
        self.documents.get(idx).map(|doc| doc.id.as_str())
    }

    /// Number of documents in the corpus.
    pub fn len(&self) -> usize {
        self.documents.len()
    }

    /// Check if the corpus is empty.
    pub fn is_empty(&self) -> bool {
        self.documents.is_empty()
    }

    /// Iterate over all documents.
    pub fn iter(&self) -> impl Iterator<Item = &Document> {
        self.documents.iter()
    }

    /// Get all document IDs.
    pub fn doc_ids(&self) -> impl Iterator<Item = &str> {
        self.documents.iter().map(|doc| doc.id.as_str())
    }
}

impl<'a> IntoIterator for &'a DocumentCorpus {
    type Item = &'a Document;
    type IntoIter = std::slice::Iter<'a, Document>;

    fn into_iter(self) -> Self::IntoIter {
        self.documents.iter()
    }
}

impl IntoIterator for DocumentCorpus {
    type Item = Document;
    type IntoIter = std::vec::IntoIter<Document>;

    fn into_iter(self) -> Self::IntoIter {
        self.documents.into_iter()
    }
}

impl FromIterator<Document> for DocumentCorpus {
    fn from_iter<T: IntoIterator<Item = Document>>(iter: T) -> Self {
        let documents: Vec<Document> = iter.into_iter().collect();
        Self::from_documents(documents)
    }
}

/// Create a sample corpus for demonstration.
///
/// Topics: Category theory, functional programming, search algorithms
pub fn create_sample_corpus() -> DocumentCorpus {
    let documents = vec![
        Document::new(
            "doc1",
            "Introduction to Category Theory",
            "Category theory is a general theory of mathematical structures and their relations. \
             It provides a unifying framework for mathematics. Categories consist of objects and morphisms. \
             Morphisms are structure-preserving maps between objects. Composition of morphisms is associative. \
             Every object has an identity morphism. Functors map between categories preserving structure.",
        ),
        Document::new(
            "doc2",
            "Functors and Natural Transformations",
            "Functors are structure-preserving maps between categories. A functor F maps objects to objects \
             and morphisms to morphisms. Natural transformations provide morphisms between functors. \
             They satisfy a naturality condition. Examples include the list functor and maybe functor. \
             Functors preserve composition and identities.",
        ),
        Document::new(
            "doc3",
            "Coalgebras and Dynamics",
            "Coalgebras capture generative or productive processes. A coalgebra consists of a carrier \
             and a structure map from the carrier to a functor applied to the carrier. Unlike algebras which \
             fold or consume, coalgebras unfold or produce. They are perfect for modeling dynamics, streams, \
             and transition systems. The structure map determines how states evolve.",
        ),
        Document::new(
            "doc4",
            "Functional Programming Basics",
            "Functional programming emphasizes pure functions and immutable data structures. \
             Functions are first-class citizens. Higher-order functions accept functions as arguments. \
             Map, filter, and reduce are fundamental operations. Recursion replaces iteration. \
             Functional programming draws heavily from lambda calculus and category theory.",
        ),
        Document::new(
            "doc5",
            "Monads in Programming",
            "Monads are a design pattern from category theory used in functional programming. \
             A monad wraps values with context. The Maybe monad handles nullable values. \
             The List monad represents nondeterminism. The State monad encapsulates stateful computation. \
             Monads have unit and bind operations satisfying monad laws.",
        ),
        Document::new(
            "doc6",
            "Breadth-First Search Algorithm",
            "BFS explores a graph level by level. It uses a queue data structure. \
             BFS finds shortest paths in unweighted graphs. Time complexity is O(V + E). \
             Applications include web crawling, social networks, and GPS navigation. \
             BFS is complete and optimal for unweighted graphs.",
        ),
        Document::new(
            "doc7",
            "Depth-First Search Algorithm",
            "DFS explores as far as possible along each branch before backtracking. \
             It uses a stack data structure or recursion. DFS is used for topological sorting, \
             cycle detection, and maze solving. Time complexity is O(V + E). \
             DFS is not guaranteed to find shortest paths.",
        ),
        Document::new(
            "doc8",
            "Advanced Search Techniques",
            "Modern search algorithms combine multiple techniques. A* search uses heuristics \
             for efficient pathfinding. Iterative deepening combines BFS and DFS benefits. \
             Bidirectional search starts from both ends. Best-first search uses priority queues. \
             These algorithms are used in AI, robotics, and game development.",
        ),
        Document::new(
            "doc9",
            "Lambda Calculus Foundations",
            "Lambda calculus is a formal system for expressing computation through function \
             abstraction and application. It consists of variables, abstraction, and application. \
             Church encoding represents data as functions. Lambda calculus is Turing complete. \
             It forms the theoretical basis for functional programming languages.",
        ),
        Document::new(
            "doc10",
            "Category Theory Applications",
            "Category theory has applications in computer science, physics, and linguistics. \
             In programming, it provides abstractions like functors and monads. In database theory, \
             it models schemas and queries. In quantum mechanics, it describes quantum processes. \
             Type theory and category theory are deeply connected. Categorical logic provides \
             foundations for constructive mathematics.",
        ),
    ];

    DocumentCorpus::from_documents(documents)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_document_creation() {
        let doc = Document::new("1", "Title", "Content");
        assert_eq!(doc.id, "1");
        assert_eq!(doc.title, "Title");
        assert_eq!(doc.content, "Content");
        assert!(doc.metadata.is_none());
    }

    #[test]
    fn test_document_full_text() {
        let doc = Document::new("1", "Title", "Content");
        assert_eq!(doc.full_text(), "Title Content");
    }

    #[test]
    fn test_corpus_operations() {
        let mut corpus = DocumentCorpus::new();
        corpus.add(Document::new("1", "First", "Content 1"));
        corpus.add(Document::new("2", "Second", "Content 2"));

        assert_eq!(corpus.len(), 2);
        assert_eq!(corpus.get("1").unwrap().title, "First");
        assert_eq!(corpus.get("2").unwrap().title, "Second");
        assert!(corpus.get("3").is_none());
    }

    #[test]
    fn test_corpus_iteration() {
        let corpus = DocumentCorpus::from_documents(vec![
            Document::new("1", "First", ""),
            Document::new("2", "Second", ""),
        ]);

        let ids: Vec<&str> = corpus.doc_ids().collect();
        assert_eq!(ids, vec!["1", "2"]);
    }

    #[test]
    fn test_sample_corpus() {
        let corpus = create_sample_corpus();
        assert_eq!(corpus.len(), 10);
        assert!(corpus.get("doc1").is_some());
        assert!(corpus.get("doc10").is_some());
    }
}
