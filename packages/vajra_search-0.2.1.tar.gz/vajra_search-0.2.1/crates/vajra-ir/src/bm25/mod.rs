//! BM25 Ranking Algorithm
//!
//! BM25 is a morphism: (Query, Document) → ℝ
//!
//! It's a probabilistic relevance function that scores documents
//! given a query. The score is a composition of term-level scores.
//!
//! Categorical structure:
//! - BM25: (Q, D) → ℝ is a morphism to the reals
//! - For fixed Q: D → ℝ is a morphism (curried form)
//! - This morphism induces a ranking (total order on documents)

mod params;
mod scorer;

pub use params::BM25Params;
pub use scorer::BM25Scorer;
