//! BM25 hyperparameters

use serde::{Deserialize, Serialize};

/// BM25 hyperparameters.
///
/// These control the functional form of the scoring morphism.
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct BM25Params {
    /// Term frequency saturation parameter (default: 1.5).
    ///
    /// Higher values increase the impact of term frequency.
    pub k1: f32,

    /// Length normalization parameter (default: 0.75).
    ///
    /// - b = 0: No length normalization
    /// - b = 1: Full length normalization
    pub b: f32,
}

impl BM25Params {
    /// Create new BM25 parameters.
    pub fn new(k1: f32, b: f32) -> Self {
        Self { k1, b }
    }

    /// Create parameters optimized for short documents (titles, abstracts).
    pub fn for_short_docs() -> Self {
        Self { k1: 1.2, b: 0.5 }
    }

    /// Create parameters optimized for long documents (full articles).
    pub fn for_long_docs() -> Self {
        Self { k1: 2.0, b: 0.75 }
    }
}

impl Default for BM25Params {
    fn default() -> Self {
        Self { k1: 1.5, b: 0.75 }
    }
}

impl std::fmt::Display for BM25Params {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "BM25(k1={}, b={})", self.k1, self.b)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_params() {
        let params = BM25Params::default();
        assert!((params.k1 - 1.5).abs() < f32::EPSILON);
        assert!((params.b - 0.75).abs() < f32::EPSILON);
    }

    #[test]
    fn test_display() {
        let params = BM25Params::default();
        assert_eq!(format!("{}", params), "BM25(k1=1.5, b=0.75)");
    }
}
