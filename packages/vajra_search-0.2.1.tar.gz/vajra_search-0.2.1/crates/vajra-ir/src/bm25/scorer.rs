//! BM25 scoring function

use super::BM25Params;
use crate::index::InvertedIndex;
use std::collections::HashMap;

/// BM25 scoring function.
///
/// This is a categorical morphism:
/// BM25: Query × Document → ℝ
///
/// For a fixed query, this becomes:
/// score: Document → ℝ
///
/// This morphism defines a total order on documents (ranking).
pub struct BM25Scorer<'a> {
    index: &'a InvertedIndex,
    params: BM25Params,
}

impl<'a> BM25Scorer<'a> {
    /// Create a new BM25 scorer.
    pub fn new(index: &'a InvertedIndex, params: BM25Params) -> Self {
        Self { index, params }
    }

    /// Create a scorer with default parameters.
    pub fn with_defaults(index: &'a InvertedIndex) -> Self {
        Self::new(index, BM25Params::default())
    }

    /// Compute BM25 score for a document given query terms.
    ///
    /// BM25(q, d) = Σ IDF(qi) × (f(qi, d) × (k1 + 1)) / (f(qi, d) + k1 × (1 - b + b × |d|/avgdl))
    ///
    /// where:
    /// - IDF(qi) = inverse document frequency of term qi
    /// - f(qi, d) = frequency of qi in document d
    /// - |d| = length of document d
    /// - avgdl = average document length in corpus
    /// - k1, b = tuning parameters
    ///
    /// This is a morphism: (Query, Document) → ℝ
    #[inline]
    pub fn score(&self, query_terms: &[String], doc_idx: usize) -> f32 {
        let doc_length = self.index.doc_length(doc_idx) as f32;
        if doc_length == 0.0 {
            return 0.0;
        }

        let avg_doc_length = self.index.avg_doc_length();

        // Pre-compute length normalization factor
        let norm_factor = 1.0 - self.params.b + self.params.b * (doc_length / avg_doc_length);

        let mut score = 0.0;

        for term in query_terms {
            // Get IDF for term
            let idf = self.index.idf(term);
            if idf == 0.0 {
                continue;
            }

            // Get term frequency in document
            let tf = self.index.get_term_frequency(term, doc_idx) as f32;
            if tf == 0.0 {
                continue;
            }

            // BM25 formula
            let term_score =
                idf * (tf * (self.params.k1 + 1.0)) / (tf + self.params.k1 * norm_factor);
            score += term_score;
        }

        score
    }

    /// Rank a list of document indices by BM25 score.
    ///
    /// Returns: Vec<(doc_idx, score)> sorted by score descending.
    ///
    /// This is applying the morphism D → ℝ to induce a ranking.
    pub fn rank_documents(
        &self,
        query_terms: &[String],
        doc_indices: &[usize],
    ) -> Vec<(usize, f32)> {
        let mut scored: Vec<(usize, f32)> = doc_indices
            .iter()
            .map(|&doc_idx| (doc_idx, self.score(query_terms, doc_idx)))
            .collect();

        // Sort by score (descending)
        scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        scored
    }

    /// Get top-k documents by score.
    ///
    /// Uses partial sort for efficiency when k << n.
    pub fn top_k(
        &self,
        query_terms: &[String],
        doc_indices: &[usize],
        k: usize,
    ) -> Vec<(usize, f32)> {
        if k >= doc_indices.len() {
            return self.rank_documents(query_terms, doc_indices);
        }

        // Score all documents
        let mut scored: Vec<(usize, f32)> = doc_indices
            .iter()
            .map(|&doc_idx| (doc_idx, self.score(query_terms, doc_idx)))
            .collect();

        // Partial sort to get top k
        scored.select_nth_unstable_by(k - 1, |a, b| {
            b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal)
        });

        // Sort the top k
        let mut top = scored[..k].to_vec();
        top.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        top
    }

    /// Break down the BM25 score by term.
    ///
    /// Useful for understanding which terms contribute most.
    pub fn explain_score(&self, query_terms: &[String], doc_idx: usize) -> HashMap<String, f32> {
        let doc_length = self.index.doc_length(doc_idx) as f32;
        let avg_doc_length = self.index.avg_doc_length();
        let norm_factor = 1.0 - self.params.b + self.params.b * (doc_length / avg_doc_length);

        let mut term_scores = HashMap::new();

        for term in query_terms {
            let idf = self.index.idf(term);
            let tf = self.index.get_term_frequency(term, doc_idx) as f32;

            let term_score = if tf > 0.0 && idf > 0.0 {
                idf * (tf * (self.params.k1 + 1.0)) / (tf + self.params.k1 * norm_factor)
            } else {
                0.0
            };

            term_scores.insert(term.clone(), term_score);
        }

        term_scores
    }

    /// Get the parameters being used.
    pub fn params(&self) -> &BM25Params {
        &self.params
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::document::{create_sample_corpus, Document, DocumentCorpus};
    use crate::index::InvertedIndex;
    use crate::text::preprocess_text;

    #[test]
    fn test_scorer_basic() {
        let corpus = create_sample_corpus();
        let index = InvertedIndex::build(&corpus);
        let scorer = BM25Scorer::with_defaults(&index);

        let query_terms = preprocess_text("category theory");

        // Document 0 ("Introduction to Category Theory") should score well
        let score = scorer.score(&query_terms, 0);
        assert!(score > 0.0);
    }

    #[test]
    fn test_ranking() {
        let corpus = create_sample_corpus();
        let index = InvertedIndex::build(&corpus);
        let scorer = BM25Scorer::with_defaults(&index);

        let query_terms = preprocess_text("category theory functors");
        let candidates: Vec<usize> = index
            .get_candidate_documents(&query_terms)
            .into_iter()
            .collect();

        let ranked = scorer.rank_documents(&query_terms, &candidates);

        // Should be sorted by score descending
        for i in 1..ranked.len() {
            assert!(ranked[i - 1].1 >= ranked[i].1);
        }
    }

    #[test]
    fn test_top_k() {
        let corpus = create_sample_corpus();
        let index = InvertedIndex::build(&corpus);
        let scorer = BM25Scorer::with_defaults(&index);

        let query_terms = preprocess_text("category theory");
        let candidates: Vec<usize> = index
            .get_candidate_documents(&query_terms)
            .into_iter()
            .collect();

        let top_3 = scorer.top_k(&query_terms, &candidates, 3);

        assert!(top_3.len() <= 3);
        // Should be sorted
        for i in 1..top_3.len() {
            assert!(top_3[i - 1].1 >= top_3[i].1);
        }
    }

    #[test]
    fn test_explain_score() {
        let corpus = DocumentCorpus::from_documents(vec![Document::new(
            "1",
            "Category Theory",
            "Morphisms and functors in category theory",
        )]);
        let index = InvertedIndex::build(&corpus);
        let scorer = BM25Scorer::with_defaults(&index);

        let query_terms = preprocess_text("category functors");
        let explanation = scorer.explain_score(&query_terms, 0);

        // Both terms should contribute
        assert!(explanation.get("category").unwrap_or(&0.0) > &0.0);
        assert!(explanation.get("functors").unwrap_or(&0.0) > &0.0);
    }

    #[test]
    fn test_zero_score_for_empty_doc() {
        let corpus = DocumentCorpus::from_documents(vec![Document::new("1", "", "")]);
        let index = InvertedIndex::build(&corpus);
        let scorer = BM25Scorer::with_defaults(&index);

        let query_terms = preprocess_text("category theory");
        let score = scorer.score(&query_terms, 0);

        assert!((score - 0.0).abs() < f32::EPSILON);
    }
}
