//! VajraSearch engine implementation

use super::{QueryState, SearchResult};
use crate::bm25::{BM25Params, BM25Scorer};
use crate::document::DocumentCorpus;
use crate::index::InvertedIndex;
use std::collections::HashMap;
use vajra_core::coalgebra::Coalgebra;

/// BM25 Search Coalgebra
///
/// Structure map: QueryState → Vec<SearchResult>
///
/// This is the categorical essence of search.
pub struct BM25SearchCoalgebra<'a> {
    index: &'a InvertedIndex,
    corpus: &'a DocumentCorpus,
    params: BM25Params,
}

impl<'a> BM25SearchCoalgebra<'a> {
    /// Create a new search coalgebra.
    pub fn new(index: &'a InvertedIndex, corpus: &'a DocumentCorpus, params: BM25Params) -> Self {
        Self {
            index,
            corpus,
            params,
        }
    }
}

impl<'a> Coalgebra<QueryState, Vec<SearchResult>> for BM25SearchCoalgebra<'a> {
    fn structure_map(&self, state: &QueryState) -> Vec<SearchResult> {
        if state.is_empty() {
            return vec![];
        }

        let scorer = BM25Scorer::new(self.index, self.params);

        // Get candidate documents
        let candidates: Vec<usize> = self
            .index
            .get_candidate_documents(&state.terms)
            .into_iter()
            .collect();

        // Score and rank
        let ranked = scorer.rank_documents(&state.terms, &candidates);

        // Build results
        ranked
            .into_iter()
            .enumerate()
            .filter_map(|(rank, (doc_idx, score))| {
                self.corpus
                    .get_by_index(doc_idx)
                    .map(|doc| SearchResult::new(doc.clone(), score, rank))
            })
            .collect()
    }
}

/// Vajra Search Engine
///
/// The main search interface wrapping the categorical coalgebra.
pub struct VajraSearch {
    corpus: DocumentCorpus,
    index: InvertedIndex,
    params: BM25Params,
}

impl VajraSearch {
    /// Create a new search engine from a corpus.
    pub fn new(corpus: DocumentCorpus, params: BM25Params) -> Self {
        let index = InvertedIndex::build(&corpus);
        Self {
            corpus,
            index,
            params,
        }
    }

    /// Create with default BM25 parameters.
    pub fn with_defaults(corpus: DocumentCorpus) -> Self {
        Self::new(corpus, BM25Params::default())
    }

    /// Search for documents matching a query.
    ///
    /// Returns results sorted by relevance (BM25 score).
    pub fn search(&self, query: impl Into<QueryState>, top_k: usize) -> Vec<SearchResult> {
        let state = query.into();
        if state.is_empty() {
            return vec![];
        }
        if top_k == 0 {
            return vec![];
        }

        let scorer = BM25Scorer::new(&self.index, self.params);
        let candidates: Vec<usize> = self
            .index
            .get_candidate_documents(&state.terms)
            .into_iter()
            .collect();
        let ranked = scorer.top_k(&state.terms, &candidates, top_k);

        ranked
            .into_iter()
            .enumerate()
            .filter_map(|(rank, (doc_idx, score))| {
                self.corpus
                    .get_by_index(doc_idx)
                    .map(|doc| SearchResult::new(doc.clone(), score, rank))
            })
            .collect()
    }

    /// Search with score explanation.
    ///
    /// Returns results with per-term score breakdown.
    pub fn search_with_explanation(
        &self,
        query: impl Into<QueryState>,
        top_k: usize,
    ) -> Vec<(SearchResult, HashMap<String, f32>)> {
        let state = query.into();
        if state.is_empty() {
            return vec![];
        }

        let scorer = BM25Scorer::new(&self.index, self.params);

        // Get candidate documents
        let candidates: Vec<usize> = self
            .index
            .get_candidate_documents(&state.terms)
            .into_iter()
            .collect();

        // Score and rank
        let ranked = scorer.top_k(&state.terms, &candidates, top_k);

        // Build results with explanations
        ranked
            .into_iter()
            .enumerate()
            .filter_map(|(rank, (doc_idx, score))| {
                self.corpus.get_by_index(doc_idx).map(|doc| {
                    let explanation = scorer.explain_score(&state.terms, doc_idx);
                    (SearchResult::new(doc.clone(), score, rank), explanation)
                })
            })
            .collect()
    }

    /// Get a document by ID.
    pub fn get_document(&self, doc_id: &str) -> Option<&crate::document::Document> {
        self.corpus.get(doc_id)
    }

    /// Get the number of documents in the corpus.
    pub fn num_documents(&self) -> usize {
        self.corpus.len()
    }

    /// Get the number of unique terms in the index.
    pub fn num_terms(&self) -> usize {
        self.index.num_terms()
    }

    /// Get the BM25 parameters.
    pub fn params(&self) -> &BM25Params {
        &self.params
    }

    /// Get a reference to the corpus.
    pub fn corpus(&self) -> &DocumentCorpus {
        &self.corpus
    }

    /// Get a reference to the index.
    pub fn index(&self) -> &InvertedIndex {
        &self.index
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::document::create_sample_corpus;

    #[test]
    fn test_basic_search() {
        let corpus = create_sample_corpus();
        let engine = VajraSearch::with_defaults(corpus);

        let results = engine.search("category theory", 5);

        assert!(!results.is_empty());
        // Results should be sorted by score
        for i in 1..results.len() {
            assert!(results[i - 1].score >= results[i].score);
        }
    }

    #[test]
    fn test_search_functors() {
        let corpus = create_sample_corpus();
        let engine = VajraSearch::with_defaults(corpus);

        let results = engine.search("functors morphisms", 3);

        assert!(!results.is_empty());
        // Should find documents about functors
        let titles: Vec<&str> = results.iter().map(|r| r.title()).collect();
        assert!(titles
            .iter()
            .any(|t| t.contains("Functor") || t.contains("Category")));
    }

    #[test]
    fn test_empty_query() {
        let corpus = create_sample_corpus();
        let engine = VajraSearch::with_defaults(corpus);

        let results = engine.search("the and", 5);
        assert!(results.is_empty());
    }

    #[test]
    fn test_search_with_explanation() {
        let corpus = create_sample_corpus();
        let engine = VajraSearch::with_defaults(corpus);

        let results = engine.search_with_explanation("category theory", 3);

        assert!(!results.is_empty());
        for (result, explanation) in &results {
            // Each query term should have an explanation
            assert!(!explanation.is_empty());
            // Score should be positive for matching docs
            assert!(result.score > 0.0);
        }
    }

    #[test]
    fn test_coalgebra_structure() {
        let corpus = create_sample_corpus();
        let engine = VajraSearch::with_defaults(corpus);

        // Test that coalgebra produces expected structure
        let coalgebra = BM25SearchCoalgebra::new(engine.index(), engine.corpus(), *engine.params());
        let state = QueryState::new("search algorithms");

        let results = coalgebra.structure_map(&state);

        // Should find documents about search
        assert!(!results.is_empty());
    }

    #[test]
    fn test_engine_stats() {
        let corpus = create_sample_corpus();
        let engine = VajraSearch::with_defaults(corpus);

        assert_eq!(engine.num_documents(), 10);
        assert!(engine.num_terms() > 0);
    }
}
