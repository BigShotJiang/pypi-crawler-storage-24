//! Search result representation

use crate::document::Document;

/// A search result with document, score, and rank.
#[derive(Debug, Clone)]
pub struct SearchResult {
    /// The matched document.
    pub document: Document,
    /// BM25 relevance score.
    pub score: f32,
    /// Rank in the result set (0-indexed).
    pub rank: usize,
}

impl SearchResult {
    /// Create a new search result.
    pub fn new(document: Document, score: f32, rank: usize) -> Self {
        Self {
            document,
            score,
            rank,
        }
    }

    /// Get the document ID.
    pub fn doc_id(&self) -> &str {
        &self.document.id
    }

    /// Get the document title.
    pub fn title(&self) -> &str {
        &self.document.title
    }
}

impl std::fmt::Display for SearchResult {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "#{} [{}] {} (score: {:.3})",
            self.rank + 1,
            self.document.id,
            self.document.title,
            self.score
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_search_result() {
        let doc = Document::new("1", "Test Title", "Content");
        let result = SearchResult::new(doc, 2.5, 0);

        assert_eq!(result.doc_id(), "1");
        assert_eq!(result.title(), "Test Title");
        assert_eq!(result.rank, 0);
        assert!((result.score - 2.5).abs() < f32::EPSILON);
    }

    #[test]
    fn test_display() {
        let doc = Document::new("1", "Test Title", "Content");
        let result = SearchResult::new(doc, 2.5, 0);

        let display = format!("{}", result);
        assert!(display.contains("Test Title"));
        assert!(display.contains("2.500"));
    }
}
