//! Query state representation

use crate::text::preprocess_text;

/// Query state - an object in the query category.
///
/// Represents a search query with its preprocessed terms.
#[derive(Debug, Clone)]
pub struct QueryState {
    /// Original query string.
    pub query: String,
    /// Preprocessed query terms.
    pub terms: Vec<String>,
}

impl QueryState {
    /// Create a new query state from a query string.
    pub fn new(query: impl Into<String>) -> Self {
        let query = query.into();
        let terms = preprocess_text(&query);
        Self { query, terms }
    }

    /// Create from pre-computed terms.
    pub fn from_terms(query: impl Into<String>, terms: Vec<String>) -> Self {
        Self {
            query: query.into(),
            terms,
        }
    }

    /// Check if the query is empty (no meaningful terms after preprocessing).
    pub fn is_empty(&self) -> bool {
        self.terms.is_empty()
    }

    /// Get the number of query terms.
    pub fn num_terms(&self) -> usize {
        self.terms.len()
    }
}

impl From<&str> for QueryState {
    fn from(query: &str) -> Self {
        Self::new(query)
    }
}

impl From<String> for QueryState {
    fn from(query: String) -> Self {
        Self::new(query)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_query_state() {
        let query = QueryState::new("category theory functors");
        assert_eq!(query.query, "category theory functors");
        // Stop words removed
        assert!(query.terms.contains(&"category".to_string()));
        assert!(query.terms.contains(&"theory".to_string()));
        assert!(query.terms.contains(&"functors".to_string()));
    }

    #[test]
    fn test_empty_query() {
        let query = QueryState::new("the and");
        // All stop words removed
        assert!(query.is_empty());
    }

    #[test]
    fn test_from_str() {
        let query: QueryState = "test query".into();
        assert_eq!(query.query, "test query");
    }
}
