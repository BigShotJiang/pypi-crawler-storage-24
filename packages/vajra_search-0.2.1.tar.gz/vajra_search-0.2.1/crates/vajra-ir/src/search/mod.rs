//! Search engine and coalgebra
//!
//! The search engine is modeled as a categorical coalgebra:
//! - QueryState: Objects in the query category
//! - Structure map: QueryState → List[SearchResult]
//! - BM25: The scoring morphism

mod engine;
mod query;
mod result;

pub use engine::VajraSearch;
pub use query::QueryState;
pub use result::SearchResult;
