//! Inverted Index
//!
//! An inverted index is a categorical structure:
//! - Maps terms to sets of documents
//! - Functor-like: preserves document relationships through term mappings
//! - Efficient morphism from query terms to candidate documents

mod posting;

pub use posting::{InvertedIndex, PostingList};
