//! Posting lists and inverted index implementation

use crate::document::DocumentCorpus;
use crate::text::preprocess_text;
use rustc_hash::{FxHashMap, FxHashSet};

/// Documents containing a term, with frequency information.
///
/// This is the image of a term under the index morphism.
#[derive(Debug, Clone, Default)]
pub struct PostingList {
    /// Term frequency in each document (doc_idx -> count).
    pub doc_frequencies: FxHashMap<usize, u32>,
    /// Precomputed BM25 IDF for this term.
    pub idf: f32,
}

impl PostingList {
    /// Create an empty posting list.
    pub fn new() -> Self {
        Self::default()
    }

    /// Number of documents containing this term.
    pub fn len(&self) -> usize {
        self.doc_frequencies.len()
    }

    /// Check if the posting list is empty.
    pub fn is_empty(&self) -> bool {
        self.doc_frequencies.is_empty()
    }

    /// Add a document to the posting list.
    pub fn add(&mut self, doc_idx: usize, frequency: u32) {
        self.doc_frequencies.insert(doc_idx, frequency);
    }

    /// Get the term frequency for a document.
    pub fn get_frequency(&self, doc_idx: usize) -> u32 {
        self.doc_frequencies.get(&doc_idx).copied().unwrap_or(0)
    }
}

/// Inverted index: Term → PostingList
///
/// Categorical interpretation:
/// - A structure-preserving map from terms to document sets
/// - Enables efficient "unfolding" of queries into candidate documents
#[derive(Debug, Clone)]
pub struct InvertedIndex {
    /// Term to posting list mapping.
    index: FxHashMap<String, PostingList>,
    /// Document lengths (in terms).
    doc_lengths: Vec<u32>,
    /// Average document length.
    avg_doc_length: f32,
    /// Number of documents.
    num_docs: usize,
}

impl InvertedIndex {
    /// Create an empty index.
    pub fn new() -> Self {
        Self {
            index: FxHashMap::default(),
            doc_lengths: Vec::new(),
            avg_doc_length: 0.0,
            num_docs: 0,
        }
    }

    /// Build index from corpus.
    ///
    /// Morphism: Corpus → Index
    pub fn build(corpus: &DocumentCorpus) -> Self {
        let mut index: FxHashMap<String, PostingList> = FxHashMap::default();
        let mut doc_lengths = Vec::with_capacity(corpus.len());
        let mut total_length: u64 = 0;
        let num_docs = corpus.len();

        // Process each document
        for (doc_idx, doc) in corpus.iter().enumerate() {
            // Preprocess document text (title + content)
            let terms = preprocess_text(&doc.full_text());

            // Store document length
            let doc_length = terms.len() as u32;
            doc_lengths.push(doc_length);
            total_length += doc_length as u64;

            // Count term frequencies
            let mut term_counts: FxHashMap<&str, u32> = FxHashMap::default();
            for term in &terms {
                *term_counts.entry(term.as_str()).or_insert(0) += 1;
            }

            // Add to inverted index
            for (term, count) in term_counts {
                index
                    .entry(term.to_string())
                    .or_insert_with(PostingList::new)
                    .add(doc_idx, count);
            }
        }

        // Calculate average document length
        let avg_doc_length = if num_docs > 0 {
            total_length as f32 / num_docs as f32
        } else {
            0.0
        };

        // Pre-compute IDF values and store them in posting lists directly.
        for posting_list in index.values_mut() {
            let df = posting_list.len() as f32;
            let n = num_docs as f32;
            // BM25 IDF formula: log((N - df + 0.5) / (df + 0.5) + 1)
            let idf = ((n - df + 0.5) / (df + 0.5) + 1.0).ln();
            posting_list.idf = idf;
        }

        Self {
            index,
            doc_lengths,
            avg_doc_length,
            num_docs,
        }
    }

    /// Get posting list for a term.
    pub fn get_posting_list(&self, term: &str) -> Option<&PostingList> {
        self.index.get(term)
    }

    /// Get term frequency in a document.
    pub fn get_term_frequency(&self, term: &str, doc_idx: usize) -> u32 {
        self.index
            .get(term)
            .map(|pl| pl.get_frequency(doc_idx))
            .unwrap_or(0)
    }

    /// Get document frequency for a term.
    pub fn get_document_frequency(&self, term: &str) -> usize {
        self.index.get(term).map(|pl| pl.len()).unwrap_or(0)
    }

    /// Get candidate documents containing any query term.
    ///
    /// This is the coalgebraic unfolding: Query → Set<DocIdx>
    pub fn get_candidate_documents(&self, query_terms: &[String]) -> FxHashSet<usize> {
        let mut candidates = FxHashSet::default();
        for term in query_terms {
            if let Some(posting_list) = self.index.get(term) {
                candidates.extend(posting_list.doc_frequencies.keys().copied());
            }
        }
        candidates
    }

    /// Get IDF (Inverse Document Frequency) for a term.
    ///
    /// IDF(term) = log((N - df + 0.5) / (df + 0.5) + 1)
    ///
    /// This is a morphism: Term → ℝ
    #[inline]
    pub fn idf(&self, term: &str) -> f32 {
        self.index.get(term).map(|pl| pl.idf).unwrap_or(0.0)
    }

    /// Get document length (in terms).
    #[inline]
    pub fn doc_length(&self, doc_idx: usize) -> u32 {
        self.doc_lengths.get(doc_idx).copied().unwrap_or(0)
    }

    /// Get average document length.
    #[inline]
    pub fn avg_doc_length(&self) -> f32 {
        self.avg_doc_length
    }

    /// Get number of documents.
    #[inline]
    pub fn num_docs(&self) -> usize {
        self.num_docs
    }

    /// Get number of unique terms.
    pub fn num_terms(&self) -> usize {
        self.index.len()
    }

    /// Check if a term exists in the index.
    pub fn contains_term(&self, term: &str) -> bool {
        self.index.contains_key(term)
    }
}

impl Default for InvertedIndex {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::document::{create_sample_corpus, Document, DocumentCorpus};

    #[test]
    fn test_posting_list() {
        let mut pl = PostingList::new();
        pl.add(0, 3);
        pl.add(1, 2);

        assert_eq!(pl.len(), 2);
        assert_eq!(pl.get_frequency(0), 3);
        assert_eq!(pl.get_frequency(1), 2);
        assert_eq!(pl.get_frequency(99), 0);
    }

    #[test]
    fn test_build_index() {
        let corpus = DocumentCorpus::from_documents(vec![
            Document::new("1", "Category Theory", "Morphisms and functors"),
            Document::new("2", "Programming", "Functional programming with functors"),
        ]);

        let index = InvertedIndex::build(&corpus);

        assert_eq!(index.num_docs(), 2);
        assert!(index.contains_term("functors"));
        assert!(index.contains_term("category"));
        assert!(!index.contains_term("nonexistent"));
    }

    #[test]
    fn test_candidate_documents() {
        let corpus = create_sample_corpus();
        let index = InvertedIndex::build(&corpus);

        let query_terms = vec!["category".to_string(), "theory".to_string()];
        let candidates = index.get_candidate_documents(&query_terms);

        // Should find documents mentioning category or theory
        assert!(!candidates.is_empty());
    }

    #[test]
    fn test_idf() {
        let corpus = create_sample_corpus();
        let index = InvertedIndex::build(&corpus);

        // Common terms should have lower IDF
        let common_idf = index.idf("category");
        let rare_idf = index.idf("queue");

        // "category" appears in multiple docs, "queue" in fewer
        // So rare_idf should be higher
        assert!(common_idf >= 0.0);
        assert!(rare_idf >= 0.0);
    }

    #[test]
    fn test_term_frequency() {
        let corpus = DocumentCorpus::from_documents(vec![Document::new(
            "1",
            "Test",
            "category category category theory",
        )]);

        let index = InvertedIndex::build(&corpus);

        // "category" appears 3 times
        assert_eq!(index.get_term_frequency("category", 0), 3);
        // "theory" appears 1 time
        assert_eq!(index.get_term_frequency("theory", 0), 1);
    }
}
