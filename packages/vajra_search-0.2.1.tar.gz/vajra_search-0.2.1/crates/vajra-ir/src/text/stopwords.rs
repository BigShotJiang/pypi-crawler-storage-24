//! Stop words for text processing

use std::collections::HashSet;
use std::sync::LazyLock;

/// Common English stop words to filter during preprocessing.
pub static STOP_WORDS: LazyLock<HashSet<&'static str>> = LazyLock::new(|| {
    [
        "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "he", "in", "is",
        "it", "its", "of", "on", "that", "the", "to", "was", "will", "with", "this", "they",
        "them", "their", "have", "but", "not", "or", "can", "been", "which", "than", "when",
    ]
    .into_iter()
    .collect()
});

/// Check if a word is a stop word.
#[inline]
pub fn is_stop_word(word: &str) -> bool {
    STOP_WORDS.contains(word)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_stop_words() {
        assert!(is_stop_word("the"));
        assert!(is_stop_word("and"));
        assert!(!is_stop_word("category"));
        assert!(!is_stop_word("functor"));
    }
}
