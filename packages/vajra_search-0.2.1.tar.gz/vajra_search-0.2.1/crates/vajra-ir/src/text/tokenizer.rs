//! Text tokenization
//!
//! Tokenization is a morphism: Text → Vec<Token>

use super::stopwords::is_stop_word;
use regex::Regex;
use std::sync::LazyLock;

/// A token (word) extracted from text.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Token {
    /// The token text (lowercase).
    pub text: String,
    /// Position in the original text.
    pub position: usize,
}

impl Token {
    /// Create a new token.
    pub fn new(text: impl Into<String>, position: usize) -> Self {
        Self {
            text: text.into(),
            position,
        }
    }
}

/// Regex for extracting word tokens.
static WORD_REGEX: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"[a-z0-9]+").unwrap());

/// Tokenize text into words.
///
/// Morphism: Text → Vec<Token>
///
/// - Converts to lowercase
/// - Extracts alphanumeric words
/// - Preserves word positions
pub fn tokenize(text: &str) -> Vec<Token> {
    let lower = text.to_lowercase();
    WORD_REGEX
        .find_iter(&lower)
        .enumerate()
        .map(|(position, m)| Token::new(m.as_str(), position))
        .collect()
}

/// Preprocess text into terms ready for indexing/querying.
///
/// Composition of morphisms:
/// Text → Vec<Token> → Vec<Token> (filtered) → Vec<String>
///
/// This is categorical composition!
pub fn preprocess_text(text: &str) -> Vec<String> {
    preprocess_text_with_options(text, true)
}

/// Preprocess text with configurable stop word removal.
pub fn preprocess_text_with_options(text: &str, remove_stopwords: bool) -> Vec<String> {
    let tokens = tokenize(text);

    if remove_stopwords {
        tokens
            .into_iter()
            .filter(|token| !is_stop_word(&token.text))
            .map(|token| token.text)
            .collect()
    } else {
        tokens.into_iter().map(|token| token.text).collect()
    }
}

/// Get unique terms from text.
pub fn get_unique_terms(text: &str) -> Vec<String> {
    let terms = preprocess_text(text);
    let mut unique: Vec<String> = terms.into_iter().collect();
    unique.sort();
    unique.dedup();
    unique
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tokenize() {
        let tokens = tokenize("Hello World!");
        assert_eq!(tokens.len(), 2);
        assert_eq!(tokens[0].text, "hello");
        assert_eq!(tokens[1].text, "world");
        assert_eq!(tokens[0].position, 0);
        assert_eq!(tokens[1].position, 1);
    }

    #[test]
    fn test_tokenize_mixed_case() {
        let tokens = tokenize("Category THEORY Functors");
        assert_eq!(tokens.len(), 3);
        assert_eq!(tokens[0].text, "category");
        assert_eq!(tokens[1].text, "theory");
        assert_eq!(tokens[2].text, "functors");
    }

    #[test]
    fn test_preprocess_removes_stop_words() {
        let terms = preprocess_text("The category and the functor");
        // "the", "and" are stop words
        assert_eq!(terms, vec!["category", "functor"]);
    }

    #[test]
    fn test_preprocess_without_stopword_removal() {
        let terms = preprocess_text_with_options("The category and the functor", false);
        assert_eq!(terms, vec!["the", "category", "and", "the", "functor"]);
    }

    #[test]
    fn test_get_unique_terms() {
        let terms = get_unique_terms("category theory category theory");
        assert_eq!(terms, vec!["category", "theory"]);
    }
}
