//! Text processing utilities
//!
//! Tokenization and normalization are morphisms:
//! - Text → Vec<Token>
//! - Token → NormalizedToken
//!
//! These morphisms preserve information while transforming representation.

mod stopwords;
mod tokenizer;

pub use stopwords::STOP_WORDS;
pub use tokenizer::{preprocess_text, tokenize, Token};
