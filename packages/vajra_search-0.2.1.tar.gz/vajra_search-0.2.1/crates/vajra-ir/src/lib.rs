//! # Vajra IR - Information Retrieval
//!
//! BM25 search engine with sparse matrix optimization.
//!
//! ## Architecture
//!
//! The search engine is modeled as a categorical coalgebra:
//! - **States**: Query representations
//! - **Structure map**: Query → List[SearchResult]
//! - **Morphism**: BM25 scoring function (Query, Document) → ℝ
//!
//! ## Modules
//!
//! - [`document`]: Document and corpus types
//! - [`text`]: Text processing and tokenization
//! - [`index`]: Sparse inverted index
//! - [`bm25`]: BM25 scorer as categorical morphism
//! - [`search`]: Search coalgebra and engine

pub mod bm25;
pub mod document;
pub mod index;
pub mod search;
pub mod text;

// Re-export main types
pub use bm25::{BM25Params, BM25Scorer};
pub use document::{Document, DocumentCorpus};
pub use index::{InvertedIndex, PostingList};
pub use search::{QueryState, SearchResult, VajraSearch};
pub use text::{preprocess_text, tokenize, STOP_WORDS};
