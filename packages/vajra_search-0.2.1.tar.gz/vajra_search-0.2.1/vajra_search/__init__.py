# BM25 core from Rust extension
from vajra_search._vajra_search import (
    BM25Params,
    Document,
    DocumentCorpus,
    HnswIndex,
    SearchResult,
    VajraSearch,
    VajraSearchParallel,
    create_sample_corpus,
    version,
)

# Python layer: embeddings, vector index, hybrid search
from vajra_search.embeddings import (
    EmbeddingMorphism,
    IdentityEmbeddingMorphism,
    PrecomputedEmbeddingMorphism,
    TextEmbeddingMorphism,
)
from vajra_search.vector import (
    NativeHNSWIndex,
    VajraVectorSearch,
    VectorSearchResult,
)
from vajra_search.hybrid import HybridSearchEngine

__all__ = [
    # Rust extension — BM25
    "Document",
    "DocumentCorpus",
    "BM25Params",
    "SearchResult",
    "VajraSearch",
    "VajraSearchParallel",
    "create_sample_corpus",
    "version",
    # Rust extension — HNSW
    "HnswIndex",
    # Python — embeddings
    "EmbeddingMorphism",
    "TextEmbeddingMorphism",
    "PrecomputedEmbeddingMorphism",
    "IdentityEmbeddingMorphism",
    # Python — vector search
    "NativeHNSWIndex",
    "VajraVectorSearch",
    "VectorSearchResult",
    # Python — hybrid search
    "HybridSearchEngine",
]
