"""
Embedding Morphisms: Text → ℝ^d

Embeddings as categorical morphisms that map text to vector space.
"""

from abc import ABC, abstractmethod
from typing import Dict, Generic, List, Optional, TypeVar

import numpy as np

A = TypeVar("A")
B = TypeVar("B")


class Morphism(ABC, Generic[A, B]):
    """Abstract morphism A → B in the search category."""

    @abstractmethod
    def apply(self, a: A) -> B:
        pass


class EmbeddingMorphism(Morphism[A, np.ndarray], ABC):
    """Abstract morphism: T → ℝ^d (embedding space)."""

    @abstractmethod
    def embed(self, item: A) -> np.ndarray:
        pass

    @abstractmethod
    def embed_batch(self, items: List[A]) -> np.ndarray:
        pass

    @property
    @abstractmethod
    def dimension(self) -> int:
        pass

    def apply(self, a: A) -> np.ndarray:
        return self.embed(a)


class TextEmbeddingMorphism(EmbeddingMorphism[str]):
    """
    Text → Embedding using sentence-transformers.

    Usage:
        embedder = TextEmbeddingMorphism("all-MiniLM-L6-v2")
        vector = embedder.embed("Hello world")
        vectors = embedder.embed_batch(["Hello", "World"])
    """

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        normalize: bool = True,
        device: Optional[str] = None,
    ):
        self.model_name = model_name
        self.normalize = normalize
        self._model = None
        self._dimension: Optional[int] = None
        self._device = device

    def _load_model(self) -> None:
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError:
                raise ImportError(
                    "sentence-transformers required for TextEmbeddingMorphism. "
                    "Install with: pip install sentence-transformers"
                )
            self._model = SentenceTransformer(self.model_name, device=self._device)
            self._dimension = self._model.get_sentence_embedding_dimension()

    @property
    def dimension(self) -> int:
        if self._dimension is None:
            self._load_model()
        return self._dimension

    def embed(self, text: str) -> np.ndarray:
        self._load_model()
        return self._model.encode(
            text,
            normalize_embeddings=self.normalize,
            convert_to_numpy=True,
        ).astype(np.float32)

    def embed_batch(self, texts: List[str]) -> np.ndarray:
        self._load_model()
        return self._model.encode(
            texts,
            normalize_embeddings=self.normalize,
            convert_to_numpy=True,
            show_progress_bar=len(texts) > 100,
        ).astype(np.float32)


class PrecomputedEmbeddingMorphism(EmbeddingMorphism[str]):
    """
    Lookup morphism for pre-computed embeddings.

    Usage:
        embeddings = {"doc1": np.array([...]), "doc2": np.array([...])}
        embedder = PrecomputedEmbeddingMorphism(embeddings)
        vector = embedder.embed("doc1")
    """

    def __init__(self, embeddings: Dict[str, np.ndarray]):
        if not embeddings:
            raise ValueError("embeddings dictionary cannot be empty")
        self._embeddings = embeddings
        first_vector = next(iter(embeddings.values()))
        self._dimension = first_vector.shape[0]
        for id_, vec in embeddings.items():
            if vec.shape[0] != self._dimension:
                raise ValueError(
                    f"Embedding for '{id_}' has dimension {vec.shape[0]}, "
                    f"expected {self._dimension}"
                )

    @property
    def dimension(self) -> int:
        return self._dimension

    def embed(self, item_id: str) -> np.ndarray:
        if item_id not in self._embeddings:
            raise KeyError(f"No embedding for ID: {item_id}")
        return self._embeddings[item_id].astype(np.float32)

    def embed_batch(self, item_ids: List[str]) -> np.ndarray:
        return np.vstack([self.embed(id_) for id_ in item_ids]).astype(np.float32)

    def add(self, item_id: str, embedding: np.ndarray) -> None:
        if embedding.shape[0] != self._dimension:
            raise ValueError(
                f"Embedding has dimension {embedding.shape[0]}, "
                f"expected {self._dimension}"
            )
        self._embeddings[item_id] = embedding.astype(np.float32)

    def __contains__(self, item_id: str) -> bool:
        return item_id in self._embeddings

    def __len__(self) -> int:
        return len(self._embeddings)


class IdentityEmbeddingMorphism(EmbeddingMorphism[np.ndarray]):
    """Identity morphism for pre-embedded data."""

    def __init__(self, dimension: int):
        self._dimension = dimension

    @property
    def dimension(self) -> int:
        return self._dimension

    def embed(self, vector: np.ndarray) -> np.ndarray:
        if vector.shape[0] != self._dimension:
            raise ValueError(
                f"Vector has dimension {vector.shape[0]}, expected {self._dimension}"
            )
        return vector.astype(np.float32)

    def embed_batch(self, vectors: np.ndarray) -> np.ndarray:
        if vectors.shape[1] != self._dimension:
            raise ValueError(
                f"Vectors have dimension {vectors.shape[1]}, expected {self._dimension}"
            )
        return vectors.astype(np.float32)
