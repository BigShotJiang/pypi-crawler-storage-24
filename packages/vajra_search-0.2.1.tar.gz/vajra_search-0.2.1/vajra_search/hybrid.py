"""
Hybrid Search: BM25 + Vector Fusion

Combines BM25 (keyword) and vector (semantic) search using score fusion.
Results are returned as VectorSearchResult objects so the full document is
accessible via result.document regardless of which engine contributed the hit.

Fusion methods:
- rrf: Reciprocal Rank Fusion (default, robust, no score normalisation needed)
- linear: Weighted average of min-max normalised scores
- rsf: Relative Score Fusion (normalise by max score)

Usage:
    hybrid = HybridSearchEngine(bm25_engine, vector_engine, alpha=0.5)
    results = hybrid.search("query", top_k=10)
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Literal, Optional, Any

from vajra_search.vector import VectorSearchResult


class FusionMethod(Enum):
    RRF = "rrf"
    LINEAR = "linear"
    RSF = "rsf"


@dataclass
class HybridSearchResult(VectorSearchResult):
    """VectorSearchResult extended with per-engine component scores."""

    bm25_score: Optional[float] = None
    bm25_rank: Optional[int] = None
    vector_score: Optional[float] = None
    vector_rank: Optional[int] = None


class HybridSearchEngine:
    """
    Hybrid search combining BM25 and vector search via score fusion.

    Both engines must expose a `.search(query, top_k=n)` method whose results
    have `.document.id`, `.document`, and `.score` attributes.
    """

    def __init__(
        self,
        bm25_engine: Any,
        vector_engine: Any,
        alpha: float = 0.5,
        method: Literal["rrf", "linear", "rsf"] = "rrf",
        rrf_k: int = 60,
    ):
        self.bm25 = bm25_engine
        self.vector = vector_engine
        self.alpha = alpha
        self.method = FusionMethod(method)
        self.rrf_k = rrf_k

    def search(
        self,
        query: str,
        top_k: int = 10,
        bm25_weight: Optional[float] = None,
    ) -> List[VectorSearchResult]:
        """Return top_k fused results as VectorSearchResult objects."""
        alpha = bm25_weight if bm25_weight is not None else self.alpha
        fetch_k = top_k * 2
        bm25_results = self.bm25.search(query, top_k=fetch_k)
        vector_results = self.vector.search(query, top_k=fetch_k)

        if self.method == FusionMethod.RRF:
            fused = self._rrf_fusion(bm25_results, vector_results, alpha)
        elif self.method == FusionMethod.LINEAR:
            fused = self._linear_fusion(bm25_results, vector_results, alpha)
        else:
            fused = self._rsf_fusion(bm25_results, vector_results, alpha)

        sorted_items = sorted(fused.values(), key=lambda x: x["score"], reverse=True)
        return [
            VectorSearchResult(
                id=item["document"].id,
                score=item["score"],
                document=item["document"],
                rank=i + 1,
            )
            for i, item in enumerate(sorted_items[:top_k])
        ]

    def search_detailed(
        self,
        query: str,
        top_k: int = 10,
        bm25_weight: Optional[float] = None,
    ) -> List[HybridSearchResult]:
        """Return top_k results with per-engine component scores."""
        alpha = bm25_weight if bm25_weight is not None else self.alpha
        fetch_k = top_k * 2
        bm25_results = self.bm25.search(query, top_k=fetch_k)
        vector_results = self.vector.search(query, top_k=fetch_k)

        results_map: Dict[str, Dict] = {}
        for rank, result in enumerate(bm25_results, 1):
            doc_id = result.document.id
            results_map[doc_id] = {
                "document": result.document,
                "bm25_score": result.score,
                "bm25_rank": rank,
                "vector_score": None,
                "vector_rank": None,
            }
        for rank, result in enumerate(vector_results, 1):
            doc_id = result.document.id
            if doc_id in results_map:
                results_map[doc_id]["vector_score"] = result.score
                results_map[doc_id]["vector_rank"] = rank
            else:
                results_map[doc_id] = {
                    "document": result.document,
                    "bm25_score": None,
                    "bm25_rank": None,
                    "vector_score": result.score,
                    "vector_rank": rank,
                }

        if self.method == FusionMethod.RRF:
            for item in results_map.values():
                bm25_contrib = (
                    alpha / (self.rrf_k + item["bm25_rank"]) if item["bm25_rank"] else 0
                )
                vec_contrib = (
                    (1 - alpha) / (self.rrf_k + item["vector_rank"])
                    if item["vector_rank"]
                    else 0
                )
                item["score"] = bm25_contrib + vec_contrib
        else:
            self._add_linear_scores(results_map, alpha, bm25_results, vector_results)

        sorted_items = sorted(
            results_map.values(), key=lambda x: x["score"], reverse=True
        )
        return [
            HybridSearchResult(
                id=item["document"].id,
                score=item["score"],
                document=item["document"],
                rank=i + 1,
                bm25_score=item["bm25_score"],
                bm25_rank=item["bm25_rank"],
                vector_score=item["vector_score"],
                vector_rank=item["vector_rank"],
            )
            for i, item in enumerate(sorted_items[:top_k])
        ]

    # ─── Fusion helpers ───────────────────────────────────────────────────────

    def _rrf_fusion(self, bm25_results, vector_results, alpha: float) -> Dict:
        results: Dict[str, Dict] = {}
        for rank, result in enumerate(bm25_results, 1):
            doc_id = result.document.id
            score = alpha / (self.rrf_k + rank)
            if doc_id in results:
                results[doc_id]["score"] += score
            else:
                results[doc_id] = {"document": result.document, "score": score}
        for rank, result in enumerate(vector_results, 1):
            doc_id = result.document.id
            score = (1 - alpha) / (self.rrf_k + rank)
            if doc_id in results:
                results[doc_id]["score"] += score
            else:
                results[doc_id] = {"document": result.document, "score": score}
        return results

    def _linear_fusion(self, bm25_results, vector_results, alpha: float) -> Dict:
        results: Dict[str, Dict] = {}
        bm25_scores = [r.score for r in bm25_results]
        bm25_min = min(bm25_scores, default=0.0)
        bm25_max = max(bm25_scores, default=1.0)
        bm25_range = bm25_max - bm25_min if bm25_max > bm25_min else 1.0

        vec_scores = [r.score for r in vector_results]
        vec_min = min(vec_scores, default=0.0)
        vec_max = max(vec_scores, default=1.0)
        vec_range = vec_max - vec_min if vec_max > vec_min else 1.0

        for result in bm25_results:
            doc_id = result.document.id
            norm = (result.score - bm25_min) / bm25_range
            results[doc_id] = {"document": result.document, "score": alpha * norm}

        for result in vector_results:
            doc_id = result.document.id
            norm = (result.score - vec_min) / vec_range
            weighted = (1 - alpha) * norm
            if doc_id in results:
                results[doc_id]["score"] += weighted
            else:
                results[doc_id] = {"document": result.document, "score": weighted}
        return results

    def _rsf_fusion(self, bm25_results, vector_results, alpha: float) -> Dict:
        results: Dict[str, Dict] = {}
        bm25_max = max((r.score for r in bm25_results), default=1.0)
        vec_max = max((r.score for r in vector_results), default=1.0)
        bm25_max = bm25_max if bm25_max > 0 else 1.0
        vec_max = vec_max if vec_max > 0 else 1.0

        for result in bm25_results:
            doc_id = result.document.id
            results[doc_id] = {
                "document": result.document,
                "score": alpha * (result.score / bm25_max),
            }
        for result in vector_results:
            doc_id = result.document.id
            weighted = (1 - alpha) * (result.score / vec_max)
            if doc_id in results:
                results[doc_id]["score"] += weighted
            else:
                results[doc_id] = {"document": result.document, "score": weighted}
        return results

    def _add_linear_scores(
        self, results_map: Dict, alpha: float, bm25_results, vector_results
    ) -> None:
        bm25_scores = [r.score for r in bm25_results]
        bm25_min = min(bm25_scores, default=0.0)
        bm25_max = max(bm25_scores, default=1.0)
        bm25_range = bm25_max - bm25_min if bm25_max > bm25_min else 1.0

        vec_scores = [r.score for r in vector_results]
        vec_min = min(vec_scores, default=0.0)
        vec_max = max(vec_scores, default=1.0)
        vec_range = vec_max - vec_min if vec_max > vec_min else 1.0

        for item in results_map.values():
            score = 0.0
            if item["bm25_score"] is not None:
                score += alpha * (item["bm25_score"] - bm25_min) / bm25_range
            if item["vector_score"] is not None:
                score += (1 - alpha) * (item["vector_score"] - vec_min) / vec_range
            item["score"] = score

    def __repr__(self) -> str:
        return f"HybridSearchEngine(method={self.method.value!r}, alpha={self.alpha})"
