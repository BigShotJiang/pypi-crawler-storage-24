"""
Vector search engine: NativeHNSWIndex (Rust backend) + VajraVectorSearch.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Generic, List, Optional, Tuple, TypeVar

import numpy as np

from vajra_search.embeddings import EmbeddingMorphism

X = TypeVar("X")
FX = TypeVar("FX")


# ─── Categorical scaffolding ──────────────────────────────────────────────────


class Coalgebra(ABC, Generic[X, FX]):
    """Abstract coalgebra α: X → F(X)."""

    @abstractmethod
    def structure_map(self, state: X) -> FX:
        pass


# ─── VectorSearchResult ───────────────────────────────────────────────────────


@dataclass
class VectorSearchResult:
    """
    Result from a vector index search.

    Attributes:
        id: Document/vector identifier.
        score: Distance or similarity score.
        document: Full document object (populated by VajraVectorSearch).
        rank: 1-based position in the result list.
    """

    id: str
    score: float
    document: Any = None  # PyDocument from _vajra_search, populated by VajraVectorSearch
    rank: int = 0

    def __repr__(self) -> str:
        return f"VectorSearchResult(id={self.id!r}, score={self.score:.4f})"


# ─── VectorIndex ABC ──────────────────────────────────────────────────────────


class VectorIndex(ABC):
    """Abstract vector index: (Query, k) → List[VectorSearchResult]."""

    @abstractmethod
    def add(self, ids: List[str], vectors: np.ndarray) -> None:
        pass

    @abstractmethod
    def search(self, query: np.ndarray, k: int) -> List[VectorSearchResult]:
        pass

    @abstractmethod
    def save(self, path: str) -> None:
        pass

    @classmethod
    @abstractmethod
    def load(cls, path: str) -> "VectorIndex":
        pass

    @property
    @abstractmethod
    def size(self) -> int:
        pass


# ─── NativeHNSWIndex ─────────────────────────────────────────────────────────


class NativeHNSWIndex(VectorIndex):
    """
    Thin Python wrapper over the Rust HnswIndex PyO3 binding.

    Usage:
        index = NativeHNSWIndex(dimension=384, metric="cosine")
        index.add(ids, vectors)          # vectors: (n, d) float32 ndarray
        results = index.search(query, k=10)
        index.save("/tmp/index.bin")
        loaded = NativeHNSWIndex.load("/tmp/index.bin")
    """

    def __init__(
        self,
        dimension: int,
        metric: str = "cosine",
        M: int = 16,
        ef_construction: int = 200,
        ef_search: int = 50,
        max_elements: int = 1_000_000,
        use_heuristic: bool = True,
        seed: Optional[int] = None,
    ):
        from vajra_search._vajra_search import HnswIndex as _HnswIndex

        kwargs = dict(
            dimension=dimension,
            metric=metric,
            m=M,
            ef_construction=ef_construction,
            max_elements=max_elements,
            ef_search=ef_search,
            use_heuristic=use_heuristic,
        )
        if seed is not None:
            kwargs["seed"] = int(seed)

        try:
            self._idx = _HnswIndex(**kwargs)
        except TypeError as exc:
            # Backward-compatible fallback when a stale compiled extension
            # without `seed` support is present on PYTHONPATH.
            if "seed" not in str(exc) or "seed" not in kwargs:
                raise
            kwargs.pop("seed", None)
            self._idx = _HnswIndex(**kwargs)
        self._dimension = dimension
        self._ef_search = ef_search
        self._use_heuristic = use_heuristic

    # ─── VectorIndex interface ────────────────────────────────────────────────

    def add(
        self,
        ids: List[str],
        vectors: np.ndarray,
        metadata: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """Add vectors to the index. `vectors` must be (n, dim) float32."""
        self._idx.add_batch(ids, np.asarray(vectors, dtype=np.float32))

    def search(self, query: np.ndarray, k: int) -> List[VectorSearchResult]:
        """Search for k nearest neighbours. Returns VectorSearchResult list."""
        raw: List[Tuple[str, float]] = self._idx.search(
            np.asarray(query, dtype=np.float32), k=k
        )
        return [VectorSearchResult(id=id_, score=score) for id_, score in raw]

    def save(self, path: str) -> None:
        self._idx.save(path)

    @classmethod
    def load(cls, path: str) -> "NativeHNSWIndex":
        from vajra_search._vajra_search import HnswIndex as _HnswIndex

        obj = cls.__new__(cls)
        obj._idx = _HnswIndex.load(path)
        obj._dimension = obj._idx.dimension
        obj._ef_search = 50  # default; not persisted separately
        obj._use_heuristic = obj._idx.use_heuristic
        return obj

    @property
    def size(self) -> int:
        return len(self._idx)

    # ─── Extras ───────────────────────────────────────────────────────────────

    def search_batch(
        self, queries: np.ndarray, k: int
    ) -> List[List[VectorSearchResult]]:
        """Parallel search for multiple queries. `queries` is (n, dim) float32."""
        raw_batch = self._idx.search_batch(np.asarray(queries, dtype=np.float32), k=k)
        return [
            [VectorSearchResult(id=id_, score=score) for id_, score in raw]
            for raw in raw_batch
        ]

    def __len__(self) -> int:
        return self.size

    def __repr__(self) -> str:
        return (
            f"NativeHNSWIndex(dimension={self._dimension}, "
            f"metric={self._idx.metric!r}, size={self.size}, "
            f"use_heuristic={self._idx.use_heuristic})"
        )


# ─── VectorQueryState + Coalgebra ─────────────────────────────────────────────


@dataclass(frozen=True)
class VectorQueryState:
    """Immutable query state for vector search coalgebra."""

    query_embedding: Tuple[float, ...]
    top_k: int
    seen_ids: frozenset = frozenset()

    def exclude(self, ids: List[str]) -> "VectorQueryState":
        return VectorQueryState(
            query_embedding=self.query_embedding,
            top_k=self.top_k,
            seen_ids=self.seen_ids | set(ids),
        )


class VectorSearchCoalgebra(Coalgebra[VectorQueryState, List[VectorSearchResult]]):
    """Coalgebra: QueryState → List[VectorSearchResult]."""

    def __init__(self, index: VectorIndex):
        self.index = index

    def structure_map(self, state: VectorQueryState) -> List[VectorSearchResult]:
        query = np.array(state.query_embedding, dtype=np.float32)
        fetch_k = state.top_k + len(state.seen_ids)
        results = self.index.search(query, k=fetch_k)
        filtered = [r for r in results if r.id not in state.seen_ids]
        return filtered[: state.top_k]


# ─── VajraVectorSearch ───────────────────────────────────────────────────────


class VajraVectorSearch:
    """
    Main vector search engine.

    Combines an EmbeddingMorphism (text → float32 vector) with a VectorIndex
    (vector → ranked results). `NativeHNSWIndex` is the default index backend.

    Usage:
        from vajra_search import TextEmbeddingMorphism, NativeHNSWIndex, VajraVectorSearch

        embedder = TextEmbeddingMorphism("all-MiniLM-L6-v2")
        index = NativeHNSWIndex(dimension=384, metric="cosine")
        engine = VajraVectorSearch(embedder, index)
        engine.index_documents(documents)
        results = engine.search("semantic query", top_k=10)
    """

    def __init__(
        self,
        embedder: EmbeddingMorphism,
        index: VectorIndex,
        cache_size: int = 1000,
    ):
        self.embedder = embedder
        self.index = index
        self.coalgebra = VectorSearchCoalgebra(index)
        self._documents: Dict[str, Any] = {}  # id → PyDocument
        self._cache: Dict[str, np.ndarray] = {}
        self._cache_order: List[str] = []
        self._cache_size = cache_size

    def index_documents(
        self,
        documents: List[Any],  # List[Document] — PyO3 Document objects
        batch_size: int = 256,
        show_progress: bool = True,
    ) -> int:
        """
        Build index from documents.

        Returns the number of documents indexed.
        """
        try:
            from tqdm import tqdm
            has_tqdm = True
        except ImportError:
            has_tqdm = False

        ids: List[str] = []
        all_embeddings: List[np.ndarray] = []

        batches = [
            documents[i: i + batch_size]
            for i in range(0, len(documents), batch_size)
        ]
        iterator = (
            tqdm(batches, desc="Indexing documents")
            if show_progress and has_tqdm and len(batches) > 1
            else batches
        )

        for batch in iterator:
            texts = [doc.content for doc in batch]
            batch_embeddings = self.embedder.embed_batch(texts)
            ids.extend(doc.id for doc in batch)
            all_embeddings.append(batch_embeddings)
            for doc in batch:
                self._documents[doc.id] = doc

        embeddings = np.vstack(all_embeddings)
        self.index.add(ids, embeddings)
        return len(documents)

    def search(
        self,
        query: str,
        top_k: int = 10,
        exclude_ids: Optional[List[str]] = None,
    ) -> List[VectorSearchResult]:
        """Search for documents similar to query text."""
        query_embedding = self._get_cached_embedding(query)
        seen_ids = frozenset(exclude_ids) if exclude_ids else frozenset()
        state = VectorQueryState(
            query_embedding=tuple(query_embedding.tolist()),
            top_k=top_k,
            seen_ids=seen_ids,
        )
        raw_results = self.coalgebra.structure_map(state)

        results: List[VectorSearchResult] = []
        for i, vr in enumerate(raw_results):
            doc = self._documents.get(vr.id)
            if doc is not None:
                results.append(
                    VectorSearchResult(id=vr.id, score=vr.score, document=doc, rank=i + 1)
                )
        return results

    def search_by_vector(
        self,
        query_vector: np.ndarray,
        top_k: int = 10,
    ) -> List[VectorSearchResult]:
        """Search by a pre-computed embedding vector."""
        return self.index.search(query_vector, k=top_k)

    def add_document(self, document: Any) -> None:
        """Add a single document to the index."""
        embedding = self.embedder.embed(document.content)
        self.index.add([document.id], embedding.reshape(1, -1))
        self._documents[document.id] = document

    def get_document(self, doc_id: str) -> Optional[Any]:
        return self._documents.get(doc_id)

    def save(self, path: str) -> None:
        """Save the HNSW index to disk (documents not persisted)."""
        self.index.save(path)

    @classmethod
    def load(
        cls,
        path: str,
        embedder: EmbeddingMorphism,
        index_class: type = NativeHNSWIndex,
    ) -> "VajraVectorSearch":
        index = index_class.load(path)
        return cls(embedder, index)

    def clear_cache(self) -> None:
        self._cache.clear()
        self._cache_order.clear()

    @property
    def num_documents(self) -> int:
        return self.index.size

    def _get_cached_embedding(self, text: str) -> np.ndarray:
        if text in self._cache:
            self._cache_order.remove(text)
            self._cache_order.append(text)
            return self._cache[text]
        embedding = self.embedder.embed(text)
        self._cache[text] = embedding
        self._cache_order.append(text)
        while len(self._cache_order) > self._cache_size:
            del self._cache[self._cache_order.pop(0)]
        return embedding

    def __repr__(self) -> str:
        return (
            f"VajraVectorSearch(embedder={self.embedder.__class__.__name__}, "
            f"index={self.index.__class__.__name__}, "
            f"documents={self.num_documents})"
        )
