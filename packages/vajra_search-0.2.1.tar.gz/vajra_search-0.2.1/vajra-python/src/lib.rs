//! # Vajra Python - PyO3 Bindings
//!
//! Python bindings for the Vajra search engine.
//!
//! ## Usage
//!
//! ```python
//! from vajra_search import Document, DocumentCorpus, VajraSearch
//!
//! # Create documents
//! docs = [
//!     Document("1", "Title One", "Content one"),
//!     Document("2", "Title Two", "Content two"),
//! ]
//!
//! # Create corpus and search engine
//! corpus = DocumentCorpus(docs)
//! engine = VajraSearch(corpus)
//!
//! # Search
//! results = engine.search("query text", top_k=10)
//! for result in results:
//!     print(f"{result.rank}. {result.title} ({result.score:.3f})")
//! ```

use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use std::collections::HashMap;

use numpy::{PyReadonlyArray1, PyReadonlyArray2};
use vajra_hnsw::{HnswError, HnswIndex, Metric as HnswMetric};

// Import Rust types
use vajra_ir::bm25::BM25Params as RustBM25Params;
use vajra_ir::document::{
    create_sample_corpus as rust_create_sample_corpus, Document as RustDocument,
    DocumentCorpus as RustDocumentCorpus,
};
use vajra_ir::search::{SearchResult as RustSearchResult, VajraSearch as RustVajraSearch};
use vajra_parallel::VajraSearchParallel as RustVajraSearchParallel;

/// A document in the search corpus.
#[pyclass(name = "Document")]
#[derive(Clone)]
pub struct PyDocument {
    inner: RustDocument,
}

#[pymethods]
impl PyDocument {
    /// Create a new document.
    #[new]
    #[pyo3(signature = (id, title, content, metadata=None))]
    fn new(
        id: String,
        title: String,
        content: String,
        metadata: Option<HashMap<String, String>>,
    ) -> Self {
        let inner = if let Some(meta) = metadata {
            RustDocument::with_metadata(id, title, content, meta)
        } else {
            RustDocument::new(id, title, content)
        };
        Self { inner }
    }

    /// Document ID.
    #[getter]
    fn id(&self) -> &str {
        &self.inner.id
    }

    /// Document title.
    #[getter]
    fn title(&self) -> &str {
        &self.inner.title
    }

    /// Document content.
    #[getter]
    fn content(&self) -> &str {
        &self.inner.content
    }

    /// Document metadata.
    #[getter]
    fn metadata(&self) -> Option<HashMap<String, String>> {
        self.inner.metadata.clone()
    }

    /// Get full text (title + content).
    fn full_text(&self) -> String {
        self.inner.full_text()
    }

    fn __repr__(&self) -> String {
        format!(
            "Document(id='{}', title='{}')",
            self.inner.id, self.inner.title
        )
    }

    fn __str__(&self) -> String {
        format!("[{}] {}", self.inner.id, self.inner.title)
    }
}

/// A corpus of documents.
#[pyclass(name = "DocumentCorpus")]
pub struct PyDocumentCorpus {
    inner: RustDocumentCorpus,
}

#[pymethods]
impl PyDocumentCorpus {
    /// Create a corpus from a list of documents.
    #[new]
    fn new(documents: Vec<PyDocument>) -> Self {
        let rust_docs: Vec<RustDocument> = documents.into_iter().map(|d| d.inner).collect();
        Self {
            inner: RustDocumentCorpus::from_documents(rust_docs),
        }
    }

    /// Add a document to the corpus.
    fn add(&mut self, doc: PyDocument) {
        self.inner.add(doc.inner);
    }

    /// Get a document by ID.
    fn get(&self, doc_id: &str) -> Option<PyDocument> {
        self.inner
            .get(doc_id)
            .map(|d| PyDocument { inner: d.clone() })
    }

    /// Number of documents.
    fn __len__(&self) -> usize {
        self.inner.len()
    }

    /// Check if corpus is empty.
    fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }

    /// Get all document IDs.
    fn doc_ids(&self) -> Vec<String> {
        self.inner.doc_ids().map(|s| s.to_string()).collect()
    }

    fn __repr__(&self) -> String {
        format!("DocumentCorpus(len={})", self.inner.len())
    }
}

/// BM25 hyperparameters.
#[pyclass(name = "BM25Params")]
#[derive(Clone)]
pub struct PyBM25Params {
    inner: RustBM25Params,
}

#[pymethods]
impl PyBM25Params {
    /// Create BM25 parameters.
    #[new]
    #[pyo3(signature = (k1=1.5, b=0.75))]
    fn new(k1: f32, b: f32) -> Self {
        Self {
            inner: RustBM25Params::new(k1, b),
        }
    }

    /// Term frequency saturation parameter.
    #[getter]
    fn k1(&self) -> f32 {
        self.inner.k1
    }

    /// Length normalization parameter.
    #[getter]
    fn b(&self) -> f32 {
        self.inner.b
    }

    fn __repr__(&self) -> String {
        format!("BM25Params(k1={}, b={})", self.inner.k1, self.inner.b)
    }
}

/// A search result with document, score, and rank.
#[pyclass(name = "SearchResult")]
pub struct PySearchResult {
    inner: RustSearchResult,
}

#[pymethods]
impl PySearchResult {
    /// The matched document.
    #[getter]
    fn document(&self) -> PyDocument {
        PyDocument {
            inner: self.inner.document.clone(),
        }
    }

    /// BM25 relevance score.
    #[getter]
    fn score(&self) -> f32 {
        self.inner.score
    }

    /// Rank in the result set (0-indexed).
    #[getter]
    fn rank(&self) -> usize {
        self.inner.rank
    }

    /// Document ID (convenience).
    #[getter]
    fn doc_id(&self) -> &str {
        self.inner.doc_id()
    }

    /// Document title (convenience).
    #[getter]
    fn title(&self) -> &str {
        self.inner.title()
    }

    fn __repr__(&self) -> String {
        format!(
            "SearchResult(rank={}, doc_id='{}', score={:.3})",
            self.inner.rank + 1,
            self.inner.doc_id(),
            self.inner.score
        )
    }

    fn __str__(&self) -> String {
        format!("{}", self.inner)
    }
}

/// Vajra BM25 Search Engine.
#[pyclass(name = "VajraSearch")]
pub struct PyVajraSearch {
    inner: RustVajraSearch,
}

#[pymethods]
impl PyVajraSearch {
    /// Create a new search engine.
    #[new]
    #[pyo3(signature = (corpus, k1=1.5, b=0.75))]
    fn new(corpus: &PyDocumentCorpus, k1: f32, b: f32) -> Self {
        // Clone the corpus since we need ownership
        let rust_corpus = corpus.inner.iter().cloned().collect();
        Self {
            inner: RustVajraSearch::new(rust_corpus, RustBM25Params::new(k1, b)),
        }
    }

    /// Search for documents matching a query.
    #[pyo3(signature = (query, top_k=10))]
    fn search(&self, query: &str, top_k: usize) -> Vec<PySearchResult> {
        self.inner
            .search(query, top_k)
            .into_iter()
            .map(|r| PySearchResult { inner: r })
            .collect()
    }

    /// Search with score explanation.
    #[pyo3(signature = (query, top_k=10))]
    fn search_with_explanation(
        &self,
        query: &str,
        top_k: usize,
    ) -> Vec<(PySearchResult, HashMap<String, f32>)> {
        self.inner
            .search_with_explanation(query, top_k)
            .into_iter()
            .map(|(r, exp)| (PySearchResult { inner: r }, exp))
            .collect()
    }

    /// Get a document by ID.
    fn get_document(&self, doc_id: &str) -> Option<PyDocument> {
        self.inner
            .get_document(doc_id)
            .map(|d| PyDocument { inner: d.clone() })
    }

    /// Number of documents in the corpus.
    #[getter]
    fn num_documents(&self) -> usize {
        self.inner.num_documents()
    }

    /// Number of unique terms in the index.
    #[getter]
    fn num_terms(&self) -> usize {
        self.inner.num_terms()
    }

    /// BM25 parameters.
    #[getter]
    fn params(&self) -> PyBM25Params {
        PyBM25Params {
            inner: *self.inner.params(),
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "VajraSearch(docs={}, terms={}, params={})",
            self.inner.num_documents(),
            self.inner.num_terms(),
            self.inner.params()
        )
    }
}

/// Parallel Vajra Search Engine for batch queries.
#[pyclass(name = "VajraSearchParallel")]
pub struct PyVajraSearchParallel {
    inner: RustVajraSearchParallel,
}

#[pymethods]
impl PyVajraSearchParallel {
    /// Create a new parallel search engine.
    #[new]
    #[pyo3(signature = (corpus, k1=1.5, b=0.75))]
    fn new(corpus: &PyDocumentCorpus, k1: f32, b: f32) -> Self {
        let rust_corpus = corpus.inner.iter().cloned().collect();
        Self {
            inner: RustVajraSearchParallel::new(rust_corpus, RustBM25Params::new(k1, b)),
        }
    }

    /// Search for documents matching a query.
    #[pyo3(signature = (query, top_k=10))]
    fn search(&self, query: &str, top_k: usize) -> Vec<PySearchResult> {
        self.inner
            .search(query, top_k)
            .into_iter()
            .map(|r| PySearchResult { inner: r })
            .collect()
    }

    /// Execute multiple queries in parallel.
    #[pyo3(signature = (queries, top_k=10))]
    fn search_batch(&self, queries: Vec<String>, top_k: usize) -> Vec<Vec<PySearchResult>> {
        let query_refs: Vec<&str> = queries.iter().map(|s| s.as_str()).collect();
        self.inner
            .search_batch(&query_refs, top_k)
            .into_iter()
            .map(|results| {
                results
                    .into_iter()
                    .map(|r| PySearchResult { inner: r })
                    .collect()
            })
            .collect()
    }

    /// Number of documents.
    #[getter]
    fn num_documents(&self) -> usize {
        self.inner.num_documents()
    }

    fn __repr__(&self) -> String {
        format!("VajraSearchParallel(docs={})", self.inner.num_documents())
    }
}

// ─── HnswError → PyErr ────────────────────────────────────────────────────────

/// Convert a Rust `HnswError` to a Python `RuntimeError`.
///
/// Different `HnswError` variants map to the same Python exception type for
/// now; the error message is always descriptive.  Callers that need to
/// distinguish specific failures (e.g. `DimensionMismatch`) can inspect the
/// message text.
fn hnsw_err(e: HnswError) -> PyErr {
    PyRuntimeError::new_err(e.to_string())
}

// ─── PyHnswIndex ──────────────────────────────────────────────────────────────

/// Hierarchical Navigable Small-World (HNSW) approximate nearest-neighbour index.
///
/// Backed by the Rust `vajra-hnsw` crate.  Vectors must be `numpy.float32`
/// arrays.  Call `add_batch` to bulk-load, `search` or `search_batch` to query.
///
/// # Example
///
/// ```python
/// import numpy as np
/// from vajra_search import HnswIndex
///
/// idx = HnswIndex(128, metric="cosine")
/// vecs = np.random.rand(1000, 128).astype(np.float32)
/// ids  = [str(i) for i in range(1000)]
/// idx.add_batch(ids, vecs)
///
/// q = np.random.rand(128).astype(np.float32)
/// for id_, score in idx.search(q, k=5):
///     print(f"{id_}  dist={score:.4f}")
/// ```
#[pyclass(name = "HnswIndex")]
pub struct PyHnswIndex {
    inner: HnswIndex,
}

#[pymethods]
impl PyHnswIndex {
    // ─── Construction ─────────────────────────────────────────────────────────

    /// Create a new empty HNSW index.
    ///
    /// Parameters
    /// ----------
    /// dimension : int
    ///     Dimensionality of every vector stored in the index.
    /// metric : str
    ///     Distance metric: ``"cosine"`` (default), ``"l2"``, or
    ///     ``"inner_product"``.  Cosine automatically normalises vectors at
    ///     insertion time.
    /// m : int
    ///     Max connections per node at layers > 0 (default 16).
    /// ef_construction : int
    ///     Beam width during index build (default 200).  Higher values improve
    ///     recall at the cost of slower insertions.
    /// max_elements : int
    ///     Pre-allocated capacity (default 1 000 000).  Insertions beyond this
    ///     limit raise ``RuntimeError``.
    /// ef_search : int
    ///     Default beam width for queries (default 50).  Can be overridden
    ///     per-query via the ``ef`` parameter of :meth:`search`.
    /// use_heuristic : bool
    ///     Enable HNSW heuristic neighbour diversification during insertion
    ///     (default True). Set False for faster builds with potential recall loss.
    /// seed : int | None
    ///     Optional deterministic RNG seed for reproducible HNSW level
    ///     sampling. If omitted, entropy-backed random sampling is used.
    #[new]
    #[pyo3(signature = (
        dimension,
        metric = "cosine",
        m = 16,
        ef_construction = 200,
        max_elements = 1_000_000,
        ef_search = 50,
        use_heuristic = true,
        seed = None,
    ))]
    fn new(
        dimension: usize,
        metric: &str,
        m: usize,
        ef_construction: usize,
        max_elements: usize,
        ef_search: usize,
        use_heuristic: bool,
        seed: Option<u64>,
    ) -> PyResult<Self> {
        let rust_metric = HnswMetric::from_str(metric).ok_or_else(|| {
            PyValueError::new_err(format!(
                "unknown metric '{}'; valid values are 'cosine', 'l2', 'inner_product'",
                metric
            ))
        })?;
        Ok(Self {
            inner: HnswIndex::new_with_options_and_seed(
                dimension,
                rust_metric,
                m,
                ef_construction,
                max_elements,
                ef_search,
                use_heuristic,
                seed,
            ),
        })
    }

    // ─── Insertion ────────────────────────────────────────────────────────────

    /// Insert a single ``float32`` vector.
    ///
    /// Parameters
    /// ----------
    /// id : str
    ///     Unique string identifier for this vector.
    /// vector : numpy.ndarray[float32]
    ///     1-D array of length ``dimension``.
    ///
    /// Raises
    /// ------
    /// RuntimeError
    ///     On dimension mismatch, duplicate ID, or a full index.
    fn add(&mut self, id: String, vector: PyReadonlyArray1<f32>) -> PyResult<()> {
        let q: Vec<f32> = vector.as_array().iter().copied().collect();
        self.inner.add(&id, &q).map_err(hnsw_err)
    }

    /// Bulk-insert *n* vectors from a 2-D ``float32`` array.
    ///
    /// Parameters
    /// ----------
    /// ids : list[str]
    ///     Unique string identifiers — length must equal ``vectors.shape[0]``.
    /// vectors : numpy.ndarray[float32], shape (n, dimension)
    ///     Row-major array of vectors.  Each row is one vector.
    ///
    /// Raises
    /// ------
    /// ValueError
    ///     If ``ids`` and ``vectors`` have incompatible shapes.
    /// RuntimeError
    ///     On dimension mismatch, duplicate ID, or a full index.
    fn add_batch(&mut self, ids: Vec<String>, vectors: PyReadonlyArray2<f32>) -> PyResult<()> {
        let arr = vectors.as_array();
        let shape = arr.shape();
        let (n, arr_dim) = (shape[0], shape[1]);

        if n != ids.len() {
            return Err(PyValueError::new_err(format!(
                "ids length ({}) must equal vectors rows ({})",
                ids.len(),
                n
            )));
        }
        if arr_dim != self.inner.dimension() {
            return Err(PyValueError::new_err(format!(
                "vectors have {} columns but index expects dimension {}",
                arr_dim,
                self.inner.dimension()
            )));
        }

        // Fast path for contiguous arrays; fall back to row-major collect.
        let flat: Vec<f32> = vectors
            .as_slice()
            .map(|s| s.to_vec())
            .unwrap_or_else(|_| arr.iter().copied().collect());
        let id_refs: Vec<&str> = ids.iter().map(|s| s.as_str()).collect();
        self.inner.add_batch(&id_refs, &flat).map_err(hnsw_err)
    }

    // ─── Search ───────────────────────────────────────────────────────────────

    /// Search for the *k* nearest neighbours of a query vector.
    ///
    /// Parameters
    /// ----------
    /// query : numpy.ndarray[float32]
    ///     1-D array of length ``dimension``.
    /// k : int
    ///     Number of results to return (default 10).
    /// ef : int, optional
    ///     Beam width for this query.  Overrides ``ef_search`` when supplied.
    ///
    /// Returns
    /// -------
    /// list[tuple[str, float]]
    ///     ``[(id, distance), ...]`` sorted nearest-first.
    ///
    /// Raises
    /// ------
    /// RuntimeError
    ///     If the index is empty or the query dimension does not match.
    #[pyo3(signature = (query, k = 10, ef = None))]
    fn search(
        &self,
        query: PyReadonlyArray1<f32>,
        k: usize,
        ef: Option<usize>,
    ) -> PyResult<Vec<(String, f32)>> {
        let q: Vec<f32> = query.as_array().iter().copied().collect();
        let results = match ef {
            Some(ef_val) => self.inner.search_ef(&q, k, ef_val),
            None => self.inner.search(&q, k),
        }
        .map_err(hnsw_err)?;

        Ok(results.into_iter().map(|r| (r.id, r.score)).collect())
    }

    /// Search multiple query vectors in parallel (Rayon).
    ///
    /// Parameters
    /// ----------
    /// queries : numpy.ndarray[float32], shape (n, dimension)
    ///     Row-major array of query vectors.
    /// k : int
    ///     Number of results per query (default 10).
    ///
    /// Returns
    /// -------
    /// list[list[tuple[str, float]]]
    ///     One inner list per query, each ``[(id, distance), ...]``.
    #[pyo3(signature = (queries, k = 10))]
    fn search_batch(
        &self,
        queries: PyReadonlyArray2<f32>,
        k: usize,
    ) -> PyResult<Vec<Vec<(String, f32)>>> {
        let arr = queries.as_array();
        let shape = arr.shape();
        let arr_dim = shape[1];

        if arr_dim != self.inner.dimension() {
            return Err(PyValueError::new_err(format!(
                "queries have {} columns but index expects dimension {}",
                arr_dim,
                self.inner.dimension()
            )));
        }

        let flat: Vec<f32> = arr.iter().copied().collect();
        let batch = self.inner.search_batch(&flat, k).map_err(hnsw_err)?;

        Ok(batch
            .into_iter()
            .map(|row| row.into_iter().map(|r| (r.id, r.score)).collect())
            .collect())
    }

    // ─── Persistence ──────────────────────────────────────────────────────────

    /// Serialise the index to a file (bincode format).
    ///
    /// Parameters
    /// ----------
    /// path : str
    ///     Destination file path.  The parent directory must exist.
    ///
    /// Raises
    /// ------
    /// RuntimeError
    ///     On I/O or serialisation errors.
    fn save(&self, path: &str) -> PyResult<()> {
        self.inner
            .save(std::path::Path::new(path))
            .map_err(hnsw_err)
    }

    /// Load an index from a file written by :meth:`save`.
    ///
    /// Parameters
    /// ----------
    /// path : str
    ///     Source file path.
    ///
    /// Returns
    /// -------
    /// HnswIndex
    ///
    /// Raises
    /// ------
    /// RuntimeError
    ///     On I/O or deserialisation errors.
    #[staticmethod]
    fn load(path: &str) -> PyResult<PyHnswIndex> {
        let inner = HnswIndex::load(std::path::Path::new(path)).map_err(hnsw_err)?;
        Ok(PyHnswIndex { inner })
    }

    // ─── Accessors ────────────────────────────────────────────────────────────

    /// Number of vectors currently stored.
    #[getter]
    fn len(&self) -> usize {
        self.inner.len()
    }

    fn __len__(&self) -> usize {
        self.inner.len()
    }

    /// ``True`` if no vectors have been inserted.
    fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }

    /// Dimensionality of this index.
    #[getter]
    fn dimension(&self) -> usize {
        self.inner.dimension()
    }

    /// Distance metric name (``"cosine"``, ``"l2"``, or ``"inner_product"``).
    #[getter]
    fn metric(&self) -> &str {
        self.inner.metric().as_str()
    }

    /// ``True`` if heuristic neighbour diversification is enabled for insertion.
    #[getter]
    fn use_heuristic(&self) -> bool {
        self.inner.use_heuristic()
    }

    /// Return ``True`` if the given ID is present in the index.
    fn contains(&self, id: &str) -> bool {
        self.inner.contains(id)
    }

    fn __repr__(&self) -> String {
        format!(
            "HnswIndex(len={}, dim={}, metric='{}', use_heuristic={})",
            self.inner.len(),
            self.inner.dimension(),
            self.inner.metric().as_str(),
            self.inner.use_heuristic()
        )
    }
}

/// Create a sample corpus for testing.
#[pyfunction]
fn create_sample_corpus() -> PyDocumentCorpus {
    PyDocumentCorpus {
        inner: rust_create_sample_corpus(),
    }
}

/// Get the version of the library.
#[pyfunction]
fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// Vajra Search - High-performance BM25 search using category theory
#[pymodule]
fn _vajra_search(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;

    // Classes
    m.add_class::<PyDocument>()?;
    m.add_class::<PyDocumentCorpus>()?;
    m.add_class::<PyBM25Params>()?;
    m.add_class::<PySearchResult>()?;
    m.add_class::<PyVajraSearch>()?;
    m.add_class::<PyVajraSearchParallel>()?;
    m.add_class::<PyHnswIndex>()?;

    // Functions
    m.add_function(wrap_pyfunction!(create_sample_corpus, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;

    Ok(())
}
