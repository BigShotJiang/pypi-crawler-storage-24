"""CLI package for DeepSeek"""
