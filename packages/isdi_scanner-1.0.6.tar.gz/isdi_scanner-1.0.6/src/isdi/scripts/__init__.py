"""ISDI shell scripts package."""
