import os
import csv
import argparse
import importlib.metadata
import subprocess
import hashlib
import re
from tqdm import tqdm
from .downloader import download_song
from .metadata_fetcher import get_clean_metadata
from .tagger import apply_metadata

# --- AUTOMATIC VERSIONING ---
def get_version():
    try:
        return importlib.metadata.version("mymusic-dl-Rajthespaceman")
    except importlib.metadata.PackageNotFoundError:
        return "1.5.0" 

__version__ = get_version()

def get_query_hash(query):
    """Generates a unique 8-character hash for a song query."""
    return hashlib.md5(query.encode('utf-8')).hexdigest()[:8]

def run_from_csv(csv_file):
    """Main execution logic with Hash-Verification and Pre-run Cleanup."""
    os.system('cls' if os.name == 'nt' else 'clear')
    
    backup_dir = "backup"
    history_file = os.path.join(backup_dir, "downloaded_history.txt")
    failed_file = os.path.join(backup_dir, "failed_songs.txt") 
    
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    # 1. --- LOAD REGISTERED HASHES ---
    registered_hashes = set()
    if os.path.exists(history_file):
        with open(history_file, "r", encoding="utf-8") as h:
            registered_hashes = {line.strip() for line in h if line.strip()}

    # 2. --- PRE-RUN CLEANUP: Delete Widow/Unregistered Files ---
    # We look for files ending in [HASH].mp3
    search_dirs = [os.getcwd(), "downloads"]
    for d in search_dirs:
        if not os.path.exists(d): continue
        for filename in os.listdir(d):
            if filename.endswith(".mp3"):
                # Extract hash from [hash].mp3 using regex
                match = re.search(r'\[([a-f0-9]{8})\]\.mp3$', filename)
                if match:
                    file_hash = match.group(1)
                    if file_hash not in registered_hashes:
                        # This is a widow file (interrupted download) - Delete it
                        try:
                            os.remove(os.path.join(d, filename))
                            print(f"🧹 Cleaned up unregistered file: {filename}")
                        except Exception: pass

    if not os.path.exists(csv_file):
        print(f"🎵 PRO MUSIC PIPELINE v{__version__}\n❌ Error: '{csv_file}' not found!")
        return

    # 3. --- LOAD SONGS & GENERATE HASHES ---
    songs_data = [] # List of tuples: (query, hash)
    try:
        with open(csv_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                track = row.get('Track Name')
                artist = row.get('Artist Name(s)')
                if track and artist:
                    q = f"{track} - {artist}"
                    songs_data.append((q, get_query_hash(q)))
    except Exception as e:
        print(f"❌ Failed to read CSV: {e}"); return

    # 4. --- PROCESS WITH HASH-SKIP ---
    failed_songs = []
    pbar = tqdm(songs_data, desc="📥 Progress", unit="song", dynamic_ncols=True)
    
    try:
        for query, q_hash in pbar:
            # SKIP: Check if hash is registered AND file physically exists with that hash
            hash_pattern = f"[{q_hash}].mp3"
            file_exists = any(
                any(f.endswith(hash_pattern) for f in os.listdir(d)) 
                for d in search_dirs if os.path.exists(d)
            )

            if q_hash in registered_hashes and file_exists:
                continue

            success = False
            for attempt in range(3):
                temp_path = None
                try:
                    s_name, a_name = query.split(" - ", 1) if " - " in query else (query, "")
                    data = get_clean_metadata(s_name, a_name)
                    
                    temp_path = download_song(query)
                    
                    if temp_path and os.path.exists(temp_path):
                        # --- HASH RENAME: Mirror Exportify + [HASH] ---
                        final_filename = f"{query} [{q_hash}].mp3"
                        os.rename(temp_path, final_filename)
                        
                        if data: 
                            apply_metadata(final_filename, data)
                        
                        # --- VERIFIED REGISTRATION ---
                        with open(history_file, "a", encoding="utf-8") as h:
                            h.write(f"{q_hash}\n")
                        registered_hashes.add(q_hash)
                            
                        success = True
                        break 
                except Exception:
                    if temp_path and os.path.exists(temp_path):
                        os.remove(temp_path)
                    continue 
            
            if not success:
                failed_songs.append(query)
                with open(failed_file, "a", encoding="utf-8") as f:
                    f.write(f"{query}\n")

    except KeyboardInterrupt:
        print("\n\n🛑 Interrupted! Widow files will be cleaned on next run.")
        return

    print("\n✨ Process Complete!")
    if failed_songs:
        print(f"\n❌ {len(failed_songs)} failures. Check backup/failed_songs.txt")
    else:
        print("✅ All songs are synced and hash-verified!")

def main():
    parser = argparse.ArgumentParser(prog="music")
    parser.add_argument("-i", "--input", help="CSV path", default="playlist.csv")
    parser.add_argument("-s", "--search", help="Single search", default=None)
    parser.add_argument("--open", help="Open folder", action="store_true")
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    args = parser.parse_args()

    if args.open:
        path = os.getcwd()
        os.startfile(path) if os.name == 'nt' else subprocess.run(['open', path])
        return

    if args.search:
        h = get_query_hash(args.search)
        path = download_song(args.search)
        if path and os.path.exists(path):
            final = f"{args.search} [{h}].mp3"
            os.rename(path, final)
            if " - " in args.search:
                s, a = args.search.split(" - ", 1)
                data = get_clean_metadata(s, a)
                if data: apply_metadata(final, data)
        return

    run_from_csv(args.input)

if __name__ == "__main__":
    main()