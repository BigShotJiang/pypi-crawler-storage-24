# 
# SPDX-FileCopyrightText: Copyright (c) provide.io llc. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#

"""Client and server classes corresponding to protobuf-defined services."""

import grpc
import warnings

from . import grpc_broker_pb2 as grpc__broker__pb2

GRPC_GENERATED_VERSION = '1.75.0'
GRPC_VERSION = grpc.__version__
_version_not_supported = False

try:
    from grpc._utilities import first_version_is_lower
    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True

if _version_not_supported:
    raise RuntimeError(
        f'The grpc package installed is at version {GRPC_VERSION},'
        + f' but the generated code in grpc_broker_pb2_grpc.py depends on'
        + f' grpcio>={GRPC_GENERATED_VERSION}.'
        + f' Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}'
        + f' or downgrade your generated code using grpcio-tools<={GRPC_VERSION}.'
    )


class GRPCBrokerStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.StartStream = channel.stream_stream(
                '/plugin.GRPCBroker/StartStream',
                request_serializer=grpc__broker__pb2.ConnInfo.SerializeToString,
                response_deserializer=grpc__broker__pb2.ConnInfo.FromString,
                _registered_method=True)


class GRPCBrokerServicer(object):
    """Missing associated documentation comment in .proto file."""

    def StartStream(self, request_iterator, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_GRPCBrokerServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'StartStream': grpc.stream_stream_rpc_method_handler(
                    servicer.StartStream,
                    request_deserializer=grpc__broker__pb2.ConnInfo.FromString,
                    response_serializer=grpc__broker__pb2.ConnInfo.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'plugin.GRPCBroker', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('plugin.GRPCBroker', rpc_method_handlers)


 # This class is part of an EXPERIMENTAL API.
class GRPCBroker(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def StartStream(request_iterator,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.stream_stream(
            request_iterator,
            target,
            '/plugin.GRPCBroker/StartStream',
            grpc__broker__pb2.ConnInfo.SerializeToString,
            grpc__broker__pb2.ConnInfo.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

# 🐍🔌📞🔚
