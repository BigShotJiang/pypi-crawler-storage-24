#
# SPDX-FileCopyrightText: Copyright (c) provide.io llc. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#

"""Base Definitions for RPC Plugin Protocols.

This module provides the abstract base class `RPCPluginProtocol`
which defines the interface for protocol implementations used within
the Pyvider RPC Plugin system."""

from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

ServerT = TypeVar("ServerT")
HandlerT = TypeVar("HandlerT")


class RPCPluginProtocol(ABC, Generic[ServerT, HandlerT]):  # pragma: no cover
    """
    Abstract base class for defining RPC protocols.
    ServerT: Type of gRPC server
    HandlerT: Type of handler implementation
    """

    @abstractmethod
    async def get_grpc_descriptors(self) -> tuple[Any, str]:
        """Returns the protobuf descriptor set and service name."""

    @abstractmethod
    async def add_to_server(self, server: ServerT, handler: HandlerT) -> None:
        """
        Adds the protocol implementation to the gRPC server.

        Args:
            server: The gRPC async server instance.
            handler: The handler implementing the RPC methods for this protocol.
        """


# 🐍🔌📞🔚
