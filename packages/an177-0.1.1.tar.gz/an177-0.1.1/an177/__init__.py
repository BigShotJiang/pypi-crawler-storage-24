import os, sys, time, hashlib, marshal, lzma, base64, gc, zlib, json

def run_cmd(data, k_enc):
    # Định nghĩa màu sắc
    G, R, W = "\033[92m", "\033[91m", "\033[0m"
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Giao diện tiếng Việt
    print(f"{G}╔{'═'*31}╗")
    print(f"║{' '*10}VINH AN 177{' '*10}║")
    print(f"╚{'═'*31}╝{W}")

    try:
        # Tầng 1: Xác thực dữ liệu
        _d = "".join(data.split()).strip()
        _key_core = hashlib.sha384(_d.encode('utf-8')).hexdigest()
        
        print(f"{G} Đang phân tích ", end="", flush=True)
        time.sleep(0.5)

        _k_b = base64.b85decode(k_enc.strip().encode('utf-8'))
        _h_v = hashlib.sha256(_key_core.encode('utf-8')).digest()
        
        _m_r = bytearray(b ^ _h_v[i % 32] for i, b in enumerate(_k_b))
        _m_d = json.loads(_m_r.decode('utf-8'))
        _rev = {v: k for k, v in _m_d.items()}
        
        _b85_p = ""
        for i in range(0, len(_d), 3):
            _chunk = _d[i:i+3]
            _b85_p += _rev.get(_chunk, "")

        _raw = base64.b85decode(_b85_p.encode('utf-8'))
        _unflip = bytes([b ^ 0xFF for b in _raw[::-1]])
        _dec = lzma.decompress(zlib.decompress(_unflip))
        
        print(f"\n{G} Đang khởi chạy tool...{W}")
        
        del data, _d, _k_b, _m_r, _rev, _b85_p, _raw, _unflip
        gc.collect()
        
        exec(marshal.loads(_dec), globals())

    except Exception as e:
        print(f"\n{R} Dữ liệu đã bị hỏng hoặc bị sửa đổi!{W}")
        sys.exit()