"""Programmatic Selenium capture example."""

from __future__ import annotations

import asyncio
from pathlib import Path

from screenshot import ScreenshotOptions, capture_screenshots_async_selenium
from screenshot.models import CaptureOptions


async def main() -> None:
    options = ScreenshotOptions(
        capture=CaptureOptions(
            enabled=True,
            viewports=("desktop",),
            depth=0,
            scroll=False,
            full_page=False,
        )
    )
    result = await capture_screenshots_async_selenium(
        "example-selenium",
        "https://example.com",
        store_dir=Path("selenium-output"),
        partition_date=None,
        options=options,
    )
    print(result.outcome.value, result.captured, result.failed)


if __name__ == "__main__":
    asyncio.run(main())
