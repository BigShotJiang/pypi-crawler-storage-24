"""Parsing helpers that fan out CLI arguments into raw job records."""

from __future__ import annotations

import json
from collections.abc import Sequence
from pathlib import Path

from .schema import RawJobRecord, ScreenshotCliArgs
from .utils import derive_job_id

__all__ = ["load_cli_inputs"]


def _load_snippets(paths: Sequence[Path]) -> list[str]:
    snippets: list[str] = []
    for path in paths:
        snippets.append(path.read_text(encoding="utf-8"))
    return snippets


def _input_error(path: Path, line_number: int, message: str) -> ValueError:
    return ValueError(f"{path}:{line_number}: {message}")


def _optional_string(path: Path, line_number: int, field: str, value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise _input_error(path, line_number, f"'{field}' must be a string")
    text = value.strip()
    return text or None


def load_cli_inputs(args: ScreenshotCliArgs) -> tuple[list[RawJobRecord], list[str], list[str]]:
    """Return raw job records plus pre-loaded CSS/JS snippets."""

    backend = (args.backend or "playwright").strip().lower()
    css_snippets = _load_snippets(args.extra_css_paths)
    js_snippets = _load_snippets(args.extra_js_paths)

    records: list[RawJobRecord] = []

    if args.input:
        with args.input.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                record = json.loads(line)
                if not isinstance(record, dict):
                    raise _input_error(args.input, line_number, "expected JSON object")

                url = _optional_string(args.input, line_number, "url", record.get("url"))
                if url is None:
                    raise _input_error(args.input, line_number, "missing non-empty 'url'")

                job_id = (
                    _optional_string(args.input, line_number, "job_id", record.get("job_id"))
                    or _optional_string(args.input, line_number, "site_id", record.get("site_id"))
                    or derive_job_id(url)
                )
                partition = (
                    _optional_string(
                        args.input,
                        line_number,
                        "partition_date",
                        record.get("partition_date"),
                    )
                    or args.partition_date
                )

                raw_options = record.get("options")
                if raw_options is None:
                    overrides = None
                elif isinstance(raw_options, dict):
                    overrides = raw_options
                else:
                    raise _input_error(args.input, line_number, "'options' must be an object")

                snapshot_path = _optional_string(
                    args.input,
                    line_number,
                    "html_snapshot_path",
                    record.get("html_snapshot_path"),
                )

                metadata = record.get("metadata")
                if metadata is None:
                    metadata_dict: dict[str, object] = {}
                elif isinstance(metadata, dict):
                    metadata_dict = dict(metadata)
                else:
                    raise _input_error(args.input, line_number, "'metadata' must be an object")
                metadata_dict.setdefault("source", "cli")
                records.append(
                    RawJobRecord(
                        job_id=job_id,
                        url=url,
                        backend=backend,
                        partition_date=partition,
                        html_snapshot_path=snapshot_path,
                        metadata=metadata_dict,
                        options_override=overrides,
                    )
                )

    urls = [url.strip() for url in (args.urls or []) if url and url.strip()]
    site_ids = [sid.strip() for sid in (args.site_ids or []) if sid and sid.strip()]
    if urls:
        for index, url in enumerate(urls):
            fallback = f"site-{index + 1}"
            job_id = (
                site_ids[index] if index < len(site_ids) else derive_job_id(url, fallback=fallback)
            )
            records.append(
                RawJobRecord(
                    job_id=job_id,
                    url=url,
                    backend=backend,
                    partition_date=args.partition_date,
                    html_snapshot_path=None,
                    metadata={"source": "cli", "input": "args"},
                    options_override=None,
                )
            )

    return records, css_snippets, js_snippets
