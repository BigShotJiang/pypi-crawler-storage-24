"""Shared models and services for screenshot capture backends."""

from __future__ import annotations

__version__ = "0.2.0"

import logging

from . import backends, capabilities
from ._shared.storage import (
    AsyncStorageBackend,
    CloudStorageBackend,
    LocalStorageBackend,
    StorageBackend,
)
from .capabilities import CAPABILITIES, Capability, find_capabilities
from .models import (
    ScreenshotBatchResult,
    ScreenshotCaptureOutcome,
    ScreenshotCaptureResult,
    ScreenshotJob,
    ScreenshotOptions,
)
from .playwright_runner import KNOWN_VIEWPORTS, capture_screenshots, capture_screenshots_async
from .selenium_runner import capture_screenshots_async as capture_screenshots_async_selenium
from .service import ScreenshotBackend, ScreenshotService

logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    "ScreenshotBatchResult",
    "ScreenshotCaptureResult",
    "ScreenshotCaptureOutcome",
    "ScreenshotJob",
    "ScreenshotOptions",
    "Capability",
    "CAPABILITIES",
    "find_capabilities",
    "capabilities",
    "backends",
    "ScreenshotBackend",
    "ScreenshotService",
    "KNOWN_VIEWPORTS",
    "LocalStorageBackend",
    "StorageBackend",
    "CloudStorageBackend",
    "AsyncStorageBackend",
    "capture_screenshots",
    "capture_screenshots_async",
    "capture_screenshots_async_selenium",
]
