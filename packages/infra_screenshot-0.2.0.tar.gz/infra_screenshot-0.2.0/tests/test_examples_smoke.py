from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from typing import Any, cast

import pytest

from screenshot import ScreenshotBatchResult, ScreenshotCaptureResult


def _load_module(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise AssertionError(f"Unable to load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


@pytest.mark.asyncio
async def test_playwright_programmatic_capture_example_runs_with_stubbed_runner() -> None:
    module = _load_module(
        "example_playwright_programmatic_capture",
        Path(__file__).resolve().parents[1] / "examples" / "playwright_programmatic_capture.py",
    )
    module_any = cast(Any, module)

    async def fake_capture(*_args: object, **_kwargs: object) -> ScreenshotCaptureResult:
        return ScreenshotCaptureResult(
            requested=1,
            captured=1,
            failed=0,
            metadata_path=None,
            entries=[],
            errors=[],
            job_id="example-playwright",
        )

    module_any.capture_screenshots_async = fake_capture
    await module_any.main()


@pytest.mark.asyncio
async def test_selenium_programmatic_capture_example_runs_with_stubbed_runner() -> None:
    module = _load_module(
        "example_selenium_programmatic_capture",
        Path(__file__).resolve().parents[1] / "examples" / "selenium_programmatic_capture.py",
    )
    module_any = cast(Any, module)

    async def fake_capture(*_args: object, **_kwargs: object) -> ScreenshotCaptureResult:
        return ScreenshotCaptureResult(
            requested=1,
            captured=1,
            failed=0,
            metadata_path=None,
            entries=[],
            errors=[],
            job_id="example-selenium",
        )

    module_any.capture_screenshots_async_selenium = fake_capture
    await module_any.main()


@pytest.mark.asyncio
async def test_service_batch_capture_example_runs_with_stubbed_service() -> None:
    module = _load_module(
        "example_service_batch_capture",
        Path(__file__).resolve().parents[1] / "examples" / "service_batch_capture.py",
    )
    module_any = cast(Any, module)

    class StubService:
        async def capture_async(self, jobs: list[object]) -> ScreenshotBatchResult:
            assert len(jobs) == 2
            return ScreenshotBatchResult(
                results=[
                    ScreenshotCaptureResult(
                        requested=1,
                        captured=1,
                        failed=0,
                        metadata_path=None,
                        entries=[],
                        errors=[],
                        job_id="example-home",
                    ),
                    ScreenshotCaptureResult(
                        requested=1,
                        captured=1,
                        failed=0,
                        metadata_path=None,
                        entries=[],
                        errors=[],
                        job_id="python-home",
                    ),
                ]
            )

    module_any.build_local_screenshot_service = lambda **_kwargs: StubService()
    await module_any.main()


@pytest.mark.asyncio
async def test_storage_summary_integration_example_runs_with_stubbed_service() -> None:
    module = _load_module(
        "example_storage_summary_integration",
        Path(__file__).resolve().parents[1] / "examples" / "storage_summary_integration.py",
    )
    module_any = cast(Any, module)

    class FakeStorage:
        def write_json(self, path: Path, _data: dict[str, object]) -> Path:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("{}", encoding="utf-8")
            return path

    class StubService:
        async def capture_async(self, jobs: list[object]) -> ScreenshotBatchResult:
            assert len(jobs) == 1
            return ScreenshotBatchResult(
                results=[
                    ScreenshotCaptureResult(
                        requested=1,
                        captured=1,
                        failed=0,
                        metadata_path=None,
                        entries=[],
                        errors=[],
                        job_id="example-storage",
                    )
                ]
            )

    module_any.LocalStorageBackend = FakeStorage
    module_any.build_local_screenshot_service = lambda **_kwargs: StubService()
    await module_any.main()
